from pathlib import Path
import hashlib,json,re,shutil,subprocess,urllib.parse,xml.etree.ElementTree as ET,zipfile

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
OUT=Path(__file__).parent
EVIDENCE=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-acc-1790488541699')
DOCS=ROOT/'docs/releases/v1.3.0'
PREFIX='io/github/sunthemoon/advancedrocketrycommunity/'
BASE='884908ebfb936402bcc7a437791f8d9683c27506'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)

facts={'head':git('rev-parse','HEAD').strip(),'checks':{}}
metadata=load(DOCS/'handoff-verification.json')
shutil.copy2(DOCS/'handoff-verification.json',OUT/'handoff-verification-observed.json')
raw=(EVIDENCE/'full-check.log').read_text(encoding='utf-8-sig')
assert sha(EVIDENCE/'full-check.log')==metadata['build_log_sha256']
assert re.search(r'^> Task :clean\s*$',raw,re.M)
assert re.search(r'^> Task :test\s*$',raw,re.M)
assert 'FROM-CACHE' not in raw and 'All 210 required tests passed' in raw
assert 'written: 0' in raw and 'BUILD SUCCESSFUL in 2m 38s' in raw
assert '27 actionable tasks: 26 executed, 1 up-to-date' in raw
roots=[ET.parse(p).getroot() for p in sorted((EVIDENCE/'frozen/junit').glob('TEST-*.xml'))]
counts={'suites':len(roots),**{key:sum(int(r.get(key,'0')) for r in roots) for key in ('tests','failures','errors','skipped')}}
assert counts=={'suites':143,'tests':769,'failures':0,'errors':0,'skipped':0}
for key,value in counts.items(): assert metadata['junit'][key]==value
warnings=re.findall(r'^.*keep up!.*$',raw,re.M)
assert warnings==metadata['lag_warnings']
facts['checks']['root_run_readback']={'build_sha256':sha(EVIDENCE/'full-check.log'),'junit':counts,
 'required_gametests':210,'duration_seconds':158,'warnings':warnings,'independent_runtime_rerun':False}

artifacts=load(DOCS/'development-artifacts.json')
assert artifacts['development_commit']==BASE and artifacts['candidate_commit'] is None
observed=[]
for entry in artifacts['artifacts']:
    p=EVIDENCE/'frozen'/entry['name']
    assert p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256']
    with zipfile.ZipFile(p) as z:
        names=z.namelist(); assert len(names)==len(set(names))
        if not p.name.startswith('arce-adapter-'):
            assert not any('arceadaptertest/' in n or 'arce_adapter_test/' in n for n in names)
    observed.append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
build=(ROOT/'compat-test-mod/build.gradle').read_text()
expected={PREFIX+s for s in re.findall(r"'(api/[^']+\.class)'",build.split('repositories {')[0])}
assert len(expected)==27
with zipfile.ZipFile(EVIDENCE/'frozen/advancedrocketry-community-1.20.1-1.3.0-dev-api.jar') as a, zipfile.ZipFile(EVIDENCE/'frozen/advancedrocketry-community-1.20.1-1.3.0-dev.jar') as m:
    assert {n for n in a.namelist() if n.endswith('.class')}==expected
    assert {n for n in m.namelist() if n.startswith(PREFIX+'api/') and n.endswith('.class')}==expected
    assert all(a.read(n)==m.read(n) for n in expected)
old=load(ROOT/'docs/work/v1.3.0-compatibility/artifact-identities.json')
for entry in observed:
    if entry['name'].startswith('arce-adapter-'):
        reference=load(ROOT/'docs/work/v1.3.0-compatibility/final-fixture-identity.json')
    else: reference=next(x for x in old if x['name']==entry['name'])
    assert entry['sha256']==reference['sha256'] and entry['bytes']==reference['bytes']
facts['checks']['artifacts']={'api_class_count':len(expected),'exact_runtime_class_bytes':True,'artifacts':observed}

index=load(DOCS/'evidence-index.json')
assert index['development_commit']==BASE and index['candidate_commit'] is None and index['manifest_failures']==[]
pins=0;manifest_count=0;entries=0
for record in index['records']:
    assert record['kind']=='historical_development_evidence'
    for item in [record['report'],*record['metadata'],*([record['manifest']] if record['manifest'] else [])]:
        p=(ROOT/item['path']).resolve()
        assert p.is_relative_to((ROOT/'docs/work').resolve())
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];pins+=1
    if record['manifest']:
        manifest_count+=1; p=ROOT/record['manifest']['path'];count=0
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip():continue
            digest,relative=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line).groups()
            target=(p.parent/relative).resolve();assert target.is_relative_to(p.parent.resolve())
            assert sha(target)==digest.lower();count+=1
        assert count==record['manifest_files_checked'];entries+=count
    else: assert record['manifest_files_checked']==0
facts['checks']['evidence_index']={'reports':len(index['records']),'pinned_files':pins,'manifests':manifest_count,'manifest_entries':entries}

changed=[ROOT/p for p in git('diff','--name-only',BASE).splitlines() if p.endswith('.md')]
markdown=sorted(set(changed+list(DOCS.glob('*.md'))))
links=0;missing=[]
for p in markdown:
    text=p.read_text(encoding='utf-8-sig')
    # Ignore fenced examples; inspect local inline Markdown destinations only.
    text=re.sub(r'(?ms)^\s*(`{3,}|~{3,})[^\n]*\n.*?^\s*\1\s*$', '',text)
    for link in re.findall(r'\[[^\]\n]*\]\(([^)\s]+)\)',text):
        target=urllib.parse.urlsplit(link)
        if target.scheme or target.netloc or not target.path:continue
        relative=urllib.parse.unquote(target.path)
        assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in relative
        dest=(p.parent/relative).resolve(); links+=1
        if not dest.is_relative_to(ROOT.resolve()) or not dest.exists():missing.append({'file':str(p.relative_to(ROOT)),'link':link})
facts['checks']['local_links']={'documents':len(markdown),'links':links,'missing':missing,
 'scope':'local file/directory destinations; no anchor or remote fetch'}
assert all(x['link']=='checksums.txt' for x in missing),missing

manifest=DOCS/'checksums.txt'
covered=[]
for line in manifest.read_text(encoding='utf-8-sig').splitlines():
    if not line.strip():continue
    digest,relative=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line).groups()
    target=(DOCS/relative).resolve();assert target.is_relative_to(DOCS.resolve())
    assert sha(target)==digest.lower();covered.append(relative)
assert len(covered)==len(set(covered))
assert set(covered)=={p.relative_to(DOCS).as_posix() for p in DOCS.rglob('*') if p.is_file() and p!=manifest}
with zipfile.ZipFile(DOCS/'handoff-checks.zip') as archive:
    names=archive.namelist();assert len(names)==len(set(names))
    assert sum(x.file_size for x in archive.infolist())<8*1024*1024
    assert archive.testzip() is None
    assert hashlib.sha256(archive.read('root/full-check.log')).hexdigest()==metadata['build_log_sha256']
    xml_names=[n for n in names if n.startswith('junit/TEST-') and n.endswith('.xml')]
    assert len(xml_names)==143
    for name in xml_names:
        assert archive.read(name)==(EVIDENCE/'frozen'/name).read_bytes()
facts['checks']['handoff_archive']={'entries':len(names),'junit_xml_files':len(xml_names),
 'sha256':sha(DOCS/'handoff-checks.zip'),'crc_check':'PASS','raw_log_and_xml_byte_identity':True,
 'manifest_entries':len(covered),'manifest_sha256':sha(manifest)}

assert git('diff',BASE,'--','src','gradle.properties','build.gradle','settings.gradle','compat-test-mod/build.gradle')==''
facts['checks']['production_diff_empty']=True
(OUT/'handoff-checks.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
print(json.dumps(facts,indent=2))
