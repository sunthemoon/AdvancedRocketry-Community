from pathlib import Path
import hashlib,json,re,subprocess,zipfile
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
OUT=Path(__file__).parent
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
tracked=set(subprocess.check_output(['git','ls-files','docs/work'],cwd=ROOT,text=True).splitlines())
facts={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
       'manifests':[],'verification_reports':[],'archives':[]}
for name in sorted(tracked):
    p=ROOT/name
    if not name.startswith('docs/work/v1.3.0-'): continue
    if p.name=='VERIFICATION.md' and len(p.relative_to(ROOT).parts)==4:
        facts['verification_reports'].append({'file':name,'sha256':sha(p),
          'scope_lines':[{'line':i,'text':s} for i,s in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1)
          if re.search(r'not |unexecuted|unverified|remain|boundary|boundaries|crash|power.loss|FROM.CACHE|from .*cache|downgrade|warning|synthetic|no .*(?:Gate|release|client)',s,re.I)]})
    if p.name=='SHA256SUMS' and len(p.relative_to(ROOT).parts)==4:
        errors=[];count=0;size=0
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip():continue
            match=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line)
            if not match: errors.append({'line':line,'error':'format'}); continue
            digest,relative=match.groups(); target=(p.parent/relative).resolve()
            if not target.is_relative_to(p.parent.resolve()): errors.append({'file':relative,'error':'outside folder'});continue
            if not target.is_file(): errors.append({'file':relative,'error':'missing'});continue
            if target.stat().st_size>256*1024*1024: errors.append({'file':relative,'error':'not checked: per-file review bound'});continue
            count+=1;size+=target.stat().st_size
            if sha(target)!=digest.lower():errors.append({'file':relative,'error':'hash mismatch'})
        facts['manifests'].append({'file':name,'entries':count,'bytes':size,'errors':errors})
    if p.name in ('build-evidence.zip','independent-review.zip') and len(p.relative_to(ROOT).parts)==4:
        with zipfile.ZipFile(p) as z:
            names=z.namelist()
            facts['archives'].append({'file':name,'entries':len(names),'duplicate_entries':len(names)-len(set(names))})
(OUT/'inventory.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in facts.items() if k!='verification_reports'},indent=2))
print('verification_reports',len(facts['verification_reports']))
