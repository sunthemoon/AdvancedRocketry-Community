# V130-ACC development-handoff inventory review

## Findings requiring handoff disposition

### Medium — broad version-plan phrases must not be treated as literally verified contracts

`docs/versions/V1.3.0-PUBLIC-API-COMPATIBILITY.md:61-64,87-90,124,132,178` still contains planning shorthand: compatibility handshake; sanitize/rollback lifecycle; rewriting old tags/config to a new namespace/version; complete exception isolation; controlled query cache; rollback of the entire transaction. The accepted contracts and actual implementation are more precise:

- `ADR-021-PUBLIC-API-VERSION-POLICY.md:38-46,103-108`: Java metadata compatibility check, not loader/network negotiation. Actual `ApiVersions.java:7,17-28` offers 1.7 and returns a compatibility enum. The consumer decides how to report or reject incompatibility.
- `ADR-022-ROCKET-ADAPTER-REGISTRATION.md:23-27,55-64,69-93`: public canMove/capture/restore only; validation and checked cleanup are host responsibilities. Runtime exception/invalid return/late return handling is not preemption, OOM containment, arbitrary side-effect rollback, or cross-chunk fsync atomicity.
- `RocketAdapterRegistry.java:73-80` keeps the built-in vanilla container adapter first in the frozen catalog. The original vanilla payload ID/format stays unchanged under ADR-022:69-70; no global tag/config namespace rewrite occurred.
- `ServerEnvironmentQueries.java:24-56,85-92` binds a read-only query to one server and clears its binding on close. ADR-028:78 specifies bounded existing indices, **no new per-position cache**. This satisfies the bounded-memory goal without implementing a new cache.

Recommendation: include an explicit requirement-to-ADR disposition table. Do not implement a redundant cache, migration framework or preemptive callback machinery merely to satisfy old shorthand; do not check the broad phrases as unconditional guarantees. This is a documentation/acceptance-mapping issue, not an established runtime defect.

### Low — packaged mod description understates the implemented API surface

`gradle.properties:32` still says the build contains the machine kernel and "initial public API version metadata", with further extension APIs in progress. Actual `ApiVersions.java:7` is 1.7, and the supported inventory in `docs/API-COMPATIBILITY.md:33-48` lists 27 class entries across all seven provider/query families plus version metadata.

Recommendation: record this stale description as a low-priority development artifact limitation; update it before a future candidate rebuild. A documentation-only handoff should not change or relabel already tested JAR bytes. It is not evidence of missing provider implementation.

### Release-readiness gaps — preserve as unexecuted/partial, not product-defect findings

No new Critical/High runtime defect was established by this bounded inventory review. That does not establish "zero Critical/High" across the version. The following requirements are not closed by the existing development evidence:

1. **Actual crash/power-loss and candidate migration.** Version plan:141 and `docs/17-V1PLUS-QUALITY-BUDGETS.md:7` require more than clean restart. `v1.3.0-external-recovery/VERIFICATION.md:21-25,116-126` uses a deliberately staged durable journal, not an observed crash. `v1.3.0-rocket-failure-containment/VERIFICATION.md:132,147` explicitly labels S1, not S2. ADR-027:135-138 leaves loader/rocket cross-file atomicity open; ADR-029:111-112 makes the same distinction for satellite work. Keep these limitations in G5/G6 and Known Issues instead of calling clean S1 "crash-safe".
2. **Real clients, joins and malicious transport.** Version plan:110,114-119 remains broader than FakePlayer/direct-service/menu tests. `SatelliteTerminalMenu.java:117-121,177-182` validates server player, live loaded BE, permission and catalog generation; `SatelliteTerminalBlockEntity.java:308-317` checks dimension/distance/loaded identity. The packaged satellite actor is explicitly network-free (`v1.3.0-satellite-payloads/VERIFICATION.md:98-102`), and the suit evidence excludes real-player save/HUD/networking (`v1.3.0-suit-equipment/VERIFICATION.md:123-125,173-174`). No new public custom C2S endpoint is exposed, but this is not proof of hostile client packets or V1/V2.
3. **Performance, no-provider overhead and alternate Forge lane.** Version plan:134's near-zero overhead claim has no measured comparative result in the inspected reports. Finite timing checks and 20 ms fault probes validate returned-time policy, not throughput/RSS/P95. Recorded lag warnings remain: fuel 2,056 ms/41 ticks, environment 2,231 ms/44 ticks, compatibility 2,553 ms/51 ticks. Forge 47.4.23 is configured, not certified for the current artifacts (`PROJECT-CONFIG.md`, `docs/API-COMPATIBILITY.md:14-16`).
4. **Candidate/release provenance.** The artifacts are `1.20.1-1.3.0-dev`, not candidate/tag builds. Per-slice hashes and results do not certify every later artifact. G0 license/provenance audit, clean candidate R1/CI/reproducibility, installation by an independent user, complete manual flow and human approval remain separate. No release publication or remote Maven upload was established here.

These are explicit handoff items, not requests to start the deferred full campaign. ADR-018 defers full remote/long-load/real-GPU/two-client/all-content campaigns but does not produce PASS or waive bounded safety checks. ADR-020:44-46 excludes v1.4+ production, and :69-72 expires before a v1.3 candidate. Completing V130-ACC documentation does not by itself authorize a v1.4 implementation branch or approve inherited Gates.

## Requirement / evidence / applicability inventory

| Requirement | Existing implementation and committed evidence | Handoff distinction / remaining coverage |
|---|---|---|
| Public version/classifier and isolated consumer | ADR-021; `v1.3.0-api-version/VERIFICATION.md`; `v1.3.0-consumer-packaging/VERIFICATION.md`; final compatibility record has exact 27 exports and API/main byte identity | Metadata check != loader/network handshake; API classifier is compile-only, not installed/shaded; fixtures share source but compile as an isolated ForgeGradle project |
| Rocket movable/adapter registry | ADR-022; common setup `AdvancedRocketryCommunity.java:204-206`; `RocketAdapterRegistry.java:32-46,49-80`; registered type matching plus existing tags/forbidden rules | Not arbitrary BE mobility. Vanilla chest/barrel precedence remains; capture/restore trusted-provider contracts, not a sandbox |
| Exceptions/oversize/slow returns, cleanup and retry | `v1.3.0-compatibility/VERIFICATION.md:20-45,75-110`; 11 added GameTests; independent 210 Required / 5 forced JUnit / consumer boundary | Initial diagnostic-oracle failure retained; nine actual callback probes. No forced crash, nonreturning callback, external side-effect compensation or direct journal durability claim |
| External inventory Earth-Moon-Earth | `v1.3.0-external-flight/VERIFICATION.md`, real production flights and four clean JVMs | No passengers/real client; fuel exactness originally stopped at landing. ADR-023 and fueled-disassembly record subsequently require explicit consent to discard remaining fuel; do not advertise fuel recovery |
| Missing adapter/mod recovery | `v1.3.0-external-recovery/VERIFICATION.md:107-150`, actual uninstall/reinstall and exact native snapshot/journal/container observations | Protects captured snapshot/journal authority, not arbitrary unknown ordinary world blocks/items. Synthetic precommit journal and finite S1, not S2 |
| Atmosphere boundary | ADR-024; `AtmosphereBoundaryRegistry.java:20-26,89-115` bounded state compilation; four-process `v1.3.0-atmosphere-boundaries/VERIFICATION.md` | Registration skipped with block still installed; not actual removal of arbitrary block mods. World-dependent callbacks unsupported; silent changes without notifications unsupported |
| Suit/oxygen | ADR-025; `SuitOxygenPayloads.java:18,22,33,49`; real life-support/canister integration; `v1.3.0-suit-equipment/VERIFICATION.md:77-125` | Native chest ItemStack and canister counts; auxiliary armor recreated. Missing registration is not removal of the item mod; no real-player save/HUD or arbitrary fluid/capability support |
| Component definitions | ADR-026; registry freezes declared metrics; `v1.3.0-rocket-components/VERIFICATION.md` and its four-process record | Existing snapshots retain numeric stats across changed/skipped registration; no new schema. No custom movement authority or arbitrary block uninstall proof; names/icons use registered blocks |
| Item fuels and loader migration | ADR-027; `FuelLoaderStorage.java:9-15,45-52,78-92`; `v1.3.0-rocket-fuels/VERIFICATION.md:120-148` | Valid schema 1 migrates to 2; input/remainder/batch preserved. Native legacy root is an injected migration fixture (`run_v130_fuel_smoke.py:2-5,170`), not proof of an authentic stable world's full upgrade |
| Environment/context query | ADR-028; `ServerEnvironmentQueries.java:38-56,59-87`; `v1.3.0-environment-queries/VERIFICATION.md:67-117` | No chunk access/new position cache; configured metadata, not effective entity gravity/local oxygen/permissions. Native accepted reload only; rejected celestial candidate retention is focused test evidence |
| Satellite payload extension | ADR-029; `v1.3.0-satellite-payloads/VERIFICATION.md:96-170` | Declarative research tasks, not custom reward callbacks. Actual fixture uninstall but payload is vanilla amethyst, not an absent third-party item. New menu wire format, unchanged persistence schemas; replay diagnostic 9 vs 12 explicitly corrected |
| Supported-use/compatibility documentation | `docs/API-COMPATIBILITY.md`, `docs/PUBLIC-API-GUIDE.md`, `compat-test-mod/README.md`, latest compatibility report | Declares side/thread/lifetime, limits, missing-provider policies, dependency/ABI boundaries and historical artifact limits. Not a modpack compatibility matrix or remote published-support promise |

## Migration and network ledger required in the handoff

The migration report should separate these identities rather than use one ambiguous `save_schema` or `network_protocol` number:

- Java API 1.7 (`api/version/ApiVersions.java:7`), independent of mod `1.3.0-dev` and MC DataVersion. No project-wide DataVersion migration is introduced.
- Rocket snapshot schema 1 (`rocket/RocketLimits.java:5`), assembly journal schema 2 (`rocket/persistence/RocketTransactionSavedData.java:31`), flight data 2 (`rocket/flight/RocketFlightLimits.java:8`), nested flight plan 3 (`rocket/flight/RocketFlightPlan.java:23`), transfer root/record 2. These were not all newly introduced by v1.3. External payloads add exact-version `{payload_version,data}` inside the existing adapter data (`compat/rocket/RocketAdapterPayloads.java:13-35`); no automatic provider format migration.
- New external suit key `arce_suit_provider`, envelope schema 1 plus provider payload version. Built-in `arce_space_suit_oxygen` is unchanged; future/unknown payload retention is not an arbitrary item-mod uninstall guarantee.
- Fuel Loader `arce_fuel_loader` live schema 2 with explicit schema-1 migration. Legacy `FuelLoaderPersistence` is deliberately still schema 1; it is not the live writer. Rollback should restore the pre-upgrade world backup, not break schema-2 loaders in an old binary (ADR-027:115-117).
- Satellite terminal/item/definition/mission/state schemas remain 1; registry root remains 2. New preservation/quarantine behavior does not imply safe serialization of arbitrary over-budget corrupted NBT or recovery from no-drop destruction (ADR-029:93-112).
- Exact channel checks remain celestial 1, life support 1, rocket visual 1, rocket flight 6 (respective `*Network.java:12-27`). **Satellite menu extra data did change**: marker -1 and format version 1 (`SatelliteTerminalTargets.java:14-15,43-60`), bounded dictionary/count/UTF encoding (:63-93), matching builds required. Unchanged channel numbers are not a mixed-version menu compatibility promise.
- Full prior stable/beta/rc -> final candidate upgrade, interruption/repeated-migration matrix and downgrade behavior are not collectively established by these individual source/fixture checks. Preserve earlier v1.2 representative-world evidence with its actual provenance/artifact, not as a new v1.3 run.

## Gate and artifact treatment

`docs/status/CURRENT_VERSION.md` deliberately keeps the earliest unfinished acceptance cursor at v1.0 while explicitly pointing active development to v1.3 under ADR-020. This is not a stale-status defect. The handoff should likewise retain `IN_PROGRESS`, empty candidate/human approval fields, and links to inherited open Gates.

Prior final host/API/sources hashes in `v1.3.0-compatibility/artifact-identities.json` are `d1f9f564...4475`, `50cc9ba0...010bf`, `359a21d3...b8a`. Its native consumer is `4207b9b3...f735`; final corrected GameTest consumer is `759f214d...ec8`. `final-fixture-identity.json` correctly restricts the change to `AdapterFaultGameTests.class` and its nested record. No current all-feature native rerun may be inferred from that delta or from subsequent documentation commits.

The compatibility full JUnit archive is explicitly FROM-CACHE; its independent five-test JUnit and 210 GameTests actually ran. Root has now started a new standard short integration build from unchanged sources. That run was still in progress during this inventory; this review did not inspect mutable build output and does not assign its result or artifact identity. The handoff must distinguish its eventual result from earlier cached evidence and from historical native artifacts.

## Actual checks and evidence

- Baseline observed: `884908ebfb936402bcc7a437791f8d9683c27506`; initial Git status contained only the excluded user bundle. Root subsequently edited canonical planning documentation; root is the sole tracked writer.
- Read `PROJECT-CONFIG.md`, `PRODUCT.md`, required principles/roadmap/test/Gate/quality/coordination docs, actual `V1.3.0-PUBLIC-API-COMPATIBILITY.md`, ADR-018 and accepted ADR-020 through ADR-029, current work log, public compatibility guides, selected production/fixture/runner code and all fourteen top-level per-slice verification reports.
- Commands: read-only `git rev-parse HEAD`, `git status --short`, `git ls-files docs/work`; bounded `Get-Content`/`Get-ChildItem` and `rg -n`/`rg --files` source/document searches. An initial guessed `docs/versions/v1.3.0.md` path and several Bash-style brace/glob forms were rejected by PowerShell; corrected reads used actual filenames. These are inspection-command errors, not test or repository failures.
- Ran `D:/python/pyenv/pyenv-win/shims/python.bat -B <this-directory>/inventory.py`, `PYTHONUTF8=1`: exit 0. `inventory.json` records exact paths and hashes; `inventory.txt` retains output. Rehashed **332 entries across 12 tracked top-level v1.3 SHA256SUMS manifests**, no missing paths or mismatches; **11 selected ZIP central directories**, no duplicate entry names. This is not an exhaustive CRC/decompression audit of every historical archive. API's nested evidence manifest and ATM/Suit's differently organized records are not included in that top-level manifest count.
- No Gradle, server, client, network, remote, Gate validator or new runtime test was executed by this review. No untracked user-bundle content, mutable build output, or running native world was inspected. All review writes are confined to this fresh Temp directory.

Report root: `C:/Users/Administrator/AppData/Local/Temp/arce-v130-acc-review-ij9aj162/`.

## Recommended bounded follow-up

Write the release-folder **development handoff**, mapping every required item to actual scoped evidence or an explicit open/deferred/non-applicable disposition. Include a candidate-blocking gap list, correct schema/network ledger, the stale-description limitation, historical-vs-current artifact identities, and ADR-018/020 boundaries. Then independently review that actual documentation diff and run only the authorized short planning/link checks. No new runtime framework or full campaign is recommended by this inventory.
