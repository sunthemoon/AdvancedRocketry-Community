"""Pin existing v1.3 reports; verify their outer manifests without reinterpreting results."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path('D:/GitHub/AdvancedRocketry-Community')
temp = Path(__file__).parent
work = root / 'docs/work'

def identity(path):
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha}

records, failures = [], []
for report in sorted(work.glob('v1.3.0-*/VERIFICATION.md')):
    directory = report.parent
    manifest = directory / 'SHA256SUMS'
    checked = []
    if manifest.exists():
        for line in manifest.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
            assert match, (manifest, line)
            sha, name = match.groups()
            target = (directory / name).resolve()
            assert target.is_relative_to(directory.resolve()), name
            assert target.is_file() and not target.is_symlink(), target
            entry = identity(target)
            if entry['sha256'] != sha.lower():
                failures.append({'manifest': str(manifest), 'entry': name,
                                 'expected': sha.lower(), 'actual': entry['sha256']})
            checked.append(entry)
    metadata = [identity(path) for path in sorted(directory.iterdir()) if path.is_file()
                and re.search(r'(artifact|identity|summary|runtime|consumer).*(json|txt)$', path.name)]
    records.append({'report': identity(report), 'kind': 'historical_development_evidence',
                    'manifest': identity(manifest) if manifest.exists() else None,
                    'manifest_files_checked': len(checked), 'metadata': metadata})
result = {'schema_version': 1,
          'development_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
          'candidate_commit': None,
          'scope': 'Original report identities and available outer checksums only; not a runtime rerun or candidate acceptance',
          'records': records, 'manifest_failures': failures}
(temp / 'evidence-index.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'reports': len(records), 'manifests': sum(r['manifest'] is not None for r in records),
                  'manifest_entries': sum(r['manifest_files_checked'] for r in records), 'failures': failures}, indent=2))
assert not failures
