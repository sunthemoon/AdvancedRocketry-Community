"""Create and check bounded v1.3 handoff metadata from actual local results."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).parent
OUT = ROOT / 'docs/releases/v1.3.0'
BASE = '884908ebfb936402bcc7a437791f8d9683c27506'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')

def collect():
    log = (TEMP / 'full-check.log').read_text(encoding='utf-8')
    assert re.search(r'^> Task :test\s*$', log, re.M), 'JUnit was not executed'
    assert 'FROM-CACHE' not in log and 'All 210 required tests passed' in log
    assert 'written: 0' in log and 'BUILD SUCCESSFUL in 2m 38s' in log
    roots = [ET.parse(p).getroot() for p in sorted((TEMP / 'frozen/junit').glob('TEST-*.xml'))]
    counts = {'suites': len(roots), **{key: sum(int(r.attrib.get(key, 0)) for r in roots)
                                     for key in ('tests', 'failures', 'errors', 'skipped')}}
    assert counts == {'suites': 143, 'tests': 769, 'failures': 0, 'errors': 0, 'skipped': 0}, counts
    artifacts = []
    for path in sorted((TEMP / 'frozen').glob('*.jar')):
        consumer = path.name.startswith('arce-adapter-')
        artifacts.append({'name': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path),
                          'scope': 'Previously independently built COMPAT consumer; not rebuilt in this handoff'
                          if consumer else 'Rebuilt by the handoff required command at the unchanged source checkpoint'})
    host = TEMP / 'frozen/advancedrocketry-community-1.20.1-1.3.0-dev.jar'
    api = TEMP / 'frozen/advancedrocketry-community-1.20.1-1.3.0-dev-api.jar'
    with zipfile.ZipFile(host) as h, zipfile.ZipFile(api) as a:
        classes = sorted(n for n in a.namelist() if n.endswith('.class'))
        assert len(classes) == 27 and all(a.read(n) == h.read(n) for n in classes)
        assert not any('arceadaptertest/' in n for n in h.namelist())
    expected = json.loads((ROOT / 'docs/work/v1.3.0-compatibility/artifact-identities.json').read_text())
    for artifact in artifacts:
        if not artifact['name'].startswith('arce-adapter-'):
            old = next(a for a in expected if a['name'] == artifact['name'])
            assert old['sha256'] == artifact['sha256'] and old['bytes'] == artifact['bytes']
    final_fixture = json.loads((ROOT / 'docs/work/v1.3.0-compatibility/final-fixture-identity.json').read_text())
    fixture = next(a for a in artifacts if a['name'] == final_fixture['name'])
    assert fixture['sha256'] == final_fixture['sha256']
    write_json(OUT / 'development-artifacts.json', {'schema_version': 1, 'development_commit': BASE,
               'candidate_commit': None, 'artifacts': artifacts, 'api_class_count': len(classes)})
    data = {'schema_version': 1, 'development_commit': BASE, 'candidate_commit': None,
            'command': 'gradlew.bat clean build runData runGameTestServer --offline --no-daemon --no-build-cache --console=plain',
            'exit_code': 0, 'gradle_duration_seconds': 158, 'tasks_executed': 26, 'tasks_up_to_date': 1,
            'junit': {**counts, 'execution': 'fresh; no build-cache result'}, 'required_gametests_passed': 210,
            'datagen_written': 0, 'api_classes_byte_identical': 27,
            'game_test_world': 'disposable world under build/gametest after clean; not an authentic upgrade fixture',
            'lag_warnings': [line.strip() for line in log.splitlines() if "Can't keep up" in line],
            'runtime_repeated': False, 'native_scope': 'Reuse explicitly attributed per-slice evidence, not a new packaged run',
            'build_log_sha256': sha(TEMP / 'full-check.log')}
    write_json(OUT / 'handoff-verification.json', data)
    write_json(OUT / 'evidence-index.json', json.loads((TEMP / 'evidence-index.json').read_text()))
    print(json.dumps({'junit': counts, 'GameTest': 210, 'artifacts': artifacts}, indent=2))

def links():
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', '*.md'], cwd=ROOT).decode().split('\0')
    paths = {ROOT / p for p in tracked if p} | set(OUT.glob('*.md'))
    missing, count = [], 0
    for path in sorted(paths):
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith(('#', 'mailto:')) or re.match(r'^[A-Za-z]:[/\\]', target):
                continue
            relative = urllib.parse.unquote(target.split('#', 1)[0])
            if not relative:
                continue
            count += 1
            if not (path.parent / relative).exists():
                missing.append([path.relative_to(ROOT).as_posix(), target])
    write_json(TEMP / 'links.json', {'targets': count, 'missing': missing})
    print(json.dumps({'targets': count, 'missing': missing}))
    assert not missing

def review():
    sources = {
        'inventory': TEMP.parent / 'arce-v130-acc-review-ij9aj162',
        'handoff': TEMP.parent / 'arce-v130-acc-handoff-review-gnoaynhi',
    }
    reports = []
    with zipfile.ZipFile(OUT / 'independent-review.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for label, directory in sources.items():
            assert directory.resolve().is_relative_to(TEMP.parent.resolve())
            report = directory / 'REVIEW.md'
            assert report.is_file()
            files = sorted(p for p in directory.rglob('*') if p.is_file())
            for path in files:
                assert not path.is_symlink() and path.resolve().is_relative_to(directory.resolve())
                z.write(path, label + '/' + path.relative_to(directory).as_posix())
            reports.append({'scope': label, 'report_entry': label + '/REVIEW.md',
                            'report_sha256': sha(report), 'archived_files': len(files)})
    write_json(OUT / 'independent-review.json', {
        'schema_version': 1, 'development_commit': BASE,
        'scope': 'Development handoff and historical evidence review; not candidate approval',
        'runtime_replayed': False,
        'final_archive_and_staged_integrity': 'Root-owned check after report attachment',
        'reports': reports,
        'archive': 'independent-review.zip',
        'archive_sha256': sha(OUT / 'independent-review.zip'),
    })
    print(json.dumps(reports, indent=2))

def package():
    with zipfile.ZipFile(OUT / 'handoff-checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(TEMP.iterdir()):
            if path.is_file() and path.suffix in ('.log', '.py', '.json'):
                z.write(path, 'root/' + path.name)
        for path in sorted((TEMP / 'frozen/junit').glob('TEST-*.xml')):
            z.write(path, 'junit/' + path.name)
    records = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'checksums.txt')
    (OUT / 'checksums.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in records), encoding='ascii', newline='\n')
    print('Evidence files checksummed:', len(records))

def verify():
    lines = (OUT / 'checksums.txt').read_text().splitlines()
    names = [line.split('  ', 1)[1] for line in lines]
    assert len(names) == len(set(names))
    assert set(names) == {p.name for p in OUT.iterdir() if p.is_file() and p.name != 'checksums.txt'}
    for line in lines:
        expected, name = line.split('  ', 1)
        path = OUT / name
        assert sha(path) == expected, ('working', name)
        staged = subprocess.check_output(['git', 'show', ':' + path.relative_to(ROOT).as_posix()], cwd=ROOT)
        assert hashlib.sha256(staged).hexdigest() == expected, ('staged', name)
    result = json.loads((OUT / 'handoff-verification.json').read_text())
    with zipfile.ZipFile(OUT / 'handoff-checks.zip') as z:
        assert len(z.namelist()) == len(set(z.namelist())) and z.testzip() is None
        assert hashlib.sha256(z.read('root/full-check.log')).hexdigest() == result['build_log_sha256']
        roots = [ET.fromstring(z.read(n)) for n in z.namelist() if n.startswith('junit/TEST-')]
        counts = {'suites': len(roots), **{key: sum(int(r.attrib.get(key, 0)) for r in roots)
                                         for key in ('tests', 'failures', 'errors', 'skipped')}}
        assert all(result['junit'][k] == value for k, value in counts.items())
        assert json.loads(z.read('root/evidence-index.json')) == json.loads((OUT / 'evidence-index.json').read_text())
        assert z.read('root/handoff_evidence.py') == Path(__file__).read_bytes()
    review_data = json.loads((OUT / 'independent-review.json').read_text())
    assert sha(OUT / review_data['archive']) == review_data['archive_sha256']
    with zipfile.ZipFile(OUT / review_data['archive']) as z:
        assert len(z.namelist()) == len(set(z.namelist())) and z.testzip() is None
        for report in review_data['reports']:
            assert hashlib.sha256(z.read(report['report_entry'])).hexdigest() == report['report_sha256']
    print('PASS: working and staged checksum entries:', len(lines))
    print('PASS: both evidence ZIP CRC/entry sets, archived log, 143 JUnit XML and independent reports')

if __name__ == '__main__':
    {'collect': collect, 'links': links, 'review': review, 'package': package, 'verify': verify}[sys.argv[1]]()
