"""Read-only final assembly delta check; all outputs stay in this Temp directory."""
import difflib, hashlib, json, re, subprocess, time, zipfile
from pathlib import Path
from urllib.parse import unquote,urlsplit
ROOT=Path('D:/GitHub/AdvancedRocketry-Community'); OUT=Path(__file__).parent
PREV=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-acc-final-review-8e8e6f2565734b6e871e99bca74c3d72')
INITIAL=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-acc-review-14448b22904b490cb7526bb5f19a3297')
REL=ROOT/'docs/releases/v1.4.0'
def sha(b): return hashlib.sha256(b).hexdigest()
def readj(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
t=time.monotonic(); result={'head':git('rev-parse','HEAD').decode().strip(),'changes':[],'commands':[]}
old={r['path']:r for r in readj(PREV/'observations.json')['staged_inputs']}
files=git('diff','--cached','--name-only').decode().splitlines(); snapshot=[]; deltas=[]
for rel in files:
    raw=git('show',':'+rel); assert raw==(ROOT/rel).read_bytes(),rel
    snapshot.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
    if rel not in old or old[rel]['sha256']!=sha(raw):
        result['changes'].append(rel)
        if rel.endswith('.md'):
            before=(PREV/'inputs'/rel).read_text() if rel in old else ''
            deltas.extend(difflib.unified_diff(before.splitlines(True),raw.decode().splitlines(True),fromfile='prior/'+rel,tofile='current/'+rel))
(OUT/'text-delta.patch').write_text(''.join(deltas),encoding='utf-8')
assert all(r.startswith('docs/releases/v1.4.0/') or r=='docs/work/v1.4.0-implementation-log.md' for r in result['changes'])
result['staged_inputs']=snapshot
checks={}
for row in (REL/'checksums.txt').read_text().splitlines():
    digest,name=row.split('  ',1); assert name not in checks
    assert sha((REL/name).read_bytes())==digest; checks[name]=digest
assert set(checks)=={p.name for p in REL.iterdir() if p.is_file() and p.name!='checksums.txt'}
result['handoff_checksums']=len(checks)
for stem in ['handoff-checks','independent-review']:
    with zipfile.ZipFile(REL/(stem+'.zip')) as z:
        names=z.namelist(); assert len(names)==len(set(names)) and z.testzip() is None
        rows={r['path']:r for r in readj(REL/(stem+'-files.json'))}; assert set(rows)==set(names)
        for name,row in rows.items():
            raw=z.read(name); assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
        if stem=='handoff-checks':
            with zipfile.ZipFile(PREV/'inputs/docs/releases/v1.4.0/handoff-checks.zip') as earlier:
                assert set(earlier.namelist()).issubset(names)
                changed=[n for n in earlier.namelist() if z.read(n)!=earlier.read(n)]
                assert changed==['check_handoff.py']
                result['root_archive_changed']=[{'path':n,'before':sha(earlier.read(n)),'after':sha(z.read(n))} for n in changed]
                result['root_archive_added']=sorted(set(names)-set(earlier.namelist()))
                assert result['root_archive_added']==['collect-governance.log','git-checks.log','planning.log','provenance.log','repository.log']
            result['root_governance']={n:z.read(n).decode('utf-8-sig') for n in result['root_archive_added']}
        else:
            for name in names:
                directory,member=name.split('/',1)
                source={PREV.name:PREV,INITIAL.name:INITIAL}[directory]/member
                assert source.read_bytes()==z.read(name),name
            manifest=z.read(PREV.name+'/SHA256SUMS')
            assert sha(manifest)=='353469ad28e9c85138a4582ccb3ad01b1edfccea7c830c02be7e39ea1e602f24'
            rows=manifest.decode().splitlines(); assert len(rows)==55
            for row in rows:
                digest,name=row.split('  ',1); assert sha(z.read(PREV.name+'/'+name))==digest
            assert sha(z.read(PREV.name+'/REVIEW-V140-ACC01.md'))=='06905d277e56e85561fd8e0aacb30e18abff419f44fed466a4a20a386944ced2'
            assert sha(z.read(INITIAL.name+'/INITIAL-INVENTORY.md'))=='90dc3de0152db1fa2d459aeaea98e02a28ede976400f43cba9df3fb7a8153026'
        result[stem]={'members':len(names),'sha256':sha((REL/(stem+'.zip')).read_bytes()),'crc':'PASS'}

for r in readj(REL/'source-identity.json')['files']:
    b=git('show',':'+r['path']); assert sha(b)==r['sha256'] and len(b)==r['bytes']
result['source_metadata_verified']=len(readj(REL/'source-identity.json')['files'])
assert (REL/'evidence-index.json').read_bytes()==(PREV/'inputs/docs/releases/v1.4.0/evidence-index.json').read_bytes()
art=readj(REL/'development-artifacts.json'); result['artifacts']=art['artifacts']
assert (REL/'development-artifacts.json').read_bytes()==(PREV/'inputs/docs/releases/v1.4.0/development-artifacts.json').read_bytes()
for r in art['artifacts']:
    b=(ROOT/'build/libs'/r['name']).read_bytes(); assert len(b)==r['bytes'] and sha(b)==r['sha256']
links=[]
for rel in git('ls-files','*.md').decode().splitlines():
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in rel
    text=(ROOT/rel).read_text(encoding='utf-8-sig'); text=re.sub(r'(?ms)^```.*?^```\s*$','',text)
    for link in re.findall(r'\[[^\]\n]*\]\(([^)\s]+)\)',text):
        parsed=urlsplit(link)
        if parsed.scheme or parsed.netloc or not parsed.path:continue
        target=((ROOT/rel).parent/unquote(parsed.path)).resolve()
        assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in target.parts
        assert target.is_relative_to(ROOT) and target.exists(),(rel,link)
        links.append({'source':rel,'target':link})
result['local_file_targets']=len(links); result['missing_targets']=0
(OUT/'links.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')
for args in [('diff','--exit-code'),('diff','--cached','--check')]:
    proc=subprocess.run(['git',*args],cwd=ROOT,capture_output=True,text=True)
    result['commands'].append({'argv':['git',*args],'exit':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr});assert proc.returncode==0
result['seconds']=time.monotonic()-t
(OUT/'observations.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['staged_inputs','root_governance']},indent=2))
