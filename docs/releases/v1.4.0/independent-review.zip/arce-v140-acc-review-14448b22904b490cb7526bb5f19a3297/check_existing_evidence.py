"""Read-only inventory of committed v1.4 slice records; outputs stay beside helper."""
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def tracked(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

started = time.monotonic()
manifests = tracked('ls-files', 'docs/work/v1.4.0*/SHA256SUMS.txt').splitlines()
report = {'head': tracked('rev-parse', 'HEAD'), 'branch': tracked('branch', '--show-current'),
          'manifests': [], 'artifacts': [], 'inputs': [], 'failures': []}
for rel in manifests:
    path = ROOT / rel
    names = set()
    size = 0
    for row in path.read_text(encoding='utf-8-sig').splitlines():
        digest, name = re.split(r'\s{2,}', row, maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest) and name not in names
        names.add(name)
        member = (path.parent / name).resolve()
        assert member.is_relative_to(path.parent.resolve())
        if not member.is_file() or sha(member) != digest:
            report['failures'].append({'manifest': rel, 'member': name})
        else:
            size += member.stat().st_size
    report['manifests'].append({'path': rel, 'sha256': sha(path), 'members': len(names), 'verified_bytes': size})
    artifact = path.parent / 'development-artifacts.json'
    if artifact.exists():
        data = json.loads(artifact.read_text(encoding='utf-8-sig'))
        report['artifacts'].append({'path': artifact.relative_to(ROOT).as_posix(), 'sha256': sha(artifact), 'record': data})

inputs = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
 'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.4.0-PLANETARY-EXPANSION.md',
 'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
 'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
 'docs/status/CURRENT_VERSION.md', 'docs/status/GATE_STATUS.md',
 'docs/work/v1.4.0-implementation-log.md', 'README.md', 'CHANGELOG.md', 'gradle.properties']
inputs += tracked('ls-files', 'docs/decisions/ADR-03*.md').splitlines()
inputs += tracked('ls-files', 'src/main/java/*/network/*Network.java', 'src/main/java/*/api/version/ApiVersions.java').splitlines()
for rel in sorted(set(inputs)):
    path = ROOT / rel
    report['inputs'].append({'path': rel, 'sha256': sha(path), 'bytes': path.stat().st_size})
report['seconds'] = time.monotonic() - started
(OUT / 'existing-evidence.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'head': report['head'], 'manifests': len(report['manifests']),
    'members': sum(row['members'] for row in report['manifests']),
    'bytes': sum(row['verified_bytes'] for row in report['manifests']),
    'artifact_records': len(report['artifacts']), 'input_files': len(report['inputs']),
    'failures': report['failures'], 'seconds': report['seconds']}, indent=2))
assert not report['failures']
