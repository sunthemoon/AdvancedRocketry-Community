# V140-ACC-01 independent documentation/evidence review

## Findings first

No unresolved correctness finding in the reviewed handoff wording after the following two documentation corrections. This is a scoped development handoff review, not candidate acceptance or a G0-G9 approval.

1. **P3, resolved: rejected sky reload was described as fallback.** The initially staged `D:/GitHub/AdvancedRocketry-Community/docs/releases/v1.4.0/SECURITY-REVIEW.md:29` conflated invalid reload with a missing/unusable profile. `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/client/sky/SkyProfileReloadListener.java` only replaces `profiles` on successful `apply`; otherwise it reports previous presentation retained. ADR-036 specifies the same distinction. Revised `SECURITY-REVIEW.md:28-31` now states last-valid-map retention separately from missing-profile/context fallback. No runtime change was requested or made by this reviewer.
2. **P3, resolved: two staging policies needed distinct operator guidance.** Initial `MIGRATION-REPORT.md:50-55` discussed research `.arce-pending` only. `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindingStore.java:54-55` refuses startup on the ledger's `.json.pending`; it is not retryable research scratch. Revised `MIGRATION-REPORT.md:38-44` and `KNOWN-ISSUES.md:9` now name that file, require stopped-world/full-backup inspection or restoration, and forbid discarding the accepted ledger. This matches ADR-032 rather than inventing an automatic repair.

The initial checklist helper failure is retained as a non-final assembly observation, not a product defect: while root regenerated metadata, the first audit required `checksums.txt` staged/worktree equality and stopped there. The corrected helper records any such mismatch while continuing immutable artifact/archive checks. Its second pass observed no staged/worktree or checksum mismatches. Root has stated that final governance/review metadata and archive packaging will be regenerated again; that future assembly is not already certified by this report.

## Scope and reviewed identity

Repository: `D:/GitHub/AdvancedRocketry-Community`; branch `codex/v1.4.0-planetary-expansion`; HEAD/development checkpoint `d33552a5374272b3b0669090ec4466075662ee4c`. Production remains `a9143c2b62d5daab412cefedcee198f1fd032588`.

Reviewed the actual staged 26-file documentation/evidence diff, reader entry points, provenance addendum, accepted ADR-018/030-038, version/Gate requirements and current API/channel/storage constants. Only documentation/archive paths changed. The excluded untracked user documentation bundle was not read. No repository/index writes, Java/Gradle/server/client commands, remote access or subagents were used.

The initial inventory remains separate and unchanged:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-acc-review-14448b22904b490cb7526bb5f19a3297/INITIAL-INVENTORY.md`, SHA-256 `90dc3de0152db1fa2d459aeaea98e02a28ede976400f43cba9df3fb7a8153026`.
That preparation independently checked 12 committed slice manifests / 155 listed files / 198,939,157 bytes with zero mismatches, extracted 11 artifact records and hashed 31 scoped inputs. It did not expand every historical nested archive.

This final review directory preserves `staged-01.patch`, the initial partial `inputs-01` snapshot, the original helper/log, then the complete second `staged.patch` and `inputs` snapshot. `observations.json` records each staged input's exact byte size and SHA-256. The report's conclusions refer to those inspected bytes plus the two confirmed wording corrections, not a future commit inferred from branch state.

## Requirements, authority and compatibility assessment

- `REQUIREMENT-MAP.md:9-30` maps actual implementation to scoped evidence, explicitly separating public catalog metadata from server-filtered arrival readiness, retained/refused removed content from a new deprecated-state field, and finite 100-body/101-route tests from stress/performance acceptance.
- `RELEASE-EVIDENCE.md:9-27,73-83`, `GATE-STATUS.md` and the canonical plan preserve development/candidate/production identities and all open G0-G9. ADR-030 is not extended to v1.5. README/CHANGELOG now direct readers to v1.4 development rather than announcing an approved release. The inherited v1.0 acceptance cursor is not overwritten.
- `MIGRATION-REPORT.md:10-25` correctly distinguishes API 1.7, definition schema 2, existing SavedData schemas, the new schema-1 binding ledger, inherited menu framing and exact-match channels (flight 8, celestial 2, life-support 1, visual 1). An unchanged API binary does not assert mixed-client compatibility or schema-2 downgrade support.
- First binding adoption is prospective. Retained binding/discovery limits include removed IDs; full history can leave a once-paid claim pending. Complete matched backups, no ledger erasure, no store mixing and no manual scratch promotion remain explicit. New worlds are startup registry data, not runtime dimension creation.
- Authentic v1.3-copy upgrade, newly prepared old-runtime station/rocket witnesses, closed-world versus live projection and historical consumer identity are correctly separated. MIG-03 supplies actual finite S2 process cuts, not a blanket absence of S2 or universal crash/power-loss proof. The P3 observer timeout/dispose limitation remains disclosed in `KNOWN-ISSUES.md:14` and `SECURITY-REVIEW.md`.
- `MANUAL-TEST.md`, `VISUAL-VALIDATION-REPORT.md`, `PERFORMANCE.md` and Gate rows explicitly leave V1/V2, two real GPU categories, audio/readability, true player survival, malicious-client sessions, reference-load and broad compatibility incomplete. Operator/UUID/FakePlayer tests are not relabeled real clients. The 100-body and eight-receipt limits are correctly count/input bounds, not measured latency guarantees.
- Historical slice counts/artifacts are not summed or treated as final artifact executions. The new root build's cached JUnit and actual GameTests are labeled separately. Intentional errors, startup lag, prior fixture/oracle mistakes and the stale packaged description are retained, not hidden. The provenance addendum correctly distinguishes SKY's 33 resources from DISC/recovery's 34, without claiming a new upstream asset import.

## Independent checks actually executed

Environment: local Windows, Python through `D:/python/pyenv/pyenv-win/shims/python.bat`, `PYTHONUTF8=1`, `-B`; no JVM execution.

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B <this-directory>/verify_handoff.py
D:/python/pyenv/pyenv-win/shims/python.bat -B scripts/validate_v1plus_planning.py
D:/python/pyenv/pyenv-win/shims/python.bat -B scripts/validate_bootstrap_provenance.py
git diff --cached --check
git diff --exit-code -- src build.gradle gradle.properties settings.gradle scripts tests
```

- Initial `verify_handoff.py`: exit **1** on staged `checksums.txt` versus in-progress working bytes; preserved unchanged as `verify_handoff-01.py` and `short-audit-01.log` with the original snapshot.
- Corrected second pass: exit **0**, helper duration **2.3693019 seconds**, raw `short-audit-02.log`, derived `observations.json`. At that moment all 26 staged inputs matched working bytes and all 18 listed handoff checksums matched. Final packaging remains a subsequent root-owned checkpoint.
- Planning: exit **0**, **11 version plans / 33-input inventory**, no Gate inference; `planning.log` retained.
- Bootstrap provenance: terminal repeat exit **0**; mechanical output confirms **2 components, 11 imported targets, 2 local assets**, digest-bound `THIRD_PARTY_APPROVED`. First output is retained as `provenance.log`; `provenance-repeat.log` and `provenance-exit.txt` retain the repeat with explicit terminal receipt because the initial combined command yielded before its shell exit was captured.
- Both scoped Git checks: exit **0**, retained receipt logs. `git diff --cached --name-only` confirms only the described documentation/evidence changes; the explicit runtime check is supplemented by the staged scope and artifact/resource comparisons, not misused as an unstaged-only proof.
- Read-only `git show`, `Get-Content`, `git ls-files`, `git diff --cached` and `rg` inspected the source contracts and exact staged reader text. A guessed sky-resource class path and test path were absent; tracked-file enumeration located `SkyProfileReloadListener.java` and `api/version/ApiArtifactTest.java`. Those lookup errors were not treated as repository defects.

### Artifacts and generated resources

All three actual `build/libs` JARs match both the staged handoff record and MIG-03 records. ZIP CRCs and unique entry names pass; fixture package/resource names are absent. No consumer rebuild or runtime claim is inferred.

| Artifact | Bytes | SHA-256 | ZIP entries |
|---|---:|---|---:|
| Main | 2,624,223 | `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475` | 1446 |
| API | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` | 45 |
| Sources | 1,193,936 | `afc83ef63e3054657831bfb6e170cbc4a6cbffe3029738ec3a6bb562474dc8db` | 1154 |

The independently derived Gradle export allowlist exactly equals **27 API classes**, also exactly the main JAR's API class set. Every exported class is byte-identical between main/API. The whole API JAR matches the v1.3 handoff digest. All **34** tracked current-version generated files exactly match their prior MIG-01 inventory and each occurs once with identical bytes in the main JAR. This covers the current resource batch, not an independently repeated audit of every historical model/texture asset.

### Archive, root result attribution and links

The inspected `handoff-checks.zip` contains **179 unique members**; CRCs and every inventory byte size/hash pass. It contains **167 JUnit XML suites / 922 tests**, with zero failures/errors/skips. Raw `root-gradle.log` is byte-identical to the retained root Temp log and machine summary, SHA-256 `82c7bec2cb1fdf75dae9551058420d1132b13562394fb495b4ec242a1a11684d`.

That raw log confirms `:test FROM-CACHE`, **236 required GameTests passed**, `BUILD SUCCESSFUL in 2m 34s`, **15 ERROR / 0 FATAL** lines and the **2560 ms / 51 tick** warning. The inspected diagnostic text includes disposable missing settings and deliberate Precision/discovery save faults. These are root executions verified by archival readback, not independently rerun Java tests. Root's two collection-assumption failures remain in this archive; its 57 Python methods are likewise root evidence, not a new reviewer rerun.

All 12 evidence-index records' referenced outer manifests and metadata sizes/hashes match current committed slice records. The independent local Markdown file-target scan checked **1870 local targets**, **zero missing**. It enumerates tracked Markdown only and checks local filesystem targets, not URL availability or fragment heading validity. Its parser/count differs from root's reported 1869; neither count is an acceptance metric. Full link records are retained in `local-links.json`.

## Remaining boundaries and disposition

The two actionable documentation findings are resolved in the inspected staged wording. The handoff accurately records implemented v1.4 development scope without certifying release acceptance. It is reasonable to mark **ACC-01's scoped documentation/evidence criteria verified after final metadata/ZIP/staged-byte checks**, while leaving parent ACC, candidate and human acceptance open.

Root is still adding completed governance logs and this independent review to final packaging. The reviewed archive/member/checksum counts are the actual in-assembly snapshot, not a prediction of that final archive. Root's subsequent final metadata and immutable-manifest verification must be separately recorded; this report does not falsely certify files not yet assembled.

No release candidate rebuild, hosted CI, Forge 47.4.23 run, independent installation, real-player/GPU/multiplayer test, native rerun, reference-load or full migration campaign occurred here. Earlier native evidence retains its own artifact-specific scope. No copied third-party source text is added by this review.
