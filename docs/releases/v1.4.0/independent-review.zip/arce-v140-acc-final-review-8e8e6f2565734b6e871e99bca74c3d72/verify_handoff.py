"""Independent bounded read-only handoff check. No game/runtime imports."""
import hashlib, json, re, subprocess, time, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
OUT=Path(__file__).parent
REL=ROOT/'docs/releases/v1.4.0'
EVIDENCE=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-handoff-dc6e6f1674a2425a86b202313e90aafd')
def sha(b): return hashlib.sha256(b).hexdigest()
def filehash(p):
    with p.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def js(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
started=time.monotonic()
result={'head':git('rev-parse','HEAD').decode().strip(),'commands':[], 'staged_worktree_mismatches':[]}
changed=git('diff','--cached','--name-only').decode().splitlines()
assert all(p.endswith('.md') or p.startswith('docs/releases/v1.4.0/') for p in changed)
(OUT/'staged.patch').write_bytes(git('diff','--cached','--binary'))
snap=OUT/'inputs'; snap.mkdir(exist_ok=True)
result['staged_inputs']=[]
for rel in changed:
    raw=git('show',':'+rel)
    if raw!=(ROOT/rel).read_bytes(): result['staged_worktree_mismatches'].append(rel)
    result['staged_inputs'].append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
    dest=snap/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)

art=js(REL/'development-artifacts.json')
old=js(ROOT/'docs/work/v1.4.0-mig-cuts/development-artifacts.json')
assert art['artifacts']==old['artifacts']
result['artifacts']=[]
for row in art['artifacts']:
    p=ROOT/'build/libs'/row['name']; assert p.stat().st_size==row['bytes'] and filehash(p)==row['sha256']
    with zipfile.ZipFile(p) as z:
        names=z.namelist(); assert len(names)==len(set(names)) and z.testzip() is None
        assert not any('arceadaptertest/' in n or 'arce_adapter_test/' in n for n in names)
        result['artifacts'].append({**row,'zip_entries':len(names),'crc':'PASS'})
main=next(ROOT/'build/libs'/r['name'] for r in art['artifacts'] if r['name'].endswith('-dev.jar'))
api=next(ROOT/'build/libs'/r['name'] for r in art['artifacts'] if r['name'].endswith('-api.jar'))
with zipfile.ZipFile(main) as host,zipfile.ZipFile(api) as interface:
    actual={n for n in interface.namelist() if n.endswith('.class')}
    declared={}
    gradle=(ROOT/'build.gradle').read_text()
    for pkgvar,array in [('apiPackage','exportedApiTypes'),('rocketApiPackage','exportedRocketApiTypes'),
      ('atmosphereApiPackage','exportedAtmosphereApiTypes'),('environmentApiPackage','exportedEnvironmentApiTypes'),
      ('satelliteApiPackage','exportedSatelliteApiTypes')]:
        pkg=re.search(r"def "+pkgvar+r" = '([^']+)'",gradle)[1]
        types=re.findall(r"'([^']+)'",re.search(r'def '+array+r' = \[([^]]+)\]',gradle,re.S)[1])
        declared.update({pkg+'/'+t+'.class':True for t in types})
    declared['io/github/sunthemoon/advancedrocketrycommunity/api/environment/EnvironmentSnapshot$Locus.class']=True
    assert len(actual)==27 and actual==set(declared)
    assert actual=={n for n in host.namelist() if '/api/' in n and n.endswith('.class')}
    assert all(host.read(n)==interface.read(n) for n in actual)
    result['api_classes']=sorted(actual)
    baseline=js(ROOT/'docs/releases/v1.3.0/development-artifacts.json')
    old_api=next(r for r in baseline['artifacts'] if r['name'].endswith('-api.jar'))
    assert filehash(api)==old_api['sha256']
    resources=js(ROOT/'docs/work/v1.4.0-mig-claims/generated-resources.json')
    assert len(resources)==34
    assert {r['path'] for r in resources}==set(git('ls-files','src/generated/v1.4/resources').decode().splitlines())
    for r in resources:
        raw=(ROOT/r['path']).read_bytes()
        assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
        assert host.namelist().count(r['jar_entry'])==1 and host.read(r['jar_entry'])==raw
    result['generated_resources']=len(resources)

inventory=js(REL/'handoff-checks-files.json')
with zipfile.ZipFile(REL/'handoff-checks.zip') as z:
    names=z.namelist(); assert len(names)==len(set(names)) and z.testzip() is None
    rows={r['path']:r for r in inventory}; assert set(names)==set(rows) and len(rows)==len(inventory)
    for n,row in rows.items():
        raw=z.read(n); assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    result['archive_members']=len(names)
    xml=[n for n in names if n.endswith('.xml') and '/TEST-' in n]
    totals={k:0 for k in ['tests','failures','errors','skipped']}
    for n in xml:
        tree=ET.fromstring(z.read(n))
        for k in totals: totals[k]+=int(tree.attrib.get(k,0))
    result['archived_junit']={'suites':len(xml),**totals}
    assert result['archived_junit']=={'suites':167,'tests':922,'failures':0,'errors':0,'skipped':0}
    log=z.read('root-gradle.log'); meta=js(REL/'handoff-verification.json')
    assert sha(log)==meta['build_log_sha256']==filehash(EVIDENCE/'root-gradle.log')
    text=log.decode('utf-8-sig'); assert ':test FROM-CACHE' in text
    assert 'All 236 required tests passed' in text and 'BUILD SUCCESSFUL in 2m 34s' in text
    assert '2560ms or 51 ticks' in text and 'ARCE_DISCOVERY_EXPECTED_SAVE_FAILURE' in text
    result['build_log']={'sha256':sha(log),'unit_freshness':'FROM-CACHE','executed_gametests':236,
      'errors':len(re.findall(r'/ERROR\]',text)),'fatal':len(re.findall(r'/FATAL\]',text)),
      'lag':[line for line in text.splitlines() if "Can't keep up" in line]}

index=js(REL/'evidence-index.json'); result['evidence_index_records']=len(index['records'])
for r in index['records']:
    rows=[r['manifest'],*r['metadata']]
    for row in rows:
        p=ROOT/row['path']; assert p.stat().st_size==row['bytes'] and filehash(p)==row['sha256']

links=[]; missing=[]
for rel in git('ls-files','*.md').decode().splitlines():
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in rel
    text=(ROOT/rel).read_text(encoding='utf-8-sig')
    text=re.sub(r'(?ms)^```.*?^```\s*$', '', text)
    for link in re.findall(r'\[[^\]\n]*\]\(([^)\s]+)\)',text):
        parsed=urlsplit(link)
        if parsed.scheme or parsed.netloc or not parsed.path: continue
        target=((ROOT/rel).parent/unquote(parsed.path)).resolve()
        assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in target.parts
        row={'source':rel,'link':link}
        links.append(row)
        if not target.is_relative_to(ROOT) or not target.exists(): missing.append(row)
result['links']={'checked':len(links),'missing':missing}
assert not missing
(OUT/'local-links.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')

# Root is assembling final review/validator archives; preserve this snapshot, do not mislabel it final.
result['in_assembly_checksum_mismatches']=[]
for line in (REL/'checksums.txt').read_text().splitlines():
    digest,name=line.split('  ',1)
    if filehash(REL/name)!=digest: result['in_assembly_checksum_mismatches'].append(name)
result['seconds']=time.monotonic()-started
(OUT/'observations.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['staged_inputs','api_classes']},indent=2))
