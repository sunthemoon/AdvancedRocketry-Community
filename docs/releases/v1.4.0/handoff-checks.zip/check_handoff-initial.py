"""Collect immutable development identities and bounded documentation evidence."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/releases/v1.4.0'
BASE = 'd33552a5374272b3b0669090ec4466075662ee4c'
PRODUCTION = 'a9143c2b62d5daab412cefedcee198f1fd032588'
EXCLUDED = 'AdvancedRocketry-Community-v1plus-Development-Docs/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8')


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n',
                            encoding='utf-8', newline='\n')


def identity(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


def collect():
    assert not git('diff', BASE, '--name-only', '--', 'src', 'build.gradle', 'gradle.properties',
                   'settings.gradle', 'gradle', 'compat-test-mod')
    prior = json.loads((ROOT / 'docs/work/v1.4.0-mig-cuts/development-artifacts.json').read_text())
    artifacts = []
    for path in sorted((ROOT / 'build/libs').glob('*1.4.0-dev*.jar')):
        data = path.read_bytes()
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': sha(data)})
    assert len(artifacts) == 3 and artifacts == prior['artifacts']
    main = next(row for row in artifacts if row['name'].endswith('-dev.jar'))
    api = next(row for row in artifacts if row['name'].endswith('-api.jar'))
    old = json.loads((ROOT / 'docs/releases/v1.3.0/development-artifacts.json').read_text())
    old_api = next(row for row in old['artifacts'] if row['name'].endswith('-api.jar'))
    assert api['bytes'] == old_api['bytes'] and api['sha256'] == old_api['sha256']
    with zipfile.ZipFile(ROOT / 'build/libs' / api['name']) as z:
        classes = sum(name.endswith('.class') for name in z.namelist())
    generated = json.loads((ROOT / 'docs/work/v1.4.0-mig-claims/generated-resources.json').read_text())
    with zipfile.ZipFile(ROOT / 'build/libs' / main['name']) as z:
        names = z.namelist()
        for row in generated:
            data = (ROOT / row['path']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert names.count(row['jar_entry']) == 1 and z.read(row['jar_entry']) == data
    assert len(generated) == 33 and classes == 27
    write('development-artifacts.json', {'schema_version': 1, 'development_commit': BASE,
          'production_commit': PRODUCTION, 'candidate_commit': None, 'artifacts': artifacts,
          'api_class_count': classes, 'runtime_unchanged': True,
          'reused_native_artifacts': prior['native_artifacts'],
          'native_scope': 'Previously executed MIG-01/02/03; no packaged run or consumer rebuild here'})

    tracked = git('ls-files', '--', 'docs/work/v1.4.0-*').splitlines()
    manifests = [ROOT / path for path in tracked if path.endswith('/SHA256SUMS.txt')]
    records = []
    for manifest in sorted(manifests):
        count, size, seen = 0, 0, set()
        for line in manifest.read_text(encoding='ascii').splitlines():
            digest, name = line.split('  ', 1)
            path = (manifest.parent / name).resolve()
            assert path.is_relative_to(manifest.parent.resolve()) and name not in seen
            assert not path.is_symlink() and sha(path.read_bytes()) == digest, str(path)
            count += 1
            size += path.stat().st_size
            seen.add(name)
        metadata = [manifest.parent / name for name in ('development-artifacts.json',
                    'root-checks.json', 'native-summary.json', 'generated-resources.json',
                    'baseline-checks.json') if (manifest.parent / name).is_file()]
        same = False
        if (manifest.parent / 'development-artifacts.json').is_file():
            previous = json.loads((manifest.parent / 'development-artifacts.json').read_text())
            same = any(row.get('sha256') == main['sha256'] for row in previous.get('artifacts', []))
        records.append({'report': identity(manifest.parent / 'VERIFICATION.md'),
                        'manifest': identity(manifest), 'metadata': [identity(p) for p in metadata],
                        'manifest_files_checked': count, 'manifest_bytes_checked': size,
                        'artifact_scope': 'same production host' if same else 'historical artifact',
                        'native_execution_repeated': False})
    write('evidence-index.json', {'schema_version': 1, 'development_commit': BASE,
          'candidate_commit': None, 'scope': 'Original reports/metadata and outer manifest members; not re-executed tests or recursive native decoding',
          'records': records, 'manifest_failures': [], 'manifest_count': len(records),
          'manifest_files_checked': sum(r['manifest_files_checked'] for r in records),
          'manifest_bytes_checked': sum(r['manifest_bytes_checked'] for r in records)})

    suites = [ET.parse(p).getroot() for p in (TEMP / 'root-junit').glob('TEST-*.xml')]
    junit = {'suites': len(suites), **{key: sum(int(s.attrib.get(key, '0')) for s in suites)
             for key in ('tests', 'failures', 'errors', 'skipped')}}
    log = (TEMP / 'root-gradle.log').read_text(encoding='utf-8')
    assert 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log
    assert junit == {'suites': 167, 'tests': 922, 'failures': 0, 'errors': 0, 'skipped': 0}
    assert 'All 236 required tests passed' in log and 'written: 0' in log
    diagnostics = [line for line in log.splitlines() if re.search(r'/(?:WARN|ERROR|FATAL)\]', line)
                   or 'main WARN' in line or 'Deprecated Gradle' in line]
    (TEMP / 'diagnostics.txt').write_text('\n'.join(diagnostics) + '\n', encoding='utf-8')
    write('handoff-verification.json', {'schema_version': 1, 'development_commit': BASE,
          'candidate_commit': None, 'command': 'gradlew.bat clean build test runData runGameTestServer --offline --no-daemon --console=plain',
          'build_log_sha256': sha((TEMP / 'root-gradle.log').read_bytes()), 'exit_code': 0,
          'duration': re.search(r'BUILD SUCCESSFUL in (.+)', log).group(1).strip(),
          'junit': junit, 'junit_execution': 'FROM-CACHE' if '> Task :test FROM-CACHE' in log else 'EXECUTED',
          'required_gametests_executed': 236, 'datagen_written': 0,
          'generated_packaged_files_checked': len(generated), 'api_classes': classes,
          'game_test_world': 'Disposable world under build/gametest after clean, not an authentic migration fixture',
          'lag_warnings': [line for line in log.splitlines() if "Can't keep up!" in line],
          'error_lines': sum('/ERROR]' in line for line in diagnostics),
          'fatal_lines': sum('/FATAL]' in line for line in diagnostics),
          'native_execution_repeated': False})
    print(f'PASS: {len(records)} manifests, {sum(r["manifest_files_checked"] for r in records)} members; '
          f'3 unchanged artifacts, {classes} API classes, {len(generated)} exact packaged resources; {junit}')


def bundle(name, groups):
    rows, members = [], []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            assert not path.is_symlink(), path
            if path.is_file():
                key = path.relative_to(source).as_posix() if source.is_dir() else path.name
                members.append((prefix + '/' + key if prefix else key, path))
    assert len(members) == len({name for name, _ in members})
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for key, path in sorted(members):
            data = path.read_bytes()
            info = zipfile.ZipInfo(key, (2026, 9, 28, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(OUT / (name + '.zip')) as z:
        assert z.testzip() is None and len(z.namelist()) == len(rows)
        for row in rows:
            data = z.read(row['path'])
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
    write(name + '-files.json', rows)
    print(f'PASS: {name} archive {len(rows)} members read back')


def finalize():
    # Index explicit new evidence before the repository validator enumerates Markdown.
    names = git('diff', '--name-only', BASE, '--', 'README.md', 'CHANGELOG.md',
                'DOCUMENT-INDEX.md', 'docs/status/CURRENT_VERSION.md',
                'docs/versions/V1.4.0-PLANETARY-EXPANSION.md',
                'docs/work/v1.4.0-implementation-log.md').splitlines()
    paths = [ROOT / name for name in names] + sorted(OUT.glob('*.md'))
    links = []
    for path in paths:
        assert EXCLUDED not in path.as_posix()
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            linked = (path.parent / unquote(parsed.path)).resolve()
            assert linked.is_relative_to(ROOT) and linked.exists(), (str(path), target)
            assert EXCLUDED not in linked.as_posix()
            links.append({'document': path.relative_to(ROOT).as_posix(), 'target': target})
    write('links.json', {'scope': 'Changed documentation and new handoff Markdown', 'links': links})
    write('source-identity.json', {'development_commit': BASE, 'production_commit': PRODUCTION,
          'files': [identity(ROOT / name) for name in names]})
    files = [p for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'checksums.txt']
    (OUT / 'checksums.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in files),
                                     encoding='ascii', newline='\n')
    print(f'PASS: {len(links)} local links, {len(names)} external document identities, {len(files)} checksums')


parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('collect', 'pack', 'finalize'))
parser.add_argument('--review', action='append', type=Path, default=[])
args = parser.parse_args()
if args.mode == 'collect':
    collect()
elif args.mode == 'pack':
    bundle('handoff-checks', [('', p) for p in sorted(TEMP.iterdir())
           if p.is_file() and p.suffix in ('.py', '.txt', '.log', '.json') and not p.name.startswith(('pack-', 'finalize-', 'push-'))]
           + [('junit', TEMP / 'root-junit')])
    if args.review:
        bundle('independent-review', [(p.name, p) for p in args.review])
else:
    finalize()
