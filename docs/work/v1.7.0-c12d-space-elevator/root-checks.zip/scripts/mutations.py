"""Mutation spot checks of the C12d elevator rules: apply one mutation to an elevator class, run the elevator unit
tests, record which tests fail, restore the file byte for byte. A mutation that no test kills is reported, not
hidden."""
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
OUT = E / 'mutations'
OUT.mkdir(exist_ok=True)
PKG = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/endgame/elevator'
GRADLEW = str(ROOT / 'gradlew.bat')
ENV = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

MUTATIONS = [
    ('E1', 'ElevatorRules.java', 'a bind of another owner\'s anchor by a non-operator',
     'if (!facts.operator() && !facts.anchorOwnedByActor()) {', 'if (false) {'),
    ('E2', 'ElevatorRules.java', 'validity ignores a remapped Level',
     '''        if (!levelKeyCurrent) {
            return Check.of(EndgameCode.PAIR_LEVEL_CHANGED);
        }
''', ''),
    ('E3', 'ElevatorRules.java', 'access ignores the anchor owner leaving the station',
     'return anchorOwnerInStation ? EndgameCode.OK : EndgameCode.ANCHOR_OWNER_NOT_MEMBER;', 'return EndgameCode.OK;'),
    ('E4', 'ElevatorRules.java', 'no limit of pending rides per endpoint',
     'facts.pendingHere() >= PENDING_RIDES_PER_ENDPOINT || ', ''),
    ('E5', 'ElevatorRules.java', 'a commit waits forever for an unloaded arrival',
     'return arrivalWaitOver ? new CommitDecision(Commit.CANCEL, Check.of(EndgameCode.ARRIVAL_UNLOADED))',
     'return false ? new CommitDecision(Commit.CANCEL, Check.of(EndgameCode.ARRIVAL_UNLOADED))'),
    ('E6', 'ElevatorRules.java', 'the cargo cost without its percent',
     'return CARGO_FE * requirePercent(percent) / 100;', 'return CARGO_FE + 0 * requirePercent(percent);'),
    ('E7', 'ElevatorRules.java', 'deletion ignores cargo of the region',
     'return stationBound || transitInRegion ? Guard.BOUND : Guard.ALLOWED;',
     'return stationBound ? Guard.BOUND : Guard.ALLOWED;'),
    ('E8', 'ElevatorPairTable.java', 'two pairs on one anchor column',
     'return byColumn.containsKey(column) ? EndgameCode.COLUMN_BOUND : EndgameCode.OK;', 'return EndgameCode.OK;'),
    ('E9', 'ElevatorRules.java', 'the anchor owner cannot unbind',
     'return operator || stationOwner || anchorOwner;', 'return operator || stationOwner;'),
    ('E10', 'ElevatorRules.java', 'a warp allowed while the endgame root is down',
     '''    public static Guard warp(boolean rootOperational, boolean stationBound) {
        if (!rootOperational) {
            return Guard.UNAVAILABLE;
        }''', '''    public static Guard warp(boolean rootOperational, boolean stationBound) {'''),
]

results = []
originals = {name: (PKG / name).read_bytes() for name in {m[1] for m in MUTATIONS}}
try:
    for name, file, description, old, new in MUTATIONS:
        path = PKG / file
        text = originals[file].decode('utf-8')
        assert text.count(old) == 1, (name, text.count(old))
        path.write_bytes(text.replace(old, new).encode('utf-8'))
        log = OUT / f'{name}.log'
        with log.open('w', encoding='utf-8') as handle:
            code = subprocess.call([GRADLEW, 'test', '--offline', '--no-daemon', '--tests',
                                    'io.github.sunthemoon.advancedrocketrycommunity.endgame.elevator.*', '--tests',
                                    '*ElevatorGuardTest*'],
                                   cwd=ROOT, env=ENV, stdout=handle, stderr=subprocess.STDOUT)
        failing = []
        for report in sorted((ROOT / 'build/test-results/test').glob('*Elevator*.xml')):
            suite = ET.parse(report).getroot()
            for case in suite.iter('testcase'):
                if case.find('failure') is not None or case.find('error') is not None:
                    failing.append(suite.get('name').rsplit('.', 1)[-1] + '.' + case.get('name'))
        text_log = log.read_text(encoding='utf-8')
        compiled = 'compileJava FAILED' not in text_log and 'compileTestJava FAILED' not in text_log
        results.append({'mutation': name, 'file': file, 'description': description, 'gradle_exit': code,
                        'compiled': compiled, 'killed': compiled and code != 0 and bool(failing),
                        'failing_tests': failing})
        print(name, 'exit', code, 'failing', len(failing), flush=True)
        path.write_bytes(originals[file])
finally:
    for file, data in originals.items():
        (PKG / file).write_bytes(data)
restored = {file: hashlib.sha256((PKG / file).read_bytes()).hexdigest() for file in originals}
assert all(hashlib.sha256(data).hexdigest() == restored[file] for file, data in originals.items())
(OUT / 'mutations.json').write_text(json.dumps({'restored_sha256': restored, 'results': results}, indent=2)
                                    + '\n', encoding='utf-8', newline='\n')
print('killed', sum(r['killed'] for r in results), 'of', len(results))
