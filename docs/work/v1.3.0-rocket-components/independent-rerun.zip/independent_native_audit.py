"""Read-only COMP-01 audit; outputs only to this review directory.

Only the existing bounded NBT/Anvil structural decoders are reused. Expected
component state, hash calculation, archive/log/provenance checks are independent
of the component runner and its JSON projections/verdict.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import struct
import sys
import uuid
import zipfile
import zlib

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-comp01-1790472883078')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import inspect_celestial_saved_data as nbt
from scripts import v120_precision_world_fixture as region

HOST = 'advancedrocketrycommunity'
PREFIX = 'io/github/sunthemoon/' + HOST + '/'
PHASES = ('assemble', 'skipped', 'updated', 'restart')
ORIGIN = (264, 101, 264)
EXPECTED_BLOCKS = {(-1, 0, 0): 'minecraft:emerald_block', (0, 0, 0): 'minecraft:diamond_block',
                   (0, 1, 0): 'minecraft:oak_planks', (0, 2, 0): 'minecraft:gold_block',
                   (1, 0, 0): 'minecraft:quartz_block'}


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def read(path, limit=32 * 1024**2):
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= limit, path
    data = path.read_bytes()
    assert len(data) <= limit
    return data


def js(path):
    return json.loads(read(path))


def gzip_nbt(path, level=False):
    with gzip.GzipFile(fileobj=io.BytesIO(read(path, 1024**2))) as stream:
        data = stream.read(4 * 1024**2 + 1)
    assert len(data) <= 4 * 1024**2
    original = nbt.MAX_TAGS
    try:
        # Full Forge level.dat has registry metadata beyond a small SavedData root.
        if level:
            nbt.MAX_TAGS = 65536
        return nbt.NbtReader(data).read_root()
    finally:
        nbt.MAX_TAGS = original


def entity_chunk(path):
    compressed = region._region_chunk(read(path, region.MAX_REGION_BYTES), 16, 16)
    stream = zlib.decompressobj()
    data = stream.decompress(compressed, region.MAX_EXPANDED_CHUNK + 1)
    assert stream.eof and not stream.unused_data and not stream.unconsumed_tail
    assert len(data) <= region.MAX_EXPANDED_CHUNK
    root = nbt.NbtReader(data).read_root()
    assert root['Position'] == [16, 16]
    return root


def block_at(chunk, pos):
    x, y, z = pos
    sections = [s for s in chunk['sections'] if s['Y'] == y // 16]
    assert len(sections) == 1
    state = sections[0]['block_states']
    palette = state['palette']
    if len(palette) == 1:
        return palette[0]
    bits = max(4, (len(palette) - 1).bit_length())
    index = ((y & 15) * 16 + (z & 15)) * 16 + (x & 15)
    per_word = 64 // bits
    word = state['data'][index // per_word] & ((1 << 64) - 1)
    return palette[(word >> ((index % per_word) * bits)) & ((1 << bits) - 1)]


def uuid_array(parts):
    return str(uuid.UUID(bytes=b''.join(struct.pack('>I', p & 0xffffffff) for p in parts)))


def snapshot_hash(snapshot):
    # Mirror the documented numeric snapshot byte format, not runner verdicts.
    out = io.BytesIO()
    def ints(*v): out.write(struct.pack('>' + 'i' * len(v), *v))
    def string(v):
        b = v.encode('utf-8'); ints(len(b)); out.write(b)
    ints(snapshot['schema_version']); string(snapshot['source_dimension'])
    ints(*snapshot['source_origin']); ints(*snapshot['bounding_box'])
    blocks = sorted(snapshot['relative_blocks'], key=lambda b: tuple(b['position']))
    ints(len(blocks))
    for block in blocks:
        ints(*block['position']); state = snapshot['block_palette'][block['palette']]
        string(state['id']); ints(len(state['properties']))
        for k, v in sorted(state['properties'].items()): string(k); string(v)
        assert 'block_entity' not in block
        out.write(b'\0')
    anchors = sorted(snapshot['passenger_anchors'])
    ints(len(anchors))
    for anchor in anchors: ints(*anchor)
    stats = snapshot['mass_inputs']; ints(stats['block_count'])
    out.write(struct.pack('>qqq', stats['mass'], stats['thrust'], stats['fuel_capacity']))
    ints(*(stats[k] for k in ('engine_count', 'seat_count', 'guidance_count', 'block_entity_count')))
    return digest(out.getvalue())


def main():
    observations = {'scope': 'read-only artifact and native captures; no server launched'}
    identities = js(BASE / 'artifact-identities.json')
    artifacts = {item['name']: read(BASE / 'artifacts' / item['name']) for item in identities}
    for item in identities:
        assert digest(artifacts[item['name']]) == item['sha256']
        assert len(artifacts[item['name']]) == item['bytes']
        assert digest(read(Path(item['path']))) == item['sha256']
    main_name = 'advancedrocketry-community-1.20.1-1.3.0-dev.jar'
    api_name = main_name[:-4] + '-api.jar'; sources_name = main_name[:-4] + '-sources.jar'
    fixture_name = 'arce-adapter-compat-test-1.0.0.jar'
    exports = {PREFIX + 'api/' + kind + '/' + name + '.class' for kind, names in {
        'version': ('ApiVersion', 'ApiCompatibility', 'ApiVersions'),
        'rocket': ('RocketBlockEntityAdapter', 'RocketAdapterRegistrar', 'RegisterRocketAdaptersEvent',
                   'RocketComponentDefinition', 'RocketComponentRegistrar', 'RegisterRocketComponentsEvent'),
        'atmosphere': ('AtmosphereBoundary', 'AtmosphereBoundaryProvider', 'AtmosphereBoundaryRegistrar',
                       'RegisterAtmosphereBoundariesEvent', 'SuitOxygenProvider', 'SuitEquipmentRegistrar',
                       'RegisterSuitEquipmentEvent')}.items() for name in names}
    with zipfile.ZipFile(io.BytesIO(artifacts[main_name])) as mainjar, zipfile.ZipFile(io.BytesIO(artifacts[api_name])) as api:
        assert {n for n in api.namelist() if n.endswith('.class')} == exports
        for entry in exports: assert api.read(entry) == mainjar.read(entry), entry
        assert PREFIX + 'rocket/forge/RocketBlockEntityAdapter.class' in mainjar.namelist()
        for name in (main_name, api_name, sources_name):
            with zipfile.ZipFile(io.BytesIO(artifacts[name])) as jar:
                assert len(jar.namelist()) == len(set(jar.namelist()))
                assert not any('arceadaptertest/' in n or n.startswith(('assets/arce_adapter_test/', 'data/arce_adapter_test/')) for n in jar.namelist())
        with zipfile.ZipFile(io.BytesIO(artifacts[sources_name])) as sources:
            for item in ('RocketComponentDefinition', 'RocketComponentRegistrar', 'RegisterRocketComponentsEvent'):
                entry = PREFIX + 'api/rocket/' + item + '.java'
                assert sources.read(entry) == read(ROOT / 'src/main/java' / entry)
    with zipfile.ZipFile(io.BytesIO(artifacts[fixture_name])) as fixture:
        classes = [n for n in fixture.namelist() if n.endswith('.class')]
        assert all(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in classes)
        assert any(n.endswith('/FixtureRocketComponents.class') for n in classes)
        for tag in ('rocket_engines', 'rocket_seats'):
            data = json.loads(fixture.read('data/' + HOST + '/tags/blocks/' + tag + '.json'))
            assert data == {'replace': False, 'values': ['minecraft:diamond_block']}
    cp = js(BASE / 'consumer-reports/classpath.json')
    assert cp['requested_api'] == 'io.github.sunthemoon.advancedrocketrycommunity:advancedrocketry-community:1.20.1-1.3.0-dev:api'
    assert digest(read(Path(cp['raw_api']))) == digest(artifacts[api_name]) == cp['published_sha256']
    assert digest(read(Path(cp['remapped_api']))) == cp['remapped_sha256']
    host_deps = [r for r in cp['resolved_artifacts'] if r['group'] == 'io.github.sunthemoon.advancedrocketrycommunity']
    assert len(host_deps) == 1 and host_deps[0]['classifier'] == 'api'
    for item in cp['fixture_sources']: assert digest(read(Path(item['file']))) == item['sha256']
    for item in cp['compile_classpath']:
        entry = item['file']
        assert not any(marker in entry.replace('\\', '/') for marker in ('/build/classes/', '/build/resources/'))
        assert not entry.endswith((main_name, sources_name))
        raw = read(Path(entry), 128 * 1024**2)
        assert digest(raw) == item['sha256']
        with zipfile.ZipFile(io.BytesIO(raw)) as jar:
            found = {n for n in jar.namelist() if n.startswith(PREFIX) and n.endswith('.class')}
            assert found == (exports if entry == cp['remapped_api'] else set())
    negative = js(BASE / 'consumer-reports/negative-import.json')
    assert negative['exit_code'] == 1 and negative['inspected_host_sha256'] == digest(artifacts[main_name])
    assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in negative['diagnostics']
    fixture_report = js(BASE / 'consumer-reports/fixture-artifact.json')
    assert fixture_report['sha256'] == digest(artifacts[fixture_name]) and fixture_report['reobfuscated'] is True
    cache_input = Path('\\\\?\\' + cp['remapped_api'] + '.input').read_bytes()
    (OUT / 'consumer-mapped-api.input').write_bytes(cache_input)
    cache = dict(line.split('=', 1) for line in cache_input.decode().splitlines())
    assert cache['orig'] == hashlib.sha1(artifacts[api_name]).hexdigest()
    observations['artifacts'] = identities
    observations['consumer'] = {'api_classes': sorted(exports), 'classpath_entries': len(cp['compile_classpath']),
                                'source_files': len(cp['fixture_sources']), 'mapped_sha256': cp['remapped_sha256'],
                                'cache_input': cache, 'negative_compile_exit': negative['exit_code']}

    evidence = BASE / 'runtime-evidence'; manifest = read(evidence / 'SHA256SUMS')
    paths = []
    for line in manifest.decode('ascii').splitlines():
        expected, relative = line.split('  ', 1)
        assert relative not in paths and '..' not in Path(relative).parts
        assert digest(read(evidence / relative)) == expected, relative
        paths.append(relative)
    assert set(paths) == {p.relative_to(evidence).as_posix() for p in evidence.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    observations['manifest'] = {'files': len(paths), 'sha256': digest(manifest)}
    prep = js(BASE / 'libraries-preparation.json')
    for item in prep['files']:
        p = Path(prep['target']) / item['path']; assert digest(read(p, 128 * 1024**2)) == item['sha256'], p
    observations['library_files_checked'] = len(prep['files'])

    states = []; summary = []
    for index, phase in enumerate(PHASES):
        path = evidence / phase
        chunk = region._decode_chunk(region._region_chunk(read(path / 'world/region/r.0.0.mca'), 16, 16), 16, 16)
        entities = entity_chunk(path / 'world/entities/r.0.0.mca')['Entities']
        rockets = [e for e in entities if e.get('id') == HOST + ':rocket']
        assert len(rockets) == 1 and not any(e.get('id') == 'minecraft:item' for e in entities)
        entity = rockets[0]; data = entity['RocketEntityData']; snapshot = data['snapshot']; flight = data['flight_data']
        assert data['schema_version'] == 2 and snapshot['schema_version'] == 1 and flight['schema_version'] == 2
        assert uuid_array(data['owner_id']) == '00000000-0000-0000-0000-000000000005'
        assert data['assembly_transaction_id'] == flight['logical_rocket_id']
        assert snapshot['source_dimension'] == 'minecraft:overworld' and snapshot['source_origin'] == list(ORIGIN)
        assert snapshot['bounding_box'] == [-1, 0, 0, 1, 2, 0] and snapshot['passenger_anchors'] == [[0, 1, 0]]
        assert len(snapshot['relative_blocks']) == len(snapshot['block_palette']) == 5
        seen = {}
        for block in snapshot['relative_blocks']:
            pos = tuple(block['position']); assert pos not in seen and 'block_entity' not in block
            palette = snapshot['block_palette'][block['palette']]; assert palette['properties'] == {}
            seen[pos] = palette['id']
        assert seen == EXPECTED_BLOCKS
        expected = {'block_count': 5, 'mass': 254 if index < 2 else 294, 'thrust': 2400 if index < 2 else 2800,
                    'fuel_capacity': 1500 if index < 2 else 2000, 'engine_count': 1, 'seat_count': 1,
                    'guidance_count': 1, 'block_entity_count': 0}
        assert snapshot['mass_inputs'] == expected and snapshot_hash(snapshot) == snapshot['content_hash']
        assert flight['state'] == 'ASSEMBLED' and flight['fuel'] == {'capacity': expected['fuel_capacity'], 'amount': 0, 'committed_debits': []}
        assert flight['passengers'] == {'seat_capacity': 1, 'assignments': []}
        positions = [tuple(a+b for a,b in zip(ORIGIN,p)) for p in EXPECTED_BLOCKS]
        assert all(block_at(chunk, p) == {'Name': 'minecraft:air'} for p in positions)
        assert block_at(chunk, (264,100,264)) == {'Name': HOST + ':rocket_assembler'}
        bes = [be for be in chunk['block_entities'] if tuple(be.get(k) for k in ('x','y','z')) in positions + [(264,100,264)]]
        assert len(bes) == 1 and bes[0]['id'] == HOST + ':rocket_assembler'
        journal = gzip_nbt(path / ('world/data/' + HOST + '_rocket_transactions.dat'))
        assert journal['data']['transactions'] == []
        level = gzip_nbt(path / 'world/level.dat', level=True)['Data']
        seed, game_time = level['WorldGenSettings']['seed'], level['Time']
        result = js(path / 'result.json'); assert result['exit_code'] == 0
        launch = js(path / 'launch.json'); assert launch['mods'] == {name: digest(artifacts[name]) for name in (main_name, fixture_name)}
        assert ('-Darce_adapter_test.skipRocketComponents=true' in launch['command']) == (phase == 'skipped')
        assert ('-Darce_adapter_test.componentVariant=updated' in launch['command']) == (index >= 2)
        commands = js(path / 'commands.json'); assert commands[-2:] == ['save-all flush', 'stop']
        assert sum(c == 'arce rocket assemble 264 100 264' for c in commands) == (1 if index in (0,2) else 0)
        assert not any(c.startswith(('data merge ', 'data modify ', 'summon ', 'kill ')) for c in commands)
        logs = {}
        expected_registration = 'Skipped rocket components (event 1)' if index == 1 else 'Registered rocket components (variant ' + ('standard' if index == 0 else 'updated') + ', API 1.4, event 1)'
        for name in ('stdout.txt','latest.log','debug.log'):
            text = read(path/name).decode('utf-8'); lines = text.splitlines()
            errors = [line for line in lines if re.search(r'/(?:ERROR|FATAL)\]|\b(?:NoClassDefFoundError|NoSuchMethodError|AbstractMethodError|VerifyError|LinkageError)\b', line)]
            assert not errors, (phase,name,errors)
            receipts = [line for line in lines if 'Registered rocket components ' in line or 'Skipped rocket components ' in line]
            assert len(receipts) == 1 and receipts[0].endswith(expected_registration)
            ticks = [int(v) for v in re.findall(r'The time is (\d+)', text)]
            assert ticks[-1]-ticks[0] == result['observation_ticks'] and ticks[-1]-ticks[0] >= 20
            assert 'Stopping server' in text and 'All dimensions are saved' in text
            assert 'V130_COMPONENT_FIRST_'+phase in text and 'V130_COMPONENT_SECOND_'+phase in text
            assemblies = re.findall(r'ARCE_ROCKET_TRANSACTION operation=assembly code=SUCCESS blocks=5 snapshot=([0-9a-f]{64}) entity=([0-9a-f-]{36})', text)
            if index in (0,2): assert assemblies == [(snapshot['content_hash'],uuid_array(entity['UUID']))]
            else: assert not assemblies
            if index == 2:
                assert text.index('V130_COMPONENT_OLD_CAPTURE') < text.index('Release-test disassembly completed') < text.index('V130_COMPONENT_RESTORED_BLOCKS') < text.index('ARCE_ROCKET_TRANSACTION operation=assembly')
            logs[name] = {'lines': len(lines), 'error_or_linkage': len(errors), 'warnings': [s for s in lines if '/WARN]' in s], 'tick_queries': ticks}
        assert result['receipt'] == [snapshot['content_hash'], uuid_array(entity['UUID'])]
        if index in (1,3): assert data == states[-1]['data'] and entity['UUID'] == states[-1]['uuid']
        if index == 2:
            assert data['assembly_transaction_id'] != states[-1]['data']['assembly_transaction_id']
            assert snapshot['snapshot_id'] != states[-1]['data']['snapshot']['snapshot_id']
            assert entity['UUID'] != states[-1]['uuid']
        if states: assert seed == states[-1]['seed'] and game_time > states[-1]['time']
        states.append({'data':data,'uuid':entity['UUID'],'seed':seed,'time':game_time})
        summary.append({'phase':phase,'seed':seed,'time':game_time,'entity_uuid':uuid_array(entity['UUID']),
                        'snapshot_id':snapshot['snapshot_id'],'hash':snapshot['content_hash'],'stats':expected,
                        'journal':journal['data'],'recorded_exit':result['exit_code'],'observation_ticks':result['observation_ticks'],'logs':logs})
    observations['phases'] = summary
    observations['result'] = 'PASS'
    (OUT/'independent-native-observations.json').write_text(json.dumps(observations,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'result':'PASS','manifest':observations['manifest'],'libraries':len(prep['files']),
                     'api_classes':len(exports),'phases':[{k:v for k,v in p.items() if k not in ('logs','journal')} for p in summary]},indent=2))


if __name__ == '__main__':
    main()
