"""Mutation spot checks of the C12b transit rules: apply one mutation to TransitRules, run the endgame unit tests,
record which tests fail, restore the file byte for byte. A mutation that no test kills is reported, not hidden."""
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
OUT = E / 'mutations'
OUT.mkdir(exist_ok=True)
RULES = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/endgame/transit/TransitRules.java'
GRADLEW = str(ROOT / 'gradlew.bat')
ENV = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

MUTATIONS = [
    ('M1', 'registration without the persisted, aged observation (source row)',
     '!recordPresent && persistedAndAged && seq == lowestSeq', '!recordPresent && seq == lowestSeq'),
    ('M2', 'receipts dropped before the acknowledgement is durable',
     'return record == null || record.acknowledged() && record.ackDurable();',
     'return record == null || record.acknowledged();'),
    ('M3', 'registration despite a tag holding transit contents (R3-H1 freeze)',
     'return !retired && !tagHoldsContents;', 'return !retired;'),
    ('M4', 'incoming gate without the persisted, aged observation (F02)',
     'return incomingPersistedAndAged && (record == null', 'return (record == null'),
    ('M5', 'resolve returns every outbox entry of a tombstoned endpoint to the input',
     'return tombstonePresent && seq > tombstoneDispatchedThrough;', 'return tombstonePresent;'),
    ('M6', 'resolve keeps a claimed payload paid at another endpoint',
     'record.state() == TransitRecord.State.CLAIMED && record.paidHere()\n',
     'record.state() == TransitRecord.State.CLAIMED\n'),
    ('M7', 'redirect without a durable destination removal (R2-H1)',
     '                && destinationRemovalDurable;', '                ;'),
    ('M8', 'claim of a record that is not durable',
     '&& record.durable()\n                && !receiptHere', '\n                && !receiptHere'),
    ('M9', 'stub pruned while the paid endpoint chunk still holds the payload',
     'return record.acknowledged() && record.ackDurable() && !paidEndpointChunkHoldsIncoming;',
     'return record.acknowledged() && record.ackDurable();'),
]

original = RULES.read_bytes()
original_sha = hashlib.sha256(original).hexdigest()
results = []
try:
    for name, description, old, new in MUTATIONS:
        text = original.decode('utf-8')
        assert text.count(old) == 1, (name, text.count(old))
        RULES.write_bytes(text.replace(old, new).encode('utf-8'))
        log = OUT / f'{name}.log'
        with log.open('w', encoding='utf-8') as handle:
            code = subprocess.call([GRADLEW, 'test', '--offline', '--no-daemon', '--tests',
                                    'io.github.sunthemoon.advancedrocketrycommunity.endgame.*'],
                                   cwd=ROOT, env=ENV, stdout=handle, stderr=subprocess.STDOUT)
        failing = []
        compiled = True
        for report in sorted((ROOT / 'build/test-results/test').glob('*endgame*.xml')):
            suite = ET.parse(report).getroot()
            for case in suite.iter('testcase'):
                if case.find('failure') is not None or case.find('error') is not None:
                    failing.append(suite.get('name').rsplit('.', 1)[-1] + '.' + case.get('name'))
        if 'compileJava FAILED' in log.read_text(encoding='utf-8') or 'compileTestJava FAILED' in \
                log.read_text(encoding='utf-8'):
            compiled = False
        results.append({'mutation': name, 'description': description, 'gradle_exit': code, 'compiled': compiled,
                        'killed': compiled and code != 0 and bool(failing), 'failing_tests': failing})
        print(name, 'exit', code, 'failing', len(failing), flush=True)
        RULES.write_bytes(original)
finally:
    RULES.write_bytes(original)
assert hashlib.sha256(RULES.read_bytes()).hexdigest() == original_sha
(OUT / 'mutations.json').write_text(json.dumps({'file': str(RULES.relative_to(ROOT)).replace('\\', '/'),
                                                'restored_sha256': original_sha, 'results': results}, indent=2)
                                    + '\n', encoding='utf-8', newline='\n')
print('killed', sum(r['killed'] for r in results), 'of', len(results))
