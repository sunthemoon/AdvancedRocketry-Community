"""Collect bounded DATA-01 receipts and unchanged raw evidence; never read the user bundle."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).parent
OUT = ROOT / 'docs/work/v1.4.0-data01'
BASE = '8947fac9641dc11ce2dce1ed8a3877984be044ab'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def command(*args):
    return subprocess.check_output(args, cwd=ROOT).decode('utf-8').strip()


def junit(directory):
    suites = [ET.parse(path).getroot() for path in sorted(directory.glob('TEST-*.xml'))]
    return {'suites': len(suites), **{key: sum(int(value.attrib.get(key, 0)) for value in suites)
                                    for key in ('tests', 'failures', 'errors', 'skipped')}}


def sources():
    scopes = ['src', 'scripts/run_v140_celestial_schema_smoke.py', 'tests/test_v140_celestial_schema_smoke.py',
              'gradle.properties', 'compat-test-mod/build.gradle']
    paths = set(command('git', 'diff', '--name-only', BASE, '--', *scopes).splitlines())
    paths.update(command('git', 'ls-files', '--others', '--exclude-standard', '--', *scopes).splitlines())
    records = []
    for name in sorted(paths):
        if not name:
            continue
        path = ROOT / name
        records.append({'path': name, 'bytes': path.stat().st_size, 'working_sha256': sha(path),
                        'git_blob': command('git', 'hash-object', '--', name)})
    write(OUT / 'source-identity.json', {'base_commit': BASE, 'branch': command('git', 'branch', '--show-current'),
                                      'scope': 'Actual implementation/test/metadata inputs; not a candidate', 'files': records})


def raw_zip(target, groups):
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for prefix, paths, parent in groups:
            for path in sorted(paths):
                if path.is_file():
                    archive.write(path, prefix + path.relative_to(parent).as_posix())
    with zipfile.ZipFile(target) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert archive.testzip() is None


def root_capture():
    OUT.mkdir(parents=True, exist_ok=True)
    log = (TEMP / 'clean-build-data-gametest-3.log').read_text(encoding='utf-8')
    counts = junit(TEMP / 'full-junit-3')
    assert counts['tests'] == 792 and counts['failures'] == counts['errors'] == counts['skipped'] == 0
    assert 'All 213 required tests passed' in log and 'BUILD SUCCESSFUL in 2m 21s' in log
    assert '> Task :test\n' in log and '> Task :test FROM-CACHE' not in log
    assert 'written: 0' in log
    write(OUT / 'root-checks.json', {
        'base_commit': BASE, 'build_command': 'gradlew.bat clean build runData runGameTestServer --offline --no-daemon --console=plain',
        'exit_code': 0, 'seconds': 141, 'junit': counts, 'junit_execution': 'executed, not restored from cache',
        'required_gametests_passed': 213, 'datagen_written': 0,
        'qualification': 'Root pass precedes independent-review fixture cleanup fix; final-source rerun is in independent evidence.',
        'failures_retained': [
            {'log': 'targeted-tests.log', 'result': '167 JUnit / 1 failure: legacy test_mars Space placeholder'},
            {'log': 'clean-build-data-gametest.log', 'result': 'Fixture compile error: used planner code in request-code assertion'},
            {'log': 'clean-build-data-gametest-2.log', 'result': '792 JUnit passed; 213 GameTests / 1 failure: Space fixture entity not visible'}],
        'python_command': 'python -B -m unittest tests.test_v140_celestial_schema_smoke -v', 'python_tests': 5,
        'planning_checks': '11 plans / 33 inputs', 'repository_checks': '45 passed / 0 pending, warnings, failures',
        'scope': 'Bounded development checks, not full acceptance', 'candidate_commit': None})
    groups = [('root/', [p for p in TEMP.iterdir() if p.suffix in ('.log', '.py')], TEMP)]
    for name in ('failed-targeted-junit', 'failed-gametest-2', 'full-junit-2', 'full-junit-3', 'gametest-3-logs'):
        parent = TEMP / name
        groups.append((name + '/', parent.rglob('*'), parent))
    raw_zip(OUT / 'root-checks.zip', groups)
    print(json.dumps(counts))


def native_capture():
    directory = TEMP / 'native-evidence-2'
    summary = json.loads((directory / 'summary.json').read_text(encoding='utf-8'))
    assert summary['result'] == 'PASS'
    raw_zip(OUT / 'native-restart.zip', [('native/', directory.rglob('*'), directory)])
    failed = TEMP / 'native-evidence'
    raw_zip(OUT / 'native-attempt-1.zip', [('native-failed/', failed.rglob('*'), failed)])
    write(OUT / 'native-summary.json', summary)
    artifacts = []
    for path in sorted((TEMP / 'artifacts').glob('*.jar')):
        artifacts.append({'name': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
    api = next(value for value in artifacts if value['name'].endswith('-api.jar'))
    prior = json.loads((ROOT / 'docs/releases/v1.3.0/development-artifacts.json').read_text(encoding='utf-8'))
    old_api = next(value for value in prior['artifacts'] if value['name'].endswith('-api.jar'))
    assert api['sha256'] == old_api['sha256'] and api['bytes'] == old_api['bytes']
    write(OUT / 'development-artifacts.json', {'build': '1.20.1-1.4.0-dev', 'artifacts': artifacts,
          'api_version': '1.7', 'api_class_count': 27, 'api_byte_identical_to_v130': True, 'candidate_commit': None})


def reviews():
    directories = [Path(value) for value in sys.argv[2:]]
    groups, identities = [], []
    for index, directory in enumerate(directories):
        paths = sorted(path for path in directory.rglob('*') if path.is_file())
        prefix = f'review-{index + 1}/'
        for path in paths:
            identities.append({'member': prefix + path.relative_to(directory).as_posix(),
                               'bytes': path.stat().st_size, 'sha256': sha(path)})
        groups.append((prefix, paths, directory))
    raw_zip(OUT / 'independent-review.zip', groups)
    write(OUT / 'independent-review.json', {'reviewer': '/root/prec04b_readback_review',
          'archive': 'independent-review.zip', 'archive_sha256': sha(OUT / 'independent-review.zip'),
          'scope': 'Unchanged staged source reviews and final-source executable review; no Gate approval', 'entries': identities})


def links():
    tracked = command('git', 'ls-files', '-z', '--', '*.md').split('\0')
    paths = {ROOT / name for name in tracked if name}
    paths.update([ROOT / 'docs/CELESTIAL-DATA-GUIDE.md', ROOT / 'docs/provenance/v1.4.0-development-metadata.md'])
    paths.update(OUT.glob('*.md'))
    missing, count = [], 0
    for path in sorted(paths):
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith(('#', 'mailto:')) or re.match(r'^[A-Za-z]:[/\\]', target):
                continue
            relative = urllib.parse.unquote(target.split('#', 1)[0])
            if relative:
                count += 1
                if not (path.parent / relative).exists():
                    missing.append([path.relative_to(ROOT).as_posix(), target])
    write(OUT / 'links.json', {'markdown_files': len(paths), 'local_targets': count, 'missing': missing,
                             'scope': 'Local file existence only; not external URLs or anchor content'})
    assert not missing, missing
    print('Local links:', len(paths), count)


def checksums():
    paths = sorted(path for path in OUT.iterdir() if path.is_file() and path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(path)}  {path.name}\n' for path in paths), encoding='ascii', newline='\n')


def verify():
    for line in (OUT / 'SHA256SUMS.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(OUT / name) == digest, name
        payload = subprocess.check_output(['git', 'show', ':' + (OUT / name).relative_to(ROOT).as_posix()], cwd=ROOT)
        assert hashlib.sha256(payload).hexdigest() == digest, 'staged ' + name
        if name.endswith('.zip'):
            with zipfile.ZipFile(OUT / name) as archive:
                assert archive.testzip() is None
                assert len(archive.namelist()) == len(set(archive.namelist()))
    for item in json.loads((OUT / 'source-identity.json').read_text())['files']:
        assert sha(ROOT / item['path']) == item['working_sha256'], item['path']
        assert command('git', 'rev-parse', ':' + item['path']) == item['git_blob'], item['path']
    print('Working/staged evidence checksums, ZIP CRC/member uniqueness and source identities match.')


if __name__ == '__main__':
    {'root': root_capture, 'sources': sources, 'native': native_capture, 'reviews': reviews,
     'links': links, 'checksums': checksums, 'verify': verify}[sys.argv[1]]()
