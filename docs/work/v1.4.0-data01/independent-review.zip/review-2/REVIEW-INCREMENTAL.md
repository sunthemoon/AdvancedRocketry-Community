# V140-DATA-01 incremental read-only review

## Findings (initial follow-up source)

### Medium: station GameTest leaks its remote fixture if visibility never arrives

`PlanetaryAdmissionGameTests.java:136-155` commits a station record, installs
a remote Space rocket and adds a ticket. Lines 156-180 put their cleanup only
inside the later `thenExecute` callback. A visibility wait that expires at the
100-tick test timeout never executes that callback; an installation assertion
at line 155 also occurs outside that cleanup. The ticket expires, but the
station record and potentially saved Space entity remain. The framework's
Overworld test-box cleanup does not delete either. Reusing this GameTest world
therefore carries failed-fixture authority into later runs.

Root accepted this source finding and plans a bounded tick-80 visibility
failure with owned-resource cleanup, retaining timeout 100 and all behavior
assertions, plus cleanup around initialization. That correction has not yet
been read or executed as of this report. Use an idempotent cleanup scoped to
this fixture's UUID/rocket/ticket; do not clear unrelated SavedData or tickets.
The other two tests also allocate some setup resources before entering their
try blocks (lines 59-74 and 111-115), a smaller analogous failure-cleanup
boundary worth including in the local fix.

### Low: native phase failure does not retain a structured exit/result record

`run_v140_celestial_schema_smoke.py:145-153` aborts on failure and retains
commands/raw logs, but writes `observations.json` with exit code only after
success (141-143). The outer error path writes `failure.json`, while the
summary remains `IN_PROGRESS` (186-201). Thus a failed command/phase has no
structured phase failure/exit record, making it harder to distinguish an
oracle refusal after clean process exit from a forced abort. This does not
create a false PASS. A small finally-written phase `result.json` preserving
the primary error and actual return code is sufficient; no new runtime matrix
or orchestration framework is needed.

No further concrete production defect was found in this incremental scope.

## Previous finding

The earlier JSON-null presence correction remains present at
`CelestialDefinitionCodec.java:127-130`; the exact new null cases are present
at `CelestialSchemaV2Test.java:79-92`. Follow-up hashes match the final copies
in the prior source report. It still requires independent executable
regression, not merely source confirmation.

## Actual reviewed behavior and evidence boundary

- GameTests use separate managers/catalogs, not replacement of the global
  server runtime. `rocket_test` reserves the local footprint. UUID-owned
  Space tickets are bounded and expire. Capability rejection exercises
  admin authority with its exact rejection code, plus player intent; it
  compares flight/fuel, full transfer SavedData and station registry snapshots.
  Positive launch/cancel exercises the actual player request service and
  asserts COUNTDOWN/journal then FUELED/exact-fuel restoration. Station
  departure also tests that rocket ownership does not bypass station access.
- The Space station source is synthesized using production constructors and
  `initializeTransferred`, not a real inbound flight or disk reload. Launch
  is cancelled before flight; these GameTests do not prove completed travel.
- Changing the test-only Mars Level key from shared Space to a distinct
  unregistered test key is consistent with pure planner coverage, not proof
  of a physical destination. A separate test rejects Space as a surface.
- Development metadata, consumer default coordinate and metadata tests move
  to 1.4.0-dev, not a release. The provenance note links the existing adapted
  Forge MDK origin, preserves notices and does not rewrite historical import
  hashes. No new upstream source/asset import is represented by this change.
- The new runner permits only a fresh libraries-only disposable server,
  rejects linked/overlapping output paths, checks actual host mod metadata
  and entrypoint, launches only owned processes and uses finite startup,
  command, status and stop waits. Helpers were inspected, not assumed.
- The first runner phase creates one Moon station under old built-in data,
  saves its native record, installs schema-2 Moon/gas data, reloads once,
  observes exact capability/mapping/environment text, rejects new Moon
  station creation, then stops. The second process repeats the read/refusal
  against that same saved station. Raw compressed station and level.dat
  captures are retained; full decoded station `data` must equal the original
  baseline, not just UUID or summary counts.
- Native NBT parsing is bounded (4 MiB compressed/decompressed wrapper;
  reader depth 16, 4096 tags/entries/string bytes, duplicate/trailing rejection).
  The dimension assertion preserves the three project baseline mappings and
  rejects a dimension named for the gas body. It is not a complete physical
  world/mapping migration or arbitrary extra-dimension audit.
- The runner has no client, artificial release hooks, flight, forced stop or
  failed catalog reload. Its valid reload checks celestial publication only;
  no DATA-02 joint-catalog/raw-parser guarantee is inferred. Unmapped metadata
  and retained station identity are not new terrain or completed v1.4 gameplay.

## Commands and identities actually inspected

HEAD/baseline: `8947fac9641dc11ce2dce1ed8a3877984be044ab`; branch remains
`codex/v1.4.0-planetary-expansion`. Source was still changing under the root
writer. `source-initial.json` records hashes of the seven principal files;
the initial GameTest and runner were separately copied to this unique Temp.

Actual commands: scoped `git rev-parse HEAD`, `git status --short`,
`git diff --stat/--binary 8947fac...`, `Get-Content` with line numbering,
`rg -n/--files` in explicit source/scripts/tests/governance locations, cached
Forge source-JAR path enumeration, and `Get-FileHash -Algorithm SHA256`.
`git diff --check 8947fac -- src scripts tests docs/provenance gradle.properties compat-test-mod/build.gradle`
returned 0. As usual this does not cover untracked files' whitespace.
One Windows `rg` invocation using literal wildcard path arguments failed
with error 123; it was replaced by `rg ... scripts --glob '*.py'`. No
production or test failure is inferred from that inspection error.

No Gradle, Java process, server, Python test, mutable build inspection,
repository edits, remote/network operation or excluded user-bundle access
was performed. All reviewer writes are in this Temp directory. Parent-reported
full JUnit/GameTest results were not independently inspected or reproduced.

## Remaining work

Re-read the cleanup correction and final runner/regressions, then execute
only the targeted checks granted after root releases the build slot.
Native execution has not yet occurred in the reviewed evidence; audit the
eventual exact artifact identities, raw logs, native station/level files and
manifest rather than trusting summary PASS. A few pure Python harness tests
covering pack preservation, native mismatch and failure cleanup would make
these runner boundaries executable without expanding the server campaign.

This is an interim scoped source report, not a release or Required Gate
decision. Prior findings/reports remain unchanged.
