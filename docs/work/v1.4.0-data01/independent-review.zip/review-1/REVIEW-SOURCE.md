# V140-DATA-01 independent source review (interim)

## Findings

### Medium, resolved in source; executable regression still pending

`CelestialDefinitionCodec.Fields.has` initially used `map.get(name) != null`
(initial reviewed file lines 127-129). The pinned DFU 6.0.8 implementation of
`JsonOps$1.get(String)` normalizes an explicit `JsonNull` to Java null. This
made explicit null indistinguishable from absence at schema selection
(lines 80-81), new-field rejection (87), and optional parent/Level reads
(96-99, 144-145). This violates ADR-031 lines 83-87 and 106-115.

Concrete affected otherwise-valid inputs were: schema-2 unmapped gas body
with `level:null`; root Earth with `parent:null`; and legacy Earth with
`schema_version:null`, `capabilities:null`, `solar_intensity:null`, or
`radiation:null`. Original null tests using mapped Moon or schema-2 gas
could reject through unrelated invariants, masking this presence defect.
This conclusion is from source plus pinned bytecode, not an executed
production-code reproduction.

Root acknowledged the finding and changed actual lines 127-130 to test
raw entry keys. `required` now still rejects null after that presence test.
The newly inspected `explicitNullCannotMasqueradeAsAnAbsentOptionalOrLegacyField`
test at `CelestialSchemaV2Test.java:79-92` isolates unmapped Level, root
parent, and the five legacy null-field cases. This source correction
addresses the identified cause without changing defaults or permitting
malformed input. It has NOT been independently run in this review.

No additional concrete production finding was identified in the reviewed
DATA-01 diff. This is an interim source assessment, not final acceptance.

## Reviewed scope and observations

Repository: `D:/GitHub/AdvancedRocketry-Community`; branch
`codex/v1.4.0-planetary-expansion`; HEAD and diff baseline
`8947fac9641dc11ce2dce1ed8a3877984be044ab`. Root continued adding tests and
normalizing source bytes during inspection; this is not a frozen commit.
`source-identities-initial.json` is the first recorded hash checkpoint,
already after the presence correction, not the original defective preimage.
Later copies of three reviewed new files retain the reviewed follow-up bytes.

- Accepted ADR-030 permits this development scope but does not approve
  inherited/version Gates. ADR-031 and the DATA-01 log correctly reserve
  raw bounded reading/coherent route publication for DATA-02 and persistent
  custom world bindings for MAP/MIG.
- `CelestialBodyDefinition.java:31-56,59-75` applies constructor invariants,
  lossless legacy defaults, optional mapping and Space surface exclusion.
  `BoundedCelestialCodecs.java:20-55,83-108` rejects fractional/exponent
  integer syntax, nonnumeric JSON, nonfinite ranges and mistyped booleans.
  `CelestialDefinitionCodec.java:58-64` refuses lossy legacy output.
- `CelestialCatalog.java:27-31,65-84,98-105` indexes only mapped bodies,
  retains fixed Earth/Moon/Space requirements and leaves multi-body Level
  lookup ambiguous rather than selecting a first match. Existing
  BodyContext instance precedence remains unchanged.
- `RocketTargetFlightPlanner.java:49-55,114-145` distinguishes new arrival
  from departure: closed mapped surfaces and committed station sources can
  leave, while absent mappings, Space-as-surface and disabled destination
  capabilities reject. The pure planner does not itself grant live Level,
  chunk, permission or station-region authority.
- `RocketFlightService.java:110-115,131-148,254-319,385-405` filters quotes,
  fails closed for configured-but-unready managers, preserves live station
  and permission checks, and returns plan failure before countdown/transfer
  preparation. Only the explicit no-manager legacy-test path retains its
  fixed fallback. Captured flight/transfer journal recovery was not changed.
- `StationManager.java:44-52` applies orbitable admission to creation;
  existing station records/startup identity checks and reservation recovery
  are not reclassified by that predicate. `LegacyFlightTargetMigrator.java:82-90`
  still checks exact legacy dimension identity rather than rewriting it or
  treating a closed arrival capability as a missing source.
- Celestial snapshot/channel move to 2; the display payload includes
  optional Level, capability and environment fields. `CelestialSnapshotCodec`
  retains 128 bodies / 96 KiB, hard-bounds encoder capacity, checks strict
  flags, IDs, numeric/capability invariants, graph and trailing bytes.
  `CelestialSnapshotPacket.java:51-59` rejects trailing envelope bytes.
  Existing cache replacement/disconnect lifecycle remains display-only.
- Legacy importer now reports constructor-invalid canonical data instead of
  allowing the new constructor exception to escape. Its exporter intentionally
  uses normal schema-2 encoding. The historic DataGen provider alone calls
  checked legacy encoding (`CelestialDefinitionProvider.java:41-46`); no
  generated-resource byte identity is claimed before actual DataGen/artifact
  checks.
- Inspected new schema/snapshot/planner tests and adjacent updated tests.
  The test-only Mars mapping change from shared Space to a test-only Level
  key preserves its pure data-driven planning purpose, without proving
  physical reachability. A separate shared-Space surface rejection test is
  present at `PlanetaryFlightAdmissionTest.java:70-80`.

## Checks actually performed

All commands were read-only repository inspection except writing this unique
Temp directory. No excluded user documentation bundle was opened.

1. `git rev-parse HEAD`, `git branch --show-current`, scoped status,
   `git diff 8947fac9641dc11ce2dce1ed8a3877984be044ab -- ...`, and scoped
   `rg -n`/`rg --files` caller searches, plus `Get-Content` with line numbers.
   Read AGENTS, project/product, porting/version/test/Gate/parallel/quality
   rules, accepted ADRs, active log, changed production and tests, and
   adjacent catalog/context/flight/transfer/station/legacy consumers.
2. `git diff --check 8947fac9641dc11ce2dce1ed8a3877984be044ab -- src docs/work/v1.4.0-implementation-log.md`
   returned 0 at both inspection checkpoints (tool transcript; empty output
   pipelines did not create the requested text files). This does not include whitespace
   validation of untracked files or prove compilation.
3. `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -c -p -classpath C:/Users/Administrator/.gradle/caches/modules-2/files-2.1/com.mojang/datafixerupper/6.0.8/3ba4a30557a9b057760af4011f909ba619fc5125/datafixerupper-6.0.8.jar com.mojang.serialization.JsonOps$1`
   returned 0; saved `JsonOps-map-javap.txt` establishes null normalization.
4. Scoped API/build/generated source-diff inventory returned no changed
   tracked files (saved `api-build-generated-static-check.json`). This is
   source inspection, NOT API classifier or generated artifact identity.
5. `Get-FileHash -Algorithm SHA256` recorded source/contract identities and
   follow-up copies. `reviewed-tracked.patch` does not include untracked new
   files; three relevant new files were separately copied into this Temp.

Read-only exploration mistakes were retained in the session: guessed
`docs/versions/v1.4.0.md`, `CelestialDefinitionValidator.java`,
`RouteCatalogValidator.java`, `celestial/client/ClientCelestialCache.java`,
and `LegacyCelestialExporter.java` did not exist; actual files were found by
scoped search. An empty Git-output pipeline did not create a requested Temp
text file; its `Get-Item` failed. A subsequent JSON command/result capture
explicitly records the empty changed-file list. These were inspection-helper
errors, not production/test failures.

## Unverified boundaries and useful next checks

- No Gradle, compilation, JUnit, GameTest, Python test, server/client, network,
  native save/restart, artifact or mutable build inspection was executed.
  Root's reported test results are not counted as independent results here.
- Root is still adding Forge authority tests. Re-review their actual fixture
  isolation and resource/journal refusal assertions before final scope
  disposition; pure immutable fuel assertions do not prove live conservation.
- After root releases output, independently execute the schema/snapshot,
  catalog/legacy import and migration, typed/planetary flight admission,
  relevant station and environment tests with actual task execution. Check
  API export/class-byte identity and historic generated data against the
  retained artifact/resource baseline, then audit the bounded native evidence.
- DATA-02's raw byte/depth/duplicate-key limits, coupled catalog generation,
  malformed-resource rollback and initial startup failure are not delivered
  by these changes. No arbitrary new-world admission, cross-restart custom
  mapping protection, new environment effects, genuine old-world upgrade,
  client/V1/V2, S2, full remote or long-load acceptance is inferred.

## Disposition

Source review complete for the inspected changing diff, with one concrete
finding corrected in source and regression execution pending. Repository
files modified by this reviewer: none. No release, candidate or Required
Gate approval; version completeness is outside this review.
