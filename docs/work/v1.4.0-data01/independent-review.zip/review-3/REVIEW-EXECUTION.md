# V140-DATA-01 independent executable review

## Findings and resolution

No unresolved concrete finding was identified in the final reviewed DATA-01
source and the checks executed below. This is a slice result, not a release,
full acceptance or Required Gate approval.

Previously reported issues remain recorded in the unchanged earlier reports:

1. **Medium, JSON null presence:** `CelestialDefinitionCodec.java:127-130`
   now checks raw map entry keys instead of JsonOps-normalized values.
   The isolated null regression at `CelestialSchemaV2Test.java:79-92`
   actually executed and passed in the 12-test schema suite.
2. **Medium, remote GameTest fixture cleanup:**
   `PlanetaryAdmissionGameTests.java:138-192,196-215` now establishes a
   fixture-owned cleanup before station allocation/entity installation and
   invokes it on initialization exceptions. Visibility is checked once per
   tick and fails with cleanup at tick 80, before the unchanged 100-tick
   timeout. The successful/assertion-failed branch cleans in finally. Only
   its own rocket, station/reservation and UUID ticket are removed. All
   three planetary GameTests actually passed. The never-visible path is
   source-reviewed, not separately fault-injected in this execution.
3. **Low, native failure records:** the runner now wraps process creation,
   writes phase FAIL/error and actual exit code in finally, and retains
   commands/logs. Both startup-wait failure and process-construction failure
   regressions actually passed. No native Java process was launched by this
   reviewer.

The metadata/provenance and test-only Mars mapping changes do not add physical
destinations, change public API 1.7 or claim a release. Current native harness
scope remains schema-2 data and retained station identity, not completed
flight, client synchronization or joint-catalog reload.

## Reviewed identity and authority

- Checkout: `D:/GitHub/AdvancedRocketry-Community`.
- Branch: `codex/v1.4.0-planetary-expansion`.
- HEAD/diff baseline during this execution:
  `8947fac9641dc11ce2dce1ed8a3877984be044ab`, plus the root's frozen, reviewed
  tracked changes and explicitly inspected new files.
- Root granted the exclusive Gradle/build slot and the exact full short
  command. No other reviewer/root Gradle ran concurrently. The slot was
  explicitly released after command termination and output capture.
- Before/after SHA-256 inventories cover 1,237 tracked/new source, test,
  scripts and build-input files; no byte changes were found. Documents are
  not claimed frozen by this inventory. No tracked file was edited, staged
  or committed by this reviewer, and the excluded user bundle was not read.

## Independently executed commands

Working directory was the checkout. Environment: Java 17 at
`C:/Program Files/Java/jdk-17.0.7`, its `bin` prepended to PATH,
`PYTHONUTF8=1`.

```powershell
.\gradlew.bat clean build runData runGameTestServer --offline --no-daemon --console=plain
& 'D:/python/pyenv/pyenv-win/shims/python.bat' -B -m unittest tests.test_v140_celestial_schema_smoke -v
& 'D:/python/pyenv/pyenv-win/shims/python.bat' -B <this-review-directory>/audit_after.py
git diff --check 8947fac -- src scripts tests gradle.properties build.gradle compat-test-mod/build.gradle docs/provenance
```

All returned exit 0. Gradle took **150.613 seconds**, reporting 2m30s and
27 actionable tasks (19 executed, seven from cache, one up-to-date).

### Actual results, including cache distinction

- **792 JUnit tests / 146 suites**, zero failures, errors or skips. `:test`
  actually executed; it was neither `FROM-CACHE` nor `UP-TO-DATE`. Some
  prerequisite compile tasks were cached. All raw XML files are copied in
  `junit/`, with per-suite inventory in `junit-summary.json`.
- New focused suites: **12 CelestialSchemaV2Test**, **6 CelestialSnapshotV2Test**,
  **5 PlanetaryFlightAdmissionTest**, all actually passed.
- **213 required GameTests passed**, including the actual
  `planetary_admission:1` three-test batch. `clean` recreated the configured
  `build/gametest` execution directory; this is not a reused-world rerun.
- **Five runner Python tests passed**: pack preservation/no gas mapping,
  exact native-station mismatch refusal, decompression bound, startup failure
  cleanup and process-creation failure evidence. unittest reported 0.168 s;
  including interpreter startup the wrapper measured 0.776 s.
- DataGen reported **written: 0**. The executed providers were the two
  current language providers; this does not claim the historical celestial
  provider was itself regenerated. `src/generated` has no diff against the
  review baseline. Separate ZIP inspection confirms the packaged legacy
  Earth/Moon/Space JSON bytes exactly match that baseline's tracked blobs.
- Retained warning: **3196 ms / 63 ticks behind** during the GameTest run.
  The pre-existing PrecisionAssembler GameTest deprecated ResourceLocation
  constructor warning and Gradle deprecation notice also remain in raw logs.
  No performance or zero-warning claim is made. This run contains intentional
  fault tests; no broad zero-ERROR log claim is inferred from the green suite.

Raw Gradle log SHA-256:
`6415928c6a5b022a0972ced914e187c66e6dace5cf8d369839d98991c0890f0f`.
Raw Python log SHA-256:
`9d714b49c6361675f2f8403dd0be7ab5be46a4294144b4be5e1337166374b7b8`.

## Artifact inspection

Actual rebuilt artifacts (not filenames inferred from version metadata):

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `advancedrocketry-community-1.20.1-1.4.0-dev.jar` | 2,382,423 | `62b187661dcd8328db141a7ea276457797743cd06061929421595bca7dbcf8f9` |
| `advancedrocketry-community-1.20.1-1.4.0-dev-api.jar` | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| `advancedrocketry-community-1.20.1-1.4.0-dev-sources.jar` | 1,085,269 | `0c8d50ffe9c564c3a923a5867952b54ebe79f972405aa43afd5f4d4fd6eff00e` |

The API JAR's entire bytes/hash equal the v1.3 handoff API record in
`docs/releases/v1.3.0/development-artifacts.json`, despite the new filename.
It contains exactly **27 API classes**, with no non-API class paths; each
class equals the corresponding rebuilt main-JAR entry byte-for-byte.
Main/API/sources contain no `arceadaptertest/` classes or `arce_adapter_test/`
resources and no duplicate ZIP entries. These checks do not constitute a new
standalone consumer compilation/publication run.

The main/source hashes differ from the artifacts present before this clean
build; those earlier artifacts preceded the final GameTest cleanup edit.
Both identities are preserved (`artifacts-before.json`, `audit-after.json`),
so the older main/source bytes are not relabeled as this execution's output.

Packaged legacy resource baseline equality is recorded in
`legacy-packaged-data.json`: Earth `6f511da6...`, Moon `d01c2816...`,
Space `18e197a1...`, with complete SHA-256 values retained there.

## Evidence and remaining limits

Evidence directory is this report's parent. It retains exact command/time/exit
records, full Gradle/Python logs, original GameTest latest/debug logs, all
146 JUnit XML files, before/after source hashes, before/after artifact records,
the actual audit helper and its output, generated-resource diff and final
diff-check result. Earlier interim reports/failure findings were not rewritten.

Still unverified here: the planned two-process packaged native execution and
independent raw station/level readback; authentic old-world upgrade; rejected
or coupled reload; custom Level persistence; new terrain; completed travel;
actual client/network/GPU/multiplayer; crash cuts and load/performance acceptance.
DATA-02/MAP/MIG and inherited/version Gates remain open. Root will run native
against immutable copies of the exact artifacts above; that later evidence
must be identified separately rather than inferred from this build.
