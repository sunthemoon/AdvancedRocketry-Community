import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    done = subprocess.run(['git', *args], cwd=ROOT, text=True, capture_output=True, check=True)
    return done.stdout


before = json.loads((OUT / 'source-before.json').read_text(encoding='utf-8-sig'))
after = [dict(path=item['path'], bytes=(ROOT / item['path']).stat().st_size,
              sha256=digest(ROOT / item['path'])) for item in before]
changes = [dict(before=left, after=right) for left, right in zip(before, after) if left != right]
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf-8')

junit = []
xml_out = OUT / 'junit'
xml_out.mkdir()
for path in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
    tree = ET.parse(path).getroot()
    junit.append({key: tree.get(key) for key in ('name', 'tests', 'failures', 'errors', 'skipped', 'time')})
    shutil.copyfile(path, xml_out / path.name)
totals = {key: sum(int(s[key] or '0') for s in junit) for key in ('tests', 'failures', 'errors', 'skipped')}

artifacts = []
for path in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append(dict(name=path.name, bytes=path.stat().st_size, sha256=digest(path)))
api_path = next((ROOT / 'build/libs').glob('*-api.jar'))
main_path = next(path for path in (ROOT / 'build/libs').glob('*.jar')
                 if not path.name.endswith(('-api.jar', '-sources.jar')))
sources_path = next((ROOT / 'build/libs').glob('*-sources.jar'))
baseline = json.loads((ROOT / 'docs/releases/v1.3.0/development-artifacts.json').read_text(encoding='utf-8'))
expected_api = next(item for item in baseline['artifacts'] if item['name'].endswith('-api.jar'))
prefix = 'io/github/sunthemoon/advancedrocketrycommunity/api/'
with zipfile.ZipFile(api_path) as api, zipfile.ZipFile(main_path) as main, zipfile.ZipFile(sources_path) as source:
    classes = sorted(name for name in api.namelist() if name.endswith('.class'))
    byte_mismatches = [name for name in classes if name not in main.namelist() or api.read(name) != main.read(name)]
    fixture_entries = {path.name: [name for name in archive.namelist()
                                   if 'arceadaptertest/' in name or 'arce_adapter_test/' in name]
                       for path, archive in ((api_path, api), (main_path, main), (sources_path, source))}
    duplicate_entries = {path.name: len(archive.namelist()) - len(set(archive.namelist()))
                         for path, archive in ((api_path, api), (main_path, main), (sources_path, source))}

generated_diff = git('diff', '8947fac9641dc11ce2dce1ed8a3877984be044ab', '--', 'src/generated')
(OUT / 'generated-resources.diff').write_text(generated_diff, encoding='utf-8')
log = (OUT / 'gradle.txt').read_text(encoding='utf-8-sig', errors='strict')
task_lines = [line for line in log.splitlines() if line.startswith('> Task :')]
test_tasks = [line for line in task_lines if line.split()[2] == ':test']
gametest_lines = [line for line in log.splitlines()
                 if ('tests passed' in line or 'tests failed' in line or 'tests complete' in line
                     or 'planetary_admission' in line or "Can't keep up" in line
                     or 'BUILD SUCCESSFUL' in line or 'BUILD FAILED' in line)]
summary = dict(head=git('rev-parse', 'HEAD').strip(), source_files=len(after), source_changes=changes,
               junit_suites=len(junit), junit_totals=totals, junit_task_lines=test_tasks,
               artifacts=artifacts, api_baseline=expected_api,
               api_hash_matches_baseline=digest(api_path) == expected_api['sha256'],
               api_class_count=len(classes), api_class_names=classes,
               api_non_public_class_paths=[name for name in classes if not name.startswith(prefix)],
               api_main_class_byte_mismatches=byte_mismatches, fixture_entries=fixture_entries,
               duplicate_entries=duplicate_entries, generated_diff_empty=not generated_diff,
               gametest_log_evidence=gametest_lines,
               gradle_result=json.loads((OUT / 'gradle-result.json').read_text(encoding='utf-8-sig')),
               python_result=json.loads((OUT / 'python-result.json').read_text(encoding='utf-8-sig')))
(OUT / 'junit-summary.json').write_text(json.dumps(junit, indent=2) + '\n', encoding='utf-8')
(OUT / 'audit-after.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
assert not changes, 'Reviewed source files changed'
assert totals['failures'] == totals['errors'] == totals['skipped'] == 0
assert summary['api_hash_matches_baseline'] and len(classes) == baseline['api_class_count'] == 27
assert not byte_mismatches and not summary['api_non_public_class_paths']
assert not any(fixture_entries.values()) and not any(duplicate_entries.values())
assert not generated_diff
assert summary['gradle_result']['exit_code'] == summary['python_result']['exit_code'] == 0
print(json.dumps({key: value for key, value in summary.items() if key not in ('api_class_names',)}, indent=2))
