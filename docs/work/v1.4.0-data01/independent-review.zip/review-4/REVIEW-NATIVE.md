# V140-DATA-01 final runner delta and native evidence review

## Findings

No unresolved concrete finding was identified in the reviewed Python-only
correction or the bounded corrected native evidence. This supplements, rather
than replaces, the source/Gradle review. It is not a release or Gate approval.

The first native attempt remains a **failure**: its first Java process exited
0 after the reload/station work, but the runner then applied the small celestial
SavedData decoder to whole-world `level.dat` and hit the 4096-tag limit.
`native-evidence/create-reload/observations.json` records FAIL/exit 0 and the
error. There is no restart phase in that attempt. The independent audit
reproduced the exact bounded-parser rejection from its retained raw level.dat.
It is not relabeled as a successful two-process run.

## Actual correction and independent Python execution

`scripts/run_v140_celestial_schema_smoke.py:131-138` now asks the live server
to resolve Overworld, Moon and Space through `execute in ... run time query
gametime`, and requires the explicit unknown-dimension failure for the gas
body key. Lines 150-151 retain a bounded raw `level.dat` copy. Station parsing,
station equality, process ownership/cleanup and their limits are unchanged.
There is **no full level.dat registry decode claim**. This is a different,
explicitly scoped live-Level oracle, not a raised SavedData parser limit.

Compared with all 1,237 source/build/test inputs captured after the independent
full build, only the runner file changed; Java, resources and Python tests did
not. Runner SHA-256:
`574287d75203e914b279d0a15cea367805c9f1f1468286518ea2e3baeb395627`.
Tests SHA-256:
`9b329c13fb1a267965f1f28fe0332e71e9bac8e1a8239117cf9a9899767a09e9`.
Both actual files are copied into this review directory.

Independently executed, in the repository with `PYTHONUTF8=1`:

```powershell
& 'D:/python/pyenv/pyenv-win/shims/python.bat' -B -m unittest tests.test_v140_celestial_schema_smoke -v
& 'D:/python/pyenv/pyenv-win/shims/python.bat' -B <this-review-directory>/native_audit.py
```

The five Python regressions passed, exit 0, unittest time **0.178 seconds**.
They cover pack preservation, station equality, the decompression limit and
two failure/cleanup cases; they do not independently mock the new live probes.
The corrected two-process evidence supplies those actual probe observations.
The final read-only raw-data audit also exited 0. No Gradle, Java/native server,
remote or gameplay process was started or managed in this follow-up.

## Corrected native evidence independently checked

Input evidence:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-data01-1790493060061/native-evidence-2`.

- All **22** manifest entries match actual SHA-256 values; the manifest covers
  every captured file other than itself, with no duplicate or escaping path.
- Actual immutable host artifact and installed server copy both equal the
  independently rebuilt main JAR:
  `62b187661dcd8328db141a7ea276457797743cd06061929421595bca7dbcf8f9`,
  2,382,423 bytes. There is one installed mod JAR. Launch records have no
  release-test hooks. Raw ModLauncher logs identify Java 17.0.7, Forge 47.4.10
  and Minecraft 1.20.1, matching the launch argfile/hash.
- Both raw status replies identify exactly Minecraft, Forge and the host;
  host version is `1.20.1-1.4.0-dev`, online players zero. The server binds
  loopback. Forge status uses its optimized `d` representation and an empty
  Forge mod marker; the Forge loader version comes from the raw launch log,
  not that empty marker.
- Raw first-phase logs show generation 1/three bodies, creation of station
  `6ef3192c-b1c5-4aff-b55d-3793d46d089a`, then one real reload to generation
  2/four bodies. Restart logs show generation 1/four bodies without another
  reload. Both show the exact closed Moon and unmapped gas capability and
  environment values, existing Moon station inspection, and rejection of
  a new Moon station with `UNKNOWN_ORBIT_BODY`.
- Each phase's captured command sequence contains the three fixed-Level
  probes and the gas probe exactly once. Corresponding raw logs contain
  exactly three successful game-time responses and one explicit
  `Unknown dimension 'advancedrocketrycommunity:schema_probe_gas'` refusal.
  The observation values agree with the raw responses. This proves actual
  started-Level availability/refusal for these four keys, not an inventory
  of every possible registry entry or dimension directory.
- Independently read the native station file before reload, after the first
  clean stop and after the second clean stop. **All three compressed byte
  sequences, decompressed NBT bytes and decoded roots are identical**,
  stronger than checking only the JSON projection. Compressed SHA-256 is
  `36052ac204c0073d4051ed63cea26f3cca89182f728f0c9be099fd3cde2b58d4`;
  decompressed SHA-256 is
  `a56b3ded3e1798525f4b5f938d41fd42740cba02980e430416cb2ffc13b3ec8e`.
- The native registry has schema 2 / `v0.9.0-beta`, one schema-1 station and
  zero reservations. Station UUID/owner UUID bind to the actual creation
  command and receipt; orbit remains Moon, pad `[0,128,0]`, region
  `[-256,-256,255,255]`, members/invitations empty. The full saved environment
  and all other native fields remain unchanged.
- Both phase observations record process exit 0, corroborated by actual
  stop/save completion logs and the subsequent same-world start. The raw
  level.dat before/after hashes match the summary and the final stopped
  world's file. Independently recomputed the world-identity marker formula
  from its actual session ID, artifact hash, first level.dat hash and startup
  properties identity; it matches the retained marker/hash and summary.
  This does not assert byte equality of level.dat across normal gameplay.
- Independently read the installed data pack: Moon retains every old field
  from the actual host JAR; new flags/solar/radiation are explicit. Gas has
  no Level field. The native scripts did not rewrite the station record to
  synthesize the retained-identity result.

## Log classification and preserved mistakes

Inspected stdout, latest.log and debug.log in **both** corrected phases, not
only the runner's PASS. No ERROR, FATAL or client-linkage marker was found;
all warning lines are retained in `native-audit.json` for inspection. Standard
`/WARN]` lines total **26** and **10**; stdout additionally includes one
terminal-capability `main WARN` in each phase (27/11 with that line counted).
They include ordinary initial config defaults, Forge library/pack notices,
loopback offline-mode warnings, and **one 2117 ms / 42 ticks lag warning** in
the first phase. No zero-warning or performance acceptance claim is made.

The independent audit itself retained two failed attempts:
`native-audit-first.py/.txt` wrongly assumed legacy `forgeData.mods` was
populated; `native-audit-second.py/.txt` decoded optimized data but wrongly
expected the Forge mod marker to contain its loader version. Both assumptions
were corrected against the actual raw status shape, the inspected existing
optimized decoder and the raw ModLauncher version line. No capture, production
assertion or test expectation was changed. These helper failures are not
classified as production failures and were not discarded.

## Scope, commands and remaining limits

Other actual commands were read-only `Get-Content`, scoped `Select-String`,
directory listing, `git rev-parse HEAD`, and source/evidence `Get-FileHash`.
The audit helper reads bounded raw native NBT, manifests, ZIP source resource,
status/launch/command/log files and world markers; it writes only this unique
Temp directory. The user documentation bundle and all repository/world files
remain untouched. No new build is implied by this Python-only correction.

The native scope is a fresh S1 world, real schema reload, refusal of new station
creation on a closed orbit, unchanged existing station authority and one clean
restart. It is not an authentic older-world upgrade, completed rocket travel,
failed/coherent celestial-route reload, crash recovery, client network/GPU,
multiplayer, new terrain or long-load test. Full level.dat decoding is expressly
unverified; raw capture/hash and live probes are the evidence used. DATA-02,
MAP/MIG and inherited/current version Gates remain open.

Final helper/result and all earlier attempts are preserved here. Prior review
directories and the original failed native evidence remain unchanged.
