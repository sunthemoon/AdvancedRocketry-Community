import gzip
import hashlib
import io
import json
import re
import sys
import uuid
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-data01-1790493060061')
EVIDENCE = BASE / 'native-evidence-2'
PREVIOUS = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-data01-final-review-ba39200886574507be8b269b25d5e01e')
sys.path.insert(0, str(ROOT))
from scripts.inspect_celestial_saved_data import NbtReader, NbtError
from scripts.run_dedicated_server_smoke import forge_mod_versions


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def raw_station(path):
    compressed = path.read_bytes()
    assert len(compressed) < 4 * 1024**2
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        raw = stream.read(4 * 1024**2 + 1)
    assert len(raw) <= 4 * 1024**2
    return compressed, raw, NbtReader(raw).read_root()


def nbt_uuid(parts):
    assert len(parts) == 4
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in parts)))


manifest = {}
for line in (EVIDENCE / 'SHA256SUMS').read_text(encoding='ascii').splitlines():
    digest, name = line.split('  ', 1)
    assert name not in manifest and '..' not in Path(name).parts and not Path(name).is_absolute()
    path = EVIDENCE / name
    assert path.is_file() and sha(path.read_bytes()) == digest
    manifest[name] = digest
assert set(manifest) == {p.relative_to(EVIDENCE).as_posix() for p in EVIDENCE.rglob('*')
                         if p.is_file() and p.name != 'SHA256SUMS'}

summary = load(EVIDENCE / 'summary.json')
server = Path(summary['server'])
artifact = summary['artifact']
expected = next(a for a in load(PREVIOUS / 'audit-after.json')['artifacts']
                if a['name'] == artifact['name'])
assert artifact['sha256'] == expected['sha256'] == '62b187661dcd8328db141a7ea276457797743cd06061929421595bca7dbcf8f9'
assert sha(Path(artifact['path']).read_bytes()) == artifact['sha256']
assert sha((server / 'mods' / artifact['name']).read_bytes()) == artifact['sha256']
assert [p.name for p in (server / 'mods').glob('*.jar')] == [artifact['name']]

initial_bytes, initial_raw, initial_root = raw_station(EVIDENCE / 'create-reload/before-reload-stations.dat')
data = initial_root['data']
assert data['schema_version'] == 2 and data['format_epoch'] == 'v0.9.0-beta'
assert data['reservations'] == [] and len(data['stations']) == 1
station = data['stations'][0]
sid = nbt_uuid(station['station_id'])
owner = nbt_uuid(station['owner_id'])
assert sid == summary['station_id'] and station['orbit_body'] == 'advancedrocketrycommunity:moon'
assert station['schema_version'] == 1 and station['landing_pad'] == [0, 128, 0]
assert station['region'] == [-256, -256, 255, 255] and station['members'] == station['invitations'] == []

phase_reports = {}
for phase in ('create-reload', 'restart'):
    directory = EVIDENCE / phase
    raw_bytes, raw, root = raw_station(directory / 'stations.dat')
    assert raw_bytes == initial_bytes and raw == initial_raw and root == initial_root
    assert root['data'] == load(directory / 'native-stations.json')
    commands = load(directory / 'commands.json')
    if phase == 'create-reload':
        assert f'arce station admin create {owner} advancedrocketrycommunity:moon Schema probe' in commands
        assert commands.count('reload') == 1
    else:
        assert 'reload' not in commands
    dims = ['minecraft:overworld', 'advancedrocketrycommunity:moon', 'advancedrocketrycommunity:space']
    gas = 'advancedrocketrycommunity:schema_probe_gas'
    for dim in [*dims, gas]:
        assert commands.count(f'execute in {dim} run time query gametime') == 1
    assert commands[-1] == 'stop'
    stdout = (directory / 'stdout.txt').read_text(encoding='utf-8')
    times = re.findall(r'\[minecraft/MinecraftServer\]: The time is (\d+)', stdout)
    assert len(times) == 3
    assert stdout.count(f"Unknown dimension '{gas}'") == 1
    assert stdout.count('Station creation failed: UNKNOWN_ORBIT_BODY') == 1
    assert f'orbit=advancedrocketrycommunity:moon gravity_milli=0 vacuum=true' in stdout
    assert 'landable=false orbitable=false gas_giant=false solar=0.5 radiation=0.25' in stdout
    assert 'schema_probe_gas -> unmapped gravity=2.5' in stdout
    assert 'landable=false orbitable=true gas_giant=true solar=0.04 radiation=0.5' in stdout
    assert 'Stopping server' in stdout and 'All dimensions are saved' in stdout
    assert 'Starting Minecraft server on 127.0.0.1:' in stdout
    if phase == 'create-reload':
        assert f'Created Schema probe id={sid} cell=0,0' in stdout
        assert 'Accepted celestial catalog generation 1 with 3 bodies' in stdout
        assert 'Accepted celestial catalog generation 2 with 4 bodies' in stdout
    else:
        assert 'Accepted celestial catalog generation 1 with 4 bodies' in stdout
    logs = {}
    for name in ('stdout.txt', 'debug.log', 'latest.log'):
        content = (directory / name).read_text(encoding='utf-8')
        errors = [line for line in content.splitlines() if re.search(r'/ERROR\]|/FATAL\]', line)]
        linkage = [line for line in content.splitlines() if any(token in line for token in
                   ('Attempted to load class net/minecraft/client', 'NoClassDefFoundError: net/minecraft/client',
                    'ClassNotFoundException: net.minecraft.client'))]
        assert not errors and not linkage
        logs[name] = dict(sha256=sha((directory / name).read_bytes()), errors=errors, linkage=linkage,
                          warnings=[line for line in content.splitlines() if '/WARN]' in line or ' main WARN ' in line],
                          lag_warnings=[line for line in content.splitlines() if "Can't keep up" in line])
    observation = load(directory / 'observations.json')
    assert observation['result'] == 'PASS' and observation['exit_code'] == 0
    assert [observation['live_dimension_probes'][d]['game_time'] for d in dims] == list(map(int, times))
    assert observation['live_dimension_probes'][gas] == {'available': False}
    launch = load(directory / 'launch.json')
    assert Path(launch['cwd']) == server and launch['artifact'] == artifact
    assert not any('releaseTestHooks' in arg for arg in launch['command'])
    argfile = next(arg[1:] for arg in launch['command'] if arg.startswith('@'))
    assert sha((server / argfile).read_bytes()) == summary['forge_args_sha256']
    status = load(directory / 'status.json')
    assert status['players']['online'] == 0
    mods = forge_mod_versions(status)
    # Forge's optimized status carries an empty marker, not its loader version.
    assert mods == {'minecraft': '1.20.1', 'forge': '', 'advancedrocketrycommunity': '1.20.1-1.4.0-dev'}
    assert '--fml.forgeVersion, 47.4.10, --fml.mcVersion, 1.20.1' in stdout
    phase_reports[phase] = dict(exit_code=observation['exit_code'], station_compressed_sha256=sha(raw_bytes),
                               station_raw_sha256=sha(raw), station_bytes_unchanged=True,
                               command_count=len(commands), live_game_times=times, status_mods=mods, logs=logs)

world = summary['world']
assert sha((EVIDENCE / 'create-reload/level.dat').read_bytes()) == world['level_dat_before_restart_sha256']
assert sha((EVIDENCE / 'restart/level.dat').read_bytes()) == world['level_dat_after_restart_sha256']
assert sha((server / 'world/level.dat').read_bytes()) == world['level_dat_after_restart_sha256']
marker_path = server / world['identity_marker']
assert sha(marker_path.read_bytes()) == world['identity_marker_sha256']
marker = load(marker_path)
assert marker['artifact_sha256'] == artifact['sha256']
assert marker['server_properties_sha256'] == world['server_properties_sha256']
assert sha((server / 'server.properties.v002-startup').read_bytes()) == world['server_properties_sha256']
identity_input = f"{marker['session_id']}\0{artifact['sha256']}\0{world['level_dat_before_restart_sha256']}\0{world['server_properties_sha256']}"
assert sha(identity_input.encode()) == marker['world_identity'] == world['identity']
(OUT / 'world-marker-observed.json').write_text(json.dumps(marker, indent=2) + '\n', encoding='utf-8')

pack = server / 'world/datapacks/schema_probe/data/advancedrocketrycommunity/celestial_bodies'
moon = load(pack / 'moon.json')
gas = load(pack / 'schema_probe_gas.json')
with zipfile.ZipFile(Path(artifact['path'])) as jar:
    old_moon = json.loads(jar.read('data/advancedrocketrycommunity/celestial_bodies/moon.json'))
assert {key: moon[key] for key in old_moon} == old_moon
assert 'level' not in gas and gas['capabilities'] == dict(landable=False, orbitable=True, gas_giant=True)

failed = load(BASE / 'native-evidence/create-reload/observations.json')
assert failed['result'] == 'FAIL' and failed['exit_code'] == 0 and '4096 tags' in failed['error']
assert not (BASE / 'native-evidence/restart').exists()
try:
    raw_station(BASE / 'native-evidence/create-reload/level.dat')
except NbtError as error:
    original_error = str(error)
else:
    raise AssertionError('Original whole-level decoder failure was not reproduced')
assert '4096 tags' in original_error

before = load(PREVIOUS / 'source-after.json')
changed = [item['path'] for item in before if sha((ROOT / item['path']).read_bytes()) != item['sha256']]
assert changed == ['scripts/run_v140_celestial_schema_smoke.py']
assert sha((ROOT / changed[0]).read_bytes()) == sha((OUT / 'runner-reviewed.py').read_bytes())
report = dict(manifest_files=len(manifest), artifact=artifact, station_id=sid, owner_id=owner,
              station_native_data=data, phases=phase_reports, world_hashes=world,
              level_dat_interpretation='Raw bounded capture and identity hashes only; no full registry parsing claim',
              original_failure=failed['error'], original_failure_reproduced=original_error,
              only_source_delta=changed, runner_sha256=sha((OUT / 'runner-reviewed.py').read_bytes()))
(OUT / 'native-audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'phases'}, indent=2))
print('Independent raw station/manifest/log/artifact/world-marker audit passed')
