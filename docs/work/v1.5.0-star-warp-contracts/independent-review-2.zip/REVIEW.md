# Independent contract re-review: ADR-044 revision 2 (station warp as logical relocation)

- Repository `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`,
  HEAD `7180885` (commits after `82568b8` touch docs and `BoundedSavedDataIo`/tests only).
- Reviewer: independent agent, not the author. Date 2026-09-30.
- Inputs: `docs/decisions/ADR-044-STATION-WARP-LOGICAL-RELOCATION.md` (rev. 2, PROPOSED), the
  archived rejection report (REVIEW.md of `arce-v150-contract-review-...`), ADR-040/041/043, the v1.5 plan,
  and the station, persistence/migration and rocket transfer/flight/admission code.
- Method: read-only. No repository file was modified, staged or committed; no Gradle, server or build
  was run; the untracked `AdvancedRocketry-Community-v1plus-Development-Docs/` was not read.
- Observation: at the end of the review the working tree held uncommitted STAR-slice changes by a
  concurrent implementer. They include `build.gradle`, celestial and datagen files, and `src/generated/v1.5/`.
  The reviewer did not create them. None of the station, rocket or persistence files cited here is
  modified, so every citation matches HEAD `7180885`.

**This is not a Gate approval.** It does not accept ADR-044 on the maintainer's behalf, does not mark
any WARP/UI/MIG leaf verified, and does not approve any v1.5 G0-G9 Gate, candidate or release.

---

## Verdict: ACCEPT WITH CHANGES (not implementable as written)

Revision 2 fixes the architecture that revision 1 got wrong:
- the orbit and the energy are now in **one file**, so any surviving copy of that file holds a
  consistent (orbit, balance) pair;
- stateless cores remove every core-identity hazard;
- the rocket rule is journal-only and fails closed.

No Critical or High finding remains. Five Medium findings still break a plan bar or leave a
correctness hole in the text an implementer would follow literally:
- N1: the half-published commit path;
- N2: the plan's §13 "SavedData not fully dirtied every tick" item;
- N3: a warp brick that has no remedy;
- N4: the tick budget;
- N5: the energy-credit authority.

All five can be fixed with local contract text; none needs a new architecture. Apply the required
changes below and record this re-review **before** any WARP-02 code.

### Required changes

1. **Specify the relocation commit at registry level (N1).**
   - Preconditions: the registry is operational and not quarantined, the live state equals the
     observed state, and the target is still valid. The live balance must cover the cost computed at
     commit, and that cost must equal the confirmed cost (see 7).
   - The candidate is the live registry with the replacement state substituted and the balance set to
     `live - cost`. An entry that reaches 0 is removed.
   - Candidate verification decodes the state, this station's balance and every other balance, and
     compares them with the expected values.
   - The publish applies the orbit and the debit in **one** synchronized model method, with no
     fallible step between them.
   - Add a predicate `isOrbitRelocationOf` that does not use `sameAuthorityAs`, which compares
     `orbitBody`. Give it negative tests for:
     - orbit plus region, orbit plus gravity/vacuum/angle, orbit plus owner/name/members/invitations;
     - the same orbit;
     - a balance delta that differs from the cost;
     - another station's balance changing.
   - The growth and gravity transitions must also prove that the balance list is unchanged.
2. **Stop per-tick dirtying (N2).**
   - Hold credits in a bounded, server-thread pending map (at most 4,096 entries, cleared at stop).
   - Fold the map into the registry at most once per fixed interval, before every warp request or
     commit check, and before the stop save. A credit never flushes.
   - State the resulting loss/duplication window.
   - Map plan §13 "多站点 SavedData 不每 tick 全量 dirty" to a test. Add a measurement of an ordinary
     save at 4,096 stations.
   - If continuous dirtying is kept instead, it needs measurements and an AGENTS §5 exemption.
3. **Do not block on settled PREPARED records (N3).** A PREPARED record that recovery has already
   returned to a stationary source (`WAITING_FOR_PASSENGERS`) must not block the warp.
   - Expose "in motion" through `StationRocketAuthority`.
   - Fail closed until the post-start recovery pass has classified every record.
   - Alternatively, add an audited operator release for such records.
   - Test: a restart during a crewed countdown whose passenger never returns.
4. **Bound commits and requests (N4).**
   - At most one warp commit per server tick. The others wait and are fully rechecked.
   - A per-station cooldown after a commit or a failed write, at least 100 ticks as in ADR-041.
   - Pending-confirmation caps: one per player plus a global cap, with expiry and clearing on
     logout and on stop.
   - A minimum cost above 0, or an explicit exemption. The ADR's own non-goal "warp without energy"
     and plan §4 forbid a cost of 0.
5. **Pin the credit authority (N5).**
   - Credit only when the core's Level is the fixed Space Level; any other Level accepts 0.
   - Credit only on the server thread; an off-thread call accepts 0.
   - `simulate=true` neither mutates nor consumes the per-tick allowance.
   - Define `getEnergyStored` and `getMaxEnergyStored`. Recommended: do not expose another station's
     balance to probes.
   - Test a core in the Overworld at a station's x/z.
6. **Make the migration concrete (N6).**
   - Give a per-schema acceptance table for STATIONS:

     | Root | Epoch | Accepted content |
     |---|---|---|
     | 1 | legacy | legacy records |
     | 2 | `v0.9.0-beta` | legacy records |
     | 3 | `v1.5.0-orbital-station` | record 2 only |
     | 4 | `v1.5.0-station-warp` | requires `warp_energy` |

   - Root-shape validation depends on the schema.
   - 3→4 only adds the list; 1/2→4 chains; the manifest records source and target per file.
   - Test with the STATION-04 native root-3 world.
   - Amend ADR-040's "current root 3" rule explicitly in the `amends` line.
   - Decide whether a zero entry is valid and make every mutation agree.
   - Budget the balance list inside the 4 MiB registry bound: refuse a credit that would add an entry
     beyond it.
   - Update the plan's `save_schema` line at acceptance.
7. **Bind consent (N7).**
   - Abort when the commit-time cost or cost class differs from the confirmed one (catalog reload,
     config reload, removed orbit body).
   - Recheck the actor's authority at commit, or state that de-opping does not cancel.
   - Warn at confirmation when the target system has no rocket routes back.
8. **Correct the text (N8-N11, N13).**
   - Fix the crash-cut matrix rows (N8).
   - Give an honest disclosure bound (N9).
   - Remove the "stale quote" rule or specify a protocol change (N10).
   - Restate the journal invariant (N11).
   - Stop saying that gravity "follows" the orbit (N13).
9. **Close the traceability and content gaps (N12).** The list is in N12.

---

## Resolution of the previous review

### Required changes 1-10 (ADR-044)

| # | Previous requirement | Status | Reason |
|---|---|---|---|
| 1 | Secure energy before or atomically with commit (H1) | **Resolved** | The debit and the orbit change are one checked write (§2). Matrix accuracy and publish atomicity remain as N8 and N1. |
| 2 | Bind cores to identities (H2) | **Resolved (superseded)** | Cores are stateless. No debt, sequence or core state exists to double-charge or free. Tests for the core cases are not mapped (N12). |
| 3 | Rewrite the rocket rule (H3) | **Resolved, with a new Medium** | Journal-only; fails closed; blocking phases PREPARED..SOURCE_REMOVED plus descending COMMITTED; landed reservations excluded; rechecked at commit; the transaction claim is corrected; a port is used. New: N3. The invariant wording is inaccurate (N11). |
| 4 | Complete schema/migration (M2) | **Partial** | Root 4, epoch, chain, bounds and a core BE schema are given. Missing: migrator mechanics, the relocation predicate and its tests, zero entries, the byte budget, and the plan `save_schema` line (N6, N1). |
| 5 | Entry point and state machine (M3) | **Partial** | Resolved: the command with a server ray-pick, target validation, one countdown per station, the global cap of 64, stop cleanup, STALE semantics, the confirmation and member notices. Missing: cooldown, per-tick budget, confirmation caps, cost consent (N4, N7). |
| 6 | Warp from an unavailable orbit body (M4) | **Resolved** | Evacuation to any valid target at interstellar cost. |
| 7 | Plan traceability, kill switch, ORBIT-03 (M5) | **Partial** | The kill switch, the ORBIT-03 reference and the table exist. §13.3 is missing and violated (N2); other items are unmapped (N12). |
| 8 | Disclose shared-Space adjacency (M6) | **Resolved** | §1 disclosure; the "free interstellar trip" rationale is removed. |
| 9 | Module direction (M7) | **Resolved (contract)** | `StationRocketAuthority` port; the existing cycle is recorded as debt. |
| 10 | `amends`, currentBody normalization, cost bounds, diagnostics | **Mostly** | Resolved: `amends`, L1 normalization, balance in `admin inspect`. Still open: the ADR-040 root-3 amendment (N6), and a lower cost bound of 0 is still allowed (N4). |

### Findings H1-H3, M1-M7, L1-L6 (and the cross-ADR L10)

| Finding | Status | Reason |
|---|---|---|
| H1 free warps / energy after commit | **Resolved** | One write; no debt; no settlement. |
| H2 core identity | **Resolved** | Stateless terminal; loot drops no BE data; a reused cell starts at 0. |
| H3 rocket rule | **Resolved (new N3)** | See required change 3 above. |
| M1 crash-cut matrix | **Partial** | New matrix, but two rows are inaccurate and two are missing (N8). Half-publication is unaddressed (N1). |
| M2 schema/migration | **Partial** | N6, N1. |
| M3 entry point/lifecycle | **Partial** | N4, N7. |
| M4 unavailable orbit body | **Resolved** | |
| M5 plan items | **Partial** | N2, N12. |
| M6 shared-Space porosity | **Resolved** | Disclosed. |
| M7 bidirectional dependency | **Resolved** | Port. |
| L1 stale currentBody | **Resolved** | New records only; checksums are untouched. Feasible: `planSourceMatches` returns true for Station targets. |
| L2 cost bounds | **Partial** | The commit-time recompute is specified. The lower bound 0 contradicts "no zero-cost teleport" and the ADR's non-goals (N4). |
| L3 deletion fail-open | **Resolved (contract)** | Fixed in the same slice; fails closed. |
| L4 header metadata | **Resolved** | ADR-040 root-3 wording remains (N6). |
| L5 diagnostics | **Resolved** | The balance is in the registry, and `admin inspect` exists. |
| L6 warp-core content | **Partial** | Loot and the FakePlayer case are resolved (the command path excludes FakePlayers). Recipe and progression gate are unspecified. Rev. 1's "original content, no imported art" provenance line was dropped (N12). |
| L10 warp-target consistency | **Resolved** | ADR-043 now defers to ADR-044. |

---

## New findings

There are no Critical or High findings.

### N1 (Medium): the relocation cannot be validated by the existing guard, and publish atomicity is unspecified

- **Contract claim.** "The same guard rejects any other change before writing."
- **Code.**
  - `StationRegistrySavedData.checkedReplace(file, observed, replacement, committer)` and
    `StationState.isCheckedUpdateOf` see only `StationState`. `requireValidCandidate` checks only that
    the replacement station decodes. A balance kept in the registry root is invisible to all of them.
  - The publish step (`registry.replaceChecked`) can throw. The catch sets `updatesQuarantined = true`
    and `setDirty()`, so the next ordinary save persists **whatever memory holds**.
- **Scenario.** An implementer debits the balance map and then calls `replaceChecked`.
  - If `replaceChecked` throws, memory holds the debited balance and the old orbit. The ordinary save
    overwrites the committed candidate: energy is destroyed and the warp is undone.
  - With the opposite order, the result is a persisted **free warp**.
- **Why it matters.** "Exactly once" holds only if the two in-memory publications are one atomic step.
  `sameAuthorityAs` compares `orbitBody`, so the new transition needs its own predicate.
- **Fix.** Required change 1.

### N2 (Medium): charging keeps the whole registry dirty (plan §13 violation, cost and exposure)

- **Contract.** "Crediting is an ordinary in-memory registry mutation (dirty, saved by ordinary saves)"
  at up to 200,000 FE per tick.
- **Code.**
  - `StationRegistrySavedData.flush` and `RocketTransferSavedData.flush` both call
    `server.overworld().getDataStorage().save()`, which rewrites **every** dirty SavedData.
  - The station registry uses vanilla non-atomic `SavedData.save(File)`. `AtomicSavedData` covers only
    the celestial and satellite authorities.
- **Scenario.** While any core charges, the registry is always dirty. Every autosave, and every ARCE
  flush, rewrites the full registry synchronously on the server thread.
  - ARCE flushes include each rocket-journal phase (about 6 per flight), membership changes and
    reservations.
  - At 4,096 stations that is 1,592,342 raw bytes per write
    (`docs/work/v1.5.0-station-capacity/VERIFICATION.md`).
  - Previously the file was rewritten only on rare player actions.
- **Consequences.**
  - A direct conflict with plan §13 "多站点 SavedData 不每 tick 全量 dirty".
  - A new, unmeasured per-flush cost.
  - A much higher rate of non-atomic writes of the one file that holds every station, where a torn
    write makes the next pre-start migration refuse the world.
- **Fix.** Required change 2.

### N3 (Medium): retained `WAITING_FOR_PASSENGERS` PREPARED records block warp indefinitely

- **Code.** `RocketTransferRecoveryService.recover` handles a PREPARED record with KEEP_SOURCE or
  REBUILD_SOURCE:
  - it returns the rocket to a stationary state;
  - `settleRecoveredSource` then **keeps the PREPARED record** until every recorded passenger is
    online;
  - at startup recovery runs before anyone can log in.
  - `prepareLaunch` then refuses to relaunch that rocket (REQUEST_REPLAYED, because only a COMMITTED
    landed authority can be replaced);
  - `/arce rocket recover` only re-runs the same wait.
- **Scenario.**
  1. A member of station A (VISIT on A) launches a crewed rocket from A, or from anywhere to A, with an
     alt account aboard.
  2. The server restarts inside the 160-tick PREPARED window (60 countdown + 80 ascent + 20 transit),
     for example at an announced nightly restart.
  3. The alt never returns.
- **Result.**
  - A's warp is denied forever by rule 2.
  - Removing the member does not help, and no operator command releases the record.
  - Deletion is equally blocked (pre-existing), but warp is the new victim.
- **Safety of the fix.** The rocket is already stationary and cannot relaunch with the old-priced plan,
  so excluding settled PREPARED records is safe.
- **Fix.** Required change 3.

### N4 (Medium): no per-tick commit budget or cooldown, and a zero cost is allowed

- **Cost of one commit.** A full checked write: 172.4 ms median at 4,096 stations (ORBIT-04). That is
  already above one tick, though under the 500 ms spike budget.
- **Concurrency.** Up to 64 countdowns may be armed. Nothing stops them from committing in the same
  tick: 64 × 172 ms ≈ 11 s, which is far outside docs/17.
- **Repetition.** There is no cooldown after a commit or a failed write, and request/cancel cycles
  broadcast countdown notices to members without limit.
- **Zero cost.** The cost bound "0..10,000,000" permits a configured free warp. This contradicts plan
  §4 and the ADR's own non-goal "warp without … energy".
- **Plan.** §13 "跃迁准备分 tick 并有上限" is mapped to tests, but the ADR sets no limit to test.
- **Fix.** Required change 4.

### N5 (Medium): the energy-credit authority lacks a Level check

- **Contract.** `receiveEnergy` credits "the station whose committed region contains the core, looked
  up with one indexed `findAt`".
- **Code.** `StationRegistrySavedData.findAt(int x, int z)` takes no Level.
- **Scenario.** Implemented literally, a core in the Overworld at (100, 64, 100), for example near
  spawn, credits the station at cell (0,0), whose Space region covers x/z −256..255.
  - A player "charging their station" from an Overworld base silently funds whichever stranger's
    station shares those coordinates.
  - An owner can also charge without placing anything in the station.
- **Thread and simulate semantics.**
  - Off-thread callers are unspecified. The per-tick map is not thread-safe, and the publish in N1
    must apply a delta, not overwrite.
  - Calls with `simulate=true` are unspecified.
- **Other exploit checks: clean.**
  - Boundary cores: the core's own position decides.
  - Pistons: vanilla cannot move block entities; mod movers carry no state.
  - Chunk unload: the capability is gone.
  - Energy pushed from outside the region: at worst a gift.
  - Deleted station, gap, blocked registry, full balance: all accept 0.
- **Fix.** Required change 5.

### N6 (Low): the migration mechanics are under-specified against the current migrator

- `SavedDataSchemaMigrator.migrate` accepts only schema 1, 2 and `type.currentSchemaVersion()`. For
  schema 2 and above, it requires the single `type.formatEpoch()` (except for 2).
  `validateRootShape` applies one tag list to every schema.
- Raising STATIONS to 4 therefore makes root 3 an `INVALID_SCHEMA` refusal unless an explicit
  per-schema chain and epoch table is added. "Through the existing pre-start backup migration" is not
  literally true.
- The balance list is not reconciled with the 4 MiB registry bound. A credit that creates an entry can
  push the encoding over it. `encode` then throws inside vanilla `SavedData.save`, outside its
  IOException catch, and the save fails.
- "One entry per station with a non-zero balance" leaves open whether a zero entry blocks the registry.
  A debit to exactly 0 must agree with the loader.
- The `amends` line cites only "warp fields", while ADR-040's "current root 3 accepts only record 2" is
  also superseded.

### N7 (Low): consent and recheck gaps in the countdown

- The confirmation is bound to the station state and the target, not to the cost. A catalog reload
  (re-parenting, ADR-043), a config reload or the removal of the current body during the ~20 s window
  can raise the charge from 2,000,000 to 8,000,000 FE without new consent.
- The actor's authority is not rechecked at commit (an operator de-opped mid-countdown).
- Pending warp confirmations have no stated per-player or global cap, and no logout cleanup. "Like
  expansion" is implied only.
- The consequence text does not warn that the example target system has no routes. Members elsewhere
  cannot fly back to the station by rocket (previous I2).

### N8 (Low): crash-cut matrix rows are inaccurate or missing

- "During replacement (caught failure) → no warp" is inaccurate. `resolveReplacement` returns
  COMMITTED when the file equals the candidate (`REPLACED_DESPITE_ERROR`).
- "Outcome unreadable → no warp, no charge" holds only after an ordinary save reasserts memory. A crash
  before that save restarts with the warp and the debit. That outcome is still consistent, but it must
  be listed.
- Missing row: publish failure after replacement (quarantine plus re-save; see N1).
- Missing row: a torn ordinary save, which leaves an unreadable registry and a refused start
  (pre-existing class, more frequent under N2).

### N9 (Low): the cross-store disclosure bound is not meaningful

- "200,000 FE per tick times the autosave interval" is 1.2×10⁹ FE at the default of 6,000 ticks. The
  real bound is min(10,000,000 FE balance cap, 200,000 × ticks since the older of the two saves), per
  station per crash. That is more than one interstellar warp.
- The two stores are saved on unrelated schedules. The registry is written by every ARCE flush;
  source chunks are written by autosave or unload. Duplication is therefore the likelier direction, so
  "the usual class" understates it.
- Restoring the pre-upgrade backup (rollback) discards all balances. Disclose this.
- The class itself is acceptable once stated honestly. N2's folding interval changes the window, so
  state it after that decision.

### N10 (Low): the "stale quote" rule is vacuous as written

- `RocketFlightService.launch` recomputes the plan in the same server operation as `prepareLaunch`.
  `RocketTargetFlightPlanner.resolve(Station)` already takes the source body from the live station
  record. The C2S request carries only the target and the request ID, never a quote.
- `RocketFlightPlan` has no "source anchor" field (it has `sourceBody`). No plan exists at admission,
  and any retained plan is replaced at launch.
- Nothing can force the player to "re-quote". A menu opened before the warp shows stale quotes; the
  launch simply charges the recomputed fuel (as after catalog reloads today).
- The admission change itself is feasible: remove the `flight.currentBody()` filter in
  `PlanetaryFlightAdmission.allows`, lines 48-52. The kept checks exist.
- **Fix.** Replace the sentence with the true behavior, or specify a bounded, versioned quote-binding
  protocol change.

### N11 (Low): the journal invariant is false under crash cuts

- "Every flight from countdown through descent has a journal record" holds in memory only.
- `failBackToSource` and `settleRecoveredSource` update the entity and then remove and flush the
  record. A crash before the entity's chunk saves reloads an in-motion entity with no record.
- Such an orphan is never ticked or recovered, so it cannot fly the old-priced plan. It is **not** a
  warp hazard, but the invariant should read "every flight that can progress is driven by a journal
  record", and the orphan should be disclosed as pre-existing.
- Feasibility of the rule is otherwise confirmed:
  - `phase()`, source and destination snapshots, `RocketRegion`, `operational()`;
  - `destinationFlightData().stateStartedGameTime()` equals the scheduled arrival (countdown start
    + 160); landing occurs once 80 ticks have elapsed from it;
  - landed reservations are COMMITTED records whose time has passed.
- A late landing after a restart past the time bound is benign: the rocket is inbound, and warp moves
  it with the station like any docked rocket.

### N12 (Low): traceability and content gaps

Unmapped plan items:
- §9 v1.4/root-3 fixture migration;
- §11.2 countdown/failure feedback, §11.3 no data mixing between stations, §11.5 GUI scale (N/A if no
  screen);
- §12.5 (N/A);
- §13.3 (N2);
- §14.5 lossless upgrade to root 4;
- §15 migration report and multiplayer permission report;
- §8 "upgrade during warp" (trivially met because countdowns are memory-only; say so).

Revision 1's native restart evidence was dropped: restart after commit, 3→4 on the STATION-04 world,
second restart.

Also unspecified:
- tests for the stateless-core cases (two cores, gap, foreign station, carried core, cell reuse,
  deletion discarding the balance);
- the recipe and progression gate;
- asset provenance, since revision 1's "original content, no imported art" line is gone (AGENTS 3.2);
- the generated-asset directory;
- the config type. The mod has only a COMMON config; "server config" implies a new, integrator-owned
  registration.

### N13 (Low): "gravity follows" is inaccurate

§1 says environment, **gravity**, routes, quotes and discovery follow the warp. Station gravity is the
stored, owner-set `gravity_milli` (ADR-041), and a warp does not change it. Only the body context,
solar intensity, routes, quotes and discovery checks follow.

### Info

- I1: §1 says no block is "queried", but the §3 ray-pick reads one block in a loaded chunk. Reword.
- I2: the countdown commit runs from a tick handler. `checkedReplace` throws
  IllegalArgumentException for a disallowed transition, so the handler must contain it and report an
  abort.
- I3: when `StationRocketAuthority` is not wired, warp must deny, as with a non-operational journal.
- I4: gaps next to a Tau Ceti station still resolve to Sol's shared Space body (previous I3,
  unaddressed; harmless).
- I5: one OUTCOME_UNKNOWN on any station quarantines all checked writes (warps included) until
  restart. This is fail-closed and inherited from ADR-041; mention it in the abort reasons.

---

## Residual risks (after the required changes)

- Energy can be duplicated or lost across the registry and the source chunks, up to the balance cap
  per station per crash. This is the disclosed class.
- The station registry's ordinary saves remain vanilla non-atomic writes (ADR-040 residual).
  Durability claims stay limited to same-directory atomic replacement: no directory fsync, no
  power-loss claim.
- Pre-existing rocket liveness issues are outside this ADR:
  - orphaned in-motion entities after crash windows;
  - `WAITING_FOR_PASSENGERS` records that block relaunch and deletion.
- The station↔rocket import cycle and shared-Space physical porosity remain accepted limitations.
- This is a contract review only. No code was run, and no WARP runtime exists yet.

## Statement

This review is independent evidence for the maintainer. It is **not** a Gate approval, it does not
accept or reject ADR-044 on the maintainer's behalf, and it changes no leaf, version or release status.
