import sys, re, pathlib
root = pathlib.Path('src-2fb9bce/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station')
M = {
 'A_no_prewrite_check': (root/'persistence/StationRegistrySavedData.java',
   'if (!replacement.isCheckedUpdateOf(observed)) {', 'if (false && !replacement.isCheckedUpdateOf(observed)) {'),
 'B_old_checked_semantics': (root/'model/StationState.java',
   '        boolean growth = !previous.expanded()', '        if (true) return true;\n        boolean growth = !previous.expanded()'),
 'C_cooldown_always_ready': (root/'service/StationWriteCooldown.java',
   '        return previous == null ||', '        return true || previous == null ||'),
 'D_no_eviction': (root/'service/StationWriteCooldown.java',
   '            entries.remove();', '            break;'),
 'E_resolveAt_no_level_check': (root/'orbit/StationOrbitEnvironmentResolver.java',
   '        Objects.requireNonNull(registry, "registry");\n        if (!CelestialIds.SPACE_LEVEL.equals(level)) {',
   '        Objects.requireNonNull(registry, "registry");\n        if (false && !CelestialIds.SPACE_LEVEL.equals(level)) {'),
}
name, action = sys.argv[1], sys.argv[2]
f, old, new = M[name]
t = f.read_text(encoding='utf-8')
bak = f.with_suffix('.java.orig')
if action == 'apply':
    t2 = t.replace('\r\n', '\n')
    assert t2.count(old) == 1, (name, t2.count(old))
    bak.write_text(t, encoding='utf-8', newline='')
    f.write_text(t2.replace(old, new), encoding='utf-8', newline='')
else:
    f.write_text(bak.read_text(encoding='utf-8'), encoding='utf-8', newline='')
    bak.unlink()
print(name, action, 'ok')
