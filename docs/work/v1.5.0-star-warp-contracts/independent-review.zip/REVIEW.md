# Independent contract review: ADR-043, ADR-044 (PROPOSED) and fix confirmation `2fb9bce`

- Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`,
  HEAD `82568b85f5b5f088fad6a6488bebe00043204b18`. `git diff --stat 2fb9bce 82568b8` touches only
  docs (the two ADRs, DOCUMENT-INDEX, implementation log), so HEAD code equals `2fb9bce` code.
- Reviewer: independent agent, not the implementer. Date: 2026-09-30.
- Scope:
  - **Part A.** Contract review of `docs/decisions/ADR-043-STAR-SYSTEMS-AS-ROOT-TREES.md` and
    `docs/decisions/ADR-044-STATION-WARP-LOGICAL-RELOCATION.md` against the v1.5 plan, AGENTS.md
    sections 3 and 5, ADR-028/031/037/038/040/041/042, and the current code.
  - **Part B.** Confirmation of `git diff 442e4a7 2fb9bce` (fix for the earlier ORBIT review M1-M3, L1-L6).
- Nothing in the repository was modified, staged or committed. Gradle ran only in a `git archive`
  export of `2fb9bce` under this output folder; the export and all build output were deleted.
  Kept evidence is in `evidence/` (logs, JUnit XML, mutation script and results).
- Observation: during the review an untracked file appeared in the repository,
  `src/test/java/.../station/persistence/StationCheckedUpdateScaleTest.java` (mtime 09:13:59 local).
  The reviewer did not create or read it; it presumably belongs to a concurrent implementer task.

**This is not a Gate approval.** It does not accept either ADR on the maintainer's behalf, does not
mark any STAR/WARP/ORBIT leaf verified, and does not approve any v1.5 G0-G9 Gate, candidate or release.

---

## Verdicts

### ADR-043 (star systems as root trees): ACCEPT WITH CHANGES

The core idea is sound and cheap: a system is the tree under a root; no new schema, codec or persisted
ID; the fixed Earth/Moon/Space baseline is untouched. Feasibility checks passed: `CelestialCatalog.create`
already accepts several roots and root orbits must have distance 0 (`CelestialBodyDefinition:50`);
`StarMapLayout` already lays out each root as its own row; `CelestialSnapshotCodec` validates parents and
cycles with no single-root assumption; the cross-system route check can run in `PlanetaryCatalog.create`,
which already holds both candidate sets, so reload atomicity is preserved; player station creation only
uses bodies with a surface Level, so nobody can create a Tau Ceti station without warp or an operator.

Required changes:

1. Align the warp-target sentence with ADR-044: ADR-043 says warp may target "a known body **in another
   system**", ADR-044 allows same-system relocation. Pick one (L10).
2. State the compatibility impact of the two new validations (16 roots, cross-system routes): a pack that
   is valid today is rejected as a whole, and on initial load the server refuses to start
   (`PlanetaryDefinitionReloadListener.apply` throws without a valid pair). Give the diagnostic and
   operator remediation, and add a test for the initial-load refusal (M8).
3. State that system membership is derived per reload, never persisted: re-parenting a body in a pack
   moves existing stations between systems without warp and can change a warp's cost class during its
   countdown; the warp commit must recompute cost from the commit-time catalog pair (L9).
4. Specify packaging for the superseded satellite definition: `build.gradle` currently excludes only the
   v0.8 copy of `satellite_definitions/data_satellite.json`; a v1.5 copy also needs the v1.4 copy excluded
   in `processResources` and `sourcesJar`, the DataGen `--existing` list updated, and the "one authoritative
   copy per resource ID" audit (ADR-031/037). These are integrator-owned files (L7).
5. Say that the star's physical facts cannot be represented literally (temperature bound 2,000 K, gravity
   bound 4.0) and name the placeholder values. Either drop `discovery_required` on the star (it is not a
   satellite target, so it can never be discovered and stays "locked" on the map) or define its display
   through system knowledge (L8).
6. Cross-reference ADR-044 for a station whose orbit body disappears (rollback of the example data): the
   ADR-043 rollback text calls it "retained, not remapped", but nothing lets its owner leave (M4).

### ADR-044 (station warp as logical relocation): REJECT as written (revise and resubmit)

Keep the architecture: logical relocation of a fixed region is the right, bounded choice. It is allowed
by plan section 17, it removes the unbounded copy, and passengers need no movement. What must be
redesigned is the energy authority and the rocket rule. Three High findings break the plan's own
acceptance bars ("no zero-cost teleport", "energy conservation", "no loss or duplication in every stage",
"zero Critical/High"): free warps are a designed-in path (H1); the exactly-once claim fails on core
identity, allowing double charges, free warps and warp bricks (H2); and the rocket rule contradicts
"docked rockets follow" and can block a station forever (H3).

Required changes:

1. **Secure energy before or atomically with the orbit commit (H1).** Remove "commit now, pay on a later
   core tick" and the free `settle`. Choose one of the options in H1 and give its complete crash-cut
   matrix in the ADR.
2. **Bind cores to identities (H2).** Persist a core UUID in the block entity (never on the dropped item)
   and bind it to a station UUID. The debt, if any remains, names that core UUID and station UUID.
   Only that core pays, and `paid_sequence` counts only for its bound station. Define loot (no BE data on
   drop), placing a core in another station or a gap, cell reuse after deletion, and two cores in one
   region.
3. **Rewrite the rocket rule precisely (H3).** Derive it only from the transfer journal, in memory, with
   no entity query, and fail closed when `RocketTransferSavedData.operational()` is false. Name the
   phases that block: PREPARED through SOURCE_REMOVED, plus COMMITTED records that have not landed,
   decided without loading chunks. State that retained landed reservations (COMMITTED and landed, with
   either snapshot overlapping) do **not** block. Correct the "transaction" claim, and recheck in the
   same server-thread operation as the checked write.
4. **Specify schema 3 and the migration completely (M2).** Choose between a root bump (3 to 4 with a new
   epoch) and an explicit nested record-2-to-3 migration under root 3, because ADR-040 says "current
   root 3 accepts only record 2". Add the missing `settled` field, or remove settlement. Give the field
   invariants and bounds and the legacy 1-to-3 chain, update the plan's `save_schema` line, and give the
   warp-core block entity its own schema version.
5. **Specify the entry point and the state machine (M3).** Say how the target is chosen: a block use
   cannot carry one, so name the command or stored selection and how it is validated. Define "no
   outstanding debt", since debts are never cleared. Allow one countdown per station, with a global cap,
   expiry and cleanup on stop, logout or station change. Say what rechecks at commit abort the warp,
   including STALE after any unrelated station change, and require a consequence confirmation like
   expansion's.
6. **Define warp from an unavailable orbit body (M4)**, including its cost class and whether it is allowed
   as an evacuation, so that stations whose body was removed are not stranded.
7. **Close plan traceability (M5).** Add an independent warp disable switch (plan section 17). Reference
   ORBIT-03 for the sky after a warp. Map every plan section 9-15 item to a test or a later leaf,
   including two stations warping at once, owner disconnect and reconnect, catalog reload during the
   countdown, forged or non-member requests, 10/100-station performance, V1/V2 and the video.
8. **Disclose shared-Space adjacency (M6).** Systems are labels over one shared Space Level. Players,
   blocks and disassembled rockets can cross the gap of at least 256 blocks between cells of different
   systems. Correct the "free interstellar trip" rationale (the rule is needed for outbound PREPARED
   records, see H3).
9. **Keep module direction clean (M7).** The warp code must reach rocket state only through a port
   interface wired at startup (the ADR-041 pattern), with no new station-to-rocket or rocket-to-station
   imports. The existing cycle (`StationManager` imports rocket classes; ten rocket classes import station
   classes) should be recorded.
10. Add `amends: ADR-040, ADR-041` to the header; normalize `currentBody` in **new** flight/transfer
    records after warp (L1); give the cost table's bounds (L2); document the diagnostic limits (L5).

---

## Findings (by severity)

There are no Critical findings. Findings H1-H3, M1-M7 and L1-L6 concern ADR-044; M8 and L7-L10 concern ADR-043.

### H1 (ADR-044): free warps are a designed-in path; energy is not locked before commit

**Contract text.** Commit writes `orbit_body`, `warp_sequence = k` and a debt. Only later, "when loaded and
ticking", does the core deduct energy. If the core is destroyed with `paid_sequence < k`, an operator
settles the debt, which "costs nothing further".

**Failure scenarios.**
1. *Break before the first core tick.* The owner's countdown commits. Before the core's next block-entity
   tick, the core is removed: by instant mining (Efficiency V plus Haste II, or creative), by a timed
   explosion, a command or an automation mod. The station has warped and no energy was taken. An
   operator `settle` finishes the free warp. In single-player with cheats, the player is that operator.
2. *No operator.* The same station can never warp again: a new warp needs a loaded core at `core_pos`
   with `paid_sequence == k`. The station is bricked for warp.
3. *One-way free trip.* Even without settlement, the warp to the target already happened for free. A
   one-way relocation needs no second warp.

**Conflicts.** Plan section 4 ("不允许无成本即时传送", no zero-cost instant teleport), section 6 step 6
("能源锁定", lock the energy before the commit) and section 14 ("权限和能源守恒", permissions and energy
conservation). The countdown does not lock anything. The core is input-only, so its energy cannot
fall during the countdown, but payment is deferred past the commit.

**Required fix (choose one; each needs a full crash-cut matrix in the ADR).**
- **A (recommended): station-held warp charge.** Add a bounded `warp_charge` to the schema-3 station
  record. The core moves its FE into it by rate-limited checked writes, using a credit-first,
  sequence-keyed protocol: the record stores the last `{core_id, credit_sequence, amount}`, and on load
  the core removes an already credited amount from its buffer. The warp is then **one** checked write
  that debits `warp_charge` and changes `orbit_body` together. It is exactly-once by construction. It
  needs no debt, no settlement and no `core_pos` binding, and destroying a core never frees or doubles
  a charge. Residual to disclose: a chunk rollback can re-create at most one credit batch of input energy
  (the same class as any machine rollback). Bound the batch size.
- **B: synchronous debit plus durable escrow.** At commit, on the server thread: debit the core and
  record `escrow{station, k}` in the block entity, force a durable save of that single chunk, then do the
  checked station write. On load, refund the escrow if the station sequence is below k, and finalize it
  otherwise. This needs a bounded single-chunk save API (Access Transformer or reflection, with ADR
  justification).
- **C (weakest acceptable): keep the debt, but debit the core in memory in the same server-thread
  operation that publishes the commit.** This closes the tick window. Carry an orphaned debt forward
  (core missing, replaced or underfunded) so it must be paid before any further warp. Never forgive it
  by default. An operator "forgive" must be a separately audited, explicitly free administrative action
  outside the gameplay contract. Disclose the remaining crash-only windows (see M1).

### H2 (ADR-044): exactly-once fails on core identity (double charge, free warp and brick)

**Contract text.** The core stores `paid_sequence` and pays "if the station's debt sequence k is above
`paid_sequence`". The payment rule never says the paying core must be the one at `core_pos`. Nothing binds
`paid_sequence` to a station or to a core instance.

**Failure scenarios.**
1. **Two cores in one region.** Both see `k > paid_sequence` and both deduct: a **double charge**. The
   first-warp race between two countdowns is also undefined.
2. **Core replaced after payment.** A core pays k and is later broken. A fresh core is placed at the same
   `core_pos` with a default `paid_sequence` of 0 and pays k **again**. If the fresh core is placed
   elsewhere instead, every new warp is refused because it must start from `core_pos` with `paid == k`:
   a **brick** until an operator acts. The ADR defines `settle` only for `paid_sequence < k`, so even that
   path is unclear.
3. **Core carried to another station.** This happens if the item keeps block-entity data, which is
   common for energy blocks and is not specified. It also happens with **cell reuse** after deletion,
   because deleting a station removes only the platform template and leaves other blocks. A core with
   `paid_sequence = 50` sits in a new station whose first debt is 1. Since 1 is not above 50, it never
   deducts: a **free warp**. After that, `paid == k` can never hold: a **brick**.
4. **Operator restores a pre-warp station backup** (ADR-040 restoration) while chunks keep a paid core. The
   reused sequence k is treated as paid: a free warp (edge case).

**Required fix.**
- Give each core a UUID, persisted only in the block entity and never copied to the item.
- Bind the core to one station UUID on first use.
- The debt, or the credit records in option A, names the core UUID.
- Only that core instance pays, and `paid_sequence` counts only for its bound station.
- Specify loot (drop with no block-entity data, or energy only), cores in a gap, cores in a foreign
  station, cell reuse and multiple cores.
- Add unit and GameTest cases for each of these.

### H3 (ADR-044): the rocket rule contradicts "docked rockets follow", can block a station forever, and adopts a fail-open, scanning guard

**Contract text.** "Pending or in-flight rockets block warp. This covers any transfer or transaction whose
source or destination snapshot overlaps the region (**the existing deletion guard**)." It also says "No
block, chunk or entity is ... scanned" and "Docked rockets ... move with the station."

**What the existing guard actually does.** `StationManager.hasRocketAuthority`, lines 216-244:
1. `space.getEntitiesOfClass(RocketEntity.class, <whole 512/768 region, full height>)` returns true if
   **any loaded rocket** is in the region. Every loaded docked rocket therefore blocks warp. This is also
   an entity scan over up to 48x48 chunk columns, which the ADR says it never does.
2. It returns true for **every** `RocketTransferSavedData` entry whose source or destination snapshot
   overlaps the region. COMMITTED records are **retained after landing** as "landed reservations"
   (`RocketTransferService.cleanupLandedIfComplete` logs `landed_reservation_retained`). They are
   removed only when that rocket launches again (`prepareLaunch` replaces `previous`) or is disassembled
   (`releaseLandedReservation`).
3. It checks no rocket *transaction* (assembly or disassembly) store at all. The ADR's "transaction"
   claim is inaccurate. Assembly derives `currentTarget` from position when it completes, so transactions
   do not need to block.
4. It is **fail-open**: when the transfer journal is blocked (future or malformed file),
   `RocketTransferSavedData.load` clears `entries`, so `entries()` is empty and the guard passes.

**Failure scenarios.**
- Applied literally, any rocket that has landed at station A and not relaunched blocks A's warp forever.
  So does any rocket that departed from A and landed elsewhere (its source snapshot overlaps A), and any
  loaded docked rocket. "Docked rockets follow" becomes impossible.
- A member or ex-member who parks a rocket at A (or flew from A to Earth and left it there, possibly in
  an unloaded chunk) keeps the owner from ever warping. The owner cannot disassemble another player's
  rocket, so this is a brick and a griefing vector.
- A blocked transfer journal lets the warp commit while inbound or outbound authority is unknown.

**What the rule must actually prevent.** Inbound rockets are harmless under logical relocation: they
arrive where docked rockets end up anyway. The ADR's "free interstellar trip by warping while a rocket
is inbound" is not the real hazard. The real hazard is **outbound**. A PREPARED record from A was priced
for A's old orbit (for example, Earth orbit to the Earth surface). If A warps during that countdown, the
rocket departs from Tau Ceti at an intra-system price.

**Required fix.**
- Blocking set: transfer-journal records overlapping the region with phase in {PREPARED,
  DESTINATION_SPAWNED, PASSENGERS_TRANSFERRED, SOURCE_REMOVED}.
- Also block on COMMITTED records until landing completes. Decide landing without loading chunks, for
  example from the record's scheduled arrival plus `DESCENT_TICKS` against game time, or from an explicit
  journal marker.
- Retained landed reservations do not block.
- No entity query. Deny the warp when the journal is not operational.
- State the invariant "every in-motion flight state (COUNTDOWN through DESCENT) has a journal record".
  It holds today because `prepareLaunch` writes the record before updating the entity. Test it, including
  migrated legacy flights.
- The pre-existing fail-open in station **deletion** should be fixed separately (see L3).

**Admission change: the exploit analysis is otherwise clean.** Making position the authority for a
`TravelTarget.Station` source is safe **provided** these existing checks stay:
- `flight.currentTarget() == Station(A)`;
- `findAt(rocket position).stationId == A`;
- the live Level equals `currentDimension`, and the snapshot's source dimension matches.

With those checks:
- A rocket that is piston-pushed, teleported with `/tp`, or moved into another station or a gap keeps
  its old `currentTarget` and is refused.
- After deletion and cell reuse, the station UUID differs, so the rocket is refused.
- Assembly and arrival are the only ways `currentTarget` is set.
- Transfer recovery (`RocketTransferRecoveryService`) never revalidates the station's orbit, so a warp
  cannot corrupt a transfer that is being recovered.
- The source body must come from the station record and the captured catalog, never from the client.

### M1 (ADR-044): the crash-cut matrix is incomplete (orphaned and underfunded cores after rollback)

| Cut | Result under ADR-044 as written |
|---|---|
| Crash during countdown | No change, no cost. OK. |
| Crash in the checked write before replace (`WRITE_FAILED`) | Old file. No warp. OK. |
| `OUTCOME_UNKNOWN` (quarantine) | Not published, so the core does not pay. Ordinary saves then re-assert the pre-warp registry. OK. |
| Station file durable, core chunk not yet saved (before or after the in-memory payment) | On reload the core pays k again. Once in persisted terms. OK, **provided** the persisted core exists at `core_pos` and holds at least the cost. |
| Same, but the persisted chunk predates the core's placement | No core. Orphaned debt, then a free warp through `settle` or a brick. **Not handled.** |
| Same, but the persisted core energy is below the cost (charged after the last chunk save) | Deduction is unspecified: clamp gives a partial free warp, a negative balance is invalid, waiting is acceptable. **Must specify.** |
| Chunk unloaded while the debt is pending | Pending until loaded; new warps refused. No brick. OK. |
| Core destroyed, replaced, carried or doubled | See H1 and H2. |
| Operator restores the station backup only | See H2 item 4. |

This matrix, with every row resolved, must appear in the revised ADR and in MIG-01.

### M2 (ADR-044): schema 3 and the migration are under-specified

- ADR-040 fixes "Current root 3 accepts only record 2 / reservation 1". A root-3 file with record-2
  entries would be CURRENT at the root level, but `StationState` requires `STATE_SCHEMA_VERSION`
  (then 3), so the registry would decode as **blocked**. Development worlds already at root 3 (the
  STATION-04 native worlds) must migrate.
  - Choose (a) a root bump to 4 with a new epoch and per-file manifest entries, or (b) nested record
    detection under root 3 that counts as a real migration with backup (ADR-040: "a nested record upgrade
    must count as a real migration").
  - Define the chain from legacy record 1.
  - Keep repeated startup idempotent.
  - Update the plan's `save_schema` line.
- `warp_debt` is `{sequence, energy, core_pos}`, but settlement "marks sequence k settled", and there is
  no `settled` field.
- Give the invariants and bounds and test them:
  - `debt.sequence == warp_sequence`;
  - `sequence >= 0`, with overflow refused;
  - `energy` in 0..maximum cost;
  - `core_pos` inside the committed region and the build height;
  - record size stays within 8 KiB.
- The warp-core block entity needs its own schema version for energy, identity, `paid_sequence` and
  escrow (AGENTS 3.3: persisted objects need independent schema versions).
- ADR-041's `isCheckedUpdateOf` uses `sameAuthorityAs`, which includes `orbitBody`. The new "orbit
  relocation" transition must be a separate, exhaustively tested predicate, with negative tests: orbit
  plus region, orbit plus gravity, orbit plus team, the same orbit, and a sequence not equal to +1.

### M3 (ADR-044): the entry point and the countdown lifecycle are unspecified

- **Target selection.** "The player starts a warp by using the core", but a block use carries no target,
  and UI-01 (a screen) is out of scope. Specify the channel: for example
  `/arce station warp <body>` under the local-actor rule while within reach of a loaded core, or a
  selection stored on the core. Also specify its validation: catalog present, orbitable, known, not the
  current orbit, and a string bound of 128. This is the plan section 12 "forged target ID" surface.
- **"Absence of debt"** is rechecked at commit, but "the station never clears the debt". Define it: the
  bound core has `paid_sequence == k`, or the debt is settled.
- **Bounds and lifecycle.** One countdown per station. A global cap (like ADR-040's 128). Cleared on
  server stop and on the actor's logout. The map must not be a lifecycle-free static (AGENTS 3.3).
  A cooldown after a commit or failure.
- **Recheck semantics.** The commit uses the ADR-041 path, so any unrelated station change during the
  countdown (an invitation accepted, a gravity change) makes it STALE and aborts it. State this. Also
  state which recheck failure produces which message.
- **Consequence confirmation.** An interstellar warp moves members (online and offline) and their docked
  rockets into a system that, in the example content, has **no routes** and a single orbitable body.
  `RoutePlanner` rejects identical anchors, so station-to-station rocket travel inside Tau Ceti is
  impossible too. Require a server-issued confirmation naming the consequences, as ADR-040 does for
  expansion, and notify online members.

### M4 (ADR-044 and ADR-043): warp from an unavailable orbit body is undefined

A station whose `orbit_body` is missing from the catalog (after a data pack is removed, or after ADR-043
rollback) keeps its record (ADR-041 fallback). Its rockets cannot launch: admission requires
`catalog.get(orbitBody)`. Its system, and so its warp cost class, is undefined. ADR-031's principle
("closes new arrival/creation, not evacuation by an owner") suggests allowing a warp to a known target as
an evacuation, at a defined cost. Decide this and test it. Otherwise the plan's "target unavailable keeps
station and assets" holds only in the sense that the assets are kept but stranded.

### M5 (ADR-044): plan items without a disposition

- Plan section 17 says "可独立禁用 warp，不影响基础站点访问" (warp can be disabled independently without
  affecting basic station access). There is no disable switch. Add one: a server config that stops new
  warps while pending debts or credits still settle.
- Sky after a warp: the station keeps the generic Space sky (ADR-041 non-goal). ADR-040 says a logical
  relocation "still owes actual environment/sky/routes". Reference ORBIT-03 and its V1 obligation
  explicitly.
- The Verification section omits plan section 10 and 12-15 items:
  - two stations warping at once to different targets;
  - owner disconnect and reconnect during the countdown;
  - online and offline passengers;
  - catalog reload or removal during the countdown;
  - non-member and forged requests;
  - 10/100-station performance;
  - V1/V2;
  - the warp video;
  - the recovery matrix.
  Map each one to a test or to a named later leaf (MIG-01/02, UI-03, ACC-02). Otherwise record an AGENTS
  section 5 exemption with owner, reason, expiry and recovery condition.
- Plan section 6 steps 5-6 ("WarpPlan, WarpState and journal", "target preparation, member/rocket
  migration") are satisfied by design choice, not literally: there is no journal and nothing moves. State
  this mapping explicitly so WARP-02/03/04 are not later marked verified against their titles by
  omission.

### M6 (ADR-044 and ADR-043): shared-Space adjacency makes system boundaries physically porous

Every station, in every system, sits in one Space Level on a 1,024-block grid, with gaps of at least 256
blocks, and building in gaps is allowed (`StationAccessService.allowedBuild` with an empty station).
Players can bridge or fly from an Earth-orbit station into a Tau Ceti station. Blocks, and rockets
disassembled and reassembled, cross the same way. A reassembled rocket takes the new station as its
`currentTarget`. The 8,000,000 FE therefore buys only the orbit label, and the ADR's "prevents a free
interstellar trip" rationale is inaccurate.

This already holds between orbits of different planets, so it is not new. It becomes material once other
systems gain real content. The ADRs must disclose it as an accepted limitation, or add a mitigation (for
example, gaps closed to building, or context-aware barriers), and must not rely on "only warp crosses
systems" for any future authority.

### M7 (ADR-044): bidirectional module dependency (AGENTS 3.4)

- station to rocket: `StationManager` imports `RocketEntity`, `RocketTransferSavedData`,
  `RocketStructureSnapshot` and `RocketRegion`.
- rocket to station: ten classes, including `PlanetaryFlightAdmission`, `RocketFlightService`,
  `RocketTransferService` and `RocketTargetFlightPlanner`, import station classes.

Warp adds a rocket-journal check (station to rocket) and an admission change (rocket to station), which
deepens the cycle. Require a narrow port, for example a `StationRocketAuthority` interface in `station/`
implemented in `rocket/` and wired at startup, like ADR-041's gravity function. Record the existing cycle.

### M8 (ADR-043): the new validations can stop existing servers from starting

The 16-root bound and cross-system route rejection apply to the whole candidate. A v1.4 world with a
custom pack that has more than 16 roots, or routes between roots (legal today), will fail its **initial**
load after the upgrade (`PlanetaryDefinitionReloadListener.apply` throws "Initial planetary catalog is
invalid"). ADR-031 documented a similar strictness change with operator guidance. Do the same here: give
the diagnostic text and the remediation, test the initial-load refusal, and justify 16.

### L1 (ADR-044): stale `currentBody` propagates into new records

Docked rockets keep `currentBody` equal to the old orbit (checksum-bound in their retained landed record).
After a warp, a new `prepareLaunch` copies that stale value into `sourceFlightData` of a **new** record.
This is harmless for authority under position admission, but misleading for diagnostics and recovery
reports. Recommend normalizing `currentBody` to the station's current orbit when building a **new**
plan or record. Never rewrite existing checksums (ADR-040).

### L2 (ADR-044): cost data bounds

"Deterministic server data" is ambiguous (a constant or a configuration value). State the bounds: at most
the 10,000,000 FE capacity, and above 0. Recompute the cost at commit from the same captured catalog
pair used for the target and system checks.

### L3 (pre-existing, outside the ADRs): station deletion's rocket guard fails open

`StationManager.delete` relies on `hasRocketAuthority`. With a blocked transfer journal, the journal part
sees no entries. The loaded-entity part misses rockets in unloaded chunks. A station can therefore be
deleted while an inbound rocket's authority is unknown. The rocket later lands at an unowned cell with a
`currentTarget` of a deleted station, and it cannot launch. Fail closed when the journal is not
operational.

### L4 (ADR-044): header metadata

The ADR amends ADR-040 ("no speculative warp fields yet") and ADR-041 ("only two transitions"). Add
`amends: ADR-040, ADR-041` to the YAML header, as ADR-041 did for ADR-028. Record the independent review
before acceptance (the ADR-042 process lesson).

### L5 (ADR-044): diagnostics limits

Under the debt design, the `PAID` state lives only in the core, so admin diagnostics cannot report
payment without the core's chunk loaded. State that diagnostics show "debt k, payment unknown (core not
loaded)" and never load the chunk. With option A, this problem disappears.

### L6 (ADR-044): warp-core content details

Specify the recipe or progression gate, the loot table (see H2), whether generated assets land in the v1.5
generated directory, and FakePlayer rejection for block use. Block use is not a command source, so restate
the local-actor rule for `RightClickBlock`: the player must be the connected `PlayerList` instance and not
a FakePlayer, with vanilla reach, a loaded chunk and the station region.

### L7 (ADR-043): superseded satellite definition packaging

See required change 4 for ADR-043. Today `currentSatelliteDefinition` excludes only
`src/generated/v0.8/...`. A v1.5 copy would sit next to the v1.4 copy in `processResources` and
`sourcesJar`.

### L8 (ADR-043): the example star cannot be "public astronomy" within the schema

Tau Ceti's roughly 5,300 K and stellar gravity exceed the 2,000 K and 4.0 bounds. The star requires
discovery but is not a satellite target, so it is never discoverable. See required change 5.

### L9 (ADR-043): system membership is reload-derived

See required change 3.

### L10 (ADR-043 and ADR-044): inconsistent warp-target rule

"Another system" only (ADR-043) versus the same or another system (ADR-044).

### Info

- **I1: feasibility confirmed.** The earlier sections list the ADR-043 feasibility points. For ADR-044:
  - the transfer journal is in memory and bounded (`MAX_ACTIVE_TRANSFERS = 64`, landed reservations
    included), so a journal-only check needs no chunk load;
  - `prepareLaunch` writes and flushes the record before the entity enters COUNTDOWN;
  - checked station writes run on the server thread, so a recheck and its commit in the same operation
    cannot interleave with a launch.
- **I2: example gameplay.** Tau Ceti has no routes and one orbitable body, so rockets docked at a warped
  station are immobile until it warps back. This is acceptable if it is disclosed (M3).
- **I3: gap environment.** Gaps and missing-body fallbacks resolve to Sol's shared Space body, even next
  to a Tau Ceti station. Document this.
- **I4: rocket fuel quotes.** Quotes still use gravity 0 for station anchors (previous review, I4); warp
  does not change this.

---

## Part B: confirmation of `2fb9bce` (`git diff 442e4a7 2fb9bce`)

### Commands and exit codes

The source was exported with `git archive 2fb9bce`, a read-only git operation. The following ran in that
export with `JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"`:

```
./gradlew test --tests '*StationWriteCooldownTest' --tests '*StationCheckedUpdateTest' \
  --tests '*StationOrbitEnvironmentResolverTest' --tests '*StationExpansion*' \
  --offline --no-daemon --no-build-cache --console=plain
```

| Run | Exit | Result |
|---|---|---|
| Initial (`evidence/gradle-test.log`) | 0 | BUILD SUCCESSFUL. 28 tests, 0 failures, 0 skipped: resolver 6, checked update 11, expansion confirmations 5, expansion service 4, write cooldown 2. |
| Mutation A: pre-write guard in `checkedReplace` disabled | 0 | **Survived** (no test fails). |
| Mutation B: `isCheckedUpdateOf` returns the old "same authority and not equal" | 1 | Killed: `onlyGrowthOrAGravityOnlyChangeIsACheckedUpdate` fails. |
| Mutation C: `StationWriteCooldown.ready` always true | 1 | Killed: `oneWritePerStationPerWindow` fails. |
| Mutation D: no eviction in `record` | 1 | Killed: `expiredEntriesArePurgedAndTheMapStaysBounded` fails. |
| Mutation E: `resolveAt` ignores the Level | 1 | Killed: `positionLookupCoversRegionEdges...` fails. |
| Re-run after restoring the files (byte-compared with `git show 2fb9bce:`) | 0 | 28 tests, 0 failures (`evidence/junit/`). |

GameTest evidence (`docs/work/v1.5.0-orbit-environment/review-fix-checks.zip`, not rerun as instructed):
- `gametest-latest.log`: "All 239 required tests passed". `root-gradle-01.log`: `EXIT_CODE=0`.
- The 13 implementation-file SHA-256s in `implementation-files.json` match the `2fb9bce` blobs (13 of 13).
  The zip's `base_commit` is `442e4a7` because the run preceded the commit.
- The log shows the audit order `GRAVITY_SET` (350), then `GRAVITY_UNCHANGED`, then `GRAVITY_COOLDOWN`.
  This is consistent with the ordering claim.

### Item-by-item

- **`StationState.isCheckedUpdateOf`: correct.**
  - It requires `sameAuthorityAs` (identity, owner, name, cell, pad, orbit, members and invitations all
    equal) and not equal.
  - Growth: an unexpanded predecessor whose region becomes exactly its cell's 768 region, with the
    environment unchanged. `withExpandedRegion` is evaluated only after `!previous.expanded()`
    short-circuits.
  - Gravity-only: the same region, the same vacuum and angle, and a different gravity.
  - `StationEnvironmentProfile` has exactly those three fields, so the conjunction is exhaustive.
  - Shrink, growth plus gravity, vacuum or angle changes, and identical states are rejected.
  - `StationRegistryModel.replaceChecked` now uses the same predicate.
- **Pre-write rejection in `checkedReplace`: correct placement, but untested and currently unreachable.**
  - It sits after the UNAVAILABLE, STALE and UNCHANGED checks and before `encode`, validation and any IO.
    A disallowed transition therefore cannot reach disk, and the post-write `replaceChecked` quarantine
    path can no longer be triggered by a bad transition.
  - Its only callers (`checkedExpand`, `checkedSetGravity`) can only build allowed transitions, so the
    guard is defense in depth. Mutation A confirms no test covers it.
  - The new assertion "Gravity outside the stored bound is refused before any write" (10,001 milli) is
    enforced by the `StationEnvironmentProfile` constructor inside `withGravityMilli`, not by this guard.
  - **Low:** add a package-private or test hook that calls `checkedReplace` with a disallowed replacement
    and asserts that the file bytes are unchanged, or correct the test comment. This matters because
    ADR-044's new transitions will pass through this guard.
- **`StationWriteCooldown`: correct.**
  - The map size is bounded at 4,096 (`MAX_STATIONS`).
  - `record` moves the key to the tail, so insertion order is time order within a server lifetime.
    Expired heads are purged on each record, and the entry just recorded is always kept.
  - A tick reset (`nowTick < previous`) is treated as ready, so a station is never blocked forever.
  - `StationManager.clear()` (called from `onServerStopped`) now clears it.
  - **Info:** under the cap, eviction could drop an unexpired entry only if more than 4,096 distinct
    stations wrote within 100 ticks. That is only possible with deleted and recreated UUIDs, so it is
    negligible.
- **`StationGravityService` ordering: correct.**
  - The actor rule comes first. An unchanged value then returns `GRAVITY_UNCHANGED` with no cooldown check
    and no write. Only then is the cooldown checked.
  - The cooldown is recorded only for `GRAVITY_SET` (a committed write).
  - **Low:** `WRITE_FAILED` and `STALE` do not start the cooldown. During a persistent disk failure, which
    does not quarantine, an owner can repeat full-registry write attempts at command rate (vanilla spam
    limits apply to non-ops only). Consider counting failed attempts too, or backing off after a failure.
- **`StationOrbitEnvironmentResolver.resolveAt`: correct.**
  - It is pure: Space-only, one `findAt` (empty when the registry is blocked), then `resolve`. `at()`
    delegates to it.
  - **Info:** the test name says "NegativeCells", but its only station is at cell (0,0), whose region
    spans negative coordinates. Negative *cell* indices are not exercised here. They are covered by
    `StationRegionBoundaryTest` and by the previous review's probe.
- **Environment command identity: no leak.**
  - `canIdentify` uses `VISIT` (owner, members, operator by the actor's own permission level).
  - An outsider sees "A station you are not a member of;" plus environment values. The GameTest asserts
    that the outsider sees no UUID; the owner case is covered by the earlier assertion.
  - **Low (accuracy):** the code comment and the ADR-041 text say "matching `/arce station list`", but
    `list` also shows stations the player is **invited** to. The implementation is stricter, not leakier.
    Correct the wording, or include invitees as the previous review suggested.
- **Can the new tests fail?** Yes, for B, C, D and E (mutations killed), and the GameTest assertions
  depend on real behavior: the cooldown message plus unchanged stored gravity, the Forge-bus-posted
  `LivingTickEvent` reaching the registered controller, the outsider identity check, and the clamp with
  the configured API value. No: the pre-write guard (mutation A).

**Part B conclusion.** M1-M3 and the code-bearing L items are correctly addressed. There are no Critical,
High or Medium findings in `2fb9bce`. The remaining notes are Low or Info, as listed above.

---

## Residual risks

- Until ADR-044 is revised, any WARP runtime code built on the debt design would inherit H1 and H2. No
  WARP code exists yet, which is correct.
- Crash durability is still bounded by the ADR-040/041 checked-write assumptions: same-directory atomic
  replace, and no claim about directory fsync or power loss. Whichever energy option is chosen, chunk
  rollback relative to SavedData remains a disclosed residual.
- The station and rocket cycle (M7) and the fail-open deletion guard (L3) exist today, independently of
  these ADRs.
- The shared-Space adjacency (M6) is a design-level limitation that future multi-system content must
  not rely on.
- Part B was verified by targeted unit tests, mutation checks and archived GameTest evidence only. It
  does not include the full suite, native restart readback (ORBIT-02 remains open for that), or V1/V2.

## Statement

This review is independent evidence for the maintainer. It is **not** a Gate approval, it does not
accept or reject ADRs on the maintainer's behalf, and it does not change any leaf, version or release
status.
