# COMP-02 native ItemStack regression review

## Finding

P2 (test oracle): `gametest/FuelLoaderGameTests.java:133-142` treats an unknown ForgeCaps key as proof that native decoding drops metadata. That is not true for the pinned Forge 47.4.10 lazy-capability path. The failure does not, by itself, identify a loader normalization defect.

## Inspected native behavior

From `forge-1.20.1-47.4.10-sources.jar` (SHA256 `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`):

- `patches/net/minecraft/world/item/ItemStack.java.patch:49-64`: native-compound construction enables lazy capabilities, captures ForgeCaps, runs forgeInit, then normalizes damage for damageable items.
- Same patch `:275-278`: forgeInit supplies the capability initializer lazily and calls deserializeCaps with saved capNBT.
- `net/minecraftforge/common/capabilities/CapabilityProvider.java:59-64,83-94,122-149`: while lazy and uninitialized, deserializeCaps stores the original lazyData and serializeCaps returns it. Only getCapabilities performs gathering and dispatching saved data.
- `net/minecraftforge/common/capabilities/CapabilityDispatcher.java:109-128`: after initialization, serialization iterates only registered writers; deserialization likewise ignores names without writers. With no dispatcher, serialization returns null. Unknown saved keys therefore need not survive initialization, but can survive an immediate lazy save exactly.
- ItemStack.save includes a nonempty serializeCaps result; it omits an empty compound. An empty ForgeCaps root is therefore a distinct normalization case from the nonempty unknown-key example.

Pinned mapped ItemStack bytecode confirms lazy constructor use, capNBT capture, the damage-normalization call, forgeInit and save behavior. Full read-only javap output is retained in `ItemStack.javap.txt` in this review directory.

`rocket/fuel/FuelItemPayloads.java:27-33` constructs and saves the stack without requesting a capability. For the ordinary fuel-cell item used by the test, an unknown nonempty ForgeCaps compound can consequently pass the exact native round-trip check legitimately. The loader's stored authority remains its private saved compound; this does not promise that arbitrary later external capability initialization preserves unknown fields.

## Precise regression correction

1. Keep the missing registered item ID case: it must remain blocked and its complete loader root unchanged.
2. For deterministic actual normalization, create/save a known damageable vanilla stack, then modify the saved compound's `tag.Damage` to -1 before loading it into the loader. Do not call stack.setTag to prepare this case: that method normalizes damage too early. The native ItemStack NBT constructor calls setDamage(getDamage); `IForgeItem.java:435-437,472-474` reads Damage and clamps it to zero. The loader's exact comparison must reject this changed native representation, retain the original root and deny extraction.
3. Keep a separate positive assertion that the existing nonempty unknown ForgeCaps payload round-trips and extracts byte-for-byte/equal-NBT while still on the lazy path. Do not force capability initialization merely to manufacture rejection, and do not remove the native exact-equality assertion.

These distinguish unknown item IDs, observed lossy native normalization, and natively preserved opaque metadata. No weaker preservation expectation is needed.

## Commands / limits

Actual checks: rg and numbered reads of the GameTest/FuelItemPayloads; Python -B zipfile reads of pinned Forge sources and patch; Get-FileHash on the source JAR; JDK 17 javap -p -c against the pinned mapped Forge JAR. Only this Temp evidence was written. No Gradle, GameTest, server/client or tracked/build modification was run. Root's reported failing GameTest was not independently rerun. This is source/bytecode confirmation and a regression recommendation, not runtime or Gate approval.
