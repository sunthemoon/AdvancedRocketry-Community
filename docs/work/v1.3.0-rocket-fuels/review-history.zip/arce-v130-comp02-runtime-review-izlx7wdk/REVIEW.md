# V130-COMP-02 in-progress runtime source review

## Findings

### P1 — Ordinary BlockItem placement merges defaults into opaque preserved roots (source correction inspected; runtime regression not yet executed)

Affected code: src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/fuel/FuelLoaderBlock.java:33-45 and :100-106, together with the existing ordinary BlockItem registration in registry/ModItems.java:89-92. FuelLoaderBlockEntity.saveAdditional/savedRoot at :192-202 creates a complete default schema-2 root for the newly placed BlockEntity.

Pinned Forge 47.4.10 BlockItem.updateCustomBlockEntityTag does not replace that root: it calls the new BlockEntity's saveWithoutMetadata, recursively merges the dropped item's BlockEntityTag, then loads the merged result (bytecode offsets 64-100). FuelLoaderBlock.setPlacedBy currently only assigns owner, so the altered root remains authoritative.

Concrete triggers:

- Load a bounded future root containing only schema_version=3 and an opaque string, obtain its normal loader drop, then place the item through BlockItem. The new loader gains schema-2 slot_role/item/buffered_units fields in the future opaque root, violating ADR-027:93-108's verbatim preservation.
- A bounded malformed schema-2 input with valid role/item but missing required buffered_units initially blocks under FuelLoaderStorage:52-58. Native placement supplies default buffered_units=0, making the previously invalid root valid; it may now be extracted/consumed instead of remaining blocked.

Minimal correction: replace arce_fuel_loader with the exact carried Tag before assigning placement ownership (for all server placements, even null placer), or use a narrowly scoped loader BlockItem override to avoid recursive merging for this root. Preserve bounded arbitrary Tag types and quarantine behavior; do not reconstruct unknown data into a known schema.

Verification: actual normal loot drop plus native BlockItem placement for minimal future and incomplete malformed compounds, asserting exact root equality and continued blocking, then ordinary complete input/output/batch placement/owner preservation. Direct BlockEntity.load or copy-only tests cannot detect this platform merge. This finding is based on actual implementation and pinned native bytecode, not an executed GameTest reproduction.

Follow-up source check: FuelLoaderBlock.setPlacedBy:41-53 now reads the exact carried arce_fuel_loader Tag, bounds it before copy (or passes through the original quarantined Tag), loads that replacement root, marks the BE changed, then assigns an absent owner. The replacement is not conditional on a player placer. This addresses the two concrete native-merge triggers at source level. Pinned BlockEntity.load only changes ForgeData/ForgeCaps when present, so the narrow second load does not clear outer data already loaded by BlockItem. No additional source finding identified in this correction. Native drop/place regression and final compile/runtime evidence remain unexecuted by this reviewer.

## Other reviewed behavior

No additional concrete correctness finding identified in the reviewed initial source:

- Public fuel record, registrar/event and registry enforce accepted numeric/known-item/owner/duplicate/quotas/thread/closed/reentrant constraints; built-in fuel is reserved outside external quotas. Common setup installs immutable item metadata on both sides and retains no world state in the static bridge.
- FuelPayloadBounds validates bounded depth/node/byte structure before recursive host copy/equality. FuelLoaderStorage separates valid data, bounded raw unsupported Tags and oversized original-reference quarantine; schema-1 parsing stays capped at 500, with an explicit frozen built-in batch. Unknown fields/roles and malformed item representations block instead of being normalized.
- FuelItemPayloads checks known registry IDs and exact native Count=1/tag/ForgeCaps round-trip. The stored inventory authority is private CompoundTag data, not a mutable ItemStack returned to callers.
- Tick captures/validates the remainder before removing input, retains pending batch metadata independent of registration, transfers at most 25 units, decrements only accepted fuel and issues the remainder only at completion. Explicit output role prevents automatic reburning. Existing owner/range/loaded entity/flight-state/capacity checks remain in effect; cross-file crash atomicity remains explicitly unprovided.
- Player/automation input and extraction operate only in the mutable server context; missing-registration queued items remain extractable. Capability invalidation/revival creates a fresh view and disables retained old views. Simulation avoids host inventory changes.
- Quarantined save uses reference passthrough instead of deliberate exception/omission; survival destruction rejects before mutation. Normal bounded drops embed one resource authority and no longer separately emit inventory in onRemove. Native creative/no-drop/explosion loss boundaries remain as accepted.

Native confirmation: BlockItem applies custom NBT before setPlacedBy, and default BlockEntity.getUpdateTag returns an empty compound, so this change does not implicitly send the preserved loader root in chunk update tags. Their actual disassemblies are retained.

## Checks and identities

Inspected HEAD c20dde3bdb339a8b6f59bafbb1562ed67ce8be0a, accepted ADR-027 and the actual tracked/untracked runtime files. Source hashes and initial diff are in identities-initial.json and runtime-diff-initial.patch (17 scoped files). No packaging/test outcome is inferred: root explicitly has those changes in progress.

Actual checks: git status/rev-parse/diff/diff --check, numbered source reads, rg searches, read-only pinned JDK javap on BlockItem/BlockEntity/CompoundTag, and Python -B to create only this unique Temp inventory/evidence. An initial PowerShell invocation rejected bash-style brace expansion before executing anything; corrected explicit directory arguments were used. No tracked/build edits, Gradle, server/client, remote work, extra agent or OpenPet event. User untracked documentation bundle was not inspected.

## Remaining boundaries

No compilation or tests have been executed by reviewer in this stage. Native item capability serialization/deserialization may execute trusted mod code; this review does not certify arbitrary callback side effects or establish same-JVM sandboxing. Actual drop/place, migration restarts, missing/changed definitions, API packaging and the final source delta still need the planned finite tests/review. No full Gate or release approval is implied.
