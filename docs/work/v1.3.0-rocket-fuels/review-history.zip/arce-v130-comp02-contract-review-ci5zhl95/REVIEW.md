# V130-COMP-02 independent contract review

## Final resolution check

No unresolved contract-semantics blocker identified after reading the actual revised accepted ADR. The original P1 below is resolved by lines 93-105: bounded malformed arbitrary Tags are retained; over-budget already-loaded data remains quarantined and is passed through by reference, not deliberately omitted or made to throw; ordinary survival removal is refused before mutation; the native writer's behavior remains outside the host's operational budget/durability promise. This is a deliberately limited corruption policy, not a new recovery framework or guaranteed safe serialization of arbitrary NBT.

The other recommended clarifications are present: public record/accessors/void signatures and exception classes (25-35), exact remainder construction and validation before removal (60-69), native loot/no-drop/placement-owner boundaries and removal of separate inventory emission (110-122). Operational limits, schema-1 migration, immutable batch semantics and the explicit cross-file atomicity exclusion remain consistent with existing source.

Two minor textual follow-ups were sent to root: the active log still said proposed ADR at the time of inspection, and the registry should spell out a nonempty 1..64 input-set range rather than only the upper bound. These are documentation precision points, not a remaining native-loss or implementation finding.

Revised exact proposal snapshot and hashes: ADR-027-revised-reviewed.md and revised-identities.json. Root's ACCEPTED status is under standing maintainer authority; reviewer does not approve a Gate or release. No production implementation or test has been verified in this task. The original finding and bytecode evidence remain below for audit history.

## Findings (proposal review, not runtime implementation)

### P1 — Serializer refusal is not a native persistence or removal veto (resolved in revised contract)

The initial ADR-027 proposal at lines 86-100 says oversized/deep roots remain retained while new save/drop serialization is refused. This needs an explicit native-platform qualification: FuelLoaderBlockEntity.saveAdditional (current lines 220-231) cannot veto a chunk save by throwing. Pinned Forge 47.4.10 LevelChunk.getBlockEntityNbtForSaving invokes saveWithFullMetadata, catches Exception, logs that the BlockEntity will not persist, and returns null. A subsequent chunk write can therefore omit the entire loader; it does not keep the previous disk entry automatically. Likewise, ServerPlayerGameMode.destroyBlock removes the block before Block.playerDestroy produces survival drops. Throwing from the drop serializer is too late to retain the placed loader.

Evidence: original proposal captured as ADR-027-reviewed.md; actual pinned bytecode retained in LevelChunk.javap.txt (getBlockEntityNbtForSaving offsets 17-53) and ServerPlayerGameMode.javap.txt (destroyBlock offsets 211-246, removeBlock offsets 9-31). This is a contract ambiguity/failure-policy risk, not a claim that COMP-02 production code already contains that implementation.

Smallest recommended policy, sent to root:

1. Valid usable/migratable payloads obey the item and loader-root budgets and strict schema/round-trip validation.
2. Bounded unsupported roots retain raw Tag authority without native ItemStack interpretation, are inert, and may be copied verbatim for ordinary save and resource-bearing drops.
3. Preexisting roots outside the usable/preservation budgets are quarantined: no operations, capability transfer, item materialization or new item drop. Keep the already-loaded original Tag reference. saveAdditional should attach this reference to the outgoing parent without copying, comparing, normalizing or throwing merely because of the host budget. This avoids deliberate omission by the host, but native serialization of preexisting over-budget/corrupt data is outside the bounded host-operation guarantee and may itself fail. Require a backup/offline repair; do not call this safe recovery or promise arbitrary-data durability.
4. Refuse ordinary survival removal before mutation, through FuelLoaderBlock.onDestroyedByPlayer returning false or a canceled Forge BreakEvent. playerDestroy/getDrops is not the veto point. Keep deliberate creative/no-drop destruction exceptions explicit. If the contract instead forbids even opaque native passthrough while also demanding arbitrary-root preservation, that requires a broader world-load/save/quarantine design and cannot be honestly met by this small BlockEntity slice.

Root acknowledged the platform issue and requested this concrete recommendation; revised contract text has not yet been inspected in this initial report.

## Additional contract clarifications recommended

- Freeze public record/accessors/value semantics, functional void registrar signature, event constructor and invalid/null versus expired/thread exception categories, consistent with ADR-021 and the existing component API. Current draft lines 25-38 name the types and intent but do not state all these source/binary details.
- Define the exact default-remainder construction rule (for example new ItemStack(resolvedItem, 1), rather than an unspecified choice with Item.getDefaultInstance()). Capture, bound and round-trip the actual native remainder before input removal; preparation failure must leave the input untouched.
- Preserve bounded malformed non-compound DATA_KEY values as raw Tag, not only compounds. Current FuelLoaderPersistence lines 48-49 replaces that case with a schema-0 sentinel, so the new preservation contract must not blindly delegate it to the old codec. Current decoded blocked compounds also copy recursively at lines 144 and 176-177 before any size bound.
- State that ordinary resource-bearing drop conservation applies when vanilla rules actually produce a loader item; the existing fuel_loader loot table includes survives_explosion. No-drop/creative semantics must not be accidentally presented as guaranteed conservation.
- Missing-registration input extraction must be available to players as well as automation. Current player insertion/takeOutput paths are hard-coded to the built-in fuel and empty canister (FuelLoaderBlockEntity lines 184-210; FuelLoaderBlock lines 67-81).
- Quarantine diagnostics must not stringify rejected tags; log bounded identifiers/location/reason only.

## Actual implementation constraints and consistency

- A schema change is necessary: FuelLoaderPersistence schema 1 stores only item_state and up to 500 buffered units, with owner/target UUIDs. It has no item ID, metadata or pending remainder. Current player insertion reconstructs a plain built-in cell (BlockEntity lines 188-195), and reload reconstructs enum items (248, 276-281); these must not be reused as schema-2 native item preservation.
- Existing migration invariants are compatible with a frozen built-in batch: buffered fuel requires an empty slot, target requires a positive buffer and owner (Persistence lines 84-92). Legacy 0/500/partial values can migrate without changing RocketFlightData. Native schema-2 batch total/remaining and remainder can then survive missing or changed registrations without lookup on tick.
- The existing runtime selects a loaded rocket within six blocks, matches owner, accepts ASSEMBLED/FUELED/LANDED and checks remaining capacity (BlockEntity lines 131-169; RocketFlightState.acceptsFuel). RocketFuelState.fill accepts min(requested, remainingCapacity), so a 25-unit maximum tick and retained residual buffer support partial tanks naturally; no whole-batch loop is needed.
- Existing transfer writes rocket fuel then decrements loader buffer (BlockEntity lines 119-128), in separate persistence domains. ADR-027 lines 113-117 correctly excludes cross-file power-loss atomicity; a clean restart cannot prove it.
- Resource-bearing drop/replace is feasible with the native BlockEntityTag plus current setPlacedBy/assignOwner behavior (FuelLoaderBlock lines 31-43; BlockEntity lines 172-177). The current separate inventory emission in FuelLoaderBlock.onRemove lines 98-107 must be removed when embedding that resource authority in the dropped loader, or item contents can duplicate. Existing empty-item loot must be augmented or replaced, not emitted in addition to the preserved carrier.
- Explicit slot roles solve the remainder-as-fuel case. They must govern tick/player/automation extraction rather than testing only item identity. No-remainder completion must leave a truly empty slot and no pending batch.
- API 1.5 adds three types to the existing sixteen, so export/isolated-consumer inventories must become nineteen without exporting internals. Existing owner-thread registry and queued-common-setup patterns fit this declarative input; no fuel callback or large new provider framework is required.

## Finite verification recommendations

Test exact units 1 and 2,048,000 plus invalid edges; registry collisions/quotas/thread/expiry; every schema-1 state and target invariant; native Count=1/tag/ForgeCaps round-trips; unknown item IDs, future/unknown fields and malformed non-compound roots; item/root byte/depth/node edges before recursive copy/equality; valid/blocked carrier drop-place; over-budget survival refusal and raw-reference passthrough without host normalization. Exercise actual player and automation simulation/commit/extraction, full/partial/no/foreign/out-of-range/ineligible targets, pending remainder and no-remainder cases, and output-as-fuel non-reburn. Changed/missing registration restart should separately test unconsumed input versus consumed batch. Maximum units need only bounded edge-state tests, not an 80,000-tick runtime run.

Use a finite clean native restart fixture and raw loader/rocket readback for resource deltas. Existing fixture conventions support API-only registration and platform/gameplay observation; no server/client or new acceptance campaign was run in this review.

## Identities, commands and limits

Baseline/current HEAD inspected: 2043b08d4cd0ed8ca97421c5c4fe3c622a42e946. Proposed ADR SHA-256: 54d94c110e29ebf16f39895ef0244301d03dcb836b18db16b60e86067560c7c5. Source and pinned Forge-JAR hashes are retained in identities.json. Required project governance/current v1.3 plan, ADR-020/021, active COMP-02 entry, loader/flight/API/fixture source and existing tests were read. Source files remain unchanged by reviewer.

Actual command categories: git rev-parse/status, numbered Get-Content/Select-String, rg source/file searches, Python -B for a new unique Temp evidence inventory, and read-only javap -classpath <pinned Forge 47.4.10 mapped JAR> -c -p on LevelChunk and ServerPlayerGameMode. A guessed loot-provider filename and a Windows wildcard-path rg invocation returned missing-path errors; actual generated loot/source and explicit paths supplied the needed evidence. No Gradle/tests, Minecraft server/client, remote call, Git mutation, tracked/build write or OpenPet update occurred. User-supplied untracked document bundle was not inspected.

This is pre-implementation contract review. Runtime behavior, external item capability behavior, migration artifacts, exact drop/place execution and all tests remain unverified. No Gate/release approval.
