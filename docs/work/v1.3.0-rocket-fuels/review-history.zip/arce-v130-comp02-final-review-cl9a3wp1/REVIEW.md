# V130-COMP-02 full source / finite-runner review

## Findings

### P3 — Java preflight failure is replaced by a missing-directory exception

At reviewed source `scripts/run_v130_fuel_smoke.py:237-240,260-262`, main assigns output from validate_inputs before resolve_java and before creating the evidence directory. A bad Java selection makes resolve_java raise SmokeError; the handler then tries to write failure.json beneath a nonexistent directory, raising FileNotFoundError and losing the intended diagnostic. No process starts, so this is a diagnostic/evidence failure, not a world or resource-conservation defect.

Reproduced using unittest.mock only: validate_inputs returns disjoint Temp paths and resolve_java raises SmokeError. Actual result: FileNotFoundError from line 261, no stderr diagnostic and no failure.json. Source SHA256 `ddd8ffe5a8ef43b678fe272a0b89fdfd181da0474296ce6e769728193a8b8dd5`. `prelaunch-reproduction.json` retains the complete traceback. Suggested finite fix: create and assign the validated evidence directory before the fallible Java preflight, or leave output unassigned until the directory exists and report the original preflight failure without a JSON path. Add the mocked prelaunch regression; no runtime process is needed to test it.

No additional concrete production correctness finding identified in the reviewed current slice. Earlier native BlockItem merge and incorrect capability-test assumptions have source corrections and corresponding real-path GameTest assertions; reviewer has not independently executed those Java tests.

## Production / fixture / packaging source checks

- Compared actual tracked diff with c20dde3 and explicitly read untracked API, fuel registry/storage/model, GameTest, consumer fixture and runner/test files. Of the 17 production files hashed in the initial runtime review, only FuelLoaderBlock changed. Its exact carried-root replacement remains before owner assignment, including non-player placement; other reviewed runtime logic is byte-identical to that initial inventory.
- `FuelLoaderPlacementGameTests.java:35-82,110-133` performs native destroyBlock loot, checks a single loader drop, invokes BlockItem.place, and compares exact saved roots for queued metadata/owner, buffered work, minimal future data, incomplete malformed data and non-compound data. The quarantine test checks reference passthrough and premutation survival refusal. These assertions exercise the previously missed platform merge, rather than direct load alone.
- `FuelLoaderGameTests.java:133-156` now separates unresolved item IDs / negative native Damage normalization from nonempty lazy ForgeCaps preservation. Native damage is changed in the already-saved compound, ensuring ItemStack.of is the operation being tested. Positive ForgeCaps extraction compares the complete saved native item.
- FixtureRocketFuels registers vanilla charcoal/stick/coal/blaze_powder through only the exported event and definition types. RocketFuelGameTests uses API/platform registration, actual block use and assembly commands, native fuel readback, and Forge inventory extraction; it does not import private host services. Retained event expiry, one-item consumption, metadata and no-remainder/reburnable-output behaviors are represented.
- API version changes to 1.5; both classifier and standalone consumer allowlists add exactly the three contract types (19 exports total). FuelApiConsumer and its compilation test use the public signature. This is source inspection only, not inspection or execution of the still-being-built final artifacts.

## Runner invariants and boundaries

`run_v130_fuel_smoke.py` drives four finite clean processes using the existing captured-process owner/abort wrapper. Inputs are validated as disjoint, fresh disposable outputs and exact host/fixture identities; each process verifies installed bytes, status mod set and a single selected fuel-registration event. No arbitrary process termination, remote target, client or existing user world is introduced.

Actual setup uses one forced chunk (16,16); both rocket footprints, the complete clearing box, three loaders and two hopper inputs are inside that chunk. The runner waits for loaded setup, uses bounded command waits, retains commands/stdout/native logs on execution exceptions, saves and cleanly stops before raw capture. Config comparison retains the existing narrow generated timestamp exception. The first setup's 125-unit schema-1 buffer is explicitly synthetic, not evidence of prior fuel consumption.

Disk assertions require exact schema-2 loader roots (roles, native metadata, frozen batch definition/total/remainder, remaining units and owner), two empty hoppers, expected BE count, one/two receipt-bound rockets, exact expected fuel totals/capacities, no loose items in the observed entity chunk, removed source components and empty assembly journal. Existing rocket snapshot/logical/transaction authority is compared across processes, and the final restart compares full RocketEntityData. Raw Anvil/level.dat/journal and file hashes are retained, not replaced by decoded JSON alone.

Important evidence distinction: the external 1573-unit batch freezes in the first process, then its remaining 73 units and the synthetic legacy 125 units finish while fuel registration is skipped. The changed-registration process consumes the still-queued charcoal at its new 301-unit value/remainder. It therefore proves missing-registration frozen-batch continuation and changed-definition application to an unconsumed input. It does not independently execute a still-pending batch while that definition is changed. Missing registration here means the fixture remains installed but skips the fuel event; it is not a mod-uninstall/native-unknown-item test. Observation is limited to the selected chunk, not a global-world duplicate search.

## Actual independent execution

Environment: `PYTHONUTF8=1`; invoked `D:/python/pyenv/pyenv-win/shims/python.bat -B` and resolved Python 3.13.15.

Focused command: `python -B -m unittest tests.test_v130_fuel_smoke -v`.

Result: exit 0, **5 tests passed**, zero failures/errors; unittest 0.003 seconds, subprocess wall time 0.283163600 seconds. Raw output in python-tests.txt and exact executable/arguments/cwd/timing in python-result.json. The extra mocked prelaunch reproduction is separately retained; it was not counted as one of the five passing tests.

Also executed git status/log/diff/diff --check, numbered reads/rg, Python SHA inventory comparisons and read-only source inspection. git diff --check passed. One rg command initially used a nonexistent legacy script name / unsupported wildcard path and was corrected to a directory search; it made no changes.

Source identities and the actual tracked diff are source-before.json / tracked-diff.patch. Initial production review and pinned platform evidence remain in sibling directory arce-v130-comp02-runtime-review-izlx7wdk. Only Temp evidence was written. No Gradle, Java/game server, remote action, user-bundle access, tracked/build write, subagent or OpenPet action was performed.

## Unverified

Root-reported GameTest success is not an independent rerun here. Final main/API/source/fixture artifacts, isolated consumer output and packaged native captures were not yet supplied for final readback. Existing crash-cut/non-atomic loader-to-rocket persistence, no-drop destruction, arbitrary native capability side effects, full clients and long-load acceptance remain outside this finite slice. No full Gate or release approval is implied.
