# V130-COMP-02 independent final scoped review

## Findings and disposition

**No unresolved concrete correctness finding in this reviewed slice.** This is not a release/Gate approval.

- Earlier P1 native placement merge: `FuelLoaderBlock.java:41-53` replaces the exact carried root after native BlockItem merge and before assigning an absent owner. `FuelLoaderPlacementGameTests.java:58-82,110-133` exercises actual loot and BlockItem placement for minimal future, incomplete malformed and scalar roots; queued metadata/owner and frozen batch cases are also present. This correction does not normalize unsupported roots into usable inventory.
- Earlier capability-test oracle issue: `FuelLoaderGameTests.java:133-156` separates missing IDs / real negative-Damage normalization from the native lazy ForgeCaps preservation case. Production exact native round-trip equality remains unchanged; unknown capability names alone are not assumed lossy.
- Earlier P3 runner prelaunch diagnostic: `scripts/run_v130_fuel_smoke.py:237-242` now assigns output only after Java validation and directory creation. The sixth Python test reproduces invalid Java with mocks and verifies the original diagnostic, exit 1 and no created evidence path. The prior FileNotFoundError is resolved.
- A real first-cycle server warning remains in raw logs: `Can't keep up! ... 2056ms or 41 ticks behind`. It did not break the bounded observations or resource assertions. This evidence must not be described as a performance/stability pass.

Prior source findings, their reproduction and pinned platform analysis remain in `arce-v130-comp02-runtime-review-izlx7wdk` and `arce-v130-comp02-final-review-cl9a3wp1`; no failed evidence was removed.

## Source identity and inspected changes

Production commit at test start: `5385be6d7a45c4ace807bcc2394e75d6ee293681`. During audit, root committed already reviewed runner/version-reference files as `3938a4311a6e25c82feb3eb14e289326cf370c0d`; final source hashes remained unchanged.

The prior review read the actual diff versus accepted ADR-027 commit c20dde3, including explicitly untracked production/API/fixture/runner/tests. Final checks covered the corrected prelaunch order and regression, 1.5/19-export build and consumer allowlists, fixture-only whole-item registration, exact carried root replacement, and the final item_ready locale-key adjustment. No additional production behavior was inferred from root's test count.

`before.json`, `after.json` and `final-identity-check.json` show **1,070 source/config/runner files**, all four immutable input artifacts and the four corresponding build artifacts unchanged across the independent test execution and final audit. Tracked source/docs were not edited by reviewer. Root remains the sole writer. No user-supplied development-doc bundle was read.

## Independently executed tests

Environment: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`; `PYTHONUTF8=1`, Python shim `D:/python/pyenv/pyenv-win/shims/python.bat` resolved Python 3.13.15.

```text
.\gradlew.bat test --tests '*FuelLoaderPersistenceTest' --tests '*FuelLoaderStorageTest' --tests '*RocketFuelRegistryTest' --tests '*ApiArtifactTest' --tests '*ApiVersionsTest' --rerun-tasks --offline --no-daemon --no-build-cache
```

**Exit 0; 51.7354804 seconds; 14 tasks actually executed.** No clean or Minecraft server was run. Exact command/output/timing: gradle-command.txt, gradle.txt, gradle-result.json. Copied independent XML is in junit/; junit-summary.json records:

| Class | Tests | Failures / errors / skipped |
|---|---:|---:|
| FuelLoaderPersistenceTest | 4 | 0 / 0 / 0 |
| FuelLoaderStorageTest | 7 | 0 / 0 / 0 |
| RocketFuelRegistryTest | 7 | 0 / 0 / 0 |
| ApiArtifactTest | 12 | 0 / 0 / 0 |
| ApiVersionsTest | 9 | 0 / 0 / 0 |
| **Total** | **39** | **0 / 0 / 0** |

```text
python -B -m unittest tests.test_v130_fuel_smoke -v
```

**Exit 0; 6 tests passed**, unittest 0.010 seconds, subprocess wall time 0.3238594 seconds. python.txt and python-result.json retain exact executable, arguments and output. The earlier independently executed five-test result and failed mocked diagnostic reproduction remain in the prior review directory.

Also ran git read/status/diff checks, read-only Python ZIP/NBT/hash analysis, and `python -B independent_audit.py` (exit 0). No reviewer GameTest/dedicated server, remote, client, load test, subagent or OpenPet action was launched.

Root's separate archived evidence was read, not rerun: final-junit contains 739 tests / 139 suites / zero failures/errors/skips; final GameTest log reports a successful 2m38s execution, and consumer-build.txt reports 23s with all 10 tasks executed. Root's 185 Required GameTests are not claimed as an independent repeat by this reviewer.

## Artifact and standalone consumer verification

Actual immutable copies under `C:/Users/Administrator/AppData/Local/Temp/arce-v130-comp02-1790476198004/artifacts`:

| Artifact | SHA256 |
|---|---|
| Main | `6de968c9db91840078864175b7685f531e991a3e0367283a6a5d039a5dbad56e` |
| API | `7424c734307e55ae1140af8d86ec60e6221c99b0849957439c58bec5169dd79b` |
| Sources | `b0c602e121842dfcf7a1a806458eb75c189739f550a79f1c93f236537c2abef6` |
| Separate fixture | `5142035900b559d61ac1fe50ac7047b0ca165a9ec149b7b987fbf050b8c449a5` |

- Opened the actual archives: exactly **19** API class entries, and every API class is byte-identical to its main-JAR entry. The source JAR's 19 API source files equal checkout source bytes.
- Host/API/sources contain no arceadaptertest package or fixture asset/data namespace. Fixture classes are confined to its own package; FixtureRocketFuels is present. Archive names are not used as a substitute for byte comparison.
- Read the independent consumer's classpath/negative-import/fixture-artifact reports and independently hashed/opened all **114** actual classpath JARs. Only the mapped API classifier supplies host-package classes, exactly the 19 exports; no main/source JAR, host classes directory or host resources directory is on that compile classpath.
- All **19** reported fixture source-file hashes match actual checkout files. The raw published classifier equals the immutable API artifact, the mapped classifier equals its reported SHA256, and retained ForgeGradle `.input` orig SHA1 matches that actual raw classifier. Cached input proof is consumer-mapped-api.input.
- Local coordinate is exactly `io.github.sunthemoon.advancedrocketrycommunity:advancedrocketry-community:1.20.1-1.3.0-dev:api`. Negative compilation exits 1 with missing private rocket.forge package; the private class is confirmed to exist in the actual main JAR. Fixture report hash matches the actual separately packaged fixture and records reobfuscation.

## Independent raw native audit

Audit input: `C:/Users/Administrator/AppData/Local/Temp/arce-v130-comp02-1790476198004/runtime-evidence`.

`independent_audit.py` retains the read-only helper. It reuses structural NBT/Anvil/Forge-ping decoders, but **does not call the fuel runner's validate_disk, expected_roots or verdict**. It decodes each raw region, entity region, transaction SavedData and level.dat; computes snapshot content hashes independently; reads each config/status/launch/command file and all three raw log variants. Only Temp derived evidence is written.

All **61** manifest-listed files are present and byte-verified, with no unlisted capture files. SHA256SUMS hash: `ba28482fd2cd95a03e41f37d67d73f9e9ad759ee371eb778cabcc5c325ba6052`. All **104** prepared library hashes were also independently verified.

| Native phase | Exit | Observed ticks | Saved game time | Rocket fuel |
|---|---:|---:|---:|---|
| buffered | 0 | 20 | 129 | 1500 |
| skipped | 0 | 26 | 206 | 1500, 198 |
| updated | 0 | 21 | 276 | 1500, 499 |
| restart | 0 | 21 | 344 | 1500, 499 |

All four level.dat captures share seed `6351899233547713531`. The same first entity UUID/snapshot/logical authority persists throughout; second entity authority persists from its actual second-cycle assembly through final restart. Snapshot payloads, positions, original component metrics and independently recomputed content hashes match command receipts. Assembly journals are empty in every saved capture; source blocks are air, and there are no loose item entities in the observed chunk.

The exact native loader roots demonstrate:

- One native hopper blaze-powder input captured a 1573-unit batch with stick remainder; 1500 reached the first rocket, **73** remained in its loader. The separate explicitly synthetic schema-1 **125**-unit buffer migrated into a frozen built-in batch with pending empty canister. Charcoal metadata remained queued; both input hoppers were empty.
- With fuel registration skipped, the captured 73 units and migrated 125 units completed into the second rocket: **198**, one stick and one empty canister. Queued charcoal and its original metadata remained unchanged. No input injection occurred in this cycle.
- With changed registration, that unconsumed charcoal supplied **301**, yielding **499** total in the second rocket and one bowl. The first rocket remained 1500. Final restart preserved both complete RocketEntityData values and the exact loader output roots.

Startup arguments and exactly one event receipt per process establish standard/skipped/updated/updated registration selection. Actual status contains only host, fixture, Minecraft and Forge and zero online players; Forge's compressed ping version field is empty, while native logs and prepared library identities bind Forge 47.4.10. All JVM captures end with clean save/stop and exit 0. Current host/fixture hashes match each launch's installed mod hashes.

Raw common/FML config bytes remain equal across cycles. server.properties equality excludes only the verified generated second-line timestamp; all other bytes remain binding. It is loopback/offline mode as explicitly configured, not an online-authentication test.

Each of stdout/latest/debug has zero ERROR/FATAL/linkage findings. Warning counts are **26/10/10/10**: standard initial config/default corrections, Forge library mods.toml notices, union-resource and offline-mode notices, plus the first-cycle 2056ms/41-tick delay noted above. Full warning lines remain in native-artifact-observations.json.

Audit-helper development evidence: its initial run assumed Forge's ping advertises version 47.4.10; the actual field is empty. That assertion failed before completing the audit and is retained in native-audit-initial.txt. The helper now checks the actual status shape and independently verifies the version from startup logs/library bytes. The successful rerun is native-audit.txt. No product assertion or captured runtime evidence was changed.

## Remaining boundaries

- Frozen-batch completion is executed under **missing registration**. Changed definitions are executed against a **not-yet-consumed input**, not an in-progress changed-definition batch; do not combine these into a claim that the latter runtime combination was executed.
- The fixture remains installed in all four phases. This is not actual uninstall of a native item provider.
- The 125 legacy units were initialized explicitly by the harness. Their earlier consumption is not proven. Runtime native observation is bounded to the chosen chunk; it is not a full-world duplicate search.
- No power-loss/cross-file atomicity, arbitrary native capability callback sandbox, explosions/no-drop preservation, GPU/client/multiplayer, remote deployment or long-load acceptance is established. The captured tick-delay warning specifically prevents treating this as performance evidence.
- The independent execution here is 39 focused JUnit plus 6 Python tests and raw audit, not a second complete build/DataGen/GameTest campaign. Full current-version Required Gates and release approval remain outside this review.
