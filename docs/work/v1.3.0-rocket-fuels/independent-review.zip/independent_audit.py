"""Read-only COMP-02 artifact/native audit. Writes derived evidence only beside this file.

Only structural NBT/Anvil and Forge status decoders are reused from the repository;
no fuel runner validation function, expected-root function or verdict is called.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import struct
import sys
import uuid
import zipfile
import zlib

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-comp02-1790476198004')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import inspect_celestial_saved_data as nbt
from scripts import v120_precision_world_fixture as region
from scripts import run_dedicated_server_smoke as protocol

HOST = 'advancedrocketrycommunity'
PREFIX = 'io/github/sunthemoon/' + HOST + '/'
PHASES = ('buffered', 'skipped', 'updated', 'restart')
ORIGINS = ((264, 101, 264), (265, 101, 268))
LOADERS = ((268, 101, 264), (270, 101, 270), (268, 101, 270))
PARTS = {(-1, 0, 0): 'minecraft:emerald_block', (0, 0, 0): 'minecraft:diamond_block',
         (0, 1, 0): 'minecraft:oak_planks', (0, 2, 0): 'minecraft:gold_block', (1, 0, 0): 'minecraft:quartz_block'}


def sha(raw): return hashlib.sha256(raw).hexdigest()


def read(path, limit=32 * 1024**2):
    path = Path(path)
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= limit, path
    raw = path.read_bytes()
    assert len(raw) <= limit
    return raw


def js(path): return json.loads(read(path))


def gzip_nbt(path, level=False):
    with gzip.GzipFile(fileobj=io.BytesIO(read(path, 1024**2))) as stream:
        raw = stream.read(4 * 1024**2 + 1)
    assert len(raw) <= 4 * 1024**2
    previous = nbt.MAX_TAGS
    try:
        if level: nbt.MAX_TAGS = 65536  # Full Forge registry metadata, not just SavedData.
        return nbt.NbtReader(raw).read_root()
    finally:
        nbt.MAX_TAGS = previous


def entity_chunk(path):
    packed = region._region_chunk(read(path, region.MAX_REGION_BYTES), 16, 16)
    stream = zlib.decompressobj()
    raw = stream.decompress(packed, region.MAX_EXPANDED_CHUNK + 1)
    assert stream.eof and not stream.unused_data and not stream.unconsumed_tail
    assert len(raw) <= region.MAX_EXPANDED_CHUNK
    result = nbt.NbtReader(raw).read_root()
    assert result['Position'] == [16, 16]
    return result


def block_at(chunk, pos):
    x, y, z = pos
    sections = [s for s in chunk['sections'] if s['Y'] == y // 16]
    assert len(sections) == 1
    state = sections[0]['block_states']; palette = state['palette']
    if len(palette) == 1: return palette[0]
    bits = max(4, (len(palette) - 1).bit_length())
    index = ((y & 15) * 16 + (z & 15)) * 16 + (x & 15)
    word = state['data'][index // (64 // bits)] & ((1 << 64) - 1)
    return palette[(word >> ((index % (64 // bits)) * bits)) & ((1 << bits) - 1)]


def uuid_array(parts):
    assert len(parts) == 4
    return str(uuid.UUID(bytes=b''.join(struct.pack('>I', p & 0xffffffff) for p in parts)))


def snapshot_hash(snapshot):
    out = io.BytesIO()
    def ints(*v): out.write(struct.pack('>' + 'i' * len(v), *v))
    def string(v):
        raw = v.encode('utf-8'); ints(len(raw)); out.write(raw)
    ints(snapshot['schema_version']); string(snapshot['source_dimension'])
    ints(*snapshot['source_origin']); ints(*snapshot['bounding_box'])
    blocks = sorted(snapshot['relative_blocks'], key=lambda b: tuple(b['position']))
    ints(len(blocks))
    for block in blocks:
        ints(*block['position']); state = snapshot['block_palette'][block['palette']]
        string(state['id']); ints(len(state['properties']))
        for k, v in sorted(state['properties'].items()): string(k); string(v)
        assert 'block_entity' not in block
        out.write(b'\0')
    anchors = sorted(snapshot['passenger_anchors']); ints(len(anchors))
    for anchor in anchors: ints(*anchor)
    stats = snapshot['mass_inputs']; ints(stats['block_count'])
    out.write(struct.pack('>qqq', stats['mass'], stats['thrust'], stats['fuel_capacity']))
    ints(*(stats[k] for k in ('engine_count', 'seat_count', 'guidance_count', 'block_entity_count')))
    return sha(out.getvalue())


def item(name): return {'id': name, 'Count': 1}


def expected_loader(index, phase):
    value = {'schema_version': 2, 'slot_role': 0, 'item': {}, 'buffered_units': 0, 'owner_id': [0, 0, 0, 5]}
    if index == 1:
        if phase in ('buffered', 'skipped'):
            value.update(slot_role=1, item={**item('minecraft:charcoal'), 'tag': {'fixture': 'queued native data'}})
        else: value.update(slot_role=2, item=item('minecraft:bowl'))
    elif phase == 'buffered':
        external = index == 0
        value.update(buffered_units=73 if external else 125, batch={
            'definition': 'arce_adapter_test:large_fuel' if external else HOST + ':rocket_fuel_cell',
            'total_units': 1573 if external else 500,
            'remainder': item('minecraft:stick' if external else HOST + ':empty_canister')})
    else: value.update(slot_role=2, item=item('minecraft:stick' if index == 0 else HOST + ':empty_canister'))
    return value


def main():
    observation = {'scope': 'read-only actual artifacts and native four-cycle evidence; no server launched'}
    artifacts = {p.name: read(p) for p in (BASE / 'artifacts').glob('*.jar')}
    main_name = 'advancedrocketry-community-1.20.1-1.3.0-dev.jar'
    api_name = main_name[:-4] + '-api.jar'; sources_name = main_name[:-4] + '-sources.jar'
    fixture_name = 'arce-adapter-compat-test-1.0.0.jar'
    assert set(artifacts) == {main_name, api_name, sources_name, fixture_name}
    before = js(OUT / 'before.json')
    for name, raw in artifacts.items(): assert before['artifacts'][str(BASE / 'artifacts' / name)] == sha(raw)
    exports = {PREFIX + 'api/' + group + '/' + name + '.class' for group, names in {
        'version': ('ApiVersion', 'ApiCompatibility', 'ApiVersions'),
        'rocket': ('RocketBlockEntityAdapter', 'RocketAdapterRegistrar', 'RegisterRocketAdaptersEvent',
                   'RocketComponentDefinition', 'RocketComponentRegistrar', 'RegisterRocketComponentsEvent',
                   'RocketFuelDefinition', 'RocketFuelRegistrar', 'RegisterRocketFuelsEvent'),
        'atmosphere': ('AtmosphereBoundary', 'AtmosphereBoundaryProvider', 'AtmosphereBoundaryRegistrar',
                       'RegisterAtmosphereBoundariesEvent', 'SuitOxygenProvider', 'SuitEquipmentRegistrar', 'RegisterSuitEquipmentEvent')
    }.items() for name in names}
    with zipfile.ZipFile(io.BytesIO(artifacts[api_name])) as api, zipfile.ZipFile(io.BytesIO(artifacts[main_name])) as host:
        assert {n for n in api.namelist() if n.endswith('.class')} == exports
        for name in exports: assert api.read(name) == host.read(name)
        assert PREFIX + 'rocket/forge/RocketBlockEntityAdapter.class' in host.namelist()
    for name in (main_name, api_name, sources_name):
        with zipfile.ZipFile(io.BytesIO(artifacts[name])) as archive:
            assert len(archive.namelist()) == len(set(archive.namelist()))
            assert not any('arceadaptertest/' in n or n.startswith(('assets/arce_adapter_test/', 'data/arce_adapter_test/')) for n in archive.namelist())
    with zipfile.ZipFile(io.BytesIO(artifacts[sources_name])) as archive:
        for name in exports:
            source = name[:-6] + '.java'
            assert archive.read(source) == read(ROOT / 'src/main/java' / source)
    with zipfile.ZipFile(io.BytesIO(artifacts[fixture_name])) as archive:
        assert all(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in archive.namelist() if n.endswith('.class'))
        assert 'io/github/sunthemoon/arceadaptertest/FixtureRocketFuels.class' in archive.namelist()
    cp = js(BASE / 'consumer-reports/classpath.json')
    assert cp['requested_api'] == 'io.github.sunthemoon.advancedrocketrycommunity:advancedrocketry-community:1.20.1-1.3.0-dev:api'
    assert sha(read(cp['raw_api'])) == sha(artifacts[api_name]) == cp['published_sha256']
    assert sha(read(cp['remapped_api'])) == cp['remapped_sha256']
    host_dependencies = [x for x in cp['resolved_artifacts'] if x['group'] == 'io.github.sunthemoon.advancedrocketrycommunity']
    assert len(host_dependencies) == 1 and host_dependencies[0]['classifier'] == 'api'
    for source in cp['fixture_sources']: assert sha(read(source['file'])) == source['sha256']
    for entry in cp['compile_classpath']:
        path = entry['file']; normalized = path.replace('\\', '/')
        assert '/build/classes/' not in normalized and '/build/resources/' not in normalized
        assert not path.endswith((main_name, sources_name))
        raw = read(path, 128 * 1024**2); assert sha(raw) == entry['sha256']
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            found = {n for n in archive.namelist() if n.startswith(PREFIX) and n.endswith('.class')}
            assert found == (exports if path == cp['remapped_api'] else set())
    cache_input = Path('\\\\?\\' + cp['remapped_api'] + '.input').read_bytes()
    (OUT / 'consumer-mapped-api.input').write_bytes(cache_input)
    cache = dict(line.split('=', 1) for line in cache_input.decode().splitlines())
    assert cache['orig'] == hashlib.sha1(artifacts[api_name]).hexdigest()
    negative = js(BASE / 'consumer-reports/negative-import.json')
    assert negative['exit_code'] == 1 and negative['inspected_host_sha256'] == sha(artifacts[main_name])
    assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in negative['diagnostics']
    fixture = js(BASE / 'consumer-reports/fixture-artifact.json')
    assert fixture['sha256'] == sha(artifacts[fixture_name]) and fixture['reobfuscated'] is True
    observation['artifacts'] = {n: {'sha256': sha(v), 'bytes': len(v)} for n, v in artifacts.items()}
    observation['consumer'] = {'api_classes': sorted(exports), 'classpath_entries': len(cp['compile_classpath']),
                               'fixture_sources': len(cp['fixture_sources']), 'negative_exit': negative['exit_code'], 'mapped_cache_input': cache}

    evidence = BASE / 'runtime-evidence'; manifest = read(evidence / 'SHA256SUMS')
    named = set()
    for line in manifest.decode('ascii').splitlines():
        expected, name = line.split('  ', 1)
        assert name not in named and '..' not in Path(name).parts and not Path(name).is_absolute()
        assert sha(read(evidence / name)) == expected, name
        named.add(name)
    assert named == {p.relative_to(evidence).as_posix() for p in evidence.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    observation['manifest'] = {'files': len(named), 'sha256': sha(manifest)}
    preparation = js(BASE / 'libraries-preparation.json')
    for entry in preparation['files']: assert sha(read(BASE / 'server' / entry['path'], 128 * 1024**2)) == entry['sha256']
    observation['libraries_checked'] = len(preparation['files'])
    phases, states, seeds, game_times, configs = [], [], [], [], []
    for phase_index, phase in enumerate(PHASES):
        path = evidence / phase
        chunk = region._decode_chunk(region._region_chunk(read(path / 'world/region/r.0.0.mca'), 16, 16), 16, 16)
        entities = entity_chunk(path / 'world/entities/r.0.0.mca')['Entities']
        count = 1 if phase == 'buffered' else 2
        assert len(entities) == count and all(e['id'] == HOST + ':rocket' for e in entities)
        by_origin = {tuple(e['RocketEntityData']['snapshot']['source_origin']): e for e in entities}
        assert set(by_origin) == set(ORIGINS[:count])
        be = {tuple(b[k] for k in ('x', 'y', 'z')): b for b in chunk['block_entities']}
        assert len(be) == len(chunk['block_entities']) == 5 + count
        roots = []
        for index, pos in enumerate(LOADERS):
            assert be[pos]['id'] == HOST + ':fuel_loader' and block_at(chunk, pos)['Name'] == HOST + ':fuel_loader'
            value = be[pos]['arce_fuel_loader']; assert value == expected_loader(index, phase)
            roots.append(value)
        for pos in ((268, 102, 264), (270, 102, 270)):
            assert be[pos]['id'] == 'minecraft:hopper' and be[pos]['Items'] == []
        rocket_data, receipts = [], []
        for index, origin in enumerate(ORIGINS[:count]):
            entity = by_origin[origin]; data = entity['RocketEntityData']; snapshot = data['snapshot']; flight = data['flight_data']
            assert data['schema_version'] == 2 and snapshot['schema_version'] == 1 and flight['schema_version'] == 2
            assert data['owner_id'] == [0, 0, 0, 5] and data['assembly_transaction_id'] == flight['logical_rocket_id']
            assert entity['Pos'] == [origin[0] + 0.5, 101.0, origin[2] + 0.5]
            assert snapshot['source_dimension'] == 'minecraft:overworld' and snapshot['bounding_box'] == [-1, 0, 0, 1, 2, 0]
            assert snapshot['passenger_anchors'] == [[0, 1, 0]]
            actual = {}
            assert len(snapshot['relative_blocks']) == len(snapshot['block_palette']) == 5
            for block in snapshot['relative_blocks']:
                offset = tuple(block['position']); assert offset not in actual and 'block_entity' not in block
                palette = snapshot['block_palette'][block['palette']]; assert palette['properties'] == {}
                actual[offset] = palette['id']
            assert actual == PARTS and snapshot_hash(snapshot) == snapshot['content_hash']
            assert snapshot['mass_inputs'] == {'block_count': 5, 'mass': 254, 'thrust': 2400, 'fuel_capacity': 1500,
                                               'engine_count': 1, 'seat_count': 1, 'guidance_count': 1, 'block_entity_count': 0}
            amount = 1500 if index == 0 else 198 if phase == 'skipped' else 499
            assert flight['state'] == 'FUELED' and flight['fuel'] == {'capacity': 1500, 'amount': amount, 'committed_debits': []}
            assert flight['passengers'] == {'seat_capacity': 1, 'assignments': []}
            for offset in PARTS:
                pos = tuple(a + b for a, b in zip(origin, offset)); assert block_at(chunk, pos) == {'Name': 'minecraft:air'}
            assembler = (origin[0], origin[1] - 1, origin[2])
            assert be[assembler]['id'] == HOST + ':rocket_assembler' and block_at(chunk, assembler)['Name'] == HOST + ':rocket_assembler'
            if states and index < len(states[-1]):
                old = states[-1][index]
                assert entity['UUID'] == old['UUID'] and snapshot == old['RocketEntityData']['snapshot']
                assert data['assembly_transaction_id'] == old['RocketEntityData']['assembly_transaction_id']
                if index == 0 or phase == 'restart': assert data == old['RocketEntityData']
            rocket_data.append(entity); receipts.append([snapshot['content_hash'], uuid_array(entity['UUID'])])
        journal = gzip_nbt(path / ('world/data/' + HOST + '_rocket_transactions.dat'))
        assert journal['data']['transactions'] == []
        level = gzip_nbt(path / 'world/level.dat', level=True)['Data']
        seeds.append(level['WorldGenSettings']['seed']); game_times.append(level['Time'])
        result = js(path / 'result.json'); assert result['exit_code'] == 0 and result['receipts'] == receipts
        launch = js(path / 'launch.json'); assert launch['mods'] == {n: sha(artifacts[n]) for n in (main_name, fixture_name)}
        assert ('-Darce_adapter_test.skipRocketFuels=true' in launch['command']) == (phase == 'skipped')
        assert ('-Darce_adapter_test.fuelVariant=updated' in launch['command']) == (phase_index >= 2)
        status = js(path / 'status.json')
        mods = protocol.forge_mod_versions(status)
        # Forge's compressed status entry has an empty version; bind its actual
        # version separately from native startup logs and prepared library bytes.
        assert mods == {HOST: '1.20.1-1.3.0-dev', 'arce_adapter_test': '1.0.0', 'minecraft': '1.20.1', 'forge': ''}
        assert status['players']['online'] == 0 and status['version']['protocol'] == 763
        commands = js(path / 'commands.json'); assert commands[-2:] == ['save-all flush', 'stop']
        assert sum('minecraft:hopper{Items:' in c for c in commands) == (2 if phase_index == 0 else 0)
        assert sum('schema_version:1' in c for c in commands) == (3 if phase_index == 0 else 0)
        assert not any(c.startswith(('data merge ', 'data modify ', 'summon ', 'kill ')) for c in commands)
        assert not any('release-test' in c or c.startswith('give ') for c in commands)
        if phase_index > 0:
            assert not any(c.startswith('setblock ') and (':fuel_loader' in c or ':hopper' in c) for c in commands)
        logs = {}
        registration = 'Skipped rocket fuels (event 1)' if phase == 'skipped' else 'Registered rocket fuels (variant ' + ('updated' if phase_index >= 2 else 'standard') + ', API 1.5, event 1)'
        for name in ('stdout.txt', 'latest.log', 'debug.log'):
            text = read(path / name).decode('utf-8'); lines = text.splitlines()
            errors = [s for s in lines if re.search(r'/(?:ERROR|FATAL)\]|\b(?:NoClassDefFoundError|NoSuchMethodError|AbstractMethodError|VerifyError|LinkageError)\b', s)]
            assert not errors, (phase, name, errors)
            assert '47.4.10' in text
            event_lines = [s for s in lines if 'Registered rocket fuels ' in s or 'Skipped rocket fuels ' in s]
            assert len(event_lines) == 1 and event_lines[0].endswith(registration)
            ticks = [int(v) for v in re.findall(r'The time is (\d+)', text)]
            assert ticks[-1] - ticks[0] == result['observation_ticks'] and ticks[-1] - ticks[0] >= 20
            assert 'V130_FUEL_' + phase + '_FIRST' in text and 'V130_FUEL_' + phase + '_SECOND' in text
            assert 'Stopping server' in text and 'All dimensions are saved' in text
            assemblies = re.findall(r'ARCE_ROCKET_TRANSACTION operation=assembly code=SUCCESS blocks=5 snapshot=([0-9a-f]{64}) entity=([0-9a-f-]{36})', text)
            assert assemblies == ([tuple(receipts[-1])] if phase_index < 2 else [])
            logs[name] = {'lines': len(lines), 'errors': errors, 'warnings': [s for s in lines if '/WARN]' in s], 'tick_queries': ticks}
        config = {}
        for relative in ('server.properties', 'config/advancedrocketrycommunity-common.toml', 'config/fml.toml'):
            raw = read(path / relative, 65536)
            if relative == 'server.properties':
                lines = raw.splitlines(keepends=True)
                assert lines[0].rstrip(b'\r\n') == b'#Minecraft server properties'
                assert re.fullmatch(rb'#(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) [A-Z][a-z]{2} +[0-9]{1,2} [0-9:]{8} [A-Za-z0-9_+:/-]+ [0-9]{4}', lines[1].rstrip(b'\r\n'))
                config[relative] = sha(b''.join(lines[:1] + lines[2:]))
                values = dict(line.decode().split('=', 1) for line in lines if b'=' in line and not line.startswith(b'#'))
                assert values['server-ip'].strip() == '127.0.0.1' and values['online-mode'].strip() == 'false'
            else: config[relative] = sha(raw)
        configs.append(config); states.append(rocket_data)
        phases.append({'phase': phase, 'exit_code': result['exit_code'], 'observation_ticks': result['observation_ticks'],
                       'seed': seeds[-1], 'game_time': game_times[-1], 'loader_roots': roots,
                       'rockets': [{'entity_uuid': r[1], 'snapshot_hash': r[0], 'fuel': e['RocketEntityData']['flight_data']['fuel']['amount']}
                                   for r, e in zip(receipts, rocket_data)], 'journal_entries': 0, 'logs': logs, 'status_mods': mods})
    assert len(set(seeds)) == 1 and game_times == sorted(set(game_times))
    assert all(config == configs[0] for config in configs)
    observation['phases'] = phases
    observation['resource_checks'] = {'captured_units': 1573, 'first_rocket': 1500, 'captured_remainder_units': 73,
                                       'synthetic_legacy_remaining': 125, 'second_without_registration': 198,
                                       'changed_unconsumed_input_units': 301, 'second_final': 499}
    (OUT / 'native-artifact-observations.json').write_text(json.dumps(observation, indent=2) + '\n', encoding='utf-8')
    print('PASS: 19 API exports; 114 classpath entries; four raw native phases; exact loader/fuel and provenance assertions')
    print(json.dumps({'manifest': observation['manifest'], 'phases': [{k: p[k] for k in ('phase','exit_code','observation_ticks','game_time','rockets')} for p in phases]}, indent=2))


if __name__ == '__main__': main()
