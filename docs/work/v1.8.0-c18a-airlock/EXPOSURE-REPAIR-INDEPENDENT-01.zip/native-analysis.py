from collections import Counter
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
log = root / 'candidate-02/build/gametest/logs/latest.log'
lines = log.read_text('utf-8').splitlines()
groups = Counter()
contexts = []
for index, line in enumerate(lines):
    if 'ERROR]' not in line:
        continue
    message = line.split(']: ', 1)[-1]
    if message.startswith('Failed to save chunk '):
        group = 'Failed to save chunk (coordinates omitted)'
    elif message.startswith('Channels '):
        group = 'Machine-menu protocol version rejection'
    elif message.startswith('Disabling machine recipe '):
        group = 'Machine recipe with no bound tag alternatives'
    elif 'migration port marker roots' in message:
        group = 'Precision migration port marker disk-root mismatch'
    elif 'migration controller snapshot roots' in message:
        group = 'Precision migration controller disk-root mismatch'
    else:
        group = message
    groups[group] += 1
    contexts.append({'line': index + 1, 'header': line,
                     'following': lines[index + 1:index + 20]})
batches = []
for index, line in enumerate(lines):
    match = re.search(r"Running test batch '([^']+)' \((\d+) tests\)", line)
    if match:
        batches.append({'line': index + 1, 'name': match.group(1), 'count': int(match.group(2))})
summary = {'error_headers': sum(groups.values()), 'fatal_headers': sum('FATAL]' in line for line in lines),
           'error_groups': dict(groups), 'batches': batches,
           'batch_total': sum(batch['count'] for batch in batches),
           'terminal_lines': [line for line in lines if 'required tests passed' in line or 'tests failed' in line],
           'failure_headers': [line for line in lines if 'Required test' in line],
           'error_contexts': contexts}
(root / 'native-analysis.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in summary.items() if key != 'error_contexts'}, indent=2))
