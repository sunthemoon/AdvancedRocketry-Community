import hashlib
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS.txt'
assert not manifest.exists(), 'Do not overwrite a sealed packet'
excluded = {'candidate', 'candidate-02', 'temp', 'execution-02/temp'}
files = []
for directory, names, leaf_names in os.walk(root):
    parent = Path(directory)
    names[:] = [name for name in names if (parent / name).relative_to(root).as_posix() not in excluded]
    for name in leaf_names:
        path = parent / name
        assert not path.is_symlink()
        files.append(path)
files.sort(key=lambda path: path.relative_to(root).as_posix())
total = sum(path.stat().st_size for path in files)
assert total < 100 * 1024 ** 2, 'Retained evidence exceeds budget'
assert all(path.stat().st_size < 50 * 1024 ** 2 for path in files)
rows = []
for path in files:
    relative = path.relative_to(root).as_posix()
    assert relative not in excluded and not relative.startswith(('candidate/', 'candidate-02/', 'temp/', 'execution-02/temp/'))
    rows.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + relative)
manifest.write_text('\n'.join(rows) + '\n', encoding='utf-8')
for row in manifest.read_text('utf-8').splitlines():
    expected, relative = row.split('  ', 1)
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected
print(json.dumps({'sealed_files': len(files), 'retained_bytes': total,
                  'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
                  'excluded_disposable_output': sorted(excluded)}, indent=2))
