# Independent C18a atmosphere-exposure source review

Date: 2026-10-08. Reviewer: delegated read-only Codex worker. Implementation,
integration, product acceptance and version Gate approval are not reviewer duties.

## Findings

No introduced Critical, High, Medium or Low finding was identified in the actual
three-file candidate diff. Source review is complete; Root's main HEAD was
released after the exact-candidate build and native execution completed.

There are two retained verification/housekeeping limitations, not new source
findings: strict repository validation fails inherited evidence links, and the
tool rejected owned cleanup before execution. Neither is counted as passing.

## Checked identity and scope

- Base commit: `4bc59ed692deef5ec48c6e0756fd162aed8653dc`.
- Base tree: `0609546507c5ea06e455fc2147cfd4e07ad918ba`.
- Candidate commit: `23bcb6b141da88a7a9548c2aa8f3de5438a09e68`.
- Candidate tree: `98adb01b6118992463d314dead0741c99fe75812`.
- Candidate source tree: `cc2d92e033bd3952f7fda703f1e096be0e883908`.
- Runtime JAR SHA-256: `d87c90e394c13b54382d6496f2c15709b7df06444dad9e8321e92d6b10b9cea1`.

Read the live main AGENTS.md, its ten mandatory governance files applicable to
v1.8/parallel review, current Gate records, ADR-060 and the candidate repair task,
plus the airlock leaf/task and adjacent scanner, service and native tests.
The actual change is confined to the repair task, one existing server adapter
and one new native-test class. It adds no registry, schema, protocol, asset,
equipment, save-writer or future-version implementation. Original airlock tests,
scanner and limits compare identically to base. No existing checkout was edited,
staged, committed, switched or merged, and no further agent was delegated.

## Behavior, bounds and lifecycle assessment

The [server adapter](D:/GitHub/arce-v180-atmosphere-exposure-20261008/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/server/ServerLevelVolumeWorldView.java#L92)
removes only the skylight-based early OPEN decision. Loaded/build-height guards
and the native heightmap check remain. Door, sealing/permeable tags, external
providers, fluids and collision classification are unchanged. World-read and
scan limits remain unchanged: no new traversal, ticket, synchronous flood fill
or client authority is added.

Independent `javap -c -p` inspection of the pinned mapped Forge JAR confirms
that canSeeSky compares SKY light with maximum light, Level.getHeight checks
chunk availability, and LevelChunk.setBlockState updates
MOTION_BLOCKING_NO_LEAVES during the native write. The inspected JAR hashes to
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
The native regressions independently demonstrate glass/full-skylight sealing,
immediate opaque-roof closure, immediate roof/side leaks and disabled sky policy.
This proves the reproduced classification defect, not the cause of an earlier
historical installed-airlock scan.

The [new fixture](D:/GitHub/arce-v180-atmosphere-exposure-20261008/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereExposureGameTests.java#L95)
owns at most 27 loaded, BE-free cells and preserves their prior BlockStates.
Its terminal listener restores success/failure/timeout, constructor failures
attempt restoration, and restoration attempts every retained cell while
preserving a primary failure. It mutates no light-engine state and creates no
forced-chunk ownership, global config override or replacement authority.
Intentional timeout/failure injection of this new fixture was not separately run;
those branches were source/API-reviewed rather than claimed as executed proof.

## Commands actually executed and results

Corrected execution uses a fresh detached exact-candidate local clone, Oracle
Java 17.0.7, Gradle 8.8 and Forge 47.4.10. C: and D: were above 10 GiB before
every command; observed minima were approximately 28.62 GiB and 282.14 GiB.
TEMP/TMP/TMPDIR and java.io.tmpdir were task-local. Existing offline Gradle
caches were used; no network, installation or global configuration change ran.

| Command | Exit | Actual outcome |
|---|---:|---|
| `gradlew.bat clean build --no-daemon --offline` | 0 | Build and actual `:test` execution passed. |
| `gradlew.bat runGameTestServer --no-daemon --offline` | 0 | All 546 required tests passed; 546 batch subjects counted independently. |
| `gradlew.bat runData --no-daemon --offline`, twice | 0 / 0 | Both native data runs completed. |
| `git diff --exit-code`, after each data run | 0 / 0 | No tracked generated diff; final full status also clean. |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | 0 | Accepted-ledger validation completed. |
| `python -B scripts/validate_bootstrap_provenance.py` | 0 | Bootstrap provenance validation completed. |
| `python -B scripts/validate_repository.py --require-approved-identity` | 1 | 44 passed, 1 failed; inherited Markdown evidence links fail. |
| Candidate diff whitespace / unchanged inherited source comparisons | 0 / 0 | Scope, whitespace and inherited assertions/budgets preserved. |
| Owned cleanup | No process exit | Rejected before execution; no retry. |

JUnit evidence contains 378 XML suites and exactly 2,179 testcase nodes:
2,179 tests, zero failures, errors or skips. Standalone `gradlew test` was not
invoked separately; clean build did execute the complete test task. Native
logs show four atmosphere-exposure and seven unchanged airlock subjects, zero
required failure headers and the terminal `All 546 required tests passed` marker.
The default native command generated no XML; complete latest/debug/console logs
and counted batches are retained instead.

Native latest.log has 62 ERROR headers and zero FATAL headers, not zero errors.
Their retained groups cover five intentional migration failures with five paired
chunk-save errors and three disk-root mismatches; three empty-tag recipe
bindings; four satellite durability/blocked-registry negative calls; sixteen
incompatible menu-channel versions; and twenty-six recipe/combustion/solar save
refusals. Source and stack contexts identify the negative fixtures; the detailed
counts/contexts are in `native-analysis.json`. No exposure or airlock test failed.
These short controlled tests do not approve production save-refusal policy.

Strict validation's single failing category stops after 256 missing or unsafe
Markdown targets, including uncommitted evidence archives and external packet
links. All listed affected document paths are inherited rather than changed by
this candidate. Full failure logs are retained; validation is still FAILED,
not excused into PASS.

The initial launcher cohort is also retained: four Gradle attempts exited 1
before Java/Gradle startup because the Python cmd.exe path used forward slashes.
It executed zero unit/native tests. A separate fresh clone and corrected native
cmd.exe path produced the results above. Initial strict validation independently
also ended 44 passed / 1 failed. Windows historical long-path checkout omissions
were restored only in the owned first clone using command-local core.longpaths;
both tested snapshots ended pin-unchanged and clean. No failed cohort is discarded.

## Evidence, cleanup and remaining obligations

Retained evidence: `candidate.diff`, commit/tree identities, complete command
records and logs for both cohorts, all 378 JUnit XML files in `unit-xml.zip`,
native console/latest/debug logs, batch/error analysis, primary API bytecode,
artifact hashes, cleanup inventory/refusal and this report. SHA256SUMS.txt seals
only these retained files; it does not reference build/ or Temp files.

Cleanup containment/process/reparse checks passed, but the single native
PowerShell deletion attempt was blocked before process creation. Own fresh
clone/build/server/temp outputs totaling 1,355,597,504 logical bytes remain;
`cleanup-refusal.md` records the four excluded directories. The allocated working
directory therefore exceeds the 100 MB evidence-directory budget while cleanup
debt remains, although the compact retained/checksummed payload is below 100 MB.
No input world, earlier evidence, existing worktree or other process was removed.

Unverified scope: independently rerunning pre-repair negatives, packaged/restart
or crash recovery, real survival clients, V1/V2, full progression, release
performance and inherited G0-G9 acceptance. No schema/client/persistence change
was introduced, but those broader obligations are not closed by short checks.
No version status, delivery ledger, Gate, tag or release approval is granted.
Next action is the current v1.8 slice's integration/evidence disposition and
remaining acceptance work, including inherited link and cleanup debt.
