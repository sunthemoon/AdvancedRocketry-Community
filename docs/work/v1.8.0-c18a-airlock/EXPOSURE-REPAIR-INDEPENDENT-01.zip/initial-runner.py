import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / 'candidate'
JDK = Path('C:/Program Files/Java/jdk-17.0.7')
PIN = '23bcb6b141da88a7a9548c2aa8f3de5438a09e68'
BASE = '4bc59ed692deef5ec48c6e0756fd162aed8653dc'
TEMP = ROOT / 'temp'
TEMP.mkdir(exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.longpaths=true', '--no-optional-locks',
                                    '-C', str(TREE), *args]).decode('utf-8')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

assert git('rev-parse', 'HEAD').strip() == PIN
assert not git('status', '--porcelain')
identities = {'base_commit': BASE, 'candidate_commit': PIN,
              'base_tree': git('rev-parse', BASE + '^{tree}').strip(),
              'candidate_tree': git('rev-parse', 'HEAD^{tree}').strip(),
              'source_tree': git('rev-parse', 'HEAD:src').strip(),
              'changed_paths': git('diff', '--name-status', BASE, PIN).splitlines()}
(ROOT / 'identities.json').write_text(json.dumps(identities, indent=2), encoding='utf-8')
(ROOT / 'candidate.diff').write_text(git('diff', '--no-ext-diff', '--unified=5', BASE, PIN), encoding='utf-8')
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + os.environ['PATH'],
           TEMP=str(TEMP), TMP=str(TEMP), TMPDIR=str(TEMP), PYTHONDONTWRITEBYTECODE='1',
           JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + TEMP.as_posix())
gradle = ['C:/Windows/System32/cmd.exe', '/d', '/c', 'gradlew.bat']
git_base = ['git', '-c', 'core.longpaths=true', '--no-optional-locks']
commands = [
    ('java', [str(JDK / 'bin/java.exe'), '-version']),
    ('build', gradle + ['clean', 'build', '--no-daemon', '--offline']),
    ('native', gradle + ['runGameTestServer', '--no-daemon', '--offline']),
    ('data-1', gradle + ['runData', '--no-daemon', '--offline']),
    ('data-1-diff', git_base + ['diff', '--exit-code']),
    ('data-2', gradle + ['runData', '--no-daemon', '--offline']),
    ('data-2-diff', git_base + ['diff', '--exit-code']),
    ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('provenance', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py']),
    ('repository', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
    ('whitespace', git_base + ['diff', '--check']),
]
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ['C:/', 'D:/']}
    if any(value <= 10 * 1024 ** 3 for value in free.values()):
        raise RuntimeError('Disk threshold not met: ' + json.dumps(free))
    log = ROOT / (name + '.log')
    started = now()
    print(json.dumps({'starting': name, 'utc': started, 'free_bytes': free}), flush=True)
    with log.open('xb') as output:
        result = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                stdout=output, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    record = {'name': name, 'argv': argv, 'cwd': str(TREE), 'source': PIN,
              'started_utc': started, 'ended_utc': now(), 'free_bytes': free,
              'exit_code': result.returncode, 'bytes': log.stat().st_size, 'sha256': sha(log)}
    records.append(record)
    (ROOT / 'commands.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)

totals = dict(tests=0, failures=0, errors=0, skipped=0)
actual = 0
files = sorted((TREE / 'build/test-results/test').glob('TEST-*.xml'))
with zipfile.ZipFile(ROOT / 'unit-xml.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        suite = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(suite.get(key, '0'))
        actual += len(suite.findall('testcase'))
        archive.write(path, path.name)
native_dir = TREE / 'build/gametest'
native_text = ''
if (native_dir / 'logs/latest.log').is_file():
    shutil.copy2(native_dir / 'logs/latest.log', ROOT / 'native-latest.log')
    native_text = (ROOT / 'native-latest.log').read_text('utf-8', errors='replace')
if (native_dir / 'logs/debug.log').is_file():
    shutil.copy2(native_dir / 'logs/debug.log', ROOT / 'native-debug.log')
native_results = [path for path in native_dir.rglob('*.xml') if 'world' not in path.parts]
with zipfile.ZipFile(ROOT / 'native-xml.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in native_results:
        archive.write(path, path.relative_to(native_dir).as_posix())
summary = dict(identities, commands=records, unit_suites=len(files), unit_totals=totals,
               actual_testcase_nodes=actual, native_xml_files=len(native_results),
               native_error_headers=sum('ERROR]' in line for line in native_text.splitlines()),
               native_fatal_headers=sum('FATAL]' in line for line in native_text.splitlines()),
               native_terminal_lines=[line for line in native_text.splitlines()
                   if re.search(r'tests done|tests failed|Required test|All \d+ required tests passed', line)],
               head_unchanged=git('rev-parse', 'HEAD').strip() == PIN,
               clean=not git('status', '--porcelain'),
               artifacts={path.name:sha(path) for path in (TREE / 'build/libs').glob('*.jar')})
(ROOT / 'results.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if all(record['exit_code'] == 0 for record in records) and summary['head_unchanged']
                 and summary['clean'] else 1)
