# Owned cleanup refusal

Date: 2026-10-08. The one cleanup command was rejected by the command tool
before PowerShell process creation: `Rejected(... rejected: blocked by policy)`.
There is no operating-system exit code and no deletion was executed.

The attempted command used only PowerShell end-to-end. It rechecked each
resolved absolute target against the exact permitted evidence directory, then
called `Remove-Item -LiteralPath $targets -Recurse -Force -ErrorAction Stop`.
The four targets are recorded in `cleanup-inventory.json`:

- `candidate`: 9,867 files, 541,011,035 bytes.
- `candidate-02`: 15,414 files, 814,351,461 bytes.
- `temp`: zero files.
- `execution-02/temp`: two files, 235,008 bytes.

All four targets were freshly created by this reviewer inside the sole allowed
write scope. Prechecks found zero reparse points and zero running task Java or
Python processes. Complete results, JUnit XML and native logs were retained
before the attempt. Total remaining disposable-output debt is 1,355,597,504
logical bytes. No source/input world, existing checkout or sealed evidence was
targeted. No retry, alternate shell or deletion helper is attempted.

The final checksum manifest seals retained review evidence only. The four
explicitly listed disposable-output directories are excluded from that manifest;
they are neither accepted delivery evidence nor a separately sealed packet.
