import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

TREE = Path('D:/GitHub/arce-v180-atmosphere-exposure-20261008')
ROOT = Path(__file__).resolve().parent
JDK = Path('C:/Program Files/Java/jdk-17.0.7')
stage = sys.argv[1]
assert stage in ('baseline', 'baseline-2', 'repair', 'repeat')
leaf = ROOT / stage
leaf.mkdir()
temp = leaf / 'temp'
temp.mkdir()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(TREE), *args]).decode('utf-8')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

source = git('rev-parse', 'HEAD').strip()
assert not git('status', '--porcelain')
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + os.environ['PATH'],
           TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONDONTWRITEBYTECODE='1',
           JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + temp.as_posix())
base = [str(Path('C:/Windows/System32/cmd.exe')), '/d', '/c', 'gradlew.bat']
commands = [('native', base + ['runGameTestServer', '--no-daemon', '--offline'])]
if stage == 'repair':
    commands = [
        ('java', [str(JDK / 'bin/java.exe'), '-version']),
        ('build', base + ['clean', 'build', '--no-daemon', '--offline']),
        ('data-1', base + ['runData', '--no-daemon', '--offline']),
        ('data-1-diff', ['git', '--no-optional-locks', 'diff', '--exit-code']),
        ('data-2', base + ['runData', '--no-daemon', '--offline']),
        ('data-2-diff', ['git', '--no-optional-locks', 'diff', '--exit-code']),
        ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
        ('provenance', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py']),
        ('repository', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
        ('whitespace', ['git', '--no-optional-locks', 'diff', '--check']),
    ] + commands
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ['C:/', 'D:/']}
    assert all(value >= 10 * 1024 ** 3 for value in free.values()), free
    started = now()
    print(json.dumps(dict(starting=name, source=source, utc=started)), flush=True)
    log = leaf / (name + '.log')
    with log.open('xb') as output:
        result = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                stdout=output, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    record = dict(name=name, argv=argv, source=source, cwd=str(TREE), started_utc=started,
                  ended_utc=now(), free_bytes=free, exit_code=result.returncode,
                  log_sha256=sha(log), bytes=log.stat().st_size)
    records.append(record)
    (leaf / 'commands.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)
    if name in ('build', 'data-1', 'data-2') and result.returncode:
        break

totals = dict(tests=0, failures=0, errors=0, skipped=0)
actual = 0
files = sorted((TREE / 'build/test-results/test').glob('TEST-*.xml')) if stage == 'repair' else []
with zipfile.ZipFile(leaf / 'unit-xml.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        suite = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(suite.get(key, '0'))
        actual += len(suite.findall('testcase'))
        archive.write(path, path.name)
native = TREE / 'build/gametest/logs/latest.log'
native_text = ''
if any(record['name'] == 'native' for record in records) and native.is_file():
    shutil.copy2(native, leaf / 'native-latest.log')
    native_text = native.read_text('utf-8', errors='replace')
summary = dict(source=source, src_tree=git('rev-parse', 'HEAD:src').strip(), commands=records,
               unit_suites=len(files), unit_totals=totals, actual_testcase_nodes=actual,
               native_error_headers=sum('ERROR]' in line for line in native_text.splitlines()),
               native_fatal_headers=sum('FATAL]' in line for line in native_text.splitlines()),
               native_terminal_lines=[line for line in native_text.splitlines()
                   if 'tests done' in line or 'tests failed' in line or 'Required test' in line
                   or 'All required tests passed' in line],
               head_unchanged=git('rev-parse', 'HEAD').strip() == source,
               clean=not git('status', '--porcelain'),
               artifacts={path.name:sha(path) for path in (TREE / 'build/libs').glob('*.jar')})
(leaf / 'results.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if all(record['exit_code'] == 0 for record in records) and summary['head_unchanged']
                 and summary['clean'] else 1)
