# C18a-AIRLOCK-EXPOSURE-01 Root verification

Date: 2026-10-08. Development verification, not version acceptance.

## Scope and source identity

Base `4bc59ed692deef5ec48c6e0756fd162aed8653dc`; regression-only commit
`369fc1c6907f875d90c26aaddbe49cb516712100`; repaired/tested commit
`23bcb6b141da88a7a9548c2aa8f3de5438a09e68`. Root integrates and normally pushes
the unchanged source at `ee77c51aef7613753a85a156a84cd817adfb2529` after independent
source review release. Complete src tree `cc2d92e033bd3952f7fda703f1e096be0e883908`
and all seven named Gradle inputs are equal between tested and integrated
commits. This equality is not a rerun or rebinding of the command commit.

The only production change removes sky-light-based `canSeeSky` as an OPEN
shortcut from ServerLevelVolumeWorldView. Its existing native loaded-chunk
heightmap shortcut and bounded boundary scan remain. Native bytecode shows
canSeeSky reads SKY brightness, not roof geometry. No registry, NBT/schema,
network, configuration, resource, save policy or scan limit changes. No upstream
code/art is copied. Root adds four native regressions and one task document.

## Actual red and green results

First baseline launcher exits 1 before Java/native startup with a CMD syntax
error caused by the forward-slash executable spelling. It is retained in
`baseline/`; it is not a product-test result. The launcher is corrected to a
native Windows executable path only; `baseline-2/` is a distinct invocation.

At regression-only commit 369fc1c6, full native command exits 1: 546 tests
complete, two required failures, both new regressions. Transparent enclosed
roof and newly closed opaque roof scans each incorrectly return OPEN after
one inspection despite the asserted current roof height. The other two new
regressions and unchanged airlock batch have no terminal failure. Raw logs
retain 64 ERROR headers, zero FATAL.

At fixed commit 23bcb6b1, actual commands are in `repair/commands.json`:

| Command | Exit/result |
| --- | --- |
| Java 17.0.7 version | 0 |
| gradlew.bat clean build --no-daemon --offline | 0; 378 XML suites / 2,179 actual testcase nodes, zero F/E/S |
| gradlew.bat runData --no-daemon --offline, twice | 0 / 0 |
| git diff --exit-code after each DataGen | 0 / 0; empty diffs |
| validate_v180_content_ledger.py --require-accepted | 0; unchanged 186 PLANNED / 154 REVIEW assets |
| validate_bootstrap_provenance.py | 0 |
| validate_repository.py --require-approved-identity | 1; 44 passed / one Markdown-link failure |
| git diff --check | 0 |
| gradlew.bat runGameTestServer --no-daemon --offline | 0; all 546 required tests pass |

The native log records `atmosphere_exposure:1` with four tests and `airlock:1`
with seven, followed by the 546-test terminal pass. New tests cover transparent
enclosure, immediate opaque-roof closure, immediate roof/side leakage and
disabled sky shortcut with bounded geometric scanning. Original airlock tests,
40/20-tick deadlines, 32/8 service loops, coordinator and all limits are
byte-identical to base; `derived-results.json` pins those inputs.

The repair native log has 62 ERROR headers and zero FATAL. These remain
unwaived; a test pass is not an error-free log or version Gate pass. Strict-link
failure is retained, not suppressed. The runner exits 1 overall because that
validation fails, even though build/DataGen/JUnit/GameTest commands succeed.

The original collector's native_terminal_lines field misses uppercase terminal
text. Its original results remain intact. The separate `audit.py` parses complete
raw logs into `derived-results.json`, retaining exact terminal lines/counts,
failure names and log hashes. No original command is rerun by this audit.

## Independent verification

Delegated read-only Codex task `/root/exposure_review` uses its own exact
candidate clone under
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/atmosphere-exposure-independent-20261008-01`.
It releases main HEAD after completing actual-source review without an
introduced C/H/M/Low finding, and reports separate clean build / 2,179 JUnit,
546 required native tests and twice clean DataGen executions. Final packet
validation, direct Root inspection and sealing are recorded separately in the
repository verification record; no Claude is called.

## Artifact and evidence boundaries

Root repaired main JAR SHA-256:
`d87c90e394c13b54382d6496f2c15709b7df06444dad9e8321e92d6b10b9cea1`.
API JAR SHA-256:
`aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
These are development artifacts, not a packaged S1, candidate or release.

The manifest seals only listed payloads: complete command/native logs, command
and result JSON, emitted XML archive, scripts, primary inspection, patch and
report. Temporary outputs are not evidence and are excluded. No whole source
tree or player world is archived. Each payload and the aggregate are below
repository evidence size limits.

## Cleanup and residual risks

Root cleanup is rejected before execution, with no bypass/retry. A separate
read-only inventory records retained own output: build 265,523,880 logical
bytes, project-local .gradle 6,077,097 bytes, run-data 127,195 bytes (5,512 files,
271,728,172 bytes total). This is retained logical data, not physical space
reclaimed; task TEMP/source also remain. Other agents, old refused cleanup,
global caches, sealed records and input/prior worlds are untouched.

Historical e91ddc16 and other airlock failures are not individually traced at
scan time. The unchanged installed test also passed in this new pre-repair
cohort, so this repair must not be presented as unique attribution of every
historical failure or proof of permanent removal of all timing failures.
It removes a demonstrated incorrect sky-light branch and adds reproducible
regressions; no original failure packet is rewritten.

Packaged/restart, prior-world migration, natural installed continuation, real
V1/V2, performance, provenance/content closure and complete progression remain
unfinished. R-021 and the physical hatch/save writer prerequisites remain open.
v1.8 remains IN_PROGRESS and no Required Gate is approved. Continue the
canonical C16-C19 implementation; the full objective is not reduced to this fix.
