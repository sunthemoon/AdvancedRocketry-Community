import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
TREE = Path('D:/GitHub/arce-v180-atmosphere-exposure-20261008')
BASE = '4bc59ed692deef5ec48c6e0756fd162aed8653dc'
SOURCE = '23bcb6b141da88a7a9548c2aa8f3de5438a09e68'

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(TREE), *args])

def digest(data):
    return hashlib.sha256(data).hexdigest()

native = {}
for stage in ['baseline-2', 'repair']:
    path = ROOT / stage / 'native-latest.log'
    text = path.read_text('utf-8')
    complete = re.findall(r'(\d+) GAME TESTS COMPLETE', text)
    passed = re.findall(r'All (\d+) required tests passed', text)
    failed = re.findall(r'(\d+) required tests failed', text)
    native[stage] = dict(log_sha256=digest(path.read_bytes()),
        complete=[int(value) for value in complete],
        required_passed=[int(value) for value in passed],
        required_failed=[int(value) for value in failed],
        test_failure_lines=[line for line in text.splitlines() if 'LogTestReporter/' in line and 'failed!' in line],
        selected_batch_lines=[line for line in text.splitlines()
            if 'Running test batch' in line and any(batch in line for batch in ['atmosphere_exposure:', 'airlock:'])],
        errors=sum('ERROR]' in line for line in text.splitlines()),
        fatals=sum('FATAL]' in line for line in text.splitlines()))

package = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
paths = [package + name for name in [
    'atmosphere/server/ServerLevelVolumeWorldView.java',
    'gametest/AtmosphereExposureGameTests.java',
    'gametest/AirlockDoorGameTests.java',
    'atmosphere/scan/VolumeScanTask.java',
    'atmosphere/scan/VolumeScanCoordinator.java',
    'atmosphere/AtmosphereLimits.java',
]] + ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
      'gradle/wrapper/gradle-wrapper.properties', 'gradle/wrapper/gradle-wrapper.jar']
hashes = []
for path in paths:
    data = git('show', SOURCE + ':' + path)
    before = None if path.endswith('AtmosphereExposureGameTests.java') else git('show', BASE + ':' + path)
    hashes.append(dict(path=path, sha256=digest(data), base_sha256=None if before is None else digest(before),
                       unchanged_from_base=before == data))
outcome = dict(base=BASE, source=SOURCE, src_tree=git('rev-parse', SOURCE + ':src').decode().strip(),
               native=native, inputs=hashes,
               interpretation='Fresh native cohorts only; not unique attribution of historical failures or Gate approval.')
(ROOT / 'derived-results.json').write_text(json.dumps(outcome, indent=2), encoding='utf-8')
(ROOT / 'source.patch').write_bytes(git('diff', '--binary', BASE, SOURCE))
print(json.dumps(dict(native=native, source=SOURCE), indent=2))
