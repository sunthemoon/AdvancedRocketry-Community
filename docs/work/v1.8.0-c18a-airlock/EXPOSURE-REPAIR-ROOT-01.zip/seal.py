import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS.txt'
assert not manifest.exists(), 'Sealed evidence must not be overwritten'
files = sorted(path for path in root.rglob('*') if path.is_file()
               and 'temp' not in path.relative_to(root).parts and path != manifest)
assert files and all(path.stat().st_size <= 50 * 1024 * 1024 for path in files)
assert sum(path.stat().st_size for path in files) <= 100 * 1024 * 1024
lines = [hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.relative_to(root).as_posix()
         for path in files]
manifest.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('payloads', len(files), 'bytes', sum(path.stat().st_size for path in files))
print('report_sha256', hashlib.sha256((root / 'REPORT.md').read_bytes()).hexdigest())
print('manifest_sha256', hashlib.sha256(manifest.read_bytes()).hexdigest())
