# Independent C18a-AIRLOCK-EXPOSURE-01 review

You are a delegated, read-only Codex review worker, not Root. Do not delegate
further or use Claude. Root implements and owns integration; this task is an
independent actual-diff review and verification.

Repository: `D:/GitHub/AdvancedRocketry-Community`.
Base commit: `4bc59ed692deef5ec48c6e0756fd162aed8653dc`.
Candidate commit: `23bcb6b141da88a7a9548c2aa8f3de5438a09e68`.
Candidate checkout: `D:/GitHub/arce-v180-atmosphere-exposure-20261008`.
Compare the actual three changed files, read their task contract and relevant
adjacent code/tests. Read the live main AGENTS.md and its mandatory governance
files; the version file is
`docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`. Check scope, behavior,
world-read bounds, native fixture validity, lifecycle cleanup and regression
coverage. Determine findings from source and execution, not Root's narration.

## Permissions and isolation

All existing checkouts and sealed packets are read-only. Do not modify, stage,
commit, switch or merge existing branches. Your only write_scope is NEW
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/atmosphere-exposure-independent-20261008-01/`.
Create your own exact candidate clone/snapshot there, and run checks only there.
Git cloning/inspection, Java 17, Gradle offline build/test/GameTest, Python,
archive/hash tools and process observation are permitted. No global settings,
dependency installation, external network, schema/content edits or stopping
another process. Main source refs remain available while your review runs.

Check C: and D: free space before build/server; each must exceed 10 GiB.
Use `C:/Program Files/Java/jdk-17.0.7`, and task-local TEMP/TMP/TMPDIR plus
Java java.io.tmpdir under your evidence directory. Keep native commands and test
budgets unchanged. Run clean build and runGameTestServer independently against
the exact candidate. Retain complete logs, JUnit XML, actual totals, native
terminal results and error-header counts. Explain failures, interruptions and
unexecuted checks as such. Do not select a passing cohort and discard a failed
one. Do not treat short checks as Gate, native restart or visual acceptance.

## Report and cleanup

Write REPORT.md with findings first (severity and exact file/line), checked
commit/tree identities, commands/exit codes, actual tests, scope compliance and
residual unverified matters. Keep the report concise and evidence-based; do
not prefill a verdict. Seal your retained logs/results/report with SHA256SUMS.txt.
Only retire your own naturally ended fresh source/build/temp/server outputs
after retaining evidence and verifying resolved containment. Do not delete any
prior/input world, sealed output, refused cleanup or another worker's output.
If cleanup is rejected, report it and do not bypass it.

Return findings, execution summary and absolute report path. Read-only review
permission does not include final product acceptance or changing the candidate.
