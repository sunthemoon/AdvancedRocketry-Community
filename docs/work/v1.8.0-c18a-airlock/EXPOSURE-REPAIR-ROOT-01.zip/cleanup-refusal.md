# Root cleanup observation

2026-10-08. After the Root baseline and repair runners ended naturally, a native
PowerShell command was submitted to verify containment, inspect reparse points
and active own Java processes, and remove only this task's new build,
project-local Gradle, run-data and stage TEMP directories.

The tool rejected the complete command before execution (`blocked by policy`).
No enumeration, containment result, byte count or deletion from that command
occurred. No retry through a helper, shell or parent-directory removal was made.
The worktree and generated outputs remain. Global caches, input/prior worlds,
inherited refused cleanup and other agents' files are not touched.

Retained source/build/server output is not release evidence. Stage TEMP content
is excluded from the payload checksum manifest. Only the listed logs, results,
scripts, source patch and report are sealed as evidence.
