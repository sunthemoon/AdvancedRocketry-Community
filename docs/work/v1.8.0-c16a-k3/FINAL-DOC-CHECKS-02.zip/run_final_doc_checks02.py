"""Separate publication replay after owner-allocation status synchronization."""
from pathlib import Path

source = Path(__file__).with_name('run_final_doc_checks01.py')
code = source.read_text(encoding='utf-8')
for old, new in (
    ('SOURCE22-FINAL-POSTCHECK-01.json', 'SOURCE22-FINAL-POSTCHECK-02.json'),
    ('markdown-links-20.json', 'markdown-links-21.json'),
    ('planning-final01', 'planning-final02'),
    ('ledger-final01', 'ledger-final02'),
    ('diff-final01', 'diff-final02'),
    ('FINAL-DOC-CHECKS-01.json', 'FINAL-DOC-CHECKS-02.json')):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(Path(__file__)), 'exec'))
