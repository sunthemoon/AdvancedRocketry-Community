import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

here = Path(__file__).parent
source = here.parent / 'ak3dp-349e0a2278'
manifest_data = (source / 'EVIDENCE-MANIFEST.json').read_bytes()
assert hashlib.sha256(manifest_data).hexdigest() == '803dcce57e1e63b68bebd9155d2c779b25fbccc000a2893d39baa53aaabb7474'
assert hashlib.sha256((source / 'ADDENDUM-01.md').read_bytes()).hexdigest() == '8a13e1befa335a09fd59aa37554a51fd3a3053177082504ce2bc9ef428e6d84b'
files = json.loads(manifest_data)['files']
names = list(files) + ['EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt']
assert len({name.casefold() for name in names}) == len(names)
payloads = {}
for name in names:
    parts = PurePosixPath(name).parts
    assert not PurePosixPath(name).is_absolute() and ':' not in name and '\\' not in name
    assert all(part not in ('', '.', '..') for part in parts)
    path = source.joinpath(*parts).resolve()
    assert path.is_relative_to(source.resolve())
    data = path.read_bytes()
    if name in files:
        assert len(data) == files[name]['bytes']
        assert hashlib.sha256(data).hexdigest() == files[name]['sha256']
    payloads[name] = data
for line in payloads['SHA256SUMS.txt'].decode().splitlines():
    digest, name = line.split('  ', 1)
    assert hashlib.sha256(payloads[name]).hexdigest() == digest
target = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-k3/reviews/documentation-postimage-01.zip')
assert not target.exists()
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payloads.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(payloads)
    assert all(archive.read(name) == data for name, data in payloads.items())
receipt = {'target': str(target), 'entries': len(payloads), 'bytes': target.stat().st_size,
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'original_payloads_exact': True, 'originals_modified': False, 'gate_claimed': False}
result = here / 'DOC-POSTIMAGE-PACKET-01.json'
assert not result.exists()
result.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt))
