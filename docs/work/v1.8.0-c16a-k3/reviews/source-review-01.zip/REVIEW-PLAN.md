# Source-derived K3 review plan (preparation only)

## Bound authority

The [task snapshot](inputs/root/docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md)
defines one package-private String-returning function:
`ClassicNbtCanonicalHash.sha256(CompoundTag root, ClassicNbtLimits limits)`.
Its bytes are exactly the already reviewed K2 output. No domain prefix,
resource snapshot, schema field or public hash-v1 producer is introduced.
The [intake](INTAKE-01.json) pins commit
`3f3d62aed3980186fe0acc9592cf93ca436405fb`, task5d1f7356 and current live
AGENTS1be0391c (sections9-11 were reread). Root tracked document changes are
recorded but remain read-only; no Root source equality is inferred for future
unrelated edits.

Five existing named source dependencies were reread from the immutable commit
and compared with both current Root and author worktree; all five are equal.
No author implementation delta has yet been intaken, no source verdict has been
issued, and no Java has launched. No whole source/export/archive was created.

## Actual-delta review when author final pins arrive

1. Verify the final two-file source manifest, patch, baseline commit/worktree
   identity, command/log/XML/results and exact before/after byte identities.
   Retain any author failures or revised checkpoints as separately identified
   evidence. Check that all existing K1/K2/limits/value/Bank/central files stay
   unchanged, with commit-relative reads instead of whole source exports.
2. Review actual access/signature, dependencies and exception/refusal paths.
   Check exact SHA-256 of K2's returned bytes, lowercase64-character hexadecimal
   result, no domain/framing/schema addition, per-call digest ownership and no
   mutable digest/cache or gameplay/native/world callback API.
3. Follow the input/output ownership through actual calls. K2 is the sole
   eligibility/limit source; a digest result must not escape after its refusal.
   Caller-stable exclusive ownership remains a precondition, not a snapshot or
   reentrancy/world authority. Review null/illegal data behavior against actual
   delegated K2 exceptions, without broadening full codec protection policy.
4. Inspect every author assertion and any red-to-green changes against source
   facts. Signed-zero native factory/load normalization, typed-empty refusal,
   original UTF16/MUTF names and compound-key K1 order retain their existing
   qualified meanings; no SHA claim becomes natural native round-trip proof.

## Independent controls to implement after exact final intake

| Control | Reference / observation |
|---|---|
| Exact empty-root digest | Manual bytes10,0,0,0 hashed independently using JDK SHA-256; compare exact lowercase text and result length |
| No extra domain/framing | Native eligible singleton frame and independently written ordered compound frame, with original modifiedUTF strings, hashed by a new reference digest |
| Deterministic complete key order | Same compound contents in different insertion orders including ordinaryUTF8 replacement ties; retain original keys and values |
| Type/presence/list/array distinctions | Distinct native types, absent vs present empty value, list and array order compared with exact byte reference rather than assumed distinct hash for every possible input |
| Ownership and call isolation | Inputs/array aliases retain identity/contents; repeated and interleaved roots agree with independently computed digests; mutation between calls affects only later result |
| Strict componentwise limits | Exact request boundaries and one-less/above-ceiling refusals using unchanged K2/ClassicNbtLimits; no larger request clamps silently |
| Invalid input/no result | Actual K2-supported invalid/foreign/typed-empty/noncanonical-NaN/cycle/null inputs refuse before a digest String is returned; no forced native writer after refusal |
| Independent-call state | Each actual operation compared with fresh reference digest; bounded sequential and, if safe/appropriate under actual source, independent-root parallel calls, no shared input mutation |

No outcome is presumed from this plan. Reference self-checks are not K3 runtime
results. Reviewer test additions will be pinned separately and cannot change
author assertions, production or limits.

## Execution constraints / evidence hygiene

Wait for author final delta, author release and a separate Root Java grant.
If Java replay needs a checkout, request a separate registered Git worktree at
the immutable commit; do not copy the whole project or create an archive.
Only reviewer tests and exact authorized candidate additions may be applied in
that isolated replay checkout. Check disk space first and coordinate the bounded
Java17/offline/no-daemon/workers2/2GB slot. Preserve fresh command/exit/raw XML
and exact pre/post pins. No build/DataGen/GT/native/server/client/network/commit.

Final delivery is a small loose report/patch/results/manifest bundle, not a
redundant source ZIP. It will distinguish source findings, actual scoped tests
and all unrun integration/runtime/client/Required Gate checks. Root alone owns
application/regression/phase commit and version acceptance.
