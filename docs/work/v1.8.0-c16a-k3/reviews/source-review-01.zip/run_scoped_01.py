"""One granted K3 scoped replay in the separate real worktree."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

B=Path(__file__).resolve().parent
W=Path('D:/GitHub/arce-v180-canonical-digest-review-20261004')
BASE=json.loads((B/'BASELINE-REVIEWER-02.json').read_bytes())
OWN=json.loads((B/'author-final/OWN-FILES-01.json').read_bytes())
PROBE='src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/IndependentCanonicalHashTest.java'
def raw(p):return Path('\\\\?\\'+str(p.absolute())).read_bytes()
def meta(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def doc(n,v):(B/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def check():
    changed={n:meta(raw(W/n)) for n,pin in BASE.items() if meta(raw(W/n))!=pin}
    assert not changed,changed
    for n,pin in OWN.items():assert meta(raw(W/n))=={'bytes':pin['bytes'],'sha256':pin['sha256']},n
    assert raw(W/PROBE)==raw(B/'IndependentCanonicalHashTest.java')
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()=='3f3d62aed3980186fe0acc9592cf93ca436405fb'
    return {'original8870_exact':True,'author_two_exact':True,'reviewer_probe_exact':True,'commit_unchanged':True}

pre=check();doc('scoped-01.pre-source.json',pre)
reverse=['git','-c','core.autocrlf=false','apply','--reverse','--check',str(B/'author-final/SOURCE-01.patch')]
r=subprocess.run(reverse,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(B/'patch-source-02-reverse-check.log').write_bytes(r.stdout)
(B/'patch-source-02-reverse-check.exit').write_text(str(r.returncode)+'\n',encoding='utf-8')
doc('patch-source-02-reverse-check.command.json',{'argv':reverse,'cwd':str(W)})
assert r.returncode==0
free={drive:shutil.disk_usage(drive+':/').free for drive in ['C','D']}
doc('scoped-01.disk-precheck.json',{'free_bytes':free,'required_min_each':10000000000,
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':all(v>=10000000000 for v in free.values())})
assert all(v>=10000000000 for v in free.values()),free
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Java/jdk-17.0.7';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
args=[str(W/'gradlew.bat'),'--offline','--no-daemon','--max-workers=2','-Dorg.gradle.jvmargs=-Xmx2G',
      'cleanTest','compileJava','compileTestJava','test','--tests',
      'io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.ClassicNbtCanonicalHashTest','--tests',
      'io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.IndependentCanonicalHashTest']
doc('scoped-01.command.json',{'argv':args,'cwd':str(W),'JAVA_HOME':env['JAVA_HOME'],'free_bytes_immediately_before':free})
start=datetime.datetime.now(datetime.timezone.utc);clock=time.monotonic()
(B/'scoped-01.started').write_text(start.isoformat()+'\n',encoding='utf-8')
print(json.dumps({'started':start.isoformat(),'worktree':str(W),'free_bytes':free}),flush=True)
with (B/'scoped-01.log').open('wb') as log:
    result=subprocess.run(args,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-clock;end=datetime.datetime.now(datetime.timezone.utc)
(B/'scoped-01.finished').write_text(end.isoformat()+'\n',encoding='utf-8')
(B/'scoped-01.exit').write_text(str(result.returncode)+'\n',encoding='utf-8')
post=check();doc('scoped-01.post-source.json',post)
doc('SCOPED-RESULT-01.json',{'exit':result.returncode,'elapsed_seconds':elapsed,'started':start.isoformat(),'finished':end.isoformat(),
    'source8870_plus_two_and_probe_exact':True,'log':meta(raw(B/'scoped-01.log'))})
print(json.dumps({'exit':result.returncode,'elapsed_seconds':elapsed,'unchanged8870_plus_two_and_probe':True}),flush=True)
raise SystemExit(result.returncode)
