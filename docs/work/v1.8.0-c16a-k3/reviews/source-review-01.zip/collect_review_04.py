"""Retain fresh XML and independently bind source/native/result facts before cleanup."""
import collections
import datetime
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

B=Path(__file__).resolve().parent
W=Path('D:/GitHub/arce-v180-canonical-digest-review-20261004')
def meta(d):return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def raw(p):return Path('\\\\?\\'+str(p.absolute())).read_bytes()
def save(n,d):
    p=B/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(d)
def doc(n,v):save(n,(json.dumps(v,indent=2)+'\n').encode())

job=json.loads((B/'SCOPED-RESULT-01.json').read_bytes());assert job['exit']==0
start=datetime.datetime.fromisoformat(job['started']).timestamp()
end=datetime.datetime.fromisoformat(job['finished']).timestamp()
xmls=sorted((W/'build/test-results/test').glob('TEST-*.xml'));assert len(xmls)==2
total=collections.Counter();suites={};classes=[]
for file in xmls:
    data=raw(file);tree=ET.fromstring(data)
    counts={n:int(tree.attrib[n]) for n in ['tests','failures','errors','skipped']}
    cases=list(tree.iter('testcase'));assert len(cases)==counts['tests']
    assert counts['failures']==counts['errors']==counts['skipped']==0
    assert start<=file.stat().st_mtime<=end+1
    assert not list(tree.iter('failure')) and not list(tree.iter('error')) and not list(tree.iter('skipped'))
    total.update(counts)
    suites[tree.attrib['name']]={'counts':counts,'testcases':[c.attrib['name'] for c in cases],'xml':meta(data),
        'mtime_utc':datetime.datetime.fromtimestamp(file.stat().st_mtime,datetime.timezone.utc).isoformat()}
    classes.extend(line for e in tree.iter('system-out') for line in (e.text or '').splitlines() if line.startswith('K3_PRIMARY '))
    save('reviewer-xml/'+file.name,data)
assert dict(total)=={'tests':23,'failures':0,'errors':0,'skipped':0} and len(classes)==3
author_xml=list((B/'author-final/xml').glob('TEST-*.xml'));assert len(author_xml)==1
author_tree=ET.fromstring(raw(author_xml[0]));author_counts={n:int(author_tree.attrib[n]) for n in ['tests','failures','errors','skipped']}
assert author_counts=={'tests':15,'failures':0,'errors':0,'skipped':0}
assert len(list(author_tree.iter('testcase')))==15
assert int((B/'author-final/scoped-01.exit').read_text(encoding='utf-8').strip())==0
jar=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
jar_pin=meta(raw(jar));assert jar_pin['sha256']=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
native={}
with zipfile.ZipFile(jar) as archive:
    for line in classes:
        _,name,sha,location=line.split(' ',3)
        entry=name.replace('.','/')+'.class'
        assert hashlib.sha256(archive.read(entry)).hexdigest()==sha
        assert 'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar' in location
        native[entry]={'sha256':sha,'observed_JUnit_location':location}
own=json.loads((B/'author-final/OWN-FILES-01.json').read_bytes())
prod_name=next(n for n in own if '/main/' in n)
prod=raw(W/prod_name).decode('utf-8')
assert prod.count('ClassicNbtCanonicalBytes.encode(')==1
assert prod.count('MessageDigest.getInstance("SHA-256")')==1
assert prod.index('ClassicNbtCanonicalBytes.encode(')<prod.index('try {')
assert 'HexFormat.of().formatHex(' in prod
assert 'static final MessageDigest' not in prod and 'static MessageDigest' not in prod
assert 'net.minecraft.client' not in prod and 'java.nio.charset' not in prod
for label,args in [('diff-tracked',['git','diff','--exit-code']),('diff-check',['git','diff','--check']),
                   ('untracked',['git','status','--porcelain','--untracked-files=all']),('head',['git','rev-parse','HEAD'])]:
    result=subprocess.run(args,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    save('git-final/'+label+'.log',result.stdout);save('git-final/'+label+'.exit',(str(result.returncode)+'\n').encode())
    assert result.returncode==0,(label,result.stdout)
    if label=='untracked':
        names=[line[3:] for line in result.stdout.decode().splitlines()]
        expected=set(own)|{'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/IndependentCanonicalHashTest.java'}
        assert set(names)==expected,names
    if label=='head':assert result.stdout.decode().strip()=='3f3d62aed3980186fe0acc9592cf93ca436405fb'
result={'actual_reviewer_job':job,'fresh_testcase_elements':dict(total),'suites':suites,
    'author_original15_XML_observed':author_counts,'all_author_assertions_source_exact':True,
    'production_source_controls':{'one_K2_call_before_try':True,'one_new_SHA256_instance_per_call':True,'unmodified_byte_digest_no_prefix':True,
        'lowercase_JDK_HexFormat':True,'no_static_digest_cache_or_world_client_api':True,'unavailable_provider_branch_uninjected':True},
    'native_mapped_jar':{'origin':str(jar),**jar_pin},'observed_runtime_class_hashes_no_bodies_copied':native,
    'baseline8870_plus_own2_plus_probe_exact_prepost':True,'tracked_git_diff_and_check_exit':0,'HEAD_unchanged':True,
    'whole_version_or_native_API_admission':False}
doc('REVIEW-CHECKS-04.json',result)
print(json.dumps({'actual23':dict(total),'suites':len(suites),'author15_observed':author_counts,
 'native_class_hashes_matched':len(native),'tracked_diff0':True,'HEAD_unchanged':True},indent=2))
