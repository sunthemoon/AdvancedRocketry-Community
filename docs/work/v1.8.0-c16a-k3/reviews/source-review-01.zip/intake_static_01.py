"""Named static inputs only; no whole-tree source/export/archive, no code verdict."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

B=Path(__file__).resolve().parent
R=Path('D:/GitHub/AdvancedRocketry-Community')
A=Path('D:/GitHub/arce-v180-canonical-digest-20261004')
COMMIT='3f3d62aed3980186fe0acc9592cf93ca436405fb'
def meta(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def save(name,data):
    p=B/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def git(where,*args):
    r=subprocess.run(['git',*args],cwd=where,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert r.returncode==0,(where,args,r.returncode,r.stderr.decode(errors='replace'))
    return r.stdout

named=[
 'AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md',
 'docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
 'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
 'docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
 'UPSTREAM.md','NOTICE.md','docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md',
 'docs/08-ASSET-LICENSE-AND-PROVENANCE.md',
 'docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md',
]
inputs={}
for n in named:
    data=(R/n).read_bytes();save('inputs/root/'+n,data)
    inputs[n]={'origin':str(R/n),**meta(data)}
task=inputs['docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md']
assert task['sha256']=='5d1f7356c50b539859eb69cd7b821e624224d004d5dbb32c7dec4c38d7d761b2'
sources={}
prefix='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
for n in ['machine/classic/adapter/ClassicNbtCanonicalBytes.java',
          'machine/classic/adapter/ClassicNbtKeyOrder.java',
          'machine/classic/adapter/ClassicNbtLimits.java',
          'machine/classic/adapter/ClassicNbtShape.java','persistence/BoundedNbt.java']:
    relative=prefix+n
    data=git(R,'show',COMMIT+':'+relative)
    save('inputs/commit/'+relative,data)
    sources[relative]={'immutable_commit':COMMIT,**meta(data),'root_live_equal':(R/relative).read_bytes()==data,
                       'author_existing_equal':(A/relative).read_bytes()==data}
assert sources[prefix+'machine/classic/adapter/ClassicNbtCanonicalBytes.java']['sha256']=='1aa5ad420a1288820f148ea55c149510c5206c7351c928186548cada54b3dfd6'
assert all(v['root_live_equal'] and v['author_existing_equal'] for v in sources.values())
git_records={}
for label,where in [('root',R),('author',A)]:
    for name,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),
                      ('status-tracked',['status','--short','--untracked-files=no'])]:
        data=git(where,*args);save('git/'+label+'-'+name+'.txt',data)
        git_records[label+'-'+name]=meta(data)
    assert git(where,'rev-parse','HEAD').decode().strip()==COMMIT
save('git/worktrees.txt',git(R,'worktree','list','--porcelain'))
result={'task_sha256':task['sha256'],'current_root_named_inputs':inputs,'exact_commit_sources':sources,
        'git_named_records':git_records,'role':'prepare-only independent reviewer',
        'write_scope':str(B),'Java_launches':0,'root_author_changes':0,'whole_source_copies':0,'archives':0,
        'final_author_source_intake':False,'final_code_verdict':None,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
save('INTAKE-01.json',(json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'root_commit':COMMIT,'task':task,'live_AGENTS':inputs['AGENTS.md'],
 'named_docs':len(inputs),'existing_dependency_snapshots':len(sources),
 'all_five_commit_root_author_equal':True,'no_final_verdict_or_Java':True},indent=2))
