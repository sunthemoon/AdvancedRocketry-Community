"""Final small loose bundle checksums; no duplicate directory/tree or ZIP."""
import hashlib
import json
import re
import subprocess
from pathlib import Path, PurePosixPath

B=Path(__file__).resolve().parent
W=Path('D:/GitHub/arce-v180-canonical-digest-review-20261004')
def raw(p):return Path('\\\\?\\'+str(p.absolute())).read_bytes()
def meta(d):return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
base=json.loads((B/'BASELINE-REVIEWER-02.json').read_bytes())
own=json.loads((B/'author-final/OWN-FILES-01.json').read_bytes())
for n,p in base.items():assert meta(raw(W/n))==p,n
for n,p in own.items():assert meta(raw(W/n))=={'bytes':p['bytes'],'sha256':p['sha256']},n
probe='src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/IndependentCanonicalHashTest.java'
assert raw(W/probe)==(B/'IndependentCanonicalHashTest.java').read_bytes()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()=='3f3d62aed3980186fe0acc9592cf93ca436405fb'
assert not (W/'build').exists() and not (W/'.gradle').exists()
links=[]
for report in ['REVIEW-01.md','HANDOFF.md','PREPARATION-RESULT.md','REVIEW-PLAN.md','author-final/HANDOFF.md']:
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(B/report).read_text(encoding='utf-8')):
        assert not target.startswith(('http:','https:','file:'))
        assert (B/Path(report).parent/target.split('#',1)[0]).is_file(),(report,target)
        links.append({'report':report,'target':target})
excluded={'EVIDENCE-MANIFEST.json','SHA256SUMS.txt','FINAL-RECEIPT-06.json',
          'freeze-loose-06.log','freeze-loose-06.exit','freeze-loose-06.started','freeze-loose-06.finished'}
files={}
for path in sorted(B.rglob('*')):
    if not path.is_file():continue
    name=path.relative_to(B).as_posix()
    if name in excluded:continue
    assert '..' not in PurePosixPath(name).parts and ':' not in name and '\\' not in name
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in name
    files[name]=meta(path.read_bytes())
assert len(files)==len({n.casefold() for n in files})
assert sum(p['bytes'] for p in files.values())<100000000
assert max(p['bytes'] for p in files.values())<50000000
payload={'scope':'small loose K3 independent source/scoped-test review; no archive or full source export',
         'baseline_commit':'3f3d62aed3980186fe0acc9592cf93ca436405fb','files':files,
         'self_and_live_receipt_exclusions':sorted(excluded)}
manifest=(json.dumps(payload,indent=2)+'\n').encode()
(B/'EVIDENCE-MANIFEST.json').write_bytes(manifest)
checks={**files,'EVIDENCE-MANIFEST.json':meta(manifest)}
sums=''.join(pin['sha256']+'  '+name+'\n' for name,pin in sorted(checks.items())).encode()
(B/'SHA256SUMS.txt').write_bytes(sums)
for n,p in checks.items():assert meta((B/n).read_bytes())==p,n
result={'folder':str(B),'files':len(files),'evidence_bytes':sum(p['bytes'] for p in files.values()),
 'manifest':meta(manifest),'checksums':meta(sums),'report':meta((B/'REVIEW-01.md').read_bytes()),
 'handoff':meta((B/'HANDOFF.md').read_bytes()),'active_links':len(links),'missing_links':0,
 'all_bundle_SHA_checked':True,'8870_baseline_plus_two_and_probe_unchanged_final':True,
 'own_build_gradle_absent':True,'archives_created':0,'whole_source_exports':0,'Java_slot_released':True}
(B/'FINAL-RECEIPT-06.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
