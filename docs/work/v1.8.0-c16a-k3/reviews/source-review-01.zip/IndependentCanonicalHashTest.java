package io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.lang.reflect.Constructor;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.nbt.*;
import org.junit.jupiter.api.Test;

/** Reviewer-only computation controls, not a resource hash or native persistence fixture. */
class IndependentCanonicalHashTest {
    @Test void exactEmptyRootDigestHasNoExtraDomainAndLowercaseText() throws Exception {
        String result = hash(new CompoundTag());
        assertEquals(reference(new byte[]{10, 0, 0, 0}), result);
        assertTrue(result.matches("[0-9a-f]{64}"));
        assertNotEquals(reference(new byte[0]), result);
    }

    @Test void originalModifiedUtfNamesUseCompleteKeyOrderBeforeDigest() throws Exception {
        String[] ordered = {"\0", "?", "\ud800", "\ud801", "\udc00", "\ud83d\ude80"};
        CompoundTag forward = new CompoundTag(), reverse = new CompoundTag();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes); out.writeByte(10); out.writeUTF("");
        for (String key : ordered) {
            forward.putString(key, "\0\udfff");
            out.writeByte(8); out.writeUTF(key); out.writeUTF("\0\udfff");
        }
        out.writeByte(0);
        for (int i = ordered.length - 1; i >= 0; i--) { reverse.putString(ordered[i], "\0\udfff"); }
        Set<String> keys = Set.copyOf(reverse.getAllKeys());
        assertEquals(reference(bytes.toByteArray()), hash(forward));
        assertEquals(reference(bytes.toByteArray()), hash(reverse));
        assertEquals(keys, reverse.getAllKeys());
        for (String key : ordered) { assertEquals("\0\udfff", reverse.getString(key)); }
    }

    @Test void eligibleSingletonTypesAndNativeWidthsMatchIndependentDigest() throws Exception {
        ListTag list = new ListTag(); list.add(IntTag.valueOf(2)); list.add(IntTag.valueOf(1));
        CompoundTag child = new CompoundTag(); child.putInt("v", 4);
        List<Tag> values = List.of(ByteTag.valueOf((byte) 1), ShortTag.valueOf((short) 1),
                IntTag.valueOf(1), LongTag.valueOf(1), FloatTag.valueOf(Float.NaN),
                DoubleTag.valueOf(Double.POSITIVE_INFINITY), new ByteArrayTag(new byte[]{2, 1}),
                StringTag.valueOf("\0\udfff"), list, child,
                new IntArrayTag(new int[]{2, 1}), new LongArrayTag(new long[]{2, 1}),
                new ListTag(), new CompoundTag());
        List<String> observed = new ArrayList<>();
        for (Tag value : values) {
            CompoundTag root = new CompoundTag(); root.put("v", value);
            byte[] before = nativeFrame(root);
            String result = hash(root);
            assertEquals(reference(before), result, value.getClass().getSimpleName());
            assertArrayEquals(before, nativeFrame(root)); assertSame(value, root.get("v"));
            observed.add(result);
        }
        // This finite typed sample is distinct; this is not a cryptographic collision-free proof.
        assertEquals(observed.size(), Set.copyOf(observed).size());
    }

    @Test void strictK2LimitsCannotBeBypassedOrClampedByDigest() throws Exception {
        CompoundTag root = new CompoundTag(); root.putInt("a", 7);
        assertEquals(reference(nativeFrame(root)), ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(12, 2, 2)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(11, 2, 2)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(12, 1, 2)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(12, 2, 1)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root,
                new ClassicNbtLimits(ClassicNbtLimits.REJECTED.bytes() + 1, 2, 2)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(12, 26, 2)));
        assertThrows(IllegalArgumentException.class, () -> ClassicNbtCanonicalHash.sha256(root, new ClassicNbtLimits(12, 2, 86_530)));
        assertEquals(7, root.getInt("a"));
    }

    @Test void losslessRefusalNeverInvokesForeignWriterOrNormalizesRetainedValues() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        CompoundTag foreign = new CompoundTag() {
            @Override public byte getId() { calls.incrementAndGet(); return 10; }
            @Override public void write(DataOutput output) { calls.incrementAndGet(); fail("Foreign write"); }
            @Override public CompoundTag copy() { calls.incrementAndGet(); fail("Foreign copy"); return null; }
        };
        assertThrows(IllegalArgumentException.class, () -> hash(foreign)); assertEquals(0, calls.get());
        for (byte type = 1; type <= 12; type++) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(bytes);
            out.writeByte(10); out.writeUTF(""); out.writeByte(9); out.writeUTF("a");
            out.writeByte(type); out.writeInt(0); out.writeByte(0);
            CompoundTag root = NbtIo.read(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())));
            ListTag list = (ListTag) root.get("a");
            assertThrows(IllegalArgumentException.class, () -> hash(root));
            assertSame(list, root.get("a")); assertEquals(type, list.getElementType());
        }
        CompoundTag nan = new CompoundTag(); nan.putFloat("f", Float.intBitsToFloat(0x7fc00009));
        assertThrows(IllegalArgumentException.class, () -> hash(nan));
        assertEquals(0x7fc00009, Float.floatToRawIntBits(nan.getFloat("f")));
        CompoundTag cycle = new CompoundTag(); cycle.put("self", cycle);
        assertThrows(IllegalArgumentException.class, () -> hash(cycle)); assertSame(cycle, cycle.get("self"));
        assertThrows(NullPointerException.class, () -> ClassicNbtCanonicalHash.sha256(null, ClassicNbtLimits.RESOURCES));
        assertThrows(NullPointerException.class, () -> ClassicNbtCanonicalHash.sha256(new CompoundTag(), null));
    }

    @Test void aliasOwnershipAndMutationBetweenCallsCannotChangeEarlierResult() throws Exception {
        byte[] array = {1, 2, 3};
        CompoundTag child = new CompoundTag(); child.putByteArray("v", array);
        CompoundTag root = new CompoundTag(); root.put("v", child);
        String earlier = hash(root), expected = reference(nativeFrame(root));
        assertEquals(expected, earlier); assertSame(child, root.get("v")); assertSame(array, child.getByteArray("v"));
        for (int i = 0; i < 8; i++) {
            CompoundTag other = new CompoundTag(); other.putInt("v", i);
            assertEquals(reference(nativeFrame(other)), hash(other)); assertEquals(expected, hash(root));
        }
        array[0] = 9;
        String later = hash(root);
        assertEquals(reference(nativeFrame(root)), later); assertNotEquals(earlier, later); assertEquals(expected, earlier);
        assertSame(array, child.getByteArray("v")); assertArrayEquals(new byte[]{9, 2, 3}, array);
    }

    @Test void independentRootsCanBeHashedWithoutCrossCallDigestState() throws Exception {
        var executor = Executors.newFixedThreadPool(2);
        try {
            var futures = new ArrayList<java.util.concurrent.Future<Boolean>>();
            for (int i = 0; i < 32; i++) {
                int value = i;
                futures.add(executor.submit(() -> {
                    CompoundTag root = new CompoundTag(); root.putLong("v", value);
                    String expected = reference(nativeFrame(root));
                    return expected.equals(hash(root)) && expected.equals(hash(root));
                }));
            }
            for (var future : futures) { assertTrue(future.get(10, TimeUnit.SECONDS)); }
        } finally {
            executor.shutdown(); assertTrue(executor.awaitTermination(10, TimeUnit.SECONDS));
        }
        // Each task owns its root; this says nothing about concurrently mutating one shared Tag.
    }

    @Test void constructorSignedZeroEmissionIsSeparateFromNaturalNativeLoad() throws Exception {
        Constructor<FloatTag> constructor = FloatTag.class.getDeclaredConstructor(float.class); constructor.setAccessible(true);
        CompoundTag exact = new CompoundTag(); exact.put("v", constructor.newInstance(-0.0f));
        assertEquals(0x80000000, Float.floatToRawIntBits(exact.getFloat("v")));
        byte[] nativeNegative = nativeFrame(exact);
        assertEquals(reference(nativeNegative), hash(exact));
        CompoundTag loaded = NbtIo.read(new DataInputStream(new ByteArrayInputStream(nativeNegative)));
        assertEquals(0, Float.floatToRawIntBits(loaded.getFloat("v")));
        assertEquals(reference(nativeFrame(loaded)), hash(loaded));
        assertNotEquals(hash(exact), hash(loaded));
        assertEquals(0x80000000, Float.floatToRawIntBits(exact.getFloat("v")));
    }

    private static String hash(CompoundTag root) { return ClassicNbtCanonicalHash.sha256(root, ClassicNbtLimits.RESOURCES); }
    private static String reference(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static byte[] nativeFrame(CompoundTag root) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(); NbtIo.write(root, new DataOutputStream(bytes)); return bytes.toByteArray();
    }
}
