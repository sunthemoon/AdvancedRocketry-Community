# K3 independent private canonical-digest source review

## Findings first

No introduced Critical, High, Medium or Low finding identified in the exact two NEW source/test files. Source and scoped observations support Root considering the bounded private digest integration and its current-version regression. This is not public `ClassicNativeHash.resources`, a GuardTicket/resource/frame/checkpoint writer, natural native round-trip, physical hatch or whole-version Gate admission.

The unavailable SHA-256-provider branch at production16-17 was reviewed statically, not injected by altering global providers. Stable exclusive input ownership remains K2's caller precondition, not an atomic snapshot or reentrancy promise. These are retained limits, not hidden passing runtime checks.

## Exact authority, checkout and source delta

Immutable reviewed baseline: commit `3f3d62aed3980186fe0acc9592cf93ca436405fb`, already pushed by Root. Real independent review worktree `D:/GitHub/arce-v180-canonical-digest-review-20261004` is detached at that exact commit. No HEAD, branch, commit or shared existing file changed by the reviewer. Live Root [AGENTS snapshot](inputs/root/AGENTS.md), SHA256 `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`, including sections9-11, governs this task instead of the older worktree instruction file.

The [task](inputs/root/docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md), SHA256 `5d1f7356c50b539859eb69cd7b821e624224d004d5dbb32c7dec4c38d7d761b2`, defines only the package-private String-returning `ClassicNbtCanonicalHash.sha256(CompoundTag, ClassicNbtLimits)` over exact K2 bytes. It preserves all existing eligibility, framing, K1 order, root limits and ownership. [Static preparation](INTAKE-01.json) captured sixteen named governance/authority documents and five existing dependency files directly from the immutable commit; those five match Root and author existing source bytes. No whole-source export or archive was created.

Author final loose handoff: `C:/Users/Administrator/AppData/Local/Temp/ak3-a1db5e5ab0`. Its [evidence manifest](author-final/EVIDENCE-MANIFEST.json) SHA256 `69a6e823e5571f6d13743ac4c3bbf88afc8ae476b50592f0046ff498a956e3bc` pins46 entries/1,964,678 bytes; every named entry byte/hash verified and retained. [Author handoff](author-final/HANDOFF.md) SHA256 `1854833d725deb524dd08b82272ed5d582b32f814c47403aabfb48266945a183`. The source is an uncommitted proposal on the pinned baseline, not delivered ledger content; Root remains sole integrator and future phase-commit writer.

| Exact proposed file / patch | Bytes | SHA256 |
|---|---:|---|
| [Production postimage](author-final/postimages/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java) | 809 | `6ca5b028317766e9106953a011134096e896b08b557db041eb0c92ad493b5ec8` |
| [Original test postimage](author-final/postimages/src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java) | 16,244 | `cf295730469021a70dc2eba85d030379860b16388025359eafb249a526d08c27` |
| [Own manifest](author-final/OWN-FILES-01.json) | 523 | `fe2fc9811ad0a9e92dd03352f7e6b06ca2538c13cf2aad257408d1f67ff59a54` |
| [Two-file patch](author-final/SOURCE-01.patch) | 17,661 | `68efad46f56d66a9c2bdc8157610adde1be9847748ec911d627e8d2df9cb804e` |
| [Separate reviewer eight controls](IndependentCanonicalHashTest.java) | 10,042 | `1475b6b07f5907cc2b72c663ef0d5d7abaab42a4df8d57d0a24071ac95b441d8` |

Both author preimages were absent. Forward `git -c core.autocrlf=false apply --check` passed; actual additions used `apply_patch` under the explicitly granted three-new-file scope. Exact postimage hashes and reverse applicability check passed. All8,870 tracked baseline file bytes match the author fixed-commit baseline before and after the test job; only the two candidate additions plus the separate reviewer test are untracked. That tracked count includes source, documentation and evidence, not runtime inputs or coverage. [Intake](INTAKE-FINAL-02.json), [source precheck](scoped-01.pre-source.json), [postcheck](scoped-01.post-source.json) and [Git checks](git-final/diff-tracked.log) preserve the facts.

## Actual source/contract assessment

Production is20 lines and has no fields, cache, public/registry/world/native callback surface or new domain prefix:

- Lines9-12 keep class/method package-private and the exact task signature. Imports3-6 are JDK SHA/formatting and native CompoundTag only; K2 is the existing same-package computation dependency. No client/resource/GuardTicket/public API or reverse module dependency is added.
- Line13 calls unchanged K2 exactly once **before** the digest try block. Its byte frame, fixed/stricter limits, eligibility and exceptions propagate. No string/SNBT/JSON conversion, normalization, status reclassification, extra root or schema ID is introduced.
- Line15 creates a fresh `MessageDigest.getInstance("SHA-256")` on every call, digests the exact returned byte array and formats the32 digest bytes through default lowercase `HexFormat`. The64-character String has no exported mutable byte array or global mutable state.
- Lines16-17 preserve the unavailable-algorithm cause as IllegalStateException. No input is placed in the error string, and no digest result returns on K2 refusal.

The original15 test methods were independently read and executed unchanged. They include manual native binary/MUTF frames, eligible native singleton differentials, K1 insertion permutations/ties, type/presence/non-normalized strings, nested compound versus list/array order, alias preservation and mutation between calls, per-call/parallel independent roots, inclusive bounds and existing maximum byte ceiling, foreign/End/null/cycle/typed-empty/lossy NaN/overlong UTF refusal. Finite different hashes do not prove general collision freedom. Exact-constructor signed-zero tests prove emitted-byte mechanics, not natural native loading/persistence support; no forced native writer is invoked after typed-empty/lossy refusal.

Eight reviewer controls separately observed exact empty-root/no-prefix/lowercase digest, manual original MUTF names under complete K1 key order, native singleton widths/types, componentwise K2 limit/refusal propagation, all typed-empty non-End subtypes1-12 and foreign writer/copy counters, alias and between-call mutation isolation,32 bounded independent-root threaded jobs, and exact-constructor -0 emission versus actual natural native-load +0 normalization. Each positive reference uses a fresh JDK SHA-256 over separately obtained/manual bytes. The independent zero control explicitly distinguishes native emission from native round-trip.

## Commands and actual results

All new evidence was written only under `D:/ARCE-Task-Evidence/v1.8.0/ak3r-19c4b829a2`; only the explicitly owned three NEW Java files were added in the separate real worktree. No Root/author/central/old test/old packet changes occurred.

| Actual command | Result / evidence |
|---|---|
| `python intake_static_01.py` | exit0; [raw](intake-static-01.log), named authority/commit preparation only |
| `python intake_final_02.py` | **exit1**, reviewer dictionary-shape comparison included author `preimage` alongside bytes/hash; [raw](intake-final-02.log), [original failed script](intake_final_02.failed-01.py); no source mutation or Java occurred |
| `python intake_final_03.py` | exit0 after projecting byte/hash and separately checking `preimage=ABSENT`; [raw](intake-final-03.log); all46 author entries,8,870 baseline files,2 new postimages and patch checked |
| `git -c core.autocrlf=false apply --check SOURCE-01.patch`, then `--reverse --check` after apply_patch | each exit0; [forward](patch-source-02-check.log), [reverse](patch-source-02-reverse-check.log); exact source byte identities verified |
| `python run_scoped_01.py`, actual Gradle command below | exit0,40.433907s; **23 testcase elements/2 fresh suites/0 failures, errors, skips**; [raw](scoped-01.log), [receipt](SCOPED-RESULT-01.json), exact8,870+2+reviewer source pre/post pins |
| `python collect_review_04.py` | exit0; [raw](collect-review-04.log), [checks](REVIEW-CHECKS-04.json); independently counts actual XML, validates fresh filesystem times, confirms original author15/0, three runtime native class pins and Git scope |
| `git diff --exit-code`, `git diff --check`, tracked/untracked/HEAD observations | all exit0; original tracked bytes and fixed HEAD retained, only authorized3 new paths observed |
| `cleanup_review_01.ps1` | **exit1**, own PowerShell whitelist-expression guard failed before deletion; [raw](cleanup-review-01.log), [failed script](cleanup_review_01.failed-01.ps1) retained |
| `cleanup_review_02.ps1` | exit0 with exact literal approved targets; only own generated build/.gradle removed after verified XML retention; [raw](cleanup-review-02.log), [receipt](CLEANUP-REVIEW-02.json) |
| Exploratory `git rev-parse HEAD` from the evidence directory rather than the worktree | tool exit1, not a Git repository; [observation](EXPLORATORY-CWD-OBSERVATION-01.txt). Correct worktree recheck [raw](head-recheck-05.log) exits0; no source or Java change |

```text
JAVA_HOME=C:/Program Files/Java/jdk-17.0.7
gradlew.bat --offline --no-daemon --max-workers=2 -Dorg.gradle.jvmargs=-Xmx2G
  cleanTest compileJava compileTestJava test
  --tests io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.ClassicNbtCanonicalHashTest
  --tests io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.IndependentCanonicalHashTest
```

Recorded start05:36:07.256721Z, finish05:36:47.690638Z,2026-10-04. Immediate [disk precheck](scoped-01.disk-precheck.json) observed C10,353,614,848 and D342,172,069,888 bytes free, each above the explicit10,000,000,000-byte threshold. `compileJava` was FROM-CACHE, `compileTestJava` and test executed. Test dependency jar/reobfJar/apiJar tasks ran incidentally; no fullbuild/DataGen/artifact admission follows. Existing deprecation warnings remain in raw output; no warning-free or full clean-host claim.

Fresh [author15 replay XML](reviewer-xml/TEST-io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.ClassicNbtCanonicalHashTest.xml) plus [reviewer8 XML](reviewer-xml/TEST-io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.IndependentCanonicalHashTest.xml) contain exactly23 testcase elements, no skip/error/failure. XML times lie inside the recorded job. Actual JUnit `CompoundTag/ListTag/NbtIo` resource hashes match mapped Forge47.4.10 JAR SHA256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`. Only derived hashes/locations, not official bodies or JAR copies, are retained.

The original author [15/1-suite/0FES result](author-final/RESULTS-01.json), raw/XML/command and missing generic-version-document read failure remain separately preserved. Reviewer tooling failures are not candidate defects or Java failures. No source/author assertion/budget/timing/provider policy was changed to obtain the23-test result. All23 Java tests passed on their first reviewer run. Java slot was released; no further Java/native process was launched or terminated.

## Remaining limits and scoped recommendation

Recommend Root may apply only the exact two candidate postimages, run the current-version integration regression and commit/push the qualified phase. The proposed files remain uncommitted development evidence until that integration; this review does not mark ledger delivery or version acceptance.

Not implemented/verified here: GuardTicket-bound resource hash, native resource capture/callbacks, full hash/frame codec, checkpoint/publication, lifecycle/save protection, FE carrier/removal, physical hatches/formation, machine consumer/lathe, unavailable-provider injection, concurrent mutation of a shared input, performance/whole-heap bound, fullbuild/DataGen/GT, native dedicated server/restart/crash, real client/player V1/V2 or v1.8 G0-G9. Existing per-root limits must be supplied by future consumers; the helper maximum does not expand a resources root.

Completed scope: independent actual-source/patch review, exact baseline/postimage preservation, one scoped compile/unit job with new controls, fresh result retention and own disposable output cleanup. Uncompleted scope: dependent runtime/public/native/writer and all version admission. Modified files: only own reviewer evidence and three authorized NEW files in the separate worktree. Known risk: consumer authority, mutation ownership and individual-root limits remain separate constraints. Current version all Required Gates: **not established by this review**. Next eligible work is Root's current-version bounded integration/regression, not a future-version expansion.
