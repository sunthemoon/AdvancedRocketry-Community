"""Small named K3 handoff intake and real-worktree preflight, never exports source."""
import hashlib
import json
import subprocess
from pathlib import Path, PurePosixPath

B=Path(__file__).resolve().parent
A=Path('C:/Users/Administrator/AppData/Local/Temp/ak3-a1db5e5ab0')
W=Path('D:/GitHub/arce-v180-canonical-digest-review-20261004')
COMMIT='3f3d62aed3980186fe0acc9592cf93ca436405fb'
def xp(p):return Path('\\\\?\\'+str(p.absolute()))
def raw(p):return xp(p).read_bytes()
def meta(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def save(name,data):
    p=B/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def git(*args):
    r=subprocess.run(['git',*args],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert r.returncode==0,(args,r.stderr)
    return r.stdout
def safe(n):return ':' not in n and '\\' not in n and not n.startswith('/') and '..' not in PurePosixPath(n).parts and 'AdvancedRocketry-Community-v1plus-Development-Docs' not in n

evidence_data=raw(A/'EVIDENCE-MANIFEST.json')
assert meta(evidence_data)['sha256']=='69a6e823e5571f6d13743ac4c3bbf88afc8ae476b50592f0046ff498a956e3bc'
evidence=json.loads(evidence_data)
assert len(evidence)==46 and len({n.casefold() for n in evidence})==46 and all(safe(n) for n in evidence)
assert sum(v['bytes'] for v in evidence.values())==1964678
for name,pin in evidence.items():
    data=raw(A/name);assert meta(data)==pin,name
    save('author-final/'+name,data)
save('author-final/EVIDENCE-MANIFEST.json',evidence_data)
F=B/'author-final'
assert meta(raw(F/'HANDOFF.md'))['sha256']=='1854833d725deb524dd08b82272ed5d582b32f814c47403aabfb48266945a183'
own_data=raw(F/'OWN-FILES-01.json')
assert meta(own_data)['sha256']=='fe2fc9811ad0a9e92dd03352f7e6b06ca2538c13cf2aad257408d1f67ff59a54'
own=json.loads(own_data)
assert len(own)==2 and all(safe(n) for n in own)
for n,pin in own.items():
    assert pin['preimage']=='ABSENT'
    assert meta(raw(F/'postimages'/n))=={'bytes':pin['bytes'],'sha256':pin['sha256']}
    assert not (W/n).exists(),n
assert git('rev-parse','HEAD').decode().strip()==COMMIT
assert not git('status','--porcelain','--untracked-files=no')
tracked=git('ls-files','-z').decode().split('\0')[:-1]
assert len(tracked)==8870 and all(safe(n) for n in tracked)
baseline=json.loads(raw(F/'BASELINE-MANIFEST-01.json'))
assert set(baseline)==set(tracked)
review_base={}
for n in tracked:
    pin=meta(raw(W/n));assert pin==baseline[n],n
    review_base[n]=pin
save('BASELINE-REVIEWER-02.json',(json.dumps(review_base,indent=2)+'\n').encode())
patch_data=raw(F/'SOURCE-01.patch')
assert meta(patch_data)['sha256']=='68efad46f56d66a9c2bdc8157610adde1be9847748ec911d627e8d2df9cb804e'
command=['git','-c','core.autocrlf=false','apply','--check',str(F/'SOURCE-01.patch')]
check=subprocess.run(command,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
save('patch-source-02-check.log',check.stdout)
save('patch-source-02-check.exit',(str(check.returncode)+'\n').encode())
save('patch-source-02-check.command.json',(json.dumps({'argv':command,'cwd':str(W)},indent=2)+'\n').encode())
assert check.returncode==0
probe='src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/IndependentCanonicalHashTest.java'
assert not (W/probe).exists() and probe not in tracked
patch='*** Begin Patch\n'
for n in own:
    text=raw(F/'postimages'/n).decode('utf-8')
    assert text.endswith('\n') and '\r' not in text
    patch+='*** Add File: '+(W/n).as_posix()+'\n'+''.join('+'+line+'\n' for line in text.splitlines())
text=(B/'IndependentCanonicalHashTest.java').read_text(encoding='utf-8')
patch+='*** Add File: '+(W/probe).as_posix()+'\n'+''.join('+'+line+'\n' for line in text.splitlines())+'*** End Patch\n'
save('APPLY-SOURCE-02.txt',patch.encode())
result={'author_origin':str(A),'evidence_manifest':meta(evidence_data),'all46_entry_SHA':True,
 'two_new_postimages':own,'baseline_commit':COMMIT,'reviewer_worktree':str(W),'all8870_baseline_equal':True,
 'baseline_reviewer_manifest':meta(raw(B/'BASELINE-REVIEWER-02.json')),'patch':meta(patch_data),'patch_check_exit':check.returncode,
 'source_edit_method':'apply_patch only, exact source postimages plus NEW reviewer test',
 'reviewer_probe':{'path':probe,**meta(raw(B/'IndependentCanonicalHashTest.java'))},'Java_launched':False,'final_verdict':None}
save('INTAKE-FINAL-02.json',(json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result,indent=2))
