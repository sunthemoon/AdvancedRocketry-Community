from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).parent
WT = Path('D:/GitHub/arce-v180-canonical-digest-20261004')

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

assert (OUT / 'scoped-01.exit').read_text(encoding='utf-8-sig').strip() == '0'
baseline = json.loads((OUT / 'BASELINE-MANIFEST-01.json').read_text(encoding='utf-8'))
own = json.loads((OUT / 'OWN-FILES-01.json').read_text(encoding='utf-8'))
changed = [name for name, value in baseline.items()
           if not (WT / name).is_file() or (WT / name).stat().st_size != value['bytes']
           or sha(WT / name) != value['sha256']]
assert not changed, changed
assert all(sha(WT / name) == value['sha256'] for name, value in own.items())
head = subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip()
assert head == '3f3d62aed3980186fe0acc9592cf93ca436405fb'
start = datetime.fromisoformat((OUT / 'scoped-01.started').read_text(encoding='utf-8-sig').strip())
end = datetime.fromisoformat((OUT / 'scoped-01.finished').read_text(encoding='utf-8-sig').strip())
files = sorted((WT / 'build/test-results/test').glob('TEST-*.xml'))
assert len(files) == 1
totals = {key: 0 for key in ['tests', 'failures', 'errors', 'skipped']}
rows = []
for source in files:
    assert source.stat().st_mtime >= start.timestamp() - 2
    target = OUT / 'xml' / source.name
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(source.read_bytes())
    tree = ET.parse(target).getroot()
    counts = {key: int(tree.attrib.get(key, '0')) for key in totals}
    assert counts['tests'] == len(tree.findall('testcase'))
    for key in totals:
        totals[key] += counts[key]
    rows.append({'path': target.relative_to(OUT).as_posix(), 'bytes': target.stat().st_size,
                 'sha256': sha(target), 'suite': tree.attrib['name'], 'counts': counts,
                 'actual_cases': [test.attrib['name'] for test in tree.findall('testcase')]})
assert totals == {'tests': 15, 'failures': 0, 'errors': 0, 'skipped': 0}, totals
native = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
native_sha = sha(native)
assert native_sha == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
runtime = []
with zipfile.ZipFile(native) as archive:
    output = ET.parse(OUT / rows[0]['path']).getroot().findtext('system-out', '')
    for line in output.splitlines():
        if line.startswith('K3_PRIMARY '):
            _, name, actual, origin = line.split(' ', 3)
            expected = hashlib.sha256(archive.read(name.replace('.', '/') + '.class')).hexdigest()
            assert expected == actual
            runtime.append({'class': name, 'runtime_sha256': actual, 'runtime_source': origin,
                            'configured_primary_sha256': expected})
assert len(runtime) == 3
diff = subprocess.run(['git', '-C', str(WT), 'diff', '--check'], capture_output=True, text=True)
assert diff.returncode == 0
status = subprocess.check_output(['git', '-C', str(WT), 'status', '--porcelain']).decode()
receipt = {'timestamp': datetime.now(timezone.utc).isoformat(), 'head': head,
           'start': start.isoformat(), 'end': end.isoformat(), 'elapsed_seconds': (end-start).total_seconds(),
           'exit': 0, 'suites': len(rows), 'totals': totals, 'xml': rows,
           'baseline_count': len(baseline), 'baseline_changes': changed, 'own_sources_unchanged': True,
           'own': own, 'runtime_native': runtime, 'native_archive_sha256': native_sha,
           'diff_check': {'exit': diff.returncode, 'stdout': diff.stdout, 'stderr': diff.stderr},
           'status': status, 'disk': {drive: {'free': shutil.disk_usage(drive).free} for drive in ['C:/', 'D:/']},
           'other_java_jobs_started': False}
(OUT / 'RESULTS-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: receipt[key] for key in ['head', 'elapsed_seconds', 'exit', 'suites', 'totals',
                                               'baseline_count', 'baseline_changes', 'own_sources_unchanged', 'disk']}))
