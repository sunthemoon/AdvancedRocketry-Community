from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess

OUT = Path(__file__).parent
WT = Path('D:/GitHub/arce-v180-canonical-digest-20261004')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = '3f3d62aed3980186fe0acc9592cf93ca436405fb'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])

assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('status', '--porcelain', '--untracked-files=all').strip()
names = sorted(x.decode('utf-8') for x in git('ls-files', '-z').split(b'\0') if x)
assert not any('Development-Docs' in name for name in names)
baseline = {name: {'bytes': (WT / name).stat().st_size, 'sha256': sha(WT / name)} for name in names}
(OUT / 'BASELINE-MANIFEST-01.json').write_text(json.dumps(baseline, indent=2) + '\n', encoding='utf-8')
documents = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
             'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
             'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
             'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
             'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
             'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
documents += ['docs/work/v1.8.0-c16a-hatches/' + name for name in
              ['CANONICAL-DIGEST-TASK.md', 'TECHNICAL-CONTRACT-02.md', 'VALUES-CODEC-TASK.md',
               'HASH-ORDER-ACCEPTANCE-01.md', 'HASH-ORDER-SOURCE-ACCEPTANCE-01.md',
               'CANONICAL-BYTES-TASK.md', 'CANONICAL-BYTES-SOURCE-ACCEPTANCE-01.md']]
inputs = {name: {'origin': str(ROOT / name), 'bytes': (ROOT / name).stat().st_size,
                 'sha256': sha(ROOT / name)} for name in documents}
task = 'docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md'
assert inputs[task]['sha256'] == '5d1f7356c50b539859eb69cd7b821e624224d004d5dbb32c7dec4c38d7d761b2'
for name in ['AGENTS.md', task]:
    target = OUT / ('LIVE-AGENTS-01.md' if name == 'AGENTS.md' else 'TASK-01.md')
    target.write_bytes((ROOT / name).read_bytes())
feasibility = Path('C:/Users/Administrator/AppData/Local/Temp/anlf-2f1171b72b/FEASIBILITY-01.md')
assert sha(feasibility) == 'bae5bf975f2653107db1862babd2af41c916823f4c5f70f545de48b3d9c092fa'
inputs['preceding-feasibility'] = {'origin': str(feasibility), 'bytes': feasibility.stat().st_size,
                                 'sha256': sha(feasibility)}
receipt = {'timestamp': datetime.now(timezone.utc).isoformat(), 'base_commit': BASE,
           'branch': git('branch', '--show-current').decode().strip(), 'worktree': str(WT),
           'tracked_count': len(names), 'tracked_bytes': sum(v['bytes'] for v in baseline.values()),
           'baseline_manifest_sha256': sha(OUT / 'BASELINE-MANIFEST-01.json'),
           'disk': {drive: {'free': shutil.disk_usage(drive).free} for drive in ['C:/', 'D:/']},
           'inputs': inputs, 'upstream_or_native_sources_copied': False,
           'governance_read_attempt_01': {'exit': 1, 'reason': 'docs/versions/v1.8.0.md does not exist',
               'correction': 'Read actual V1.8.0-CLASSIC-CONTENT-COMPLETION.md; no file edits occurred'}}
(OUT / 'INTAKE-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: receipt[key] for key in ['base_commit', 'branch', 'tracked_count', 'tracked_bytes',
                                               'baseline_manifest_sha256', 'disk']}))
