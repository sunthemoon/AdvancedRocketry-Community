# C16a-03b-01-K3 private canonical digest author handoff

Date: 2026-10-04. Status: READY_FOR_REVIEW, not source/runtime/API acceptance.
Author: delegated c18. Root is the sole integrator and commit/status writer.

## Scope and findings

Two new files implement and test the task's private digest composition. No
blocking defect was observed by the author checks; different-agent actual-source
review is pending. This is an author report, not an independent verdict.

The fixed, already pushed code baseline is commit
`3f3d62aed3980186fe0acc9592cf93ca436405fb`, branch
`codex/v1.8.0-canonical-digest`, worktree
`D:/GitHub/arce-v180-canonical-digest-20261004`. Root may advance its own branch;
this worktree was not rebased or moved. All 8,870 tracked baseline file bytes
remained unchanged before and after the scoped job. The tracked count includes
documentation/evidence; it is not a runtime input or coverage count.

The [task snapshot](TASK-01.md) has SHA256
`5d1f7356c50b539859eb69cd7b821e624224d004d5dbb32c7dec4c38d7d761b2`.
The [live governance snapshot](LIVE-AGENTS-01.md) includes sections 9–11 and
overrides the older worktree governance for this task. Exact named authority
origins and hashes are recorded in [intake](INTAKE-01.json); those are provenance
records, not checksum targets in mutable build/Temp trees. The baseline manifest
names immutable committed files, not exported copies of the source tree.

## Exact source delta and design

- [Production](postimages/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java):
  809 bytes, SHA256 `6ca5b028317766e9106953a011134096e896b08b557db041eb0c92ad493b5ec8`.
- [Test](postimages/src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java):
  16,244 bytes, SHA256 `cf295730469021a70dc2eba85d030379860b16388025359eafb249a526d08c27`.
- [Own-file manifest](OWN-FILES-01.json): SHA256
  `fe2fc9811ad0a9e92dd03352f7e6b06ca2538c13cf2aad257408d1f67ff59a54`.
- [Two-new-file patch](SOURCE-01.patch): SHA256
  `68efad46f56d66a9c2bdc8157610adde1be9847748ec911d627e8d2df9cb804e`.
  Both preimages are absent. Author reverse applicability check exited 0 with
  `core.autocrlf=false`; a reviewer/integrator must independently check/apply
  against the named baseline and verify these postimages.

The only new surface is package-private
`ClassicNbtCanonicalHash.sha256(CompoundTag root, ClassicNbtLimits limits)`.
It calls unchanged K2 exactly once, obtains a fresh per-call JDK SHA-256 digest,
and formats its 32 bytes as 64 lowercase hexadecimal characters. There is no
mutable static digest/cache, string round-trip, prefix or common framework.
K2 refusal propagates; unavailable SHA-256 is reported as IllegalStateException
using the existing project's exception convention. The unavailable-provider
branch was not injected or tested by changing global JVM providers.

Caller-owned standard input must remain exclusive/stable throughout the call.
The new helper creates no concurrency snapshot. Eligibility, input aliases,
native widths/modified UTF, compound ordering and componentwise maximum/stricter
limits are exactly K2's existing policies. Full resources still need their own
actual per-root bounds and future GuardTicket-bound capture; the REJECTED maximum
is not permission to enlarge a resources root. Allocation includes K2's bounded
buffers/result, a 32-byte digest and 64-character result plus JDK overhead; no
whole-JVM allocation/performance guarantee is claimed.

All existing Bank/value/K1/K2/preflight/test files, schemas, public APIs,
registration, network, assets, build and generated resources remain unchanged.
Both files are new local code; no upstream/native class body or asset was copied.
There are no new persistent IDs, schema versions, migrations or protocol effects.

## Actual verification and failure lineage

[Source checkpoint](SOURCE-CHECKPOINT-01.json) verifies unchanged baseline,
exact two new paths, postimages and patch before Java. Its fresh disk observation
was C: 10,363,035,648 bytes and D: 342,709,866,496 bytes free. The launch command
records a separate immediately preceding both-drive threshold check.

The single granted command ran in the author worktree with Java 17.0.7:

```text
gradlew.bat --offline --no-daemon --max-workers=2 -Dorg.gradle.jvmargs=-Xmx2G
  cleanTest compileJava compileTestJava test
  --tests io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.ClassicNbtCanonicalHashTest
```

Exact [command](scoped-01.command.json), [start](scoped-01.started),
[finish](scoped-01.finished), [raw log](scoped-01.log), [exit](scoped-01.exit),
[Java version](java17-01.log), [fresh XML](xml/TEST-io.github.sunthemoon.advancedrocketrycommunity.machine.classic.adapter.ClassicNbtCanonicalHashTest.xml)
and [collector result](RESULTS-01.json) are preserved locally.
Actual exit 0; elapsed 53.200262 seconds, Gradle reports 52 seconds.
compileJava/compileTestJava and test executed. Gradle's test dependencies also
built/remapped its runtime/API JAR; this was not a full build/DataGen invocation.
The offline task name `downloadMcpConfig` is present; no network/download command
was separately launched. Existing deprecation warnings remain in the raw log.

Actual fresh XML contains **15 test cases / 1 suite / 0 failures, errors or
skips**, with declared counts checked against the case elements. Controls cover:
manual named-root/binary/modified-UTF frames and independent JDK reference digest;
native payload types; finite compound key permutations/ties; nested compound
versus list/array order; presence/type/unnormalized strings; aliases and mutation
between calls; independent per-call inputs; inclusive byte/depth/node budgets;
maximum bytes and larger component refusal; null/End/cycle/foreign rejection;
typed empty-list subtype retention; lossy NaN/UTF refusal; and exact-constructor
signed-zero emitted-byte fidelity. Finite different digests do not establish
general collision freedom. Signed-zero fixtures are mechanically constructed
exact native classes, not naturally loaded gameplay/persistence support.

Three actual runtime native class-resource hashes and code-source locations were
observed in the test XML. They match the configured mapped Forge 47.4.10 primary
archive SHA256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
No official class bodies/JAR are included; this is not a whole-runtime/server
classpath or native writer measurement.

No compile/test failure occurred in this K3 run. An earlier read command used
the nonexistent generic `docs/versions/v1.8.0.md` and exited 1; the actual named
version document was then read. That observation is retained in intake, not
represented as a Java failure or silently renamed passing command. Intake,
checkpoint and collector commands each have raw command/stamp/log/exit receipts.

## Storage, integration and remaining limits

After copying and verifying the fresh XML/results, only this worker's disposable
worktree `build` and `.gradle` directories were removed by native PowerShell.
[Cleanup result](CLEANUP-RESULTS-01.json) records exit 0, containment/reparse checks
and 58,780,198 deleted file bytes. Source files, committed baseline and all raw
evidence remain. No process was terminated. There is no copied full source tree,
redundant ZIP, server/world copy or artifact export in this handoff.

Root should apply only the two new postimages after different-agent review,
perform current-version regression, then commit/push its scoped phase. Until
that happens the proposal is uncommitted development work, not delivered ledger
content. Reverting before any future consumer simply removes the two new files.

Unimplemented/unrun: GuardTicket/native/resource capture, full hash/frame codec,
checkpoint/publication, persistence/save/carrier/removal, physical hatches,
lathe, registered GT, dedicated/native server, client/player V1/V2, performance,
full build/DataGen and all v1.8 Required Gates. No public API/runtime/Gate
admission is claimed. The Java slot is released and no further job is authorized.
