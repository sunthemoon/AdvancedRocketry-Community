from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import shutil
import subprocess

OUT = Path(__file__).parent
WT = Path('D:/GitHub/arce-v180-canonical-digest-20261004')
BASE = '3f3d62aed3980186fe0acc9592cf93ca436405fb'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

baseline = json.loads((OUT / 'BASELINE-MANIFEST-01.json').read_text(encoding='utf-8'))
changed = [name for name, value in baseline.items()
           if not (WT / name).is_file() or (WT / name).stat().st_size != value['bytes']
           or sha(WT / name) != value['sha256']]
assert not changed, changed
head = subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip()
assert head == BASE
names = ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java',
         'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java']
actual_new = subprocess.check_output(['git', '-C', str(WT), 'ls-files', '--others', '--exclude-standard', '-z'])
assert sorted(name.decode('utf-8') for name in actual_new.split(b'\0') if name) == sorted(names)
own = {}
patch = ''
for name in names:
    source = WT / name
    target = OUT / 'postimages' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    own[name] = {'bytes': source.stat().st_size, 'sha256': sha(source), 'preimage': 'ABSENT'}
    patch += ''.join(difflib.unified_diff([], source.read_text(encoding='utf-8').splitlines(keepends=True),
                                        fromfile='/dev/null', tofile='b/' + name))
(OUT / 'SOURCE-01.patch').write_text(patch, encoding='utf-8', newline='\n')
(OUT / 'OWN-FILES-01.json').write_text(json.dumps(own, indent=2) + '\n', encoding='utf-8')
result = subprocess.run(['git', '-c', 'core.autocrlf=false', '-C', str(WT), 'apply', '--reverse', '--check',
                         str(OUT / 'SOURCE-01.patch')], capture_output=True, text=True)
disk = {drive: {'free': shutil.disk_usage(drive).free} for drive in ['C:/', 'D:/']}
receipt = {'timestamp': datetime.now(timezone.utc).isoformat(), 'head': head,
           'baseline_count': len(baseline), 'baseline_changes': changed,
           'own': own, 'own_manifest_sha256': sha(OUT / 'OWN-FILES-01.json'),
           'patch_sha256': sha(OUT / 'SOURCE-01.patch'), 'disk': disk,
           'patch_reverse_check': {'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}}
(OUT / 'SOURCE-CHECKPOINT-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
assert result.returncode == 0
assert all(value['free'] >= 10_000_000_000 for value in disk.values()), disk
print(json.dumps(receipt))
