$ErrorActionPreference = 'Stop'
$evidence = 'C:/Users/Administrator/AppData/Local/Temp/ak3-a1db5e5ab0'
$workspace = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-canonical-digest-20261004').TrimEnd('\')
$result = Get-Content -LiteralPath "$evidence/RESULTS-01.json" -Raw -Encoding utf8 | ConvertFrom-Json
if ($result.exit -ne 0 -or -not $result.own_sources_unchanged -or $result.baseline_changes.Count -ne 0) {
    throw 'Test/source receipt is not a completed unchanged run'
}
foreach ($xml in $result.xml) {
    $path = Join-Path $evidence $xml.path
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $xml.sha256) {
        throw 'Copied XML identity mismatch'
    }
}
$targets = @('build', '.gradle') | ForEach-Object {
    $absolute = [IO.Path]::GetFullPath((Join-Path $workspace $_))
    if (-not $absolute.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Target is outside this author worktree'
    }
    $item = Get-Item -LiteralPath $absolute -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Target is a reparse point' }
    $children = @(Get-ChildItem -LiteralPath $absolute -Recurse -Force)
    if (@($children | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
        throw 'Disposable tree contains a reparse point'
    }
    $files = @($children | Where-Object { -not $_.PSIsContainer })
    @{path=$absolute; files=$files.Count; bytes=($files | Measure-Object Length -Sum).Sum}
}
$targets | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$evidence/CLEANUP-TARGETS-01.json" -Encoding utf8
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target.path -Recurse -Force
    if (Test-Path -LiteralPath $target.path) { throw 'Disposable directory still exists' }
}
@{deleted=$targets; deleted_file_bytes=($targets | Measure-Object bytes -Sum).Sum;
  preserved='Committed baseline, both new source/test files and copied evidence/XML/logs/manifests';
  java_process_operations=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$evidence/CLEANUP-RESULTS-01.json" -Encoding utf8
Get-Content -LiteralPath "$evidence/CLEANUP-RESULTS-01.json"
