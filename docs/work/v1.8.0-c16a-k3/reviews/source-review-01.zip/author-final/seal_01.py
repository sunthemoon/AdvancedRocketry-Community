from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).parent
WT = Path('D:/GitHub/arce-v180-canonical-digest-20261004')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

own = json.loads((OUT / 'OWN-FILES-01.json').read_text(encoding='utf-8'))
for name, value in own.items():
    assert sha(OUT / 'postimages' / name) == value['sha256'] == sha(WT / name)
    assert (OUT / 'postimages' / name).stat().st_size == value['bytes']
head = subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip()
assert head == '3f3d62aed3980186fe0acc9592cf93ca436405fb'
status = subprocess.check_output(['git', '-C', str(WT), 'status', '--porcelain']).decode()
assert all(line.startswith('?? ') for line in status.splitlines())
actual = subprocess.check_output(['git', '-C', str(WT), 'ls-files', '--others', '--exclude-standard', '-z'])
assert sorted(x.decode() for x in actual.split(b'\0') if x) == sorted(own)
prod = (OUT / 'postimages' / next(name for name in own if name.startswith('src/main/'))).read_text(encoding='utf-8')
assert prod.count('ClassicNbtCanonicalBytes.encode(') == 1
assert 'static final' not in prod and 'static String sha256(' in prod and 'getInstance("SHA-256")' in prod
links = []
for source in OUT.glob('*.md'):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', source.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('#'):
            continue
        resolved = (source.parent / target.split('#')[0]).resolve()
        assert resolved.is_relative_to(OUT.resolve()) and resolved.is_file(), (source.name, target)
        links.append({'source': source.name, 'target': target})
receipt = {'head': head, 'untracked_exactly_own_paths': True, 'own_postimages_unchanged': True,
           'local_links': links, 'missing_links': [], 'source_implements_only_k2_digest_composition': True,
           'full_source_export_or_archive_created': False}
(OUT / 'SEAL-CHECKS-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
files = sorted(path for path in OUT.rglob('*') if path.is_file()
               and path.name not in {'EVIDENCE-MANIFEST.json', 'seal-01.log', 'SEAL-RECEIPT-01.json'})
manifest = {path.relative_to(OUT).as_posix(): {'bytes': path.stat().st_size, 'sha256': sha(path)} for path in files}
target = OUT / 'EVIDENCE-MANIFEST.json'
assert not target.exists()
target.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for name, value in manifest.items():
    assert (OUT / name).stat().st_size == value['bytes'] and sha(OUT / name) == value['sha256']
result = {'manifest_sha256': sha(target), 'entries': len(manifest),
          'file_bytes': sum(value['bytes'] for value in manifest.values()),
          'handoff_sha256': sha(OUT / 'HANDOFF.md'), 'manifest_files_verified': True,
          'local_links_verified': len(links), 'ZIP_created': False}
(OUT / 'SEAL-RECEIPT-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
