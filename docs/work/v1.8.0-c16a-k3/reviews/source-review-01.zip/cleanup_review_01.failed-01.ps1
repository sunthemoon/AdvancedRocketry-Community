$ErrorActionPreference='Stop'
$w=[System.IO.Path]::GetFullPath('D:/GitHub/arce-v180-canonical-digest-review-20261004')
$e=[System.IO.Path]::GetFullPath('D:/ARCE-Task-Evidence/v1.8.0/ak3r-19c4b829a2')
$checks=Get-Content -LiteralPath ($e+'/REVIEW-CHECKS-04.json') -Raw | ConvertFrom-Json
if($checks.fresh_testcase_elements.tests -ne 23 -or $checks.fresh_testcase_elements.failures -ne 0){throw 'Fresh results not preserved'}
$job=Get-Content -LiteralPath ($e+'/SCOPED-RESULT-01.json') -Raw | ConvertFrom-Json
if($job.exit -ne 0){throw 'No completed granted job receipt'}
$active=@(Get-CimInstance Win32_Process -Filter "name = 'java.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.Contains($w)})
if($active.Count -ne 0){throw 'Owned Java command still present'}
$before=@(Get-PSDrive -Name C,D | Select-Object Name,Free)
$removed=@()
foreach($literal in @('D:/GitHub/arce-v180-canonical-digest-review-20261004/build','D:/GitHub/arce-v180-canonical-digest-review-20261004/.gradle')){
 if(-not (Test-Path -LiteralPath $literal)){continue}
 $resolved=[System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $literal).Path)
 if(-not $resolved.StartsWith($w+[System.IO.Path]::DirectorySeparatorChar,[System.StringComparison]::OrdinalIgnoreCase)){throw 'Outside explicit review worktree'}
 if($resolved -notin @($w+'\build',$w+'\.gradle')){throw 'Target is not an approved disposable folder'}
 $entry=Get-Item -LiteralPath $resolved
 if(($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Refuse reparse target'}
 $all=@(Get-ChildItem -LiteralPath $resolved -Recurse -Force)
 if(@($all | Where-Object {($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0}).Count -ne 0){throw 'Refuse reparse descendant'}
 $bytes=($all | Where-Object {-not $_.PSIsContainer} | Measure-Object -Property Length -Sum).Sum
 Remove-Item -LiteralPath $resolved -Recurse -Force
 $removed+=@{absolute_path=$resolved;bytes=[long]$bytes;absent_after=(-not (Test-Path -LiteralPath $resolved))}
}
$result=@{removed=$removed;removed_bytes=($removed | Measure-Object -Property bytes -Sum).Sum;free_before=$before;free_after=@(Get-PSDrive -Name C,D | Select-Object Name,Free);sources_evidence_preserved=$true;processes_terminated=0;own_matching_java_processes=0;utc=[DateTime]::UtcNow.ToString('o')}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($e+'/CLEANUP-REVIEW-01.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8
