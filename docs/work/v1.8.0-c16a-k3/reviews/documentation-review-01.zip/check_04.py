from pathlib import Path
import hashlib
import json
import re
import subprocess
import unittest
import io

OUT = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')
BASE = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def local_targets(text):
    return [token.split('#', 1)[0] for token in re.findall(r'\]\(([^)]+)\)', text)
            if not token.startswith(('https:', 'http:', '#'))]


class Controls(unittest.TestCase):
    def test_link_fragments_and_external_links(self):
        self.assertEqual(['a.md'], local_targets('[a](a.md#part) [b](https://example.invalid/a) [c](#head)'))
    def test_changed_input_is_not_an_unchanged_pin(self):
        self.assertNotEqual(sha(b'old'), sha(b'new'))
    def test_error_header_is_not_exception_occurrence(self):
        text = '[x/ERROR] one\n Exception: a\n trace ERROR prose\n[y/ERROR] two\n'
        self.assertEqual(2, len(re.findall(r'/ERROR\]', text)))


buf = io.StringIO()
control = unittest.TextTestRunner(stream=buf, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
(OUT / 'CONTROL-04.log').write_text(buf.getvalue(), encoding='utf-8')
assert control.wasSuccessful()

original_pins = json.loads((OUT / 'INPUT-PINS-02.json').read_text(encoding='utf-8'))
scope = ['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
         'docs/work/v1.8.0-c16a-k3/SOURCE-ACCEPTANCE-01.md', 'docs/work/v1.8.0-c16a-k3/VERIFICATION.md',
         'docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md',
         'docs/work/v1.8.0-c16a-save-guard/SAVE-REFUSAL-DISPOSITION-01.md']
links = []; drifts = []; later_pins = {}
(OUT / 'document-snapshots-04').mkdir(exist_ok=True)
for name in scope:
    path = ROOT / name
    raw = path.read_bytes()
    identity = {'sha256': sha(raw), 'bytes': len(raw)}
    later_pins[str(path)] = identity
    (OUT / 'document-snapshots-04' / path.name).write_bytes(raw)
    if identity != original_pins[str(path)]:
        drifts.append({'path': name, 'original': original_pins[str(path)], 'later': identity})
    for target in local_targets(raw.decode('utf-8')):
        assert 'Development-Docs' not in target
        destination = path.parent / target
        links.append({'source': name, 'target': target, 'exists': destination.is_file()})
assert all(row['exists'] for row in links)

task = ROOT / scope[4]
old = subprocess.check_output(['git', '-C', str(ROOT), 'show', BASE + ':' + scope[4]]).decode('utf-8')
new = task.read_text(encoding='utf-8')
def fixed_scope(text):
    return text.split('## Outcome and boundary', 1)[1].split('- [', 1)[0]
assert fixed_scope(old) == fixed_scope(new)

archive_sha_expected = {
    'advancedrocketry-community-1.20.1-1.8.0-dev-api.jar': '7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da',
    'advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar': '1368d531681032c3c70fa320fbe7697dff3f124e668c4f17176707220abef9d2',
    'advancedrocketry-community-1.20.1-1.8.0-dev.jar': '796c9611ec8d655398e5a046bfe6cc3f81b2c7880a19c835ea9ed301a990373e'}
prefix = 'D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/integration-artifacts-21/'
assert all(original_pins[str(Path(prefix + name))]['sha256'] == digest for name, digest in archive_sha_expected.items())

later = {}
for name in ['repository-boundary-23.result.json', 'repository-boundary-23.json',
             'repository-boundary-23.command.json', 'repository-boundary-23.log', 'markdown-links-19.json']:
    path = E / name
    if not path.is_file():
        later[name] = {'exists': False}
        continue
    raw = path.read_bytes()
    later_pins[str(path)] = {'sha256': sha(raw), 'bytes': len(raw)}
    later[name] = json.loads(raw) if name.endswith('.json') else {'sha256': sha(raw), 'bytes': len(raw)}

result = {'controls': {'tests': control.testsRun, 'failures': len(control.failures), 'errors': len(control.errors)},
          'targeted_links': len(links), 'missing_links': [], 'document_drifts': drifts,
          'computation_scope_unchanged_from_task_at_code_commit': True,
          'prior_artifact_pins_match_preceding_declared_K2_identities': True,
          'later_final_receipts': later, 'later_pins': later_pins,
          'note': 'Later Root final checks observed separately; no execution or full audit of its private exclusion wrapper claimed'}
(OUT / 'CHECK-04.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ['controls', 'targeted_links', 'missing_links', 'document_drifts']}))
