from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')
BASE = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'
PINS = {}


def blob(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    assert 'Development-Docs' not in str(path)
    raw = path.read_bytes()
    PINS[str(path)] = blob(raw)
    return raw


def js(path):
    return json.loads(read(path))


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def git(*args):
    result = subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True)
    assert result.returncode == 0, (args, result.stderr)
    return result.stdout


assert git('rev-parse', 'HEAD').decode().strip() == BASE
scope = ['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
         'docs/work/v1.8.0-c16a-k3/SOURCE-ACCEPTANCE-01.md', 'docs/work/v1.8.0-c16a-k3/VERIFICATION.md',
         'docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md',
         'docs/work/v1.8.0-c16a-save-guard/SAVE-REFUSAL-DISPOSITION-01.md']
snapshots = OUT / 'document-snapshots'
snapshots.mkdir(exist_ok=True)
for path in scope:
    raw = read(ROOT / path)
    (snapshots / Path(path).name).write_bytes(raw)
log_path = 'docs/work/v1.8.0-implementation-log.md'
read(ROOT / log_path)
(OUT / 'DOCUMENT-DELTA-01.patch').write_bytes(git('diff', BASE, '--', *scope, log_path))

mandatory = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
             'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
             'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
             'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
             'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
for path in mandatory:
    read(ROOT / path)

build = js(E / 'build-result-01.json')
gt = js(E / 'gt-result-01.json')
for name, result in [('build', build), ('gt', gt)]:
    assert blob(read(E / (name + '-01.log'))) == result['raw_log']
    command = js(E / (name + '-command-01.json'))
    assert command['started_utc'] == result['started_utc']
    duration = (datetime.fromisoformat(result['finished_utc']) - datetime.fromisoformat(result['started_utc'])).total_seconds()
    assert abs(duration - result['elapsed_seconds']) < 0.000001
    assert result['exit'] == 0
    assert command['JAVA_HOME'] == 'C:/Program Files/Java/jdk-17.0.7'
    assert command['command'][1:5] == ['--offline', '--no-daemon', '--max-workers=2', '-Dorg.gradle.jvmargs=-Xmx2G']
    disk = js(E / (name + '-disk-precheck-01.json'))
    assert all(n >= disk['threshold_bytes'] == 10_000_000_000 for n in disk['free_bytes'].values())

buildtext = read(E / 'build-01.log').decode('utf-8')
assert re.search(r'Caching: total files: 771, .*written: 0', buildtext)
assert '> Task :compileJava FROM-CACHE' in buildtext
assert '> Task :compileTestJava FROM-CACHE' in buildtext
assert '> Task :test\n' in buildtext.replace('\r\n', '\n')
assert 'BUILD SUCCESSFUL' in buildtext

junit = js(E / 'JUNIT-01.json')
actual = dict(tests=0, failures=0, errors=0, skipped=0)
declared = dict(actual)
for name, pin in junit['xml'].items():
    raw = read(E / 'junit' / name)
    assert blob(raw) == pin
    tree = ET.fromstring(raw)
    cases = tree.findall('testcase')
    actual['tests'] += len(cases)
    for tag in ['failure', 'error', 'skipped']:
        actual[{'failure': 'failures', 'error': 'errors', 'skipped': 'skipped'}[tag]] += sum(len(c.findall(tag)) for c in cases)
    for key in declared:
        declared[key] += int(tree.get(key, '0'))
assert actual == declared == junit['actual'] == junit['declared']
assert len(junit['xml']) == junit['suites']

gtfacts = js(E / 'GAMETEST-01.json')
native = read(E / 'gt-native-01.log')
assert blob(native) == gtfacts['native_log']
assert blob(read(E / 'gt-01.log')) == gtfacts['gradle_log']
assert re.findall(r'All (\d+) required tests passed', native.decode('utf-8')) == ['464']
assert re.findall(r'All (\d+) required tests passed', read(E / 'gt-01.log').decode('utf-8')) == ['464']
assert len(re.findall(r'/ERROR\]', native.decode('utf-8'))) == gtfacts['logger_ERROR_lines'] == 61

static = js(E / 'STATIC-RESULTS-01.json')
for job in static['jobs']:
    raw = read(E / (job['name'] + '-01.log'))
    assert hashlib.sha256(raw).hexdigest() == job['log_sha256']
    js(E / (job['name'] + '-command-01.json'))
assert re.search(rb'Ran 90 tests.*?OK', read(E / 'focused-python-01.log'), re.S)

manifest = js(E / 'SOURCE22-MANIFEST-01.json')
assert len(manifest) == 2992
source_drifts = []
for name, pin in manifest.items():
    assert 'Development-Docs' not in name and name != 'docs/11-RISK-REGISTER.md'
    if blob(read(ROOT / name)) != pin:
        source_drifts.append(name)
precheck = js(E / 'SOURCE22-PRECHECK-01.json')
assert precheck['inputs'] == 2992 and precheck['unchanged_baseline_inputs'] == 2990
commit = js(E / 'CODE-COMMIT-PUSH-01.json')
assert commit['commit'] == BASE
changed = git('diff-tree', '--no-commit-id', '--name-only', '-r', BASE).decode().splitlines()
assert sorted(changed) == sorted(commit['files'])
for name in commit['files']:
    assert git('show', BASE + ':' + name) == read(ROOT / name)
for index, receipt in enumerate(commit['commands'], 1):
    assert hashlib.sha256(read(E / f'code-commit01-{index:02d}.log')).hexdigest() == receipt['log_sha256']
    cmd = js(E / f'code-commit01-{index:02d}.command.json')
    assert cmd['command'] == receipt['command'] and cmd['exit'] == receipt['exit']

generated = {name.removeprefix('src/generated/v1.8/resources/'): pin for name, pin in manifest.items()
             if name.startswith('src/generated/v1.8/resources/')}
assert len(generated) == 771
artifact_result = []
previous = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/integration-artifacts-21')
for row in js(E / 'ARTIFACTS-01.json'):
    data = read(E / 'artifacts' / row['name'])
    assert blob(data) == {key: row[key] for key in ['sha256', 'bytes']}
    with zipfile.ZipFile(io.BytesIO(data)) as jar:
        assert jar.testzip() is None and len(jar.namelist()) == row['entries']
        assert len(jar.namelist()) == len(set(jar.namelist()))
        if not row['name'].endswith('-api.jar'):
            assert all(blob(jar.read(name)) == pin for name, pin in generated.items())
        if row['name'].endswith('-sources.jar'):
            members = [name for name in jar.namelist() if name.endswith('.java')]
            payload = b''.join((BASE + ':src/main/java/' + name + '\n').encode() for name in members)
            objects = subprocess.run(['git', '-C', str(ROOT), 'cat-file', '--batch'], input=payload, capture_output=True)
            assert objects.returncode == 0
            output = io.BytesIO(objects.stdout)
            for name in members:
                header = output.readline().decode().strip().split()
                assert header[1] == 'blob'
                raw = output.read(int(header[2])); assert output.read(1) == b'\n'
                assert raw == jar.read(name), name
            assert len(members) == row['committable_main_java_compared'] == 1211
        old_data = read(previous / row['name'])
        with zipfile.ZipFile(io.BytesIO(old_data)) as old:
            assert all(name in jar.namelist() and old.read(name) == jar.read(name) for name in old.namelist())
            assert sorted(set(jar.namelist()) - set(old.namelist())) == row['added_members']
        if row['name'].endswith('-api.jar'):
            assert data == old_data
    artifact_result.append({'name': row['name'], **blob(data), 'entries': row['entries'],
                            'added_members': row['added_members'], 'old_members_changed': []})

archive_receipt = js(E / 'SOURCE-REVIEW-ARCHIVE-01.json')
archive_data = read(Path(archive_receipt['location']))
assert blob(archive_data) == {key: archive_receipt[key] for key in ['bytes', 'sha256']}
with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == archive_receipt['entries']
    manifest_name = next(name for name in archive.namelist() if name.endswith('EVIDENCE-MANIFEST.json'))
    innerraw = archive.read(manifest_name)
    assert hashlib.sha256(innerraw).hexdigest() == archive_receipt['original_internal_manifest_sha256']
    inner = json.loads(innerraw)
    save('SOURCE-REVIEW-MANIFEST-SHAPE-01.json', {'keys': list(inner), 'manifest_entry': manifest_name})
    rows = inner.get('files', inner)
    rootprefix = manifest_name.removesuffix('EVIDENCE-MANIFEST.json')
    for name, row in rows.items():
        assert blob(archive.read(rootprefix + name)) == {key: row[key] for key in ['bytes', 'sha256']}
    report_name = next(name for name in archive.namelist() if name.endswith('REVIEW-01.md'))
    assert hashlib.sha256(archive.read(report_name)).hexdigest() == 'bf4c35622a6af1c8d80215c16bec9ee2a6efbefba88af83cb1f7a165a7e5402a'
    archive_count = len(rows)

guard_report = ROOT / 'docs/work/v1.8.0-c16a-save-guard/reviews/save-refusal-impact-01/REVIEW-01.md'
assert hashlib.sha256(read(guard_report)).hexdigest() == '3d04a317ce519df1314fe642681af0fa50127c081e9ecddfcbfd053afb60bb87'
save('RESULT-01.json', {'base_commit': BASE, 'timestamp': datetime.now(timezone.utc).isoformat(),
    'source_drifts': source_drifts, 'junit': {'suites': len(junit['xml']), 'actual': actual, 'declared': declared},
    'generated_in_both_non_api_jars': len(generated), 'gametest_required_passed': 464, 'ERROR_headers': 61,
    'artifacts': artifact_result, 'source_review_manifested_files': archive_count,
    'document_findings_require_manual_review': True,
    'scope': 'Root documentation/evidence audit, not independent code review of own K3 implementation or Java replay'})
save('INPUT-PINS-01.json', PINS)
print(json.dumps({'junit': actual, 'suites': len(junit['xml']), 'source_drifts': source_drifts,
                  'source_review_manifested_files': archive_count, 'selected_inputs': len(PINS)}))
