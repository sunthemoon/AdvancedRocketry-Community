from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).parent
links = []
for name in ['REVIEW-01.md']:
    path = ROOT / name
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if target.startswith(('http:', 'https:', '#')):
            continue
        assert (path.parent / target.split('#', 1)[0]).is_file(), target
        links.append(target)
rows = {path.relative_to(ROOT).as_posix(): {'bytes': path.stat().st_size,
                                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        for path in sorted(ROOT.rglob('*')) if path.is_file()
        and path.name not in {'EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt'}}
manifest = {'scope': 'K3 Root-owned documentation/evidence review; underlying K3 source authored by reviewer; no self-source verdict',
            'code_commit': '1ece7e9d2515003ca705b5634ef654a6bcae8f89',
            'file_count': len(rows), 'total_bytes': sum(row['bytes'] for row in rows.values()),
            'local_report_links': len(links), 'files': rows,
            'storage': 'Internal loose evidence only; no ZIP/source export/JAR copy'}
raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode('utf-8')
(ROOT / 'EVIDENCE-MANIFEST.json').write_bytes(raw)
entries = {**rows, 'EVIDENCE-MANIFEST.json': {'sha256': hashlib.sha256(raw).hexdigest()}}
(ROOT / 'SHA256SUMS.txt').write_text(''.join(row['sha256'] + '  ' + path + '\n' for path, row in sorted(entries.items())), encoding='utf-8')
for path, row in rows.items():
    value = (ROOT / path).read_bytes()
    assert len(value) == row['bytes'] and hashlib.sha256(value).hexdigest() == row['sha256']
print(json.dumps({'files': len(rows), 'bytes': manifest['total_bytes'], 'links': len(links), 'mismatches': 0,
                  'report_sha256': rows['REVIEW-01.md']['sha256'], 'manifest_sha256': hashlib.sha256(raw).hexdigest(),
                  'checksums_sha256': hashlib.sha256((ROOT / 'SHA256SUMS.txt').read_bytes()).hexdigest()}))
