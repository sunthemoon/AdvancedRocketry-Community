from pathlib import Path
import hashlib
import io
import json
import re
import zipfile

OUT = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


pins = {}
zip_path = ROOT / 'docs/work/v1.8.0-c16a-k3/ROOT-INTEGRATION-22-COMPACT-01.zip'
raw = zip_path.read_bytes(); pins[str(zip_path)] = identity(raw)
assert pins[str(zip_path)] == {'bytes': 741221, 'sha256': 'ac9b47b78f4cbce140b235974d4e68e2587083c87159e9ec19a634b48a35081d'}
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == 404
    name = next(name for name in archive.namelist() if name.endswith('EVIDENCE-MANIFEST.json'))
    innerraw = archive.read(name)
    assert hashlib.sha256(innerraw).hexdigest() == '00c51fdff0573284a1a177cec7bfacde078a91704feb972f4bad2e594add7325'
    inner = json.loads(innerraw)
    rows = inner.get('files', inner)
    prefix = name.removesuffix('EVIDENCE-MANIFEST.json')
    for path, row in rows.items():
        assert 'Development-Docs' not in path
        assert identity(archive.read(prefix + path)) == {key: row[key] for key in ['sha256', 'bytes']}
    root_files = len(rows)

guard = ROOT / 'docs/work/v1.8.0-c16a-save-guard/reviews/save-refusal-impact-01'
manifest_path = guard / 'EVIDENCE-MANIFEST.json'
raw = manifest_path.read_bytes(); pins[str(manifest_path)] = identity(raw)
assert hashlib.sha256(raw).hexdigest() == '373dc11496fb4e326f8eef66548ef5bafcf2eebce34356888d76ce696ae809a9'
manifest = json.loads(raw); guardrows = manifest.get('files', manifest)
for path, row in guardrows.items():
    assert 'Development-Docs' not in path
    data = (guard / path).read_bytes()
    pins[str(guard / path)] = identity(data)
    assert identity(data) == {key: row[key] for key in ['sha256', 'bytes']}
assert len(guardrows) == 36

result_path = E / 'repository-boundary-23.result.json'
receipt = json.loads(result_path.read_bytes())
log = (E / 'repository-boundary-23.log').read_bytes()
pins[str(result_path)] = identity(result_path.read_bytes())
pins[str(E / 'repository-boundary-23.log')] = identity(log)
assert hashlib.sha256(log).hexdigest() == receipt['log_sha256']
text = log.decode('utf-8')
assert len(re.findall(r'^\[PASS\]', text, re.M)) == 45
assert 'Summary: 45 passed, 0 pending, 0 warnings, 0 failed' in text
assert receipt['exit'] == 0

result = {'root_compact_archive': pins[str(zip_path)], 'root_archive_entries': 404,
          'root_manifested_files': root_files, 'guard_manifested_files': 36,
          'fresh_repository_log_PASS_lines': 45, 'fresh_repository_exit': receipt['exit'],
          'fresh_repository_elapsed_seconds': receipt['elapsed_seconds'],
          'pins': pins, 'scope': 'Integrity/recorded claims only; no validator execution, code self-review or native replay'}
(OUT / 'CHECK-05.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ['root_archive_entries', 'root_manifested_files',
                  'guard_manifested_files', 'fresh_repository_log_PASS_lines', 'fresh_repository_exit']}))
