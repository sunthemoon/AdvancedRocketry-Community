"""Completed repository validation and compact Root archive, read-only."""
import json
import re
import zipfile
from pathlib import Path
import audit_build_packages as core


def main():
    root = core.ROOT_EVIDENCE
    cmd = core.load(root / 'repository-boundary-23.command.json')
    result = core.load(root / 'repository-boundary-23.result.json')
    inventory = core.load(root / 'repository-boundary-23.json')
    raw = core.read(root / 'repository-boundary-23.log')
    wrapper = core.read(root / 'validate_repository_boundary23.py')
    runner = core.read(root / 'run_repository23.py')
    core.require(result['exit'] == inventory['exit'] == 0, 'Repository validation exit')
    core.require(core.record(raw)['sha256'] == result['log_sha256'] == 'c94019a11bfacdedace2433fc95da4f10bad7a3d8995530c44b5fd75608d605b', 'Repository log pin')
    core.require(cmd['external_governance_and_validator_pins'] == result['external_governance_and_validator_postpins'] and result['pinned_inputs_unchanged'], 'Repository pre/post pins')
    core.require(inventory['validator_sha256'] == cmd['external_governance_and_validator_pins']['scripts/validate_repository.py'], 'Original validator pin')
    named_pin_checks = {}
    for name, sha in cmd['external_governance_and_validator_pins'].items():
        data = core.read(Path('D:/GitHub/AdvancedRocketry-Community') / name)
        core.require(core.record(data)['sha256'] == sha, f'Named external current pin: {name}')
        named_pin_checks[name] = core.record(data)
    text = raw.decode('utf-8')
    statuses = re.findall(r'^\[(PASS|PENDING|WARN|WARNING|FAIL)\] ', text, re.MULTILINE)
    measured = {k: statuses.count(k) for k in ('PASS', 'PENDING', 'WARN', 'WARNING', 'FAIL')}
    core.require(measured == {'PASS': 45, 'PENDING': 0, 'WARN': 0, 'WARNING': 0, 'FAIL': 0}, 'Actual full validator records')
    summaries = [line for line in text.splitlines() if line.startswith('Summary: ')]
    core.require(summaries == ['Summary: 45 passed, 0 pending, 0 warnings, 0 failed'], 'Full validator summary')
    prefix = 'AdvancedRocketry-Community-v1plus-Development-Docs/'
    for call in inventory['calls']:
        args = call['command']
        exclusion = '--exclude=/' + prefix
        others = '--others' in args
        core.require(call['foreign_directory_excluded'] == others and args.count(exclusion) == int(others), 'Literal inventory exclusion scope')
        core.require('ls-files' in args and '--cached' in args, 'Named inventory command shape')
    core.require(len(inventory['calls']) == 2, 'Two inventory observations')
    wrapper_text = wrapper.decode()
    core.require("prefix = '" + prefix + "'" in wrapper_text and "args.append('--exclude=/' + prefix)" in wrapper_text, 'Actual exclusion implementation')
    core.require('validator._bounded_git_stdout = inventory' in wrapper_text and 'code = validator.main()' in wrapper_text, 'Actual wrapper scope')
    core.require(not result['gate_claim'] and not inventory['release_gate_claimed'], 'Static Gate qualification')

    archive = root / 'ROOT-INTEGRATION-22-COMPACT-01.zip'
    archive_pin = core.record(core.read(archive))
    core.require(archive_pin == {'bytes': 741221, 'sha256': 'ac9b47b78f4cbce140b235974d4e68e2587083c87159e9ec19a634b48a35081d'}, 'Final compact archive pin')
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        core.names_valid(names)
        core.require(z.testzip() is None and len(names) == 404, 'Compact archive CRC/count')
        core.require(not any(n.endswith(('.jar', '.zip')) or n.startswith('src/') for n in names), 'No artifact archive or whole source export in compact')
        manifest_bytes = z.read('EVIDENCE-MANIFEST-01.json')
        core.require(core.record(manifest_bytes)['sha256'] == '00c51fdff0573284a1a177cec7bfacde078a91704feb972f4bad2e594add7325', 'Final compact internal manifest')
        manifest = json.loads(manifest_bytes, object_pairs_hook=core.unique_object)
        core.require(manifest['schema'] == 1 and manifest['tested_code_commit'] == '1ece7e9d2515003ca705b5634ef654a6bcae8f89', 'Final compact schema/commit')
        files = manifest['files']
        paths = [row['path'] for row in files]
        core.require(len(paths) == len(set(paths)) and set(names) == set(paths) | {'EVIDENCE-MANIFEST-01.json'}, 'Complete compact payload inventory')
        for row in files:
            core.safe_name(row['path'])
            core.require(set(row) == {'path', 'bytes', 'sha256'} and core.record(z.read(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')}, f'Compact payload pin: {row}')
        # Bind all previously measured Root payloads that this compact contains.
        prior = json.loads((core.HERE / 'FINAL-RECEIPTS-AUDIT-01.json').read_bytes())
        rebound = 0
        for locator, pin in prior['external_inputs'].items():
            path = Path(locator)
            try:
                rel = path.relative_to(root).as_posix()
            except ValueError:
                continue
            if rel in paths:
                core.require(core.record(z.read(rel)) == pin, f'Compact prior measured input: {rel}')
                rebound += 1
        links = json.loads(z.read('markdown-links-19.json'))
        archive_measurement = {'input': archive_pin, 'entries': len(names), 'payload_files': len(files),
            'all_CRC_and_payload_hashes_match': True, 'internal_manifest': core.record(manifest_bytes),
            'prior_audited_root_payloads_rebound': rebound, 'initial_links_receipt': links,
            'final_current_links_claimed': False, 'source_or_jar_exported_by_auditor': False}
    output = {'scope': 'Actual completed full-static receipt and compact evidence packaging only',
              'command': cmd, 'result': result, 'inventory_receipt': inventory, 'actual_status_records': measured,
              'literal_private_untracked_inventory_exclusion': prefix, 'wrapper': core.record(wrapper),
              'runner': core.record(runner), 'named_governance_postpins_measured': named_pin_checks,
              'compact_archive': archive_measurement, 'external_inputs': core.INPUTS,
              'validator_reexecuted_by_auditor': False, 'private_bundle_read_or_walked': False,
              'final_docs_links_pending': True, 'whole_version_gate_claimed': False, 'R021_closed': False}
    dest = core.HERE / 'FULL-STATIC-ARCHIVE-AUDIT-01.json'
    core.require(not dest.exists(), 'Do not overwrite result')
    dest.write_bytes((json.dumps(output, indent=2) + '\n').encode())
    print(json.dumps({'full_validator_records': measured, 'exit': result['exit'],
                      'elapsed': result['elapsed_seconds'], 'archive_entries': len(names), 'archive_payloads': len(files),
                      'measured_payloads_rebound': rebound, 'result': core.record(dest.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
