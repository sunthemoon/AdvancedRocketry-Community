"""Read-only measurement of named immutable K3 integration evidence."""
import datetime as dt
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path, PurePosixPath

HERE = Path(__file__).parent
ROOT_EVIDENCE = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')
PREVIOUS = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41')
OLD_MANIFEST = PREVIOUS / 'integration-21-source-manifest-r1.json'
NEW = {
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java': '6ca5b028317766e9106953a011134096e896b08b557db041eb0c92ad493b5ec8',
    'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java': 'cf295730469021a70dc2eba85d030379860b16388025359eafb249a526d08c27',
}
OLD_PINS = {
    '-api.jar': '7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da',
    '-sources.jar': '1368d531681032c3c70fa320fbe7697dff3f124e668c4f17176707220abef9d2',
    '-dev.jar': '796c9611ec8d655398e5a046bfe6cc3f81b2c7880a19c835ea9ed301a990373e',
}
NEW_PINS = {
    '-api.jar': '7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da',
    '-sources.jar': 'b7ae68c8066261d3d23fe5bddf3cce84a3967bd93d178f3c075db3395d0c4582',
    '-dev.jar': '26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a',
}
INPUTS = {}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def record(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    data = path.read_bytes()
    before = INPUTS.setdefault(str(path), record(data))
    require(before == record(data), f'Input changed during audit: {path}')
    return data


def unique_object(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, f'Duplicate JSON key: {name}')
        result[name] = value
    return result


def load(path):
    return json.loads(read(path), object_pairs_hook=unique_object)


def safe_name(name, allow_directory=False):
    require(isinstance(name, str) and name and '\\' not in name, f'Unsafe name: {name!r}')
    require(not name.startswith('/') and ':' not in name, f'Absolute/drive name: {name!r}')
    parts = name.rstrip('/').split('/')
    require(all(part not in ('', '.', '..') for part in parts), f'Unsafe path component: {name!r}')
    require(allow_directory or not name.endswith('/'), f'Unexpected directory: {name!r}')
    require(not any('advancedrocketry-community-v1plus-development-docs' in part.lower() for part in parts), 'Protected bundle path')
    return name


def manifest_shape(manifest):
    require(isinstance(manifest, dict), 'Manifest must be object')
    folded = set()
    for name, row in manifest.items():
        safe_name(name)
        require(name.casefold() not in folded, f'Case alias: {name}')
        folded.add(name.casefold())
        require(set(row) == {'bytes', 'sha256'}, f'Manifest fields: {name}')
        require(type(row['bytes']) is int and row['bytes'] >= 0, f'Manifest size: {name}')
        require(re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None, f'Manifest SHA: {name}')


def xml_counts(data):
    tree = ET.fromstring(data)
    require(tree.tag == 'testsuite', 'Expected a single Gradle testsuite')
    cases = tree.findall('testcase')
    actual = {'tests': len(cases), **{key: sum(len(c.findall(tag)) for c in cases)
              for tag, key in [('failure', 'failures'), ('error', 'errors'), ('skipped', 'skipped')]}}
    declared = {key: int(tree.attrib[key]) for key in actual}
    require(actual == declared, f'XML count disagreement {actual} != {declared}')
    return actual, {'suite': tree.get('name'), 'timestamp': tree.get('timestamp'),
                    'hostname': tree.get('hostname'), 'time': tree.get('time')}


def names_valid(names):
    require(len(names) == len(set(names)), 'Duplicate ZIP member')
    folded = set()
    for name in names:
        safe_name(name, allow_directory=True)
        require(name.casefold() not in folded, f'Case-alias ZIP member: {name}')
        folded.add(name.casefold())


def sum_counts(rows):
    return {key: sum(row[key] for row in rows) for key in ('tests', 'failures', 'errors', 'skipped')}


def controls():
    observations = []

    def rejects(label, callable_):
        try:
            callable_()
        except (AssertionError, ET.ParseError, ValueError):
            observations.append({'control': label, 'rejected': True})
        else:
            raise AssertionError(f'Negative control was accepted: {label}')

    rejects('parent manifest path', lambda: safe_name('src/../secret'))
    rejects('absolute manifest path', lambda: safe_name('/src/example'))
    rejects('drive manifest path', lambda: safe_name('C:/example'))
    rejects('backslash manifest path', lambda: safe_name('src\\example'))
    rejects('protected bundle manifest path', lambda: safe_name('AdvancedRocketry-Community-v1plus-Development-Docs/example'))
    rejects('case-alias ZIP names', lambda: names_valid(['a/Foo.java', 'a/foo.java']))
    rejects('duplicate ZIP names', lambda: names_valid(['a.java', 'a.java']))
    rejects('duplicate JSON key', lambda: json.loads('{"a":1,"a":2}', object_pairs_hook=unique_object))
    rejects('XML declaration masks failure', lambda: xml_counts(b'<testsuite tests="1" failures="0" errors="0" skipped="0"><testcase><failure/></testcase></testsuite>'))
    rejects('XML declaration inflates count', lambda: xml_counts(b'<testsuite tests="2" failures="0" errors="0" skipped="0"><testcase/></testsuite>'))
    for tag, key in [('failure', 'failures'), ('error', 'errors'), ('skipped', 'skipped')]:
        attrs = {'tests': 1, 'failures': 0, 'errors': 0, 'skipped': 0}
        attrs[key] = 1
        text = '<testsuite ' + ' '.join(f'{k}="{v}"' for k, v in attrs.items()) + f'><testcase><{tag}/></testcase></testsuite>'
        actual, _ = xml_counts(text.encode())
        require(actual[key] == 1, f'{tag} control not observed')
        observations.append({'control': f'actual {tag} element counted', 'measured': actual})
    return observations


def main():
    original = load(OLD_MANIFEST)
    require(INPUTS[str(OLD_MANIFEST)]['sha256'] == '2a2e4973bd1d214a89ab3e340c8977c66b574ff680a77d2dc49f3bfffaae0a46', 'Old source manifest pin')
    current = load(ROOT_EVIDENCE / 'SOURCE22-MANIFEST-01.json')
    manifest_shape(original)
    manifest_shape(current)
    changed = [name for name, row in original.items() if current.get(name) != row]
    removed = sorted(set(original) - set(current))
    added = sorted(set(current) - set(original))
    require(not changed and not removed and added == sorted(NEW), f'Source delta {changed}, {removed}, {added}')
    require(len(original) == 2990 and len(current) == 2992, 'Source counts')
    for name, sha in NEW.items():
        require(current[name]['sha256'] == sha, f'New source pin {name}')

    precheck = load(ROOT_EVIDENCE / 'SOURCE22-PRECHECK-01.json')
    application = load(ROOT_EVIDENCE / 'SOURCE-APPLICATION-01.json')
    require(precheck['new_paths_only'] == added and precheck['unchanged_baseline_inputs'] == len(original)
            and precheck['inputs'] == len(current), 'Source precheck agrees')
    require(precheck['baseline_r1_manifest_sha256'] == INPUTS[str(OLD_MANIFEST)]['sha256'], 'Precheck baseline pin')
    require(application['applied_source'] == NEW, 'Applied source receipt disagrees')

    command = load(ROOT_EVIDENCE / 'build-command-01.json')
    result = load(ROOT_EVIDENCE / 'build-result-01.json')
    disk = load(ROOT_EVIDENCE / 'build-disk-precheck-01.json')
    raw = read(ROOT_EVIDENCE / 'build-01.log')
    require(record(raw) == result['raw_log'], 'Build log pin')
    require(result['exit'] == 0, 'Build exit')
    expected_tail = ['--offline', '--no-daemon', '--max-workers=2', '-Dorg.gradle.jvmargs=-Xmx2G', 'clean', 'build', 'test', 'runData']
    require(command['command'][1:] == expected_tail, 'Build command scope')
    require(command['JAVA_HOME'] == 'C:/Program Files/Java/jdk-17.0.7', 'Java17 location')
    require(command['started_utc'] == result['started_utc'], 'Command/result start')
    seconds = (dt.datetime.fromisoformat(result['finished_utc']) - dt.datetime.fromisoformat(result['started_utc'])).total_seconds()
    require(abs(seconds - result['elapsed_seconds']) < 0.00001, 'Elapsed arithmetic')
    require(disk['threshold_bytes'] == 10_000_000_000 and all(disk['free_bytes'][drive] >= disk['threshold_bytes'] for drive in ('C', 'D')), 'Disk admission receipt')
    log = raw.decode('utf-8')
    require('> Task :clean' in log and re.search(r'^> Task :test\s*$', log, re.MULTILINE) is not None, 'Clean/test execution not observed')
    require('BUILD SUCCESSFUL' in log and 'BUILD FAILED' not in log, 'Build completion lines')
    cache_lines = re.findall(r'Caching: total files: (\d+), old count: (\d+), new count: (\d+), removed stale: (\d+), written: (\d+)', log)
    require(cache_lines == [('771', '771', '772', '0', '0')], f'DataGen cache {cache_lines}')

    junit = load(ROOT_EVIDENCE / 'JUNIT-01.json')
    xml_details = {}
    for name, pin in sorted(junit['xml'].items()):
        require(PurePosixPath(safe_name(name)).name == name, 'XML path scope')
        data = read(ROOT_EVIDENCE / 'junit' / name)
        require(record(data) == pin, f'XML pin {name}')
        actual, metadata = xml_counts(data)
        xml_details[name] = {'input': pin, 'actual': actual, **metadata}
    xml_names = {p.name for p in (ROOT_EVIDENCE / 'junit').iterdir() if p.is_file()}
    require(xml_names == set(junit['xml']), 'Extra/missing copied XML')
    actual = sum_counts([r['actual'] for r in xml_details.values()])
    require(actual == junit['actual'] == junit['declared'], 'Aggregate XML counts')
    require(junit['suites'] == len(xml_details) == 330 and actual == {'tests': 1765, 'failures': 0, 'errors': 0, 'skipped': 0}, 'Observed suite/case counts')

    generated = {name.removeprefix('src/generated/v1.8/resources/'): row for name, row in current.items()
                 if name.startswith('src/generated/v1.8/resources/')}
    require(len(generated) == 771 and not any('.cache' in PurePosixPath(name).parts for name in generated), 'Generated source pins')
    artifacts = load(ROOT_EVIDENCE / 'ARTIFACTS-01.json')
    require(len(artifacts) == 3, 'Three artifacts')
    artifact_details = []
    for receipt in artifacts:
        name = receipt['name']
        require(PurePosixPath(safe_name(name)).name == name, 'Artifact name')
        path = ROOT_EVIDENCE / 'artifacts' / name
        old_path = PREVIOUS / 'integration-artifacts-21' / name
        suffix = next(s for s in OLD_PINS if name.endswith(s))
        old_bytes = read(old_path)
        new_bytes = read(path)
        require(record(old_bytes)['sha256'] == OLD_PINS[suffix], f'Old JAR pin {name}')
        require(record(new_bytes) == {k: receipt[k] for k in ('bytes', 'sha256')}, f'Current artifact receipt {name}')
        require(record(new_bytes)['sha256'] == NEW_PINS[suffix], f'Current artifact pin {name}')
        with zipfile.ZipFile(path) as new_zip, zipfile.ZipFile(old_path) as old_zip:
            names, old_names = new_zip.namelist(), old_zip.namelist()
            names_valid(names)
            names_valid(old_names)
            require(new_zip.testzip() is None and old_zip.testzip() is None, f'CRC {name}')
            changed_members = [n for n in old_names if n not in names or new_zip.read(n) != old_zip.read(n)]
            added_members = sorted(set(names) - set(old_names))
            api, sources = suffix == '-api.jar', suffix == '-sources.jar'
            expected_added = [] if api else ['io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash' + ('.java' if sources else '.class')]
            require(not changed_members and added_members == expected_added, f'Artifact member delta {name}')
            require(receipt['entries'] == len(names) and receipt['added_members'] == added_members and receipt['old_members_changed'] == changed_members, 'Artifact member receipt')
            if api:
                require(new_bytes == old_bytes, 'API whole JAR differs')
            else:
                for member, pin in generated.items():
                    require(record(new_zip.read(member)) == pin, f'Generated bytes {name}:{member}')
            java_members = [n for n in names if n.endswith('.java')] if sources else []
            for member in java_members:
                require(record(new_zip.read(member)) == current['src/main/java/' + member], f'Main Java manifest bytes {member}')
            require(len(java_members) == (1211 if sources else 0), 'Sources Java count')
            measured = {'name': name, 'input': record(new_bytes), 'old_input': record(old_bytes),
                        'entries': len(names), 'old_entries': len(old_names), 'added': added_members,
                        'removed_or_changed_old_members': changed_members, 'old_members_bytes_compared': len(old_names),
                        'generated_bytes_compared': 0 if api else len(generated), 'main_java_bytes_compared': len(java_members),
                        'api_whole_byte_equality_checked': api}
            artifact_details.append(measured)

    synthetic = controls()
    output = {'scope': 'Archived source manifests/completed Root build and package only; GT/static/commit still pending',
              'source': {'baseline': len(original), 'current': len(current), 'added': added, 'removed': removed,
                         'changed_baseline': changed, 'all_relative_paths_safe_unique': True,
                         'baseline_code_receipt': precheck['code_baseline'], 'documentation_tip_receipt': precheck['documentation_tip']},
              'build': {'command': command, 'result': result, 'disk': disk, 'datagen_cache_counts': cache_lines,
                        'logger_WARN_lines': len(re.findall(r'/WARN\]', log)),
                        'logger_ERROR_lines': len(re.findall(r'/ERROR\]', log)),
                        'compile_tasks_from_cache': re.findall(r'^> Task :(compile\w+) FROM-CACHE$', log, re.MULTILINE),
                        'clean_log_claimed': False},
              'junit': {'suites': len(xml_details), 'actual': actual, 'per_xml': xml_details,
                        'freshness_basis': 'Recorded clean/test command and executed test task; exact copied XML pins, timestamps retained without guessing timezone'},
              'artifacts': artifact_details, 'synthetic_controls': synthetic,
              'external_inputs': INPUTS, 'java_native_replay': False, 'source_self_review': False,
              'gate_claimed': False, 'existing_save_R021_closed': False}
    result_path = HERE / 'BUILD-PACKAGE-AUDIT-01.json'
    require(not result_path.exists(), 'Do not overwrite result')
    result_path.write_bytes((json.dumps(output, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'source': output['source'], 'junit': {'suites': len(xml_details), 'actual': actual},
                      'artifact_counts': [{k: r[k] for k in ('name', 'entries', 'old_entries', 'generated_bytes_compared', 'main_java_bytes_compared')} for r in artifact_details],
                      'controls': len(synthetic), 'result': record(result_path.read_bytes()), 'external_inputs': len(INPUTS)}, indent=2))


if __name__ == '__main__':
    main()
