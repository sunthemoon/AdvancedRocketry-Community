# K3 integration evidence audit handoff

## Completion and findings

The [findings-first report](REVIEW-01.md) records no introduced C/H/M/L
integration-evidence discrepancy in the exact completed Root cohort. This is
not a source self-review or independent Java/native replay. Root's code commit
is `1ece7e9d2515003ca705b5634ef654a6bcae8f89`.

Independently measured: 2,990 declared prior input rows unchanged plus two new
files; 1,765 actual JUnit cases / 330 suites / 0 failure, error or skip; DataGen
written 0; 464 official required GameTests passed with a final 464-success status
bar; 90 recorded focused Python tests; fresh full repository validation has 45
PASS records and no pending/warning/failure records. The API JAR is whole-byte
equal to the prior pinned API, and every old main/sources member is unchanged.
All 771 generated members in both packages and all 1,211 source-JAR Java members
match the manifest; 1,211 Java plus the new test match the fixed commit blobs.

Ledger closure exit 1, dirty diff exit 1 and 61 native ERROR logger lines remain
preserved nonpasses/qualifications. Full validation success does not erase them.
The final current-doc link check remains Root's separate follow-up; the archived
687-file / 3,116-link / 0-error receipt precedes task-text edits. R-021 remains
separate and open in this audit. No Required Gate, native/client/cross-peer,
crash, persistence writer or public API admission is made.

## Write scope and files

Only this fresh owned directory was written. New audit scripts, measured JSON,
raw command/result/log/exit files, two failed script preimages, the context-patch
failure observation, report and small named receipt copies are the entire delta.
No Root/worktree/status/ADR/old packet/source change, Git HEAD move, Java/native
launch, network query, process termination, JAR/source/ZIP export, or protected
bundle/live-world access was performed. No disposable build/server tree exists
in this scope, so there is no such cleanup to perform.

The [input retention ledger](INPUT-LOCATORS-01.json) lists 66 small retained
named inputs (4,504,354 bytes), with original locators and exact hashes. Other
already immutable named Root references are hash-bound there; no artifact,
archive, whole source or bulk XML copy was made. The Root compact archive
`ac9b47b78f4cbce140b235974d4e68e2587083c87159e9ec19a634b48a35081d`
was checked in place: 404 entries, CRC and 403 payload hashes exact, 390 prior
measured payloads rebound. The original source-review repackaging was also
checked in place: 147 entries / 145 original manifested payloads exact.

## Actual commands and negative history

Commands and results are recorded in companion `*-command.json`, `*.log`,
`*.exit` and `*-result.json` files. Independent audit commands are Python only,
except read-only Git fixed-object batch/diff-tree/object reads invoked by the
final-receipt script. No product tests were changed or rerun by this auditor.

- Build/package audit first failed on a reviewer receipt-key locator; its
  preimage/raw failure remains. Corrected run exited 0.
- Final receipt audit first failed on a reviewer CRLF summary regex; its
  preimage/raw failure remains. Corrected run exited 0.
- Context/membership, strict GameTest marker controls, full-static/archive
  audit and named-input retention each exited 0.
- A guessed version-doc lookup produced a nonterminating PowerShell error;
  the corrected actual filename is recorded. One own report patch context
  failure occurred before writing and is preserved separately.

Independent synthetic controls test the audit parsers, not product behavior:
13 manifest/XML/ZIP controls, two original completion checks, then one positive
and nine stronger strict logger/count/order/final-status controls. Budgets,
test assertions, timeouts and candidate sources were never relaxed.

## Evidence and remaining verification

The loose bundle is inventoried by `EVIDENCE-MANIFEST.json`; its `files` map
uses bundle-relative paths with byte counts and SHA-256. `SHA256SUMS.txt`
checksums only payload files and the internal manifest, never external or
mutable build paths. The explicitly excluded final freeze receipt/log are
sidecars, not mutable measured inputs. No redundant ZIP is produced.

Root may retain this exact qualified audit alongside its compact regression
receipt and run its final documentation/link/input-pin checks. Future C16a
writers need their own frozen contracts and actual lifecycle/native evidence;
this report does not close those obligations or all v1.8 G0–G9.
