"""Strict logger / integer / final-status controls on completed archived GT."""
import json
import re
from pathlib import Path
import audit_build_packages as core

PREFIX = r'(?:\[\d{2}[A-Za-z]{3}\d{4} \d{2}:\d{2}:\d{2}\.\d{3}\]|\[\d{2}:\d{2}:\d{2}\]) \[Server thread/INFO\] \[(?:net\.minecraft\.gametest\.framework\.GameTestServer/|minecraft/GameTestServer)\]: '
PASS = re.compile('^' + PREFIX + r'All (\d+) required tests passed :\)$')
TOTAL = re.compile('^' + PREFIX + r'=+ (\d+) GAME TESTS COMPLETE =+$')
BAR = re.compile('^' + PREFIX + r'\[([+_Xx! -]+)\]$')


def measure(text):
    passes, totals, bars = [], [], []
    for line, raw in enumerate(text.splitlines(), 1):
        if match := PASS.fullmatch(raw):
            passes.append({'line': line, 'count': int(match[1])})
        if match := TOTAL.fullmatch(raw):
            totals.append({'line': line, 'count': int(match[1])})
        if match := BAR.fullmatch(raw):
            bars.append({'line': line, 'characters': match[1], 'successes': match[1].count('+')})
    core.require(len(passes) == len(totals) == 1, 'Exactly one trusted pass and total marker')
    core.require(passes[0]['count'] == totals[0]['count'] and passes[0]['line'] > totals[0]['line'], 'Exact total/pass integer and order')
    prior = [b for b in bars if b['line'] < totals[0]['line']]
    core.require(prior, 'Final status bar before completion')
    final = prior[-1]
    core.require(final['characters'] == '+' * passes[0]['count'], 'All final status characters are successful, count exact')
    return {'required': passes[0], 'total': totals[0], 'final_status': final}


def main():
    native = core.read(core.ROOT_EVIDENCE / 'gt-native-01.log')
    raw = core.read(core.ROOT_EVIDENCE / 'gt-01.log')
    current = {'native': measure(native.decode()), 'gradle': measure(raw.decode())}
    core.require(current['native']['required']['count'] == current['gradle']['required']['count'], 'Two logs agree')
    prefix = '[04Oct2026 14:01:33.268] [Server thread/INFO] [net.minecraft.gametest.framework.GameTestServer/]: '
    baseline = '\n'.join([prefix + '[+++]', prefix + '========= 3 GAME TESTS COMPLETE ======', prefix + 'All 3 required tests passed :)'])
    core.require(measure(baseline)['required']['count'] == 3, 'Synthetic positive')
    negative = {
        'arbitrary prefix/nested logger': 'untrusted ' + baseline.replace('\n', '\nuntrusted '),
        'quoted completion in other logger': baseline.replace('framework.GameTestServer/', 'framework.Other/'),
        'wrong severity': baseline.replace('thread/INFO', 'thread/ERROR'),
        'duplicate official completion': baseline + '\n' + prefix + 'All 3 required tests passed :)',
        'count substring not integer equality': baseline.replace('3 GAME TESTS', '30 GAME TESTS'),
        'incomplete final status': baseline.replace('[+++]', '[++_]'),
        'failed final status': baseline.replace('[+++]', '[++X]'),
        'total after passed marker': '\n'.join(baseline.splitlines()[::-1]),
        'missing native total': '\n'.join(line for line in baseline.splitlines() if 'COMPLETE' not in line),
    }
    controls = []
    for name, fixture in negative.items():
        try:
            measure(fixture)
        except AssertionError:
            controls.append({'name': name, 'rejected': True})
        else:
            raise AssertionError('Negative marker fixture accepted: ' + name)
    output = {'scope': 'Strict archived-log completion/status oracle, no native replay', 'measured': current,
              'positive_controls': 1, 'negative_controls': controls, 'external_inputs': core.INPUTS,
              'per_test_assertions_reexecuted': False, 'gate_claimed': False}
    dest = core.HERE / 'GT-MARKER-CONTROLS-01.json'
    core.require(not dest.exists(), 'Do not overwrite result')
    dest.write_bytes((json.dumps(output, indent=2) + '\n').encode())
    print(json.dumps({'actual_count': current['native']['required']['count'], 'final_success_characters': current['native']['final_status']['successes'],
                      'positive_controls': 1, 'negative_controls': len(controls), 'result': core.record(dest.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
