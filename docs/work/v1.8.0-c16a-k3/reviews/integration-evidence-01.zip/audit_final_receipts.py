"""Named final GT/static/commit receipts; no source checkout or runtime writes."""
import collections
import datetime as dt
import json
import re
import subprocess
import zipfile
from pathlib import Path

import audit_build_packages as core

HERE, EVIDENCE = core.HERE, core.ROOT_EVIDENCE
COMMIT = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'
REPO = Path('D:/GitHub/AdvancedRocketry-Community')


def git(args, input_bytes=None):
    command = ['git', '-C', str(REPO), *args]
    proc = subprocess.run(command, input=input_bytes, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    core.require(proc.returncode == 0, f'Read-only Git failed {args}: {proc.stderr!r}')
    return proc.stdout, {'command': command, 'exit': proc.returncode,
                         'stdout': core.record(proc.stdout), 'stderr': proc.stderr.decode('utf-8')}


def completions(text):
    rows = []
    for number, line in enumerate(text.splitlines(), 1):
        # Parse the actual INFO GameTestServer logger, not arbitrary quoted text.
        match = re.fullmatch(r'.*\[Server thread/INFO\] \[(?:net\.minecraft\.gametest\.framework\.GameTestServer/|minecraft/GameTestServer)\]: All (\d+) required tests passed :\)', line)
        if match:
            rows.append({'line': number, 'required_passed': int(match.group(1)), 'raw': line})
    return rows


def native_errors(text):
    patterns = [
        ('intentional energy migration callback', r'Intentional Energy-only migration binding save failure'),
        ('chunk save failure', r'Failed to save chunk '),
        ('unbound tag recipe disabling', r'Disabling machine recipe '),
        ('satellite idle failure', r'Satellite idle launch operation failed'),
        ('intentional precision migration callback', r'Intentional one-shot Precision migration save failure'),
        ('precision port disk mismatch', r'Precision Assembler migration port marker roots are not confirmed on disk'),
        ('precision controller disk mismatch', r'Precision Assembler migration controller snapshot roots are not confirmed on disk'),
        ('satellite launch failure', r'Satellite launch operation failed'),
        ('menu peer-map refusal', r'Channels \[advancedrocketrycommunity:machine_menu\] rejected their (?:server|client) side version number'),
        ('oversized recipe save refusal', r'Refusing chunk save with oversized recipe input'),
        ('oversized combustion save refusal', r'Refusing chunk save with oversized combustion input'),
    ]
    lines = text.splitlines()
    rows, groups = [], collections.Counter()
    for index, line in enumerate(lines):
        if '/ERROR]' not in line:
            continue
        categories = [name for name, pattern in patterns if re.search(pattern, line)]
        category = categories[0] if len(categories) == 1 else 'unclassified'
        groups[category] += 1
        stop = next((j for j in range(index + 1, len(lines)) if re.match(r'^\[\d+\w+\d+ ', lines[j])), min(index + 100, len(lines)))
        frames = [row.strip() for row in lines[index + 1:stop] if '.gametest.' in row and row.lstrip().startswith('at ')][:3]
        rows.append({'line': index + 1, 'category': category, 'raw': line, 'associated_gametest_frames': frames})
    return {'count': len(rows), 'categories': dict(groups), 'errors': rows,
            'qualification': 'Text categories and associated frames only; not a clean-log waiver, source-defect attribution, or R-021 closure'}


def main():
    initial = json.loads((HERE / 'BUILD-PACKAGE-AUDIT-01.json').read_bytes())
    recheck = []
    for locator, pin in initial['external_inputs'].items():
        actual = core.record(core.read(Path(locator)))
        core.require(actual == pin, f'Prior input changed: {locator}')
        recheck.append(locator)

    gt = core.load(EVIDENCE / 'GAMETEST-01.json')
    result = core.load(EVIDENCE / 'gt-result-01.json')
    command = core.load(EVIDENCE / 'gt-command-01.json')
    disk = core.load(EVIDENCE / 'gt-disk-precheck-01.json')
    raw_bytes = core.read(EVIDENCE / 'gt-01.log')
    native_bytes = core.read(EVIDENCE / 'gt-native-01.log')
    core.require(core.record(raw_bytes) == result['raw_log'] == gt['gradle_log'], 'GT Gradle log pin')
    core.require(core.record(native_bytes) == gt['native_log'], 'GT native log pin')
    core.require(result['exit'] == gt['exit'] == 0, 'GT command exit')
    core.require(command['command'][1:] == ['--offline', '--no-daemon', '--max-workers=2', '-Dorg.gradle.jvmargs=-Xmx2G', 'runGameTestServer'], 'GT scope')
    core.require(command['JAVA_HOME'] == 'C:/Program Files/Java/jdk-17.0.7', 'GT Java17')
    core.require(command['started_utc'] == result['started_utc'], 'GT start')
    elapsed = (dt.datetime.fromisoformat(result['finished_utc']) - dt.datetime.fromisoformat(result['started_utc'])).total_seconds()
    core.require(abs(elapsed - result['elapsed_seconds']) < 0.00001, 'GT elapsed')
    core.require(disk['threshold_bytes'] == 10_000_000_000 and all(disk['free_bytes'][d] >= disk['threshold_bytes'] for d in ('C', 'D')), 'GT disk threshold')
    raw, native = raw_bytes.decode('utf-8'), native_bytes.decode('utf-8')
    raw_complete, native_complete = completions(raw), completions(native)
    core.require(len(raw_complete) == len(native_complete) == 1, 'Exactly one required completion in each logger')
    core.require(raw_complete[0]['required_passed'] == native_complete[0]['required_passed'] == gt['required_passed'], 'GT completion agreement')
    total_complete = [{'line': i, 'raw': line} for i, line in enumerate(native.splitlines(), 1) if 'GAME TESTS COMPLETE' in line]
    core.require(len(total_complete) == 1 and str(gt['required_passed']) in total_complete[0]['raw'], 'Native total completion')
    core.require('BUILD SUCCESSFUL' in raw and 'BUILD FAILED' not in raw, 'GT Gradle completion')
    errors = native_errors(native)
    core.require(errors['count'] == gt['logger_ERROR_lines'], 'GT ERROR count')
    core.require(gt['source_inputs_postchecked'] == 2992 and not gt['clean_log_or_waiver_claimed'], 'GT source/clean log qualification')

    static = core.load(EVIDENCE / 'STATIC-RESULTS-01.json')
    static_rows = []
    for row in static['jobs']:
        name = row['name']
        core.safe_name(name)
        data = core.read(EVIDENCE / f'{name}-01.log')
        cmd = core.load(EVIDENCE / f'{name}-command-01.json')
        core.require(core.record(data)['sha256'] == row['log_sha256'], f'Static log pin {name}')
        text = data.decode('utf-8')
        static_rows.append({**row, 'command': cmd, 'log': core.record(data), 'pass_claimed': row['exit'] == 0})
        core.require(row['non_pass_preserved'] == (row['exit'] != 0), 'Static nonpass receipt')
        if name == 'focused-python':
            counts = [match.groups() for line in text.splitlines()
                      if (match := re.fullmatch(r'Ran (\d+) tests in ([\d.]+)s', line)) is not None]
            core.require(len(counts) == 1 and counts[0][0] == '90' and text.rstrip().endswith('OK'), 'Focused Python counts')
        if name == 'ledger-closure':
            core.require(row['exit'] == 1 and '186 ledger rows are still PLANNED' in text and '154 assets are still handled as REVIEW' in text and '"result": "FAIL"' in text, 'Closure nonpass evidence')
        if name == 'dirty-diff':
            core.require(row['exit'] == 1 and text.startswith('diff --git '), 'Dirty diff nonpass')

    commit = core.load(EVIDENCE / 'CODE-COMMIT-PUSH-01.json')
    core.require(commit['commit'] == COMMIT and sorted(commit['files']) == sorted(core.NEW), 'Commit receipt scope')
    commit_rows = []
    for index, row in enumerate(commit['commands'], 1):
        raw_command = core.load(EVIDENCE / f'code-commit01-{index:02d}.command.json')
        raw_log = core.read(EVIDENCE / f'code-commit01-{index:02d}.log')
        core.require(raw_command['command'] == row['command'] and core.record(raw_log)['sha256'] == row['log_sha256'] and row['exit'] == 0, 'Root commit command/log pin')
        commit_rows.append({**row, 'command_receipt': raw_command, 'raw_log': core.record(raw_log)})
    push = [r for r in commit_rows if r['command'][1:2] == ['push']]
    core.require(len(push) == 1 and push[0]['command'] == ['git', 'push', 'origin', 'codex/v1.8.0-classic-content'], 'Exact non-force push command')

    # Read fixed commit object bodies in memory; do not export source or move HEAD.
    manifest = core.load(EVIDENCE / 'SOURCE22-MANIFEST-01.json')
    wanted = sorted(name for name in manifest if name.startswith('src/main/java/') and name.endswith('.java'))
    wanted += [next(name for name in core.NEW if name.startswith('src/test/'))]
    source_request = ''.join(f'{COMMIT}:{name}\n' for name in wanted).encode('utf-8')
    body, batch_command = git(['cat-file', '--batch'], source_request)
    position, commit_sources = 0, {}
    for name in wanted:
        end = body.index(b'\n', position)
        header = body[position:end].split()
        core.require(len(header) == 3 and header[1] == b'blob', f'Commit blob missing {name}')
        length = int(header[2]); start = end + 1
        data = body[start:start + length]
        core.require(body[start + length:start + length + 1] == b'\n', 'Batch framing')
        position = start + length + 1
        pin = core.record(data)
        core.require(pin == manifest[name], f'Fixed commit source mismatch: {name}')
        commit_sources[name] = {'git_blob': header[0].decode(), **pin}
    core.require(position == len(body) and len(wanted) == 1212, 'Fixed commit source count/end')
    delta, delta_command = git(['diff-tree', '--no-commit-id', '--name-status', '-r', COMMIT])
    measured_delta = [line.split('\t', 1) for line in delta.decode('utf-8').splitlines()]
    core.require(measured_delta == [['A', name] for name in sorted(core.NEW)], f'Actual commit delta {measured_delta}')
    commit_data, object_command = git(['cat-file', '-p', COMMIT])
    parent = re.findall(rb'^parent ([0-9a-f]{40})$', commit_data, re.MULTILINE)
    core.require(len(parent) == 1, 'One parent commit')

    archive_receipt = core.load(EVIDENCE / 'SOURCE-REVIEW-ARCHIVE-01.json')
    archive = Path(archive_receipt['location'])
    core.require(core.record(core.read(archive)) == {k: archive_receipt[k] for k in ('bytes', 'sha256')}, 'Source review archive receipt')
    with zipfile.ZipFile(archive) as z:
        core.names_valid(z.namelist())
        core.require(z.testzip() is None and len(z.namelist()) == 147, 'Source review archive CRC/count')
        embedded = z.read('EVIDENCE-MANIFEST.json')
        core.require(core.record(embedded)['sha256'] == archive_receipt['original_internal_manifest_sha256'], 'Original source review internal manifest')
        review_manifest = json.loads(embedded)
        archive_summary = {'input': core.record(archive.read_bytes()), 'entries': len(z.namelist()), 'internal_manifest': core.record(embedded), 'all_CRC_ok': True}
        # Schema is intentionally discovered rather than presuming a prior author format.
        archive_summary['manifest_top_level_type'] = type(review_manifest).__name__
        archive_summary['manifest_top_level_keys'] = sorted(review_manifest)[:12]
        core.require(set(review_manifest) == {'files', 'scope', 'baseline_commit', 'self_and_live_receipt_exclusions'}, 'Source review manifest shape')
        core.require(len(review_manifest['files']) == 145, 'Source review payload count')
        for name, pin in review_manifest['files'].items():
            core.safe_name(name)
            core.require(core.record(z.read(name)) == pin, f'Original review payload identity {name}')
        archive_summary['payloads_verified'] = len(review_manifest['files'])

    controls = [
        {'name': 'quoted false completion', 'ignored': completions('[Server thread/INFO] [minecraft/Other]: All 999 required tests passed :)') == []},
        {'name': 'wrong logger completion', 'ignored': completions('[Server thread/ERROR] [minecraft.GameTestServer/]: All 999 required tests passed :)') == []},
    ]
    core.require(all(row['ignored'] for row in controls), 'Completion parser controls')
    output = {'scope': 'Independent archived-byte/result audit, not source self-review or native replay',
              'prior_inputs_rechecked': len(recheck),
              'gt': {'command': command, 'result': result, 'disk': disk, 'collector': gt,
                     'gradle_required_completion': raw_complete, 'native_required_completion': native_complete,
                     'native_total_completion': total_complete, 'native_errors': errors},
              'static': static_rows,
              'commit': {'commit': COMMIT, 'parent': parent[0].decode(), 'actual_delta': measured_delta,
                         'read_only_commands': [batch_command, delta_command, object_command], 'source_blobs': commit_sources,
                         'root_commands': commit_rows, 'remote_network_recheck': False},
              'source_review_archive': archive_summary, 'controls': controls, 'external_inputs': core.INPUTS,
              'native_or_client_replay': False, 'whole_version_gate_claimed': False, 'R021_closed': False}
    dest = HERE / 'FINAL-RECEIPTS-AUDIT-01.json'
    core.require(not dest.exists(), 'Do not overwrite final result')
    dest.write_bytes((json.dumps(output, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'gt_required_passed': gt['required_passed'], 'gt_ERROR_count': errors['count'], 'gt_ERROR_categories': errors['categories'],
                      'static_exits': {r['name']: r['exit'] for r in static_rows}, 'commit': COMMIT,
                      'commit_main_java_plus_new_test': len(wanted), 'actual_commit_delta': measured_delta,
                      'previous_inputs_unchanged': len(recheck), 'controls': len(controls), 'result': core.record(dest.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
