"""Read named governance and exact source-JAR membership, not whole source."""
import json
import zipfile
from pathlib import Path
import audit_build_packages as core

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
DOCS = [
    'AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
]


def main():
    manifest = core.load(core.ROOT_EVIDENCE / 'SOURCE22-MANIFEST-01.json')
    docs = {}
    for name in DOCS:
        body = core.read(ROOT / name)
        pin = core.record(body)
        docs[name] = {'input': pin, 'lines': len(body.decode('utf-8').splitlines()),
                      'in_source_manifest': name in manifest,
                      'same_as_source_manifest': manifest.get(name) == pin}
    sources = core.ROOT_EVIDENCE / 'artifacts/advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar'
    pin = core.record(core.read(sources))
    expected = {name.removeprefix('src/main/java/') for name in manifest
                if name.startswith('src/main/java/') and name.endswith('.java')}
    with zipfile.ZipFile(sources) as z:
        actual = {name for name in z.namelist() if name.endswith('.java')}
        core.require(actual == expected, 'Complete source-JAR Java membership equals manifest')
    result = {'named_governance_context': docs,
              'source_jar_exact_java_membership': {'input': pin, 'manifest_java': len(expected),
                                                 'jar_java': len(actual), 'missing': sorted(expected - actual),
                                                 'unexpected': sorted(actual - expected)},
              'version_locator_observation': {'wrong_guess': 'docs/versions/v1.8.0.md',
                  'tool_outcome': 'Nonterminating PowerShell Get-Item error; tool exit was 0, not successful file read',
                  'actual_named_file': 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md'},
              'external_inputs': core.INPUTS, 'live_checkout_source_audit': False}
    dest = core.HERE / 'CONTEXT-MEMBERSHIP-AUDIT-01.json'
    core.require(not dest.exists(), 'Do not overwrite result')
    dest.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'named_docs': len(docs), 'manifest_matches': sum(r['same_as_source_manifest'] for r in docs.values()),
                      'java_membership_exact': len(actual), 'result': core.record(dest.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
