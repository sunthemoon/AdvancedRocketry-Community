# K3 Root integration evidence audit

## Findings and disposition

No introduced Critical, High, Medium or Low **integration-evidence discrepancy**
was identified in the completed build, package, GameTest, fixed-commit and
recorded scoped-static evidence audited here. This is an archived-byte/result
audit, not another review of the K3 implementation and not an independent
Java/GameTest/native replay.

The following nonpasses and boundaries are retained, not converted to passes:

- Root's [ledger-closure command](inputs/root/ledger-closure-01.log) exited **1**:
  186 ledger rows remained PLANNED and 154 assets remained REVIEW. This is an
  open whole-content condition.
- Root's `git diff --exit-code` exited **1**. The [captured diff](inputs/root/dirty-diff-01.log) is retained;
  a successful build and zero DataGen writes do not mean a clean worktree.
- The native GameTest log contains **61 ERROR logger lines**, including save
  refusals, intentional migration callback failures, disk-marker mismatches,
  tag binding, menu peer-map rejection and satellite failure messages. The
  measured successful test outcome is not a clean-log claim or a log waiver.
- **R-021 existing-save risk review is separate and remains open here.** This
  audit cannot approve a Guard/save writer, arbitrary-crash recovery, migration,
  charged carrier, client behavior or any v1.8 Required Gate.
- A separate **fresh full repository validation** completed with 45 actual PASS
  records and no pending/warning/failure records. It does not erase the separate
  ledger-closure or dirty-diff failures. The final current-document link check
  remains pending after subsequent task-text edits; its earlier draft check is
  not promoted to final coverage. Prior source-cohort successes are not reused.

The completed evidence supports the narrow statement that the exact committed
two-file private K3 computation delta was packaged with the preserved baseline,
and that Root actually executed the recorded successful build/unit/DataGen and
GameTest commands. Root alone decides the qualified integration record and
follow-on documentation. No whole-version acceptance is recommended here.

## Role, ownership and tested identities

The auditor wrote only this NEW owned directory. Root, author worktrees, prior
reviews, source/status/ADR and frozen packets were not modified. No Java,
Gradle, server, native replay, client, network query, commit, checkout or process
termination was executed by the auditor. No whole source export, JAR copy or
ZIP was created. No protected bundle or live world was read or walked.

Root's integration code commit is
`1ece7e9d2515003ca705b5634ef654a6bcae8f89`, with the independently read commit
parent `37286766e75688b1f2ddb4784adb55576145ba5d`. Fixed commit object reads,
not the moving Root HEAD, bound the source comparison.

The archived input closure is called **Source22** in Root receipts. It is a
declared build-input manifest, not a claim that every tracked repository file
is inventoried. The previous **Source21R1** manifest has 2,990 rows. Its SHA-256
is `2a2e4973bd1d214a89ab3e340c8977c66b574ff680a77d2dc49f3bfffaae0a46`.
Source22 has 2,992 rows, SHA-256
`4de6f64b14b2cd728c713c37d10ec97d70a2532f9ca31184ec4854a41b443aaf`.
All 2,990 prior manifest rows are unchanged; the only two added rows are:

| New committed path | Bytes | SHA-256 |
|---|---:|---|
| `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java` | 809 | `6ca5b028317766e9106953a011134096e896b08b557db041eb0c92ad493b5ec8` |
| `src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java` | 16,244 | `cf295730469021a70dc2eba85d030379860b16388025359eafb249a526d08c27` |

Manifest controls check strict row fields/types/SHA shape, unique JSON keys,
relative components, case aliases and prohibited bundle names. They do not
read the manifested source tree. The 11 named governance/version documents
were read and independently measured equal to Source22's recorded rows.
See [context/membership measurements](CONTEXT-MEMBERSHIP-AUDIT-01.json).

## Independently measured Root build and unit evidence

Root's recorded command used Java 17.0.7, offline Gradle, `--no-daemon`, two
workers, a 2 GiB Gradle heap, and `clean build test runData`. Actual exit was
**0**, elapsed **179.501121 seconds**, UTC
`2026-10-04T05:52:51.533981+00:00` to
`2026-10-04T05:55:51.035102+00:00`.

The pinned raw log is 12,898 bytes, SHA-256
`6e94af6c6a93d3b055e7d9fbc7e361b2eb4ee3a4246d030af259bbf19491df03`.
It contains actual `clean` and executed `test` tasks and successful completion.
Compilation tasks used Gradle's cache; this is not an uncached release rebuild
or proof of a pristine environment. Build disk receipts recorded both C and D
above the unchanged 10,000,000,000-byte precondition.

Each of the 330 copied XML filenames and bodies matches Root's hash receipt.
The independent parser counted **1,765 actual testcase elements**, with **0
failure, error or skipped elements**; suite declarations agree exactly. There
are no extra or missing XML files in the named copied directory. K3's own suite
has 15 tests and no failure/error/skip. Timestamp strings are retained without
assuming their timezone. Freshness is grounded in the recorded clean/test
command, executed test task, and exact pinned copied XML evidence—not a stale
XML count borrowed from a preceding candidate.

DataGen's recorded cache line says total/old files 771, new count 772, removed
stale 0, **written 0**. The actual generated content comparison below is 771;
the cache's 772 figure is not mislabeled as generated resources. Six build
`/WARN]` logger lines and the terminal/deprecation messages are preserved;
there are no `/ERROR]` build logger lines. This is not a broad clean-log claim.

Detailed per-XML counts, input pins, raw command/result and measurements are in
[the build/package result](BUILD-PACKAGE-AUDIT-01.json).

## Independently measured packaged artifacts

All three current and previous pinned JARs were read in place; no JAR or member
body was exported. Both cohorts passed ZIP CRC, duplicate-name, unsafe-path
and case-alias checks. Every previous member remains present with exactly the
same uncompressed bytes. Only the listed member is added where applicable.

| Current artifact | Bytes / entries | SHA-256 | Exact addition |
|---|---|---|---|
| API | 51,045 / 48 | `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da` | None; **whole JAR bytes equal** to the prior API |
| Sources | 2,621,320 / 2,662 | `b7ae68c8066261d3d23fe5bddf3cce84a3967bd93d178f3c075db3395d0c4582` | `io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java` |
| Main | 5,441,840 / 3,306 | `26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a` | Same package's `ClassicNbtCanonicalHash.class` |

The previous sources/main pins are
`1368d531681032c3c70fa320fbe7697dff3f124e668c4f17176707220abef9d2` and
`796c9611ec8d655398e5a046bfe6cc3f81b2c7880a19c835ea9ed301a990373e`.
Their respective member counts are 2,661 and 3,305.

All **771 generated resource bodies** match Source22's manifest in both sources
and main JARs. The sources JAR's complete set of **1,211 Java members** is exactly
the manifest's `src/main/java` set, and all bodies match those pins. An
independent read-only `git cat-file --batch` then compared all 1,211 named Java
blobs, plus the new test, from the fixed code commit to Source22. All **1,212**
matched. `git diff-tree` independently observed exactly the two added paths,
with no existing-file delta in that commit.

Root's pinned actual staging/commit/push command logs agree with its receipt.
The recorded push has no force option and exited 0. Remote state was **not**
queried independently; this audit only establishes the captured successful
non-force push command/log. See [final receipt/commit measurements](FINAL-RECEIPTS-AUDIT-01.json).

## Actual completed Root GameTest evidence

Root's actual `runGameTestServer` command used the same Java/offline/daemon/
worker/heap limits. Exit was **0**, elapsed **240.231154 seconds**, UTC
`2026-10-04T05:57:37.190304+00:00` to
`2026-10-04T06:01:37.421458+00:00`. This result was read only after Root reported
completion; the earlier empty/in-progress log was never treated as evidence.

The 1,475,026-byte Gradle log pin is
`145f06e599c7c6093523a9cd5d53a3dfaca787e0f4fb306a47c3af61bb1a980b`.
The 1,645,636-byte native runtime log pin is
`c2971afd007ae07986031817379567133bf5639ddc9070be9cef7aa5903213ea`.

The independent strict logger parser found exactly one native and one Gradle
official completion: **464 required tests passed**. In the native log, lines
5540–5542 contain a final status bar of exactly 464 `+` characters, total 464
complete, and the matching required-pass marker. Integer counts and marker
ordering match; there is no partial/failed character in the final bar.
[Strict completion controls](GT-MARKER-CONTROLS-01.json) also measure both logs.

The 61 native ERROR lines in the [captured runtime log](inputs/root/gt-native-01.log)
are preserved individually with original line numbers
and associated GameTest stack frames where present:

| Observed message category | Count |
|---|---:|
| Intentional energy migration callback | 3 |
| Chunk save failure | 5 |
| Unbound tag recipe disabling | 3 |
| Satellite idle / launch failure | 3 / 1 |
| Intentional precision migration callback | 2 |
| Precision port / controller disk mismatch | 2 / 1 |
| Menu peer-map refusal | 16 |
| Oversized recipe / combustion save refusal | 24 / 1 |

These are text/context measurements, **not** a new source-defect attribution,
log exemption or proof that saved player data is safe. The recorded collector
explicitly does not claim a clean log or waiver. In particular, the save-error
and refusal messages cannot close R-021 merely because the test suite passed.
No peer, client, native stopped-region or crash behavior was replayed here.

## Recorded scoped static outcomes

Every named static command and raw log matches its completed hash receipt.
Eight commands exited 0: focused Python (actual **90 tests**, `OK`), common/
client import check, strict ledger validation, planning validation, provenance,
machine resources, current main artifact validation, and `git diff --check`.
Two commands exited 1: ledger closure and dirty diff. These two remain failures.
The static runner's overall orchestration expectations do not relabel them.

These checks were recorded around the build/GameTest cohort and before the
subsequent code commit; they are not silently moved to post-commit time.
The later full validation has a separate command, input boundary and receipt;
no historical full-static count is reused.

## Fresh full validation and Root compact archive

Root separately executed `validate_repository_boundary23.py` after the code
commit. The actual exit is **0**, elapsed **343.217632 seconds**. The raw log's
SHA-256 is `c94019a11bfacdedace2433fc95da4f10bad7a3d8995530c44b5fd75608d605b`.
The auditor counted 45 individual PASS records and 0 PENDING/WARN/WARNING/FAIL
records; the summary agrees. This is the new completed run, not an old 45-count
receipt. AGENTS, the externally owned risk register and original validator
pre/post pins agree; the three named current bytes were independently rehashed
and matched those pins.

The original validator SHA-256 remains
`ff77ac86f500ce2f6c782d01084623746e87a653f76916ad1f04673683a950f2`.
The inspected wrapper changes only its Git inventory hook: an exact literal
untracked private-directory exclusion is appended to the `ls-files --others`
call, while the cached-only call is unchanged. Both recorded inventory command
shapes agree. The protected directory was not read or walked by the auditor.
The wrapper is not mislabeled as an unmodified direct validator invocation,
and no repository validation was rerun by the auditor.

Root's compact regression archive is 741,221 bytes / 404 entries, SHA-256
`ac9b47b78f4cbce140b235974d4e68e2587083c87159e9ec19a634b48a35081d`.
Its internal manifest SHA-256 is
`00c51fdff0573284a1a177cec7bfacde078a91704feb972f4bad2e594add7325`.
CRC and every one of the 403 manifested payload hashes match; the internal
manifest itself is the 404th entry. The inventory has no redundant JAR, nested
ZIP or whole source subtree. It binds the fixed K3 commit. **390** previously
measured Root input payloads were independently rebound to archive bytes.
The auditor read this archive in place and did not copy it.

Its initial current-link receipt records 687 Markdown files, 3,116 links and
0 errors. Root subsequently edited task progress text, so this is **draft-time
coverage only**, not final current-link coverage. Root will record the final
textual/link check separately after this audit. See
[full validation/archive measurements](FULL-STATIC-ARCHIVE-AUDIT-01.json).

## Independent commands, controls and retained failures

All audit executions are Python or fixed-object read-only Git, not Java. Raw
commands, start/finish timestamps, logs and exits are retained locally:

| Independent execution | Actual outcome |
|---|---|
| `audit_build_packages.py`, first run | Exit 1: reviewer used nonexistent receipt key `applied_source`; no product evidence was altered |
| Same script, corrected receipt-field locator | Exit 0: build/XML/source manifest/package measurements, 13 synthetic controls |
| `audit_final_receipts.py`, first run | Exit 1: reviewer's focused-Python summary regex did not handle the captured CRLF terminator |
| Same script, corrected split-line parsing | Exit 0: GT/static/fixed commit/145 preserved archive payload measurements |
| `audit_context_and_membership.py` | Exit 0: 11 named governance rows exact, complete 1,211 Java-member set equality |
| `audit_gt_markers.py` | Exit 0: actual completion/bar measurements, 1 positive + 9 negative synthetic controls |
| `audit_full_static_archive.py` | Exit 0: actual fresh 45/0 full validation and all 403 compact-archive payload hashes |

The two failed script preimages, raw failure logs and command/result
receipts remain intact. An exploratory PowerShell lookup of the guessed
`docs/versions/v1.8.0.md` emitted a nonterminating missing-path error (tool exit
0); the actual uppercase version filename was then read. It is recorded in the
context result, not disguised as a successful read. One manual report patch
failed its context check before changing any file; the corrected patch applied
and its failure observation is retained. No candidate assertion,
budget, timeout or source was changed to obtain an audit pass.

The 13 source/XML/ZIP controls cover unsafe paths, case aliases, duplicate keys/
members, masked/inflated XML declarations, and actual failure/error/skip counting.
The supplementary 9 strict GT controls reject nested/other loggers, wrong
severity, duplicate or missing markers, nonmatching integer totals, out-of-order
markers and partial/failed status bars. These controls test the auditor's
parsers; they are not product tests or additional Root GameTests.

## Source-review evidence packaging integrity only

Root repackaged the previously completed private source review into a NEW
1,093,973-byte, 147-entry ZIP, SHA-256
`1b36df461aa12cab58ba4dbfd9c6a1a24bfd022d55fbe5c04372818e1c6265a1`.
CRC and member names passed. Its embedded original manifest hash remains
`f7f0dc8cf5f78213456c70694ff39d5ef165968cc13d6966e796f59f5aadf133`.
All 145 original manifested payloads were independently compared to that
manifest, without importing the ZIP or re-reviewing its source verdict.
This establishes packaging identity only; the original loose packet was not
modified. Existing source/admission limits stay unchanged.

## Remaining work and Required Gate boundary

This audit did not independently run Java, GameTest, native servers, restart/
crash worlds, client/peer sessions, resource writers or release rebuilds. It
did not assess implementation policy, natural signed-zero persistence, native
registry/codecs, hash consumers or protection lifecycle. It does not upgrade
private computation into a public API or managed writer.

Full v1.8 G0–G9 are **not all satisfied by this evidence**. The whole-content
ledger closure, R-021 and separately scheduled migration/client/visual/player/
performance/release conditions remain outside the K3 integration statement.
Follow-on work should use the independently qualified committed K3 input only
for its existing private purpose; any dependent writer needs its own frozen
contract, independent source review and applicable actual lifecycle/native
evidence.

The companion [handoff](HANDOFF.md), [input retention ledger](INPUT-LOCATORS-01.json),
internal manifest and checksum list record
the final small loose bundle. Artifact/source bodies and ZIPs remain at their
named immutable Root locations; this audit contains no redundant export.
