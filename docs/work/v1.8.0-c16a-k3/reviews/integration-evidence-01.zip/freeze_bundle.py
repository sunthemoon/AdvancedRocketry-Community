"""Freeze only this owned small loose evidence directory, no archive/export."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).parent.resolve()
EXCLUDED = {'EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt', 'FREEZE-RESULTS-01.json',
            'freeze-01.log', 'freeze-01.exit', 'freeze-01-result.json'}


def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    rows = {}
    for path in sorted(HERE.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(HERE).as_posix()
        if relative in EXCLUDED:
            continue
        assert path.resolve().is_relative_to(HERE), path
        assert path.suffix not in ('.jar', '.zip', '.class'), path
        assert '__pycache__' not in path.parts and 'build' not in path.parts and '.gradle' not in path.parts, path
        data = path.read_bytes()
        assert len(data) < 50_000_000, relative
        rows[relative] = pin(data)
    assert sum(row['bytes'] for row in rows.values()) < 100_000_000
    link_rows = []
    for name in ('TASK.md', 'REVIEW-01.md', 'HANDOFF.md'):
        text = (HERE / name).read_text(encoding='utf-8')
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
            assert not re.match(r'(?:https?:|file:|[A-Za-z]:)', target), target
            dest = (HERE / target.split('#')[0]).resolve()
            assert dest.is_relative_to(HERE) and dest.is_file(), (name, target)
            link_rows.append({'document': name, 'target': target})
    manifest_path = HERE / 'EVIDENCE-MANIFEST.json'
    assert not manifest_path.exists()
    manifest = {'schema': 1, 'scope': 'Small loose independent K3 Root integration result audit; no runtime replay/Gate/source admission',
                'tested_code_commit': '1ece7e9d2515003ca705b5634ef654a6bcae8f89',
                'files': rows, 'sidecar_exclusions': sorted(EXCLUDED)}
    manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
    checks = {**rows, 'EVIDENCE-MANIFEST.json': pin(manifest_path.read_bytes())}
    sums = HERE / 'SHA256SUMS.txt'
    assert not sums.exists()
    sums.write_bytes(''.join(f'{checks[name]["sha256"]}  {name}\n' for name in sorted(checks)).encode())
    # Fresh verification after writing, against bundle-internal files only.
    for name, expected in checks.items():
        assert pin((HERE / name).read_bytes()) == expected, name
    result = {'files': len(rows), 'payload_bytes': sum(r['bytes'] for r in rows.values()),
              'report': rows['REVIEW-01.md'], 'handoff': rows['HANDOFF.md'],
              'internal_manifest': pin(manifest_path.read_bytes()), 'sha256sums': pin(sums.read_bytes()),
              'all_payloads_verified': True, 'active_companion_links': len(link_rows), 'missing_links': 0,
              'link_observations': link_rows, 'archive_or_source_export': False, 'runtime_process_launched': False,
              'whole_version_gate_claimed': False, 'R021_closed': False}
    final = HERE / 'FREEZE-RESULTS-01.json'
    assert not final.exists()
    final.write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
