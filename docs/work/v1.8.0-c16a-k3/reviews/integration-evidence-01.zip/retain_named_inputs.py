"""Keep small named receipts/logs only. Never duplicate JAR/source/ZIP bodies."""
import json
from pathlib import Path
import audit_build_packages as core

HERE = core.HERE


def main():
    inputs = {}
    results = ['BUILD-PACKAGE-AUDIT-01.json', 'FINAL-RECEIPTS-AUDIT-01.json',
               'CONTEXT-MEMBERSHIP-AUDIT-01.json', 'GT-MARKER-CONTROLS-01.json',
               'FULL-STATIC-ARCHIVE-AUDIT-01.json']
    for name in results:
        result = json.loads((HERE / name).read_bytes())
        for locator, pin in result['external_inputs'].items():
            previous = inputs.setdefault(locator, pin)
            core.require(previous == pin, f'Conflicting observed input {locator}')
    copied, not_copied = {}, {}
    for locator, pin in sorted(inputs.items()):
        path = Path(locator)
        if path.parent == core.ROOT_EVIDENCE and path.suffix in ('.json', '.log', '.py'):
            # Root show-index logs contain the new source bodies; retain only their
            # hash in the observation ledger, not another source export.
            if path.name in ('code-commit01-07.log', 'code-commit01-08.log'):
                not_copied[locator] = {'input': pin, 'reason': 'Source-body Git logs not duplicated'}
                continue
            relative = Path('inputs/root') / path.name
        elif path == core.OLD_MANIFEST:
            relative = Path('inputs/baseline/integration-21-source-manifest-r1.json')
        elif path.parent == core.ROOT_EVIDENCE / 'junit' and 'ClassicNbtCanonicalHashTest' in path.name:
            relative = Path('inputs/root/junit') / path.name
        else:
            not_copied[locator] = {'input': pin, 'reason': 'Named immutable Root/reference payload; no redundant JAR/source/ZIP or bulk XML export'}
            continue
        data = path.read_bytes()
        core.require(core.record(data) == pin, f'Input changed before retention {locator}')
        target = HERE / relative
        core.require(not target.exists(), f'Do not overwrite retained input {relative}')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        core.require(core.record(target.read_bytes()) == pin, f'Copy bytes {relative}')
        copied[relative.as_posix()] = {'original_locator': locator, **pin}
    dest = HERE / 'INPUT-LOCATORS-01.json'
    core.require(not dest.exists(), 'Do not overwrite retention ledger')
    result = {'scope': 'Receipt/log/manifest retention only; no source tree, JAR or archive export',
              'retained_named_inputs': copied, 'read_only_named_external_inputs': not_copied,
              'retained_bytes': sum(r['bytes'] for r in copied.values())}
    dest.write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({'retained_files': len(copied), 'retained_bytes': result['retained_bytes'],
                      'read_only_external_inputs': len(not_copied), 'result': core.record(dest.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
