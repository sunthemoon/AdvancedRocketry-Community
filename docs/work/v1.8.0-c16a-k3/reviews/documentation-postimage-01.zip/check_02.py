from pathlib import Path
import hashlib
import io
import json
import zipfile

OUT = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


path = ROOT / 'docs/work/v1.8.0-c16a-k3/FINAL-DOC-CHECKS-01.zip'
raw = path.read_bytes()
assert identity(raw) == {'bytes': 44975, 'sha256': '2d11ff32a6d52f0bb1d7de8118622e2a505be153aeb368187950e0ddf8bde037'}
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == 16
    manifest_raw = archive.read('EVIDENCE-MANIFEST.json')
    assert hashlib.sha256(manifest_raw).hexdigest() == 'd828f06fba689817414f47fb140c8013f0e04a242eab17374ecdd5ee0145a174'
    manifest = json.loads(manifest_raw)
    rows = manifest.get('files', manifest)
    if isinstance(rows, list):
        rows = {row['path']: row for row in rows}
    for name, row in rows.items():
        assert identity(archive.read(name)) == {key: row[key] for key in ['bytes', 'sha256']}
        assert 'Development-Docs' not in name
        assert identity((E / name).read_bytes()) == {key: row[key] for key in ['bytes', 'sha256']}
    assert archive.read('FINAL-DOC-CHECKS-01.json') == (E / 'FINAL-DOC-CHECKS-01.json').read_bytes()
    assert archive.read('markdown-links-20.json') == (E / 'markdown-links-20.json').read_bytes()
    assert archive.read('SOURCE22-FINAL-POSTCHECK-01.json') == (E / 'SOURCE22-FINAL-POSTCHECK-01.json').read_bytes()

original = json.loads((OUT / 'INPUT-PINS-01.json').read_text(encoding='utf-8'))
changed = []
for name, row in original.items():
    if name.startswith(str(ROOT)) and identity(Path(name).read_bytes()) != row:
        changed.append(name)
assert not changed
result = {'publication_archive': {'path': str(path), **identity(raw)}, 'entries': 16,
          'manifested_files': len(rows), 'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
          'all_archive_and_named_external_payloads_exact': True,
          'selected_repo_input_postcheck_changed': changed,
          'chronology': 'Initial directory observation lacked final ZIP; Root froze it separately before this check, without Markdown changes',
          'runtime_or_gate_admission': False}
(OUT / 'RESULT-02.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(result))
