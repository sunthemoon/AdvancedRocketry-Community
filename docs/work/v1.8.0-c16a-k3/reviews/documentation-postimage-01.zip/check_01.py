from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import io
import json
import re
import subprocess
import zipfile

OUT = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/ak3d-6d040b00df')
BASE = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'
PINS = {}


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    assert 'Development-Docs' not in str(path)
    raw = path.read_bytes(); PINS[str(path)] = identity(raw)
    return raw


def js(path):
    return json.loads(read(path))


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')


head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip()
assert head == BASE
old_manifest_raw = read(OLD / 'EVIDENCE-MANIFEST.json')
assert hashlib.sha256(old_manifest_raw).hexdigest() == 'b1f969d50d8ca8f6b9f086231b9f20f0593bb81dadc8f03511fd35fc1e4146b6'
old_manifest = json.loads(old_manifest_raw)
for name, pin in old_manifest['files'].items():
    assert identity((OLD / name).read_bytes()) == pin
assert identity(read(OLD / 'REVIEW-01.md'))['sha256'] == 'af3e4eb6deff76221778a9f1e257ee9224c9edb03b51b798fdfbb3b0ce5ffb6f'

scope = ['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
         'docs/work/v1.8.0-c16a-k3/SOURCE-ACCEPTANCE-01.md', 'docs/work/v1.8.0-c16a-k3/VERIFICATION.md',
         'docs/work/v1.8.0-c16a-hatches/CANONICAL-DIGEST-TASK.md',
         'docs/work/v1.8.0-c16a-save-guard/SAVE-REFUSAL-DISPOSITION-01.md']
deltas = []; links = []
for name in scope:
    path = ROOT / name
    raw = read(path)
    old = read(OLD / 'document-snapshots-04' / path.name)
    deltas.extend(difflib.unified_diff(old.decode('utf-8').splitlines(keepends=True),
                                     raw.decode('utf-8').splitlines(keepends=True),
                                     fromfile='frozen-review/' + path.name, tofile=name))
    for token in re.findall(r'\]\(([^)]+)\)', raw.decode('utf-8')):
        if token.startswith(('http:', 'https:', '#')):
            continue
        target = token.split('#', 1)[0]
        assert 'Development-Docs' not in target
        links.append({'source': name, 'target': target, 'exists': (path.parent / target).is_file()})
    if path.name in ['CANONICAL-DIGEST-TASK.md', 'VERIFICATION.md']:
        (OUT / path.name).write_bytes(raw)
assert all(row['exists'] for row in links)
(OUT / 'CURRENT-DOCUMENT-DELTA-01.patch').write_text(''.join(deltas), encoding='utf-8')
logpath = ROOT / 'docs/work/v1.8.0-implementation-log.md'
rawlog = read(logpath).decode('utf-8')
base_log = subprocess.check_output(['git', '-C', str(ROOT), 'show', BASE + ':docs/work/v1.8.0-implementation-log.md']).decode('utf-8')
(OUT / 'IMPLEMENTATION-LOG-ADDITIONS-01.patch').write_text(''.join(difflib.unified_diff(
    base_log.splitlines(keepends=True), rawlog.splitlines(keepends=True),
    fromfile='committed-implementation-log', tofile='current-implementation-log')), encoding='utf-8')

task = (OUT / 'CANONICAL-DIGEST-TASK.md').read_text(encoding='utf-8')
oldtask = (OLD / 'document-snapshots-04/CANONICAL-DIGEST-TASK.md').read_text(encoding='utf-8')
assert task.split('## Outcome and boundary', 1)[1].split('- [', 1)[0] == oldtask.split('## Outcome and boundary', 1)[1].split('- [', 1)[0]

archive_path = ROOT / 'docs/work/v1.8.0-c16a-k3/reviews/integration-evidence-01.zip'
archive_data = read(archive_path)
assert identity(archive_data) == {'bytes': 855925, 'sha256': 'e0c54a81d7a64a187ee05ab96f84ffff16660ea3388cb3ba074b759702bd7da3'}
with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == 120
    manifestraw = archive.read('EVIDENCE-MANIFEST.json')
    assert hashlib.sha256(manifestraw).hexdigest() == 'ea1025f33fe07cd51ff01586d7d55f2c984948a686a10b793413a69e609aba33'
    manifest = json.loads(manifestraw)
    for path, pin in manifest['files'].items():
        assert identity(archive.read(path)) == pin
    assert len(manifest['files']) == 118
    report = archive.read('REVIEW-01.md')
    assert hashlib.sha256(report).hexdigest() == '1771d4c397e1b02efab8d73a4d7c1aa7cae06a617f471b70e5b60272f594b017'
    reporttext = report.decode('utf-8')
    assert 'not an independent' in reporttext and 'Java/GameTest/native replay' in reporttext

checks = js(E / 'FINAL-DOC-CHECKS-01.json')
for command in checks['commands']:
    raw = read(E / (command['name'] + '.log'))
    assert hashlib.sha256(raw).hexdigest() == command['log_sha256']
    assert command['exit'] == 0
    js(E / (command['name'] + '.command.json'))
assert checks['links_exit'] == 0 and checks['current_head'] == BASE
post = js(E / 'SOURCE22-FINAL-POSTCHECK-01.json')
assert post['changed'] == [] and post['snapshot_inputs'] == 2992 and post['current_head'] == BASE
linkreceipt = js(E / 'markdown-links-20.json')
assert linkreceipt['errors'] == []
rows = {row['path']: row['sha256'] for row in linkreceipt['inputs']}
stale = [name for name in scope + ['docs/work/v1.8.0-implementation-log.md']
         if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != rows[name]]
finalzip = ROOT / 'docs/work/v1.8.0-c16a-k3/FINAL-DOC-CHECKS-01.zip'
result = {'timestamp': datetime.now(timezone.utc).isoformat(), 'code_head': head,
          'old_sealed_files_unchanged': len(old_manifest['files']), 'computation_task_text_unchanged': True,
          'current_local_links': len(links), 'missing_links': [], 'integration_archive_entries': 120,
          'integration_manifested_files': 118, 'integration_report_sha256': hashlib.sha256(report).hexdigest(),
          'final_receipt_commands': checks['commands'], 'final_link_receipt_files': linkreceipt['files'],
          'final_link_receipt_links': linkreceipt['links'], 'scoped_current_document_link_pins_stale': stale,
          'source_final_receipt': post, 'claimed_final_doc_zip_exists': finalzip.is_file(),
          'note': 'Source/HEAD/postcheck are recorded checks, not new source self-review or Java replay'}
save('RESULT-01.json', result); save('INPUT-PINS-01.json', PINS)
print(json.dumps({key: result[key] for key in ['old_sealed_files_unchanged', 'current_local_links',
    'integration_archive_entries', 'integration_manifested_files', 'scoped_current_document_link_pins_stale',
    'claimed_final_doc_zip_exists']}))
