import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
sys.path.insert(0, str(root))
from scripts.validate_repository import markdown_link_errors

paths = {root / path for path in subprocess.check_output(
    ['git', 'ls-files', '*.md'], cwd=root, text=True).splitlines()}
for name in ('v1.8.0-c16a-k3', 'v1.8.0-c16a-save-guard'):
    paths.update((root / 'docs/work' / name).rglob('*.md'))
broken, checked = markdown_link_errors(root, list(paths))
receipt = {'files': len(paths), 'links': checked, 'errors': broken,
           'private_directory_read_or_walked': False,
           'inputs': [{'path': path.relative_to(root).as_posix(),
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                      for path in sorted(paths)]}
target = here / 'markdown-links-19.json'
assert not target.exists()
target.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({key: receipt[key] for key in ('files', 'links', 'errors')}, indent=2))
sys.exit(bool(broken))
