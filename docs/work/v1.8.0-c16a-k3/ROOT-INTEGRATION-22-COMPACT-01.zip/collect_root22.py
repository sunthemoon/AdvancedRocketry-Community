import hashlib
import json
import re
import shutil
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
previous = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/integration-artifacts-21')

def record(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    path = here / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())

def source_check():
    manifest = json.loads((here / 'SOURCE22-MANIFEST-01.json').read_bytes())
    changed = [name for name, row in manifest.items() if record((root / name).read_bytes()) != row]
    assert not changed, changed
    return manifest

mode = sys.argv[1]
manifest = source_check()
if mode == 'build':
    assert json.loads((here / 'build-result-01.json').read_bytes())['exit'] == 0
    dest = here / 'junit'; assert not dest.exists(); dest.mkdir()
    totals = {name: 0 for name in ('tests', 'failures', 'errors', 'skipped')}
    declared = dict(totals); rows = {}
    for path in sorted((root / 'build/test-results/test').glob('*.xml')):
        data = path.read_bytes(); tree = ET.fromstring(data); cases = tree.findall('testcase')
        for key in declared: declared[key] += int(tree.get(key, '0'))
        totals['tests'] += len(cases)
        for tag, key in (('failure', 'failures'), ('error', 'errors'), ('skipped', 'skipped')):
            totals[key] += sum(len(case.findall(tag)) for case in cases)
        (dest / path.name).write_bytes(data); rows[path.name] = record(data)
    assert rows and totals == declared
    assert not any(totals[key] for key in ('failures', 'errors', 'skipped'))
    write('JUNIT-01.json', {'suites': len(rows), 'actual': totals, 'declared': declared, 'xml': rows})
    generated = {name.removeprefix('src/generated/v1.8/resources/'): row
                 for name, row in manifest.items() if name.startswith('src/generated/v1.8/resources/')}
    actual_generated = [p for p in (root / 'src/generated/v1.8/resources').rglob('*')
                        if p.is_file() and '.cache' not in p.parts]
    assert len(generated) == len(actual_generated) == 771
    artifacts = []; output = here / 'artifacts'; assert not output.exists(); output.mkdir()
    old_pins = {'-api.jar': '7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da',
                '-sources.jar': '1368d531681032c3c70fa320fbe7697dff3f124e668c4f17176707220abef9d2',
                '-dev.jar': '796c9611ec8d655398e5a046bfe6cc3f81b2c7880a19c835ea9ed301a990373e'}
    for path in sorted((root / 'build/libs').glob('*.jar')):
        old = previous / path.name; old_data = old.read_bytes()
        expected = next(sha for suffix, sha in old_pins.items() if path.name.endswith(suffix))
        assert record(old_data)['sha256'] == expected
        data = path.read_bytes(); api = path.name.endswith('-api.jar'); sources = path.name.endswith('-sources.jar')
        with zipfile.ZipFile(path) as current, zipfile.ZipFile(old) as baseline:
            names = current.namelist(); assert current.testzip() is None and len(names) == len(set(names))
            old_names = set(baseline.namelist()); changed = [n for n in old_names if n not in names or current.read(n) != baseline.read(n)]
            assert not changed, changed
            added = sorted(set(names) - old_names)
            assert not added if api else added == ['io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash' + ('.java' if sources else '.class')]
            if api: assert data == old_data
            if not api:
                for name, row in generated.items(): assert record(current.read(name)) == row, name
            java_count = 0
            if sources:
                for name in names:
                    if not name.endswith('.java'): continue
                    source = root / 'src/main/java' / name
                    assert current.read(name) == source.read_bytes(), name
                    java_count += 1
            artifacts.append({'name': path.name, **record(data), 'entries': len(names),
                'generated_compared': 0 if api else len(generated), 'committable_main_java_compared': java_count,
                'added_members': added, 'old_members_changed': changed, 'api_byte_equal': api})
        shutil.copyfile(path, output / path.name); assert (output / path.name).read_bytes() == data
    assert len(artifacts) == 3
    write('ARTIFACTS-01.json', artifacts)
    print(json.dumps({'suites': len(rows), **totals, 'artifacts': artifacts}), flush=True)
elif mode == 'gt':
    assert json.loads((here / 'gt-result-01.json').read_bytes())['exit'] == 0
    data = (root / 'build/gametest/logs/latest.log').read_bytes(); gradle = (here / 'gt-01.log').read_bytes()
    count = re.findall(r'All (\d+) required tests passed', data.decode('utf-8'))
    assert len(count) == 1 and re.findall(r'All (\d+) required tests passed', gradle.decode('utf-8')) == count
    path = here / 'gt-native-01.log'; assert not path.exists(); path.write_bytes(data)
    write('GAMETEST-01.json', {'required_passed': int(count[0]), 'exit': 0,
         'native_log': record(data), 'gradle_log': record(gradle),
         'logger_ERROR_lines': len(re.findall(r'/ERROR\]', data.decode('utf-8'))),
         'clean_log_or_waiver_claimed': False, 'source_inputs_postchecked': len(manifest)})
    print('Required GameTests passed: ' + count[0], flush=True)
else:
    raise ValueError(mode)
