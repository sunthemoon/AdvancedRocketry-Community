import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
old = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/integration-21-source-manifest-r1.json')
delta = {
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHash.java': '6ca5b028317766e9106953a011134096e896b08b557db041eb0c92ad493b5ec8',
    'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicNbtCanonicalHashTest.java': 'cf295730469021a70dc2eba85d030379860b16388025359eafb249a526d08c27',
}

def write(name, value):
    path = here / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode('utf-8'))

def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(manifest):
    changed = [name for name, row in manifest.items() if digest(root / name) != row]
    assert not changed, changed

mode = sys.argv[1]
if mode == 'prepare':
    baseline = json.loads(old.read_bytes())
    assert len(baseline) == 2990
    check(baseline)
    manifest = dict(baseline)
    for name, expected in delta.items():
        assert name not in baseline
        row = digest(root / name)
        assert row['sha256'] == expected
        manifest[name] = row
    write('SOURCE22-MANIFEST-01.json', dict(sorted(manifest.items())))
    write('SOURCE22-PRECHECK-01.json', {
        'baseline_r1_manifest_sha256': digest(old)['sha256'],
        'unchanged_baseline_inputs': len(baseline), 'inputs': len(manifest),
        'new_paths_only': list(delta), 'code_baseline': '3f3d62aed3980186fe0acc9592cf93ca436405fb',
        'documentation_tip': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'private_bundle_accessed': False, 'whole_source_exported': False})
    print('Verified 2,990 unchanged R1 inputs plus two exact new source files.', flush=True)
    sys.exit(0)

assert mode in ('build', 'gt')
manifest = json.loads((here / 'SOURCE22-MANIFEST-01.json').read_bytes())
check(manifest)
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
write(mode + '-disk-precheck-01.json', {'free_bytes': free, 'threshold_bytes': 10_000_000_000})
assert min(free.values()) >= 10_000_000_000, free
arguments = ['clean', 'build', 'test', 'runData'] if mode == 'build' else ['runGameTestServer']
command = [str(root / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
           '-Dorg.gradle.jvmargs=-Xmx2G', *arguments]
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
environment['PATH'] = environment['JAVA_HOME'] + '/bin;' + environment['PATH']
start = datetime.datetime.now(datetime.timezone.utc)
write(mode + '-command-01.json', {'command': command, 'cwd': str(root),
     'JAVA_HOME': environment['JAVA_HOME'], 'started_utc': start.isoformat()})
log = here / (mode + '-01.log')
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=root, env=environment,
                            stdout=stream, stderr=subprocess.STDOUT)
end = datetime.datetime.now(datetime.timezone.utc)
write(mode + '-result-01.json', {'exit': result.returncode,
     'started_utc': start.isoformat(), 'finished_utc': end.isoformat(),
     'elapsed_seconds': (end - start).total_seconds(), 'raw_log': digest(log),
     'gate_claimed': False})
check(manifest)
print(json.dumps({'mode': mode, 'exit': result.returncode,
                  'elapsed_seconds': (end - start).total_seconds()}), flush=True)
sys.exit(result.returncode)
