import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
command = [sys.executable, '-B', str(here / 'validate_repository_boundary23.py')]
start = datetime.datetime.now(datetime.timezone.utc)
pins = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
        for name in ('AGENTS.md', 'docs/11-RISK-REGISTER.md',
                     'scripts/validate_repository.py')}
for name in ('repository-boundary-23.log', 'repository-boundary-23.command.json',
             'repository-boundary-23.result.json'):
    assert not (here / name).exists(), name
(here / 'repository-boundary-23.command.json').write_bytes((json.dumps({
    'command': command, 'cwd': str(root), 'started_utc': start.isoformat(),
    'external_governance_and_validator_pins': pins,
    'private_directory_read_or_walked': False}, indent=2) + '\n').encode())
with (here / 'repository-boundary-23.log').open('xb') as output:
    result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
end = datetime.datetime.now(datetime.timezone.utc)
post = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in pins}
receipt = {'exit': result.returncode, 'elapsed_seconds': (end-start).total_seconds(),
           'log_sha256': hashlib.sha256((here / 'repository-boundary-23.log').read_bytes()).hexdigest(),
           'external_governance_and_validator_postpins': post,
           'pinned_inputs_unchanged': post == pins, 'gate_claim': False}
(here / 'repository-boundary-23.result.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt), flush=True)
sys.exit(result.returncode if result.returncode else int(post != pins))
