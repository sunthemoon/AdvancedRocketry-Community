import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
python = [sys.executable, '-B']
jobs = [
    ('focused-python', python + ['-m', 'unittest', 'tests.test_run_v180_pump_smoke', 'tests.test_run_v180_tank_smoke', 'tests.test_run_v180_signature_smoke', '-v']),
    ('common-client', python + ['scripts/check_client_imports.py']),
    ('ledger-strict', python + ['scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('ledger-closure', python + ['scripts/validate_v180_content_ledger.py', '--closure']),
    ('planning', python + ['scripts/validate_v1plus_planning.py']),
    ('provenance', python + ['scripts/validate_bootstrap_provenance.py', '--require-approved-review']),
    ('machine-resources', python + ['scripts/validate_v120_machine_resources.py']),
    ('artifact', python + ['scripts/validate_build_artifact.py', str(here / 'artifacts/advancedrocketry-community-1.20.1-1.8.0-dev.jar'), '--expected-version', '1.20.1-1.8.0-dev']),
    ('diff-check', ['git', 'diff', '--check']),
    ('dirty-diff', ['git', 'diff', '--exit-code']),
]
rows = []
for name, command in jobs:
    log = here / (name + '-01.log'); assert not log.exists()
    start = datetime.datetime.now(datetime.timezone.utc)
    (here / (name + '-command-01.json')).write_bytes((json.dumps({
        'command': command, 'cwd': str(root), 'started_utc': start.isoformat()
    }, indent=2) + '\n').encode())
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode,
           'elapsed_seconds': (datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
           'non_pass_preserved': result.returncode != 0}
    rows.append(row); print(json.dumps(row), flush=True)
target = here / 'STATIC-RESULTS-01.json'; assert not target.exists()
target.write_bytes((json.dumps({'jobs': rows, 'gate_claimed': False}, indent=2) + '\n').encode())
# Report the documented open checks separately; never convert them into PASS.
unexpected = [row for row in rows if row['exit'] != (1 if row['name'] in ('ledger-closure', 'dirty-diff') else 0)]
sys.exit(bool(unexpected))
