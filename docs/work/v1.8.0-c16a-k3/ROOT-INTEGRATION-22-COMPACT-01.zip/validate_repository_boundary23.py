"""Run unchanged checks with only the owner's private Git inventory exclusion."""
import hashlib
import json
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
sys.path.insert(0, str(root))
from scripts import validate_repository as validator

prefix = 'AdvancedRocketry-Community-v1plus-Development-Docs/'
original = validator._bounded_git_stdout
calls = []


def inventory(command, **kwargs):
    args = list(command)
    excluded = 'ls-files' in args and '--others' in args
    if excluded:
        args.append('--exclude=/' + prefix)
    result = original(args, **kwargs)
    if 'ls-files' in args:
        assert not any(name.decode('utf-8').startswith(prefix)
                       for name in result.split(b'\0') if name)
    calls.append({'command': args, 'foreign_directory_excluded': excluded,
                  'stdout_bytes': len(result),
                  'stdout_sha256': hashlib.sha256(result).hexdigest()})
    return result


validator._bounded_git_stdout = inventory
sys.argv = [str(root / 'scripts/validate_repository.py'), '--require-approved-identity']
code = validator.main()
receipt = here / 'repository-boundary-23.json'
assert not receipt.exists()
receipt.write_bytes((json.dumps({'validator_sha256': hashlib.sha256(
    (root / 'scripts/validate_repository.py').read_bytes()).hexdigest(),
    'exit': code, 'calls': calls, 'release_gate_claimed': False}, indent=2) + '\n').encode())
sys.exit(code)
