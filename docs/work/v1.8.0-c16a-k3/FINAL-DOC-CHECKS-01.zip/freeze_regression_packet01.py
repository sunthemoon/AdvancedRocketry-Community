"""Freeze only actual regression receipts, raw logs/XML and helper commands."""
import hashlib
import json
import zipfile
from pathlib import Path

here = Path(__file__).parent
target = here / 'ROOT-INTEGRATION-22-COMPACT-01.zip'
receipt_path = here / 'ROOT-PACKET-01.json'
assert not target.exists() and not receipt_path.exists()
for name in ('build-result-01.json', 'gt-result-01.json',
             'repository-boundary-23.result.json', 'markdown-links-19.json',
             'CODE-COMMIT-PUSH-01.json'):
    assert (here / name).is_file(), name

# Exact flat evidence and one XML directory; never recurse into artifacts,
# preserved copies, source trees, private documents or another agent's outputs.
excluded = {target.name, receipt_path.name, 'freeze_regression_packet01.py'}
paths = sorted(path for path in here.iterdir()
               if path.is_file() and path.name not in excluded
               and path.suffix in ('.json', '.log', '.py'))
paths += sorted((here / 'junit').glob('*.xml'))
entries = []
payloads = []
for path in paths:
    name = path.relative_to(here).as_posix()
    data = path.read_bytes()
    assert len(data) < 50_000_000
    entries.append({'path': name, 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})
    payloads.append((name, data))
assert len({row['path'].casefold() for row in entries}) == len(entries)
assert sum(row['bytes'] for row in entries) < 100_000_000
manifest = (json.dumps({'schema': 1,
    'tested_code_commit': '1ece7e9d2515003ca705b5634ef654a6bcae8f89',
    'scope': 'recorded Root Source22 regression, not native/client/Gate acceptance',
    'files': entries}, indent=2) + '\n').encode()
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in payloads:
        archive.writestr(name, data)
    archive.writestr('EVIDENCE-MANIFEST-01.json', manifest)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(entries) + 1
    for row in entries:
        data = archive.read(row['path'])
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
    assert archive.read('EVIDENCE-MANIFEST-01.json') == manifest
receipt = {'location': str(target), 'bytes': target.stat().st_size,
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'entries': len(entries) + 1,
           'manifest_sha256': hashlib.sha256(manifest).hexdigest(),
           'payload_bytes': sum(row['bytes'] for row in entries),
           'jar_or_complete_source_export': False, 'gate_claimed': False}
receipt_path.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt), flush=True)
