import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

here = Path(__file__).parent
repo = Path('D:/GitHub/AdvancedRocketry-Community')
tasks = [
    ('integration-evidence-01', 'ak3i-a1dc946183',
     '1771d4c397e1b02efab8d73a4d7c1aa7cae06a617f471b70e5b60272f594b017',
     'ea1025f33fe07cd51ff01586d7d55f2c984948a686a10b793413a69e609aba33'),
    ('documentation-review-01', 'ak3d-6d040b00df',
     'af3e4eb6deff76221778a9f1e257ee9224c9edb03b51b798fdfbb3b0ce5ffb6f',
     'b1f969d50d8ca8f6b9f086231b9f20f0593bb81dadc8f03511fd35fc1e4146b6'),
]
rows = []
for label, directory, report_hash, manifest_hash in tasks:
    source = here.parent / directory
    manifest_path = source / 'EVIDENCE-MANIFEST.json'
    manifest_data = manifest_path.read_bytes()
    assert hashlib.sha256(manifest_data).hexdigest() == manifest_hash
    assert hashlib.sha256((source / 'REVIEW-01.md').read_bytes()).hexdigest() == report_hash
    manifest = json.loads(manifest_data)
    files = manifest['files']
    assert isinstance(files, dict)
    names = list(files) + ['EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt']
    assert len({name.casefold() for name in names}) == len(names)
    payloads = {}
    for name in names:
        parts = PurePosixPath(name).parts
        assert parts and not PurePosixPath(name).is_absolute()
        assert all(part not in ('', '.', '..') for part in parts)
        assert ':' not in name and '\\' not in name
        path = source.joinpath(*parts).resolve()
        assert path.is_relative_to(source.resolve())
        data = path.read_bytes()
        if name in files:
            row = files[name]
            assert len(data) == row['bytes'], name
            assert hashlib.sha256(data).hexdigest() == row['sha256'], name
        payloads[name] = data
    for line in payloads['SHA256SUMS.txt'].decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert name in payloads and name != 'SHA256SUMS.txt'
        assert hashlib.sha256(payloads[name]).hexdigest() == digest, name
    target = repo / 'docs/work/v1.8.0-c16a-k3/reviews' / (label + '.zip')
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payloads.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(payloads)
        for name, data in payloads.items():
            assert archive.read(name) == data, name
    row = {'label': label, 'original_loose_location': str(source),
           'target': str(target), 'bytes': target.stat().st_size,
           'entries': len(payloads),
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'manifest_sha256': manifest_hash, 'report_sha256': report_hash,
           'all_original_payloads_exact': True,
           'root_compacted_not_reviewer_created_zip': True,
           'originals_modified': False, 'gate_claimed': False}
    rows.append(row)
    print(json.dumps(row), flush=True)
receipt = here / 'REVIEW-PACKETS-01.json'
assert not receipt.exists()
receipt.write_bytes((json.dumps(rows, indent=2) + '\n').encode())
