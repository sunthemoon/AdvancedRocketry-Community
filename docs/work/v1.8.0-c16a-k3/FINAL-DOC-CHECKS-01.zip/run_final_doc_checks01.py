import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
sys.path.insert(0, str(root))
from scripts.validate_repository import markdown_link_errors

# Recorded code/data inputs, not the excluded private directory or evidence tree.
manifest = json.loads((here / 'SOURCE22-MANIFEST-01.json').read_bytes())
changed = [name for name, row in manifest.items()
           if not (root / name).is_file()
           or len((root / name).read_bytes()) != row['bytes']
           or hashlib.sha256((root / name).read_bytes()).hexdigest() != row['sha256']]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
proof = {'tested_code_commit': '1ece7e9d2515003ca705b5634ef654a6bcae8f89',
         'current_head': head, 'snapshot_inputs': len(manifest), 'changed': changed,
         'private_directory_read_or_walked': False, 'gate_claimed': False}
target = here / 'SOURCE22-FINAL-POSTCHECK-01.json'
assert not target.exists()
target.write_bytes((json.dumps(proof, indent=2) + '\n').encode())

paths = {root / name for name in subprocess.check_output(
    ['git', 'ls-files', '*.md'], cwd=root, text=True).splitlines()}
for name in ('v1.8.0-c16a-k3', 'v1.8.0-c16a-save-guard'):
    paths.update((root / 'docs/work' / name).rglob('*.md'))
broken, checked = markdown_link_errors(root, list(paths))
links = {'files': len(paths), 'links': checked, 'errors': broken,
         'private_directory_read_or_walked': False,
         'inputs': [{'path': path.relative_to(root).as_posix(),
                     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for path in sorted(paths)]}
target = here / 'markdown-links-20.json'
assert not target.exists()
target.write_bytes((json.dumps(links, indent=2) + '\n').encode())
print(json.dumps({key: links[key] for key in ('files', 'links', 'errors')}), flush=True)

rows = []
for name, command in (
    ('planning-final01', [sys.executable, '-B', 'scripts/validate_v1plus_planning.py']),
    ('ledger-final01', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('diff-final01', ['git', 'diff', '--check'])):
    start = datetime.datetime.now(datetime.timezone.utc)
    log = here / (name + '.log')
    command_path = here / (name + '.command.json')
    assert not log.exists() and not command_path.exists()
    command_path.write_bytes((json.dumps({'command': command, 'cwd': str(root),
        'started_utc': start.isoformat()}, indent=2) + '\n').encode())
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode,
           'elapsed_seconds': (datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    print(json.dumps(row), flush=True)
receipt = {'commands': rows, 'source_inputs_exact': not changed,
           'links_exit': int(bool(broken)), 'current_head': head, 'gate_claimed': False}
target = here / 'FINAL-DOC-CHECKS-01.json'
assert not target.exists()
target.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
sys.exit(int(bool(changed or broken or any(row['exit'] for row in rows))))
