#!/usr/bin/env bash
# C15c Python checks after the ledger and documentation edits; each log and exit code is kept.
C=C:/Users/ADMINI~1/AppData/Local/Temp/arce-v180-c15c-27e5d85d411242028299223ae71b0848
EV=C:/Users/ADMINI~1/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251
cd /d/GitHub/AdvancedRocketry-Community || exit 1
mkdir -p $C/python
git rev-parse HEAD > $C/python/head.txt
git status --porcelain > $C/python/status.txt
run() { name=$1; shift; "$@" > $C/python/$name.log 2>&1; echo $? > $C/python/$name.exit; }
run py-01-ledger python -B scripts/validate_v180_content_ledger.py
run py-02-ledger-accepted python -B scripts/validate_v180_content_ledger.py --require-accepted
run py-03-ledger-closure python -B scripts/validate_v180_content_ledger.py --closure
run py-04-inventory python -B tools/audit/inventory_v180_content.py --upstream $EV/upstream/ar --check
run py-05-derivation python -B tools/audit/vanilla_derivation.py --upstream $EV/upstream/ar --vanilla 1.12.2=$EV/vanilla/client-1.12.2.jar --vanilla 1.20.1=$EV/vanilla/client-1.20.1.jar --check --report-memory
run py-06-art-screen python -B tools/audit/screen_generated_art.py --root src/generated/v1.8/resources --vanilla 1.12.2=$EV/vanilla/client-1.12.2.jar --vanilla 1.20.1=$EV/vanilla/client-1.20.1.jar --output $C/python/art-screen.json
run py-07-unittest python -B -m unittest -v tests.test_validate_v180_content_ledger tests.test_vanilla_derivation tests.test_screen_generated_art
run py-08-machine-resources python -B scripts/validate_v120_machine_resources.py
run py-09-beta-resources python -B scripts/validate_v090_resources.py
run py-10-client-imports python -B scripts/check_client_imports.py
echo DONE > $C/python/status.done
