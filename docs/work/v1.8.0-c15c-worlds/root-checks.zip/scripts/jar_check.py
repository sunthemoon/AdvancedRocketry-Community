"""C15c JAR resource check: no duplicate entries; each superseded planet file and each v1.8 tool tag appears once in
the main and sources JARs, with the bytes of the v1.8 generated copy; no empty directory entries."""
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
V18 = ROOT / 'src/generated/v1.8/resources'
CHECKED = [
    'data/advancedrocketrycommunity/dimension/moon.json',
    'data/advancedrocketrycommunity/dimension/mars.json',
    'data/advancedrocketrycommunity/dimension/venus.json',
    'data/advancedrocketrycommunity/worldgen/noise_settings/moon.json',
    'data/advancedrocketrycommunity/worldgen/noise_settings/mars.json',
    'data/advancedrocketrycommunity/worldgen/noise_settings/venus.json',
    'data/minecraft/tags/blocks/needs_iron_tool.json',
    'data/minecraft/tags/blocks/needs_stone_tool.json',
    'data/minecraft/tags/blocks/mineable/pickaxe.json',
    # C15c: the v1.8 data satellite supersedes the v1.5 copy; the new Levels and the vanilla wood tags.
    'data/advancedrocketrycommunity/satellite_definitions/data_satellite.json',
    'data/advancedrocketrycommunity/dimension/tau_ceti_f.json',
    'data/advancedrocketrycommunity/dimension/tau_ceti_g.json',
    'data/advancedrocketrycommunity/worldgen/noise_settings/tau_ceti_f.json',
    'data/minecraft/tags/blocks/logs_that_burn.json',
    'data/minecraft/tags/blocks/planks.json',
    'data/minecraft/tags/blocks/leaves.json',
    'data/minecraft/tags/blocks/saplings.json',
]
sha = lambda data: hashlib.sha256(data).hexdigest()
failures = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    if not (jar.name.endswith('-dev.jar') or jar.name.endswith('-sources.jar')):
        continue
    with zipfile.ZipFile(jar) as archive:
        names = [info.filename for info in archive.infolist()]
        duplicates = sorted({name for name in names if names.count(name) > 1})
        print(f'{jar.name} sha256 {sha(jar.read_bytes())} entries {len(names)} duplicate entries {len(duplicates)}')
        if duplicates:
            failures.append(f'{jar.name}: duplicates {duplicates[:5]}')
        for path in CHECKED:
            copies = names.count(path)
            expected = sha((V18 / path).read_bytes())
            actual = sha(archive.read(path)) if copies else None
            same = actual == expected
            print(f'  {path} copies={copies} v1.8_bytes={same} sha256={actual}')
            if copies != 1 or not same:
                failures.append(f'{jar.name}: {path} copies={copies} same={same}')
        directories = {name for name in names if name.endswith('/')}
        empty = sorted(d for d in directories if not any(n != d and n.startswith(d) for n in names))
        print(f'  empty-directory entries without files: {empty}')
        if empty:
            failures.append(f'{jar.name}: empty directories {empty}')
print('RESULT', 'PASS' if not failures else 'FAIL ' + '; '.join(failures))
sys.exit(1 if failures else 0)
