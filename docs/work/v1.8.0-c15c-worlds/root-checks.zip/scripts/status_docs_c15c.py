"""Record the C15c delivery and C15b review round 1 in the status documents (documentation only)."""
import json
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
facts = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))


def edit(relative, old, new):
    path = ROOT / relative
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (relative, old[:80])
    path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')


LOG = 'docs/work/v1.8.0-implementation-log.md'
edit(LOG, '| C15 | C15b | Moon/Mars/Venus surfaces, biomes and features | delivered; geode cover fix `d0f9545` after '
          'delivery; implementation review pending |',
     '| C15 | C15b | Moon/Mars/Venus surfaces, biomes and features | delivered; review round 1 answered (fixes '
     '`d0f9545`..`e39fd9d`), round 2 pending |')
edit(LOG, '| C15 | C15c | Classic exoplanet worlds and their flora | implementing |',
     '| C15 | C15c | Classic exoplanet worlds and their flora | delivered; implementation review pending |')
text = (ROOT / LOG).read_text(encoding='utf-8').rstrip('\n')
text += '''
- C15b review round 1 (0 Critical, 1 High, 5 Medium, 6 Low, 6 Info) is answered
  commit by commit ([dispositions](v1.8.0-c15b-surfaces/review-01-dispositions.md)):
  geodes centred under the lowest ground over their lens, volcanoes refused over
  cliffs, the Moon's highland turf for foreign biomes and the upgrade band
  disclosed, structure tests that compare blocks before and after, the GameTest
  seed pinned to 0, server switches held in memory by tests, the Venus layout
  reason corrected, and the ledger, guide and ADR notes. Their re-run evidence is
  this slice's run.
- Implementation `28d24b8` (with `fae751b`, the landing ground in revision 6).
  Evidence run on `{run}`: {gt} GameTests, {junit} JUnit tests, clean DataGen diff;
  S1 on a copy of the retained v1.6 world upgraded by the v1.7 handoff build, with
  the C15bR1 seam step ([C15c evidence](v1.8.0-c15c-worlds/VERIFICATION.md)).
- 25 ledger rows delivered: {implemented} IMPLEMENTED, {redesigned} REDESIGNED.
- Open: one of six GameTest runs (before the seed was pinned) stalled the Tau
  Ceti path's transfer after the destination spawned, with no log line; five
  runs passed. The test now reports the journal phase, the journal state and
  whether the rocket's chunk ticks if it recurs.
'''.format(**facts)
(ROOT / LOG).write_text(text, encoding='utf-8', newline='\n')

PLAN = 'docs/status/COMPLETION-PLAN.md'
edit(PLAN, '''    C15b 月球、火星、金星地表与地物 `[x]`（开发完成，待独立实现审核与 ADR-063 第 5 版的接受；证据
    `docs/work/v1.8.0-c15b-surfaces/`）；C15c 经典系外行星世界（ADR-063 已接受）；''',
     '''    C15b 月球、火星、金星地表与地物 `[x]`（开发完成；独立实现审核第 1 轮的发现已逐项修复，待第 2 轮
    与 ADR-063 第 5 版的接受；证据 `docs/work/v1.8.0-c15b-surfaces/`）；C15c 经典系外行星世界 `[x]`
    （开发完成，待独立实现审核与 ADR-063 第 6 版的接受；证据 `docs/work/v1.8.0-c15c-worlds/`）；''')
edit(PLAN, '''**C15b 收尾**：独立实现审核与修复。维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机或改键
`rolling_iron_bars`、金红石不压制、轧制配方用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）、
第 5 版（陨石坑结构、金星斑块生物群系源、三颗天体无洞穴雕刻、掉落与工具、结构件 schema 等）与
ADR-061 第 7 版（内核机器配方在 C16a 前只用物品原料）。随后 **C15c 经典系外行星世界**
（同一会话继续；ADR-063 §6）。''',
     '''**C15 收尾**：C15b 独立实现审核第 2 轮与 C15c 独立实现审核及修复。维护者决定是否接受 ADR-063
第 4 版（铁板来自压板机或改键 `rolling_iron_bars`、金红石不压制、轧制配方用物品原料、压板机在动作时解析
标签并拒绝歧义、两个开关）、第 5 版（陨石坑结构、金星斑块生物群系源与其固定布局、三颗天体无洞穴雕刻、
晶洞覆盖层与火山起伏限制、掉落与工具、结构件 schema 等）、第 6 版（鲸鱼座τ f 与 g、着陆场、六种生物群系与
地物、方块与客户端闪电效果）与 ADR-061 第 7 版（内核机器配方在 C16a 前只用物品原料）。随后
**C16a 经典机器家族、流体、储罐与泵**（同一会话继续；先冻结 C16 批次 ADR）。''')

CURRENT = 'docs/status/CURRENT_VERSION.md'
edit(CURRENT, '''accepted it. C15b (the Moon, Mars and Venus surfaces, structures and planet ores) is
delivered ([C15b evidence](../work/v1.8.0-c15b-surfaces/VERIFICATION.md)); its
independent review is pending. The owner's decision on ADR-063 revisions 4 and 5 and
ADR-061 revision 7 is open. The next chunk is in [COMPLETION-PLAN](COMPLETION-PLAN.md).
No Gate is claimed.''', '''accepted it. C15b (the Moon, Mars and Venus surfaces, structures and planet ores) is
delivered ([C15b evidence](../work/v1.8.0-c15b-surfaces/VERIFICATION.md)); its first
independent review is answered and the second is pending. C15c (the Tau Ceti f and g
worlds) is delivered ([C15c evidence](../work/v1.8.0-c15c-worlds/VERIFICATION.md)); its
independent review is pending. The owner's decision on ADR-063 revisions 4, 5 and 6 and
ADR-061 revision 7 is open. The next chunk is in [COMPLETION-PLAN](COMPLETION-PLAN.md).
No Gate is claimed.''')

MATRIX = 'docs/PORTING_MATRIX.md'
edit(MATRIX, '月球/火星/金星地表方块与生物群系、陨石坑/火山/晶洞与焦木（C15b 已交付）；水晶与外星森林等六种生物群系落在固定的'
             '数据驱动世界（C15c）',
     '月球/火星/金星地表方块与生物群系、陨石坑/火山/晶洞与焦木（C15b 已交付）；鲸鱼座τ f 与 g 两个世界的六种生物群系、'
     '外星树、巨型沼泽树、倒悬石柱、水晶簇与电蘑菇（C15c 已交付）')
print('status documents updated')
