"""Fill the C15c VERIFICATION template from the run's facts, the S1 summary and the Python check results."""
import json
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
OUT = ROOT / 'docs/work/v1.8.0-c15c-worlds'
NS = 'advancedrocketrycommunity'

lang = json.loads((ROOT / 'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/en_us.json')
                  .read_text(encoding='utf-8'))
BLOCKS = ['lightwood_log', 'lightwood_leaves', 'lightwood_sapling', 'lightwood_planks', 'electric_mushroom'] + [
    f'{colour}_crystal_block' for colour in ('violet', 'blue', 'green', 'red', 'yellow', 'orange')]
for block in BLOCKS:
    assert f'block.{NS}.{block}' in lang, block
registered = ', '.join(f'`{NS}:{block}`' for block in BLOCKS)

run = (E / 'run-commit.txt').read_text().strip()[:7]
junit = json.loads((E / 'junit-summary.json').read_text())
gametests = json.loads((E / 'gametest-summary.json').read_text())['required_passed']
artifacts = {a['name']: a['sha256'][:8] for a in json.loads((E / 'artifacts.json').read_text())['artifacts']}
art = json.loads((E / 'python' / 'art-screen.json').read_text(encoding='utf-8'))
art_counts = art.get('counts') or art.get('summary') or {}
clear = art_counts.get('CLEAR') if isinstance(art_counts, dict) else None


def line_of(log, needle):
    for line in (E / log).read_text(encoding='utf-8', errors='replace').splitlines():
        if needle in line:
            return line.strip()
    return ''


build1 = line_of('root-gradle-01.log', 'BUILD SUCCESSFUL').replace('BUILD SUCCESSFUL in ', '')
build2 = line_of('root-gradle-02.log', 'BUILD SUCCESSFUL').replace('BUILD SUCCESSFUL in ', '')
errors = sum(1 for line in (E / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace').splitlines()
             if '/ERROR]' in line)
fatal = sum(1 for line in (E / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace').splitlines()
            if '/FATAL]' in line)

PYTHON = [
    ('py-01-ledger', '`python -B scripts/validate_v180_content_ledger.py`'),
    ('py-02-ledger-accepted', '`… --require-accepted`'),
    ('py-03-ledger-closure', '`… --closure` (expected to fail until C19)'),
    ('py-04-inventory', '`python -B tools/audit/inventory_v180_content.py --upstream <Temp> --check`'),
    ('py-05-derivation', '`python -B tools/audit/vanilla_derivation.py --upstream <Temp> --vanilla … --check`'),
    ('py-06-art-screen', '`python -B tools/audit/screen_generated_art.py --root src/generated/v1.8/resources '
                         '--vanilla 1.12.2=… --vanilla 1.20.1=…`'),
    ('py-07-unittest', '`python -B -m unittest tests.test_validate_v180_content_ledger '
                       'tests.test_vanilla_derivation tests.test_screen_generated_art`'),
    ('py-08-machine-resources', '`python -B scripts/validate_v120_machine_resources.py`'),
    ('py-09-beta-resources', '`python -B scripts/validate_v090_resources.py`'),
    ('py-10-client-imports', '`python -B scripts/check_client_imports.py`'),
]


def summary(name):
    log = (E / 'python' / f'{name}.log').read_text(encoding='utf-8', errors='replace').strip().splitlines()
    code = (E / 'python' / f'{name}.exit').read_text().strip()
    if name == 'py-07-unittest':
        keys = [line.strip() for line in log if line.startswith('Ran ') or line.strip() == 'OK']
    else:
        keys = [line.strip() for line in log if '"result"' in line or 'PASS' in line or 'up to date' in line
                or 'CLEAR' in line]
    tail = '; '.join(dict.fromkeys(keys[-2:])) if keys else (log[-1].strip() if log else '')
    return code, tail.replace('|', '/')


rows = ['| Command | Result |', '|---|---|',
        f'| `gradlew --offline clean build test runData runGameTestServer` on `{run}` | Exit 0, {build1}. '
        f'**{gametests} required GameTests** passed (seed 0). `git status -- src/generated` after DataGen: clean |',
        f'| `gradlew --offline test --rerun` | Exit 0, {build2}. **{junit["tests"]:,} JUnit tests / {junit["suites"]} '
        f'suites**, {junit["failures"]} failures, {junit["errors"]} errors, {junit["skipped"]} skips |',
        '| JAR resource check (`jar-resource-check.txt`) | No duplicate entries; the v1.8 Moon, Mars, Venus and '
        'Tau Ceti dimension and noise-settings files, the v1.8 data satellite, the tool tags and the wood tags '
        'appear once each in the main and sources JARs, with the v1.8 bytes; no empty directories '
        '(`RESULT PASS`) |']
for name, command in PYTHON:
    code, text = summary(name)
    rows.append(f'| {command} | Exit {code}; {text} |')
commands = '\n'.join(rows) + f'''

Final validators: after packaging, {{final}}. They need the finished packet, so their log is
`packaging/out/validation-final.log` in the Temp evidence directory, outside `root-checks.zip`.

The three JARs (`artifacts.json`, with every entry in `artifact-entries.json`): main
`{artifacts['advancedrocketry-community-1.20.1-1.8.0-dev.jar']}…`, API
`{artifacts['advancedrocketry-community-1.20.1-1.8.0-dev-api.jar']}…` (unchanged since C15a), sources
`{artifacts['advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar']}…`. The full build log has {errors} ERROR
lines and {fatal} FATAL, from intentional failure-injection GameTests and the transfer recovery tests. This is not
a clean-log claim. The pre-commit GameTest logs (six C15c runs, three runs of a copy of the tree, two runs on the
C15b round 1 fixes) are in `prechecks/`.'''

summary_native = json.loads((E / 'native' / 'summary.json').read_text(encoding='utf-8'))
upgrade = summary_native['upgrade']
samples = upgrade['samples']
ms = upgrade['ms_per_chunk']
timings = upgrade['timings']


def tops(prefix):
    values = sorted({value['block'] for key, value in samples.items() if key.startswith(prefix)})
    return ', '.join(f'`{value}`' for value in values)


def biomes(prefix):
    values = sorted({value['biome'] for key, value in samples.items() if key.startswith(prefix)})
    return ', '.join(f'`{value}`' for value in values)


native = ['A copy of the retained v1.6 world (`arce-v160-c9-…/attempt-04/native-server/world`) was opened by the '
          'v1.7 handoff build (main JAR `4326d3d6…`), which generated and saved a 10 × 10 chunk square (chunks −5..4) '
          'around the origin of the Moon, Mars and Venus. The v1.8 build of the tested commit then opened it on a '
          'packaged dedicated server (`native_c15c_check.py`, derived from the C15b harness; release-test hooks on, '
          'no clients; structures on in the copy). The upgrade phase force-loaded chunks −7..6 of each body, so the '
          'v1.8 build loaded every explored chunk (C15bR1-L6); it then sampled every chunk of −10..9 outside that '
          'square, which finishes the band the v1.7 build had saved part-way (C15bR1-M1), and warmed up before '
          'measuring the Overworld reference (L6). A first attempt (`attempt-01-ring-too-near/`, passed) sampled '
          'chunks −6 and 5 only, which the v1.7 build had fully generated next to its forced square, so it did not '
          'reach the band.', '',
          '| Check | Result |', '|---|---|']
for planet in ('moon', 'mars', 'venus'):
    old = samples[f'{planet}:explored']
    native.append(f'| {planet.capitalize()} explored column (−40, −40) keeps its old top | `{old["block"]}` at y '
                  f'{old["top"]}, biome `{old["biome"]}` |')
for planet in ('moon', 'mars', 'venus'):
    ring = upgrade.get('ring_' + planet, {})
    native.append(f'| {planet.capitalize()} band beyond the explored square (each chunk of −10..9 outside −7..6, '
                  f'{sum(ring.values())} columns) | top / biome: '
                  + '; '.join(f'`{pair}` × {count}' for pair, count in ring.items())
                  + (' (never bare stone; new terrain on the stored `plains` biome wears turf)' if planet == 'moon'
                     else ' (never bare stone)') + ' |')
for planet in ('moon', 'mars', 'venus'):
    generated = timings[planet]
    native.append(f'| {planet.capitalize()} new chunks (9 × 9 around chunk 64, 64) | tops {tops(planet + ":new")}; '
                  f'biomes {biomes(planet + ":new")}; highest surface y {generated.get("highest")}; starts '
                  f'{generated.get("starts")} |')
for world in ('tau_ceti_f', 'tau_ceti_g'):
    generated = timings[world]
    native.append(f'| {world} new chunks (9 × 9 around chunk 64, 64) | tops {tops(world + ":new")}; biomes '
                  f'{biomes(world + ":new")}; highest surface y {generated.get("highest")} |')
    pads = [value for key, value in samples.items() if key.startswith(world + ':pad:')]
    native.append(f'| {world} landing pads (the eight centres) | tops {tops(world + ":pad")}; surfaces y '
                  f'{min(int(p["top"]) for p in pads)}–{max(int(p["top"]) for p in pads)} |')
native.append('| Generation time (81 chunks each, synchronous) | ' + '; '.join(
    f'{name} {ms[name]:.1f} ms/chunk' for name in ('overworld', 'moon', 'mars', 'venus', 'tau_ceti_f', 'tau_ceti_g'))
    + ' (budget 1.5 × the Overworld reference) |')
native.append(f'| Explored chunks after the upgrade | {summary_native["explored_chunks_unchanged"]} chunks (10 × 10 per '
              f'body, all loaded by the v1.8 build): every block section equal before and after |')
native.append('| Logs | Both phases start and stop cleanly (exit 0); the log scan finds no unexpected error or warning; '
              'the source world is unchanged |')
native.append('')
native.append('The phases\' logs, commands, receipts and the summary are in `root-checks.zip` (`native/`).')

facts = {'run': run, 'implemented': 18, 'redesigned': 7, 'registered': registered, 'art': clear,
         'native': '\n'.join(native), 'commands': commands}
template = (E / 'scripts' / 'verification-c15c.md').read_text(encoding='utf-8')
text = template
for key, value in facts.items():
    text = text.replace('{' + key + '}', str(value))
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'VERIFICATION.md').write_text(text, encoding='utf-8', newline='\n')
(E / 'scripts' / 'facts-c15c.json').write_text(json.dumps(
    {'run': run, 'gt': str(gametests), 'junit': f'{junit["tests"]:,}', 'implemented': 18, 'redesigned': 7},
    indent=2) + '\n', encoding='utf-8', newline='\n')
print('written', OUT / 'VERIFICATION.md', 'unfilled:', [k for k in ('{final}',) if k in text])
