"""Mark the 25 C15c ledger rows delivered (ADR-062 section 1) with the C15c evidence (ADR-063 section 6, rev. 6)."""
import csv
import io
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEDGER = ROOT / 'docs/work/v1.8.0-content-ledger.csv'
EVIDENCE = 'docs/work/v1.8.0-c15c-worlds/VERIFICATION.md'
NS = 'advancedrocketrycommunity:'
I, R = 'IMPLEMENTED', 'REDESIGNED'
COLOURS = ['violet', 'blue', 'green', 'red', 'yellow', 'orange']

# unit -> (disposition, target, notes or None to keep)
DELIVERED = {
    'biome:alien_forest': (I, NS + 'alien_forest biome', 'Tau Ceti f'),
    'biome:crystalchasms': (I, NS + 'crystal_chasms biome', 'Tau Ceti g'),
    'biome:deepswamp': (I, NS + 'deep_swamp biome', 'Tau Ceti f; nothing spawns (the legacy slimes are not restored)'),
    'biome:marsh': (I, NS + 'marsh biome', 'Tau Ceti f'),
    'biome:oceanspires': (I, NS + 'ocean_spires biome', 'Tau Ceti f'),
    'biome:stormland': (I, NS + 'stormland biome',
                        'Tau Ceti g; nothing spawns (the legacy creepers are not restored)'),
    'block:alienLeaves': (I, NS + 'lightwood_leaves', 'alien forest flora; light 8, a sapling in 1 of 100 drops'),
    'block:alienSapling': (I, NS + 'lightwood_sapling', 'alien forest flora; grows the lightwood tree'),
    'block:alienWood': (I, NS + 'lightwood_log', 'alien forest flora; burns, hardness 3'),
    'block:crystal': (R, 'six crystal blocks, one per colour', 'the legacy block with six variants is one block per '
                      'colour; crystal chasm decoration'),
    'block:electricMushroom': (I, NS + 'electric_mushroom', 'stormland flora; sparks, and flashes in the rain'),
    'block:planks': (I, NS + 'lightwood_planks', 'alien forest flora; light 4, four from a log'),
    'config:CLIENT.electricPlantsSpawnLightning': (
        R, 'CLIENT value effects.electricMushroomFlashes',
        'client effect only: a sky flash and distant thunder in a stormland during rain; nothing is struck'),
    'worldgen:MapGenInvertedPillar': (R, 'inverted_pillar placed feature in the ocean spires',
                                      'a placed feature within 12 blocks instead of a map generator'),
    'worldgen:MapGenLargeCrystal': (R, 'crystal_cluster placed feature in the crystal chasms',
                                    'the large crystals become the crystal cluster feature, within 12 blocks'),
    'worldgen:MapGenSwampTree': (R, 'giant_swamp_tree placed feature in the deep swamp',
                                 'a placed feature with its canopy within 12 blocks instead of a map generator'),
    'worldgen:WorldGenAlienTree': (R, 'lightwood_tree placed feature in the alien forest',
                                   'branches shortened to stay within 12 blocks (the legacy tree reached about 14)'),
    'worldgen:WorldGenElectricMushroom': (I, 'electric_mushrooms placed feature in the stormland', None),
    'worldgen:WorldGenLargeCrystal': (R, 'crystal_cluster placed feature in the crystal chasms',
                                      'the lean is capped so that the top stays within 12 blocks'),
}
for index, colour in enumerate(COLOURS):
    DELIVERED[f'block_variant:crystal/{index}'] = (I, f'{NS}{colour}_crystal_block', None)

raw = LEDGER.read_text(encoding='utf-8')
rows = list(csv.reader(io.StringIO(raw)))
seen = set()
for row in rows[1:]:
    if row[0] in DELIVERED:
        assert row[1] == 'PLANNED' and row[2] == 'C15c', row
        disposition, target, notes = DELIVERED[row[0]]
        row[1], row[2], row[3], row[4], row[6] = disposition, 'v1.8.0', target, 'ADR-063', EVIDENCE
        if notes is not None:
            row[5] = notes
        seen.add(row[0])
    elif row[0] == 'worldgen:WorldGenCharredTree':
        # C15c also places the charred tree in the stormland.
        row[3] = 'charred_tree feature in the volcanic biome and the stormland'
assert seen == set(DELIVERED), set(DELIVERED) - seen
left = [row[0] for row in rows[1:] if row[2] == 'C15c']
assert not left, left
out = io.StringIO()
csv.writer(out, lineterminator='\n').writerows(rows)
LEDGER.write_text(out.getvalue(), encoding='utf-8', newline='')
counts = {}
for unit, (disposition, _, _) in DELIVERED.items():
    counts[disposition] = counts.get(disposition, 0) + 1
print('delivered', len(seen), counts)
