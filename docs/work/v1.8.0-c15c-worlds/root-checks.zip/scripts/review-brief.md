You are the independent implementation reviewer for slice C15c of v1.8.0 in the repository
D:/GitHub/AdvancedRocketry-Community (Minecraft 1.20.1 Forge 47.4.10, Java 17). Review round 1 (C15cR1).

Read-only rules (strict):
- Do not modify the repository or its working copy in any way: no git writes (no commit, checkout, stash,
  reset, worktree, add), no file edits, no builds inside the repository directory.
- Read the committed tree only through git (`git show`, `git diff`, `git log`, `git ls-tree`, `git archive`).
  Export the reviewed commit with `git archive <commit> | tar -x -C <your dir>/tree` and build/run there.
- Work only in your own directory: C:/Users/Administrator/AppData/Local/Temp/arce-v180-c15c-review-<random hex>.
  Create it first.
- Never read or copy the untracked folder `AdvancedRocketry-Community-v1plus-Development-Docs/`.
- Java: `C:/Program Files/Java/jdk-17.0.7` (set JAVA_HOME; the shell default is invalid). Gradle with `--offline`.
  Run Gradle builds one at a time; a full `clean build runData runGameTestServer` takes about 7 minutes.
  The C: drive has limited space (about 25 GB free): keep at most one exported tree plus its build, and delete
  server copies and trees when you finish.
- If you need Minecraft/Forge behaviour, use `javap -c` on the mapped Forge jar in
  C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/
  1.20.1-47.4.10_mapped_official_1.20.1/.
- Another reviewer may be running a C15b re-review at the same time in its own directory; do not touch it.

Reviewed commit: {REVIEWED} on branch `codex/v1.8.0-classic-content`. C15a and C15b are delivered (C15b's
round 1 findings are answered in the same tree; they are not your scope except where C15c depends on them).
C15c commits: `f32ec0c` (ADR-063 revision 6 proposed), `315ccd8` (four textures drawn new), `d0f9545` (a
C15b geode defect C15c found), `fae751b` (revision 6: the landing ground, alternative D, corrections),
`28d24b8` (the implementation), `{PACKET}` (the evidence packet, ledger delivery and status documents).
The evidence run tested `e39fd9d` (C15c plus the C15b round 1 fixes); the packet commit changes only
documents.

Read first: AGENTS.md; docs/decisions/ADR-061 (identity, import, validation), ADR-062 §1/§6/§7, ADR-063 in
full (especially §6 with revision 6, §8, §9, alternative D), ADR-006 (rocket transfer, fixed pads) and
ADR-033 (planetary admission and landing support); docs/work/v1.8.0-c15c-worlds/VERIFICATION.md; the C15c
section of docs/work/v1.8.0-implementation-log.md; the non-generated diff `7be9226..{REVIEWED}` restricted to
C15c (the exoplanet packages, datagen V180Exoplanet*, ClientConfig, the client exoplanet effects, the new
GameTests, build.gradle, CHANGELOG, provenance); spot-check the generated JSON under src/generated/v1.8.

Review for:
1. Correctness against ADR-063 §6/§9 and revision 6: the bodies' numbers, routes and data satellite targets;
   the Levels and terrain (Tau Ceti f's top block 63 + 22n with the biome bands, g's plateau 96 + 8n and its
   patches); the six biomes (surfaces, colours, no spawns or carvers); every feature within 12 blocks of its
   origin with its switch and legacy numbers; the blocks (drops, light, flammability, tags, the sapling); the
   electric mushroom's client effect (client only, nothing over the network, the CLIENT setting).
2. The landing ground (revision 6): does it really guarantee free, dry pads on both worlds for any seed and the
   widest landing footprint? Are the density function and placement filter codecs bounded, flat and safe? Does
   anything outside the landing ground change? Is alternative D fairly stated?
3. AGENTS.md constraints: server authority, bounded algorithms, size limits on variable data (codecs), no
   client imports in common code, persistence and schema, file sizes (500/800 lines), registry identities.
4. Test quality: do the GameTests and JUnit tests actually prove the contract? Run mutations (a feature's
   reach, a switch, the landing radius or floor, a biome band, a drop chance, the Tau Ceti path) and report
   which survive. Check for tests that pass vacuously. Note the open intermittent stall of the Tau Ceti path
   test recorded in VERIFICATION; if you can reproduce or explain it, say how.
5. Evidence: rebuild the export, compare GameTest/JUnit counts, JAR hashes and entries, DataGen determinism,
   the art screen (32 CLEAR), the ledger validator, and the S1 native results in the packet with what you
   measure. The GameTest seed is pinned to 0.
6. The earlier tests changed by C15c (`BootstrapGameTests` body count, the interstellar warp quote, the
   discovery fixture batch, StarSystemGameTests): do they keep their intent without weakening?
7. The ledger rows (25 delivered: 18 IMPLEMENTED, 7 REDESIGNED): are dispositions, targets and notes honest?
8. ADR-063 revision 6 (proposed): recommend accept / accept with changes / reject, with reasons.

Write your report as REVIEW.md in your directory, in the format of
docs/work/v1.8.0-c15b-surfaces/reviews/REVIEW-01.md: header (reviewed commit, scope, method, isolation),
"1. Commands run and results" (table), "2. Findings" (each with an ID C15cR1-<severity letter><n>, severity
Critical/High/Medium/Low/Info, evidence with file:line, impact, and a concrete required change), "3. Verdicts"
(C15c: accept / accept with required changes / reject; ADR-063 revision 6). Keep all your scripts, logs and
probes in your directory (not the exported tree or Minecraft disassembly). Reply with a short summary: counts
by severity, verdicts, and the path of REVIEW.md.
