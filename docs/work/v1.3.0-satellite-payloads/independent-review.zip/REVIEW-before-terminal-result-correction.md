# V130-SAT final independent scoped review

## Findings

**No unresolved concrete finding remains in the reviewed SAT source, finite runner or inspected final evidence.** This is a scoped review, not approval of v1.3 or any complete Required Gate.

Two source findings from the prior read-only review were corrected:

1. **P1, inherited menu authority hole.** Old terminal menus/cached handlers could access already-dropped resources after replacement by another terminal at the same position. `satellite/terminal/SatelliteTerminalMenu.java:177-182` now checks removed state, loaded chunk and exact live BE identity; `SatelliteTerminalBlockEntity.java:64` blocks removed-handler insertion/extraction. `gametest/SatelliteTerminalPersistenceGameTests.java:138-153` exercises destruction/replacement, old menu/cached-handler refusal and the original three dropped chassis. Root's final 199-test GameTest pass includes this regression; this reviewer did not independently launch GameTest.
2. **P2, native-item budget mismatch.** `SatelliteTerminalInventory.java:72-80` now budgets the host-added integer Slot separately (11 bytes/one node), then checks the original 4,096-byte/depth-16/256-node native item. The exactly 4,096-byte insertion/save/load regression is at `SatelliteTerminalPersistenceGameTests.java:156-170`. Root's final GameTest pass includes it. No operational item budget was relaxed.

Java paths above are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`. Detailed first-pass source analysis and the initial source snapshots remain unchanged at `C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-source-review-x56e52t3/REVIEW.md`.

## Reviewed identities and scope

- Baseline: `f29a4f88f80fdd59784c65842c0e7733df5f006c`.
- Accepted ADR-029: `387cf5c`; isolated Rolling fixture annotation correction: `ff539a2`.
- Final implementation/API/fixture/tests: `1216d58`; runner/Python updates: `24cd0d26f4ba612648cd79a3b72d6e114952ecea`.
- Final runner SHA-256: `8a044aebd86a97e097677bf6029abb12b870709a2c189647e774c81073d4f176`.
- Final Python test SHA-256: `9f7d2f5451fdab19f9bbe20bc71c085ed7c4410f27db6a9b6ab204b933bee639`.
- Independent checks retained 1,206 scoped source hashes and eight initial original/copied artifact locations. Every hash matched immediately before/after the focused Gradle rerun. Later root edits changed only `SatellitePayloadGameTests.java`, the new runner and its Python tests in that inventory; no production or focused-JUnit source changed. Those changes and final identities are explicitly recorded, not described as unchanged from the initial run.
- The final fixture differs from the initial fixture only in `SatellitePayloadGameTests.class` and its nested `ResearchView.class`, independently compared by ZIP entry bytes. Host/API/sources JARs stayed byte-identical.

## Independently executed tests

Environment: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, `PYTHONUTF8=1`; cwd `D:/GitHub/AdvancedRocketry-Community`.

```powershell
.\gradlew.bat test --tests '*SatellitePayloadRegistryTest' --tests '*SatelliteTerminalTargetsTest' --tests '*SatelliteCatalogDecoderTest' --tests '*SatelliteMissionSavedDataTest' --tests '*ApiArtifactTest' --tests '*ApiVersionsTest' --tests '*FuelLoaderPersistenceTest' --tests '*FuelLoaderStorageTest' --rerun-tasks --offline --no-daemon --no-build-cache
```

Exit **0**, **48.3854386 seconds**, 16 tasks actually executed; **56 tests / 8 suites**, zero failures/errors/skips. XML was copied immediately into `junit/`.

| Suite | Tests |
|---|---:|
| ApiArtifactTest | 16 |
| ApiVersionsTest | 9 |
| SatellitePayloadRegistryTest | 6 |
| SatelliteTerminalTargetsTest | 2 |
| SatelliteCatalogDecoderTest | 7 |
| SatelliteMissionSavedDataTest | 5 |
| FuelLoaderPersistenceTest | 4 |
| FuelLoaderStorageTest | 7 |

The fuel tests cover the shared BoundedNbt extraction alongside SAT tests; previous read-only comparison showed the extracted method/nested implementation is mechanically unchanged apart from its signature and diagnostic text.

```powershell
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v130_satellite_payload_smoke -v
```

Executed against the final corrected runner/tests. Exit **0**, **6 tests passed**, 0.012 seconds reported by unittest / 0.8621727 seconds process time. `python.txt`, `python-result.json`, `gradle.txt`, `gradle-result.json`, exact command files and XML remain here.

No independent clean build, GameTest server, client, native server, remote or load run was launched. Root's archived full XML was independently counted: **769 tests / 143 suites**, zero failures/errors/skips. Root's final log records **199 required GameTests passed**, `BUILD SUCCESSFUL in 2m 1s`; this is inspected root evidence, not an independently repeated run.

## Artifact and consumer audit

Final immutable artifacts at `C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436/final-artifacts/`:

| Artifact | SHA-256 |
|---|---|
| Main | `d1f9f564ed1dcd1df7ac0648b4091a07dfa9a02f63b36b827f36aad591224475` |
| API | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | `359a21d3c5bd7217ed39876d1fb88208438976e8baaa3acec4117c59e5bc2b8a` |
| Independent fixture | `e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47` |

Independent ZIP inspection confirmed:

- Exactly **27 exported API classes**, independently enumerated as 24 existing + three satellite types; every API class byte-identical to its main-JAR entry. No fixture package/resource leakage in main/API/sources; fixture classes stay in its own package and do not bundle host/API/platform classes; no duplicate ZIP entries.
- The archived standalone consumer requested the approved lowercase `io.github.sunthemoon.advancedrocketrycommunity:advancedrocketry-community:1.20.1-1.3.0-dev:api` coordinate. Raw publication hash matches the copied API. All **114 compile-classpath archives** were inspected: only the mapped API JAR contains host classes, and its host class set is exactly the 27 exports.
- Mapped API SHA-256 `b653a4fd8655ca05a71678fc5a3350e5407f7cb45fec49ac78b7494afee753e7`. Adjacent `.input` metadata retained; `orig=50091ee52c0a1b9efc8be2c7db2f8b6c302ee562` matches the raw API SHA-1; recorded mapping key `names=f5fa2554c58505bbb05836b9b987b46853742a0f` is preserved. This records the actual cached transform input, not a new remapping run by the reviewer.
- All **23 final consumer source hashes** match actual files. Negative javac exit 1 is specifically `compiler.err.doesnt.exist` for the real `rocket.forge` internal package; the referenced internal class actually exists in the inspected main JAR. This is not an arbitrary compilation failure. Focused ApiArtifactTest additionally exercised the satellite-specific positive and negative consumer.
- Final fixture receipt hash/entries and reobfuscated output match the actual copied fixture. Root consumer final build is inspected evidence; it was not independently rebuilt here.

`artifact-audit-initial.json` preserves the initial artifact epoch; `artifact-audit-final.json`, both consumer-report copies and `final-mapped-api.input` identify the final one.

## Runner and raw native evidence

Reviewed final `scripts/run_v130_satellite_payload_smoke.py` and its six pure tests, including inherited bounded process/input helpers. It operates only its validated disposable server/evidence directories, checks immutable input/installed JAR hashes, starts three finite owned server processes, captures failure/exit information and raw logs, and aborts an owned process on failure. Actual fixture uninstall removes its JAR and the exact run-authored definition JSON; reinstall restores the same fixture hash and override. No provider callback or new world mutation API is added to production.

Independent helper `audit_sat.py` reads **raw gzip NBT, Anvil sector contents, status payloads and all three log variants**, not merely `native-state.json` or the runner verdict. It reuses a structural NBT reader and Forge status decoder, not the runner's mission/disk validation functions. It wrote derived files only in this Temp directory.

Final evidence: `C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436/runtime-final/`.

- **48 manifest files** all rehashed; manifest exactly matches the evidence file set. SHA256SUMS SHA-256: `6ab4e4e3711b2090f275c2bce10896b8ca0c52c2aeb78aff494f2c5d85ad0e36`.
- Three phase results have exit 0 with actual ready/save/stop log evidence. Forge status decoding confirms fixture present / absent / present, host version correct, zero network players. Launch receipts bind the exact copied artifacts. **104 library files** independently match both source and destination hashes.
- Same raw world seed and increasing level times **48 → 462 → 523**. Raw satellite ID is `bbffb4d2-b917-4547-bc4e-c0c10151c06a`; owner `c6fcdf97-8f10-450e-ad36-67a644d23c2b`; definition `arce_adapter_test:research_payload`.
- First mission `22187e3f-12b4-3a43-8ec1-056ccced12cf`: starts 44, completes 444, frozen 400 ticks / yield137 / discovery cost11 / discovery-required1. Initial snapshot ACTIVE; absent-provider process completes/claims it, ready460/resolved461. Immutable mission fields remain exact through both later captures. Claim/replay logs show SUCCESS then ALREADY_CLAIMED while the actual fixture and satellite definition are absent.
- Reinstalled mission starts487/completes507, uses changed definition 20 ticks / yield211 / cost11 / discovery-required0; ready520/resolved521, CLAIMED. Both claimed missions remain, no active binding remains.
- Raw account progression: **balance 0 → 126 → 337; lifetime earned 0 → 137 → 348; spent 0 → 11 → 11**. Duplicate claims do not add credit.
- Raw terminal Anvil BE remains at (264,101,264), schema1, same owner, energy9000 and selected index0. Exactly one vanilla amethyst shard and one bound control chip remain; full resource-bearing terminal fields compare equal across captures, apart from expected final result ALREADY_CLAIMED. Package/input chassis/solar have been consumed. `/reload` acceptance is visible in the create raw logs before stop; active mission scalars stay unchanged.
- Exactly **two expected GameData ERROR messages** in the uninstall phase, in stdout/latest/debug: missing block mapping header for **cargo_container:1022 and state_boundary:1023**, then the native continuation warning at ERROR level. No other ERROR, FATAL, linkage or Can't-keep-up line was found. These expected diagnostics are retained, not summarized as zero errors. No performance/soak claim follows from the short run.

## Failures and corrections retained

- Root initial GameTest: 197 tests, two required failures. One observer recreated its ContainerListener for every read, losing unchanged delta values; corrected to one retained observer without relaxing exact reward/replay assertions. Rolling fixtures wrote beyond 1x1x1 template allocations; exactly 11 template names changed to 16x16x16 `rocket_test`, with all methods/assertions/timeouts unchanged. This fixes an independently confirmed isolation violation; source review alone does not identify the exact interfering neighbor.
- Root first native run: one clean server exit, then the oracle incorrectly expected already-discovered Earth in a fresh no-player world. Independently decoded original raw SavedData has discovery_required1, duration400, yield137, cost11. That failure is retained in `runtime-evidence/`; it is not relabeled successful. Final runner now requires exact first cost/net126 and final337; negative tests reject wrong discovery/cost/account values. The GameTest separately snapshots DataSlot8 before launch to compute the exact frozen cost, avoiding dependence on other batches' global discovery state.
- Local audit-helper attempts are preserved: the celestial-only reader's 4,096-tag default was unsuitable for full native terrain/level.dat; a retained helper revision uses a finite 65,536-tag bound with byte bounds. A supplemental library check initially applied the capture reader's 32 MiB cap to Mojang's 47,791,053-byte bundled server JAR; replaced that local hashing operation with bounded streaming SHA-256. Original outputs/helpers remain here. Neither changed production tests, evidence files or acceptance assertions. Final artifact and enhanced native audit commands exited 0.

## Evidence boundaries and remaining scope

- API-only assembly/launch/claim uses a fixture actor/FakePlayer, not a real connected client. While fixture is uninstalled, claiming uses the existing opt-in operator release-test hook, not an unavailable fixture command or a real player menu.
- The JAR is genuinely uninstalled, but the payload is **vanilla amethyst** and remains a registered item. This native run proves missing assembly-registration/definition behavior, not real deletion/restoration of an external payload Item ID. Unknown-item quarantine/drop/actual BlockItem placement is separately represented by GameTests with synthetic unknown NBT.
- Native first/second mission snapshots and clean restart/discovery/replay are verified; arbitrary crash cuts, cross-file power-loss atomicity, deep corrupt native serialization, all item callbacks and general mod-uninstall recovery are not.
- Root GameTest evidence covers actual item-boundary/replacement/native placement behavior, but this reviewer independently repeated only the 56 focused JUnit tests and six Python tests. No new GameTest server or standalone consumer build was launched by the reviewer.
- Actual `/reload` affects future mission values in the native run; generation-mismatched menu rejection is a GameTest/source check, not a real-client stale-menu visual test.
- No full original-feature/long-load/remote/multiplayer/GPU or complete G0-G9 approval. The excluded untracked development-document bundle was not read or changed. No tracked edits, git mutation, remote work, OpenPet, server management or additional agents were performed by this reviewer.

## Local evidence files

`before.json`, `after-gradle.json`, `final-identity.json`, `source.patch`, `final-changed-source/`, `junit/`, `junit-summary.json`, command/result/raw logs, initial/final artifact audit JSON, initial/final consumer reports, `failed-create-native-independent.json`, `audit_sat.py`, preserved helper failure attempts, `native-audit.json` and `native-audit-final.txt`.

Important hashes:

- `gradle.txt`: `ee1dbbb8c7c12effb8f46edb4c513f0ab1a674b242cc6f0dfd7b6fb8a99c878b`.
- `python.txt`: `0b575e7a1188cf2f1c9c8d26e9c93dfb64c1ad5f443391dec8adf402e5913704`.

The current slice can use these scoped independent results; full version/Gate status remains for the repository's separate acceptance process.
