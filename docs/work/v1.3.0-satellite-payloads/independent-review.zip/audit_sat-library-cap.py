"""Read-only SAT evidence audit. All derived output stays beside this helper."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import shutil
import struct
import sys
import uuid
import zipfile
import zlib

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436')
OUT = Path(__file__).resolve().parent
HOST = 'advancedrocketrycommunity'
PREFIX = 'io/github/sunthemoon/' + HOST + '/'
sys.path.insert(0, str(ROOT))
from scripts import inspect_celestial_saved_data as nbt
from scripts import run_dedicated_server_smoke as protocol
# Native terrain and level.dat contain more tags than the celestial-only reader's
# 4,096 default. Retain a finite 65,536-tag bound plus decompressed-byte limits.
nbt.MAX_TAGS = 65536


def read(p, limit=32 * 1024**2):
    p = Path(p)
    if len(str(p)) >= 260 and p.drive:
        p = Path('\\\\?\\' + str(p))
    assert p.is_file() and not p.is_symlink() and p.stat().st_size <= limit, str(p)
    return p.read_bytes()


def sha(p):
    return hashlib.sha256(read(p)).hexdigest()


def js(p):
    return json.loads(read(p).decode('utf-8-sig'))


def uid(parts):
    assert len(parts) == 4
    return str(uuid.UUID(bytes=b''.join(struct.pack('>I', x & 0xffffffff) for x in parts)))


def unpack(path):
    with gzip.GzipFile(fileobj=io.BytesIO(read(path))) as f:
        raw = f.read(4 * 1024**2 + 1)
    assert len(raw) <= 4 * 1024**2
    return nbt.NbtReader(raw).read_root()


def chunk(path, x, z):
    region = read(path)
    index = ((x & 31) + (z & 31) * 32) * 4
    entry = int.from_bytes(region[index:index + 4], 'big')
    offset, sectors = (entry >> 8) * 4096, entry & 255
    assert offset >= 8192 and sectors > 0 and offset + sectors * 4096 <= len(region)
    length = int.from_bytes(region[offset:offset + 4], 'big')
    assert 1 < length <= sectors * 4096 - 4 and region[offset + 4] == 2
    inflater = zlib.decompressobj()
    raw = inflater.decompress(region[offset + 5:offset + 4 + length], 8 * 1024**2)
    assert inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail
    result = nbt.NbtReader(raw).read_root()
    assert result['xPos'] == x and result['zPos'] == z
    return result


def artifacts():
    classes = {
        'version': ['ApiVersion', 'ApiVersions', 'ApiCompatibility'],
        'rocket': ['RocketBlockEntityAdapter', 'RocketAdapterRegistrar', 'RegisterRocketAdaptersEvent',
                   'RocketComponentDefinition', 'RocketComponentRegistrar', 'RegisterRocketComponentsEvent',
                   'RocketFuelDefinition', 'RocketFuelRegistrar', 'RegisterRocketFuelsEvent'],
        'atmosphere': ['AtmosphereBoundary', 'AtmosphereBoundaryProvider', 'AtmosphereBoundaryRegistrar',
                       'RegisterAtmosphereBoundariesEvent', 'SuitOxygenProvider', 'SuitEquipmentRegistrar',
                       'RegisterSuitEquipmentEvent'],
        'environment': ['AtmosphereProfile', 'EnvironmentQueries', 'EnvironmentSnapshot',
                        'EnvironmentSnapshot$Locus', 'ServerEnvironmentReadyEvent'],
        'satellite': ['SatelliteMissionDefinition', 'SatellitePayloadRegistrar', 'RegisterSatellitePayloadsEvent'],
    }
    expected = {PREFIX + 'api/' + package + '/' + name + '.class' for package, names in classes.items() for name in names}
    assert len(expected) == 27
    directory = BASE / 'final-artifacts'
    hashes = {p.name: sha(p) for p in directory.glob('*.jar')}
    assert len(hashes) == 4
    api = directory / 'advancedrocketry-community-1.20.1-1.3.0-dev-api.jar'
    host = directory / 'advancedrocketry-community-1.20.1-1.3.0-dev.jar'
    fixture = directory / 'arce-adapter-compat-test-1.0.0.jar'
    with zipfile.ZipFile(api) as a, zipfile.ZipFile(host) as h:
        assert {n for n in a.namelist() if n.endswith('.class')} == expected
        assert {n for n in h.namelist() if n.startswith(PREFIX + 'api/') and n.endswith('.class')} == expected
        assert all(a.read(n) == h.read(n) for n in expected)
    for p in directory.glob('*.jar'):
        with zipfile.ZipFile(p) as jar:
            names = jar.namelist()
            assert len(names) == len(set(names))
            if p == fixture:
                assert all(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in names if n.endswith('.class'))
                assert 'io/github/sunthemoon/arceadaptertest/SatellitePayloadFixture.class' in names
            else:
                assert not any('arceadaptertest' in n or 'arce_adapter_test' in n for n in names)

    reports = BASE / 'consumer-final-reports' / 'consumer'
    if not reports.is_dir():
        reports = BASE / 'consumer-final-reports'
    copied = OUT / 'consumer-reports-final'
    if not copied.exists():
        shutil.copytree(reports, copied)
    cp, negative, receipt = [js(reports / n) for n in ('classpath.json', 'negative-import.json', 'fixture-artifact.json')]
    assert cp['requested_api'] == 'io.github.sunthemoon.advancedrocketrycommunity:advancedrocketry-community:1.20.1-1.3.0-dev:api'
    assert sha(cp['published_file']) == cp['published_sha256'] == sha(api) == sha(cp['raw_api'])
    assert sha(cp['remapped_api']) == cp['remapped_sha256']
    for value in cp['compile_classpath']:
        p = Path(value['file'] if isinstance(value, dict) else value)
        with zipfile.ZipFile(p) as jar:
            owned = {n for n in jar.namelist() if n.startswith(PREFIX) and n.endswith('.class')}
        assert owned == (expected if str(p) == cp['remapped_api'] else set()), str(p)
    assert all(sha(value['file']) == value['sha256'] for value in cp['fixture_sources'])
    assert negative['exit_code'] == 1 and negative['inspected_host_sha256'] == sha(host)
    assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in negative['diagnostics']
    with zipfile.ZipFile(host) as jar:
        assert negative['existing_internal_type'] in jar.namelist()
    assert receipt['reobfuscated'] is True and receipt['sha256'] == sha(fixture)
    cache = read(cp['remapped_api'] + '.input')
    (OUT / 'final-mapped-api.input').write_bytes(cache)
    fields = dict(line.split('=', 1) for line in cache.decode('ascii').splitlines())
    assert fields['orig'] == hashlib.sha1(read(api)).hexdigest()
    result = {'hashes': hashes, 'exports': sorted(expected), 'byte_identical_api_classes': len(expected),
              'classpath_jars': len(cp['compile_classpath']), 'fixture_sources': len(cp['fixture_sources']),
              'mapping_cache': fields, 'mapped_sha256': sha(cp['remapped_api']), 'negative_exit': negative['exit_code']}
    (OUT / 'artifact-audit-final.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


def native():
    evidence = BASE / 'runtime-final'
    manifest = {}
    for line in read(evidence / 'SHA256SUMS').decode('ascii').splitlines():
        digest, name = line.split('  ', 1)
        path = (evidence / name).resolve()
        assert evidence.resolve() in path.parents and name not in manifest
        assert sha(path) == digest, name
        manifest[name] = digest
    assert set(manifest) == {p.relative_to(evidence).as_posix() for p in evidence.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    owner = 'c6fcdf97-8f10-450e-ad36-67a644d23c2b'
    definition = 'arce_adapter_test:research_payload'
    phases = ('create', 'mod-uninstalled', 'reinstalled')
    observations = []
    satellite_id = None
    first_id = None
    first_frozen = None
    previous_time = -1
    seed = None
    terminal_before = None
    config_identity = None
    artifact_hashes = {p.name: sha(p) for p in (BASE / 'final-artifacts').glob('*.jar')}
    for phase in phases:
        d = evidence / phase
        result = js(d / 'result.json')
        assert result['exit_code'] == 0 and result['result'] == 'PASS'
        launch = js(d / 'launch.json')
        expected_mods = {n: h for n, h in artifact_hashes.items() if n.endswith('-dev.jar') or phase != 'mod-uninstalled' and n.startswith('arce-adapter-')}
        assert launch['mods'] == expected_mods
        assert '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
        status = js(d / 'status.json')
        mods = protocol.forge_mod_versions(status)
        assert mods[HOST] == '1.20.1-1.3.0-dev'
        assert ('arce_adapter_test' in mods) == (phase != 'mod-uninstalled')
        assert status['players']['online'] == 0
        logs = {}
        for name in ('stdout.txt', 'latest.log', 'debug.log'):
            text = read(d / name).decode('utf-8', errors='strict')
            assert 'Done (' in text and 'Stopping server' in text and 'Saving worlds' in text
            assert not any(value in text for value in ('NoClassDefFoundError', 'NoSuchMethodError', 'UnsupportedClassVersionError', '/FATAL]'))
            regs = [line for line in text.splitlines() if 'Registered satellite payload ' in line]
            assert len(regs) == (0 if phase == 'mod-uninstalled' else 1)
            if regs:
                assert regs[0].endswith('Registered satellite payload arce_adapter_test:research_payload (API 1.7, event 1)')
            if phase == 'create':
                assert 'Accepted satellite catalog generation 2 with 2 definitions' in text
            if phase == 'mod-uninstalled':
                assert 'code=SUCCESS status=CLAIMED research=126 discovered=true' in text
                assert 'code=ALREADY_CLAIMED status=CLAIMED research=126 discovered=true' in text
            logs[name] = {'errors': [line for line in text.splitlines() if '/ERROR]' in line or ' ERROR ' in line],
                          'warnings': [line for line in text.splitlines() if '/WARN]' in line or ' WARN ' in line]}
            errors = logs[name]['errors']
            if phase == 'mod-uninstalled':
                assert len(errors) == 2
                assert errors[0].endswith('Unidentified mapping from registry minecraft:block')
                assert errors[1].endswith('There are unidentified mappings in this world - we are going to attempt to process anyway')
                lines = text.splitlines()
                start = lines.index(errors[0])
                assert re.fullmatch(r'\tarce_adapter_test:cargo_container: \d+', lines[start + 1])
                assert re.fullmatch(r'\tarce_adapter_test:state_boundary: \d+', lines[start + 2])
                assert lines[start + 3] == ''
            else:
                assert not errors
            assert not any("Can't keep up" in line for line in text.splitlines())
        level = unpack(d / 'world/level.dat')['Data']
        assert level['Time'] > previous_time
        previous_time = level['Time']
        actual_seed = level['WorldGenSettings']['seed']
        if seed is None:
            seed = actual_seed
        assert seed == actual_seed
        data = unpack(d / f'world/data/{HOST}_satellite_missions.dat')['data']
        assert data['schema_version'] == 2
        assert len(data['satellites']) == len(data['research_accounts']) == 1
        sat = data['satellites'][0]
        assert uid(sat['owner_id']) == owner and sat['definition_id'] == definition and sat['status'] == 'operational'
        if satellite_id is None:
            satellite_id = uid(sat['satellite_id'])
        assert uid(sat['satellite_id']) == satellite_id
        missions = {uid(m['mission_id']): m for m in data['missions']}
        assert len(missions) == len(data['missions']) == (2 if phase == 'reinstalled' else 1)
        if first_id is None:
            first_id = next(iter(missions))
        first = missions[first_id]
        frozen = {k: v for k, v in first.items() if k not in ('status', 'ready_at', 'resolved_at')}
        if first_frozen is None:
            first_frozen = frozen
        assert first_frozen == frozen
        for mid, m in missions.items():
            original = mid == first_id
            assert uid(m['satellite_id']) == satellite_id and uid(m['owner_id']) == owner
            assert m['definition_id'] == definition and m['target_body_id'] == HOST + ':earth'
            assert m['completes_at'] - m['started_at'] == (400 if original else 20)
            assert m['research_yield'] == (137 if original else 211) and m['discovery_cost'] == 11
            assert m['discovery_required'] == (1 if original else 0)
            assert m['status'] == ('active' if phase == 'create' else 'claimed')
        if phase == 'create':
            assert uid(sat['current_mission_id']) == first_id
        else:
            assert 'current_mission_id' not in sat
        account = data['research_accounts'][0]
        expected = {'create': (0, 0, 0), 'mod-uninstalled': (126, 137, 11), 'reinstalled': (337, 348, 11)}[phase]
        assert uid(account['owner_id']) == owner
        assert tuple(account[k] for k in ('balance', 'lifetime_earned', 'lifetime_spent')) == expected
        terrain = chunk(d / 'world/region/r.0.0.mca', 16, 16)
        found = [be for be in terrain['block_entities'] if (be.get('x'), be.get('y'), be.get('z')) == (264, 101, 264)]
        assert len(found) == 1 and found[0]['id'] == HOST + ':satellite_terminal'
        terminal = found[0]['SatelliteTerminal']
        assert terminal['schema_version'] == 1 and uid(terminal['owner_id']) == owner
        assert terminal['energy'] == 9000 and terminal['selected_target'] == 0 and terminal['last_result'] == (9 if phase == 'reinstalled' else 0)
        inventory = terminal['inventory']
        assert inventory['Size'] == 6 and len(inventory['Items']) == 2
        slots = {i['Slot']: i for i in inventory['Items']}
        assert set(slots) == {2, 3}
        assert slots[2] == {'Slot': 2, 'id': 'minecraft:amethyst_shard', 'Count': 1}
        chip = slots[3]
        assert chip['id'] == HOST + ':satellite_control_chip' and chip['Count'] == 1
        identity = chip['tag']['SatelliteIdentity']
        assert identity['schema_version'] == 1 and uid(identity['owner_id']) == owner
        assert identity['definition_id'] == definition and uid(identity['satellite_id']) == satellite_id
        terminal_resources = {k: v for k, v in terminal.items() if k != 'last_result'}
        if terminal_before is None:
            terminal_before = terminal_resources
        assert terminal_resources == terminal_before
        configs = {}
        for relative in ('server.properties', 'config/fml.toml', 'config/advancedrocketrycommunity-common.toml'):
            raw = read(d / relative)
            if relative == 'server.properties':
                lines = raw.splitlines(keepends=True)
                assert lines[0] == b'#Minecraft server properties\r\n' or lines[0] == b'#Minecraft server properties\n'
                assert re.fullmatch(rb'#[A-Z][a-z]{2} [A-Z][a-z]{2} \d{2} \d{2}:\d{2}:\d{2} [^\r\n]+ \d{4}\r?\n', lines[1])
                raw = b''.join(lines[:1] + lines[2:])
                assert b'server-ip=127.0.0.1' in raw
            configs[relative] = hashlib.sha256(raw).hexdigest()
        if config_identity is None:
            config_identity = configs
        assert config_identity == configs
        observations.append({'phase': phase, 'logical_time': data['clock'], 'level_time': level['Time'],
                             'satellite': sat, 'missions': data['missions'], 'account': account,
                             'terminal': terminal, 'mods': mods, 'logs': logs, 'commands': js(d / 'commands.json')})
    libraries = js(BASE / 'final-library-copy-identity.json')
    assert len(libraries['sha256']) == 104
    for relative, digest in libraries['sha256'].items():
        assert sha(Path(libraries['source']) / relative) == digest
        assert sha(Path(libraries['destination']) / relative) == digest
    result = {'manifest_count': len(manifest), 'manifest_sha256': sha(evidence / 'SHA256SUMS'),
              'seed': seed, 'satellite_id': satellite_id, 'first_mission_id': first_id,
              'library_files_verified': len(libraries['sha256']), 'phases': observations}
    (OUT / 'native-audit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


if __name__ == '__main__':
    operation = sys.argv[1]
    result = artifacts() if operation == 'artifacts' else native()
    print(json.dumps(result, indent=2))
