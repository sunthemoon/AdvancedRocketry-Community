# V130-SAT independent contract review

## Findings, ordered by severity

### P2 - Quarantine and payload eligibility need a concrete bounded native-data policy

ADR-029:20-22,62,87-93 excludes capability-bearing/tagged payloads and promises bounded terminal quarantine, but does not yet define the terminal's byte/depth/node limits, exact inventory shape before native decoding, malformed non-compound preservation or over-budget disposition.

This is an implementation-relevant gap, not merely terminology. At baseline, `SatelliteTerminalBlockEntity.java:498-528` uses a serialized-byte-size check and then calls `ItemStackHandler.deserializeNBT` directly. Pinned Forge 47.4.10 `ItemStackHandler.java:186-198` trusts the serialized `Size` when allocating its list, then decodes entries with native `ItemStack.of`. A small root with a huge `Size` therefore evades a byte-only operation budget. Duplicate/out-of-range slots and unknown IDs can also be normalized/dropped before the terminal's post-decode loop. `SatelliteNbtSize.java:13-19` itself serializes the entire root before returning its size.

The existing slot predicate is only `!stack.hasTag()` (`SatelliteTerminalBlockEntity.java:567-577`), which is not a definition of absent serialized Forge capability data. A provider can have data outside the ordinary `tag` compound; its payload must not accidentally qualify for an explicitly capability-free assembly.

**Minimal recommendation:** freeze the existing six-slot shape and bounded root/metadata validation before any native inventory allocation: exact Size=6, no duplicate/out-of-range slots, bounded list/counts and known item IDs. Define the operational payload as a bounded lossless native round-trip with no serialized ordinary tag or capability state; distinguish assembly eligibility from extraction of an already saved unregistered item. Reuse the already accepted ADR-027:93-108 distinctions rather than inventing escrow: bounded arbitrary raw Tag preservation; oversized/deep raw-reference passthrough without copying or normalization; ordinary pre-removal refusal when it cannot safely become an inventory item; no promise that vanilla durably serializes arbitrary preexisting corrupt data. Preserve blocked inventory authority and reject mutation. These checks do not require a root schema bump or new framework.

Status at captured ADR hash: **not yet specified**. Root was notified; concurrent implementation was not reviewed.

### P2 - Survival removal wording exceeds native item-drop guarantees

ADR-029:89-93 promises preservation across normal survival break/replacement while excluding only creative/operator destruction. The terminal requires the correct tool (`registry/ModBlocks.java:85-92`), so an ordinary wrong-tool survival break may not produce a terminal item. Its native loot is `dropSelf` (`datagen/SatelliteLootTableProvider.java:35-37`), while `SatelliteTerminalBlock.java:90-97` separately emits inventory from `onRemove`. A blocked terminal has reset live slots and retains its authority only in the raw root, so the existing loose-item path cannot preserve that authority.

**Minimal recommendation:** either restrict the portable recovery promise to native operations that actually produce the terminal item, explicitly excluding wrong-tool/no-drop/explosion destruction, or refuse such removal while quarantined. When carrying a quarantined root, suppress the separate inventory emission to avoid duplicate ownership. Placement must replace the exact carried root, not merge it with defaults: existing `rocket/fuel/FuelLoaderBlock.java:43-50` already documents and handles native BlockItem recursive merge. Preserve the carried owner rather than replacing it with the placer. This is the ADR-027:110-122 policy applied to the terminal, not a requirement for a new drop framework.

Status at captured ADR hash: **not yet specified**. Root was notified.

### P3 - Freeze the remaining public signature and failure details

ADR-029:31-35 names the registrar/event register parameters but omits the return type, interface form and event constructor visibility/finality; lines 42-45 say calls fail without specifying registration exception classes. The record's NPE/IAE rule is explicit, but it does not unambiguously bind registration failures. ADR-021:58-72 makes published signatures and behavior compatibility promises.

**Minimal recommendation:** specify a public functional interface with `void register(...)`, a final non-cancelable event with public non-null registrar constructor and forwarding `void register(...)`; define null=NPE, invalid/duplicate/namespace/capacity=IAE and retained/reentrant/off-thread=ISE, matching ADR-027:29-35. No additional accessor or registration result API is needed.

Status at captured ADR hash: **not yet specified**.

### Resolved during review: P2 - Menu bounds initially exceeded Forge's packet limit

Original ADR-029:64 allowed 16 definitions each containing 16 full target IDs, up to 128 characters per ID, without a total wire bound. Just the target strings can occupy `16 * 16 * (128 + 2) = 33,280` bytes, before definition IDs/position/framing. The existing path is `NetworkHooks.openScreen` (`SatelliteTerminalBlock.java:79`); pinned Forge `NetworkHooks.java:186,202-207` rejects the length-prefixed buffer above 32,600 bytes.

Root changed actual ADR-029:64-69 to a shared target table (at most 128 IDs), indexed target lists, bounded UTF and a complete framed 32,600-byte budget plus maximum-boundary test. This addresses the contract finding without lowering the advertised definition/target maxima. A conservative indexed layout estimate is 19,011 bytes including a five-byte marker and outer length prefix; exact implementation framing still requires the planned test. `menu-budget-analysis.json` retains the arithmetic. **Resolved in contract; no implementation test executed.**

## Source-supported compatibility and scope

Java references above/below are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`; baseline source is `f29a4f88f80fdd59784c65842c0e7733df5f006c`.

- The declarative record's durations, yields/costs, target counts and catalog count match existing `satellite/model/SatelliteLimits.java:11-16` and `SatelliteDefinition.java:53-77`. The new constructor must also enforce the 128-character IDs when converting directly into internal values; the old JSON codec enforces them but the internal record constructor does not.
- Existing `SatelliteCatalog.java:26-58` validates complete bounded definitions, targets and required built-in definition. Merging registered defaults by stable definition ID before whole-catalog validation is feasible. A datapack override should replace one default by ID, not count twice. Unbound datapack entries still count toward the combined 16-entry cap. Removing an override while registration remains should restore its default; genuinely removing registration and absent definition is a separate missing-extension scenario.
- `SatelliteManager.java:88-159` already launches/starts using `identity.definitionId()`. The built-in coupling is primarily terminal assembly and target selection (`SatelliteTerminalBlockEntity.java:178-204,337-348`) and shift-click routing (`SatelliteTerminalMenu.java:177-193`). The proposed injection therefore need not alter mission scheduling or reward schemas.
- `MissionState.java:10-24,51-80` persists the chosen target, deadline, yield/cost and definition identity. `SatelliteMissionRegistry.java:265-320` claims from those scalars, not the live catalog. Missing satellite definitions can therefore leave existing completion/claim valid. **Boundary:** missing celestial target or unavailable celestial SavedData still leaves discovery pending (`SatelliteManager.java:432-450`), and capacity failures remain possible. Do not generalize removal of a satellite definition into guaranteed completion after removing its celestial-body provider as well.
- The existing menu stores one fixed target list at opening (`SatelliteTerminalMenu.java:43,89,221-227`), while server target selection reads a live list. The generation-close/reopen decision is appropriate for accepted catalog changes. Choose a marker outside the old valid count range 0..16, at the old count position after BlockPos; test both old/new rejection rather than relying on a marker name alone. A definition/target selection change must not reinterpret an old target index as user consent to launch somewhere else.
- A registered-but-missing assembly definition must not authorize a new launch/start. Conversely, a known unregistered queued payload must remain extractable rather than quarantining the entire healthy terminal merely because its assembly mapping disappeared. The contract already states this distinction; native implementation tests are still needed.
- API 1.7 plus three explicit types is consistent with ADR-021 and preserves 24 existing exports. An eventual exact 27-class classifier and isolated consumer check are appropriate. No provider callback framework, new world service, satellite entity, packet-authoritative definition or additional persistence schema is necessary for this slice.
- v1.3 explicitly calls for a satellite component/mission extension point. The active SAT leaf remains in progress and leaves compatibility/full G0-G9 acceptance open. The stated client/multiplayer deferral is not visual approval: actual GUI changes still require the version's eventual V1/V2 evidence.

## Minimal verification implications

These are recommendations, not executed tests:

1. Registration bounds/ownership/thread/expired/reentrant and atomic failure; copied target list; default/override merge, combined count and unknown targets.
2. Built-in behavior plus two different payload definitions through actual assembly, package/chip identity, target selection, exact one-item/energy consumption and launch/claim. Test automation and shift-click against the same matcher; no mutation on metadata/unsupported input rejection.
3. Maximum encoded menu payload, malformed counts/indices/IDs, legacy format rejection, chip/payload switch and accepted-reload stale-menu refusal.
4. Native persistence: known unregistered extraction, unknown item root retention, exact malformed/future root round-trip, tiny invalid Size, duplicates/count bounds, native normalization refusal and bounded/over-budget removal policy. Test real BlockItem drop/place rather than only calling `load` with a hand-built parent.
5. Active mission restart followed by missing satellite-definition claim/replay; separate changed-definition future mission from saved mission values. Distinguish absent registration, absent definition, unknown item registry ID and missing celestial target.

## Evidence and commands actually run

- Read ADR-029, SAT implementation-log section, applicable AGENTS/docs14/v1.3/quality rules, ADR-010/021/027, relevant catalog/reload/manager/mission/persistence/terminal/menu/item and registration/loot source. Inspected adjacent existing tests without executing them.
- Read-only `git rev-parse HEAD`, `git status --short`, `git diff --check`, `rg`, numbered PowerShell `Get-Content`, `Select-String`, and local pinned Forge source-JAR inspection using Python `-B`/zipfile. Final whitespace check exited 0.
- One speculative old ADR-010 filename was absent and then corrected to `ADR-010-BOUNDED-SATELLITE-MISSIONS.md`; one generated-loot search used an absent generic directory and was corrected to the versioned `src/generated/v0.8/resources/...` location. Neither altered files.
- Python `-B` created only this unique OS Temp report folder, document/hash capture and menu-size arithmetic. `identity.json` identifies the captured files; `ADR-029-reviewed.md` is the reviewed contract copy.
- No Gradle, Java, server, test suite, remote/network, source mutation, git mutation, OpenPet or subagent operation occurred. Root began implementation during this review; it was not examined or treated as tested here. The excluded untracked development-document bundle was not read or changed.

## Limit / next action

This is a contract feasibility and boundary review only. Resolve the remaining concrete contract points above, then review the actual implementation and execute authorized finite tests separately. No release or Required Gate decision is made by this report.
