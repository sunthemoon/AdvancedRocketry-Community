# V130-SAT independent contract review — resolution

## Findings and disposition

No unresolved material contract feasibility finding remains in the revised ADR-029 inspected for this report. This is not a finding that implementation or tests pass. Three minor wording recommendations are retained below; the substantive findings and original evidence remain in `REVIEW-initial.md` rather than being erased.

### P3 — Remaining public-signature and callback wording

- `docs/decisions/ADR-029-SATELLITE-PAYLOAD-MISSIONS.md:33-35` now freezes a public final event and public forwarding method but should also explicitly call the non-null registrar constructor **public**. This avoids leaving one exported signature implicit under ADR-021.
- ADR-029:44-52 says no external code runs during assembly, then correctly acknowledges native ItemStack capability callbacks. Prefer "No registered mission/reward callbacks run" for the former sentence; the latter acknowledgement is appropriate and must remain. This is a wording ambiguity, not a request to sandbox native Forge item code.
- ADR-029:106-110 now makes oversized raw-reference passthrough and refusal of ordinary survival removal explicit. Add ADR-027's existing qualification that passthrough does not guarantee native serialization of arbitrary preexisting corrupt data; the cross-file power-loss disclaimer is not quite the same platform boundary. No new escrow or sidecar is required.

These were sent to the root writer. They do not invalidate the bounded declarative design.

### Resolved P2 — Menu aggregate wire budget

ADR-029:70-75 now requires a shared table of at most 128 distinct target IDs, up to 16 indexed target lists of at most 16 entries, 128-character UTF bounds and a 32,600-byte complete framed limit plus maximum-boundary test. This resolves the original flattened-layout issue: target strings alone could have required 33,280 bytes before framing. Pinned Forge 47.4.10 `NetworkHooks.java:186,202-207` confirms the actual 32,600-byte limit. `menu-budget-analysis.json` retains the arithmetic; no actual encoding test was run here.

### Resolved P2 — Native inventory quarantine and eligibility

ADR-029:50-52,93-108 now defines lossless native ItemStack round-trip eligibility without serialized tag/ForgeCaps state; extractability of still-existing unregistered input; detection of unknown IDs before native decoding; exact six-slot shape, unique in-range integer slots, bounded native counts; terminal 64 KiB/depth 20/2,048 nodes and item 4 KiB/depth 16/256 nodes; bounded arbitrary raw-Tag preservation; and oversized/deep reference passthrough plus pre-removal refusal.

These address the initial concrete allocation/normalization concern. Baseline `satellite/terminal/SatelliteTerminalBlockEntity.java:498-528` performed byte sizing then native inventory deserialization; pinned Forge `ItemStackHandler.java:186-198` trusts serialized `Size` for allocation before reading entries. Therefore an operation budget must precede native decoding, and the revised contract requires that. The native serialization qualification above remains useful wording, not an additional runtime framework requirement.

### Resolved P2 — Native drop/place resource authority

ADR-029:96-100 now limits portable recovery to removals actually yielding the terminal item, carries the bounded raw root once, suppresses separate inventory emission, restores the exact root instead of BlockItem merge, and excludes wrong-tool/no-drop/explosion/creative/operator destruction. This matches the platform issue: `registry/ModBlocks.java:85-92` requires the correct tool; `satellite/terminal/SatelliteTerminalBlock.java:90-97` previously emitted live slots separately; the blocked root is independent authority. Existing `rocket/fuel/FuelLoaderBlock.java:43-50` is a local precedent for exact replacement after native merge.

### Resolved P3 — Registration failure contract

ADR-029:31-35,47-49 now specifies a public registrar interface, void registration/forwarding, final non-cancelable event and NPE/IAE/ISE categories including lifecycle/thread validation before lookup/mutation. Only the explicit constructor-visibility word remains as noted above.

## Source-supported boundaries

Java paths in this section are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`; baseline is `f29a4f88f80fdd59784c65842c0e7733df5f006c`.

- Existing `satellite/model/SatelliteLimits.java:11-16` and `SatelliteDefinition.java:53-77` support the proposed bounded scalar/list model. Direct API construction must enforce ID length as well as the existing JSON codec. No callback framework is needed.
- `satellite/service/SatelliteCatalog.java:26-58` validates the complete catalog. Merge registered defaults and datapack replacements by stable definition ID before validating the combined 16-entry cap; removing an override while registration remains restores the default and is not a missing-provider scenario.
- Existing `satellite/service/SatelliteManager.java:88-159` launches/starts by identity definition ID; fixed built-in coupling is primarily terminal assembly, target selection and menu shift-click. The existing mission scheduler and reward schema need not change.
- `satellite/mission/MissionState.java:10-24,51-80` and `satellite/mission/SatelliteMissionRegistry.java:265-320` retain the chosen target and reward/cost/deadline scalars, allowing claims without a live satellite definition. Missing celestial targets or unavailable celestial SavedData can still leave discovery pending (`SatelliteManager.java:432-450`); no guaranteed completion after removing a celestial provider is inferred.
- Generation-bound menu reopen is appropriate because old menu target snapshots and live terminal targets could diverge after reload. The legacy rejection marker must occupy the old count position and be outside 0..16; actual malformed/max/reload tests are still required.
- API 1.7 with three additional public types is consistent with ADR-021's additive-minor rule; eventual packaging should have exactly 27 API classes and a classifier-only consumer. These outputs were not inspected for this contract review.
- Implementation log:63-68,123-147 remains in-progress/planned, with no SAT verification or full G0-G9 claim. GUI/client/multiplayer deferral is not V1/V2 approval.

The detailed initial source inventory and finite verification recommendations are retained in `REVIEW-initial.md`. Nothing in this resolution expands scope to a full runtime audit, load test, remote server or release Gate.

## Checks actually executed

- Read the contract and active leaf, required governance/version/quality and parallel rules, ADR-010/021/027, relevant existing satellite model/catalog/reload/manager/mission/identity/terminal/menu/loot source, and adjacent tests.
- Read-only git identity/status/whitespace checks, rg, numbered PowerShell source reads, local pinned Forge source-JAR inspection using Python -B/zipfile, and finite menu-size arithmetic. Latest `git diff --check` exited 0.
- Temp-only document/report/identity captures. `identity.json` and `ADR-029-reviewed.md` preserve the first archived capture; `resolution-identity.json` and `ADR-029-resolution.md` identify this resolution. Those archived ADR copies have the same hash: root had already applied the substantive corrections before the first archive was created. `REVIEW-initial.md` preserves the initial working findings, whose unresolved-status wording lagged that actual archived contract; this report corrects those statuses rather than treating the working report as evidence of the archive content. No pre-correction ADR byte snapshot was retained.
- No Gradle, Java, unit tests, GameTest, packaged servers, network/remote, git mutation, tracked edits, OpenPet or subagent execution. Root-reported baseline test results are not independent evidence from this review. Concurrent implementation is outside this review.
- The excluded untracked development-document bundle was neither read nor changed.

## Remaining verification

Review the actual implementation separately, then execute authorized finite registration/catalog/menu/native-preservation and API-consumer checks. Missing satellite definition, missing item registration/registry identity and missing celestial target are different cases and must not be conflated. No full version acceptance or Required Gate approval is given.
