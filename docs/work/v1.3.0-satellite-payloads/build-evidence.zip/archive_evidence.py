from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(r"D:/GitHub/AdvancedRocketry-Community")
TEMP = Path(__file__).parent
OUT = ROOT / "docs/work/v1.3.0-satellite-payloads"


def archive(name, entries):
    with zipfile.ZipFile(OUT / name, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for source, relative in sorted(entries, key=lambda value: value[1]):
            target.writestr(relative, source.read_bytes())


def tree(root, prefix=""):
    return [(p, prefix + p.relative_to(root).as_posix()) for p in root.rglob("*") if p.is_file()]


OUT.mkdir(exist_ok=True)
archive("junit-full.zip", tree(TEMP / "full-junit"))
archive("native-runtime.zip", tree(TEMP / "runtime-final"))
archive("native-initial.zip", tree(TEMP / "runtime-evidence"))
archive("review-history.zip",
        tree(Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-contract-review-vboz6qkj"), "contract/")
        + tree(Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-source-review-x56e52t3"), "source/"))
archive("independent-review.zip", tree(Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-independent-iae58_k1")))
archive("build-evidence.zip", [(p, p.name) for p in TEMP.iterdir() if p.is_file() and p.suffix in (".log", ".json", ".py")]
        + tree(TEMP / "consumer-reports", "consumer-initial/")
        + tree(TEMP / "consumer-final-reports", "consumer-final/"))
for source, name in ((TEMP / "junit-summary.json", "junit-summary.json"),
                     (TEMP / "final-artifact-identities.json", "artifact-identities.json"),
                     (TEMP / "runtime-final/summary.json", "runtime-summary.json")):
    # Canonicalize only derived outer JSON; archived captured bytes stay untouched.
    (OUT / name).write_bytes(source.read_bytes().replace(b"\r\n", b"\n"))
print(json.dumps({p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                  for p in sorted(OUT.iterdir()) if p.is_file()}, indent=2))
