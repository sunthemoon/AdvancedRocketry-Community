from pathlib import Path
from urllib.parse import unquote
import re
import subprocess

root = Path(r"D:/GitHub/AdvancedRocketry-Community")
paths = set(subprocess.check_output(["git", "ls-files", "--", "*.md"], cwd=root).decode().splitlines())
paths.add("docs/work/v1.3.0-satellite-payloads/VERIFICATION.md")
checked, failures = 0, []
for name in sorted(paths):
    path = root / name
    value = re.sub(r"```.*?```", "", path.read_text(encoding="utf-8"), flags=re.S)
    for match in re.finditer(r"\[[^\]\n]*\]\(([^)\n]+)\)", value):
        link = match.group(1).strip().split(" \"")[0].strip("<>")
        if re.match(r"[a-zA-Z][a-zA-Z0-9+.-]*:", link) or link.startswith(("#", "//")):
            continue
        file_part = unquote(link.split("#", 1)[0])
        if not file_part:
            continue
        checked += 1
        if not (path.parent / file_part).exists():
            failures.append((name, link))
for value in failures:
    print("FAIL", value)
print(f"Checked {checked} repository Markdown relative links; {len(failures)} missing targets")
raise SystemExit(bool(failures))
