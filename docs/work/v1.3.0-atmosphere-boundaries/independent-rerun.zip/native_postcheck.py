import gzip, hashlib, io, json, pathlib, re, socket, sys, tomllib, zipfile
sys.path.insert(0, r'D:/GitHub/AdvancedRocketry-Community')
from scripts import v120_precision_world_fixture as region
from scripts import inspect_celestial_saved_data as nbt
from scripts import run_dedicated_server_smoke as server
# Finite full-world metadata limits, not the smaller celestial SavedData profile.
nbt.MAX_TAGS=200000
nbt.MAX_COLLECTION_ENTRIES=100000
nbt.MAX_DEPTH=64
BASE=pathlib.Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v130-atm01-1790444703294')
EVIDENCE=BASE/'runtime-evidence'
OUT=pathlib.Path(__file__).parent
PHASES=['setup-reload','open-restart','provider-skipped','provider-restored']
HOST='advancedrocketrycommunity'
FIXTURE='arce_adapter_test'
REGION='world/dimensions/advancedrocketrycommunity/moon/region/r.0.0.mca'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def require(value,message):
    if not value: raise AssertionError(message)
def block(chunk,x,y,z):
    sections=[s for s in chunk['sections'] if s['Y']==y//16]
    require(len(sections)==1,'Section uniqueness')
    encoded=sections[0]['block_states']
    palette=encoded['palette']
    require(1<=len(palette)<=4096,'Palette bound')
    if len(palette)==1:return palette[0]
    bits=max(4,(len(palette)-1).bit_length())
    per_word=64//bits
    words=encoded['data']
    require(len(words)==(4096+per_word-1)//per_word,'Packed palette length')
    index=(y%16)*256+(z%16)*16+x%16
    selected=(words[index//per_word] >> ((index%per_word)*bits)) & ((1<<bits)-1)
    require(selected<len(palette),'Palette index')
    return palette[selected]
manifest={}
for line in (EVIDENCE/'SHA256SUMS').read_text(encoding='ascii').splitlines():
    digest,relative=line.split('  ',1)
    part=pathlib.PurePosixPath(relative)
    require(not part.is_absolute() and '..' not in part.parts and relative not in manifest,'Manifest path')
    require(re.fullmatch('[0-9a-f]{64}',digest) and sha(EVIDENCE/relative)==digest,'Manifest hash '+relative)
    manifest[relative]=digest
actual={p.relative_to(EVIDENCE).as_posix() for p in EVIDENCE.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
require(actual==set(manifest),'Complete manifest set')
summary=read(EVIDENCE/'summary.json')
artifacts=[]
for item in summary['artifacts']:
    p=pathlib.Path(item['path'])
    require(p.parent==BASE/'artifacts' and sha(p)==item['sha256'] and p.stat().st_size==item['bytes'],'Immutable artifact identity')
    require(sha(BASE/'server/mods'/p.name)==item['sha256'],'Installed artifact unchanged')
    with zipfile.ZipFile(p) as archive:
        metadata=tomllib.loads(archive.read('META-INF/mods.toml').decode())
        require([(m['modId'],m['version']) for m in metadata['mods']]==[(item['mod_id'],item['version'])],'Actual mod metadata')
        classes=[n for n in archive.namelist() if n.endswith('.class')]
        if item['mod_id']==HOST:
            require(not any('arceadaptertest' in n for n in classes),'Fixture excluded from host')
        else:
            require(all(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in classes),'Only fixture classes')
            require('io/github/sunthemoon/arceadaptertest/FixtureBoundaryBlock.class' in classes,'Actual boundary implementation')
    artifacts.append({'file':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'metadata':metadata['mods']})
observations=[]
worldgen=None
previous=None
for phase in PHASES:
    directory=EVIDENCE/phase
    commands=read(directory/'commands.json')
    launch=read(directory/'launch.json')
    result=read(directory/'result.json')
    require(result['exit_code']==0 and result['result']=='PASS','Recorded clean exit')
    require(launch['mods']=={a['name']:a['sha256'] for a in summary['artifacts']},'Launch exact JAR set')
    require(launch['cwd']==summary['server'],'Same launch directory')
    skip='-Darce_adapter_test.skipAtmosphereBoundary=true'
    require((skip in launch['command'])==(phase=='provider-skipped'),'Provider selection')
    require(not any('releaseTestHooks' in s for s in launch['command']),'No release hook')
    stdout=(directory/'stdout.txt').read_text(encoding='utf-8')
    lines=stdout.splitlines()
    registrations=[l for l in lines if 'Registered atmosphere boundary ' in l]
    skipped=[l for l in lines if 'Skipped atmosphere boundary ' in l]
    expected=f'Registered atmosphere boundary {FIXTURE}:state_boundary (API 1.2, event 1)'
    if phase=='provider-skipped':
        require(not registrations and len(skipped)==1 and f'Skipped atmosphere boundary {FIXTURE}:state_boundary (event 1)' in skipped[0],'Skipped registration')
    else:
        require(not skipped and len(registrations)==1 and expected in registrations[0],'Single complete-lifecycle registration')
    require('Saved the game' in stdout and 'Stopping server' in stdout and 'All dimensions are saved' in stdout,'Native save/stop log')
    markers=[l.rsplit('V130_ATM_',1)[1] for l in lines if re.search(r'\[Server\] V130_ATM_',l)]
    require(phase+'_FIRST' in markers and phase+'_SECOND' in markers,'Live observation markers')
    times=[int(re.search(r'The time is (\d+)',l).group(1)) for l in lines if re.search(r'The time is (\d+)',l)]
    require(len(times)==3 and times[-1]-times[0]==22 and result['observation_ticks']==22,'Native tick window')
    if phase=='setup-reload':
        expected_order=['CLOSED_ACTIVE','OPEN_INACTIVE','RECLOSED_ACTIVE','REPLACED_INACTIVE','SEALING_TAG_OVERRIDES','TAG_REMOVED_RULE_RESTORED']
        require([m for m in markers if m in expected_order]==expected_order,'Real ordered boundary transitions')
        require(commands.count('reload')==2 and len([l for l in lines if 'Reloading!' in l])==2,'Two real reloads')
        require('Accepted celestial catalog generation 2 with 3 bodies' in stdout and 'Accepted celestial catalog generation 3 with 3 bodies' in stdout,'Two accepted reload generations')
        require(sum('data merge block' in c for c in commands)==1,'Single resource setup')
        require(read(directory/'sealing-enabled.json')=={'replace':False,'values':[FIXTURE+':state_boundary']},'Enabled tag fixture')
        require(read(directory/'sealing-disabled.json')=={'replace':False,'values':[]},'Disabled tag fixture')
    else:
        require(not any(re.search(r'\b(fill|setblock|merge|reload)\b',c) for c in commands),'Restart contains no reconstruction/top-up')
    audits={}
    for name in ['stdout.txt','debug.log','latest.log']:
        raw=(directory/name).read_text(encoding='utf-8')
        errors=[l for l in raw.splitlines() if re.search(r'/(ERROR|FATAL)\]',l)]
        linkage=[l for l in raw.splitlines() if any(s in l for s in ['NoClassDefFoundError','ClassNotFoundException','InvalidDistException','Attempted to load class net/minecraft/client'])]
        project_warnings=[l for l in raw.splitlines() if '/WARN]' in l and re.search(r'\[(?:io\.github\.sunthemoon\.advancedrocketrycommunity|io\.gi\.su\.ad\.)',l)]
        require(not errors and not linkage and not project_warnings,'Raw error/linkage/project-WARN audit '+phase+'/'+name)
        audits[name]={'error_fatal':len(errors),'linkage':len(linkage),'project_warn':len(project_warnings),'warning_lines':sum('WARN' in l for l in raw.splitlines())}
    payload=(directory/REGION).read_bytes()
    chunk=region._decode_chunk(region._region_chunk(payload,16,16),16,16)
    vents=[be for be in chunk['block_entities'] if be.get('id')==HOST+':oxygen_vent']
    require(len(vents)==1 and tuple(vents[0][k] for k in ['x','y','z'])==(264,220,264),'Unique native vent identity')
    be=vents[0]
    data=be['arce_oxygen_vent']
    require(set(data)=={'schema_version','oxygen_canisters','empty_canisters','oxygen_units','energy','oxygen_phase'},'Exact resource schema')
    require(all(type(v)is int for v in data.values()) and data['schema_version']==1 and data['oxygen_canisters']==data['empty_canisters']==0,'Resource integer schema')
    require(0<data['energy']<=40000 and 0<data['oxygen_units']<=3000 and 0<=data['oxygen_phase']<20,'Resource bounds')
    for x in range(262,267):
        for y in range(219,225):
            for z in range(262,267):
                pos=(x,y,z)
                expected={'Name':'minecraft:iron_block'} if 263<=x<=265 and 220<=y<=222 and 263<=z<=265 else {'Name':'minecraft:air'}
                if pos==(264,221,264):expected={'Name':'minecraft:air'}
                if pos==(264,222,264):expected={'Name':FIXTURE+':state_boundary','Properties':{'open':'true'}}
                if pos==(264,220,264):expected={'Name':HOST+':oxygen_vent','Properties':{'lit':'true' if phase=='provider-skipped' else 'false'}}
                require(block(chunk,x,y,z)==expected,'Native fixture block '+str(pos))
    with gzip.GzipFile(fileobj=io.BytesIO((directory/'world/level.dat').read_bytes())) as g:
        expanded=g.read(4*1024*1024+1)
    require(len(expanded)<=4*1024*1024,'Level NBT bound')
    level=nbt.NbtReader(expanded).read_root()['Data']
    if worldgen is None:worldgen=level['WorldGenSettings']
    require(level['WorldGenSettings']==worldgen and level['LevelName']=='world','Stable native world generation identity')
    require('mod:'+FIXTURE in level['DataPacks']['Enabled'] and 'file/arce_boundary_fixture' in level['DataPacks']['Enabled'],'Fixture and tag pack retained')
    if previous is not None:
        if phase=='provider-skipped':
            require(data['energy']<=previous['energy']-400 and data['oxygen_units']<previous['oxygen_units'],'Fallback really consumes resources')
        else:require(data==dict(previous,oxygen_phase=0),'Inactive restart preserves resources')
    previous=data
    published=read(directory/'disk-state.json')
    require(published['vent_data']==data and published['boundary']==block(chunk,264,222,264) and published['vent_block']==block(chunk,264,220,264),'Derived disk JSON matches independent raw readback')
    for relative, info in result['disk_evidence'].items():
        require(info['sha256']==sha(directory/relative) and info['bytes']==(directory/relative).stat().st_size,'Native evidence bindings')
    properties=server.verify_active_server_properties((directory/'server.properties').read_bytes(),summary['port'])
    status=read(directory/'status.json')
    require(status['players']['online']==0 and set(server.forge_mod_versions(status))=={HOST,FIXTURE,'minecraft','forge'},'Live mod status with empty server')
    observations.append({'phase':phase,'recorded_exit':result['exit_code'],'observation_ticks':times[-1]-times[0],'native_resources':data,'vent_lit':block(chunk,264,220,264)['Properties']['lit'],'boundary':block(chunk,264,222,264),'world_seed':worldgen['seed'],'saved_game_time':level['Time'],'room_and_shell_blocks_checked':150,'live_markers':markers,'logs':audits})
require(read(BASE/'server/world/datapacks/arce_boundary_fixture/data/advancedrocketrycommunity/tags/blocks/atmosphere_sealing.json')=={'replace':False,'values':[]},'Final tag pack disabled')
identity=summary['world']
require(sha(BASE/'server'/identity['identity_marker'])==identity['identity_marker_sha256'],'Retained world marker')
s=socket.socket()
s.settimeout(1)
port_open=s.connect_ex(('127.0.0.1',summary['port']))==0
s.close()
require(not port_open,'Owned server port closed')
report={'result':'PASS','scope':'Independent readback of four existing clean-process captures; no Java launched by reviewer','manifest_count':len(manifest),'manifest_sha256':sha(EVIDENCE/'SHA256SUMS'),'artifacts':artifacts,'observations':observations,'port_closed':True}
(OUT/'native-observations.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))