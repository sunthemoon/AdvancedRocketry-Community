"""Collect JUnit XML, a summary, tested implementation file hashes and artifact hashes into an evidence dir."""
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(sys.argv[1])
suffix = sys.argv[2] if len(sys.argv) > 2 else ''
sha = lambda b: hashlib.sha256(b).hexdigest()
junit = E / ('full-junit' + suffix)
junit.mkdir()
tests = failures = errors = skipped = suites = 0
for f in sorted((ROOT / 'build/test-results/test').glob('*.xml')):
    shutil.copyfile(f, junit / f.name)
    r = ET.parse(f).getroot()
    suites += 1
    tests += int(r.get('tests')); failures += int(r.get('failures')); errors += int(r.get('errors'))
    skipped += int(r.get('skipped'))
summary = {'suites': suites, 'tests': tests, 'failures': failures, 'errors': errors, 'skipped': skipped}
(E / ('junit-summary' + suffix + '.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
changed = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=ROOT).decode().splitlines()
files = {}
for line in changed:
    path = line[3:]
    if path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/') or path.startswith('docs/'):
        continue
    if (ROOT / path).is_file():
        files[path] = sha((ROOT / path).read_bytes())
(E / 'implementation-files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
artifacts = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append({'name': jar.name, 'bytes': jar.stat().st_size, 'sha256': sha(jar.read_bytes())})
(E / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}, indent=2) + '\n', encoding='utf-8')
for name in ('latest.log', 'debug.log'):
    log = ROOT / 'run/gametest/logs' / name
    if log.exists():
        shutil.copyfile(log, E / ('gametest-' + name.replace('.log', '') + suffix + '.log'))
diff = subprocess.run(['git', 'diff', '--exit-code', '--stat', '--', 'src/generated'], cwd=ROOT, capture_output=True, text=True)
(E / ('generated-diff' + suffix + '.log')).write_text(f'exit={diff.returncode}\n{diff.stdout}{diff.stderr}', encoding='utf-8')
print(summary, len(files), 'implementation files', [a['name'] for a in artifacts], 'generated diff exit', diff.returncode)
