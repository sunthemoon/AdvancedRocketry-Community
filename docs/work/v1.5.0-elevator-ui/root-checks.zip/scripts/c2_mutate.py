"""C2 mutation checks. Usage: c2_mutate.py <E>. JUnit mutations run alone; GameTest ones as one combined run
in which each mutation targets different cells."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

E = Path(sys.argv[1]) / 'mutations'
E.mkdir(parents=True, exist_ok=True)
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
S = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'
VALIDATOR = S / 'station/elevator/ElevatorEndpointValidator.java'
COMMANDS = S / 'station/command/StationCommands.java'
EXPANSION = S / 'station/service/StationExpansionService.java'
WARP = S / 'station/warp/StationWarpService.java'
env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

JUNIT = [
    ('V1-authority-after-orbit', VALIDATOR,
     """        // Rule 2: authority, before anything else about the station is disclosed.
        if (!snapshot.operator() && !station.ownerId().equals(snapshot.requesterId())) {
            return Result.failed(ElevatorEndpointCode.UNAUTHORIZED, Optional.empty());
        }
        // Rule 3: the station's current orbit body.
        if (!request.bodyId().equals(station.orbitBody())) {
            return Result.failed(ElevatorEndpointCode.NOT_CURRENT_ORBIT, found);
        }""",
     """        // Rule 3: the station's current orbit body.
        if (!request.bodyId().equals(station.orbitBody())) {
            return Result.failed(ElevatorEndpointCode.NOT_CURRENT_ORBIT, found);
        }
        // Rule 2: authority, before anything else about the station is disclosed.
        if (!snapshot.operator() && !station.ownerId().equals(snapshot.requesterId())) {
            return Result.failed(ElevatorEndpointCode.UNAUTHORIZED, Optional.empty());
        }"""),
    ('V2-shared-level-accepted', VALIDATOR,
     """        if (!PlanetarySurfaceResolver.find(catalog, level, true)
                .map(CelestialBodyDefinition::id).filter(request.bodyId()::equals).isPresent()) {""",
     """        if (false) {"""),
    ('V3-border-ignored', VALIDATOR,
     """        if (!snapshot.border().inside(level, request.x(), request.z())) {""", """        if (false) {"""),
]
GAMETEST = [
    ('G1-elevator-leaf-requirement-removed', COMMANDS,
     """                .then(Commands.literal("elevator")
                        .requires(source -> source.hasPermission(2))""",
     """                .then(Commands.literal("elevator")"""),
    ('G2-expansion-confirm-takes-before-authority', EXPANSION,
     """        StationLocalActor.Located actor = StationLocalActor.locate(access, player, issuedByPlayer);
        if (actor.code() != null) {
            return audit("confirm", player, StationManagementResult.of(actor.code(), actor.station()));
        }
""", ""),
    ('G3-warp-confirm-takes-before-authority', WARP,
     """        StationLocalActor.Located actor = StationLocalActor.locate(access, player, issuedByPlayer);
        if (actor.code() != null) {
            return audit("confirm", player, StationWarpResult.of(actor.code(), actor.station()));
        }
""", ""),
    ('G4-uuid-removal-branch-removed', COMMANDS,
     """                                .then(Commands.literal("uuid")
                                        .then(Commands.argument("member", UuidArgument.uuid())
                                                .executes(this::removeByUuid)))
""", ""),
]


def apply(path, old, new):
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (path, 'anchor')
    path.write_bytes(text.replace(old, new).encode('utf-8'))


results = []
for name, path, old, new in JUNIT:
    original = path.read_bytes()
    try:
        apply(path, old, new)
        with open(E / f'{name}.log', 'wb') as log:
            code = subprocess.call(['sh', './gradlew', 'test', '--tests', '*ElevatorEndpointValidatorTest'],
                                   cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    finally:
        path.write_bytes(original)
    results.append(f'{name}\t{"KILLED" if code else "SURVIVED"}\texit={code}')
    print(results[-1], flush=True)

originals = {}
try:
    for name, path, old, new in GAMETEST:
        originals.setdefault(path, path.read_bytes())
        apply(path, old, new)
    with open(E / 'gametest-combined.log', 'wb') as log:
        code = subprocess.call(['sh', './gradlew', 'runGameTestServer'], cwd=ROOT, env=env, stdout=log,
                               stderr=subprocess.STDOUT)
finally:
    for path, data in originals.items():
        path.write_bytes(data)
shutil.copy(ROOT / 'build/gametest/logs/latest.log', E / 'gametest-combined-latest.log')
results.append(f'gametest-combined({",".join(n for n, *_ in GAMETEST)})\texit={code}')
print(results[-1], flush=True)
(E / 'mutation-results.tsv').write_text('\n'.join(results) + '\n', encoding='utf-8', newline='\n')
