"""Build the ADR-046 A1 permission report from a GameTest log. Usage: c2_matrix_report.py <E> <out.md>."""
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path

E = Path(sys.argv[1])
OUT = Path(sys.argv[2])
log = (E / 'run-02' / 'gametest-latest.log').read_text(encoding='utf-8', errors='replace')
LINE = re.compile(r'ARCE_STATION_PERMISSION_MATRIX table=(\d+) action=(\w+) actor=(\w+) precondition="([^"]*)" '
                  r'expected=(\S+) actual=(.+?) result=(PASS|FAIL) registry_changed=(.+?) chunk_delta=(.+?)'
                  r'(?: cell_full_chunks=(\d+))?$')
SUMMARY = re.compile(r'ARCE_STATION_PERMISSION_MATRIX_SUMMARY (.*)$')
cells = OrderedDict()
summary = None
for raw in log.splitlines():
    m = LINE.search(raw)
    if m:
        cells[(m.group(2), m.group(3))] = m.groups()
    s = SUMMARY.search(raw)
    if s:
        summary = s.group(1)
actions = list(OrderedDict.fromkeys(a for a, _ in cells))
actors = list(OrderedDict.fromkeys(b for _, b in cells))
artifacts = json.loads((E / 'artifacts.json').read_text())['artifacts']
junit = json.loads((E / 'junit-summary.json').read_text())
base = (E / 'base-commit.txt').read_text().strip()
passes = sum(1 for c in cells.values() if c[6] == 'PASS')
executed = sum(1 for c in cells.values() if c[4] != 'N/A')

CONSTRUCTION = {
    'OWNER': 'connected mock player (embedded channel), the station owner, on its platform',
    'MEMBER': 'connected mock player, a member, on the platform',
    'INVITEE': 'connected mock player with a pending invitation, on the platform',
    'OUTSIDER': 'connected mock player with no relation to the station, on the platform',
    'OPERATOR': 'connected mock player with a level-4 ops entry, on the platform',
    'OPERATOR_OUTSIDE': 'connected mock player with a level-4 ops entry, in Space in the gap west of the cell',
    'OTHER_STATION_OWNER': 'connected mock player owning a second station, standing in this one',
    'REMOVED_MEMBER': 'connected mock player added as a member and then removed',
    'PREVIOUS_OWNER': 'connected mock player who created the station and transferred it (kept as a member)',
    'DEOPPED_OPERATOR': 'connected mock player whose level-4 ops entry was removed before the matrix',
    'CONSOLE': 'server command source (permission level 4)',
    'EXECUTE_AS_OWNER': '`/execute as <owner> at <owner> run ...` from the console (console permission level)',
    'SILENT_OWNER': "the owner's own source with `withSuppressedOutput()` (as `/function` or a reward)",
    'FAKE_PLAYER_OWNER': "Forge `FakePlayer` with the owner's UUID on the platform",
    'STALE_OWNER': "the owner's first player object, after it logged out and the owner joined again",
}

out = []
w = out.append
w('# v1.5 multiplayer permission report (A1, development copy)')
w('')
w('ADR-046 UI-03. This is the development copy; the candidate-bound copy belongs in')
w('`docs/releases/v1.5.0/`. It is evidence for the maintainer, **not a Gate approval**.')
w('S1 (packaged JAR on a native dedicated server) and V2 (two real clients) are not')
w('part of this report: S1 is planned for C3 and V2 stays open for ACC-02.')
w('')
w('## Identity')
w('')
w(f'- Base commit: `{base}`; the tested implementation files are bound by hash in')
w('  `root-checks.json` (`tested_implementation_files`).')
w('- Minecraft 1.20.1, Forge 47.4.10, Java 17.0.7; mod `1.20.1-1.5.0-dev`.')
for a in artifacts:
    w(f"- `{a['name']}`: {a['bytes']} bytes, SHA-256 `{a['sha256']}`.")
w('- Command: `./gradlew clean build test runData runGameTestServer`, exit 0 (full run 02):')
w(f"  {junit['tests']} JUnit tests with {junit['failures']} failures and {junit['errors']} errors; all 256 required")
w('  GameTests passed.')
w('- Source of every row: the `ARCE_STATION_PERMISSION_MATRIX` lines of run 02')
w('  (`run-02/gametest-latest.log` in `root-checks.zip`).')
w('')
w('## Method')
w('')
w('- Table revision 1: `StationPermissionMatrix.expected(action, actor)`. The GameTest')
w('  `everyCellOfTheStationAuthorityMatrixMatchesTheTable` runs every cell through the real')
w('  commands, the block-break event or the flight service\'s VISIT predicate, and fails on any')
w('  difference.')
w('- Outcomes come from the replies the source receives. Silent sources and FakePlayers receive')
w('  no replies, so for them the outcome is read from the command\'s `ARCE_STATION_*` audit line')
w('  and its return value. For `accept` and `decline` they carry no audit line, so the reason of a')
w('  refusal is not observable for them (`REJECTED`).')
w('- `UNKNOWN_COMMAND` means Brigadier did not parse the command for that source (a permission')
w('  requirement). `REACHED` means it parsed and ran. `NOT_PLAYER` is Brigadier\'s "A player is')
w('  required to run this command here".')
w('- Before each cell: the registry encoding and the loaded chunk-holder count of every Level.')
w('  After it: only allowed team cells may change the registry, and they are reset and checked.')
w('  No other cell may change any Level\'s holder count.')
w('- `ADMIN_CREATE_DELETE` runs for OPERATOR and CONSOLE only; the others are checked by parse.')
w('  It must leave every other Level unchanged and load at most the 2 x 2 platform chunks of the')
w('  new cell (`cell_full_chunks`, full chunks inside the cell\'s region). Its Space holder count')
w('  is recorded but not compared: vanilla adds a light ticket around every chunk it loads, and')
w('  on a never-generated cell this creates holders for neighbouring chunks (676 in run 02).')
w('- The matrix waits until the loaded chunk counts are stable for 40 ticks after the players')
w('  join, so each cell\'s delta is its own.')
w('')
w('## Actors')
w('')
w('| Actor | Construction |')
w('|---|---|')
for actor in actors:
    w(f'| {actor} | {CONSTRUCTION.get(actor, "")} |')
w('')
w('## Summary grid (actual outcome; every cell equals the expected value)')
w('')
w('| Action | ' + ' | '.join(a.replace('_', ' ') for a in actors) + ' |')
w('|---' * (len(actors) + 1) + '|')
for action in actions:
    w(f'| {action} | ' + ' | '.join(cells[(action, actor)][5] for actor in actors) + ' |')
w('')
w('## Cells')
w('')
for action in actions:
    first = cells[(action, actors[0])]
    w(f'### {action}')
    w('')
    w(f'Precondition: {first[3]}.')
    w('')
    w('| Actor | Expected | Actual | Result | Registry changed | Chunk delta |')
    w('|---|---|---|---|---|---|')
    for actor in actors:
        c = cells[(action, actor)]
        delta = c[8] + (f'; cell full chunks {c[9]}' if c[9] else '')
        w(f'| {actor} | {c[4]} | {c[5]} | {c[6]} | {c[7]} | {delta} |')
    w('')
w('## Forged and stale identifiers')
w('')
w('| Case | Test |')
w('|---|---|')
w('| Unknown station UUID | `StationElevatorGameTests` (elevator check), `ElevatorEndpointValidatorTest.anUnknownStationIsMissingEvenForAnOperator` |')
w('| Another station\'s confirmation; a confirmation after a change (`STATION_CHANGED`) | `StationExpansionGameTests.localOwnerAndOperatorExpandOnlyThroughConfirmedCheckedCommit`, `StationWarpGameTests.cancelledChangedOrRepricedCountdownsNeverWarpOrCharge`, `StationExpansionConfirmationsTest.confirmationCannotTransferToAnotherPlayerStationOrAuthority` |')
w('| Consumed confirmation (replay) | `StationExpansionGameTests` ("consumed confirmation"), `StationExpansionConfirmationsTest.confirmationIsOneShotAndReturnsTheObservedState`, `StationWarpStateTest.confirmationsAreOneShotBoundAndBounded` |')
w('| Unknown or non-orbitable warp target; a target removed during the countdown | `StationWarpGameTests.requestsWithoutAuthorityCoreTargetEnergyOrKnownRocketStateAreRejected`, `StationWarpGameTests.aTargetRemovedDuringTheCountdownAborts` |')
w('| Flight to a private or deleted station | `RocketNavigationGameTests` ("Private station or control permission leaked"), `PlanetaryAdmissionGameTests` (source station access denial) |')
w('| A confirmation consumed by another source | `StationWarpGameTests.ownerWarpsInSystemAfterConfirmationAndCountdown` (`/execute` confirm refused before the confirmation is taken) |')
w('')
w('## Contention')
w('')
w('| Case | Test |')
w('|---|---|')
w('| Different stations never interfere; due countdowns commit one per tick | `StationWarpGameTests.countdownsDueTogetherCommitOnePerTick`, `StationWarpGameTests.tenChargingStationsDirtyTheRegistryOnlyOncePerFoldWindow` |')
w('| One station: the first commit wins, the rest get `STATION_CHANGED` or `WARP_COUNTDOWN_ACTIVE` | `StationWarpGameTests.cancelledChangedOrRepricedCountdownsNeverWarpOrCharge`, `StationWarpStateTest.countdownsAreOnePerStationBoundedAnnouncedAndCommittedInOrder` |')
w('')
w('## Caps and replay')
w('')
w('| Case | Test |')
w('|---|---|')
w('| 128 warp confirmations, 64 countdowns | `StationWarpStateTest.confirmationsAreOneShotBoundAndBounded`, `StationWarpStateTest.countdownsAreOnePerStationBoundedAnnouncedAndCommittedInOrder` |')
w('| Expansion confirmation capacity | `StationExpansionConfirmationsTest.capacityRejectsNewPlayersUntilEntriesExpireOrClear` |')
w('| 32 members, 32 invitations; inviting the owner, a member or an invitee changes nothing | `StationTeamCapsTest` |')
w('| Registry storage bound for every growth path | `StationRegistryStorageBoundTest.everyGrowthPathIsRefusedOnItsOwnAtTheBound` |')
w('')
w('## Rate')
w('')
w('- Non-operator players are bound by vanilla `detectRateSpam` (checked with `javap` in the')
w('  contract review): +20 per chat command, decaying by 1 per tick, disconnect above 200.')
w('  Operators are trusted.')
w('- Gravity and warp have 100-tick per-station cooldowns; expansion confirmations are one-shot.')
w('- Team commands flush the registry; with the vanilla limiter one non-operator causes at most')
w('  about one flush per second. No per-station team cooldown is added.')
w('')
w('## Totals')
w('')
w(f'- Cells: {len(cells)} ({len(actions)} actions x {len(actors)} actors); executed {executed}; not applicable '
  f'{len(cells) - executed}.')
w(f'- PASS: {passes}; FAIL: {len(cells) - passes}.')
w(f'- GameTest summary line: `{summary}`.')
w('')
w('## Known gaps')
w('')
w('- VISIT is decided with the flight service\'s own predicate and inputs')
w('  (`StationAccessService.allowed(station, player UUID, hasPermissions(2), VISIT)`, as in')
w('  `RocketFlightService`); the packet path itself is covered by the tests listed above.')
w('- For silent sources and FakePlayers, `accept` and `decline` refusals have no observable reason.')
w('- The `elevator` literal\'s own permission requirement is defence in depth: today the shared')
w('  `admin` node already requires level 2, so removing the leaf requirement changes no cell')
w('  (mutation G1 survived; see VERIFICATION).')
w('- Notices do not name the station; visitors are not notified; offline members get no notice at')
w('  login (ADR-046 UI-02).')
w('- S1 and V2 are not covered here.')
w('')
w('This report is not a Gate approval.')
OUT.write_text('\n'.join(out) + '\n', encoding='utf-8', newline='\n')
print('cells', len(cells), 'pass', passes, 'executed', executed)
