import hashlib, json, subprocess, sys, zipfile, io
REPO = r"D:/GitHub/AdvancedRocketry-Community"
PACKETS = [("c5e213b", "docs/work/v1.5.0-star-systems"),
           ("30b9b11", "docs/work/v1.5.0-station-capacity"),
           ("9969550", "docs/work/v1.5.0-warp-schema")]

def blob(commit, path):
    return subprocess.run(["git", "-C", REPO, "show", f"{commit}:{path}"], capture_output=True, check=True).stdout

def sha(b):
    return hashlib.sha256(b).hexdigest()

problems = 0
for commit, d in PACKETS:
    print(f"=== {commit} {d}")
    sums = blob(commit, f"{d}/SHA256SUMS.txt").decode()
    for line in sums.strip().splitlines():
        h, name = line.split(None, 1)
        name = name.strip().lstrip("*")
        actual = sha(blob(commit, f"{d}/{name}"))
        ok = actual == h
        problems += not ok
        print(f"  SHA256SUMS {name}: {'OK' if ok else 'MISMATCH ' + actual}")
    archives = json.loads(blob(commit, f"{d}/evidence-archives.json"))
    for a in archives["archives"]:
        zb = blob(commit, f"{d}/{a['name']}")
        z = zipfile.ZipFile(io.BytesIO(zb))
        names = [i.filename for i in z.infolist() if not i.is_dir()]
        ok = (len(zb) == a["bytes"] and sha(zb) == a["sha256"] and len(names) == a["members"])
        problems += not ok
        print(f"  archive {a['name']}: bytes {len(zb)}/{a['bytes']} sha {'OK' if sha(zb)==a['sha256'] else 'MISMATCH'} members {len(names)}/{a['members']} -> {'OK' if ok else 'PROBLEM'}")
        manifest = json.loads(blob(commit, f"{d}/{a['manifest']}"))
        listed = {m["path"]: m for m in manifest}
        bad = 0
        for n in names:
            m = listed.get(n)
            data = z.read(n)
            if m is None or m["bytes"] != len(data) or m["sha256"] != sha(data):
                bad += 1
                if bad <= 5: print("    member mismatch:", n, None if m is None else (m["bytes"], len(data)))
        missing = set(listed) - set(names)
        problems += bad + len(missing)
        print(f"  manifest {a['manifest']}: {len(listed)} entries, {bad} mismatched, {len(missing)} listed-but-missing")
    ident = json.loads(blob(commit, f"{d}/source-identity.json"))
    files = ident.get("files", [])
    bad = 0
    for f in files:
        try:
            b = blob(commit, f["path"])
        except subprocess.CalledProcessError:
            print("    not in commit:", f["path"]); bad += 1; continue
        if sha(b) != f["sha256"] or len(b) != f["bytes"]:
            bad += 1
            print("    identity mismatch:", f["path"], len(b), f["bytes"])
    problems += bad
    print(f"  source-identity: {len(files)} files, {bad} mismatched; keys={sorted(k for k in ident if k!='files')}")
print("TOTAL PROBLEMS", problems)
