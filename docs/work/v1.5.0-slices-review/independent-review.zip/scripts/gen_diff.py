import os, sys, subprocess, hashlib
REPO="D:/GitHub/AdvancedRocketry-Community"; commit=sys.argv[2]; tree=sys.argv[1]
ls = subprocess.run(["git","-C",REPO,"ls-tree","-r",commit,"--","src/generated"],capture_output=True,text=True).stdout.splitlines()
blobs = {}
for line in ls:
    meta, path = line.split("\t",1); blobs[path]=meta.split()[2]
diff=0; seen=set()
for root, dirs, files in os.walk(os.path.join(tree,"src","generated")):
    dirs[:] = [x for x in dirs if x != ".cache"]
    for f in files:
        full=os.path.join(root,f); rel=os.path.relpath(full,tree).replace(os.sep,"/"); seen.add(rel)
        data=open(full,"rb").read()
        h=hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
        if blobs.get(rel)!=h: diff+=1; print("DIFF/NEW", rel)
for p in blobs:
    if p not in seen and "/.cache/" not in p: diff+=1; print("MISSING", p)
print("generated files:", len(blobs), "differences:", diff)
