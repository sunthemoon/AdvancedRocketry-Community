import os, sys, xml.etree.ElementTree as ET
B = chr(92)
d = B + B + "?" + B + os.path.abspath(sys.argv[1]).replace("/", B)
t=f=e=s=0; n=0; failed=[]
for name in os.listdir(d):
    if not name.endswith(".xml"): continue
    n+=1
    r=ET.parse(d + B + name).getroot(); t+=int(r.get("tests")); f+=int(r.get("failures")); e+=int(r.get("errors")); s+=int(r.get("skipped"))
    for tc in r.iter("testcase"):
        if tc.find("failure") is not None or tc.find("error") is not None:
            failed.append(tc.get("classname").split(".")[-1] + "." + tc.get("name"))
print("suites",n,"tests",t,"failures",f,"errors",e,"skipped",s)
for x in failed: print("FAILED", x)
