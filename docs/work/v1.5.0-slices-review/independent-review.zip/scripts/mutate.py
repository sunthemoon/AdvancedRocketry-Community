"""Apply one mutation at a time to tree-mut, run focused JUnit tests, record results, restore.
Usage: python mutate.py [ID ...]   (no args = all)"""
import os, shutil, subprocess, sys, time, xml.etree.ElementTree as ET

D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TREE = os.path.join(D, "tree-mut")
LOGS = os.path.join(D, "evidence", "mutations")
os.makedirs(LOGS, exist_ok=True)
B = chr(92)
P = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"
SRD = P + "station/persistence/StationRegistrySavedData.java"
MODEL = P + "station/model/StationRegistryModel.java"
STATE = P + "station/model/StationState.java"
MST = P + "persistence/migration/ManagedSavedDataType.java"
PAY = P + "station/persistence/StationRegistryPayload.java"
BIO = P + "persistence/migration/BoundedSavedDataIo.java"
CC = P + "celestial/service/CelestialCatalog.java"
PC = P + "celestial/data/PlanetaryCatalog.java"
SSK = P + "celestial/service/StarSystemKnowledge.java"
GRAV = P + "station/service/StationGravityService.java"

MUT = {
    "BASE": ("no mutation (focused baseline)", []),
    "W1": ("candidate verification skips the balance comparison", [(SRD,
        "                || !decoded.reservations().equals(registry.reservations())\n"
        "                || !decoded.warpEnergyBalances().equals(expectedBalances)) {",
        "                || !decoded.reservations().equals(registry.reservations())) {")]),
    "W2": ("candidate encode ignores the debited balance (verification intact)", [(SRD,
        "        if (substitute != null && substituteBalance != null) {", "        if (false) {")]),
    "W3": ("W1+W2: encode ignores the debit AND verification skips balances", [
        (SRD, "        if (substitute != null && substituteBalance != null) {", "        if (false) {"),
        (SRD, "                || !decoded.reservations().equals(registry.reservations())\n"
              "                || !decoded.warpEnergyBalances().equals(expectedBalances)) {",
              "                || !decoded.reservations().equals(registry.reservations())) {")]),
    "W4": ("relocation publish drops the balance debit", [(MODEL,
        "        putBalance(replacement.stationId(), expectedBalance - cost);\n        return replacement;",
        "        return replacement;")]),
    "W5": ("root-shape check allows warp_energy in roots 1-3 (single guard)", [(MST,
        ": payload.contains(WARP_ENERGY_KEY)) {", ": false) {")]),
    "W5b": ("all three root<4 warp_energy guards removed", [
        (MST, ": payload.contains(WARP_ENERGY_KEY)) {", ": false) {"),
        (PAY, "        if (source.contains(WARP_ENERGY)) {\n            throw new IllegalArgumentException(\"Station registry root \" + rootSchema",
              "        if (false) {\n            throw new IllegalArgumentException(\"Station registry root \" + rootSchema"),
        (PAY, "        } else if (source.contains(WARP_ENERGY)) {", "        } else if (false) {")]),
    "W6": ("candidate verification checks only the replaced station", [(SRD,
        "        if (!decoded.stations().equals(expectedStations)\n",
        "        if (!decoded.find(stationId).filter(replacement::equals).isPresent()\n")]),
    "W7": ("candidate verification skips reservations", [(SRD,
        "                || !decoded.reservations().equals(registry.reservations())\n", "")]),
    "W8": ("checked(): no INSUFFICIENT_ENERGY pre-check", [(SRD,
        "        if (relocation && balance < cost) {\n            return CheckedUpdate.INSUFFICIENT_ENERGY;\n        }\n", "")]),
    "W9": ("relocateChecked ignores the observed balance", [(MODEL,
        "\n                || warpEnergy(expected.stationId()) != expectedBalance) {", ") {")]),
    "W10": ("isOrbitRelocationOf only compares the orbit", [(STATE,
        "        return !orbitBody.equals(previous.orbitBody)\n                && equals(previous.withOrbitBody(orbitBody));",
        "        return !orbitBody.equals(previous.orbitBody);")]),
    "W11": ("model delete keeps the balance", [(MODEL,
        "            warpEnergy.remove(stationId);\n        }\n        return Optional.ofNullable(removed);",
        "        }\n        return Optional.ofNullable(removed);")]),
    "W12": ("fold ignores the entry headroom", [(SRD,
        "                if (!entryHeadroom) {\n                    continue;\n                }\n", "")]),
    "W13": ("headroom exact check uses the full bound instead of bound - 256 KiB", [(SRD,
        "            return StationNbtSize.uncompressedBytes(encode(new CompoundTag(), null, null)) <= limit;",
        "            return StationNbtSize.uncompressedBytes(encode(new CompoundTag(), null, null)) <= StationLimits.MAX_REGISTRY_NBT_BYTES;")]),
    "W14": ("restoreWarpEnergy accepts orphaned balances", [(MODEL,
        "        if (!stations.containsKey(stationId)) {\n            throw new IllegalArgumentException(\"Station warp energy belongs to no committed station\");\n        }\n",
        "")]),
    "W15": ("root 1-3 upgrade does not add the warp_energy list", [(PAY,
        "        result.put(WARP_ENERGY, new ListTag());\n", "")]),
    "W16": ("relocation publish goes through replaceChecked (no single swap)", [(SRD,
        "            if (relocation) {\n                registry.relocateChecked",
        "            if (false) {\n                registry.relocateChecked")]),
    "W17": ("root-shape check accepts root 4 without warp_energy (single guard)", [(MST,
        "            if (warpRoot ? !payload.contains(WARP_ENERGY_KEY, Tag.TAG_LIST) :",
        "            if (warpRoot ? false :")]),
    "S1": ("cross-system route rejection removed", [(PC,
        "            if (fromSystem.isPresent() && toSystem.isPresent() && !fromSystem.equals(toSystem)) {",
        "            if (false) {")]),
    "S2": ("16-system bound removed", [(CC, "        if (roots > MAX_SYSTEMS) {", "        if (false) {")]),
    "S3": ("16-system bound off by one (exactly 16 roots rejected)", [(CC,
        "        if (roots > MAX_SYSTEMS) {", "        if (roots >= MAX_SYSTEMS) {")]),
    "S4": ("each body is its own system", [(CC,
        "            systems.put(definition.id(), current.id());",
        "            systems.put(definition.id(), definition.id());")]),
    "S5": ("system known only when all bodies are known", [(SSK,
        ".stream().anyMatch(body -> PlanetaryDiscoveryPolicy.allows(body, discovered));",
        ".stream().allMatch(body -> PlanetaryDiscoveryPolicy.allows(body, discovered));")]),
    "S6": ("build.gradle no longer excludes the superseded v1.4 satellite copy", [("build.gradle",
        "        if ((details.file.toPath().startsWith(file('src/generated/v0.8/resources').toPath())\n"
        "                || details.file.toPath().startsWith(file('src/generated/v1.4/resources').toPath()))\n"
        "                && details.path == currentSatelliteDefinition) {\n"
        "            details.exclude()\n"
        "        }\n"
        "        boolean isHistoricalCopy = details.file.toPath().startsWith(\n"
        "                file('src/generated/resources').toPath()\n"
        "        ) || details.file.toPath().startsWith(\n"
        "                file('src/generated/v0.8/resources').toPath()\n"
        "        )\n"
        "        if (isHistoricalCopy && currentSupersededHistoricalBlockTags.contains(details.path)) {\n"
        "            details.exclude()\n"
        "        }\n"
        "        if (details.file.toPath().startsWith(file('src/generated/v0.3/resources').toPath())\n"
        "                && currentSupersededV030Types.contains(details.path)) {\n"
        "            details.exclude()\n"
        "        }\n"
        "    }\n"
        "}\n\ntasks.named('sourcesJar')",
        "        if (details.file.toPath().startsWith(file('src/generated/v0.8/resources').toPath())\n"
        "                && details.path == currentSatelliteDefinition) {\n"
        "            details.exclude()\n"
        "        }\n"
        "        boolean isHistoricalCopy = details.file.toPath().startsWith(\n"
        "                file('src/generated/resources').toPath()\n"
        "        ) || details.file.toPath().startsWith(\n"
        "                file('src/generated/v0.8/resources').toPath()\n"
        "        )\n"
        "        if (isHistoricalCopy && currentSupersededHistoricalBlockTags.contains(details.path)) {\n"
        "            details.exclude()\n"
        "        }\n"
        "        if (details.file.toPath().startsWith(file('src/generated/v0.3/resources').toPath())\n"
        "                && currentSupersededV030Types.contains(details.path)) {\n"
        "            details.exclude()\n"
        "        }\n"
        "    }\n"
        "}\n\ntasks.named('sourcesJar')")]),
    "C1": ("heap accounting factor back to 1", [(BIO,
        "    static final long HEAP_ACCOUNTING_FACTOR = 8L;", "    static final long HEAP_ACCOUNTING_FACTOR = 1L;")]),
    "C2": ("wrapped raw-quota breach not classified (exceeded() dropped)", [(BIO,
        "if (accounter.getUsage() > heapLimit || bounded.exceeded()) {", "if (accounter.getUsage() > heapLimit) {")]),
    "C3": ("gravity cooldown only after a committed write (30b9b11 change reverted)", [(GRAV,
        "        if (code != StationManagementCode.GRAVITY_UNCHANGED && code != StationManagementCode.STATION_CHANGED\n"
        "                && code != StationManagementCode.AUTHORITY_UNAVAILABLE) {",
        "        if (code == StationManagementCode.GRAVITY_SET) {")]),
}
TESTS = ["io.github.sunthemoon.advancedrocketrycommunity.station.*",
         "io.github.sunthemoon.advancedrocketrycommunity.persistence.*",
         "io.github.sunthemoon.advancedrocketrycommunity.celestial.*",
         "io.github.sunthemoon.advancedrocketrycommunity.diagnostics.*"]


def longpath(path):
    return B + B + "?" + B + os.path.abspath(path).replace("/", B)


def tally(results):
    failed, total = [], 0
    d = longpath(results)
    if not os.path.isdir(d):
        return failed, total
    for name in os.listdir(d):
        if not name.endswith(".xml"):
            continue
        root = ET.parse(d + B + name).getroot()
        for tc in root.iter("testcase"):
            total += 1
            if tc.find("failure") is not None or tc.find("error") is not None:
                failed.append(tc.get("classname").split(".")[-1] + "." + tc.get("name"))
    return failed, total


def run(mid, desc, edits):
    originals = {}
    for path, _, _ in edits:
        full = os.path.join(TREE, path)
        if full not in originals:
            with open(full, "rb") as f:
                originals[full] = f.read()
    try:
        for path, old, new in edits:
            full = os.path.join(TREE, path)
            with open(full, "r", encoding="utf-8", newline="") as f:
                text = f.read()
            n = text.count(old)
            if n != 1:
                raise SystemExit(f"{mid}: anchor count {n} in {path}")
            with open(full, "w", encoding="utf-8", newline="") as f:
                f.write(text.replace(old, new))
        results = os.path.join(TREE, "build", "test-results", "test")
        shutil.rmtree(longpath(results), ignore_errors=True)
        if any(path == "build.gradle" for path, _, _ in edits):
            # eachFile closures are not task inputs; force processResources to run again.
            shutil.rmtree(longpath(os.path.join(TREE, "build", "resources", "main")), ignore_errors=True)
        cmd = ["bash", "./gradlew", "test", "--offline", "--no-daemon", "--no-build-cache", "--console=plain"]
        for t in TESTS:
            cmd += ["--tests", t]
        env = dict(os.environ, JAVA_HOME="C:/Program Files/Java/jdk-17.0.7")
        start = time.time()
        p = subprocess.run(cmd, cwd=TREE, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
        with open(os.path.join(LOGS, f"mut-{mid}.log"), "w", encoding="utf-8") as f:
            f.write(f"MUTATION {mid}: {desc}\n")
            for path, old, new in edits:
                f.write(f"--- {path}\n-{old}\n+{new}\n")
            f.write(p.stdout)
            f.write(p.stderr)
            f.write(f"\nEXIT_CODE={p.returncode}\n")
        failed, total = tally(results)
        hint = ""
        if p.returncode != 0 and not failed:
            for line in (p.stdout + p.stderr).splitlines():
                low = line.lower()
                if "what went wrong" in low or "duplicate" in low or ": error:" in low or "execution failed" in low:
                    hint += line.strip()[:220] + " | "
        verdict = "KILLED" if p.returncode != 0 else "SURVIVED"
        line = (f"{mid}\t{verdict}\texit={p.returncode}\ttests={total}\tfailed={len(failed)}\t"
                f"{time.time() - start:.0f}s\t{desc}\t{'; '.join(failed[:8])}"
                f"{(' [no test failed; build: ' + hint + ']') if hint else ''}")
        print(line, flush=True)
        with open(os.path.join(LOGS, "mutation-results.tsv"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    finally:
        for full, data in originals.items():
            with open(full, "wb") as f:
                f.write(data)
        for full, data in originals.items():
            with open(full, "rb") as f:
                assert f.read() == data, full


MUT["S6b"] = ("S6 rerun with processResources output removed first", MUT["S6"][1])

if __name__ == "__main__":
    ids = sys.argv[1:] or list(MUT)
    for mid in ids:
        desc, edits = MUT[mid]
        run(mid, desc, edits)
