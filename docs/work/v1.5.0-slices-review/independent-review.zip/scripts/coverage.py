import json, subprocess
REPO = r"D:/GitHub/AdvancedRocketry-Community"
for commit, d in [("c5e213b","docs/work/v1.5.0-star-systems"),("30b9b11","docs/work/v1.5.0-station-capacity"),("9969550","docs/work/v1.5.0-warp-schema")]:
    changed = subprocess.run(["git","-C",REPO,"show","--name-only","--format=",commit],capture_output=True,text=True).stdout.split()
    ident = json.loads(subprocess.run(["git","-C",REPO,"show",f"{commit}:{d}/source-identity.json"],capture_output=True).stdout)
    paths = {f["path"] for f in ident["files"]}
    notcov = [c for c in changed if c not in paths and not c.startswith(d)]
    extra = [p for p in paths if p not in changed]
    print(commit, "changed(non-packet)=", len([c for c in changed if not c.startswith(d)]), "identity=", len(paths))
    print("  changed but not in identity:", notcov)
    print("  in identity but not changed:", extra)
