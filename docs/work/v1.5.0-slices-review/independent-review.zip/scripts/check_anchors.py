import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mutate  # noqa: E402

bad = 0
for mid, (desc, edits) in mutate.MUT.items():
    for path, old, new in edits:
        with open(os.path.join(mutate.TREE, path), encoding="utf-8", newline="") as f:
            count = f.read().count(old)
        if count != 1:
            bad += 1
            print("BAD", mid, path, count)
print("anchors checked; bad =", bad)
