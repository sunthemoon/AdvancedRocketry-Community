"""Independent decode of the WARP-02 native station files inside root-checks.zip (9969550)."""
import gzip
import io
import json
import struct
import sys
import zipfile


def read_nbt(data):
    stream = io.BytesIO(data)

    def u(fmt):
        size = struct.calcsize(fmt)
        return struct.unpack(">" + fmt, stream.read(size))[0]

    def string():
        length = u("H")
        return stream.read(length).decode("utf-8", "replace")

    def payload(tag):
        if tag == 1: return u("b")
        if tag == 2: return u("h")
        if tag == 3: return u("i")
        if tag == 4: return u("q")
        if tag == 5: return u("f")
        if tag == 6: return u("d")
        if tag == 7: return list(stream.read(u("i")))
        if tag == 8: return string()
        if tag == 9:
            element = u("b"); count = u("i")
            return [payload(element) for _ in range(count)]
        if tag == 10:
            result = {}
            while True:
                child = u("b")
                if child == 0:
                    return result
                name = string()
                result[name] = payload(child)
        if tag == 11: return [u("i") for _ in range(u("i"))]
        if tag == 12: return [u("q") for _ in range(u("i"))]
        raise ValueError(tag)

    root = u("b"); string()
    return payload(root)


def load(z, name):
    return read_nbt(gzip.decompress(z.read(name)))["data"]


z = zipfile.ZipFile(sys.argv[1])
before = load(z, "native/before/advancedrocketrycommunity_stations.dat")
upgrade = load(z, "native/upgrade/state/advancedrocketrycommunity_stations.dat")
restart = load(z, "native/restart/state/advancedrocketrycommunity_stations.dat")
print("before root:", before.get("schema_version"), before.get("format_epoch"), "warp_energy" in before,
      "stations:", len(before["stations"]), "reservations:", len(before["reservations"]))
print("upgrade root:", upgrade.get("schema_version"), upgrade.get("format_epoch"), upgrade.get("warp_energy"))
print("restart root:", restart.get("schema_version"), restart.get("format_epoch"), restart.get("warp_energy"))
changed = sorted(k for k in set(before) | set(upgrade) if before.get(k) != upgrade.get(k))
print("keys changed by upgrade:", changed)
print("upgrade == restart:", upgrade == restart)
print("stations identical before/upgrade:", before["stations"] == upgrade["stations"])
for station in upgrade["stations"]:
    print("  station", station.get("name"), "orbit", station.get("orbit_body"), "region", station.get("region"),
          "members", len(station.get("members", [])), "invitations", len(station.get("invitations", [])))
for backup in sorted({n.rsplit("/", 1)[0] for n in z.namelist() if n.startswith("native/migration-backups/")}):
    manifest = json.loads(z.read(backup + "/manifest.json"))
    rows = [(f["file"], f.get("role"), f.get("sourceSchema"), f.get("targetSchema")) for f in manifest["files"]]
    print(backup, rows)
