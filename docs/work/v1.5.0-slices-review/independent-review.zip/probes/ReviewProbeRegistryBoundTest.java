package io.github.sunthemoon.advancedrocketrycommunity.station.persistence;

import io.github.sunthemoon.advancedrocketrycommunity.ModIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.CheckedSavedDataFile;
import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.ManagedSavedDataType;
import io.github.sunthemoon.advancedrocketrycommunity.station.model.StationLimits;
import io.github.sunthemoon.advancedrocketrycommunity.station.model.StationState;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Independent-review probes (not part of the repository). */
final class ReviewProbeRegistryBoundTest {
    @TempDir Path root;

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    /** How many fully populated stations fit before the 4 MiB registry bound, and what fails then. */
    @Test
    void probeMaximalRecordsAgainstTheRegistryBound() throws Exception {
        StationRegistrySavedData data = new StationRegistrySavedData();
        String name = "鲸".repeat(StationLimits.MAX_NAME_LENGTH);
        ResourceLocation longBody = ModIdentity.id("b".repeat(128 - ModIdentity.MOD_ID.length() - 1));
        int count = 0;
        int maxRecord = 0;
        String failure = "none";
        UUID lastId = null;
        UUID firstId = null;
        while (count < StationLimits.MAX_STATIONS) {
            UUID id = new UUID(77L, count);
            try {
                data.reserve(id, new UUID(78L, count), name, longBody, Long.MAX_VALUE);
                data.commit(id);
                for (int m = 0; m < StationLimits.MAX_MEMBERS; m++) {
                    UUID member = new UUID(79L, count * 64L + m);
                    data.invite(id, member);
                    data.acceptInvitation(id, member);
                    data.invite(id, new UUID(80L, count * 64L + m));
                }
            } catch (RuntimeException exception) {
                failure = "mutation refused at station " + count + ": " + exception;
                break;
            }
            if (count == 0) {
                maxRecord = StationNbtSize.uncompressedBytes(
                        StationNbtCodec.encodeState(data.find(id).orElseThrow()));
                firstId = id;
                data.foldWarpCredits(Map.of(id, 5_000_000));
            }
            lastId = id;
            count++;
            if (count % 16 == 0) {
                try {
                    data.save(new CompoundTag());
                } catch (RuntimeException exception) {
                    failure = "ordinary save() throws with " + count + " committed stations (first failing 16-step): " + exception;
                    break;
                }
            }
        }
        System.out.printf("REVIEW_PROBE max_record_bytes=%d stations_committed=%d failure=%s%n", maxRecord, count, failure);
        // What does a checked write do once the registry is over its bound?
        Path file = root.resolve(ManagedSavedDataType.STATIONS.fileName());
        StationState observed = data.find(firstId).orElseThrow();
        String gravity;
        try {
            gravity = String.valueOf(data.checkedSetGravity(file, observed, 300, CheckedSavedDataFile::atomicMove));
        } catch (RuntimeException exception) {
            gravity = exception.toString();
        }
        String relocation;
        try {
            relocation = String.valueOf(data.checkedRelocation(file, observed, ModIdentity.id("moon"), 2_000_000,
                    CheckedSavedDataFile::atomicMove));
        } catch (RuntimeException exception) {
            relocation = exception.toString();
        }
        System.out.printf("REVIEW_PROBE over_bound checked_gravity=%s checked_relocation=%s balance=%d%n",
                gravity, relocation, data.warpEnergy(firstId));
        System.out.printf("REVIEW_PROBE over_bound new_entry_fold=%s%n", data.foldWarpCredits(Map.of(lastId, 1)));
    }

    /** A fold that meets an invalid credit mid-way leaves earlier credits applied but not dirty. */
    @Test
    void probePartialFoldOnInvalidCredit() {
        StationRegistrySavedData data = new StationRegistrySavedData();
        UUID first = new UUID(1L, 1L);
        UUID second = new UUID(2L, 2L);
        for (UUID id : new UUID[]{first, second}) {
            data.reserve(id, UUID.randomUUID(), "S" + id.getLeastSignificantBits(), ModIdentity.id("earth"), 0);
            data.commit(id);
        }
        data.setDirty(false);
        String outcome;
        try {
            outcome = String.valueOf(data.foldWarpCredits(Map.of(first, 100, second, -1)));
        } catch (RuntimeException exception) {
            outcome = exception.toString();
        }
        System.out.printf("REVIEW_PROBE partial_fold outcome=%s first_balance=%d dirty=%s%n",
                outcome, data.warpEnergy(first), data.isDirty());
    }
}
