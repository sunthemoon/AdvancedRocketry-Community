package io.github.sunthemoon.advancedrocketrycommunity.persistence.migration;

import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.GZIPOutputStream;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Independent-review probe (not part of the repository): a tiny gzip file whose NBT declares one
 * byte array just under the heap-accounting quota. NbtAccounter charges the declared length before
 * ByteArrayTag allocates it, so the allocation happens before the raw-byte quota can trip.
 */
final class ReviewProbeHeapQuotaTest {
    @TempDir Path root;

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    @Test
    void probeDeclaredArrayAllocationPerManagedType() throws Exception {
        System.out.printf("REVIEW_PROBE jvm_max_heap_bytes=%d factor=%d%n", Runtime.getRuntime().maxMemory(),
                BoundedSavedDataIo.HEAP_ACCOUNTING_FACTOR);
        for (ManagedSavedDataType type : ManagedSavedDataType.values()) {
            long rawQuota = type.maxCompressedBytes();
            long heapQuota = rawQuota * BoundedSavedDataIo.HEAP_ACCOUNTING_FACTOR;
            // Just under the heap quota (after the fixed per-tag charges), and also just above the raw quota.
            for (long declared : new long[]{rawQuota + 1, Math.min(Integer.MAX_VALUE - 8L, heapQuota - 1_000L)}) {
                Path file = root.resolve(type.fileName());
                Files.write(file, crafted((int) declared));
                String outcome;
                long start = System.nanoTime();
                try {
                    BoundedSavedDataIo.read(file, type);
                    outcome = "ACCEPTED";
                } catch (SavedDataMigrationException exception) {
                    outcome = "SavedDataMigrationException/" + exception.diagnosticId();
                } catch (Throwable throwable) {
                    outcome = throwable.getClass().getName();
                }
                System.out.printf("REVIEW_PROBE type=%s file_bytes=%d raw_quota=%d heap_quota=%d declared_array=%d outcome=%s ms=%.1f%n",
                        type, Files.size(file), rawQuota, heapQuota, declared, outcome, (System.nanoTime() - start) / 1e6);
                Files.delete(file);
            }
        }
    }

    /** Root compound "" { "data": byte[declared] } with no array bytes following (truncated). */
    private static byte[] crafted(int declared) throws Exception {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(raw)) {
            out.writeByte(10);
            out.writeUTF("");
            out.writeByte(7);
            out.writeUTF("data");
            out.writeInt(declared);
        }
        ByteArrayOutputStream compressed = new ByteArrayOutputStream();
        try (GZIPOutputStream gzip = new GZIPOutputStream(compressed)) {
            gzip.write(raw.toByteArray());
        }
        return compressed.toByteArray();
    }
}
