# Independent review: V150-STAR-02/03 (`c5e213b`), bounded-codec capacity fix (`30b9b11`), V150-WARP-02 (`9969550`)

Reviewer: independent reviewer (not the author). Date: 2026-09-30.
Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`.

| Slice | Commit | Base | Contract |
|---|---|---|---|
| STAR-02/03 star systems + Tau Ceti example | `c5e213bc4a923f2d30fac93fcfc55edf0bd23cf7` | `7180885` | ADR-043 (accepted) |
| Bounded-codec heap accounting + ORBIT-04 measurement | `30b9b1150d1b3085c23c19e097af2abf633edb8b` | `82568b8` | ADR-040/041 persistence rules |
| WARP-02 station root schema 4, balances, checked relocation | `99695505d2ba2d31fab1f67902d9dcf0c077f4e5` | `a001dc1` | ADR-044 rev. 3 §2, §3, §6 (accepted) |

**This is not a Gate approval.** It does not verify, accept or reject any leaf, ADR, version or release
on anyone's behalf, and it changes no status. It is evidence for the maintainer.

## Method

- Read-only on the repository. Only `git show`, `git diff`, `git log`, `git ls-tree`, `git grep` and
  `git archive` were used; the working tree (with concurrent WARP-03 edits) and the untracked private
  directory were not read. Everything below is from the committed trees.
- Read `AGENTS.md`, ADR-040, ADR-041, ADR-043, ADR-044 rev. 3, `docs/work/v1.5.0-implementation-log.md`,
  the three `VERIFICATION.md` packets and Part B of `docs/work/v1.5.0-star-warp-contracts/independent-review.zip`.
- Full diff review of all three commits (source, tests, build, generated data, docs).
- During the review the branch head advanced to `0416455` (another session, WARP-03 work, descending
  from `9969550`). That commit was not reviewed; all results here refer to the three named commits.
- Exports (`git archive <commit> | tar -x`) under this directory; Gradle with
  `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, `--offline --no-daemon`.
- Vanilla/Forge behaviour relied on below was confirmed by `javap -c` on the mapped Forge 47.4.10 jar
  (`evidence/javap-*.txt`): `ByteArrayTag` charges `NbtAccounter` and then allocates the declared array
  before reading it; `SavedData.save(File)` catches only `IOException` around the write, not around
  `save(CompoundTag)`; `DimensionDataStorage.save()` catches nothing.

### Commands actually run

| Command (in export) | Result | Log |
|---|---|---|
| `9969550`: `gradlew clean build test runData runGameTestServer --offline --no-daemon` | Exit 0, 3 m 10 s; JUnit 1,001 tests / 180 suites, 0 failures, 0 errors, 0 skipped; "All 240 required tests passed"; regenerated `src/generated` identical to the commit (258 files, 0 differences) | `evidence/baseline-9969550-full.log`, `evidence/baseline-9969550-junit-tally.txt`, `evidence/baseline-9969550-generated-diff.txt` |
| `9969550`: focused JUnit (station, persistence, celestial, diagnostics packages) as mutation baseline | Exit 0, 278 tests | `evidence/mutations/mut-BASE.log` |
| 27 single mutations (28 runs; S6 was rerun as S6b), each followed by the same focused JUnit set; every file restored and byte-compared after each run | See "Mutation results" | `evidence/mutations/` |
| Review probes (scratch tests copied only into the `9969550` export, never into the repository); the heap probe was also run once with the factor temporarily set to 1 in the export (restored and byte-compared) | See F1, F2, F3 | `probes/`, `evidence/probes-*.log`, `evidence/probe-*.txt` |
| `30b9b11`: `gradlew clean build test runData runGameTestServer` | Exit 0, 3 m 13 s; 975 JUnit / 177 suites, 0 failures; "All 239 required tests passed"; generated files unchanged (253) — matches the packet | `evidence/full-30b9b11.log`, `evidence/full-30b9b11-*.txt` |
| `c5e213b`: same | Exit 0, 3 m 6 s; 981 JUnit / 178 suites, 0 failures; "All 240 required tests passed"; generated files unchanged (258) — matches the packet | `evidence/full-c5e213b.log`, `evidence/full-c5e213b-*.txt` |
| Evidence integrity script over all three packets | 0 problems | `evidence/evidence-integrity.log`, `evidence/source-identity-coverage.log` |
| Independent NBT decode of the WARP-02 native station files | Matches the claims | `evidence/native-warp-schema-decode.txt` |

Timing lines (this machine): checked gravity write at 4,096 stations, median 176.5 ms at `30b9b11`,
173.0 ms at `c5e213b`, 190.8 ms at `9969550` (packet: 172 ms); region lookup 121-135 ns; full registry
raw 1,592,342 bytes (1,592,358 at root 4), heap accounted 9,023,141 (ratio 5.67), matching the capacity
packet.

## Verdicts

| Slice | Verdict | Why |
|---|---|---|
| `c5e213b` STAR-02/03 | **ACCEPT WITH CHANGES** | Implementation matches ADR-043 (derived systems, 16-root bound, whole-candidate cross-system route rejection on reload and initial load, knowledge without persistence, packaging exclusion, original example data). Changes requested are test-only: several ADR-043 verification items are covered weakly or not at all, including the 16-root boundary (F6). |
| `30b9b11` capacity fix | **ACCEPT WITH CHANGES** | The station defect is real and fixed, `exceeded()` is correct and tested. But the 8x heap factor is applied to every managed type, which raises the worst-case pre-allocation for a tiny crafted file to 537 MB (rocket transactions) and 1.18 GB (rocket transfers) and lets an `OutOfMemoryError` escape the fail-closed diagnostic path (F1). |
| `9969550` WARP-02 | **ACCEPT WITH CHANGES** | Schema 4, migration 1/2/3→4, balance validation, candidate verification, the single publish and every crash-cut row behave as ADR-044 §2/§3/§6 require; no path found that writes an inconsistent (orbit, balance) pair, charges twice or warps without a charge. Requested changes are small: make the fold validate its input before mutating (F3), state which ADR-044 §3 commit checks are caller obligations (F4), and correct the §2 capacity premise (F2, pre-existing). |

No Critical or High findings.

## Findings

Line numbers are at the reviewed commit named in each finding.

### F1 — Medium — `30b9b11`: the 8x heap quota applies to every managed type and lets a tiny file force a huge pre-allocation

- Where: `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/BoundedSavedDataIo.java:19-20, 35-37`
  (`HEAP_ACCOUNTING_FACTOR = 8L`; `heapLimit = expandedLimit * 8` for every `ManagedSavedDataType`).
- Mechanism: vanilla `NbtAccounter` is charged with the *declared* length of a byte/int/long array or list
  and the array is allocated before a single payload byte is read (confirmed by `javap`). Only the heap
  quota can stop that allocation; the raw-byte `QuotaInputStream` trips afterwards. The factor was measured
  for the station registry only (5.67), but it now multiplies the bounds of all five types:
  rocket transactions 64 MiB + 64 KiB → heap quota 537,395,200; rocket transfers → 1,175,453,696.
- Failure scenario (reproduced; `probes/ReviewProbeHeapQuotaTest.java`, outputs
  `evidence/probe-factor8-and-registry-output.txt` and `evidence/probe-heap-factor1-output.txt`):
  a 34-byte gzip file `advancedrocketrycommunity_rocket_transfers.dat` (or `..._rocket_transactions.dat`)
  whose root compound declares one byte array just under the heap quota. The pre-start migration reads
  every managed file at every start (`WorldDataMigrationService.discoverSources`).
  - At `30b9b11`/`9969550` in the default 512 MiB test JVM: `java.lang.OutOfMemoryError` for both rocket
    types. `OutOfMemoryError` is not caught by `BoundedSavedDataIo`, `WorldDataMigrationService` or
    `BetaWorldMigrationEvents.onServerAboutToStart` (which logs the operator guidance only for
    `SavedDataMigrationException`), so the start fails with an OOM instead of the ADR-040 diagnostic.
    The hook runs on `ServerAboutToStartEvent`, so an integrated (singleplayer) server opening a
    downloaded world is included. With a larger heap the read succeeds in allocating 0.5–1.2 GB
    transiently and then reports `INVALID_SCHEMA`.
  - With the factor reverted to 1 (pre-fix behaviour), the same files are refused with `OVERSIZED_DATA`
    before any allocation.
  - Station and satellite types stay harmless (34 MB quota).
  Vanilla's own SavedData reader is unbounded, so this is a regression of the project's bounded pre-start reader, not a new class
  of vanilla risk; it could reasonably be rated Low, but the fix widened a documented bound 8x for types
  that were not measured, and the packet mentions rocket transactions but not the larger rocket-transfer
  quota or the OOM path.
- Suggested fix (any one):
  1. per-type factors (8 only for `STATIONS`, 1 or a measured value elsewhere), or an absolute cap on the
     heap quota;
  2. better: subclass `NbtAccounter` (its `accountBytes` is public and not final) and refuse any *single*
     charge larger than the remaining raw-byte budget (x4 for list headers) before allocation, keeping 8x
     for the cumulative total;
  3. add a regression test per managed type with such a crafted small file, asserting
     `OVERSIZED_DATA` under the default test heap.

### F2 — Medium (pre-existing, not introduced by these commits) — the 4 MiB station-registry bound is not enforced on mutations; ADR-044 §2's capacity premise holds only for minimal records

- Where (`9969550`): `station/persistence/StationRegistrySavedData.java:493-495` (encode throws
  `IllegalStateException` above 4 MiB); `station/model/StationRegistryModel.java:25, 91, 99` (`reserve`,
  `addMember`, `invite`, …) accept growth without a registry-size check; `station/model/StationLimits.java:25-26`.
- Measured (`probes/ReviewProbeRegistryBoundTest.java`, `evidence/probe-factor8-and-registry-output.txt`): a fully populated record (48 three-byte-UTF-8 characters,
  128-character orbit ID, 32 members, 32 invitations) is 2,276 bytes. The ordinary `save()` throws once
  about 1,856 such stations exist (first failing step of 16) — far below the 4,096-station limit.
  ADR-044 §2 says the balance list fits "inside the 4 MiB registry bound together with 4,096 records
  (measured 1.59 MB)"; 1.59 MB is the minimal-record case.
- Failure scenario: a large server grows teams until the encoded registry exceeds 4 MiB. The next
  autosave calls `StationRegistrySavedData.save`, which throws; vanilla does not catch it
  (`SavedData.save(File)` guards only the write, `DimensionDataStorage.save` guards nothing), so the save
  and server tick fail and every in-memory change since the last good save is lost. After the overflow,
  `checkedSetGravity`, `checkedExpand` and `checkedRelocation` throw `IllegalStateException` before any
  write (fail closed, confirmed by the probe), and new balance entries are refused (headroom false), so
  WARP-02's own paths stay consistent.
- Suggested fix: refuse the mutation instead of failing the save — an admission check (cheap upper bound,
  exact encode only when needed, as `hasWarpEntryHeadroom` already does) in `reserve`/`commit`/`invite`/
  `addMember`/`acceptInvitation`/`transferOwnership`, or reduce per-record bounds so that
  4,096 × max record + 64 × max reservation + 256 KiB ≤ 4 MiB. Correct the ADR-044 §2 budget sentence.
  Track it for WARP-05/MIG-02 at the latest.

### F3 — Low — `9969550`: `foldWarpCredits` is not atomic for invalid input

- Where: `station/persistence/StationRegistrySavedData.java:205-233` with
  `station/model/StationRegistryModel.java:177-181`.
- Scenario (reproduced by `ReviewProbeRegistryBoundTest.probePartialFoldOnInvalidCredit`): `foldWarpCredits(Map.of(a, 100, b, -1))` with `a < b`. The loop credits
  `a`, then `creditWarpEnergy(b, -1)` throws `IllegalArgumentException`. Result: `a`'s balance is 100 in
  memory, `isDirty() == false`, and no `WarpCreditFold` is returned. If WARP-03 keeps its pending map when
  the fold throws and retries, `a` is credited twice; if nothing else dirties the registry before a stop,
  the credit exists only in memory. A `null` value (NPE on unboxing) behaves the same.
- Suggested fix: validate the whole map first (non-null keys/values, `0 <= value <= MAX_WARP_ENERGY`,
  size ≤ 4,096) and refuse it as a whole, or mark dirty in a `finally` when anything was credited; add a
  test.

### F4 — Low — `9969550`: ADR-044 §3 commit-check items not implemented at the registry level, without a stated hand-off

- Where: `station/persistence/StationRegistrySavedData.java:299-312, 332-359`.
- ADR-044 §3 says the registry-level `checkedRelocation(observed, target, cost)` requires, among others,
  "the target is valid at commit", "the live balance after a fold is at least cost" and "cost equals the
  confirmed cost". The method checks operational/quarantine, live == observed, exactly one orbit relocation,
  and balance ≥ cost; it accepts any `ResourceLocation` (unknown, non-orbitable, or not known to the actor)
  and never folds. `VERIFICATION.md` lists the remaining work as WARP-03 but does not name these checks.
- Scenario: a WARP-03 caller that trusts the method's name and ADR wording relocates a station to a
  missing or undiscovered body, or commits with a stale cost, and the registry accepts it.
- Suggested fix: state in the Javadoc and in ADR-044 §3 (or the WARP-02 packet) that target validity, the
  fold and the confirmed-cost equality are caller obligations of the WARP-03 commit step, and cover them in
  WARP-03 tests; or pass a validated target/cost value object into `checkedRelocation`.

### F5 — Low — `9969550`: defense-in-depth checks are not proven by any test

- Mutations W1 (skip the balance comparison in candidate verification), W6 (compare only the replaced
  station), W7 (skip reservations) and W5 (one of the three root<4 `warp_energy` guards removed) all
  survive. This is expected — the candidate is encoded from the same registry it is compared with, and the root-shape guard
  is repeated in `StationRegistryPayload.upgrade/decode` — but it means the verification step itself is
  untested; W3 shows the on-disk pair assertions still catch an encode bug when verification is also broken.
- Suggested fix: a package-private seam to corrupt the candidate (e.g. an encode hook in tests) with a test
  that expects `IllegalStateException` and an untouched file; assert the migration diagnostic *message*
  for the root-shape cases so the first guard is observable.

### F6 — Low — `c5e213b`: ADR-043 verification items only partly covered

- ADR-043 "Verification" asks for GameTests: "reload with the example system; rocket planner cannot reach
  it; a data-satellite discovery makes it known".
  - `StarSystemGameTests` (`gametest/StarSystemGameTests.java:46`) calls `CelestialSavedData.discover`
    directly instead of completing a data-satellite mission for `tau_ceti_e`.
  - No test asks the rocket planner (`RocketTargetFlightPlanner`) for a route from Earth orbit to
    `tau_ceti_e` or to a station orbiting it (UNSUPPORTED_ROUTE expected). By inspection the planner is a
    pure route-graph Dijkstra with no implicit edges, so the rule holds today, but nothing pins it.
  - No reload GameTest.
  - The exactly-16-roots boundary is untested (mutation S3 survives).
- Suggested fix: add these tests in STAR-03 or WARP-03 (the WARP-03 cross-system warp test is a natural
  place for the planner assertion).

### F7 — Low — `30b9b11`: the new raw-bound test is weak

- Where: `src/test/java/.../persistence/migration/BoundedSavedDataIoCapacityTest.java:69-86`.
- It asserts only `SavedDataMigrationException`, not `OVERSIZED_DATA`, so it would pass if the raw-quota
  breach were misreported as `INVALID_SCHEMA`. (Mutation C2 is still killed, by the unchanged
  `WorldDataMigrationServiceTest.compressedAndExpandedSizeLimitsFailClosed`.) The comment says
  "incompressible-enough filler", but `('a' + (index * 7919) % 26)` has period 26 and is highly
  compressible; the test still works because it only needs to pass the compressed-size precheck, so the
  comment is simply wrong.
- Suggested fix: assert the diagnostic ID; fix the comment.

### F8 — Low — `30b9b11`: cooldown after a failed gravity write is untested

- Where: `station/service/StationGravityService.java:58-62`.
- Mutation C3 (revert to "cooldown only after `GRAVITY_SET`") survives JUnit, and the only GameTest
  cooldown assertion (`StationOrbitGameTests.java:110`) covers a committed write. The confirmation-review
  note this change addresses is therefore closed without a regression test.
- Suggested fix: a unit test with a failing committer (the service needs a small seam) or a GameTest that
  forces `WRITE_FAILED`.

### F9 — Info — `9969550`: failed focused-run logs not retained

`focused-runs.txt` in `root-checks.zip` summarizes runs 01-02 (12/149 and 2/169 failures) with "full logs
were not captured"; the earlier packets retained failed runs. The summary is consistent with the diff
(pinned root-3 values, fixture UUID constants) and no assertion was removed.

### F10 — Info — `9969550`: reader-side atomicity relies on server-thread confinement

`encode` (`StationRegistrySavedData.java:472-497`) and `requireValidCandidate` read `stations()`,
`reservations()` and `warpEnergyBalances()` in separate synchronized calls. With `relocateChecked`
being "one synchronized publish", a second thread could still observe a new orbit with an old balance
between two reads. All current callers are on the server thread, so this is not a bug; either document
the confinement or add one snapshot method under a single lock.

### F11 — Info — `9969550`: epoch/shape rules are tied to "current" instead of to root 4

`ManagedSavedDataType.formatEpoch(int)` (`:94-102`) returns `v1.5.0-station-warp` only for
`REGISTRY_SCHEMA_VERSION`, `validateRootShape` uses `schema >= REGISTRY_SCHEMA_VERSION`, and
`StationRegistryPayload.upgrade` (`:26-43`) rejects any older root carrying `warp_energy`. When root 5 is
introduced, root-4 files would be refused as "invalid format epoch" or "cannot carry warp energy" unless
these are rewritten. A `WARP_REGISTRY_SCHEMA_VERSION = 4` constant now would avoid the trap.

### F12 — Info — `c5e213b`: other compatibility notes

- The two packaged example bodies count toward the 128-body cap: a data pack that added 121-122 bodies is
  now rejected as a whole (ADR-043 lists only the 16-root and cross-system rules as compatibility impact).
- `VERIFICATION.md` lists "star-map grouping" as not done, while ADR-043's "or group roots" option is met
  by the existing per-root rows; worth one sentence in the packet.
- `BootstrapDataGenerators` no longer runs the v1.4 providers (frozen v1.4 output, same pattern as earlier
  versions): later edits to `PlanetaryContent` would silently not reach the packaged v1.4 JSON.

## Checked and found correct

WARP-02 (`9969550`):
- **Schema table (§6)**: roots 1-3 with any `warp_energy` tag are refused (three independent guards: root
  shape, `upgrade`, `decode`); root 4 requires a `warp_energy` list of compounds; epochs are checked per
  schema (2 `v0.9.0-beta`, 3 `v1.5.0-orbital-station`, 4 `v1.5.0-station-warp`) and mixed combinations
  are refused; root 5 is `FUTURE`; runtime load of anything but root 4 is blocked and preserved.
- **Migration**: 1→4 and 2→4 go through record 1→2 with strict geometry; 3→4 adds only an empty list and
  keeps every other tag; the result is `CURRENT` on a second pass (idempotent). The backup manifest already
  records source/target schema per file (`WorldDataMigrationService.java:305-312`). Independent decode of
  the native files: only `schema_version`, `format_epoch` and `warp_energy=[]` changed, restart state
  identical, backup manifest station 3→4.
- **Balances**: strictly typed (`TAG_INT`, `hasUUID`), exactly two keys, ≤ 64 bytes (47 in a list),
  1..10,000,000, unique, owned by a committed station, ≤ 4,096; encoded in UUID order; zero balances are
  never stored.
- **Predicate**: `isOrbitRelocationOf` compares every field (`StationState.equals` is complete) except the
  orbit, independent of `sameAuthorityAs`; the cost-0 path (`isCheckedUpdateOf`) still refuses any orbit
  change before any write (tested).
- **Candidate verification**: decodes the candidate through the migrator and compares the full station
  list (with the substitution), the reservation list and the full balance map (with the debit or removal)
  with the live registry; all types involved have complete `equals`. Growth and gravity candidates now
  compare balances too.
- **`relocateChecked`**: re-checks the predicate, cost and observed state/balance, then does a `put` on an
  existing key and a replace/remove of an existing balance entry — nothing fallible remains after the
  checks.
- **Headroom**: the cheap bound `1,024 + (stations + reservations) × 8,192 + entries × 64` is a true upper
  bound (records are capped at 8,192 as standalone roots; list elements carry less overhead; root keys are
  about 150 bytes); the exact encode compares with 4 MiB − 256 KiB. One check per fold is safe because at
  most 4,096 entries × 47 bytes can be added.
- **Crash-cut matrix**: each row maps to code (`checked`, `resolveReplacement`) and to a fault-injection
  test; in every case the readable registry holds (old orbit, old balance) or (new orbit, debited balance).
  A retry after success is `STALE`; the same target is `UNCHANGED`; no charge without a committed
  relocation.
- **Tests**: no assertion was removed or loosened; pinned values changed to the exact root-4 values and new
  refusal cases were added (`StationSchemaMigrationTest`, `StationWorldMigrationTest`,
  `SavedDataSchemaMigratorTest`, `BetaOperationalReportTest`, `PopulatedWorldDataPreservationTest`).

STAR (`c5e213b`):
- System derivation is a bounded parent walk (depth < 128) over a catalog whose parents and acyclicity are
  validated first; `systems()` is in ID order; the 16-root check runs inside `CelestialCatalog.create`.
- `PlanetaryCatalog.create` rejects any route whose endpoints lie in different systems, so the whole reload
  candidate fails and the previous pair stays; the initial load throws "Initial planetary catalog is
  invalid … connects systems" (tested with real pack files).
- Rocket planning (`RocketTargetFlightPlanner`, `RoutePlanner`) uses only route edges, including for
  station targets (`orbit(station.orbitBody)`), so rockets cannot cross systems; admin flights use the same
  planner.
- Knowledge: body known = no discovery required or recorded; system known = any body known; the command
  treats a non-writable discovery file as "nothing discovered" (fail closed); no new persistence.
- Packaging: the v1.4 `data_satellite.json` is excluded from `processResources` and `sourcesJar`; the test
  classpath resolves the v1.5 copy (`PlanetaryDiscoveryTest`), and dropping the exclusion breaks a clean
  build (mutation S6b; an incremental build does not notice, S6). Example data is original, inside schema
  bounds, and the star is public and not a satellite target. Test updates (`PlanetaryDiscoveryTest` 6→7 targets plus superset check, `BootstrapGameTests` 6→8
  bodies) are exact.

Capacity (`30b9b11`):
- The station defect and its measurement reproduce (ratio 5.67). The raw-byte quota remains the size
  bound; `exceeded()` is set before the quota exception and survives `NbtIo` wrapping it in a
  `ReportedException`; removing it is caught by the unchanged compression-bomb test (mutation C2).
- The confirmation-review notes on `2fb9bce` are addressed: the pre-write refusal is now tested (by
  inspection, removing the guard would reach the throwing committer and fail the new assertion; not run
  here), failed writes start the cooldown (but see F8), and the wording is corrected.

## Mutation results

Each mutation was applied alone to an export of `9969550` (which contains all three slices; the STAR and
capacity code is unchanged since its own commit), followed by the focused JUnit set (packages `station`,
`persistence`, `celestial`, `diagnostics`; 278 tests; baseline passes). Files were restored and
byte-compared after every run. Script: `scripts/mutate.py`; per-mutation logs: `evidence/mutations/`.
GameTests were not rerun per mutation.

| ID | Mutation | Result | Caught by |
|---|---|---|---|
| W1 | Candidate verification skips the balance comparison | Survived | — (defense in depth, F5) |
| W2 | Candidate encode ignores the debit (verification intact) | Killed | 8 `StationWarpRelocationTest` cases (verification throws before any write) |
| W3 | W1 + W2 together | Killed | 5 `StationWarpRelocationTest` cases via on-disk (orbit, balance) pair checks |
| W4 | Relocation publish drops the balance debit | Killed | 4 `StationWarpRelocationTest` cases |
| W5 | Root-shape check allows `warp_energy` in roots 1-3 (one of three guards) | Survived | — (the `upgrade`/`decode` guards still refuse; F5) |
| W5b | All three root<4 `warp_energy` guards removed | Killed | `StationWarpSchemaTest.rootShapeAndEpochAreChosenBySchema`, `StationWorldMigrationTest.unsupportedGeometry…` |
| W6 | Verification compares only the replaced station | Survived | — (F5) |
| W7 | Verification skips reservations | Survived | — (F5) |
| W8 | No `INSUFFICIENT_ENERGY` pre-check | Killed | `insufficientEnergyAndSameOrbitWriteNothing` |
| W9 | `relocateChecked` ignores the observed balance | Killed | `modelPublishesOnlyAnExactRelocationWithTheObservedBalance` |
| W10 | `isOrbitRelocationOf` compares only the orbit | Killed | `modelPublishesOnlyAnExactRelocationWithTheObservedBalance` |
| W11 | Model delete keeps the balance | Killed | `creditsAreCappedOwnedByCommittedStationsAndDroppedWithTheStation` |
| W12 | Fold ignores the entry headroom | Killed | `aNewBalanceEntryIsRefusedWhenTheRegistryIsNearItsBound` |
| W13 | Headroom exact check against 4 MiB instead of 4 MiB − 256 KiB | Killed | same |
| W14 | Orphaned balances accepted on decode | Killed | `everyMalformedBalanceBlocksTheRegistryUnchanged` |
| W15 | Root 1-3 upgrade does not add the list | Killed | `PopulatedWorldDataPreservationTest` (all types), `ManagedSavedDataLoaderMigrationTest`, … |
| W16 | Relocation published through `replaceChecked` | Killed | 5 `StationWarpRelocationTest` cases (publish throws → OUTCOME_UNKNOWN) |
| W17 | Root-shape check accepts root 4 without the list | Killed | `rootShapeAndEpochAreChosenBySchema` |
| S1 | Cross-system route rejection removed | Killed | `PlanetaryReloadTest` (reload and initial load), `StarSystemContentTest` |
| S2 | 16-system bound removed | Killed | `PlanetaryReloadTest.tooManyStarSystemsRejectTheReload` |
| S3 | Bound off by one (exactly 16 roots rejected) | **Survived** | — (boundary untested, F6) |
| S4 | Every body is its own system | Killed | `PlanetaryReloadTest`, `PlanetaryBindingsTest` and others |
| S5 | System known only when all bodies are known | Killed | `StarSystemContentTest.systemKnowledgeFollowsBodyDiscovery` |
| S6 | `build.gradle` no longer excludes the v1.4 satellite copy (incremental build) | Survived | — `processResources` stayed UP-TO-DATE: the `eachFile` closure is not a task input |
| S6b | Same, with `build/resources/main` removed first | Killed | Build: `processResources` fails, "data_satellite.json is a duplicate but no duplicate handling strategy has been set" |
| C1 | Heap factor back to 1 | Killed | `BoundedSavedDataIoCapacityTest`, `StationCheckedUpdateScaleTest` |
| C2 | `exceeded()` dropped from the classification | Killed | `WorldDataMigrationServiceTest.compressedAndExpandedSizeLimitsFailClosed` (not by the new capacity test, F7) |
| C3 | Gravity cooldown only after a committed write (30b9b11 change reverted) | **Survived** | — (F8; the only GameTest cooldown check covers a committed write) |

Summary: 21 of 27 distinct mutations killed (S6 and S6b are one mutation, counted as killed by a clean
build). The survivors are defense-in-depth checks (W1, W5, W6, W7), the 16-root boundary (S3) and the
failed-write cooldown (C3). S6 is caught by any clean build (the required commands start with `clean`),
but an incremental build does not notice a change to the packaging rule.

## Evidence integrity

For each packet (`v1.5.0-star-systems`, `v1.5.0-station-capacity`, `v1.5.0-warp-schema`):
- every `SHA256SUMS.txt` line matches the committed blob;
- `evidence-archives.json` bytes, SHA-256 and member count match `root-checks.zip` (552, 232, 234 members);
- every ZIP member's size and SHA-256 matches `root-checks-files.json`, with none missing or extra;
- every `source-identity.json` entry matches the blob at the commit, and the entries cover exactly the
  commit's changed files outside the packet (25, 9, 23).
Script and output: `scripts/verify_evidence.py`, `scripts/coverage.py`, `evidence/evidence-integrity.log`,
`evidence/source-identity-coverage.log`.

## Required changes

1. **F1** (`30b9b11`): stop the 8x heap quota from permitting a large single pre-allocation for the rocket
   types (per-type factor, absolute cap, or a single-charge guard), with a crafted-small-file regression
   test per managed type asserting `OVERSIZED_DATA`.
2. **F3** (`9969550`): validate the fold input as a whole before mutating (or mark dirty in `finally`),
   with a test.
3. **F4** (`9969550`): record in the Javadoc and ADR-044 §3 / the WARP-02 packet which commit checks are
   caller obligations for WARP-03, and test them there.
4. **F2** (pre-existing): correct the ADR-044 §2 capacity sentence now; add a registry-size admission check
   (or re-derive bounds) before WARP-05/MIG-02 closes.
5. **F6/F7/F8**: add the missing tests (planner cannot reach Tau Ceti e, mission-based discovery, reload,
   16-root boundary, diagnostic ID in the raw-bound test, cooldown after a failed write).

F5 and F9-F12 are recommendations.

## Residual risks

- WARP-02 has no production caller: the fold, headroom and relocation paths are exercised by unit tests
  only. Correct behaviour of the whole warp depends on WARP-03 (fold before request/commit, target and cost
  checks, cooldown, one commit per tick, cache invalidation for orbit-derived context).
- Crash cuts are fault injection, not power loss; durability still rests on ADR-040/041 assumptions
  (same-directory atomic move, no directory fsync claim), and the vanilla ordinary save is non-atomic.
- Forge Energy duplication/loss around crashes (ADR-044 §3 disclosure) is accepted by the ADR, not solved.
- Timing figures come from one development machine; the 4,096-station checked write is a 173-191 ms
  server-thread spike.
- GameTests were run once per reviewed commit (three full runs); mutations were judged with focused JUnit
  only, so a mutation marked SURVIVED could in principle be caught by a GameTest (checked by search for C3).
- V1/V2 client evidence, native multi-player and performance acceptance remain open, as the packets state.

## Statement

This review is independent evidence for the maintainer. It is **not** a Gate approval, it does not mark
any leaf verified or accepted, and it does not change any version, leaf or release status.
