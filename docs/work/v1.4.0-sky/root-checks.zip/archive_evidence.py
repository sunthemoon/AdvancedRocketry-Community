"""Archive observed SKY checks without changing the original evidence bytes."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/work/v1.4.0-sky'
BASE = '251de231612049f62721f8911a4f402a4f1157d0'
PRIOR = TEMP.parent / 'arce-v140-nav-6fae0c34ff8247e5a5834a9520b71249/artifacts'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def bundle(name, groups):
    entries = []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            if path.is_file():
                relative = path.relative_to(source).as_posix() if source.is_dir() else path.name
                entries.append((prefix + '/' + relative if prefix else relative, path))
    entries.sort()
    assert len(entries) == len({key for key, _ in entries})
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in entries:
            data = path.read_bytes()
            archive.writestr(key, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)


def junit(folder):
    suites = [ET.parse(path).getroot() for path in sorted((TEMP / folder).glob('*.xml'))]
    assert suites, folder
    return {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
                                  for key in ('tests', 'failures', 'errors', 'skipped')}}


def archive(reviews):
    groups = [('', path) for path in sorted(TEMP.glob('*.log'))]
    groups += [('', TEMP / 'inspect_failed_pads.py'), ('', TEMP / 'archive_evidence.py')]
    groups += [(path.name, path) for path in sorted(TEMP.iterdir()) if path.is_dir()
               and (path.name.endswith('-xml') or path.name.endswith('-gametest-logs') or path.name == 'clean-all-01-gametest')]
    bundle('root-checks', groups)
    bundle('failed-world', [('', TEMP / 'clean-all-02-gametest')])
    bundle('native-restart', [('', TEMP / 'native')])
    native = json.loads((TEMP / 'native/summary.json').read_text(encoding='utf-8'))
    assert native['result'] == 'PASS'
    write('native-summary.json', native)
    bundle('independent-review', [(path.name, path) for path in reviews])
    result = junit('clean-all-03-xml')
    assert result['failures'] == result['errors'] == result['skipped'] == 0
    log = (TEMP / 'clean-all-03.log').read_text(encoding='utf-8')
    assert 'BUILD SUCCESSFUL' in log
    required = re.findall(r'All (\d+) required tests passed', log)
    assert required
    prior_attempts = {path.name: junit(path.name) for path in sorted(TEMP.glob('*-xml')) if path.name != 'clean-all-03-xml'}
    write('root-checks.json', {
        'base_commit': BASE, 'junit': result, 'required_gametests_passed': int(required[-1]),
        'command': 'gradlew.bat clean build runData runGameTestServer --console=plain',
        'exit_code': 0, 'duration': re.findall(r'BUILD SUCCESSFUL in (.+)', log)[-1],
        'prior_junit_attempts': prior_attempts,
        'failed_world': {'command_log': 'clean-all-02.log', 'required_gametests': 233, 'failed': 4, 'exit_code': 1,
                         'archive': 'failed-world.zip', 'seed': 5912724636835073799},
        'scope': 'Short development checks, not real-client/GPU/load/release acceptance'})
    artifacts = []
    for path in sorted((TEMP / 'artifacts').glob('*.jar')):
        data = path.read_bytes()
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': sha(data)})
        assert data == (ROOT / 'build/libs' / path.name).read_bytes(), path
    assert len(artifacts) == 3
    api = next(path for path in (TEMP / 'artifacts').glob('*-api.jar'))
    assert api.read_bytes() == (PRIOR / api.name).read_bytes()
    write('development-artifacts.json', {'artifacts': artifacts, 'public_api_unchanged': True, 'api_version': '1.7'})
    resources = ROOT / 'src/generated/v1.4/resources'
    rows = []
    with zipfile.ZipFile(TEMP / 'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar') as jar:
        assert len(jar.namelist()) == len(set(jar.namelist()))
        for path in sorted(resources.rglob('*.json')):
            if '.cache' in path.parts:
                continue
            data = path.read_bytes()
            entry = path.relative_to(resources).as_posix()
            assert jar.read(entry) == data, entry
            rows.append({'path': path.relative_to(ROOT).as_posix(), 'jar_entry': entry, 'bytes': len(data), 'sha256': sha(data)})
    assert len(rows) == 33
    write('generated-resources.json', rows)


def finalize():
    for name in ('SHA256SUMS.txt', 'links.json'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii', newline='\n')
    files = git('diff', '--cached', '--name-only', BASE).decode().splitlines()
    rows, documents = [], []
    for relative in files:
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if relative.endswith('.md'):
            documents.append(relative)
        if relative.startswith('docs/work/v1.4.0-sky/'):
            continue
        staged, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
        assert staged == working.replace(b'\r\n', b'\n'), relative
        rows.append({'path': relative, 'bytes': len(staged), 'sha256': sha(staged), 'working_sha256': sha(working),
                     'git_blob': git('rev-parse', ':' + relative).decode().strip()})
    write('source-identity.json', {'base_commit': BASE, 'files': rows,
          'scope': 'Changed staged inputs outside evidence; raw worktree digests identify executed inputs'})
    links = []
    for relative in documents:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
            assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
            links.append({'document': relative, 'target': target, 'exists': True})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets, not URLs/anchors', 'links': links})
    for listing in OUT.glob('*-files.json'):
        with zipfile.ZipFile(listing.with_name(listing.name.replace('-files.json', '.zip'))) as archive:
            assert archive.testzip() is None
            expected = json.loads(listing.read_text(encoding='utf-8'))
            assert set(archive.namelist()) == {row['path'] for row in expected}
            for row in expected:
                data = archive.read(row['path'])
                assert len(data) == row['bytes'] and sha(data) == row['sha256']
    members = sorted(path for path in OUT.iterdir() if path.is_file() and path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(path.read_bytes())}  {path.name}\n' for path in members),
                                      encoding='ascii', newline='\n')
    print(f'PASS: {len(links)} local links and {len(members)} evidence members verified')


def check_index():
    for path in OUT.iterdir():
        if path.is_file():
            assert git('show', ':' + path.relative_to(ROOT).as_posix()) == path.read_bytes(), path
    for line in (OUT / 'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
        digest, relative = line.split('  ', 1)
        assert sha((OUT / relative).read_bytes()) == digest, relative
    print('PASS: staged evidence bytes and complete evidence manifest')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, action='append')
    parser.add_argument('--finalize', action='store_true')
    parser.add_argument('--check-index', action='store_true')
    args = parser.parse_args()
    if args.review:
        archive(args.review)
    if args.finalize:
        finalize()
    if args.check_index:
        check_index()
