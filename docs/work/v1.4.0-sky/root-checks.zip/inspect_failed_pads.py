import json
import sys
from pathlib import Path

sys.path.insert(0, 'D:/GitHub/AdvancedRocketry-Community')
from scripts import v120_precision_world_fixture as f
from scripts import inspect_celestial_saved_data as n

n.MAX_TAGS = 50000  # Read-only diagnostic includes level.dat's registry metadata.
from scripts.run_v140_celestial_schema_smoke import read_nbt

root = Path(__file__).parent / 'clean-all-02-gametest/world'
data = read_nbt(root / 'level.dat')['Data']
print(json.dumps({key: value for key, value in data.items() if 'Spawn' in key or 'Border' in key}, sort_keys=True))
print('seed', data['WorldGenSettings']['seed'])
cache = {}

def chunk(x, z):
    cx, cz = x >> 4, z >> 4
    key = cx, cz
    if key not in cache:
        region = (root / f'region/r.{cx >> 5}.{cz >> 5}.mca').read_bytes()
        cache[key] = f._decode_chunk(f._region_chunk(region, cx, cz), cx, cz)
    return cache[key]

def entry(words, index, bits):
    per = 64 // bits
    return (words[index // per] >> ((index % per) * bits)) & ((1 << bits) - 1)

def block(x, y, z):
    sections = chunk(x, z)['sections']
    section = next((section for section in sections if section['Y'] == y >> 4), None)
    if section is None or 'block_states' not in section:
        return 'minecraft:air'
    states = section['block_states']
    palette = states['palette']
    if len(palette) == 1:
        return palette[0]['Name']
    index = ((y & 15) << 8) | ((z & 15) << 4) | (x & 15)
    return palette[entry(states['data'], index, max(4, (len(palette) - 1).bit_length()))]['Name']

for dx, dz in [(0,0),(64,0),(-64,0),(0,64),(0,-64),(64,64),(-64,64),(64,-64)]:
    x, z = data['SpawnX'] + dx, data['SpawnZ'] + dz
    heights = {}
    for xx in range(x-1, x+2):
        for zz in range(z-1, z+2):
            h = chunk(xx, zz)['Heightmaps']['MOTION_BLOCKING_NO_LEAVES']
            heights[(xx,zz)] = entry(h, (zz & 15)*16+(xx & 15), 9) - 64
    y = max(heights.values())
    print('PAD', x, z, 'heightmap', sorted(heights.items()), 'nonair',
          [(xx, yy, zz, block(xx,yy,zz)) for xx in range(x-1,x+2)
           for zz in range(z-1,z+2) for yy in range(y-1,y+4) if block(xx,yy,zz) != 'minecraft:air'])
