# V140-SKY independent contract review

## Findings, ordered by severity

### P2 resolved: one effects adapter did not define preservation of existing Space effects

Initial ADR-036:19-26 selected one `planetary` effects ID while promising unchanged lighting and vanilla fallback. Existing `src/generated/v0.3/resources/data/advancedrocketrycommunity/dimension_type/space.json:5` selects `minecraft:the_end`; Moon and the two current planetary types select `minecraft:overworld`. Effects are not only a sky callback: the pinned End effects constructor supplies END, no ground, no clouds and `forceBrightLightmap=true`, while Overworld supplies NORMAL, ground, cloud height 192 and `forceBrightLightmap=false`. `LightTexture` reads the latter flag directly; `LevelRenderer` uses the selected effects object's sky type after a custom callback returns false. Equal DimensionType JSON except `effects` alone could therefore not establish the promised client-lighting/fallback behavior.

**Resolution inspected:** revised ADR-036:19-32 uses separate `planetary` and `planetary_space` IDs, preserves the appropriate ground/lightmap flags and NORMAL/END fallback, delegates platform fog/sunrise behavior, and expressly identifies cloud/rain suppression as a visual change. This resolves the contract ambiguity without a save/Level/body identity change. Actual implementation and its tests remain to be reviewed.

### P2 resolved: a far-plane-only bound did not preserve fog distance strength

Initial ADR-036:50-51 bounded only fog far distance while claiming visibility never extends. With an allowed start fraction .95, unchanged far 128 and profile end 512, a new near 121.6 can exceed the incoming near. Pinned ordinary 1.20.1 terrain fog computes near as `far - clamp(far / 10, 4, 64)`, which is 115.2 at far 128. Thus far-plane equality did not prevent weakening distance fog across part of the interval.

**Resolution inspected:** revised ADR-036:58-63 fixes `newFar=min(incomingFar, profileEnd)` and `newNear=min(incomingNear, newFar*startFraction)`, retains the incoming shape, and leaves invalid incoming ranges untouched. Neither plane increases. This resolves the distance-policy gap; the existing fluid/status-preservation requirement still needs implementation guards.

The initial parent message used a .75R shorthand for vanilla near; pinned bytecode subsequently established the actual formula above, and that correction was explicitly sent to root. The example did not determine the resolution: any permitted incoming near below .95R demonstrates the original gap.

### P3 clarifications resolved

- Profile resource IDs now share the existing **128-character** identifier bound (ADR:33-34; `celestial/model/BoundedCelestialCodecs.java:17,70-74`). This prevents reachable profile identifiers from having a different bound than synchronized selectors.
- GPU allocation/upload/close is now explicitly **render-thread-owned**, and preparation never touches GPU state (ADR:51-56). Pinned `SimplePreparableReloadListener` dispatches preparation and application via distinct supplied executors; a generic reference to the reload executor was insufficient lifecycle guidance.
- The **400 unpaused-client-tick** additional-audio cooldown survives world/profile/reload/logout transitions rather than allowing repeated immediate starts (ADR:66-73). Stopping the owned sound remains separate from resetting eligibility.

No remaining concrete contract blocker was identified in the revised document. This is not an implementation result, acceptance vote or Required Gate approval. The reviewed document remains `PROPOSED` in the preserved snapshot.

## Actual repository/platform constraints inspected

- Base HEAD `251de231612049f62721f8911a4f402a4f1157d0`, branch `codex/v1.4.0-planetary-expansion`. Read AGENTS, PROJECT-CONFIG, PRODUCT, porting/version/master-test/Gate rules, v1.0+ roadmap and budgets, parallel-review and visual-environment rules, current v1.4 plan and active SKY-01..04 leaves (`docs/work/v1.4.0-implementation-log.md:60-91`). Current gates remain open; ADR-018 defers full visual/multiplayer acceptance rather than passing it.
- `celestial/network/CelestialSnapshot.java:24-53` already carries bounded Level, visual profile, pressure and solar intensity display values. `CelestialClientCache` retains the last valid snapshot on malformed data and clears via `client/ClientCelestialEvents.java:19-21`. The new selector must use the active Level and this bounded snapshot, handle absent/ambiguous matching, and not invent station-orbit authority for shared Space.
- `celestial/data/BoundedDefinitionJson.java:22-45,90-133` accepts a caller-selected byte cap no greater than 32768, strict UTF-8, depth 16, duplicate-key rejection and exact JSON lexical checks. The proposed 16384-byte profile cap can reuse this without widening server data limits. Resource enumeration is not a world scan; reject over-count before decoding an unbounded set.
- Existing client registrations are isolated through `Dist.CLIENT` in `client/ClientBootstrap.java:16-21`. Forge's client-only mod-bus `RegisterDimensionSpecialEffectsEvent` and `RegisterClientReloadListenersEvent`, plus Forge-bus `ViewportEvent` hooks, are applicable without an AT or ASM.
- Pinned `IForgeDimensionSpecialEffects.renderSky` includes the PoseStack and `setupFog` callback. In mapped `LevelRenderer.renderSky`, custom effects run at bytecode offset 24, **before** setupFog at 33 and the vanilla fluid/status checks at 43-72. The custom renderer must explicitly honor the contract's fog/fluid/status restrictions and establish/restore its own affected state; returning true cannot rely on later vanilla guards being reached.
- Forge `ViewportEvent.RenderFog` changes take effect only when cancelled; `ComputeFogColor` is separate and not cancellable. This makes it necessary to preserve fluid/status color as well as terrain distances, not just to skip one of these events.
- `build.gradle:112-162` already keeps historical generated roots with narrowly scoped `processResources` and `sourcesJar` exclusions. The two new dimension-type supersessions should follow the same narrow pattern. No historical byte rewrite, duplicate archive path or global replacement of vanilla effects is required.
- No copied platform/upstream artwork is proposed. Cached platform sources/bytecode were inspected only as API behavior evidence, not copied into repository production code.

## Required finite follow-up verification (not executed here)

1. Codec/resource tests: required/missing/null/wrong-type fields; strict integers and finite numeric limits; malformed UTF-8, duplicate keys, depth, 16384/16385-byte and 128/129-file boundaries; resource-ID bound; whole-candidate rejection retaining the last valid map and deterministic initial defaults.
2. Selection/reload tests: active surface and generic Space, absent or ambiguous Level mapping, missing profile, switching bodies and disconnect; no use of previous-body mutable selection or server-only world access.
3. Effects/fog tests: separate platform flags/fallback identity, suppression choices, min-near/min-far and unchanged shape, invalid incoming ranges, fluid/powder-snow/blindness/darkness guards in both color and distance handling. Source inspection should confirm callback ordering and state restoration in finally.
4. Finite geometry/resource tests: actual fixed vertex/index bounds, no per-frame upload, close/reset/failure lifecycle and render-thread ownership. Headless tests cannot establish a working GL resource lifecycle by themselves.
5. Audio state tests: one owned non-looping sound, cooldown across all specified transitions, missing sound silence, stop on loss of exposure, no native audio muting. Real audible results remain unverified.
6. The planned short build/DataGen/GameTest, packaged restart/sidedness and independent key reruns; old type JSON equality except effects, duplicate-free main/sources JARs, and unchanged API artifact. Keep genuine GPU V1/V2 manual observations separately pending.

These checks support the finite SKY leaves; they do not replace the broader v1.4 or release acceptance matrix. Root retains implementation/approval ownership.

## Commands actually run and limitations

Read-only Git `rev-parse HEAD`, scoped status/diff-check; PowerShell `Get-Content`, `rg`/`rg --files`, scoped cache listings and hashes. Local Java17 `javap -c -p` inspected DimensionSpecialEffects and its Overworld/End variants, LevelRenderer, FogRenderer, LightTexture and SimplePreparableReloadListener. Python `-B`/zipfile read four pinned Forge source entries into this Temp review directory. Scoped `git diff --check` completed exit 0. Two exploratory lookups used nonexistent local cache/source paths, reported those errors, and were corrected to the actual pinned source JAR and `celestial/CelestialDefaults.java`; neither was a build/test attempt.

No Gradle, test, Minecraft client/server, remote, network, process termination, Git/index mutation, OpenPet call, delegation or excluded user-document read occurred. Repository files remain untouched. All report/snapshot writes are confined to this Temp directory. Implementation, GL state restoration, audio, resource reload execution, packaged bytes, visual quality/performance and actual end-to-end client behavior are not verified in this contract task.

Reviewed revised ADR SHA-256: `01c421d0ee3b8f60c8454d5431b9911d7fa75b74a9d8b6e1c1c1166310acb680`. Work-log SHA-256: `1508370b6ea3fb12f8d772b8916c8ab96bfcfa58b2f6c6e23ac3872505c9ddbc`. Original/revised snapshots, relevant source identities, full pinned bytecode and Forge source evidence are retained beside this report. Pinned mapped Forge JAR: `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`; source JAR: `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
