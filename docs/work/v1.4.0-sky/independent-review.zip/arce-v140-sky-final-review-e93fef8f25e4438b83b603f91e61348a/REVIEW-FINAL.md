# V140-SKY final independent review and bounded verification

## Findings first

**No unresolved concrete finding in the reviewed final SKY/fixture scope.** This does not establish real-GPU correctness, full version acceptance or any Gate approval.

Previously reported issues are retained, not erased:
- P2 render-state restoration: final SkyRenderState.java:30-58 and PlanetarySkyRenderer.java:35-78 capture/restore the mutated flags, blend factors/equations, bindings/program and managed shader/color. The original default-reset implementation was corrected.
- P3 logout failure latch: PlanetarySkyClient.java:61-75 now distinguishes logout from resource reload; PlanetarySkyRenderer.java:115-122 releases buffers without clearing failed except on reload.
- P2 Earth-return fixture precondition: the failed random world had snow at all eight computed landing planes. EarthReturnPadFixture.java:35-57,89-158 provisions/restores one bounded owned floor; its additive regression :59-86 preserves snow/grass refusal. Flight production, original scenario assertions and timeouts remain unchanged. The inherited RocketMaintenanceStructureTest stays unchanged; the added case resides in the new fixture class.

The state-guard fake test verifies scoped capture/restore control flow, not actual OpenGL driver behavior. Known conservative refusal of naturally obstructed Earth pads remains an explicit runtime policy/limitation, not silently changed by this fixture fix.

## Completed and not completed

Completed: contract/source/incremental review; native diagnosis of the retained failed GameTest world; final fixture review; forced focused JUnit; DataGen; independent reused-world GameTests; published archive/API/generated-resource comparison; read-only raw native packaged upgrade/restart audit. Root remained sole repository writer.

Not completed: client launch, V1 on two GPU families, V2/two clients, audible playback assessment, real resource-reload visual continuity, shader-mod compatibility, frame-time/state-query cost, forced-stop/S2, whole-world migration or long-load acceptance. No such result is inferred from server tests.

## Identity and changed-file boundary

Repository baseline and reviewed HEAD at input capture: `251de231612049f62721f8911a4f402a4f1157d0`. Root may subsequently commit these same reviewed bytes; such a pointer is not a new build claim.

`inputs-before.json` / `inputs-after.json` compare **1,187 files**, covering main/test/adapter-test sources and resources, generated resources (excluding generator caches), build/settings/properties/wrapper inputs. All hashes remained equal across the independent commands. `tracked-diff-before.patch` preserves the tracked change set; new source identities were recorded in earlier source reviews. No tracked/index edit was made by this reviewer. Root's documentation/evidence-only edits are outside this code-input equality statement.

Reviewed additions/change domains: celestial/visual; client/sky and client bootstrap; sky datagen and narrowly scoped old Moon/Space resource exclusions; four profiles/four effects IDs in type resources; sky tests; dedicated-effects GameTest; EarthReturnPadFixture; ADR/guide/provenance/manual cases. No new API export, save schema, network protocol or flight authority mutation was found. Common visual code has no client imports; physical client adapters are Dist.CLIENT event subscribers.

## Independently executed commands and results

Environment: Windows PowerShell, Java `C:/Program Files/Java/jdk-17.0.7`, Python `D:/python/pyenv/pyenv-win/shims/python.bat`, PYTHONUTF8=1. All Gradle commands were serialized in the explicitly delegated exclusive build slot, offline; no clean/world deletion.

```text
.\gradlew.bat test --tests '*SkyProfileTest' --tests '*SkySelectionTest' --tests '*SkyMathTest' --tests '*SkyResourcesTest' --tests '*AmbientControllerTest' --tests '*SkyProfileReloadTest' --tests '*SkyRenderStateTest' --tests '*PlanetaryEffectsTest' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

- **Exit 0**, measured **47.7983514 s**; all 16 Gradle tasks executed.
- **25 JUnit tests / 8 suites / 0 failures / 0 errors / 0 skipped**, independently counted from retained XML.
- Per class: AmbientController 3; SkyMath 3; SkyProfile 4; SkyResources 2; SkySelection 4; PlanetaryEffects 2; SkyProfileReload 6; SkyRenderState 1.
- `focused-junit.log`, `focused-junit-receipt.json`, `focused-counts.json`, `focused-xml/` retain original command/results. Seven compile warnings and Gradle deprecation text remain in the log.

```text
.\gradlew.bat runData runGameTestServer --offline --no-daemon --no-build-cache --console=plain
```

- **Exit 0**, measured **132.8924247 s**; reused `build/gametest/world` left by root's clean-all-03 (not the earlier failed seed world).
- DataGen: **33 current-version files, written 0**. Existing tracked generated differences belong to the planned SKY change; equality before/after proves this execution introduced no content delta.
- **All 234 required GameTests passed.** All four Earth-return batch hooks installed 25 floor cells and logged restoration of 25 cells; no unexpected failed-test marker. Existing deliberate save-failure tests still produce their injected error logs.
- Retained ordinary timing warning: **2140 ms / 42 ticks behind**. This is not performance acceptance.
- `datagen-gametest.log`, `datagen-gametest-receipt.json`, `gametest-logs/`, `postcheck.json` retain execution and cleanup evidence.

Both Gradle processes are terminal; the exclusive slot was explicitly **released to root** after copying logs and completing source/JAR hash comparisons. No additional JVM is requested or pending.

Other executed checks: read-only Git diff/status/source inspection and `git diff --check` (exit 0); Python -B archive/raw-native/hash helpers (results below); pinned Java 17 javap inspections in prior reports. No Python unittest was independently repeated in this final slice; the SKY scope added Java tests, not a new Python runner.

### Root execution distinction

Root's `fixture-reused-world-02.log` actually executed all 891 JUnit tests and the same previously failed world's 234 GameTests; it succeeded in 2m48s. Root's later clean-all-03 succeeded in 3m1s with 234 GameTests and DataGen written 0, but its `:test FROM-CACHE` restored the **891-test / 163-suite** XML. This report does not count that clean run as a fresh full JUnit execution. The independent 25-test run above was forced and actually executed.

## Artifact / packaging audit

Frozen SKY artifacts and all three build/libs files after independent checks agree exactly:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Main | 2,594,614 | 676f4c0421a80f7b3dd8a732c77186306799fee4d8f88750d1bc30fb2bf26aea |
| API | 48,469 | 50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf |
| Sources | 1,180,375 | d7f11442a26b3329d065e09ef775a6cbed73a67469cf3b25b95aaeebe822722c |

`audit_artifacts.py` exited 0; `artifact-audit.json` retains exact entry deltas:
- All three ZIPs pass CRC and unique-entry checks; no adapter-test package/resources leaked.
- **27 API classes**, each byte-identical to its main-JAR class; the complete API artifact is **byte-identical to NAV**.
- All **33 current-version JSON resources** exactly equal their unique main/sources members.
- Historical Moon/Space JSON differs from new packaged JSON **only in effects**; historical source bytes remain preserved.
- Main vs NAV changes are confined to expected sky/profile/client/datagen/fixture classes and four dimension-type resources; no production flight class differs.

## Native packaged audit — raw files, not only summary

Audited immutable root captures at `C:/Users/Administrator/AppData/Local/Temp/arce-v140-sky-8bdcd66a68c54fefadc350434c25b4fb/native`. The reviewer did not launch or modify these worlds.

`audit-native.py` verifies **138 unique SHA256SUMS members**, path containment and every raw file digest; manifest SHA-256 `5bbd02f760fc32f06fd144c5e3deb96bf3f5374359385551db2b175e4d78d50e`. It checks actual launch commands/artifact bytes, phase exit receipts, raw stdout/latest/debug logs, all retained entity-region Anvil allocations/NBT, native station/transfers files, binding JSON, world marker and properties. It does not merely trust decoded `entity-regions.json`: raw entity roots are decoded independently then compared with that projection.

Observed:
- Three phases baseline/upgrade/restart each exited **0**, logged save/stop completion; no ERROR/FATAL in any of the three log variants. Stdout warnings remain **25 / 10 / 10** respectively; configuration/default/offline/Forge warnings are retained, not suppressed.
- Baseline actually uses older MAP-01 main SHA `9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`; upgrade/restart use the final SKY main `676f4c04...`. This is an older-development-world upgrade regression, not a release-to-release or client sky observation.
- Each stopped capture contains exactly **one** rocket across all retained bounded entity regions. Logical identity and owner agree; native dimensions, origins, state, snapshots and receipt IDs agree with raw command/log observations.
- Fuel begins **2000**, then raw/log-bound debits **448, 533, 515** produce **1552 -> 1019 -> 504**. Final restart remains **504**; native debit transaction IDs exactly match each leg once.
- Six relative blocks, palette, bounding box, mass inputs, passenger anchors and schema are conserved from baseline to final landing. Cargo is exactly **17 diamonds + 64 iron ingots** in the captured vanilla-container adapter payload. Full final RocketEntityData is identical between upgrade and restart; no active plan/transfer in the landed entity.
- One final COMMITTED transfer reservation remains, bound to the last transfer and exact destination snapshot. Its source fuel is 1019, required fuel 515, destination fuel 504. Upgrade/restart journal bytes match.
- Stations grow **1 -> 3 -> 3** with exact IDs/owners/names/orbit bodies matching command requests; baseline station remains, upgrade/restart full native station state and bytes match.
- Body/Level binding entries grow **3 -> 6 -> 6**; original reservations remain, upgrade/restart full binding JSON matches. Same-world marker identity and normalized server.properties remain equal. Raw level.dat files are manifest-bound but not fully decoded here; whole-world byte immutability is not claimed.

Preserved audit-helper attempts: first adapted raw audit passed; an extra conservation assertion used nonexistent key `bounds` and raised **KeyError** in `audit-native-02-schema-error.py/.log`. It was corrected to the actual saved `bounding_box` plus palette/mass/anchors/schema, without changing captures or weakening predicates. Final helper exited 0. Original attempts remain intact. This helper schema error is not a runtime/test failure.

Native coverage is operator-driven finite travel, side isolation, authority/resource preservation and clean restart only. It does not render the custom sky, play audio, exercise client packets/multiplayer, or prove any visual Gate.

## Prior evidence identities and remaining scope

`prior-reviews.json` records immutable full paths and these hashes:
- Contract: `4e892e0015d93aab4d4cf8225627c16d05ffb51d4d766854247fa4ce4686fbb9`
- Original source: `8d5848cf6c1434f5a97667767fcebce523b12800fb3155315bf1b0433ff122b5`
- Incremental render/lifecycle: `7b8f5ccb5cad1a97e0d79734d8d059c52ee764c5d62a6a7073f73c83398cd043`
- Retained failure/native diagnosis/final fixture: `ef5330e8e708e23d29af8087ea43c4a34872256243cca4877529e75b5c7386a9`

The prior report includes the original two source findings, failed clean-world evidence, maintenance-inventory failure and timing overlap between a source read and root's regression-method move. Their original versions are retained; the final location/identities are explicit.

No repository source modification was made by the reviewer. Build/cache/test-world writes occurred only through authorized Gradle commands; notes/helpers/XML/log copies are in this fresh Temp review directory. The excluded user documentation bundle was never inspected. No remote/client/soak/extra-agent/OpenPet action occurred.

**All Required Gates are not established.** V1/V2 and the other deferred/full acceptance work remain open under the recorded project policy. Suggested next action is archive this bounded evidence and continue only the remaining current-v1.4 work; no release/tag/approval is recommended by this scoped review.
