from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path(r'D:/GitHub/AdvancedRocketry-Community')
OUT=Path(__file__).parent
SKY=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-sky-8bdcd66a68c54fefadc350434c25b4fb')
NAV=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-nav-6fae0c34ff8247e5a5834a9520b71249/artifacts')
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def entries(p):
 with zipfile.ZipFile(p) as z:
  names=z.namelist();assert len(names)==len(set(names)),p
  assert z.testzip() is None,p
  return {name:sha(z.read(name)) for name in names if not name.endswith('/')}
paths=set()
for dirname in ['src/main','src/test','src/adapterTest','src/generated']:
 for p in (ROOT/dirname).rglob('*'):
  if p.is_file() and '.cache' not in p.parts:paths.add(p)
for name in ['build.gradle','settings.gradle','gradle.properties','gradle/wrapper/gradle-wrapper.properties']:paths.add(ROOT/name)
source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(paths)}
(OUT/'inputs-before.json').write_text(json.dumps(source,indent=2),encoding='utf-8')
(OUT/'reviewed-head.txt').write_bytes(git('rev-parse','HEAD'))
(OUT/'tracked-diff-before.patch').write_bytes(git('diff','251de231612049f62721f8911a4f402a4f1157d0'))
artifacts={}
archives={}
for p in sorted((SKY/'artifacts').glob('*.jar')):
 kind='api' if p.name.endswith('-api.jar') else 'sources' if p.name.endswith('-sources.jar') else 'main'
 archives[kind]=entries(p)
 before=entries(NAV/p.name)
 artifacts[kind]={'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'nav_sha256':sha((NAV/p.name).read_bytes()),'entry_count':len(archives[kind]),'added':sorted(archives[kind].keys()-before.keys()),'removed':sorted(before.keys()-archives[kind].keys()),'changed':sorted(k for k in before.keys()&archives[kind].keys() if before[k]!=archives[kind][k])}
 assert not any('arceadaptertest' in k or 'arce_adapter_test' in k for k in archives[kind]),kind
assert artifacts['api']['sha256']==artifacts['api']['nav_sha256']
api_classes={k:v for k,v in archives['api'].items() if k.endswith('.class')}
assert len(api_classes)==27,len(api_classes)
assert all(archives['main'].get(k)==v for k,v in api_classes.items())
generated={}
for p in sorted((ROOT/'src/generated/v1.4/resources').rglob('*.json')):
 if '.cache' in p.parts:continue
 name=p.relative_to(ROOT/'src/generated/v1.4/resources').as_posix();data=p.read_bytes();json.loads(data)
 assert archives['main'].get(name)==sha(data),name
 assert archives['sources'].get(name)==sha(data),name
 generated[name]=sha(data)
assert len(generated)==33,len(generated)
for body in ['moon','space']:
 name=f'data/advancedrocketrycommunity/dimension_type/{body}.json'
 old=json.loads((ROOT/'src/generated/v0.3/resources'/name).read_bytes())
 new=json.loads((ROOT/'src/generated/v1.4/resources'/name).read_bytes())
 assert set(old)==set(new)
 assert [k for k in old if old[k]!=new[k]]==['effects']
 common='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/visual'
for p in (ROOT/common).glob('*.java'):
 assert b'net.minecraft.client.' not in p.read_bytes(),p
result={'source_input_count':len(source),'artifacts':artifacts,'api_classes':sorted(api_classes),'generated_count':len(generated),'generated':generated,'notes':['All ZIPs CRC-tested and entry names unique.','API byte-identical to NAV and each of 27 exported classes equals main.','Historical Moon/Space only effects differs; package member uniquely maps to v1.4 bytes.','No fixture package/resources in three published JARs.','Static common visual-package import check only; native side isolation not established by this helper.']}
(OUT/'artifact-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'input_count':len(source),'generated_count':len(generated),'artifacts':{k:{x:v[x] for x in ['sha256','bytes','entry_count']} for k,v in artifacts.items()},'main_delta':{k:artifacts['main'][k] for k in ['added','changed','removed']}},indent=2))
