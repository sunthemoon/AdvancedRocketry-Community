# V140-SKY incremental source review

## Findings / resolution

No additional unresolved finding in this four-file correction after the final blend-equation addition was inspected. This is a source/pinned-bytecode conclusion, not real-GPU or Gate approval.

- **Prior P2 addressed in source:** SkyRenderState captures the incoming blend enable/four factors/two equations, cull enable, depth-write, VAO, array-buffer and current program (lines 30-47), restoring them with the platform wrappers or direct separate-equation API (lines 50-58). PlanetarySkyRenderer captures before upload, restores shader/color, clears the ShaderInstance program cache and closes the state guard in finally (lines 35-38,72-78). The final renderer sets FUNC_ADD explicitly before drawing (line 49), rather than relying on a prior BlendMode cache state.
- The first incremental read omitted blend equations. Independent pinned bytecode inspection identified ShaderInstance.apply -> BlendMode.apply -> RenderSystem.blendEquation; this was sent to root. Root had added the two equations immediately before that message. The final files were reread and hashed; the observation is resolved, not an outstanding defect.
- **Prior P3 addressed in source:** PlanetarySkyClient.logout invokes cleanup(false), resource reload invokes cleanup(true), and only the latter calls renderer.resourceReloaded. Renderer.close releases buffers without clearing failed; resourceReloaded explicitly clears it (client lines 61-75; renderer lines 115-122). Session audio cooldown remains untouched by either cleanup.

## Pinned platform evidence

Local mapped Forge 1.20.1-47.4.10 JAR, SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`, read using Java 17 javap only:

- ShaderInstance.clear sets program 0, lastProgramId=-1 and lastAppliedShader=null; it does not reset BlendMode's cache. The correction clears this cache before restoring the externally bound program.
- ShaderInstance.apply calls BlendMode.apply. BlendMode.apply can call RenderSystem.blendEquation; this justified capturing both equations. GlStateManager._blendEquation directly calls GL14.glBlendEquation without a hidden equation cache, so GL20.glBlendEquationSeparate restoration does not desynchronize that wrapper cache.
- ProgramManager.glUseProgram delegates to the render-thread checked GlStateManager call. VertexBuffer.drawWithShader applies and clears the ShaderInstance; explicit final clear also handles an interrupted apply/draw sequence.
- These are inspections of pinned platform bytecode, not copied production code or GPU execution. Full dumps are retained beside this report.

## Test scope and limits

SkyRenderStateTest uses a fake Access/state to check capture once/restore once for successful scope, pre-mutation failure and post-mutation failure, including distinct RGB/alpha equations. It establishes the guard's scoped restoration control flow. It does **not** execute OPEN_GL, prove the driver state values on a live context, exercise actual VertexBuffer upload/draw failure, or measure per-frame readback cost. Failure-latch behavior is checked here by source inspection; no new executable lifecycle result is claimed.

The state guard performs a fixed number of queries; actual GPU correctness/performance and arbitrary shader/resource-pack modifications still need client evidence. Exceptions from a broken GL context or from the cleanup calls themselves are not sandboxed by these pure tests. No expansion into driver fault injection is requested by this review.

## Actual commands and identities

- Read-only Get-Content/numbered listings for the four changed files; Select-String for final blend equation/failure-latch integration; Get-FileHash — exit 0.
- `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -classpath <pinned mapped Forge JAR> -p -c` for ShaderInstance, ProgramManager, BlendMode, VertexBuffer and GlStateManager — exit 0; original output retained as five `.txt` files.
- `git diff --check` — exit 0, no whitespace errors.
- `D:/python/pyenv/pyenv-win/shims/python.bat -B -`, with PYTHONUTF8=1, finite Temp-only copy/hash helper — exit 0; four final source snapshots in source/, identities in source-identities.json.
- One tool orchestration JavaScript syntax error occurred before shell execution while requesting the final read; no command ran or repository file changed. The request was corrected and the listed read succeeded.

Final identities:

| File | SHA-256 |
|---|---|
| SkyRenderState.java | 766ea348a3f1fb7803b6f50a66b390aa7c4c18236c4086623831a16a3eb1adea |
| SkyRenderStateTest.java | a9412c7aeecb3907d33a8f6d8cc24c6602dd5a48c4a35a75100c16d84faceb14 |
| PlanetarySkyRenderer.java | f2b9d3816fbca794d13dfa4e56df3180c3e8db2b4114169b45bb4a5d4f0c9055 |
| PlanetarySkyClient.java | b3d77ee85d9a67ce1ca2c7b5cc0cea6e1feecfa1ebea6d50841f444445408079 |

No Gradle, tests, client/server, remote commands, tracked edits or index mutations were performed. Root-reported pre-fix 890 JUnit / 233 GameTests are not independently repeated or attributed to these final corrections. Independent executable verification awaits root's exclusive slot. The original source report and its findings remain unchanged at `C:/Users/Administrator/AppData/Local/Temp/arce-v140-sky-source-review-589df13352214b97990bbd2cead56b1c/REVIEW-SOURCE-01.md` (SHA-256 `8d5848cf6c1434f5a97667767fcebce523b12800fb3155315bf1b0433ff122b5`).
