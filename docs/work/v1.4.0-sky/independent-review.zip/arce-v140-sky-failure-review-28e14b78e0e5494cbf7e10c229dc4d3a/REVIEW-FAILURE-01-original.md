# V140-SKY clean-all-02 failure diagnosis — independent read-only review

## Findings

**P2 — Four success-path GameTests depend on an unprovisioned random Earth landing surface.** The failed world's eight fixed arrival candidates all have natural snow occupying the computed rocket bottom plane. Production conservatively refuses non-air; the success-path fixtures only load chunks and remove rocket entities, without establishing an available Earth arrival location. The evidence supports a fixture terrain-precondition defect, not a SKY flight regression. It does not justify deleting vegetation or weakening production collision checks.

Exact source references:
- `rocket/transfer/RocketLandingPadSelector.java:56-64,273-293`: Overworld candidates are shared spawn plus eight fixed offsets; landing Y uses maximum MOTION_BLOCKING_NO_LEAVES across the rocket's actual columns.
- Same file `:188-201`: every restored rocket-block position must be air and have no block entity. Snow, grass and leaves are not air even when ignored by the chosen heightmap.
- `gametest/RocketFlightGameTestFixtures.java:132-154`: primePadChunks loads/tickets candidates; clearPadRockets removes entities. Neither creates an empty arrival corridor.
- `gametest/RocketFlightGameTests.java:47-123,127-153,287-295`: station and Moon success paths expect an Earth landing without provisioning it.
- `gametest/PlanetaryWorldGameTests.java:88-112`: Earth/Mars/Venus/Earth success similarly expects the unprovisioned Earth leg.
- `gametest/PlanetaryAdmissionGameTests.java:127-191`: authorized station departure tests source admission but its launch necessarily also selects an Earth arrival.

`git diff <baseline> --` for the production selector and three inherited flight/admission fixture files was empty. SKY adds only the separate dimension-effects GameTest to PlanetaryWorldGameTests; its existing round-trip method is unchanged. No causal client-renderer connection is established by these server failures.

## Actual failure evidence

Original `clean-all-02.log` is retained byte-for-byte as `clean-all-02-original.log`. It ends BUILD FAILED in 3m 27s, native GameTest exit 4; 233 tests completed / 4 required failures:

| Test | Failure log line | Observed result |
|---|---:|---|
| earthMoonRoundTripConservesFuelAndBlockedPadReturnsSource | 435 | Moon-to-Earth LANDING_PAD_UNAVAILABLE |
| earthStationEarthUsesApprovedPadAndPreservesNeighborSpace | 587 | Station-to-Earth LANDING_PAD_UNAVAILABLE |
| earthMarsVenusEarthKeepsOneRocketAndExactFuelDebits | 974 | Venus-to-Earth LANDING_PAD_UNAVAILABLE |
| closedOrbitStationCanDepartButStillRequiresLiveMembership | 1587 | Authorized departure never entered countdown; lines 1583-1584 show the same destination rejection |

Each rejection exhausted 8 candidates, with 8 chunk-position requests for four-block rockets or 16 for the wider planetary rocket. No timeout/assertion change is needed to explain the result.

Independent read of the archived root JUnit XML: **891 tests / 163 suites / 0 failures / 0 errors / 0 skipped**; the full log shows `:test` executed, not FROM-CACHE. This is a readback of root execution, not an independent rerun.

## Independent native readback

Read ONLY root's stopped archived world under `clean-all-02-gametest/world`. Retained helper `inspect_archived_pads.py` and output `pad-observations.json` bind the raw level.dat and all inspected region hashes. World identity:
- Spawn `(0,60,0)`, angle 0.
- Seed `5912724636835073799`.
- Overworld generator `minecraft:noise`, settings/preset `minecraft:overworld`.

For the actual two-column and three-column rocket footprint shapes used by these fixtures, the helper independently decoded section palettes/packed block states and MOTION_BLOCKING_NO_LEAVES heights. Every candidate has at least one `minecraft:snow` at the calculated bottom plane:

| Candidate X/Z | Two-/three-column arrival Y |
|---|---|
| 0,0 | 64 / 64 |
| 64,0 | 64 / 64 |
| -64,0 | 52 / 52 |
| 0,64 | 66 / 66 |
| 0,-64 | 70 / 70 |
| 64,64 | 65 / 65 |
| -64,64 | 71 / 71 |
| 64,-64 | 64 / 64 |

The initial bounded read also observed ordinary grass and spruce leaves near some columns; the retained exact footprint oracle alone already establishes snow obstruction for all eight choices. It requires all 16 footprint observations to be occupied and exited 0.

This is a stopped-world reconstruction, not a captured live predicate result at each failed tick. It cannot independently prove the absence of additional entity/reservation obstacles at those earlier instants. The terrain is sufficient to reproduce the selector's non-air refusal from saved state. The passing clean-all-01 world was not retained, so no passing-seed comparison is claimed.

The supplemental helper uses the repository NBT parser with a process-local 131,072-tag cap for registry-heavy level.dat, a 4 MiB decompression bound, and existing bounded region/chunk decoding. It does not change the production or canonical small-SavedData parser limits and writes only this Temp directory.

## Minimal remedy and pinned batch lifecycle

Recommended scoped correction: fixture-owned bounded Earth floor/air corridor at one normal server-selected shared-spawn candidate. Root's proposed 5x5 stone floor above maximum **WORLD_SURFACE**, preflighted wholly in air, is consistent with that approach: no arbitrary seed selection, destructive world clearing, new production pad policy, increased search budgets or weakened flight/fuel assertions. Record/reinstate every changed block; reject unexpected block entities/ownership conflicts. Keep the platform alive for the entire asynchronous flight batch.

Paired BeforeBatch/AfterBatch hooks are appropriate for normal successful/failed tests. Pinned mapped Forge 47.4.10 bytecode retained here establishes:
- GameTestBatchRunner.runBatch calls BeforeBatch at offsets 81-86 **before** constructing the completion tracker/listener at 89-131.
- GameTestBatchRunner$1.testPassed and testFailed both invoke testCompleted.
- testCompleted invokes AfterBatch once the tracker is done, then advances to the next batch.
- MultipleTestTracker.isDone checks done-count == total-count, not all-tests-passed.

**Setup caveat:** a BeforeBatch exception has no installed completion listener, so partial provisioning must restore in its own catch/finally before rethrowing. A hard process termination also cannot guarantee AfterBatch; this is bounded GameTest cleanup, not crash durability. The lifecycle should remain one explicitly owned active fixture, not global world/entity/journal cleanup. Within the flight batch, a synchronous terrain regression must finish restoring its temporary snow/grass before the asynchronous round-trip begins.

Required finite verification after implementation:
1. Real selector admits the prepared first candidate.
2. Snow and grass placed at an actual destination block still make available() reject; removal restores acceptance.
3. Existing four success paths and exact fuel/return behavior pass unchanged.
4. Batch setup/cleanup receipt confirms owned floor restoration on ordinary completed batch, including test-failure lifecycle if practically testable without expanding runtime scope.
5. Repeat normal short GameTests; preserve this failed log/world and do not relabel it as a production SKY failure or clean run.

Actual helper/fixture implementation and rerun were not yet reviewed at this report snapshot.

## Commands / boundaries

Performed read-only Git/status/diff, rg and Get-Content/Select-String inspection, archived XML aggregation, short Python native readback (`D:/python/pyenv/pyenv-win/shims/python.bat -B`, PYTHONUTF8=1), and Java 17 **javap only** against the pinned local mapped JAR. Source snapshots/identities and five batch lifecycle javap dumps are retained. Initial broad log output was truncated and followed by narrow exact failure extraction. Two rg calls used Windows-incompatible literal wildcard paths and one guessed filename did not exist; corrected reads supplied the actual sources. No failed check was suppressed or relabeled.

No Gradle, tests, Minecraft server/client, remote, index mutation, tracked write, excluded user-bundle read or process termination occurred. No full-version/Gate/visual approval is implied. Next work is the current SKY fixture correction, independent short checks and existing bounded presentation evidence only.
