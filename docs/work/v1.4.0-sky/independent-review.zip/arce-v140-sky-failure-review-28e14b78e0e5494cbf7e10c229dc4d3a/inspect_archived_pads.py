import gzip, hashlib, io, json, pathlib, sys
ROOT=pathlib.Path(r'D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0,str(ROOT))
from scripts import inspect_celestial_saved_data as nbt
from scripts import v120_precision_world_fixture as region
# Supplemental stopped-world inspection only. This is not the small SavedData contract reader.
nbt.MAX_TAGS=131072
BASE=pathlib.Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-sky-8bdcd66a68c54fefadc350434c25b4fb')
world=BASE/'clean-all-02-gametest/world'
raw=(world/'level.dat').read_bytes();assert len(raw)<1024**2
with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream: payload=stream.read(4*1024**2+1)
assert len(payload)<=4*1024**2
data=nbt.NbtReader(payload).read_root()['Data']
identities={str(world/'level.dat'):hashlib.sha256(raw).hexdigest()}
cache={}
def chunk(x,z):
    key=x//16,z//16
    if key not in cache:
        p=world/'region'/f'r.{key[0]//32}.{key[1]//32}.mca'
        assert p.stat().st_size<16*1024**2
        b=p.read_bytes();identities[str(p)]=hashlib.sha256(b).hexdigest()
        cache[key]=region._decode_chunk(region._region_chunk(b,*key),*key)
    return cache[key]
def height(x,z):
    a=chunk(x,z)['Heightmaps']['MOTION_BLOCKING_NO_LEAVES'];idx=(z&15)*16+(x&15)
    return (((a[idx//7]&((1<<64)-1))>>((idx%7)*9))&511)-64

def block(x,y,z):
    sections=chunk(x,z)['sections']
    for s in sections:
        if s['Y']!=y//16 or 'block_states' not in s:continue
        bs=s['block_states']; palette=bs['palette'];bits=max(4,(len(palette)-1).bit_length());per=64//bits
        index=(y&15)*256+(z&15)*16+(x&15)
        p=0 if 'data' not in bs else ((bs['data'][index//per]&((1<<64)-1))>>((index%per)*bits))&((1<<bits)-1)
        return palette[p]
    return {'Name':'minecraft:air'}

observations=[]
for dx,dz in [(0,0),(64,0),(-64,0),(0,64),(0,-64),(64,64),(-64,64),(64,-64)]:
    x,z=data['SpawnX']+dx,data['SpawnZ']+dz
    footprints=[]
    for name,offsets in [('two-column', [0,1]),('three-column',[-1,0,1])]:
        hs=[height(x+offset,z) for offset in offsets];y=max(-63,*hs)
        bottom=[{'position':[x+offset,y,z],'state':block(x+offset,y,z)} for offset in offsets]
        footprints.append({'kind':name,'column_heights':hs,'arrival_y':y,'bottom':bottom,'occupied':any(p['state']['Name']!='minecraft:air' for p in bottom)})
    observations.append({'candidate':[x,z],'footprints':footprints})
assert all(f['occupied'] for p in observations for f in p['footprints'])
log=(BASE/'clean-all-02.log').read_text(encoding='utf-8')
lines=log.splitlines()
result={'scope':'Stopped archived world; matching two/three-column GameTest rocket footprints, not per-tick snapshot capture',
 'spawn':{key:data[key] for key in ['SpawnX','SpawnY','SpawnZ','SpawnAngle']},'seed':data['WorldGenSettings']['seed'],
 'generator':data['WorldGenSettings']['dimensions']['minecraft:overworld']['generator'],
 'pads':observations,'native_identities':identities,
 'failures':[{'line':i+1,'text':v} for i,v in enumerate(lines) if 'failed!' in v or 'code=LANDING_PAD_UNAVAILABLE' in v],
 'command_tail':lines[-24:]}
print(json.dumps(result,indent=2))
