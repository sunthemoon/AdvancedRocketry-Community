# V140-SKY independent source review — first implementation snapshot

## Findings

1. **P2 — Renderer cleanup restores assumed defaults, not the state it received.** `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/client/sky/PlanetarySkyRenderer.java:42-45,68-75` saves only the shader and color, then always resets blend factors, disables blending, enables culling and enables depth writes. A caller entering with any different state loses it; the same cleanup executes after an upload failure before the renderer has changed those flags. This does not meet ADR-036's explicit state-restoration rule. A bounded state guard should capture/restore the specific mutated flags/factors with the pinned platform APIs on both normal and caught-failure exits. Review establishes this by source/control flow, not a reproduced GPU fault. The ordinary platform sky call currently does not supply a formal arbitrary-state restoration wrapper: pinned LevelRenderer dispatches AFTER_SKY immediately after the custom hook.

2. **P3 — Logout resets the failure latch without a reload.** `client/sky/PlanetarySkyClient.java:61-71` implements logout by calling resourceReloaded, and `PlanetarySkyRenderer.java:112-115` clears `failed`. After a caught render error, logout/reconnect therefore retries and can log again although neither a resource reload nor a renderer fix occurred. ADR-036 and the reader guide say disabled until reload. Keep buffer release separate from resetting the failure latch, or explicitly revise that lifetime to world-session scope. Ambient cooldown is correctly preserved across the same cleanup.

Both findings were sent to root while its test slot remained exclusive. This snapshot is immutable; future fixes must receive an incremental review rather than overwriting this report.

## Scope and inspected identity

- Repository: `D:/GitHub/AdvancedRocketry-Community`; baseline and HEAD `251de231612049f62721f8911a4f402a4f1157d0`.
- `source-identities.json` binds 40 scoped source/test/resource/doc/build files and the retained `source/` byte copies. `tracked-diff.patch` records tracked differences; the new sky files are captured explicitly, not omitted because they were untracked.
- Renderer SHA-256 at capture: `de5aab9bda29fe0f9722cd944ab54ac3b8d725757f832902709bd30ef615d549`.
- Reviewed model validation, atomic profile reload/retention, selection cache, bounded geometry/math, optional sound policy, render/effects/fog adapters, physical-client wiring, exact historical resource exclusions, generation, pure/unit/resource tests, one new physical-Level GameTest, ADR and reader/provenance text.
- Mandatory repository/version/governance instructions and the pinned Forge hook evidence were already read in the separate immutable contract review. That report is `C:/Users/Administrator/AppData/Local/Temp/arce-v140-sky-contract-review-dd364697f56745d5a0035f87f432b758/REVIEW-CONTRACT.md`, SHA-256 `4e892e0015d93aab4d4cf8225627c16d05ffb51d4d766854247fa4ce4686fbb9`.

## Observed implementation properties

- No new API exports, custom network protocol, server environment authority, saved identity or inventory mutations were found in this scoped diff. Common visual math uses no Minecraft client imports; Forge event registration is physical-client restricted.
- Surface and Space preserve distinct Overworld/End fallback and lightmap flags. Both intentionally suppress cloud/rain presentation; this is not claimed as server weather preservation at the visual level.
- A full immutable candidate resource map is published only after the reload preparation barrier; invalid profiles retain the previous map. The source now converts invalid ambient IDs using `ResourceLocation.tryParse` into the listener's bounded rejection path. This incorporates root's correction after its reported initial targeted failure, but no independent test has yet run.
- Profile limits are 128 winning resources, 16,384 bytes per resource, depth 16, bounded IDs, finite numeric fields. Geometry is fixed at 512 stars / 32 sun segments and 5,472 total vertices, uploaded once per buffer lifetime; no per-frame world scan or geometry upload is used.
- Fog adaptation never increases either finite incoming distance and does not alter shape. Fluid/powder snow/blindness/darkness bypass the additional sky/fog policy.
- Ambient cadence is session-local, finite, and not reset by world/profile/cover/resource/logout changes. The unit-gain resolved Sound fixture tests the real factory pitch/volume order without opening an audio device.
- Build exclusions are restricted to the two historical Moon/Space dimension-type paths. New resources preserve all fields besides effects by source authoring and resource tests; final archive uniqueness and byte identities still require execution/artifact inspection.

## Commands actually executed for this source pass

Read-only PowerShell commands via exec:
- `git status --short --untracked-files=normal`; `Get-Content AGENTS.md`; `git diff --stat 251de231612049f62721f8911a4f402a4f1157d0` — exit 0.
- `git rev-parse HEAD`; `git diff --check` — exit 0; no whitespace errors.
- `Get-Content` scoped Java/tests/docs/build files; numbered source listings and bounded selections from the retained pinned LevelRenderer javap dump — exit 0. The first broad Select-String output was truncated; it was narrowed to the renderLevel sky-call interval afterward.
- `D:/python/pyenv/pyenv-win/shims/python.bat -B -` with `PYTHONUTF8=1`, a finite read/hash/copy helper — exit 0; captured exactly 40 allowed files into this Temp directory. It uses `git diff --name-only` plus explicit new sky directories/files; it never reads the excluded user bundle.

No Gradle, JUnit, Python unittest, DataGen, GameTest, Minecraft client/server, network or remote command was run in this source-review phase. No tracked/index files were written. Root-reported 24-test initial result (2 failures) is context only, not independent execution evidence.

## Verification still needed / applicability limits

- Review the render-state/failure-lifetime correction; independently force the scoped sky/profile/selection/math/audio/reload tests once root releases the Gradle slot, including the invalid-ID retention regression.
- Inspect final main/API/sources archives for duplicate-free resource packaging, unchanged API identity, and historical type equality except effects; inspect generated-resource idempotence and physical-Level GameTest results.
- Pure tests do not execute real OpenGL upload/draw/error restoration, audio-device playback, or platform client reload/render scheduling. Dedicated-server loading/restart can validate side isolation and resource compatibility but not rendered appearance or audible behavior.
- V1/two-GPU, V2, shader-mod compatibility, rapid-travel visible behavior and sustained load remain unverified. This is neither full-version acceptance nor Gate/release approval.
