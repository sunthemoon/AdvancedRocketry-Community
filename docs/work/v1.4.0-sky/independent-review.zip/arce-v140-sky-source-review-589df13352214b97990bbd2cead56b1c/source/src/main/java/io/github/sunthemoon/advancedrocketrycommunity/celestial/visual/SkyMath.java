package io.github.sunthemoon.advancedrocketrycommunity.celestial.visual;

/** Pure display math; these values never feed server exposure or navigation. */
public final class SkyMath {
    private SkyMath() { }

    public static double daylight(double angle) { return clamp(Math.cos(angle) * 1.5 + 0.25, 0, 1); }

    public static double sunRadius(SkyProfile profile, double solar) {
        return clamp(profile.sunRadius() * Math.sqrt(clamp(solar, 0, 16)), 0.5, 12);
    }

    public static double stars(SkyProfile profile, double pressure, double daylight) {
        return profile.starBrightness() * (1 - clamp(daylight, 0, 1) * clamp(pressure * 50, 0, 1));
    }

    public static int skyColor(SkyProfile profile, double daylight) {
        double mix = clamp(daylight, 0, 1);
        int result = 0;
        for (int shift = 0; shift <= 16; shift += 8) {
            int night = (profile.nightColor() >> shift) & 255;
            int day = (profile.dayColor() >> shift) & 255;
            result |= (int) Math.round(night + (day - night) * mix) << shift;
        }
        return result;
    }

    public static Fog fog(SkyProfile profile, float near, float far) {
        if (!Float.isFinite(near) || !Float.isFinite(far) || near >= far || far <= 0) {
            return new Fog(near, far);
        }
        float end = Math.min(far, (float) profile.fogEnd());
        return new Fog(Math.min(near, (float) (end * profile.fogStart())), end);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Double.isFinite(value) ? Math.max(minimum, Math.min(maximum, value)) : minimum;
    }

    public record Fog(float near, float far) { }
}
