# V130-ROCKET-03C independent packaged execution

## Scope and result

PASS for one bounded external-cargo Earth -> Moon -> Earth trip across four
clean processes. The corrected driver and independent raw-file postcheck each
exited 0. This is not a soak, passenger/client test, crash test or Gate approval.

Fuel evidence ends at Earth landing/pre-disassembly: one initial operator fill
of 1000, two distinct committed debits of 372, remaining 628 then 256. No refill
occurred on the return leg. **No assertion or claim is made that fuel survives
disassembly.** That production gap is outside this cargo slice and tracked by
ROCKET-04. Cargo evidence continues through production disassembly and the
subsequent native BlockEntity restart.

## Source and artifacts

- Integrated source: `8130bc83e20430560f2a702e2a83b6a935330eb4`.
- Driver SHA-256: `3396dd3fdfce004b19abb4c5a7413fafe64061274373a1fc26944a39ad26d939`.
- Host SHA-256: `3f8be1e0adce70b1c25fc1eeeffeac5b7f398016abf6670af11b42c52c84c200`.
- Fixture SHA-256: `8144ded5d03764cdd6b1eda8ff5e778f7dd87c564ebde3e5dfe20d382629085f`.
- Immutable input copies and final installed JARs matched those hashes.
- `source-snapshot/` preserves nine executed source/helper files; actual paths
  and hashes are in `script-identities.json`, verified unchanged after execution.

This new disposable server copied only 104 previously verified Forge libraries,
not a previous world/mods/config. The initial failed world's bytes remain intact.
The exact Python command is in `launch-command.txt`; exact JVM commands and JAR
identities are in each phase's `launch.json`. No development GameTest flag,
substituted Runtime/manager, repository edit or Gradle command was used.

## Execution

Java 17.0.7 / Forge 47.4.10 / Minecraft 1.20.1, offline loopback port 57526.
Elapsed window: 2026-09-26 16:31:10 through 16:33:10 UTC.

| Phase | JVM PID | Exit | Observation ticks | WARN | ERROR |
| --- | ---: | ---: | ---: | ---: | ---: |
| moon-landing | 19244 | 0 | 21 | 25 | 0 |
| earth-landing | 16060 | 0 | 22 | 10 | 0 |
| disassembly | 13928 | 0 | 21 | 10 | 0 |
| container-restart | 14964 | 0 | 22 | 10 | 0 |

Counts are from full process stdout. Independent auditing also read every
debug/latest log: no ERROR/FATAL, project warning/error, linkage failure or
tick-lag warning. Baseline warnings concern fresh config defaults, Forge library
metadata, offline mode and asset URL schemes; all raw warning lines remain.
The owned Python PID 4208 and all four JVM PIDs were absent afterward; loopback
port 57526 was closed. No unrelated process was terminated.

## Actual native evidence

- The five-block production craft used a separately packaged external cargo BE,
  adapter `arce_adapter_test:cargo_inventory`, payload version 1.
- Exact inventory: 17 diamonds with `Public adapter cargo` display-name metadata,
  and 64 iron ingots in the fixture's two slots.
- Logical identity: `26647900-6e67-460d-a60a-a80366ddbac8`.
- Origin progression: Earth `(264,101,264)`, Moon `(8,80,8)`, Earth `(0,66,32)`.
- The actual transfer records retained relocated snapshot identities but exact
  relative blocks, palettes, payloads and inventory. Each source entity was
  replaced by one destination authority, with no source material duplication.
- Restart inspection bound the persisted COMMITTED transfer checksum, source
  count 0, destination count 1 and fuel values before return/disassembly.
- After production disassembly, both schema-2 journals were empty, rocket
  authority was absent, five native blocks and one exact cargo BE remained.
  The fourth process preserved the native BE unchanged.
- Independent raw decoding covered 2/6/6/6 touched chunks respectively, within
  the driver's 12-chunk budget. This is not a whole-world inventory audit.
- Actual loaded-JAR debug receipts, Forge status mod sets and one API 1.1
  registration event per process matched both approved artifacts.

`independent_postcheck.py` decodes raw captured region/entity/journal bytes,
not merely the driver's PASS fields. Results are in
`independent-observations.json` and `independent-postcheck-{stdout.txt,exit.json}`.
`configuration_postcheck.py` independently confirmed every captured config byte
except the exact generated timestamp, with byte-identical TOMLs. One initial
ad-hoc multiline Python invocation hit Windows shim quoting before evaluation;
its diagnostic is retained and the same read-only checks then passed as a script.
No server was rerun for that postcheck.

## Retained failure and archive boundary

The first attempt remains FAIL: two clean JVM exits, followed by a harness
comparison failure because Minecraft rewrites the generated timestamp comment
in `server.properties`. Exact raw differences, original captures and a separate
stopped-world Earth readback are retained at sibling Temp directory
`arce-v130-adapter-flight-e1769690262f4565a228cc18bf07a75c`.
Its manifest lists 71 files (72 including the manifest), SHA-256
`52b4865193ec7c46c906a935f7a558cbb5cbd5c048bac7175c97b97c5d638e6c`.
The correction validates that exact generated header/timestamp and excludes
only the timestamp line from configuration identity; all other bytes still bind.
The corrected runtime used a fresh world, not a retry of the failed world.

Archive the final files listed in `evidence-sha256sums.txt` and that manifest.
They include `flight-evidence/`, source snapshots and all top-level supplemental
files. Exclude full `server/` and `artifacts/`; both disposable worlds remain in Temp.

- Native `flight-evidence/SHA256SUMS` SHA-256:
  `92b08f467c8ab6ef2006f3b885b595903dd33e2fb6fe296ae69f184033993362`.
- Summary SHA-256:
  `1c509aed85f32295fdc41e0006bb44907b1d359b040494a3124d160c73b16e2a`.
- Independent observations SHA-256:
  `b4a879bc4827b4f176ee8b055c8dbbf7ac65972d7ce8cd377180bd1e9accb939`.

Remaining scope: teardown fuel preservation, additional v1.3 providers, broad
compatibility, long-load and full G0-G9 acceptance remain unapproved/unverified
by this execution. Next work is confined to current-version remaining items.
