"""Prepare a unique libraries-only Forge runtime; never invoke Java."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
PREVIOUS = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v130-adapter-recovery-corrected-725c77ab81e044348b9c150030feae8f")
SOURCE = PREVIOUS / "server/libraries"
TARGET = BASE / "server/libraries"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main():
    manifest = PREVIOUS / "preparation.json"
    expected = json.loads(manifest.read_text(encoding="utf-8"))["libraries"]
    paths = sorted(SOURCE.rglob("*"))
    for path in [SOURCE, *paths]:
        if path.is_symlink() or getattr(path.lstat(), "st_file_attributes", 0) & 0x400:
            raise RuntimeError(f"Refusing reparse point: {path}")
    actual = {path.relative_to(SOURCE).as_posix(): path for path in paths if path.is_file()}
    if len(expected) != 104 or set(actual) != {item["path"] for item in expected}:
        raise RuntimeError("Cached library inventory differs from the verified 104-file set")
    for item in expected:
        source = actual[item["path"]]
        if source.stat().st_size != item["bytes"] or digest(source) != item["sha256"]:
            raise RuntimeError(f"Cached library identity changed: {source}")
    TARGET.parent.mkdir()
    shutil.copytree(SOURCE, TARGET)
    for item in expected:
        target = TARGET / item["path"]
        if target.stat().st_size != item["bytes"] or digest(target) != item["sha256"]:
            raise RuntimeError(f"Copied library identity differs: {target}")
    if {path.name for path in TARGET.parent.iterdir()} != {"libraries"}:
        raise RuntimeError("Non-library server state present")
    result = {
        "task": "V130-ROCKET-03C",
        "prepared_at": datetime.now(timezone.utc).isoformat(),
        "source_libraries": str(SOURCE),
        "previous_manifest": str(manifest),
        "previous_manifest_sha256": digest(manifest),
        "libraries": expected,
        "copied_library_count": len(expected),
        "server_entries": ["libraries"],
        "java_launched": False,
    }
    with (BASE / "preparation.json").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"Prepared {len(expected)} previously verified libraries; no world/mods/config or Java start.", flush=True)


if __name__ == "__main__":
    main()
