"""Read-only exact comparison of the four captured configuration files."""
import hashlib
import json
import re
from pathlib import Path

base = Path(__file__).resolve().parent
evidence = base / "flight-evidence"
summary = json.loads((evidence / "summary.json").read_text(encoding="utf-8"))
baseline = {}
observations = []
for cycle in summary["cycles"]:
    for relative in ("server.properties", "config/advancedrocketrycommunity-common.toml", "config/fml.toml"):
        raw = (evidence / cycle["phase"] / relative).read_bytes()
        comparable = raw
        if relative == "server.properties":
            lines = raw.splitlines(keepends=True)
            assert lines[0] == b"#Minecraft server properties\r\n"
            assert re.fullmatch(rb"#Sun Sep 27 00:[0-5][0-9]:[0-5][0-9] CST 2026\r\n", lines[1])
            comparable = lines[0] + b"".join(lines[2:])
        identity = hashlib.sha256(comparable).hexdigest()
        assert baseline.setdefault(relative, identity) == identity
        observations.append({"phase": cycle["phase"], "path": relative,
                             "raw_sha256": hashlib.sha256(raw).hexdigest(), "identity_sha256": identity})
with (base / "configuration-postcheck.json").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(observations, indent=2) + "\n")
print("PASS: four raw configs match except exact generated timestamp; TOMLs byte-identical")
for path in (evidence / "SHA256SUMS", evidence / "summary.json", base / "independent-observations.json"):
    print(path.name, hashlib.sha256(path.read_bytes()).hexdigest())
