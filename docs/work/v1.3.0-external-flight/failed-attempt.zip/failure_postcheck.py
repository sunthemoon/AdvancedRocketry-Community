"""Capture the stopped second-phase world; do not start/retry or mutate it."""
import importlib.util
import json
import socket
import sys
from pathlib import Path
import independent_postcheck as check

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "source-snapshot"))
spec = importlib.util.spec_from_file_location("captured_flight_runner", BASE / "source-snapshot/run_v130_adapter_flight_smoke.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

first = BASE / "flight-evidence/moon-landing"
second = BASE / "flight-evidence/earth-landing"
record = json.loads((first / "result.json").read_text(encoding="utf-8"))
reports, legs = record["reports"], record["legs"]
lines = (second / "stdout.txt").read_text(encoding="utf-8").splitlines()
launches = [match for line in lines if (match := runner.flight.LAUNCH_LOG.search(line))]
assert len(launches) == 1
launch = launches[0]
assert launch.group(4) == check.MOON and launch.group(5) == check.EARTH
assert launch.group(7) == "SUCCESS" and int(launch.group(8)) == 372 and int(launch.group(9)) == 628
transfer = launch.group(1)
matches = [match for line in lines if (match := runner.flight.REPORT_LOG.search(line))
           and match.group(4) == check.EARTH and match.group(5) == "LANDED"]
assert matches
reported = matches[-1]
entity, logical, snapshot, dimension, state, fuel, capacity, passengers, active, x, y, z, blocks = reported.groups()
returned = {"entity": entity, "logical": logical, "snapshot": snapshot, "dimension": dimension,
            "state": state, "fuel": int(fuel), "capacity": int(capacity), "passengers": int(passengers),
            "transfer": active, "origin": [int(x), int(y), int(z)], "blocks": int(blocks)}
assert returned["logical"] == reports[-1]["logical"] and returned["fuel"] == 256
events = [match.group(4) for line in lines if (match := runner.flight.PHASE_LOG.search(line)) and match.group(1) == transfer]
assert events == runner.flight.EXPECTED_FLIGHT_EVENTS
reports = [*reports, returned]
legs = [*legs, {"transfer": transfer, "required": 372, "fuel_before": 628, "fuel_after": 256, "events": events}]
moon = reports[1]
cx, cz = moon["origin"][0] // 16, moon["origin"][2] // 16
previous = [entry["RocketEntityData"] for entry in check.entity_chunk(
    check.region_file(first, check.MOON, "entities", cx, cz), cx, cz) if entry["id"] == check.ROCKET]
assert len(previous) == 1
destination = BASE / "failed-earth-disk"
destination.mkdir()
state = runner.capture_disk(BASE / "server", destination,
                            [runner.site(report["dimension"], report["origin"]) for report in reports])
runner.write_json(destination / "disk-state.json", state)
returned_data = runner.validate_disk(state, reports, legs, False, previous[0])
assert returned_data["flight_data"]["fuel"]["amount"] == 256
assert state["transfers"]["transfers"][0]["source_snapshot"] == previous[0]["snapshot"]
for snapshot_data in [returned_data["snapshot"], state["transfers"]["transfers"][0]["source_snapshot"]]:
    check.check_snapshot(snapshot_data)
summary = json.loads((BASE / "flight-evidence/summary.json").read_text(encoding="utf-8"))
try:
    connection = socket.create_connection(("127.0.0.1", summary["port"]), timeout=1)
except OSError:
    pass
else:
    connection.close()
    raise AssertionError("Owned endpoint remains open")
runner.write_json(destination / "postcheck.json", {
    "scope": "Supplemental failure diagnostic after second clean stop; original driver remains FAIL",
    "reports_from_actual_logs": reports, "legs_from_actual_logs": legs,
    "returned_rocket_entity_data": returned_data, "raw_files": state["files"],
    "fuel_scope": "One fill, two debits, 256 at Earth landing; no disassembly executed or fuel-survival assertion",
    "observed_port_closed": summary["port"],
})
print("PASS supplemental stopped-world readback: actual Earth entity/payload, exact two fuel debits, pending landed transfer binding and vacated source material; original driver remains FAIL")
