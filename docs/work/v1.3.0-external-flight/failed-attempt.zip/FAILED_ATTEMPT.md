# V130-ROCKET-03C initial attempt

Result: **FAIL**, driver exit 1; do not relabel this as a four-process pass.

- Integrated source `566c92fcde0a8fd3a1e7421036284de114edf6bb`;
  runner SHA-256 `6d8e01633daacc78f32a57d24960e103358e5d8c19af8420540b1ceaf2d0e3a3`.
- Host SHA-256 `3f8be1e0adce70b1c25fc1eeeffeac5b7f398016abf6670af11b42c52c84c200`;
  fixture SHA-256 `8144ded5d03764cdd6b1eda8ff5e778f7dd87c564ebde3e5dfe20d382629085f`.
- Exact command is `launch-command.txt`, process exit is `runner-exit.json`.
- Run: 2026-09-26 16:24:42 through 16:26:01 UTC, Java 17.0.7 / Forge 47.4.10,
  normal packaged dedicated server with existing operator-only release-test hooks.
- Owned Python PID 10708; Moon process PID 12376 and Earth process PID 18920.
  Both JVMs exited 0 and each observed 22 stable ticks; the second process completed
  its return flight, save and clean stop before the harness failed its config check.
- The exact configuration difference was the generated second-line timestamp
  comment in `server.properties`: `00:24:52` versus `00:25:37` CST.
  All setting lines were unchanged and both TOML files were byte-identical.
  Original bytes and `configuration-difference.txt` are retained.
- Disassembly and native-container restart never ran. The failed world was not
  retried, deleted or modified after the clean second stop.

`flight-evidence/` is the original failed driver output and its original checksums.
The failure occurred before second-phase raw disk capture. `failure_postcheck.py`
therefore copied the stopped native files to `failed-earth-disk/` and decoded them
using the exact captured runner validators, independently binding additional
checks to actual launch/report/phase logs and the first phase's raw Moon entity.

The supplemental readback exited 0: exact external adapter/version/items persisted,
one returned Earth entity held authority, source material was vacated, both debits
were present, and the landed COMMITTED transfer matched the saved Moon snapshot.
This supplemental diagnosis is not an original driver pass. It confirms fuel
1000 -> 628 -> 256 only at landing, before disassembly; no teardown fuel claim.
The endpoint was closed and no owned Java process remained.

Archive the files listed by `evidence-sha256sums.txt` plus that manifest. Full
`server/` and `artifacts/` directories are excluded; the original disposable
world remains in Temp. No repository files, Gradle tasks, remote hosts or clients
were changed or run by this verifier. This finite failure observation grants no Gate.
