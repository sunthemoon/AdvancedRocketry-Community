# V140-MAP-02 independent runner/source review

Date: 2026-09-27. Delegated independent reviewer; repository/index read-only.
Repository: `D:/GitHub/AdvancedRocketry-Community`.
Observed base/HEAD: `d41e42fb2118a060a7df4c0480e0887079e0d38e`.

## Findings, resolutions and remaining applicability

**No unresolved concrete finding in the final inspected runner/source scope.**
Three oracle gaps were reported during the evolving initial read and corrected
before the final independent Python execution:

1. **P2: a missing landed transfer file was accepted.** The initial 350-line
   runner made all journal checks conditional on `journal_path.exists()`.
   Omitting the file after a completed flight therefore skipped the promised
   reservation check. Final `scripts/run_v140_planetary_worlds_smoke.py:339-344`
   requires the file when legs exist. Its `validate_transfer:82-112` additionally
   binds phase/schema, request/logical/owner/entity identities, required fuel,
   captured source/destination snapshots, flight states, fuel histories and
   destination plan/typed target. Empty or altered journal tests now reject.

2. **P2: native entity comparison omitted important saved authority.** The first
   reader checked outer logical identity and report fields but not owner,
   current body/typed target, flight logical identity, physical position or
   passengers. Travel-time changes could pass and subsequently remain stable
   across restart. Final `validate_flight:65-79` and `capture_rocket:123-176`
   bind those fields, including stationary absence of active plan/transfer.
   The added positive/mutation tests exercise the important helper decisions.

3. **P2: new station counts did not establish their requested orbit identity.**
   Initially the script retained the old record and counted three stations,
   while discarding creation UUID receipts. A new record with the wrong orbit
   could pass. Final `validate_stations:115-120` binds exact UUID, owner, body and
   name to retained command receipts; `cycle:323-330` also preserves the old
   complete record and compares the complete registry across final restart.

Bounded raw per-phase `level.dat`, effective `server.properties`, its original
harness identity, EULA and available world marker are now archived at **349-355**.
Effective properties comparison normalizes only the already-defined generated
Java timestamp line. The raw files/hashes are retained; no whole-world NBT decode
or whole-world byte immutability is inferred.

## Source fuel correction

The earlier source-review report's proposed post-rejection debit expectation
was incorrect. `RocketTransferService.java:109-133` retains original fuel in
`sourceTransit`; the prepared destination flight owns the prospective debit.
Existing `RocketFlightGameTests.java:368-369` already requires original source
fuel after a blocked destination. The revised
`PlanetaryLandingGameTests.java:85-86` checks full `state.fuel().equals(before.fuel())`,
and its method name now states that policy. This is a correction of the test
oracle, **not** a production fuel-policy change or an observed resource defect.
The parent reported retaining the original failing GameTest log; that runtime
log was not read or rerun in this Python/source-only review. Earlier review files
remain unchanged rather than retrospectively rewriting that mistaken expectation.

## Safety and evidence design inspected

- Input handling requires a fresh libraries-only server, fresh disjoint evidence
  directory, external artifact inputs, no traversal/symlink ancestors, actual
  host entry point/mod metadata and exact 3-body/4-route versus 6-body/9-route
  artifact counts. The pre-planet and final artifacts may share a filename;
  replacement is deliberate, bounded to the owned server's verified installed
  JAR, and checked again after each phase.
- The runner owns only the `CapturedProcess` instances it launches. Startup,
  status, command/flight markers and normal stop have finite inherited bounds;
  failure aborts only that owned process. Phase observations retain FAIL/error,
  actual process exit (or null before successful spawn), command list and logs.
  Python failure tests use mocks, not actual Java processes. On outer failure,
  callers must inspect `failure.json`, phase receipts and the command exit;
  `summary.json` can remain IN_PROGRESS rather than becoming a PASS.
- The baseline is newly created with the supplied prior MAP-01 development JAR,
  not a naturally aged or arbitrary historical player world. The full stopped
  pre-upgrade world is retained before the JAR replacement. The sequence is
  baseline assembly/station, upgrade with three surface legs, then final restart.
- Launch receipts are cursor-scoped; phase events and positive per-leg fuel
  changes are exact. Fuel is filled only during baseline assembly. Saved entity
  structure/payload is compared against baseline, final debit UUID history is
  exact, the last committed reservation is required, and complete native rocket
  data is compared across final restart. The snapshots are not disassembled.
- Entity reading is limited to the five declared fixture Levels, at most 16
  region files and 128 populated entity chunks, with bounded parser/file inputs.
  One global live rocket count and scoped live air/no-drop checks supplement it.
  This is not an audit of every possible unloaded entity in every Minecraft Level.

## Independently executed checks

Working directory was the repository; `PYTHONUTF8=1`.

Initial actual command:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v140_planetary_worlds_smoke -v
```

Result: **exit 0, 7 tests, 0.108 s unittest / 0.671 s process**.
Raw output/receipt: `python-initial.txt`, `python-initial-receipt.json`.
Initial reviewed runner snapshot was already revised from the first 350-line
read; its identity is recorded, not presented as the untouched first draft.

Final actual command:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v140_planetary_worlds_smoke tests.test_v140_celestial_schema_smoke -v
```

Result: **exit 0, 22 tests (11 new runner + 11 schema runner), 0.303 s unittest /
0.873 s process**. No failures/errors/skips. The nine explicitly captured input
files had identical before/after hashes. Raw log and exact command receipt are
`python-final.txt` and `python-final-receipt.json`; reviewed bytes are preserved
under `final-source/`.

Final runner SHA-256:
`8d1ebe14cf2db21f47e56fec5d647b73553134f9aac3a800b47503838d9d4ea1`.
Final new test SHA-256:
`2fdf8b731671fc1aab9257298e6dd0ae0092075998b3b3b91b95044fd9b2cc44`.

Other executed commands: read-only `git rev-parse/status/diff --check`, `rg`,
numbered PowerShell source reads, copying scoped source snapshots to this Temp
directory, and SHA-256 calculation. Scoped `git diff --check` produced no
diagnostics (it does not cover untracked files). A few guessed source filenames
and a Windows `scripts/*.py` rg operand were corrected after read errors; no
test or product verdict was inferred from those search attempts.

## Evidence boundaries / not executed

No Gradle, Minecraft/Java server, client, remote work, repository/index write,
process termination, subagent or OpenPet operation was performed. The excluded
user documentation bundle was not read. Root-owned mutable build output and
active native world were not inspected.

Vacated blocks/no nearby drops are **live command observations**, not native
block-region palette/BlockEntity readback. Saved entity cargo and transfer/station
NBT are separate native checks. Baseline/upgrade commands use the operator path;
player permissions/UI and player station creation rely on other tests, not this
runner. Gas denial checks the live rocket report; it is not an independent
before/after native journal cut for that denial. The runner checks only the last
retained journal; intermediate legs have live event/identity/fuel evidence.

Native execution was still root-owned/in progress at this review checkpoint.
This report makes no claim that the three cycles passed or that actual artifact,
world/manifest bytes have been independently audited. Those and an independently
authorized Java test pass remain separate work. No S2/V1/V2, crash/soak, broad
historical migration or full-version Gate approval is implied.
