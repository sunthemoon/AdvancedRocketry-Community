# Source-review command record

All commands ran from `D:/GitHub/AdvancedRocketry-Community` through PowerShell.
Reads were restricted to tracked repository paths and expressly scoped new
MAP-02 files, plus the pinned local Forge cache. No tests were invoked.

Command families actually executed:

```powershell
git rev-parse HEAD
git branch --show-current
git status --short --untracked-files=normal
git diff --stat d41e42fb2118a060a7df4c0480e0887079e0d38e -- src/main src/test build.gradle
git diff d41e42fb2118a060a7df4c0480e0887079e0d38e -- <explicit changed source/build/test files>
git diff --check d41e42fb2118a060a7df4c0480e0887079e0d38e -- build.gradle docs/decisions/ADR-033-PLANETARY-WORLDS-AND-SURFACE-ADMISSION.md src/main src/test src/adapterTest scripts tests
rg -n 'pads\.available|class LegacyFlightTargetMigrator|launch-surface|release-test|releaseTestRocket' src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket
rg -n 'available\(' src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket
rg --files src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest src/test/java/io/github/sunthemoon/advancedrocketrycommunity
Get-Content -LiteralPath <explicit source/doc paths>
Get-ChildItem -LiteralPath src/generated/v1.4/resources -Recurse -File
git ls-files -- src/main/resources src/generated/<explicit version roots>/resources
Get-FileHash -LiteralPath <explicit source or generated JSON path> -Algorithm SHA256
Get-Content -LiteralPath <new generated JSON path> -Raw | ConvertFrom-Json
& 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe' -classpath 'C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar' -p -c net.minecraft.world.level.block.LiquidBlock
```

Bounded PowerShell loops added line numbers, compared generated relative keys
against old tracked roots, and copied scoped read snapshots/hashes only into
this unique Temp directory. One initial `rg` named a nonexistent transfer
recovery file and reported that read error; subsequent searches used actual
caller locations. A search in nonexistent `.gradle/configuration` produced no
result. Neither was treated as test success or a production failure.
