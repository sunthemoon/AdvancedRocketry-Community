# V140-MAP-02 early independent source review

Date: 2026-09-27. Reviewer: delegated read-only reviewer, not implementation owner.
Repository: `D:/GitHub/AdvancedRocketry-Community`.
Base/observed HEAD: `d41e42fb2118a060a7df4c0480e0887079e0d38e`;
branch: `codex/v1.4.0-planetary-expansion`.

## Findings and revisions

1. **P2, production finding corrected during review; regression not executed.**
   The first read of `RocketLandingPadSelector.java:85-88` applied the new
   support/fluid condition only in `select`. Its `available` method did not
   check that condition, although `RocketTransferService.java:396-402` uses
   `available` to admit the reserved destination after countdown/transit.
   Removing the selected new-planet pad's sole sturdy support, or placing fluid
   immediately below a bottom block, leaves the rocket's occupied target cells
   clear and previously allowed destination creation. This violated the new
   landing support policy without requiring a catalog change.
   The revised selector now includes the bounded support condition in
   `available` at **211-216**, and `select` uses that same method at **85-87**.
   Earth/Moon/Space are expressly exempted, retaining their old policies.
   This addresses the source defect by inspection; no regression execution is
   claimed. The new AIR transfer regression should establish one returned source,
   retained snapshot/typed target, exact committed debit and no reservation.

2. **P3, new fluid fixture isolation needs correction at this checkpoint.**
   `PlanetaryLandingGameTests.java:65-67` places WATER using `UPDATE_CLIENTS`,
   waits 190 ticks at **72**, and cleanup restores only those initial support
   positions at **51-53**. Pinned Forge 47.4.10 `LiquidBlock.onPlace` calls
   `Level.scheduleTick` regardless of that update flag (retained
   `LiquidBlock.javap.txt`). A bottom block overhanging sloped terrain can let
   water flow beyond the saved cells, leaving mutations in a remote shared
   world and involving fluid simulation in the intended support-only oracle.
   Keep an actual transfer test using removed support, and test fluid rejection
   synchronously with immediate restoration, or explicitly contain/restore all
   finite affected cells. This is a test-isolation finding, not a production
   resource-loss conclusion.

3. **Earlier fixture-cleanup observation substantially addressed by inspection.**
   The initial `PlanetaryWorldGameTests` cleaned owned journal/entities/stations
   only after successful assertions. The later read adds guarded callbacks and
   owned logical-ID cleanup at **84, 91, 118-139**, plus station deletion/template
   restoration/flush in `finally` at **158-166**. It does not broadly delete other
   test records. Runtime failure and timeout behavior have not been exercised.

No other concrete production defect was identified in the bounded source scope
below. These are source observations, not a full-version or Gate verdict.

## Contract and compatibility observations

- The SPACE alias in ADR-033 **47-50** is an existing compatibility rule, not an
  invented bypass. `LegacyFlightTargetMigrator.currentLocation:50-58` already
  accepts `(Space Level, SPACE_ID)`. `RocketEntity.initialize:95-100` still uses
  `bodyForDimension:477-484` for Station targets, which initializes SPACE_ID.
  `PlanetaryFlightAdmission:31-40` confines the allowance to the actual Space
  Level and matching committed station UUID/region; arbitrary current-body
  mismatches remain denied. Admission does not rewrite the record.
- `PlanetaryFlightAdmission:19-55` checks live ServerLevel identity, saved Level,
  typed target and snapshot Level; mapped surface resolution is unambiguous;
  arrival additionally requires a started Level and arrival capability.
  Generic Orbit/Mission launch locations are rejected. `RocketFlightService`
  invokes it against the captured catalog pair before planning; quote checks
  remain metadata-only. Existing transfer recovery is not catalog re-planned.
- `StationManager:62-69` resolves a player's actual mapped source instead of an
  Earth/Moon enum. Existing creation service still enforces orbit capability,
  permission/owner limits and reserve/generate/commit authority. Operator
  creation remains separate.
- `RocketCommands:61-100,346-363,412-418` keeps the new typed diagnostic launch
  beneath permission level 2 and the release-test JVM-property registration
  gate. It reuses runtime launch admission and accepts no client landing
  coordinates.
- `PlanetaryWorldgen:39-87` describes two vanilla noise-generator startup data
  entries with separately authored biome/noise/surface settings. The gas body
  has no Level data. This source reading is not native codec/worldgen evidence.
- The explicit resource inventory contains **20** new non-cache JSON resources,
  with **zero** relative-path collisions against earlier tracked resource roots.
  It contains 3 schema-2 bodies, 5 routes, 2 dimension entries, 2 dimension types,
  2 biomes, 2 noises, 2 noise settings and 2 language files. Gas has no `level`
  member. `build.gradle` retains older roots while adding v1.4; no public API,
  network or save-schema edit was observed in this source diff.
- The P3 reverse-binding diagnostic is corrected in `PlanetaryBindings:30-34`;
  its added test names both conflicting IDs without claiming sorted order is
  historical ownership. Rejection and retained bindings are unchanged.

## Actual checks and retained evidence

- Read-only `git rev-parse HEAD`, `git branch --show-current`, scoped
  `git diff`/`git diff --stat`/`git status`, `rg`, and numbered PowerShell
  `Get-Content` inspection. One initial search used a nonexistent
  `RocketTransferRecovery.java` path; corrected search found actual callers.
- Scoped `git diff --check d41e42fb... -- build.gradle docs/decisions/ADR-033-...
  src/main src/test src/adapterTest scripts tests`: no whitespace diagnostics.
- PowerShell JSON/resource inspection and hash inventory:
  `generated-source-inventory.json`; 20 files decoded, 0 old-key collisions.
  This is structural inspection, not a test-suite run or packaged-JAR audit.
- Pinned `javap -classpath <Forge 1.20.1-47.4.10 mapped official JAR> -p -c
  net.minecraft.world.level.block.LiquidBlock`: exited 0, raw output retained.
- `source-checkpoint-identities.json`, `source-checkpoint/` and
  `tracked-source-checkpoint.patch` preserve 24 scoped inputs at an intermediate
  checkpoint. The support fix was already present in that snapshot. Later
  fixture edits read above may postdate it; this is not a final frozen identity.

## Limits and useful remaining checks

No Gradle, Java game/server, Python tests, build-output inspection, network,
repository/index edits, subagents or desktop-pet calls were performed. The
excluded user documentation bundle was not opened. Root retained the exclusive
live Gradle slot throughout this review.

Later verification should execute the new selector/admission and changed-pad
cases; keep quotes free of chunk generation; cover missing/closed/mismatched
surface refusal with unchanged fuel/journal, actual Station/SPACE-alias source
admission, and preserve Earth/Moon behavior. The authored resource keys still
need packaged uniqueness/native codec, actual terrain, existing-world append
and finite same-world restart evidence. Test additions and the native runner
were still evolving, so this is deliberately not final implementation review.
No S2/V1/V2, broad migration, long-load or full Gate approval is implied.
