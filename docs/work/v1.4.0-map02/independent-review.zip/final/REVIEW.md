# V140-MAP-02 independent final review

## Findings and disposition

No unresolved concrete correctness finding was identified in the final reviewed MAP-02 source and bounded observations. This is not a full-version Gate or release approval.

The earlier reports are retained, not rewritten. Their findings and corrections have the following disposition:

1. **Resolved P2: destination support could change after pad selection.** `RocketLandingPadSelector.available:211-216` now applies the bounded support/fluid check for the new planetary surfaces; selection uses the same check. Existing Earth/Moon/Space policy remains exempt as contracted. The independent GameTest run exercised both changed-pad cases, including actual transfer refusal/return after removal of support and the synchronous fluid check.
2. **Resolved P3: new fixture cleanup and liquid scheduling.** Owned entity/journal/station/platform cleanup is bounded to the fixtures. The fluid mutation is restored synchronously rather than leaving scheduled liquid updates through the countdown. The real AIR-support transfer regression remains.
3. **Correction to the earlier review's fuel expectation, not a production fix.** `RocketTransferService:109-133` preserves the original source-transit fuel and places the prospective debit in the destination copy. The earlier reviewer suggestion that a refused destination should retain a debit was incorrect. `PlanetaryLandingGameTests:85-86` now requires the entire returned fuel ledger to equal the original. The root's initial failed fuel assertion and the original review remain historical evidence.
4. **Resolved runner oracle gaps.** The final runner requires the transfer journal, compares saved owner/body/typed-target/fuel/payload authority, and binds newly allocated station identities to their exact requested orbit bodies rather than accepting a count alone. The final 24 Python tests include the corresponding mutations.
5. **Retained harness failures, not reclassified as successful runs.** Native attempt A rejected real zero-byte empty entity regions after a clean process exit. Attempt B incorrectly charged these empty handles against the material-region budget. Final parsing has independent limits of 16 material regions, 32 empty regions, and 128 populated chunks; nonzero truncated headers still fail. This is an evidence-reader limit correction, not an increase to runtime world-scan/landing budgets.

The existing Space body alias remains explicitly scoped: `PlanetaryFlightAdmission:31-40`, `LegacyFlightTargetMigrator.currentLocation:50-58`, and `RocketEntity.initialize:95-100`/`bodyForDimension:477-484` permit the legacy Space identity only with the actual committed station/region checks; no arbitrary source-body exemption or identity rewrite was found. The reverse-Level binding diagnostic now names both conflicting identities without depending on sorted order to label a historical owner.

## Scope and identities

- Repository: `D:/GitHub/AdvancedRocketry-Community`; branch `codex/v1.4.0-planetary-expansion`; reviewed diff baseline `d41e42fb2118a060a7df4c0480e0887079e0d38e`.
- Contract: accepted ADR-030/031/032/033 and the active MAP-02 scopes. Reviewed production admission, pad selection/revalidation, typed launch, station source/body resolution, generated worlds, diagnostics, new/affected fixtures, and final planetary/schema runner tests.
- Source inspection and prior revisions are recorded in the unchanged source-review and runner-review directories listed below.
- Tracked tree/index were read-only. Only authorized build/cache outputs and this Temp directory were written; no user-bundle read, remote access, additional agent, or server manipulation was performed.
- `inputs-before.json` and `inputs-after.json` contain 1,284 scoped source/build-input files. Paths, lengths and SHA-256 hashes are unchanged, including generated resources. `generated-tracked-diff.txt` retains the observed new v1.4 generated-path inventory; it is not evidence that those untracked resources were already committed.
- Final runner SHA-256: `4732a8663d0d449c52b8c4056ec391679958ac2b6db21dfce40d3fccf137c732`, also equal to the frozen attempt-C runner source. Exact source/test identities are in the input manifests.

## Independently executed commands and results

All Gradle commands used `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`. Python used `PYTHONUTF8=1`. Commands were serial; the exclusive Gradle slot was released after completion.

```text
.\gradlew.bat test --tests '*Planetary*' --tests '*RocketTargetFlightPlanner*' --tests '*LegacyFlightTargetMigrator*' --tests '*BodyContextResolver*' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

Exit 0, 44.294 seconds. **61 tests / 7 suites**, zero failures/errors/skips; all 16 tasks executed, not cached test evidence. Classes: PlanetaryBindingsTest (18), BodyContextResolverTest (8), PlanetaryReloadTest (15), PlanetaryContentTest (7), PlanetaryFlightAdmissionTest (5), RocketTargetFlightPlannerTest (3), LegacyFlightTargetMigratorTest (5). Raw output, receipt and all focused XML are retained in `gradle-focused.log`, `gradle-focused-receipt.json`, and `junit-focused/`.

```text
.\gradlew.bat runGameTestServer --offline --no-daemon --no-build-cache --console=plain
```

Exit 0, 102.604 seconds. **All 220 Required GameTests passed**, using the existing `build/gametest` world with no clean. The server task actually executed (3 tasks executed, 14 up-to-date). Planetary batches include surface flight, player station, terrain, physical admission, changed-pad and earlier admission cases. Raw output and server logs are retained.

The GameTest log retains a **2,322 ms / 46 tick lag warning** and **13 ERROR-severity lines from deliberate Precision migration save-fault cases** (injected exceptions, associated chunk-save failures, and expected readback mismatch diagnostics). Their exact lines are preserved in `gametest-error-lines.txt`. The report does not claim a zero-ERROR GameTest log or performance acceptance.

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v140_planetary_worlds_smoke tests.test_v140_celestial_schema_smoke -v
```

Exit 0, **24 tests** (13 planetary, 11 schema); unittest time 0.468 seconds, process time 1.099 seconds. `python-final.log` and receipt retain actual output. No full JUnit rebuild, additional independent native launch, or consumer rebuild is claimed by this review.

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B <this-review-directory>/native_audit.py
```

Exit 0, 0.905 seconds. This helper independently reads raw native files and log/command receipts. It reuses bounded binary NBT/Anvil decoding primitives, not the planetary runner's validation or PASS functions. Source SHA-256 is recorded in `native-audit-receipt.json`; full derived observations are in `native-audit.json`.

## Artifact and generated-resource checks

All three build artifacts are byte-identical before/after independent execution and equal the frozen root artifacts:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Main | 2458839 | `83e9992ca2ca96353fb6485deaf99b867ccbe22de4144177b8eaec46a1a1f593` |
| API | 48469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1121970 | `9217f556800492932957d83282f9e8c5eca5ddf94356e1e693c580bb0a5fae8e` |

ZIP entry names are unique, with no adapter-test fixture namespace/resources in the host/API/sources artifacts. All **27 API class entries** are in the API namespace and byte-equal to the main JAR. The complete API JAR hash matches `docs/releases/v1.3.0/development-artifacts.json` (unchanged API 1.7 artifact). All 20 new generated v1.4 JSON resources compare byte-equal to their main-JAR entries. This is artifact inspection, not a new isolated-consumer build claim.

## Independent native readback

Read-only input root: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-map02-bed74a30e67b4ccead37daac2e86d46c`.

All manifest entries and the exact captured member sets were verified for **native-a (16)**, **native-b (90)** and **native-c (145)**. The original failed receipts and inputs remain intact. Attempt A's baseline JVM and attempt B's upgrade JVM exited 0, but their reader phases correctly remain FAIL.

For native C, all three process receipts are PASS/exit 0, supported by raw ready/stop/save log sequences, not only summary JSON. The baseline uses the genuine archived MAP-01 JAR (`9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`), then the final MAP-02 JAR. This proves a bounded freshly authored previous-build-world upgrade, not arbitrary aged-world compatibility.

Observed raw facts:

- Binding ledger grows additively from 3 to 6 entries: mapped Mars/Venus plus explicitly unmapped gas body; upgrade/restart ledger is equal. Baseline live Mars/Venus/gas Level lookups refuse; upgraded/restarted Mars/Venus resolve, gas remains refused.
- Exactly one logical rocket is present across the five declared Level capture sets. Logical identity `5594319f-615e-48c6-a20c-8f08ec17a7d9` and owner `00000000-0000-0000-0000-000000000005` persist; physical Entity UUID changes during transfer as expected.
- Actual route: Earth to Mars to Venus to Earth. Fuel is **2000 -> 1552 -> 1019 -> 504**, debits **448 + 533 + 515 = 1496**, with one initial fill and no top-up. Raw successful launch/phase receipts bind the three transfer IDs and identities. The refused gas request has zero required fuel and leaves 2000 before the successful route.
- Six-block snapshot retains exact invariant block/payload content, including a chest with **17 diamond + 64 iron**. Saved current body, typed target, physical position, owner/logical identity, fuel/debit IDs and passengers were checked. Complete final `RocketEntityData` is equal after restart.
- The final COMMITTED journal binds the last transfer, Venus source fuel 1019 and Earth destination fuel 504, exact owner/IDs/snapshot; raw journal bytes are unchanged on restart. Intermediate leg journals are not independently persisted/captured between each landing; their evidence is live receipts/events.
- The entire existing Moon station record is retained. New Mars and gas station UUIDs/body/owner/name/cell/region match their commands and receipts. The complete station registry and compressed native station bytes are equal upgrade/restart. Station commands are operator fixtures; player interaction evidence is separate GameTest coverage.
- Entity-region observations: baseline 4 material / 4 empty / 36 populated chunks; upgrade and restart 4 material / 20 empty / 54 chunks. Final limits reject 17 material or 33 empty regions, and still reject truncated nonempty headers.
- Raw server properties retain all substantive bytes, normalizing only the known generated timestamp line. The same-world marker is bound to both later phases; baseline backup and baseline level.dat bytes match. Raw level.dat is retained and hashed, **not fully decoded**, and its hashes legitimately differ across phases. Whole-world byte immutability is not claimed.
- Raw stdout/latest/debug each retain **25 / 10 / 10 warnings** by phase, **zero ERROR/FATAL**, and no lag/client-linkage finding in these three native captures. This does not establish a performance or visual Gate.

Native source/target vacated-block and nearby no-drop observations are live commands. No native block-section palette or block-entity restoration readback was performed for those claims; native entity/payload/journal/station/binding readback is distinguished from them. Disassembly is outside this runner.

## Retained supplemental reviewer failure

`inspect_items.py` and `native-preexisting-items.log` preserve an **exit-1 reviewer assertion** that whole captured regions' background ItemEntities would remain identical. That assertion was too broad: vanilla wheat-seed/dandelion entities far from the rocket sites move/merge/change during normal simulation. `inspect_items_v2.py` retains the original helper and replaces only that equality assertion with observation; its output is preserved separately. `native-background-items-classified.json` confirms all 12 per-phase observations are background seeds/dandelion, not diamond/iron cargo. There is no claim of zero global ItemEntities or unchanged whole-world item identity. This failure is not erased, counted as a native product failure, or used to relax the runner's bounded nearby-drop assertion.

## Limits and remaining work

This review does not certify full version Required Gates, all historical/custom worlds, client visuals, two-client behavior, long load/stability, arbitrary datapacks/terrain, disk crash cuts, or full native block-storage conservation. Flight coverage is the bounded operator-created route and a separate reused-world GameTest run. Root owns final documentation/staged-byte/archive checks; this report does not assert their future outcome. No new runtime campaign is recommended solely to remove warnings or broaden this slice.

## Preserved preceding reports

- `C:/Users/Administrator/AppData/Local/Temp/arce-v140-map02-source-review-a4869839d4424355bab10470b050d119`: `REVIEW-SOURCE.md` SHA-256 `bc32ad88e990ad4f008619600fc305bb7c0cd226a4f0514a02ef55fc70da0485`; `REVIEW-ADDENDUM.md` SHA-256 `01ee3938f0200f6bf0190d65e2f5d0213a656323e7872e46236f2f108cf9fd11`.
- `C:/Users/Administrator/AppData/Local/Temp/arce-v140-map02-runner-review-b020c84c94714adeb3c1e0eeee6c5454`: `REVIEW.md` SHA-256 `b80613de82a34e19621c41bc68b949e80972d99d8898155c8dc54c2ed6d39c25`; `REVIEW-LATEST.md` SHA-256 `e401d561efb1e04e7b0ce3d89b6d30188c9012f477706e5147c613cc9e6e06fe`.

All files in this final review directory, including failed-helper evidence, are enumerated by its final `SHA256SUMS` (excluding the manifest itself). Exact execution receipts, raw logs, focused XML, source/artifact inventories and independent native helper/results are retained for archival.
