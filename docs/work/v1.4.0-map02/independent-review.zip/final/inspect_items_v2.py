from pathlib import Path

# Keep the initial over-strong whole-item-position comparison and its failure.
# This follow-up records raw observations before checking only the relevant cargo distinction.
source=(Path(__file__).parent/'inspect_items.py').read_text(encoding='utf-8')
source=source.replace("assert observations['baseline']==observations['upgrade']==observations['restart']",
    "identities = {phase: [(item['uuid'], item['stack']) for item in values] for phase, values in observations.items()}\n"
    "print('UUID/stack identity unchanged:', identities['baseline'] == identities['upgrade'] == identities['restart'])")
exec(compile(source,'inspect_items_v2-derived','exec'))
