import json
import re
import zlib
from native_audit import BASE, OUT, NbtReader, region, uid

observations={}
for phase in ('baseline','upgrade','restart'):
    result=[]
    for path in (BASE/'native-c'/phase/'native').rglob('r.*.*.mca'):
        raw=path.read_bytes()
        if not raw: continue
        rx,rz=map(int,re.fullmatch(r'r\.(-?\d+)\.(-?\d+)\.mca',path.name).groups())
        for i in range(1024):
            if raw[i*4:i*4+4]==bytes(4): continue
            x,z=rx*32+i%32,rz*32+i//32
            compressed=region._region_chunk(raw,x,z)
            stream=zlib.decompressobj()
            data=stream.decompress(compressed,region.MAX_EXPANDED_CHUNK+1)
            assert len(data)<=region.MAX_EXPANDED_CHUNK and stream.eof
            for entity in NbtReader(data).read_root()['Entities']:
                if entity.get('id')=='minecraft:item':
                    result.append({'uuid':uid(entity['UUID']),'stack':entity['Item'],'position':entity['Pos'],'region':path.relative_to(BASE/'native-c'/phase/'native').as_posix()})
    observations[phase]=sorted(result,key=lambda x:x['uuid'])
assert observations['baseline']==observations['upgrade']==observations['restart']
assert all(x['stack']['id'] not in ('minecraft:diamond','minecraft:iron_ingot') for x in observations['baseline'])
(OUT/'native-preexisting-items.json').write_text(json.dumps(observations,indent=2)+'\n',encoding='utf-8')
print(json.dumps(observations,indent=2))
