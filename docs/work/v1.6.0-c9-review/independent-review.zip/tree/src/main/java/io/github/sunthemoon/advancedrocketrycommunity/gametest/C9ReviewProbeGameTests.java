package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import com.mojang.authlib.GameProfile;
import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.ModIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.content.PlanetaryContent;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModBlocks;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModItems;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.content.SatelliteIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.content.SatelliteItemData;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.MissionKind;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.ResourceMissions;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.RewardEntry;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.SatelliteOperationCode;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteBlueprint;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteKind;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteKindState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteStats;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.persistence.SatelliteMissionSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalBlock;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalMenu;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.storage.ChunkSerializer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.level.ChunkDataEvent;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.registries.ForgeRegistries;

/** C9 independent-review probes (reviewer's copy only; not part of the reviewed commit). */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class C9ReviewProbeGameTests {
    private static final String KEY = "SatelliteTerminal";
    private static final ResourceLocation HARVESTER = ModIdentity.id("gas_harvester");

    private C9ReviewProbeGameTests() {
    }

    /**
     * 70 other missions bound to one terminal, then the owner presses CLAIM once per 10 ticks (the production
     * intent spacing), never on a multiple of 20 game ticks.
     */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 600)
    public static void c9ProbeRateLimitedClaimsAtABusyTerminal(GameTestHelper helper) {
        MinecraftServer server = helper.getLevel().getServer();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.get(server);
        SatelliteTerminalBlockEntity terminal = place(helper, new BlockPos(1, 2, 1));
        FakePlayer owner = player(helper, terminal);
        observeChunkSave(helper, terminal);
        ResourceLocation hydrogen = ForgeRegistries.ITEMS.getKey(ModItems.HYDROGEN_CANISTER.get());
        long now = server.overworld().getGameTime();
        for (int index = 0; index < 70; index++) {
            UUID other = UUID.randomUUID();
            UUID craft = craft(data, other, server);
            SatelliteOperationCode code = data.resources(missions -> missions.startResource(
                    new ResourceMissions.ResourceStart(craft, UUID.randomUUID(), other, MissionKind.GAS,
                            PlanetaryContent.GAS_GIANT, Optional.empty(), List.of(new RewardEntry(hydrogen, 1)),
                            "gas-v1/probe/0123456789abcdef", 200, 1L, terminal.terminalId(), Optional.empty()),
                    now)).code();
            helper.assertTrue(code == SatelliteOperationCode.SUCCESS, "filler start " + code);
        }
        UUID mine = craft(data, owner.getUUID(), server);
        SatelliteOperationCode started = data.resources(missions -> missions.startResource(
                new ResourceMissions.ResourceStart(mine, UUID.randomUUID(), owner.getUUID(), MissionKind.GAS,
                        PlanetaryContent.GAS_GIANT, Optional.empty(), List.of(new RewardEntry(hydrogen, 5)),
                        "gas-v1/probe/0123456789abcdef", 200, 1L, terminal.terminalId(), Optional.empty()),
                now)).code();
        helper.assertTrue(started == SatelliteOperationCode.SUCCESS, "own start " + started);
        chip(helper, terminal, new SatelliteIdentity(mine, owner.getUUID(), HARVESTER, SatelliteKind.GAS_HARVESTER,
                components()));
        data.completeDue(0L);
        data.completeDue(10_000L);
        data.flush(server);
        int[] presses = {0};
        int[] reconciling = {0};
        int[] other = {0};
        String[] finalCode = {"none"};
        List<String> contrast = new java.util.ArrayList<>();
        StringBuilder trace = new StringBuilder();
        helper.onEachTick(() -> {
            long gameTime = helper.getLevel().getGameTime();
            if (presses[0] >= 25) {
                // Phase B: presses right on the periodic pass tick (game time a multiple of 20), 20 ticks apart.
                if (contrast.size() < 3 && gameTime % 20L == 0L && !contrast.contains("SUCCESS")) {
                    terminal.handleButton(owner, SatelliteTerminalMenu.BUTTON_CLAIM);
                    contrast.add(SatelliteOperationCode.values()[terminal.saveWithoutMetadata().getCompound(KEY)
                            .getInt("last_result")].name());
                }
                return;
            }
            if (gameTime % 10L != 5L) {
                return;
            }
            if (!contrast.isEmpty() || "SUCCESS".equals(finalCode[0])) {
                return;
            }
            terminal.handleButton(owner, SatelliteTerminalMenu.BUTTON_CLAIM);
            presses[0]++;
            SatelliteOperationCode code = SatelliteOperationCode.values()[terminal.saveWithoutMetadata()
                    .getCompound(KEY).getInt("last_result")];
            trace.append(presses[0]).append('@').append(gameTime % 20L).append('=').append(code.name().charAt(0))
                    .append(' ');
            if (code == SatelliteOperationCode.RECONCILING) {
                reconciling[0]++;
            } else {
                other[0]++;
                finalCode[0] = code.name();
            }
        });
        helper.runAfterDelay(400, () -> {
            AdvancedRocketryCommunity.LOGGER.info("C9_PROBE livelock phaseA(gameTime%10==5) presses={} reconciling={} "
                    + "other={} last={} bound=71; phaseB(gameTime%20==0) codes={} trace={}", presses[0], reconciling[0],
                    other[0], finalCode[0], contrast, trace);
            helper.succeed();
        });
    }

    /** A claimed reward sits in the buffer; the terminal is broken with drops. */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 60)
    public static void c9ProbeBreakingATerminalWithABuffer(GameTestHelper helper) {
        MinecraftServer server = helper.getLevel().getServer();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.get(server);
        BlockPos relative = new BlockPos(1, 2, 1);
        SatelliteTerminalBlockEntity terminal = place(helper, relative);
        FakePlayer owner = player(helper, terminal);
        observeChunkSave(helper, terminal);
        ResourceLocation hydrogen = ForgeRegistries.ITEMS.getKey(ModItems.HYDROGEN_CANISTER.get());
        UUID mine = craft(data, owner.getUUID(), server);
        long now = server.overworld().getGameTime();
        data.resources(missions -> missions.startResource(new ResourceMissions.ResourceStart(mine, UUID.randomUUID(),
                owner.getUUID(), MissionKind.GAS, PlanetaryContent.GAS_GIANT, Optional.empty(),
                List.of(new RewardEntry(hydrogen, 100)), "gas-v1/probe/0123456789abcdef", 200, 1L,
                terminal.terminalId(), Optional.empty()), now));
        chip(helper, terminal, new SatelliteIdentity(mine, owner.getUUID(), HARVESTER, SatelliteKind.GAS_HARVESTER,
                components()));
        data.completeDue(0L);
        data.completeDue(10_000L);
        data.flush(server);
        SatelliteOperationCode code = SatelliteOperationCode.RECONCILING;
        for (int attempt = 0; attempt < 8 && code == SatelliteOperationCode.RECONCILING; attempt++) {
            terminal.handleButton(owner, SatelliteTerminalMenu.BUTTON_CLAIM);
            code = SatelliteOperationCode.values()[terminal.saveWithoutMetadata().getCompound(KEY).getInt("last_result")];
        }
        int buffered = terminal.saveWithoutMetadata().getCompound(KEY).getList("reward_buffer", Tag.TAG_COMPOUND)
                .stream().mapToInt(tag -> ((CompoundTag) tag).getInt("count")).sum();
        BlockPos absolute = helper.absolutePos(relative);
        ServerLevel level = helper.getLevel();
        level.destroyBlock(absolute, true);
        List<ItemEntity> drops = level.getEntitiesOfClass(ItemEntity.class, new AABB(absolute).inflate(3.0D));
        int canisters = drops.stream().filter(entity -> entity.getItem().is(ModItems.HYDROGEN_CANISTER.get()))
                .mapToInt(entity -> entity.getItem().getCount()).sum();
        boolean carried = drops.stream().anyMatch(entity -> entity.getItem().is(ModBlocks.SATELLITE_TERMINAL.get()
                .asItem()) && entity.getItem().getTag() != null && entity.getItem().getTag().contains("BlockEntityTag"));
        AdvancedRocketryCommunity.LOGGER.info("C9_PROBE break claim={} bufferedBefore={} droppedEntities={} "
                        + "droppedCanisters={} terminalItemCarriesRoot={} drops={}", code, buffered, drops.size(),
                canisters, carried, drops.stream().map(entity -> entity.getItem().toString()).toList());
        drops.forEach(ItemEntity::discard);
        helper.succeed();
    }

    private static void observeChunkSave(GameTestHelper helper, SatelliteTerminalBlockEntity terminal) {
        ServerLevel level = helper.getLevel();
        LevelChunk chunk = level.getChunkAt(terminal.getBlockPos());
        MinecraftForge.EVENT_BUS.post(new ChunkDataEvent.Save(chunk, level, ChunkSerializer.write(level, chunk)));
    }

    private static UUID craft(SatelliteMissionSavedData data, UUID owner, MinecraftServer server) {
        UUID satelliteId = UUID.randomUUID();
        SatelliteBlueprint blueprint = new SatelliteBlueprint(components(), false,
                new SatelliteStats(4, 10_720, 1_000, 9, 10));
        data.launchIdle(time -> SatelliteState.launchIdle(satelliteId, HARVESTER, owner, time,
                PlanetaryContent.GAS_GIANT, blueprint, new SatelliteKindState.Plain(SatelliteKind.GAS_HARVESTER)),
                server.overworld().getGameTime());
        return satelliteId;
    }

    private static List<ResourceLocation> components() {
        return List.of(key(ModItems.SATELLITE_CHASSIS.get()), key(ModItems.GAS_INTAKE_MODULE.get()),
                key(ModItems.SATELLITE_CARGO_HOLD.get()));
    }

    private static void chip(GameTestHelper helper, SatelliteTerminalBlockEntity terminal, SatelliteIdentity identity) {
        var slots = terminal.menuInventory();
        slots.extractItem(SatelliteTerminalBlockEntity.SLOT_CONTROL_CHIP, 64, false);
        ItemStack chip = new ItemStack(ModItems.SATELLITE_CONTROL_CHIP.get());
        SatelliteItemData.write(chip, identity);
        helper.assertTrue(slots.insertItem(SatelliteTerminalBlockEntity.SLOT_CONTROL_CHIP, chip, false).isEmpty(),
                "Could not insert the control chip");
    }

    private static SatelliteTerminalBlockEntity place(GameTestHelper helper, BlockPos position) {
        helper.setBlock(position, ModBlocks.SATELLITE_TERMINAL.get().defaultBlockState()
                .setValue(SatelliteTerminalBlock.FACING, Direction.NORTH)
                .setValue(SatelliteTerminalBlock.LIT, false));
        SatelliteTerminalBlockEntity terminal = (SatelliteTerminalBlockEntity) helper.getBlockEntity(position);
        terminal.getCapability(ForgeCapabilities.ENERGY).resolve().orElseThrow()
                .receiveEnergy(SatelliteTerminalBlockEntity.ENERGY_CAPACITY, false);
        return terminal;
    }

    private static FakePlayer player(GameTestHelper helper, SatelliteTerminalBlockEntity terminal) {
        FakePlayer player = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "C9Probe"));
        BlockPos position = terminal.getBlockPos();
        player.setPos(position.getX() + 0.5D, position.getY() + 1.0D, position.getZ() + 0.5D);
        return player;
    }

    private static ResourceLocation key(Item item) {
        return ForgeRegistries.ITEMS.getKey(item);
    }
}
