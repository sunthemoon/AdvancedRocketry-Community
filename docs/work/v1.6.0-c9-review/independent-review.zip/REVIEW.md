# C9 independent review: v1.6 satellite resource missions (C8a-2, C8a-1, C8b)

Reviewer: independent C9 reviewer (read-only toward the repository). Date: 2026-10-01.

## Scope

| Item | Value |
|---|---|
| Reviewed commit | `ce55ee338316bfaa6062030c7a3251211e723c15` (branch `codex/v1.6.0-satellite-resource-missions`) |
| Reviewed tree | `57866775f3f51a1129282863405bb4749e6607c7`, exported with `git archive ce55ee3` into `tree/` |
| Commits in scope | `d15dfcc` C8a-2 (resource tables, algorithms, `mission verify`), `53d4cf7` C8a-1 (ADR-050 write policy, limits, budgets, retention), `ce55ee3` C8b (resource missions, terminal delivery, reconciliation) |
| Contracts | ADR-050 rev 4, ADR-051 rev 3, ADR-052 rev 2, `docs/work/v1.6.0-preparation/examples.json` |
| Not reviewed | Uncommitted changes in the working tree (`SatelliteManager`, `SatelliteCommands`, `SatelliteRuntime`, `AdvancedRocketryCommunity`, `ReleaseTestCommands`, `docs/releases/v1.6.0/`); the directory `AdvancedRocketry-Community-v1plus-Development-Docs/` was not opened |

File list: `files-reviewed.txt`. Probe outputs: `probe-results.txt`, `probe-unit.log`,
`baseline-tests.log`, `probe-gametest.log`, `probe-gametest-2.log`.

## Commands run

All Gradle runs were in the exported copy `tree/` with `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`. No
command wrote to the repository. `git status` of the repository was checked at the end; its changes come
from other sessions, not from this review.

| # | Command | Result |
|---|---|---|
| 1 | `git -C <repo> archive ce55ee3 \| tar -x -C tree` | Tree `57866775…` exported |
| 2 | `git -C <repo> log`, `diff --stat e7119a8 ce55ee3`, targeted `git diff` of wiring, menu and fixture files | 90 files, +9,878/−383 lines in C8a-1 and C8b |
| 3 | `./gradlew test --tests '*ResourceMissionsTest' --tests '*DeliveryCrashCutTest' --tests '*TerminalDeliveryTest' --tests '*DeliveryReconciliationTest' --tests '*RegistryLifecycleTest' --tests '*SatelliteWritePolicyTest' --tests '*RewardVerifierTest' --tests '*ResourceAlgorithmsTest' --tests '*DeliveryRuntimeTest'` | BUILD SUCCESSFUL. 9 suites, 42 tests, 0 failures, 0 errors |
| 4 | Reviewer probe `C9ReviewProbeTest` (3 unit tests, written only in `tree/`): `./gradlew test --tests '*C9ReviewProbeTest'` | Exit 0. All 3 probes confirmed their defect (M1, M2, M3 below) |
| 5 | Reviewer probe `C9ReviewProbeGameTests` (2 GameTests in the resource batch, only in `tree/`): `./gradlew runGameTestServer` | Exit 0, `All 291 required tests passed` (the implementers' 289 plus the 2 probes). The probes log the defects (H1, H2 below) and do not fail on them |
| 6 | Same as 5, rerun with a per-press trace | Exit 0, `All 291 required tests passed`; deterministic trace for H1 |

Probe results (verbatim, from `probe-results.txt`):

```text
C9_PROBE long level: start=SUCCESS reloadOperational=false
C9_PROBE retention: cycles=2000 records=2 finished=1 globalQueue=2000 ownerQueues=1
C9_PROBE ledger: cycles=2000 instances=1 expiryQueue=2001
C9_PROBE break claim=SUCCESS bufferedBefore=100 droppedEntities=2 droppedCanisters=0 terminalItemCarriesRoot=false drops=[1 satellite_terminal, 1 satellite_control_chip]
C9_PROBE livelock phaseA(gameTime%10==5) presses=25 reconciling=25 other=0 last=none bound=71; phaseB(gameTime%20==0) codes=[SUCCESS] trace=1@5=R 2@15=R … 25@5=R
(run 1 of the same probe, without the trace: presses=25 reconciling=24 other=1)
```

## Findings

Paths are relative to `tree/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless stated.

| ID | Severity | Location | Description | Failure scenario | Recommended fix |
|---|---|---|---|---|---|
| C9-H1 | High | `satellite/terminal/TerminalResourceActions.java:277-289` (gate), `:83-92` (periodic pass), `satellite/mission/TerminalIndex.java:19-26`; masked by `gametest/ResourceMissionGameTests.java:425-434` | When a terminal has more than 64 bound missions plus receipts, resource actions almost always fail with `RECONCILING`. The gate starts a full pass whenever none is active, steps 64, and refuses if the pass is still active. The index keeps every resource mission bound to the terminal in any status, including CLAIMED with a durable ack and CANCELLED, until retention prunes it. So N grows with normal use. An action succeeds only if it arrives in the one tick in which a pass is active with at most 64 left. ADR-051 §7 says actions *wait* for the pass. Here they are refused, and the next press starts a new pass. | Normal play: an owner has run about 65 asteroid or gas missions through one terminal. On a small server nothing is pruned: global finished ≤ 1,536, and the owner limit is 128 finished of all kinds. Probe (71 bound, production spacing of 1 press per 10 ticks): 25 of 25 presses at game time ≡ 5 or 15 (mod 20) returned `RECONCILING`; the first press at ≡ 0 succeeded. A human press lands in the success window about 1 time in 20. The GameTest helper `act()` presses up to 16 times in one tick and bypasses the menu's intent limiter, so the 272-claim test passes and the defect is hidden. | Do not refuse an action while a pass restarts. Options: (a) treat reconciliation as fresh when a full pass finished since the last change to this terminal's receipts or bound set; (b) queue the intent and run it when the pass completes; (c) keep settled records out of the pass (CLAIMED with a durable ack and CANCELLED without a receipt). A receipt still brings its mission into the pass. Add a GameTest that goes through `SatelliteTerminalMenu.clickMenuButton` with the real rate limiter and more than 64 bound missions. |
| C9-H2 | High | `satellite/terminal/SatelliteTerminalBlock.java:81-92` (`getDrops` carries the root only when `blocked()`), `:129-136` (`onRemove` drops only the 6 inventory slots) | Breaking a normal (non-quarantined) terminal deletes its reward buffer (up to 3,456 items), its receipts and its `terminal_id`. The item that drops carries no root. ADR-051 §5 says `terminal_id` is "carried with the raw root when the block is taken as an item". No stated residual covers this loss. Every ACTIVE or READY mission bound to the old ID is stranded: a claim elsewhere is `WRONG_TERMINAL`, and the owner cancel works only at the bound terminal. The satellite stays busy until an operator runs `rebind`, and `rebind` accepts only READY missions. An unacknowledged CLAIMED record can never be pruned without `purge`. | Normal survival: claim a reward, then break the terminal to move it. Probe: buffer 100 canisters; `destroyBlock(pos, true)` dropped `[1 satellite_terminal, 1 satellite_control_chip]` and 0 canisters. The terminal item carries no `BlockEntityTag`. | Carry the whole bounded schema-2 root (ID, buffer, receipts) on normal removal. This is what the ADR text says. Placement then restores it unpersisted, as `BlockEntity.load` already does. Alternatively, refuse survival removal while the buffer, receipts or unfinished bound missions are non-empty. At minimum, drop the buffer as items and write an audit line. Add a GameTest that breaks and re-places a terminal with a buffer, a receipt and a bound READY mission. |
| C9-M1 | Medium | `satellite/mission/MissionRetention.java:89-121` (prune), `:149-157` (enqueue into both queues) | Each prunable record is put in the global queue and in its owner's queue. A record removed through one queue leaves a stale entry in the other. The other queue is drained only under its own trigger: the global queue while finished > 1,536, an owner's queue while that owner has finished > limit. The stale entries therefore accumulate for the whole uptime. This breaks ADR-050 §5, "A queue never holds more entries than there are records it serves". When the threshold is later crossed, the stale entries use up the 128-inspection budget and delay real pruning. | Probe (per-owner limit 1, one owner, 2,000 start/claim cycles with passes): 2 records, 1 finished, **2,000 entries** in the global queue. The same happens in reverse on busy servers: records pruned globally leave entries in owner queues. | Keep one queue with lazy deletion and discard stale heads regardless of the trigger condition (bounded by inspections). Or remove an entry from both queues when a record is removed, for example with an `eligibleAt` map and `TreeSet`s. Add a test that bounds queue size by records. |
| C9-M2 | Medium | `satellite/mission/InstanceLedger.java:36-56` (`changed` always adds an entry), `:71-94` (pass); the trigger is `satellite/mission/ResourceMissions.java:273-279` (owner cancel returns the instance to AVAILABLE with the same `expires_at`) | Each time an instance returns to AVAILABLE, the ledger adds another expiry entry with the same due time and removes none. Start/cancel churn grows the expiry queue without bound until `expires_at`, which can be up to 1,728,000 ticks. This breaks ADR-050 §5, "A queue never holds more entries than there are records it serves". When the entries come due they share the 32-inspection budget (1.6 per tick), so other expiries and removals of DEPLETED or EXPIRED records are delayed. The owner's live count and the global 2,048 records stay occupied meanwhile. | Probe: 2,000 asteroid start/owner-cancel cycles on one instance gave 1 instance and **2,001** queue entries. One player at the 10-tick intent limit adds about 8,400 entries per default TTL. | Keep at most one live entry per instance, for example a `Map<UUID, Long>` of queued due times, and skip `add` when the same due time is queued. Or remove the previous entry on change. Add a churn test that bounds the queue size. |
| C9-M3 | Medium | `satellite/mission/MissionPayload.java:106-111` (no bound on `TerminalLocation.level`), `satellite/service/DeliveryTerminal.java:20-22`, encode `satellite/persistence/SatelliteNbtCodec.java:320-323`, decode `:366-373` → `:533-536` (rejects > 128 characters) | The display-only level ID of the bound terminal is not bounded when a record is created. It comes from the terminal's dimension (start, rebind, REBIND_CONFLICT bind-back). The decoder rejects anything over 128 characters. `CodecRecordSizer` reserves only 128. This breaks ADR-050 §3 ("Bounds are enforced when a record is created or changed, never only when encoding"): a start saves without error, and the next load blocks the **whole** registry fail-closed. | A server with a datapack dimension whose ID is longer than 128 characters. A player starts an asteroid or gas mission at a terminal there, and the server restarts. Probe: start `SUCCESS`, `SatelliteMissionSavedData.load(save())` gives `operational() == false`. | Validate the level ID length (≤ 128) in `TerminalLocation` or `DeliveryTerminal.display()`. Store `Optional.empty()` when it is longer, since it is display-only. Test a 129-character dimension at start, rebind and bind-back. |
| C9-L1 | Low | `satellite/terminal/TerminalResourceActions.java:141-147`; `satellite/mission/SatelliteOperationResult.java:24-28` | The terminal pays the reward when `result.success()`. That method is also true for `ALREADY_CLAIMED`, `IDEMPOTENT` and `PENDING_DISCOVERY`. `claimResource` returns `SUCCESS` only after `settle`, and `ALREADY_CLAIMED` needs a satellite whose `current_mission` is CLAIMED, which the invariants prevent. So this path cannot be reached today, but it is a latent double payment. | A future change that returns `ALREADY_CLAIMED` with the mission (for example a replay path) would pay again. `pay` throws only if a receipt is still present. | Pay only when `result.code() == SUCCESS && result.changed()`. |
| C9-L2 | Low | `satellite/service/ResourceMissionService.java:256-263` (REBIND_CONFLICT barrier flush, unguarded), called from `satellite/terminal/TerminalResourceActions.java:291-316` inside `SatelliteTerminalBlockEntity.serverTick` (`satellite/terminal/SatelliteTerminalBlockEntity.java:105-107`) | Reconciliation runs in the block-entity ticker without a guard. A `RuntimeException`, for example an IO failure in the bind-back barrier flush, leaves the ticker and crashes the server ("Ticking block entity"). The bind-back was not persisted, so the same row and the same crash repeat after restart while the fault lasts. Every other barrier site catches and logs the failure (`satellite/service/SatelliteManager.java:129-145`, `:419-439`). | Disk full or a permission error during REBIND_CONFLICT. | Wrap the barrier in `reconcile` (log once, and leave it pending so the coalesced flush retries). Guard `step()` so that one failing row is logged and the terminal keeps ticking. |
| C9-L3 | Low | `satellite/terminal/TerminalResourceActions.java:165-184` (withdraw is never gated on persistence) | A player can withdraw a claimed reward before its receipt is in a chunk save. With the ADR-051 §11 cut "registry flushed, chunk not", REMATERIALIZE then pays the full reward again, and the withdrawn stack survives in the player file. A torn vanilla chest/player save has the same kind of defect, but it conflicts with the S1/S2 statement "the reward exists exactly once". | Claim → withdraw → log out (player saved) → coalesced flush within 100 ticks → crash before the chunk's incremental save (≤ about 10 s). | Refuse WITHDRAW while any receipt is unpersisted. This only lasts until the next chunk save, and the terminal already calls `setChanged()` to shorten it. Alternatively, document it as a residual. |
| C9-L4 | Low | `satellite/service/ResourceMissionService.java:125-192` (asteroid and gas starts never consult the satellite catalog), compared with the survey start at `:93-101` | ADR-050 §11 says that removing or changing a definition refuses new starts with `DEFINITION_NOT_FOUND`. Survey starts check the current kind definition. Asteroid and gas starts do not, so a datapack that removes `asteroid_miner` or `gas_harvester` does not stop new missions of existing satellites. | A datapack reload removes the gas harvester definition, and existing harvesters keep starting missions. | Look up the current kind definition in `startAsteroid` and `startGas`, and refuse with `DEFINITION_NOT_FOUND`. |
| C9-L5 | Low | `satellite/service/SatelliteManager.java:383-417` (`cancelCurrent`, used for survey cancels through `SatelliteRuntime.cancel`), `:419-439` (`cancelAdmin` for asteroid and gas) | v1.6 survey cancels and operator cancels of resource missions still run barrier flushes. ADR-050 §2 ("v1.6 starts, claims and cancels … mark flush pending") and its Consequences ("New v1.6 paths add no barrier flush") say they should not. This is safe for conservation but adds full-root main-thread writes that the C9 flush measurements must count. | Survey cancel at a terminal, or `admin mission cancel` of an asteroid mission. | Route survey and resource cancels through `resources()` without `flush`, or record the deviation for the C9 performance evidence. |
| C9-L6 | Low | `satellite/resource/RewardVerifier.java:86-104` | `verifyAsteroid` reports `MATCH` when the instance's asteroid type changed or is gone. The instance outcome appears only in the detail text. ADR-052 §7 names `VERSION_CHANGED` and `INPUTS_UNAVAILABLE` for these cases. `RewardVerifierTest` does not cover them. | `mission verify` of an asteroid mission after a table rebalance says MATCH. | Propagate a non-MATCH instance outcome, or document that the mission check covers only truncation. Add the two test cases. |
| C9-L7 | Low | `satellite/mission/MissionDeadlineScheduler.java:46-49` | Every claim, cancel, lazy completion and quarantine runs `queue.removeIf(...)`, a linear scan of up to 8,192 entries. ADR-050 §5 says counters and queues are maintained without a full scan per operation. The cost is small at 1,024 unfinished missions. | Many claims or cancels per tick on a full registry. | Use lazy deletion (drain already skips stale entries) or an indexed structure. |
| C9-L8 | Low | `gametest/ResourceMissionGameTests.java:425-434`; `src/test/.../satellite/persistence/SatelliteWritePolicyTest.java:42-68`; `src/test/.../satellite/terminal/DeliveryCrashCutTest.java:178-183` | Test quality. (a) `act()` repeats a button up to 16 times in the same tick and skips the per-player intent limiter, which hides H1. (b) No test breaks a terminal (H2). (c) The write-policy test covers 12 C7/C8a change kinds but none of the C8b resource paths. ADR-050 rev 4 item 1 asks C8 to test the rule. Acknowledgements are covered indirectly by the crash-cut ack→flush→drop test. (d) The crash-cut test restarts from in-memory `save()` snapshots and simulates `ChunkDataEvent.Load` by marking every read receipt persisted. It does not use `TerminalChunkEvents` or `TerminalObservations`, so the VERIFICATION wording "restarts from files written at different moments" overstates it. | — | Drive A1 actions through the menu with real spacing. Add break/carry tests. Extend `SatelliteWritePolicyTest` to start, claim, cancel, reconcile/acknowledge, rebind, purge, release and expiry/prune. Add one crash-cut test through the chunk-event path. |
| C9-L9 | Low | `satellite/terminal/SatelliteTerminalBlockEntity.java:178-183`, `:191`; `satellite/terminal/SatelliteTerminalBlock.java:76` | WITHDRAW is authorized only by terminal ownership. A terminal whose `ownerId` is null (placed by `/setblock`, a structure or a non-player placer) lets any player open it and withdraw rewards paid for another player's missions. | Player A binds missions to an unowned terminal, and player B withdraws the buffer. | Set the owner at first resource start, or allow withdrawal only to the owner of the paid missions (or an operator). |

Counts: Critical 0, High 2, Medium 3, Low 9.

### Questions (not verified as defects)

- Q1. `instance release` of an instance held by an operator cancel of a reverted claim (the §11 cut
  "PAID_THEN_CANCELLED") returns an already-paid instance to AVAILABLE. ADR-050 §8 and ADR-051 §2 leave
  this check to the operator. Should `releaseInstance` refuse, or warn, when a terminal has reported a
  receipt for the allocating mission?
- Q2. Duplicate terminal IDs are outside the ADR. They can come from creative pick-block with NBT,
  structure blocks, `/clone` or third-party movers that copy block-entity NBT. Two terminals with one ID can
  both rematerialize the same unacknowledged claim. Is creative- or operator-only duplication accepted as
  out of scope?
- Q3. `ChunkDataEvent.Save` is taken to fire only on the main thread before the `IOWorker` write, and
  resource-mission code relies on this. Forge 47.4.10 behaves this way as far as I know, but I did not
  check it against the Forge sources.

## Assessment of the implementation clarifications

C8b (`docs/work/v1.6.0-c8b-delivery/VERIFICATION.md`):

1. **Missing terminal = the rebind itself.** Acceptable. ADR-051 §9 allows an operator declaration, and
   the record schema has no field for it. `TERMINAL_MISSING` is derived from the loaded chunk, and the rebind
   is audited with the old terminal. Note: rebind does not check that the old terminal is actually missing. The ADR
   makes rebind an operator decision, so this is acceptable.
2. **Replayed claims keep `ALREADY_CLAIMED` (registry) and `MISSION_NOT_FOUND` (terminal).** Acceptable. No
   replay pays. See C9-L1: the terminal's `success()` check would also accept `ALREADY_CLAIMED`, which
   is not reachable today.
3. **Busy craft answers `MISSION_BUSY` first.** Acceptable. It reveals nothing, and it runs before any selection
   lookup.
4. **One-off audits once per receipt per load (runtime flag).** Acceptable. The output stays bounded (≤ 256
   receipts per terminal per load) and matches the intent of "once".
5. **Changed existing GameTest (a survey chip now starts a survey).** Acceptable. ADR-051 §3 requires this
   behaviour change, and the new assertion is stronger than the old one.

C8a-1 (`docs/work/v1.6.0-c8a-scheduler/VERIFICATION.md`):

1. **Expiry, purge, rebind and instance release delivered in C8b.** Acceptable. All four are present in
   `ce55ee3` (`InstanceLedger`, `ResourceMissions.purge/rebind/releaseInstance`, `ResourceMissionCommands`).
2. **Research accounts reserve a fixed 128 bytes.** Acceptable. The account record (schema, UUID, int and
   two longs) has a fixed shape that never grows. By hand it encodes to about 120 bytes. I did not measure
   it separately.
3. **A load-time quarantine or recovery counts as a change.** Acceptable, and needed for ADR-050 rev 4
   item 1 (`finishRestore` sets `changedSinceEpoch`, and the SavedData sets `flushPending`).

C8a-2 (`docs/work/v1.6.0-c8a-resources/VERIFICATION.md`): the balance table (ore choices and time multipliers)
is data, not contract. It keeps the ADR-052 §8 reference numbers (weights 20/15/2/1, masses
200/200/75/50, richness 30/20/20/20, variability 50 and 50/50/30/50, cobblestone base, hydrogen 8 per 1,000
ticks). Acceptable. `SatelliteRecordFit` reporting `DOES_NOT_FIT` instead of throwing is acceptable.

## What was checked and holds

- ADR-051 §7 table: `DeliveryReconciliation.decide` matches all 36 rows (the test is exhaustive over the enum
  product). `ResourceMissions.reconcile` applies the registry side and `TerminalDelivery.apply` applies the
  terminal side, in one tick. Only the paying terminal rematerializes or acknowledges. A blocked registry
  changes nothing and keeps the receipts.
- ADR-051 §6 preconditions: bound terminal (`WRONG_TERMINAL`), whole-reward room and a receipt slot (`room()` is
  evaluated inside the registry lock), `start_epoch < save_epoch`, and a READY mission (with lazy
  completion reported as a change). The claim, instance DEPLETED, satellite release and reward+receipt happen
  in the same tick.
- ADR-051 §2 and §8: all instance transitions match the table. Operator, QUARANTINED and rebound cancels
  hold the instance. An owner cancel needs the bound terminal and, at the terminal, a completed pass.
- ADR-051 §5: `BlockEntity.load` always starts unpersisted. Only `ChunkDataEvent.Save`, which marks the live
  terminal from its own tag entry, and `ChunkDataEvent.Load`, which records a synchronized, bounded
  observation consumed at the terminal's first tick, mark anything persisted. `setChanged()` runs every 20
  ticks while something is unpersisted.
- Acknowledgement durability: `ack_epoch = E` is a change. `markPersisted` advances E only after a changed
  write returns, re-offers durable acknowledgements to retention, and the receipt is dropped only when
  `ack_epoch < E`. Retention of CLAIMED resource records requires the same condition.
- ADR-050 §2: resource starts, claims, cancels, reconciliation, rebind, purge, release, expiry and pruning mark
  "flush pending" through the SavedData wrappers. Every path that changes a record returns
  `changed = true`. The coalesced flush runs at most once per 100 ticks and a failure keeps it pending. The
  REBIND_CONFLICT bind-back is a barrier.
- Budgets and limits: counts are checked before any map mutation. Lifecycle reservations cover
  claim/ack/quarantine/rebind variants (except C9-M3). Rewards are ≤ 1,728 items (cargo ≤ 27) and the buffer
  holds ≤ 3,456 items and 32 entries. The terminal root stays well within 64 KiB. The view packet is ≤ 12 KiB.
  Audit lines are ≤ about 410 bytes, below the 512-byte check.
- Authority: no packet carries a seed, reward, index, instance or product. Selections are kept on the server.
  Starts and claims require the chip owner to be the player. Operator paths require permission level 2. No
  chunk tickets or forced loads (`getChunkNow` only).
- Class sizes: registry 794 lines and terminal block entity 779 lines, both below 800.

## Verdict

**ACCEPT WITH REQUIRED CHANGES**. Required: C9-H1, C9-H2, C9-M1, C9-M2, C9-M3. Strongly recommended with
them, because each is small: C9-L1, C9-L2 and C9-L8(a)/(b), which are the tests that would have caught H1 and H2.
The delivery protocol, the reconciliation table, the epoch rule and the crash-cut behaviour are
implemented as the accepted contracts describe. I found no normal-play duplication path. The required items
are a usability livelock, a reward loss on breaking a terminal, two unbounded queues and one bound that is
enforced only at load time. None of them needs a contract revision. C9-H2 follows the ADR-051 §5 text
("carried with the raw root").
