# Independent implementation review — v1.7.0 C11, round 3 (confirmation)

- Reviewed: `a8cf76d..6ace111` on `codex/v1.7.0-endgame-systems` (HEAD
  `6ace1115171677e4050aaccb312ed685a4696091`): `45d337c` (C11R2-L1), `4178839` (C11R2-L2), `6ace111` (C11R2-I4 and
  the log's record of I1, I2, I3, I5), against [REVIEW-ROUND2.md](REVIEW-ROUND2.md).
- Method: diffs read in full; suites and probes run in a fresh `git archive` export (`tree3/`). The repository was
  only read, with no Gradle runs in it. The untracked review draft, `endgame/transit` work in progress and the user
  documentation bundle are out of scope and were not read.
- Path convention: Java paths are relative to `tree3/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.

## Result

Both round-2 Low findings are fixed and I4 is done. The index refactor is behaviour-identical, and I found no new
problems. The verdicts stay **ACCEPT** for C11a, C11b, C11c and C11d.

## Per-finding status

| Finding | Commit | Status | Verification |
|---|---|---|---|
| **C11R2-L1** (an owner change before registration registered the old owner) | `45d337c` | **Fixed** | See below. |
| **C11R2-L2** (`EndgameService` over 500 lines) | `4178839` | **Fixed** | See below. |
| C11R2-I1 (skip rule leaves a block a same-layer reaction transformed; vanilla drops lie in the shaft) | log only | **Accepted** (no change) | Recorded in the log; the C13 operator guide will cover it. |
| C11R2-I2 (`TARGET_OUT_OF_BOUNDS` for keys too long to record) | log only | **Accepted** (no change) | Recorded. |
| C11R2-I3 (C11 development-format roots quarantine) | log only | **Accepted** (no change) | Recorded; the format was never released. |
| C11R2-I4 (duplicate import, misplaced Javadoc) | `6ace111` | **Fixed** | The import is removed (`gametest/LaserTargetGameTests.java`), and the `command(...)` Javadoc is back above its method (`gametest/GravityFieldGameTests.java`). |
| C11R2-I5 (flaky v1.3 rocket GameTest) | log only | **Accepted** (watched) | It passed in this run. |

**C11R2-L1 details.** `LaserTargetBlockEntity.ownerChanged` now re-awaits a not-yet-registered, not-frozen marker
under the new owner in the same tick (`endgame/laser/LaserTargetBlockEntity.java`, after `reset(null)`). This
replaces the waiting candidate (`EndpointRegistrations.await`). A request queued from an earlier save no longer
equals the waiting candidate, so `drain` skips it. A registered marker is still handled by `reassign`.

- My unchanged round-2 probe `anOwnerChangeBeforeRegistrationCanRegisterTheOldOwner` now **fails its assertion** as
  intended: `command_result=1 block_entity_owner_is_new=true registered_record_owner_is_old=false`.
- My inverted round-3 probe `anOwnerChangeBeforeRegistrationRegistersTheNewOwner` passes:
  `registered_record_owner_is_new=true`. It uses the same timing as round 2, plus one save before the command (which
  queues a stale request in the same tick) and one save after it.
- The fix's own GameTest (`LaserTargetGameTests.anOwnerChangeBeforeRegistrationRegistersTheNewOwner`) passes.

**C11R2-L2 details.** The chunk index moved verbatim to `endgame/service/EndpointChunkIndex.java` (126 lines,
`ChunkKey` included). `EndgameService` is now 444 lines. I compared old and new code line by line:

- `rebuild` and `update` have the same bodies.
- `clear()` still clears both maps, including in the not-operational branches.
- `watches(key)` is `containsKey(key) || containsKey(key.hashed())`, the old inline condition.
- `idsAt(key)` is the same union of the exact and hashed entries.
- `keyOf` and `chunkOf` are unchanged, and the `ChunkKey` record has the same components and equality.
- The concurrent map of immutable sets is kept, so chunk-load readers are unaffected.

No `EndgameService.ChunkKey` reference remains (the tree compiles). The index-versus-rebuild unit test passes, and
the benchmark is unchanged (below). The log now gives the drill block entity's current 587 lines.

## Commands run (in `tree3/`, Java 17.0.7, `--no-daemon --offline`; logs in `logs/`)

| Command | Result |
|---|---|
| `git -C <repo> show/diff/archive 6ace111` (read-only) | `tree3/` = `6ace111`; `gen-ref3/` = committed `src/generated` |
| `gradlew clean build test runData runGameTestServer` with the round-2 probes (unchanged), the round-3 probe and the benchmark | build, test and runData OK; **330 GameTests: 329 passed, 1 failed** — the unchanged round-2 race probe, which asserts the old bug and now fails as intended (`logs/round3-full.log`). That is 321 of yours, 8 round-2 probes and 1 round-3 probe, so all 321 of yours pass. |
| JUnit from that run | **1,305 tests / 241 suites, 0 failures** (1,304 / 240 plus my benchmark) |
| `diff -r gen-ref3/src/generated tree3/src/generated` after runData | identical except the git-ignored `v1.7/resources/.cache` |
| Error lines in that log | 19 ERROR (the evidence's 18 plus the one intended probe failure line), 0 FATAL |
| Benchmark | 3,840 settled → idle 0.001 ms, no-op call 0.003 ms; 8,192 settled → idle 0.012 ms, no-op 0.001 ms (round 2: 0.009 / 0.001; noise) |

Probe and benchmark lines are in `logs/round3-probe-results.txt`, and the probe sources are in `probes/`. No file
outside this review directory was written.
