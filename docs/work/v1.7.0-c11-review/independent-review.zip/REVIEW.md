# Independent implementation review — v1.7.0 C11 (C11a–C11d)

- Reviewed commit: `8d52d7f` (branch `codex/v1.7.0-endgame-systems`), base `9d30892`; 20 commits, 178 `src` files.
- Contracts: ADR-054 (§1–§10, §12–§16; §11 transit ledger out of scope), ADR-055, ADR-058, AGENTS.md, the
  [implementation log](tree/docs/work/v1.7.0-implementation-log.md) and the four C11 evidence packets.
- Method: full read of every C11 production class (endgame, API, persistence, gravity hook, registries, DataGen
  output, client screens/renderer), the C11 JUnit and GameTests, the reference vectors; then targeted runtime
  probes and a micro-benchmark in an exported copy. The repository was only read (`git log/diff/archive/status`).
- Review directory: `C:\Users\Administrator\AppData\Local\Temp\arce-v170-c11-review-f3c773ba`
  (`tree/` = `git archive 8d52d7f`, `probes/` = the review-only probe sources, `logs/` = all command output).
- Path convention: Java paths below are relative to
  `tree/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless they start with `tree/`.

## Summary

The C11 framework is carefully built and mostly faithful to the accepted contracts: the authority matrix, the
protection chain, the strict endgame root (codec, epoch, bounds, blocked-root preservation), endpoint
registration from persisted tags with freeze/retirement, quarantine, the `laser-v1` draw, the whole-layer
classification and the gravity field (consent, 1.00 g station cap, index caps) all check out, and no code path
loads a chunk. The existing suites pass in my copy (1,290 JUnit tests; 303 GameTests plus 9 probes).

However, the runtime probes confirm one **Critical** and two **High** problems that an ordinary player can reach:

1. **C11R-C1** — a partial shift-click out of the drill output or a laser target buffer shrinks the item
   handler's live stack without marking the block entity changed; the chunk stays clean, so the next unload or
   server stop keeps the old stack on disk while the player keeps the moved items: **item duplication**, in the
   default logical mode.
2. **C11R-H1** — a physical layer counts drops of attached blocks (wall torches, ladders, buttons, levers, cocoa,
   amethyst…) that vanilla already dropped as item entities when an earlier cell of the same layer was removed:
   **duplication** (physical mode, default off).
3. **C11R-H2** — device menus only require `VIEW`, and their item slots never check `WITHDRAW`: any player can
   empty another player's laser target outside stations; station members can take the drill's output and lens.

Five Medium findings follow (free credit layers through the 8-entry revoked-link list, `device owner` leaving the
endpoint index stale, player-triggered barrier writes through refused `endpoint forget`, unreachable `WITHDRAW` in
unavailable stations, and per-mutation index rebuilds / per-tick housekeeping), plus Low and Info items.

## Verdicts

| Slice | Verdict | Blocking findings |
|---|---|---|
| C11a — ADR-054 framework | **ACCEPT WITH REQUIRED CHANGES** | C11R-M3, C11R-M5 (C11R-L3a, L4 recommended) |
| C11b — logical mode + device parts | **REJECT** (not acceptable as delivered; fixes are local, no redesign needed; re-review after fixes) | C11R-C1 (drill output), C11R-H2 (device menu base, drill), C11R-M2, C11R-M4 |
| C11c — physical mode | **REJECT** (same note) | C11R-C1 (marker buffer), C11R-H1, C11R-H2 (marker), C11R-M1; L1, L2 recommended |
| C11d — ADR-058 gravity field | **ACCEPT** | none (C11R-L6, gravity part of L7 recommended) |

## Findings

### Critical

#### C11R-C1 — Partial shift-click from the drill output or the marker buffer is never persisted (item duplication)

- **Location:** `endgame/laser/OrbitalLaserDrillMenu.java:279-300` (`quickMoveStack`; `OutputSlot` 311-320, lens
  slot 87) and `endgame/laser/LaserTargetMenu.java:115-133` (`quickMoveStack`; `TakeOnlySlot` 135-144).
- **Mechanism:** `source.getItem()` on a Forge `SlotItemHandler` returns the live stack inside the
  `ItemStackHandler` (`getStackInSlot` returns `stacks.get(slot)`, verified with `javap` on the 47.4.10 jar).
  `moveItemStackTo` shrinks it in place. On a partial move the code calls `source.setChanged()`, which
  `SlotItemHandler` does not override: `Slot.setChanged()` calls the dummy `SimpleContainer(0)`, so the
  handler's `onContentsChanged` and the block entity's `setChanged()` never run. Only a complete move
  (`source.set(EMPTY)`) marks the block entity. Vanilla only writes unsaved chunks on autosave, unload and
  server stop (`ChunkMap.save` returns early when `!isUnsaved()`).
- **Rule violated:** ADR-054 §8 same-store rule and §15 "Duplication"; ADR-055 §1/§7 (output and drops conserved);
  the `IItemHandler#getStackInSlot` contract ("MUST NOT be modified").
- **Failure scenario:** the owner of an idle drill (stopped, no power, no lens, unformed — any state in which it
  does not operate and call `setChanged()` before the chunk unloads) or of a laser target between layers fills
  their inventory so only 10 items fit, shift-clicks a 64 stack: 10 move, 54 stay, the chunk stays clean. They
  leave (chunk unload) or the server restarts: the stack is 64 again, the player keeps 10. Repeatable without
  limit. Combined with C11R-H2, a VIEW-only player can do it too.
- **Evidence:** probe `probeAPartialQuickMoveDoesNotMarkTheBlockEntityChanged` (run 3):
  `left_in_buffer=54 player_cobblestone=64 chunk_unsaved_after_partial=false disk_before=64
  disk_after_partial_and_save=64`; control (full move) `chunk_unsaved_after_full_move=true`.
- **Suggested fix:** in both menus move a copy and write the remainder back with `source.set(remainder)` (which
  goes through `setStackInSlot`), or use a `SlotItemHandler` subclass whose `setChanged()` calls the owning block
  entity's `setChanged()`. Add a GameTest that forces a save after a partial move and reads the stored chunk tag
  (as the probe does). The same pattern should be checked in the repository's other `SlotItemHandler` menus.

### High

#### C11R-H1 — A physical layer duplicates blocks destroyed by vanilla neighbour reactions inside the same layer

- **Location:** `endgame/laser/LaserPhysicalDrill.java:131-135` (removal loop) with `plan()` 193-240 (drops of all
  breakable cells computed before any removal) and `endgame/laser/LaserTargetBlockEntity.java:296-313`
  (`layerDone` adds every planned drop).
- **Mechanism:** `Level.removeBlock` → `setBlock(..., 3)` → `updateNeighbourShapes(flags & ~33)` →
  `Block.updateOrDestroy` → `destroyBlock(pos, dropResources = true)` for every neighbour that can no longer
  survive. A breakable cell later in the same layer that hangs on an earlier cell (wall torch, soul/redstone wall
  torch, ladder, button, lever, tripwire hook, cocoa, amethyst bud/cluster, modded wall-mounted blocks) is destroyed
  with its drops spawned as an `ItemEntity`, and its planned drops are added to the marker as well.
- **Rule violated:** ADR-055 §3 steps 3–4 ("add every drop", "no drop entities") and §7 "Duplication: … whole-layer
  atomicity" / "Lost drops"; drop conservation.
- **Failure scenario:** with physical mining enabled, a player builds each layer with a support block in cell 1
  and a wall torch in cell 4 (up to four dependent cells per layer, e.g. corners as supports): every layer yields
  one extra item per dependent cell, for every layer of every shaft.
- **Evidence:** probe `probeWallTorchInOneLayerIsDuplicatedAndBreakEventsArePostedTwice` (runs 1–3):
  `torches_placed=1 torches_in_marker=1 torch_item_entities=1 cobblestone_in_marker=8`.
- **Suggested fix:** after each `removeBlock`, re-read the remaining planned cells and discard the planned drops of
  any cell whose state changed (the world already produced or kept them), or remove dependent cells before their
  supports. Add GameTests with a wall torch, a ladder and a button in the footprint.

#### C11R-H2 — Menu item slots ignore `WITHDRAW`: VIEW-only players take drops, output and the lens

- **Location:** `endgame/device/EndgameDeviceMenu.java:116-136` (`stillValid` needs only `VIEW`);
  `endgame/laser/LaserTargetBlock.java:38-56` and `endgame/laser/OrbitalLaserDrillBlock.java:53-71` (menus open on
  `VIEW`); `endgame/laser/LaserTargetMenu.java:51-53,135-144` and `endgame/laser/OrbitalLaserDrillMenu.java:87-89,
  311-320` (slots with no authority check; `SlotItemHandler.mayPickup` only asks the handler).
- **Rule violated:** ADR-054 §3 (`WITHDRAW` for the device owner with station `BUILD`, the station owner and
  operators; "Anyone else: VIEW of public status only"; station members `VIEW`), §15 "Grief"; AGENTS §3.3 (every
  C2S packet — here vanilla slot clicks — must be checked for permission).
- **Failure scenario:** any player walks up to another player's laser target on a planet (outside stations, so
  public `VIEW` is allowed), right-clicks and empties the drop buffer. On a station, any member opens the station
  owner's drill and takes the output and the lens (stopping it).
- **Evidence:** probe `probeAStrangerTakesALaserTargetsDrops`: `view_allowed=true use_opened=LaserTargetMenu
  still_valid=true diamonds_taken=5 left_in_buffer=0`; probe `probeAStationMemberTakesTheDrillOutputAndLens`:
  `use_opened=OrbitalLaserDrillMenu still_valid=true output_diamonds_taken=7 lens_taken=1`.
- **Suggested fix:** decide `WITHDRAW` for the viewer when the menu opens (and in `stillValid`) and gate
  `mayPickup`/`mayPlace` and `quickMoveStack` on it, or open a slot-less status view for viewers without
  `WITHDRAW`. Add GameTests for a stranger and a station member.

### Medium

#### C11R-M1 — The 8-entry revoked-link list lets an old link re-adopt a reset marker: free credit layers

- **Location:** `endgame/laser/LaserTargetBlockEntity.java:58` (`MAX_REVOKED = 8`), 248-263 (`accepts`/`adopt`),
  328-348 (`reset` drops the oldest revoked ID); `endgame/laser/LaserPhysicalDrill.java:81-87` (adoption at
  contact), 103 (credit), 126-129 (no payment for credit layers).
- **Rule violated:** ADR-055 §3 (the abandoned/forgiven difference is "at most a few layers' energy, never of blocks
  or drops"), ADR-054 §8 ("no device mints energy"); the implementation-log `link_id` + revoked-links refinement
  is only safe while the list is unbounded.
- **Failure scenario:** drill C has link L1 with `ops_paid = k` at marker M. The owner resets M (C now sees
  `LINK_LOST` but keeps L1). With a second drill C2 the owner links M, lets it adopt, resets M and unlinks — eight
  times. L1 has left the revoked list, so C's next contact adopts M with `ops_done = 0`: `k` credit layers dig for
  free. Repeat each round until the shaft floor; the owner pays for as little as one layer.
- **Evidence:** probe `probeARevokedLinkIsAcceptedAgainAfterEightMoreResets`: `refused_after_reset=true
  accepted_after_8_more_resets=true ops_done_after_readoption=0`.
- **Suggested fix:** replace the FIFO list by a monotone per-marker generation that a reset increments and the
  controller records at first contact; accept an unlinked adoption only for a link whose recorded generation
  equals the marker's (a crash-restored marker has an older or equal generation). Extend the counter model test
  with reset/relink.

#### C11R-M2 — `/arce endgame device owner` changes the block entity but not the endpoint index

- **Location:** `endgame/command/EndgameCommands.java:127-140` (only `device.assignOwner`);
  `endgame/root/EndgameRoot.java:288-304` (`reassign`) is never called in production. Index owners are used by
  `OrbitalLaserDrillMenu.targets` (166-175), `LaserDrillIntents.link` (117-121), `LaserPhysicalDrill.breakingStop`
  (153-156, link rule 1) and `EndgameRoot.places` (111-120).
- **Rule violated:** ADR-054 §13 (`device owner`), §9 selection ("owned by the device's owner"), ADR-055 §3 rule 1.
- **Failure scenario:** an operator transfers a laser target from A to B. A's drills still list, link and dig it
  (rule 1 passes on the stale record) on B's land; B's drills cannot select it; A's per-owner endpoint count stays
  charged.
- **Evidence:** probe `probeDeviceOwnerLeavesTheEndpointRecordWithTheOldOwner`: `command_result=1
  block_entity_owner_is_new=true index_record_owner_is_old=true`.
- **Suggested fix:** for endpoints, run `root.reassign(id, owner, limit)` as a barrier before changing the block
  entity (refuse with `ENDPOINT_LIMIT`), and reset the marker's link when the controller's owner differs. Test it.

#### C11R-M3 — Any player can force synchronous full-root writes (and flood the audit ring) with refused `endpoint forget`

- **Location:** `endgame/command/EndgameCommands.java:88-89` (no permission), 230-238 and 280-289
  (`service.barrier(...)` even when the forget is refused), 291-296 (an audit line per call);
  `endgame/service/EndgameService.java:139-148` (a barrier flushes whenever the root is dirty, i.e. whenever any
  other mutation is flush-pending).
- **Rule violated:** ADR-054 §10 write policy (only binds/unbinds, zones and operator redirects/purges are barriers;
  everything else coalesced, ≤ 1 per 100 ticks), §7 spacing for player-triggered barriers and flush budgets
  (≤ 60/250 ms), §13 audit ring.
- **Failure scenario:** a player (or a macro) runs `/arce endgame endpoint forget <random uuid>` about once per
  second (vanilla's command spam limit). Whenever a registration, removal or settlement is pending — common — each
  refused command writes the whole root synchronously on the server thread and adds an audit line, pushing real
  lines out of the 512-line ring.
- **Evidence:** probe `probeARefusedPlayerForgetForcesARootWrite`: `write_pending_before=true forget_result=0
  write_pending_after=false`.
- **Suggested fix:** check the player's own `MISSING` record before touching the root (no barrier on refusal),
  make a successful player forget a coalesced mutation or subject it to the §7 spacing, and aggregate refused
  command lines.

#### C11R-M4 — `WITHDRAW` is unreachable when the station is unavailable

- **Location:** `endgame/authority/EndgameAuthority.java:26-30` grants only `WITHDRAW` there, but every menu needs
  `VIEW` (`OrbitalLaserDrillBlock.java:62-68`, `LaserTargetBlock.java:47-53`, `EndgameDeviceMenu.java:116-128`) and
  no other withdrawal path exists.
- **Rule violated:** ADR-054 §3 ("refused with `STATION_UNAVAILABLE` for every action except `WITHDRAW` by its owner
  or an operator"), §1 (withdrawal continues).
- **Failure scenario:** the station registry is blocked/quarantined, or a drill ends up outside every region after a
  region change: its owner cannot open it to take the output or the lens; only breaking it (if station protection
  allows) or automation remains.
- **Suggested fix:** open a withdraw-only view (no buttons) when `VIEW` is refused but `WITHDRAW` is allowed, and
  accept `WITHDRAW` in that menu's `stillValid`; implement together with C11R-H2.

#### C11R-M5 — The chunk index is rebuilt on every mutation and housekeeping scans every tick above 4,096 tombstones

- **Location:** `endgame/service/EndgameService.java:132-148` (`rebuildIndex()` after every coalesced/barrier call,
  including refusals and retries), 257-265 (up to 32 registration attempts per tick, each a rebuild), 313-334
  (each settlement a rebuild), 336-346 (housekeeping every tick: copies both tombstone collections; above the
  threshold sorts every settled tombstone and rebuilds even when nothing is eligible), 370-387;
  `endgame/root/EndgameRoot.java:251-279`.
- **Rule violated:** ADR-054 §7 budgets (idle ≤ 0.1 ms per tick; all endgame work ≤ 2.0 ms mean at the reference
  load; every cap reachable at once), AGENTS bounded per-tick work.
- **Evidence:** benchmark (`probes/ReviewHousekeepingBenchmarkTest.java`, JIT-warm, development host):
  1,024 endpoints + 3,840 settled tombstones → idle tick 0.033 ms, one no-op coalesced call 0.98 ms;
  1,024 endpoints + 8,192 settled → **idle tick 1.26 ms every tick**, no-op call 0.95 ms. Hence 32 retried
  registrations in one tick ≈ 30 ms; a `/fill` that removes 100 laser targets settles them in one tick ≈ 100 ms.
- **Suggested fix:** update the chunk index incrementally (or only when the mutation changed something), keep
  tombstone counts as integers, and run housekeeping on a bounded cadence.

### Low

#### C11R-L1 — Every physical layer posts its `EndgameEffectEvent` and each `BreakEvent` twice

- **Location:** `endgame/laser/LaserPhysicalDrill.java:113-125`: `plan()` (chain, break events, `getDrops`) runs
  before `laserLayers().take()`, and grants only exist for the next tick (`device/RoundRobinBudget.java:38-64`), so
  each layer is planned in the requesting tick and again in the granted tick.
- **Rule violated:** ADR-055 §3 (events precede removal; the documented exception is only a later cell's
  cancellation).
- **Evidence:** probe H1 counted `break_events_for_one_layer=18` for 9 breakable cells.
- **Scenario:** logging/claim-audit/quest mods record two breaks per block; reactive listeners run twice.
- **Fix:** take or request the layer budget before planning; plan only in the granted tick.

#### C11R-L2 — The counter tests prove a model the engine does not use

- **Location:** `endgame/laser/LaserLinkCounters.java:29-40` is referenced only by
  `tree/src/test/.../endgame/laser/LaserLinkCountersTest.java`; `LaserPhysicalDrill.java:89-129` re-implements the
  steps inline. No GameTest drives `ENERGY_DEBT`, `DEBT_SETTLED` or `CREDIT_USED` on the real engine, and the model
  has no reset/relink (C11R-M1).
- **Rule violated:** ADR-055 Verification A0 ("counter reconciliation for every crash cut"), AGENTS test discipline.
- **Fix:** call `LaserLinkCounters.next` from the engine (or test the engine through a seam), add GameTests that set
  `ops_done`/`ops_paid` to each save-order cut, extend the model with reset/relink.

#### C11R-L3 — Server-tick crash paths from unbounded identifiers

- (a) `endgame/root/EndgameRoot.java:160` constructs `EndpointRecord`, which throws for a Level key over 128
  characters (`endgame/root/EndpointRecord.java:28-30`); it runs in `EndgameService.drainRegistrations`
  (`EndgameService.java:257-265`) inside the `ServerTickEvent` handler, so a laser target placed in a datapack
  dimension with such a key crashes the server at registration (and again after each restart).
- (b) The view line `table` (`endgame/laser/OrbitalLaserDrillMenu.java:214`, value from
  `OrbitalLaserDrillBlockEntity.java:285`) carries the table ID, which comes from the file path without a length
  bound (`endgame/laser/LaserDrillTableReloadListener.java:63-64`; `MAX_ID_CHARS` only bounds bodies and items).
  A table path over ~360 characters makes `EndgameDeviceView.Line` throw (`endgame/network/EndgameDeviceView.java:53-55`)
  inside `broadcastChanges()` during the player tick.
- **Rule violated:** ADR-054 §9 record bounds (refuse, not crash), AGENTS bounds. Both need admin-supplied data.
- **Fix:** refuse over-long Level keys in `register` with a code, reject table IDs over 128 characters at reload,
  truncate view values defensively.

#### C11R-L4 — A 32-bit Level-key hash in the observation index can retire a live endpoint

- **Location:** `endgame/service/EndgameService.java:191, 376-393, 428-430` (`ChunkKey(levelHash, chunk)` for ACTIVE
  records and young tombstones), `endgame/root/Tombstone.java:22-24`.
- **Rule violated:** ADR-054 §9 (`MISSING` needs the endpoint's own chunk tag).
- **Scenario:** two dimension keys with equal `String.hashCode` (trivially constructible): a save of chunk (x, z) in
  Level A is read as an absence for an ACTIVE endpoint at the same chunk coordinates in Level B → `MISSING` →
  retired and frozen for good.
- **Fix:** key ACTIVE records and young tombstones by the full `ResourceLocation`; keep the hash only for settled
  tombstones (housekeeping only).

#### C11R-L5 — Endpoint registration relies on incidental chunk saves

- **Location:** `endgame/laser/LaserTargetBlockEntity.java:204-218` (no `setChanged()` while
  `AWAITING_WORLD_SAVE`), 228-234 (candidate forgotten on unload); `endgame/service/EndgameService.java:90-92,
  186-197` (saves after `ServerStoppingEvent` are ignored; a chunk's `Load` event fires before its block entities'
  `onLoad` re-adds the candidate, so load tags never register anything).
- **Rule violated:** ADR-054 §2 ("while anything is unpersisted the block entity calls `setChanged()`").
- **Impact:** limited, because vanilla marks every loaded chunk unsaved (`ChunkSerializer.read` →
  `setLightCorrect` → `setUnsaved(true)`, verified with `javap`), so the next autosave registers the marker; worst
  case a marker waits one autosave interval after each load, longer if a save raced its first tick. (A runtime
  probe was inconclusive because GameTest structure blocks dirty the test chunk; see Commands.)
- **Fix:** call `setChanged()` at each status check while awaiting; keep candidates across unloads or re-scan on load.

#### C11R-L6 — The consent list has no schema version

- **Location:** `endgame/gravity/GravityTrust.java:67-89` (a bare `ListTag` under
  `PlayerPersisted.advancedrocketrycommunity_field_trust`).
- **Rule violated:** AGENTS §3.3 ("持久化对象必须带独立 schema 版本").
- **Fix:** store `{schema_version: 1, owners: [...]}`; read the bare list as legacy during this cycle.

#### C11R-L7 — Missing negative tests for important rules

- No test for withdrawal authority (H2), partial quick-move persistence (C1), attached blocks in a layer (H1),
  endpoint owner reassignment (M2), `WITHDRAW` in an unavailable station (M4), registration without the manual
  `ChunkDataEvent.Save` fixture (L5), debt/credit on the engine (L2), physical `TARGET_UNLOADED` (acknowledged in
  the C11c packet). ADR-054 §12 says tests count tickets by type before and after every system; the laser
  GameTests count loaded chunks (`gametest/OrbitalLaserDrillGameTests.java:100`,
  `gametest/LaserPhysicalGameTests.java:180-182`) and the gravity GameTests count neither.
- **Fix:** add these tests (the probes in `probes/ReviewProbeGameTests.java` can be inverted into regressions).

#### C11R-L8 — An unbounded per-session map and unpaged operator listings

- `endgame/service/EndpointRegistrations.java:32,113`: `results` keeps every attempt's code until server stop.
  `endgame/command/EndgameCommands.java:188-218`: `zone list` and `endpoint list` show only the first 16 entries
  with no page argument, so zone names beyond 16 of up to 256 cannot be listed (needed for `zone remove`).
- **Fix:** drop results on success/forget; add a page argument.

### Info

- **C11R-I1** — `level.hasNeighborSignal` reads neighbour positions without `getChunkNow`
  (`endgame/laser/OrbitalLaserDrillBlockEntity.java:278`, `endgame/gravity/GravityFieldBlockEntity.java:189`).
  Safe, because block-entity tickers only run in block-ticking chunks whose neighbours are FULL, but not the letter
  of ADR-054 §7.
- **C11R-I2** — `EndgameDeviceBlockEntity.saveAdditional` → `ensureIdentity()` (`endgame/device/
  EndgameDeviceBlockEntity.java:116-131`) also runs on the client (creative pick-block NBT) and creates random IDs
  there; harmless (`onlyOpCanSetNbt`, placement re-randomises).
- **C11R-I3** — One audit line per physical layer instead of the ADR-054 §13 aggregated effect summary (recorded
  decision; bounded by 7 layers/tick).
- **C11R-I4** — The danger confirmation (footprint, layer, floor, "removes blocks") is only visible in a hover
  tooltip (`client/OrbitalLaserDrillScreen.java:87-99`); the V1 `[H]` check should confirm it is discoverable.
- **C11R-I5** — A field stays in the index while its controller's chunk is FULL but not block-ticking (no upkeep
  is paid then); only reachable with non-ticking chunk loaders, and no player can stand in such a box.
- **C11R-I6** — Housekeeping evicts in settlement order (`endgame/root/EndgameRoot.java:26-27, 251-262`); ADR-054
  §11 says oldest observation first.
- **C11R-I7** — The quarantine line is logged directly (`endgame/device/EndgameDeviceBlockEntity.java:110-111,
  165-167`): not bounded to 512 bytes (the reason can carry an NBT key name) and not in the audit ring.
- **C11R-I8** — `endpoint forget` accepts `/execute as` sources (`EndgameCommands.java:231-237`), unlike
  `field trust`; only operators can build such sources.
- **C11R-I9** — Gravity particles are shown to the nearest player in the cube regardless of consent (cosmetic).
- **C11R-I10** — The repository advanced during this review (HEAD `7b062c6`, C12 black-hole work, plus uncommitted
  changes touching `EndgameModule`, `endgame/device/*`, registries). This review covers `8d52d7f` only; the shared
  device/menu findings (C1, H2, M4) should be re-checked against those changes.
- **C11R-I11** — The `scripts/validate_*.py` checks require a Git worktree and could not run on the `git archive`
  export (no Git writes were allowed); the C11 evidence packets record them as passing.

## Recorded refinements and decisions reviewed

- **Per-link `link_id` + revoked links (ADR-055 §3 refinement):** sound against the crash cuts and the "relink an
  old marker" debt problem it targets, and a crash-returned unlinked marker correctly settles as credit; unsafe once
  the bounded list overflows (C11R-M1).
- **Player-aware field layer (ADR-058 §4 refinement):** sound. The position override keeps its signature; field,
  then station region, then Level profile; consent needs the player, so the layer is a player function.
- **Tombstones inside `endpoints`, settled as six longs; `dispatched_through` as one long array, non-zero only:**
  sound, strict on decode, within the 64/32-byte budgets; the Level hash is fine for settled tombstones only
  (C11R-L4).
- **Device root holds everything; any defect quarantines the whole root; a root without an ID is quarantined:**
  consistent with ADR-054 §2; a removed-mod item freezes a whole marker buffer until an operator acts (accepted
  consequence).
- **Work caps grant at end of tick for the next tick:** correct for logical operations (pure decision); for physical
  layers it causes C11R-L1.

## Verified as correct (brief)

- **Authority (§3):** pure `EndgameAuthority.decide` matches the table, the UNAVAILABLE row and the ADR-058
  `MANAGE_STATION` narrowing; operators only for connected non-fake players; public `VIEW` carries no target,
  coordinate, owner name or other device ID (detail gating in all three menus).
- **Intents (§4):** button IDs only; checks in order (real player, operational, Level, chunk via `getChunkNow`,
  same device, 8 blocks, quarantine, authority, switch for operation starts) and the per-player rate last; refusals
  change nothing and send one translated line with the code; FakePlayers cannot open menus; no C2S message; S2C
  `endgame` channel protocol 1, one message, ≤ 8 KiB with a max-size test, every 5 ticks on change.
- **Protection chain (§5/§5.1):** steps 1–6 in order on the batch box, `getChunkNow` only, world border and build
  height, zones with allow lists per Level, stations need owner `BUILD` over the whole box, spawn square on dedicated
  servers only and never op-bypassed, cancellable API event with the §5.1 fields and nothing else; step 7 per cell
  with the owner-bound FakePlayer. API: two new types, `ApiVersions` 1.8 (build exports only those).
- **Root (§10):** strict codec, required tags, 4 MiB bound on both sides, growth admission at 3 MiB, accounted
  maximum 2,932,736 B, save-epoch semantics (file carries E+1, durable when `save_epoch > record_epoch`), checked
  atomic path, blocked root preserved byte-identical and refused at pre-start, type-aware epoch check from schema 1.
- **Endpoints (§9/§9.1):** registration only from a Save/Load tag showing the ID at its position, freeze flag read
  from the tag and recorded in the block entity root, retired/MISSING IDs never register, 32 per tick, limits and
  `ROOT_FULL` retry; removal → young tombstone; aged absence → `MISSING`/settled; quarantined or unreadable roots
  count as present; tombstone caps 256/owner and 8,192 with audited eviction; endpoint protections (1,200 blast
  resistance, `PushReaction.BLOCK`, wither/dragon immune, Create/Carry On tags with `replace` false).
- **Device root (§2):** quarantine keeps the raw root and re-saves it unchanged, inert (no tick work, no
  capabilities, menu refused, non-op break refused, buffers not dropped), one quarantine line; IDs created at
  placement or first load and never carried by items (plain loot tables, `onlyOpCanSetNbt`, placement
  re-randomises); owners only for connected, listed, non-fake `ServerPlayer`s.
- **No chunk loading (§12):** every read outside the device's own block is guarded (`getChunkNow` in the chain, the
  shaft neighbourhood, the marker read, menus, commands, the intent guard); `getLevel(key)` never creates a Level;
  no tickets anywhere.
- **Laser logical (ADR-055 §1–§2, §4):** `laser-v1` matches the reference vectors; strict table codec and reload
  (last complete set kept, initial failure fatal, one aggregated error); eligibility; cost; payment, index and whole
  stack in one tick; `OUTPUT_FULL` keeps `n`; per-tick cap in canonical ID order, round robin; active admission
  first come first served with 200-tick retry; energy buffer input-only, server thread, 20,000 FE/tick.
- **Laser physical (ADR-055 §3, §5):** shaft geometry, floor and the local 2..13 rule; the 3 × 3 FULL
  neighbourhood; classification order; any stop leaves the layer untouched and unpaid (GameTest); debt settles
  regardless of switches and running state; credit only while breaking is allowed; link change rules; two-step
  confirmation by the same player within 200 ticks; update tags only `active`/`depth`; ≤ 8 particles.
- **Gravity (ADR-058):** box, clipping, upkeep, consent and winner vectors; activation order; station owner
  requirement and the 1.00 g cap; index caps and density (`ACTIVE_LIMIT` before `FIELD_DENSITY`); removal on
  deactivation, unload, Level unload, stop and the switch; transient modifier; trust commands only from the
  player's own, connected, non-silent source; ≤ 32 owners in persisted data, surviving respawn.
- **AGENTS:** no `net.minecraft.client` in common/server code; only `OrbitalLaserDrillBlockEntity` exceeds 500 lines
  (577, responsibility check recorded); nothing exceeds 800; no binary assets added; models reference vanilla
  textures by ID; `build.gradle`/`gradle.properties` edits recorded in `docs/provenance/v1.7.0-development-metadata.md`
  (with the recorded ordering defect).

## Commands run (all in `tree/`, Java 17.0.7, `--no-daemon --offline`; logs in `logs/`)

| Command | Result |
|---|---|
| `git -C <repo> log/diff/archive 8d52d7f` (read-only) | tree exported to `tree/` |
| `gradlew runGameTestServer` with `probes/ReviewProbeGameTests.java` added (run 1) | 310 tests, 1 failed — the first await probe, which asserted and was inconclusive (`logs/gametest-run1.log`) |
| same, await probe changed to measure only, plus a control (run 2) | **All 311 required tests passed** (`logs/gametest-run2.log`) |
| same, plus the quick-move probe (run 3) | **All 312 required tests passed** (`logs/gametest-run3.log`); the 303 original GameTests pass |
| `gradlew test` (before adding the benchmark) | BUILD SUCCESSFUL; **1,290 JUnit tests / 238 suites, 0 failures** (`logs/junit-run.log`) |
| `gradlew test --tests '*ReviewHousekeepingBenchmarkTest*'` | `REVIEW_BENCH` lines quoted in C11R-M5 (`logs/bench-run.log`) |
| `javap` on `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar` | `ChunkAccess.setLightCorrect` → `setUnsaved(true)`; `ChunkSerializer.read` calls it; `SlotItemHandler` does not override `setChanged`; `ItemStackHandler.getStackInSlot` returns the live stack |
| `python -B scripts/validate_bootstrap_provenance.py` | FAIL: needs a Git worktree (`logs/validate-provenance.log`); not pursued |

Probe results (each probe asserts the suspected behaviour, so a pass confirms the finding) are collected in
`logs/probe-results.txt`:

| Probe | Observed | Finding |
|---|---|---|
| `probeAPartialQuickMoveDoesNotMarkTheBlockEntityChanged` | buffer 54, player 64, chunk clean, disk 64 → 64; full move dirties | C11R-C1 |
| `probeWallTorchInOneLayerIsDuplicatedAndBreakEventsArePostedTwice` | 1 torch in marker + 1 item entity from 1 torch; 18 break events / 9 cells | C11R-H1, C11R-L1 |
| `probeAStrangerTakesALaserTargetsDrops` | `use()` opened the menu; 5/5 diamonds taken | C11R-H2 |
| `probeAStationMemberTakesTheDrillOutputAndLens` | 7/7 diamonds and the lens taken | C11R-H2 |
| `probeARevokedLinkIsAcceptedAgainAfterEightMoreResets` | refused after reset; accepted after 8 more; `ops_done` 0 | C11R-M1 |
| `probeDeviceOwnerLeavesTheEndpointRecordWithTheOldOwner` | BE owner new; index owner old | C11R-M2 |
| `probeARefusedPlayerForgetForcesARootWrite` | write pending → written by a refused non-op forget | C11R-M3 |
| `probeAnAwaitingEndpointDoesNotDirtyItsChunk` / control | target chunk dirtied at tick 1 (3 GameTest structure blocks in it); control chunk clean — inconclusive | C11R-L5 (code reading) |

No file in `D:\GitHub\AdvancedRocketry-Community` or any other worktree was written; the probes and the benchmark
exist only in this directory.
