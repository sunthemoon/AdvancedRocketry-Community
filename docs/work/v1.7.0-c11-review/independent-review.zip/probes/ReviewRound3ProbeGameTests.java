package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserTargetBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndpointRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.service.EndgameRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModBlocks;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/**
 * Independent C11 review, round 3 (review copy only): the round-2 owner-race probe inverted. Same timing as round 2
 * (the command and a save three ticks after placement, right after the first status check queued the candidate
 * with the old owner); a pass means the record registers for the new owner.
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ReviewRound3ProbeGameTests {
    private ReviewRound3ProbeGameTests() {
    }

    @GameTest(template = "empty", batch = "review_r3_owner_race", timeoutTicks = 200)
    public static void anOwnerChangeBeforeRegistrationRegistersTheNewOwner(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID oldOwner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(oldOwner), "owner");
        UUID id = target.deviceId().orElseThrow();
        ServerPlayer newOwner = ConnectedTestPlayers.join(server, UUID.randomUUID(), "r3RaceOwner", level,
                pos.east(3), new ArrayList<>());
        int[] result = new int[1];
        helper.startSequence()
                .thenIdle(3)
                .thenExecute(() -> {
                    // A save before the command queues a request for the old-owner candidate in the same tick.
                    LaserTargetGameTests.chunkSaved(level, pos);
                    try {
                        result[0] = server.getCommands().getDispatcher().execute("arce endgame device owner "
                                + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " @a[name=r3RaceOwner]",
                                server.createCommandSourceStack());
                    } catch (CommandSyntaxException exception) {
                        result[0] = -1;
                    }
                    LaserTargetGameTests.chunkSaved(level, pos);
                })
                .thenWaitUntil(() -> helper.assertTrue(EndgameRuntime.operational().orElseThrow().root().orElseThrow()
                        .endpoint(id).isPresent(), "not registered"))
                .thenExecute(() -> {
                    EndpointRecord record = EndgameRuntime.operational().orElseThrow().root().orElseThrow()
                            .endpoint(id).orElseThrow();
                    boolean recordNew = record.owner().equals(newOwner.getUUID());
                    boolean blockEntityNew = target.ownerId().filter(newOwner.getUUID()::equals).isPresent();
                    AdvancedRocketryCommunity.LOGGER.info("REVIEW_R3 owner_race command_result={}"
                            + " block_entity_owner_is_new={} registered_record_owner_is_new={}", result[0],
                            blockEntityNew, recordNew);
                    server.getPlayerList().remove(newOwner);
                    level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    helper.assertTrue(result[0] == 1 && blockEntityNew && recordNew,
                            "the record registered for the old owner");
                })
                .thenSucceed();
    }
}
