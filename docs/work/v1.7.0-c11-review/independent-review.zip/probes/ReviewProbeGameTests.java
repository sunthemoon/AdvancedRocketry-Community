package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;
import io.github.sunthemoon.advancedrocketrycommunity.config.CommonConfig;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.device.EndgameDeviceMenu;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserShaft;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserTargetBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserTargetMenu;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.OrbitalLaserDrillBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.OrbitalLaserDrillMenu;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameCode;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.protection.ProtectedZone;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndpointRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.service.EndgameRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.service.EndgameService;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModBlocks;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.AfterBatch;
import net.minecraft.gametest.framework.BeforeBatch;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/**
 * Independent C11 review probes (review copy only, never committed). Each probe asserts the behaviour the reviewer
 * suspects, so a passing probe CONFIRMS a finding; every probe logs one REVIEW_PROBE line with its measurements.
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ReviewProbeGameTests {
    private static final String PHYSICAL = "review_probe_physical";
    private static final AtomicInteger BREAKS = new AtomicInteger();
    private static volatile UUID countBreaksFor;

    static {
        MinecraftForge.EVENT_BUS.addListener(ReviewProbeGameTests::onBreak);
    }

    private ReviewProbeGameTests() {
    }

    private static void onBreak(BlockEvent.BreakEvent event) {
        if (event.getPlayer() instanceof FakePlayer fake && fake.getUUID().equals(countBreaksFor)) {
            BREAKS.incrementAndGet();
        }
    }

    private static void log(String line) {
        AdvancedRocketryCommunity.LOGGER.info("REVIEW_PROBE {}", line);
    }

    @BeforeBatch(batch = PHYSICAL)
    public static void enable(ServerLevel level) {
        CommonConfig.ENDGAME_LASER_PHYSICAL.set(true);
    }

    @AfterBatch(batch = PHYSICAL)
    public static void disable(ServerLevel level) {
        CommonConfig.ENDGAME_LASER_PHYSICAL.set(false);
    }

    /** H1: a wall torch attached to an earlier cell of the same layer drops once into the world and once into the marker. */
    @GameTest(template = "atmosphere_test", batch = PHYSICAL, timeoutTicks = 1200)
    public static void probeWallTorchInOneLayerIsDuplicatedAndBreakEventsArePostedTwice(GameTestHelper helper) {
        OrbitalLaserDrillGameTests.Fixture fixture = new OrbitalLaserDrillGameTests.Fixture(helper,
                CelestialIds.EARTH_ID);
        OrbitalLaserDrillBlockEntity drill = fixture.drill();
        drill.storage().lens().setStackInSlot(0, new ItemStack(ModItems.LASER_LENS.get()));
        drill.storage().setEnergy(200_000);
        ServerLevel overworld = helper.getLevel();
        BlockPos marker = markerPosition(helper);
        overworld.setBlockAndUpdate(marker, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) overworld.getBlockEntity(marker);
        helper.assertTrue(target.assignOwner(fixture.owner), "owner");
        List<BlockPos> layer1 = LaserShaft.layer(marker, marker.getY() - 1);
        List<BlockPos> layer2 = LaserShaft.layer(marker, marker.getY() - 2);
        layer2.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.STONE.defaultBlockState()));
        for (int i = 0; i < LaserShaft.CELLS; i++) {
            if (i != 4) {
                overworld.setBlockAndUpdate(layer1.get(i), Blocks.STONE.defaultBlockState());
            }
        }
        // Cell 4 (the centre) holds a wall torch hanging on cell 1 (its north neighbour, removed first).
        overworld.setBlockAndUpdate(layer1.get(4), Blocks.WALL_TORCH.defaultBlockState()
                .setValue(WallTorchBlock.FACING, Direction.SOUTH));
        helper.assertTrue(overworld.getBlockState(layer1.get(4)).is(Blocks.WALL_TORCH), "torch not placed");
        List<ServerPlayer> joined = new ArrayList<>();
        ServerPlayer owner = ConnectedTestPlayers.join(fixture.server, fixture.owner, "probeOwner", fixture.space,
                fixture.controller.south(4).above(2), new ArrayList<>());
        joined.add(owner);
        OrbitalLaserDrillMenu menu = new OrbitalLaserDrillMenu(7, owner.getInventory(), drill);
        helper.startSequence()
                .thenWaitUntil(() -> {
                    LaserTargetGameTests.chunkSaved(overworld, marker);
                    helper.assertTrue(target.endpointActive(), "not registered: " + target.describe());
                })
                .thenExecute(() -> click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_MODE))
                .thenExecuteAfter(11, () -> {
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_TARGET_NEXT);
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_LINK);
                })
                .thenExecuteAfter(11, () -> click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_START))
                .thenExecuteAfter(11, () -> {
                    BREAKS.set(0);
                    countBreaksFor = fixture.owner;
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_CONFIRM);
                })
                .thenWaitUntil(() -> helper.assertTrue(target.opsDone() == 1, "no layer: " + drill.describe()))
                .thenExecute(() -> {
                    int breaks = BREAKS.get();
                    countBreaksFor = null;
                    int inMarker = count(target, Items.TORCH);
                    int cobble = count(target, Items.COBBLESTONE);
                    int entities = overworld.getEntitiesOfClass(ItemEntity.class, new AABB(marker).inflate(4.0D))
                            .stream().filter(entity -> entity.getItem().is(Items.TORCH))
                            .mapToInt(entity -> entity.getItem().getCount()).sum();
                    log("H1 torches_placed=1 torches_in_marker=" + inMarker + " torch_item_entities=" + entities
                            + " cobblestone_in_marker=" + cobble + " break_events_for_one_layer=" + breaks
                            + " breakable_cells=9 ops_paid=" + drill.opsPaid() + " energy=" + drill.storage().energy());
                    overworld.getEntitiesOfClass(ItemEntity.class, new AABB(marker).inflate(4.0D))
                            .forEach(ItemEntity::discard);
                    joined.forEach(player -> fixture.server.getPlayerList().remove(player));
                    for (int slot = 0; slot < LaserTargetBlockEntity.BUFFER_SLOTS; slot++) {
                        target.buffer().setStackInSlot(slot, ItemStack.EMPTY);
                    }
                    overworld.setBlockAndUpdate(marker, Blocks.AIR.defaultBlockState());
                    layer1.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.AIR.defaultBlockState()));
                    layer2.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.AIR.defaultBlockState()));
                    fixture.close();
                    helper.assertTrue(inMarker + entities == 2, "torch NOT duplicated: marker=" + inMarker
                            + " entities=" + entities);
                    helper.assertTrue(breaks == 18, "break events per layer were " + breaks);
                })
                .thenSucceed();
    }

    /** H2: any player may open a laser target outside stations (public VIEW) and take its drops. */
    @GameTest(template = "empty", batch = "review_probe_theft_target", timeoutTicks = 100)
    public static void probeAStrangerTakesALaserTargetsDrops(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        helper.assertTrue(target.assignOwner(UUID.randomUUID()), "owner");
        target.buffer().setStackInSlot(0, new ItemStack(Items.DIAMOND, 5));
        ServerPlayer stranger = ConnectedTestPlayers.join(server, UUID.randomUUID(), "probeStranger", level,
                pos.east(2), new ArrayList<>());
        boolean viewAllowed = EndgameDeviceMenu.viewAuthority(level, stranger, target).allowed();
        String opened;
        try {
            BlockState state = level.getBlockState(pos);
            state.use(level, stranger, InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP,
                    pos, false));
            opened = stranger.containerMenu.getClass().getSimpleName();
        } catch (RuntimeException exception) {
            opened = "use() threw " + exception;
        }
        if (!(stranger.containerMenu instanceof LaserTargetMenu)) {
            stranger.containerMenu = new LaserTargetMenu(41, stranger.getInventory(), target);
        }
        boolean stillValid = stranger.containerMenu.stillValid(stranger);
        stranger.containerMenu.clicked(0, 0, ClickType.QUICK_MOVE, stranger);
        int taken = stranger.getInventory().countItem(Items.DIAMOND);
        int left = target.buffer().getStackInSlot(0).getCount();
        log("H2a stranger view_allowed=" + viewAllowed + " use_opened=" + opened + " still_valid=" + stillValid
                + " diamonds_taken=" + taken + " left_in_buffer=" + left);
        server.getPlayerList().remove(stranger);
        target.buffer().setStackInSlot(0, ItemStack.EMPTY);
        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        helper.assertTrue(viewAllowed && stillValid && taken == 5, "stranger could NOT take the drops");
        helper.succeed();
    }

    /** H2: a station member (VIEW only) opens the station owner's drill and takes its output and lens. */
    @GameTest(template = "empty", batch = "review_probe_theft_drill", timeoutTicks = 100)
    public static void probeAStationMemberTakesTheDrillOutputAndLens(GameTestHelper helper) {
        OrbitalLaserDrillGameTests.Fixture fixture = new OrbitalLaserDrillGameTests.Fixture(helper,
                CelestialIds.EARTH_ID);
        OrbitalLaserDrillBlockEntity drill = fixture.drill();
        drill.storage().lens().setStackInSlot(0, new ItemStack(ModItems.LASER_LENS.get()));
        drill.storage().output().setStackInSlot(0, new ItemStack(Items.DIAMOND, 7));
        ServerPlayer member = ConnectedTestPlayers.join(fixture.server, UUID.randomUUID(), "probeMember",
                fixture.space, fixture.controller.south(4).above(2), new ArrayList<>());
        fixture.stations.invite(fixture.stationId, member.getUUID());
        fixture.stations.acceptInvitation(fixture.stationId, member.getUUID());
        String opened;
        try {
            BlockState state = fixture.space.getBlockState(fixture.controller);
            state.use(fixture.space, member, InteractionHand.MAIN_HAND, new BlockHitResult(
                    Vec3.atCenterOf(fixture.controller), Direction.UP, fixture.controller, false));
            opened = member.containerMenu.getClass().getSimpleName();
        } catch (RuntimeException exception) {
            opened = "use() threw " + exception;
        }
        if (!(member.containerMenu instanceof OrbitalLaserDrillMenu)) {
            member.containerMenu = new OrbitalLaserDrillMenu(42, member.getInventory(), drill);
        }
        boolean stillValid = member.containerMenu.stillValid(member);
        member.containerMenu.clicked(1, 0, ClickType.QUICK_MOVE, member);
        member.containerMenu.clicked(0, 0, ClickType.QUICK_MOVE, member);
        int diamonds = member.getInventory().countItem(Items.DIAMOND);
        int lenses = member.getInventory().countItem(ModItems.LASER_LENS.get());
        log("H2b station_member use_opened=" + opened + " still_valid=" + stillValid + " output_diamonds_taken="
                + diamonds + " lens_taken=" + lenses);
        fixture.server.getPlayerList().remove(member);
        fixture.close();
        helper.assertTrue(stillValid && diamonds == 7 && lenses == 1, "member could NOT take output and lens");
        helper.succeed();
    }

    /** M: a marker reset only remembers 8 revoked links; after 8 more adopt/reset cycles the first link is accepted again. */
    @GameTest(template = "empty", batch = "review_probe_revoked", timeoutTicks = 100)
    public static void probeARevokedLinkIsAcceptedAgainAfterEightMoreResets(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID owner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(owner), "owner");
        UUID controllerA = UUID.randomUUID();
        UUID linkA = UUID.randomUUID();
        UUID controllerB = UUID.randomUUID();
        target.adopt(controllerA, linkA);
        target.reset(owner);
        boolean refusedAfterReset = !target.accepts(controllerA, linkA);
        for (int i = 0; i < 8; i++) {
            UUID link = UUID.randomUUID();
            target.adopt(controllerB, link);
            target.reset(owner);
        }
        boolean acceptedAgain = target.accepts(controllerA, linkA);
        target.adopt(controllerA, linkA);
        long doneAfterReadoption = target.opsDone();
        log("M-revoked refused_after_reset=" + refusedAfterReset + " accepted_after_8_more_resets=" + acceptedAgain
                + " ops_done_after_readoption=" + doneAfterReadoption);
        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        helper.assertTrue(refusedAfterReset && acceptedAgain && doneAfterReadoption == 0,
                "the revoked link was NOT accepted again");
        helper.succeed();
    }

    /** M: /arce endgame device owner changes the block entity's owner but not the endpoint record's owner. */
    @GameTest(template = "empty", batch = "review_probe_owner", timeoutTicks = 200)
    public static void probeDeviceOwnerLeavesTheEndpointRecordWithTheOldOwner(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID oldOwner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(oldOwner), "owner");
        UUID id = target.deviceId().orElseThrow();
        ServerPlayer newOwner = ConnectedTestPlayers.join(server, UUID.randomUUID(), "probeNewOwner", level,
                pos.east(3), new ArrayList<>());
        helper.startSequence()
                .thenWaitUntil(() -> {
                    LaserTargetGameTests.chunkSaved(level, pos);
                    helper.assertTrue(target.endpointActive(), "not registered: " + target.describe());
                })
                .thenExecute(() -> {
                    int result;
                    try {
                        result = server.getCommands().getDispatcher().execute("arce endgame device owner "
                                + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " @a[name=probeNewOwner]",
                                server.createCommandSourceStack());
                    } catch (CommandSyntaxException exception) {
                        result = -1;
                    }
                    EndpointRecord record = root().root().orElseThrow().endpoint(id).orElseThrow();
                    log("M-owner command_result=" + result + " block_entity_owner_is_new="
                            + target.ownerId().filter(newOwner.getUUID()::equals).isPresent()
                            + " index_record_owner_is_old=" + record.owner().equals(oldOwner));
                    server.getPlayerList().remove(newOwner);
                    level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    helper.assertTrue(result == 1 && target.ownerId().filter(newOwner.getUUID()::equals).isPresent()
                            && record.owner().equals(oldOwner), "the index followed the owner change");
                })
                .thenSucceed();
    }

    /** M: a non-operator's refused endpoint forget still runs a barrier that writes a pending root. */
    @GameTest(template = "empty", batch = "review_probe_forget", timeoutTicks = 100)
    public static void probeARefusedPlayerForgetForcesARootWrite(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        EndgameService service = root();
        String name = "probe_" + UUID.randomUUID().toString().substring(0, 8);
        BlockPos corner = helper.absolutePos(BlockPos.ZERO);
        ProtectedZone zone = ProtectedZone.of(name, level.dimension().location(), corner.getX(), corner.getZ(),
                corner.getX() + 1, corner.getZ() + 1, List.of());
        EndgameCode added = service.coalesced(root -> root.addZone(zone, 256));
        boolean pendingBefore = service.writePending();
        ServerPlayer player = ConnectedTestPlayers.join(server, UUID.randomUUID(), "probeForget", level,
                corner, new ArrayList<>());
        int result;
        try {
            result = server.getCommands().getDispatcher().execute("arce endgame endpoint forget " + UUID.randomUUID(),
                    player.createCommandSourceStack());
        } catch (CommandSyntaxException exception) {
            result = -1;
        }
        boolean pendingAfter = service.writePending();
        log("M-forget zone_added=" + added + " write_pending_before=" + pendingBefore + " forget_result=" + result
                + " write_pending_after=" + pendingAfter);
        server.getPlayerList().remove(player);
        service.barrier(root -> root.removeZone(name));
        helper.assertTrue(added == EndgameCode.OK && pendingBefore && result == 0 && !pendingAfter,
                "a refused forget did not flush the root");
        helper.succeed();
    }

    /** M: an endpoint waiting for a save never marks its chunk unsaved, so a clean chunk never registers it. */
    @GameTest(template = "empty", batch = "review_probe_await", timeoutTicks = 400)
    public static void probeAnAwaitingEndpointDoesNotDirtyItsChunk(GameTestHelper helper) {
        awaitProbe(helper, true);
    }

    /** Control for the await probe: the same chunk handling without a laser target. */
    @GameTest(template = "empty", batch = "review_probe_await_control", timeoutTicks = 400)
    public static void probeControlChunkWithoutTarget(GameTestHelper helper) {
        awaitProbe(helper, false);
    }

    private static void awaitProbe(GameTestHelper helper, boolean withTarget) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        net.minecraft.world.level.GameRules.IntegerValue randomTicks = level.getGameRules()
                .getRule(net.minecraft.world.level.GameRules.RULE_RANDOMTICKING);
        int previousRandomTicks = randomTicks.get();
        randomTicks.set(0, server);
        BlockPos pos = helper.absolutePos(new BlockPos(1, 4, 1));
        LaserTargetBlockEntity[] target = new LaserTargetBlockEntity[1];
        if (withTarget) {
            level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
            target[0] = (LaserTargetBlockEntity) level.getBlockEntity(pos);
            helper.assertTrue(target[0].assignOwner(UUID.randomUUID()), "owner");
        }
        LevelChunk chunk = level.getChunkAt(pos);
        long[] firstDirty = {-1L};
        String[] cause = {""};
        long[] start = {0L};
        helper.startSequence()
                .thenWaitUntil(() -> helper.assertTrue(!withTarget
                        || target[0].endpointStatus() == EndgameCode.AWAITING_WORLD_SAVE, "not awaiting"))
                .thenExecute(() -> {
                    chunk.setUnsaved(false);
                    start[0] = level.getGameTime();
                })
                .thenExecuteFor(120, () -> {
                    if (firstDirty[0] < 0 && chunk.isUnsaved()) {
                        firstDirty[0] = level.getGameTime() - start[0];
                        StringBuilder entities = new StringBuilder();
                        chunk.getBlockEntities().values().forEach(entity -> entities.append(
                                net.minecraftforge.registries.ForgeRegistries.BLOCK_ENTITY_TYPES.getKey(
                                        entity.getType())).append(' '));
                        cause[0] = entities.toString();
                    }
                })
                .thenExecute(() -> {
                    log("M-await with_target=" + withTarget + " status="
                            + (withTarget ? target[0].endpointStatus() : "-") + " random_ticks=0"
                            + " first_unsaved_tick=" + firstDirty[0] + " block_entities_in_chunk=[" + cause[0] + "]");
                    randomTicks.set(previousRandomTicks, server);
                    if (withTarget) {
                        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    }
                })
                .thenSucceed();
    }

    /**
     * H: a partial shift-click out of the marker buffer shrinks the handler's stack in place and never marks the block
     * entity changed, so the chunk is not dirtied (an unload then keeps the older, larger stack on disk).
     */
    @GameTest(template = "empty", batch = "review_probe_quickmove", timeoutTicks = 100)
    public static void probeAPartialQuickMoveDoesNotMarkTheBlockEntityChanged(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID ownerId = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(ownerId), "owner");
        ServerPlayer owner = ConnectedTestPlayers.join(server, ownerId, "probeQuickMove", level, pos.east(2),
                new ArrayList<>());
        target.buffer().setStackInSlot(0, new ItemStack(Items.COBBLESTONE, 64));
        for (int slot = 0; slot < 36; slot++) {
            owner.getInventory().setItem(slot, new ItemStack(Items.DIRT, 64));
        }
        owner.getInventory().setItem(0, new ItemStack(Items.COBBLESTONE, 54));
        LaserTargetMenu menu = new LaserTargetMenu(44, owner.getInventory(), target);
        owner.containerMenu = menu;
        LevelChunk chunk = level.getChunkAt(pos);
        // The target with 64 cobblestone reaches the disk, as after any autosave.
        chunk.setUnsaved(true);
        level.getChunkSource().save(true);
        int diskBefore = diskCount(level, chunk, pos);
        menu.clicked(0, 0, ClickType.QUICK_MOVE, owner);
        int leftAfterPartial = target.buffer().getStackInSlot(0).getCount();
        int playerCobble = owner.getInventory().countItem(Items.COBBLESTONE);
        boolean unsavedAfterPartial = chunk.isUnsaved();
        // The next save (autosave, unload or server stop) skips the clean chunk: the disk keeps 64.
        level.getChunkSource().save(true);
        int diskAfter = diskCount(level, chunk, pos);
        String savedCount = "disk_before=" + diskBefore + " disk_after_partial_and_save=" + diskAfter;
        // Control: a complete move empties the slot through set(), which does mark the block entity changed.
        owner.getInventory().setItem(1, ItemStack.EMPTY);
        chunk.setUnsaved(false);
        menu.clicked(0, 0, ClickType.QUICK_MOVE, owner);
        boolean unsavedAfterFull = chunk.isUnsaved();
        log("H3 partial_quick_move left_in_buffer=" + leftAfterPartial + " player_cobblestone=" + playerCobble
                + " chunk_unsaved_after_partial=" + unsavedAfterPartial + " " + savedCount
                + " chunk_unsaved_after_full_move=" + unsavedAfterFull);
        owner.containerMenu = owner.inventoryMenu;
        server.getPlayerList().remove(owner);
        target.buffer().setStackInSlot(0, ItemStack.EMPTY);
        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        helper.assertTrue(leftAfterPartial == 54 && playerCobble == 64 && !unsavedAfterPartial && unsavedAfterFull
                && diskAfter == 64, "the partial move marked the block entity changed");
        helper.succeed();
    }

    /** The cobblestone count of the laser target's buffer slot 0 in the chunk tag currently stored on disk. */
    private static int diskCount(ServerLevel level, LevelChunk chunk, BlockPos pos) {
        net.minecraft.nbt.CompoundTag tag = level.getChunkSource().chunkMap.read(chunk.getPos()).join().orElse(null);
        if (tag == null) {
            return -1;
        }
        net.minecraft.nbt.ListTag entities = tag.getList("block_entities", 10);
        for (int i = 0; i < entities.size(); i++) {
            net.minecraft.nbt.CompoundTag entity = entities.getCompound(i);
            if (entity.getInt("x") == pos.getX() && entity.getInt("y") == pos.getY() && entity.getInt("z") == pos.getZ()) {
                net.minecraft.nbt.ListTag items = entity.getCompound("endgame").getCompound("buffer").getList("Items", 10);
                return items.isEmpty() ? 0 : items.getCompound(0).getByte("Count");
            }
        }
        return -2;
    }

    private static EndgameService root() {
        return EndgameRuntime.operational().orElseThrow();
    }

    private static void click(GameTestHelper helper, OrbitalLaserDrillMenu menu, ServerPlayer player, int button) {
        helper.assertTrue(menu.clickMenuButton(player, button), "intent " + button + " refused");
    }

    private static int count(LaserTargetBlockEntity target, net.minecraft.world.item.Item item) {
        int total = 0;
        for (int slot = 0; slot < LaserTargetBlockEntity.BUFFER_SLOTS; slot++) {
            ItemStack stack = target.buffer().getStackInSlot(slot);
            total += stack.is(item) ? stack.getCount() : 0;
        }
        return total;
    }

    private static BlockPos markerPosition(GameTestHelper helper) {
        BlockPos base = helper.absolutePos(BlockPos.ZERO);
        int x = 1;
        while (((base.getX() + x) & 15) < LaserShaft.MIN_LOCAL || ((base.getX() + x) & 15) > LaserShaft.MAX_LOCAL) {
            x++;
        }
        int z = 1;
        while (((base.getZ() + z) & 15) < LaserShaft.MIN_LOCAL || ((base.getZ() + z) & 15) > LaserShaft.MAX_LOCAL) {
            z++;
        }
        return helper.absolutePos(new BlockPos(x, 6, z));
    }
}
