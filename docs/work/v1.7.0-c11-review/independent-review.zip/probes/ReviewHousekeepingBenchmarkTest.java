package io.github.sunthemoon.advancedrocketrycommunity.endgame.service;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameCode;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSettings;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameSavedData;
import java.util.Set;
import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import org.junit.jupiter.api.Test;

/** Independent C11 review measurement (review copy only): the per-tick cost of the service with many tombstones. */
class ReviewHousekeepingBenchmarkTest {
    private static final ResourceLocation KIND = ResourceLocation.tryBuild("advancedrocketrycommunity", "laser_target");
    private static final ResourceLocation LEVEL = ResourceLocation.tryBuild("minecraft", "overworld");

    @Test
    void measureIdleTicks() {
        for (int owners : new int[] {15, 32}) {
            EndgameSavedData data = EndgameSavedData.create();
            int[] next = {0};
            data.update(root -> {
                for (int owner = 0; owner < owners; owner++) {
                    UUID ownerId = new UUID(7L, owner);
                    for (int i = 0; i < 256; i++) {
                        UUID id = new UUID(owner, i);
                        long pos = ((long) (next[0]++ % 4096) << 12) | i;
                        root.register(id, KIND, ownerId, LEVEL, pos, false, 2048, 64);
                        root.remove(id);
                        root.settle(id, ignored -> false);
                    }
                }
                for (int i = 0; i < 1024; i++) {
                    root.register(new UUID(99L, i), KIND, new UUID(8L, i % 32), LEVEL, i * 4096L, false, 2048, 64);
                }
                return null;
            });
            EndgameService service = new EndgameService(() -> EndgameSettings.DEFAULTS, () -> Set.of("x"));
            service.startForTest(data);
            int tombstones = service.root().orElseThrow().settledTombstones().size();
            for (int i = 0; i < 200; i++) {
                service.tick(1_000L + i);
            }
            long start = System.nanoTime();
            int ticks = 500;
            for (int i = 0; i < ticks; i++) {
                service.tick(2_000L + i);
            }
            double perTick = (System.nanoTime() - start) / 1_000_000.0 / ticks;
            start = System.nanoTime();
            int noOps = 200;
            for (int i = 0; i < noOps; i++) {
                EndgameCode code = service.coalesced(root -> root.register(new UUID(99L, 0L), KIND,
                        new UUID(8L, 0L), LEVEL, 0L, false, 2048, 64));
                if (code != EndgameCode.OK) {
                    throw new AssertionError(code);
                }
            }
            double perNoOp = (System.nanoTime() - start) / 1_000_000.0 / noOps;
            System.out.printf("REVIEW_BENCH settled_tombstones=%d endpoints=1024 idle_tick_ms=%.3f"
                    + " no_op_coalesced_call_ms=%.3f%n", tombstones, perTick, perNoOp);
        }
    }
}
