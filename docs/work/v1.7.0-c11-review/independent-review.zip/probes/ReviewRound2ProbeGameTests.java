package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;
import io.github.sunthemoon.advancedrocketrycommunity.config.CommonConfig;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserShaft;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserTargetBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.LaserTargetMenu;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.OrbitalLaserDrillBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.laser.OrbitalLaserDrillMenu;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameCode;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.protection.ProtectedZone;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndpointRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.service.EndgameRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.service.EndgameService;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModBlocks;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.AfterBatch;
import net.minecraft.gametest.framework.BeforeBatch;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/**
 * Independent C11 review, round 2 (review copy only, never committed). The round-1 probes are inverted: a pass means
 * the finding is fixed. Two probes check suspected problems in the fixes and assert the suspected behaviour. Every
 * probe logs one REVIEW_R2 line.
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ReviewRound2ProbeGameTests {
    private static final String PHYSICAL = "review_r2_physical";
    private static final AtomicInteger BREAKS = new AtomicInteger();
    private static volatile UUID countBreaksFor;

    static {
        MinecraftForge.EVENT_BUS.addListener(ReviewRound2ProbeGameTests::onBreak);
    }

    private ReviewRound2ProbeGameTests() {
    }

    private static void onBreak(BlockEvent.BreakEvent event) {
        if (event.getPlayer() instanceof FakePlayer fake && fake.getUUID().equals(countBreaksFor)) {
            BREAKS.incrementAndGet();
        }
    }

    private static void log(String line) {
        AdvancedRocketryCommunity.LOGGER.info("REVIEW_R2 {}", line);
    }

    @BeforeBatch(batch = PHYSICAL)
    public static void enable(ServerLevel level) {
        CommonConfig.ENDGAME_LASER_PHYSICAL.set(true);
    }

    @AfterBatch(batch = PHYSICAL)
    public static void disable(ServerLevel level) {
        CommonConfig.ENDGAME_LASER_PHYSICAL.set(false);
    }

    /**
     * H1 + L1 inverted, and the skip rule: layer 1 has a wall torch on a stone cell earlier in cell order; layer 2
     * has a wall torch hanging on stairs (also without a full collision shape) that come first in removal order. Each
     * torch must exist exactly once (marker or world), and each layer must post 9 break events.
     */
    @GameTest(template = "atmosphere_test", batch = PHYSICAL, timeoutTicks = 1600)
    public static void hangingBlocksAreCountedOnceAndEventsPostedOnce(GameTestHelper helper) {
        OrbitalLaserDrillGameTests.Fixture fixture = new OrbitalLaserDrillGameTests.Fixture(helper,
                CelestialIds.EARTH_ID);
        OrbitalLaserDrillBlockEntity drill = fixture.drill();
        drill.storage().lens().setStackInSlot(0, new ItemStack(ModItems.LASER_LENS.get()));
        drill.storage().setEnergy(200_000);
        ServerLevel overworld = helper.getLevel();
        BlockPos marker = markerPosition(helper);
        overworld.setBlockAndUpdate(marker, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) overworld.getBlockEntity(marker);
        helper.assertTrue(target.assignOwner(fixture.owner), "owner");
        List<BlockPos> layer1 = LaserShaft.layer(marker, marker.getY() - 1);
        List<BlockPos> layer2 = LaserShaft.layer(marker, marker.getY() - 2);
        List<BlockPos> layer3 = LaserShaft.layer(marker, marker.getY() - 3);
        layer3.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.STONE.defaultBlockState()));
        for (int i = 0; i < LaserShaft.CELLS; i++) {
            overworld.setBlockAndUpdate(layer2.get(i), i == 3 ? Blocks.OAK_STAIRS.defaultBlockState()
                    .setValue(StairBlock.FACING, Direction.EAST) : Blocks.STONE.defaultBlockState());
        }
        overworld.setBlockAndUpdate(layer2.get(4), Blocks.WALL_TORCH.defaultBlockState()
                .setValue(WallTorchBlock.FACING, Direction.EAST));
        for (int i = 0; i < LaserShaft.CELLS; i++) {
            if (i != 4) {
                overworld.setBlockAndUpdate(layer1.get(i), Blocks.STONE.defaultBlockState());
            }
        }
        overworld.setBlockAndUpdate(layer1.get(4), Blocks.WALL_TORCH.defaultBlockState()
                .setValue(WallTorchBlock.FACING, Direction.SOUTH));
        boolean placed = overworld.getBlockState(layer1.get(4)).is(Blocks.WALL_TORCH)
                && overworld.getBlockState(layer2.get(4)).is(Blocks.WALL_TORCH)
                && overworld.getBlockState(layer2.get(3)).is(Blocks.OAK_STAIRS);
        helper.assertTrue(placed, "fixture blocks not placed");
        List<ServerPlayer> joined = new ArrayList<>();
        ServerPlayer owner = ConnectedTestPlayers.join(fixture.server, fixture.owner, "r2Owner", fixture.space,
                fixture.controller.south(4).above(2), new ArrayList<>());
        joined.add(owner);
        OrbitalLaserDrillMenu menu = new OrbitalLaserDrillMenu(70, owner.getInventory(), drill);
        int[] breaks = new int[2];
        helper.startSequence()
                .thenWaitUntil(() -> {
                    LaserTargetGameTests.chunkSaved(overworld, marker);
                    helper.assertTrue(target.endpointActive(), "not registered: " + target.describe());
                })
                .thenExecute(() -> click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_MODE))
                .thenExecuteAfter(11, () -> {
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_TARGET_NEXT);
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_LINK);
                })
                .thenExecuteAfter(11, () -> click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_START))
                .thenExecuteAfter(11, () -> {
                    BREAKS.set(0);
                    countBreaksFor = fixture.owner;
                    click(helper, menu, owner, OrbitalLaserDrillMenu.BUTTON_CONFIRM);
                })
                .thenWaitUntil(() -> helper.assertTrue(target.opsDone() == 1, "no layer 1: " + drill.describe()))
                .thenExecute(() -> breaks[0] = BREAKS.getAndSet(0))
                .thenWaitUntil(() -> helper.assertTrue(target.opsDone() == 2, "no layer 2: " + drill.describe()))
                .thenExecute(() -> {
                    breaks[1] = BREAKS.get();
                    countBreaksFor = null;
                    int torchesInMarker = count(target, Items.TORCH);
                    int stairsInMarker = count(target, Items.OAK_STAIRS);
                    int cobble = count(target, Items.COBBLESTONE);
                    int torchEntities = overworld.getEntitiesOfClass(ItemEntity.class, new AABB(marker).inflate(5.0D))
                            .stream().filter(entity -> entity.getItem().is(Items.TORCH))
                            .mapToInt(entity -> entity.getItem().getCount()).sum();
                    boolean layer2Clear = layer2.stream().allMatch(cell -> overworld.getBlockState(cell).isAir());
                    log("H1/L1 torches_placed=2 torches_in_marker=" + torchesInMarker + " torch_item_entities="
                            + torchEntities + " stairs_in_marker=" + stairsInMarker + " cobblestone_in_marker="
                            + cobble + " break_events_layer1=" + breaks[0] + " break_events_layer2=" + breaks[1]
                            + " layer2_clear=" + layer2Clear + " ops_paid=" + drill.opsPaid());
                    overworld.getEntitiesOfClass(ItemEntity.class, new AABB(marker).inflate(5.0D))
                            .forEach(ItemEntity::discard);
                    joined.forEach(player -> fixture.server.getPlayerList().remove(player));
                    for (int slot = 0; slot < LaserTargetBlockEntity.BUFFER_SLOTS; slot++) {
                        target.buffer().setStackInSlot(slot, ItemStack.EMPTY);
                    }
                    overworld.setBlockAndUpdate(marker, Blocks.AIR.defaultBlockState());
                    layer1.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.AIR.defaultBlockState()));
                    layer2.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.AIR.defaultBlockState()));
                    layer3.forEach(cell -> overworld.setBlockAndUpdate(cell, Blocks.AIR.defaultBlockState()));
                    fixture.close();
                    helper.assertTrue(torchesInMarker + torchEntities == 2, "a torch was duplicated or lost: marker="
                            + torchesInMarker + " entities=" + torchEntities);
                    helper.assertTrue(breaks[0] == 9 && breaks[1] == 9, "break events per layer: " + breaks[0]
                            + ", " + breaks[1]);
                })
                .thenSucceed();
    }

    /** C1 inverted on the drill output: after a partial shift-click and a save, the disk holds what was left. */
    @GameTest(template = "empty", batch = "review_r2_drill_disk", timeoutTicks = 100)
    public static void aPartialShiftClickOutOfTheDrillOutputReachesTheDisk(GameTestHelper helper) {
        OrbitalLaserDrillGameTests.Fixture fixture = new OrbitalLaserDrillGameTests.Fixture(helper,
                CelestialIds.EARTH_ID);
        ServerPlayer owner = ConnectedTestPlayers.join(fixture.server, fixture.owner, "r2DrillDisk", fixture.space,
                fixture.controller.south(3), new ArrayList<>());
        int before;
        int after;
        int live;
        int moved;
        try {
            OrbitalLaserDrillBlockEntity drill = fixture.drill();
            drill.storage().output().setStackInSlot(0, new ItemStack(Items.COBBLESTONE, 64));
            for (int slot = 0; slot < 36; slot++) {
                owner.getInventory().setItem(slot, new ItemStack(Items.DIRT, 64));
            }
            owner.getInventory().setItem(0, new ItemStack(Items.COBBLESTONE, 54));
            OrbitalLaserDrillMenu menu = new OrbitalLaserDrillMenu(71, owner.getInventory(), drill);
            owner.containerMenu = menu;
            LevelChunk chunk = fixture.space.getChunkAt(fixture.controller);
            chunk.setUnsaved(true);
            fixture.space.getChunkSource().save(true);
            before = diskOutputCount(fixture.space, chunk, fixture.controller);
            menu.clicked(1, 0, ClickType.QUICK_MOVE, owner);
            live = drill.storage().output().getStackInSlot(0).getCount();
            moved = owner.getInventory().countItem(Items.COBBLESTONE) - 54;
            fixture.space.getChunkSource().save(true);
            after = diskOutputCount(fixture.space, chunk, fixture.controller);
        } finally {
            owner.containerMenu = owner.inventoryMenu;
            fixture.server.getPlayerList().remove(owner);
            fixture.close();
        }
        log("C1 drill_output disk_before=" + before + " live_after_partial=" + live + " moved=" + moved
                + " disk_after_save=" + after);
        helper.assertTrue(before == 64 && live == 54 && moved == 10 && after == 54,
                "the partial move did not reach the disk");
        helper.succeed();
    }

    /** H2 inverted with the click types the fix's own test does not use: pickup-all, drag and swap puts. */
    @GameTest(template = "empty", batch = "review_r2_clicks", timeoutTicks = 100)
    public static void viewOnlyPlayersCannotTakeOrPutWithOtherClickTypes(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        helper.assertTrue(target.assignOwner(UUID.randomUUID()), "owner");
        target.buffer().setStackInSlot(0, new ItemStack(Items.DIAMOND, 5));
        target.buffer().setStackInSlot(1, new ItemStack(Items.DIAMOND, 7));
        ServerPlayer stranger = ConnectedTestPlayers.join(server, UUID.randomUUID(), "r2Stranger", level, pos.east(2),
                new ArrayList<>());
        String markerResult;
        try {
            level.getBlockState(pos).use(level, stranger, InteractionHand.MAIN_HAND,
                    new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
            LaserTargetMenu menu = (LaserTargetMenu) stranger.containerMenu;
            menu.setCarried(new ItemStack(Items.DIAMOND, 1));
            menu.clicked(0, 0, ClickType.PICKUP_ALL, stranger);
            int carriedAfterPickupAll = menu.getCarried().getCount();
            menu.setCarried(ItemStack.EMPTY);
            menu.clicked(0, 0, ClickType.THROW, stranger);
            menu.clicked(1, 1, ClickType.THROW, stranger);
            int left = target.buffer().getStackInSlot(0).getCount() + target.buffer().getStackInSlot(1).getCount();
            int dropped = level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(4.0D)).stream()
                    .mapToInt(entity -> entity.getItem().getCount()).sum();
            markerResult = "carried_after_pickup_all=" + carriedAfterPickupAll + " left_in_buffer=" + left
                    + " thrown=" + dropped;
            helper.assertTrue(carriedAfterPickupAll == 1 && left == 12 && dropped == 0,
                    "stranger took drops: " + markerResult);
        } finally {
            stranger.containerMenu = stranger.inventoryMenu;
            server.getPlayerList().remove(stranger);
            target.buffer().setStackInSlot(0, ItemStack.EMPTY);
            target.buffer().setStackInSlot(1, ItemStack.EMPTY);
            level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        }
        log("H2 stranger " + markerResult);
        helper.succeed();
    }

    /** H2 inverted on the drill: a station member cannot drag or swap a lens in. */
    @GameTest(template = "empty", batch = "review_r2_member_put", timeoutTicks = 100)
    public static void aStationMemberCannotDragOrSwapALensIn(GameTestHelper helper) {
        OrbitalLaserDrillGameTests.Fixture fixture = new OrbitalLaserDrillGameTests.Fixture(helper,
                CelestialIds.EARTH_ID);
        OrbitalLaserDrillBlockEntity drill = fixture.drill();
        ServerPlayer member = ConnectedTestPlayers.join(fixture.server, UUID.randomUUID(), "r2Member", fixture.space,
                fixture.controller.south(3), new ArrayList<>());
        String result;
        try {
            fixture.stations.invite(fixture.stationId, member.getUUID());
            fixture.stations.acceptInvitation(fixture.stationId, member.getUUID());
            fixture.space.getBlockState(fixture.controller).use(fixture.space, member, InteractionHand.MAIN_HAND,
                    new BlockHitResult(Vec3.atCenterOf(fixture.controller), Direction.UP, fixture.controller, false));
            OrbitalLaserDrillMenu menu = (OrbitalLaserDrillMenu) member.containerMenu;
            // Drag (quick craft) one lens onto the lens slot: start, add slot 0, end.
            menu.setCarried(new ItemStack(ModItems.LASER_LENS.get()));
            menu.clicked(-999, AbstractQuickCraft.START, ClickType.QUICK_CRAFT, member);
            menu.clicked(0, AbstractQuickCraft.ADD, ClickType.QUICK_CRAFT, member);
            menu.clicked(-999, AbstractQuickCraft.END, ClickType.QUICK_CRAFT, member);
            boolean draggedIn = drill.storage().lensPresent();
            menu.setCarried(ItemStack.EMPTY);
            // Swap from hotbar slot 0 into the lens slot.
            member.getInventory().setItem(0, new ItemStack(ModItems.LASER_LENS.get()));
            menu.clicked(0, 0, ClickType.SWAP, member);
            boolean swappedIn = drill.storage().lensPresent();
            result = "dragged_in=" + draggedIn + " swapped_in=" + swappedIn;
            helper.assertTrue(!draggedIn && !swappedIn, "member put a lens: " + result);
        } finally {
            member.containerMenu = member.inventoryMenu;
            fixture.server.getPlayerList().remove(member);
            fixture.close();
        }
        log("H2 station_member " + result);
        helper.succeed();
    }

    /** Vanilla quick-craft header values (AbstractContainerMenu.getQuickcraftMask with type 0). */
    private static final class AbstractQuickCraft {
        static final int START = 0;
        static final int ADD = 1;
        static final int END = 2;
    }

    /** M1 inverted: after a reset and 20 more adopt/reset cycles the first link stays refused; a new link is accepted. */
    @GameTest(template = "empty", batch = "review_r2_generation", timeoutTicks = 100)
    public static void aResetLinkNeverReturns(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID owner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(owner), "owner");
        UUID controllerA = UUID.randomUUID();
        UUID linkA = UUID.randomUUID();
        target.adopt(controllerA, linkA);
        long touchedAt = target.generation();
        target.reset(owner);
        boolean refusedAfterReset = !target.accepts(controllerA, linkA, touchedAt);
        boolean refusedEver = refusedAfterReset;
        for (int i = 0; i < 20; i++) {
            target.adopt(UUID.randomUUID(), UUID.randomUUID());
            target.reset(owner);
            refusedEver &= !target.accepts(controllerA, linkA, touchedAt);
        }
        boolean newLinkAccepted = target.accepts(UUID.randomUUID(), UUID.randomUUID(), -1L);
        log("M1 refused_after_reset=" + refusedAfterReset + " refused_after_20_more=" + refusedEver
                + " new_link_accepted=" + newLinkAccepted + " generation=" + target.generation());
        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        helper.assertTrue(refusedEver && newLinkAccepted, "an old link was accepted again");
        helper.succeed();
    }

    /** M2 inverted: the record follows the owner change. */
    @GameTest(template = "empty", batch = "review_r2_owner", timeoutTicks = 200)
    public static void deviceOwnerMovesTheRecord(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID oldOwner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(oldOwner), "owner");
        UUID id = target.deviceId().orElseThrow();
        ServerPlayer newOwner = ConnectedTestPlayers.join(server, UUID.randomUUID(), "r2NewOwner", level,
                pos.east(3), new ArrayList<>());
        helper.startSequence()
                .thenWaitUntil(() -> {
                    LaserTargetGameTests.chunkSaved(level, pos);
                    helper.assertTrue(target.endpointActive(), "not registered: " + target.describe());
                })
                .thenExecute(() -> {
                    int result = command(server, server.createCommandSourceStack(), "arce endgame device owner "
                            + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " @a[name=r2NewOwner]");
                    EndpointRecord record = service().root().orElseThrow().endpoint(id).orElseThrow();
                    boolean moved = record.owner().equals(newOwner.getUUID())
                            && target.ownerId().filter(newOwner.getUUID()::equals).isPresent();
                    log("M2 registered command_result=" + result + " record_and_block_entity_moved=" + moved);
                    server.getPlayerList().remove(newOwner);
                    level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    helper.assertTrue(result == 1 && moved, "the record did not follow");
                })
                .thenSucceed();
    }

    /**
     * Suspected new problem in the M2 fix: a marker still waiting for registration keeps its old owner in the
     * waiting candidate until its next status check, so a save observed in between registers the old owner. This
     * probe ASSERTS the stale owner (a pass confirms the problem).
     */
    @GameTest(template = "empty", batch = "review_r2_owner_race", timeoutTicks = 200)
    public static void anOwnerChangeBeforeRegistrationCanRegisterTheOldOwner(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        level.setBlockAndUpdate(pos, ModBlocks.LASER_TARGET.get().defaultBlockState());
        LaserTargetBlockEntity target = (LaserTargetBlockEntity) level.getBlockEntity(pos);
        UUID oldOwner = UUID.randomUUID();
        helper.assertTrue(target.assignOwner(oldOwner), "owner");
        UUID id = target.deviceId().orElseThrow();
        ServerPlayer newOwner = ConnectedTestPlayers.join(server, UUID.randomUUID(), "r2RaceOwner", level,
                pos.east(3), new ArrayList<>());
        int[] result = new int[1];
        // The status field starts as AWAITING_WORLD_SAVE: idle a few ticks so the first status check has run and
        // queued the waiting candidate with the old owner; the next check is 20 ticks later.
        helper.startSequence()
                .thenIdle(3)
                .thenExecute(() -> {
                    // The operator command, then a chunk save before the marker's next status check.
                    result[0] = command(server, server.createCommandSourceStack(), "arce endgame device owner "
                            + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " @a[name=r2RaceOwner]");
                    LaserTargetGameTests.chunkSaved(level, pos);
                })
                .thenWaitUntil(() -> helper.assertTrue(service().root().orElseThrow().endpoint(id).isPresent(),
                        "not registered"))
                .thenExecute(() -> {
                    EndpointRecord record = service().root().orElseThrow().endpoint(id).orElseThrow();
                    boolean blockEntityNew = target.ownerId().filter(newOwner.getUUID()::equals).isPresent();
                    boolean recordOld = record.owner().equals(oldOwner);
                    log("M2-race command_result=" + result[0] + " block_entity_owner_is_new=" + blockEntityNew
                            + " registered_record_owner_is_old=" + recordOld);
                    server.getPlayerList().remove(newOwner);
                    level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    helper.assertTrue(result[0] == 1 && blockEntityNew && recordOld,
                            "the record has the new owner (no race)");
                })
                .thenSucceed();
    }

    /** M3 inverted: a refused player forget leaves a pending write pending. */
    @GameTest(template = "empty", batch = "review_r2_forget", timeoutTicks = 100)
    public static void aRefusedForgetWritesNothing(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        EndgameService service = service();
        String name = "r2_" + UUID.randomUUID().toString().substring(0, 8);
        BlockPos corner = helper.absolutePos(BlockPos.ZERO);
        EndgameCode added = service.coalesced(root -> root.addZone(ProtectedZone.of(name, level.dimension().location(),
                corner.getX(), corner.getZ(), corner.getX() + 1, corner.getZ() + 1, List.of()), 256));
        boolean pendingBefore = service.writePending();
        ServerPlayer player = ConnectedTestPlayers.join(server, UUID.randomUUID(), "r2Forget", level, corner,
                new ArrayList<>());
        int result = command(server, player.createCommandSourceStack(), "arce endgame endpoint forget "
                + UUID.randomUUID());
        boolean pendingAfter = service.writePending();
        log("M3 zone_added=" + added + " write_pending_before=" + pendingBefore + " forget_result=" + result
                + " write_pending_after=" + pendingAfter);
        server.getPlayerList().remove(player);
        service.barrier(root -> root.removeZone(name));
        helper.assertTrue(pendingBefore && result == 0 && pendingAfter, "a refused forget wrote the root");
        helper.succeed();
    }

    private static int command(MinecraftServer server, net.minecraft.commands.CommandSourceStack source,
                               String command) {
        try {
            return server.getCommands().getDispatcher().execute(command, source);
        } catch (CommandSyntaxException exception) {
            return -1;
        }
    }

    private static EndgameService service() {
        return EndgameRuntime.operational().orElseThrow();
    }

    private static void click(GameTestHelper helper, OrbitalLaserDrillMenu menu, ServerPlayer player, int button) {
        helper.assertTrue(menu.clickMenuButton(player, button), "intent " + button + " refused");
    }

    private static int count(LaserTargetBlockEntity target, net.minecraft.world.item.Item item) {
        int total = 0;
        for (int slot = 0; slot < LaserTargetBlockEntity.BUFFER_SLOTS; slot++) {
            ItemStack stack = target.buffer().getStackInSlot(slot);
            total += stack.is(item) ? stack.getCount() : 0;
        }
        return total;
    }

    /** The count in output slot 0 of the drill in the chunk tag currently stored on disk. */
    private static int diskOutputCount(ServerLevel level, LevelChunk chunk, BlockPos pos) {
        CompoundTag tag = level.getChunkSource().chunkMap.read(chunk.getPos()).join().orElse(null);
        if (tag == null) {
            return -1;
        }
        ListTag entities = tag.getList("block_entities", 10);
        for (int i = 0; i < entities.size(); i++) {
            CompoundTag entity = entities.getCompound(i);
            if (entity.getInt("x") == pos.getX() && entity.getInt("y") == pos.getY()
                    && entity.getInt("z") == pos.getZ()) {
                ListTag items = entity.getCompound("endgame").getCompound("output").getList("Items", 10);
                return items.isEmpty() ? 0 : items.getCompound(0).getByte("Count");
            }
        }
        return -2;
    }

    private static BlockPos markerPosition(GameTestHelper helper) {
        BlockPos base = helper.absolutePos(BlockPos.ZERO);
        int x = 1;
        while (((base.getX() + x) & 15) < LaserShaft.MIN_LOCAL || ((base.getX() + x) & 15) > LaserShaft.MAX_LOCAL) {
            x++;
        }
        int z = 1;
        while (((base.getZ() + z) & 15) < LaserShaft.MIN_LOCAL || ((base.getZ() + z) & 15) > LaserShaft.MAX_LOCAL) {
            z++;
        }
        return helper.absolutePos(new BlockPos(x, 6, z));
    }
}
