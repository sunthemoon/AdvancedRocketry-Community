import json,sys
d=json.load(open('examples.json'))
for k in sys.argv[1:]:
    print(k, json.dumps(d[k], indent=1)[:3000])
