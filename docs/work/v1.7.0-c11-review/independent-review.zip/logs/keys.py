import json
d=json.load(open('examples.json'))
for k in d:
    print(k, len(json.dumps(d[k])))
