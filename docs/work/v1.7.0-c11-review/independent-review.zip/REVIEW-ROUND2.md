# Independent implementation review — v1.7.0 C11, round 2 (fix verification)

- Reviewed: commits `6ff9d27..a8cf76d` on `codex/v1.7.0-endgame-systems` (HEAD
  `a8cf76dc4693fe1b90fed8023c82adf9d1eecae9`), one commit per round-1 finding, against the round-1 report
  ([REVIEW.md](REVIEW.md), commit `8d52d7f`), ADR-054/055/058, AGENTS.md and the implementation log section
  "C11 review fixes".
- Method: every fix diff read in full; the final state of the changed classes re-read for regressions; round-1 probes
  inverted (a pass now means "fixed") plus new probes for suspected problems in the fixes; full suite, DataGen check
  and the round-1 benchmark run in a fresh `git archive` export (`tree2/`). Read-only toward the repository; the
  untracked `docs/work/v1.7.0-c11-review/` draft and the user documentation bundle were not read.
- Scope note: the base `6ff9d27` includes C12a (black-hole generator). C12a is not reviewed here, except where a
  C11 fix touched it (the generator's fuel slots in C1/H2, its block in M4, its data IDs in L3).
- Path convention: Java paths are relative to `tree2/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.

## Summary

All three blocking defects are fixed, and my own probes confirm it at runtime:

- **C1:** partial shift-clicks now reach the disk, for both the drill output and the laser target.
- **H1:** a hanging block is counted once, including when its support is itself removed first.
- **H2:** view-only players can no longer take or put items with any click type.

All five Medium findings are fixed: M1 (marker generation), M2 (record moves with the owner), M3 (refusals write
nothing), M4 (withdraw-only menu) and M5 (incremental index; the benchmark idle tick drops from 1.26 ms to 0.009 ms).
Every Low finding and I7/I8 are fixed. The recorded refinements (H1 removal order and skip rule, put = `CONFIGURE`,
`TARGET_OUT_OF_BOUNDS` for over-long IDs, I7 as a bounded log line) are acceptable.

The fixes introduced no Critical, High or Medium problem. Two new Low findings:

- **C11R2-L1:** an operator's `device owner` on a laser target that is still waiting for registration can register
  the old owner. Confirmed by a probe.
- **C11R2-L2:** `EndgameService` crossed 500 lines without the AGENTS §3.4 responsibility check.

There are also a few Info items. Suites in my copy: 1,305 JUnit tests (1,304 plus my benchmark) and 328 GameTests
(320 plus 8 probes) pass, and DataGen output is identical to the committed tree.

## Verdicts

| Slice | Round 1 | Round 2 |
|---|---|---|
| C11a — ADR-054 framework | ACCEPT WITH REQUIRED CHANGES | **ACCEPT** (C11R2-L2 recommended) |
| C11b — logical mode + device parts | REJECT | **ACCEPT** (C11R2-L1 recommended) |
| C11c — physical mode | REJECT | **ACCEPT** |
| C11d — ADR-058 gravity field | ACCEPT | **ACCEPT** |

C11R2-L1 sits in the C11b `device owner` command and the C11c registration path. It needs an operator command to race
a chunk save, so it does not block either slice.

## Per-finding status

| Finding | Fix commit | Status | Verification |
|---|---|---|---|
| C11R-C1 partial shift-click not persisted | `e56eec4` | **Fixed** | `EndgameItemSlot.setChanged()` forwards to the block entity (`endgame/device/EndgameItemSlot.java`); used for the drill lens/output, marker buffer, generator fuel. Probe R2 `aPartialShiftClickOutOfTheDrillOutputReachesTheDisk`: `disk_before=64 live_after_partial=54 moved=10 disk_after_save=54`; the fix's own marker test reads the disk too. |
| C1 sibling: satellite terminal/builder | `bcce9c4` | **Fixed** | Their slots forward `setChanged()`; I checked the other `SlotItemHandler` menus: electrolyzer, precision assembler and rolling machine write moved stacks back with `set` (`machine/*/…Menu.java`, `sourceSlot.set(...)`), the microwave receiver's slots hold one item. Claim holds. |
| C11R-H1 hanging blocks counted twice | `0cffc08` | **Fixed** | Cells without a full collision shape are removed first; a cell whose block a same-layer reaction already changed is skipped with its planned drops (`endgame/laser/LaserPhysicalDrill.java`, `remove()` and the two-pass order in `plan()`). Probe R2: layer 1 wall torch on stone (removed first, in the marker), layer 2 wall torch on stairs that precede it (stairs removed first, vanilla drops the torch, the cell is skipped): `torches_placed=2 torches_in_marker=1 torch_item_entities=1 stairs_in_marker=1 cobblestone_in_marker=15`. The refinement of ADR-055 §3 step 4 keeps conservation (see C11R2-I1). |
| C11R-H2 slots ignored `WITHDRAW` | `4f5556e` | **Fixed** | `mayPickup` needs `WITHDRAW`, `mayPlace` needs `CONFIGURE`, decided server-side per click; `quickMoveStack` checks first (drill, marker, generator). I walked every vanilla click path (pickup, place, swap, throw, pickup-all, quick-craft drag, quick-move; `moveItemStackTo` merges are only reachable after the quick-move check). Probes R2: stranger `carried_after_pickup_all=1 left_in_buffer=12 thrown=0`; station member `dragged_in=false swapped_in=false`; the fix's tests cover quick-move, pickup, throw, swap. Put = `CONFIGURE` is acceptable: in ADR-054 §3 `CONFIGURE` and `OPERATE` grant the same actors except ADR-058's station narrowing, which has no slots. |
| C11R-M1 revoked-link overflow | `c87b71f` | **Fixed** | Monotone marker `generation`; links record first-contact generation (`-1` before); an unlinked marker adopts only `-1` or its current generation (`LaserLinkCounters.accepts`). Checked: payment always follows `touched()` in the same tick, so no paid link keeps `-1`; a crash rollback restores marker and blocks together. Probe R2: `refused_after_reset=true refused_after_20_more=true new_link_accepted=true generation=21`. |
| C11R-M2 `device owner` left the index | `bbae140` | **Fixed** (see new C11R2-L1) | `reassign` as a barrier first, within the new owner's limit, then the block entity; marker link reset. Probe R2: `record_and_block_entity_moved=true`. A marker not yet registered is not covered (C11R2-L1). |
| C11R-M3 refused forget wrote the root | `490e2bc` | **Fixed** | Refusals decided on the read view, no write, no audit line; foreign record = not found; success coalesced. Probe R2: `write_pending_before=true forget_result=0 write_pending_after=true`. |
| C11R-M4 `WITHDRAW` unreachable | `c5de66a` | **Fixed** | `openRefusal` admits `VIEW`, or `WITHDRAW` alone; `stillValid` uses it; withdraw-only view carries only the refusal code; buttons refused by the intent guard; puts refused (`CONFIGURE`). Covered by `EndgameMenuGameTests.theOwnerWithdrawsFromADrillInAnUnavailableStation` (passes). |
| C11R-M5 index rebuild / housekeeping | `e8540b6` | **Fixed** | Root records touched IDs on every indexed mutation (register, remove, markMissing, settle, evict, reassign; forget/retire go through settle); only `coalesced`/`barrier` mutate and both drain. Housekeeping ≤ 1 per 200 ticks, O(1) count. Benchmark (round-1 harness, unchanged): 3,840 settled → idle 0.001 ms, no-op call 0.002 ms; 8,192 settled → idle 0.009 ms, no-op 0.001 ms (were 1.256 / 0.947 ms). |
| C11R-L1 events posted twice | `a1bf266` | **Fixed** | Grant taken before planning. Probe R2: `break_events_layer1=9 break_events_layer2=9`. |
| C11R-L2 model not used by engine | `53af094` | **Fixed** | Engine takes every step from `LaserLinkCounters.next` and contact from `accepts`; I checked the refactor is equivalent to the old inline logic (debt loop, `ENERGY_DEBT`, credit, `INSUFFICIENT_ENERGY`). New GameTests drive debt and credit cuts. |
| C11R-L3 crash paths from long IDs | `f849173` | **Fixed** | `register` refuses with `TARGET_OUT_OF_BOUNDS`; table/black-hole file IDs > 128 chars fail the reload; view text cut to the byte bound without splitting a surrogate pair. Unit tests present (`EndgameRootTest.aLevelKeyOverTheRecordBoundIsRefused`, `LaserDrillTablesTest.tableIdsFromFilePathsAreBounded`, `EndgameDeviceViewTest.longTextValuesAreCutToTheBound`). Code choice: see C11R2-I2. |
| C11R-L4 32-bit Level hash | `67a3635` | **Fixed** | ACTIVE records, young tombstones and candidates keyed by the full Level key; settled tombstones by hash, reachable from a colliding Level only for housekeeping read-back. Unit test `levelKeysWithEqualHashesDoNotShareChunks`. |
| C11R-L5 registration relied on incidental saves | `2038307` | **Fixed** | Awaiting marker calls `setChanged()` at each status check; GameTest runs one check on a clean chunk. |
| C11R-L6 trust list without schema | `4c7c707` | **Fixed** | `{schema_version: 1, owners: [...]}`; bare list read and rewritten on change; GameTest. |
| C11R-L7 missing negative tests | `a8cf76d` (+ tests in each fix) | **Fixed** | Tests for C1, H1, H2, M1–M4, L1–L6, L8, I8 exist; unloaded-marker GameTest; ticket counts by type around the laser and gravity chunks (`gametest/TicketCounts.java`, reflection on the dev-mapped `tickets` field; chunk-load and player tickets excluded, loads caught by loaded-chunk counts). |
| C11R-L8 unbounded results / unpaged lists | `199e351` | **Fixed** | Results kept only for refusals, dropped on registration/forget; `zone list [page]`, `endpoint list [player] [page]`; GameTest pages 20 zones. |
| C11R-I7 quarantine line | `f103e18` | **Fixed** | Reason cut to 256 chars, one line. Keeping it a log line rather than an audit-ring line is acceptable (ADR-054 §2 names a log line; the device package does not depend on the service). |
| C11R-I8 forget from `/execute as` | `8c5e94d` | **Fixed** | Shared `EndgameCommandSources.ownPlayer`; GameTest. |
| C11R-I1–I6, I9 | — | Accepted as is | No change made. The draft dispositions were not read (untracked; outside the review scope). |
| C11R-I10, I11 | — | Informational | I10: the repository moved past the round-1 commit (expected). I11: the `validate_*.py` scripts still need a Git worktree; I did not run them. |

## New findings

### C11R2-L1 (Low) — An owner change before registration can register the old owner

- **Location:** `endgame/command/EndgameCommands.java` (`assignOwner`: `reassign` only when a record exists);
  `endgame/service/EndpointRegistrations.java` (`drain` registers the waiting candidate's owner);
  `endgame/laser/LaserTargetBlockEntity.java` (the candidate is refreshed only at the next 20-tick status check).
- **Rule:** ADR-054 §9 (selection lists "owned by the device's owner"), ADR-055 §3 rule 1, and the intent of C11R-M2.
- **Scenario:** a laser target is placed (or loaded) and its candidate waits with owner A. An operator runs
  `/arce endgame device owner … B`. No record exists yet, so nothing is reassigned, and the block entity becomes B's.
  If the marker's chunk saves before the marker's next status check (≤ 20 ticks; autosave, an unload, or the
  `setChanged()` the L5 fix adds), the record registers with owner **A**. A's drills can then list, link and dig
  B's marker, the state C11R-M2 fixed for registered markers.
- **Evidence:** probe `anOwnerChangeBeforeRegistrationCanRegisterTheOldOwner` (run 2):
  `command_result=1 block_entity_owner_is_new=true registered_record_owner_is_old=true`.
- **Fix:** take the owner from the persisted tag at registration (the tag carries `owner_id` and is the authority the
  ADR already relies on), or call `forgetCandidate` / re-await with the new owner in the marker's `ownerChanged`.

### C11R2-L2 (Low) — `EndgameService` crossed 500 lines without a responsibility check

- **Location:** `endgame/service/EndgameService.java` (529 lines after M5/L4/L8; 439 at `8d52d7f`). It now holds
  lifecycle and write policy, persistence observations, the incremental chunk index and diagnostics.
- **Rule:** AGENTS §3.4 (a class over 500 lines must be checked for mixed responsibilities). The implementation log
  records the check for `OrbitalLaserDrillBlockEntity` (still quoted at 577 lines; it is now 587).
- **Fix:** move the chunk index (`index`, `indexedAt`, `updateIndex`, `rebuildIndex`, `indexKey`, `ChunkKey`) into
  its own class, or record the check in the log; refresh the 577-line note.

### Info

- **C11R2-I1** — H1's skip rule also skips a cell that a same-layer reaction turned into another, non-air block
  (e.g. concrete powder next to a waterlogged stairs cell removed first becomes concrete). That block stays in the
  shaft while the layer advances. Nothing is duplicated or lost; it is a rare cosmetic gap in the "whole layer".
  Separately, blocks that vanilla drops under the skip rule land as item entities in the shaft, not in the marker,
  so players should be told.
- **C11R2-I2** — `TARGET_OUT_OF_BOUNDS` doubles as the refusal for a kind or Level key too long to record. The
  wording ("outside the world border or build height") does not fit that case; a dedicated code would be clearer.
  Acceptable as recorded.
- **C11R2-I3** — The marker root now requires `generation` (and rejects `revoked`), and the drill link requires
  `generation`. Any root in the C11 development format is therefore quarantined on load. This is acceptable for the
  unreleased format, as the log records.
- **C11R2-I4** — Test-file hygiene, no effect on behaviour:
  - `gametest/LaserTargetGameTests.java` imports `CommandSource` twice.
  - In `gametest/GravityFieldGameTests.java`, the new L6 test was inserted between the `command(...)` helper's
    Javadoc and the helper, so that Javadoc now sits above the wrong method.
- **C11R2-I5** — The pre-existing v1.3 GameTest `assemblyRollbackExceptionRetainsSnapshotForLaterRestoration` failed
  once in my two GameTest runs ("Fixture entity chunk is not ready for recovery") and passed on the rerun. It is
  timing-sensitive and unrelated to C11, but worth watching in evidence runs.

## Regression checks (no problem found)

- **Data slots:** the base menu now adds its authority data slot first, so subclass data slots shift by one index.
  This is symmetric on client and server, and the gravity and drill energy readers use their own `ContainerData`
  objects, so it is safe.
- **Withdraw-only menu:** it reveals only item slots and the refusal code, and all buttons are still refused through
  the intent guard.
- **L1 grant spending:** a grant spent by a stopped plan does not cause per-tick spinning, because stops reschedule
  20 ticks later.
- **L5 dirtying:** markers held at `ENDPOINT_LIMIT` or `TARGET_OUT_OF_BOUNDS` keep their chunk dirty. The only
  effect is one extra chunk write per autosave.
- **Chunk-load threads:** the M5 index is a `ConcurrentHashMap` of immutable sets, which is safe for chunk-load
  thread readers.
- **AGENTS:** no `net.minecraft.client` import was added in `endgame/` or `api/`. No new class exceeds 800 lines.

## Commands run (in `tree2/`, Java 17.0.7, `--no-daemon --offline`; logs in `logs/`)

| Command | Result |
|---|---|
| `git -C <repo> log/show/diff/archive` (read-only) | `tree2/` = `a8cf76d`; `gen-ref/` = committed `src/generated` |
| `gradlew clean build test runData runGameTestServer` with `probes/ReviewRound2ProbeGameTests.java` and the benchmark added | build, test, runData OK; GameTests: 2 failed — my race probe (timing flaw: the marker's status field starts as `AWAITING_WORLD_SAVE`) and the flaky rocket test (C11R2-I5) (`logs/round2-full.log`) |
| JUnit from that run | **1,305 tests / 241 suites, 0 failures** (1,304 / 240 plus my benchmark) |
| `diff -r gen-ref/src/generated tree2/src/generated` after runData | identical except the git-ignored `v1.7/resources/.cache` |
| Error lines in that log | 20 ERROR (the evidence's 18 plus the two test-failure lines), 0 FATAL |
| `gradlew runGameTestServer` with the race probe corrected | **All 328 required tests passed** (320 plus 8 probes) (`logs/round2-gametest2.log`) |
| Benchmark (`ReviewHousekeepingBenchmarkTest`, unchanged from round 1) | numbers in the M5 row |

All probe and benchmark lines are in `logs/round2-probe-results.txt`. Probes in round 2 assert the fixed behaviour,
except `anOwnerChangeBeforeRegistrationCanRegisterTheOldOwner`, which asserts the suspected new problem
(C11R2-L1). No file outside this review directory was written.
