"""Pin actual preparation checks without claiming new v1.4 runtime behavior."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).parent
OUT = ROOT / 'docs/work/v1.4.0-preparation'
BASE = '1a192b4b9b9a90372c11643e086f7b0fbdcd1860'
REVIEW = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-contract-review-2s_izm8c')
REVIEW_SHA = '42ed789ec9c3efd89af9e1a01ab4b51a0491a1cc3661265859f3411d512dd5a2'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def collect():
    log = (TEMP / 'baseline-build.log').read_text(encoding='utf-8')
    assert '> Task :test FROM-CACHE' in log
    assert 'All 210 required tests passed' in log and 'written: 0' in log
    assert 'BUILD SUCCESSFUL in 2m 1s' in log
    frozen = TEMP / 'frozen/junit'
    frozen.mkdir(parents=True, exist_ok=True)
    for path in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
        shutil.copyfile(path, frozen / path.name)
    roots = [ET.parse(p).getroot() for p in sorted(frozen.glob('TEST-*.xml'))]
    counts = {'suites': len(roots), **{k: sum(int(r.attrib.get(k, 0)) for r in roots)
                                     for k in ('tests', 'failures', 'errors', 'skipped')}}
    assert counts == {'suites': 143, 'tests': 769, 'failures': 0, 'errors': 0, 'skipped': 0}
    prior = json.loads((ROOT / 'docs/releases/v1.3.0/development-artifacts.json').read_text())
    artifacts = []
    for old in prior['artifacts']:
        if old['name'].startswith('arce-adapter-'):
            continue
        path = ROOT / 'build/libs' / old['name']
        identity = {'name': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
        assert identity['bytes'] == old['bytes'] and identity['sha256'] == old['sha256']
        artifacts.append(identity)
    metadata = {'schema_version': 1, 'development_baseline': BASE,
                'scope': 'Unchanged v1.3 runtime checks during v1.4 contract preparation; not v1.4 feature verification',
                'command': 'gradlew.bat clean build runData runGameTestServer --offline --no-daemon --console=plain',
                'exit_code': 0, 'duration_seconds': 121,
                'tasks': {'executed': 18, 'from_cache': 8, 'up_to_date': 1},
                'junit': {**counts, 'execution': 'FROM-CACHE, not newly run'},
                'required_gametests_passed': 210, 'datagen_written': 0,
                'game_test_world': 'Disposable build/gametest world after clean',
                'lag_warnings': [line.strip() for line in log.splitlines() if "Can't keep up" in line],
                'build_log_sha256': sha(TEMP / 'baseline-build.log'),
                'artifacts': artifacts, 'native_restart_run': False,
                'new_runtime_implementation': False, 'candidate_commit': None}
    write_json(OUT / 'baseline-checks.json', metadata)
    print(json.dumps(metadata, indent=2))


def links():
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', '*.md'], cwd=ROOT).decode().split('\0')
    extras = [ROOT / 'docs/work/v1.4.0-implementation-log.md',
              ROOT / 'docs/decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md',
              ROOT / 'docs/decisions/ADR-031-PLANETARY-DEFINITIONS-AND-FIXED-LEVELS.md']
    paths = {ROOT / p for p in tracked if p} | set(extras) | set(OUT.glob('*.md'))
    missing, count = [], 0
    for path in sorted(paths):
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith(('#', 'mailto:')) or re.match(r'^[A-Za-z]:[/\\]', target):
                continue
            relative = urllib.parse.unquote(target.split('#', 1)[0])
            if relative:
                count += 1
                if not (path.parent / relative).exists():
                    missing.append([path.relative_to(ROOT).as_posix(), target])
    result = {'markdown_files': len(paths), 'targets': count, 'missing': missing,
              'scope': 'Existing relative local-file targets; excludes external URLs and anchor contents'}
    write_json(TEMP / 'links.json', result)
    print(json.dumps(result))
    assert not missing


def review():
    assert sha(REVIEW / 'REVIEW.md') == REVIEW_SHA
    entries = []
    with zipfile.ZipFile(OUT / 'independent-review.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(REVIEW.rglob('*')):
            if path.is_file():
                relative = path.relative_to(REVIEW).as_posix()
                entry = {'member': 'review/' + relative, 'bytes': path.stat().st_size,
                         'sha256': sha(path)}
                z.write(path, entry['member'])
                entries.append(entry)
    write_json(OUT / 'independent-review.json', {
        'schema_version': 1, 'reviewer': '/root/prec04b_readback_review',
        'scope': 'Independent read-only source/draft/example review; not ADR acceptance or runtime verification',
        'reviewed_baseline': BASE, 'archive': 'independent-review.zip',
        'archive_sha256': sha(OUT / 'independent-review.zip'),
        'report_sha256': REVIEW_SHA, 'entries': entries})
    print('Archived unchanged independent evidence:', len(entries), 'files')


def docs():
    commands = [
        ('examples-final', [sys.executable, '-B', 'docs/work/v1.4.0-preparation/check_examples.py']),
        ('planning', [sys.executable, '-B', 'scripts/validate_v1plus_planning.py']),
        ('repository', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
        ('source-diff', ['git', 'diff', '--exit-code', BASE, '--', 'src', 'build.gradle',
                         'gradle.properties', 'settings.gradle', 'compat-test-mod']),
        ('diff-check', ['git', 'diff', '--check']),
        ('staged-diff-check', ['git', 'diff', '--cached', '--check']),
    ]
    results = []
    for name, command in commands:
        started = time.perf_counter()
        result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (TEMP / (name + '.log')).write_bytes(result.stdout)
        record = {'name': name, 'command': command, 'exit_code': result.returncode,
                  'duration_seconds': round(time.perf_counter() - started, 3),
                  'log_sha256': sha(TEMP / (name + '.log'))}
        results.append(record)
        write_json(TEMP / 'documentation-checks.json', results)
        print(json.dumps(record), flush=True)
        print(result.stdout.decode('utf-8', errors='replace'), flush=True)
        assert result.returncode == 0, name


def package():
    with zipfile.ZipFile(OUT / 'root-checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(TEMP.iterdir()):
            if path.is_file() and path.suffix in ('.py', '.log', '.json'):
                z.write(path, 'root/' + path.name)
        for path in sorted((TEMP / 'frozen/junit').glob('TEST-*.xml')):
            z.write(path, 'junit/' + path.name)
    paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in paths), encoding='ascii', newline='\n')
    print('Checksummed preparation files:', len(paths))


def verify():
    rows = (OUT / 'SHA256SUMS.txt').read_text().splitlines()
    names = [line.split('  ', 1)[1] for line in rows]
    assert len(set(names)) == len(names)
    assert set(names) == {p.name for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS.txt'}
    for line in rows:
        expected, name = line.split('  ', 1)
        path = OUT / name
        assert sha(path) == expected, ('working', name)
        staged = subprocess.check_output(['git', 'show', ':' + path.relative_to(ROOT).as_posix()], cwd=ROOT)
        assert hashlib.sha256(staged).hexdigest() == expected, ('staged', name)
    for path in sorted(OUT.glob('*.zip')):
        with zipfile.ZipFile(path) as z:
            assert len(z.namelist()) == len(set(z.namelist())) and z.testzip() is None
    metadata = json.loads((OUT / 'baseline-checks.json').read_text())
    with zipfile.ZipFile(OUT / 'root-checks.zip') as z:
        assert hashlib.sha256(z.read('root/baseline-build.log')).hexdigest() == metadata['build_log_sha256']
        roots = [ET.fromstring(z.read(n)) for n in z.namelist() if n.startswith('junit/TEST-')]
        assert len(roots) == 143 and sum(int(r.attrib['tests']) for r in roots) == 769
    review_identity = json.loads((OUT / 'independent-review.json').read_text())
    assert sha(OUT / review_identity['archive']) == review_identity['archive_sha256']
    with zipfile.ZipFile(OUT / review_identity['archive']) as z:
        assert set(z.namelist()) == {entry['member'] for entry in review_identity['entries']}
        for entry in review_identity['entries']:
            raw = z.read(entry['member'])
            assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
        assert hashlib.sha256(z.read('review/REVIEW.md')).hexdigest() == REVIEW_SHA
    print('PASS: working/staged hashes, unique ZIP entries/CRC, archived baseline log/XML and independent evidence identities')


if __name__ == '__main__':
    {'collect': collect, 'links': links, 'review': review, 'docs': docs,
     'package': package, 'verify': verify}[sys.argv[1]]()
