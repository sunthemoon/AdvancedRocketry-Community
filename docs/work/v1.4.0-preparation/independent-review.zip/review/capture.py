import hashlib
import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
OUT = pathlib.Path(__file__).parent

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

drafts = [
    'docs/decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md',
    'docs/decisions/ADR-031-PLANETARY-DEFINITIONS-AND-FIXED-LEVELS.md',
    'docs/work/v1.4.0-implementation-log.md',
]
selected = []
for name in git('ls-files', 'src/main/java', 'src/test/java', 'docs/decisions').splitlines():
    if any(part in name for part in (
        '/celestial/', '/travel/', '/station/', '/rocket/flight/',
        '/rocket/server/', '/rocket/transfer/', '/compat/environment/',
        '/api/environment/', '/satellite/service/',
    )) or name.endswith(('AdvancedRocketryCommunity.java', 'AtmosphereManager.java',
                           'ADR-020-V130-DEVELOPMENT-BASELINE-EXCEPTION.md',
                           'ADR-021-PUBLIC-API-VERSION-POLICY.md',
                           'ADR-028-READ-ONLY-ENVIRONMENT-QUERIES.md')):
        selected.append(name)
selected += drafts + ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'build.gradle',
    'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/versions/V1.4.0-PLANETARY-EXPANSION.md']
hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
          for name in sorted(set(selected))}
for name in drafts:
    shutil.copyfile(ROOT / name, OUT / ('initial-' + pathlib.Path(name).name))
record = {'head': git('rev-parse', 'HEAD'), 'branch': git('branch', '--show-current'),
          'status': git('status', '--short'), 'hashes': hashes,
          'note': 'Hashes are identity inventory, not a claim of exhaustive review or test execution.'}
(OUT / 'initial-identities.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'head': record['head'], 'branch': record['branch'],
                  'hashed_files': len(hashes), 'report_dir': str(OUT)}))
