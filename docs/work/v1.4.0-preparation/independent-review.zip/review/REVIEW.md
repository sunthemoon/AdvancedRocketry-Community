# V140 preparation: independent source and contract review

## Identity and result

Reviewer: delegated `/root/prec04b_readback_review`, separate from the sole root writer.
Repository: `D:/GitHub/AdvancedRocketry-Community`; branch `codex/v1.4.0-planetary-expansion`;
baseline `1a192b4b9b9a90372c11643e086f7b0fbdcd1860`.
This is read-only preparation/contract review, not implementation verification, approval of an ADR,
a runtime result, or a Required Gate verdict. Production remains unchanged at the reviewed baseline.

## Findings, ordered by severity

### Medium, existing mechanism to replace in DATA-02: malformed resources can disappear before validation

[CelestialDefinitionReloadListener.java:15,32-34](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialDefinitionReloadListener.java#L15)
inherits the platform JSON preparation path. Independent `javap` of the pinned Forge 47.4.10
mapped class confirms `scanDirectory` parses readers before any project byte budget, catches
`IOException`/`JsonParseException`, logs, and continues without the failed file. The project
[decoder:26-39,51-56](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialCatalogDecoder.java#L26)
only sees the remaining parsed map and checks compact JSON character length afterward.

Concrete source-derived trigger: accept Earth/Moon/Space plus an independent custom body;
make only that custom file syntactically invalid while leaving no dependent body references.
The three-body remainder still validates and replaces the prior catalog rather than retaining
the custom body. The existing `rejectedCandidateRetainsLastValidCatalog` test directly supplies
an error result; it does not exercise this preparation failure.

Disposition: revised ADR-031 explicitly requires bounded raw reads, whole-candidate failure on
syntax/read errors, and real malformed-file retention tests in DATA-02. This is a necessary
planned correction, not a claim that it already works. Retained platform evidence:
`SimpleJsonResourceReloadListener-javap.txt` (parse offsets 77-90; catch/log/continue 176-207).

### Medium, resolved during review: graph validity versus destination admission

The initial ADR-031 said capability-compatible route endpoints without explaining how a
closed destination remains a departure source. Existing
[RouteCatalog.java:69-110](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/travel/route/service/RouteCatalog.java#L69)
builds static forward/reverse edges. Rejecting every `landable=false` endpoint would remove
the exit route or reject the complete reload, contrary to the proposed departure guarantee.

The revised contract now specifies that a surface graph endpoint needs a mapped non-gas body;
landable/orbitable are final-destination/new-station checks, not reasons to remove reverse
edges. It also explicitly preserves departure from a committed station after orbitable becomes
false, subject to existing region/ownership checks. This resolves the design ambiguity;
runtime implementation and the corresponding source-versus-destination tests remain unexecuted.

### Medium, resolved by explicit scoped deferral: cross-restart body/Level identity binding

The initial mapping rule forbade reinterpreting an old identity but did not identify the
enforcement boundary. [CelestialSavedData.java:24-35,167-182](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L24)
stores discovery/visit identities, not a body-to-Level ledger. Existing flight plans and transfer
records instead retain their captured body/dimension/target/fuel authority. Comparing only
consecutive catalogs cannot detect a remap across restart or remove/re-add.

The revised ADR-031 explicitly keeps DATA-01's existing Earth/Moon admission and baseline
mapping invariants, defers persisted custom binding/old-world initialization to MAP/MIG before
new-world admission, and forbids inferred rewrites of existing rocket/station records. This is
an accurate limitation, not a migration guarantee. Preserve this prerequisite in later work.

### Low, resolved during review: intentionally stricter legacy input limits

The new 32,768 raw UTF-8 byte limit, nesting limit and duplicate-key rejection are stricter
than the existing post-parse compact-character check. A legacy pack with large whitespace,
Unicode ignored metadata, or duplicate object keys may have loaded before but be rejected now.
The revised ADR-031:135-140 states this intentional fail-closed authoring compatibility
boundary, active-pair retention/initial failure, and operator repair/compaction then retry.
It forbids automatic pack/world rewrites or accepting only the parsed subset. This resolves
the wording issue without enlarging the budget. Existing values of a successfully decoded
legacy definition must still be preserved.

No unresolved document finding or additional blocking contradiction was identified in ADR-030's proposed baseline authority,
the revised first-slice boundaries, or the unchanged public API/save identity policy. All three
new preparation documents are still proposals/planning, not runtime permission by themselves.

## Existing mechanisms and affected consumers

All Java references below are production facts, not proposed capabilities.

| Boundary | Existing mechanism and implication |
|---|---|
| Definition model | `celestial/model/CelestialBodyDefinition.java:13-44,51-57` has no schema field and requires a non-null `level`, despite the optional-mapping Javadoc. Optional mapping changes must reach every consumer, not just the codec. |
| Immutable catalog | `celestial/service/CelestialCatalog.java:20-33,66-105` limits 128 bodies, fixes Earth/Moon/Space graph/mappings, indexes every body by Level, and returns no result for ambiguous Level mappings. Do not replace ambiguity with first-entry selection. |
| Reload scope | `AdvancedRocketryCommunity.java:235-239` registers celestial, routes and satellite listeners separately. `travel/route/service/RouteDefinitionReloadListener.java:39-47` and `satellite/service/SatelliteDefinitionReloadListener.java:39-48` use the then-active celestial catalog. Existing atomicity is manager-local, not a coherent pair or all-datapack rollback. The proposed celestial/route pair intentionally does not include satellite/assets. |
| Context and environment | `celestial/context/BodyContextResolver.java:38-61` resolves committed instances before Level; `station/orbit/StationRegionBodyContextResolver.java:21-36` owns Space and makes gaps unresolved. `compat/environment/ServerEnvironmentQueries.java:38-82` is server-thread/lifetime scoped, requires an existing Level, reads no chunks, and projects persisted station gravity/vacuum rather than surface atmosphere. |
| Runtime physics boundary | `celestial/service/CelestialGravityController.java:22-30` and `atmosphere/server/AtmosphereManager.java:109-132` remain Level-based; ambiguity falls back to existing defaults. New metadata does not unify these with position-aware BodyContext, add temperature damage, or implement solar/radiation effects. |
| New surface entry | `rocket/flight/RocketTargetFlightPlanner.java:108-138` can quote generic surface/orbit identities, but `rocket/transfer/RocketLandingPadSelector.java:52-70,328-329` admits only Earth/Moon. `rocket/server/RocketFlightService.java:128-164,286-313` builds surface quotes and rejects direct Orbit requests. Do not advertise new terrain travel merely because a pure planner accepts its ID. |
| Loaded-region authority | `rocket/flight/RocketFlightLimits.java:18-20` has 8 landing candidates and 16 chunks per candidate; `RocketLandingPadSelector.java:321-324` deliberately loads server-selected bounded chunks. Metadata lookup remains zero-chunk, while actual flight is not zero-chunk. No new client-selected coordinates or unlimited candidate search. |
| Station creation and preservation | `station/service/StationManager.java:55-79` permits player creation from Earth/Moon; operator creation uses a body-exists predicate. `station/persistence/StationRegistrySavedData.java:186-200` reports missing orbit bodies without deleting stations/reservations. Capability checks must distinguish new creation/arrival from existing ownership and departure. |
| Frozen transaction authority | `rocket/server/RocketTransferService.java:51-146` captures exact destinations, relocated snapshots and fuel in the journal before countdown; later phases use those recorded dimensions/snapshots. Reject new entry after removal/capability changes without silently recomputing or deleting accepted journals. |
| Legacy migration | `travel/migration/LegacyFlightTargetMigrator.java:28-91` checks exact world location/body and handles shared Space via region context; ambiguous/unknown data blocks instead of guessing. `RocketTargetContextService.java:62-94` migrates only suitable committed legacy transfers. Preserve these distinct schemas and checks. |
| Display and API | `celestial/network/CelestialSnapshotCodec.java:21-42` is schema 1/96 KiB with mandatory Level; channel version 1 is exact matched in `CelestialNetwork.java:12-26`. `CelestialSnapshotSynchronizer.java:20-45` sends complete snapshots on join/reload and `client/ClientCelestialEvents.java:21` clears disconnect cache. ADR-021 and ADR-028 protect public API 1.7 signatures; internal optional mappings are not permission to change exported record constructors. |
| Persisted progress | `CelestialSavedData.java:126-162,167-182` retains stable-ID progress independently of catalog removal, with a separate 128-entry lifetime limit. Removed entries still consume that bound; never silently prune them to make room. `satellite/service/SatelliteManager.java:436-452` retains pending discovery when its target is absent or progress is full. |

## Recommended finite verification

1. Legacy Earth/Moon/Space samples decode to exactly the old gravity/atmosphere/orbit/visual values;
   add only specified defaults. Explicit schema 1, absent schema, future/malformed schema,
   reserved new fields without version 2, nested unknown fields and integer-fraction cases.
2. Schema 2 capability/mapping combinations, null versus absent, finite endpoints, max/max+1
   IDs/count/bytes/depth. Keep constructors/programmatic catalog creation and serialized validation
   aligned; current direct constructors do not perform every codec numeric check.
3. Actual request refusal for unmapped/gas/closed destination with unchanged fuel/journal;
   closed mapped source and orbit-disabled committed station may leave under existing permissions.
   Preserve direct-Orbit refusal and bounded Earth/Moon admission until MAP is implemented.
4. Real preparation path with syntax/duplicate-key/read failure, missing related route, invalid
   graph, valid replacement and rejected replacement. Capture exact old pair/generation/cache
   before rejection; no partial pair visible. Test 100 valid bodies and hard-limit boundaries
   without calling the result a soak/performance acceptance.
5. Snapshot 2 round-trip at maximum supported shape, optional Level, all configured fields,
   malformed/future/trailing/oversized payload retention, disconnect clearing, and exact channel
   mismatch rejection. Preserve unchanged API export set/signatures and inspect packaged identity.
6. Bounded copied-world save/restart with raw station/progress/flight identities and original
   resource files retained. Distinguish old-definition decoding, synthetic NBT fixtures,
   clean process restart, and authentic whole-world upgrade; no S2/V1/V2 inference.

## Outstanding later decisions (not missing first-slice implementation)

- MAP/MIG stable mappings and legacy initialization, including removed/re-added bodies and
  occupied/in-flight worlds; exact Mars/Venus body and dimension IDs before adding resources.
- NAV/DISC discovery ownership policy and actual unlock enforcement. Current progress is
  overworld-global; merely sending catalog entries is not access control.
- ENV rules for temperature/solar/radiation and position-versus-Level simulation; SKY/asset
  provenance and visual profiles. Reserved metadata is not implemented protection/gameplay.
- Historical-ID capacity policy if catalog churn exhausts 128 retained progress entries.

## Checks actually executed and evidence

- Read applicable AGENTS, PROJECT-CONFIG, PRODUCT, docs 01/04/05/06/14/16/17, v1.4 plan,
  ADR-020/021/028 and new ADR-030/031/worklog; targeted numbered PowerShell reads and `rg`
  of source/tests. Production Java tests were inspected, **not executed**.
- `git status --short`, `git branch --show-current`, `git rev-parse HEAD`, `git diff --stat`,
  and `git diff --check` (exit 0). The latter does not validate untracked draft contents.
- `D:/python/pyenv/pyenv-win/shims/python.bat -B <review-dir>/capture.py` (exit 0):
  retained 214 selected source/doc identity hashes and initial draft copies. Inventory size
  is not a claim of exhaustive review of every listed file.
- `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -c -p -classpath <pinned Forge47.4.10 mapped JAR>
  net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener` (exit 0), retained
  as `SimpleJsonResourceReloadListener-javap.txt`. This is cached-bytecode inspection only.
- Some early searches used guessed nonexistent filenames (`CelestialLimits`, old ADR020 name,
  RocketFlightManager/service path, equipment/test name); their read errors were corrected
  through tracked-file enumeration and actual paths. They are not test results.

No Gradle, production/runtime tests, server/client, mutable build output, browser/network, Git mutation, repository
write, user untracked documentation bundle access, OpenPet, or subdelegation was used.
Temporary helper/report writes are confined to this new review directory.

## Final documentation-only verification

Reviewed `docs/work/v1.4.0-preparation/examples.json` and `check_examples.py` against the revised
ADR. No additional finding. Six authored samples demonstrate legacy Earth, schema-2 Earth,
closed Moon, Mars-like/Venus-like and unmapped gas-giant metadata. Their `example:` IDs and
values are not installed Levels, calibrated astronomy, or approved assets.

Independent command, with `PYTHONUTF8=1`:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B C:/Users/Administrator/AppData/Local/Temp/arce-v140-contract-review-2s_izm8c/final_checks.py
```

Exit 0. That retained helper used the actual Python interpreter selected by the shim and ran:

```text
<python.exe> -B docs/work/v1.4.0-preparation/check_examples.py
<python.exe> -B scripts/validate_v1plus_planning.py
```

Both exited 0. **14 documentation example tests passed** (unittest-reported 0.011 seconds).
Planning passed **11 plans / 33-input inventory** without a `--package-root` argument.
The bounded repository Markdown helper checked **366 files / 1,526 local targets**, zero
missing/unsafe targets. It read tracked Markdown plus new `docs/` Markdown only; it does not
validate external URLs or anchor contents. Raw output, exact resolved commands and timing are
in `examples.log`, `planning.log`, `links.json`, and `final-checks.json`.

The checker is deliberately not a production codec or complete catalog validator: its
synthetic 100/128-body cases check authored graph/count constraints, not fixed Earth/Moon/Space
baseline admission, route pairing, world loading, runtime timing or the required 100-body
performance evidence. It cannot prove reload rollback, authority, departure, native migration,
snapshot encoding, source/binary API compatibility, or client rendering. Those remain runtime
implementation obligations listed above.

The final helper detected **zero source-byte changes** across the initial selected `src/`
identity inventory. Five current draft/example/checker hashes and the unchanged baseline HEAD
are retained in `final-checks.json`; initial draft copies remain intact for the finding history.
Root's separately reported unchanged-baseline build/GameTest run was not repeated or audited
from mutable output here and is not evidence of a v1.4 implementation.

This review concludes the requested preparation/source-feasibility and actual draft check only.
Both ADRs remain proposed at the inspected identities, runtime permission remains false, and
the complete v1.4 acceptance campaign and inherited Required Gates remain open.
