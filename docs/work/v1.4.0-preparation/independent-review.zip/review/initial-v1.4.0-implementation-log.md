# v1.4.0 implementation log

## Goal and scope

Deliver [Planetary Expansion](../versions/V1.4.0-PLANETARY-EXPANSION.md):
explorable contrasting worlds, non-landable logical bodies, authoritative
environment, navigation/discovery and sky presentation. Complete the scoped
implementation before the deferred full acceptance campaign; do not equate
development progress with release approval.

```yaml
version: v1.4.0
status: IN_PROGRESS
phase: CONTRACT_PREPARATION
branch: codex/v1.4.0-planetary-expansion
proposed_development_baseline: 1a192b4b9b9a90372c11643e086f7b0fbdcd1860
runtime_implementation_allowed: false
last_updated: 2026-09-27
```

The baseline contains the reviewed v1.3 implementation and development handoff,
not a passed v1.3 candidate. Inherited acceptance remains open. Root is the sole
tracked writer; independent review is read-only with fresh Temp outputs. The
user-supplied untracked documentation bundle is excluded from reads and writes.

Preparation non-goals: runtime changes, new assets, changing an existing world,
candidate/tag/release approval, remote/client/long-load tests or v1.5+ features.
No physics, terrain, sky, discovery or API implementation is implied by a draft.

## Feature map

- [ ] `V140-GOV-01` Version-limited development baseline decision — status: in-progress
- [ ] `V140-CON-01` Fixed-Level strategy and definition contract — status: in-progress
- [ ] `V140-DATA` Versioned definitions and coherent catalogs — status: planned
  - [ ] `V140-DATA-01` Legacy-compatible schema and capability-aware consumers — status: planned
  - [ ] `V140-DATA-02` Joint bounded celestial/route reload — status: planned
  - [ ] `V140-DATA-03` Independent schema/reload and restart verification — status: planned
- [ ] `V140-MAP` Mars-like/Venus-like worlds and non-landable gas giant — status: planned
  - [ ] `V140-MAP-01` Cross-restart body/Level binding and initialization contract — status: planned
  - [ ] `V140-MAP-02` World data, bounded landing and station integration — status: planned
- [ ] `V140-ENV` Environmental response and equipment protection — status: planned
- [ ] `V140-NAV` Star map, server-filtered reachability and synchronization — status: planned
- [ ] `V140-SKY` Sky/fog/sun/sound and audited asset batches — status: planned
- [ ] `V140-DISC` Discovery/research policy and presentation — status: planned
- [ ] `V140-MIG` Existing-world and removed-content recovery — status: planned
- [ ] `V140-ACC` Required G0-G9 evidence and human acceptance — status: planned

## Active preparation

### V140-GOV-01

- Observable outcome: a maintainer can distinguish the authorized v1.4
  development baseline from inherited acceptance and from later-version scope.
- Scope: a new version-limited decision; no extension of ADR-020's v1.3 scope.
- Dependencies: actual v1.3 commit/evidence, ADR-018 scheduling and maintainer
  authorization to use recommended implementation solutions.
- Acceptance: immutable baseline, owner/basis, expiry and recovery condition;
  no candidate, Gate PASS, publication or v1.5 production permission.
- Verification: independent authority/diff review, planning and local links.
- Status: in-progress; [ADR-030](../decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md).

### V140-CON-01

- Observable outcome: implementers can add a logical non-landable body without
  manufacturing a Level, and can identify exactly how old definitions and
  world identities remain usable.
- Scope: fixed startup data dimensions, definition schema/capabilities, bounded
  reload and display compatibility; later environmental effects/visual assets
  still need their own concrete task contracts.
- Dependencies: actual celestial, travel, station, network and API code; stable
  v1.1 target/context and v1.3 API contracts; current platform documentation.
- Acceptance: finite fields/defaults, mapping and source/destination distinction,
  joint-catalog visibility, missing-content policy, protocol/save separation,
  testable limits and explicit non-goals. No new import before provenance.
- Verification: source/caller inventory, independently reviewed ADR and finite
  data examples; distinguish example checking from runtime implementation.
- Status: in-progress; [ADR-031](../decisions/ADR-031-PLANETARY-DEFINITIONS-AND-FIXED-LEVELS.md).

## First implementation slice

`V140-DATA-01` will add the definition decoder/model and adapt every current
consumer of mandatory Level mappings, including snapshots and authoritative
destination checks. Its outcome is a usable non-landable definition in the
existing runtime, not a standalone unused model. Existing IDs, environment
values, physical Levels, station UUID/orbit-body records and flight journals
must not be rewritten merely because a data definition gets a version.

Acceptance includes legacy/default round trips, invalid capability/value input,
unmapped-body behavior, destination refusal without fuel mutation, departing a
still-mapped body closed to new arrivals, and matching display protocol checks.
Run short unit/GameTest/build/DataGen checks and a bounded packaged restart.
Its actual write scope and leaf evidence will be recorded before coding after
the preparation decisions are accepted. Joint resource reload is DATA-02;
DATA-01 alone must not advertise cross-catalog atomicity.
New-world travel also depends on MAP-01/02: the existing landing selector and
player station-creation flow still restrict physical destinations to Earth/Moon.
Schema support is not evidence that Mars is already reachable or that arbitrary
custom body remapping is safe across restarts.

## Verification and remaining work

Preparation is in progress. No v1.4 runtime result, candidate or Gate approval
has been assigned. Full mechanical/dimensional completion remains outstanding;
ADR-018's full-campaign trigger has not been met.
