import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from scripts.validate_repository import markdown_link_errors

checks = []
for relative, label in [
    ('docs/work/v1.4.0-preparation/check_examples.py', 'examples'),
    ('scripts/validate_v1plus_planning.py', 'planning'),
]:
    command = [sys.executable, '-B', relative]
    started = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    (OUT / (label + '.log')).write_bytes(result.stdout)
    checks.append({'command': command, 'cwd': str(ROOT), 'exit_code': result.returncode,
                   'seconds': round(time.monotonic() - started, 3),
                   'log_sha256': hashlib.sha256(result.stdout).hexdigest()})
    print(label, result.returncode, result.stdout.decode('utf-8', errors='replace'))

tracked = subprocess.check_output(['git', 'ls-files', '*.md'], cwd=ROOT, text=True).splitlines()
new_docs = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'docs'],
                                   cwd=ROOT, text=True).splitlines()
paths = sorted({name for name in tracked + new_docs if name.endswith('.md')
                and not name.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')})
errors, count = markdown_link_errors(ROOT, [ROOT / name for name in paths])
links = {'files': len(paths), 'local_targets': count, 'errors': errors,
         'scope': 'Tracked Markdown plus new docs Markdown; path existence, not anchors or external URLs.'}
(OUT / 'links.json').write_text(json.dumps(links, indent=2) + '\n', encoding='utf-8')
print('links', json.dumps(links))

initial = json.loads((OUT / 'initial-identities.json').read_text(encoding='utf-8'))
source_changes = [name for name, expected in initial['hashes'].items()
                  if name.startswith('src/') and hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected]
selected = ['docs/decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md',
            'docs/decisions/ADR-031-PLANETARY-DEFINITIONS-AND-FIXED-LEVELS.md',
            'docs/work/v1.4.0-implementation-log.md',
            'docs/work/v1.4.0-preparation/examples.json',
            'docs/work/v1.4.0-preparation/check_examples.py']
identities = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in selected}
result = {'checks': checks, 'links': links, 'source_changes_since_initial_inventory': source_changes,
          'document_identities': identities,
          'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}
(OUT / 'final-checks.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
if any(check['exit_code'] for check in checks) or errors or source_changes:
    raise SystemExit(1)
