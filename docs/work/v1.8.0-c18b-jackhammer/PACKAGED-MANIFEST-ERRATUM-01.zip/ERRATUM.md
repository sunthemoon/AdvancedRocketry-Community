# Manifest notification hash and size correction

This corrects the reviewer's final tool output and notification, not any sealed
original file or covered-file hash. The original REPORT, manifest, seal result,
scripts, receipts, archives and native evidence remain unchanged.

## Independently observed actual bytes

`../SHA256SUMS.txt` has 103 CRLF rows, no bare LF/CR, and **11,314 bytes**.
Its actual SHA-256 is:

```text
ee3313881c9c3851806ffd53a462dd62a346845e3612b882280cb82b7c793248
```

The earlier notification's hash
`9eb4c5db35bcf12b29d6f2067cbd9db4444a26bdd21ebeffa873b8b2fa95c7b4`
and 11,211-byte length describe only the LF-normalized in-memory representation,
not the actual manifest file. They must not be used as that file's identity.

## Actual cause

The sealed original `../seal_evidence.py:54` writes the logical LF string with
`Path.write_text(manifest, encoding='utf-8')`. Its default text newline handling
on this Windows runtime translates each LF to CRLF. Lines 60-61 then calculate
the notification hash/length from `manifest.encode()`, rather than reading the
written bytes. The resulting difference is exactly the 103 additional CR bytes.

The original writer source itself verifies against its sealed entry, SHA-256
`9d1163c6416f76275a941caaf002a99aed33fa9d2cfb4604b9c43135193772c2`.
This is a notification calculation error, not evidence of an original-file
replacement. A future separate writer revision should hash/read the persisted
bytes or write an explicit byte representation; this erratum does not alter the
sealed original writer or manifest.

## Actual verification and unchanged boundaries

`python -B verify_manifest.py` executed at
`2026-10-09T03:24:45.034717Z` to `2026-10-09T03:24:45.053989Z`, exit 0.
`RESULT.json` records the actual argv, UTC, bytes, hashes, relevant source lines
and all 103 independently reverified covered entries (1,151,288 bytes).

Actual REPORT SHA-256 remains:

```text
450cd21226a803262d7a48f4f478f27d095e5feb41947c59634d44a55fd6e8ba
```

The original source/pure/native review verdicts, Gate limitations and denied
cleanup retention do not change. No native/build run, cleanup retry, source,
Root, peer or original sealed-file write occurred. Only this new supplemental
directory in the reviewer's exclusive leaf was written. Its separate relative
manifest hashes persisted bytes; it does not replace the original manifest.
