import datetime
import hashlib
import json
import pathlib
import sys

here = pathlib.Path(__file__).resolve().parent
leaf = here.parent
started = datetime.datetime.now(datetime.UTC).isoformat()
raw = (leaf / 'SHA256SUMS.txt').read_bytes()
normalized = raw.replace(b'\r\n', b'\n')
entries = []
seen = set()
for line in raw.decode('utf-8').splitlines():
    expected, relative = line.split('  ', 1)
    name = pathlib.PurePosixPath(relative)
    assert not name.is_absolute() and '..' not in name.parts
    assert relative.casefold() not in seen
    seen.add(relative.casefold())
    path = leaf.joinpath(*name.parts)
    assert path.is_file() and not path.is_symlink() and not path.is_junction()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected, relative
    entries.append({'relative': relative, 'bytes': path.stat().st_size, 'sha256': actual})

report = (leaf / 'REPORT.md').read_bytes()
seal_source = (leaf / 'seal_evidence.py').read_bytes()
result = {
    'argv': [sys.executable, '-B', str(pathlib.Path(__file__).resolve())],
    'started_utc': started,
    'ended_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'exit': 0,
    'actual_manifest_sha256': hashlib.sha256(raw).hexdigest(),
    'actual_manifest_bytes': len(raw),
    'crlf_pairs': raw.count(b'\r\n'),
    'bare_lf': raw.count(b'\n') - raw.count(b'\r\n'),
    'bare_cr': raw.count(b'\r') - raw.count(b'\r\n'),
    'lf_normalized_sha256': hashlib.sha256(normalized).hexdigest(),
    'lf_normalized_bytes': len(normalized),
    'covered_files_verified': len(entries),
    'covered_bytes_verified': sum(row['bytes'] for row in entries),
    'report_sha256': hashlib.sha256(report).hexdigest(),
    'sealed_writer_source_sha256': hashlib.sha256(seal_source).hexdigest(),
    'writer_relevant_lines': [
        {'line': i, 'text': line}
        for i, line in enumerate(seal_source.decode('utf-8').splitlines(), 1)
        if 'write_text(manifest' in line or 'manifest.encode()' in line
    ],
    'verified_entries': entries,
    'originals_modified': False,
}
(here / 'RESULT.json').write_bytes((json.dumps(result, indent=2)+'\n').encode('utf-8'))
print(json.dumps({k: v for k, v in result.items() if k != 'verified_entries'}, indent=2))
