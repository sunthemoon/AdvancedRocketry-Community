# Fresh independent host-template/history corrective qualification

You are a delegated worker reviewer, not an implementer. Do not delegate further
or use Claude. Root coordinates OpenPet.

Source repository: D:/GitHub/arce-v180-jackhammer-20261009.
Fixed candidate: 3b18a6bc8b58424d647053d6c6f1833ba14d9dc7.
Full adoption base: 106d31653f8bce66761c919742629a75a047e2ca.
Read the candidate's SOURCE-REVIEW-TASK-01.md and all its required governance,
adoption, source, correction/preparation and provenance/history records. Follow
its command/evidence/cleanup rules except for this candidate and exclusive leaf.

Your only write_scope is a NEW exclusive evidence/private-copy leaf:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04.
Snapshot fixed Git inputs promptly, then release Main/Root/source/mutable HEAD
interests. All existing trees and evidence leaves remain read-only. No source
edits, installs, global settings, policy changes, owner decisions or cleanup
takeover. Owned clone/build/Temp/disposable outputs belong under unsealed _tmp.

Review the complete actual adoption diff, adjacent source and correction history,
including new native tests and independent adapter fixture. Assess provenance
and exact upstream-touch history under accepted origin policy using actual
primary bytes/records, not a presumed finding or readiness conclusion. Root's
recipe-history-01 receipts and bare pinned upstream objects may be read only;
do not alter or clean its clone. Copy only compact evidence needed for your
manifest, not the full source/JAR/world or mutable Temp references.

Run the actual forced full clean build, explicit test, two forced runData/separate
empty diffs and unfiltered native suite. Retain all command outcomes with actual
UTC/exits/argv, fresh XML counts, native logs and identities. Run accepted ledger,
bootstrap, strict repository with the unchanged 180-second wrapper deadline,
whitespace, artifact/resource/provenance and applicable primary checks. A timeout
is not a passed/failed link report; preserve it independently of earlier failures.

Root separately qualifies the reobfuscated consumer and its committed harness
revision-02 at Main commit 6d75429ab5f4941092216474c7d3d966417d3701. Its eventual
native continuation evidence will be provided. Inspect available Root artifacts
and receipts at report time without substituting them for your executions or
claiming your own packaged launch. Source qualification, native inventory/use,
survival, asset approval, client/GPU/multiplayer and G0-G9 remain distinct.

Deliver findings-first REPORT.md, exact fixed input/command/evidence boundaries,
failures/unexecuted checks, hashes, one-attempt owned native cleanup result,
retained/unsealed byte counts and released interests. Seal compact relative
evidence with SHA256SUMS.txt; no denied-target retry or alternate shell/policy
bypass. No result, finding count, approval or Gate verdict is prescribed.
