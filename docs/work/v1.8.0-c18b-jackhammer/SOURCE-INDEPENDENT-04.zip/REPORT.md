# Fixed jackhammer host-template/history source review

## Findings first

No new change-required production/source finding was identified in the complete
35-file adoption diff at `3b18a6bc8b58424d647053d6c6f1833ba14d9dc7`.
This is a bounded technical review, not an approval of all qualification checks
or any release Gate.

Qualification and evidence limitations remain explicit:

1. **Unqualified strict repository check:** the actual unchanged 180-second
   attempt timed out, with empty stdout/stderr. Its
   [receipt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/strict-repository/RESULT.json) is independent of earlier
   candidates' inherited-link failures. It supplies neither a link PASS nor a
   link FAIL and was not retried at a longer deadline.
2. **Preparation evidence gap:** the first dependency-cache copy's wrapper
   session/output was inadvertently not retained. Its observed partial copy and
   the separately captured, previously unattempted wrapper/native copy are
   documented in [SETUP-NOTES](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/SETUP-NOTES.md) and
   [cache completion](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/inputs/cache-copy.json). No precise lost exception or
   success is invented. All assigned qualification commands have full receipts.
3. **Owned retention exception:** sealing-script syntax preflight created a
   7,332-byte `.pyc` outside `_tmp` after the main cleanup. One native deletion
   invocation was rejected by tool policy before launch; no retry or bypass
   occurred. That file remains unsealed. The exact denied command and remaining
   file hash are retained in the denial/remainder receipts. The preflight/denial
   command UTC was not captured; its creation/observation UTC is available.

The original missing upstream-touch record is now supplied by actual primary
history, not by relabeling the recipe NEW or approving its origin. The native
template fix binds the existing authority test to the host namespace without
changing assertions, batch or its 100-tick budget. Historical failed candidates
remain distinct; their existing evidence was not edited or discarded.

## Fixed inputs and ownership

- Adoption base: `106d31653f8bce66761c919742629a75a047e2ca`.
- Audited/tested candidate: `3b18a6bc8b58424d647053d6c6f1833ba14d9dc7`.
- Exclusive write scope: this evidence leaf only. Detached private clone,
  Gradle home, builds, native world and TEMP/TMP/Java temporary files were owned
  under unsealed `_tmp`. Existing trees/evidence remained read-only.
- Snapshot/release UTC: `2026-10-09T02:54:17.1706634Z`. Main, Root, source and
  mutable HEAD interests were released then. No source edits, staged files,
  commits, pushes, installations, global settings, policy decisions, new
  delegation or Claude calls occurred.
- Required governance, adoption, task, preauthoring/final provenance and all
  source checkpoints/correction preparations were read; retained input list:
  [governance reading list](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/inputs/governance-reading-list.txt).
- Exact raw adoption diff SHA-256:
  `88da1b66721365fe2f4a7550aa5b9459617ae10e9b9db43388106d3e9e6d6aab`.
  [Raw diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/adoption-diff/stdout.log),
  [last correction diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/last-correction-diff/stdout.log),
  [source/build input hashes](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/inputs/source-hashes.json).

## Design and source assessment

The registered additive `advancedrocketrycommunity:jackhammer` is an ordinary
`PickaxeItem` using the actual diamond tier, constructor attack bonus 1/speed
-2.8, maximum damage 1,024 and single stacking. Only pickaxe-tag blocks gain
speed 50. It does not override tier-qualified loot, scan/AOE removal, native
progress, protection events or world-state persistence. Live titanium-rod tag
repair replaces the default diamond repair. The COMMON equipment switch retains
registration, recipes, inventories and safe native anvil repair.

Actual primary bytecode confirms BreakEvent precedes `onBlockStartBreak`, which
precedes creative removal and survival wear/loot. The new disabled final hook
cannot be defeated merely by uncanceling that earlier event. Native attack
checks the item refusal hook before damage. Native wear may precede a later
removal refusal; no stronger transaction atomicity is claimed. The class adds
no project-owned NBT root, packet, world scan, player collection or client-only
dependency. References are to native common types, not client rendering classes.

The fixture and 13 host cases cover actual single-target actions, delayed
obsidian progress and diamond-qualified drops, finite breakage, creative wear,
negative hardness/reach refusal, Forge cancellation, installed unavailable
station BUILD protection, disable/re-enable, native melee, actual crafting takes
for four motor variants, and actual material/same-item/book anvil takes. Nine
new JUnit cases cover exact switch registration/default/type/override and
deterministic recipe/unlock/model/tag/language/art bytes. The corrected exact
config inventory guard remains 74; its obsolete-registration assertion remains.

The independent adapter fixture is packaged separately, looks up the item by
registry ID, defaults off behind an opt-in JVM flag, and requires actual native
console identity, permission four, no source entity and the server thread.
Its fixed UUID is native-loaded before continuation assertions, with no manual
playerdata writer/reseed. Its authority test now resolves the existing host
empty template. Actual mapped Forge template resolution honors the explicit
method namespace before the holder namespace.

These are native action/progress/endpoint checks, not full network-packet
admission or real elapsed server-tick tests. Actors are connected embedded
`ServerPlayer`s, not real clients. Station evidence is unavailable-registry
denial, not the whole owner/member matrix. Above-diamond/mod interaction and
COMMON client/server synchronization remain unqualified.

## Actual commands and outcomes

Java/Javap `17.0.7`, Gradle wrapper `8.8`, Minecraft `1.20.1`, Forge `47.4.10`.
The mapped native JAR was freshly hashed before inspection:
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
[Native identity](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/inputs/native-identity.json), actual Java/Javap/Git version
receipts and 11 native javap inspections are retained under `results/`.
C and D each exceeded 10 GiB before every sustained command. All owned
qualification receipts contain exact argv, cwd, fixed HEAD, UTC, deadlines,
process IDs, environment and stdout/stderr hashes; no cached-result substitute
was used. Full inventory: [COMMAND-SUMMARY](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/COMMAND-SUMMARY.json).

Every Gradle invocation used
`gradlew.bat --no-daemon --no-build-cache --rerun-tasks` plus the listed task:

| Actual check | UTC start → end | Outcome |
|---|---|---|
| `clean build` | 02:58:00.047864 → 03:01:30.289289 | Exit 0; 20 executed tasks; 2,192 tests / 381 fresh XML; 0 failures/errors/skips |
| explicit `test` | 03:01:30.775321 → 03:04:30.179352 | Exit 0; 17 executed tasks; separate 2,192 tests / 381 fresh XML; 0 failures/errors/skips |
| first `runData` | 03:04:40.129547 → 03:05:29.441826 | Exit 0; 10 executed tasks; fresh DataGen cache wrote 846 files |
| first separate `git diff --exit-code` | 03:05:29.488470 → 03:05:29.862082 | Exit 0; empty diff and separate empty status |
| second `runData` | 03:05:30.104751 → 03:06:15.870239 | Exit 0; 10 executed tasks; 846 existing files, 0 written |
| second separate `git diff --exit-code` | 03:06:15.919770 → 03:06:16.012235 | Exit 0; empty diff and separate empty status |
| unfiltered `runGameTestServer` | 03:06:16.203295 → 03:10:34.145572 | Exit 0; 18 executed tasks; all 579 required tests passed |
| accepted content ledger | 02:59:04.950317 → 02:59:05.274695 | Exit 0; 653 units / 898 assets; 186 units still PLANNED |
| approved bootstrap provenance | 02:59:05.338134 → 02:59:37.321600 | Exit 0; actual accepted bootstrap digest-bound review |
| strict repository / approved identity | 02:59:37.376022 → 03:02:37.400707 | TIMEOUT at unchanged 180 seconds; no report |
| adoption `git diff --check` | 03:02:37.447103 → 03:02:37.512831 | Exit 0 |
| final post-native diff/status | 03:11:39.289362 → 03:11:39.514057 | Both exit 0; empty; all 43 source/build hashes and all 3 artifact hashes unchanged |

Both XML cohorts, raw build/test/data/native logs and every timeout remain
retained. Native logs explicitly show `jackhammer_console` (1) and
`jackhammer_native` (13), and final completion at stdout line 5,939. They also
retain 62 ERROR and 161 WARN lines, including inherited intentional save-failure,
invalid recipe/tag, wrong protocol version, blocked satellite data and bounded
adapter-fault diagnostics. Their actual contexts were inspected against the
fixture source; no FATAL appeared. This is not an error-free packaged-server
claim. [Native summary](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/native/NATIVE-SUMMARY.json),
[error contexts](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/native/ERROR-CONTEXTS.txt), full latest/debug/raw logs.

## Provenance, generated bytes and artifacts

All seven target hashes and NEW authoring-source hashes match; bilingual files
add exactly four keys each without altering prior values. The shaped layout,
ingredient counts, one-tool output, motor unlock and additive pickaxe tag match
the adopted conversion. Across all 898 legacy assets, only the exact jackhammer
recipe's effective rule changes to IMPORTED; other effective rules, ledger,
allowlist and origin findings remain unchanged.

Actual read-only non-shallow pinned upstream objects confirm the 666-byte
recipe hash `a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45`
and one added-file touching commit
`12d238cb2a883533be5b3dabb8c5b7fb3297a99e` through pin
`c5cd5af62fc07cd4e0d24f06a16033f181c47c04`. Independent follow/name-status
output hashes match the committed record and Root receipts. No issue/PR-origin
material is identified in that exact inspected history; this does not certify
earlier gameplay-idea provenance or human authorship approval. Upstream MIT
license bytes and notices were inspected. The final pending digest recomputes to
`405f659a116d4292bc7cb8706e075b8243055d8cb7e9badeab19dbf3b4110b34`.

The 169-byte original 16×16 RGBA icon has 82 opaque pixels and was directly
viewed. The unchanged derivation implementation reports CLEAR against both
actually hash-pinned vanilla clients. Resource-parent references are lawful
references, not copied official models. This is mechanical/static art evidence,
not real-client visual or human license approval.

Actual normal JAR: 6,073,913 bytes, 3,586 unique entries, SHA-256
`0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011`.
It includes exact target bytes, LICENSE/NOTICE and host GameTests, but no
independent adapter fixture. API JAR SHA-256:
`aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
[Resource/provenance results](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/resources/PROVENANCE-RESOURCE-CHECK.json),
[art screen](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/resources/ART-SCREEN.json),
[artifact inventory](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/resources/ARTIFACTS.json).

## Separately attributed Root packaged observations

Available ended Root evidence was independently read/reparsed, not substituted
for this reviewer's required commands. The revision-02 committed driver archive
at Main `6d75429ab5f4941092216474c7d3d966417d3701` matches the actual frozen driver
bytes. Installed Root host hash matches this reviewer's independently built
normal JAR; reobfuscated consumer hash is
`92f31fbf73604e480be41fe028c4cda2d5c6e6e002a003ba5d3b127eb0295f76`.
Both Root processes exit 0 with trusted native use/stop/save order. Actual
stopped playerdata parses to the same UUID, survival mode, selected slot,
single tool, name, note and Efficiency II, with Damage 18 after seed and 19 after
continuation. [Independent Root observation](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/ROOT-OBSERVATION.json)
and compact copied raw receipts/logs/playerdata are retained.

This reviewer did not launch a packaged server, independently rebuild the
consumer, perform crash cuts, use real clients or acquire recipe inputs in
survival. Root's ended runtime and other agents' cleanup were never taken over.

## Completion, remaining scope and Gate status

Completed: complete fixed actual-source/adoption/history/provenance review,
forced owned build/test/DataGen/native execution, applicable static/primary
checks, artifact hashing and bounded reinspection of Root receipts. Modified
files are this leaf's evidence/scripts only; no production/test source changed.

Remaining: strict repository qualification; human provenance/asset approval;
initial titanium/steel and motor progression/recipe-graph survival closure;
above-tier and supported-mod interactions; real GPU/client V1/V2, multiplayer,
crash recovery, long-load/reference performance and final release acceptance.
The new art does not deliver the legacy IMPORT bitmap. Short inventory/use and
clean restart evidence does not imply survival reachability or crash atomicity.

Not all v1.8 Required Gates are satisfied. G0–G9 are not approved here, the
accepted ADR-060 development exception does not advance the earliest v1.0
acceptance cursor, and no status/ledger row is changed. Subsequent work should
stay within this v1.8 slice's remaining qualification/acceptance obligations or
other still-planned v1.8 content, not a v1.9 implementation.

## Owned cleanup and sealing

The one native PowerShell `Remove-Item -LiteralPath .../_tmp -Recurse -Force`
attempt ran from `2026-10-09T03:12:34.2669698Z` to
`2026-10-09T03:12:51.7464804Z`, after containment, ancestor/descendant reparse
and owned-process checks. It removed 34,473 owned temporary files totaling
5,010,274,073 bytes. No reparse descendants or live owned processes were found;
no denied-removal retry or bypass occurred. The clone, caches, build artifacts,
native world and temporary process files are gone; no full source/JAR/world is
retained. [Cleanup receipt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/OWNED-CLEANUP.json).

After this successful `_tmp` cleanup, the sealing-script syntax preflight
created `scripts/__pycache__/seal.cpython-313.pyc`. Its single deletion invocation
was denied before process launch. It is not retried, moved, executed or included
in the compact checksum manifest. The separate 7,332-byte unsealed remainder
has SHA-256 `f57dc5de0c130d26a309a6c2c1bfa629239a5cf7b05ca7833c16048a282ff735`.
[Denial receipt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/PREFLIGHT-DENIAL.json),
[unsealed remainder](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-04/results/UNSEALED-REMAINDER.json).

All Main, Root, source, mutable HEAD, runtime, artifact and upstream-object
interests are released. The compact copied Root observations are sufficient
for this report; Root-owned cleanup was not attempted here.

<!-- SEAL-METRICS-START -->
Sealed UTC: `2026-10-09T03:22:51.286600Z`. Retained evidence including the manifest: 11,089,117 bytes; checksummed payload: 10,917,526 bytes across 1,026 files; largest retained file: 2,012,949 bytes. Unsealed remainder: 7,332 bytes; complete leaf including that remainder: 11,096,449 bytes. Every file is below 50 MiB, and the complete leaf is below 100 MiB. The relative `SHA256SUMS.txt` covers compact evidence only, not the explicitly unsealed preflight bytecode, build/Temp or any external mutable file.
<!-- SEAL-METRICS-END -->
