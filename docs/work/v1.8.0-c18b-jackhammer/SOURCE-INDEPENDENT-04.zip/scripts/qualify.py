"""Private fixed-input qualification; capture raw outcomes without changing tests."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

LEAF = Path(__file__).resolve().parents[1]
REPO = LEAF / "_tmp/candidate"
SHA = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
TMP = LEAF / "_tmp/process-temp"
GRADLE_HOME = LEAF / "_tmp/gradle-home"
JAVA_HOME = Path("C:/Program Files/Java/jdk-17.0.7")
TMP.mkdir(exist_ok=True)
ENV = dict(os.environ, JAVA_HOME=str(JAVA_HOME), GRADLE_USER_HOME=str(GRADLE_HOME),
           TEMP=str(TMP), TMP=str(TMP), PYTHONDONTWRITEBYTECODE="1",
           JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=" + TMP.as_posix() + " -Dfile.encoding=UTF-8")
ENV["PATH"] = str(JAVA_HOME / "bin") + ";" + ENV["PATH"]

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(name, argv, timeout=2400, cwd=REPO):
    out = LEAF / "results" / name
    out.mkdir(exist_ok=False)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    assert head == SHA, head
    for drive in ["C:/", "D:/"]:
        assert shutil.disk_usage(drive).free >= 10 * 1024 ** 3
    rec = dict(name=name, argv=[str(x) for x in argv], cwd=str(cwd), head=head,
               started_utc=utc(), timeout_seconds=timeout,
               free_bytes={x: shutil.disk_usage(x).free for x in ["C:/", "D:/"]},
               environment={k:ENV[k] for k in ["JAVA_HOME","GRADLE_USER_HOME","TEMP","TMP","JAVA_TOOL_OPTIONS","PYTHONDONTWRITEBYTECODE"]})
    (out / "COMMAND.json").write_text(json.dumps(rec, indent=2) + "\n", encoding="utf-8")
    with (out / "stdout.log").open("wb") as stdout, (out / "stderr.log").open("wb") as stderr:
        proc = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr)
        rec["pid"] = proc.pid
        try:
            rec["exit"] = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            rec["exit"] = "TIMEOUT"
            proc.kill()
            proc.wait(timeout=30)
            rec["timeout_process_disposition"] = "Owned wrapper process killed; descendant ownership checked before cleanup."
    rec["ended_utc"] = utc()
    rec["stdout_sha256"] = digest(out / "stdout.log")
    rec["stderr_sha256"] = digest(out / "stderr.log")
    (out / "RESULT.json").write_text(json.dumps(rec, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(rec), flush=True)
    return rec

def cohort(name):
    src = REPO / "build/test-results/test"
    dst = LEAF / "results" / name / "xml"
    dst.mkdir()
    rows = []
    for path in sorted(src.glob("TEST-*.xml")):
        shutil.copy2(path, dst / path.name)
        node = ET.parse(path).getroot()
        rows.append(dict(file=path.name, sha256=digest(path), bytes=path.stat().st_size,
                         tests=int(node.attrib["tests"]), failures=int(node.attrib["failures"]),
                         errors=int(node.attrib["errors"]), skipped=int(node.attrib["skipped"]),
                         suite=node.attrib.get("name"), timestamp=node.attrib.get("timestamp")))
    summary = dict(files=len(rows), totals={k:sum(r[k] for r in rows) for k in ["tests","failures","errors","skipped"]}, suites=rows)
    (dst.parent / "JUNIT.json").write_text(json.dumps(summary, indent=2)+"\n",encoding="utf-8")
    print(json.dumps({name:summary["totals"],"files":len(rows)}),flush=True)

def cache():
    start = utc()
    src = Path("C:/Users/Administrator/.gradle")
    GRADLE_HOME.mkdir(exist_ok=False)
    copied = []
    for dirname in ["caches", "wrapper", "native"]:
        shutil.copytree(src / dirname, GRADLE_HOME / dirname)
        copied.append(dirname)
    rec = dict(started_utc=start, ended_utc=utc(), source=str(src), target=str(GRADLE_HOME),
               copied=copied, note="Existing dependency caches copied read-only into owned scope. No install or global settings change.")
    (LEAF / "inputs/cache-copy.json").write_text(json.dumps(rec,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(rec),flush=True)

def complete_cache():
    start = utc()
    src = Path("C:/Users/Administrator/.gradle")
    assert (GRADLE_HOME / "caches").is_dir()
    for dirname in ["wrapper", "native"]:
        shutil.copytree(src / dirname, GRADLE_HOME / dirname)
    rec = dict(started_utc=start, ended_utc=utc(), source=str(src), target=str(GRADLE_HOME),
               copied=["wrapper","native"],
               preceding_attempt="Initial copy completed most cache bytes but stopped before wrapper/native/completion receipt. Its process ended; original wrapper session metadata/output was inadvertently not forwarded. No denied cache target was retried.",
               note="Continue with previously copied caches. Copy previously unattempted wrapper/native directories; all build and runtime writes remain owned.")
    (LEAF / "inputs/cache-copy.json").write_text(json.dumps(rec,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(rec),flush=True)

def gradle(name, *args):
    return run(name, [str(REPO / "gradlew.bat"), "--no-daemon", "--no-build-cache", "--rerun-tasks", *args])

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "cache":
        cache()
    elif mode == "complete-cache":
        complete_cache()
    elif mode == "build":
        gradle("clean-build", "clean", "build")
        cohort("clean-build")
        gradle("explicit-test", "test")
        cohort("explicit-test")
    elif mode == "data-native":
        for name in ["data-a", "data-b"]:
            gradle(name,"runData")
            run(name + "-diff", ["git","diff","--exit-code"],60)
            run(name + "-status", ["git","status","--short"],60)
        gradle("native","runGameTestServer")
        for path in [REPO / "build/gametest/logs/latest.log", REPO / "build/gametest/logs/debug.log"]:
            if path.exists():
                shutil.copy2(path, LEAF / "results/native" / path.name)
        crash = REPO / "build/gametest/crash-reports"
        if crash.exists():
            shutil.copytree(crash, LEAF / "results/native/crash-reports")
    elif mode == "static":
        run("ledger",[sys.executable,"scripts/validate_v180_content_ledger.py","--require-accepted"],180)
        run("bootstrap",[sys.executable,"scripts/validate_bootstrap_provenance.py","--require-approved-review"],180)
        run("strict-repository",[sys.executable,"-u","scripts/validate_repository.py","--require-approved-identity"],180)
        run("whitespace",["git","diff","--check","106d31653f8bce66761c919742629a75a047e2ca",SHA],60)
        run("final-status",["git","status","--short"],60)
    else:
        raise SystemExit(mode)
