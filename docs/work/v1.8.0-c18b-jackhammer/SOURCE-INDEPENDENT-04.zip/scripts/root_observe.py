"""Inspect separately attributed ended Root observations, never launch a packaged server."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import types
import zipfile
from qualify import LEAF, REPO, SHA, digest, utc

ROOT=Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01")
out=LEAF / "inputs/root-packaged-02"
out.mkdir(exist_ok=False)
start=utc()
archive=subprocess.check_output(["git","show","6d75429ab5f4941092216474c7d3d966417d3701:docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-02.zip"],cwd=REPO)
assert hashlib.sha256(archive).hexdigest()=="e93a7da4a4848f6b87761c3f006b673e8157ee1642c53e51c8cceb32ea9a9ca4"
(out / "PACKAGED-DRIVER-02.zip").write_bytes(archive)
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    name=next(n for n in z.namelist() if n.endswith("packaged_driver.py"))
    driver=z.read(name)
assert hashlib.sha256(driver).hexdigest()=="63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e"
assert driver==(ROOT / "driver-frozen-02/packaged_driver.py").read_bytes()
module=types.ModuleType("fixed_driver_observation")
module.__file__=str(out / "packaged_driver.py")
exec(compile(driver,module.__file__,"exec"),module.__dict__)
nbt_source=subprocess.check_output(["git","show",SHA+":scripts/inspect_celestial_saved_data.py"],cwd=REPO)
nbt=types.ModuleType("fixed_nbt_observation")
nbt.__file__=str(REPO / "scripts/inspect_celestial_saved_data.py")
exec(compile(nbt_source,nbt.__file__,"exec"),nbt.__dict__)
inputs=json.loads((ROOT / "packaged-02/inputs.json").read_text("utf-8"))
assert inputs["source_sha"]==SHA
own=json.loads((LEAF / "results/resources/ARTIFACTS.json").read_text("utf-8"))
host=next(r for r in own["jars"] if r["file"].endswith("-dev.jar"))
assert inputs["artifacts"][0]["sha256"]==host["sha256"]
for artifact in inputs["artifacts"]:
    installed=ROOT / "packaged-02/_tmp/server/mods" / artifact["name"]
    assert digest(installed)==artifact["sha256"]
launch=json.loads((ROOT / "packaged-launch-02/RESULT.json").read_text("utf-8"))
assert launch["exit"]==0 and launch["source_sha"]==SHA and launch["harness_commit"]=="6d75429ab5f4941092216474c7d3d966417d3701"
fixture=json.loads((ROOT / "packaged-launch-02/fixture-artifact.json").read_text("utf-8"))
assert fixture["sha256"]==inputs["artifacts"][1]["sha256"] and fixture["reobfuscated"]
phases=[]
for phase,damage in [("seed",18),("continue",19)]:
    source=ROOT / "packaged-02" / phase
    dest=out / phase
    dest.mkdir()
    receipt=json.loads((source / "receipt.json").read_text("utf-8"))
    assert receipt["exit"]==0 and receipt["phase"]==phase
    text=(source / "stdout.txt").read_text("utf-8")
    lines=text.splitlines(keepends=True)
    observations=module.observations(lines,phase)
    stop=module.clean_stop(lines)
    raw,player=module.read_player(source / "playerdata.dat",nbt,damage)
    assert observations==receipt["observation"] and stop==receipt["clean_stop"]
    assert hashlib.sha256(raw).hexdigest()==receipt["playerdata_sha256"]
    assert player==json.loads((source / "playerdata-observation.json").read_text("utf-8"))
    for name in ["receipt.json","launch.json","commands.json","stdout.txt","latest.log","debug.log","playerdata.dat","playerdata-observation.json","status.json"]:
        shutil.copy2(source / name,dest / name)
    phases.append(dict(phase=phase,receipt_exit=receipt["exit"],observation=observations,clean_stop=stop,
                       actual_saved_player=player,playerdata_sha256=hashlib.sha256(raw).hexdigest(),
                       raw_stdout_sha256=digest(source / "stdout.txt")))
for rel in ["packaged-02/RESULT.json","packaged-02/inputs.json","packaged-launch-02/RESULT.json",
            "packaged-launch-02/fixture-artifact.json","packaged-launch-02/negative-import.json"]:
    shutil.copy2(ROOT / rel,out / rel.replace("/","--"))
rec=dict(started_utc=start,ended_utc=utc(),inspected_source=SHA,harness_commit=launch["harness_commit"],
         artifacts=inputs["artifacts"],own_built_host_matches_root=True,phases=phases,
         limits="Read-only reinspection of Root executions. Reviewer did not launch packaged runtime, qualify crash cuts, survival, client/GPU or multiplayer, or approve Gates.")
(LEAF / "results/ROOT-OBSERVATION.json").write_text(json.dumps(rec,indent=2)+"\n",encoding="utf-8")
print(json.dumps(rec,indent=2),flush=True)
