"""Read primary pinned native and upstream objects, retaining compact command receipts."""
import json
import shutil
from qualify import LEAF, REPO, SHA, ENV, JAVA_HOME, GRADLE_HOME, digest, run

ENV["GIT_OPTIONAL_LOCKS"] = "0"
ENV["GIT_NO_LAZY_FETCH"] = "1"
jar = GRADLE_HOME / "caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar"
assert digest(jar) == "95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e"
native = dict(jar=str(jar),bytes=jar.stat().st_size,sha256=digest(jar),head=SHA)
(LEAF / "inputs/native-identity.json").write_text(json.dumps(native,indent=2)+"\n",encoding="utf-8")
run("java-version",[JAVA_HOME / "bin/java.exe","-version"],60)
run("javap-version",[JAVA_HOME / "bin/javap.exe","-version"],60)
run("git-version",["git","--version"],60)
for cls in ["net.minecraft.world.item.PickaxeItem","net.minecraft.world.item.DiggerItem",
            "net.minecraft.world.item.TieredItem","net.minecraft.world.item.Item$Properties",
            "net.minecraft.server.level.ServerPlayerGameMode","net.minecraft.world.entity.player.Player",
            "net.minecraftforge.common.ForgeHooks","net.minecraftforge.common.extensions.IForgeItem",
            "net.minecraftforge.gametest.ForgeGameTestHooks","net.minecraft.commands.CommandSourceStack",
            "net.minecraftforge.common.ForgeConfigSpec$Builder"]:
    run("javap-" + cls.rsplit(".",1)[-1].replace("$","-"),[JAVA_HOME / "bin/javap.exe","-classpath",jar,"-p","-c",cls],60)
bare = "D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01/tmp/upstream-history.git"
pin = "c5cd5af62fc07cd4e0d24f06a16033f181c47c04"
source = "src/main/resources/assets/advancedrocketry/recipes/jackhammer.json"
prefix = ["git","--git-dir=" + bare]
run("upstream-shallow",prefix + ["rev-parse","--is-shallow-repository"],60)
run("upstream-history",prefix + ["log","--follow","--format=%H%x09%aI%x09%an%x09%s",pin,"--",source],60)
run("upstream-name-status",prefix + ["log","--follow","--format=commit %H","--name-status",pin,"--",source],60)
run("upstream-source",prefix + ["show",pin + ":" + source],60)
run("upstream-license",prefix + ["show",pin + ":LICENSE"],60)
raw = LEAF / "results/upstream-source/stdout.log"
assert digest(raw) == "a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45"
rows=[row.split("\t",3) for row in (LEAF / "results/upstream-history/stdout.log").read_text("utf-8").splitlines()]
provenance=json.loads((REPO / "docs/provenance/v1.8.0-c18b-jackhammer.json").read_text("utf-8"))
entry=next(e for e in provenance["entries"] if e["status"] == "UPSTREAM_AR_MIT")
actual=[dict(commit=sha,authored_at=date,author=author,subject=subject) for sha,date,author,subject in rows]
assert actual == entry["upstream_history"]
rec=dict(head=SHA,upstream_pin=pin,history=actual,source_sha256=digest(raw),history_matches_provenance=True,
         primary_scope="Exact recipe file through pin; not full gameplay-idea provenance or human authorship approval.")
(LEAF / "results/upstream-check.json").write_text(json.dumps(rec,indent=2)+"\n",encoding="utf-8")
src = __import__("pathlib").Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01/recipe-history-01")
shutil.copytree(src, LEAF / "inputs/root-recipe-history-01")
print(json.dumps(rec),flush=True)
