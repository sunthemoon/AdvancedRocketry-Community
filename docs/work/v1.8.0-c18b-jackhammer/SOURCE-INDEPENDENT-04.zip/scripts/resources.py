"""Actual candidate bytes, provenance, rule handling and unchanged art screen."""
from collections import Counter
import csv
import fnmatch
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from qualify import LEAF, REPO, SHA, digest, utc

BASE = "106d31653f8bce66761c919742629a75a047e2ca"
out = LEAF / "results/resources"
out.mkdir(exist_ok=False)
start = utc()
provenance = json.loads((REPO / "docs/provenance/v1.8.0-c18b-jackhammer.json").read_text("utf-8"))
core = {k:v for k,v in provenance.items() if k != "review"}
review_digest = hashlib.sha256((json.dumps(core,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n").encode()).hexdigest()
assert provenance["schema_version"] == 2 and provenance["review"]["status"] == "PENDING_HUMAN_REVIEW"
assert review_digest == provenance["review"]["content_digest"]
targets=[]
for entry in provenance["entries"]:
    target=REPO / entry["target_path"]
    assert digest(target) == entry["target_sha256"]
    if entry["status"] == "NEW":
        source=subprocess.check_output(["git","show",entry["authoring_commit"]+":"+entry["source_path"]],cwd=REPO)
        assert hashlib.sha256(source).hexdigest() == entry["source_sha256"]
        assert digest(REPO / entry["source_path"]) == entry["source_sha256"]
    else:
        assert digest(LEAF / "results/upstream-source/stdout.log") == entry["source_sha256"]
    if target.suffix == ".json":
        data=json.loads(target.read_text("utf-8"))
        if "new_keys" in entry:
            before=json.loads(subprocess.check_output(["git","show",BASE+":"+entry["target_path"]],cwd=REPO))
            assert all(data[key] == value for key,value in before.items())
            assert sorted(data.keys()-before.keys()) == sorted(entry["new_keys"])
    targets.append(dict(path=entry["target_path"],bytes=target.stat().st_size,sha256=digest(target),source_sha256=entry["source_sha256"],status=entry["status"]))
prefix="src/main/resources/assets/advancedrocketry/"
manifest=list(csv.DictReader((REPO / "legacy-manifest/assets.csv").read_text("utf-8").splitlines()))
assets=[row["source_path"][len(prefix):] for row in manifest]
old_rules=list(csv.DictReader(io.StringIO(subprocess.check_output(["git","show",BASE+":docs/work/v1.8.0-asset-plan.csv"],cwd=REPO).decode())))
new_rules=list(csv.DictReader((REPO / "docs/work/v1.8.0-asset-plan.csv").read_text("utf-8").splitlines()))
def match(asset,rules):
    row=next(row for row in rules if fnmatch.fnmatchcase(asset,row["pattern"]))
    return {k:v for k,v in row.items() if k != "order"}
changed=[dict(asset=a,before=match(a,old_rules),after=match(a,new_rules)) for a in assets if match(a,old_rules) != match(a,new_rules)]
assert len(changed)==1 and changed[0]["asset"]=="recipes/jackhammer.json"
assert changed[0]["after"]["handling"]=="IMPORTED"
assert subprocess.check_output(["git","diff",BASE,SHA,"--","docs/work/v1.8.0-content-ledger.csv","docs/work/v1.8.0-import-allowlist.csv","docs/work/v1.8.0-origin-findings.json"],cwd=REPO)==b""
rec=dict(head=SHA,started_utc=start,ended_utc=utc(),target_count=len(targets),targets=targets,review_digest=review_digest,
         approval=False,assets_compared=len(assets),effective_asset_rule_changes=changed)
(out / "PROVENANCE-RESOURCE-CHECK.json").write_text(json.dumps(rec,indent=2)+"\n",encoding="utf-8")
sys.path.insert(0,str(REPO))
from tools.audit import vanilla_derivation as d
clients=["1.12.2=C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/vanilla/client-1.12.2.jar",
         "1.20.1=C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_repo/versions/1.20.1/client.jar"]
pins={"1.12.2":"8ada07da5ee77dad3527bd7278fbd05ee1fc8a597813b216a871a2d7d64cc64f",
      "1.20.1":"56b71336d2b4fdffd197f56595b0da93e32a946f78f382a299b8f4b92758bb0f"}
for arg in clients:
    label,path=arg.split("=",1)
    assert digest(Path(path))==pins[label]
artstart=utc()
sources,_,vanilla=d.load_vanilla(clients)
texture=next(r for r in targets if r["path"].endswith("jackhammer.png"))
width,height,rgba=d.decode_rgba((REPO / texture["path"]).read_bytes())
assert width==height==16 and sum(1 for alpha in rgba[3::4] if alpha)==82
result=d.analyse_images([(texture["path"],d.Image(width,height,rgba))],vanilla)
_,verdict,best=result.get(texture["path"],(None,"CLEAR",{}))
art=dict(head=SHA,started_utc=artstart,ended_utc=utc(),vanilla=sources,candidate=texture,width=width,height=height,
         opaque_pixels=82,verdict=verdict,best=best,unchanged_implementation_sha256=digest(REPO / "tools/audit/vanilla_derivation.py"),human_approval=False)
(out / "ART-SCREEN.json").write_text(json.dumps(art,indent=2,default=str)+"\n",encoding="utf-8")
print(json.dumps(dict(resources=rec,art=art),indent=2,default=str),flush=True)
assert verdict=="CLEAR"

artifact_start=utc()
jars=[]
for path in sorted((REPO / "build/libs").glob("*.jar")):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        assert len(names)==len(set(names))
        rows=dict(file=path.name,bytes=path.stat().st_size,sha256=digest(path),entries=len(names),
                  duplicate_entries=False,license="META-INF/LICENSE" in names,notice="META-INF/NOTICE.md" in names,
                  jackhammer_entries=sorted(n for n in names if "jackhammer" in n.lower()))
        if not path.name.endswith(("-sources.jar","-api.jar")):
            assert "assets/advancedrocketrycommunity/textures/item/jackhammer.png" in names
            assert "io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.class" not in names
            for row in targets:
                resource=row["path"].removeprefix("src/generated/v1.8/resources/")
                assert hashlib.sha256(z.read(resource)).hexdigest()==row["sha256"]
            assert rows["license"] and rows["notice"]
        jars.append(rows)
(out / "ARTIFACTS.json").write_text(json.dumps(dict(head=SHA,started_utc=artifact_start,ended_utc=utc(),jars=jars),indent=2)+"\n",encoding="utf-8")
assert jars
print(json.dumps(jars,indent=2),flush=True)
