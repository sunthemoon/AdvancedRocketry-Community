"""Capture final source/resource identities and actual native diagnostic inventory."""
from collections import Counter
import json
import re
from qualify import LEAF, REPO, SHA, digest, run, utc

run("post-native-diff",["git","diff","--exit-code"],60)
run("post-native-status",["git","status","--short"],60)
source=json.loads((LEAF / "inputs/source-hashes.json").read_text("utf-8"))
for row in source["files"]:
    assert digest(REPO / row["path"])==row["sha256"]
artifacts=json.loads((LEAF / "results/resources/ARTIFACTS.json").read_text("utf-8"))
for row in artifacts["jars"]:
    assert digest(REPO / "build/libs" / row["file"])==row["sha256"]
lines=(LEAF / "results/native/stdout.log").read_text("utf-8").splitlines()
completion=[dict(line=i+1,text=line) for i,line in enumerate(lines) if "All " in line and " required tests passed" in line]
assert len(completion)==1
count=int(re.search(r"All (\d+) required tests passed",completion[0]["text"]).group(1))
batches=[dict(line=i+1,text=line) for i,line in enumerate(lines) if "Running test batch 'jackhammer_" in line]
diagnostics=[dict(line=i+1,text=line) for i,line in enumerate(lines) if re.search(r"\[(?:[^\]]*/)?(?:ERROR|WARN|FATAL)\]",line)]
level=Counter("ERROR" if "/ERROR]" in row["text"] else "FATAL" if "/FATAL]" in row["text"] else "WARN" for row in diagnostics)
fatal=[row for row in diagnostics if "/FATAL]" in row["text"]]
assert not fatal
contexts=[]
for row in diagnostics:
    if "/ERROR]" in row["text"]:
        idx=row["line"]-1
        contexts.append("\n".join(f"{j+1}: {lines[j]}" for j in range(max(0,idx-2),min(len(lines),idx+16))))
(LEAF / "results/native/ERROR-CONTEXTS.txt").write_text("\n\n".join(contexts)+"\n",encoding="utf-8")
summary=dict(head=SHA,captured_utc=utc(),required_passed=count,completion=completion,jackhammer_batches=batches,
             diagnostic_counts=dict(level),diagnostics=diagnostics,source_hashes_unchanged_after_commands=True,
             artifacts_unchanged_after_commands=True,no_filtered_test_selection=True)
(LEAF / "results/native/NATIVE-SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
receipts=[json.loads(p.read_text("utf-8")) for p in sorted((LEAF / "results").glob("*/RESULT.json"))]
receipts.sort(key=lambda row:row["started_utc"])
(LEAF / "results/COMMAND-SUMMARY.json").write_text(json.dumps(receipts,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in summary.items() if k!="diagnostics"},indent=2),flush=True)
