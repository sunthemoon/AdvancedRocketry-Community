"""Seal only this reviewer's compact evidence leaf; never change a prior seal."""

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MANIFEST = ROOT / "SHA256SUMS.txt"
STATUS = ROOT / "results" / "SEAL-STATUS.json"
REPORT = ROOT / "REPORT.md"
START = "<!-- SEAL-METRICS-START -->"
END = "<!-- SEAL-METRICS-END -->"

if MANIFEST.exists():
    raise SystemExit("Refusing to change a previously sealed evidence leaf")
if (ROOT / "_tmp").exists():
    raise SystemExit("Refusing to seal while owned temporary output remains")

cleanup = json.loads((ROOT / "results" / "OWNED-CLEANUP.json").read_text())
if cleanup["outcome"] != "REMOVED" or cleanup["unsealed_remaining_bytes"] != 0:
    raise SystemExit("Cleanup receipt does not establish removed owned _tmp")
remainder = json.loads((ROOT / "results" / "UNSEALED-REMAINDER.json").read_text())
unsealed_paths = {ROOT / f["relative_path"] for f in remainder["files"]}
for entry in remainder["files"]:
    path = ROOT / entry["relative_path"]
    if not path.resolve().is_relative_to(ROOT):
        raise SystemExit("Unsealed remainder escapes the exclusive evidence leaf")
    if path.stat().st_size != entry["bytes"]:
        raise SystemExit("Unsealed remainder byte count changed")
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
        raise SystemExit("Unsealed remainder hash changed")
unsealed_bytes = sum(f["bytes"] for f in remainder["files"])
if unsealed_bytes != remainder["bytes"]:
    raise SystemExit("Unsealed remainder receipt is inconsistent")

report_template = REPORT.read_text(encoding="utf-8")
if report_template.count(START) != 1 or report_template.count(END) != 1:
    raise SystemExit("Report sealing metrics markers are ambiguous")
sealed_utc = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
total = 0
payload = 0
count = 0
largest = 0

for iteration in range(20):
    status = {
        "sealed_utc": sealed_utc,
        "exclusive_leaf": str(ROOT),
        "candidate_commit": "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7",
        "adoption_base": "106d31653f8bce66761c919742629a75a047e2ca",
        "retained_bytes_including_manifest": total,
        "checksummed_payload_bytes": payload,
        "checksummed_payload_files": count,
        "largest_retained_file_bytes": largest,
        "unsealed_remaining_bytes": unsealed_bytes,
        "total_leaf_bytes": total + unsealed_bytes,
        "unsealed_receipt": "results/UNSEALED-REMAINDER.json",
        "temporary_cleanup_outcome": cleanup["outcome"],
        "mutable_interests": "ALL_RELEASED",
        "per_file_limit_bytes": 50 * 1024 * 1024,
        "evidence_limit_bytes": 100 * 1024 * 1024,
        "manifest": "SHA256SUMS.txt",
        "manifest_paths": "relative within this leaf; manifest and identified unsealed remainder excluded",
    }
    STATUS.write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
    metrics = (
        f"{START}\n"
        f"Sealed UTC: `{sealed_utc}`. Retained evidence including the manifest: "
        f"{total:,} bytes; checksummed payload: {payload:,} bytes across {count:,} "
        f"files; largest retained file: {largest:,} bytes. Unsealed remainder: "
        f"{unsealed_bytes:,} bytes; complete leaf including that remainder: "
        f"{total + unsealed_bytes:,} bytes. Every file is below 50 MiB, and the complete leaf is below "
        "100 MiB. The relative `SHA256SUMS.txt` covers compact evidence only, "
        "not the explicitly unsealed preflight bytecode, build/Temp or any external mutable file.\n"
        f"{END}"
    )
    updated_report = re.sub(
        re.escape(START) + r".*?" + re.escape(END),
        lambda _: metrics,
        report_template,
        flags=re.DOTALL,
    )
    REPORT.write_text(updated_report, encoding="utf-8")
    files = sorted(
        (p for p in ROOT.rglob("*") if p.is_file() and p != MANIFEST and p not in unsealed_paths),
        key=lambda p: p.relative_to(ROOT).as_posix(),
    )
    entries = []
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        if path.is_symlink() or "_tmp" in Path(relative).parts:
            raise SystemExit(f"Unsafe manifest target: {relative}")
        entries.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {relative}\n")
    manifest_bytes = "".join(entries).encode("utf-8")
    lengths = [p.stat().st_size for p in files]
    new_payload = sum(lengths)
    new_count = len(files)
    new_total = new_payload + len(manifest_bytes)
    new_largest = max(lengths + [len(manifest_bytes)])
    if (total, payload, count, largest) == (
        new_total, new_payload, new_count, new_largest
    ):
        break
    total, payload, count, largest = (
        new_total, new_payload, new_count, new_largest
    )
else:
    raise SystemExit("Sealing byte-count fixed point did not converge")

if max(largest, unsealed_bytes) > 50 * 1024 * 1024 or total + unsealed_bytes > 100 * 1024 * 1024:
    raise SystemExit("Retained evidence exceeds the unchanged storage budget")

MANIFEST.write_bytes(manifest_bytes)
for line in MANIFEST.read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise SystemExit(f"Manifest target escapes its evidence leaf: {relative}")
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"Sealed hash verification failed: {relative}")
actual_files = [p for p in ROOT.rglob("*") if p.is_file()]
if sum(p.stat().st_size for p in actual_files) != total + unsealed_bytes:
    raise SystemExit("Sealed retained-byte count changed")

print(json.dumps({
    "sealed_utc": sealed_utc,
    "manifest_verified": True,
    "checksummed_files": count,
    "retained_bytes": total,
    "unsealed_remaining_bytes": unsealed_bytes,
    "total_leaf_bytes": total + unsealed_bytes,
    "report_sha256": hashlib.sha256(REPORT.read_bytes()).hexdigest(),
    "manifest_sha256": hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
}, indent=2))
