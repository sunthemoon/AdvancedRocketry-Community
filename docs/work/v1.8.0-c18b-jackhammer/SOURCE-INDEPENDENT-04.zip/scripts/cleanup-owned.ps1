$ErrorActionPreference = 'Stop'
$leaf = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$target = (Resolve-Path -LiteralPath (Join-Path $leaf '_tmp')).Path
$record = [ordered]@{
    started_utc = (Get-Date).ToUniversalTime().ToString('o')
    argv = @('Remove-Item', '-LiteralPath', $target, '-Recurse', '-Force', '-ErrorAction', 'Stop')
    exclusive_leaf = $leaf
    target = $target
    removal_attempts = 0
    outcome = 'NOT_ATTEMPTED'
}
try {
    if (-not $target.StartsWith($leaf.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Resolved target is outside the exclusive leaf'
    }
    $ancestor = Get-Item -LiteralPath $target -Force
    while ($null -ne $ancestor) {
        if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse ancestor refused: $($ancestor.FullName)"
        }
        $ancestor = $ancestor.Parent
    }
    $all = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
    $links = @($all | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
    $record['reparse_descendants'] = @($links | Select-Object -ExpandProperty FullName)
    if ($links.Count -ne 0) { throw 'Reparse descendant refused' }
    $live = @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -in @('java.exe', 'javaw.exe', 'python.exe', 'pythonw.exe', 'cmd.exe') -and
        $null -ne $_.CommandLine -and $_.CommandLine.IndexOf($leaf, [StringComparison]::OrdinalIgnoreCase) -ge 0
    } | Select-Object ProcessId, ParentProcessId, Name, CreationDate, CommandLine)
    $record['live_owned_processes'] = $live
    if ($live.Count -ne 0) { throw 'Owned process still running; no cleanup performed' }
    $record['before_files'] = @($all | Where-Object { -not $_.PSIsContainer }).Count
    $record['before_bytes'] = ($all | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
    $record['removal_attempts'] = 1
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    $record['outcome'] = 'REMOVED'
} catch {
    $record['outcome'] = 'FAILED_OR_REFUSED'
    $record['error'] = $_.Exception.ToString()
    $record['error_record'] = ($_ | Out-String)
}
$record['exists_after'] = Test-Path -LiteralPath $target
if ($record['exists_after']) {
    $record['unsealed_remaining_bytes'] = (Get-ChildItem -LiteralPath $target -Recurse -File -Force | Measure-Object -Property Length -Sum).Sum
} else { $record['unsealed_remaining_bytes'] = 0 }
$record['ended_utc'] = (Get-Date).ToUniversalTime().ToString('o')
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'results/OWNED-CLEANUP.json') -Encoding utf8
$record | ConvertTo-Json -Depth 8
if ($record['outcome'] -ne 'REMOVED') { exit 1 }
