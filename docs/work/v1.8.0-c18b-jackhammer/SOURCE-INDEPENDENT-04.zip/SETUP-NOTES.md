# Independent reviewer preparation observations

The only writable scope is this new evidence leaf and its private `_tmp` outputs.
The source repository initially had an empty short status on
`codex/v1.8.0-jackhammer`; the inspected worktree list included separate Main and
other existing worktrees. The detached private clone was captured with local
`--no-hardlinks --no-checkout` and per-command `core.longpaths=true`, followed by
checkout of the exact assigned commit. No source edit, staging, commit, push,
installation, global setting or policy change was performed. Mutable source,
Main, Root and HEAD interests were released at the UTC in the snapshot receipt.
Root is the OpenPet coordinator. No further delegation or Claude invocation was
made. The team listing later showed Root and its independent packaged/source/
sleep reviewers running in their separate scopes.

## Preparation failures and observation limitations

- An exploratory `git show <candidate>:SOURCE-REVIEW-TASK-01.md` lookup failed:
  the task is under `docs/work/v1.8.0-c18b-jackhammer/`. The correctly located
  task was read and is retained under `inputs/governance/`.
- Initial grouped reads tried the nonexistent lowercase version filename,
  `verify_bootstrap_provenance.py`, bare PATH `javap`, and the earlier reviewer
  leaf's nonexistent `scripts` directory. Actual required inputs, approved
  bootstrap command and explicit Java 17 JDK tools were subsequently resolved;
  these lookup failures were not counted as successful checks.
- The first cache-copy launcher result was incorrectly reduced to its `output`
  field, discarding its ongoing wrapper-session identifier. Its Python process
  was observed to end, with most dependency-cache bytes present but no completion
  receipt or copied wrapper/native directory. The original raw failure/output
  was therefore not retained. This is an evidence-retention gap, not a cache-copy
  PASS, and its precise exception cannot be reconstructed. No denied cache
  target was retried. Only the previously unattempted wrapper/native directories
  were copied in the separately logged completion step. The assigned build,
  explicit test, two DataGen/diff pairs, native suite and validators all have
  separate full argv/cwd/UTC/outcome/raw-output receipts.
- A premature build-launch check reported `Cache copy not finished` before any
  Gradle launch. The owned completion step then established the wrapper/native
  dependencies and the actual assigned forced build was launched separately.
- Preliminary Root-artifact reads expected per-phase `RESULT.json` and
  `command.log`, which do not exist; the actual `receipt.json`, `stdout.txt`,
  aggregate results and raw playerdata were subsequently inspected and copied.
- The strict repository command has its own unchanged 180-second timeout
  receipt. Its empty output is not a link-check result. No timeout extension,
  alternate implementation, waived assertion or denied-target cleanup retry is
  used to turn it into a pass.

Existing Gradle dependencies were read/copied into an owned Gradle user home;
build/runtime/config/cache/temp writes belong below this leaf's `_tmp`.
No published JAR, complete source tree or world is retained in compact evidence.
The only saved native player files are the two small stopped Root observations
needed to recheck its separately attributed inventory evidence, not a full world.

The final sealing-script syntax check (`python -m py_compile scripts/seal.py`,
exit 0) created a 7,332-byte `scripts/__pycache__/seal.cpython-313.pyc` outside
`_tmp`, after the main owned-copy cleanup had succeeded. One precise native
file-removal invocation with intended containment/reparse/process checks was
rejected by tool policy before process launch. Those checks did not execute;
no exit code or actual command UTC exists in a process receipt. Creation and
subsequent observation UTC, the exact command, rejection outcome, remaining
bytes/hash and zero retries are retained separately. No alternate shell,
move or policy bypass is attempted. The file is explicitly unsealed, not part
of the compact replayable evidence or a project build product.
