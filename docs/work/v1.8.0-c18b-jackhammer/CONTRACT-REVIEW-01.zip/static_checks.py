import collections
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess

L = pathlib.Path(__file__).resolve().parent
os.environ['TEMP'] = os.environ['TMP'] = str(L / 'tmp')
R = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
C = 'c583d40b1120bb4f1a22b23740d273dd907beec5'
TASK = L / 'inputs/docs/work/v1.8.0-c18b-jackhammer/TASK-01.md'
recipe_bytes = (L / 'upstream-recipe-preimage.txt').read_bytes()
recipe = json.loads(recipe_bytes)
task = TASK.read_text(encoding='utf-8')
checks = []

def check(name, passed, observed):
    checks.append({'name': name, 'passed': bool(passed), 'observed': observed})

digest = hashlib.sha256(recipe_bytes).hexdigest()
check('exact_recipe_sha256', digest == 'a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45', digest)
counts = collections.Counter(''.join(recipe['pattern']).replace(' ', ''))
check('recipe_pattern_and_counts', recipe['pattern'] == [' pt', 'imp', 'di ']
    and counts == {'d': 1, 't': 1, 'i': 2, 'p': 2, 'm': 1}, dict(counts))
check('upstream_result_one', recipe['result']['count'] == 1, recipe['result'])
mapping = {'gemDiamond': 'forge:gems/diamond', 'stickTitanium': 'forge:rods/titanium',
    'stickIron': 'forge:rods/iron', 'plateAluminum': 'forge:plates/aluminum',
    'blockMotor': 'advancedrocketrycommunity:motors'}
check('conversion_names_declared', all(mapping[v['ore']] in task for v in recipe['key'].values()), mapping)
tags = {}
for p in ['data/advancedrocketrycommunity/tags/items/motors.json', 'data/forge/tags/items/rods/titanium.json',
    'data/forge/tags/items/rods/iron.json', 'data/forge/tags/items/plates/aluminum.json']:
    tags[p] = json.loads((L / 'inputs/src/generated/v1.8/resources' / p).read_bytes())
check('existing_owned_material_tags_nonempty', all(t['values'] for t in tags.values()), tags)
grid = re.findall(r'^([.0-9]{16})$', task, re.M)
check('proposed_grid_dimensions_characters', len(grid) == 16 and all(len(row) == 16 for row in grid),
    {'rows': len(grid), 'widths': sorted(set(map(len, grid))), 'alphabet': ''.join(sorted(set(''.join(grid)))),
     'opaque_pixels': sum(c != '.' for row in grid for c in row)})
material_art = (L / 'inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/V180MaterialArt.java').read_text()
palette = [int(x) for x in re.search(r'GREYS = \{([^}]+)', material_art).group(1).split(',')]
tint = 0xBDD0DE
colors = {d: [palette[int(d)] * ((tint >> shift) & 255) // 255 for shift in [16, 8, 0]]
    for d in sorted(set(''.join(grid)) - {'.'})}
check('grid_uses_existing_digit_palette', len(palette) == 10 and len(colors) == 6,
    {'tint': hex(tint), 'digit_rgb': colors, 'transparent_alpha': 0, 'digit_alpha': 255})
moditems = (L / 'inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry/ModItems.java').read_text()
config = (L / 'inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfig.java').read_text()
check('tool_and_equipment_switch_are_additive', 'jackhammer' not in moditems and 'equipment.classicEnabled' not in config,
    {'jackhammer_already_registered': 'jackhammer' in moditems, 'equipment_switch_exists': 'equipment.classicEnabled' in config})
native_digger = (L / 'native/DiggerItem.txt').read_text()
native_properties = (L / 'native/Item-Properties.txt').read_text()
check('native_tier_and_explicit_durability_hooks_exist', 'TierSortingRegistry.isCorrectTierForDrops' in native_digger
    and 'defaultDurability(int)' in native_properties and 'durability(int)' in native_properties,
    {'tier_rule': 'inherited native Forge', 'durability_default_only_if_zero': 'verified by javap branch'})
check('numeric_static_implications_finite', 1024 > 0 and 50 > 1,
    {'mineable_base_speed': 50, 'other_base_speed': 1, 'diamond_native_speed': 8,
     'unmodified_stone_start_progress': 50 / 1.5 / 30,
     'unmodified_obsidian_progress_per_tick': 50 / 50 / 30,
     'material_anvil_repair_max_per_rod': 1024 // 4, 'native_melee_wear': 2,
     'native_nonzero_hardness_mining_wear': 1,
     'qualification': 'static formulas only; native effects/enchantments/events alter actual progress'})
argv = ['git', '-C', str(R), 'diff', '--check', C + '^', C]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
r = subprocess.run(argv, cwd=L, capture_output=True)
(L / 'prepared-diff-check.txt').write_bytes(r.stdout + r.stderr)
with (L / 'commands.jsonl').open('a', encoding='utf-8') as f:
    f.write(json.dumps({'argv': argv, 'cwd': str(L), 'started': start,
        'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': r.returncode,
        'output': 'prepared-diff-check.txt'}) + '\n')
check('prepared_diff_whitespace', r.returncode == 0, {'exit': r.returncode})
result = {'classification': 'STATIC_INPUT_REVIEW_NOT_RUNTIME_OR_GATE', 'prepared_commit': C, 'checks': checks}
(L / 'static-checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
