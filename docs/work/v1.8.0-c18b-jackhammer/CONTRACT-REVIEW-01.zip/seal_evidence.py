import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import zipfile

L = pathlib.Path(__file__).resolve().parent
R = 'D:/GitHub/AdvancedRocketry-Community'
C = 'c583d40b1120bb4f1a22b23740d273dd907beec5'
J = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
os.environ['TEMP'] = os.environ['TMP'] = str(L / 'tmp')
assert not (L / 'SHA256SUMS.txt').exists(), 'Evidence already sealed'

def run(args, output):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    r = subprocess.run(args, cwd=L, capture_output=True)
    (L / output).write_bytes(r.stdout + r.stderr)
    with (L / 'commands.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps({'argv': args, 'cwd': str(L), 'started': start,
            'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'exit': r.returncode, 'output': output}) + '\n')
    if r.returncode:
        raise RuntimeError((args, r.returncode, r.stderr))
    return r.stdout

run(['git', '-C', R, 'rev-list', '-n', '1', '--parents', C], 'prepared-parent.txt')
run(['git', '--version'], 'git-version.txt')
run([sys.executable, '--version'], 'python-version.txt')
run(['git', '-C', R, 'grep', '-n', 'stationManager::onBlockBroken', C, '--', 'src/main/java'], 'station-break-binding.txt')
data = run(['git', '-C', R, 'show', C + ':src/main/java/io/github/sunthemoon/advancedrocketrycommunity/AdvancedRocketryCommunity.java'], 'central-registration-preimage.java.txt')
(L / 'final-input-identities.json').write_text(json.dumps({'commit': C,
    'central_registration_preimage_sha256': hashlib.sha256(data).hexdigest()}, indent=2), encoding='utf-8')
with zipfile.ZipFile(J) as z:
    tag_name = 'data/forge/tags/items/gems/diamond.json'
    diamond = z.read(tag_name)
    tag = {'jar_entry': tag_name, 'sha256': hashlib.sha256(diamond).hexdigest(), 'json': json.loads(diamond)}
(L / 'native-diamond-tag.json').write_text(json.dumps(tag, indent=2), encoding='utf-8')
assert tag['json']['values'], 'Native diamond tag empty'
with J.open('rb') as f:
    final_jar_hash = hashlib.file_digest(f, 'sha256').hexdigest()
assert final_jar_hash == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
disk_process = run(['pwsh', '-NoProfile', '-Command',
    "$ErrorActionPreference='Stop'; $d=Get-PSDrive -Name C,D | Select-Object Name,Free; "
    "$p=Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine.Contains('jackhammer-contract-independent-20261009-01') } | Select-Object ProcessId,ParentProcessId,Name,CommandLine; "
    "@{drives=@($d);matching_processes=@($p);utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json -Depth 5"], 'final-disk-process.json')
observed = json.loads(disk_process.decode('utf-8-sig'))
assert all(d['Free'] >= 10 * 1024**3 for d in observed['drives'])
files = sorted(p for p in L.rglob('*') if p.is_file())
tmp_files = [p for p in (L / 'tmp').rglob('*') if p.is_file()]
env = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python_executable': sys.executable,
    'python_version': sys.version, 'TEMP': os.environ['TEMP'], 'TMP': os.environ['TMP'],
    'own_current_process': os.getpid(), 'process_inventory_note': 'Includes the synchronous sealing/check shell only, not a retained background job.',
    'final_mapped_jar_sha256': final_jar_hash, 'tmp_residual_bytes': sum(p.stat().st_size for p in tmp_files),
    'outside_owned_leaf_outputs_created': 0, 'retained_bytes_before_environment_and_manifest': sum(p.stat().st_size for p in files),
    'largest_retained_file_bytes_before_manifest': max(p.stat().st_size for p in files), 'disk_process_inventory': observed,
    'cleanup_attempts': 0, 'cleanup_reason': 'No disposable source/build/world/JAR/server output was created; all non-temp files are compact retained evidence.'}
assert env['tmp_residual_bytes'] == 0
(L / 'reviewer-environment.json').write_text(json.dumps(env, indent=2), encoding='utf-8')
files = sorted(p for p in L.rglob('*') if p.is_file())
assert all(p.stat().st_size <= 50 * 1024**2 for p in files)
assert sum(p.stat().st_size for p in files) < 100 * 1024**2
manifest = []
for p in files:
    with p.open('rb') as f:
        digest = hashlib.file_digest(f, 'sha256').hexdigest()
    manifest.append(digest + '  ' + p.relative_to(L).as_posix())
(L / 'SHA256SUMS.txt').write_text('\n'.join(manifest) + '\n', encoding='utf-8')
for line in manifest:
    expected, relative = line.split('  ', 1)
    with (L / relative).open('rb') as f:
        assert hashlib.file_digest(f, 'sha256').hexdigest() == expected
print(json.dumps({'manifest_entries': len(manifest), 'sealed_retained_bytes': sum(p.stat().st_size for p in L.rglob('*') if p.is_file()),
    'tmp_residual_bytes': 0, 'report': str(L / 'REPORT.md'), 'sealed_hashes_verified': True}, indent=2))
