# C18b-JACKHAMMER-01 independent contract review

## Findings first

No change-required Critical, High, Medium or Low finding was identified in the
prepared **ordinary single-block tool contract**. This conclusion is limited to
the proposal and the static native/current-source evidence below. There is no
jackhammer implementation, generated resource, test execution or delivered
content in this input, so this is not a no-defect source verdict or runtime approval.

Informational boundaries that matter to implementation and its later review:

1. **Info — native admission and downstream break are different evidence.**
   [TASK-01 lines 43-50](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/TASK-01.md#L43)
   preserves that distinction. The pinned
   [ServerPlayerGameMode disassembly lines 259-635](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/native/ServerPlayerGameMode.txt#L259)
   supplies action/reach/progress admission; its lines 667-808 supply downstream
   event, tool hook, wear, removal and loot. A direct destroyBlock fixture cannot
   establish hardness, reach or elapsed mining admission. The task already requires
   those checks through native action/progress, so no correction is requested.
2. **Info — survival acquisition and original-asset closure remain open.**
   [TASK-01 lines 65-70](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/TASK-01.md#L65)
   and [ADR-063 lines 112-115](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-063-MATERIALS-ORES-AND-PLANETARY-SURFACES.md#L112)
   explicitly retain missing initial titanium/steel progression. The existing
   titanium rod recipe starts from titanium ingots, and the base motor consumes
   steel ingot/plates; supplied test ingredients do not establish those roots.
   The legacy jackhammer bitmap remains an IMPORT candidate in asset-plan line
   235, while the proposed NEW grid is only a development replacement. The task
   correctly makes neither acquisition-complete nor asset-delivery claims.

## Exact inputs, identity and release

Prepared input: `c583d40b1120bb4f1a22b23740d273dd907beec5` on
`codex/v1.8.0-classic-content`; the initial HEAD matched. Its source baseline is
`30dd002841a6d0dbabad7c72e1774d5f3cb17330`. The actual six-file prepared diff is
preserved in [prepared-diff.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/prepared-diff.txt).

At `2026-10-09T01:28:08.685604Z`, 41 selected committed inputs (1,034,230 bytes)
were byte-exactly captured with Git blob IDs/SHA-256 in
[input-identities.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/input-identities.json).
Ten supplementary committed inputs were subsequently read only from that same
fixed Git object and captured in
[supplement-identities.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/supplement-identities.json).
The central native-event binding was also captured from that fixed object and
identified in [final-input-identities.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/final-input-identities.json).
Mandatory project/version/Gate/provenance/parallel/visual governance, accepted
ADR-060/061/063/066, current configuration, registration, data generation and
station protection were inspected. The canonical plan/current-version/log
changes preserve PLANNED tool work, IN_PROGRESS / IMPLEMENTING v1.8 and the
separate unanswered sleep question; they do not adopt tool source or a new
sleep/dimension policy.

Initial status had the user's modified AGENTS.md and inherited untracked
directories/archives. None was modified, staged, committed, deleted or used as
source. Mutable AGENTS.md preimage SHA-256 was
`c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`;
the committed AGENTS blob is separately identified in the input manifest.
[Initial status/worktrees](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/initial-worktrees.txt)
and the user's AGENTS diff were retained only as ownership context.

Immediately after capture the reviewer told Root that mutable Main, source and
HEAD interests were released. All subsequent source inspection used fixed
objects or owned snapshots. No HEAD move, worktree creation, installation,
network, global configuration change or delegated agent was performed. Root
coordinated OpenPet. The only write scope is this NEW exclusive reviewer leaf.

Pinned local primary binary identities, verified from actual bytes:

| Input/tool | Identity |
|---|---|
| Forge mapped official 1.20.1 / 47.4.10 JAR | 19,355,242 bytes; SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Java 17 javap | version `17.0.7`; SHA-256 `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d` |
| Git | `2.55.0.windows.5` |
| Python | `3.13.15` |
| Approved upstream recipe | 666 bytes; SHA-256 `a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45` |

The mapped JAR hash matches existing committed primary-source identity records,
and before/after JAR/recipe hashes matched. Full paths/identities are in
[tool-identities.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/tool-identities.json).
No JAR or full project/source/build/world tree was copied into this evidence.

## Static native and product review

### Authority and numeric behavior

Accepted ADR-066 section 5.3 authorizes an ordinary native single-block tool,
while its proposed balance still requires leaf review. The frozen-input proposal
uses actual `Tiers.DIAMOND`, speed 50 on `minecraft:mineable/pickaxe`, speed one
otherwise, 1,024 maximum damage, one stack, attack constructor bonus 1 and speed
-2.8. These are finite and internally consistent with the accepted proposal;
they add neither a tier identity nor a new mining/charge transaction.

The [PickaxeItem disassembly](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/native/PickaxeItem.txt)
binds the mineable tag and native pickaxe actions. DiggerItem lines 125-197 use
the inherited Forge TierSortingRegistry rule; lines 76-104 apply native melee
wear two and nonzero-hardness mining wear one. TieredItem lines 5-16 apply
defaultDurability, and Item-Properties lines 61-82 preserve an explicit nonzero
durability and set stack size one. Thus properties.durability(1024) is not
overwritten by diamond's native 1561-use default. Native diamond enchantability
is ten; its attack bonus three plus constructor one yields the ordinary pickaxe
attribute modifier four, without a custom combat system.

Static unmodified progress implications are explicit, not gameplay timings:
stone progress is `50 / 1.5 / 30 > 1`, permitting native instant mining; obsidian
progress is `50 / 50 / 30`. Ordinary effects/enchantments/Forge events and native
STOP thresholds still participate. A hardness -1 survival block returns zero
progress in BlockBehaviour lines 447-477. Creative takes its earlier native
branch and retains normal creative behavior/no wear; the contract does not
invent a creative unbreakable restriction.

### Server refusal and protection ordering

ServerPlayerGameMode.destroyBlock lines 681-687 check the final BreakEvent
cancellation before wear/removal. Lines 712-721 then call the actual held item's
onBlockStartBreak before either the creative or survival branch. This is a
usable final native disabled-tool refusal, not a mining-speed prediction or
cancelable event listener whose cancellation another listener may clear.

The survival order is harvest qualification -> mineBlock -> removeBlock -> loot,
with a pre-wear stack copy for actual loot. Native mineBlock may debit wear even
if a later removal hook refuses. TASK-01 states that limit accurately and does
not claim stronger resource/removal atomicity. Existing StationManager lines
357-361/387-414 apply station BUILD through the BreakEvent route, including the
existing operator policy, without tool-specific authority replacement.

Player.attack lines 2850-2856 invoke ForgeHooks.onPlayerAttackTarget before attack
effects. ForgeHooks lines 1237-1265 post AttackEntityEvent and then call the main
item's onLeftClickEntity; returning true refuses the native attack before hurt
and durability. Native packet handling has its own reach/thread/border route;
direct Player.attack checks prove the attack-item endpoint, not packet admission.
No arbitrary third-party event callback is claimed to be controlled by this tool.

The proposed COMMON switch is additive and already authorized by ADR-066 lines
110-114. It belongs before CommonConfig.SPEC construction and must enter the
existing SERVER_SWITCHES set/accessor so SwitchOverrides can test it. No current
suit or reserve switch semantics should change. COMMON is not evidence of
client/server config synchronization: client tooltip/prediction must not be
presented as final server authority. The leaf permits prediction differences
and requests no new packet. Later source/V1/V2 review must inspect the actual
disabled feedback rather than infer it from this static contract.

### Repair, data, recipe and visual input

Keeping actual diamond tier while overriding **only** isValidRepairItem to the
live titanium-rod tag avoids inherited diamond repair. AnvilMenu lines 196-341
copy the left stack and use that method for material repair; each rod repairs at
most `1024 / 4 = 256` damage. Its separate same-item/book path remains native.
Unknown/unrelated vanilla item data and enchantments should keep their native
operation semantics, not an invented universal preservation promise across
every vanilla recipe. No project-owned item root means no new custom schema or
1.12 mapping is needed. The additive permanent stable ID matches ADR-061;
renaming/removing it later still requires the documented migration process.

The approved recipe file's actual hash matches TASK-01, the pre-authoring record
and committed legacy-manifest/assets.csv line 423 / recipes.csv line 73. Its
exact rows are `" pt"`, `"imp"`, `"di "`: diamond one, titanium rod one, iron rods
two, aluminum plates two, motor one, output one. The proposed modern tags map
the five ore-dictionary inputs without changing those counts or layout. Existing
owned material tags are populated; the motors group contains all four existing
motor IDs. Motor acquisition unlock and the normal recipe-unlocked alternate
criterion are compatible with native crafting. Forge's diamond tag is a native
dependency, not a project diamond item re-registration.

The recipe is MIT-derived conversion, not NEW-only data. Before committed
delivery its final schema-2 provenance must retain source/history/transformations,
target hash and pending review state as required by ADR-061 section 4; the
pre-authoring Markdown is an input registration, not final human asset approval.

The exact proposed grid is 16 x 16, uses only `.` and digits 2/5/6/7/8/9, and
contains 82 opaque pixels. The existing palette/`0xBDD0DE` arithmetic is compatible
with V180MaterialArt.pixels/png. Its top cross-handle, body and narrow bit are
coherent as a development jackhammer silhouette. No bitmap was generated or
imported during this review. Static grid/color inspection does not establish
originality-screen clearance, held-item orientation, resource reload correctness
or real-client appearance. `minecraft:item/handheld` is a lawful ID reference,
not permission to copy a vanilla model. Final PNG screening and human V1/asset
review remain necessary, and the legacy IMPORT asset is not closed by this grid.

## Commands, checks and failures

The replayable small-check scripts and exact subprocess argv/cwd/UTC times/exits
are preserved in
[commands.jsonl](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/commands.jsonl).

| Executed command | Result |
|---|---|
| Read-only PowerShell Get-Content, Git status/branch/rev-parse/worktree list, Get-PSDrive and Get-FileHash exploration | Exit 0; status and excluded ownership inputs retained; one nonterminating missing-directory read error below |
| `python capture_inputs.py` | Exit 0; exact committed/preimage input capture |
| `python native_inspect.py` | Exit 0; 16 javap disassemblies, JAR/recipe/tool hashes, fixed-commit identity/legacy grep |
| `python supplement.py` | Exit 0; ten additional fixed-commit snapshots and three additional javap classes |
| `python static_checks.py` (twice; second run adds explicit owned TEMP/TMP setup) | Exit 0 both times; 11 static-input checks true; final result retained |
| `git -C D:/GitHub/AdvancedRocketry-Community diff --check c583d40b1120bb4f1a22b23740d273dd907beec5^ c583d40b1120bb4f1a22b23740d273dd907beec5` | Exit 0 on both small-check runs; empty whitespace output |
| `python seal_evidence.py` | Exit 0; fixed parent/binding/tool checks, native diamond-tag byte inspection, final identity/space/owned-process checks and relative manifest verification |

The exact initial failed attempt was
`Get-ChildItem -LiteralPath 'docs/adr' -Filter '*06[136]*'` from Main. PowerShell
reported that docs/adr does not exist; the surrounding composite command exited
zero because it was a nonterminating read error. The actual ADR directory was
then resolved through the fixed Git tree as docs/decisions. This was not hidden,
retried through a policy bypass or treated as a successful ADR read. Supplement
path candidates absent from the fixed tree are listed in the script's output;
they were not substituted as existing sources.

The final JSON result is
[static-checks.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/static-checks.json).
These are **static input/provenance/formula checks only**. No Gradle, Forge
GameTest, server, client, network or installation command was executed, because
this independent contract task expressly forbids them. No project test was
added/modified, and no runtime check is reported as PASS or NOT_APPLICABLE.

## Verification sufficiency, remaining work and Gate status

The plan can substantiate the declared bounded native tool if later evidence
actually exercises its required routes: tagged/non-tagged speed, diamond-qualified
loot, ordinary single-target survival/creative wear, canceled/station-denied
breaks, survival negative-hardness and reach/progress admission, finite ordinary
breakage, live-tag/native anvil repair, same-item/book/enchantment/item-data
semantics, disabled native mining/melee and re-enable. Listener/override cleanup
must be exception-safe so tests do not contaminate later cases. A titanium repair
getter call alone is not a native anvil result, and a harvest predicate alone is
not actual loot. Missing above-diamond/mod interaction runtime proof must remain
attributed, as the task already requires.

The committed candidate still needs independent actual-diff review and the
specified Java 17 uncached build/test, twice-deterministic DataGen plus separate
empty diffs, unfiltered GameTest, validators, artifact inspection and packaged
save/restart/continued-use evidence. Real-client V1/V2 remains a distinct
obligation; embedded actors/static art do not discharge it. Tests of supplied
ingredients do not discharge new-world survival reachability. Inherited/current
G0-G9, full acquisition, recipe graph, asset review, release and sleep policy
remain unfinished. This review meets **none** of the version's complete Required
Gates and changes no version/Gate/ledger state.

No product-defining missing decision was found for this isolated ordinary-tool
mechanism. Equipment modules, physical hatches, charging, lasers and sleep are
not inferred dependencies/permissions for this leaf. Root may consider adopting
the exact reviewed inputs under the existing conditional authority, then implement
and submit the committed candidate for source review. That is a v1.8 remaining
item, not permission for a later version or release.

## Ownership, volume and retained evidence

Before the reviewer leaf was created, C had 30,513,602,560 free bytes and D had
298,578,518,016 free bytes, both above 10 GiB. All authored files are within the
exclusive leaf. Javap used its owned `tmp` directory as Java tmp, and checking
scripts used owned TEMP/TMP. All synchronous owned Python/Git/javap processes
completed; no reviewer-started background server, agent or lingering process
exists. No cleanup of another owner's output or denied target was attempted.
There was no owned disposable source/build/world/server export to remove, and
the owned tmp directory contains no residual files. Unsealed residual bytes
outside this leaf created by this reviewer: zero.

The relative [SHA256SUMS.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/SHA256SUMS.txt) seals compact scripts, observations, selected input
preimages, diff and raw javap evidence; no individual retained file approaches
50 MiB and the leaf remains below 100 MiB. Exact retained sizes and final
environment/process inventory are in [reviewer-environment.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-contract-independent-20261009-01/reviewer-environment.json). Mutable Main,
source and HEAD interests remain released.
