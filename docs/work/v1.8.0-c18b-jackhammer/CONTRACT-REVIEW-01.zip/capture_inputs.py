import hashlib
import json
import pathlib
import subprocess
import datetime

REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = pathlib.Path(__file__).resolve().parent
COMMIT = 'c583d40b1120bb4f1a22b23740d273dd907beec5'
LOG = LEAF / 'commands.jsonl'

def run(args):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, cwd=REPO, capture_output=True)
    with LOG.open('a', encoding='utf-8') as output:
        output.write(json.dumps({'argv': args, 'cwd': str(REPO), 'started': started,
            'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'exit': result.returncode, 'stderr': result.stderr.decode('utf-8', 'replace')}) + '\n')
    if result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr))
    return result.stdout

all_paths = run(['git', 'ls-tree', '-r', '--name-only', COMMIT]).decode().splitlines()
fixed = {'PROJECT-CONFIG.md', 'PRODUCT.md', 'UPSTREAM.md', 'NOTICE.md', 'AGENTS.md',
    'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/15-REMOTE-LINUX-DEVELOPMENT-AND-VISUAL-VALIDATION.md',
    'docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md', 'docs/08-ASSET-LICENSE-AND-PROVENANCE.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/status/CURRENT_VERSION.md', 'docs/status/GATE_STATUS.md',
    'docs/status/COMPLETION-PLAN.md', 'docs/work/v1.8.0-implementation-log.md',
    'docs/provenance/v1.8.0-c18b-jackhammer-preauthoring.md',
    'docs/work/v1.8.0-c18b-jackhammer/TASK-01.md',
    'docs/work/v1.8.0-c18b-jackhammer/REVIEW-TASK-01.md',
    'docs/work/v1.8.0-asset-plan.csv', 'build.gradle'}
suffixes = ('/CommonConfig.java', '/ModItems.java', '/ModCreativeTabs.java',
    '/BootstrapDataGenerators.java', '/V180LanguageProvider.java',
    '/V180MaterialArt.java', '/V180MaterialsData.java', '/V180MaterialsRecipeData.java',
    '/StationProtectionEvents.java')
selected = sorted(p for p in all_paths if p in fixed or p.endswith(suffixes)
    or p.startswith('docs/decisions/ADR-060-')
    or p.startswith('docs/decisions/ADR-061-')
    or p.startswith('docs/decisions/ADR-063-')
    or p.startswith('docs/decisions/ADR-066-')
    or (p.startswith('src/main/java/') and '/equipment/' in p)
    or (p.startswith('src/generated') and ('tags/items/motors' in p
        or 'tags/items/rods/titanium' in p or 'tags/items/rods/iron' in p
        or 'tags/items/plates/aluminum' in p)))
manifest = []
for path in selected:
    data = run(['git', 'show', f'{COMMIT}:{path}'])
    target = LEAF / 'inputs' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    manifest.append({'path': path, 'sha256': hashlib.sha256(data).hexdigest(),
        'bytes': len(data), 'git_blob': run(['git', 'rev-parse', f'{COMMIT}:{path}']).decode().strip()})
for label, args in [('initial-status', ['git', 'status', '--porcelain=v1']),
    ('initial-worktrees', ['git', 'worktree', 'list', '--porcelain']),
    ('initial-head', ['git', 'rev-parse', 'HEAD']),
    ('prepared-show', ['git', 'show', '--format=fuller', '--stat', COMMIT]),
    ('prepared-diff', ['git', 'diff', COMMIT + '^', COMMIT]),
    ('initial-agents-diff', ['git', 'diff', '--', 'AGENTS.md'])]:
    (LEAF / (label + '.txt')).write_bytes(run(args))
data = (REPO / 'AGENTS.md').read_bytes()
(LEAF / 'mutable-AGENTS-preimage.md').write_bytes(data)
(LEAF / 'input-identities.json').write_text(json.dumps({'commit': COMMIT,
    'capture_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'mutable_AGENTS_sha256': hashlib.sha256(data).hexdigest(), 'inputs': manifest}, indent=2), encoding='utf-8')
print(json.dumps({'commit': COMMIT, 'inputs': len(selected), 'bytes': sum(x['bytes'] for x in manifest),
    'mutable_AGENTS_sha256': hashlib.sha256(data).hexdigest()}, indent=2))
