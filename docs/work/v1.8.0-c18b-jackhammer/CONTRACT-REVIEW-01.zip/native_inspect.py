import datetime
import hashlib
import json
import os
import pathlib
import subprocess

LEAF = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = 'c583d40b1120bb4f1a22b23740d273dd907beec5'
JAR = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP = pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
UPSTREAM = pathlib.Path('C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/upstream/ar/src/main/resources/assets/advancedrocketry/recipes/jackhammer.json')
os.environ['TEMP'] = os.environ['TMP'] = str(LEAF / 'tmp')

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def run(args, output):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    r = subprocess.run(args, cwd=LEAF, capture_output=True)
    (LEAF / output).parent.mkdir(parents=True, exist_ok=True)
    (LEAF / output).write_bytes(r.stdout)
    with (LEAF / 'commands.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps({'argv': [str(x) for x in args], 'cwd': str(LEAF), 'started': started,
            'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'exit': r.returncode, 'output': output, 'stderr': r.stderr.decode('utf-8', 'replace')}) + '\n')
    if r.returncode:
        raise RuntimeError((args, r.returncode, r.stderr))
    return r.stdout

identities = {'mapped_jar': {'path': str(JAR), 'bytes': JAR.stat().st_size, 'sha256': sha(JAR)},
    'javap': {'path': str(JAVAP), 'bytes': JAVAP.stat().st_size, 'sha256': sha(JAVAP)},
    'upstream_recipe': {'path': str(UPSTREAM), 'bytes': UPSTREAM.stat().st_size, 'sha256': sha(UPSTREAM)}}
run([str(JAVAP), '-version'], 'javap-version.txt')
classes = ['net.minecraft.server.level.ServerPlayerGameMode', 'net.minecraft.server.network.ServerGamePacketListenerImpl',
    'net.minecraftforge.common.ForgeHooks', 'net.minecraftforge.common.extensions.IForgeItem',
    'net.minecraftforge.common.TierSortingRegistry', 'net.minecraft.world.item.Item',
    'net.minecraft.world.item.Item$Properties', 'net.minecraft.world.item.TieredItem',
    'net.minecraft.world.item.DiggerItem', 'net.minecraft.world.item.PickaxeItem',
    'net.minecraft.world.item.Tiers', 'net.minecraft.world.item.ItemStack',
    'net.minecraft.world.entity.player.Player', 'net.minecraft.world.inventory.AnvilMenu',
    'net.minecraft.world.item.crafting.RepairItemRecipe',
    'net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase']
for c in classes:
    run([str(JAVAP), '-J-Djava.io.tmpdir=' + str(LEAF / 'tmp'), '-classpath', str(JAR), '-c', '-p', c],
        'native/' + c.rsplit('.', 1)[-1].replace('$', '-') + '.txt')
data = UPSTREAM.read_bytes()
(LEAF / 'upstream-recipe-preimage.txt').write_bytes(data)
identities['upstream_recipe']['decoded'] = json.loads(data)
identities['mapped_jar_after'] = sha(JAR)
identities['upstream_recipe_after'] = sha(UPSTREAM)
run(['git', '-C', str(REPO), 'grep', '-n', '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e', COMMIT, '--', 'docs'], 'recorded-mapped-jar-identity.txt')
run(['git', '-C', str(REPO), 'grep', '-n', 'jackhammer', COMMIT, '--', 'legacy-manifest/assets.csv',
    'legacy-manifest/recipes.csv', 'docs/work/v1.8.0-content-ledger.csv', 'docs/work/v1.8.0-asset-plan.csv'], 'jackhammer-ledger-manifest.txt')
(LEAF / 'tool-identities.json').write_text(json.dumps(identities, indent=2), encoding='utf-8')
print(json.dumps({'classes': len(classes), 'mapped_jar': identities['mapped_jar'], 'recipe': identities['upstream_recipe']}, indent=2))
