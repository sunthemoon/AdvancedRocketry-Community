import datetime
import hashlib
import json
import os
import pathlib
import subprocess

L = pathlib.Path(__file__).resolve().parent
R = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
C = 'c583d40b1120bb4f1a22b23740d273dd907beec5'
J = 'C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
P = 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'
os.environ['TEMP'] = os.environ['TMP'] = str(L / 'tmp')

def run(args, target):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    r = subprocess.run(args, cwd=L, capture_output=True)
    with (L / 'commands.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps({'argv': args, 'cwd': str(L), 'started': start,
            'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'exit': r.returncode, 'output': target, 'stderr': r.stderr.decode('utf-8', 'replace')}) + '\n')
    if r.returncode:
        raise RuntimeError((args, r.returncode, r.stderr))
    p = L / target
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(r.stdout)
    return r.stdout

package = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
paths = [package + p for p in ['config/SwitchOverrides.java', 'station/service/StationManager.java',
    'datagen/V180MaterialData.java', 'datagen/V180MaterialRecipes.java', 'datagen/V180MotorData.java',
    'registry/ModMaterialItems.java', 'registry/ModMotorItems.java']]
paths += ['docs/work/v1.8.0-c18-contract/ACCEPTANCE.md',
    'src/generated/v1.8/resources/data/advancedrocketrycommunity/recipes/titanium_rod.json',
    'src/generated/v1.8/resources/data/advancedrocketrycommunity/recipes/iron_rod.json',
    'src/generated/v1.8/resources/data/advancedrocketrycommunity/recipes/motor.json',
    'src/generated/v1.8/resources/data/advancedrocketrycommunity/recipes/rolling/aluminum_plate.json',
    'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/config/SwitchOverridesTest.java']
tree = run(['git', '-C', str(R), 'ls-tree', '-r', '--name-only', C], 'supplement-tree.txt').decode().splitlines()
selected = [p for p in paths if p in tree]
manifest = []
for p in selected:
    data = run(['git', '-C', str(R), 'show', C + ':' + p], 'inputs/' + p)
    manifest.append({'path': p, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
for name in ['net.minecraft.world.level.block.state.BlockBehaviour',
    'net.minecraftforge.common.extensions.IForgeItemStack', 'net.minecraft.server.network.ServerGamePacketListenerImpl$1']:
    run([P, '-J-Djava.io.tmpdir=' + str(L / 'tmp'), '-classpath', J, '-c', '-p', name],
        'native/' + name.rsplit('.', 1)[-1].replace('$', '-') + '.txt')
(L / 'supplement-identities.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps({'captured': selected, 'not_present': [p for p in paths if p not in tree]}, indent=2))
