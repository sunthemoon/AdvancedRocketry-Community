import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

LEAF = pathlib.Path(__file__).resolve().parent
base = (LEAF / 'pure_checks.py').read_text()
modified = base.replace("FROZEN = LEAF / '_tmp' / 'frozen'", "FROZEN = LEAF / '_tmp' / 'revision02'")
modified = modified.replace("COMMIT = '53523bcf68af203934845521e97af2f824b2958d'",
                            "COMMIT = '3b18a6bc8b58424d647053d6c6f1833ba14d9dc7'")
modified = modified.replace("LEAF / 'inputs'", "LEAF / 'revision02' / 'inputs'")
modified = modified.replace("LEAF / 'frozen-tests.log'", "LEAF / 'revision02' / 'frozen-tests.log'")
modified = modified.replace("LEAF / '_tmp' / 'binary-tests'", "LEAF / '_tmp' / 'revision02-binary-tests'")
modified = modified.replace("LEAF / 'pure-commands.json'", "LEAF / 'revision02' / 'pure-commands.json'")
modified = modified.replace("LEAF / 'binary-checks.json'", "LEAF / 'revision02' / 'binary-checks.json'")
modified = modified.replace("rows.append({'name': 'alternate-nonfixture-observation-source',\n"
                            "             'input': console_marker, 'actual_acceptance': driver.observations([console_marker], 'seed')})",
                            "try:\n    driver.observations([console_marker], 'seed')\n    raise AssertionError('Alternate source accepted')\n"
                            "except ValueError as error:\n    rows.append({'name': 'alternate-nonfixture-observation-source',\n"
                            "                 'input': console_marker, 'accepted': False, 'message': str(error)})")
start = datetime.datetime.now(datetime.UTC).isoformat()
namespace = {'__file__': str(LEAF / 'pure_checks.py'), '__name__': '__main__'}
try:
    exec(compile(modified, 'revision02-pure-checks-transformed', 'exec'), namespace)
    code = 0
finally:
    receipt = {'argv': [sys.executable, '-B', str(pathlib.Path(__file__).resolve())],
               'start_utc': start, 'end_utc': datetime.datetime.now(datetime.UTC).isoformat(),
               'base_check_script_sha256': hashlib.sha256(base.encode()).hexdigest(),
               'executed_script_sha256': hashlib.sha256(modified.encode()).hexdigest(),
               'exit': locals().get('code', 1)}
    (LEAF / 'revision02' / 'checks-execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (LEAF / 'revision02' / 'executed-pure-checks.py').write_text(modified)
