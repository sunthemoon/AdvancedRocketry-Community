import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import pathlib
import struct
import subprocess
import sys

LEAF = pathlib.Path(__file__).resolve().parent
FROZEN = LEAF / '_tmp' / 'revision02'
SOURCE = 'D:/GitHub/arce-v180-jackhammer-20261009'
COMMIT = '3b18a6bc8b58424d647053d6c6f1833ba14d9dc7'
records = []

def command(argv, cwd=None):
    start = datetime.datetime.now(datetime.UTC).isoformat()
    p = subprocess.run(argv, cwd=cwd, capture_output=True)
    records.append({'argv': argv, 'cwd': str(cwd) if cwd else None, 'start_utc': start,
                    'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'exit': p.returncode,
                    'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                    'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})
    return p

for name in ['run_dedicated_server_smoke.py', 'inspect_celestial_saved_data.py']:
    p = command(['git', '-C', SOURCE, 'show', COMMIT + ':scripts/' + name])
    assert p.returncode == 0
    destination = LEAF / 'revision02' / 'inputs' / COMMIT[:8] / 'scripts' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(p.stdout)

p = command([sys.executable, '-B', '-m', 'unittest', '-v', 'test_packaged_driver'], FROZEN)
(LEAF / 'revision02' / 'frozen-tests.log').write_bytes(p.stdout + p.stderr)
assert p.returncode == 0

sys.dont_write_bytecode = True
sys.path.insert(0, str(FROZEN))
import packaged_driver as driver
import test_packaged_driver as fixtures

spec = importlib.util.spec_from_file_location('fixed_nbt', LEAF / 'revision02' / 'inputs' / COMMIT[:8] /
                                            'scripts' / 'inspect_celestial_saved_data.py')
nbt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nbt)

def string(value):
    raw = value.encode('utf-8')
    return struct.pack('>H', len(raw)) + raw

def payload(tag):
    t, value = tag
    if t in {1, 2, 3, 4}:
        return struct.pack({1: '>b', 2: '>h', 3: '>i', 4: '>q'}[t], value)
    if t == 8:
        return string(value)
    if t == 9:
        subtype = value[0][0] if value else 0
        assert all(child[0] == subtype for child in value)
        return bytes([subtype]) + struct.pack('>i', len(value)) + b''.join(map(payload, value))
    if t == 10:
        return b''.join(bytes([child[0]]) + string(key) + payload(child)
                        for key, child in value.items()) + b'\0'
    if t in {11, 12}:
        return struct.pack('>i', len(value)) + b''.join(struct.pack('>i' if t == 11 else '>q', v) for v in value)
    raise AssertionError(t)

def encode(root):
    return b'\x0a\0\0' + payload(root)

rows = []
samples = LEAF / '_tmp' / 'revision02-binary-tests'
samples.mkdir()

def check(name, raw, damage=18, expected=True, compressed=None):
    path = samples / (name + '.dat')
    path.write_bytes(gzip.compress(raw, mtime=0) if compressed is None else compressed)
    try:
        saved, observed = driver.read_player(path, nbt, damage)
        result = {'accepted': True, 'observed': observed}
    except Exception as exc:
        result = {'accepted': False, 'exception': type(exc).__name__, 'message': str(exc)}
    result.update(name=name, expected_accept=expected, compressed_bytes=path.stat().st_size,
                  sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    assert result['accepted'] == expected, result
    rows.append(result)

good = encode(fixtures.player())
check('binary-seed', good)
check('binary-continuation', encode(fixtures.player(19)), 19)
check('phase-mismatch', good, 19, False)
wrong = fixtures.player(); wrong[1]['UUID'] = (11, [0, 0, 0, 0])
check('wrong-uuid', encode(wrong), expected=False)
wrong = fixtures.player(); wrong[1]['Inventory'][1][0][1]['Count'] = (3, 1)
check('wrong-count-type', encode(wrong), expected=False)
check('duplicate-root-key', good[:-1] + b'\x03' + string('DataVersion') + struct.pack('>i', 3465) + b'\0', expected=False)
check('trailing-nbt', good + b'\0', expected=False)
check('truncated-nbt', good[:-1], expected=False)
check('bad-gzip', b'', expected=False, compressed=b'not gzip')
check('expanded-limit', b'\0' * (driver.MAX_EXPANDED + 1), expected=False)
check('compressed-limit', b'', expected=False, compressed=b'\0' * (driver.MAX_COMPRESSED + 1))
check('collection-limit', b'\x0a\0\0\x09' + string('Inventory') + b'\x0a'
      + struct.pack('>i', nbt.MAX_COLLECTION_ENTRIES + 1) + b'\0', expected=False)
deep = b'\x0a\0\0' + (b'\x0a\0\x01x' * (nbt.MAX_DEPTH + 2)) + b'\0' * (nbt.MAX_DEPTH + 3)
check('depth-limit', deep, expected=False)

marker = fixtures.row()
console_marker = '[12:34:56] [Server thread/INFO] [minecraft/MinecraftServer]: ' + marker
try:
    driver.observations([console_marker], 'seed')
    raise AssertionError('Alternate source accepted')
except ValueError as error:
    rows.append({'name': 'alternate-nonfixture-observation-source',
                 'input': console_marker, 'accepted': False, 'message': str(error)})

prefix = '[12:34:56] [Server thread/INFO] [minecraft/MinecraftServer]: '
rows.append({'name': 'stop-only-ordering-scope',
             'actual_acceptance': driver.clean_stop([prefix + 'Stopping server',
                                                    prefix + 'ThreadedAnvilChunkStorage: All dimensions are saved'])})

(LEAF / 'revision02' / 'pure-commands.json').write_text(json.dumps(records, indent=2) + '\n')
(LEAF / 'revision02' / 'binary-checks.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'frozen_unittest_exit': p.returncode, 'binary_checks': len(rows), 'results': rows}, indent=2))
