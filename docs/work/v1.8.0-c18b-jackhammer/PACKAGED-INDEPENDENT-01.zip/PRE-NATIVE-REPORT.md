# Findings-first independent frozen harness review

## Findings

### Medium E1 - An alternate non-fixture observation source is accepted

At frozen `packaged_driver.py:24-29,47-58`, `ROW` includes the ordinary
`minecraft/MinecraftServer` logger as an allowed observation source. The fixed
adapter at `53523bcf68af203934845521e97af2f824b2958d` emits its observation with
`System.out.println` from `JackhammerContinuationFixture.run`, not that logger.
The actual independent reproduction in `binary-checks.json` supplies a complete
marker with the MinecraftServer prefix and the validator accepts it. This is an
evidence-parser defect against the assignment's wrong-source rejection, not a
gameplay vulnerability or an observation that a native log was fabricated.

Restrict recognized redirected observations to the fixed fixture source while
retaining only justified raw-output support. Preserve archive 01, this original
finding and any receipts; a correction must be a separately frozen revision.

### Low E2 - HEAD/unstaged-diff checks do not freeze executable helper inputs

At frozen `packaged_driver.py:130-136`, HEAD is checked but `git diff --exit-code`
does not inspect staged changes or untracked files before the working-tree
helpers are imported. The imported helpers are hashed later at lines 192-197;
they are not compared with the fixed Git blobs. An otherwise same-HEAD checkout
can therefore run helper bytes from a different source cohort. This is a static
source-binding limitation; no actual launch-input substitution is asserted.

Before native execution, independently compare the executable driver and both
helper inputs with the frozen archive/fixed Git objects, including actual
staged/untracked input state. This comparison can establish the particular
cohort even though the driver alone does not enforce it.

## Input identities

- Harness repository: `D:/GitHub/AdvancedRocketry-Community`.
- Harness commit: `269ff8c3050e60f6c61794084de533230e7ced67`.
- Adapter/tool repository: `D:/GitHub/arce-v180-jackhammer-20261009`.
- Adapter/tool commit: `53523bcf68af203934845521e97af2f824b2958d`.
- Archive SHA-256:
  `9003334443508f58178f2876d20ad3c9b2f67cfb207f21a15ba6a80b6e361fbb`.
- Driver SHA-256:
  `f1e4f6f194e839c86064e2d88c2ddfa6f68cc0bbf3a57af6b138dac464cb684e`.
- Frozen manifest SHA-256:
  `c80e2526d259b733395f2ea2d5c6fee9d109687ce684ed4a9c44dcd6814a2c14`.

The fixed archive was read with binary `git show`, not from the mutable working
copy. Its six entries and 24,318 uncompressed bytes match the published freeze.
Extraction checked bounded count/size, relative containment, case uniqueness
and no archive symlink; reading every entry verified CRC. Hashes of extracted
entries are retained in `archive-listing.json`.

## Source observations and boundaries

The adapter is separate opt-in compatibility-fixture source. Its command
predicate requires permission four, no command entity and identity of the
underlying native server console. The fixture runs on the server thread with an
offline fixed UUID, constructs a native `ServerPlayer` and connection, and calls
`placeNewPlayer`/`remove`. The continuation branch reads native loaded state and
does not set expected inventory, manually deserialize player NBT or reseed it.
Only the seed branch supplies one diagnostic item. Native action/progress
breaks one stone target, inspects one cobblestone drop and unchanged neighbor,
then checks ordinary held-stack data except expected wear. Temporary target,
neighbor, drops and break-progress are restored/cleared in `finally`.

This supports a designed logout-save/load/continued-native-use diagnostic, not
a network client, FakePlayer execution, preserved mining terrain/loot,
online-stop first save, acquisition progression, universal metadata preservation,
crash durability, V1/V2 or independent native execution. The actual driver must
still establish its artifact/consumer/library/environment bindings and receipts.

The driver's stopped-data reader limits compressed data to 1 MiB and expansion
to 4 MiB. Its fixed NBT helper additionally bounds depth, tags, collection length
and strings, rejects duplicate compound keys/trailing bytes, and the typed stack
validator requires the UUID, survival mode, selected slot zero, exactly one
jackhammer and sampled name/enchantment/unrelated tag with Damage 18 then 19.
The main execution uses explicit readiness/status, command and stop deadlines;
errors preserve a failed receipt and abort only its own process. Native log and
property checks occur after process exit. There is no automatic runtime cleanup.

The inherited Java launch environment is not fully listed by the driver (its
receipt records TEMP/TMP only). The eventual actual-cohort audit must inspect
whether external Java option variables or `win_args.txt` enable unapproved
hooks; this is an unexecuted binding check, not an asserted defect in the
eventual environment.

## Actual independent checks

- `python -B -m unittest -v test_packaged_driver` in the owned frozen extraction:
  eight tests, exit 0. Full output: `frozen-tests.log`; command/UTC receipts:
  `pure-commands.json`.
- `pure_checks.py`: 13 independently encoded gzip/binary-NBT checks, exit 0.
  Two positive reads succeeded; 11 negatives rejected wrong phase/UUID/wire
  type, duplicate/trailing/truncated data, invalid gzip, compressed/expanded
  limits, collection limit and excessive depth. Inputs are synthetic pure-test
  data, not native observations.
- Two further parser probes are recorded separately: alternate-source
  acceptance (E1), and the limited stop-before-completed-save predicate. Native
  explicit save-before-stop is enforced by main's live wait, not inferred from
  that isolated two-line probe.
- Fixed Git reads and retained stdout hashes: `input-commands.json` and
  `pure-commands.json`. Python interpreter observed: 3.13.15.

Initial read-only exploration also checked `git status --short`, branch and
worktrees. Inherited modified/untracked files were not touched. Two exploratory
reads of guessed filenames failed with exit 1 (`docs/versions/v1.8.0.md` and
the guessed ADR-066 basename); actual tree names were resolved and subsequently
read through successful fixed-object commands. No source correction occurred.
Those preliminary tool invocations did not separately capture wall-clock UTC;
the retained fixed-input retrieval and pure checks have actual UTC receipts.

## Verdict and remaining scope

Original frozen harness: changes requested for E1; E2 needs particular-cohort
binding evidence. Adapter semantics in this scoped inspection: no additional
change-required finding identified. Native execution/receipts/artifact and
consumer binding are pending. No Gradle, Minecraft, client or crash test was
launched by this reviewer, and no Gate approval is given.

Only this new independent evidence leaf was written. Fixed repositories,
original archives, Root/other-agent leaves and mutable HEADs remain read-only;
all mutable HEAD/source interests are released. The reviewer remains available
for an exact separate revision or Root receipt audit. Final report, cleanup,
byte counts and relative sealing will follow after that assigned audit scope.
