# Preserved reviewer audit-script failure

The first `python -B audit_native.py` attempt exited 1 at its own line 180:

```text
assert len(library_rows) == 91
AssertionError
```

That expected count was an unsupported reviewer assumption, not a task
requirement, library mismatch or target execution failure. The actual input
manifest contains 104 entries. Before changing the unsealed reviewer script,
its exact original bytes were retained as
`../audit-native-original-assertion-failure.py`, SHA-256
`313855f7aa4f9ad956ec72f24f6684c5b2b318f3658e7db0281062f71d0bdd7d`.

The corrected review enumerates the supplied library list with a 1,000-entry
inspection cap and independently verifies all actual original/copied lengths
and hashes. It does not change target source, native outputs, task assertions,
performance budgets or frozen tests. The subsequent audit exits 0; its actual
UTC/argv/exit/output are in `audit-rerun-COMMAND.json` /`audit-rerun.log`.
The first preliminary audit invocation did not separately capture wall-clock
UTC before this self-assertion; no timestamp is invented for it.
