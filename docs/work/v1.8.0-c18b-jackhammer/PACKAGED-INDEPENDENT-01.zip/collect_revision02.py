import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = 'D:/GitHub/AdvancedRocketry-Community'
SOURCE = 'D:/GitHub/arce-v180-jackhammer-20261009'
HARNESS = '6d75429ab5f4941092216474c7d3d966417d3701'
ADAPTER = '3b18a6bc8b58424d647053d6c6f1833ba14d9dc7'
records = []

def run(argv):
    start = datetime.datetime.now(datetime.UTC).isoformat()
    p = subprocess.run(argv, capture_output=True)
    records.append({'argv': argv, 'start_utc': start,
                    'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'exit': p.returncode,
                    'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                    'stderr': p.stderr.decode('utf-8', errors='replace')})
    assert p.returncode == 0, records[-1]
    return p.stdout

def collect(repo, commit, path):
    b = run(['git', '-C', repo, 'show', commit + ':' + path])
    destination = LEAF / 'revision02' / 'inputs' / commit[:8] / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(b)
    return b

tree = run(['git', '-C', ROOT, 'ls-tree', '-r', '--name-only', HARNESS,
            'docs/work/v1.8.0-c18b-jackhammer']).decode().splitlines()
for path in tree:
    if 'PACKAGED-' in path and path.endswith('.md'):
        collect(ROOT, HARNESS, path)

archive = collect(ROOT, HARNESS, 'docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-02.zip')
assert hashlib.sha256(archive).hexdigest() == 'e93a7da4a4848f6b87761c3f006b673e8157ee1642c53e51c8cceb32ea9a9ca4'
extract = LEAF / '_tmp' / 'revision02'
extract.mkdir(parents=True)
listing = []
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert len(z.infolist()) <= 100
    assert sum(i.file_size for i in z.infolist()) <= 1_000_000
    names = set()
    for i in z.infolist():
        name = pathlib.PurePosixPath(i.filename)
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in i.filename
        assert i.filename.casefold() not in names
        names.add(i.filename.casefold())
        assert i.external_attr >> 28 != 0xA
        b = z.read(i)
        path = extract.joinpath(*name.parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b)
        listing.append({'path': i.filename, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
    hashes = {entry['path']: entry['sha256'] for entry in listing}
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashes[name] == digest

for path in ['src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java',
             'scripts/run_dedicated_server_smoke.py', 'scripts/inspect_celestial_saved_data.py']:
    collect(SOURCE, ADAPTER, path)
diff = run(['git', '-C', SOURCE, 'diff', '53523bcf68af203934845521e97af2f824b2958d', ADAPTER,
            '--', 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java'])
(LEAF / 'revision02' / 'adapter-diff.patch').write_bytes(diff)
old = (LEAF / '_tmp' / 'frozen' / 'packaged_driver.py').read_bytes().decode().splitlines(keepends=True)
new = (extract / 'packaged_driver.py').read_bytes().decode().splitlines(keepends=True)
import difflib
(LEAF / 'revision02' / 'driver-diff.patch').write_text(''.join(difflib.unified_diff(old, new, 'archive01/packaged_driver.py',
                                                                                'archive02/packaged_driver.py')))
(LEAF / 'revision02' / 'input-commands.json').write_text(json.dumps(records, indent=2) + '\n')
(LEAF / 'revision02' / 'archive-listing.json').write_text(json.dumps(listing, indent=2) + '\n')
print(json.dumps(listing, indent=2))
