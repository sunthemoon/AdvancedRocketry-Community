$ErrorActionPreference = 'Stop'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\jackhammer-packaged-independent-20261009-01'
$target = Join-Path $leaf '_tmp'
$record = @{ argv = @('powershell.exe', '-NoProfile', '-File', (Join-Path $leaf 'cleanup-owned.ps1')); started_utc = [DateTime]::UtcNow.ToString('o'); target = $target; attempt = 1; retry_authorized = $false }
try {
    $resolvedLeaf = (Resolve-Path -LiteralPath $leaf).ProviderPath
    $resolvedTarget = (Resolve-Path -LiteralPath $target).ProviderPath
    if ($resolvedTarget -ne (Join-Path $resolvedLeaf '_tmp') -or !$resolvedTarget.StartsWith($resolvedLeaf + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup target containment mismatch' }
    $scan = @(Get-Item -LiteralPath $resolvedLeaf -Force) + @(Get-Item -LiteralPath $resolvedTarget -Force) + @(Get-ChildItem -LiteralPath $resolvedTarget -Force -Recurse)
    $links = @($scan | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
    if ($links.Count -ne 0) { throw 'Cleanup target includes a reparse point' }
    $ancestors = [IO.DirectoryInfo]$resolvedLeaf
    while ($null -ne $ancestors) {
        if ($ancestors.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Cleanup ancestor is a reparse point' }
        $ancestors = $ancestors.Parent
    }
    $processes = @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine.IndexOf($leaf, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
    if ($processes.Count -ne 0) { throw 'A process still references the owned evidence leaf' }
    $record['resolved_target'] = $resolvedTarget
    $record['checked_reparse_points'] = $links.Count
    $record['checked_live_references'] = $processes.Count
    $record['removed_bytes'] = (@($scan | Where-Object { !$_.PSIsContainer }) | Measure-Object Length -Sum).Sum
    Remove-Item -LiteralPath $resolvedTarget -Recurse -Force
    $record['result'] = 'REMOVED'
    $record['exit'] = 0
} catch {
    $record['result'] = 'RETAINED_NO_RETRY'
    $record['error'] = $_.Exception.Message
    $record['exit'] = 1
} finally {
    $record['ended_utc'] = [DateTime]::UtcNow.ToString('o')
    $record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-owned-RESULT.json') -Encoding UTF8
}
$record | ConvertTo-Json -Depth 6
exit $record['exit']
