import collections
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import struct
import subprocess
import sys
import types
import uuid
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01')
OUT = LEAF / 'native02'
OUT.mkdir()
start = datetime.datetime.now(datetime.UTC).isoformat()
reads = []

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def capture(path, relative=None):
    assert path.is_file() and not path.is_symlink() and not path.is_junction(), str(path)
    assert path.stat().st_size <= 20 * 1024 * 1024, str(path)
    b = path.read_bytes()
    reads.append({'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                  'observed_utc': datetime.datetime.now(datetime.UTC).isoformat()})
    if relative is not None:
        dst = OUT / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(b)
    return b

for directory in ['packaged-launch-02', 'packaged-02/seed', 'packaged-02/continue']:
    for path in sorted((ROOT / directory).iterdir()):
        if path.is_file():
            capture(path, path.relative_to(ROOT))
for name in ['inputs.json', 'RESULT.json']:
    capture(ROOT / 'packaged-02' / name, 'packaged-02/' + name)
capture(ROOT / 'launch_packaged.py', 'launch_packaged.py')
inputs = json.loads((OUT / 'packaged-02/inputs.json').read_bytes())
receipts = [json.loads((OUT / 'packaged-02' / phase / 'receipt.json').read_bytes()) for phase in ['seed', 'continue']]
assert receipts == json.loads((OUT / 'packaged-02/RESULT.json').read_bytes())
assert inputs['source_sha'] == '3b18a6bc8b58424d647053d6c6f1833ba14d9dc7'

def load(name, path):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module

driver = load('review_frozen02', LEAF / '_tmp/revision02/packaged_driver.py')
nbt = load('review_nbt02', LEAF / 'revision02/inputs/3b18a6bc/scripts/inspect_celestial_saved_data.py')
server = load('review_server02', LEAF / 'revision02/inputs/3b18a6bc/scripts/run_dedicated_server_smoke.py')

class IndependentReader:
    def __init__(self, raw):
        assert len(raw) <= 4 * 1024 * 1024
        self.raw, self.at, self.nodes = raw, 0, 0
    def take(self, n):
        assert n >= 0 and self.at + n <= len(self.raw)
        b = self.raw[self.at:self.at+n]; self.at += n
        return b
    def num(self, fmt):
        return struct.unpack('>' + fmt, self.take(struct.calcsize('>' + fmt)))[0]
    def string(self):
        n = self.num('H'); assert n <= 65535
        return self.take(n).decode('utf-8')
    def count(self):
        n = self.num('i'); assert 0 <= n <= 4096
        return n
    def value(self, kind, depth=0):
        self.nodes += 1
        assert self.nodes <= 16384 and depth <= 16
        if kind in range(1, 7):
            v = self.num({1:'b', 2:'h', 3:'i', 4:'q', 5:'f', 6:'d'}[kind])
        elif kind == 7:
            v = list(self.take(self.count()))
        elif kind == 8:
            v = self.string()
        elif kind == 9:
            sub, n = self.num('B'), self.count()
            assert sub != 0 or n == 0
            v = [self.value(sub, depth+1) for _ in range(n)]
        elif kind == 10:
            v = {}
            while True:
                sub = self.num('B')
                if sub == 0: break
                key = self.string(); assert key not in v
                v[key] = self.value(sub, depth+1)
        elif kind in (11, 12):
            v = [self.num('i' if kind == 11 else 'q') for _ in range(self.count())]
        else:
            raise ValueError('Unknown type')
        return kind, v
    def root(self):
        kind = self.num('B'); assert kind == 10
        self.string()
        root = self.value(kind)
        assert self.at == len(self.raw)
        return root

summaries = []
inventories = []
for phase, damage, receipt in zip(['seed', 'continue'], [18,19], receipts):
    assert receipt['phase'] == phase and receipt['exit'] == 0
    assert receipt['argv'] == receipts[0]['argv'] and receipt['cwd'] == receipts[0]['cwd']
    assert datetime.datetime.fromisoformat(receipt['started_utc']) < datetime.datetime.fromisoformat(receipt['ended_utc'])
    folder = OUT / 'packaged-02' / phase
    lines = (folder / 'stdout.txt').read_text().splitlines(keepends=True)
    observation = driver.observations(lines, phase)
    assert observation == receipt['observation']
    stop = driver.clean_stop(lines); assert stop == receipt['clean_stop']
    explicit = [i+1 for i,line in enumerate(lines) if server.SAVE_MARKER.search(line)]
    markers = [i+1 for i,line in enumerate(lines) if driver.ROW.fullmatch(line.rstrip('\r\n'))]
    joins = [i+1 for i,line in enumerate(lines) if server.JOIN_MARKER.search(line)]
    assert len(joins) == len(markers) == len(explicit) == 1
    assert joins[0] < markers[0] < explicit[0] < stop['stopping_line'] < stop['saved_after_stop_line']
    assert json.loads((folder / 'commands.json').read_bytes()) == ['arce_jackhammer_test '+phase,'save-all flush','stop']
    raw, decoded = driver.read_player(folder / 'playerdata.dat', nbt, damage)
    assert hashlib.sha256(raw).hexdigest() == receipt['playerdata_sha256']
    assert decoded == json.loads((folder / 'playerdata-observation.json').read_bytes())
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as f:
        expanded = f.read(4*1024*1024+1)
    independent = IndependentReader(expanded).root()
    assert driver.validate_player(independent, damage) == decoded
    inventories.append(independent[1]['Inventory'])
    status = json.loads((folder / 'status.json').read_bytes())
    server.validate_status_identity(status, driver.VERSION)
    assert server.forge_mod_versions(status)['arce_adapter_test'] == '1.0.0'
    log_rows = []
    for filename in ['stdout.txt','latest.log','debug.log']:
        text = (folder / filename).read_text()
        log_lines = text.splitlines(keepends=True)
        counts = server.log_audit_counts(log_lines)
        findings = server.scan_log(log_lines)
        save_warnings = [line.strip() for line in log_lines if server.WARNING_LINE.search(line)
                         and re.search(r"(?:Failed|failed|Couldn't|couldn't|Unable|unable).*player", line)]
        assert not findings and not save_warnings, (phase, filename, findings, save_warnings)
        assert 'Picked up JAVA_TOOL_OPTIONS' not in text and 'Picked up JDK_JAVA_OPTIONS' not in text and 'Picked up _JAVA_OPTIONS' not in text
        warnings = [line.rstrip() for line in log_lines if server.WARNING_LINE.search(line)]
        grouped = collections.Counter(re.sub(r'^\[\d\d:\d\d:\d\d\] ', '', line) for line in warnings)
        log_rows.append({'file': filename, 'counts': counts, 'findings': findings,
                         'player_save_load_warning_count': len(save_warnings),
                         'unbracketed_terminal_warning': text.count('main WARN Advanced terminal features'),
                         'warnings': [{'text': key, 'count': n} for key,n in sorted(grouped.items())]})
        if filename == 'stdout.txt': assert counts == receipt['log_counts']
    summaries.append({'phase': phase, 'pid': receipt['pid'], 'exit': receipt['exit'],
                      'join_line': joins[0], 'observation_line': markers[0], 'explicit_saved_line': explicit[0],
                      'clean_stop': stop, 'decoded': decoded, 'independent_nbt_agrees': True,
                      'compressed_bytes': len(raw), 'expanded_bytes': len(expanded),
                      'playerdata_sha256': hashlib.sha256(raw).hexdigest(), 'logs': log_rows})

assert receipts[0]['pid'] != receipts[1]['pid']
assert datetime.datetime.fromisoformat(receipts[0]['ended_utc']) < datetime.datetime.fromisoformat(receipts[1]['started_utc'])
inventories[0][1][0][1]['tag'][1]['Damage'] = (3,19)
assert inventories[0] == inventories[1], 'Persisted sampled stack differs beyond one durability use'

runtime = pathlib.Path(receipts[0]['cwd'])
library_rows = []
for row in inputs['libraries']:
    relative = pathlib.PurePosixPath(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    original = pathlib.Path(inputs['runtime_template']) / 'libraries' / relative
    installed = runtime / 'libraries' / relative
    for path in [original, installed]:
        assert path.is_file() and not path.is_symlink() and not path.is_junction()
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], str(path)
    library_rows.append(row)
assert len(library_rows) == 91
argsfile = runtime / 'libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt'
argbytes = capture(argsfile, 'actual-win_args.txt')
assert b'arce.' not in argbytes and b'--fml.forgeVersion 47.4.10' in argbytes and b'--fml.mcVersion 1.20.1' in argbytes
props = capture(runtime / 'server.properties', 'actual-server.properties')
actualprops = server.parse_java_properties(props)
assert all(actualprops.get(k) == v for k,v in inputs['configured_properties'].items())
marker = capture(runtime / '.jackhammer-world-identity.json', 'actual-world-marker.json')
assert json.loads(marker)['identity'] == inputs['identity']
capture(runtime / 'world/playerdata' / (driver.UUID + '.dat'), 'actual-final-playerdata.dat')
assert (OUT / 'actual-final-playerdata.dat').read_bytes() == (OUT / 'packaged-02/continue/playerdata.dat').read_bytes()
old = runtime / 'world/playerdata' / (driver.UUID + '.dat_old')
if old.exists():
    oldraw = capture(old, 'actual-predecessor-playerdata.dat')
    assert oldraw == (OUT / 'packaged-02/seed/playerdata.dat').read_bytes()

for dependency in inputs['dependencies']:
    path = pathlib.Path(dependency['path'])
    raw = capture(path)
    assert hashlib.sha256(raw).hexdigest() == dependency['sha256']
    if path.name == 'packaged_driver.py':
        assert raw == (LEAF / '_tmp/revision02/packaged_driver.py').read_bytes()
    else:
        assert raw == (LEAF / 'revision02/inputs/3b18a6bc/scripts' / path.name).read_bytes()

artifacts = []
for row in inputs['artifacts']:
    path = pathlib.Path(row['path'])
    assert digest(path) == row['sha256'] == digest(runtime / 'mods' / row['name'])
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist(); assert len(set(names)) == len(names)
        classes = sorted(n for n in names if n.endswith('.class'))
        if row['mod'] == 'arce_adapter_test':
            assert all(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in classes)
            assert 'io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.class' in classes
        else:
            assert not any(n.startswith('io/github/sunthemoon/arceadaptertest/') for n in classes)
        artifacts.append(dict(row, actual_bytes=path.stat().st_size, class_count=len(classes),
                              jackhammer_fixture_present='io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.class' in classes))

launch = json.loads((OUT / 'packaged-launch-02/RESULT.json').read_bytes())
assert launch['exit'] == 0 and launch['driver_sha256'] == inputs['dependencies'][0]['sha256']
assert launch['log_sha256'] == digest(OUT / 'packaged-launch-02/command.log')
fixture_report = json.loads((OUT / 'packaged-launch-02/fixture-artifact.json').read_bytes())
assert fixture_report['sha256'] == inputs['artifacts'][1]['sha256']
negative = json.loads((OUT / 'packaged-launch-02/negative-import.json').read_bytes())
assert negative['exit_code'] == 1 and negative['inspected_host_sha256'] == inputs['artifacts'][0]['sha256']
assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in negative['diagnostics']
classpath = json.loads((OUT / 'packaged-launch-02/classpath.json').read_bytes())
source_matches = []
for row in classpath['fixture_sources']:
    path = pathlib.Path(row['file'])
    relative = path.relative_to(pathlib.Path('D:/GitHub/arce-v180-jackhammer-20261009')).as_posix()
    p = subprocess.run(['git','-C','D:/GitHub/arce-v180-jackhammer-20261009','show',inputs['source_sha']+':'+relative], capture_output=True)
    assert p.returncode == 0 and hashlib.sha256(p.stdout).hexdigest() == row['sha256'], relative
    source_matches.append({'relative':relative, 'sha256':row['sha256'], 'git_exit':p.returncode})

result = {'result':'SCOPED_NATIVE_EVIDENCE_CORROBORATED', 'source_sha':inputs['source_sha'],
          'harness_commit':launch['harness_commit'], 'phases':summaries, 'artifacts':artifacts,
          'library_files_verified':len(library_rows), 'library_bytes_verified':sum(r['bytes'] for r in library_rows),
          'fixture_source_git_matches':source_matches,
          'sampled_stack_diff_only_damage_18_to_19':True,
          'environment_limit':'TEMP/TMP and Java argv recorded; no JVM injected-option banners in complete logs; full historical environment not captured',
          'native_independent_launch':False}
(OUT / 'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT / 'read-inputs.json').write_text(json.dumps(reads,indent=2)+'\n')
(OUT / 'COMMAND.json').write_text(json.dumps({'argv':[sys.executable,'-B',str(pathlib.Path(__file__).resolve())],
                    'start_utc':start,'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'exit':0},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['phases','fixture_source_git_matches']},indent=2))
print(json.dumps([{'phase':p['phase'],'decoded':p['decoded'], 'markers':[p['join_line'],p['observation_line'],p['explicit_saved_line'],p['clean_stop']],
                  'logs':[{'file':r['file'],'counts':r['counts']} for r in p['logs']]} for p in summaries],indent=2))
