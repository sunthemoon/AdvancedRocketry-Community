import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = 'D:/GitHub/AdvancedRocketry-Community'
SOURCE = 'D:/GitHub/arce-v180-jackhammer-20261009'
HARNESS = '269ff8c3050e60f6c61794084de533230e7ced67'
ADAPTER = '53523bcf68af203934845521e97af2f824b2958d'
records = []

def run(argv):
    start = datetime.datetime.now(datetime.UTC).isoformat()
    p = subprocess.run(argv, capture_output=True)
    records.append({'argv': argv, 'start_utc': start,
                    'end_utc': datetime.datetime.now(datetime.UTC).isoformat(),
                    'exit': p.returncode, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                    'stderr': p.stderr.decode('utf-8', errors='replace')})
    if p.returncode:
        raise RuntimeError(records[-1])
    return p.stdout

def collect(repo, commit, path):
    b = run(['git', '-C', repo, 'show', commit + ':' + path])
    destination = LEAF / 'inputs' / commit[:8] / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(b)
    return b

for path in ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
             'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
             'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
             'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
             'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
             'docs/status/CURRENT_VERSION.md',
             'docs/work/v1.8.0-c18b-jackhammer/TASK-01.md',
             'docs/work/v1.8.0-c18b-jackhammer/ADOPTION-01.md',
             'docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-TASK-01.md',
             'docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-FREEZE-01.md']:
    collect(ROOT, HARNESS, path)

archive = collect(ROOT, HARNESS, 'docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-01.zip')
assert hashlib.sha256(archive).hexdigest() == '9003334443508f58178f2876d20ad3c9b2f67cfb207f21a15ba6a80b6e361fbb'
extract = LEAF / '_tmp' / 'frozen'
extract.mkdir(parents=True)
listing = []
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert len(z.infolist()) <= 100
    assert sum(i.file_size for i in z.infolist()) <= 1_000_000
    names = set()
    for i in z.infolist():
        name = pathlib.PurePosixPath(i.filename)
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in i.filename
        assert i.filename.casefold() not in names
        names.add(i.filename.casefold())
        assert i.external_attr >> 28 != 0xA
        b = z.read(i)
        path = extract.joinpath(*name.parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b)
        listing.append({'path': i.filename, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})

tree = run(['git', '-C', SOURCE, 'ls-tree', '-r', '--name-only', ADAPTER]).decode()
for path in tree.splitlines():
    if ('JackhammerContinuationFixture.java' in path
            or path == 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerItem.java'
            or path == 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterTestMod.java'
            or path == 'build.gradle'
            or ('docs/decisions/' in path and ('ADR-066-' in path or 'ADR-060-' in path))):
        collect(SOURCE, ADAPTER, path)

(LEAF / 'input-commands.json').write_text(json.dumps(records, indent=2) + '\n')
(LEAF / 'archive-listing.json').write_text(json.dumps(listing, indent=2) + '\n')
print(json.dumps(listing, indent=2))
