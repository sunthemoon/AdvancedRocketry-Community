import datetime
import hashlib
import json
import pathlib
import sys
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
OUT = LEAF / 'native02'
ROOT = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01')
start = datetime.datetime.now(datetime.UTC).isoformat()
prefix = 'io/github/sunthemoon/advancedrocketrycommunity/'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for raw in iter(lambda:f.read(1024*1024),b''):h.update(raw)
    return h.hexdigest()

def classes(path):
    with zipfile.ZipFile(path) as z:
        assert len(z.infolist()) <= 100000
        return {i.filename for i in z.infolist() if not i.is_dir() and i.filename.endswith('.class')}

report = json.loads((OUT / 'packaged-launch-02/classpath.json').read_bytes())
published = pathlib.Path(report['published_file'])
raw = pathlib.Path(report['raw_api'])
mapped = pathlib.Path(report['remapped_api'])
assert digest(published) == digest(raw) == report['published_sha256']
assert digest(mapped) == report['remapped_sha256']
assert classes(raw) == classes(mapped)
assert all(n.startswith(prefix+'api/') for n in classes(raw))
rows = []
for row in report['compile_classpath']:
    path = pathlib.Path(row['file'])
    assert path.is_file() and path.suffix == '.jar'
    actual = digest(path); assert actual == row['sha256']
    host = sorted(n for n in classes(path) if prefix in n)
    assert host == row['host_classes']
    if path.resolve() == mapped.resolve(): assert set(host) == classes(raw)
    else: assert host == []
    rows.append(dict(row,actual_bytes=path.stat().st_size))

original = ROOT / 'consumer-04'
for name in ['COMMAND.json','RESULT.json','command.log']:
    b = (original / name).read_bytes()
    assert len(b) <= 5*1024*1024
    (OUT / ('consumer04-'+name)).write_bytes(b)
result = json.loads((OUT / 'consumer04-RESULT.json').read_bytes())
assert result['exit'] == 0
text = (OUT / 'consumer04-command.log').read_text()
assert 'BUILD SUCCESSFUL' in text and '10 actionable tasks: 10 executed' in text

warnings = []
for phase in ['seed','continue']:
    lines = (OUT / 'packaged-02' / phase / 'stdout.txt').read_text().splitlines()
    groups = {}
    details = []
    for line in lines:
        if '/WARN]' not in line: continue
        if 'ForgeConfigSpec/CORE' in line: category='fresh Forge COMMON default corrections'
        elif 'FMLConfig/CORE' in line: category='fresh FML configuration initialization'
        elif 'is missing mods.toml file' in line: category='Forge language/core library metadata'
        elif 'uses unexpected schema' in line: category='Forge union resource URL'
        elif 'minecraft/DedicatedServer' in line: category='explicit offline test-server warnings'
        elif "Can't keep up!" in line:
            category='short startup/save timing overrun'
            details.append(line)
        else:
            category='unclassified'
            details.append(line)
        groups[category]=groups.get(category,0)+1
    assert 'unclassified' not in groups
    warnings.append({'phase':phase,'bracketed_groups':groups,'timing_messages':details,
                     'additional_raw_terminal_warnings':sum('main WARN Advanced terminal features' in l for l in lines)})

audit = {'consumer_actual_root_execution_exit':result['exit'], 'independent_consumer_build_rerun':False,
         'compile_classpath_verified_jars':len(rows), 'compile_classpath_verified_bytes':sum(r['actual_bytes'] for r in rows),
         'api_class_count':len(classes(raw)), 'published_api_sha256':report['published_sha256'],
         'remapped_api_sha256':report['remapped_sha256'], 'classpath_rows':rows,'warning_classification':warnings}
(OUT / 'consumer-AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
(OUT / 'consumer-audit-COMMAND.json').write_text(json.dumps({'argv':[sys.executable,'-B',str(pathlib.Path(__file__).resolve())],
    'start_utc':start,'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'exit':0},indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k != 'classpath_rows'},indent=2))
