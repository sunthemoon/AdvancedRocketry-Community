import datetime
import hashlib
import io
import json
import pathlib
import sys
import zipfile

leaf = pathlib.Path(__file__).resolve().parent
assert not (leaf / 'SHA256SUMS.txt').exists()
assert not (leaf / 'SEAL-RESULT.json').exists()
started = datetime.datetime.now(datetime.UTC).isoformat()
inputs = json.loads((leaf / 'native02/packaged-02/inputs.json').read_bytes())
java = pathlib.Path(inputs['java'])
assert java.is_file() and not java.is_symlink() and not java.is_junction()
actual_java_hash = hashlib.sha256(java.read_bytes()).hexdigest()
assert actual_java_hash == inputs['java_sha256']

for path in [leaf / 'inputs/269ff8c3/docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-01.zip',
             leaf / 'revision02/inputs/6d75429a/docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-02.zip']:
    with zipfile.ZipFile(io.BytesIO(path.read_bytes())) as z:
        assert z.testzip() is None
        for line in z.read('SHA256SUMS.txt').decode().splitlines():
            expected, relative = line.split('  ',1)
            assert hashlib.sha256(z.read(relative)).hexdigest() == expected

checks = {'argv':[sys.executable,'-B',str(pathlib.Path(__file__).resolve())], 'started_utc':started,
          'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(), 'exit':0,
          'actual_java_sha256':actual_java_hash, 'frozen_archive_internal_manifests_verified':2}
(leaf / 'FINAL-CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
tmp_files = [p for p in (leaf / '_tmp').rglob('*') if p.is_file()]
files = sorted(p for p in leaf.rglob('*') if p.is_file() and '_tmp' not in p.relative_to(leaf).parts)
assert all(not p.is_symlink() and not p.is_junction() for p in files)
assert all(p.stat().st_size < 50*1024*1024 for p in files)
payload_bytes = sum(p.stat().st_size for p in files)
result = {'result':'SEALED_SCOPED_INDEPENDENT_REVIEW', 'covered_files':len(files)+1,
          'covered_bytes_excluding_manifest':payload_bytes,
          'unsealed_tmp_files':len(tmp_files),'unsealed_tmp_bytes':sum(p.stat().st_size for p in tmp_files),
          'cleanup':'ONE_NATIVE_POWERSHELL_LAUNCH_POLICY_DENIED_NO_RETRY',
          'report_sha256':hashlib.sha256((leaf / 'REPORT.md').read_bytes()).hexdigest(),
          'native_result':'NARROW_LOGOUT_SAVE_RESTART_LOAD_CONTINUED_USE_CORROBORATED',
          'native_independent_launch':False, 'source_head_interests':'RELEASED',
          'version_required_gates_satisfied':False}
while True:
    encoded = (json.dumps(result,indent=2)+'\n').encode()
    covered = payload_bytes+len(encoded)
    if covered == result['covered_bytes_excluding_manifest']:break
    result['covered_bytes_excluding_manifest']=covered
assert covered < 100*1024*1024
(leaf / 'SEAL-RESULT.json').write_bytes(encoded)
files.append(leaf / 'SEAL-RESULT.json')
files.sort()
manifest = '\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(leaf).as_posix() for p in files)+'\n'
(leaf / 'SHA256SUMS.txt').write_text(manifest,encoding='utf-8')
for line in manifest.splitlines():
    expected, relative = line.split('  ',1)
    path = leaf / relative
    assert path.is_relative_to(leaf) and '_tmp' not in path.relative_to(leaf).parts
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
print(json.dumps(dict(result,manifest_sha256=hashlib.sha256(manifest.encode()).hexdigest(),
                      manifest_bytes=len(manifest.encode())),indent=2))
