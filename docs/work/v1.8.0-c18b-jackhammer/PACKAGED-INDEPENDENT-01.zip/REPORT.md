# Findings-first frozen driver and native receipt review

## Findings and cohort verdicts

1. **Medium E1, original archive 01:** its observation parser accepts an
   ordinary MinecraftServer logger marker, although the fixed fixture emits
   raw/fixed-class stdout. The actual alternate-source reproduction is retained
   in `binary-checks.json`. Source: archive-01 `packaged_driver.py:24-29,47-58`.
2. **Low E2, original archive 01:** its HEAD/unstaged-diff check precedes ambient
   working-tree helper imports and does not compare executable bytes to fixed
   Git objects. Source: archive-01 `packaged_driver.py:130-136,192-197`.
3. **Separate archive 02:** E1/E2 are addressed. The actual archive diff removes
   the non-fixture logger and verifies helper bytes against requested Git blobs
   before compiling/executing those same bytes without source-directory imports
   or bytecode loading. Its source diff also covers staged changes. Nine frozen
   tests and independent negative reproductions corroborate these corrections.
   No new scoped change-required finding was identified in that cohort.
4. **Actual revision-02 native receipts:** independently corroborate the narrow
   native logout-save/restart-load/continued-tool-use diagnostic. No additional
   change-required finding was identified in the bound logs/playerdata/artifact
   audit. This is not an independently launched restart or complete item/Gate
   verdict.

Original `PRE-NATIVE-REPORT.md` and revision-02
`revision02/PRE-NATIVE-REPORT.md` remain separate and unchanged. Archive 01 is
not retrospectively qualified by corrected source or later native receipts.

## Fixed input identities

| Cohort | Fixed identity |
|---|---|
| Original harness | `269ff8c3050e60f6c61794084de533230e7ced67` |
| Original reviewed adapter/tool | `53523bcf68af203934845521e97af2f824b2958d` |
| Separate harness revision 02 | `6d75429ab5f4941092216474c7d3d966417d3701` |
| Actual native adapter/tool target | `3b18a6bc8b58424d647053d6c6f1833ba14d9dc7` |

Archive-01 SHA-256:
`9003334443508f58178f2876d20ad3c9b2f67cfb207f21a15ba6a80b6e361fbb`.
Its driver SHA-256:
`f1e4f6f194e839c86064e2d88c2ddfa6f68cc0bbf3a57af6b138dac464cb684e`.
Archive-02 SHA-256:
`e93a7da4a4848f6b87761c3f006b673e8157ee1642c53e51c8cceb32ea9a9ca4`.
Its driver SHA-256:
`63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e`.

Both archives were independently read via binary fixed-object `git show`, with
bounded/relative/case-unique/symlink-free extraction, CRC and entry hashes.
Original archive has six entries /24,318 expanded bytes; revision 02 has six
entries /27,237 expanded bytes. Actual archive/fixture diffs are retained.
The fixture's scoped 53523bcf-to-3b18a6bc Java delta adds the host GameTest
template namespace only. This review does not replace the separate complete
gameplay-source reviewer.

## Actual source and pure verification

- Read fixed project identity/product/porting/version/test/Gate/parallel/v1+
  governance and the accepted ADR-066 section 5.3 plus leaf task/adoption.
- Original frozen `python -B -m unittest -v test_packaged_driver`: eight tests,
  exit 0. Revision-02 frozen invocation: nine tests, exit 0.
- Each driver cohort additionally received 13 independently encoded gzip and
  typed binary-NBT checks: two positive reads and 11 negative refusals for
  phase/UUID/wire types, duplicates/trailing/truncation, invalid gzip, size,
  collection and depth limits. These are synthetic pure inputs, not native data.
- Revision-02 helper-binding test creates and mutates only its own Git fixture
  beneath the exclusive `_tmp` extraction. No real repository HEAD was moved.
- Actual commands/UTC/exits/hashes: `input-commands.json`, `pure-commands.json`,
  `revision02/input-commands.json`, `revision02/pure-commands.json`, and
  `revision02/checks-execution.json`; actual full test outputs are retained.

The adapter console predicate requires permission four, no command entity and
native server-console source identity. It executes on the server thread with
its fixed offline UUID, uses native `ServerPlayer`/connection/`placeNewPlayer`
and logout `remove`, and continuation never reseeds inventory or manually loads
NBT. Ordinary action/progress breaks one stone and inspects one cobblestone
plus unchanged neighbor; held-stack data is compared except for one damage use.
Target/neighbor/drop/progress cleanup is exception-safe and intentionally does
not preserve mined terrain/loot as its persistence result.

## Actual Root native evidence independently inspected

Original immutable Root inputs were copied read-only from
`jackhammer-root-20261009-01/packaged-02` and `packaged-launch-02` into `native02`.
Actual source read identities are in `native02/read-inputs.json`; audit outputs
are `native02/AUDIT.json` and `native02/consumer-AUDIT.json`.

The wrapper actually ran from `2026-10-09T02:59:12.689471Z` to
`2026-10-09T03:00:09.309058Z`, exit 0. Its archive/driver identity matches the
separately committed revision 02. Native PIDs were 27148 and 20452, distinct
and sequential; both process receipts have exit 0, identical argv/artifacts/cwd
and no overlap in recorded start/end times.

| Actual stopped data /full stdout | Seed | Continue |
|---|---:|---:|
| Native join line | 187 | 64 |
| Exact single observation line | 188 | 65 |
| Explicit `Saved the game` line | 200 | 77 |
| Native `Stopping server` line | 204 | 81 |
| Completed all-dimensions save line | 225 | 102 |
| Compressed playerdata bytes | 840 | 884 |
| Saved Damage | 18 | 19 |
| Bracketed WARN headers per stdout/latest/debug log | 113 | 11 |
| ERROR /FATAL /project findings per full log | 0 /0 /0 | 0 /0 /0 |

Commands are exactly the stage command, `save-all flush`, then `stop`. Each
full stdout has one native join and one exact raw fixture marker in the stated
order, no malformed/duplicate/wrong-stage/UUID observation. The raw marker form
is actually observed, not inferred from the redirected-log regex.

Native data was decoded independently by the frozen bounded reader and a second
reviewer-written bounded typed reader. Both agree on UUID
`914adf94-5147-49a3-bf78-ff21cd948719`, DataVersion 3465, survival game mode,
selected slot zero, exactly one jackhammer in slot zero, count one, sampled
custom name `Jackhammer restart`, efficiency II and unrelated note
`native continuation`. Persisted inventory structures differ only by Damage
18 to 19. The actual final runtime `.dat` equals the retained continuation file;
its native predecessor `.dat_old` equals the retained seed file.

Seed playerdata SHA-256:
`5e71a8c8be626c391062ab4116d0dbc8f1078d7f7197168ca898cebe015dbe6e`.
Continuation playerdata SHA-256:
`dcb8f084bec60e7a37920d200a02ea72f2df5d9788efba292279bc7b2ae1e004`.

All actual stdout/latest/debug logs were rescanned, not just the wrapper PASS.
No player save/load failure warning or client linkage finding was found. Seed
WARNs comprise 101 fresh COMMON default corrections, one fresh FML correction,
four Forge library metadata warnings, two union-resource warnings, four explicit
offline-mode warnings and one 2,073 ms timing overrun. Continue has the same
metadata/union/offline groups plus one 2,430 ms timing overrun. Each stdout also
has one raw, unbracketed terminal-feature warning outside those header counts.
All are retained; these short timing messages are not performance qualification.

## Actual artifact, consumer and runtime binding

Host SHA-256:
`0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011`.
Fixture SHA-256:
`92f31fbf73604e480be41fe028c4cda2d5c6e6e002a003ba5d3b127eb0295f76`.
Actual installed copies match those artifacts; CRC/unique entries and fixture
class boundaries were independently checked. The diagnostic fixture is absent
from the normal host JAR and present only in the separate compat fixture.

All 104 listed runtime-template/copied library files (166,368,435 bytes) match
their recorded lengths/hashes. Actual `win_args.txt` identifies Forge 47.4.10
/Minecraft 1.20.1, contains no `arce.` hook flag and is retained. Actual properties
match fresh loopback-only offline survival settings, RCON/query disabled, with
the same-world marker matching its recorded identity. Java is the recorded
17.0.7 executable. Actual driver and both helper bytes match frozen/fixed inputs.

The independent compat-consumer report binds 38 actual fixture source files to
fixed Git blobs and 114 actual dependency JAR hashes (100,353,199 bytes). The
published/remapped API class surfaces both have 29 API-only classes; no other
classpath JAR supplies host implementation classes. The actual negative compile
report has the required missing internal-package diagnostic /exit 1 against
the bound normal host. Actual Root consumer output reports ten executed tasks,
build success /exit 0; no reviewer Gradle or negative compiler rerun is claimed.

Published API SHA-256:
`aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
Remapped API SHA-256:
`a04dbac3aa097869f9f47eb57c619acdc1d62925f6d8e489820c68796e7aee6e`.

Historical environment is not fully captured: receipts record TEMP/TMP and Java
argv, and complete captured logs contain no Java injected-option banners. The
actual argument file has no additional project hook flag. This is narrower
than asserting every historical environment variable was independently recorded.

## Reviewer failures, cleanup and evidence hygiene

One reviewer audit attempt exited 1 on an unsupported expected library count
of 91. Its exact original script and explanation are retained; corrected bounded
enumeration verifies all 104 actual entries. This was not a target failure,
source change, assertion relaxation in frozen tests or Gate-budget change.
Initial guessed-name exploratory reads also failed and were replaced by actual
fixed-tree names. Preliminary exploratory/failing audit calls without separate
UTC capture are explicitly noted rather than assigned invented timestamps.

The single native PowerShell own-`_tmp` cleanup launcher was denied before script
loading; containment/reparse/process checks and removal therefore did not run.
No retry, shell/policy bypass or Root takeover occurred. `CLEANUP-DENIAL.md`
retains the exact failure/boundary. Unsealed retained `_tmp`: 67 files,
2,189,759 bytes. It is excluded from the compact final manifest.

Final compact retained-file count and exact covered-byte count, including the
seal result but excluding the manifest's own bytes, are recorded once in
`SEAL-RESULT.json`. `SHA256SUMS.txt` covers only relative retained evidence in
this leaf, never mutable `build`, Root runtime, other leaves or `_tmp` inputs.

## Completion and open boundaries

Completed: original frozen driver/adapter-semantic review, separate corrective
cohort review, independent pure/binary checks, and actual bound two-process
logs/playerdata/consumer/runtime evidence inspection. No production/source,
central/state/ledger, existing archive or other-agent file was modified.

Not executed by this reviewer: Gradle/Minecraft/native restart, real client,
GPU/multiplayer, crash/forced-stop, survival acquisition, above-tier/mod
interaction, migration or performance qualification. Root's separate reported
full source build/GameTest totals are not independently established by this
packaged-receipt review. The player inventory continuation claim does not
include online-stop first save, preserved mining terrain/loot or arbitrary
metadata preservation.

No item/asset delivery, owner policy, ADR acceptance, release/tag or G0-G9
approval is inferred. Full current-version Required Gates are not satisfied by
this slice. Remaining work is the current jackhammer leaf's separate source,
acquisition/interaction/client/provenance obligations and the current v1.8
Gate backlog, not an unrelated future feature.

All Main/tool mutable HEAD/source interests are released. All fixed repository,
Root and other-agent inputs remained read-only. Only this exclusive new leaf
was written; no subagent/Claude or external network target was invoked.
