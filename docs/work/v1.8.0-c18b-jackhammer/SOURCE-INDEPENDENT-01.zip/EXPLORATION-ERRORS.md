# Reviewer exploration errors (not product/test outcomes)

These are retained from the tool-call transcript. The preliminary exploration
commands predate the replay logger; their exact UTC start/end was not captured.
That metadata gap is explicit, not filled with guessed timestamps. The fixed
snapshot UTC is in inputs.txt. All qualification commands have actual argv,
cwd, UTC times, process ID and exit in commands.jsonl.

1. Tool chunk 45ed86; cwd D:/GitHub/AdvancedRocketry-Community; compound
   PowerShell exit 1. `Get-Content -LiteralPath` included
   `D:/GitHub/arce-v180-jackhammer-20261009/docs/versions/v1.8.0.md`.
   Error: Cannot find path because it does not exist. The committed tree was
   then enumerated; the actual file is V1.8.0-CLASSIC-CONTENT-COMPLETION.md.
2. Tool chunk a0b76d; cwd the owned _tmp/repo; compound PowerShell exit 1.
   `Get-Content -LiteralPath` included
   `docs/work/v1.8.0-c18b-jackhammer/CONTRACT-REVIEW-REPORT-01.md`.
   Error: Cannot find path because it does not exist. The existing committed
   CONTRACT-REVIEW-01.zip supplied the report and tool identities instead.
3. Tool chunk 88af86; cwd the owned _tmp/repo; compound PowerShell exit 1.
   `Get-Command java,javap,python,git` reported that `javap` is not recognized.
   The archive identifies the existing Java17 absolute executable, whose bytes
   and version were verified before execution; PATH/global config was not changed.
4. Tool chunk aa3b37; cwd the owned _tmp/repo; compound PowerShell exit 0 with
   a nonterminating read error. `Get-Content` attempted
   `docs/provenance/v1.8.0-c18b-jackhammer-source-registration.md`.
   Error: Cannot find path because it does not exist. The tree enumeration
   supplied the actual preauthoring.md file, later read.
5. Tool chunk d1f356; cwd the owned _tmp/repo; compound PowerShell exit 0 with
   a nonterminating read error. `Get-Content` attempted
   `docs/decisions/ADR-066-CLASSIC-EQUIPMENT-AND-LIFE-SUPPORT.md`.
   Error: Cannot find path because it does not exist. The enumerated committed
   file is ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md.
6. Tool chunk 84c61e; cwd the owned _tmp/repo; compound PowerShell exit 0.
   `rg -n 'add_argument|def main|write_text|mkdir'` and `Get-Content` included
   `tools/import/verify_provenance.py`. rg reported OS error 2 and Get-Content
   reported Cannot find path because it does not exist. Enumeration showed the
   actual importer; independent byte/digest checks were performed in static_review.py.
7. Tool chunk 5b717d; cwd the owned _tmp/repo; compound PowerShell exit 0.
   `rg -n 'content_digest|PENDING_HUMAN_REVIEW|schema_version|digest' tools/audit/*.py`
   reported OS error 123: The filename, directory name, or volume label syntax
   is incorrect. No result was interpreted as a successful provenance scan.
8. Tool chunk b35109; cwd the owned _tmp/repo; compound PowerShell exit 0.
   `Get-Content src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/StationManager.java`
   reported Cannot find path because it does not exist.
9. Tool chunk 520410; cwd the owned _tmp/repo; compound PowerShell exit 1.
   `rg -n 'BUILD|onBlockBreak|BreakEvent' src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/forge/StationManager.java`
   reported OS error 2. The committed enumeration showed station/service/StationManager.java,
   which was read; no wrong-path read is counted as a protection review.
10. Tool chunk 34c26d; cwd the owned _tmp/repo; compound PowerShell exit 1.
    `Get-Content ../../repository.log -Tail 8` was attempted before the
    sequential qualification runner had created that file. The read reported
    Cannot find path because it does not exist. This was an observation-timing
    error, not a failed/successful execution of the strict validator; its actual
    later command/result remains separately recorded in commands.jsonl.

The preliminary exploration had no access denial, cleanup failure, install,
alternate-shell retry or policy bypass. A later distinct cache cleanup was
denied and is separately retained in CACHE-CLEANUP-DENIAL.md. Correcting a
nonexistent filename by enumerating fixed inputs
does not change the product/test inputs. None of these errors is suppressed or
counted as a passed check. Long exploration output was occasionally truncated
by the tool output budget; substantive source/native sections were subsequently
read in narrower slices. Qualification raw files are not truncated.
