"""Read-only fixed-source qualification; all disposable writes are in owned _tmp."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

LEAF = Path(__file__).resolve().parent
REPO = LEAF / '_tmp/repo'
JAVA = Path('C:/Program Files/Java/jdk-17.0.7')
TMP = LEAF / '_tmp/temp'
TMP.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV.update(JAVA_HOME=str(JAVA), TEMP=str(TMP), TMP=str(TMP),
           JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + str(TMP))
ENV['PATH'] = str(JAVA / 'bin') + os.pathsep + ENV['PATH']

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(label, argv):
    log = LEAF / (label + '.log')
    start = utc()
    with log.open('wb') as stream:
        child = subprocess.Popen(list(map(str, argv)), cwd=REPO, env=ENV,
                                 stdout=stream, stderr=subprocess.STDOUT)
        with (LEAF / 'process-starts.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(dict(label=label, pid=child.pid, argv=list(map(str, argv)), start_utc=start)) + '\n')
        code = child.wait()
    record = dict(label=label, argv=list(map(str, argv)), cwd=str(REPO),
                  start_utc=start, end_utc=utc(), exit=code, pid=child.pid,
                  log=log.name, fixed_commit='61cada9e6042e0149a96a7d97a485bd3996b58db')
    with (LEAF / 'commands.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(record) + '\n')
    print(json.dumps(record), flush=True)
    return code

def cohort(label):
    dest = LEAF / ('xml-' + label)
    dest.mkdir()
    summaries = []
    for source in sorted((REPO / 'build/test-results/test').glob('TEST-*.xml')):
        shutil.copyfile(source, dest / source.name)
        root = ET.parse(source).getroot()
        summaries.append(dict(file=source.name, sha256=sha(source), **root.attrib))
    (LEAF / ('cohort-' + label + '.json')).write_text(json.dumps(summaries, indent=2), encoding='utf-8')

def space(label):
    record = dict(utc=utc(), label=label, disks={d: shutil.disk_usage(d)._asdict() for d in ['C:/', 'D:/']})
    with (LEAF / 'disk-space.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(record) + '\n')
    if any(v['free'] < 10 * 1024**3 for v in record['disks'].values()):
        raise RuntimeError('Insufficient disk space; no sustained work started')

def main():
    run('git-version', ['git', '--version'])
    run('python-version', [sys.executable, '--version'])
    run('java-version', [JAVA / 'bin/java.exe', '-version'])
    run('javap-version', [JAVA / 'bin/javap.exe', '-version'])
    run('fixed-inputs', ['git', 'rev-parse', 'HEAD', '106d31653f8bce66761c919742629a75a047e2ca'])
    run('owned-status-before', ['git', 'status', '--short'])
    with zipfile.ZipFile(REPO / 'docs/work/v1.8.0-c18b-jackhammer/CONTRACT-REVIEW-01.zip') as z:
        tools = json.loads(z.read('tool-identities.json'))
    actual = {}
    for key in ['mapped_jar', 'javap', 'upstream_recipe']:
        path = Path(tools[key]['path'])
        actual[key] = dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))
        assert actual[key]['sha256'] == tools[key]['sha256'], (key, actual[key])
    actual['java'] = dict(path=str(JAVA / 'bin/java.exe'), sha256=sha(JAVA / 'bin/java.exe'))
    actual['gradle_wrapper'] = {p: sha(REPO / p) for p in ['gradlew.bat', 'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties']}
    (LEAF / 'tool-identities.json').write_text(json.dumps(actual, indent=2), encoding='utf-8')
    jar = Path(actual['mapped_jar']['path'])
    for cls in ['net.minecraft.server.level.ServerPlayerGameMode', 'net.minecraftforge.common.ForgeHooks',
                'net.minecraft.world.item.DiggerItem', 'net.minecraft.world.inventory.AnvilMenu',
                'net.minecraft.world.item.TieredItem', 'net.minecraft.world.item.Item$Properties',
                'net.minecraft.world.item.PickaxeItem', 'net.minecraft.world.item.Tiers',
                'net.minecraftforge.common.TierSortingRegistry', 'net.minecraft.world.entity.player.Player']:
        run('native-' + cls.rsplit('.', 1)[1].replace('$', '-'), [JAVA / 'bin/javap.exe', '-p', '-c', '-classpath', jar, cls])
    gradle = [REPO / 'gradlew.bat', '--no-daemon', '--no-build-cache', '--rerun-tasks']
    space('clean-build')
    run('build-01', gradle + ['clean', 'build'])
    cohort('build-01')
    artifact = {str(p.relative_to(REPO)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (REPO / 'build/libs').glob('*.jar')}
    (LEAF / 'artifact-hashes.json').write_text(json.dumps(artifact, indent=2), encoding='utf-8')
    space('forced-test')
    run('test-01', gradle + ['test'])
    cohort('test-01')
    for n in [1, 2]:
        space('runData-' + str(n))
        run('data-0' + str(n), gradle + ['runData'])
        run('data-diff-0' + str(n), ['git', 'diff', '--exit-code'])
        run('data-status-0' + str(n), ['git', 'status', '--short'])
    space('unfiltered-GameTest')
    run('gametest-01', gradle + ['runGameTestServer'])
    for name in ['latest.log', 'debug.log']:
        source = REPO / 'build/gametest/logs' / name
        if source.exists():
            shutil.copyfile(source, LEAF / ('gametest-' + name))
    run('ledger', [sys.executable, 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
    run('bootstrap-provenance', [sys.executable, 'scripts/validate_bootstrap_provenance.py', '--require-approved-review'])
    run('repository', [sys.executable, 'scripts/validate_repository.py', '--require-approved-identity'])
    run('whitespace', ['git', 'diff', '--check', '106d31653f8bce66761c919742629a75a047e2ca', '61cada9e6042e0149a96a7d97a485bd3996b58db'])
    run('owned-status-after', ['git', 'status', '--short'])
    print('QUALIFICATION_COMMANDS_FINISHED', flush=True)

if __name__ == '__main__':
    main()
