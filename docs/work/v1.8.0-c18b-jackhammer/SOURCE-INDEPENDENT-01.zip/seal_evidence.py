"""Seal compact retained evidence; do not retry cleanup of the denied own cache."""
import datetime
import hashlib
import json
from pathlib import Path

leaf = Path(__file__).resolve().parent
manifest = leaf / 'SHA256SUMS.txt'
if manifest.exists():
    raise RuntimeError('Existing seal must not be modified')
if (leaf / '_tmp').exists():
    raise RuntimeError('Private clone/disposable _tmp remains')
if 'Result is completed below' in (leaf / 'REPORT.md').read_text(encoding='utf-8'):
    raise RuntimeError('Unfinished report')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

residual = [p for p in (leaf / '__pycache__').rglob('*') if p.is_file()]
files = sorted((p for p in leaf.rglob('*') if p.is_file()
                and '__pycache__' not in p.relative_to(leaf).parts
                and p.name not in ['SHA256SUMS.txt', 'seal-summary.json']),
               key=lambda p: p.relative_to(leaf).as_posix())
summary = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    covered_payload_files_excluding_summary_manifest=len(files),
    covered_payload_bytes_excluding_summary_manifest=sum(p.stat().st_size for p in files),
    maximum_retained_file_bytes=max(p.stat().st_size for p in files),
    unsealed_residual_bytes=sum(p.stat().st_size for p in residual),
    unsealed_residual=[dict(path=p.relative_to(leaf).as_posix(), bytes=p.stat().st_size, sha256=sha(p)) for p in residual],
    private_copy_remaining=False, cleanup_denial_no_retry=True,
    main_root_source_head_interests='RELEASED',
    residual_outputs_outside_owned_leaf=0)
assert summary['covered_payload_bytes_excluding_summary_manifest'] < 100 * 1024**2
assert summary['maximum_retained_file_bytes'] <= 50 * 1024**2
assert summary['unsealed_residual_bytes'] == 11353
(leaf / 'seal-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
files.append(leaf / 'seal-summary.json')
files.sort(key=lambda p: p.relative_to(leaf).as_posix())
names = [p.relative_to(leaf).as_posix() for p in files]
assert len({n.casefold() for n in names}) == len(names)
manifest.write_text(''.join(sha(p) + '  ' + p.relative_to(leaf).as_posix() + '\n' for p in files), encoding='utf-8')
for line in manifest.read_text().splitlines():
    digest, name = line.split('  ', 1)
    p = leaf / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert p.resolve().is_relative_to(leaf)
    assert sha(p) == digest
print(json.dumps(dict(summary=summary, manifest_files=len(files), manifest_sha256=sha(manifest),
                     report_sha256=sha(leaf / 'REPORT.md'),
                     total_retained_bytes_with_manifest=sum(p.stat().st_size for p in files)+manifest.stat().st_size), indent=2))
