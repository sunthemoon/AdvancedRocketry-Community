"""Summarize actual retained logs and fixed-source supplemental identities."""
import hashlib
import json
import re
import subprocess
from qualify import LEAF, REPO, sha, utc

additional = ['docs/work/v1.8.0-asset-plan.csv', 'scripts/validate_v180_content_ledger.py',
              'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/SwitchOverrides.java',
              'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationManager.java']
ids = []
for name in additional:
    b = subprocess.check_output(['git', '-C', str(REPO), 'show', '61cada9e:' + name])
    path = LEAF / 'inputs' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b)
    ids.append(dict(path=name, sha256=sha(path), bytes=len(b),
                    unchanged_from_adoption_base=b == subprocess.check_output(['git', '-C', str(REPO), 'show', '106d3165:' + name])))
(LEAF / 'supplement-identities.json').write_text(json.dumps(ids, indent=2), encoding='utf-8')
summary = dict(utc=utc(), unit={}, gradle={}, native={})
for label in ['build-01', 'test-01']:
    cohort = json.loads((LEAF / ('cohort-' + label + '.json')).read_text())
    summary['unit'][label] = dict(suites=len(cohort), **{k: sum(int(x[k]) for x in cohort) for k in ['tests', 'failures', 'errors', 'skipped']})
    summary['unit'][label]['failed_suites'] = [c['name'] for c in cohort if int(c['failures']) or int(c['errors'])]
for label in ['build-01', 'test-01', 'data-01', 'data-02', 'gametest-01']:
    lines = (LEAF / (label + '.log')).read_text(encoding='utf-8', errors='replace').splitlines()
    summary['gradle'][label] = dict(tasks=[line for line in lines if line.startswith('> Task ')],
        final_markers=[line for line in lines if line.startswith(('BUILD ', 'FAILURE:', '18 actionable', '24 actionable', '25 actionable', '26 actionable', '10 actionable'))],
        from_cache=sum('FROM-CACHE' in line for line in lines), up_to_date=sum('UP-TO-DATE' in line for line in lines),
        skipped=sum(' SKIPPED' in line for line in lines))
native = (LEAF / 'gametest-latest.log').read_text(encoding='utf-8')
summary['native'] = dict(completion_markers=[l for l in native.splitlines() if 'GAME TESTS COMPLETE' in l or 'required tests failed' in l],
     batches=len(re.findall(r'Running test batch .*?\((\d+) tests\)',native)),
     batch_test_sum=sum(map(int,re.findall(r'Running test batch .*?\((\d+) tests\)',native))),
     failures=[l for l in native.splitlines() if 'LogTestReporter' in l and ' failed!' in l])
tools = json.loads((LEAF / 'tool-identities.json').read_text())
summary['native_input_hashes_after'] = {k: sha(__import__('pathlib').Path(tools[k]['path'])) for k in ['mapped_jar','javap','upstream_recipe']}
(LEAF / 'actual-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
