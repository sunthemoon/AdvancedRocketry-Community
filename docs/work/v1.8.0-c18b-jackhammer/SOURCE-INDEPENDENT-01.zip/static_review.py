"""Fixed-source data/hash/artifact observations, independent of implementation tests."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

from qualify import LEAF, REPO, sha, run

def blob(path, commit='61cada9e6042e0149a96a7d97a485bd3996b58db'):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', commit + ':' + path])

def main():
    changed = subprocess.check_output(['git', '-C', str(REPO), 'diff', '--name-only',
                '106d31653f8bce66761c919742629a75a047e2ca', '61cada9e6042e0149a96a7d97a485bd3996b58db'], text=True).splitlines()
    extra = ['src/test/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfigTest.java',
             'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/V180MaterialArt.java',
             'docs/provenance/v1.8.0-c18b-jackhammer-preauthoring.md',
             'docs/work/v1.8.0-c18b-jackhammer/TASK-01.md',
             'docs/work/v1.8.0-c18b-jackhammer/ADOPTION-01.md']
    identities = []
    for path in changed + extra:
        data = blob(path)
        target = LEAF / 'inputs' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        identities.append(dict(path=path, bytes=len(data), sha256=sha(target),
                          git_blob=subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', '61cada9e:' + path], text=True).strip()))
    (LEAF / 'input-identities.json').write_text(json.dumps(identities, indent=2), encoding='utf-8')
    provenance = json.loads((REPO / 'docs/provenance/v1.8.0-c18b-jackhammer.json').read_text(encoding='utf-8'))
    core = {k: v for k, v in provenance.items() if k != 'review'}
    digest = hashlib.sha256((json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode()).hexdigest()
    results = {'provenance_content_digest_actual': digest,
               'provenance_content_digest_matches': digest == provenance['review']['content_digest'],
               'provenance_file_sha256': sha(REPO / 'docs/provenance/v1.8.0-c18b-jackhammer.json'),
               'pending_human_review': provenance['review']['status'] == 'PENDING_HUMAN_REVIEW',
               'entries': []}
    for e in provenance['entries']:
        check = dict(target=e['target_path'], target_sha256=sha(REPO / e['target_path']))
        check['target_hash_matches'] = check['target_sha256'] == e['target_sha256']
        if e['status'] == 'NEW':
            source_hash = sha(REPO / e['source_path'])
            check.update(source_sha256=source_hash, source_hash_matches=source_hash == e['source_sha256'])
        results['entries'].append(check)
    languages = {}
    for lang in ['en_us', 'zh_cn']:
        path = 'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/' + lang + '.json'
        old = json.loads(blob(path, '106d31653f8bce66761c919742629a75a047e2ca'))
        new = json.loads(blob(path))
        languages[lang] = dict(existing_values_unchanged=all(new[k] == v for k, v in old.items()),
                               added={k: v for k, v in new.items() if k not in old}, removed=sorted(set(old)-set(new)))
    results['language_comparison'] = languages
    results['generated_json'] = {e['target_path']: json.loads((REPO / e['target_path']).read_text(encoding='utf-8'))
                                for e in provenance['entries'] if e['target_path'].endswith('.json') and '/lang/' not in e['target_path']}
    # Decode using the existing byte decoder, then compare actual pixels against arithmetic from the source.
    sys.path.insert(0, str(REPO / 'tools/audit'))
    import vanilla_derivation as d
    png = REPO / 'src/generated/v1.8/resources/assets/advancedrocketrycommunity/textures/item/jackhammer.png'
    width, height, rgba = d.decode_rgba(png.read_bytes())
    rows = ['................','..222222222222..','..299222222992..','..222267762222..',
            '.....269962.....','.....268862.....','.....267762.....','.....266662.....',
            '......2772......','......2992......','......2992......','......2882......',
            '.......99.......','.......77.......','.......55.......','................']
    greys = [20,44,72,93,117,141,169,191,210,238]
    expected = bytes(v for row in rows for c in row for v in
                     ([0,0,0,0] if c == '.' else [greys[int(c)]*189//255, greys[int(c)]*208//255, greys[int(c)]*222//255,255]))
    results['png'] = dict(width=width, height=height, opaque=sum(rgba[i] != 0 for i in range(3,len(rgba),4)),
                          exact_adopted_pixels=bytes(rgba) == expected, bytes=png.stat().st_size, sha256=sha(png))
    client = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_repo/versions/1.20.1/client.jar')
    screen_root = LEAF / '_tmp/art'
    screen_root.mkdir(exist_ok=True)
    shutil.copyfile(png, screen_root / 'jackhammer.png')
    results['screen_client'] = dict(path=str(client), bytes=client.stat().st_size, sha256=sha(client))
    (LEAF / 'static-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    run('original-art-screen-1201', [sys.executable, 'tools/audit/screen_generated_art.py', '--root', screen_root,
         '--vanilla', '1.20.1=' + str(client), '--output', LEAF / 'art-screen-1201.json'])
    print(json.dumps(results, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
