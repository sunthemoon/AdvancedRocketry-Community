"""Replay reported-link attribution against the two fixed Git commits."""
import json
import re
import subprocess
from qualify import LEAF, REPO

text = (LEAF / 'repository.log').read_text()
matches = re.findall(r'(docs/[^:;]+\.md):(\d+) -> ([^;\n]+)', text)
cache = {}
out = []
for file, line, diagnostic in matches:
    if file not in cache:
        cache[file] = subprocess.check_output(['git', '-C', str(REPO), 'show', '61cada9e:' + file]) == subprocess.check_output(['git', '-C', str(REPO), 'show', '106d3165:' + file])
    out.append(dict(file=file, line=int(line), diagnostic=diagnostic, unchanged_from_adoption_base=cache[file]))
result = dict(reported_entries=len(out), unique_files=len(cache), all_reported_source_files_unchanged=all(cache.values()), entries=out)
(LEAF / 'link-attribution.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'entries'}))
