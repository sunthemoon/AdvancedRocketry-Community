"""Observe candidate archive identities/owned resource bytes without retaining JARs."""
from collections import Counter
import json
import zipfile
from qualify import LEAF, REPO, sha

provenance = json.loads((REPO / 'docs/provenance/v1.8.0-c18b-jackhammer.json').read_text())
result = {}
for path in sorted((REPO / 'build/libs').glob('*.jar')):
    entry = dict(bytes=path.stat().st_size, sha256=sha(path))
    with zipfile.ZipFile(path) as archive:
        counts = Counter(archive.namelist())
        entry['duplicate_entries'] = {k: v for k, v in counts.items() if v > 1}
        entry['license_notice'] = {n: n in counts for n in ['META-INF/LICENSE', 'META-INF/NOTICE.md']}
        entry['jackhammer_entries'] = [n for n in counts if 'jackhammer' in n.lower()]
        if not path.name.endswith(('-api.jar', '-sources.jar')):
            entry['owned_resource_bytes_match_source'] = {}
            for e in provenance['entries']:
                n = e['target_path'].split('src/generated/v1.8/resources/', 1)[1]
                entry['owned_resource_bytes_match_source'][n] = archive.read(n) == (REPO / e['target_path']).read_bytes()
    result[path.name] = entry
(LEAF / 'artifact-inspection.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
