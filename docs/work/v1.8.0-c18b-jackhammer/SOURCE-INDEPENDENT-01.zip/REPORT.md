# C18b-JACKHAMMER-01 independent actual-source review

## Findings first — CHANGES_REQUESTED for the fixed candidate

No Critical or High production defect is established by this review. The
following Medium findings prevent qualification of the submitted candidate;
they are not excused by the correct production hooks or successful DataGen.

1. **Medium — adding the adopted switch breaks the exact configuration test.**
   [CommonConfig.java:327–329](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfig.java#L327)
   adds a 74th value, but the unchanged
   [CommonConfigTest.java:36–47](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/test/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfigTest.java#L36)
   requires 73. Both independently executed fresh XML cohorts fail with
   `expected: <73> but was: <74>` at line 47. Update the exact inventory assertion
   and cover the newly consumed switch's registration/default/server override,
   rather than removing or weakening the assertion. The production addition is
   within the adopted contract; the failed regression is the qualification gap.
2. **Medium — final upstream recipe provenance conflicts with the accepted asset plan.**
   The new
   [provenance entry:104–119](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/docs/provenance/v1.8.0-c18b-jackhammer.json#L104)
   records the MIT-derived recipe, while the first-match inherited
   [asset rule:200](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/docs/work/v1.8.0-asset-plan.csv#L200)
   still handles `recipes/*.json` as REGENERATE. The accepted-ledger check exits
   1 with `recipes/jackhammer.json has a provenance record but is not handled as
   IMPORTED` under
   [validator:584–587](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/scripts/validate_v180_content_ledger.py#L584).
   Reconcile the actual converted-recipe record and plan under the existing
   accepted policy; do not delete correct MIT provenance, invent approval or
   mark the full tool/legacy bitmap delivered. This failure is caused by the
   candidate's new record, not by relocated markdown links.
3. **Medium — crafting fixture has no native server world access.**
   [JackhammerGameTests.java:260–268](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerGameTests.java#L260)
   constructs CraftingMenu with ContainerLevelAccess.NULL. The pinned
   [native CraftingMenu:241–248](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/native-CraftingMenu.log#L241)
   updates its result through access.execute; NULL does not evaluate the server
   callback. Independent runtime fails on the first MOTOR match. None of the
   four-motor native takes is qualified. Supply a loaded owned crafting context
   and rerun the existing take/consumption assertions; a direct recipe getter
   is not equivalent evidence.
4. **Medium — both anvil fixtures omit native rename input, so their name-preservation assertions fail.**
   [JackhammerGameTests.java:201–214](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerGameTests.java#L201)
   and
   [229–242](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerGameTests.java#L229)
   use annotated custom-name inputs but never set the anvil's native itemName.
   [Pinned AnvilMenu:574–611](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/native-AnvilMenu.log#L574)
   resets a custom hover name when that rename input is null/blank. The two
   independent failures are `Native anvil changed left name/enchantment/unrelated
   data`; the combined assertion does not itself report which field differed.
   The name-reset explanation is an inference supported by actual bytecode,
   not a measured post-failure item dump. Model native retained-name input and
   keep the name/enchantment/data/XP/input-take assertions; do not alter the
   production tool to override ordinary vanilla rename semantics. The book
   branch is not reached after the earlier same-item assertion fails.
5. **Medium — the reach check reuses a native pending destroy from the hardness check.**
   [JackhammerGameTests.java:86–93](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/inputs/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerGameTests.java#L86)
   sends STOP against bedrock, then ABORT and replaces that same cell with stone
   before ticking the outside-reach action. Pinned native ABORT clears
   isDestroyingBlock, not hasDelayedDestroy
   ([ServerPlayerGameMode:579–586](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/native-ServerPlayerGameMode.log#L579));
   tick still processes the pending position
   ([132–173](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/native-ServerPlayerGameMode.log#L132)).
   Independent runtime fails the combined unchanged assertion. The log does
   not expose the assertion's individual fields or a source stack; pending
   destroy contamination is a source/native-supported explanation, not a
   separately instrumented witness. Isolate the reach case from the prior
   native operation and rerun unchanged-world/tool/loot assertions. This does
   not justify replacing vanilla mining with a new transaction or claiming a
   new jackhammer network vulnerability.

All four failed GameTests are in the new jackhammer batch. This source verdict
uses independently executed fixed-candidate results; Root's separately notified
observations are not substituted for them. A correction requires a new committed
candidate and fresh applicable checks. No review of such a correction is included.

## Exact input, tools and released interests

Candidate: `61cada9e6042e0149a96a7d97a485bd3996b58db`.
Adoption base: `106d31653f8bce66761c919742629a75a047e2ca`.
The assigned source checkout was initially clean on codex/v1.8.0-jackhammer.
Its fixed objects, complete binary diff and ownership/worktree context were
captured before a detached --no-hardlinks private clone. The candidate has
22 changed files, 1,059 insertions and one deletion, plus the new PNG.

Main, Root, all existing leaves and mutable HEAD interests were promptly
released after the clone snapshot. No subsequent read requires their mutable
state. All project inspection and qualification uses this exclusively owned
_tmp/repo at the exact candidate. No source edit, staging, commit/push, global
config/policy change, installation, client/GPU session or further delegation
was performed. Root coordinates OpenPet.

Tool identities were checked from actual bytes before native use, against the
committed contract archive:

| Input/tool | Actual identity |
|---|---|
| Forge mapped official 1.20.1 / 47.4.10 JAR | 19,355,242 bytes; SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Java 17 javap | 17.0.7; SHA-256 `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d` |
| Git | 2.55.0.windows.5 |
| Python | 3.13.15 |
| Approved upstream recipe | 666 bytes; SHA-256 `a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45` |

Native JAR/javap/upstream-recipe hashes still match after checks. Exact paths,
Java/wrapper hashes, source Git blobs and SHA-256 are in tool-identities.json,
input-identities.json, supplement-identities.json and actual-summary.json.
No native JAR or full project tree belongs in retained evidence.

## Actual implementation and data review

The complete actual diff was inspected, with adjacent configuration/override,
registration/DataGen/art and installed station-protection code. Mandatory
project/product/porting/version/test/Gate/parallel/asset governance and accepted
ADR scope were read from the fixed candidate. v1.0 remains the unfinished release
acceptance cursor; ADR-060 permits separate v1.8 development, not Gate approval.

The production tool is a short common-side PickaxeItem adapter using actual
Tiers.DIAMOND, constructor attack bonus 1/speed -2.8, explicit 1,024 durability,
tag-qualified speed 50 and live titanium-rod repair. It does not override harvest
qualification, native wear/loot/anvil logic or ordinary ItemStack persistence.
The pinned TieredItem/defaultDurability path preserves explicit durability and
native stack size one. Registration is additive/stable, the creative binding is
narrow, and the config value is before SPEC construction and enters the existing
testable SERVER_SWITCHES/accessor. Existing equipment state is unchanged.

The final disabled mining hook is after native BreakEvent cancellation and before
wear/removal in destroyBlock; native melee reaches onLeftClickEntity before hurt.
The item creates no listener, alternate removal, scan/AOE, packet, new tier or
custom NBT root. Common/server code adds no net.minecraft.client import. Native
wear precedes a later removeBlock refusal, as the adopted contract already states;
stronger resource/removal atomicity is not promised.

All seven final target hashes and NEW generator/language source hashes match.
The pending content digest recomputes to
`b176422d37beb327b4ee0879028097973709b20b4aa63936b4f7984926654b46`;
provenance file SHA-256 is
`d2e190ea4ce1b2f1b75728da2bdc0969795a11e8f52d13916ca5e7f628d58bb3`.
The actual JSON preserves the reviewed shaped rows/counts, five tags, one output,
motor/recipe-unlocked alternative criteria, lawful handheld ID reference and
additive pickaxes membership. Both language files add exactly four keys and
preserve every previous value. Static map/PNG checks are independent of the
six implementation-owned JUnit checks.

The PNG was directly viewed and decoded: 16 x 16 RGBA, 82 opaque pixels, 169 bytes,
exact adopted grid/palette arithmetic, SHA-256
`771eaebb41fcc90c4d9622f8c807705cca67d51ca3b64784e7ee4057cfb53563`.
The local vanilla 1.20.1 screen returns one CLEAR, using a byte-identified client
JAR. This is only automated originality screening; no 1.12.2 screen, human
license/visual approval, held-item GPU observation or legacy IMPORT closure is
claimed. Pending human review remains unchanged.

Runtime/api/sources JARs were produced despite the build's later test failure.
Their observed hashes are retained, not approved artifacts. Runtime SHA-256:
`f6b45bc6c147e83f114a6ebedb7a0ae978520babe5d703acbf78dc70548a35b2`.
Archive inspection finds no duplicate entries, retains LICENSE/NOTICE, includes
the tool class/resources, and matches all seven packaged resource bytes to the
candidate. JARs themselves are disposable, not retained.

## Commands actually run and outcomes

All Gradle commands use Java17 and the exact common prefix:
`gradlew.bat --no-daemon --no-build-cache --rerun-tasks`.
Raw untruncated logs, argv/cwd/UTC/end/exit/PID/fixed SHA, task execution markers
and two separate actual XML cohorts are retained. Each mandatory Gradle command
has all its actionable tasks executed (build 20, explicit test 17, each DataGen
10, native server 18); no FROM-CACHE/UP-TO-DATE result is promoted to test
execution. The clean build additionally reports jarJar and reobfJarJar SKIPPED:
those optional nested-JAR tasks are not executed tests or a qualification pass.
Detailed task lists are in actual-summary.json and the raw logs.

| Command | Actual result |
|---|---|
| `clean build` | Exit 1; 380 XML suites, 2,189 tests, one failure, zero errors/skips |
| explicit forced `test` | Exit 1; separate fresh 380-suite/2,189-test XML cohort, same one failure, zero errors/skips |
| first forced `runData` | Exit 0; separate `git diff --exit-code` and status exit 0, empty |
| second forced `runData` | Exit 0; separate `git diff --exit-code` and status exit 0, empty |
| unfiltered `runGameTestServer` | Exit 1; 578 complete, four required failures; new tool batch 13, four failures |
| accepted content ledger `--require-accepted` | Exit 1; candidate recipe-provenance/asset-plan mismatch above |
| bootstrap provenance `--require-approved-review` | Exit 0; accepted v0.0.2 identity `9359257b9fe1eccf7e0043dfa7f626cf1ee44be9`, mechanically approved/digest-bound |
| strict repository `--require-approved-identity` | Exit 1; 44 passed, zero pending/warnings, one broken-markdown-link check failed; capped at 256 reported entries |
| `git diff --check <adoption-base> <candidate>` | Exit 0; empty |
| native javap/source/static/artifact checks | Logged successful commands and raw observations; no runtime Gate inference |

The strict validator's 256 reported link entries span 108 source files; every
reported source file is byte-identical to the adoption base (link-attribution.json).
These include existing absent internal evidence references and targets rejected
as unsafe/oversized. Relocating a clone does not supply external evidence/paths or
make such inherited records valid; this remains an actual failure, not PASS.
The validator stops after 256 entries, so this is not a complete inventory of
all broken links. No new candidate file is among these reported entries. The
candidate-introduced ledger failure is separately attributed above. Final owned
`git status --short` is empty, exit 0.

Both A0 cohorts actually execute all six JackhammerDataTest cases successfully.
The native four failures are crafting MOTOR match, combined hardness/reach
unchanged-state assertion, material-anvil annotation and same-item-anvil
annotation. The three remaining motor iterations and book assertions are not
reached in their failed cases. Other 574 native cases finish without reported
test failure; this does not make the unfiltered command a pass. Expected existing
adversarial persistence/capability ERROR/WARN messages remain in the full raw
logs; no assertion/log filtering or rerun hides them.

Pre-logger exploratory missing-file/PATH/wildcard and premature-log-read errors
are retained in EXPLORATION-ERRORS.md with transcript IDs/cwd/exits. Their exact
UTC metadata was not captured; that limited evidence gap is explicit. None is
counted as a successful input read or validator outcome. The later denied cache
cleanup is separately retained below; no retry through another shell or policy
bypass occurred.

## Evidence limits, remaining work and Gate status

Connected EmbeddedChannel ServerPlayers are embedded actors, not real clients.
Native game-mode progress calls are synchronous function ticks, not elapsed
server/wall ticks. Direct destroyBlock and Player.attack checks exercise final
item endpoints, not packet admission; action/progress cases inspect game-mode
admission, and the combined hardness/reach case fails. Station evidence covers
installed unavailable-registry BUILD denial, not full owner/member/multiplayer
permissions. Listener/switch/registry restoration is exception-safe and fixtures
attempt to restore owned BE-free cells and remove owned actors/loot.

No above-diamond third-party tier/mod interaction, packaged save/restart/continued
use, S1/S2, real-client V1/V2, survival progression roots, JEI/modpack compatibility,
human asset review, full performance/soak or Required Gate approval is produced.
The missing titanium/steel roots are not cured by supplied crafting ingredients.
The legacy bitmap and full tool ledger unit remain open; sleep/equipment-module/
hatch/writer authority is unchanged.

**No version's full Required Gates are met.** The submitted candidate needs the
bounded current-v1.8 corrections above followed by fresh candidate qualification,
then the still-required lifecycle/client/asset evidence. No source/status/ledger
delivery or human approval is written by this reviewer.

## Ownership, cleanup and sealing

Initial C free space: 30,502,502,400 bytes; D: 297,934,356,480 bytes, both above
10 GiB. Each sustained qualification step rechecks both disks; exact values and
owned TEMP/TMP/Java tmp are recorded. Existing Gradle dependency caches supply
the pinned toolchain; build/DataGen/server worlds and private checkout are owned
disposable outputs only. This review does not clean any shared cache/source/world.

At 2026-10-09T02:23:56.9942909Z, native PowerShell 7.6.6 verified the resolved
absolute target equals this leaf's _tmp child, checked all children and found
zero reparse points, and inspected real process command lines with zero live
leaf-referencing processes other than the cleanup shell. One Remove-Item
-LiteralPath -Recurse -Force attempt completed exit 0 at
2026-10-09T02:24:05.8116503Z. Its 15,808 disposable files / 1,448,976,375 bytes
(clone/.git, builds/JARs, world, art copy and tmp) were removed. No other owner's
tree/process/source world was removed, no denied target was retried, and no
background server/agent survives. Exact checks/argv/times/disks are retained in
cleanup.ps1, cleanup.json and cleanup.log.

The final compact retained slice is under 11 MiB, with no file above 50 MiB,
well below the 100 MiB limit. SHA256SUMS.txt covers only relative retained
scripts, selected committed inputs, diff, raw logs, result XML, observations,
hashes and this report; it excludes no evidence into build/Temp references.
seal-summary.json records the measured covered payload and unsealed cache.
Reviewer-owned residual outputs outside this leaf: zero. No earlier
sealed package is edited. Main, Root, source checkout and mutable HEAD interests
remain released throughout; the owned clone is now removed.

The reviewer also found an own Python import cache beside qualify.py rather
than under _tmp. This is a disposable-output placement error confined to the
exclusive leaf. A distinct native PowerShell cache-removal command was rejected
by tool policy before process creation; it did not execute. CACHE-CLEANUP-DENIAL.md
preserves its actual requested command and failure. No retry, alternate shell,
replacement script, policy bypass or Root cleanup takeover was attempted.
The own import cache remains **unsealed** and is excluded from SHA256SUMS.txt;
its 11,353 bytes and actual identity are recorded in seal-summary.json. No clone/JAR/world
remains. Subsequent sealing disables Python bytecode creation.

