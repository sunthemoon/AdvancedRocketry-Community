# Distinct owned Python-cache cleanup denied — no retry

After the owned _tmp clone/build/world cleanup completed exit 0, the reviewer
noticed a Python import cache created beside qualify.py by earlier imports.
This is a disposable placement error inside the exclusively owned evidence leaf,
not a write to Main/Root or another owner's tree. The cache remains unsealed.

The following PowerShell cleanup attempt was submitted from the evidence leaf
and rejected by the tool policy **before process creation**. It did not execute
the containment/reparse/process checks or Remove-Item. No exit code or exact
UTC execution interval exists for that denied process. Tool output was:

`exec_command failed: CreateProcess ... rejected: blocked by policy`

Actual requested command:

```powershell
$ErrorActionPreference='Stop'; $leaf=(Resolve-Path -LiteralPath '.').ProviderPath; $expected=Join-Path $leaf '__pycache__'; $target=(Resolve-Path -LiteralPath $expected).ProviderPath; $start=[DateTime]::UtcNow.ToString('o'); if(!$target.Equals($expected,[StringComparison]::OrdinalIgnoreCase)-or !$target.StartsWith($leaf+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Python cache containment mismatch'}; $items=@(Get-Item -LiteralPath $target -Force)+@(Get-ChildItem -LiteralPath $target -Recurse -Force); if(@($items|Where-Object {($_.Attributes-band[IO.FileAttributes]::ReparsePoint)-ne 0}).Count-ne 0){throw 'Cache reparse point'}; $live=@(Get-CimInstance Win32_Process|Where-Object {$_.ProcessId-ne $PID -and $_.CommandLine -and ($_.CommandLine.IndexOf($leaf,[StringComparison]::OrdinalIgnoreCase)-ge 0 -or $_.CommandLine.IndexOf($leaf.Replace('\','/'),[StringComparison]::OrdinalIgnoreCase)-ge 0)}); if($live.Count-ne 0){throw 'Owned leaf process still running'}; $bytes=($items|Where-Object {!$_.PSIsContainer}|Measure-Object Length -Sum).Sum; Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop; [ordered]@{start_utc=$start;end_utc=[DateTime]::UtcNow.ToString('o');argv='PowerShell Remove-Item -LiteralPath <checked owned leaf>/__pycache__ -Recurse -Force -ErrorAction Stop';cwd=$leaf;resolved_target=$target;bytes=$bytes;reparse_count=0;live_process_count=0;attempts=1;exit=0;target_remains=(Test-Path -LiteralPath $target);reason='Reviewer-owned Python import cache was inadvertently placed beside the logger script; first removal of this distinct disposable target, not a retry'} | ConvertTo-Json | Tee-Object -FilePath (Join-Path $leaf 'python-cache-cleanup.json')
```

The shell requested was the normal tool PowerShell executable; no alternate
shell or escalation was requested. No retry, replacement script, bypass or
Root cleanup takeover is allowed/attempted. python-cache-cleanup.json was not
created because the command never ran. Subsequent reads only measured the
residual; sealing disables bytecode creation and excludes __pycache__.
