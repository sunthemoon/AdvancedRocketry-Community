$ErrorActionPreference = 'Stop'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\jackhammer-source-independent-20261009-01'
$record = [ordered]@{
    argv = 'PowerShell: & D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-01/cleanup.ps1'
    cwd = (Get-Location).Path
    start_utc = [DateTime]::UtcNow.ToString('o')
    powershell = $PSVersionTable.PSVersion.ToString()
    shell_pid = $PID
    status = 'NOT_STARTED'
    attempts = 0
}
$log = Join-Path $leaf 'cleanup.log'
try {
    $base = (Resolve-Path -LiteralPath $leaf).ProviderPath.TrimEnd('\')
    $target = (Resolve-Path -LiteralPath (Join-Path $leaf '_tmp')).ProviderPath.TrimEnd('\')
    $record.base = $base
    $record.target = $target
    if (!$target.Equals(($base + '\_tmp'), [StringComparison]::OrdinalIgnoreCase) -or
        !$target.StartsWith(($base + '\'), [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Resolved target is not the exclusively owned _tmp directory'
    }
    $rootItem = Get-Item -LiteralPath $target -Force
    if (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'Owned _tmp root is a reparse point'
    }
    $children = @(Get-ChildItem -LiteralPath $target -Force -Recurse)
    $reparse = @($children | Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0})
    $record.reparse_count = $reparse.Count
    if ($reparse.Count -gt 0) { throw 'A disposable child is a reparse point; no cleanup attempted' }
    $allProcesses = @(Get-CimInstance Win32_Process)
    $self = $allProcesses | Where-Object {$_.ProcessId -eq $PID}
    $record.shell_identity = $self | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine
    $live = @($allProcesses | Where-Object {
        $_.ProcessId -ne $PID -and $_.CommandLine -and
        ($_.CommandLine.IndexOf($leaf, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
         $_.CommandLine.IndexOf($leaf.Replace('\','/'), [StringComparison]::OrdinalIgnoreCase) -ge 0)
    })
    $record.live_leaf_processes = @($live | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
    if ($live.Count -gt 0) { throw 'Leaf-referencing process remains active; no cleanup attempted' }
    $record.disposable_file_count = @($children | Where-Object {!$_.PSIsContainer}).Count
    $record.disposable_bytes = ($children | Where-Object {!$_.PSIsContainer} | Measure-Object -Property Length -Sum).Sum
    $record.disks_before = @(Get-PSDrive -Name C,D | Select-Object Name,Free,Used)
    $record.attempts = 1
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    $record.target_remains = Test-Path -LiteralPath $target
    if ($record.target_remains) { throw 'Owned target remains after the single cleanup attempt' }
    $record.status = 'REMOVED'
    $record.exit = 0
} catch {
    $record.status = 'FAILED_OR_BLOCKED_NO_RETRY'
    $record.error = ($_ | Out-String)
    $record.exit = 1
    ($_ | Out-String) | Out-File -LiteralPath $log -Encoding utf8
} finally {
    $record.end_utc = [DateTime]::UtcNow.ToString('o')
    $record.disks_after = @(Get-PSDrive -Name C,D | Select-Object Name,Free,Used)
    $record | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup.json') -Encoding utf8
    ($record | ConvertTo-Json -Depth 10) | Out-File -LiteralPath $log -Append -Encoding utf8
}
$record | ConvertTo-Json -Depth 10
exit $record.exit
