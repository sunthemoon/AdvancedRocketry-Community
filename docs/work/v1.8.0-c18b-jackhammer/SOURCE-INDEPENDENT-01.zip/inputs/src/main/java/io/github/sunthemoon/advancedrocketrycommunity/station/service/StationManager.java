package io.github.sunthemoon.advancedrocketrycommunity.station.service;

import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.CelestialCatalogManager;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.PlanetarySurfaceResolver;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.entity.RocketEntity;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.persistence.RocketTransferSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketStructureSnapshot;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.transaction.RocketRegion;
import io.github.sunthemoon.advancedrocketrycommunity.station.elevator.ElevatorEndpointService;
import io.github.sunthemoon.advancedrocketrycommunity.station.elevator.ElevatorEndpointValidator;
import io.github.sunthemoon.advancedrocketrycommunity.station.forge.StationPlatformGenerator;
import io.github.sunthemoon.advancedrocketrycommunity.station.forge.StationPlatformResult;
import io.github.sunthemoon.advancedrocketrycommunity.station.model.StationLimits;
import io.github.sunthemoon.advancedrocketrycommunity.station.elevator.ElevatorStationGuard;
import io.github.sunthemoon.advancedrocketrycommunity.station.model.StationState;
import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationOrbitEnvironment;
import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationOrbitEnvironmentResolver;
import io.github.sunthemoon.advancedrocketrycommunity.station.persistence.StationRegistrySavedData;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;

/** Lifecycle-owned station creation, mutation, protection, and recovery authority. */
public final class StationManager implements StationOperationService {
    private static final int MAX_DENIAL_TRACKING_PLAYERS = 128;
    private static final int DENIAL_NOTICE_TICKS = 20;

    private final StationPlatformGenerator platforms = new StationPlatformGenerator();
    private final CelestialCatalogManager celestialCatalogs;
    private final StationCreationService creation;
    private final StationAccessService access = new StationAccessService();
    private final StationExpansionService expansion;
    private final StationGravityService gravity;
    private final StationOrbitEnvironmentResolver orbitEnvironments;
    private final ElevatorEndpointService elevatorEndpoints;
    private final Map<UUID, Long> lastDenialNotice = new LinkedHashMap<>();

    public StationManager(CelestialCatalogManager celestialCatalogs) {
        this(celestialCatalogs, StationWriteBudget.unbounded());
    }

    /** {@code writeBudget} is shared with the warp service: one server-wide spacing for checked writes. */
    public StationManager(CelestialCatalogManager celestialCatalogs, StationWriteBudget writeBudget) {
        this.celestialCatalogs = Objects.requireNonNull(celestialCatalogs, "celestialCatalogs");
        this.expansion = new StationExpansionService(access, writeBudget);
        this.gravity = new StationGravityService(access, writeBudget);
        this.creation = new StationCreationService(
                platforms,
                bodyId -> celestialCatalogs.current()
                        .flatMap(catalog -> catalog.get(bodyId))
                        .filter(body -> body.capabilities().orbitable())
                        .isPresent()
        );
        this.orbitEnvironments = new StationOrbitEnvironmentResolver(celestialCatalogs);
        this.elevatorEndpoints = new ElevatorEndpointService(celestialCatalogs);
    }

    @Override
    public StationCreationResult createForPlayer(ServerPlayer player) {
        Objects.requireNonNull(player, "player");
        MinecraftServer server = player.getServer();
        if (server == null) {
            return StationCreationResult.failure(StationCreationCode.SERVICE_UNAVAILABLE);
        }
        ResourceLocation orbitBody = celestialCatalogs.current()
                .flatMap(catalog -> PlanetarySurfaceResolver.find(catalog, player.level().dimension(), false))
                .map(body -> body.id()).orElse(null);
        if (orbitBody == null || server.getLevel(player.level().dimension()) != player.level()) {
            return StationCreationResult.failure(StationCreationCode.INVALID_SOURCE);
        }
        String name = player.getScoreboardName() + " Station";
        return creation.create(server, player.getUUID(), name, orbitBody, true);
    }

    public StationCreationResult createForOperator(
            MinecraftServer server,
            UUID ownerId,
            String name,
            ResourceLocation orbitBody
    ) {
        return creation.create(server, ownerId, name, orbitBody, false);
    }

    public Optional<StationState> station(MinecraftServer server, UUID stationId) {
        return StationRegistrySavedData.get(server).find(stationId);
    }

    public List<StationState> stations(MinecraftServer server) {
        return StationRegistrySavedData.get(server).stations();
    }

    public StationState invite(
            MinecraftServer server,
            UUID actorId,
            boolean operator,
            UUID stationId,
            UUID playerId
    ) {
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = requireAllowed(data, stationId, actorId, operator,
                StationAccessAction.MANAGE_MEMBERS);
        StationState updated = data.invite(state.stationId(), playerId);
        data.flush(server);
        auditAccess("invite", stationId, actorId, playerId, true);
        return updated;
    }

    public StationState accept(MinecraftServer server, UUID stationId, UUID playerId) {
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = data.find(stationId).orElseThrow(
                () -> new IllegalArgumentException("Station is missing")
        );
        if (!state.invitations().contains(playerId)) {
            throw new SecurityException("Station invitation is missing");
        }
        StationState updated = data.acceptInvitation(stationId, playerId);
        data.flush(server);
        auditAccess("accept", stationId, playerId, playerId, true);
        return updated;
    }

    public StationState decline(MinecraftServer server, UUID stationId, UUID playerId) {
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = data.find(stationId).orElseThrow(
                () -> new IllegalArgumentException("Station is missing")
        );
        if (!state.invitations().contains(playerId)) {
            throw new SecurityException("Station invitation is missing");
        }
        StationState updated = data.declineInvitation(stationId, playerId);
        data.flush(server);
        auditAccess("decline", stationId, playerId, playerId, true);
        return updated;
    }

    public StationState removeMember(
            MinecraftServer server,
            UUID actorId,
            boolean operator,
            UUID stationId,
            UUID memberId
    ) {
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = requireAllowed(data, stationId, actorId, operator,
                StationAccessAction.MANAGE_MEMBERS);
        StationState updated = data.removeMember(state.stationId(), memberId);
        data.flush(server);
        auditAccess("remove", stationId, actorId, memberId, true);
        return updated;
    }

    public StationState transferOwnership(
            MinecraftServer server,
            UUID actorId,
            boolean operator,
            UUID stationId,
            UUID ownerId
    ) {
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = requireAllowed(data, stationId, actorId, operator,
                StationAccessAction.TRANSFER_OWNERSHIP);
        StationState updated = data.transferOwnership(state.stationId(), ownerId);
        data.flush(server);
        auditAccess("transfer", stationId, actorId, ownerId, true);
        return updated;
    }

    public StationState delete(
            MinecraftServer server,
            UUID actorId,
            boolean operator,
            UUID stationId,
            String confirmation
    ) {
        if (!"confirm".equals(confirmation)) {
            throw new IllegalArgumentException("Station deletion requires the literal confirmation token");
        }
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        StationState state = requireAllowed(data, stationId, actorId, operator,
                StationAccessAction.DELETE);
        ServerLevel space = server.getLevel(CelestialIds.SPACE_LEVEL);
        if (space == null) {
            throw new IllegalStateException("Fixed Space Level is unavailable");
        }
        if (hasRocketAuthority(server, space, state)) {
            throw new IllegalStateException("Station deletion is blocked while a rocket authority uses its region");
        }
        // ADR-059 section 5: pairs and transit records that reference the station keep it; fail closed without them.
        switch (ElevatorStationGuard.Installed.current().delete(server, state)) {
            case BOUND -> throw new IllegalStateException("ELEVATOR_REFERENCES: an elevator pair or endgame cargo"
                    + " references this station; unbind and settle them first");
            case UNAVAILABLE -> throw new IllegalStateException("ENDGAME_UNAVAILABLE: endgame data is unavailable,"
                    + " so station deletion is refused until it loads");
            default -> {
            }
        }
        AdvancedRocketryCommunity.LOGGER.warn(
                "ARCE_STATION_DELETE_BACKUP station={} owner={} members={} cell={},{} region={},{},{},{}",
                state.stationId(),
                state.ownerId(),
                state.sortedMembers(),
                state.cell().x(),
                state.cell().z(),
                state.region().minimumX(),
                state.region().minimumZ(),
                state.region().maximumX(),
                state.region().maximumZ()
        );
        StationPlatformResult removed = platforms.removeTemplate(space, state.cell());
        StationState deleted = data.delete(stationId).orElseThrow(
                () -> new IllegalStateException("Station changed during deletion")
        );
        data.flush(server);
        AdvancedRocketryCommunity.LOGGER.warn(
                "ARCE_STATION_DELETED station={} actor={} inspected={} removed={} chunks={}",
                stationId, actorId, removed.inspected(), removed.changed(), removed.chunksLoaded()
        );
        return deleted;
    }

    private static boolean hasRocketAuthority(
            MinecraftServer server,
            ServerLevel space,
            StationState station
    ) {
        AABB region = new AABB(
                station.region().minimumX(),
                space.getMinBuildHeight(),
                station.region().minimumZ(),
                (double) station.region().maximumX() + 1.0D,
                space.getMaxBuildHeight(),
                (double) station.region().maximumZ() + 1.0D
        );
        if (!space.getEntitiesOfClass(RocketEntity.class, region).isEmpty()) {
            return true;
        }
        RocketTransferSavedData journal = RocketTransferSavedData.get(server);
        if (!journal.operational()) {
            // ADR-044 §5: a blocked journal hides its records, so deletion fails closed.
            return true;
        }
        return journal.entries().stream().anyMatch(record ->
                usesStationRegion(station, record.sourceSnapshot())
                        || usesStationRegion(station, record.destinationSnapshot())
        );
    }

    private static boolean usesStationRegion(
            StationState station,
            RocketStructureSnapshot snapshot
    ) {
        return snapshot.sourceDimension().equals(CelestialIds.SPACE_LEVEL.location())
                && overlaps(station, RocketRegion.fromSnapshot(snapshot));
    }

    private static boolean overlaps(StationState station, RocketRegion rocket) {
        return station.region().minimumX() <= rocket.maximum().x()
                && station.region().maximumX() >= rocket.minimum().x()
                && station.region().minimumZ() <= rocket.maximum().z()
                && station.region().maximumZ() >= rocket.minimum().z();
    }

    public StationManagementResult requestExpansion(ServerPlayer player, boolean issuedByPlayer) {
        return expansion.request(player, issuedByPlayer);
    }

    public StationManagementResult confirmExpansion(ServerPlayer player, boolean issuedByPlayer, UUID stationId) {
        return expansion.confirm(player, issuedByPlayer, stationId);
    }

    public StationManagementResult setGravity(ServerPlayer player, boolean issuedByPlayer, int percent) {
        return gravity.set(player, issuedByPlayer, percent);
    }

    /** ADR-041 effective environment of the committed station region at a position, if any. */
    public Optional<StationOrbitEnvironment> environmentAt(ServerLevel level, BlockPos position) {
        return orbitEnvironments.at(level.getServer(), level.dimension(), position.getX(), position.getZ());
    }

    /** Owner, member or operator: may see a station's name and UUID (as {@code /arce station list} does). */
    public boolean canIdentify(ServerPlayer player, UUID stationId) {
        MinecraftServer server = player.getServer();
        return server != null && station(server, stationId)
                .filter(state -> access.allowed(state, player.getUUID(), player.hasPermissions(2),
                        StationAccessAction.VISIT))
                .isPresent();
    }

    /** Player-physics gravity for a station region; empty elsewhere so the Level profile applies. */
    public OptionalDouble effectiveGravity(ServerLevel level, BlockPos position) {
        return environmentAt(level, position)
                .map(environment -> OptionalDouble.of(environment.effectiveGravity()))
                .orElse(OptionalDouble.empty());
    }

    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        expansion.forget(event.getEntity().getUUID());
    }

    /** ADR-045 read-only endpoint check; the caller has already required permission level 2. */
    public ElevatorEndpointValidator.Result checkElevatorEndpoint(MinecraftServer server, UUID requesterId,
                                                                  boolean operator,
                                                                  ElevatorEndpointValidator.Request request) {
        return elevatorEndpoints.check(server, requesterId, operator, request);
    }

    public int recoverReservations(MinecraftServer server) {
        return creation.recoverReservations(server);
    }

    /**
     * The mod instance outlives integrated-server worlds, and ServerStoppedEvent clears the bridge, so
     * each server start reinstalls it (as the machine and satellite runtimes do).
     */
    public void onServerAboutToStart(net.minecraftforge.event.server.ServerAboutToStartEvent event) {
        StationRuntime.install(this);
    }

    public void onServerStarted(ServerStartedEvent event) {
        int recovered = recoverReservations(event.getServer());
        if (recovered > 0) {
            AdvancedRocketryCommunity.LOGGER.warn(
                    "ARCE_STATION_STARTUP_RECOVERY reservations={}", recovered
                );
        }
        StationRegistrySavedData data = StationRegistrySavedData.get(event.getServer());
        if (data.operational()) {
            StationRegistrySavedData.OrbitBodyValidation validation = data.validateOrbitBodies(
                    body -> celestialCatalogs.current().flatMap(catalog -> catalog.get(body)).isPresent()
            );
            validation.invalidStationIds().forEach(stationId -> AdvancedRocketryCommunity.LOGGER.error(
                    "ARCE_STATION_UNKNOWN_ORBIT_BODY station={}", stationId
            ));
            validation.invalidReservationIds().forEach(stationId -> AdvancedRocketryCommunity.LOGGER.error(
                    "ARCE_STATION_RESERVATION_UNKNOWN_ORBIT_BODY station={}", stationId
            ));
        }
    }

    public void onBlockBroken(BlockEvent.BreakEvent event) {
        if (event.getLevel() instanceof ServerLevel level
                && event.getPlayer() instanceof ServerPlayer player) {
            protect(event, level, event.getPos(), player);
        }
    }

    public void onBlockPlaced(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)
                || !(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (event instanceof BlockEvent.EntityMultiPlaceEvent multiple) {
            for (BlockSnapshot snapshot : multiple.getReplacedBlockSnapshots()) {
                if (!allowedBuild(level, snapshot.getPos(), player)) {
                    deny(event, level, snapshot.getPos(), player);
                    return;
                }
            }
            return;
        }
        protect(event, level, event.getPos(), player);
    }

    public void clear() {
        lastDenialNotice.clear();
        expansion.clear();
        gravity.clear();
    }

    private void protect(
            BlockEvent event,
            ServerLevel level,
            BlockPos position,
            ServerPlayer player
    ) {
        if (!allowedBuild(level, position, player)) {
            deny(event, level, position, player);
        }
    }

    private boolean allowedBuild(ServerLevel level, BlockPos position, ServerPlayer player) {
        if (!level.dimension().equals(CelestialIds.SPACE_LEVEL)) {
            return true;
        }
        StationRegistrySavedData data = StationRegistrySavedData.get(level.getServer());
        return access.allowedBuild(data.operational(), data.findAt(position.getX(), position.getZ()),
                player.getUUID(), player.hasPermissions(2));
    }

    private void deny(
            BlockEvent event,
            ServerLevel level,
            BlockPos position,
            ServerPlayer player
    ) {
        event.setCanceled(true);
        long time = level.getGameTime();
        Long previous = lastDenialNotice.put(player.getUUID(), time);
        if (lastDenialNotice.size() > MAX_DENIAL_TRACKING_PLAYERS) {
            UUID eldest = lastDenialNotice.keySet().iterator().next();
            lastDenialNotice.remove(eldest);
        }
        if (previous == null || time - previous >= DENIAL_NOTICE_TICKS) {
            boolean authorityAvailable = StationRegistrySavedData.get(level.getServer()).operational();
            player.displayClientMessage(
                    Component.translatable(authorityAvailable ? "station.advancedrocketrycommunity.access.denied"
                            : "station.advancedrocketrycommunity.creation.registry_blocked"),
                    true
            );
            AdvancedRocketryCommunity.LOGGER.warn(
                    "ARCE_STATION_ACCESS_DENIED player={} position={} dimension={} authority_available={}",
                    player.getUUID(), position.toShortString(), level.dimension().location(), authorityAvailable
            );
        }
    }

    private StationState requireAllowed(
            StationRegistrySavedData data,
            UUID stationId,
            UUID actorId,
            boolean operator,
            StationAccessAction action
    ) {
        StationState state = data.find(stationId).orElseThrow(
                () -> new IllegalArgumentException("Station is missing")
        );
        if (!access.allowed(state, actorId, operator, action)) {
            auditAccess(action.name().toLowerCase(java.util.Locale.ROOT), stationId, actorId, actorId, false);
            throw new SecurityException("Station action is unauthorized");
        }
        return state;
    }

    private static void auditAccess(
            String action,
            UUID stationId,
            UUID actorId,
            UUID subjectId,
            boolean allowed
    ) {
        AdvancedRocketryCommunity.LOGGER.info(
                "ARCE_STATION_ACCESS action={} station={} actor={} subject={} allowed={}",
                action, stationId, actorId, subjectId, allowed
        );
    }
}
