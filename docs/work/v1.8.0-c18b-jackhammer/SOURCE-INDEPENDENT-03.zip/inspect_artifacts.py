import csv,hashlib,json,pathlib,sys,zipfile
from run_checks import LEAF,SOURCE

hashes={r['sha256']:r['source_path'] for r in csv.DictReader((SOURCE/'legacy-manifest/assets.csv').open(encoding='utf8',newline=''))}
records=[]
for file in (SOURCE/'docs/provenance').glob('*.json'):
    data=json.loads(file.read_text(encoding='utf-8-sig'))
    for entry in data.get('entries',[]):
        if isinstance(entry,dict) and 'target_path' in entry and 'target_sha256' in entry:
            records.append(dict(entry,record=str(file.relative_to(SOURCE))))
by_target={e['target_path'].split('/resources/',1)[-1]:e for e in records}
artifacts=[]
for jar in sorted((SOURCE/'build/libs').glob('*.jar')):
    with zipfile.ZipFile(jar) as z:
        names=z.namelist(); contents=[];imports=[];forbidden=[]
        for n in names:
            if n.endswith('/'): continue
            b=z.read(n);h=hashlib.sha256(b).hexdigest()
            contents.append({'path':n,'bytes':len(b),'sha256':h})
            if h in hashes:
                entry=by_target.get(n)
                imports.append({'path':n,'legacy_source':hashes[h],
                                'provenance_record':entry and entry['record'],
                                'record_hash_matches':bool(entry and entry['target_sha256']==h)})
            if by_target.get(n,{}).get('status') in ('QUARANTINED','REJECTED'): forbidden.append(n)
        data={'name':jar.name,'bytes':jar.stat().st_size,'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),
              'duplicate_entries':sorted({n for n in names if names.count(n)>1}),
              'legacy_exact_hash_entries':imports,'forbidden_provenance_entries':forbidden,
              'jackhammer_entries':[c for c in contents if 'Jackhammer' in c['path'] or 'jackhammer' in c['path']],
              'has_adapter_continuation':any('JackhammerContinuationFixture' in n for n in names),
              'license_notice_present':all('META-INF/'+n in names for n in ('LICENSE','NOTICE.md'))}
        artifacts.append(data)
        (LEAF/(jar.name+'.contents.json')).write_text(json.dumps(contents,indent=2),encoding='utf8')
data={'artifacts':artifacts}
(LEAF/'artifact-inspection.json').write_text(json.dumps(data,indent=2),encoding='utf8')
main=next(a for a in artifacts if a['name']=='advancedrocketry-community-1.20.1-1.8.0-dev.jar')
fail=bool(main['duplicate_entries'] or main['forbidden_provenance_entries'] or not main['license_notice_present']
          or main['has_adapter_continuation'] or any(not i['record_hash_matches'] for i in main['legacy_exact_hash_entries']))
print(json.dumps(data,indent=2))
sys.exit(1 if fail else 0)
