import hashlib,json,pathlib,sys
from run_checks import LEAF,SOURCE
sys.path.insert(0,str(SOURCE))
from tools.audit import vanilla_derivation as tool
from tools.audit.fetch_vanilla_clients import CLIENTS

root=pathlib.Path('C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/vanilla')
specs=[]
for label,pins in CLIENTS.items():
    path=root/('client-'+label+'.jar')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pins['sha256']
    specs.append(label+'='+str(path))
sources,hashes,images=tool.load_vanilla(specs)
path=SOURCE/'src/generated/v1.8/resources/assets/advancedrocketrycommunity/textures/item/jackhammer.png'
body=path.read_bytes();w,h,rgba=tool.decode_rgba(body)
matches=tool.analyse_images([('jackhammer.png',tool.Image(w,h,rgba))],images)
data={'target_sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'width':w,'height':h,
      'opaque_pixels':sum(rgba[i]>0 for i in range(3,len(rgba),4)),
      'vanilla_clients':sources,'exact_file_hash_matches':hashes.get(hashlib.sha256(body).hexdigest(),[]),
      'thresholds':tool.thresholds(),'best':matches,'tool_sha256':hashlib.sha256((SOURCE/'tools/audit/vanilla_derivation.py').read_bytes()).hexdigest(),
      'peak_memory_mb':tool.peak_memory_mb(),
      'limit':'Automated unchanged-measure screen only; human visual/license approval and actual V1/V2 remain separate.'}
(LEAF/'new-icon-screen.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(data,ensure_ascii=False,indent=2))
