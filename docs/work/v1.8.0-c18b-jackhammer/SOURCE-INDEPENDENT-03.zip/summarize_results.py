import collections,hashlib,json,pathlib,re,shutil
from run_checks import LEAF,SOURCE

records=[json.loads(line) for line in (LEAF/'commands.jsonl').read_text().splitlines()]
commands=[]
for record in records:
    if record['name'].startswith('native/'): continue
    text=(LEAF/(record['name']+'.log')).read_text(encoding='utf8',errors='replace')
    commands.append(dict(record,tasks=re.findall(r'^> Task :(.+)$',text,re.M),
        executed_summary=re.findall(r'^\d+ actionable tasks:.*$',text,re.M),
        task_cache_markers=[line for line in text.splitlines() if line.startswith('> Task ') and any(x in line for x in ('UP-TO-DATE','FROM-CACHE','SKIPPED','NO-SOURCE'))]))
native=(LEAF/'native-latest.log').read_text(encoding='utf8',errors='replace')
headers=re.findall(r'^\[[^\r\n]+\] \[[^\r\n]+/(WARN|ERROR|FATAL)\] \[([^\r\n]+)\]: (.*)$',native,re.M)
by_level=collections.Counter(x[0] for x in headers)
progress=re.findall(r'GameTestServer/\]: \[([+x_X !-]+)\]',native)
data={'command_results':commands,'native':{'header_counts':dict(by_level),
      'complete_warn_error_fatal_headers':[{'level':a,'logger':b,'message':c} for a,b,c in headers],
      'batches':re.findall(r"Running test batch '([^']+)' \((\d+) tests\)",native),
      'completion_markers':re.findall(r'All \d+ required tests passed',native),
      'last_tracker':progress[-1] if progress else None,
      'missing_structure_exception':'Could not find structure file gameteststructures\\empty.snbt' in native,
      'limit':'An aborted native cohort has no final required-test count or completed jackhammer cohort.'}}
for file in (SOURCE/'build/gametest/crash-reports').glob('*.txt'):
    shutil.copy2(file,LEAF/('native-'+file.name))
    data['native'].setdefault('crash_reports',[]).append({'file':'native-'+file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
root=pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01')
root_evidence={'observed_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
               'leaf':str(root),'directory_names':sorted(p.name for p in root.iterdir() if p.is_dir()),'records':[]}
for name in ('QUALIFICATION-03.json','DRIVER-PACKAGE-01.json','PACKAGED-DRIVER-REVIEW-TASK-01.md'):
    p=root/name
    if p.is_file():
        b=p.read_bytes();root_evidence['records'].append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        (LEAF/('root-observed-'+name)).write_bytes(b)
root_evidence['limit']='No completed separately packaged two-process continuation evidence directory is available in this observed catalogue. Root owns that execution; no independent restart was attempted.'
(LEAF/'root-evidence-observation.json').write_text(json.dumps(root_evidence,indent=2),encoding='utf8')
(LEAF/'results-summary.json').write_text(json.dumps(data,indent=2),encoding='utf8')
print(json.dumps({'native_headers':dict(by_level),'completion_markers':data['native']['completion_markers'],
                 'batches':data['native']['batches'],'missing_structure_exception':data['native']['missing_structure_exception'],
                 'root_observed':root_evidence},indent=2))
