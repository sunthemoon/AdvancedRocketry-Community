import csv, fnmatch, hashlib, io, json, pathlib, subprocess, sys, zipfile
from run_checks import LEAF, SOURCE

BASE='106d31653f8bce66761c919742629a75a047e2ca'
CANDIDATE='53523bcf68af203934845521e97af2f824b2958d'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=SOURCE)
def old(path): return git('show',BASE+':'+path)

record=json.loads((SOURCE/'docs/provenance/v1.8.0-c18b-jackhammer.json').read_text(encoding='utf8'))
checks=[]
def check(name, condition, detail):
    checks.append({'name':name,'pass':bool(condition),'detail':detail})
    if not condition: print('FAILED',name,detail)
targets=[]
manifest=list(csv.DictReader((SOURCE/'legacy-manifest/assets.csv').open(encoding='utf8',newline='')))
upstream=pathlib.Path('C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/upstream/ar')
for entry in record['entries']:
    target=SOURCE/entry['target_path']
    source=(upstream if entry['status']=='UPSTREAM_AR_MIT' else SOURCE)/entry['source_path']
    t,s=sha(target.read_bytes()),sha(source.read_bytes())
    targets.append({'target':entry['target_path'],'bytes':target.stat().st_size,'target_sha256':t,
                    'source':str(source),'source_sha256':s,'status':entry['status']})
    check('target '+entry['target_path'],t==entry['target_sha256'],t)
    check('source '+entry['source_path'],s==entry['source_sha256'],s)
    if entry['status']=='UPSTREAM_AR_MIT':
        row=next(r for r in manifest if r['source_path']==entry['source_path'])
        check('MIT recipe legacy registration',row['sha256']==s and row['source_commit']==entry['source_commit'],row)
core={k:v for k,v in record.items() if k!='review'}
digest=sha((json.dumps(core,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode())
check('pending review digest',digest==record['review']['content_digest'] and record['review']['status']=='PENDING_HUMAN_REVIEW',digest)

plan_path='docs/work/v1.8.0-asset-plan.csv'
before=list(csv.DictReader(io.StringIO(old(plan_path).decode())))
after=list(csv.DictReader((SOURCE/plan_path).open(encoding='utf8',newline='')))
effect=[]
for row in manifest:
    asset=row['source_path'].removeprefix('src/main/resources/assets/advancedrocketry/')
    b=next(rule for rule in before if fnmatch.fnmatchcase(asset,rule['pattern']))
    a=next(rule for rule in after if fnmatch.fnmatchcase(asset,rule['pattern']))
    keep=lambda rule:{k:v for k,v in rule.items() if k!='order'}
    if keep(a)!=keep(b): effect.append({'asset':asset,'before':b,'after':a})
check('effective asset plan delta',len(effect)==1 and effect[0]['asset']=='recipes/jackhammer.json'
      and effect[0]['before']['handling']=='REGENERATE' and effect[0]['after']['handling']=='IMPORTED',effect)
check('plan order contiguous',[int(r['order']) for r in after]==list(range(1,len(after)+1)),len(after))
guard_paths=['docs/work/v1.8.0-asset-import-allowlist.txt','docs/provenance/v1.8.0-origin-findings.json',
             'docs/work/v1.8.0-content-ledger.csv','build.gradle','settings.gradle','gradle.properties',
             'src/main/resources/META-INF/mods.toml']
for path in guard_paths: check('unchanged '+path,old(path)==(SOURCE/path).read_bytes(),sha((SOURCE/path).read_bytes()))
for lang in ('en_us','zh_cn'):
    path='src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/'+lang+'.json'
    b=json.loads(old(path));a=json.loads((SOURCE/path).read_text(encoding='utf8'))
    check('additive '+lang,all(a.get(k)==v for k,v in b.items()) and len(a)-len(b)==4,sorted(set(a)-set(b)))
recipe_path='src/generated/v1.8/resources/data/advancedrocketrycommunity/recipes/jackhammer.json'
legacy=json.loads((upstream/'src/main/resources/assets/advancedrocketry/recipes/jackhammer.json').read_text())
modern=json.loads((SOURCE/recipe_path).read_text())
check('recipe shaped count and mapping',modern['pattern']==legacy['pattern'] and modern['result']['count']==legacy['result']['count']==1
      and {k:v['tag'] for k,v in modern['key'].items()}=={'d':'forge:gems/diamond','t':'forge:rods/titanium',
         'i':'forge:rods/iron','p':'forge:plates/aluminum','m':'advancedrocketrycommunity:motors'},modern)
changed=git('diff','--name-only',BASE,CANDIDATE).decode().splitlines()
hashes=[{'path':p,'sha256':sha((SOURCE/p).read_bytes()),'bytes':(SOURCE/p).stat().st_size} for p in changed]
gov=['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','UPSTREAM.md','NOTICE.md',
     'docs/01-PORTING-PRINCIPLES.md','docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md','docs/04-VERSION-ROADMAP.md',
     'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/08-ASSET-LICENSE-AND-PROVENANCE.md',
     'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md','docs/16-POST-1.0-VERSION-ROADMAP.md',
     'docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
     'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
     'docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md',
     'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
     'docs/provenance/v1.8.0-c18b-jackhammer-preauthoring.md',
     'docs/work/v1.8.0-c18b-jackhammer/ADOPTION-01.md', 'docs/work/v1.8.0-c18b-jackhammer/TASK-01.md',
     'gradlew.bat','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties']
tools=['scripts/validate_repository.py','scripts/validate_v180_content_ledger.py','scripts/validate_bootstrap_provenance.py',
       'scripts/validate_build_artifact.py','tools/audit/vanilla_derivation.py','tools/audit/fetch_vanilla_clients.py']
data={'base':BASE,'candidate':CANDIDATE,'head':git('rev-parse','HEAD').decode().strip(),
      'targets':targets,'effective_asset_plan_changes':effect,'checks':checks,'changed_file_hashes':hashes,
      'governance_and_tool_hashes':[{'path':p,'sha256':sha((SOURCE/p).read_bytes())} for p in gov+tools]}
(LEAF/'static-audit.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'checks':len(checks),'failed':sum(not c['pass'] for c in checks),'changed_files':len(changed),
       'effective_asset_plan_changes':effect,'provenance_digest':digest},ensure_ascii=False,indent=2))
sys.exit(1 if any(not c['pass'] for c in checks) else 0)
