import datetime,hashlib,json,pathlib,shutil,sys
from run_checks import LEAF,SOURCE,run

paths=[pathlib.Path(sys.executable),pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/java.exe'),
       pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javac.exe'),pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'),
       pathlib.Path(shutil.which('git'))]
data={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,
      'tool_hashes':[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],
      'artifacts':json.loads((LEAF/'artifact-inspection.json').read_text())['artifacts'],
      'snapshot':{'tmp_bytes':sum(p.stat().st_size for p in (LEAF/'_tmp').rglob('*') if p.is_file()),
                  'retained_bytes_before_final_report':sum(p.stat().st_size for p in LEAF.rglob('*') if p.is_file() and not {'_tmp','__pycache__'} & set(p.relative_to(LEAF).parts))}}
(LEAF/'final-input-tool-artifact-identities.json').write_text(json.dumps(data,indent=2),encoding='utf8')
run('actual-gradle-java-version',['C:/Program Files/Java/jdk-17.0.7/bin/java.exe','-version'])
run('gradle-version',['gradlew.bat','--version'])
run('fixed-final-head',['git','rev-parse','HEAD'])
run('fixed-final-diff',['git','diff','--exit-code'])
run('fixed-final-status',['git','status','--short'])
print(json.dumps({'tmp_bytes':data['snapshot']['tmp_bytes'],'artifacts':[(a['name'],a['sha256']) for a in data['artifacts']]},indent=2))
