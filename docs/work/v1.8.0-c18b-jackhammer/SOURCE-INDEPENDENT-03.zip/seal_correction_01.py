import datetime,hashlib,json,pathlib,sys

root=pathlib.Path(__file__).resolve().parent
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
original=root/'SHA256SUMS.txt'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='4109dcde4b43427f2f8fd6ba06eb1bc7262a28771bc8ac345d8e443a1df5d05b'
assert hashlib.sha256((root/'REPORT.md').read_bytes()).hexdigest()=='be70983b8a786e764e5cb6c6d584c5da2ba1ea7c46effa05c737fd487bd05158'
for line in original.read_text(encoding='utf8').splitlines():
    h,name=line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
meta={'argv':[sys.executable,str(pathlib.Path(__file__).resolve())],'cwd':str(root),'started_utc':started,
      'original_manifest_hashes_verified':854,
      'verification_observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'note':'Supplementary manifest verification prints the actual final exit/result to the caller; original evidence remains unchanged.'}
(root/'seal-correction-command-01.json').write_bytes((json.dumps(meta,indent=2)+'\n').encode('utf8'))
note=root/'SEAL-CORRECTION-01.md'
text=note.read_text(encoding='utf8')
for label in ('FINAL_RETAINED_VALUE','FINAL_UNSEALED_VALUE','FINAL_FILE_COUNT_VALUE','FINAL_LARGEST_VALUE'):
    text=text.replace(label,'0'*20)
note.write_bytes(text.encode('utf8'))
manifest=root/'SHA256SUMS-CORRECTION-01.txt'
paths=sorted(p for p in root.rglob('*') if p.is_file() and p!=manifest
             and not {'_tmp','__pycache__'} & set(p.relative_to(root).parts))
manifest_bytes=sum(64+2+len(p.relative_to(root).as_posix().encode('utf8'))+1 for p in paths)
retained=sum(p.stat().st_size for p in paths)+manifest_bytes
unsealed=sum(p.stat().st_size for p in root.rglob('*') if p.is_file()
             and {'_tmp','__pycache__'} & set(p.relative_to(root).parts))
largest=max(p.stat().st_size for p in paths)
for value in (retained,unsealed,len(paths),largest): text=text.replace('0'*20,str(value).rjust(20),1)
note.write_bytes(text.encode('utf8'))
assert sum(p.stat().st_size for p in paths)+manifest_bytes==retained
assert retained<=100*1024*1024 and largest<=50*1024*1024
lines=[];names=[]
for p in paths:
    relative=p.relative_to(root).as_posix()
    assert '..' not in pathlib.PurePosixPath(relative).parts and not relative.startswith('/')
    assert relative.lower() not in names
    names.append(relative.lower())
    lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+relative+'\n')
manifest.write_bytes(''.join(lines).encode('utf8'))
assert manifest.stat().st_size==manifest_bytes
for line in manifest.read_text(encoding='utf8').splitlines():
    h,name=line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
print(json.dumps({'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'exit':0,'original_hashes_verified':854,'supplementary_covered_files':len(paths),
 'retained_bytes':retained,'unsealed_residual_bytes':unsealed,'largest_retained_file_bytes':largest,
 'report_sha256':hashlib.sha256((root/'REPORT.md').read_bytes()).hexdigest(),
 'original_manifest_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),
 'supplementary_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()},indent=2))
