import datetime, hashlib, json, os, pathlib, shutil, subprocess, time, xml.etree.ElementTree as ET

LEAF = pathlib.Path(__file__).resolve().parent
SOURCE = LEAF / '_tmp' / 'source'
ENV = os.environ.copy()
ENV['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
ENV['PATH'] = ENV['JAVA_HOME'] + '/bin;' + ENV['PATH']
TEMP = LEAF / '_tmp' / 'temp'
TEMP.mkdir(exist_ok=True)
ENV['TEMP'] = ENV['TMP'] = str(TEMP)
ENV['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + str(TEMP).replace('\\', '/')

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(name, argv, timeout=None):
    print('START', name, utc(), flush=True)
    record = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'started_utc': utc(),
              'timeout_seconds': timeout, 'environment': {k: ENV[k] for k in ('JAVA_HOME','TEMP','TMP','JAVA_TOOL_OPTIONS')}}
    with (LEAF / (name + '.log')).open('wb') as log:
        try:
            p = subprocess.Popen(argv, cwd=SOURCE, env=ENV, stdout=log, stderr=subprocess.STDOUT)
            record['pid'] = p.pid
            try: record['exit'] = p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.kill()
                record['exit'] = p.wait()
                record['error'] = 'TIMEOUT'
        except Exception as exc: record.update(exit=None, error=repr(exc))
    record['ended_utc'] = utc()
    record['log_sha256'] = hashlib.sha256((LEAF / (name + '.log')).read_bytes()).hexdigest()
    with (LEAF / 'commands.jsonl').open('a', encoding='utf8') as out: out.write(json.dumps(record) + '\n')
    print('END', name, record['exit'], record.get('error',''), utc(), flush=True)
    return record

def xml_snapshot(name):
    dest = LEAF / name
    dest.mkdir(exist_ok=True)
    records=[]
    for file in sorted((SOURCE / 'build/test-results/test').glob('*.xml')):
        shutil.copy2(file, dest / file.name)
        root=ET.parse(file).getroot()
        records.append({'file':file.name, 'tests':int(root.attrib.get('tests',0)),
            'failures':int(root.attrib.get('failures',0)), 'errors':int(root.attrib.get('errors',0)),
            'skipped':int(root.attrib.get('skipped',0)), 'timestamp':root.attrib.get('timestamp'),
            'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
    data={'files':len(records),'counts':{k:sum(r[k] for r in records) for k in ('tests','failures','errors','skipped')},'xml':records}
    (LEAF/(name+'.json')).write_text(json.dumps(data,indent=2),encoding='utf8')
    print(name,data['counts'],flush=True)

if __name__ == '__main__':
    for n,cmd in [('java-version',['java','-version']),('javap-version',['javap','-version']),
                  ('git-version',['git','--version']),('python-version',['python','--version'])]: run(n,cmd)
    flags=['--no-daemon','--no-build-cache','--rerun-tasks']
    run('clean-build',['gradlew.bat',*flags,'clean','build'])
    xml_snapshot('build-xml')
    run('explicit-test',['gradlew.bat',*flags,'test'])
    xml_snapshot('test-xml')
    for i in (1,2):
        run(f'data-{i}',['gradlew.bat',*flags,'runData'])
        run(f'data-{i}-diff',['git','diff','--exit-code'])
        run(f'data-{i}-status',['git','status','--short'])
    run('gametest',['gradlew.bat',*flags,'runGameTestServer'])
    native = SOURCE / 'build/gametest/logs'
    for name in ('latest.log','debug.log'):
        if (native/name).exists(): shutil.copy2(native/name, LEAF/('native-'+name))
    run('final-status',['git','status','--short'])
