import hashlib, json, pathlib
from run_checks import LEAF, SOURCE, run

JAR=pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP=pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
identities={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (JAR,JAVAP)}
assert identities[str(JAR)]['sha256']=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
assert identities[str(JAVAP)]['sha256']=='69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d'
(LEAF/'native-tool-identities.json').write_text(json.dumps(identities,indent=2),encoding='utf8')
run('javap-absolute-version',[str(JAVAP),'-version'])
classes=['net.minecraft.server.level.ServerPlayerGameMode','net.minecraft.server.network.ServerGamePacketListenerImpl',
 'net.minecraftforge.common.ForgeHooks','net.minecraftforge.common.extensions.IForgeItem',
 'net.minecraftforge.common.TierSortingRegistry','net.minecraft.world.item.Item','net.minecraft.world.item.Item$Properties',
 'net.minecraft.world.item.TieredItem','net.minecraft.world.item.DiggerItem','net.minecraft.world.item.PickaxeItem',
 'net.minecraft.world.item.Tiers','net.minecraft.world.item.ItemStack','net.minecraft.world.entity.player.Player',
 'net.minecraft.world.inventory.AnvilMenu','net.minecraft.world.inventory.CraftingMenu','net.minecraft.world.item.crafting.RepairItemRecipe',
 'net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase','net.minecraftforge.common.ForgeConfigSpec$Builder',
 'net.minecraft.commands.CommandSourceStack','net.minecraft.server.players.PlayerList','net.minecraft.world.level.storage.PlayerDataStorage']
(LEAF/'native').mkdir(exist_ok=True)
for c in classes:
    result=run('native/'+c.rsplit('.',1)[-1].replace('$','-'),[str(JAVAP),'-J-Djava.io.tmpdir='+str(LEAF/'_tmp/temp'),'-classpath',str(JAR),'-c','-p',c])
    assert result['exit']==0
identities['after']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (JAR,JAVAP)}
(LEAF/'native-tool-identities.json').write_text(json.dumps(identities,indent=2),encoding='utf8')
