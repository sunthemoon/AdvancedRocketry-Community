$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03')
$targets = @([IO.Path]::GetFullPath("$leaf/_tmp"), [IO.Path]::GetFullPath("$leaf/__pycache__"))
$record = @{ utc = (Get-Date).ToUniversalTime().ToString('o'); attempts = 1; leaf = $leaf; targets = $targets; status = 'NOT_EXECUTED' }
try {
    foreach ($target in $targets) {
        if (-not $target.StartsWith($leaf + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Resolved target escapes owned leaf: $target"
        }
    }
    $active = @(Get-CimInstance Win32_Process | Where-Object {
        $_.ProcessId -ne $PID -and $_.CommandLine -and ($_.CommandLine.Contains($leaf) -or $_.CommandLine.Contains($leaf.Replace('\', '/')))
    } | Select-Object ProcessId, ParentProcessId, Name, CommandLine)
    $record.activeProcesses = $active
    if ($active.Count -gt 0) { throw 'A process still references this owned leaf; refusing deletion.' }
    foreach ($target in $targets) {
        if (Test-Path -LiteralPath $target) {
            $root = Get-Item -LiteralPath $target -Force
            if ($root.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse target: $target" }
            $reparse = @(Get-ChildItem -LiteralPath $target -Recurse -Force -Attributes ReparsePoint)
            if ($reparse.Count -gt 0) { throw "Reparse descendants: $target" }
        }
    }
    $record.containmentAndReparseChecks = 'PASS'
    foreach ($target in $targets) {
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    }
    $record.status = 'REMOVED'
} catch {
    $record.status = 'FAILED_NO_RETRY'
    $record.error = $_.ToString()
} finally {
    $record.finishedUtc = (Get-Date).ToUniversalTime().ToString('o')
    $record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$leaf/cleanup-result.json" -Encoding utf8
    $record | ConvertTo-Json -Depth 6
}
if ($record.status -ne 'REMOVED') { exit 1 }
