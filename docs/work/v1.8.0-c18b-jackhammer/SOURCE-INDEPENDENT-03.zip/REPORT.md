# Fixed jackhammer source qualification: 53523bcf

## Findings (severity order)

### M1 — New adapter test resolves an absent structure and aborts the full native suite

At the reviewed commit, `src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java:66`
declares `@GameTest(template = "empty", ...)` without a host `templateNamespace`.
Its class has `@GameTestHolder(AdapterTestMod.MOD_ID)`, so the pinned Forge
`getTemplateNamespace` resolves `arce_adapter_test:empty`. No such structure is
provided; the existing empty structure belongs to the host namespace. The
unchanged adjacent adapter tests explicitly select their host template namespace.
See the [complete fixed diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/actual-complete.diff)
and [fresh native primary route](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/native/ForgeGameTestHooks.log).

The independent unfiltered `runGameTestServer` exits 1, with
`Could not find structure file gameteststructures\empty.snbt`, a server-tick
crash, and no final required-test completion marker. The authority test does not
execute its assertions; the thirteen new tool tests do not form a completed
native cohort. This is a development test-suite blocker, not evidence that the
opt-in command crashes a normal packaged gameplay server. Select the existing
host template namespace and qualify a new committed input without changing its
assertions or timeout. [Actual native log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/native-latest.log),
[crash report](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/native-crash-2026-10-09_10.41.59-server.txt).

### L1 — The derived recipe record omits the required upstream-touch history

At the reviewed commit, `docs/provenance/v1.8.0-c18b-jackhammer.json:105-120`
records the upstream snapshot, file hash and transformations but no list of
upstream commits that touched that source file. ADR-061 section 4.9 requires
that per-source history. The pre-authoring record likewise names only the
snapshot/hash, with no linked touch-history record in this candidate. The
approved local C14 tree is an export, not a Git checkout, and cannot independently
establish that history. The byte-exact recipe does match the committed manifest
and MIT pin; this finding does not assert an unlawful source. Add a verifiable
history list/source and bind it into the pending provenance digest before
provenance closure. [Fixed diff and entry](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/actual-complete.diff),
[actual source/hash audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/static-audit.json).

No additional change-required production implementation finding was identified
within this bounded source review. That statement does not convert incomplete
runtime, provenance or Gate evidence into a pass.

## Input and authority identities

- Source: `D:/GitHub/arce-v180-jackhammer-20261009`.
- Candidate: `53523bcf68af203934845521e97af2f824b2958d`.
- Full adoption base: `106d31653f8bce66761c919742629a75a047e2ca`.
- Snapshot began at `2026-10-09T02:30:29.8723531Z`; source status was empty.
  A `git -c core.longpaths=true clone --no-hardlinks --no-checkout` and detached
  candidate checkout created the exclusively owned copy. Clone/checkout exit 0.
  Main, Root, original source worktree and mutable HEAD interests were released
  immediately after this snapshot. No later source/HEAD interest was reacquired.
- Reviewed the complete 31-file actual diff, adjacent implementation, adoption,
  pre-authoring/final provenance, both source checkpoints and both corrective
  preparation/checkpoint pairs, including the adapter. No source edit, staging,
  commit, push, installation, policy/global-setting change or delegation occurred.
- Java runtime: Oracle `17.0.7+8-LTS-224`; Gradle `8.8`; Minecraft `1.20.1`;
  Forge `47.4.10`; Python `3.13.15`. The original shell had a Zulu Java17 JRE,
  but every actual Gradle run selected the existing Oracle JDK through JAVA_HOME.
- Mapped native JAR: SHA-256
  `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
  Java17 javap: `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`.
  Both match the pinned contract archive before inspection; initial/after hashes,
  complete native bytecode and all 23 successful class inspections are retained.

[Inputs](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/INPUT-IDENTITY.txt),
[Git history](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/source-log.txt),
[tool/source hashes](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/final-input-tool-artifact-identities.json).

## Actual commands and results

All Gradle task commands use `gradlew.bat --no-daemon --no-build-cache --rerun-tasks`
in the private fixed checkout. TEMP, TMP and Java temporary files belong to its
owned `_tmp`. Exact argv/cwd, UTC start/end, exits, process IDs, errors and raw
combined outputs are in [commands.jsonl](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/commands.jsonl).

| Actual command/check | Exit and actual result |
|---|---|
| `clean build` | 0; 02:31:53–02:35:12 UTC; 20 actionable tasks executed. 381 fresh XML /2,192 tests /0 failures /0 errors /0 skips. `jarJar` and `reobfJarJar` are explicitly SKIPPED, not executed checks. |
| Explicit `test` | 0; 02:35:12–02:38:44 UTC; 17 actionable tasks executed. A separate 381 fresh XML /2,192 tests /0 failures /0 errors /0 skips. |
| First `runData` | 0; 02:38:45–02:39:42 UTC; 10 tasks executed, then separate empty `git diff --exit-code` and `git status --short`, both exit 0. |
| Second `runData` | 0; 02:39:42–02:40:26 UTC; 10 tasks executed, then separate empty diff/status, both exit 0. |
| Unfiltered `runGameTestServer` | 1; 02:40:27–02:42:00 UTC; 18 tasks executed; M1 crash before required-test completion. No native pass count is asserted. |
| Accepted content ledger | 0; 653 units /898 assets; 186 PLANNED units remain. No `--closure` or full-delivery claim. |
| Approved bootstrap provenance | 0; validates the accepted historical v0.0.2 authority, not approval of new jackhammer provenance. |
| Strict `validate_repository.py --require-approved-identity` | TIMEOUT at its unchanged 180-second deadline; wrapper exit 1, zero output bytes. No strict report or link-check result is available from this attempt. |
| Adoption-to-candidate `git diff --check` | 0, empty. |
| Independent target/source/effective-plan audit | 0; 28 checks. All seven target/source hashes and pending content digest match; exactly one effective asset-plan change. |
| Unchanged NEW PNG screen | 0; CLEAR against both hash-verified pinned vanilla clients; 16x16 RGBA /82 opaque pixels /169 bytes. Human review and V1/V2 remain open. |
| Build-artifact validator | 0; 3,586 entries; metadata, notices, paths and credential scan pass. |
| Owned additional artifact/provenance audit | Initial helper exits 1 due to invalid encoding spelling; complete traceback retained. Corrected helper is a separate exit-0 run, with no repository edit. No duplicate/forbidden target, unrecorded exact legacy hash or bundled continuation adapter is found in the main JAR. |
| Final fixed HEAD/diff/status | 0; exact candidate, empty diff/status after all tests. |

The two [build XML](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/build-xml.json)
and [explicit-test XML](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/test-xml.json)
cohorts preserve every actual XML file independently. No cached/inherited cohort
is counted as execution. Compiler deprecations and Gradle warnings remain in raw
logs. All exploratory path/PATH/argument failures are retained in
[exploratory-errors.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/exploratory-errors.txt).

## Native observations and evidence limitations

Fresh latest.log has **114 WARN, 8 ERROR and 2 FATAL headers**, all retained with
their full messages and tracebacks. The 8 ERROR headers include intentional
energy-only migration save-fault observations, three pre-bound-tag recipe
diagnostics, and the new unexpected exception/crash. They are not erased or
waived. No `All N required tests passed` marker occurs. Source existence,
compilation and partial tracker progress do not establish native jackhammer
success. [Complete observations](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/results-summary.json),
[fresh debug log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/native-debug.log).

The tool preserves actual diamond tier/native events, native single-target
progress/loot/wear/anvil semantics and final disabled mining/melee hooks. No new
transaction, tier, scan/AOE, packet, world-state service, schema or save veto is
added. COMMON prediction does not prove synchronization. Tests distinguish direct
destroyBlock from admission, synchronous game-mode ticks from elapsed ticks,
embedded native actors from real clients, and unavailable-registry BUILD denial
from the full station permission matrix. Actual source details are in
[SOURCE-OBSERVATIONS.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/SOURCE-OBSERVATIONS.md).

The effective asset plan changes only `recipes/jackhammer.json` from REGENERATE
to IMPORTED. All other effective handling, the allowlist, origin findings and
content ledger remain unchanged. Generated languages are additive, and the model
references native resources without copying them. The recipe is MIT-derived;
the bitmap is NEW development art. Neither is human-approved provenance.

Root's available qualification/driver records were snapshotted and inspected at
02:43:54 UTC. No completed separately packaged two-process continuation evidence
was available in that catalogue. Root owns that execution; this reviewer ran no
independent restart. The adapter compiles separately and is absent from the host
JAR, but compile/native tests imply neither packaged persistence nor S2.
[Observed Root evidence](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/root-evidence-observation.json).
Any subsequent corrective commit is outside this fixed qualification and is not
credited as closing M1 or L1 here.

Unexecuted/unproven: full corrected native cohort, completed strict validation,
packaged continuation, survival titanium/steel/motor acquisition, above-diamond
third-party tiers/mod interactions, hostile native packet admission, two-player
contested targets, V1/V2, human asset/license approval, reference performance,
crash recovery and all version Required Gate approval. Supplied test materials
do not prove a reachable survival technology chain. No assertion, timeout,
filter, detector threshold or budget was weakened.

## Artifact identities

| Artifact (not retained as a binary) | SHA-256 |
|---|---|
| Main JAR | `0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011` |
| API JAR | `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b` |
| Sources JAR | `7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a` |

Complete relative entry/size/hash manifests and target/provenance checks are
retained; no JAR, world, source tree or server copy is part of the sealed package.

## Scope, cleanup, Gate conclusion and next action

Completed: independent complete actual-diff/adjacent-source review; mandatory
fixed commands; fresh dual XML capture; deterministic generation; accepted
ledger/bootstrap and artifact/source/hash checks; direct PNG inspection and
unchanged screening; retained failures and compact evidence. Candidate changes
contain nine new JUnit cases, thirteen main native cases and one adapter native
case. The reviewer changed only owned evidence/helpers, never repository files.

Incomplete: M1/L1 qualification, the strict timeout and the separate obligations
above. **This fixed candidate is not fully qualified. Current version G0–G9 are
not all satisfied; no Required Gate is approved.** Acceptance remains v1.0 under
ADR-060; v1.8 development remains IN_PROGRESS /IMPLEMENTING.

Before sustained work, C/D available space exceeded 10 GiB. After all owned
commands ended, one native PowerShell cleanup checked absolute containment,
absence of reparse points and actual process ownership, then removed only this
leaf's `_tmp` and `__pycache__`. It succeeded at 02:47:21.6494377 UTC. One attempt;
no denial, retry, alternate shell/policy mode, other-agent cleanup or Root takeover.
The pre-cleanup disposable set was 1,319,383,343 bytes. No owned process survives.
Main/Root/original source/mutable HEAD interests remain released.
[Cleanup result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03/cleanup-result.json).

Sealed retained bytes, including manifest:              8302566.
Unsealed disposable/residual bytes:                    0.
Sealed evidence files, excluding the manifest:                  854.
Largest retained file bytes:               765383.
Only compact relative evidence is sealed; limits are 50 MiB/file and 100 MiB/slice.

Recommended next action: qualify a new committed current-version correction for
M1/L1, preserve this failed fixed cohort, complete the separately assigned short
packaged continuation, and retain every other current-version obligation. Do not
rename/remove the newly permanent ID or infer release acceptance from this review.
