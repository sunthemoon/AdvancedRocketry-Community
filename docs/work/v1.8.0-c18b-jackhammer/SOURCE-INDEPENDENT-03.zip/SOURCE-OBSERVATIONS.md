# Independent fixed-source observations

Reviewed the complete 31-file adoption-to-candidate diff (1,559 insertions and
135 deletions), not only historical findings. The actual recipe, unlock, model,
tag, both language files and PNG were read/inspected. The PNG displays a narrow
bit, compact vertical body and cross-handle on transparency; this is direct
asset inspection, not a GPU/client or human licensing approval.

## Production and neighboring routes

- JackhammerItem lines 25-33 select actual Tiers.DIAMOND, maximum damage 1,024,
  constructor attack bonus 1 and speed -2.8. No tier registry or project NBT root
  is introduced. The inherited TieredItem constructor uses defaultDurability,
  which does not replace explicitly configured damage. DiggerItem preserves
  native damage/attribute/enchantment/tier semantics.
- The tag-only speed decision and live forge:rods/titanium repair predicate are
  distinct from inherited correct-tool-for-drops checks. DiggerItem's actual
  Forge sorted-tier route remains intact; there is no blanket harvesting override.
- Pinned ServerPlayerGameMode.destroyBlock (native/ServerPlayerGameMode.log
  around lines 670-822) executes ForgeHooks.onBlockBreakEvent first, rejects its
  -1 result, then calls ItemStack.onBlockStartBreak before wear or removal.
  The item's disabled refusal is therefore independent of a listener uncanceling
  BreakEvent. Native mineBlock still precedes removeBlock; no stronger durability
  atomicity is established or promised.
- Native handleBlockBreakAction performs the reach, height, mayInteract and
  restricted-game-mode route before progress/destroy handling. The tests call
  this native endpoint, not ServerGamePacketListenerImpl network handling.
  Fixture loading is bounded, owned setup, not proof of arbitrary packet input
  admission. Obsidian progress invokes real game-mode tick methods synchronously,
  not elapsed server or wall time.
- ForgeHooks.onPlayerAttackTarget checks AttackEntityEvent and then the held
  Item.onLeftClickEntity hook before Player.attack continues. Disabled use is
  enforced here; normal melee uses the inherited native path.
- ModItems uses DeferredRegister and RegistryObject for the permanent additive
  jackhammer ID; ModCreativeTabs and the five narrow central bindings are scoped.
  The COMMON switch joins the existing registered override/accessor mechanism.
  It does not establish client/server COMMON synchronization.
- StationManager.onBlockBroken retains the installed BUILD protection route.
  The owned GameTest's proof is an unavailable station registry refusal, not
  the complete owner/member/operator permission matrix.

## Tests, correction and adapter boundaries

The data/config suites add nine JUnit cases. The exact config inventory guard
remains (74) with the obsolete lifecycle assertion preserved. The corrected
boolean spec follows the pinned native validator rather than modifying parsing.
The thirteen main-source native tool methods retain timeoutTicks 100 and the
progress helper's maximum 40 ticks. Crafting/anvil corrections use actual
ContainerLevelAccess and native unchanged-name input; crafting and anvil tests
assert native takes, consumption and XP rather than previews alone.

Fixtures use connected native ServerPlayers and EmbeddedChannels, never
FakePlayer breaking. Setup/teardown preserve captured BE-free cells, remove owned
new drops and release native actors/channels with exception retention. The
station swap, event listeners and switch overrides are restored in finally
blocks. No production scan, packet, service or static world-state collection is
added. This static review is not substituted for the failed native execution.

The separately packaged adapter has a fixed UUID, opt-in property default false,
registry-only host lookup, fixed setup cells, native player load/save and no
continuation reseeding. The command permission predicate additionally requires
the actual MinecraftServer CommandSource, using the pinned withSource identity
rule, not reflection. Its new one-case authority GameTest has a missing template
namespace and aborts the actual unfiltered test server. Production artifacts do
not contain this adapter; the unchanged compat-test-mod build owns its separate
packaging. Compile/native tests do not prove packaged two-process persistence.

## Assets and origin

All seven recorded target/source hashes and the pending review content digest
are independently recomputed. The upstream recipe bytes match the committed
legacy manifest and pinned MIT commit. Its exact rows, counts and modern tag
conversion match the generated output. Both language files preserve every
inherited key/value and add exactly four keys. The model references the native
handheld resource ID; no official model bytes are copied.

Every one of the 898 manifest assets was evaluated under both ordered asset
plans. Only recipes/jackhammer.json changes effective handling, REGENERATE to
IMPORTED. Subsequent order renumbering is mechanical; the import allowlist,
origin findings and content ledger are byte-identical. This is registration of
the actual derived recipe, not legacy bitmap delivery or full item acceptance.
The upstream source entry lacks the upstream-touch history required by ADR-061
section 4.9. The approved local C14 export contains no Git repository, so its
snapshot alone cannot establish that history.

The unchanged screen measures report CLEAR against both SHA-verified official
client JARs for the NEW 16x16 RGBA /82-opaque-pixel/169-byte icon. Detector
thresholds are not changed. This mechanical result does not approve provenance,
close its known detector limitations or supply real-client V1/V2 evidence.
