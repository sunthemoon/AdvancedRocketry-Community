# Independent seal/accounting correction

This is an additive correction to the original fixed-candidate package. No
previous report, log, helper, XML or SHA256SUMS.txt is changed. Source findings,
commands and cleanup outcomes are unchanged.

The first seal helper wrote a valid 854-entry SHA256SUMS.txt, then failed its
manifest byte-size assertion. Windows text-mode output changed each expected LF
to CRLF. The original report's retained-byte calculation therefore undercounts
the actual initial package by 854 bytes. This is an evidence accounting error,
not a source/runtime finding or a failed covered-file hash. The first assertion
trace is retained in seal-first-attempt-errors.txt.

A subsequent read-only hash verification printed all 854 hashes as valid and
the initial actual retained bytes as 8,303,420. Its later report-text read used
the system GBK default instead of UTF-8 and failed with UnicodeDecodeError;
that error is likewise retained. It did not change files.

The original immutable report SHA-256 is
`be70983b8a786e764e5cb6c6d584c5da2ba1ea7c46effa05c737fd487bd05158`.
The original immutable manifest SHA-256 is
`4109dcde4b43427f2f8fd6ba06eb1bc7262a28771bc8ac345d8e443a1df5d05b`.

The supplementary SHA256SUMS-CORRECTION-01.txt covers the complete compact package,
including the unchanged original manifest and these additive corrections. It
uses explicit byte output with LF endings; every relative covered-file hash is
reverified. No disposable source, JAR, world, residual or external file is covered.
The old manifest remains valid for its original cohort; use the supplementary
manifest for the full corrected package.

Final retained bytes including both manifests:              8451171.
Final unsealed disposable/residual bytes:                    0.
Supplementary covered files excluding its own manifest:                  859.
Largest retained file bytes:               765383.
All original files stay byte-identical. Limits remain 50 MiB/file and 100 MiB/slice.
