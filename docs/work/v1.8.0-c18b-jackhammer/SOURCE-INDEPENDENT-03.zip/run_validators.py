from run_checks import run
run('accepted-ledger',['python','scripts/validate_v180_content_ledger.py','--require-accepted'])
run('bootstrap-provenance',['python','scripts/validate_bootstrap_provenance.py','--require-approved-review'])
run('strict-repository',['python','scripts/validate_repository.py','--require-approved-identity'],180)
run('whitespace',['git','diff','--check','106d31653f8bce66761c919742629a75a047e2ca','HEAD'])
