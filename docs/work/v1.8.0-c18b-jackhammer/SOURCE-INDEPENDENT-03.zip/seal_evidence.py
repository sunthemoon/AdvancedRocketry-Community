import hashlib,json,pathlib

root=pathlib.Path(__file__).resolve().parent
report=root/'REPORT.md'
text=report.read_text(encoding='utf8')
labels=['RETAINED_BYTES_VALUE','UNSEALED_BYTES_VALUE','SEALED_FILES_VALUE','LARGEST_BYTES_VALUE']
for label in labels:
    text=text.replace(label,'0'*20)
report.write_text(text,encoding='utf8')
paths=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'
             and not {'_tmp','__pycache__'} & set(p.relative_to(root).parts))
manifest_bytes=sum(64+2+len(p.relative_to(root).as_posix().encode('utf8'))+1 for p in paths)
retained=sum(p.stat().st_size for p in paths)+manifest_bytes
unsealed=sum(p.stat().st_size for p in root.rglob('*') if p.is_file()
             and {'_tmp','__pycache__'} & set(p.relative_to(root).parts))
largest=max(p.stat().st_size for p in paths)
values=[retained,unsealed,len(paths),largest]
for value in values: text=text.replace('0'*20,str(value).rjust(20),1)
report.write_text(text,encoding='utf8')
assert sum(p.stat().st_size for p in paths)+manifest_bytes==retained
assert retained<=100*1024*1024 and largest<=50*1024*1024
lines=[]
for p in paths:
    relative=p.relative_to(root).as_posix()
    assert '..' not in pathlib.PurePosixPath(relative).parts and not relative.startswith('/')
    lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+relative+'\n')
(root/'SHA256SUMS.txt').write_text(''.join(lines),encoding='utf8')
assert (root/'SHA256SUMS.txt').stat().st_size==manifest_bytes
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
    h,name=line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
print(json.dumps({'sealed_files_excluding_manifest':len(paths),'retained_bytes':retained,
                  'unsealed_residual_bytes':unsealed,'largest_retained_file_bytes':largest,
                  'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),
                  'manifest_sha256':hashlib.sha256((root/'SHA256SUMS.txt').read_bytes()).hexdigest()},indent=2))
