# Independent corrected-source review — fixed bab14562

## Findings first

**M1 — Medium: the new BooleanValue test fails the required build and explicit test.**
At fixed-candidate `src/test/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerConfigTest.java:19`,
the assertion rejects the String `"true"`. Both independent, forced, uncached
executions instead return true from `ValueSpec.test`, and fail with expected
false / actual true. The pinned Forge BooleanValue builder explicitly accepts
case-insensitive String `true` and `false`, as well as Boolean values. This is
a test/API-contract mismatch, not evidence that the production disable hook
allows mining. Correct the case matrix to the actual adopted Forge semantics,
retain meaningful invalid-value/default/override assertions, and rerun both full
commands. Do not remove the test or relax the exact 74-value inventory guard.
[Fixed source lines](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/finding-source-lines.txt),
[native BooleanValue builder, lines 1110–1131](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/native/supplement-ForgeConfigSpec-Builder.txt#L1110),
[clean-build XML](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/clean-build/TEST-io.github.sunthemoon.advancedrocketrycommunity.equipment.tool.JackhammerConfigTest.xml).

**M2 — Medium: the new derived-recipe provenance conflicts with the accepted asset plan.**
The added `docs/provenance/v1.8.0-c18b-jackhammer.json:105–120` names the upstream
jackhammer recipe as `UPSTREAM_AR_MIT`. Its first matching asset-plan rule is
unchanged `docs/work/v1.8.0-asset-plan.csv:200`, order 199, `recipes/*.json`,
`REGENERATE`. The accepted ledger validator exits 1: `recipes/jackhammer.json has
a provenance record but is not handled as IMPORTED`. The candidate introduces
the record that triggers this mismatch; this is not an inherited link failure.
Reconcile the exact derived-recipe registration with the accepted mechanical
asset-plan rules without declaring the tool's full acquisition/asset unit delivered
or approving pending human review. Preserve its MIT provenance instead of deleting
or relabeling it merely to pass validation.
[Fixed source lines](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/finding-source-lines.txt),
[actual ledger failure](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/logs/ledger.log),
[first-match record](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/inherited-link-attribution.json).

**L1 — Low: the opt-in adapter command is entity-free, not strictly local-console-only.**
At fixed-candidate `src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java:48`,
permission 4 plus a null entity also admits a native RCON source. Pinned
`RconConsoleSource.createCommandSourceStack` constructs permission 4 and null
entity, with RCON as its command source. This is a narrow mismatch with the
task's console-only disposable-fixture boundary. It is not an unprivileged
gameplay bypass: the fixture is separately packaged, off by default, and requires
permission 4. Constrain the actual native command-source identity and test both
accepted and rejected sources before using it as packaged evidence. No RCON or
other network target was contacted in this review.
[Fixed fixture lines](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/finding-source-lines.txt),
[pinned RCON constructor, lines 42–65](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/native/supplement-RconConsoleSource.txt#L42).

No additional Critical or High source finding was identified in the complete
assigned diff. The fixed candidate is **CHANGES_REQUESTED**, not qualified for
integration by this report. Later candidates are not reviewed or credited here.

## Input, scope, identity and ownership release

Reviewed commit: `bab145626633a7c778ba3606d400d5f29f8659b5`.
Complete adoption base: `106d31653f8bce66761c919742629a75a047e2ca`.
Original source/generated candidate: `61cada9e6042e0149a96a7d97a485bd3996b58db`.
Corrective preparation: `0e89d7c93d2cb636b268aa9011ebfaa3fc40d6c0`.
The actual full diff is 28 files, 1,331 insertions, three deletions, plus the
169-byte new PNG. No presumed finding list limited the review.
[Diff/stat](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/full-diff.patch),
[fixed tree IDs](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/final-fixed-inputs.json).

Required project/product/porting/version/Gate/parallel/asset governance, the
actual V1.8.0 version file, TASK/ADOPTION/checkpoints/corrections/pre-authoring/final
provenance, and relevant accepted ADR-060/061/066 were inspected. The accepted
development exception does not approve release prerequisites or G0–G9.
Forty-seven selected changed/governance inputs are Git-blob/SHA-256 identified in
[input identities](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/input-tool-identities.json).

Initial Main was `96236acb682c060796e41d3837af7991d492d3b1`, with the user's
modified AGENTS.md and inherited untracked directories/archives. These and every
existing worktree/evidence leaf were read-only. A new non-hardlinked local clone
was checked out detached at the fixed candidate under this exclusive leaf's
unsealed `_tmp`. Root was promptly told that Main, Root, source worktree and
mutable HEAD interests were released after that snapshot. All subsequent source
commands used the private fixed checkout, not mutable Main/Root source. Those
interests remain released; the private checkout's final HEAD matched and its
status was empty before cleanup.

There was no project implementation, manual private-source edit, stage, commit,
push, installation, global setting/policy change, client/GPU session, delegation
or cleanup takeover. Root coordinated OpenPet. Per-command `core.longpaths=true`
was used for the owned Windows clone/checkout only. Existing Gradle dependency
caches were reused; no new Gradle installation was requested.

## Actual native/source review

- Registration is additive `advancedrocketrycommunity:jackhammer`, through the
  existing DeferredRegister and creative tab. Actual `Tiers.DIAMOND`, native
  combat/enchantability and inherited Forge tier qualification remain. Explicit
  durability 1,024 survives native tier construction and stack size is one.
  Speed 50 is confined to the pickaxe-mineable tag; other blocks use one.
- COMMON `equipment.classicEnabled` is built before SPEC, registered in the
  existing switch override set and defaults true. No suit/reserve rule changes.
  Native post-BreakEvent `onBlockStartBreak` and pre-hit `onLeftClickEntity`
  refuse disabled use before native removal/attack wear. Tool-action/speed/UI
  prediction are not final authority or proof of client/server config sync.
- Pinned native destruction order remains event cancellation, item hook,
  qualification, wear, removal, loot from the pre-wear item copy. No AOE,
  alternate removal, fake-player harvest, blanket qualification, new packet,
  custom item NBT schema or stronger wear/removal atomicity is added.
- The thirteen native cases cover real native action/progress, stone and
  obsidian loot, survival/creative/last-use wear, negative hardness/reach,
  BreakEvent cancellation/control, unavailable-station BUILD denial,
  disabled/reenabled break and melee, material and same-item/book anvil takes,
  item data, and actual crafting takes with each motor tag member while disabled.
  Listeners/overrides, actors/channels, owned loaded cells and drops are scoped
  and restored. The corrected crafting/anvil access and unchanged-name input
  follow pinned native behavior; distinct actors separate reach admission from
  delayed destruction. Synchronous game-mode progress ticks are not elapsed
  server ticks, direct attack/destroy endpoints are not packet admission, and
  embedded actors are not real clients. Owner/member station and above-diamond
  third-party-tier interactions are not established by these cases.
- The adapter fixture uses native/Forge APIs and registry lookup, not production
  internal classes. Its subscriber belongs to the separate test mod and its JVM
  property defaults off. Stable UUID native login checks the held item's damage,
  name, note and Efficiency before further changes; continuation does not
  manually read/write playerdata or reseed. Native removal performs saving, which
  can report failure through WARN rather than throw: a packaged driver must
  inspect actual stopped playerdata and reject save/load WARN. Fixed setup uses
  one loaded chunk/two BE-free cells, one-target native loot and synchronous
  cleanup. L1 remains an authority limitation of this fixed fixture.

The reviewed native binary is mapped official Forge 1.20.1 / 47.4.10,
19,355,242 bytes, SHA-256
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
It was verified against the contract archive identity before inspection and
rechecked at the end. Java/javap are Oracle 17.0.7; javap SHA-256 is
`69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`.
Git is 2.55.0.windows.5; Python 3.13.15; wrapper Gradle 8.8. Selected full native
disassemblies and exact supplemental commands are retained, not the JAR.

## Independent commands and actual outcomes

Every Gradle command below used Java 17, owned TEMP/TMP/Java tmp, and
`--no-daemon --no-build-cache --rerun-tasks`. No test filter/assertion/timing
budget was changed. Exact argv/cwd/UTC/exit/source/log hashes are in
[commands.jsonl](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/commands.jsonl).

| Actual command | Exit/result |
|---|---|
| `gradlew.bat ... clean build` | **1**; 20 actionable tasks executed; 2,192 tests / 381 XML; one failure, zero errors/skips: M1. Adapter class compilation executed. `jarJar` and `reobfJarJar` explicitly SKIPPED, not test skips. |
| `gradlew.bat ... test` | **1**; 17 actionable tasks executed; separate 2,192 tests / 381 XML; same sole failure, zero errors/skips. |
| `gradlew.bat ... runData`, first | **0**; all ten tasks executed; fresh generation/cache, 846 files. |
| `git diff --exit-code`, after first DataGen | **0**; empty. |
| `gradlew.bat ... runData`, second | **0**; all ten tasks executed; providers reran, native cache wrote zero changed files. |
| `git diff --exit-code`, after second DataGen | **0**; separate empty result. |
| Unfiltered `gradlew.bat ... runGameTestServer` | **0**; all 578 required tests passed, including 13 in `jackhammer_native:1`; 18 actionable tasks executed. |
| `python scripts/validate_v180_content_ledger.py --require-accepted` | **1**; M2. No closure or delivery approval inferred. |
| `python scripts/validate_bootstrap_provenance.py --require-approved-review` | **0**; historical approved bootstrap provenance at 9359257b9fe1eccf7e0043dfa7f626cf1ee44be9. |
| `python scripts/validate_repository.py --require-approved-identity` | **1**, after actual completion; 44 checks passed, one failed Markdown-link group capped at 256 errors. Not a timeout and not a strict PASS. |
| `git diff --check 106d3165... HEAD` | **0**; full adoption whitespace clean. |
| Owned resource/artifact/art-screen, observation capture and final observation scripts | **0** each; hashes, cohort totals, inherited-link attribution and fixed final identities retained. |

Both full XML cohorts and raw combined logs remain separate. The native suite's
raw log includes 62 ERROR entries from negative-path cases (intentional migration
save injection, unbound recipes, launch failures, protocol refusals and oversized
save guards); they were not removed. No ERROR is in the jackhammer batch, and
no native playerdata save/load failure warning was observed. This is not a
clean-log packaged-server or persistence Gate claim.
[Native summary/raw errors](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/native-summary.json).

All 256 surfaced broken-link source files are byte-identical to the adoption
base. Failures include inherited absolute/out-of-root links and archives/hash
files that Main had only as excluded untracked local inputs and thus were not in
the fixed private clone. Their absence was not patched around. The validator's
256-error cap prevents claiming an exhaustive link pass. Attribution records
the actual failures, not a waiver or a pass.

Two initial uninstrumented exploratory path errors are retained as transcribed
observations in [exploratory-errors](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/exploratory-errors.txt).
Their UTC timestamps were not captured; this limitation is explicit. Both were
resolved by reading the actual fixed-tree paths, not hidden or treated as passes.

## Generated bytes, provenance and artifacts

Seven target hashes, NEW authoring-source hashes and the pending schema-2 digest
`b176422d37beb327b4ee0879028097973709b20b4aa63936b4f7984926654b46`
match. The byte/CRC/hash-verified contract archive contains the 666-byte MIT
upstream recipe with SHA-256
`a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45`.
Modern shaped layout/counts/tags and one-tool result preserve the adopted recipe;
the motor unlock and additive pickaxes tag parse correctly. Existing bilingual
language values are unchanged; exactly the four declared new keys are added.

Actual PNG decoding gives 16×16 RGBA with 82 opaque pixels. The image was directly
inspected. The unchanged project derivation implementation independently returned
**CLEAR** against both byte-verified pinned vanilla clients. This is mechanical
screening, not human license/visual approval, real V1/V2, or legacy IMPORT bitmap
delivery. The provenance remains pending human review.

Runtime JAR: 6,073,913 bytes, SHA-256
`0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011`.
API JAR: `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
Sources JAR: `7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a`.
ZIP CRCs and duplicate/case checks pass; the runtime JAR contains the native item,
the seven exact resources and LICENSE/NOTICE, and excludes the adapter fixture.
The fixture compiled separately (15,546-byte class); this is not separate
compat-test-mod packaging or restart proof. Artifact hashes are unchanged after
native execution. No JAR/full tree/world is retained in the evidence.
[Resource/artifact results](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/resources-artifacts.json),
[art screening](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/art-screen.json).

## Root evidence observations and remaining limits

Historical Root build-01/native-01 remain bound to 61cada9e. Its original config
inventory and four native failures are historical observations, not rewritten
as passes by this candidate's results. Root build-02 independently records this
candidate's new BooleanValue failure. Selected exact raw-result/log identities
are retained in [Root observations](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/root-observations.json).
They did not substitute for independent commands.

At report time Root explicitly reports no packaged continuation execution for
this candidate. No main-plus-fixture artifact-bound two-process dedicated restart
was independently performed or credited. The later 53523bcf candidate mentioned
by Root is outside this fixed review and has no result in this report.
Real-client packet/config behavior, contested two-player targets, full station
permission matrix, above-tier/third-party interactions, survival titanium/steel
progression, legacy asset closure, human asset review and V1/V2 remain open.

Review execution is complete; no project test was added/modified. Key design
choices preserve native item authority, ordinary item persistence, stable ID,
bounded private fixtures and unchanged pending asset review. All writes are
review logs/scripts/results beneath the exclusive evidence leaf. There is no
implementation delivery, release/tag decision or central state/ledger change.
**No complete Required Gate is approved.** v1.8 remains IN_PROGRESS / IMPLEMENTING,
with inherited v1.0 acceptance and G0–G9 obligations unchanged. For the current
v1.8 slice, correct the findings, review/rerun a new fixed candidate, then obtain
the separately required packaged continuation and player/asset evidence.

## Cleanup, retained volume and sealing

Initial C/D free space was 30,487,150,592 / 296,406,310,912 bytes; both exceed
10 GiB. Disk was checked again before DataGen/native work and cleanup. All owned
commands completed before removal; exact command PIDs and matching owned process
interests were no longer live. After resolved-absolute containment and zero
reparse-point checks, **one** native PowerShell Remove-Item attempt removed only
this review's `_tmp`: 15,874 disposable files, **1,449,899,962 bytes**. It removed
the clone/build/world/runtime tmp, not source/input worlds or any earlier leaf.
There was no denial, retry, alternate-shell workaround, process termination or
Root takeover. Unsealed owned disposable bytes afterward: **0**; no retained
source tree, JAR, exported server or temporary archive remains.
[Cleanup result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/cleanup.json).

Retained evidence bytes, including the manifest: **8,189,261**.
Each file is below 50 MiB and the complete leaf is below 100 MiB. Exact file/count/
volume data are in [evidence-volume](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/results/evidence-volume.json).
The relative [SHA256SUMS.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-02/SHA256SUMS.txt)
seals only compact replayable scripts, raw logs, full XML cohorts, fixed diff,
selected observation excerpts and hashes. No manifest target references build,
Temp, another leaf or a deleted checkout. Earlier sealed packages were untouched.
Main/Root/source/mutable-HEAD interests remain released.
