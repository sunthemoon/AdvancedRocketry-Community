import csv
import datetime
import fnmatch
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

LEAF=Path(__file__).resolve().parent.parent
SOURCE=LEAF/'_tmp/source'
ROOT=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01')
def gitblob(commit,path): return subprocess.check_output(['git','show',commit+':'+path],cwd=SOURCE)
def sha(data): return hashlib.sha256(data).hexdigest()
observed=[]
for relative in ['build-01/RESULT.json','build-01/JUNIT.json','build-02/RESULT.json','build-02/JUNIT.json','native-01/RESULT.json','resources-01/PROVENANCE-CHECK.json','resources-01/ART-SCREEN.json']:
    path=ROOT/relative
    if path.is_file():
        data=path.read_bytes()
        observed.append({'path':str(path),'bytes':len(data),'sha256':sha(data),'observed_data':json.loads(data)})
path=ROOT/'native-01/command.log'
data=path.read_bytes()
lines=data.decode('utf-8',errors='replace').splitlines()
observed.append({'path':str(path),'bytes':len(data),'sha256':sha(data),
 'selected_lines':[line for line in lines if re.search('Failed|failed|FAILURE|tests passed|required tests|failed on',line)]})
(LEAF/'results/root-observations.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'items':observed,'independent_execution':False},indent=2),encoding='utf-8')
text=(LEAF/'logs/strict-repository.log').read_text(encoding='utf-8',errors='replace')
line=next(l for l in text.splitlines() if l.startswith('[FAIL] Broken Markdown links: '))
items=re.findall(r'(docs/[^;]+?):(\d+) -> ([^;]+)',line)
results=[]
for path,number,target in items:
    base=gitblob('106d31653f8bce66761c919742629a75a047e2ca',path)
    actual=(SOURCE/path).read_bytes()
    results.append({'path':path,'line':int(number),'target':target,'base_sha256':sha(base),'candidate_sha256':sha(actual),'unchanged':base==actual})
assert len(results)==256 and all(item['unchanged'] for item in results)
assetplan=SOURCE/'docs/work/v1.8.0-asset-plan.csv'
rows=list(csv.DictReader(assetplan.open(encoding='utf-8')))
rule=next({'line':i+2,**row} for i,row in enumerate(rows) if fnmatch.fnmatchcase('recipes/jackhammer.json',row['pattern']))
(LEAF/'results/inherited-link-attribution.json').write_text(json.dumps({'reported_errors':len(results),'capped':True,'all_surfaced_source_files_unchanged':True,'errors':results,'jackhammer_asset_first_match':rule},indent=2),encoding='utf-8')
cohorts={}
for label in ['clean-build','explicit-test']:
    files=list((LEAF/'results'/label).glob('*.xml'))
    cohorts[label]={'xml_files':len(files),**{key:sum(int(ET.parse(file).getroot().get(key,'0')) for file in files) for key in ['tests','failures','errors','skipped']}}
(LEAF/'results/junit-cohorts.json').write_text(json.dumps(cohorts,indent=2),encoding='utf-8')
selected=[('src/test/java/io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerConfigTest.java',13,20),
          ('src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java',44,53),
          ('docs/provenance/v1.8.0-c18b-jackhammer.json',107,126),
          ('docs/work/v1.8.0-asset-plan.csv',198,201)]
out=[]
for path,start,end in selected:
    out.append(path+' fixed candidate bab145626633a7c778ba3606d400d5f29f8659b5')
    out.extend(str(n)+': '+line for n,line in enumerate((SOURCE/path).read_text(encoding='utf-8').splitlines(),1) if start<=n<=end)
(LEAF/'results/finding-source-lines.txt').write_text('\n'.join(out)+'\n',encoding='utf-8')
print(json.dumps(cohorts));print('256 surfaced strict link errors have unchanged source files; no strict PASS inferred.')
