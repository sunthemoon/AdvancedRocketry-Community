import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

LEAF = Path(__file__).resolve().parent.parent
SOURCE = LEAF / '_tmp' / 'source'
TMP = LEAF / '_tmp' / 'runtime-tmp'
TMP.mkdir(exist_ok=True)
env = dict(os.environ)
env['JAVA_HOME'] = r'C:\Program Files\Java\jdk-17.0.7'
env['PATH'] = env['JAVA_HOME'] + r'\bin;' + env['PATH']
env['TEMP'] = env['TMP'] = str(TMP)
env['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + str(TMP)
label = sys.argv[1]
args = sys.argv[2:]
if args[0] == 'gradlew.bat':
    args[0] = str(SOURCE / 'gradlew.bat')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
log = LEAF / 'logs' / (label + '.log')
with log.open('wb') as out:
    proc = subprocess.Popen(args, cwd=SOURCE, env=env, stdout=out, stderr=subprocess.STDOUT)
    code = proc.wait()
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
entry = dict(label=label, argv=args, cwd=str(SOURCE), started_utc=started, ended_utc=ended,
             exit_code=code, pid=proc.pid, java_home=env['JAVA_HOME'], temp=str(TMP),
             java_tool_options=env['JAVA_TOOL_OPTIONS'], source_sha=subprocess.check_output(
                 ['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
             log=log.relative_to(LEAF).as_posix(), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (LEAF / 'commands.jsonl').open('a', encoding='utf-8') as out:
    out.write(json.dumps(entry) + '\n')
if label in ('clean-build', 'explicit-test'):
    results = SOURCE / 'build' / 'test-results' / 'test'
    if results.exists():
        target = LEAF / 'results' / label
        target.mkdir(exist_ok=True)
        for file in results.glob('*.xml'):
            shutil.copy2(file, target / file.name)
print(json.dumps(entry), flush=True)
print(log.read_text(encoding='utf-8', errors='replace')[-5000:], flush=True)
sys.exit(code)
