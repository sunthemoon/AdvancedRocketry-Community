import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

LEAF = Path(__file__).resolve().parent.parent
SOURCE = LEAF/'_tmp/source'
sys.path.insert(0,str(SOURCE))
from tools.audit import vanilla_derivation as vd

def digest(data): return hashlib.sha256(data).hexdigest()
def blob(commit,path): return subprocess.check_output(['git','show',commit+':'+path],cwd=SOURCE)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert head=='bab145626633a7c778ba3606d400d5f29f8659b5'
record=json.loads((SOURCE/'docs/provenance/v1.8.0-c18b-jackhammer.json').read_bytes())
core={k:v for k,v in record.items() if k!='review'}
actual=digest((json.dumps(core,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode())
assert actual==record['review']['content_digest']
assert record['review']['status']=='PENDING_HUMAN_REVIEW'
outputs=[]
contract=SOURCE/'docs/work/v1.8.0-c18b-jackhammer/CONTRACT-REVIEW-01.zip'
assert digest(contract.read_bytes())=='533e2c3545b6121494d17336771a72bc5aabb91ed69c630a238cf520cf464136'
with zipfile.ZipFile(contract) as z:
    assert z.testzip() is None
    assert digest(z.read('REPORT.md'))=='6e1b3d9ab6c7285d471f2dd7b3a198c9ad1aa8a15f87f7bbe31eb6d61153dc4e'
    recipe=z.read('upstream-recipe-preimage.txt')
    assert digest(recipe)=='a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45'
for e in record['entries']:
    path=e['target_path']; data=(SOURCE/path).read_bytes()
    assert digest(data)==e['target_sha256'], path
    source=blob(e['authoring_commit'],e['source_path']) if e['status']=='NEW' else recipe
    assert digest(source)==e['source_sha256'],path
    if path.endswith('.json'): json.loads(data)
    if '/lang/' in path:
        old=json.loads(blob('106d31653f8bce66761c919742629a75a047e2ca',path)); new=json.loads(data)
        assert all(new.get(k)==v for k,v in old.items())
        assert set(new)-set(old)==set(e['new_keys'])
    outputs.append({'path':path,'bytes':len(data),'sha256':digest(data)})
art=SOURCE/'src/generated/v1.8/resources/assets/advancedrocketrycommunity/textures/item/jackhammer.png'
w,h,pixels=vd.decode_rgba(art.read_bytes())
assert (w,h)==(16,16) and sum(pixels[i]>0 for i in range(3,len(pixels),4))==82
jars=[]
for jar in sorted((SOURCE/'build/libs').glob('*.jar')):
    with zipfile.ZipFile(jar) as z:
        names=z.namelist(); assert z.testzip() is None
        assert len(names)==len(set(names))==len(set(n.casefold() for n in names))
        if not jar.stem.endswith(('-api','-sources')):
            assert not any('JackhammerContinuationFixture' in n for n in names)
            assert 'io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerItem.class' in names
            assert all(n in names for n in ('META-INF/LICENSE','META-INF/NOTICE.md'))
            for e in record['entries']:
                packaged=e['target_path'].split('src/generated/v1.8/resources/')[1]
                assert digest(z.read(packaged))==e['target_sha256'],packaged
        jars.append({'name':jar.name,'bytes':jar.stat().st_size,'sha256':digest(jar.read_bytes()),'entries':len(names)})
result={'fixed_commit':head,'record_digest':actual,'outputs':outputs,'art':{'width':w,'height':h,'opaque':82},'artifacts':jars}
(LEAF/'results/resources-artifacts.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
clients=[('1.12.2',Path(r'C:\Users\Administrator\AppData\Local\Temp\arce-v180-c14-189c61a748584cab97c5881f8bdc1251\vanilla\client-1.12.2.jar'),'8ada07da5ee77dad3527bd7278fbd05ee1fc8a597813b216a871a2d7d64cc64f'),
         ('1.20.1',Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_repo\versions\1.20.1\client.jar'),'56b71336d2b4fdffd197f56595b0da93e32a946f78f382a299b8f4b92758bb0f')]
for _,path,pin in clients: assert digest(path.read_bytes())==pin
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
sources,_,vanilla=vd.load_vanilla([v+'='+str(p) for v,p,_ in clients])
best=vd.analyse_images([(art.name,vd.Image(w,h,pixels))],vanilla)
_,verdict,detail=best.get(art.name,(None,'CLEAR',{}))
screen={'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':verdict,'detail':detail,'vanilla':sources,'human_review':False}
(LEAF/'results/art-screen.json').write_text(json.dumps(screen,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2));print(json.dumps(screen,indent=2))
assert verdict=='CLEAR'
