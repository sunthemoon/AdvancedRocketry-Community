$ErrorActionPreference = 'Stop'
$leaf = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$expected = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\jackhammer-source-independent-20261009-02'
if ($leaf -cne $expected) { throw 'Unexpected evidence owner root' }
$target = (Resolve-Path -LiteralPath (Join-Path $leaf '_tmp')).Path
if (-not $target.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside owner root' }
$parents = @($leaf, $target)
foreach ($path in $parents) {
    if (((Get-Item -LiteralPath $path).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'Cleanup ancestor is a reparse point'
    }
}
$entries = @(Get-ChildItem -LiteralPath $target -Force -Recurse)
$reparse = @($entries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
if ($reparse.Count -ne 0) { throw 'Owned disposable tree contains a reparse point' }
$processes = @(Get-CimInstance Win32_Process)
$ownedLive = @($processes | Where-Object {
    $_.Name -match '^(java|python|cmd)(\.exe)?$' -and $_.CommandLine -like '*jackhammer-source-independent-20261009-02*'
})
if ($ownedLive.Count -ne 0) { throw 'Owned disposable outputs are still in use' }
$records = @(Get-Content -LiteralPath (Join-Path $leaf 'commands.jsonl') | ForEach-Object { $_ | ConvertFrom-Json })
$recordedLive = @($processes | Where-Object { $_.ProcessId -in $records.pid })
if ($recordedLive.Count -ne 0) { throw 'A recorded command process is still alive; inspect ownership before cleanup' }
$before = [long](($entries | Where-Object { -not $_.PSIsContainer } | Measure-Object Length -Sum).Sum)
$record = [ordered]@{
    started_utc = [DateTime]::UtcNow.ToString('o')
    leaf = $leaf
    resolved_target = $target
    reparse_points = 0
    owned_live_processes = 0
    recorded_command_pids_alive = 0
    disposable_files = @($entries | Where-Object { -not $_.PSIsContainer }).Count
    disposable_bytes_before = $before
    command = 'Remove-Item -LiteralPath <resolved owned _tmp> -Recurse -Force -ErrorAction Stop'
    attempts = 1
}
try {
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    $record.result = 'REMOVED'
} catch {
    $record.result = 'FAILED_OR_DENIED_NO_RETRY'
    $record.error = $_.Exception.Message
}
$record.ended_utc = [DateTime]::UtcNow.ToString('o')
$record.target_exists = Test-Path -LiteralPath $target
$record.unsealed_bytes_after = if ($record.target_exists) {
    [long]((Get-ChildItem -LiteralPath $target -File -Force -Recurse | Measure-Object Length -Sum).Sum)
} else { 0 }
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $leaf 'results/cleanup.json') -Encoding utf8
$processes | Select-Object ProcessId, ParentProcessId, Name, CommandLine | ConvertTo-Json -Depth 3 |
    Set-Content -LiteralPath (Join-Path $leaf 'results/processes-before-cleanup.json') -Encoding utf8
$record | ConvertTo-Json -Depth 5
if ($record.result -ne 'REMOVED') { exit 1 }
