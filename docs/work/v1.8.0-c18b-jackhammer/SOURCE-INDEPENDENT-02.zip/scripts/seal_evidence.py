import hashlib
import json
from pathlib import Path

LEAF=Path(__file__).resolve().parent.parent
MANIFEST=LEAF/'SHA256SUMS.txt'
VOLUME=LEAF/'results/evidence-volume.json'
REPORT=LEAF/'REPORT.md'
assert not MANIFEST.exists(), 'Do not replace an existing seal'
assert not (LEAF/'_tmp').exists(), 'Owned disposable output remains'
template=REPORT.read_text(encoding='utf-8')
assert template.count('{{RETAINED_BYTES}}')==1
VOLUME.write_text('{}\n',encoding='utf-8')
total=0
for _ in range(12):
    REPORT.write_text(template.replace('{{RETAINED_BYTES}}',f'{total:,}'),encoding='utf-8',newline='\n')
    files=sorted((p for p in LEAF.rglob('*') if p.is_file() and p!=MANIFEST),key=lambda p:p.relative_to(LEAF).as_posix())
    assert all(not p.is_symlink() and p.resolve().is_relative_to(LEAF) for p in files)
    names=[p.relative_to(LEAF).as_posix() for p in files]
    assert len(names)==len(set(n.casefold() for n in names))
    assert all(not n.startswith('_tmp/') and ':' not in n and '\\' not in n for n in names)
    payload=sum(p.stat().st_size for p in files if p!=VOLUME)
    manifest_bytes=sum(len(('0'*64+'  '+n+'\n').encode('utf-8')) for n in names)
    largest=max((p.stat().st_size for p in files if p!=VOLUME),default=0)
    value={'retained_files_including_manifest':len(files)+1,'retained_total_bytes_including_manifest':total,
           'payload_bytes_excluding_volume_and_manifest':payload,'manifest_bytes':manifest_bytes,
           'largest_retained_file_bytes':largest,'unsealed_disposable_bytes':0,
           'file_limit_bytes':50_000_000,'slice_limit_bytes':100_000_000,'main_root_source_head_interests':'RELEASED'}
    VOLUME.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
    updated=payload+VOLUME.stat().st_size+manifest_bytes
    if updated==total: break
    total=updated
else: raise AssertionError('Volume fixed point did not stabilize')
assert total<100_000_000 and largest<50_000_000
content=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(LEAF).as_posix()+'\n' for p in files)
MANIFEST.write_text(content,encoding='utf-8',newline='\n')
assert sum(p.stat().st_size for p in LEAF.rglob('*') if p.is_file())==total
for line in MANIFEST.read_text(encoding='utf-8').splitlines():
    expected,name=line.split('  ',1)
    assert hashlib.sha256((LEAF/name).read_bytes()).hexdigest()==expected
print(json.dumps(value,indent=2))
print('REPORT_SHA256='+hashlib.sha256(REPORT.read_bytes()).hexdigest())
print('MANIFEST_SHA256='+hashlib.sha256(MANIFEST.read_bytes()).hexdigest())
