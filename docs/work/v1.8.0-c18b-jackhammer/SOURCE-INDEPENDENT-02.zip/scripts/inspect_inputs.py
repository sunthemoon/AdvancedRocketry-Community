import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

LEAF = Path(__file__).resolve().parent.parent
SOURCE = LEAF / '_tmp' / 'source'
JDK = Path(r'C:\Program Files\Java\jdk-17.0.7')
JAR = Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(JAR) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
assert sha(JDK / 'bin' / 'javap.exe') == '69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d'
identities = {'jar': {'path':str(JAR), 'bytes':JAR.stat().st_size, 'sha256':sha(JAR)}, 'tools':{}}
for name, command in [('java',[str(JDK/'bin/java.exe'),'-version']),('javap',[str(JDK/'bin/javap.exe'),'-version']),('git',['git','--version']),('python',['python','--version'])]:
    p = subprocess.run(command,cwd=SOURCE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    identities['tools'][name] = {'argv':command,'exit':p.returncode,'output':p.stdout.decode(errors='replace')}
changed = subprocess.check_output(['git','diff','--name-only','106d31653f8bce66761c919742629a75a047e2ca','HEAD'],cwd=SOURCE,text=True).splitlines()
required = ['PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md',
            'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/08-ASSET-LICENSE-AND-PROVENANCE.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md','docs/16-POST-1.0-VERSION-ROADMAP.md',
            'docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'UPSTREAM.md','NOTICE.md','docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md',
            'docs/work/v1.8.0-c18b-jackhammer/TASK-01.md','docs/work/v1.8.0-c18b-jackhammer/ADOPTION-01.md',
            'docs/provenance/v1.8.0-c18b-jackhammer-preauthoring.md',
            'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
            'docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md',
            'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md']
identities['fixed_inputs'] = [{'path':p,'bytes':(SOURCE/p).stat().st_size,'sha256':sha(SOURCE/p),
     'blob':subprocess.check_output(['git','rev-parse','HEAD:'+p],cwd=SOURCE,text=True).strip()} for p in sorted(set(changed+required))]
native = LEAF / 'results' / 'native'; native.mkdir(exist_ok=True)
classes = ['net.minecraft.server.level.ServerPlayerGameMode','net.minecraft.world.entity.player.Player',
           'net.minecraft.server.players.PlayerList','net.minecraft.world.level.storage.PlayerDataStorage',
           'net.minecraft.world.item.DiggerItem','net.minecraft.world.item.PickaxeItem',
           'net.minecraft.world.item.TieredItem','net.minecraft.world.item.Item$Properties',
           'net.minecraft.world.inventory.AnvilMenu','net.minecraft.world.inventory.CraftingMenu',
           'net.minecraftforge.common.ForgeHooks','net.minecraftforge.common.TierSortingRegistry']
identities['native_commands'] = []
for cls in classes:
    args=[str(JDK/'bin/javap.exe'),'-J-Djava.io.tmpdir='+str(LEAF/'_tmp/runtime-tmp'),'-classpath',str(JAR),'-c','-p',cls]
    p=subprocess.run(args,cwd=SOURCE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert p.returncode == 0, cls
    output=native/(cls.split('.')[-1].replace('$','-')+'.txt')
    output.write_bytes(p.stdout)
    identities['native_commands'].append({'argv':args,'exit':p.returncode,'output':output.relative_to(LEAF).as_posix(),'sha256':sha(output)})
(LEAF/'results/input-tool-identities.json').write_text(json.dumps(identities,indent=2),encoding='utf-8')
print(json.dumps(identities['tools'],indent=2)); print('fixed inputs',len(identities['fixed_inputs']),'native outputs',len(classes))
