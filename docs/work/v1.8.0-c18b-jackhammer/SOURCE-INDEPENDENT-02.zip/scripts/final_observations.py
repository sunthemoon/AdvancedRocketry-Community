import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

LEAF=Path(__file__).resolve().parent.parent
SOURCE=LEAF/'_tmp/source'
JAR=Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP=Path(r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(JAR.read_bytes())=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
records=[]
for cls in ['net.minecraftforge.common.ForgeConfigSpec$Builder','net.minecraft.commands.CommandSourceStack','net.minecraft.server.rcon.RconConsoleSource','net.minecraft.server.ServerFunctionManager']:
    args=[str(JAVAP),'-J-Djava.io.tmpdir='+str(LEAF/'_tmp/runtime-tmp'),'-classpath',str(JAR),'-c','-p',cls]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc=subprocess.run(args,cwd=SOURCE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    path=LEAF/'results/native'/('supplement-'+cls.split('.')[-1].replace('$','-')+'.txt')
    path.write_bytes(proc.stdout)
    records.append({'argv':args,'cwd':str(SOURCE),'started_utc':start,'ended_utc':end,'exit':proc.returncode,'path':path.relative_to(LEAF).as_posix(),'sha256':sha(proc.stdout)})
    assert proc.returncode==0
(LEAF/'results/native-supplement-commands.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
data=(LEAF/'logs/native-full.log').read_text(encoding='utf-8',errors='replace')
passed=re.search(r'All (\d+) required tests passed',data)
batch=re.search(r"Running test batch 'jackhammer_native:1' \((\d+) tests\)",data)
assert passed and batch and int(passed.group(1))==578 and int(batch.group(1))==13
lines=data.splitlines()
errors=[{'line':i,'text':line} for i,line in enumerate(lines,1) if '/ERROR]' in line]
bad_playerdata=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.search(r'Failed to (save|load) player data',line)]
assert not bad_playerdata
native={'required_passed':578,'jackhammer_batch_tests':13,'error_log_entries':errors,'native_playerdata_warning_entries':bad_playerdata,
        'log_sha256':sha((LEAF/'logs/native-full.log').read_bytes()),'latest_sha256':sha((LEAF/'logs/native-latest.log').read_bytes()),
        'adapter_fixture_independently_executed':False,'packaged_restart_independently_executed':False}
(LEAF/'results/native-summary.json').write_text(json.dumps(native,indent=2),encoding='utf-8')
old=json.loads((LEAF/'results/resources-artifacts.json').read_text(encoding='utf-8'))
for item in old['artifacts']:
    path=SOURCE/'build/libs'/item['name']; assert sha(path.read_bytes())==item['sha256']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
status=subprocess.check_output(['git','status','--short'],cwd=SOURCE,text=True)
assert head=='bab145626633a7c778ba3606d400d5f29f8659b5' and not status
fixture=SOURCE/'build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.class'
final={'head':head,'status':status,'artifacts_unchanged_after_native':True,'compiled_adapter_class':{'bytes':fixture.stat().st_size,'sha256':sha(fixture.read_bytes())},
       'fixed_objects':{c:subprocess.check_output(['git','rev-parse',c+'^{tree}'],cwd=SOURCE,text=True).strip() for c in ['106d31653f8bce66761c919742629a75a047e2ca','61cada9e6042e0149a96a7d97a485bd3996b58db','0e89d7c93d2cb636b268aa9011ebfaa3fc40d6c0','bab145626633a7c778ba3606d400d5f29f8659b5']}}
(LEAF/'results/final-fixed-inputs.json').write_text(json.dumps(final,indent=2),encoding='utf-8')
print(json.dumps({'native_tests':578,'jackhammer_tests':13,'raw_error_entries':len(errors),'playerdata_warnings':len(bad_playerdata),'final_input':final},indent=2))
