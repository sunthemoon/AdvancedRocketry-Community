"""Record cheap post-merge checks without claiming a merge-SHA game rerun."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parent
main = Path("D:/GitHub/AdvancedRocketry-Community")
python = "D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe"
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=main, check=True, capture_output=True).stdout.decode().strip()
assert head == "80bbf16d9e76708b7e39c50d21b3cff1a66432ef"
rows = []
for name, argv in [
    ("postmerge-ledger", [python, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("postmerge-bootstrap", [python, "-B", "scripts/validate_bootstrap_provenance.py", "--require-approved-review"]),
    ("postmerge-whitespace", ["git", "diff", "--check", "e2df95bde1ae9f00b664a26eeaa1e7fa5e3ec7ef", head]),
]:
    start = datetime.now(timezone.utc).isoformat()
    proc = subprocess.run(argv, cwd=main, capture_output=True, timeout=180)
    raw = proc.stdout + proc.stderr
    (root / (name + ".log")).write_bytes(raw)
    rows.append(dict(name=name, argv=argv, source_sha=head, started_utc=start,
                     ended_utc=datetime.now(timezone.utc).isoformat(), exit=proc.returncode,
                     raw_sha256=hashlib.sha256(raw).hexdigest()))
    assert proc.returncode == 0, (name, raw)
(root / "POSTMERGE-CHECKS.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
archives = []
for path in sorted((main / "docs/work/v1.8.0-c18b-jackhammer").glob("*.zip")):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        expanded = sum(i.file_size for i in archive.infolist())
    archives.append(dict(path=path.relative_to(main).as_posix(), bytes=path.stat().st_size,
                         expanded_bytes=expanded, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert sum(a["expanded_bytes"] for a in archives) < 100 * 1024**2
(root / "ARCHIVE-VOLUME-01.json").write_text(json.dumps(dict(archives=archives,
    total_compressed_bytes=sum(a["bytes"] for a in archives),
    total_expanded_bytes=sum(a["expanded_bytes"] for a in archives)), indent=2) + "\n", encoding="utf-8")
print(json.dumps(rows, indent=2))
print("aggregate_expanded_bytes=" + str(sum(a["expanded_bytes"] for a in archives)))
