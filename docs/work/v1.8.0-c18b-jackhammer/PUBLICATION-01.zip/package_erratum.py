"""Package a new independently sealed erratum without changing its original seal."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
source = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-packaged-independent-20261009-01/manifest-notification-erratum-01")
target = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/PACKAGED-MANIFEST-ERRATUM-01.zip")
manifest = source / "SHA256SUMS.txt"
assert not target.exists()
rows = []
seen = set()
for line in manifest.read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    path = Path(name)
    assert not path.is_absolute() and ".." not in path.parts and name.casefold() not in seen
    seen.add(name.casefold())
    file = source / path
    assert file.is_file() and not file.is_symlink() and not file.is_junction()
    raw = file.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    rows.append((name, raw))
rows.append(("SHA256SUMS.txt", manifest.read_bytes()))
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in rows:
        archive.writestr(name, raw)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
record = dict(archive=str(target), bytes=target.stat().st_size,
              sha256=hashlib.sha256(target.read_bytes()).hexdigest(), files=len(rows),
              uncompressed_bytes=sum(len(raw) for _, raw in rows),
              report_sha256=hashlib.sha256((source / "ERRATUM.md").read_bytes()).hexdigest(),
              manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())
(root / "PACKAGED-ERRATUM-PACKAGE-01.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
