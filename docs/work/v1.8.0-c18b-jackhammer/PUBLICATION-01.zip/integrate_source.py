"""Record guarded normal merge and complete tested-source equivalence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
main = Path("D:/GitHub/AdvancedRocketry-Community")
tool = Path("D:/GitHub/arce-v180-jackhammer-20261009")
candidate = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
preimage = "e2df95bde1ae9f00b664a26eeaa1e7fa5e3ec7ef"
commands = []

def run(name, args, cwd=main):
    start = datetime.now(timezone.utc).isoformat()
    proc = subprocess.run(args, cwd=cwd, capture_output=True, timeout=120)
    raw = proc.stdout + proc.stderr
    path = root / (name + ".log")
    assert not path.exists()
    path.write_bytes(raw)
    commands.append(dict(name=name, argv=args, cwd=str(cwd), started_utc=start,
                         ended_utc=datetime.now(timezone.utc).isoformat(), exit=proc.returncode,
                         log_sha256=hashlib.sha256(raw).hexdigest()))
    (root / "INTEGRATION-COMMANDS.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
    assert proc.returncode == 0, (name, raw.decode("utf-8", "replace"))
    return proc.stdout.strip().decode("utf-8")

assert run("pre-main-head", ["git", "rev-parse", "HEAD"]) == preimage
assert run("pre-tool-head", ["git", "rev-parse", "HEAD"], tool) == candidate
assert run("pre-main-branch", ["git", "branch", "--show-current"]) == "codex/v1.8.0-classic-content"
assert run("pre-tool-status", ["git", "status", "--short"], tool) == ""
assert run("pre-index", ["git", "diff", "--cached", "--name-only"]) == ""
assert run("pre-tracked", ["git", "diff", "--name-only"]) == "AGENTS.md"
owner_hash = hashlib.sha256((main / "AGENTS.md").read_bytes()).hexdigest()
assert owner_hash == "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
names = run("source-change-names", ["git", "diff", "--name-only",
            "106d31653f8bce66761c919742629a75a047e2ca", candidate]).splitlines()
assert len(names) == 35 and "AGENTS.md" not in names
run("source-whitespace", ["git", "diff", "--check",
    "106d31653f8bce66761c919742629a75a047e2ca", candidate])
run("merge", ["git", "merge", "--no-ff", candidate,
    "-m", "feat(equipment): integrate qualified ordinary jackhammer slice"])
merged = run("merged-head", ["git", "rev-parse", "HEAD"])
assert run("merged-parents", ["git", "rev-list", "--parents", "-n", "1", merged]).split()[1:] == [preimage, candidate]
source_tree = run("tested-src-tree", ["git", "rev-parse", candidate + ":src"])
assert run("merged-src-tree", ["git", "rev-parse", merged + ":src"]) == source_tree
inputs = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat",
          "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties",
          "compat-test-mod/build.gradle", "compat-test-mod/settings.gradle", "compat-test-mod/gradle.properties",
          "docs/provenance/v1.8.0-c18b-jackhammer.json", "docs/work/v1.8.0-asset-plan.csv"]
bindings = []
for number, name in enumerate(inputs):
    expected = run(f"tested-input-{number}", ["git", "rev-parse", f"{candidate}:{name}"])
    actual = run(f"merged-input-{number}", ["git", "rev-parse", f"{merged}:{name}"])
    assert actual == expected, name
    bindings.append(dict(path=name, blob=actual))
assert hashlib.sha256((main / "AGENTS.md").read_bytes()).hexdigest() == owner_hash
assert run("post-tracked", ["git", "diff", "--name-only"]) == "AGENTS.md"
assert run("post-index", ["git", "diff", "--cached", "--name-only"]) == ""
run("push", ["git", "push"])
assert run("upstream-head", ["git", "rev-parse", "@{upstream}"]) == merged
record = dict(preimage=preimage, tested_source=candidate, merged_commit=merged,
              complete_src_tree=source_tree, equal_inputs=bindings,
              owner_agents_sha256=owner_hash, main_regression_rerun=False,
              independent_candidate_builds_matching=True,
              status="MERGED_AND_NORMALLY_PUSHED_SOURCE_EQUIVALENCE_NOT_RERUN")
(root / "INTEGRATION-RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
