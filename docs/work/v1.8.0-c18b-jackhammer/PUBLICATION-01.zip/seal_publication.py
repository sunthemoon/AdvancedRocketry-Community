"""Seal persisted compact publication bytes without text-newline ambiguity."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
assert not manifest.exists()
files = sorted(p for p in root.rglob("*") if p.is_file())
assert sum(p.stat().st_size for p in files) < 100 * 1024**2
seen = set()
lines = []
for path in files:
    name = path.relative_to(root).as_posix()
    assert not path.is_symlink() and not path.is_junction() and name.casefold() not in seen
    assert path.stat().st_size < 50 * 1024**2
    seen.add(name.casefold())
    lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {name}\n")
manifest.write_bytes("".join(lines).encode("utf-8"))
for line in manifest.read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
print(f"files={len(files)}, covered_bytes={sum(p.stat().st_size for p in files)}")
print("manifest_sha256=" + hashlib.sha256(manifest.read_bytes()).hexdigest())
