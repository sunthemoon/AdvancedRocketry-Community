# Root jackhammer evidence publication and development integration

This metadata-only leaf binds immutable source/native qualification archives to
the actual guarded Main merge. It launches no Gradle, Minecraft or client and
does not replace actual tests on source 3b18a6bc. Source/preparation/read failures
remain in their original archives.

Actual guarded normal merge/push:
`80bbf16d9e76708b7e39c50d21b3cff1a66432ef`, parents
`e2df95bde1ae9f00b664a26eeaa1e7fa5e3ec7ef` and
`3b18a6bc8b58424d647053d6c6f1833ba14d9dc7`.
INTEGRATION-COMMANDS/RESULT record actual argv, UTC, exits, logs and comparisons.
The full src Git tree is `368c91b05ecf98c1b817ec6e499708ff47c8399b` for both
tested source and merge. Ten Gradle/consumer inputs and two provenance/asset-plan
blobs match. User-owned AGENTS.md SHA remains c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09;
the pre/post index is empty and the sole tracked worktree change stays that file.
No other agent retains a mutable Main/source/HEAD interest at the merge.

The complete fixed-source independent report identifies no new source change
requirement. Its forced build/test/DataGen/native commands are independently
actual, not repeated here. Root and independent normal JARs match. Source-04
sealed payload, Root qualification, original/corrected reports and packaged
receipts are packaged only after every actual manifest-covered hash verifies.
No original sealed file is changed. Package receipts record actual archive lengths,
entry counts, report/manifest/archive hashes and CRC checks.

Root independently resolves the packaged notification-only manifest discrepancy:
actual persisted CRLF bytes differ from the pre-write LF string. A separate
reviewer erratum corroborates the cause and every unchanged covered file. Neither
the original manifest nor archive is rewritten; the supplementary archive stays
separate. The initial task trigger for this follow-up failed because all worker
slots were occupied; it subsequently ran after a source reviewer finished.
No cleanup, tool policy or evidence restriction is bypassed.

Actual cheap post-merge ledger, approved bootstrap and commit-diff whitespace
checks all exit 0, with separate UTC/raw receipts. ARCHIVE-VOLUME-01 verifies
CRC and inventories all ten then-present tool archives, totaling 60,659,349
expanded bytes before this small publication archive. Each remains below 50 MiB;
the slice total remains below 100 MiB. No JAR/world/export/build copy is included.

Open: strict repository TIMEOUT and inherited errors; full survival/above-tier/mod,
COMMON sync, actual clients/GPU/multiplayer, migration/crash/performance/soak,
human asset/provenance, all G0-G9 and the ledger's 186 PLANNED /154 REVIEW assets.
Tool development code is merged, not a completed item/legacy bitmap delivery.
Actual sleep remains a proposed, independently reviewed contract with M1/M2 and
B1/D1 inputs; separate read-only feasibility tasks and owner ancillary choice
continue. No sleep runtime, new product policy, hatch/writer or release is added.

Only new Root-owned publication files and bounded Main metadata are written.
There is no new disposable world/cache/process requiring cleanup here. Separate
peer-denied temporary outputs remain excluded and are never acquired or retried.
The leaf-relative manifest hashes persisted bytes and is not an acceptance Gate.
