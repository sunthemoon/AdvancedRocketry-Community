"""Read immutable manifest bytes and preserve the notification discrepancy."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-packaged-independent-20261009-01/SHA256SUMS.txt")
raw = manifest.read_bytes()
record = dict(actual_bytes=len(raw), actual_sha256=hashlib.sha256(raw).hexdigest(),
              crlf_count=raw.count(b"\r\n"), lf_count=raw.count(b"\n"),
              normalized_lf_bytes=len(raw.replace(b"\r\n", b"\n")),
              normalized_lf_sha256=hashlib.sha256(raw.replace(b"\r\n", b"\n")).hexdigest(),
              notification_sha256="9eb4c5db35bcf12b29d6f2067cbd9db4444a26bdd21ebeffa873b8b2fa95c7b4",
              changed_sealed_input=False)
assert record["actual_sha256"] == "ee3313881c9c3851806ffd53a462dd62a346845e3612b882280cb82b7c793248"
assert record["normalized_lf_sha256"] == record["notification_sha256"]
assert record["actual_bytes"] == 11314 and record["normalized_lf_bytes"] == 11211
for line in raw.decode("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    assert hashlib.sha256((manifest.parent / name).read_bytes()).hexdigest() == digest
target = root / "PACKAGED-SEAL-DISCREPANCY-01.json"
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(record, indent=2))
