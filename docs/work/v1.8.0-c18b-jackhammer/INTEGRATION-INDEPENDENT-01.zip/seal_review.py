"""Seal and verify only this reviewer's new compact evidence leaf."""
import datetime
import hashlib
import json
from pathlib import Path
import stat
import sys


ROOT = Path(
    "D:/GitHub/ARCE-Task-Evidence/v1.8.0/"
    "jackhammer-integration-record-independent-20261009-01"
).resolve()
RESULT = ROOT / "SEAL-RESULT.json"
MANIFEST = ROOT / "SHA256SUMS.txt"
assert Path(__file__).resolve().parent == ROOT
assert not RESULT.exists() and not MANIFEST.exists(), "Do not mutate an existing seal"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
REPARSE = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)


def check_plain(path):
    info = path.lstat()
    assert not path.is_symlink()
    assert not getattr(info, "st_file_attributes", 0) & REPARSE
    return info


for ancestor in (ROOT, *ROOT.parents):
    check_plain(ancestor)
files = []
for path in ROOT.rglob("*"):
    info = check_plain(path)
    assert path.resolve().is_relative_to(ROOT)
    assert "_tmp" not in path.parts and "__pycache__" not in path.parts
    assert path.is_file(), "No directory/scratch/expanded tree may enter this seal"
    assert info.st_size < 50 * 1024 * 1024
    files.append(path)
names = [path.relative_to(ROOT).as_posix() for path in files]
assert len(names) == len({name.casefold() for name in names})
payloads = {name: (ROOT / name).read_bytes() for name in names}
payload_bytes = sum(map(len, payloads.values()))
covered_names = sorted([*names, RESULT.name])
manifest_bytes = sum(64 + 2 + len(name.encode("utf-8")) + 1 for name in covered_names)
result = {
    "reviewed_commit": "6245fa15d5355b51845b1ebb02779ead8829d87b",
    "exclusive_write_scope": ROOT.as_posix(),
    "argv": [sys.executable, "-B", str(Path(__file__).resolve())],
    "cwd": str(Path.cwd()),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "started_utc": started,
    "preseal_checks_completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "report_sha256": hashlib.sha256(payloads["REPORT.md"]).hexdigest(),
    "covered_files": len(covered_names),
    "leaf_files_including_manifest": len(covered_names) + 1,
    "covered_bytes": 0,
    "manifest_bytes": manifest_bytes,
    "total_leaf_bytes": 0,
    "largest_file": max(payloads, key=lambda name: len(payloads[name])),
    "largest_file_bytes": max(map(len, payloads.values())),
    "scratch_expanded_bytes": 0,
    "cleanup_attempts": 0,
    "unsealed_remainder_files": 0,
    "unsealed_remainder_bytes": 0,
    "runtime_processes_started": 0,
    "input_mutations": 0,
    "mutable_interests": "released",
    "serialization": "UTF-8, explicit LF; manifest hashes persisted bytes",
    "verification": "Final all-entry persisted-byte verification required by this script before exit 0",
}
for _ in range(10):
    encoded = (json.dumps(result, indent=2, ensure_ascii=True) + "\n").encode("utf-8")
    covered_bytes = payload_bytes + len(encoded)
    if result["covered_bytes"] == covered_bytes:
        break
    result["covered_bytes"] = covered_bytes
    result["total_leaf_bytes"] = covered_bytes + manifest_bytes
else:
    raise AssertionError("Unstable seal counters")
assert result["total_leaf_bytes"] < 100 * 1024 * 1024
assert len(encoded) < 50 * 1024 * 1024
RESULT.write_bytes(encoded)
payloads[RESULT.name] = RESULT.read_bytes()
rows = [
    hashlib.sha256(payloads[name]).hexdigest() + "  " + name + "\n"
    for name in covered_names
]
MANIFEST.write_bytes("".join(rows).encode("utf-8"))
assert MANIFEST.stat().st_size == manifest_bytes
actual_names = sorted(path.relative_to(ROOT).as_posix() for path in ROOT.rglob("*"))
assert actual_names == sorted([*covered_names, MANIFEST.name])
for line in MANIFEST.read_bytes().decode("utf-8").splitlines():
    expected, name = line.split("  ", 1)
    path = ROOT / name
    check_plain(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
assert sum((ROOT / name).stat().st_size for name in covered_names) == result["covered_bytes"]
assert sum(path.stat().st_size for path in ROOT.iterdir()) == result["total_leaf_bytes"]
print(json.dumps({
    "exit": 0,
    "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "report_sha256": result["report_sha256"],
    "manifest_sha256": hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
    "covered_files": result["covered_files"],
    "covered_bytes": result["covered_bytes"],
    "manifest_bytes": manifest_bytes,
    "total_leaf_bytes": result["total_leaf_bytes"],
    "largest_file_bytes": result["largest_file_bytes"],
    "unsealed_remainder_files": 0,
}, indent=2))
