"""Secondary pure record checks, with no installed/runtime/product execution."""
import collections
import csv
import fnmatch
import io
import json
import pathlib
import re
import sys

import record_checks as checks


def main():
    result = {"started_utc": checks.now(), "fixed_commit": checks.FIXED}
    buffers = {}
    for name in ("ROOT-QUALIFICATION-01.zip", "SOURCE-INDEPENDENT-01.zip",
                 "SOURCE-INDEPENDENT-02.zip", "SOURCE-INDEPENDENT-04.zip",
                 "PACKAGED-INDEPENDENT-01.zip", "PUBLICATION-01.zip"):
        _, buffers[name] = checks.archive_audit(checks.blob(checks.PREFIX + name))
    root = buffers["ROOT-QUALIFICATION-01.zip"]
    independent = buffers["SOURCE-INDEPENDENT-04.zip"]
    packaged = buffers["PACKAGED-INDEPENDENT-01.zip"]
    publication = buffers["PUBLICATION-01.zip"]
    result["corrected_original_native_log"] = checks.log_observation(
        buffers["SOURCE-INDEPENDENT-02.zip"]["logs/native-full.log"])
    assert any("All 578 required tests passed" in r["text"] for r in result["corrected_original_native_log"]["completion"])
    provenance = json.loads(checks.blob("docs/provenance/v1.8.0-c18b-jackhammer.json"))
    canonical = {k: v for k, v in provenance.items() if k != "review"}
    digest = checks.sha((json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode())
    assert digest == provenance["review"]["content_digest"]
    assert provenance["review"]["status"] == "PENDING_HUMAN_REVIEW"
    result["provenance"] = {"digest": digest, "review": provenance["review"], "entries": []}
    for entry in provenance["entries"]:
        target = checks.blob(entry["target_path"], checks.SOURCE)
        assert checks.sha(target) == entry["target_sha256"]
        row = {"target": entry["target_path"], "bytes": len(target), "sha256": checks.sha(target)}
        if entry["status"] == "NEW":
            source = checks.blob(entry["source_path"], entry["authoring_commit"])
            assert checks.sha(source) == entry["source_sha256"]
        else:
            history = json.loads(root["recipe-history-01/HISTORY.json"])
            assert entry["source_commit"] == history["pinned_commit"]
            assert entry["source_sha256"] == checks.sha(root["recipe-history-01/source.stdout"])
            assert entry["upstream_history"] == history["history"]
            row["upstream_source_bytes"] = len(root["recipe-history-01/source.stdout"])
        if "/lang/" in entry["target_path"]:
            old = json.loads(checks.blob(entry["target_path"], checks.BASE))
            new = json.loads(target)
            assert all(new[k] == v for k, v in old.items())
            additions = sorted(set(new) - set(old))
            assert additions == sorted(entry["new_keys"]) and len(additions) == 4
            row["additive_keys"] = additions
        result["provenance"]["entries"].append(row)
    history_commands = json.loads(root["recipe-history-01/COMMANDS.json"])
    history_names = ["clone", "shallow", "history", "history-status", "source"]
    assert len(history_commands) == len(history_names)
    for name, command in zip(history_names, history_commands):
        assert command["exit"] == 0
        for kind in ("stdout", "stderr"):
            assert checks.sha(root["recipe-history-01/" + name + "." + kind]) == command[kind + "_sha256"]
    result["upstream_history_receipts"] = history_commands
    assert root["recipe-history-01/history.stdout"] == independent["results/upstream-history/stdout.log"]
    assert root["recipe-history-01/history-status.stdout"] == independent["results/upstream-name-status/stdout.log"]
    ledger_path = "docs/work/v1.8.0-content-ledger.csv"
    ledger = checks.blob(ledger_path)
    assert ledger == checks.blob(ledger_path, checks.BASE)
    counts = dict(collections.Counter(row["disposition"] for row in csv.DictReader(io.StringIO(ledger.decode()))))
    asset_rows = list(csv.DictReader(io.StringIO(checks.blob("legacy-manifest/assets.csv").decode())))
    def effective(commit):
        plan = list(csv.DictReader(io.StringIO(checks.blob("docs/work/v1.8.0-asset-plan.csv", commit).decode())))
        values = {}
        for asset in asset_rows:
            relative = asset["source_path"].split("assets/advancedrocketry/", 1)[1]
            matches = [row for row in plan if fnmatch.fnmatchcase(relative, row["pattern"])]
            assert matches, relative
            values[relative] = matches[0]["handling"]
        return values
    old = effective(checks.BASE)
    new = effective(checks.FIXED)
    changes = {k: [old[k], new[k]] for k in new if old[k] != new[k]}
    assert changes == {"recipes/jackhammer.json": ["REGENERATE", "IMPORTED"]}
    asset_counts = dict(collections.Counter(new.values()))
    actual_ledger = json.loads(root["static-04/ledger.log"])
    assert counts == actual_ledger["dispositions"] and asset_counts == actual_ledger["assets"]
    result["ledger"] = {"units": sum(counts.values()), "dispositions": counts,
                         "assets": len(new), "handling": asset_counts, "effective_changes": changes,
                         "ledger_unchanged_from_adoption": True}
    artifacts = {row["name"]: row for row in json.loads(root["ARTIFACTS-04.json"])["artifacts"]}
    result["artifact_record_matches"] = []
    for row in json.loads(independent["results/resources/ARTIFACTS.json"])["jars"]:
        other = artifacts[row["file"]]
        assert row["bytes"] == other["bytes"] and row["sha256"] == other["sha256"]
        assert row["entries"] == len(other["entries"])
        result["artifact_record_matches"].append({k: row[k] for k in ("file", "bytes", "sha256", "entries")})
    native_inputs = json.loads(root["packaged-02/inputs.json"])
    audit = json.loads(packaged["native02/AUDIT.json"])
    assert len(native_inputs["libraries"]) == audit["library_files_verified"] == 104
    assert sum(r["bytes"] for r in native_inputs["libraries"]) == audit["library_bytes_verified"]
    assert len(set(r["path"].casefold() for r in native_inputs["libraries"])) == 104
    result["runtime_library_inventory"] = {"files": 104, "bytes": audit["library_bytes_verified"],
                                            "currently_installed_bytes_rehashed": False}
    for row in audit["fixture_source_git_matches"]:
        assert checks.sha(checks.blob(row["relative"], checks.SOURCE)) == row["sha256"]
    result["fixture_source_git_hashes_verified"] = len(audit["fixture_source_git_matches"])
    classpath = json.loads(root["packaged-launch-02/classpath.json"])
    consumer = json.loads(packaged["native02/consumer-AUDIT.json"])
    assert len(classpath["compile_classpath"]) == len(consumer["classpath_rows"])
    for declared, audited in zip(classpath["compile_classpath"], consumer["classpath_rows"]):
        assert declared == {k: v for k, v in audited.items() if k != "actual_bytes"}
    assert sum(row["actual_bytes"] for row in consumer["classpath_rows"]) == consumer["compile_classpath_verified_bytes"]
    assert len(classpath["compile_classpath"]) == consumer["compile_classpath_verified_jars"] == 114
    host_classes = [r for r in classpath["compile_classpath"] if r.get("host_classes")]
    assert len(host_classes) == 1 and len(host_classes[0]["host_classes"]) == 29
    assert all("/api/" in n for n in host_classes[0]["host_classes"])
    negative = json.loads(root["packaged-launch-02/negative-import.json"])
    assert negative["exit_code"] == 1 and "compiler.err.doesnt.exist" in negative["diagnostics"]
    result["consumer_boundaries"] = {"classpath_jars": 114, "api_classes": 29,
                                     "negative_compile_exit": negative["exit_code"],
                                     "native_or_compiler_rerun": False}
    before = json.loads(root["CLEANUP-BEFORE.json"])
    after = json.loads(root["CLEANUP-RESULT.json"])
    assert after["attempt"] == 1 and after["result"] == "REMOVED"
    result["root_cleanup"] = {"files": sum(t["files"] for t in before["targets"]),
                               "bytes": sum(t["bytes"] for t in before["targets"]),
                               "attempts": after["attempt"], "raw_receipt": "CLEANUP-RESULT.json"}
    result["source_review_cleanup"] = json.loads(independent["results/OWNED-CLEANUP.json"])
    result["source_review_unsealed_remainder"] = json.loads(independent["results/UNSEALED-REMAINDER.json"])
    result["packaged_review_cleanup_seal"] = json.loads(packaged["SEAL-RESULT.json"])
    manifest_writer = packaged["seal_evidence.py"].decode().splitlines()
    result["manifest_writer_lines"] = {str(n): manifest_writer[n - 1] for n in (54, 60, 61)}
    result["push_receipt"] = next(r for r in json.loads(publication["INTEGRATION-COMMANDS.json"]) if r["name"] == "push")
    assert "--force" not in result["push_receipt"]["argv"] and result["push_receipt"]["exit"] == 0
    result["push_log"] = publication["push.log"].decode()
    result["attributes_equal"] = {c: checks.object_id(".gitattributes", c) for c in (checks.SOURCE, checks.MERGE, checks.FIXED)}
    assert len(set(result["attributes_equal"].values())) == 1
    current = checks.blob("docs/status/CURRENT_VERSION.md").decode()
    result["status_refs"] = {field: re.search(r"^" + field + r": (.+)$", current, re.M)[1] for field in
                             ("current_version", "status", "active_development_version", "latest_source_checkpoint",
                              "tested_code_commit", "native_tested_code_commit", "latest_regression_result",
                              "latest_regression_observed_utc", "actual_unit_rerun_observed_utc")}
    assert result["status_refs"]["tested_code_commit"] == checks.SOURCE
    assert result["status_refs"]["latest_source_checkpoint"] == checks.MERGE
    qualifications = json.loads(root["QUALIFICATION-04.json"])
    for name, field in (("native-04", "latest_regression_observed_utc"), ("build-04", "actual_unit_rerun_observed_utc")):
        receipt = next(r for r in qualifications if r["name"] == name)
        assert receipt["ended_utc"].replace("+00:00", "Z") == result["status_refs"][field]
    result["ended_utc"] = checks.now()
    result["git_commands_executed"] = checks.COMMANDS
    (checks.LEAF / "ADDITIONAL-CHECKS.json").write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
    print(json.dumps({k: result[k] for k in ("ledger", "artifact_record_matches", "runtime_library_inventory",
                                           "fixture_source_git_hashes_verified", "consumer_boundaries", "root_cleanup", "status_refs")}, indent=2))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
