"""Read fixed Git records; independently parse bounded evidence, never run inputs."""
import collections
import copy
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import stat
import struct
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
import zipfile

FIXED = "6245fa15d5355b51845b1ebb02779ead8829d87b"
SOURCE = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
MERGE = "80bbf16d9e76708b7e39c50d21b3cff1a66432ef"
PREIMAGE = "e2df95bde1ae9f00b664a26eeaa1e7fa5e3ec7ef"
BASE = "106d31653f8bce66761c919742629a75a047e2ca"
REPO = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
LEAF = pathlib.Path(__file__).resolve().parent
PREFIX = "docs/work/v1.8.0-c18b-jackhammer/"
COMMANDS = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    start = now()
    p = subprocess.run(["git", *args], cwd=REPO, capture_output=True, check=False)
    COMMANDS.append({"argv": ["git", *args], "cwd": str(REPO),
                     "started_utc": start, "ended_utc": now(), "exit": p.returncode,
                     "stdout_bytes": len(p.stdout), "stdout_sha256": sha(p.stdout),
                     "stderr_bytes": len(p.stderr), "stderr_sha256": sha(p.stderr)})
    if p.returncode:
        raise RuntimeError((args, p.returncode, p.stderr.decode(errors="replace")))
    return p.stdout


def blob(path, commit=FIXED):
    return git("show", commit + ":" + path)


def object_id(path, commit):
    return git("rev-parse", commit + ":" + path).decode().strip()


def relative(name):
    p = pathlib.PurePosixPath(name)
    return (bool(name) and not p.is_absolute() and "\\" not in name
            and ":" not in name and all(x not in ("", ".", "..") for x in name.split("/")))


def archive_audit(raw):
    z = zipfile.ZipFile(io.BytesIO(raw))
    infos = z.infolist()
    assert sum(i.file_size for i in infos) <= 100 * 1024 * 1024
    assert all(i.file_size < 50 * 1024 * 1024 for i in infos)
    names = [i.filename for i in infos]
    assert len(names) == len(set(n.casefold() for n in names))
    assert all(relative(n) for n in names)
    assert not any(stat.S_ISLNK(i.external_attr >> 16) for i in infos)
    assert not any(i.is_dir() for i in infos)
    data = {n: z.read(n) for n in names}  # Every read verifies CRC.
    manifests = {}
    for name in names:
        if name.rsplit("/", 1)[-1].startswith("SHA256SUMS") and name.endswith(".txt"):
            root = name.rpartition("/")[0]
            rows = []
            for line in data[name].decode("utf-8").splitlines():
                if not line.strip():
                    continue
                m = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
                assert m and relative(m[2]), (name, line)
                target = root + "/" + m[2] if root else m[2]
                assert target in data and sha(data[target]) == m[1], (name, target)
                rows.append(target)
            assert len(rows) == len(set(rows))
            manifests[name] = {"rows": len(rows), "bytes": len(data[name]),
                               "sha256": sha(data[name]),
                               "covered_bytes": sum(len(data[n]) for n in rows)}
    covering = "SHA256SUMS-CORRECTION-01.txt" if "SHA256SUMS-CORRECTION-01.txt" in data else "SHA256SUMS.txt"
    assert manifests[covering]["rows"] == len(names) - 1
    result = {"bytes": len(raw), "sha256": sha(raw), "entries": len(names),
              "uncompressed_bytes": sum(i.file_size for i in infos),
              "largest_entry_bytes": max(i.file_size for i in infos),
              "report_sha256": sha(data.get("REPORT.md", data.get("ERRATUM.md", b""))),
              "manifest_sha256": sha(data[covering]), "manifests": manifests,
              "crc_path_case_symlink_bounds_verified": True}
    return result, data


def xml_totals(data):
    groups = collections.defaultdict(lambda: {"xml": 0, "tests": 0, "failures": 0,
                                              "errors": 0, "skipped": 0, "testcase_nodes": 0,
                                              "failure_names": []})
    for name, raw in data.items():
        if not name.endswith(".xml"):
            continue
        root = ET.fromstring(raw)
        group = groups[name.rpartition("/")[0]]
        group["xml"] += 1
        for key in ("tests", "failures", "errors", "skipped"):
            group[key] += int(root.attrib.get(key, 0))
        cases = root.findall("testcase")
        group["testcase_nodes"] += len(cases)
        for case in cases:
            if case.find("failure") is not None or case.find("error") is not None:
                group["failure_names"].append(case.attrib)
    for group in groups.values():
        assert group["tests"] == group["testcase_nodes"]
    return dict(groups)


def log_observation(raw):
    lines = raw.decode("utf-8", errors="replace").splitlines()
    return {"bytes": len(raw), "sha256": sha(raw), "lines": len(lines),
            "headers": {level: sum(bool(re.match(r"^\[[^\]]+\] \[[^\]]+/" + level + r"\]", line))
                                  for line in lines) for level in ("WARN", "ERROR", "FATAL")},
            "completion": [{"line": n, "text": line} for n, line in enumerate(lines, 1)
                           if re.search(r"All \d+ required tests passed|\d+ required tests failed|tests completed|Running test batch.*jackhammer", line)],
            "native_order": [{"line": n, "text": line} for n, line in enumerate(lines, 1)
                             if any(s in line for s in ("ARCE_JACKHAMMER_CONTINUATION", "logged in with", "Saved the game", "Stopping server", "All dimensions are saved"))],
            "raw_terminal_warnings": [line for line in lines if "terminal" in line.lower() and "WARN" in line]}


class NbtReader:
    """Independent bounded typed NBT decoder; no project parser import."""
    def __init__(self, raw):
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
            self.data = stream.read(262145)
        assert len(self.data) <= 262144
        self.pos = 0
        self.nodes = 0

    def read(self, size):
        assert 0 <= size <= 262144 and self.pos + size <= len(self.data)
        b = self.data[self.pos:self.pos + size]
        self.pos += size
        return b

    def number(self, fmt):
        return struct.unpack(">" + fmt, self.read(struct.calcsize(">" + fmt)))[0]

    def string(self):
        size = self.number("H")
        assert size <= 32768
        return self.read(size).decode("utf-8")

    def payload(self, kind, depth=0):
        self.nodes += 1
        assert self.nodes <= 65536 and depth <= 32
        if kind in (1, 2, 3, 4, 5, 6):
            value = self.number({1: "b", 2: "h", 3: "i", 4: "q", 5: "f", 6: "d"}[kind])
        elif kind in (7, 11, 12):
            length = self.number("i")
            assert 0 <= length <= 65536
            value = [self.number({7: "b", 11: "i", 12: "q"}[kind]) for _ in range(length)]
        elif kind == 8:
            value = self.string()
        elif kind == 9:
            child = self.number("B")
            length = self.number("i")
            assert 0 <= length <= 65536 and (length == 0 or 1 <= child <= 12)
            value = [self.payload(child, depth + 1) for _ in range(length)]
        elif kind == 10:
            value = {}
            while True:
                child = self.number("B")
                if child == 0:
                    break
                assert 1 <= child <= 12 and len(value) < 65536
                name = self.string()
                assert name not in value
                value[name] = self.payload(child, depth + 1)
        else:
            raise AssertionError(kind)
        return {"type": kind, "value": value}

    def root(self):
        assert self.number("B") == 10
        name = self.string()
        node = self.payload(10)
        assert self.pos == len(self.data)
        return name, node["value"]


def native_nbt(raw):
    reader = NbtReader(raw)
    name, root = reader.root()
    def field(node, key, kind):
        assert node[key]["type"] == kind, (key, node[key])
        return node[key]["value"]
    ints = field(root, "UUID", 11)
    assert len(ints) == 4
    uid = str(uuid.UUID(bytes=b"".join(struct.pack(">I", v & 0xffffffff) for v in ints)))
    inventory = field(root, "Inventory", 9)
    assert len(inventory) == 1 and inventory[0]["type"] == 10
    item = inventory[0]["value"]
    tag = field(item, "tag", 10)
    display = field(tag, "display", 10)
    enchants = field(tag, "Enchantments", 9)
    assert len(enchants) == 1 and enchants[0]["type"] == 10
    sample = {"uuid": uid, "native_data_version": field(root, "DataVersion", 3),
              "game_mode": field(root, "playerGameType", 3),
              "selected_slot": field(root, "SelectedItemSlot", 3),
              "slot": field(item, "Slot", 1), "count": field(item, "Count", 1),
              "item": field(item, "id", 8), "damage": field(tag, "Damage", 3),
              "name": json.loads(field(display, "Name", 8)),
              "enchantments": enchants}
    sample["tag_keys"] = list(tag)
    sample["other_tags"] = {k: v for k, v in tag.items() if k not in ("Damage", "display", "Enchantments")}
    return {"bytes": len(raw), "sha256": sha(raw), "expanded_bytes": len(reader.data),
            "nodes": reader.nodes, "root_name": name, "sample": sample}, inventory


def check_receipt(data, prefix, result_name="RESULT.json"):
    result = json.loads(data[prefix + "/" + result_name])
    for key, filename in (("log_sha256", "command.log"), ("stdout_sha256", "stdout.log"), ("stderr_sha256", "stderr.log")):
        if key in result:
            assert sha(data[prefix + "/" + filename]) == result[key]
    return {key: result[key] for key in ("argv", "head", "source_sha", "started_utc", "ended_utc", "exit", "timeout_seconds", "free_bytes") if key in result}


def main():
    result = {"started_utc": now(), "fixed_commit": FIXED, "source_commit": SOURCE, "merge_commit": MERGE}
    paths = git("ls-tree", "-r", "--name-only", FIXED, "--", PREFIX).decode().splitlines()
    archives = {}
    buffers = {}
    for path in paths:
        if path.endswith(".zip"):
            audit, data = archive_audit(blob(path))
            archives[path.rsplit("/", 1)[-1]] = audit
            buffers[path.rsplit("/", 1)[-1]] = data
    result["archives"] = archives
    result["archive_totals"] = {"archives": len(archives),
                                "compressed_bytes": sum(v["bytes"] for v in archives.values()),
                                "expanded_bytes": sum(v["uncompressed_bytes"] for v in archives.values()),
                                "entries": sum(v["entries"] for v in archives.values())}
    assert result["archive_totals"]["expanded_bytes"] <= 100 * 1024 * 1024
    result["xml_cohorts"] = {name: xml_totals(data) for name, data in buffers.items() if any(n.endswith(".xml") for n in data)}
    result["parents"] = git("rev-list", "--parents", "-n", "1", MERGE).decode().strip().split()
    assert result["parents"] == [MERGE, PREIMAGE, SOURCE]
    result["src_trees"] = {c: object_id("src", c) for c in (SOURCE, MERGE, FIXED)}
    assert len(set(result["src_trees"].values())) == 1
    pub = buffers["PUBLICATION-01.zip"]
    record = json.loads(pub["INTEGRATION-RESULT.json"])
    result["equal_inputs"] = []
    for row in record["equal_inputs"]:
        observed = {c: object_id(row["path"], c) for c in (SOURCE, MERGE, FIXED)}
        assert set(observed.values()) == {row["blob"]}
        result["equal_inputs"].append({"path": row["path"], "blobs": observed})
    changed = git("diff", "--name-only", BASE, SOURCE).decode().splitlines()
    result["adoption_diff_files"] = len(changed)
    result["adoption_diff_sha256"] = sha(git("diff", "--binary", BASE, SOURCE))
    assert len(changed) == 35
    result["metadata_changes"] = git("diff-tree", "--no-commit-id", "--name-status", "-r", FIXED).decode().splitlines()
    result["whitespace"] = git("diff", "--check", FIXED + "^", FIXED).decode()
    result["commits"] = {c: git("show", "--no-patch", "--format=%H%n%P%n%aI%n%cI%n%s", c).decode().splitlines()
                         for c in (FIXED, SOURCE, MERGE, "6d75429ab5f4941092216474c7d3d966417d3701")}
    independent = buffers["SOURCE-INDEPENDENT-04.zip"]
    source_hashes = json.loads(independent["inputs/source-hashes.json"])
    result["independent_source_hashes_verified"] = 0
    for row in source_hashes["files"]:
        raw = blob(row["path"], SOURCE)
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], row["path"]
        result["independent_source_hashes_verified"] += 1
    result["publication_receipt"] = json.loads(blob(PREFIX + "PUBLICATION-RECEIPT-01.json"))
    for key in ("bytes", "sha256", "uncompressed_bytes", "report_sha256", "manifest_sha256"):
        assert result["publication_receipt"][key] == archives["PUBLICATION-01.zip"][key], key
    assert result["publication_receipt"]["files"] == archives["PUBLICATION-01.zip"]["entries"]
    result["publication_commands"] = json.loads(pub["INTEGRATION-COMMANDS.json"])
    for command in result["publication_commands"]:
        assert command["exit"] == 0
        assert sha(pub[command["name"] + ".log"]) == command["log_sha256"]
        assert command["ended_utc"] >= command["started_utc"]
    result["postmerge_receipts"] = json.loads(pub["POSTMERGE-CHECKS.json"])
    for command in result["postmerge_receipts"]:
        assert sha(pub[command["name"] + ".log"]) == command["raw_sha256"]
    root = buffers["ROOT-QUALIFICATION-01.zip"]
    result["root_receipts"] = {prefix: check_receipt(root, prefix) for prefix in
                               ("build-01", "build-02", "build-03", "build-04", "test-03", "test-04",
                                "data-04a", "data-04b", "native-01", "native-03", "native-04", "publish-04", "consumer-04", "packaged-launch-02")}
    result["independent_latest_receipts"] = {prefix: check_receipt(independent, "results/" + prefix) for prefix in
                                             ("clean-build", "explicit-test", "data-1", "data-2", "data-1-diff", "data-2-diff", "native", "strict-repository")}
    result["root_static_receipts"] = json.loads(root["static-04/COMMANDS.json"])
    for command in result["root_static_receipts"]:
        assert sha(root["static-04/" + command["name"] + ".log"]) == command["log_sha256"]
    native_logs = {"ROOT-QUALIFICATION-01.zip": ("native-01/command.log", "native-03/command.log", "native-04/command.log", "native-04/latest.log", "native-04/debug.log"),
                   "SOURCE-INDEPENDENT-01.zip": ("gametest-01.log",),
                   "SOURCE-INDEPENDENT-02.zip": ("logs/gametest.log",),
                   "SOURCE-INDEPENDENT-03.zip": ("gametest.log", "native-latest.log"),
                   "SOURCE-INDEPENDENT-04.zip": ("results/native/stdout.log", "results/native/latest.log", "results/native/debug.log")}
    result["native_logs"] = {}
    for archive, names in native_logs.items():
        for name in names:
            if name in buffers[archive]:
                result["native_logs"][archive + "!" + name] = log_observation(buffers[archive][name])
    result["native_playerdata"] = {}
    inventories = {}
    for stage in ("seed", "continue"):
        prefix = "packaged-02/" + stage + "/"
        raw = root[prefix + "playerdata.dat"]
        observation, inventory = native_nbt(raw)
        result["native_playerdata"][stage] = observation
        inventories[stage] = inventory
        receipt = json.loads(root[prefix + "receipt.json"])
        assert receipt["exit"] == 0 and receipt["playerdata_sha256"] == sha(raw)
        result["native_playerdata"][stage]["receipt"] = receipt
        for name in ("stdout.txt", "latest.log", "debug.log"):
            result["native_logs"]["ROOT-QUALIFICATION-01.zip!" + prefix + name] = log_observation(root[prefix + name])
        for archive, other in (("PACKAGED-INDEPENDENT-01.zip", "native02/" + prefix),
                               ("SOURCE-INDEPENDENT-04.zip", "inputs/root-packaged-02/" + stage + "/")):
            for name in ("stdout.txt", "latest.log", "debug.log", "playerdata.dat", "receipt.json"):
                assert buffers[archive][other + name] == root[prefix + name], (archive, other + name)
    assert inventories["seed"][0]["value"]["tag"]["value"]["Damage"]["value"] == 18
    assert inventories["continue"][0]["value"]["tag"]["value"]["Damage"]["value"] == 19
    normalized = copy.deepcopy(inventories["continue"])
    normalized[0]["value"]["tag"]["value"]["Damage"]["value"] = 18
    assert inventories["seed"] == normalized
    result["native_inventory_only_damage_diff"] = True
    seed = result["native_playerdata"]["seed"]["receipt"]
    cont = result["native_playerdata"]["continue"]["receipt"]
    assert seed["pid"] != cont["pid"] and seed["ended_utc"] < cont["started_utc"]
    assert seed["cwd"] == cont["cwd"] and seed["argv"] == cont["argv"]
    driver = buffers["PACKAGED-DRIVER-02.zip"]["packaged_driver.py"]
    assert driver == root["driver-frozen-02/packaged_driver.py"]
    assert blob(PREFIX + "PACKAGED-DRIVER-02.zip", "6d75429ab5f4941092216474c7d3d966417d3701") == blob(PREFIX + "PACKAGED-DRIVER-02.zip")
    result["driver02_sha256"] = sha(driver)
    manifest = buffers["PACKAGED-INDEPENDENT-01.zip"]["SHA256SUMS.txt"]
    normalized = manifest.replace(b"\r\n", b"\n")
    result["packaged_manifest_bytes"] = {"actual_bytes": len(manifest), "actual_sha256": sha(manifest),
                                         "crlf": manifest.count(b"\r\n"), "lf_bytes": len(normalized),
                                         "lf_sha256": sha(normalized)}
    result["ended_utc"] = now()
    result["git_commands_executed"] = COMMANDS
    (LEAF / "CHECKS.json").write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
    print(json.dumps({"archives": result["archive_totals"], "xml": result["xml_cohorts"],
                      "source_hashes": result["independent_source_hashes_verified"],
                      "playerdata": {k: v["sample"] for k, v in result["native_playerdata"].items()},
                      "manifest": result["packaged_manifest_bytes"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
