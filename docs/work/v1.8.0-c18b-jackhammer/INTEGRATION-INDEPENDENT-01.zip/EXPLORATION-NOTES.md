# Reviewer exploration and checker failures

Exploration used only read-only Git, PowerShell and Python. It did not execute
any helper from an input archive. Exact UTC was not separately captured for
the preliminary interactive reads; no timestamps are invented for them.

1. The initial fixed-version read requested the guessed path
   `6245fa15d5355b51845b1ebb02779ead8829d87b:docs/versions/v1.8.0.md`.
   `git show` returned 128 and its Python wrapper returned 1. The fixed tree
   supplies `docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`; that actual file
   was subsequently read. The failed guessed read does not count as governance
   reading. Tool chunk: `bcfd16`.
2. A preliminary JSON presentation script assumed QUALIFICATION-04.json was a
   dictionary and attempted `.items()`. The actual object is a list. Its Python
   wrapper returned 1 with `AttributeError: 'list' object has no attribute
   'items'`. This was an exploration/presentation failure, not a failed target
   receipt. Subsequent inspection handled the actual schema. Tool chunk: `35c609`.
3. Some exploratory tool output was truncated, and initial Chinese output used
   the wrong stdout codec. The actual mandatory records and relevant report
   sections were reread in bounded UTF-8 output; truncated output was not used
   as evidence that an unseen statement or receipt was read successfully.
4. The first main checker failed on an overly broad equality assertion between
   a Git LF blob and a captured Windows checkout file. Its original helper is
   `record_checks-01.py`, SHA-256
   `315c9a7849ed3a0d535044edfdae172c9a4ce5e740c64fa6be4414cfcc25e05c`.
   CHECK-RUN-01.json and both actual raw logs remain unchanged. Fixed
   `.gitattributes` requires `gradlew.bat text eol=crlf`; the exact 92 additional
   CR bytes reproduce the recorded checkout hash. The corrected checker records
   both identities and does not normalize or change an input file.
5. The first secondary checker expected two JSON rows to have identical key
   sets. The independent consumer auditor adds `actual_bytes` to each Root
   declaration, so that expectation was incorrect. The original helper is
   `additional_checks-01.py`, SHA-256
   `3cb8c59b15205fde10287ea272943a9c040a7f70c9610e8b4ff04ae0a512ba51`.
   ADDITIONAL-RUN-01.json and both raw logs remain unchanged. The corrected
   checker compares every declared field exactly and independently sums the
   extra audited byte counts; it does not change either receipt.
6. A no-op report patch requested a substring not present in the actual report.
   `apply_patch` reported verification failure and changed no file. The report
   was reread before the subsequent actual edits. This is reviewer editing
   feedback, not target evidence or a changed input seal.

Neither helper failure establishes a target or gameplay finding. Both passing
successor runs have their own argv, UTC, exit and raw-output hashes. No failure
was removed, and no target assertion, timeout or budget was changed.
