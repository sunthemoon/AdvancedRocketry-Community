"""Assert actual native marker/command ordering, without running fixture code."""
import json
import re
import sys

import record_checks as checks


def main():
    result = {"started_utc": checks.now(), "fixed_commit": checks.FIXED, "phases": {}}
    _, root = checks.archive_audit(checks.blob(checks.PREFIX + "ROOT-QUALIFICATION-01.zip"))
    marker = re.compile(r"ARCE_JACKHAMMER_CONTINUATION stage=(seed|continue) "
                        r"uuid=([0-9a-f-]+) before_damage=(\d+) after_damage=(\d+)")
    for stage, before, after in (("seed", 17, 18), ("continue", 18, 19)):
        prefix = "packaged-02/" + stage + "/"
        lines = root[prefix + "stdout.txt"].decode().splitlines()
        all_marker_lines = [(i, line) for i, line in enumerate(lines, 1)
                            if "ARCE_JACKHAMMER_CONTINUATION" in line]
        assert len(all_marker_lines) == 1
        line_number, text = all_marker_lines[0]
        match = marker.fullmatch(text)
        assert match and match.groups() == (stage, "914adf94-5147-49a3-bf78-ff21cd948719", str(before), str(after))
        joins = [i for i, line in enumerate(lines, 1) if "jackContinue[embedded] logged in with" in line]
        saves = [i for i, line in enumerate(lines, 1) if "Saved the game" in line]
        stops = [i for i, line in enumerate(lines, 1) if "Stopping server" in line]
        completed = [i for i, line in enumerate(lines, 1) if "All dimensions are saved" in line]
        assert len(joins) == len(saves) == len(stops) == 1
        assert joins[0] < line_number < saves[0] < stops[0] < max(completed)
        commands = json.loads(root[prefix + "commands.json"])
        assert commands == ["arce_jackhammer_test " + stage, "save-all flush", "stop"]
        receipt = json.loads(root[prefix + "receipt.json"])
        assert receipt["observation"] == {"stage": stage, "uuid": match[2], "before_damage": before, "after_damage": after}
        assert receipt["clean_stop"] == {"saved_after_stop_line": max(completed), "stopping_line": stops[0]}
        result["phases"][stage] = {"join_line": joins[0], "marker_line": line_number,
                                  "explicit_save_line": saves[0], "stop_line": stops[0],
                                  "final_dimensions_save_line": max(completed), "commands": commands,
                                  "raw_marker": text, "exit": receipt["exit"]}
    source = checks.blob("src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java", checks.SOURCE)
    result["fixture_source_sha256"] = checks.sha(source)
    result["ended_utc"] = checks.now()
    result["git_commands_executed"] = checks.COMMANDS
    (checks.LEAF / "FINAL-RECORD-CHECKS.json").write_bytes((json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
