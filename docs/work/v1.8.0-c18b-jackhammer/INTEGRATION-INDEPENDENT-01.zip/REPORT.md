# Independent fixed jackhammer integration-record review

## Findings first

No new change-required integration-record finding was identified at fixed Main
commit `6245fa15d5355b51845b1ebb02779ead8829d87b`. This conclusion covers the
committed source/evidence integration records and their byte-bound support,
not another gameplay implementation review or item/Gate acceptance.

The records correctly preserve unresolved qualification limits rather than
turning passing test counts into complete delivery:

- [SOURCE-INTEGRATION-01.md:22-25,29-35](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/SOURCE-INTEGRATION-01.md#L22)
  binds actual qualification to source `3b18a6bc`, explicitly not a merge-SHA
  Gradle/native rerun. The strict 180-second TIMEOUT and 62 unwaived native ERROR
  headers remain recorded.
- [SOURCE-INTEGRATION-01.md:37-45,63-70](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/SOURCE-INTEGRATION-01.md#L37)
  and [PACKAGED-REVIEW-STATUS-01.md:10-22](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/PACKAGED-REVIEW-STATUS-01.md#L10)
  distinguish actual Root native inventory continuation from receipt-only
  independent corroboration, real clients, online-stop-first-save, crash,
  persisted mining terrain/loot and performance proof.
- [CURRENT_VERSION.md:40-73,102-123](D:/GitHub/AdvancedRocketry-Community/docs/status/CURRENT_VERSION.md#L40)
  and [COMPLETION-PLAN.md:275-288](D:/GitHub/AdvancedRocketry-Community/docs/status/COMPLETION-PLAN.md#L275)
  retain unfinished full-tool, progression, client, provenance and policy work.
  There is no new delivered ledger row or release/Gate approval.

All local file/line references above mean the contents of the fixed reviewed
commit, not a later working-tree version. Original failed findings and their
cohorts are historical inputs, not new findings manufactured by this review.

## Fixed inputs, authority and ownership

Assigned task: `JACKHAMMER-INTEGRATION-RECORD-REVIEW-TASK-01.md` in the external
v1.8 evidence root. Its actual hash is in FINAL-OBSERVATIONS.json. The exclusive
new write scope is this evidence leaf only. All repository reads use fixed Git
objects; no production, test, registry, build, status, ledger, owner AGENTS.md,
peer or original seal/archive was written, staged, committed or removed.

Read fixed project identity/product/porting/roadmap/current-version/test/Gate,
parallel/v1+ quality and upstream/provenance governance, ADR-060, the adoption,
the complete five requested integration/status records, original/corrected
qualification reports and additive corrections, publication receipts, actual
native logs/playerdata, and the changed current/historical status/log sections.
ADR-060 preserves the earliest acceptance cursor at v1.0 while allowing bounded
v1.8 development; it does not approve this tool or any Required Gate.

No compiler, Gradle, Minecraft, client/server, world, installation, external
network request, source export or delegated agent was launched. Input scripts
were inspected as text and never executed. Root coordinated OpenPet. All mutable
Main/source/HEAD/runtime/artifact interests were released immediately; the Root
could move HEAD independently. Initial HEAD was the fixed reviewed commit; final
observed HEAD was `2ad2ea944d87176f6b4171c2c13c69502c106db5`. That later commit
is not an input or retroactively reviewed here. Final index was empty and the
existing owner AGENTS.md modification/inherited untracked files remained outside
the assigned write scope. No current owner AGENTS.md file bytes were acquired.

## Independent source/merge binding

Own read-only Git checks establish the merge parents exactly:

```text
80bbf16d9e76708b7e39c50d21b3cff1a66432ef
  e2df95bde1ae9f00b664a26eeaa1e7fa5e3ec7ef
  3b18a6bc8b58424d647053d6c6f1833ba14d9dc7
```

Source, merge and reviewed metadata commit have identical complete `src` tree
`368c91b05ecf98c1b817ec6e499708ff47c8399b`. All twelve listed blob identities
match: seven main Gradle/wrapper inputs, three compat-consumer inputs, tool
provenance and asset plan. `.gitattributes` also matches across those commits.
The complete adoption-to-source diff contains 35 files; own raw binary diff hash
is `88da1b66721365fe2f4a7550aa5b9459617ae10e9b9db43388106d3e9e6d6aab`, matching
the independent source report. The reviewed metadata commit changes only its
nine recorded status/publication files; its commit-diff whitespace check exits 0.
CHECKS.json preserves exact Git argv, UTC, exits and output hashes.

Git blob equality and captured checkout byte identity are different assertions.
The source review's 43-file actual checkout hash inventory independently
reconciles with fixed Git content. Forty-two match directly. `gradlew.bat` has:

| Representation | Bytes | SHA-256 |
|---|---:|---|
| Git blob, 92 LF rows | 2,776 | `18774a0ac0203f6893bf1db3291a0d77f06cd1b4dca2a43b51e7009da3e28cfa` |
| Attribute-required Windows CRLF checkout | 2,868 | `8e327fcb99d29ce0fe3ee2fec6e6a25de815a2df83a6a44a553dea89ffc92955` |

Fixed `.gitattributes:29` specifies `gradlew.bat text eol=crlf`. Adding exactly
92 CR bytes reproduces the recorded executable checkout identity. The integration
claims equal Git blobs, not runtime use of the LF blob. Neither representation
was written into an input or immutable evidence file by this reviewer.

[PUBLICATION-01.zip](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/PUBLICATION-01.zip)
`INTEGRATION-COMMANDS.json`, `merge.log`, `push.log` and `INTEGRATION-RESULT.json`
bind the actual merge/push, UTC, exits and comparisons. The push argv has no
force flag, exits 0 and its raw log reports `e2df95bd..80bbf16d` to the existing
development branch. Three post-merge ledger/bootstrap/whitespace receipts exit
0, with their raw hashes verified. This is an audit of historical receipts, not
a new remote-branch attestation or merge-SHA behavior rerun. The user-owned
AGENTS hash/released-worker statements are historical ownership context; this
review does not independently reconstruct every prior communication.

## Actual cohorts independently reparsed

Every archived JUnit XML was parsed by the reviewer-written checker, counting
both suite attributes and actual testcase nodes. Fourteen complete XML cohorts
are retained; totals agree without substituting a later successful cohort:

| Fixed cohort | Root XML /tests /failures | Independent build and explicit-test XML /tests /failures | Native evidence |
|---|---|---|---|
| `61cada9e` | 380 /2,189 /1 | Each 380 /2,189 /1 | Root and independent finish with four required failures |
| `bab14562` | 381 /2,192 /1 | Each 381 /2,192 /1 | Independent all 578 required pass; Root did not run native on this SHA |
| `53523bcf` | Build and test each 381 /2,192 /0 | Each 381 /2,192 /0 | Root and independent abort; no final completion; 114 WARN /8 ERROR /2 FATAL |
| `3b18a6bc` | Build and test each 381 /2,192 /0 | Each 381 /2,192 /0 | Root and independent all 579 required pass; 161 WARN /62 ERROR /0 FATAL |

All listed XML cohorts have zero errors/skips; the first two retain their actual
single failure, not a rewritten pass. The native latest/debug/stdout logs are
full and separately hashed. Latest Root final completion is `native-04/command.log:6034`
and `native-04/latest.log:5889`; latest independent completion is
`results/native/stdout.log:5939`. Native counts agree with the records and are
not a clean-log Gate waiver. Original missing-template results and immutable
seal-accounting correction remain separate.

Root and latest independent command/result receipts contain fixed source HEAD,
forced `--no-daemon --no-build-cache --rerun-tasks`, actual argv/cwd, UTC,
environment, disk counters and hashes. Root build wrapper ends at
`2026-10-09T02:48:27.328362Z`; native wrapper ends at
`2026-10-09T02:57:20.031453Z`. These exactly match the status observation fields;
they are wrapper observation times, distinct from enclosed Gradle receipt ends.
Latest independent build/test run 02:58:00.047864–03:01:30.289289 and
03:01:30.775321–03:04:30.179352 UTC, both exit 0. Twice DataGen and separately
captured empty diff/status receipts remain actual per-executor commands.

Root strict receipt times out after 180 seconds at 02:53:14.110021 UTC, and the
latest independent strict receipt after the same budget at 03:02:37.400707 UTC.
Both logs are empty; neither establishes link PASS or FAIL. Original independent
strict link failures remain distinct. This reviewer did not rerun a strict
validator or any Gradle/native command.

Current 2,192/579 numbers are not rebound to the previous detector cohort:
[implementation-log.md:207-239](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-implementation-log.md#L207)
retains its 2,183/379/565 counts, strict link failure, correction, denied cleanup
and interrupted reviewer. The earlier tool-publication checkpoint is historical
under its dated section, while the new top entry states the subsequent integration.

## Native inventory and artifact receipt scope

Own bounded gzip/typed-NBT reader, without target-parser imports, parses the actual
840-byte seed and 884-byte continuation files. Root bytes are identical to both
independent reviewers' compact retained playerdata/log/receipt copies. Hashes:

```text
seed:     5e71a8c8be626c391062ab4116d0dbc8f1078d7f7197168ca898cebe015dbe6e
continue: dcb8f084bec60e7a37920d200a02ea72f2df5d9788efba292279bc7b2ae1e004
```

Both decode UUID `914adf94-5147-49a3-bf78-ff21cd948719`, DataVersion 3465,
survival mode, selected slot/stack slot zero, count one, the jackhammer ID,
custom name `Jackhammer restart`, Efficiency II and note `native continuation`.
The typed inventory differs only by Damage 18 to 19. This does not assert that
the entire player NBT is identical or that arbitrary metadata is preserved.

PIDs 27148 and 20452 are distinct and sequential, with identical argv/cwd. The
second starts after the first exits. Full logs actually contain one fixture
observation per stage, explicit save, stop and completed all-dimension saves.
Each process exits 0; all six stdout/latest/debug files independently recount
113/11 bracketed WARN and zero ERROR/FATAL. Raw terminal warnings and short
2,073/2,430 ms overruns remain. The embedded login is not a real-client login;
logger/raw marker positions need not be described as packet admission.

The final independent pure check confirms one exact raw observation per phase,
followed by `save-all flush`, `stop` and the final all-dimension save. Its login
line numbers (seed 185 /continuation 62) identify PlayerList's `logged in with`
event; the prior packaged report's join lines 187 /64 identify the subsequent
`joined the game` event. Both precede raw observations 188 /65. They are distinct
events in the same retained stdout, not conflicting evidence or real-client proof.

The executed driver bytes equal the separately committed driver-02 at
`6d75429ab5f4941092216474c7d3d966417d3701` (02:48:12 UTC, preceding execution).
Driver SHA-256 is `63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e`.
Original driver-01 findings and eight-test cohort remain distinct from the
corrected nine-test and independent thirteen-binary-check records. This reviewer
inspected their receipts but did not rerun their tests or launch either driver.

Root and independent normal/source/API artifact receipts agree on bytes, entries
and hashes; normal JAR SHA-256 is
`0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011`, API is
`aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`, and
separate fixture is `92f31fbf73604e480be41fe028c4cda2d5c6e6e002a003ba5d3b127eb0295f76`.
Own checks reconcile 38 fixture-source hashes with actual fixed Git blobs, all
114 declared consumer classpath rows with independent audited fields, its
100,353,199-byte sum and API-only 29-class surface. The archived negative compile
exit 1/missing-internal-package diagnostic is intentional. The 104-library
166,368,435-byte inventory agrees with the receipt auditor's recorded enumeration.
Actual disposable installed JAR/library bytes were removed; they are not freshly
rehashed or independently rebuilt here. This is receipt consistency, not new
binary/runtime qualification.

## Provenance, ledger and archive integrity

Own fixed-blob checks verify all seven payload hashes, NEW authoring-source
hashes, four additive keys per language and the pending canonical digest
`405f659a116d4292bc7cb8706e075b8243055d8cb7e9badeab19dbf3b4110b34`.
The archived actual 666-byte upstream recipe/source/history outputs and all
command stdout/stderr hashes agree with the final recorded pinned touch history.
Root and independent raw history/name-status outputs are byte-identical. No new
upstream clone/browser request or human license review was performed here.

The ledger remains byte-identical to adoption, with 653 units and 186 PLANNED.
Own first-match evaluation of all 898 legacy assets yields 154 REVIEW. The only
effective plan change is `recipes/jackhammer.json`: REGENERATE to IMPORTED.
No other asset disposition or ledger delivery changes. Pending human provenance
and original-bitmap obligations are not closed by successful mechanical hashing.

All eleven committed archives have relative, case-unique, non-symlink paths;
every entry is below 50 MiB. Every read verifies its CRC, every manifest-covered
hash verifies, and each final top-level seal covers its full compact package.
The original source-03 854-entry seal and additive 859-entry correction both
verify without editing their original bytes. Aggregate: 6,365 entries,
10,062,671 compressed /60,714,962 expanded bytes, below 100 MiB. No archive is
persistently expanded here and no whole source/JAR/world/runtime copy is retained.
Per-archive identities, volumes, original/supplemental manifest identities and
covered counts are in CHECKS.json.

Publication receipt exactly matches actual archive bytes: 25,968 compressed,
55,613 expanded bytes /62 entries; archive hash
`20570b0ecb22faf6f418be226c990b7ad30722e6b7e09f63188f96c3c973eef8`, report hash
`6eab2c42ee1bcb4b1619975dca59141960e7f7c6b65b95833bf8246f94247a1d`, manifest hash
`b1c9c1f794afe05882e1e345cdfb16010b8a8332e77da3ae001a4fbc726c0bc7`.

The separate packaged notification erratum accurately distinguishes persisted
bytes from a normalized string. Actual seal: 103 CRLF rows /11,314 bytes, hash
`ee3313881c9c3851806ffd53a462dd62a346845e3612b882280cb82b7c793248`.
Only its LF representation is 11,211 bytes/hash
`9eb4c5db35bcf12b29d6f2067cbd9db4444a26bdd21ebeffa873b8b2fa95c7b4`.
The original writer's lines 54/60-61 confirm write_text default newline conversion
versus hashing pre-write text. All original 103 covered files remain valid; the
supplemental erratum has its own verified seal. Neither representation supplies
a manufactured native or qualification result.

## Commands this reviewer actually executed

| Independent command | UTC start/end on 2026-10-09 | Exit/result |
|---|---|---|
| Read-only fixed Git/PowerShell/Python exploration | Preliminary UTC not separately captured | Governance/records read; two failed guessed/schema reads disclosed |
| `python -B record_checks-01.py` equivalent original helper | 03:44:13.251566–03:44:17.460110 | Exit 1: checker conflated Git LF and checkout CRLF |
| `python -B record_checks.py` corrected helper | 03:46:50.370186–03:46:56.274293 | Exit 0: complete archive/XML/Git/log/NBT/receipt checks |
| `python -B additional_checks-01.py` equivalent original helper | 03:51:07.834769–03:51:11.409125 | Exit 1: checker rejected auditor-added byte-count fields |
| `python -B additional_checks.py` corrected helper | 03:51:40.607639–03:51:44.358576 | Exit 0: provenance/ledger/history/artifact/consumer/cleanup/status checks |
| `python -B final_record_checks.py` | 03:58:21.846626–03:58:22.133808 | Exit 0: native raw-marker and actual command/save ordering |
| Final read-only Git version/status/branch/HEAD/worktree/index | Exact per-command UTC in FINAL-OBSERVATIONS.json | All exit 0; no staged reviewer files |
| Persisted-byte sealing and re-verification | Exact UTC/metrics in SEAL-RESULT.json | Complete compact relative seal; no input mutation |

The original invocations actually named the live helper filename; the preserved
`*-01.py` copies are its exact bytes at failure time. Raw stdout/stderr and
argv/UTC/exit/hash receipts remain separate for each original/successor run.
EXPLORATION-NOTES.md preserves checker assumptions, exploratory path/schema
failures, missing exploratory UTC and output-presentation limits. No failed
target command is changed into PASS, and no target assertion/budget is weakened.

## Completion, remaining work, cleanup and seal

Completed: assigned fixed integration-record review; independent Git/blob,
archive/seal/CRC, actual XML/log/NBT, scope/current-history attribution and
provenance/ledger/receipt checks. Modified files are only this leaf's report,
reviewer-written scripts, command receipts and compact parsed outputs. No project
tests were added/modified. SHA256SUMS.txt seals the final persisted bytes; exact
covered file/byte/largest-file/total counters are in SEAL-RESULT.json.

This reviewer creates no `_tmp`, source clone, expanded archive, bytecode cache,
JAR, world, server or background process. Scratch expansion: 0 bytes. Cleanup
attempts: 0, because no disposable tree/process exists. Unsealed remainder: 0.
No peer cleanup or denied target retry/takeover occurred. Input archives and seals
are unchanged. Root's archived cleanup sums to 6,075 files /509,224,705 bytes;
source-04's successful own cleanup is 5,010,274,073 bytes, distinct from its later
denied 7,332-byte cache. Packaged review's denied 67-file /2,189,759-byte remainder
and source-01's 11,353-byte cache are excluded, not acquired or cleaned here.

Uncompleted/outside this review: runtime reruns, merged release reproducibility,
strict qualification, full survival/acquisition/recipe graph, native owner/member
and above-tier/mod matrix, COMMON display synchronization, prior-world/upgrade,
online-stop-first-save, crash recovery, real clients/GPU V1/V2, soak/reference
performance, human asset/provenance and final release acceptance. Historical
setup/cleanup/UTC/environment limits remain as disclosed in original reports.

Not all current-version Required Gates are satisfied. No item/asset/owner-policy,
ADR/risk acceptance, ledger delivery, G0-G9 PASS, candidate/tag or release decision
is inferred. v1.8 development remains IN_PROGRESS, separate from the earliest
v1.0 acceptance cursor. Remaining recommendations concern the stated current-v1.8
qualification and full-tool obligations, not a v1.9 implementation. All mutable
Main/source/HEAD/runtime/artifact interests remain released.
