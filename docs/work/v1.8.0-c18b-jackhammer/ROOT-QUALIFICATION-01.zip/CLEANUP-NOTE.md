# Root owned disposable cleanup

All independent readers released the Root runtime/build/history inputs before
the single native PowerShell attempt. cleanup_owned.ps1 ran without any execution
policy override, alternate shell or retry at 2026-10-09T03:15:39.4488539Z through
03:15:42.4884035Z, exit 0. Checked absolute roots are the Root-created isolated
jackhammer worktree and this exclusive evidence leaf. Live referencing process
set and reparse-point set were empty. CLEANUP-BEFORE/RESULT retain exact targets,
pre-removal lengths/counts and resolved-boundary checks.

Removed own ended build, DataGen runtime, local Gradle/consumer outputs/logs,
bare upstream clone/temporary data, pure-test Git fixtures and packaged server
copy/world/libraries. No source world, Main template, other-agent target or user
file was removed. All existing targets were absent afterward; no residual target
is retried. Compact XML/raw logs/typed stopped playerdata/receipts/manifests remain.
Other reviewers' separately denied temporary targets remain theirs, excluded
from their seals, and are not taken over by Root.
