"""Package the additive supplementary manifest without changing its original seal."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
source = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-source-independent-20261009-03")
manifest = source / "SHA256SUMS-CORRECTION-01.txt"
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == "143d09e38c7523ba5243c3a642609203fac495379c245d21fb8bf1a6e2ef91d0"
names, rows = set(), []
for line in manifest.read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    path = Path(name)
    assert not path.is_absolute() and ".." not in path.parts and name.casefold() not in names
    names.add(name.casefold())
    file = source / path
    assert file.is_file() and not file.is_symlink() and not file.is_junction()
    raw = file.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    rows.append((name, raw))
rows.append((manifest.name, manifest.read_bytes()))
assert len(rows) == 860 and sum(len(raw) for _, raw in rows) == 8451171
output = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/SOURCE-INDEPENDENT-03.zip")
assert not output.exists()
with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in rows:
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
record = dict(bytes=output.stat().st_size, sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
              files=len(rows), uncompressed_bytes=sum(len(raw) for _, raw in rows),
              report_sha256=hashlib.sha256((source / "REPORT.md").read_bytes()).hexdigest(),
              supplementary_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())
(root / "SOURCE-INDEPENDENT-PACKAGE-03.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
