"""Execute separate fixed-candidate qualification cohorts; retain every result."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path("D:/GitHub/arce-v180-jackhammer-20261009")
sha = "53523bcf68af203934845521e97af2f824b2958d"
records = []

def command(name, argv, cwd=root):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    (root / (name + "-launch.log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    record = dict(name=name, argv=[str(arg) for arg in argv], cwd=str(cwd), exit=result.returncode,
                  started_utc=start, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(record)
    (root / "QUALIFICATION-03.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)

command("capture-build-03", [sys.executable, root / "capture_junit.py", "build-03"])
for name, args in [("test-03", ["test"]), ("data-03a", ["runData"]),
                   ("data-03b", ["runData"]), ("native-03", ["runGameTestServer"])]:
    command(name, [sys.executable, root / "run_fixed.py", name, sha, *args])
    if name == "test-03":
        command("capture-test-03", [sys.executable, root / "capture_junit.py", name])
    if name.startswith("data-"):
        command(name + "-diff", ["git", "diff", "--exit-code"], repo)
        command(name + "-status", ["git", "status", "--short"], repo)
raise SystemExit(1 if any(record["exit"] for record in records) else 0)
