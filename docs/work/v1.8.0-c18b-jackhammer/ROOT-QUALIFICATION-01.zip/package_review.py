"""Package only an unchanged sealed review manifest and its covered files."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

source, target, receipt = map(Path, sys.argv[1:])
manifest = source / "SHA256SUMS.txt"
assert not target.exists() and not receipt.exists()
rows = []
names = set()
for line in manifest.read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    path = Path(name)
    assert not path.is_absolute() and ".." not in path.parts and name.casefold() not in names
    names.add(name.casefold())
    file = source / path
    assert file.is_file() and not file.is_symlink() and not file.is_junction()
    raw = file.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    rows.append((name, raw))
rows.append(("SHA256SUMS.txt", manifest.read_bytes()))
assert sum(len(raw) for _, raw in rows) <= 100 * 1024**2
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in rows:
        archive.writestr(name, raw)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(rows)
record = dict(archive=str(target), bytes=target.stat().st_size,
              sha256=hashlib.sha256(target.read_bytes()).hexdigest(), files=len(rows),
              uncompressed_bytes=sum(len(raw) for _, raw in rows),
              report_sha256=hashlib.sha256((source / "REPORT.md").read_bytes()).hexdigest(),
              manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())
receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
