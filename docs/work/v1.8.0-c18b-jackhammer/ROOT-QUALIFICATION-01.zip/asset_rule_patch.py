"""Render a manual one-asset rule patch; preserve all other effective dispositions."""
import csv
import fnmatch
import io
import json
from pathlib import Path

root = Path(__file__).resolve().parent
path = Path("D:/GitHub/arce-v180-jackhammer-20261009/docs/work/v1.8.0-asset-plan.csv")
old = path.read_text("utf-8").splitlines()
new_row = "199,recipes/jackhammer.json,IMPORTED,v1.8.0,item:jackHammer,MIT-derived DataGen conversion recorded in docs/provenance/v1.8.0-c18b-jackhammer.json; human review pending; not item or bitmap delivery"
assert old[199].startswith("199,recipes/*.json,REGENERATE,")
tail = [str(int(line.split(",", 1)[0]) + 1) + "," + line.split(",", 1)[1] for line in old[199:]]
new = old[:199] + [new_row] + tail
before = list(csv.DictReader(io.StringIO("\n".join(old))))
after = list(csv.DictReader(io.StringIO("\n".join(new))))
manifest = Path("D:/GitHub/arce-v180-jackhammer-20261009/legacy-manifest/assets.csv")
rows = list(csv.DictReader(manifest.open(encoding="utf-8")))
asset_prefix = "src/main/resources/assets/advancedrocketry/"
assets = [row["source_path"][len(asset_prefix):] for row in rows if row["source_path"].startswith(asset_prefix)]
assert assets
effective = lambda rules, asset: next(rule["handling"] for rule in rules if fnmatch.fnmatchcase(asset, rule["pattern"]))
changes = [(asset, effective(before, asset), effective(after, asset)) for asset in assets if effective(before, asset) != effective(after, asset)]
assert changes == [("recipes/jackhammer.json", "REGENERATE", "IMPORTED")], changes
(root / "ASSET-RULE-CHECK.json").write_text(json.dumps(dict(assets_checked=len(assets), semantic_changes=changes,
    before_rules=len(before), after_rules=len(after), all_other_effective_handlings_unchanged=True), indent=2) + "\n", encoding="utf-8")
print("*** Begin Patch\n*** Update File: " + path.as_posix() + "\n@@\n" +
      "\n".join("-" + line for line in old[199:]) + "\n" +
      "\n".join("+" + line for line in [new_row] + tail) + "\n*** End Patch")
