"""Bind committed harness and current candidate artifacts before native launch."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
repo = Path("D:/GitHub/arce-v180-jackhammer-20261009")
main = Path("D:/GitHub/AdvancedRocketry-Community")
source_sha = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
harness_sha = "6d75429ab5f4941092216474c7d3d966417d3701"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == source_sha
assert json.loads((root / "native-04/RESULT.json").read_text("utf-8"))["exit"] == 0
for name in ("publish-04", "consumer-04"):
    assert json.loads((root / name / "RESULT.json").read_text("utf-8"))["exit"] == 0
raw = subprocess.check_output(["git", "show", harness_sha + ":docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-02.zip"], cwd=main)
assert hashlib.sha256(raw).hexdigest() == "e93a7da4a4848f6b87761c3f006b673e8157ee1642c53e51c8cceb32ea9a9ca4"
driver = root / "driver-frozen-02/packaged_driver.py"
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert driver.read_bytes() == archive.read("packaged_driver.py")
host = repo / "build/libs/advancedrocketry-community-1.20.1-1.8.0-dev.jar"
fixture = repo / "compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar"
hash_file = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
host_hash, fixture_hash = hash_file(host), hash_file(fixture)
work = root / "packaged-02"
assert not work.exists()
records = root / "packaged-launch-02"
assert not records.exists()
records.mkdir()
for path in sorted((repo / "compat-test-mod/build/reports/consumer").glob("*")):
    if path.is_file():
        shutil.copyfile(path, records / path.name)
argv = [sys.executable, "-B", str(driver), "--source-checkout", str(repo), "--source-sha", source_sha,
        "--runtime-template", "D:/GitHub/AdvancedRocketry-Community/.gradle/v120-jei-session/server",
        "--host-jar", str(host), "--host-sha256", host_hash, "--fixture-jar", str(fixture),
        "--fixture-sha256", fixture_hash, "--work-root", str(work)]
record = dict(argv=argv, cwd=str(root), source_sha=source_sha, harness_commit=harness_sha,
              harness_archive_sha256=hashlib.sha256(raw).hexdigest(), driver_sha256=hash_file(driver),
              host_sha256=host_hash, fixture_sha256=fixture_hash, started_utc=datetime.now(timezone.utc).isoformat())
(records / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with (records / "command.log").open("wb") as log:
    result = subprocess.run(argv, cwd=root, stdout=log, stderr=subprocess.STDOUT)
record.update(exit=result.returncode, ended_utc=datetime.now(timezone.utc).isoformat(), log_sha256=hash_file(records / "command.log"))
(records / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(result.returncode)
