"""Verify and archive only immutable, manifest-covered contract evidence."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

root = Path(__file__).resolve().parent
leaf = root.parent / "jackhammer-contract-independent-20261009-01"
dest = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/CONTRACT-REVIEW-01.zip")
assert not dest.exists()
entries = []
for line in (leaf / "SHA256SUMS.txt").read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and ".." not in relative.parts
    assert ":" not in name and "\\" not in name
    path = leaf.joinpath(*relative.parts)
    assert path.resolve(strict=True).is_relative_to(leaf.resolve())
    assert not path.is_symlink() and not path.is_junction()
    payload = path.read_bytes()
    assert hashlib.sha256(payload).hexdigest() == digest
    assert len(payload) < 50 * 1024 ** 2
    entries.append((name, payload))
assert len(entries) == 104
entries.append(("SHA256SUMS.txt", (leaf / "SHA256SUMS.txt").read_bytes()))
assert len({name.casefold() for name, _ in entries}) == len(entries)
total = sum(len(payload) for _, payload in entries)
assert total < 100 * 1024 ** 2
with zipfile.ZipFile(dest, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, payload in entries:
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 9, 1, 38, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        archive.writestr(info, payload)
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(entries)
    assert all(archive.read(name) == payload for name, payload in entries)
result = dict(archive_bytes=dest.stat().st_size,
              archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
              uncompressed_bytes=total, files=len(entries),
              report_sha256=hashlib.sha256((leaf / "REPORT.md").read_bytes()).hexdigest(),
              manifest_sha256=hashlib.sha256((leaf / "SHA256SUMS.txt").read_bytes()).hexdigest(),
              manifests_crc_payloads_verified=True)
(root / "CONTRACT-PACKAGE.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
