"""Seal compact owned evidence once after disposing of ended runtime copies."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
result = root / "SEAL-RESULT.json"
assert not manifest.exists() and not result.exists()
for name in ("tmp", "driver-test-tmp", "packaged-02/_tmp"):
    assert not (root / name).exists(), name
license_bytes = subprocess.run(
    ["git", "-C", "D:/GitHub/arce-v180-jackhammer-20261009", "show",
     "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7:LICENSE"],
    check=True, capture_output=True).stdout
assert not (root / "SOURCE-LICENSE.txt").exists()
(root / "SOURCE-LICENSE.txt").write_bytes(license_bytes)
files = sorted(p for p in root.rglob("*") if p.is_file())
for path in root.rglob("*"):
    assert not path.is_symlink() and not path.is_junction(), path
for path in files:
    assert path.stat().st_size < 50 * 1024**2, path
    assert path.suffix.lower() not in (".jar", ".mca", ".mcc", ".class"), path
names = [p.relative_to(root).as_posix() for p in files]
assert len(names) == len(set(n.casefold() for n in names))
base_bytes = sum(p.stat().st_size for p in files)
cleanup = json.loads((root / "CLEANUP-RESULT.json").read_text("utf-8-sig"))
assert cleanup["result"] == "REMOVED" and not cleanup["process_check"]
record = dict(covered_files=len(files) + 1, covered_bytes=base_bytes,
              removed_disposable_files=sum(t["files"] for t in cleanup["targets"]),
              removed_disposable_bytes=sum(t["bytes"] for t in cleanup["targets"]),
              unsealed_disposable_bytes=0, source_sha="3b18a6bc8b58424d647053d6c6f1833ba14d9dc7",
              report_sha256=hashlib.sha256((root / "REPORT.md").read_bytes()).hexdigest(),
              source_license_sha256=hashlib.sha256(license_bytes).hexdigest())
for _ in range(20):
    raw = (json.dumps(record, indent=2) + "\n").encode("utf-8")
    new_bytes = base_bytes + len(raw)
    if new_bytes == record["covered_bytes"]:
        break
    record["covered_bytes"] = new_bytes
else:
    raise AssertionError("seal-result byte count did not stabilize")
assert record["covered_bytes"] < 100 * 1024**2
result.write_bytes(raw)
files.append(result)
rows = [(p.relative_to(root).as_posix(), hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
manifest.write_text("".join(f"{digest}  {name}\n" for name, digest in sorted(rows)), encoding="utf-8", newline="\n")
for name, digest in rows:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
assert sum(p.stat().st_size for p in files) == record["covered_bytes"]
print(json.dumps(record, indent=2))
print("manifest_sha256=" + hashlib.sha256(manifest.read_bytes()).hexdigest())
