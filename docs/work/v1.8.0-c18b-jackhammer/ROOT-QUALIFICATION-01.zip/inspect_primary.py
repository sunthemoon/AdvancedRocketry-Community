"""Read pinned primary API facts only; no game or source implementation is run."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

leaf = Path(__file__).resolve().parent
repo = Path("D:/GitHub/AdvancedRocketry-Community")
jar = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
javap = "C:/Program Files/Java/jdk-17.0.7/bin/javap.exe"
assert not (leaf / "PRIMARY-IDENTITIES.json").exists()
spaces = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
assert min(spaces.values()) > 10 * 1024 ** 3
commands = []
for name in (
    "net.minecraft.world.item.PickaxeItem", "net.minecraft.world.item.DiggerItem",
    "net.minecraft.world.item.TieredItem", "net.minecraft.world.item.Item$Properties",
    "net.minecraft.server.level.ServerPlayerGameMode", "net.minecraftforge.common.ForgeHooks",
    "net.minecraftforge.common.extensions.IForgeItem",
):
    argv = [javap, "-classpath", str(jar), "-p", "-c", name]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.run(argv, capture_output=True, timeout=60)
    output = leaf / (name.rsplit(".", 1)[-1] + ".javap.txt")
    assert not output.exists()
    output.write_bytes(child.stdout)
    errors = leaf / (name.rsplit(".", 1)[-1] + ".stderr.txt")
    assert not errors.exists()
    errors.write_bytes(child.stderr)
    commands.append(dict(argv=argv, start_utc=start,
                         end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         exit=child.returncode, timeout_seconds=60, output=output.name,
                         stdout_sha256=hashlib.sha256(child.stdout).hexdigest()))
    assert child.returncode == 0
recipe = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/upstream/ar/src/main/resources/assets/advancedrocketry/recipes/jackhammer.json")
recipe_bytes = recipe.read_bytes()
recipe_hash = hashlib.sha256(recipe_bytes).hexdigest()
assert recipe_hash == "a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45"
jar_hash = hashlib.sha256(jar.read_bytes()).hexdigest()
assert jar_hash == "95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e"
names = ["docs/work/v1.8.0-c18b-jackhammer/TASK-01.md",
         "docs/work/v1.8.0-c18b-jackhammer/REVIEW-TASK-01.md",
         "docs/provenance/v1.8.0-c18b-jackhammer-preauthoring.md"]
result = dict(head=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).decode().strip(),
              free_bytes=spaces, jar=str(jar), jar_sha256=jar_hash, commands=commands,
              recipe_source=str(recipe), recipe_sha256=recipe_hash,
              recipe_observation=json.loads(recipe_bytes),
              prepared_input_sha256={n: hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in names},
              static_api_inspection_only=True, source_authoring=False, runtime_tests=False)
(leaf / "PRIMARY-IDENTITIES.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(head=result["head"], commands=len(commands), recipe_sha256=recipe_hash,
                      static_api_inspection_only=True), indent=2))
