"""Render the actual primary history addition and recomputed pending digest."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
path = Path("D:/GitHub/arce-v180-jackhammer-20261009/docs/provenance/v1.8.0-c18b-jackhammer.json")
old = path.read_text("utf-8")
data = json.loads(old)
history = json.loads((root / "recipe-history-01/HISTORY.json").read_text("utf-8"))
entry = next(entry for entry in data["entries"] if entry["status"] == "UPSTREAM_AR_MIT")
assert history["source_path"] == entry["source_path"] and history["source_sha256"] == entry["source_sha256"]
entry["upstream_history"] = history["history"]
entry["upstream_history_evidence"] = "docs/work/v1.8.0-c18b-jackhammer/RECIPE-HISTORY-01.md"
core = {key: value for key, value in data.items() if key != "review"}
data["review"]["content_digest"] = hashlib.sha256((json.dumps(core, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")) + "\n").encode()).hexdigest()
new = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
(root / "HISTORY-PROVENANCE-DIGEST.json").write_text(json.dumps(dict(digest=data["review"]["content_digest"]), indent=2) + "\n")
print("*** Begin Patch\n*** Update File: " + path.as_posix() + "\n@@\n" +
      "\n".join("-" + line for line in old.splitlines()) + "\n" +
      "\n".join("+" + line for line in new.splitlines()) + "\n*** End Patch")
