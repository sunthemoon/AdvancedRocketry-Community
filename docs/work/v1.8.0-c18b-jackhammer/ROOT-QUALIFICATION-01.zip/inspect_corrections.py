"""Record exact primary console-source identity and native Boolean specification predicates."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
jar = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
assert hashlib.sha256(jar.read_bytes()).hexdigest() == "95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e"
commands = []
for name in ["net.minecraft.commands.CommandSourceStack", "net.minecraftforge.common.ForgeConfigSpec$Builder"]:
    argv = ["C:/Program Files/Java/jdk-17.0.7/bin/javap.exe", "-classpath", str(jar), "-p", "-c", name]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv, capture_output=True)
    filename = name.rsplit(".", 1)[-1] + "-correction.javap.txt"
    (root / filename).write_bytes(process.stdout)
    (root / (filename + ".stderr")).write_bytes(process.stderr)
    commands.append(dict(argv=argv, started_utc=started, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         exit=process.returncode, output=filename, sha256=hashlib.sha256(process.stdout).hexdigest()))
    assert process.returncode == 0
(root / "CORRECTION-PRIMARY.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
print(json.dumps(commands, indent=2))
