"""Run one fixed-source command, retaining stdout/stderr, argv, UTC and exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
checkout = Path("D:/GitHub/arce-v180-jackhammer-20261009")
name, expected, *args = sys.argv[1:]
out = root / name
assert not out.exists()
out.mkdir()
tmp = root / "tmp"
tmp.mkdir(exist_ok=True)
for drive in ["C:/", "D:/"]:
    assert shutil.disk_usage(drive).free >= 10 * 1024 ** 3
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip()
assert head == expected, (head, expected)
env = dict(os.environ, JAVA_HOME="C:/Program Files/Java/jdk-17.0.7", TEMP=str(tmp), TMP=str(tmp),
           JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=" + tmp.as_posix() + " -Dfile.encoding=UTF-8")
env["PATH"] = env["JAVA_HOME"] + "/bin;" + env["PATH"]
argv = [str(checkout / "gradlew.bat"), "--no-daemon", "--no-build-cache", "--rerun-tasks", *args]
record = dict(argv=argv, cwd=str(checkout), head=head, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              environment={key: env[key] for key in ["JAVA_HOME", "TEMP", "TMP", "JAVA_TOOL_OPTIONS"]},
              free_bytes={drive: shutil.disk_usage(drive).free for drive in ["C:/", "D:/"]})
(out / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with (out / "command.log").open("wb") as log:
    try:
        result = subprocess.run(argv, cwd=checkout, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
        record["exit"] = result.returncode
    except subprocess.TimeoutExpired:
        record["exit"] = "TIMEOUT"
record["ended_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record["log_sha256"] = hashlib.sha256((out / "command.log").read_bytes()).hexdigest()
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2), flush=True)
sys.exit(0 if record["exit"] == 0 else 1)
