"""Actual fixed-source validation; retain timeouts and every separate outcome."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path("D:/GitHub/arce-v180-jackhammer-20261009")
sha = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == sha
out = root / "static-04"
assert not out.exists()
out.mkdir()
records = []
for name, argv in [
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("bootstrap", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py", "--require-approved-review"]),
    ("strict", [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]),
    ("whitespace", ["git", "diff", "--check", "106d31653f8bce66761c919742629a75a047e2ca", sha]),
]:
    record = dict(name=name, argv=argv, source_sha=sha, cwd=str(repo), started_utc=datetime.now(timezone.utc).isoformat(), deadline_seconds=180)
    with (out / (name + ".log")).open("wb") as log:
        try:
            result = subprocess.run(argv, cwd=repo, stdout=log, stderr=subprocess.STDOUT, timeout=180)
            record["exit"] = result.returncode
        except subprocess.TimeoutExpired:
            record["exit"] = "TIMEOUT"
    record["ended_utc"] = datetime.now(timezone.utc).isoformat()
    record["log_sha256"] = hashlib.sha256((out / (name + ".log")).read_bytes()).hexdigest()
    records.append(record)
    (out / "COMMANDS.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)
data = json.loads((repo / "docs/provenance/v1.8.0-c18b-jackhammer.json").read_text("utf-8"))
core = {key: value for key, value in data.items() if key != "review"}
digest = hashlib.sha256((json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()).hexdigest()
assert digest == data["review"]["content_digest"] and data["review"]["status"] == "PENDING_HUMAN_REVIEW"
rows = []
for entry in data["entries"]:
    raw = (repo / entry["target_path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == entry["target_sha256"]
    if entry["status"] == "NEW":
        source = subprocess.check_output(["git", "show", entry["authoring_commit"] + ":" + entry["source_path"]], cwd=repo)
        assert hashlib.sha256(source).hexdigest() == entry["source_sha256"]
    else:
        history = json.loads((root / "recipe-history-01/HISTORY.json").read_text("utf-8"))
        assert entry["upstream_history"] == history["history"]
        assert hashlib.sha256((root / "recipe-history-01/source.stdout").read_bytes()).hexdigest() == entry["source_sha256"]
    rows.append(dict(path=entry["target_path"], sha256=entry["target_sha256"], bytes=len(raw)))
(out / "PROVENANCE-CHECK.json").write_text(json.dumps(dict(source_sha=sha, pending_digest=digest, targets=rows), indent=2) + "\n", encoding="utf-8")
raise SystemExit(0 if all(row["exit"] == 0 for row in records) else 1)
