"""Retain the just-executed fixed source's actual JUnit XML, without live build references."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
name = sys.argv[1]
out = root / name
assert (out / "RESULT.json").exists()
dest = out / "junit"
assert not dest.exists()
dest.mkdir()
files = sorted(Path("D:/GitHub/arce-v180-jackhammer-20261009/build/test-results/test").glob("TEST-*.xml"))
assert files
cases = []
inventory = []
for path in files:
    raw = path.read_bytes()
    tree = ET.fromstring(raw)
    cases.extend(tree.iter("testcase"))
    shutil.copyfile(path, dest / path.name)
    inventory.append(dict(path="junit/" + path.name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
result = dict(source=json.loads((out / "RESULT.json").read_text("utf-8"))["head"],
              xml_files=len(files), actual_cases=len(cases),
              failures=sum(case.find("failure") is not None for case in cases),
              errors=sum(case.find("error") is not None for case in cases),
              skips=sum(case.find("skipped") is not None for case in cases), files=inventory)
(out / "JUNIT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "files"}))
