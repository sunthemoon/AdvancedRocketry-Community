"""Execute resource/provenance/art portions not reached by the timed-out validator attempt."""
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parent
tmp = root / "tmp"
os.environ["TEMP"] = os.environ["TMP"] = str(tmp)
source = (root / "static_checks.py").read_text("utf-8")
source = source.replace('out = root / "static-01"', 'out = root / "resources-01"')
start = source.index("records = []")
end = source.index("provenance = json.loads")
source = source[:start] + "records = []\n" + source[end:]
exec(compile(source, str(root / "static_checks.py") + "[resources-only]", "exec"), {"__file__": str(root / "static_checks.py"), "__name__": "__main__"})
