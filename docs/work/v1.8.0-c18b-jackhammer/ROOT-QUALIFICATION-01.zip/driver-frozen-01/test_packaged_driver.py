"""Pure fail-closed validations, not native execution evidence."""
import copy
import json
import unittest
import uuid

import packaged_driver as driver


def row(phase="seed", before=17, after=18):
    return f"ARCE_JACKHAMMER_CONTINUATION stage={phase} uuid={driver.UUID} before_damage={before} after_damage={after}"


def player(damage=18):
    number = uuid.UUID(driver.UUID).int
    words = [(number >> shift) & 0xffffffff for shift in (96, 64, 32, 0)]
    words = [value if value < 2**31 else value - 2**32 for value in words]
    tag = {"Damage": (3, damage), "fixture_note": (8, "native continuation"),
           "display": (10, {"Name": (8, json.dumps({"text": "Jackhammer restart"}))}),
           "Enchantments": (9, [(10, {"id": (8, "minecraft:efficiency"), "lvl": (2, 2)})])}
    item = {"id": (8, driver.ITEM), "Slot": (1, 0), "Count": (1, 1), "tag": (10, tag)}
    return (10, {"UUID": (11, words), "DataVersion": (3, 3465), "playerGameType": (3, 0),
                 "SelectedItemSlot": (3, 0), "Inventory": (9, [(10, item)])})


class DriverTest(unittest.TestCase):
    def test_accepts_raw_and_native_stdout_sources(self):
        for prefix in ("", "[12:34:56] [Server thread/INFO] [STDOUT/]: "
                       "[io.github.sunthemoon.arceadaptertest.JackhammerContinuationFixture:run:130]: "):
            self.assertEqual(driver.observations([prefix + row()], "seed")["after_damage"], 18)

    def test_accepts_only_correct_continuation_phase(self):
        self.assertEqual(driver.observations([row("continue", 18, 19)], "continue")["before_damage"], 18)
        for lines in ([], [row(), row()], [row("continue", 18, 19)], [row("seed", 18, 19)]):
            with self.assertRaises(ValueError): driver.observations(lines, "seed")

    def test_rejects_echo_wrong_logger_uuid_and_oversized_marker(self):
        for line in ("echo " + row(), "[Server thread/INFO] [other/]: " + row(),
                     row().replace(driver.UUID, str(uuid.uuid4())), row() + "x" * 4096):
            with self.assertRaises(ValueError): driver.observations([line], "seed")

    def test_native_stop_must_precede_completed_save(self):
        prefix = "[12:34:56] [Server thread/INFO] [minecraft/MinecraftServer]: "
        stop = prefix + "Stopping server"
        saved = prefix + "ThreadedAnvilChunkStorage: All dimensions are saved"
        self.assertEqual(driver.clean_stop([stop, saved])["stopping_line"], 1)
        for lines in ([saved, stop], [saved], [stop, stop, saved], ["echo " + stop, saved]):
            with self.assertRaises(ValueError): driver.clean_stop(lines)

    def test_exact_typed_saved_stack(self):
        for damage in (18, 19):
            self.assertEqual(driver.validate_player(player(damage), damage)["damage"], damage)

    def test_wrong_nbt_wire_types_refused(self):
        for name in ("UUID", "DataVersion", "playerGameType", "SelectedItemSlot", "Inventory"):
            root = player()
            root[1][name] = (8, root[1][name][1])
            with self.assertRaises(ValueError): driver.validate_player(root, 18)

    def test_duplicate_item_and_wrong_selected_mode_refused(self):
        for name, value in (("playerGameType", (3, 1)), ("SelectedItemSlot", (3, 1))):
            root = player(); root[1][name] = value
            with self.assertRaises(ValueError): driver.validate_player(root, 18)
        root = player(); root[1]["Inventory"][1].append(copy.deepcopy(root[1]["Inventory"][1][0]))
        with self.assertRaises(ValueError): driver.validate_player(root, 18)

    def test_item_count_damage_and_metadata_mutation_refused(self):
        for name, value in (("Count", (1, 2)), ("Slot", (1, 1)), ("id", (8, "minecraft:diamond_pickaxe"))):
            root = player(); root[1]["Inventory"][1][0][1][name] = value
            with self.assertRaises(ValueError): driver.validate_player(root, 18)
        for name, value in (("Damage", (3, 17)), ("Damage", (2, 18)),
                            ("fixture_note", (8, "changed")), ("Enchantments", (9, []))):
            root = player(); root[1]["Inventory"][1][0][1]["tag"][1][name] = value
            with self.assertRaises(ValueError): driver.validate_player(root, 18)


if __name__ == "__main__":
    unittest.main()
