"""Capture pure tests, freeze the bounded harness, and produce a compact archive."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
dest = root / "driver-frozen-01"
assert not dest.exists()
dest.mkdir()
argv = [sys.executable, "-B", "-m", "unittest", "-v", "test_packaged_driver"]
start = datetime.now(timezone.utc).isoformat()
result = subprocess.run(argv, cwd=root, capture_output=True, text=True, encoding="utf-8")
(dest / "tests.log").write_text(result.stdout + result.stderr, encoding="utf-8")
record = dict(argv=argv, cwd=str(root), started_utc=start, ended_utc=datetime.now(timezone.utc).isoformat(),
              exit=result.returncode, native_execution=False)
(dest / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
assert result.returncode == 0
for name in ("packaged_driver.py", "test_packaged_driver.py", "freeze_driver.py"):
    (dest / name).write_bytes((root / name).read_bytes())
files = sorted(dest.iterdir())
lines = [hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.name for path in files]
(dest / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
output = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18b-jackhammer/PACKAGED-DRIVER-01.zip")
assert not output.exists()
with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(dest.iterdir()):
        archive.writestr(path.name, path.read_bytes())
summary = dict(archive=str(output), bytes=output.stat().st_size,
               sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
               uncompressed_bytes=sum(path.stat().st_size for path in dest.iterdir()), files=len(list(dest.iterdir())),
               driver_sha256=hashlib.sha256((dest / "packaged_driver.py").read_bytes()).hexdigest(),
               manifest_sha256=hashlib.sha256((dest / "SHA256SUMS.txt").read_bytes()).hexdigest())
(root / "DRIVER-PACKAGE-01.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
