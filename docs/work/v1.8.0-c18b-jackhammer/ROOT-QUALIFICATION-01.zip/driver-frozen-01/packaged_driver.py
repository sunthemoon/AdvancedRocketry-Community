"""Bounded two-process native inventory/use proof, not crash or client proof."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
import zipfile

UUID = "914adf94-5147-49a3-bf78-ff21cd948719"
ITEM = "advancedrocketrycommunity:jackhammer"
VERSION = "1.20.1-1.8.0-dev"
MAX_COMPRESSED = 1024 * 1024
MAX_EXPANDED = 4 * 1024 * 1024
CONSOLE = r"^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Server thread/INFO\] \[minecraft/MinecraftServer\]: "
STDOUT = (r"^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Server thread/INFO\] \[STDOUT/\]: "
          r"\[io\.github\.sunthemoon\.arceadaptertest\.JackhammerContinuationFixture:run:\d+\]:? ")
PAYLOAD = (r"ARCE_JACKHAMMER_CONTINUATION stage=(seed|continue) uuid=" + UUID +
           r" before_damage=(17|18) after_damage=(18|19)\s*$")
ROW = re.compile("(?:" + CONSOLE + "|" + STDOUT + r"|^)(?:" + PAYLOAD + ")")
STOP = re.compile(CONSOLE + r"Stopping server\s*$")
SAVED = re.compile(CONSOLE + r"ThreadedAnvilChunkStorage: All dimensions are saved\s*$")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def utc():
    return datetime.now(timezone.utc).isoformat()


def observations(lines, phase):
    require(phase in ("seed", "continue"), "Unknown phase")
    rows = []
    for line in lines:
        if "ARCE_JACKHAMMER_CONTINUATION" not in line:
            continue
        require(len(line.encode("utf-8")) <= 4096, "Oversized observation")
        match = ROW.fullmatch(line.rstrip("\r\n"))
        require(match is not None, "Malformed/untrusted observation source")
        rows.append(match.groups())
    before, after = ("17", "18") if phase == "seed" else ("18", "19")
    require(rows == [(phase, before, after)], "Missing/duplicate/out-of-order observation")
    return dict(stage=phase, uuid=UUID, before_damage=int(before), after_damage=int(after))


def clean_stop(lines):
    stops = [i for i, line in enumerate(lines) if STOP.fullmatch(line.rstrip())]
    saves = [i for i, line in enumerate(lines) if SAVED.fullmatch(line.rstrip())]
    require(len(stops) == 1 and any(i > stops[0] for i in saves), "Missing native stop/save order")
    return dict(stopping_line=stops[0] + 1, saved_after_stop_line=max(saves) + 1)


def validate_player(root, damage):
    require(type(damage) is int and damage in (18, 19), "Unknown saved damage phase")
    require(root[0] == 10, "Wrong player root wire type")
    data = root[1]
    number = uuid.UUID(UUID).int
    signed = lambda value: value if value < 2**31 else value - 2**32
    words = [signed((number >> shift) & 0xffffffff) for shift in (96, 64, 32, 0)]
    require(data.get("UUID") == (11, words), "Wrong native saved UUID")
    require(data.get("playerGameType") == (3, 0) and data.get("SelectedItemSlot") == (3, 0),
            "Wrong native game mode or selected slot")
    version = data.get("DataVersion")
    require(type(version) is tuple and version[0] == 3 and type(version[1]) is int and version[1] > 0,
            "Missing native data version")
    inventory = data.get("Inventory")
    require(type(inventory) is tuple and inventory[0] == 9 and type(inventory[1]) is list,
            "Wrong native inventory wire type")
    require(len(inventory[1]) == 1 and inventory[1][0][0] == 10, "Unexpected/multiple native inventory items")
    item = inventory[1][0][1]
    require(set(item) == {"Slot", "id", "Count", "tag"} and item.get("Slot") == (1, 0)
            and item.get("id") == (8, ITEM) and item.get("Count") == (1, 1), "Wrong native item identity/count/slot")
    tag = item.get("tag")
    require(type(tag) is tuple and tag[0] == 10 and type(tag[1]) is dict, "Wrong item tag wire type")
    values = tag[1]
    require(set(values) == {"Damage", "display", "Enchantments", "fixture_note"}
            and values.get("Damage") == (3, damage)
            and values.get("fixture_note") == (8, "native continuation"), "Saved wear/unrelated item data changed")
    require(values.get("Enchantments") == (9, [(10, {"id": (8, "minecraft:efficiency"), "lvl": (2, 2)})]),
            "Saved native enchantment changed")
    display = values.get("display")
    require(type(display) is tuple and display[0] == 10 and set(display[1]) == {"Name"}, "Saved native display changed")
    name = display[1]["Name"]
    require(name[0] == 8 and json.loads(name[1]) == {"text": "Jackhammer restart"}, "Saved native name changed")
    return dict(uuid=UUID, damage=damage, item=ITEM, count=1, slot=0, native_data_version=version[1],
                game_mode=0, enchantment="minecraft:efficiency", enchantment_level=2,
                name="Jackhammer restart", fixture_note="native continuation")


def read_player(path, nbt, damage):
    require(path.is_file() and not path.is_symlink() and not path.is_junction(), "Missing/linked playerdata")
    require(0 < path.stat().st_size <= MAX_COMPRESSED, "Oversized playerdata")
    compressed = path.read_bytes()
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        expanded = stream.read(MAX_EXPANDED + 1)
    require(len(expanded) <= MAX_EXPANDED, "Oversized expanded playerdata")

    class TypedReader(nbt.NbtReader):
        def _payload(self, tag_type, depth):
            return tag_type, super()._payload(tag_type, depth)

    return compressed, validate_player(TypedReader(expanded).read_root(), damage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-checkout", "runtime-template", "host-jar", "fixture-jar", "work-root"):
        parser.add_argument("--" + name, required=True, type=Path)
    for name in ("source-sha", "host-sha256", "fixture-sha256"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--java", default="C:/Program Files/Java/jdk-17.0.7/bin/java.exe")
    args = parser.parse_args()
    source = args.source_checkout.resolve()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
    require(head == args.source_sha, "Source HEAD differs from frozen input")
    require(subprocess.run(["git", "diff", "--exit-code", "--", "scripts", "src", "build.gradle",
                            "compat-test-mod/build.gradle"], cwd=source).returncode == 0, "Uncommitted source input")
    sys.path.insert(0, str(source / "scripts"))
    import run_dedicated_server_smoke as server
    import inspect_celestial_saved_data as nbt

    work = args.work_root.resolve()
    require(not work.exists() and not server.is_link_or_junction(args.work_root), "Use an absent owned work directory")
    inputs = [args.runtime_template, args.host_jar, args.fixture_jar, source]
    for path in inputs:
        for ancestor in [path.absolute(), *path.absolute().parents]:
            require(not server.is_link_or_junction(ancestor), "Linked input ancestor")
        resolved = path.resolve()
        require(not work.is_relative_to(resolved) and not resolved.is_relative_to(work), "Overlapping input/output")
    for ancestor in [args.work_root.absolute(), *args.work_root.absolute().parents]:
        require(not server.is_link_or_junction(ancestor), "Linked output ancestor")
    space = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
    require(all(free >= 10 * 1024**3 for free in space.values()), "Insufficient disk space")
    java, java_version = server.resolve_java(args.java)
    require(java_version.startswith("17."), "Require Java17")
    artifacts = []
    for path, expected, mod, version in [(args.host_jar, args.host_sha256, "advancedrocketrycommunity", VERSION),
                                         (args.fixture_jar, args.fixture_sha256, "arce_adapter_test", "1.0.0")]:
        require(path.is_file() and server.digest_file(path) == expected, "Artifact hash mismatch")
        with zipfile.ZipFile(path) as archive:
            require(archive.testzip() is None, "Artifact CRC failure")
            metadata = archive.read("META-INF/mods.toml").decode("utf-8")
            require(f'modId="{mod}"' in metadata and f'version="{version}"' in metadata, "Wrong artifact identity")
            artifacts.append(dict(path=str(path.resolve()), name=path.name, sha256=expected, mod=mod, version=version))
    require(artifacts[0]["name"] != artifacts[1]["name"], "Colliding artifact names")
    libraries = args.runtime_template / "libraries"
    require(libraries.is_dir(), "Missing runtime libraries")
    library_rows = []
    for path in sorted(libraries.rglob("*")):
        require(not server.is_link_or_junction(path), "Linked library tree member")
        if path.is_file():
            library_rows.append(dict(path=path.relative_to(libraries).as_posix(), bytes=path.stat().st_size,
                                     sha256=server.digest_file(path)))
    require(library_rows, "Empty libraries")
    runtime = work / "_tmp" / "server"
    runtime.mkdir(parents=True)
    shutil.copytree(libraries, runtime / "libraries")
    for row in library_rows:
        require(server.digest_file(runtime / "libraries" / row["path"]) == row["sha256"], "Copied library changed")
    mods = runtime / "mods"
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact["path"], mods / artifact["name"])
        require(server.digest_file(mods / artifact["name"]) == artifact["sha256"], "Installed artifact changed")
    port = server.allocate_port()
    properties = server.expected_server_properties(port, True)
    properties.update({"enable-rcon": "false", "enable-query": "false", "gamemode": "survival",
                       "force-gamemode": "false", "level-seed": "0", "motd": "ARCE jackhammer development proof"})
    payload = "".join(f"{key}={value}\n" for key, value in sorted(properties.items())).encode("ascii")
    (runtime / "server.properties").write_bytes(payload)
    (runtime / "eula.txt").write_text("# Fresh automated development test\neula=true\n", encoding="ascii")
    identity = hashlib.sha256((str(work) + args.source_sha + args.host_sha256).encode()).hexdigest()
    marker = runtime / ".jackhammer-world-identity.json"
    write(marker, dict(identity=identity, source=args.source_sha))
    marker_hash = server.digest_file(marker)
    helper_files = [Path(__file__), Path(server.__file__), Path(nbt.__file__)]
    dependencies = [dict(path=str(path.resolve()), sha256=server.digest_file(path)) for path in helper_files]
    write(work / "inputs.json", dict(source_sha=head, artifacts=artifacts, java=java, java_version=java_version,
          java_sha256=server.digest_file(Path(java)), dependencies=dependencies, free_bytes=space,
          runtime_template=str(args.runtime_template.resolve()), libraries=library_rows, identity=identity,
          configured_properties_sha256=hashlib.sha256(payload).hexdigest(), configured_properties=properties))
    args_file = runtime / "libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt"
    require(args_file.is_file(), "Missing pinned Forge arguments")
    command = [java, "-Xms512M", "-Xmx2G", "-Djava.net.preferIPv4Stack=true",
               "-Darce.jackhammerSmoke=true", "@" + args_file.relative_to(runtime).as_posix(), "nogui"]
    temp = work / "_tmp" / "java-tmp"
    temp.mkdir()
    command.insert(4, "-Djava.io.tmpdir=" + temp.as_posix())
    os.environ["TEMP"] = str(temp)
    os.environ["TMP"] = str(temp)
    records = []
    for phase, damage in [("seed", 18), ("continue", 19)]:
        evidence = work / phase
        evidence.mkdir()
        commands = []
        receipt = dict(phase=phase, result="IN_PROGRESS", started_utc=utc(), cwd=str(runtime), argv=command,
                       environment={key: os.environ[key] for key in ("TEMP", "TMP")})
        process = None
        try:
            require(all(shutil.disk_usage(drive).free >= 10 * 1024**3 for drive in ("C:/", "D:/")), "Insufficient launch space")
            require(server.digest_file(marker) == marker_hash, "World identity changed")
            for artifact in artifacts:
                require(server.digest_file(mods / artifact["name"]) == artifact["sha256"], "Restart artifact changed")
            if phase == "seed":
                require(not (runtime / "world").exists(), "Seed world already exists")
            else:
                require((runtime / "world/level.dat").is_file(), "Restart world missing")
                read_player(runtime / "world/playerdata" / (UUID + ".dat"), nbt, 18)
            process = server.CapturedProcess(command, runtime, evidence / "stdout.txt")
            receipt["pid"] = process.process.pid
            write(evidence / "launch.json", receipt)
            process.wait_for(server.READY_MARKER, 300)
            status = server.wait_for_status(port, 60)
            server.validate_status_identity(status, VERSION)
            require(server.forge_mod_versions(status).get("arce_adapter_test") == "1.0.0", "Fixture missing from status")
            write(evidence / "status.json", status)
            start = len(process.lines)
            commands.append("arce_jackhammer_test " + phase)
            process.command(commands[-1])
            process.wait_for(ROW, 60, start_at=start)
            receipt["observation"] = observations(process.lines[start:], phase)
            start = len(process.lines)
            commands.append("save-all flush"); process.command(commands[-1])
            process.wait_for(server.SAVE_MARKER, 60, start_at=start)
            commands.append("stop"); process.command(commands[-1])
            receipt["exit"] = process.finish(90)
            require(receipt["exit"] == 0, "Native process failed")
            receipt["clean_stop"] = clean_stop(process.lines)
            observations(process.lines, phase)
            findings = server.scan_log(process.lines)
            findings.extend(line.rstrip() for line in process.lines if server.WARNING_LINE.search(line)
                            and re.search(r"(?:Failed|failed|Couldn't|couldn't|Unable|unable).*player", line))
            receipt["log_findings"] = findings
            require(not findings, "Native log findings require review")
            raw, observed = read_player(runtime / "world/playerdata" / (UUID + ".dat"), nbt, damage)
            (evidence / "playerdata.dat").write_bytes(raw)
            write(evidence / "playerdata-observation.json", observed)
            receipt["playerdata_sha256"] = hashlib.sha256(raw).hexdigest()
            actual = server.parse_java_properties((runtime / "server.properties").read_bytes())
            require(all(actual.get(key) == value for key, value in properties.items()), "Native properties changed owned settings")
            require(server.digest_file(marker) == marker_hash, "Same-world marker changed")
            receipt.update(result="PASS", log_counts=server.log_audit_counts(process.lines))
        except BaseException as error:
            receipt.update(result="FAIL", error=f"{type(error).__name__}: {error}")
            if process is not None:
                process.abort()
            raise
        finally:
            receipt["ended_utc"] = utc()
            write(evidence / "receipt.json", receipt); write(evidence / "commands.json", commands)
            for name in ("latest.log", "debug.log"):
                log = runtime / "logs" / name
                if log.is_file():
                    shutil.copyfile(log, evidence / name)
            records.append(receipt)
            write(work / "RESULT.json", records)
    for dependency in dependencies:
        require(server.digest_file(Path(dependency["path"])) == dependency["sha256"], "Harness input changed")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
