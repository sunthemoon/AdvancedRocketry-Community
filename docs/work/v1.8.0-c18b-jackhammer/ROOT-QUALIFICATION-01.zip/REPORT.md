# Root ordinary jackhammer qualification

Date: 2026-10-09. This leaf records actual development commands and narrow
native observations, not full item delivery, provenance approval or release.

## Scope and fixed identities

The adopted ordinary tool uses stable `advancedrocketrycommunity:jackhammer`,
native diamond PickaxeItem harvesting, durability 1024 and pickaxe-tag speed 50.
It preserves native drops, permissions, reach, creative behavior, anvil and
ItemStack persistence. The additive COMMON equipment switch is server-authoritative
at final ordinary mining/melee hooks; there is no area mining, world scan,
new tier/API/protocol/schema or client-side final decision.

Adoption base: `106d31653f8bce66761c919742629a75a047e2ca`.
Latest tested source: `3b18a6bc8b58424d647053d6c6f1833ba14d9dc7`.
Frozen native driver revision 02 is published at Main metadata commit
`6d75429ab5f4941092216474c7d3d966417d3701` before its actual execution.
Root owns the isolated `codex/v1.8.0-jackhammer` worktree and this evidence leaf;
reviewers own distinct leaves and temporary clones. Main's user-owned AGENTS.md,
inherited worktrees, worlds and untracked archives are not edited or cleaned.

## Original and corrective cohorts remain separate

| Actual Root source cohort | Forced clean build /actual JUnit | Native result |
|---|---|---|
| 61cada9e | Exit 1; 2189 /380 XML /1 failure | Exit 1; 578 complete, four required tool failures |
| bab14562 | Exit 1; 2192 /381 XML /1 failure | Not run by Root on this SHA |
| 53523bcf | Exit 0; 2192 /381 XML /0 failures/errors/skips | Exit 1; missing adapter-namespace template, no final completion |
| 3b18a6bc | Exit 0; 2192 /381 XML /0 failures/errors/skips | Exit 0; all 579 required cases pass |

The original config-inventory assertion counted 73 instead of 74. Original
native fixtures omitted real crafting/anvil context and retained-name input,
and reused pending native bedrock destruction state for the reach case.
Those failures precede the corrective commits and remain in build-01/native-01.
The bab14562 native Boolean specification legally accepts string true; the
incorrect rejection expectation is retained as build-02, not changed into PASS.
The 53523bcf new native-console authority case lacked the host template namespace;
3b18a6bc fixes that declaration without weakening its assertion or tick deadline.

Source reviewers independently retain their own original/corrected commands,
findings and cleanup results. They do not establish Root's unexecuted bab14562
native result. Independent source-03 retains its native latest/debug/crash files;
Root's attempted native-03 snapshot used the wrong `run/logs` directory and
failed. Root retains its complete command stdout only for that native-03 run;
later clean erased its mutable runtime files. Root native-04 successfully copies
actual `build/gametest/logs` latest/debug before cleanup.

## Latest complete actual commands

`run_fixed.py` checks fixed source HEAD and C/D free space above 10 GiB, uses
Java 17 with owned D-drive TEMP/TMP/Java temporary storage, and forces
`--no-daemon --no-build-cache --rerun-tasks`. Each command has its own COMMAND,
RESULT and raw output; JUnit XML is copied before subsequent tasks overwrite it.
`QUALIFICATION-04.json` records exact argv, UTC start/end and exits.

| Actual command on 3b18a6bc | Exit /result |
|---|---|
| gradlew clean build | 0; 20 executed tasks; 2192 JUnit /381 XML /0 F/E/S |
| gradlew test | 0; 17 executed tasks; separate 2192 JUnit /381 XML /0 F/E/S |
| gradlew runData, first forced invocation | 0; 10 executed tasks |
| git diff --exit-code; git status --short | 0; empty separately captured outputs |
| gradlew runData, second forced invocation | 0; 10 executed tasks |
| git diff --exit-code; git status --short | 0; empty separately captured outputs |
| gradlew runGameTestServer, unfiltered | 0; 18 executed tasks; all 579 required cases pass |
| gradlew publishMavenJavaPublicationToLocalProjectRepositoryRepository --offline | 0; 17 executed tasks |
| gradlew -p compat-test-mod clean build -ParceVersion=1.20.1-1.8.0-dev --offline | 0; 10 executed tasks |
| python -B scripts/validate_v180_content_ledger.py --require-accepted | 0 |
| python -B scripts/validate_bootstrap_provenance.py --require-approved-review | 0 |
| python -B scripts/validate_repository.py --require-approved-identity | TIMEOUT at the unchanged 180-second deadline; empty log |
| git diff --check 106d3165 3b18a6bc | 0 |

Build runs from 02:45:32.303223Z to 02:48:27.328362Z; separate test from
02:48:27.719182Z to 02:51:26.820350Z; native from 02:53:02.708725Z to
02:57:20.031453Z. The new native batches are thirteen ordinary tool cases and
one adapter-console authority case. Complete latest native logs retain
161 WARN /62 ERROR /zero FATAL headers. No blanket waiver or clean-log Gate
is inferred from the required-test PASS. Original independent strict link
failure and later Root/reviewer TIMEOUT cohorts are not interchangeable.

`ARTIFACTS-04.json` records actual lengths, hashes and entries after publication:

| Actual artifact | Bytes | SHA-256 |
|---|---:|---|
| Main JAR | 6073913 | 0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011 |
| Sources JAR | 2892005 | 7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a |
| API JAR | 51052 | aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b |
| Separate adapter fixture JAR | 143762 | 92f31fbf73604e480be41fe028c4cda2d5c6e6e002a003ba5d3b127eb0295f76 |

The API JAR is unchanged from the preceding detector cohort. The opt-in
continuation fixture appears only in the separate compat JAR, not the host.
Consumer source/dependency/API-boundary receipts accompany consumer-04; the
consumer's internal-implementation negative compile intentionally exits 1.

## Actual two-process native continuation

The driver is immutable revision 02, archive SHA-256
`e93a7da4a4848f6b87761c3f006b673e8157ee1642c53e51c8cceb32ea9a9ca4`,
driver SHA-256
`63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e`.
Original revision 01 was frozen but never launched natively; its reviewer E1/E2
findings are preserved. Revision 02 requires trusted fixture markers and
verifies executed helper bytes against fixed Git objects, including staged
changes. Its nine frozen pure tests pass; the original eight-test result remains.

`packaged-launch-02` actually exits 0 between 02:59:12.689471Z and
03:00:09.309058Z. It launches the exact previously committed driver bytes.
Runtime libraries are copied read-only from the existing Forge 47.4.10 template;
all 104 source/copy files are hashed. The fresh owned world binds loopback only,
offline mode, survival, RCON/query disabled and exactly host plus fixture JARs.
It installs no dependencies and starts no real client or external connection.

| Actual native process | Seed | Continue |
|---|---|---|
| PID | 27148 | 20452 |
| Start UTC | 02:59:14.109723Z | 02:59:46.341387Z |
| End UTC | 02:59:46.336676Z | 03:00:09.280633Z |
| Exit | 0 | 0 |
| Actual tool use | 17 to 18 | native load 18 before action, then 19 |
| Stopped playerdata SHA-256 | 5e71a8c8be626c391062ab4116d0dbc8f1078d7f7197168ca898cebe015dbe6e | dcb8f084bec60e7a37920d200a02ea72f2df5d9788efba292279bc7b2ae1e004 |
| Bracketed WARN | 113 | 11 |
| ERROR /FATAL /project findings | 0 /0 /0 | 0 /0 /0 |

Both use actual ServerPlayer/native PlayerList.placeNewPlayer and ordinary
game-mode START stone breaking, not FakePlayer mining. Seed constructs the
native held stack once; native logout remove saves inventory before clean
`save-all flush` and stop. Continue uses the same UUID and same world without
reseed or fixture NBT loading. Both stop only after completed native saves.
Typed disk data binds UUID `914adf94-5147-49a3-bf78-ff21cd948719`, DataVersion
3465, survival, one count-one slot-zero tool, custom name, efficiency II and
unrelated fixture note. Actual inventory structures differ only by Damage.

The native target/neighbor cells and loot are constructed and restored in each
stage: persisted mined terrain/loot is NOT this observation. Native logout
save occurs before stop: online-first-save-at-stop is NOT established. This
is not crash recovery, real packet/client join, acquisition, arbitrary metadata
or performance proof. Logs retain 2073/2430 ms timing overruns and one raw
terminal warning per stdout in addition to bracketed counts. All variables of
the historical environment were not independently captured.

## Data, assets and provenance

Seven new/generated payload hashes and the pending provenance digest verify.
The new original 16x16 bitmap is mechanically distinct from pinned official
assets; this is not human visual or origin approval. The MIT-derived legacy
recipe retains its source path, 666-byte hash and pinned original repository
commit c5cd5af6. Exactly its first-match plan rule is IMPORTED; all other
effective asset handling and ledger units are unchanged.

Actual non-shallow pinned upstream `git log --follow` /name-status/source reads
identify the JSON addition at `12d238cb2a883533be5b3dabb8c5b7fb3297a99e`.
`recipe-history-01` retains commands, bytes and hashes. The earlier missing
touch-history step is annotated, not credited as pre-authoring review.
Pending digest is `405f659a116d4292bc7cb8706e075b8243055d8cb7e9badeab19dbf3b4110b34`.
Human asset review remains pending; no ledger unit changes to delivered.

## Failed observations, cleanup and limits

Guessed paths, wildcard reads, unavailable API browsing, the first asset-rule
helper's wrong manifest key, and native-03 log-path failure are not successful
checks. Relevant retained scripts/raw failures are kept; exploratory calls
without individual UTC receipts are not assigned invented times. The independent
source-03 additive seal correction and packaged review's failed library-count
audit belong to their separate immutable reports, not new production failures.

Root cleanup and compact seal are recorded separately after all runtime readers
release their interests. Only Root-created ended disposable outputs may be
removed; denied peer cleanup targets are never retried or taken over. The
manifest covers retained files in this leaf only, excluding disposable caches,
copies/worlds, and nested frozen manifests' own immutable contents remain intact.

Open obligations include native wear-before-removal atomicity limits, unsynced
COMMON client display, above-tier/mod interaction, titanium/steel/motor survival
roots, upgrade/client/V1/V2/soak, human provenance and all Required Gates.
The ledger remains 186 PLANNED /154 REVIEW assets; v1.8 remains IN_PROGRESS.
Actual sleep has only its separately proposed dimension/spawn/time contract;
no sleep policy or implementation change is part of this tool qualification.
No Claude, release tag, Gate approval or full-item parity claim is made.
