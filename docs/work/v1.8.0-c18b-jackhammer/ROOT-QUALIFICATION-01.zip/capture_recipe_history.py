"""Capture original-upstream Git history in an owned bare clone, without assets."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
out = root / "recipe-history-01"
assert not out.exists()
out.mkdir()
repo = root / "tmp" / "upstream-history.git"
assert not repo.exists()
url = "https://github.com/Advanced-Rocketry/AdvancedRocketry.git"
commit = "c5cd5af62fc07cd4e0d24f06a16033f181c47c04"
path = "src/main/resources/assets/advancedrocketry/recipes/jackhammer.json"
records = []
env = dict(os.environ, TEMP=str(root / "tmp"), TMP=str(root / "tmp"))

def run(name, argv, timeout=180):
    record = dict(argv=argv, started_utc=datetime.now(timezone.utc).isoformat())
    with (out / (name + ".stdout")).open("wb") as stdout, (out / (name + ".stderr")).open("wb") as stderr:
        try:
            result = subprocess.run(argv, stdout=stdout, stderr=stderr, env=env, timeout=timeout)
            record["exit"] = result.returncode
        except subprocess.TimeoutExpired:
            record["exit"] = "TIMEOUT"
    record["ended_utc"] = datetime.now(timezone.utc).isoformat()
    record["stdout_sha256"] = hashlib.sha256((out / (name + ".stdout")).read_bytes()).hexdigest()
    record["stderr_sha256"] = hashlib.sha256((out / (name + ".stderr")).read_bytes()).hexdigest()
    records.append(record)
    (out / "COMMANDS.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)
    assert record["exit"] == 0
    return (out / (name + ".stdout")).read_bytes()

run("clone", ["git", "clone", "--bare", "--filter=blob:none", "--single-branch", "--branch", "1.12", url, str(repo)])
run("shallow", ["git", "--git-dir=" + str(repo), "rev-parse", "--is-shallow-repository"])
history = run("history", ["git", "--git-dir=" + str(repo), "log", "--follow", "--format=%H%x09%aI%x09%an%x09%s",
                          commit, "--", path]).decode("utf-8")
run("history-status", ["git", "--git-dir=" + str(repo), "log", "--follow", "--format=commit %H", "--name-status", commit, "--", path])
data = run("source", ["git", "--git-dir=" + str(repo), "show", commit + ":" + path])
assert hashlib.sha256(data).hexdigest() == "a2d717f1afe921977dfced20123272c8ceca26b457b2d52d37d23b9f6e249a45"
rows = [line.split("\t", 3) for line in history.splitlines()]
assert rows and all(len(row) == 4 for row in rows)
record = dict(repository=url, pinned_commit=commit, source_path=path,
              source_sha256=hashlib.sha256(data).hexdigest(), follow_renames=True, history=[
                  dict(commit=sha, authored_at=date, author=author, subject=subject) for sha, date, author, subject in rows])
(out / "HISTORY.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2), flush=True)
