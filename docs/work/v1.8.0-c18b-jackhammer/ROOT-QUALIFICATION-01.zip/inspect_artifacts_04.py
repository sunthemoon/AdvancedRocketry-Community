"""Capture exact committed-source artifacts and current native observations."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parent
repo = Path("D:/GitHub/arce-v180-jackhammer-20261009")
sha = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == sha
artifacts = []
provenance = json.loads((repo / "docs/provenance/v1.8.0-c18b-jackhammer.json").read_text("utf-8"))
for path in [repo / "build/libs/advancedrocketry-community-1.20.1-1.8.0-dev.jar",
             repo / "build/libs/advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar",
             repo / "build/libs/advancedrocketry-community-1.20.1-1.8.0-dev-api.jar",
             repo / "compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar"]:
    raw = path.read_bytes()
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        if path.name.endswith("-dev.jar"):
            assert "io/github/sunthemoon/advancedrocketrycommunity/equipment/tool/JackhammerItem.class" in names
            assert not any("JackhammerContinuationFixture" in name for name in names)
            for entry in provenance["entries"]:
                relative = entry["target_path"].split("src/generated/v1.8/resources/", 1)[1]
                assert hashlib.sha256(archive.read(relative)).hexdigest() == entry["target_sha256"]
            assert "META-INF/LICENSE" in names and "META-INF/NOTICE.md" in names
        if path.name.startswith("arce-adapter"):
            assert "io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.class" in names
            assert not any(name.startswith("io/github/sunthemoon/advancedrocketrycommunity/") for name in names)
        artifacts.append(dict(name=path.name, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), entries=names))
native = (root / "native-04/latest.log").read_text("utf-8")
markers = [line for line in native.splitlines() if re.search(r"GAME TESTS COMPLETE|required tests passed|Running test batch 'jackhammer", line)]
headers = {kind: len(re.findall(r"\[[^\]\r\n]+/" + kind + r"\]", native)) for kind in ["WARN", "ERROR", "FATAL"]}
result = dict(source_sha=sha, utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts,
              native_headers=headers, native_markers=markers,
              main_api_matches_previous_detector=artifacts[2]["sha256"] == "aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b")
(root / "ARTIFACTS-04.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: value if key != "artifacts" else [{k: v for k, v in row.items() if k != "entries"} for row in value]
                  for key, value in result.items()}, indent=2))
