"""Fixed-candidate record/resource checks and the unchanged vanilla art screen."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
checkout = Path("D:/GitHub/arce-v180-jackhammer-20261009")
expected = "61cada9e6042e0149a96a7d97a485bd3996b58db"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip() == expected
out = root / "static-01"
assert not out.exists()
out.mkdir()
records = []
for name, argv in [
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("bootstrap", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py", "--require-approved-review"]),
    ("strict", [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]),
    ("whitespace", ["git", "diff", "--check", "106d31653f8bce66761c919742629a75a047e2ca", expected]),
]:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out / (name + ".log")).open("wb") as log:
        proc = subprocess.run(argv, cwd=checkout, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    records.append(dict(argv=argv, cwd=str(checkout), head=expected, started_utc=started,
                        ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit=proc.returncode,
                        log=name + ".log", log_sha256=hashlib.sha256((out / (name + ".log")).read_bytes()).hexdigest()))
provenance = json.loads((checkout / "docs/provenance/v1.8.0-c18b-jackhammer.json").read_text("utf-8"))
assert provenance["schema_version"] == 2 and len(provenance["entries"]) == 7
assert provenance["review"]["status"] == "PENDING_HUMAN_REVIEW"
core = {key: value for key, value in provenance.items() if key != "review"}
digest = hashlib.sha256((json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()).hexdigest()
assert digest == provenance["review"]["content_digest"]
targets = []
for entry in provenance["entries"]:
    payload = (checkout / entry["target_path"]).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == entry["target_sha256"]
    if entry["status"] == "NEW":
        source = subprocess.check_output(["git", "show", entry["authoring_commit"] + ":" + entry["source_path"]], cwd=checkout)
        assert hashlib.sha256(source).hexdigest() == entry["source_sha256"]
    else:
        source = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/upstream/ar") / entry["source_path"]
        assert hashlib.sha256(source.read_bytes()).hexdigest() == entry["source_sha256"]
    targets.append(dict(path=entry["target_path"], bytes=len(payload), sha256=entry["target_sha256"]))
(out / "PROVENANCE-CHECK.json").write_text(json.dumps(dict(head=expected, review_digest=digest, targets=targets), indent=2) + "\n", encoding="utf-8")
(out / "COMMANDS.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
print(json.dumps(records, indent=2), flush=True)
sys.path.insert(0, str(checkout))
from tools.audit import vanilla_derivation as derivation
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
sources, _, vanilla = derivation.load_vanilla([
    "1.12.2=C:/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/vanilla/client-1.12.2.jar",
    "1.20.1=C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_repo/versions/1.20.1/client.jar"])
target = "src/generated/v1.8/resources/assets/advancedrocketrycommunity/textures/item/jackhammer.png"
width, height, rgba = derivation.decode_rgba((checkout / target).read_bytes())
best = derivation.analyse_images([(target, derivation.Image(width, height, rgba))], vanilla)
_, verdict, record = best.get(target, (None, "CLEAR", {}))
result = dict(head=expected, started_utc=started, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              vanilla=sources, candidate=targets[1] if targets[1]["path"] == target else next(item for item in targets if item["path"] == target),
              verdict=verdict, record=record, unchanged_screen_implementation=True, no_human_approval=True)
(out / "ART-SCREEN.json").write_text(json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2, default=str), flush=True)
sys.exit(0 if verdict == "CLEAR" and all(item["exit"] == 0 for item in records if item["log"] != "strict.log") else 1)
