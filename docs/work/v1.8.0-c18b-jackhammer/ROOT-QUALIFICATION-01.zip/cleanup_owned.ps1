$ErrorActionPreference = 'Stop'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\jackhammer-root-20261009-01'
$checkout = 'D:\GitHub\arce-v180-jackhammer-20261009'
$record = [ordered]@{ started_utc = [DateTime]::UtcNow.ToString('o'); attempt = 1; targets = @(); result = 'NOT_STARTED' }
$targets = @(
    "$checkout\build", "$checkout\run-data", "$checkout\.gradle",
    "$checkout\compat-test-mod\build", "$checkout\compat-test-mod\.gradle",
    "$checkout\logs", "$checkout\scripts\__pycache__",
    "$leaf\tmp", "$leaf\driver-test-tmp", "$leaf\packaged-02\_tmp"
)
try {
    $live = @(Get-CimInstance Win32_Process | Where-Object {
        $_.ProcessId -ne $PID -and $_.CommandLine -and
        ($_.CommandLine.Contains($checkout) -or $_.CommandLine.Contains($leaf))
    } | Select-Object ProcessId, Name, CommandLine)
    $record.process_check = $live
    if ($live.Count -ne 0) { throw 'An active process references the owned checkout/evidence leaf.' }
    foreach ($target in $targets) {
        $full = [IO.Path]::GetFullPath($target)
        if (-not ($full.StartsWith($checkout + '\', [StringComparison]::OrdinalIgnoreCase) -or
                  $full.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase))) {
            throw 'Target is outside the two explicitly owned roots.'
        }
        if (-not (Test-Path -LiteralPath $full)) {
            $record.targets += [ordered]@{ path = $full; exists = $false; files = 0; bytes = 0 }
            continue
        }
        $resolved = (Resolve-Path -LiteralPath $full).Path
        if ($resolved -ne $full) { throw 'Resolved target differs from the checked absolute target.' }
        $items = @(Get-Item -LiteralPath $full) + @(Get-ChildItem -LiteralPath $full -Force -Recurse)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) {
            throw 'Reparse point encountered; no target is deleted.'
        }
        $files = @($items | Where-Object { -not $_.PSIsContainer })
        $bytes = ($files | Measure-Object -Property Length -Sum).Sum
        $record.targets += [ordered]@{ path = $full; exists = $true; files = $files.Count; bytes = [long]$bytes }
    }
    $record.result = 'CHECKS_PASSED'
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$leaf\CLEANUP-BEFORE.json" -Encoding utf8
    foreach ($target in $record.targets) {
        if ($target.exists) {
            Remove-Item -LiteralPath $target.path -Recurse -Force
            if (Test-Path -LiteralPath $target.path) { throw 'Owned target remains after the single removal.' }
        }
    }
    $record.result = 'REMOVED'
} catch {
    $record.result = 'FAILED_NO_RETRY'
    $record.error = $_.Exception.Message
    throw
} finally {
    $record.ended_utc = [DateTime]::UtcNow.ToString('o')
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$leaf\CLEANUP-RESULT.json" -Encoding utf8
}
