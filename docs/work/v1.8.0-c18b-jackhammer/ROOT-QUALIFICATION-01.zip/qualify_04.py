"""Full separate qualification of the committed host-template/history correction."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path("D:/GitHub/arce-v180-jackhammer-20261009")
sha = "3b18a6bc8b58424d647053d6c6f1833ba14d9dc7"
records = []

def command(name, argv, cwd=root):
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    (root / (name + "-launch.log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    record = dict(name=name, argv=[str(arg) for arg in argv], cwd=str(cwd), exit=result.returncode,
                  started_utc=start, ended_utc=datetime.now(timezone.utc).isoformat())
    records.append(record)
    (root / "QUALIFICATION-04.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)

for name, args in [("build-04", ["clean", "build"]), ("test-04", ["test"]),
                   ("data-04a", ["runData"]), ("data-04b", ["runData"]),
                   ("native-04", ["runGameTestServer"]),
                   ("publish-04", ["publishMavenJavaPublicationToLocalProjectRepositoryRepository", "--offline"]),
                   ("consumer-04", ["-p", "compat-test-mod", "clean", "build", "-ParceVersion=1.20.1-1.8.0-dev", "--offline"])]:
    command(name, [sys.executable, root / "run_fixed.py", name, sha, *args])
    if name in ("build-04", "test-04"):
        command("capture-" + name, [sys.executable, root / "capture_junit.py", name])
    if name.startswith("data-"):
        command(name + "-diff", ["git", "diff", "--exit-code"], repo)
        command(name + "-status", ["git", "status", "--short"], repo)
raise SystemExit(1 if any(record["exit"] for record in records) else 0)
