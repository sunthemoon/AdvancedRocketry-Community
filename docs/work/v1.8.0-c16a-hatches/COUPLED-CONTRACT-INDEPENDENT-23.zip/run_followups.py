"""Retain original selector failure and run standard read-only follow-up commands."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

LEAF = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
records = []

def run(argv,log):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
    (LEAF/log).parent.mkdir(parents=True,exist_ok=True)
    (LEAF/log).write_bytes(process.stdout)
    records.append({'argv':argv,'cwd':str(ROOT),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':process.returncode,'log':log,'log_sha256':hashlib.sha256(process.stdout).hexdigest()})
    print(json.dumps(records[-1]),flush=True)

if sys.argv[1] == 'selectors':
    run([sys.executable,'-B',str(LEAF/'inspect_selectors.py')],'selectors-initial.txt')
elif sys.argv[1] == 'selectors-r2':
    run([sys.executable,'-B',str(LEAF/'inspect_selectors_r2.py')],'selectors-r2.txt')
elif sys.argv[1] == 'selectors-r3':
    run([sys.executable,'-B',str(LEAF/'inspect_selectors_r3.py')],'selectors-r3.txt')
elif sys.argv[1] == 'strict':
    run([sys.executable,'-B','scripts/validate_repository.py','--require-approved-identity'],'validation/strict-rerun.txt')
    run(['git','diff','--check'],'validation/whitespace.txt')
(LEAF/('commands-followup-'+sys.argv[1]+'.json')).write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
