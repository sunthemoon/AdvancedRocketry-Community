"""Retain bounded selectors, source hash pins and current draft hygiene."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import urllib.parse

LEAF = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
ROOT_LEAF = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-root-20261008-01')

def sha(data): return hashlib.sha256(data).hexdigest()

manifest = json.loads((LEAF/'input-manifest.json').read_text())
source_pins = []
for row in manifest:
    if row['source'].startswith('git:'):
        data = (LEAF/row['path']).read_bytes()
        source_pins.append({'source':row['source'],'bytes':len(data),'sha256':sha(data),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()})
(LEAF/'source-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n',encoding='utf-8')
excerpts = []
adapter = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/'
for name,start,end in [('ClassicHatchBlockEntity',53,117),('ClassicHatchBlockEntity',143,149),('ClassicHatchBlockEntity',264,288),('ClassicChunkObservation',293,327),('ClassicLoadedWorld',47,58),('ClassicOwnerState',35,47)]:
    path = adapter+name+'.java'
    lines = (LEAF/'source'/path).read_text().splitlines()
    excerpts.append({'git_source':BASE+':'+path,'start':start,'end':end,'lines':lines[start-1:end]})
(LEAF/'source-excerpts.json').write_text(json.dumps(excerpts,indent=2)+'\n',encoding='utf-8')
# Preserve the two failed exploratory Git-show logs before owned-cache cleanup.
for name in ['ClassicObservationCapability','ClassicChunkObservationProvider']:
    path = LEAF/'source'/adapter/(name+'.java')
    target = LEAF/'instrumentation'/('missing-'+name+'.txt')
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(path.read_bytes())
root_pins = []
for path in sorted(ROOT_LEAF.iterdir()):
    if path.is_file() and path.stat().st_size <= 4*1024*1024:
        data = path.read_bytes()
        target = LEAF/'root-inputs'/path.name
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(data)
        root_pins.append({'source':str(path),'snapshot':'root-inputs/'+path.name,'bytes':len(data),'sha256':sha(data)})
(LEAF/'root-input-pins.json').write_text(json.dumps(root_pins,indent=2)+'\n',encoding='utf-8')
native_pins = json.loads((LEAF/'native-identities.json').read_text())
native_matches = []
for row in native_pins:
    original = ROOT_LEAF/Path(row['javap_log']).name
    ours = (LEAF/row['javap_log']).read_bytes()
    native_matches.append({'member':row['member'],'root_log':str(original),'same_javap_bytes':original.read_bytes()==ours})
(LEAF/'native-root-comparison.json').write_text(json.dumps(native_matches,indent=2)+'\n',encoding='utf-8')
checks = []
for name in ['COUPLED-CONTRACT-TASK-23.md','COUPLED-CONTRACT-23.md','COUPLED-VERIFICATION-MATRIX-23.md']:
    relative = 'docs/work/v1.8.0-c16a-hatches/'+name
    data = (LEAF/'inputs'/relative).read_bytes()
    text = data.decode('utf-8',errors='strict')
    checks.append({'file':relative,'utf8':True,'replacement_chars':text.count('\ufffd'),'whitespace_bad_lines':[i for i,line in enumerate(text.splitlines(),1) if line.endswith((' ','\t'))],'snapshot_current_equal':data==(ROOT/relative).read_bytes(),'sha256':sha(data)})
    for line_number,line in enumerate(text.splitlines(),1):
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',line):
            if re.match(r'^[a-z]+://',target): continue
            local = urllib.parse.unquote(target.split('#',1)[0])
            if local:
                exists = ((ROOT/relative).parent/local).exists()
                checks.append({'file':relative,'line':line_number,'link':target,'exists':exists})
(LEAF/'draft-hygiene.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
data=(ROOT/'docs/versions/V1.0.0-COMMUNITY-MVP.md').read_bytes()
(LEAF/'inputs/docs/versions/V1.0.0-COMMUNITY-MVP.md').write_bytes(data)
(LEAF/'extra-governance-pin.json').write_text(json.dumps({'source':str(ROOT/'docs/versions/V1.0.0-COMMUNITY-MVP.md'),'bytes':len(data),'sha256':sha(data)},indent=2)+'\n',encoding='utf-8')
inventory = []
for dirname in ['source','inputs/source']:
    path = (LEAF/dirname).resolve()
    assert path.is_relative_to(LEAF.resolve()) and path != LEAF.resolve()
    files = [{'relative':str(file.relative_to(path)),'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())} for file in sorted(path.rglob('*')) if file.is_file()]
    inventory.append({'resolved':str(path),'owned_by':'this independent review; created by review_checks.py snapshot','files':files,'logical_bytes':sum(row['bytes'] for row in files)})
(LEAF/'cache-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source_pins':len(source_pins),'source_excerpts':len(excerpts),'root_files':len(root_pins),'native_comparison_count':len(native_matches),'native_comparison_same':sum(row['same_javap_bytes'] for row in native_matches),'draft_missing_links':[row for row in checks if row.get('exists') is False],'cache_logical_bytes':sum(row['logical_bytes'] for row in inventory)},indent=2))
