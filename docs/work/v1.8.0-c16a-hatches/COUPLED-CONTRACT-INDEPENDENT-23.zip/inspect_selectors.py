"""Independent bounded selectors of saved javap and pinned source outputs."""
import hashlib
import json
from pathlib import Path
import re

LEAF = Path(__file__).resolve().parent
out = []

def method(filename, header):
    text = (LEAF / filename).read_text(encoding='utf-8')
    parts = re.split(r'(?m)(?=^  (?:public|private|protected|static)[^\n]*\([^\n]*\);\r?$)', text)
    matches = [part for part in parts if part.splitlines()[0].strip() == header]
    if len(matches) != 1:
        raise ValueError((filename,header,len(matches)))
    return matches[0]

def check(name, condition, excerpt=''):
    out.append({'id':name,'passed':bool(condition),'excerpt':excerpt})

def calls(body, suffix):
    return [line.strip() for line in body.splitlines() if suffix in line and re.search(r'\binvoke',line)]

lc = method('native/LevelChunk-javap.txt','public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.world.level.Level, net.minecraft.world.level.ChunkPos, net.minecraft.world.level.chunk.UpgradeData, net.minecraft.world.ticks.LevelChunkTicks<net.minecraft.world.level.block.Block>, net.minecraft.world.ticks.LevelChunkTicks<net.minecraft.world.level.material.Fluid>, long, net.minecraft.world.level.chunk.LevelChunkSection[], net.minecraft.world.level.chunk.LevelChunk$PostLoadProcessor, net.minecraft.world.level.levelgen.blending.BlendingData);')
check('LevelChunk exact carrier', '37: ldc' in lc and '// class net/minecraft/world/level/chunk/LevelChunk' in lc and 'AsField' in lc, '\n'.join(line for line in lc.splitlines() if '37:' in line or 'AsField' in line or '153:' in line))
proto = method('native/LevelChunk-javap.txt','public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.server.level.ServerLevel, net.minecraft.world.level.chunk.ProtoChunk, net.minecraft.world.level.chunk.LevelChunk$PostLoadProcessor);')
check('Proto constructor copy after carrier gathering', '75: invokevirtual' in proto and 'Method setBlockEntity:' in proto and '89: invokevirtual' in proto and 'getBlockEntityNbts' in proto, '\n'.join(line for line in proto.splitlines() if '75:' in line or '89:' in line or 'pendingBlockEntities' in line))
setblock = method('native/LevelChunk-javap.txt','public net.minecraft.world.level.block.state.BlockState setBlockState(net.minecraft.core.BlockPos, net.minecraft.world.level.block.state.BlockState, boolean);')
check('Owned allocation comes after native write', setblock.index('LevelChunkSection.setBlockState') < setblock.index('EntityBlock.newBlockEntity') < setblock.index('addAndRegisterBlockEntity'), '\n'.join(line for line in setblock.splitlines() if 'LevelChunkSection.setBlockState' in line or 'newBlockEntity' in line or 'addAndRegisterBlockEntity' in line))
registration = method('native/LevelChunk-javap.txt','public void addAndRegisterBlockEntity(net.minecraft.world.level.block.entity.BlockEntity);')
check('Fresh direct onLoad follows installation', registration.index('setBlockEntity') < registration.index('BlockEntity.onLoad'), '\n'.join(line for line in registration.splitlines() if 'setBlockEntity' in line or 'isInLevel' in line or 'onLoad' in line))
promote = method('native/ChunkMap-javap.txt','private com.mojang.datafixers.util.Either lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, com.mojang.datafixers.util.Either);')
check('Promotion selects actual Proto constructor', '50: invokespecial' in promote and 'LevelChunk."<init>"' in promote and 'ProtoChunk;' in promote, '\n'.join(line for line in promote.splitlines() if 'ImposterProtoChunk' in line or '50:' in line or 'ChunkEvent$Load' in line or '149:' in line))
check('isNewChunk derives only from ImposterProto exclusion', re.search(r'138: instanceof[^\n]*ImposterProtoChunk',promote) is not None and '149: invokespecial' in promote, '\n'.join(line for line in promote.splitlines() if any(str(pc)+':' in line for pc in [132,135,137,138,141,144,145,148,149])))
read = method('native/ChunkSerializer-javap.txt','public static net.minecraft.world.level.chunk.ProtoChunk read(net.minecraft.server.level.ServerLevel, net.minecraft.world.entity.ai.village.poi.PoiManager, net.minecraft.world.level.ChunkPos, net.minecraft.nbt.CompoundTag);')
check('Disk FULL event precedes Imposter return', read.index('1199: invokespecial') < read.index('1218: invokespecial') and 'ChunkDataEvent$Load' in read, '\n'.join(line for line in read.splitlines() if any(str(pc)+':' in line for pc in [1194,1196,1197,1199,1202,1212,1214,1218,1221])))
check('Disk Proto event uses Proto local', '1403: aload' in read and '1408: invokespecial' in read, '\n'.join(line for line in read.splitlines() if any(str(pc)+':' in line for pc in range(1395,1424))))
unload_parts = re.split(r'(?m)(?=^  (?:public|private|protected|static)[^\n]*\([^\n]*\);\r?$)',(LEAF/'native/ChunkMap-javap.txt').read_text())
unloads = [part for part in unload_parts if 'ChunkEvent$Unload' in part and 'ServerLevel.unload:' in part]
check('Exactly one native unload body found',len(unloads)==1)
unload = unloads[0]
check('Unload event precedes attempted save and native clear', unload.index('IEventBus.post') < unload.index('Method save:') < unload.index('ServerLevel.unload'), '\n'.join(line for line in unload.splitlines() if any(s in line for s in ['IEventBus.post','Method save:','ServerLevel.unload',' 92: pop'])))
check('Unload discards save result', re.search(r'89: invokevirtual[^\n]*Method save:[^\n]*\n\s+92: pop',unload) is not None)
injection = method('native/InjectionInfo-javap.txt','public void postInject();')
check('Mixin hard lower and upper enforcement', all(s in injection for s in ['requiredCallbackCount','maxCallbackCount','InjectionError','if_icmpge','if_icmple']))
for file, header, target in [
    ('native-extra/ServerGamePacketListenerImpl-javap.txt','public void handleUseItemOn(net.minecraft.network.protocol.game.ServerboundUseItemOnPacket);','ServerPlayerGameMode.useItemOn:'),
    ('native-extra/ServerPlayerGameMode-javap.txt','public void tick();','Method destroyBlock:'),
    ('native-extra/ServerPlayerGameMode-javap.txt','private void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);','Method destroyBlock:')]:
    b = method(file,header)
    found = calls(b,target)
    check('Single selected invocation: ' + header,len(found)==1,'\n'.join(found))
place = method('native-extra/BlockItem-javap.txt','public net.minecraft.world.InteractionResult place(net.minecraft.world.item.context.BlockPlaceContext);')
check('Returned placement context drives placeBlock once', len(calls(place,'getPlacementContext:'))==1 and len(calls(place,'placeBlock:'))==1 and place.index('getPlacementContext:') < place.index('placeBlock:'), '\n'.join(line for line in place.splitlines() if any(s in line for s in ['getPlacementContext:','astore_2','placeBlock:'])))
stack = method('native-extra/ItemStack-javap.txt','public net.minecraft.world.InteractionResult useOn(net.minecraft.world.item.context.UseOnContext);')
check('Server ItemStack uses Forge placement wrapper', 'ForgeHooks.onPlaceItemIntoWorld' in stack, '\n'.join(calls(stack,'ForgeHooks.onPlaceItemIntoWorld:')))
for name in ['ClassicChunkObservation','ClassicHatchBlockEntity','ClassicLoadedWorld','GuardTicket']:
    path = LEAF/'source/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter'/ (name+'.java')
    text = path.read_text()
    if name == 'ClassicHatchBlockEntity':
        check('Successful second LOAD is followed by unconditional candidate clear', 'joined = recordCompletedLoad(service);' in text and 'loadJoinCandidate = null; preparingLoad = false;' in text)
        check('Current second LOAD makes availability visible before return', 'if (loadJoinCandidate.pending() == null) { storage.installed(); }' in text)
        check('Current retirement clears completed join', 'void retireAccess() { clearLoadJoin(); storage.retire(); }' in text)
    if name == 'ClassicChunkObservation':
        check('Current save equals origin and exact retained cardinality', 'outgoing.records().equals(selected.scan().records())' in text and 'retained.size() != selected.scan().records().size()' in text)
        check('Current capture only takes actual LevelChunk', 'event.getChunk() instanceof LevelChunk chunk' in text)
    if name == 'ClassicLoadedWorld':
        check('Current installed owner uses ordinary observation', '!ClassicSaveProtection.ownerObservationMatches(level, chunk, owner)' in text)
    if name == 'GuardTicket':
        check('Current ticket acquisition uses installed predicate', '!installed(world, owner)' in text)
(LEAF/'selector-results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(out),'passed':sum(row['passed'] for row in out),'failures':[row['id'] for row in out if not row['passed']]},indent=2))
raise SystemExit(0 if all(row['passed'] for row in out) else 1)
