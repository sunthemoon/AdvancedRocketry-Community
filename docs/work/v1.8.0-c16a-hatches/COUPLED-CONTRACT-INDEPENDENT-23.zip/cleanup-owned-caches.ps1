$ErrorActionPreference = 'Stop'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\hatch-coupled-contract-independent-20261008-01'
$resolvedLeaf = (Resolve-Path -LiteralPath $leaf).Path
$inventory = Get-Content -LiteralPath (Join-Path $leaf 'cache-inventory.json') -Raw | ConvertFrom-Json
$results = @()
try {
    foreach ($entry in $inventory) {
        $target = (Resolve-Path -LiteralPath $entry.resolved).Path
        if (-not $target.StartsWith($resolvedLeaf + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'Owned cache target is outside the review leaf.'
        }
        if ($target -ne (Join-Path $resolvedLeaf 'source') -and $target -ne (Join-Path $resolvedLeaf 'inputs\source')) {
            throw 'Target is not one of the two authorized read caches.'
        }
        $items = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [System.IO.FileAttributes]::ReparsePoint }).Count -gt 0) {
            throw 'Owned cache contains a reparse point.'
        }
        $files = @($items | Where-Object { -not $_.PSIsContainer })
        if ($files.Count -ne $entry.files.Count) { throw 'Owned cache file count changed.' }
        foreach ($file in $files) {
            $relative = $file.FullName.Substring($target.Length + 1)
            $row = @($entry.files | Where-Object { $_.relative -eq $relative })
            if ($row.Count -ne 1 -or $file.Length -ne $row[0].bytes) { throw 'Unexpected owned cache file.' }
            if ((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ne $row[0].sha256) {
                throw 'Owned cache content changed.'
            }
        }
    }
    foreach ($entry in $inventory) {
        $target = (Resolve-Path -LiteralPath $entry.resolved).Path
        Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
        $results += [pscustomobject]@{target=$target; inventoried_logical_bytes=$entry.logical_bytes; result='REMOVED'; exists_after=(Test-Path -LiteralPath $target)}
    }
    [pscustomobject]@{result='SUCCESS';attempts=1;targets=$results;removed_logical_bytes=($results | Measure-Object -Property inventoried_logical_bytes -Sum).Sum;physical_reclaim_measured=$false} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-result.json') -Encoding utf8
    Write-Output 'Owned read-cache cleanup succeeded once.'
} catch {
    [pscustomobject]@{result='FAILED';attempts=1;targets=$results;error=$_.Exception.Message;no_retry=$true;physical_reclaim_measured=$false} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-result.json') -Encoding utf8
    throw
}
