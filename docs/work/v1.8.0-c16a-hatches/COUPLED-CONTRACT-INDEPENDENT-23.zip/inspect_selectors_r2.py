"""Correct only exact native headers in the preserved first instrument."""
from pathlib import Path

path = Path(__file__).resolve().parent / 'inspect_selectors.py'
text = path.read_text(encoding='utf-8')
old = 'private com.mojang.datafixers.util.Either lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, com.mojang.datafixers.util.Either);'
new = 'private net.minecraft.world.level.chunk.ChunkAccess lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, net.minecraft.world.level.chunk.ChunkAccess);'
assert text.count(old) == 1
text = text.replace(old,new)
old = 'private void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);'
new = 'public void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);'
assert text.count(old) == 1
text = text.replace(old,new)
exec(compile(text,str(path)+' [r2 exact-header correction]','exec'))
