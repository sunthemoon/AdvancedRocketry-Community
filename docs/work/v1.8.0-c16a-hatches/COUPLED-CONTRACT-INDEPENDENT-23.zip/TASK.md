# Independent contract and primary-fact review

You are a delegated read-only Codex reviewer, not the author or root agent.
Do not use the Nekomata persona. Do not delegate or call Claude/OpenPet.

Checkout: D:/GitHub/AdvancedRocketry-Community.
Base Git object: a01703366c51a0e06788b95a1793b312dfa8a9a4.
Root task: docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-TASK-23.md.
Draft inputs: COUPLED-CONTRACT-23.md and COUPLED-VERIFICATION-MATRIX-23.md in
the same folder, and only the new task23 section of the implementation log.
New primary-fact input leaf:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-root-20261008-01.

Read applicable AGENTS and its mandated governance/current-version documents,
source/licensing governance, ADR068 and relevant prior private/qualification
records. Inspect the actual complete new draft against fixed actual source and
pinned native inputs; verify claims and check the useful whole's boundaries,
state transitions and evidence attribution. Assess technical readiness and
remaining acceptance dependencies from evidence. Evaluate rather than assume
the candidate design. Findings first, ordered by severity with precise refs.

Permissions: read only repository, other worktrees, input leaf, local named
Forge47.4.10 mapped JAR and bundled Mixin0.8.5 JAR. Do not change Git HEAD/index,
source/build/docs/configuration, inherited files, root input or old evidence.
Only write this independent external leaf: TASK, REPORT, own scripts, bounded
logs, fixed input snapshots and evidence manifests. No full source ZIP/tree.
Allowed commands: read-only git show/diff/status/worktree/log/hash-object;
rg, Get-Content/Get-FileHash; Python read/shape/hash/static checks; explicit
C:/Program Files/Java/jdk-17.0.7/bin/javap.exe on <=512KiB named members.
No Gradle build/native game/dependency install/transform/server, cache mutation,
cleanup, deployment, commit or push. Existing repository read-only validators
may run if needed, with no edits. Primary official documentation browsing is
allowed for relevant version-sensitive API behavior.

Rerun key static/native selectors independently, record exact argv/exits/member
hashes/source pins, and preserve any failures. Distinguish checks of draft
consistency from proof of an unimplemented runtime. There is no prescribed
finding count, severity, verdict or expected phrase. Root can address findings
only after your input snapshot/report is retained.

Final output: REPORT.md in this leaf with findings, reviewed input hashes,
actual commands/results, proof limits and scope/HEAD release. Final chat should
give a concise result and REPORT absolute path. Confirm no repository writes.

## Root amendment: owned reproducible read-cache cleanup only

Source: Root's direct collaboration message on 2026-10-08 during this review.
This is a task-file amendment, not a maintainer policy/ADR/Gate decision.
Root explicitly permits one native PowerShell cleanup attempt for only the two
newly created reviewer caches in this independent leaf: source/ and
inputs/source/. First retain fixed Git path/blob/content hashes, bounded source
excerpts and all failed command logs. Resolve and verify both absolute targets
inside this leaf and verify their contents belong to this review. No shell
composition, inherited targets, retries or bypass after denial are permitted.
Record exact inventoried logical bytes removed/retained and command result.
All other no-cleanup boundaries remain. These caches are excluded from the
sealed evidence payload regardless of cleanup outcome; no full-leaf recursive
source ZIP is permitted.
