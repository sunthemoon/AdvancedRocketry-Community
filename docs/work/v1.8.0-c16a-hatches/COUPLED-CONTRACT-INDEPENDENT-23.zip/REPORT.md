# Independent review: coupled empty-hatch candidate 23

Date: 2026-10-08. Reviewer: delegated independent Codex, read-only.
Fixed source: `a01703366c51a0e06788b95a1793b312dfa8a9a4`.
Reviewed draft: original complete candidate and matrix, not a runtime implementation.

## Findings, ordered by severity

### M1 - Normal LOAD-candidate cleanup is not distinguished from receipt invalidation

[COUPLED-CONTRACT-23.md:154-160](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L154)
states that candidate clearing invalidates publication while retaining the
existing preparation/reentrancy shape. At the fixed source,
[ClassicHatchBlockEntity.java:97-101](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicHatchBlockEntity.java#L97)
unconditionally clears `loadJoinCandidate` in `finally`, including a successful
second LOAD. That cleanup precedes the outer native return and POSTCHECK.
Consequently, interpreting the draft's candidate-clearing condition as this
actual candidate invalidates every normally completed provisional birth before
terminal publication. Interpreting it as another, operation-owned candidate
instead requires a currently unstated transfer and invalidation boundary.

Specify the exact temporary `LoadJoinCandidate` to operation-owned completed
receipt transfer. Distinguish successful temporary cleanup from withdrawal of
that completed receipt; retirement, replacement, changed checkpoint/encoding
and explicit receipt invalidation must still prevent publication. Include a
positive terminal case after the normal `prepareLoaded` finally and negative
cases for actual receipt invalidation. This is a Medium contract/assignment
ambiguity, not an observed product regression. Bounded fixed-source excerpts
and independently executed selectors retain the normal-clear fact.

### M2 - Placement's unselected, already-delegating state is missing from the state model

[COUPLED-CONTRACT-23.md:69-78](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L69)
gives IDLE no active operation, PREPARED a selected target, and NATIVE the
original exactly-once delegation. However,
[the placement seam at lines 105-110](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L105)
begins PREPARED only inside owned `placeBlock`, which is reached after the
outer redirect has already delegated `ServerPlayerGameMode.useItemOn` and
passed earlier native priority/callback decisions. The actual state between
that delegation and target selection is neither IDLE nor PREPARED. Removal,
which can select before delegating `destroyBlock`, has different ordering.

Specify separate Level-invocation and selected-cell transitions, or add an
explicit unselected in-flight state with no LOAD/save/resource permission.
The outer native call must start exactly once before placement selection;
the inherited `placeBlock` write is a separate inner mutation boundary, not
a second delegation of the outer call. State how no-selection return/throw,
nested entry before selection, and later successful selection terminate.
Do not solve this by precomputing another placement context. This is a Medium
finite-state/assignment ambiguity; the pinned native call flow establishes the
ordering, not execution of the proposed handler.

### L1 - The named native placement-context method does not exist at the pin

[COUPLED-CONTRACT-23.md:106-107](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L106)
names native `getPlacementContext`. The inspected Forge47.4.10 mapped
`BlockItem.place(BlockPlaceContext)` instead invokes
`updatePlacementContext(BlockPlaceContext)` at BCI 34, stores the returned
context in local 2 at BCI 37, and passes that same local to `placeBlock` at
BCI 63. No `getPlacementContext` member is present. Correct the name/descriptor
without changing the good requirement to use the actual returned context.
The predecessor placement-facts wording has the same nomenclature problem;
this review does not authorize rewriting that old record. The native member is
19,126 bytes, SHA-256
`2b3e1defc87df357543458f44516b32b7519bb42746690fc24cee8ba6db4defc`.

## Assessment and remaining dependencies

The candidate is useful as a whole research/design record, but it is not frozen
or ready for physical source assignment. The two prior Medium assignment
prerequisites remain open, consistently with the draft's declaration. No
Critical or High introduced defect is demonstrated by this contract-only
review; absence of runtime execution is not proof that none can exist.

The authentic invocation/allocation grammar is still a proposed mechanism,
not authentication proved by qualification 22. Its raw frames and shared
context cannot independently authorize an operation. Actual native source
confirms the returned pre-write context seam and allocation after the section
write; it does not qualify the new owned allocation receipt or its interaction
with `setLevel`, initial `onLoad` retirement and replacement callbacks.

The two-LOAD/provisional-availability branch has concrete named edit sites,
but remains unimplemented. The old installed predicate requires raw origin,
the current second LOAD calls `storage.installed()`, and the current save
comparison uses origin plus exact retained cardinality. None of those existing
methods already implements the proposed new receipt/expectation transition.
The terminal tail must validate only captured/local identities: existing
`storage.installed()` includes `owner.isRemoved()`, so it is not itself the
specified native-getter-free publication primitive. Specify/test the replacement
private local tail; do not count a prose prohibition as a verified tail.

The candidate correctly keeps both early owner serialization and late chunk
inspection under the same qualified operation, preserves sticky precedence,
and keeps transient deferral outside the ordinary denial-conversion catch.
It does not claim unchanged resource codecs are safe post-removal witnesses.
That distinction is necessary: the current LOAD/gameplay guard becomes invalid
on removal, while raw retained emission has different lifetime semantics.

Authentic disk-Proto to FULL transfer and generated completed origin remain
technical prerequisites. The inspected event carrier/new-flag/constructor
facts substantiate the draft's cautions; they do not establish a transfer.
The three selected wrappers do not supply the missing predecessor. Ordinary
unload proves an attempted save before native BE clearing, not save success,
last writer, shutdown ordering, provider survival or durable flush.

O1/O2/O3, ADR-068 final review/adoption and R-021 impact/recovery disposition
remain necessary and unadopted. Exact source/tool/drop seams and numeric
shape/work/count/capability limits remain unspecified. Chunk/player/drop
cross-store durability cannot be inferred from a held synchronous operation.
The full generated/disk-Proto/FULL and ordinary tool/source scope must not be
replaced by observed-FULL, bare-hand or metadata-free subsets.

Before freezing/assigning the whole useful successor, resolve those technical
bindings and owner policies. After authorized inactive implementation, actual
transformed/package/player/fault/stop/restart tests are still needed before
activation. Matrix P1-P23 are unexecuted requirements, not achieved results;
adding an explicit assignment-versus-activation phase per row would make that
ordering clearer. No v1.8 G0-G9 approval follows from this review.

## Reviewed inputs and pins

| Input | SHA-256 |
| --- | --- |
| Complete original candidate | `ce353fb442edd2610d01a730127c41345f10e9fa6b8b9736df3831685ff91159` |
| Complete original matrix | `d5a79dee8bd87e1eed8cacded1a9aec5b3b2909adf298ca343637c502e441323` |
| Root task23 | `ec6bdd8c9b67324aa54bf8d442813179de9ca52791f11775a4fc2483a8924f40` |
| Initial new task23 implementation-log diff | `56d80eb1a322099ea69db3ee710f2413b0f1bdd59f70576d4351b648428b9506` |
| Mapped Forge47.4.10 archive | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Bundled Mixin0.8.5 archive | `ca15a907e4d1f6b38cefed51d7df96a83347dcfb0bc8ced53111519e991d887d` |

`input-manifest.json` retains governance/private/qualification input hashes and
initial snapshot identities. `source-pins.json` retains 13 fixed Git source
path/blob/content hashes; `extra-source-pins-excerpts.json` adds three named
source pins with bounded excerpts. Source files are reproducible at BASE, not
included as complete evidence files. `native-identities.json` and
`native-extra-identities.json` retain every inspected member's byte size/hash.
`root-input-pins.json` retains the received primary-input hashes and original
Root selector failures/corrections without replacing them with our results.

Final 30 named input/archive pins have 29 unchanged entries. The only changed
entry is Root's concurrently edited `docs/status/CURRENT_VERSION.md`; its
before/after hashes and Root-owned current-state diffs are retained. Candidate,
matrix, task, fixed source and both JAR identities remain unchanged. This is
not reported as zero total working-tree drift or a reviewer write.

## Actual commands and results

Exact argv, exits and timestamps are in `commands-*.json`, `final-pins.json`
and the retained logs. All command working directories are the named checkout.

| Check actually executed | Result |
| --- | --- |
| Read-only Git status/branch/HEAD/worktree/diff and 16 named fixed-source `git show` reads | Successful fixed reads; two exploratory nonexistent source-name probes exit 128 and are separately preserved. |
| Explicit `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -p -c -s -classpath <pinned JAR> <named class>` | All 18 invocations exit 0; every member below 512 KiB. |
| Eleven primary Root versus independent javap outputs | All 11 byte-identical. |
| Independent selector first instrument | Exit 1: wrong exact generic/header selection; original script/trace retained. |
| Exact-header corrected selector | Exit 1: 22/24 checks; wrong unload BCI and nonexistent `getPlacementContext` selector retained. |
| Further fact-corrected selector | Exit 0: 24/24 static/native/source selectors; no assertion removed or runtime proof inferred. |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | Exit 0; 653 units, 186 PLANNED / 154 REVIEW assets. |
| `python -B scripts/validate_bootstrap_provenance.py` | Exit 0; accepted bootstrap provenance mechanically valid. |
| First strict-validator launcher | Instrumentation timeout after its arbitrary 180 seconds; no validator verdict captured; timeout preserved. |
| Unchanged `python -B scripts/validate_repository.py --require-approved-identity`, standard follow-up without that launcher watchdog | Exit 1 in about 296 seconds; 44 PASS / one inherited broken-link check; 256 displayed targets, none in task23. No Gate PASS. |
| `git diff --check` | Exit 0; empty output. |
| New draft UTF-8, whitespace, local Markdown links and initial/current byte equality | Three draft/task files valid UTF-8, zero replacement characters/trailing-space lines; all seven new local links resolve; draft bytes unchanged. |
| Authorized single native PowerShell owned-cache cleanup | Exit 0; 269,521 inventoried logical bytes removed from exactly two owned caches; no physical-space gain measured. |

Native control flow independently confirms the LevelChunk carrier, FULL event
before Imposter wrapping, actual Proto event, constructor copying after carrier
initialization, isNewChunk's Imposter test, fresh direct onLoad, ordinary unload
save-result discard and Mixin hard lower/upper injection checks. The three
selected invocation counts remain exactly one each. These are pinned static
facts, not tests of transformed production classes or the proposed operation.

Official primary cross-checks were browsed on 2026-10-08. Mixin's receiver-aware
handler signature and hard `require`/`allow` versus debug-only `expect` semantics
agree with the selected dependency candidate. [Mixin0.8.5 Redirect](https://raw.githubusercontent.com/SpongePowered/Mixin/0.8.5/src/main/java/org/spongepowered/asm/mixin/injection/Redirect.java)
The refmap/mapping discussion is background, not coverage evidence.
[Mixin obfuscation documentation](https://github.com/SpongePowered/Mixin/wiki/Introduction-to-Mixins---Obfuscation-and-Mixins)
Java17 StackFrame exposes metadata, not receiver/locals; its API does not make
the proposed frame grammar an installed authentication mechanism.
[Java17 StackFrame](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.StackFrame.html)

## Proof limits, changes, cleanup and release

No Gradle build/test/DataGen/GameTest, dependency installation, game/native
server, transform, player, restart, S2, V1/V2, performance or release rebuild
was run. These are NOT_RUN, not NOT_APPLICABLE. Qualifications 21/22 are prior
regressions only; their 548/551 native counts and 2,179 JUnit counts are not
rebound to this candidate or this review. No runtime test was added/modified.

Only this external independent leaf contains reviewer-created TASK amendment,
REPORT, scripts, snapshots, bounded logs, excerpts, manifests and results. No
repository file, index, HEAD, other worktree, Root-input file, old evidence,
saved player data or global dependency cache was changed. No Claude, subagent or OpenPet call was
made. Root coordinates progress outside this delegated read-only scope.

Under the explicitly recorded Root TASK amendment, one native PowerShell
attempt checks absolute descendant targets, exact authorized names, every
owned inventory file/hash and absence of reparse points before removal.
`source/` (134,956 bytes) and `inputs/source/` (134,565 bytes) are removed;
no reproducible source read cache remains. Their failed-name logs are separately
retained, and source hashes/excerpts remain. Both folders are excluded from the
sealed payload regardless of the cleanup result; no full source tree/ZIP,
world/server/build copy or inherited cleanup target is included.

Required Gates: none are granted by this task; current v1.8 G0-G9 and both
physical assignment prerequisites remain open. Recommended next action is
correct M1/M2/L1 in a new reviewed draft, then continue the current v1.8 coupled
binding/policy prerequisites rather than assigning an unused helper.

All owned commands have ended. Final HEAD remains
`a01703366c51a0e06788b95a1793b312dfa8a9a4`. This reviewer releases all repository,
HEAD, draft and native-input read interests; Root may proceed with scoped
documentation revisions/commit after retaining this original report and inputs.
