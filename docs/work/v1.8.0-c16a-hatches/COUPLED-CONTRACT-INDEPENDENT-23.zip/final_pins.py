"""Record final read-only pins and bounded additional source identities."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
sha=lambda data:hashlib.sha256(data).hexdigest()
records=[]
for argv,log in [(['git','rev-parse','HEAD'],'final-head.txt'),(['git','status','--short'],'final-status.txt'),(['git','diff','--','docs/status/COMPLETION-PLAN.md','docs/status/CURRENT_VERSION.md','docs/work/v1.8.0-implementation-log.md'],'root-concurrent-doc-diff.txt')]:
    p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
    (LEAF/log).write_bytes(p.stdout)
    records.append({'argv':argv,'exit_code':p.returncode,'log':log,'sha256':sha(p.stdout)})
pins=[]
for row in json.loads((LEAF/'input-manifest.json').read_text()):
    src=row['source']
    if src.startswith(str(ROOT)) and Path(src).is_file():
        current=Path(src).read_bytes()
        pins.append({'source':src,'initial_sha256':row['sha256'],'final_sha256':sha(current),'unchanged':sha(current)==row['sha256']})
for row in json.loads((LEAF/'native-identities.json').read_text())+json.loads((LEAF/'native-extra-identities.json').read_text()):
    path=Path(row['jar'])
    if any(p.get('source')==str(path) for p in pins):continue
    current=sha(path.read_bytes())
    pins.append({'source':str(path),'initial_sha256':row['jar_sha256'],'final_sha256':current,'unchanged':current==row['jar_sha256']})
extra=[]
for name,ranges in [('ClassicFamilyService',[(18,46),(196,230)]),('ClassicLevelServices',[(31,49)]),('ClassicRawPermit',[(33,58)])]:
    path='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/'+name+'.java'
    argv=['git','show',BASE+':'+path]
    p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    records.append({'argv':argv,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode()})
    lines=p.stdout.decode().splitlines()
    extra.append({'source':'git:'+BASE+':'+path,'bytes':len(p.stdout),'sha256':sha(p.stdout),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(p.stdout)).encode()+b'\0'+p.stdout).hexdigest(),'excerpts':[{'start':a,'end':b,'lines':lines[a-1:b]} for a,b in ranges]})
(LEAF/'extra-source-pins-excerpts.json').write_text(json.dumps(extra,indent=2)+'\n',encoding='utf-8')
summary={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pins':pins,'changed':[p for p in pins if not p['unchanged']],'commands':records,'scope':'Repository reads only. Concurrent Root-owned state/docs updates are not reviewer writes.'}
(LEAF/'final-pins.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checked':len(pins),'changed':summary['changed'],'extra_source_count':len(extra)},indent=2))
