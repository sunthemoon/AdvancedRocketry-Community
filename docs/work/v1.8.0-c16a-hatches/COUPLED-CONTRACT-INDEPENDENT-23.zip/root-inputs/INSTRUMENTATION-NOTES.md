# Task23 instrumentation observations

Date: 2026-10-08. These observations describe inspection tooling, not product
regressions, readiness or a change to the candidate's runtime proof limits.

The first primary selector chose the first scheduleUnload lambda, which is the
exception-reporting helper rather than the actual native save/unload body.
It exits1 with ValueError; the script and captured rerun output are retained.
Revision2 names the actual $14 method, then incorrectly selects LevelChunk's
short delegating constructor by a broad prefix: 22 selectors pass, 2 fail.
Revision3 names the extended primary constructor; identical factual checks pass
24/24. No fact assertion or native source is weakened to obtain that result.
Both failed predecessors remain in the payload. The combined run-checks process
returns nonzero when its required revision2 check fails; revision3 is a separate
actual execution/receipt, not a retroactive replacement of that process result.

The file check-r2.patch is a Python patch-generation helper, not a patch: an
initial PowerShell pipe saved the helper text rather than executing it. It was
then explicitly executed with Python, and its output was applied with apply_patch.
This naming/instrumentation mistake is retained without any runtime effect.

Exploratory reads used nonexistent ClassicFamilyAccess.java,
PHYSICAL-OPERATIONS-OWNER-DECISIONS.md, ClassicChunkMetadata.java and
validate_classic_content_ledger.py names. Actual paths were discovered with rg;
the real bodies/owner decision/metadata reader/ledger validator were then read
or executed. Early attempts to read strict.txt before the running validator
finished also report missing files. None of these exploratory errors authorizes
inventing source behavior or changing files outside the declared task scope.

OpenPet thinking/reviewing attempts encounter WinError10061 at the local runtime.
No pet configuration/data is changed. This safe failure does not stop repository
inspection; it is not a build, native game or release Gate failure.
