import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
checks = []


def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})


def method(filename, signature):
    text = (ROOT / filename).read_text(encoding='utf-8')
    start = text.index('  ' + signature)
    rest = text[start:]
    match = re.search(r'\n  (?:public|private|protected|static) ', rest[1:])
    return rest if match is None else rest[:match.start() + 1]


primary_ctor = method('LevelChunk-javap.txt', 'public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.world.level.Level,')
check('LevelChunk carrier type literal', '37: ldc' in primary_ctor and '// class net/minecraft/world/level/chunk/LevelChunk' in primary_ctor)
check('carrier initialized in primary constructor', '153: invokevirtual' in primary_ctor and '.initInternal:()V' in primary_ctor)
proto_ctor = method('LevelChunk-javap.txt', 'public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.server.level.ServerLevel, net.minecraft.world.level.chunk.ProtoChunk,')
check('Proto ctor later copies live owners', '75: invokevirtual' in proto_ctor and '// Method setBlockEntity:' in proto_ctor)
check('Proto ctor later copies pending owners', 'ProtoChunk.getBlockEntityNbts:' in proto_ctor and '89: invokeinterface' in proto_ctor)
reader = method('ChunkSerializer-javap.txt', 'public static net.minecraft.world.level.chunk.ProtoChunk read(')
check('two native data load events', reader.count('// class net/minecraftforge/event/level/ChunkDataEvent$Load') == 2)
check('FULL load event precedes wrapping', reader.index('1199: invokespecial') < reader.index('1218: invokespecial'))
check('Proto branch posts its load event', '1408: invokespecial' in reader and '1411: invokeinterface' in reader)
promotion = method('ChunkMap-javap.txt', 'private net.minecraft.world.level.chunk.ChunkAccess lambda$protoChunkToFullChunk$34(')
check('promotion actual Proto local', 'checkcast' in promotion and '// class net/minecraft/world/level/chunk/ProtoChunk' in promotion)
check('promotion constructs FULL from Proto', '50: invokespecial' in promotion and 'LevelChunk$PostLoadProcessor;)V' in promotion)
check('new flag is NOT Imposter predicate', '138: instanceof' in promotion and '144: iconst_1' in promotion and '148: iconst_0' in promotion)
check('bulk registration before Load event', promotion.index('115: invokevirtual') < promotion.index('149: invokespecial'))
unload_text = (ROOT / 'ChunkMap-javap.txt').read_text()
unload_sig = next(line.strip() for line in unload_text.splitlines() if line.startswith('  private ') and 'lambda$scheduleUnload$' in line)
unload = method('ChunkMap-javap.txt', unload_sig)
check('ordinary unload event before save', unload.index('ChunkEvent$Unload."<init>"') < unload.index('// Method save:'))
check('save boolean ignored before native unload', '79: pop' in unload and unload.index('// Method save:') < unload.index('ServerLevel.unload:'))
level_unload = method('ServerLevel-javap.txt', 'public void unload(net.minecraft.world.level.chunk.LevelChunk);')
check('ServerLevel unload clears then unregisters', level_unload.index('clearAllBlockEntities:') < level_unload.index('unregisterTickContainerFromLevel:'))
check('ServerLevel unload no direct cap invalidation', 'invalidateCaps' not in level_unload)
state = method('LevelChunk-javap.txt', 'public net.minecraft.world.level.block.state.BlockState setBlockState(')
check('native allocation before owned install', state.index('443: invokeinterface') < state.index('458: invokevirtual'))
injection = (ROOT / 'InjectionInfo-javap.txt').read_text()
check('Mixin required and max count fields', 'requiredCallbackCount:I' in injection and 'maxCallbackCount:I' in injection)
check('Mixin below/above count errors exist', 'succeeded. Scanned %d target(s)' in injection and 'succeeded of %d allowed' in injection)
source_files = ['ClassicChunkObservation', 'ClassicSaveProtection', 'ClassicLoadedWorld',
                'ClassicHatchBlockEntity', 'ClassicOwnerState', 'GuardTicket', 'ClassicAccessCoordinator']
pins = []
sources = {}
prefix = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/'
for name in source_files:
    filename = prefix + name + '.java'
    obj = subprocess.check_output(['git', 'show', BASE + ':' + filename], cwd=REPO)
    pins.append({'path': filename, 'base': BASE, 'sha256': hashlib.sha256(obj).hexdigest(),
                 'working_matches': obj == (REPO / filename).read_bytes()})
    sources[name] = obj.decode('utf-8')
check('private source bytes unchanged from base', all(row['working_matches'] for row in pins))
check('current observation captures LevelChunk only', 'event.getChunk() instanceof LevelChunk' in sources['ClassicChunkObservation'])
check('current installed requires raw observation', 'ClassicSaveProtection.ownerObservationMatches' in sources['ClassicLoadedWorld'])
check('current second LOAD still publishes installed', 'recordCompletedLoad' in sources['ClassicHatchBlockEntity'] and 'storage.installed()' in sources['ClassicHatchBlockEntity'])
check('current early serialization inherits before its guarded work', 'super.saveAdditional(tag)' in sources['ClassicHatchBlockEntity'])
check('current Proto save branch has no transfer', 'No Proto-to-FULL owner promotion or observation transfer' in sources['ClassicSaveProtection'])
result = {'checks': checks, 'passed': sum(row['passed'] for row in checks),
          'failed': sum(not row['passed'] for row in checks), 'source_pins': pins,
          'scope': 'Static selectors only; no runtime, transform, lifecycle or candidate correctness proof.'}
(ROOT / 'primary-checks.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
raise SystemExit(bool(result['failed']))
