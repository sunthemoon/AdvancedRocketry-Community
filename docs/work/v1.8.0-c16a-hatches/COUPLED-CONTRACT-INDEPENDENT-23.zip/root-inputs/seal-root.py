import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
DEST = pathlib.Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-ROOT-23.zip')
assert (ROOT / 'REPORT.md').is_file()
assert not DEST.exists()
assert not (ROOT / 'SHA256SUMS.txt').exists()
paths = sorted(path for path in ROOT.rglob('*') if path.is_file())
rows = []
for path in paths:
    name = path.relative_to(ROOT).as_posix()
    assert path.stat().st_size < 50 * 1024 * 1024
    rows.append({'path': name, 'bytes': path.stat().st_size,
                 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
assert sum(row['bytes'] for row in rows) < 100 * 1024 * 1024
(ROOT / 'FILE-MANIFEST.json').write_text(json.dumps({'payloads': rows,
    'payload_count': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows)}, indent=2) + '\n', encoding='utf-8')
hashes = rows + [{'path': 'FILE-MANIFEST.json',
    'sha256': hashlib.sha256((ROOT / 'FILE-MANIFEST.json').read_bytes()).hexdigest()}]
(ROOT / 'SHA256SUMS.txt').write_text(''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in hashes), encoding='ascii')
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(path for path in ROOT.rglob('*') if path.is_file()):
        archive.write(path, path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for row in hashes:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
print(json.dumps({'archive': str(DEST), 'bytes': DEST.stat().st_size,
    'sha256': hashlib.sha256(DEST.read_bytes()).hexdigest(),
    'payloads': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows),
    'report_sha256': hashlib.sha256((ROOT / 'REPORT.md').read_bytes()).hexdigest()}))
