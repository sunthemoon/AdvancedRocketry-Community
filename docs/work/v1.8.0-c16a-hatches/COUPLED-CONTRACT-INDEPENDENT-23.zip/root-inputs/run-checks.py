import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
COMMANDS = [('primary-original-failure', [sys.executable, '-B', str(ROOT / 'check-primary.py')]),
            ('primary-r2', [sys.executable, '-B', str(ROOT / 'check-primary-r2.py')]),
            ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py']),
            ('provenance', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py']),
            ('strict', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
            ('diff-check', ['git', 'diff', '--check'])]
rows = []
for label, argv in COMMANDS:
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(argv, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = ROOT / (label + '.txt')
    assert not log.exists()
    log.write_bytes(proc.stdout)
    row = {'label': label, 'argv': argv, 'cwd': str(REPO), 'started_utc': start,
           'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exit_code': proc.returncode, 'log': log.name, 'bytes': len(proc.stdout),
           'sha256': hashlib.sha256(proc.stdout).hexdigest()}
    rows.append(row)
    print(json.dumps(row))
    if label in ('primary-r2', 'ledger', 'provenance'):
        print(proc.stdout.decode('utf-8', errors='replace'))
(ROOT / 'check-commands.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
raise SystemExit(any(row['exit_code'] != (1 if row['label'] in ('primary-original-failure', 'strict') else 0) for row in rows))
