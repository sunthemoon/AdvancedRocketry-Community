import datetime
import hashlib
import json
import pathlib
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
NATIVE = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
MIXIN = pathlib.Path('C:/Users/Administrator/.gradle/caches/modules-2/files-2.1/org.spongepowered/mixin/0.8.5/9d1c0c3a304ae6697ecd477218fa61b850bf57fc/mixin-0.8.5.jar')
JAVAP = pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
INPUTS = [(NATIVE, 'net.minecraft.server.level.ServerLevel'),
          (MIXIN, 'org.spongepowered.asm.mixin.injection.Redirect'),
          (MIXIN, 'org.spongepowered.asm.mixin.injection.struct.InjectionInfo')]
results = []
for jar, name in INPUTS:
    with zipfile.ZipFile(jar) as archive:
        entry = archive.getinfo(name.replace('.', '/') + '.class')
        assert entry.file_size <= 512 * 1024
        member = archive.read(entry)
    argv = [str(JAVAP), '-p', '-c', '-s', '-classpath', str(jar), name]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = ROOT / (name.rsplit('.', 1)[1] + '-javap.txt')
    assert not output.exists()
    output.write_bytes(proc.stdout)
    results.append({'jar': str(jar), 'jar_sha256': hashlib.sha256(jar.read_bytes()).hexdigest(),
        'member': entry.filename, 'bytes': len(member), 'sha256': hashlib.sha256(member).hexdigest(),
        'argv': argv, 'started_utc': start, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exit_code': proc.returncode, 'log': output.name,
        'log_sha256': hashlib.sha256(proc.stdout).hexdigest()})
    assert proc.returncode == 0
(ROOT / 'extra-identities-commands.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results, indent=2))
