import datetime
import hashlib
import json
import pathlib
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
JAR = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP = pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
TYPES = [
    'net.minecraft.world.level.chunk.ChunkAccess',
    'net.minecraft.world.level.chunk.LevelChunk',
    'net.minecraft.world.level.chunk.ProtoChunk',
    'net.minecraft.world.level.chunk.ImposterProtoChunk',
    'net.minecraft.world.level.chunk.storage.ChunkSerializer',
    'net.minecraft.server.level.ChunkMap',
    'net.minecraftforge.event.level.ChunkEvent$Load',
    'net.minecraftforge.event.level.ChunkDataEvent$Load',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert sha(JAR.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
identities = []
commands = []
with zipfile.ZipFile(JAR) as archive:
    for type_name in TYPES:
        name = type_name.replace('.', '/') + '.class'
        entry = archive.getinfo(name)
        assert entry.file_size <= 512 * 1024
        member = archive.read(entry)
        identities.append({'class': type_name, 'bytes': len(member), 'sha256': sha(member)})
        argv = [str(JAVAP), '-p', '-c', '-s', '-classpath', str(JAR), type_name]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        process = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logfile = ROOT / (type_name.rsplit('.', 1)[1] + '-javap.txt')
        assert not logfile.exists()
        logfile.write_bytes(process.stdout)
        commands.append({'argv': argv, 'started_utc': start,
                         'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'exit_code': process.returncode, 'bytes': len(process.stdout),
                         'sha256': sha(process.stdout)})
        assert process.returncode == 0, type_name
(ROOT / 'native-identities.json').write_text(json.dumps({'jar': str(JAR), 'bytes': JAR.stat().st_size,
    'sha256': sha(JAR.read_bytes()), 'members': identities}, indent=2) + '\n', encoding='utf-8')
(ROOT / 'native-commands.json').write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'members': identities, 'javap_exits': [row['exit_code'] for row in commands]}, indent=2))
