"""Seal enumerated bounded review payloads, never a recursive full-leaf ZIP."""
import hashlib
import json
from pathlib import Path

LEAF=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
assert not (LEAF/'SHA256SUMS.txt').exists(), 'Evidence is already sealed.'
roots=['inputs','native','native-extra','root-inputs','instrumentation','validation']
payloads=[path for path in LEAF.iterdir() if path.is_file() and path.name not in {'evidence-manifest.json','SHA256SUMS.txt'}]
for root in roots:
    for path in (LEAF/root).rglob('*'):
        if not path.is_file(): continue
        relative=path.relative_to(LEAF).as_posix()
        if relative.startswith('inputs/source/'):continue
        payloads.append(path)
payloads=sorted(set(payloads),key=lambda path:path.relative_to(LEAF).as_posix())
rows=[]
for path in payloads:
    data=path.read_bytes()
    assert len(data)<=50*1024*1024
    name=path.relative_to(LEAF).as_posix()
    assert not name.startswith(('source/','inputs/source/'))
    rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
assert sum(row['bytes'] for row in rows)<100*1024*1024
manifest={'payloads':rows,'payload_count':len(rows),'payload_bytes':sum(row['bytes'] for row in rows),'exclusions':['source/**','inputs/source/**','full source/tree ZIP','world/server/build copies'],'source_pins':'source-pins.json','bounded_source_excerpts':'source-excerpts.json','cleanup':'cleanup-result.json','report':'REPORT.md','scope':'All required review records preserved. No ZIP generated; use only this enumerated payload list.'}
encoded=(json.dumps(manifest,indent=2)+'\n').encode()
(LEAF/'evidence-manifest.json').write_bytes(encoded)
checks=''.join(row['sha256']+'  '+row['path']+'\n' for row in rows)+sha(encoded)+'  evidence-manifest.json\n'
(LEAF/'SHA256SUMS.txt').write_text(checks,encoding='utf-8')
print(json.dumps({'payload_count':len(rows),'payload_bytes':manifest['payload_bytes'],'report_sha256':sha((LEAF/'REPORT.md').read_bytes()),'manifest_sha256':sha(encoded),'checksum_sha256':sha((LEAF/'SHA256SUMS.txt').read_bytes()),'source_cache_exists':(LEAF/'source').exists() or (LEAF/'inputs/source').exists()},indent=2))
