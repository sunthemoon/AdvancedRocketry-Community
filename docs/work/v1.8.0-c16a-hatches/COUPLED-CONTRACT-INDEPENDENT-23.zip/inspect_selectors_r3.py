"""Retain earlier instruments; fix their BCI and exact native context name."""
from pathlib import Path

leaf = Path(__file__).resolve().parent
original = (leaf/'inspect_selectors.py').read_text(encoding='utf-8')
original = original.replace('private com.mojang.datafixers.util.Either lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, com.mojang.datafixers.util.Either);', 'private net.minecraft.world.level.chunk.ChunkAccess lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, net.minecraft.world.level.chunk.ChunkAccess);')
original = original.replace('private void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);','public void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);')
original = original.replace(r'89: invokevirtual[^\n]*Method save:[^\n]*\n\s+92: pop',r'76: invokevirtual[^\n]*Method save:[^\n]*\n\s+79: pop')
original = original.replace('getPlacementContext:','updatePlacementContext:')
original = original.replace("LEAF/'selector-results.json'", "LEAF/'selector-results-r3.json'")
exec(compile(original,str(leaf/'inspect_selectors.py')+' [r3 factual corrections]','exec'))
