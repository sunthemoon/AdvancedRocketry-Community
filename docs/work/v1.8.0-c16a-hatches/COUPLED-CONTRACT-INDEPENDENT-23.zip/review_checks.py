"""Bounded read-only source/native review. Writes only this evidence leaf."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = Path(__file__).resolve().parent
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
NATIVE = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
MIXIN = Path('C:/Users/Administrator/.gradle/caches/modules-2/files-2.1/org.spongepowered/mixin/0.8.5/9d1c0c3a304ae6697ecd477218fa61b850bf57fc/mixin-0.8.5.jar')
JAVAP = 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'
records = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    target = LEAF / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {'path': name, 'bytes': len(data), 'sha256': sha(data)}

def command(argv, log):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180, check=False)
    rec = {'argv': argv, 'cwd': str(ROOT), 'started_utc': start, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': p.returncode, 'output': save(log, p.stdout)}
    records.append(rec)
    print(json.dumps({'argv': argv, 'exit_code': p.returncode, 'log': log}))
    return p

def snapshot():
    for argv, name in [(['git','status','--short'], 'initial-status.txt'), (['git','rev-parse','HEAD'], 'initial-head.txt'), (['git','branch','--show-current'], 'initial-branch.txt'), (['git','worktree','list'], 'initial-worktrees.txt'), (['git','diff','--','AGENTS.md','docs/work/v1.8.0-implementation-log.md'], 'initial-diff.txt')]:
        command(argv, name)
    paths = [
        'AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','UPSTREAM.md','NOTICE.md',
        'docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md','docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
        'docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md','docs/08-ASSET-LICENSE-AND-PROVENANCE.md','docs/11-RISK-REGISTER.md',
        'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md','docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
        'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md','docs/status/CURRENT_VERSION.md',
        'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md','docs/decisions/ADR-068-V180-CLASSIC-NATIVE-OUTER-OPERATIONS.md',
    ]
    hatch = 'docs/work/v1.8.0-c16a-hatches/'
    paths += [hatch + name for name in ['COUPLED-CONTRACT-TASK-23.md','COUPLED-CONTRACT-23.md','COUPLED-VERIFICATION-MATRIX-23.md','PRIVATE-OPERATION-REVIEW-01.md','PRIVATE-OPERATION-RESEARCH-01.md','PLACEMENT-ENTRY-FACTS-01.md','NATIVE-LOAD-ORDER-VERIFICATION-21.md','PLACEMENT-PROVENANCE-VERIFICATION-22.md','OUTER-HOOK-OWNER-DECISION-01.md']]
    inputs = []
    for path in paths:
        data = (ROOT / path).read_bytes()
        row = save('inputs/' + path, data)
        row['source'] = str(ROOT / path)
        inputs.append(row)
    p = command(['git','diff','--','docs/work/v1.8.0-implementation-log.md'], 'task23-log-diff.txt')
    inputs.append({'source':'git diff task23 implementation-log section', **save('inputs/task23-log-diff.txt', p.stdout)})
    adapter = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/'
    source_paths = [adapter + name + '.java' for name in ['ClassicChunkObservation','ClassicSaveProtection','ClassicLoadedWorld','GuardTicket','ClassicAccessCoordinator','ClassicHatchBlockEntity','ClassicOwnerState','ClassicHatchCheckpoint','OwnedNativeTag','ClassicObservationCapability','ClassicChunkObservationProvider']]
    source_paths += ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/' + name + '.java' for name in ['GuardedChunkSaves','ChunkSaveDenials']]
    source_paths += ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/resource/ClassicNativePayload.java','build.gradle']
    for path in source_paths:
        p = command(['git','show',BASE + ':' + path], 'source/' + path)
        if p.returncode == 0:
            inputs.append({'source':'git:' + BASE + ':' + path, **save('inputs/source/' + path,p.stdout)})
    save('input-manifest.json', (json.dumps(inputs,indent=2) + '\n').encode())
    print('Snapshot entries:',len(inputs))

def native():
    jars = [(NATIVE, ['net.minecraft.world.level.chunk.ChunkAccess','net.minecraft.world.level.chunk.LevelChunk','net.minecraft.world.level.chunk.ProtoChunk','net.minecraft.world.level.chunk.ImposterProtoChunk','net.minecraft.world.level.chunk.storage.ChunkSerializer','net.minecraft.server.level.ChunkMap','net.minecraft.server.level.ServerLevel','net.minecraftforge.event.level.ChunkEvent$Load','net.minecraftforge.event.level.ChunkDataEvent$Load']), (MIXIN,['org.spongepowered.asm.mixin.injection.Redirect','org.spongepowered.asm.mixin.injection.struct.InjectionInfo'])]
    identities = []
    for jar, names in jars:
        archive_hash = sha(jar.read_bytes())
        with zipfile.ZipFile(jar) as z:
            for name in names:
                member = name.replace('.','/') + '.class'
                info = z.getinfo(member)
                if info.file_size > 512 * 1024:
                    raise ValueError('Member exceeds limit: ' + member)
                raw = z.read(member)
                log = 'native/' + name.rsplit('.',1)[-1] + '-javap.txt'
                p = command([JAVAP,'-p','-c','-s','-classpath',str(jar),name],log)
                identities.append({'jar':str(jar),'jar_sha256':archive_hash,'member':member,'bytes':len(raw),'sha256':sha(raw),'javap_log':log,'exit_code':p.returncode})
    save('native-identities.json',(json.dumps(identities,indent=2)+'\n').encode())

def native_extra():
    names = ['net.minecraft.world.item.BlockItem','net.minecraft.world.item.ItemStack','net.minecraft.server.level.ServerPlayerGameMode','net.minecraft.server.network.ServerGamePacketListenerImpl','net.minecraft.world.level.Level','net.minecraftforge.common.ForgeHooks','net.minecraftforge.common.capabilities.CapabilityProvider$AsField']
    identities = []
    with zipfile.ZipFile(NATIVE) as z:
        archive_hash = sha(NATIVE.read_bytes())
        for name in names:
            member = name.replace('.','/') + '.class'
            info = z.getinfo(member)
            if info.file_size > 512 * 1024:
                raise ValueError('Member exceeds limit: ' + member)
            raw = z.read(member)
            log = 'native-extra/' + name.rsplit('.',1)[-1] + '-javap.txt'
            p = command([JAVAP,'-p','-c','-s','-classpath',str(NATIVE),name],log)
            identities.append({'jar':str(NATIVE),'jar_sha256':archive_hash,'member':member,'bytes':len(raw),'sha256':sha(raw),'javap_log':log,'exit_code':p.returncode})
    save('native-extra-identities.json',(json.dumps(identities,indent=2)+'\n').encode())

def validators():
    command([sys.executable,'-B','scripts/validate_v180_content_ledger.py','--require-accepted'],'validation/ledger.txt')
    command([sys.executable,'-B','scripts/validate_bootstrap_provenance.py'],'validation/provenance.txt')
    command([sys.executable,'-B','scripts/validate_repository.py','--require-approved-identity'],'validation/strict.txt')
    command(['git','diff','--check'],'validation/whitespace.txt')

if __name__ == '__main__':
    try:
        mode = sys.argv[1]
        {'snapshot':snapshot,'native':native,'native-extra':native_extra,'validators':validators}[mode]()
    finally:
        save('commands-' + sys.argv[1] + '.json',(json.dumps(records,indent=2)+'\n').encode())
