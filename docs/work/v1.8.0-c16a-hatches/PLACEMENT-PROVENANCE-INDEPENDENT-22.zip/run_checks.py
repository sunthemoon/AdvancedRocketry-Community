"""Independent committed-source verification; evidence writes remain in this leaf."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "c2"
PIN = sys.argv[1]
BASE = "4ab2ef8ec5a82e79b4244d92e89320848f4c0564"
JDK = Path("C:/Program Files/Java/jdk-17.0.7")
OUT = ROOT / "corrected"
OUT.mkdir()
TEMP = ROOT / "temp-corrected"
TEMP.mkdir()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(TREE), *args])


assert git("rev-parse", "HEAD").decode().strip() == PIN
assert git("status", "--porcelain") == b""
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / "bin") + os.pathsep + os.environ["PATH"],
           TEMP=str(TEMP), TMP=str(TEMP), TMPDIR=str(TEMP), PYTHONDONTWRITEBYTECODE="1",
           JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=" + TEMP.as_posix())
inputs = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat",
          "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties"]
changed = git("diff", "--name-only", BASE, PIN).decode().splitlines()
identity = dict(utc=stamp(), pin=PIN, base=BASE, tree=git("rev-parse", "HEAD^{tree}").decode().strip(),
                src_tree=git("rev-parse", "HEAD:src").decode().strip(), python=sys.executable,
                python_version=sys.version, platform=platform.platform(), java_home=str(JDK),
                environment={key: env[key] for key in ("JAVA_HOME", "JAVA_TOOL_OPTIONS", "TEMP", "TMP", "TMPDIR")},
                inputs={name: digest(TREE / name) for name in sorted(set(inputs + changed))})
(OUT / "identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8")
(OUT / "source.patch").write_bytes(git("diff", "--binary", BASE, PIN))
(OUT / "git-object-identities.txt").write_bytes(git("show", "--no-patch", "--format=fuller", PIN))
launcher = [str(Path("C:/Windows/System32/cmd.exe")), "/d", "/c", "gradlew.bat"]
gradle = ["--no-daemon", "--offline", "--no-build-cache"]
commands = [
    ("git-version", ["git", "--version"]),
    ("java-version", [str(JDK / "bin/java.exe"), "-version"]),
    ("build", launcher + ["clean", "build"] + gradle),
    ("data-1", launcher + ["runData"] + gradle),
    ("data-1-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("data-2", launcher + ["runData"] + gradle),
    ("data-2-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("provenance", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py"]),
    ("repository", [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]),
    ("whitespace", ["git", "--no-optional-locks", "diff", "--check"]),
    ("native", launcher + ["runGameTestServer"] + gradle),
]
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
    assert min(free.values()) >= 10 * 1024 ** 3, free
    started = stamp()
    print(json.dumps(dict(start=name, utc=started, free_bytes=free)), flush=True)
    log = OUT / (name + ".log")
    with log.open("xb") as stream:
        process = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                 stdout=stream, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
    records.append(dict(name=name, argv=argv, cwd=str(TREE), pin=PIN, start_utc=started,
                        end_utc=stamp(), free_bytes=free, exit_code=process.returncode,
                        log_sha256=digest(log), log_bytes=log.stat().st_size))
    (OUT / "commands.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(records[-1]), flush=True)

xmls = sorted((TREE / "build/test-results/test").glob("TEST-*.xml"))
counts = {key: 0 for key in ("tests", "failures", "errors", "skipped")}
actual = 0
with zipfile.ZipFile(OUT / "unit-xml.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in xmls:
        node = ET.parse(path).getroot()
        for key in counts:
            counts[key] += int(node.get(key, 0))
        actual += len(node.findall("testcase"))
        archive.write(path, path.name)
for filename in ("latest.log", "debug.log"):
    path = TREE / "build/gametest/logs" / filename
    if path.is_file():
        shutil.copyfile(path, OUT / ("native-" + filename))
native = (OUT / "native-latest.log").read_text(encoding="utf-8") if (OUT / "native-latest.log").is_file() else ""
console = (OUT / "native.log").read_text(encoding="utf-8", errors="replace")
artifacts = {}
for path in (TREE / "build/libs").glob("*.jar"):
    with zipfile.ZipFile(path) as archive:
        members = archive.namelist()
        (OUT / (path.name + ".entries.txt")).write_text("\n".join(members) + "\n", encoding="utf-8")
    artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size,
                               adapter_fixture_entries=[name for name in members if "arceadaptertest" in name])
summary = dict(pin=PIN, src_tree=identity["src_tree"], unit_suites=len(xmls), unit_totals=counts,
               actual_testcase_nodes=actual, artifacts=artifacts,
               native_terminal=[line for line in native.splitlines() if re.search(r"GAME TESTS COMPLETE|All \d+ required tests passed|\d+ required tests failed", line)],
               native_error_headers=len(re.findall(r"/ERROR]", native)),
               native_fatal_headers=len(re.findall(r"/FATAL]", native)),
               native_failure_lines=[line for line in native.splitlines() if "failed!" in line],
               probe_batches=[line for line in native.splitlines() if "Running test batch 'placement_provenance" in line],
               frame_observations=[line for line in native.splitlines() if "ARCE_PLACEMENT_ENTRY" in line],
               console_frame_observations=[line for line in console.splitlines() if "ARCE_PLACEMENT_ENTRY" in line],
               head_unchanged=git("rev-parse", "HEAD").decode().strip() == PIN,
               clean=not git("status", "--porcelain"))
(OUT / "results.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
(OUT / "git-final-status.txt").write_bytes(git("status", "--porcelain"))
print(json.dumps(summary), flush=True)
sys.exit(0 if all(row["exit_code"] == 0 for row in records) and summary["clean"] and summary["head_unchanged"] else 1)
