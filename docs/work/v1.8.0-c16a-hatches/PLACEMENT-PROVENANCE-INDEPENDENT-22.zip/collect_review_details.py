"""Retain exact source boundary/correction identities and native console observations."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "c2"
BASE = "4ab2ef8ec5a82e79b4244d92e89320848f4c0564"
ORIGINAL = "5b48514e4b8946316ac38b5485acfb6e5c5c56ea"
PIN = "7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e"


def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(TREE), *args])


assert git("rev-parse", "HEAD").decode().strip() == PIN
(ROOT / "corrected/correction.patch").write_bytes(git("diff", "--binary", ORIGINAL, PIN))
build = (TREE / "build.gradle").read_text(encoding="utf-8")
lines = build.splitlines()
selected = []
for index, line in enumerate(lines, 1):
    if any(token in line for token in ("sourceSets", "adapterTest", "source sourceSets", "sourcesJar", "tasks.named('jar'", "from({ zipTree", "apiJar", "tasks.named('check'")):
        selected.append(dict(line=index, text=line))
(ROOT / "corrected/source-set-boundary.json").write_text(json.dumps(selected, indent=2) + "\n", encoding="utf-8")
compiled = []
for path in sorted((TREE / "build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest").glob("*Placement*.class")):
    compiled.append(dict(name=path.name, bytes=path.stat().st_size,
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(ROOT / "corrected/compiled-probe-identities.json").write_text(json.dumps(compiled, indent=2) + "\n", encoding="utf-8")
console = (ROOT / "corrected/native.log").read_text(encoding="utf-8", errors="replace")
rows = []
for line in console.splitlines():
    if "ARCE_PLACEMENT_ENTRY" not in line:
        continue
    subject = re.search(r"subject=([^ ]+)", line).group(1)
    phase = re.search(r"phase=([^ ]+)", line).group(1)
    frames = [dict(type=m.group(1), method=m.group(2), descriptor=m.group(3), bci=int(m.group(4)))
              for m in re.finditer(r"Caller\[type=class ([^,]+), method=([^,]+), descriptor=([^,]+), bci=(-?\d+)\]", line)]
    rows.append(dict(subject=subject, phase=phase, frame_count=len(frames), frames=frames,
                     native_caller_indices=[i for i, frame in enumerate(frames)
                                            if frame["type"] == "net.minecraft.server.level.ServerPlayerGameMode"
                                            and frame["method"] == "useItemOn"], raw_line=line))
(ROOT / "corrected/console-frame-observations.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(pin=PIN, observations=len(rows), compiled_classes=len(compiled),
                      phases=[(row["subject"], row["phase"], row["frame_count"], row["native_caller_indices"]) for row in rows])))
