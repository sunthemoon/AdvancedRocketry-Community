$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$names = @('checkout', 'c2', 'temp-original', 'temp-corrected')
$targets = @()
foreach ($name in $names) {
    $resolved = (Resolve-Path -LiteralPath (Join-Path $leaf $name)).ProviderPath.TrimEnd('\')
    if ($resolved -ne [IO.Path]::GetFullPath((Join-Path $leaf $name)).TrimEnd('\') -or
        -not $resolved.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw "Target is outside the declared owned leaf: $resolved"
    }
    $targets += $resolved
    $ancestor = Get-Item -LiteralPath $resolved -Force
    while ($null -ne $ancestor) {
        if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse ancestor rejected: $($ancestor.FullName)"
        }
        $ancestor = $ancestor.Parent
    }
}
$processes = @(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CommandLine)
$processes | ForEach-Object {
    $process = $_
    [pscustomobject]@{ProcessId=$process.ProcessId; ParentProcessId=$process.ParentProcessId; Name=$process.Name;
        owned_target_references=@($targets | Where-Object { $process.CommandLine -and $process.CommandLine.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 });
        command_line_sha256=if ($process.CommandLine) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($process.CommandLine))) } else { $null }}
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-processes.json') -Encoding utf8
$blockers = @($processes | Where-Object {
    $process = $_
    $process.ProcessId -ne $PID -and $process.CommandLine -and
    @($targets | Where-Object { $process.CommandLine.IndexOf($_, [StringComparison]::OrdinalIgnoreCase) -ge 0 }).Count -gt 0
})
if ($blockers.Count -gt 0) {
    $blockers | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-blockers.json') -Encoding utf8
    throw 'A process still references a cleanup target. Nothing deleted.'
}
$inventory = @()
$totals = @()
foreach ($target in $targets) {
    $entries = @(Get-ChildItem -LiteralPath $target -Recurse -Force -ErrorAction Stop)
    if (@($entries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -gt 0) {
        throw "Reparse descendant rejected: $target"
    }
    $files = @($entries | Where-Object { -not $_.PSIsContainer })
    foreach ($file in $files) {
        $inventory += [pscustomobject]@{target=$target; path=$file.FullName.Substring($target.Length + 1); bytes=$file.Length}
    }
    $totals += [pscustomobject]@{target=$target; files=$files.Count; directories=@($entries | Where-Object PSIsContainer).Count; logical_bytes=($files | Measure-Object Length -Sum).Sum}
}
$inventory | Export-Csv -LiteralPath (Join-Path $leaf 'cleanup-inventory.csv') -NoTypeInformation -Encoding utf8
$totals | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-totals.json') -Encoding utf8
Get-PSDrive -Name C,D | Select-Object Name,Free,Used | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-drives-before.json') -Encoding utf8
# Single native PowerShell cleanup attempt. No shell composition or retry.
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
}
$remaining = @($targets | Where-Object { Test-Path -LiteralPath $_ })
if ($remaining.Count -ne 0) { throw "Owned disposable targets remain: $remaining" }
Get-PSDrive -Name C,D | Select-Object Name,Free,Used | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-drives-after.json') -Encoding utf8
@{utc=[DateTime]::UtcNow.ToString('o'); deleted_targets=$targets; remaining_targets=$remaining; process_blockers=$blockers.Count; attempts=1} |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-result.json') -Encoding utf8
Write-Output 'Single owned cleanup attempt completed.'
