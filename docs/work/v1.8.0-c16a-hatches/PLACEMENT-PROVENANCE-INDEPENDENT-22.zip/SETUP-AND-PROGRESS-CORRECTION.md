# Reviewer setup and progress correction

The reviewer owns only this newly created external evidence leaf. No shared
candidate, main source, index, branch or HEAD was changed. Fresh disposable
clones are local `git clone --no-hardlinks --no-checkout` repositories, not
shared worktrees. Their source is restored only from their recorded commit.

The first clone checkout at `5b48514e4b8946316ac38b5485acfb6e5c5c56ea`
reported Windows filename-too-long errors for historical test XML evidence.
Those messages are retained in `checkout.log`. Clone-local `core.longpaths`
was then enabled and `git restore --source=HEAD --worktree -- .` restored the
missing files. The exact successful restore exit is retained; the original
setup pipeline did not capture the first checkout's exit separately, so no
successful complete-checkout assertion is based on that pipeline. The first
runner itself asserts a clean checkout and exact pin before any commands.

The second clone's first checkout also left missing historical XML files.
Its clone and checkout exits are recorded as 0, but its printed dirty status
means those exits alone were insufficient. Enabling clone-local long paths
and restoring from HEAD again establishes a complete clean source input.
No validation/build command ran in the second clone before correction.

The first runner used literal `C:/Windows/System32/cmd.exe`. All attempted
Gradle launches failed before Gradle with `The syntax of the command is
incorrect.` and exit 1. They are reviewer command-instrumentation failures,
not product test failures, and the empty DataGen-adjacent diffs do not prove
deterministic generation. A progress message initially misstated these as
successful build and DataGen runs. The reviewer corrected that statement to
Root immediately after reading the actual command records. The original
attempt, zero-test counts and executed runner bytes are retained separately;
they will not be relabeled as a later source cohort.

The full independent rerun will use a separately recorded corrected candidate
and `str(Path('C:/Windows/System32/cmd.exe'))`, giving native Windows path
spelling. This changes reviewer instrumentation only, not source assertions,
timeouts, budgets or build settings. Every substantive Gradle invocation uses
Java 17, `--offline --no-daemon --no-build-cache`; TEMP/TMP/TMPDIR and
java.io.tmpdir are task-local and both drive free-space checks are recorded.

The original source finding is independently established from the candidate
diff and the pinned mapped Forge JAR: registered chest-backed BlockItem
inherits block-to-item registration and therefore changes a global vanilla
mapping. Source read interests on the shared candidate and main checkout were
released after that investigation. Later execution reads only owned clones.

Read-only exploration also retained these non-product command failures in the
tool transcript: the guessed `docs/versions/v1.8.0.md` did not exist (the real
version document was then read); a literal Windows `src/main/java/**/...`
argument to rg returned invalid-path error 123 (the real adjacent class was
then located with `rg --files`); an optional `python.bat -c` result-summary
query lost embedded double quotes and raised NameError before reading its
input. The equivalent summary was subsequently read with native PowerShell
ConvertFrom-Json. None changed a source file or served as test evidence.
