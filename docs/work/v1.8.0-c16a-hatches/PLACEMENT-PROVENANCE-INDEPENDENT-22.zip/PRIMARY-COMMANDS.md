# Primary read and metadata commands

All commands below are read-only source/archive queries. They run through native
PowerShell. Full command cohort argv, source pins, starts/ends, disk measurements,
exit codes and log hashes are independently recorded in each commands.json.

The exact JDK executable for bytecode reads is
`C:/Program Files/Java/jdk-17.0.7/bin/javap.exe`; options are `-p -c -s`.
The primary archive classpath is the path in `mapped-jar-identity.json`.
The four queried classes are `net.minecraftforge.registries.GameData$ItemCallbacks`,
`net.minecraft.world.item.BlockItem`, `net.minecraft.world.level.block.Block` and
`net.minecraft.world.item.Item`. Each full javap stdout/stderr and explicit exit
is retained in the correspondingly named root text files. Four <=512 KiB class
members are independently hashed in `mapped-member-identities.json`; the whole
mapped artifact is identified by SHA-256, not a web branch or cached filename alone.

The corrected compiled probe query uses the same JDK/options with classpath
`c2/build/classes/java/adapterTest` and class
`io.github.sunthemoon.arceadaptertest.FixturePlacementProbeItem`.
Its output and explicit exit are retained in corrected/compiled-probe-javap*.
Compiled-bytecode identities are retained, but no compiled probe binary is packed.

Gradle runtime metadata is obtained in the corrected owned checkout with
`gradlew.bat --version --no-daemon --offline`, explicit JAVA_HOME 17.0.7 and the
same task-local TEMP/TMP/TMPDIR/java.io.tmpdir as the corrected cohort.
Both-drive measurements, actual metadata stdout/stderr and exit are retained.

`python -B hash_primary_inputs.py` uses the explicit Python executable recorded
in the cohorts. It exits 0 and hashes 4 archive members plus 19 committed source
and governance inputs. The live main AGENTS was read before review and its later
read identity is retained separately; its user-owned modification was not changed.
The committed AGENTS hash is intentionally not represented as the live one.

Clone/fetch/detached-checkout/long-path restores occur only in the newly owned
external disposable clones. Their logs and explicit exits are retained wherever
recorded. No Git/source mutation occurred in Root's checkout or the main tree.
