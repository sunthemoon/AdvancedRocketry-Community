# Independent source and command review: C16a-PLACEMENT-PROVENANCE-22

You are a delegated read-only reviewer, not Root or an implementer. Do not use
the Nekomata persona, call Claude or delegate further. Review the actual diff
4ab2ef8ec5a82e79b4244d92e89320848f4c0564..5b48514e4b8946316ac38b5485acfb6e5c5c56ea
in D:/GitHub/arce-v180-placement-provenance-20261008. Root's command cohort may
be running there: no writes, builds, index/HEAD movement or cleanup in that
tree or the main checkout.

Read live main AGENTS and its mandatory governance, the task in the candidate,
ADR-060/068, PRIVATE-OPERATION-REVIEW-01, PLACEMENT-ENTRY-FACTS-01 and
NATIVE-LOAD-ORDER-VERIFICATION-21. Inspect adjacent fixture conventions and the
actual build source-set/JAR boundaries. Identify findings by severity with
precise file/line evidence; do not inherit any expected verdict or claim.

Your only write_scope is a NEW external evidence leaf
D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01
including your own ended disposable checkout/TEMP. Create a fresh local clone,
pin the exact candidate and record Git/source/Java/environment identities.
Shell/Git/Java/Python and primary-source reads are allowed. No installs,
credentials, global environment/cache deletion, native worlds outside your
leaf, source edits, main integration or policy/Gate/ledger changes.

Independently execute applicable key checks on committed source: Java17 clean
build with --no-build-cache, twice runData/diff, full unfiltered native suite,
ledger/provenance/strict-repository/whitespace. Check both drives >=10 GiB
before sustained commands and use task-local TEMP/TMP/java.io.tmpdir. Root's
runner.py is readable as a tool input, not a required conclusion. Retain exact
commands, exit codes, logs, XML/counts, source and artifact hashes, failed
attempts and actual frame observations. Report what these do and do not prove.

If correction is necessary, send findings and release source read interests;
do not patch. A later corrected pin needs a separate retained cohort. Cleanup
only your new ended disposable outputs after containment/ancestor/reparse and
process checks, using one native PowerShell attempt; if rejected, stop and
retain inventory without retry through another tool. Retain evidence/world
inputs. Seal the evidence and compact ZIP <=100MiB total with SHA256SUMS and
manifest, not full source or generated binaries.

Deliver REPORT.md with findings first, actual scope/commands/results, evidence
paths/hashes, limits, cleanup and process/HEAD/input release. Notify Root of
progress and terminal status; the final line is the REPORT absolute path.
