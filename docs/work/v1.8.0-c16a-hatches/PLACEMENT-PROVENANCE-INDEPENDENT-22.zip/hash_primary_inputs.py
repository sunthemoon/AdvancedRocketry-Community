"""Bounded primary-archive identities and committed governance/input identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parent
jar = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
members = ["net/minecraftforge/registries/GameData$ItemCallbacks.class",
           "net/minecraft/world/item/BlockItem.class", "net/minecraft/world/item/Item.class",
           "net/minecraft/world/level/block/Block.class"]
identities = {}
with zipfile.ZipFile(jar) as archive:
    for name in members:
        info = archive.getinfo(name)
        assert info.file_size <= 512 * 1024
        value = archive.read(name)
        identities[name] = dict(bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
(root / "mapped-member-identities.json").write_text(json.dumps(identities, indent=2) + "\n", encoding="utf-8")
tree = root / "checkout"
paths = ["AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md",
         "docs/04-VERSION-ROADMAP.md", "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
         "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md", "docs/16-POST-1.0-VERSION-ROADMAP.md",
         "docs/17-V1PLUS-QUALITY-BUDGETS.md", "docs/versions/V1.0.0-COMMUNITY-MVP.md",
         "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md", "docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md",
         "docs/decisions/ADR-068-V180-CLASSIC-NATIVE-OUTER-OPERATIONS.md",
         "docs/work/v1.8.0-c16a-hatches/PRIVATE-OPERATION-REVIEW-01.md",
         "docs/work/v1.8.0-c16a-hatches/PLACEMENT-ENTRY-FACTS-01.md",
         "docs/work/v1.8.0-c16a-hatches/NATIVE-LOAD-ORDER-VERIFICATION-21.md",
         "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/BlockEntityLoadOrderingGameTests.java",
         "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/FixtureThermiteItems.java"]
records = {}
for name in paths:
    data = subprocess.check_output(["git", "--no-optional-locks", "-C", str(tree), "show", "HEAD:" + name])
    records[name] = dict(bytes=len(data), git_blob=subprocess.check_output([
        "git", "--no-optional-locks", "-C", str(tree), "rev-parse", "HEAD:" + name]).decode().strip(),
        committed_sha256=hashlib.sha256(data).hexdigest(),
        checkout_sha256=hashlib.sha256((tree / name).read_bytes()).hexdigest())
(root / "original/primary-input-identities.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(archive_members=len(identities), committed_inputs=len(records))))
