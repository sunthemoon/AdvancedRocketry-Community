# Independent source and command review: C16a-PLACEMENT-PROVENANCE-22

Date: 2026-10-08. Reviewer: delegated independent Codex; not Root or the implementer.
Write scope: this new external evidence leaf only. No Claude or further delegation.

## Findings first

### M-01 — Native chest block-to-item mapping is changed by the original probe registration — resolved in the corrected pin

At original candidate `5b48514e4b8946316ac38b5485acfb6e5c5c56ea`,
[FixturePlacementProbeItem.java:23,28](D:/GitHub/arce-v180-placement-provenance-20261008/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/FixturePlacementProbeItem.java)
registers a BlockItem backed by `Blocks.CHEST`, and
[AdapterTestMod.java:66](D:/GitHub/arce-v180-placement-provenance-20261008/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterTestMod.java)
installs that registration. It inherits the map-registration implementation.
The independently inspected pinned mapped JAR dispatches `registerBlocks` from
`GameData$ItemCallbacks.onAdd` at PC 69; inherited `BlockItem.registerBlocks`
performs `Map.put(getBlock(), item)` at PC 6. This changes a shared vanilla
registration mapping for the entire development GameTest host, rather than
limiting observation effects to the owned invocation/cells. It can contaminate
other chest lookup behavior and therefore the test baseline. This is a Medium
fixture-isolation finding, not a demonstrated production hatch regression.
The [original actual diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/original/source.patch),
[registration bytecode](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/GameData-ItemCallbacks-javap.txt)
and [BlockItem bytecode](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/BlockItem-javap.txt)
retain precise evidence. The source line numbers above are for the original pin.

Correction `7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e` adds both no-op callbacks at
`FixturePlacementProbeItem.java:33-35` and direct `Item.byBlock(Blocks.CHEST) ==
Items.CHEST` checks before/after use at `PlacementProvenanceGameTests.java:143-145,212-213`.
`Block.asItem` alone would be weaker because it caches its first lookup.
The [correction diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/correction.patch)
preserves every existing assertion, timeout and budget. Independent compilation
shows both overrides are solely `0: return`; the required native cases pass with
the direct mapping assertions. M-01 is resolved at this corrected pin, not erased
from the original review. No remaining introduced Critical/High/Medium/Low source
finding is established in the reviewed corrected diff.

### Verification failure retained — strict repository validation is not passing

Both independently executed strict validations exit 1: 44 checks pass, one
Markdown-link check fails. In a fresh committed-source clone, ignored historical
ZIPs are absent and several external targets fail safety/size checks. The corrected
output reaches the 256-diagnostic cap and names 108 broken-link documents; neither
changed document appears in those diagnostics. This is not a complete enumeration
of all broken links and is not claimed byte-identical to Root's local-tree log.
The [exact corrected failure](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/repository.log)
and [post-run audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/final-audit.json)
remain retained. No missing untracked material was copied in to make this pass.

## Completed scope, decisions and files

Reviewed the live main governance, both acceptance/development version documents,
ADR-060/068, the task and three named placement/private-operation/LOAD-order records.
The acceptance cursor remains v1.0.0; ADR-060 permits the separate v1.8 development
scope without approving inherited/current release Gates. Reviewed the actual
`4ab2ef8e..5b48514e` diff, the `5b48514e..7f5c5b18` correction and adjacent fixtures.
Examined build source-set/JAR boundaries and exact pinned primary archive members.

The implementation adds three required development-only GameTests and one registered
observation item; no new JUnit case is introduced. This reviewer changes no source,
test, main/candidate index/HEAD, policy, Gate, ledger or state file. Reviewer changes
are only the report, bounded audit/runner/cleanup/sealing scripts and retained evidence
under the assigned leaf. No source correction was written by this reviewer.

Map registration is isolated; invocation-local event capture remains bounded to four
events/16 frames. The probe is observation infrastructure, not gameplay content,
an authority credential, an adopted physical hatch or a new interception site.
The complete `src/main` tree is unchanged from the base (`9b1e79254d7467c8afc1c700006cf2c0318d4cd3`).

## Actual commands and results

Corrected independent source: `7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e`.
Complete source tree: `d12da7cfbb3aab3fc6bd21eab60dc08d56ce2025`.
Fresh local no-hardlink clones; existing offline dependency caches. Java 17.0.7,
Gradle 8.8, Python 3.13.15, Windows 11 x64. Seven Gradle inputs and changed source
inputs are hashed. TEMP/TMP/TMPDIR/java.io.tmpdir are task-local; both drives exceed
10 GiB before every cohort command. This is not a fresh-dependency/download environment.

All substantive Gradle commands below include `--no-daemon --offline --no-build-cache`.
Exact argv, dates, exits, disk bytes and log hashes are in
[corrected/commands.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/commands.json).

| Actual command | Exit | Independent result |
| --- | --- | --- |
| `gradlew.bat clean build` | 0 | 4m 13s; all 20 actionable tasks execute, including `:test`; no standalone test invocation by this reviewer |
| `gradlew.bat runData`, twice | 0 / 0 | Both execute successfully |
| `git diff --exit-code`, after each DataGen | 0 / 0 | Both empty |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | 0 | Validator succeeds |
| `python -B scripts/validate_bootstrap_provenance.py` | 0 | Validator succeeds |
| `python -B scripts/validate_repository.py --require-approved-identity` | 1 | 44 pass / one link-check failure, preserved above |
| `git diff --check` | 0 | Empty working-tree check |
| `git diff --check 4ab2ef8e 7f5c5b18` | 0 | Committed actual-diff whitespace check |
| `gradlew.bat runGameTestServer` | 0 | Unfiltered suite: all 551 required tests pass; new three-case batch present |
| `gradlew.bat --version --no-daemon --offline` | 0 | Actual Gradle/JVM metadata retained |
| Primary/compiled `javap` reads and both Python evidence audits | 0 | Exact bytecode/member identities and retained XML/console evidence inspected |

The independently reparsed [JUnit archive](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/unit-xml.zip)
contains 378 suites / 2,179 actual testcase nodes / zero failures, errors or skips.
The native terminal is fresh and reports 551 complete / all 551 required passed.
Native logs retain 62 ERROR headers and zero FATAL; these are not blanket-waived.
Runner exit is 1 because strict validation fails. Final source HEAD is unchanged
and tracked/untracked Git status is clean.

The first attempt at `5b48514e` used an incorrect CMD path spelling: all four Gradle
launches fail before Gradle, with zero unit/native execution and no artifacts.
Only its ledger/provenance/whitespace checks pass; its empty diffs prove nothing
about DataGen. The mistaken early progress statement was explicitly corrected.
Original runner bytes, logs, exits and zero-test summary remain separate in
[original/commands.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/original/commands.json)
and the [setup/correction record](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/SETUP-AND-PROGRESS-CORRECTION.md).
There was no independent full native execution of the original defective pin.
Windows long-filename checkout problems and other failed read-only exploration
attempts are retained there rather than converted into source/test failures.

## Actual frame observations and their limits

Ten actual System.out observations appear in the native console; none appear in
latest.log. Both outputs are retained separately. Every observation captures
exactly 16 frames, so collection reaches its cap and does not establish a complete
outer stack. The following are actual zero-based native `useItemOn` frame indices/BCIs,
not prefilled assertions:

| Subject | FIRST | USE | PLACE | Later USE |
| --- | --- | --- | --- | --- |
| ordinary creative | 6 / 128 | 4 / 349 | 7 / 349 | none |
| ordinary survival | 6 / 128 | 4 / 366 | 7 / 366 | none |
| direct-first survival | 6 / 128 | 9 / 128 | 12 / 128 | 4 / 366 |

The [parsed console frames](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/console-frame-observations.json)
retain ordered class, method, descriptor, BCI and exact raw lines. The tests assert
shared actual first-use/item-entry context identity, hand/source/level identity,
selected pre-write target and empty cell, native chest owner, count/tag outcomes,
and direct versus ordinary result/caller distinctions. Both direct and ordinary
entries retain the native game-mode class despite different measured call sites.

These are plain ServerPlayers with owned EmbeddedChannels, not genuine C2S packet,
packaged transformed entry, real-client/V1/V2 or dedicated restart evidence.
StackWalker does not reveal receivers, arguments or locals. The cases qualify
only these baseline development paths; they do not authenticate all native entries,
bind LOAD/save/outcome authority, test arbitrary callbacks/transforms or establish
cross-store crash conservation. Normal cleanup assertions run successfully; failure
branches are source-reviewed, not separately failure-injected.

## Artifact/source identity and evidence

All three independently built JAR entry sets exclude `arceadaptertest` and both new
fixture names. Full entry lists/hashes are retained; generated JARs themselves are
not packed. The observed hashes are:

- Runtime: `dd93cb968430eba12fb13539bbdfb29e943af1f16a6b6a8ebb3257a14d9a6b87`.
- API: `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
- Sources: `ed57d4d0923c1571b421979a8e6068165b70dc048b755b8d8bdd8faf1c27d2a9`.
- Pinned mapped Forge JAR, rehashed unchanged:
  `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.

These preserve the already-recorded development baseline identities, not release
approval. Source/artifact/environment identities are in
[corrected/identity.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/identity.json)
and [results.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/corrected/results.json).
The leaf is sealed with MANIFEST.json, SHA256SUMS.txt and a compact evidence.zip;
SEAL-RESULT.json identifies the exact ZIP/report/controller hashes and validated
entry/byte totals. No full source, generated JAR, server tree or world binary is packed.

## Cleanup, release, remaining risks and next action

One native PowerShell cleanup attempt succeeds after absolute containment,
ancestor/descendant reparse, ended-session and process checks. It removes only the
reviewer's two newly owned disposable clones and two task TEMP directories:
2,546,145,449 inventoried logical bytes. This is an inventory, not measured physical
space reclaimed. Zero referencing process blockers or disposable targets remain.
The [cleanup result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-independent-20261008-01/cleanup-result.json)
and inventories remain retained. Generated world output identities (700 files) and
seed-0 server properties are recorded; no original/committed world input, other-agent
output, old refused cleanup target, global cache or Root sealed evidence is deleted.

All own commands have ended. No process is terminated by this reviewer. Both shared
source read interests and own HEAD/input interests are released; no Root/main HEAD
movement is requested or performed by this reviewer. The original and corrected pins
remain distinct. No new disposable cleanup debt remains from this review.

**Current version Required Gates are not all satisfied.** No Gate/ADR/risk/ledger
approval follows. ADR-068 remains PROPOSED; the two existing Medium physical admission
prerequisites, provisional LOAD/availability/terminal bindings, O1/O2/O3 dispositions,
R-021, packaged/restart/prior-world/installed continuation, compatibility, V1/V2,
progression, performance and release evidence remain open.

Recommendation: retain this as corrected test-side development qualification, not
physical activation or version acceptance. Continue the current v1.8 coupled
authentic-entry/outcome and provisional LOAD/save/terminal contract work and strict
evidence-link disposition before broader delivery; do not start later-version features.
