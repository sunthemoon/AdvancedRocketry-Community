"""Reparse retained artifacts and fixed Git objects before retiring the owned clones."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "c2"
PIN = "7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e"
BASE = "4ab2ef8ec5a82e79b4244d92e89320848f4c0564"
OUT = ROOT / "corrected"


def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(TREE), *args])


summary = json.loads((OUT / "results.json").read_text(encoding="utf-8"))
counts = {key: 0 for key in ("tests", "failures", "errors", "skipped")}
actual = 0
with zipfile.ZipFile(OUT / "unit-xml.zip") as archive:
    assert archive.testzip() is None
    suites = len(archive.namelist())
    for name in archive.namelist():
        node = ET.fromstring(archive.read(name))
        for key in counts:
            counts[key] += int(node.get(key, 0))
        actual += len(node.findall("testcase"))
assert counts == summary["unit_totals"]
assert suites == summary["unit_suites"]
assert actual == summary["actual_testcase_nodes"]
commands = json.loads((OUT / "commands.json").read_text(encoding="utf-8"))
for record in commands:
    assert record["pin"] == PIN
    assert min(record["free_bytes"].values()) >= 10 * 1024 ** 3
    assert hashlib.sha256((OUT / (record["name"] + ".log")).read_bytes()).hexdigest() == record["log_sha256"]
build = (OUT / "build.log").read_text(encoding="utf-8", errors="replace")
assert "20 actionable tasks: 20 executed" in build
assert "> Task :test FROM-CACHE" not in build
assert "> Task :test UP-TO-DATE" not in build
frames = json.loads((OUT / "console-frame-observations.json").read_text(encoding="utf-8"))
assert frames and all(0 < row["frame_count"] <= 16 for row in frames)
latest = (OUT / "native-latest.log").read_text(encoding="utf-8")
console = (OUT / "native.log").read_text(encoding="utf-8", errors="replace")
assert len(frames) == len([line for line in console.splitlines() if "ARCE_PLACEMENT_ENTRY" in line])
jar_boundaries = {}
for name, record in summary["artifacts"].items():
    artifact = TREE / "build/libs" / name
    assert hashlib.sha256(artifact.read_bytes()).hexdigest() == record["sha256"]
    with zipfile.ZipFile(artifact) as archive:
        matching = [name for name in archive.namelist() if any(token in name for token in (
            "arceadaptertest", "FixturePlacementProbe", "PlacementProvenance"))]
    assert not matching
    jar_boundaries[name] = dict(sha256=record["sha256"], forbidden_fixture_members=matching)
changed = git("diff", "--name-only", BASE, PIN).decode().splitlines()
repo = (OUT / "repository.log").read_text(encoding="utf-8", errors="replace")
broken_docs = sorted(set(re.findall(r"(docs/[A-Za-z0-9_./-]+\.md):\d+ ->", repo)))
introduced_link_diagnostics = sorted(set(changed).intersection(broken_docs))
whitespace = subprocess.run(["git", "--no-optional-locks", "-C", str(TREE), "diff", "--check", BASE, PIN],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(OUT / "committed-diff-whitespace.log").write_bytes(whitespace.stdout)
assert whitespace.returncode == 0
for name in ("server.properties",):
    source = TREE / "build/gametest" / name
    shutil.copyfile(source, OUT / ("native-" + name))
world_outputs = []
for source in sorted((TREE / "build/gametest/world").rglob("*")):
    if source.is_file():
        world_outputs.append(dict(path=source.relative_to(TREE / "build/gametest/world").as_posix(),
                                  bytes=source.stat().st_size, sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(OUT / "generated-world-output-identities.json").write_text(json.dumps(world_outputs, indent=2) + "\n", encoding="utf-8")
mapped = json.loads((ROOT / "mapped-jar-identity.json").read_text(encoding="utf-8-sig"))
assert hashlib.sha256(Path(mapped["Path"]).read_bytes()).hexdigest().upper() == mapped["Hash"]
main_before = git("rev-parse", BASE + ":src/main").decode().strip()
main_after = git("rev-parse", PIN + ":src/main").decode().strip()
assert git("rev-parse", "HEAD").decode().strip() == PIN
assert git("status", "--porcelain") == b""
result = dict(pin=PIN, src_tree=summary["src_tree"], unit_archive_suites=suites, unit_archive_totals=counts,
              actual_archived_testcase_nodes=actual, xml_crc_ok=True, clean_build_all_20_tasks_executed=True,
              jar_boundaries=jar_boundaries, changed_paths=changed, main_tree_before=main_before,
              main_tree_after=main_after, main_tree_unchanged=main_before == main_after,
              listed_broken_document_count=len(broken_docs), link_diagnostic_cap_reached="stopped after 256 errors" in repo,
              changed_docs_in_broken_link_diagnostics=introduced_link_diagnostics,
              latest_frame_lines=len([line for line in latest.splitlines() if "ARCE_PLACEMENT_ENTRY" in line]),
              console_frame_lines=len(frames), committed_diff_whitespace_exit=whitespace.returncode,
              mapped_jar_unchanged=True, generated_world_output_files=len(world_outputs),
              head_unchanged=True, clean=True,
              minimum_command_free_bytes={drive:min(row["free_bytes"][drive] for row in commands) for drive in ("C:/", "D:/")})
(OUT / "final-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
