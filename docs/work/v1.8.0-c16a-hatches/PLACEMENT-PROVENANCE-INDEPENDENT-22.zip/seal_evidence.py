"""Seal retained review evidence only, excluding disposable source/build/world binaries."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
LIMIT = 100 * 1024 ** 2
assert all(not (ROOT / name).exists() for name in ("checkout", "c2", "temp-original", "temp-corrected"))
assert (ROOT / "REPORT.md").is_file()
for name in ("MANIFEST.json", "SHA256SUMS.txt", "evidence.zip", "SEAL-RESULT.json"):
    assert not (ROOT / name).exists(), name
paths = sorted(path for path in ROOT.rglob("*") if path.is_file())
rows = [dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
             sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in paths]
manifest = dict(source_pins=["5b48514e4b8946316ac38b5485acfb6e5c5c56ea", "7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e"],
                payload_count=len(rows), payload_bytes=sum(row["bytes"] for row in rows), files=rows,
                exclusion="Ended disposable clones/TEMP/build/world outputs; no full source or generated JAR retained")
(ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
manifest_hash = hashlib.sha256((ROOT / "MANIFEST.json").read_bytes()).hexdigest()
checksums = "".join(row["sha256"] + "  " + row["path"] + "\n" for row in rows) + manifest_hash + "  MANIFEST.json\n"
(ROOT / "SHA256SUMS.txt").write_text(checksums, encoding="utf-8")
archive_paths = paths + [ROOT / "MANIFEST.json", ROOT / "SHA256SUMS.txt"]
with zipfile.ZipFile(ROOT / "evidence.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in archive_paths:
        archive.write(path, path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(ROOT / "evidence.zip") as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == {path.relative_to(ROOT).as_posix() for path in archive_paths}
    for path in archive_paths:
        assert archive.read(path.relative_to(ROOT).as_posix()) == path.read_bytes()
for row in rows:
    assert hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
total = sum(path.stat().st_size for path in ROOT.rglob("*") if path.is_file())
assert total < LIMIT
assert max(path.stat().st_size for path in ROOT.rglob("*") if path.is_file()) <= 50 * 1024 ** 2
result = dict(payload_count=len(rows), archive_entries=len(archive_paths), payload_bytes=manifest["payload_bytes"],
              archive_bytes=(ROOT / "evidence.zip").stat().st_size,
              archive_sha256=hashlib.sha256((ROOT / "evidence.zip").read_bytes()).hexdigest(),
              manifest_sha256=manifest_hash, checksum_controller_sha256=hashlib.sha256((ROOT / "SHA256SUMS.txt").read_bytes()).hexdigest(),
              report_sha256=hashlib.sha256((ROOT / "REPORT.md").read_bytes()).hexdigest(),
              combined_bytes_before_seal_controller=total, crc_and_all_payloads_verified=True)
(ROOT / "SEAL-RESULT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
assert sum(path.stat().st_size for path in ROOT.rglob("*") if path.is_file()) < LIMIT
print(json.dumps(result, indent=2))
