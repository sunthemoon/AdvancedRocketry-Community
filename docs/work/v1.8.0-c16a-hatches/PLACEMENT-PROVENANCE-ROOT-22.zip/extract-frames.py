"""Extract retained console observations separately from original cohort summaries."""
import hashlib
import json
from pathlib import Path
import re
import sys

leaf = Path(__file__).resolve().parent / sys.argv[1]
path = leaf / 'native.log'
data = path.read_bytes()
observations = []
for line in data.decode('utf-8').splitlines():
    if 'ARCE_PLACEMENT_ENTRY ' not in line:
        continue
    header = re.search(r'ARCE_PLACEMENT_ENTRY subject=(\S+) phase=(\S+) frames=', line)
    assert header, line
    frames = [dict(type=kind, method=method, descriptor=descriptor, bci=int(bci))
              for kind, method, descriptor, bci in re.findall(
                  r'Caller\[type=(?:class|interface) ([^,]+), method=([^,]+), descriptor=([^,]+), bci=(-?\d+)\]', line)]
    assert 0 < len(frames) <= 16
    observations.append(dict(subject=header.group(1), phase=header.group(2), frames=frames))
result = dict(console_file='native.log', console_sha256=hashlib.sha256(data).hexdigest(),
              source=json.loads((leaf / 'results.json').read_text('utf-8'))['source'],
              observation_count=len(observations), observations=observations)
with (leaf / 'console-frames.json').open('x', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps(dict(source=result['source'], count=len(observations),
                     callers=[dict(subject=observation['subject'], phase=observation['phase'],
                                   game_mode=[(index, frame['bci']) for index, frame in enumerate(observation['frames'])
                                              if frame['type']=='net.minecraft.server.level.ServerPlayerGameMode'
                                              and frame['method']=='useItemOn']) for observation in observations])))
