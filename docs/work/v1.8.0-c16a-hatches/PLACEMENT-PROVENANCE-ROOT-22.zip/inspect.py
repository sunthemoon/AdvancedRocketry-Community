"""Retain bounded primary metadata and artifact-boundary observations, not native bodies."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = Path('D:/GitHub/arce-v180-placement-provenance-20261008')
JAR = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP = Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(TREE), *args]).decode('utf-8').strip()

members = ['net/minecraft/world/item/BlockItem.class', 'net/minecraft/world/item/ItemStack.class',
           'net/minecraftforge/registries/GameData$ItemCallbacks.class']
metadata = []
with zipfile.ZipFile(JAR) as archive:
    for name in members:
        info = archive.getinfo(name)
        assert info.file_size <= 512 * 1024
        metadata.append(dict(member=name, bytes=info.file_size, sha256=sha(archive.read(name))))
facts = []
commands = []
for name, selectors in [
    ('net.minecraft.world.item.ItemStack', ['public final class']),
    ('net.minecraft.world.item.BlockItem', ['registerBlocks', 'removeFromBlockToItemMap', 'Map.put']),
    ('net.minecraftforge.registries.GameData$ItemCallbacks', ['BlockItem.registerBlocks'])]:
    argv = [str(JAVAP), '-p', '-c', '-classpath', str(JAR), name]
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
    text = result.stdout.decode('utf-8')
    assert result.returncode == 0, result.stderr.decode('utf-8', errors='replace')
    selected = [line.strip() for line in text.splitlines() if any(word in line for word in selectors)]
    facts.append(dict(type=name, selected_scalars=selected))
    commands.append(dict(argv=argv, exit_code=result.returncode))
artifacts = []
for path in sorted((TREE / 'build/libs').glob('*.jar')):
    with zipfile.ZipFile(path) as archive:
        leaked = [name for name in archive.namelist() if 'arceadaptertest' in name or 'placement_probe' in name]
        assert not leaked, (str(path), leaked)
        artifacts.append(dict(name=path.name, sha256=sha(path.read_bytes()), fixture_entries=leaked))
inputs = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
          'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties']
result = dict(source=git('rev-parse', 'HEAD'), src_tree=git('rev-parse', 'HEAD:src'),
              native_archive=dict(path=str(JAR), bytes=JAR.stat().st_size, sha256=sha(JAR.read_bytes())),
              members=metadata, facts=facts, commands=commands, main_artifacts=artifacts,
              build_inputs={name: sha((TREE / name).read_bytes()) for name in inputs},
              official_references=['https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.html',
                                   'https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.StackFrame.html'])
output = ROOT / sys.argv[1]
with output.open('x', encoding='utf-8') as file:
    json.dump(result, file, indent=2)
    file.write('\n')
print(json.dumps(result))
