"""Seal the task's retained evidence and create a portable packet without source copies."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = Path('D:/GitHub/arce-v180-placement-provenance-20261008')
assert not (ROOT / 'SHA256SUMS.txt').exists()
for name, begin, end in [('original-source.patch','4ab2ef8e','5b48514e'),
                         ('mapping-correction.patch','5b48514e','7f5c5b18')]:
    data = subprocess.check_output(['git','-C',str(TREE),'diff','--binary',begin,end])
    with (ROOT/name).open('xb') as output:
        output.write(data)
paths = sorted(path for path in ROOT.rglob('*') if path.is_file())
assert all('/temp/' not in path.as_posix() for path in paths)
assert all(path.stat().st_size <= 50*1024**2 for path in paths)
assert sum(path.stat().st_size for path in paths) <= 100*1024**2
rows = [dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
             sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in paths]
manifest = ROOT/'retained-manifest.json'
manifest.write_text(json.dumps(dict(payloads=rows, payload_count=len(rows),
                                   payload_bytes=sum(row['bytes'] for row in rows)),indent=2)+'\n','utf-8')
paths.append(manifest)
(ROOT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+
                                path.relative_to(ROOT).as_posix()+'\n' for path in sorted(paths)), 'utf-8')
packet = ROOT.parent/'placement-provenance-root-20261008-01.zip'
with zipfile.ZipFile(packet,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():
            archive.write(path,path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(packet) as archive:
    assert archive.testzip() is None
    count = len(archive.namelist())
print(json.dumps(dict(packet=str(packet), sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),
                     bytes=packet.stat().st_size, entries=count,
                     payload_count=len(rows), payload_bytes=sum(row['bytes'] for row in rows))))
