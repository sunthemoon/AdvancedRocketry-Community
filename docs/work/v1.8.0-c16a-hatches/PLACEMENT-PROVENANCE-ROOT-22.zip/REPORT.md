# Native placement provenance qualification: Root evidence

2026-10-08. Base 4ab2ef8ec5a82e79b4244d92e89320848f4c0564;
original committed source 5b48514e4b8946316ac38b5485acfb6e5c5c56ea;
corrected committed source 7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e.
This is development-only native qualification, not physical hatch activation,
policy acceptance, content delivery or a Required Gate decision. No Claude.

Both complete Root cohorts pass clean build, twice DataGen/empty diffs,
ledger/provenance/whitespace and all 551 required native tests, including the
new three-case batch. Each native log retains 62 unwaived ERROR / zero FATAL.
Strict repository validation exits 1, 44 passing checks / one inherited link
failure; both full runners therefore exit 1. These are not wholly passing Gates.

Original build actually executes its test task, emitting 378 suites / 2,179
testcase nodes / zero F/E/S. Corrected build restores its test task FROM-CACHE;
do not describe that as execution. The separately retained corrected-unit-rerun
forces test --rerun-tasks --no-build-cache at the exact corrected SHA: exit 0,
17 tasks execute, 378 suites / 2,179 actual nodes / zero F/E/S.

Independent review finds an introduced Medium despite the original passing
cohort: inherited BlockItem registration overwrites the native chest-to-item
map. The correction opts the development probe out of both registration-map
callbacks and adds direct Item.byBlock(CHEST) assertions. No original assertion
is weakened. The independent corrected cohort and final review are separate
evidence; static map-write evidence is not a demonstrated chest-drop failure.

Ten actual bounded frame observations per native cohort occur in native.log
(System.out), not latest.log. The original summaries' empty latest-log field is
preserved; separate console-frames.json files bind extraction to console hashes.
Same actual UseOnContext reaches the first-use direct and later ordinary item
entries. Both have the game-mode ancestor, but direct USE observes index9/BCI128
and ordinary survival USE index4/BCI366; ordinary creative USE has BCI349.
At the actual pre-write placeBlock seam the selected cell is observed empty.
The direct call places a native chest and consumes one source; later ordinary
use returns non-consuming FAIL. This is a measured counterexample to equating
the outer result or shared context with a receipt, not an installed exploit.

Stack observations do not expose receivers/locals, authenticate the packet
wrapper or prove a packaged transformed whitelist. Three-site interception,
full admission/outcome, provisional LOAD/save/terminal joins, origin/Proto,
disposal/restart and O1/O2/O3 remain open. ADR-068 PROPOSED; R-021 OPEN.
Embedded native players are not real-client/packet/S1/S2/V1/V2 evidence.

Pinned mapped Forge archive/member hashes and scalar API inspection are in
initial-inspection.json and corrected-inspection.json. No native body or asset
enters production source. All three main JARs exclude the adapter fixture and
exactly match the previous baseline hashes. Java17.0.7, Gradle8.8, Forge47.4.10;
47.4.23 is not qualified. All commands use task-local temporary directories and
check C:/D: >=10GiB before sustained execution.

Initial PATH javap attempts cannot launch a binary; explicit JDK17 inspection
finds ItemStack final. The probe is a registered development BlockItem, not a
stack subclass. The separately retained independent launcher failure is not
a successful build or a source regression. Every original record stays intact.

Root cleanup succeeds once after absolute containment/ancestor/subtree reparse
and process checks; inventory in cleanup.json. Source checkout is retained.
Only new ended build/local .gradle/run-data/three TEMP trees are removed; no
old rejected target, input world, inherited work or sealed evidence is touched.
Logical inventory size is not a physical free-space measurement. No new task
disposable-output debt remains. Source HEAD/inputs are released after terminal
commands. C16-C19 and all v1.8 Required Gates remain unfinished.
