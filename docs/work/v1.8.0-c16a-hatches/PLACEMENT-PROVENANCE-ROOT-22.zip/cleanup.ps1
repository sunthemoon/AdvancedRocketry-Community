$ErrorActionPreference = 'Stop'
$source = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-placement-provenance-20261008')
$evidence = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/placement-provenance-root-20261008-01')
if (Test-Path -LiteralPath (Join-Path $evidence 'cleanup.json')) { throw 'Cleanup record already exists; no retry' }
$running = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^(java|javaw|python)\.exe$' -and
    ($_.CommandLine.Contains($source) -or $_.CommandLine.Contains($evidence) -or
     $_.CommandLine.Contains($source.Replace('\','/')) -or $_.CommandLine.Contains($evidence.Replace('\','/')))
})
if ($running.Count -ne 0) { throw 'Owned task processes remain active' }
$targets = @(
    (Join-Path $source 'build'), (Join-Path $source '.gradle'), (Join-Path $source 'run-data'),
    (Join-Path $evidence 'cohort-01/temp'), (Join-Path $evidence 'cohort-02/temp'),
    (Join-Path $evidence 'corrected-unit-rerun/temp')
)
$inventory = @()
foreach ($target in $targets) {
    $absolute = [IO.Path]::GetFullPath($target)
    if (-not ($absolute.StartsWith($source + '\', [StringComparison]::OrdinalIgnoreCase) -or
              $absolute.StartsWith($evidence + '\', [StringComparison]::OrdinalIgnoreCase))) { throw 'Outside owned roots' }
    if (-not (Test-Path -LiteralPath $absolute)) { continue }
    $resolved = (Resolve-Path -LiteralPath $absolute).ProviderPath
    if (-not $resolved.Equals($absolute, [StringComparison]::OrdinalIgnoreCase)) { throw 'Resolved path differs' }
    $ancestor = Get-Item -LiteralPath $absolute -Force
    while ($null -ne $ancestor) {
        if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Ancestor reparse point' }
        $ancestor = $ancestor.Parent
    }
    $items = @(Get-ChildItem -LiteralPath $absolute -Recurse -Force)
    if (@($items | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count) {
        throw 'Subtree reparse point'
    }
    $files = @($items | Where-Object { -not $_.PSIsContainer })
    $bytes = ($files | Measure-Object -Property Length -Sum).Sum
    $inventory += [pscustomobject]@{ path=$absolute; files=$files.Count; logical_bytes=[long]$bytes; existed=$true }
}
$record = [ordered]@{ utc=(Get-Date -AsUTC -Format o); inventory=$inventory; result='preflight-complete'; source_checkout_retained=$true }
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidence 'cleanup-preflight.json') -Encoding utf8
foreach ($item in $inventory) { Remove-Item -LiteralPath $item.path -Recurse -Force }
foreach ($item in $inventory) { if (Test-Path -LiteralPath $item.path) { throw 'Target survived removal' } }
$record.result = 'single-native-attempt-success'
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidence 'cleanup.json') -Encoding utf8
$record | ConvertTo-Json -Depth 6
