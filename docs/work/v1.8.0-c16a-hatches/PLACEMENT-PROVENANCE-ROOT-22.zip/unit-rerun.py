"""Force actual corrected-source JUnit execution; retain cache-derived cohort XML separately."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = Path('D:/GitHub/arce-v180-placement-provenance-20261008')
JDK = Path('C:/Program Files/Java/jdk-17.0.7')
LEAF = ROOT / 'corrected-unit-rerun'
LEAF.mkdir()
TEMP = LEAF / 'temp'
TEMP.mkdir()
source = subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', 'HEAD']).decode().strip()
assert source == '7f5c5b1802e5d63a26a306c7ec8e1a1d49b6865e'
assert not subprocess.check_output(['git', '-C', str(TREE), 'status', '--porcelain'])
free = {drive: shutil.disk_usage(drive).free for drive in ('C:/', 'D:/')}
assert all(value >= 10 * 1024**3 for value in free.values())
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + os.environ['PATH'],
           TEMP=str(TEMP), TMP=str(TEMP), TMPDIR=str(TEMP),
           JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + TEMP.as_posix())
argv = [str(Path('C:/Windows/System32/cmd.exe')), '/d', '/c', 'gradlew.bat', 'test',
        '--rerun-tasks', '--no-build-cache', '--no-daemon', '--offline']
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (LEAF / 'test.log').open('xb') as output:
    command = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                             stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
totals = dict(tests=0, failures=0, errors=0, skipped=0)
nodes = 0
files = sorted((TREE / 'build/test-results/test').glob('TEST-*.xml'))
with zipfile.ZipFile(LEAF / 'unit-xml.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        tree = ET.parse(path).getroot()
        nodes += len(tree.findall('testcase'))
        for key in totals:
            totals[key] += int(tree.get(key, '0'))
        archive.write(path, path.name)
log = (LEAF / 'test.log').read_bytes()
result = dict(source=source, argv=argv, cwd=str(TREE), started_utc=start,
              ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), free_bytes=free,
              exit_code=command.returncode, log_sha256=hashlib.sha256(log).hexdigest(),
              unit_suites=len(files), unit_totals=totals, actual_testcase_nodes=nodes,
              test_task_lines=[line for line in log.decode('utf-8').splitlines() if line.startswith('> Task :test')])
(LEAF / 'results.json').write_text(json.dumps(result, indent=2) + '\n', 'utf-8')
print(json.dumps(result))
raise SystemExit(command.returncode)
