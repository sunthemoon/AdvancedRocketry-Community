# Root native LOAD-order development verification

Date: 2026-10-08. Actual corrected source:
3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b.
Base: 355766c6841137c8e8b5977be1fc3e25bc074fa7.
Source tree: 3a9ae41d52b04d47db0d0f5b29ce97803757aaef.
This is test-side development evidence, not physical hatch or release acceptance.

## Completed scope and design

Two new required native GameTests use ordinary chest Item placement through
ServerPlayerGameMode.useItemOn in SURVIVAL and CREATIVE. They assert consistent
player/game-mode abilities, installed registered ChestBlockEntity identity,
source stack identity/count/tag, absence from both fresh-owner queues, empty
native saveWithFullMetadata with exact ID/position before a tick, and retained
identity/queue absence after a naturally scheduled subsequent tick.

Each fixture owns two already-loaded, BE-free cells, one plain native ServerPlayer
and one EmbeddedChannel. Terminal pass/failure/timeout and synchronous failure
cleanup restore captured cells, unregister only the exact owned player and
release the owned channel. Reflection only reads native queues/testInfo; each
queue observation has a 4,096-entry cap. No synthetic onLoad, queue writes,
chunk tickets, new registration, source cap or production behavior is introduced.
Cell-restoration boolean/equality and exceptional terminal cleanup are reviewed,
not independently fault-injected or broad restoration proof.

Pinned mapped Forge 47.4.10 native JAR SHA-256:
95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e.
Native identity and three bounded class-member hashes are in native-identity.json;
the same JAR/member bytes are reverified after execution by audit.py.
LevelChunk.setBlockState calls addAndRegisterBlockEntity for a fresh owner;
the latter installs it and, when isInLevel is true, invokes onLoad directly at
bytecode offset 41. Whole-chunk registerAllBlockEntitiesAfterLevelLoad instead
queues owners through Level.addFreshBlockEntities for tickBlockEntities.
These are distinct routes. Queue absence alone does not instrument onLoad;
the synchronous dispatch conclusion joins the pinned bytecode and exercised
normal in-Level placement route, not a callback trace from an installed hatch.

In the unchanged ClassicHatchBlockEntity, prepareLoaded opens one fresh LOAD
ticket and recordCompletedLoad opens a second during that invocation. These
are two tickets, not two native callbacks/ticks. Only LOAD-BINDING-20's normal
in-Level scheduling concern U2 is qualified here. Neither successful hatch
LOAD tickets, authentic invocation provenance, provisional predicates,
availability fencing nor callback-free terminal publication is established.
The unmerged draft 932600d9 and prior sealed evidence are unchanged.

## Actual commands and results

Java 17.0.7, Gradle 8.8 and task-local TEMP/TMP/java.io.tmpdir were used with
offline caches. Both drives exceeded 10 GiB before every sustained command.
Exact argv, timestamps, raw logs and log hashes are in each commands.json.

| Corrected cohort-02 command | Result |
|---|---|
| gradlew.bat clean build --no-daemon --offline | exit 0; :test executed |
| Parsed JUnit XML | 378 suites / 2,179 actual testcase nodes; zero F/E/S |
| gradlew.bat runData --no-daemon --offline, twice | exits 0 / 0 |
| git diff --exit-code after each DataGen | exits 0 / 0; empty |
| python -B scripts/validate_v180_content_ledger.py --require-accepted | exit 0 |
| python -B scripts/validate_bootstrap_provenance.py | exit 0 |
| python -B scripts/validate_repository.py --require-approved-identity | exit 1; 44 pass / one inherited Markdown-link failure |
| git diff --check | exit 0 |
| gradlew.bat runGameTestServer --no-daemon --offline | exit 0; all 548 required tests pass |

Native completes at 2026-10-08T11:34:42.190684+00:00. The new two-test batch
is present; no terminal failure occurs. Latest log retains 62 unwaived ERROR
headers and zero FATAL. The runner's overall exit 1 reflects strict repository
validation, not build/native failure. AUDIT.json independently reparses archived
unit XML and complete native terminals and verifies all recorded command hashes.
The source HEAD remains pinned and the task worktree is clean throughout.

Main development JAR SHA-256:
dd93cb968430eba12fb13539bbdfb29e943af1f16a6b6a8ebb3257a14d9a6b87.
API JAR: aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b.
Sources JAR: ed57d4d0923c1571b421979a8e6068165b70dc048b755b8d8bdd8faf1c27d2a9.
These are development artifacts, not packaged S1 or a frozen release candidate.

## Preserved original failure

Original committed candidate 673ef97f4f1c19d1bfa6497b7709770e1d09aa28 passes
clean build/2,179 units/twice DataGen and the same static checks except strict
links. Its complete native cohort exits 1: 548 complete, exactly the two new
cases fail because GameTestHelper's login Connection has no Channel at pipeline
access. Placement assertions are not reached. Latest log has 64 ERROR / zero
FATAL. All original logs/XML/results/commands remain unchanged in cohort-01.
This is a fixture failure, not negative evidence about LOAD scheduling.

The corrected source uses an owned EmbeddedChannel and a plain ServerPlayer
instead of that helper, also removing the helper's unconditional creative
override. Existing tests/assertions/deadlines/budgets are unchanged; mode
consistency assertions are added. No historical product failure is erased or
uniquely attributed. A separate independent Codex review/rerun packet records
its own source findings and actual outcomes. No Claude call is made.

## Cleanup, unfinished scope and risks

One native PowerShell cleanup attempt succeeds, exit 0, after ended-process,
absolute containment and ancestor/subtree reparse checks. It removes only this
task's build, local .gradle, run-data and two cohort TEMP directories: 272,137,479
logical bytes inventoried before deletion. Source worktree and retained evidence
remain. No earlier refused target, other agent output, source/input/prior world,
global cache or user AGENTS.md is deleted. This does not close inherited cleanup
debt. cleanup-before.json, cleanup-result.json and the exact script/log are retained.

No actual packet or connected real client, registered physical hatch, guarded
save consumer, writer/disposal/restart, Proto/generated origin, crash atomicity,
prior-world migration, natural installed machine continuation, V1/V2, progression
or performance acceptance is established. U1/U3-U7, O1/O2/O3, both Medium
physical-admission prerequisites, ADR-068 PROPOSED and R-021 OPEN remain.
The ledger stays 186 PLANNED /154 REVIEW assets; C16-C19 remain unfinished.
All v1.8 Required Gates remain open. Continue the coupled current-version
authentic placement/outcome and provisional LOAD/save/terminal contract, not v1.9.
