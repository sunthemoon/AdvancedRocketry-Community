$ErrorActionPreference = 'Stop'
$tree = [IO.Path]::GetFullPath('D:\GitHub\arce-v180-hatch-load-order-20261008')
$leaf = [IO.Path]::GetFullPath('D:\GitHub\ARCE-Task-Evidence\v1.8.0\hatch-native-load-order-root-20261008-01')
foreach ($root in @($tree, $leaf)) {
    $ancestor = Get-Item -LiteralPath $root -Force
    while ($null -ne $ancestor) {
        if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Scope ancestor is a reparse point.' }
        $ancestor = $ancestor.Parent
    }
}
$targets = @(
    [IO.Path]::Combine($tree, 'build'),
    [IO.Path]::Combine($tree, '.gradle'),
    [IO.Path]::Combine($tree, 'run-data'),
    [IO.Path]::Combine($leaf, 'cohort-01', 'temp')
    [IO.Path]::Combine($leaf, 'cohort-02', 'temp')
)
$running = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^(java|javaw|python)\.exe$' -and
    ($_.CommandLine -like "*$tree*" -or $_.CommandLine -like "*$leaf*")
})
if ($running.Count -ne 0) { throw 'Owned commands are still running; no deletion attempted.' }
$rows = @()
foreach ($target in $targets) {
    $absolute = [IO.Path]::GetFullPath($target)
    $expected = $absolute.StartsWith($tree + '\', [StringComparison]::OrdinalIgnoreCase) -or
        $absolute -eq [IO.Path]::Combine($leaf, 'cohort-01', 'temp') -or
        $absolute -eq [IO.Path]::Combine($leaf, 'cohort-02', 'temp')
    if (-not $expected) { throw "Target is outside the declared disposable scope: $absolute" }
    if (-not (Test-Path -LiteralPath $absolute)) { continue }
    $item = Get-Item -LiteralPath $absolute -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Root reparse point.' }
    $children = @(Get-ChildItem -LiteralPath $absolute -Force -Recurse)
    if (@($children | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count) {
        throw 'Disposable subtree has a reparse point; no deletion attempted.'
    }
    $files = @($children | Where-Object { -not $_.PSIsContainer })
    $rows += [PSCustomObject]@{ path = $absolute; files = $files.Count; logical_bytes = ($files | Measure-Object Length -Sum).Sum }
}
$rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-before.json') -Encoding utf8
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
}
$remaining = @($targets | Where-Object { Test-Path -LiteralPath $_ })
if ($remaining.Count) { throw "Some own outputs remain: $remaining" }
'Removed only this task''s five ended disposable output directories.'
