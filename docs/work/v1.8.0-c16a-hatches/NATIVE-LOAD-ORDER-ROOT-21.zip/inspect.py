"""Read pinned mapped native bytecode for lifecycle scheduling and fixture APIs."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
JAR = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
JAVAP = "C:/Program Files/Java/jdk-17.0.7/bin/javap.exe"
targets = {
    "net.minecraft.world.level.Level": ["addFreshBlockEntities(", "tickBlockEntities(", "lambda$tickBlockEntities"],
    "net.minecraft.world.level.chunk.LevelChunk": ["addAndRegisterBlockEntity(", "registerAllBlockEntitiesAfterLevelLoad(", "setBlockEntity(", "setBlockState("],
    "net.minecraft.gametest.framework.GameTestHelper": ["makeMockServerPlayerInLevel("],
}
output = []
for name, methods in targets.items():
    raw = subprocess.check_output([JAVAP, "-p", "-c", "-classpath", str(JAR), name], text=True)
    output.append("CLASS " + name)
    sections = []
    for line in raw.splitlines():
        if line.startswith("  ") and not line.startswith("    ") and line.rstrip().endswith(";"):
            sections.append([line])
        elif sections:
            sections[-1].append(line)
    selected = ["\n".join(section) for section in sections if any(method in section[0] for method in methods)]
    assert selected, name
    output.extend(selected)
text = "\n\n".join(output) + "\n"
(HERE / "native-bytecode.txt").write_text(text, "utf-8")
members = {}
with zipfile.ZipFile(JAR) as archive:
    for name in targets:
        member = name.replace(".", "/") + ".class"
        assert archive.getinfo(member).file_size <= 512 * 1024
        content = archive.read(member)
        members[member] = {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
(HERE / "native-identity.json").write_text(json.dumps({"jar": str(JAR), "sha256": hashlib.sha256(JAR.read_bytes()).hexdigest(), "classes": targets, "members": members}, indent=2) + "\n", "utf-8")
print(text)
