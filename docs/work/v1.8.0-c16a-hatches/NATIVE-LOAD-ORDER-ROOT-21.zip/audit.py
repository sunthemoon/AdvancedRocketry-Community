"""Read retained exact-source results; never alter sealed packets or native inputs."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
COHORT = ROOT / "cohort-02"
PIN = "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"
results = json.loads((COHORT / "results.json").read_text("utf-8"))
assert results["source"] == PIN and results["head_unchanged"] and results["clean"]
assert len(results["commands"]) == 11
for record in results["commands"]:
    log = COHORT / (record["name"] + ".log")
    assert hashlib.sha256(log.read_bytes()).hexdigest() == record["log_sha256"]
    assert record["source"] == PIN
    assert all(value >= 10 * 1024 ** 3 for value in record["free_bytes"].values())
assert all(record["exit_code"] == (1 if record["name"] == "repository" else 0)
           for record in results["commands"])
with zipfile.ZipFile(COHORT / "unit-xml.zip") as archive:
    assert archive.testzip() is None
    trees = [ET.fromstring(archive.read(name)) for name in archive.namelist()]
    actual = sum(len(tree.findall("testcase")) for tree in trees)
    totals = {key: sum(int(tree.get(key, "0")) for tree in trees)
              for key in ("tests", "failures", "errors", "skipped")}
assert totals == results["unit_totals"] and actual == results["actual_testcase_nodes"]
native = (COHORT / "native-latest.log").read_text("utf-8")
terminal = re.findall(r"All (\d+) required tests passed", native)
assert len(terminal) == 1 and not results["native_failure_lines"]
assert len(results["native_probe_batches"]) == 1
repository = (COHORT / "repository.log").read_text("utf-8")
identity = json.loads((ROOT / "native-identity.json").read_text("utf-8"))
jar = Path(identity["jar"])
assert hashlib.sha256(jar.read_bytes()).hexdigest() == identity["sha256"]
with zipfile.ZipFile(jar) as archive:
    for name, expected in identity["members"].items():
        value = archive.read(name)
        assert len(value) == expected["bytes"]
        assert hashlib.sha256(value).hexdigest() == expected["sha256"]
summary = dict(source=PIN, src_tree=results["src_tree"], unit_suites=len(trees),
               actual_unit_nodes=actual, unit_totals=totals,
               required_native_passed=int(terminal[0]),
               new_batch=results["native_probe_batches"],
               native_error_headers=results["native_error_headers"],
               native_fatal_headers=results["native_fatal_headers"],
               native_identity_unchanged=True, artifacts=results["artifacts"],
               repository_terminal=repository.splitlines()[-2:])
original = json.loads((ROOT / "cohort-01/results.json").read_text("utf-8"))
assert original["source"] == "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"
assert original["head_unchanged"] and original["clean"]
assert len(original["native_failure_lines"]) == 2
assert all("Connection.channel()" in line for line in original["native_failure_lines"])
for record in original["commands"]:
    log = ROOT / "cohort-01" / (record["name"] + ".log")
    assert hashlib.sha256(log.read_bytes()).hexdigest() == record["log_sha256"]
summary["retained_original_native_failure"] = original["native_terminal_lines"]
(ROOT / "AUDIT.json").write_text(json.dumps(summary, indent=2) + "\n", "utf-8")
print(json.dumps(summary, indent=2))
