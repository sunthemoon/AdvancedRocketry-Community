"""Seal the new compact retained Root packet exactly once."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
assert not (ROOT / "SHA256SUMS.txt").exists()
audit = json.loads((ROOT / "AUDIT.json").read_text("utf-8"))
assert audit["source"] == "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"
assert audit["required_native_passed"] == 548 and audit["native_identity_unchanged"]
assert json.loads((ROOT / "cleanup-result.json").read_text("utf-8"))["status"] == "SUCCESS"
(ROOT / "source.patch").write_bytes(subprocess.check_output([
    "git", "--no-optional-locks", "-C", "D:/GitHub/arce-v180-hatch-load-order-20261008",
    "diff", "--binary", "355766c6841137c8e8b5977be1fc3e25bc074fa7", audit["source"]]))
files = [path for path in ROOT.iterdir() if path.is_file()]
for cohort in ("cohort-01", "cohort-02"):
    files.extend(path for path in (ROOT / cohort).iterdir() if path.is_file())
assert sum(path.stat().st_size for path in files) < 100 * 1024 ** 2
assert all(path.stat().st_size < 50 * 1024 ** 2 and not path.is_symlink() for path in files)
manifest = "".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  "
                   + path.relative_to(ROOT).as_posix() + "\n" for path in sorted(files))
with (ROOT / "SHA256SUMS.txt").open("x", encoding="utf-8", newline="\n") as output:
    output.write(manifest)
print(json.dumps(dict(payloads=len(files), bytes=sum(path.stat().st_size for path in files),
                     manifest_sha256=hashlib.sha256((ROOT / "SHA256SUMS.txt").read_bytes()).hexdigest())))
