# Independent revision review: coupled empty-hatch candidate 23

Date: 2026-10-08. Reviewer: delegated read-only independent Codex.
Fixed source/base: `a01703366c51a0e06788b95a1793b312dfa8a9a4`.
Reviewed object: complete revision2 candidate and matrix, compared with the
original sealed reviewed bytes/report. This is not a runtime implementation.

## Findings, ordered by severity

No new introduced contract finding is demonstrated by this focused revision
review. The original M1/M2/L1 are addressed at the **draft specification**
level, as detailed below. This is not closure of the two earlier full physical
assignment prerequisites, nor evidence that the proposed mechanisms execute.
The complete design remains PROPOSED, not frozen or source-assignment-ready.

## Original-finding dispositions

### M1 - Addressed in the draft; execution remains unverified

[Candidate lines 176-201](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L176)
now explicitly transfers the successful second LOAD's actual temporary
`LoadJoinCandidate` identities into a distinct immutable
`OperationCompletedLoadReceipt`, owned by the selected operation and also
referenced opaquely by the owner. The provisional success predicate uses that
receipt and the still-current second LOAD before ticket closure, not
`storage.available()` or premature installation.

Normal `prepareLoaded` finally cleanup clears only temporary candidate/preparing
fields. Completed-receipt validation does not call `loadJoinStillCurrent` or
require those temporary fields. Later retirement/`clearLoadJoin`, replacement,
checkpoint/encoding/lifetime/epoch change or explicit receipt withdrawal still
prevents publication. Lifetime is captured after initial native `onLoad`
retirement, rather than treating the allocation identity as a lifetime bypass.

This resolves the original contradiction against
[fixed-source hatch lines 97-115](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicHatchBlockEntity.java#L97).
[Matrix P5/P7](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-VERIFICATION-MATRIX-23.md#L28)
requires positive terminal publication after normal finally cleanup and negative
actual invalidation cases. None has run for the proposed receipt.

### M2 - Addressed in the draft; actual handler transitions remain unverified

[Candidate lines 63-99](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L63)
separates the Level invocation slot from selected-cell state. Placement's
literal outer `useItemOn` starts once, enters `DELEGATING_UNSELECTED`, then
selects at the real inner pre-write seam without another outer delegation.
The selected-cell IDLE row expressly permits that unselected Level invocation.
Removal instead prepares before its one original `destroyBlock` call.

No-selection return/throw releases only the Level slot while preserving native
result/throwable and ordinary saves. Preselection nesting permanently taints
that invocation and cannot grant later authority; selected uncertainty remains
a different terminal case. Every selected path releases both held scopes in
outer finally. No second placement-context computation is introduced.
[Matrix P24](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-VERIFICATION-MATRIX-23.md#L47)
contains these distinct positive/negative transition requirements. The pinned
native call flow supports the ordering, not an execution claim about the future
redirect or owned adapters.

### L1 - Corrected at the exact native pin

[Candidate lines 126-132](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L126)
and [matrix P2](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-VERIFICATION-MATRIX-23.md#L25)
now name `updatePlacementContext(BlockPlaceContext) -> BlockPlaceContext`.
Fresh explicit JDK17 disassembly confirms that `BlockItem.place` invokes that
method at BCI 34, stores its returned context at BCI 37 and passes that same
local to `placeBlock` at BCI 63. The pinned class contains no
`getPlacementContext` member. Its 19,126 bytes and SHA-256
`2b3e1defc87df357543458f44516b32b7519bb42746690fc24cee8ba6db4defc`
match the original independent inspection. No old historical record is rewritten.

## Complete resulting design and remaining prerequisites

The added
[local publication requirement](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-CONTRACT-23.md#L203)
appropriately distinguishes the proposed terminal from existing
[ClassicOwnerState.installed lines 45-47](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicOwnerState.java#L45),
which calls `owner.isRemoved()`. The new primitive must compare captured/local
owner/storage/receipt/epoch fields under the same coherent tail and expose
availability last. Its locking, source and callback exclusion are still
unimplemented/unverified. A prose prohibition is not a proved atomic tail.

The unmodified rest of the resulting contract preserves the required whole
operation rather than substituting an unused helper:

- Authentic ordinary entry, exact owned allocation and gap-free transformed
  frame/call-site profile remain technical prerequisites. Qualification22's
  shared context/raw ancestors do not authenticate them. The exact three native
  invocation counts are static facts, not transformed coverage. Mixin dependency,
  AP/refmap, descriptors, multiplicity/conflict and protection-failure behavior
  remain unqualified.
- The new birth must change both `ClassicLoadedWorld.installed` and
  `GuardTicket.acquire` through the same exact private provisional predicate.
  Current source still requires ordinary origin observation; the current second
  LOAD still installs availability early. Ordinary disk/pending owners must not
  inherit provisional suppression or weakened comparison.
- Both save consumers are necessary: genuine birth handling before inherited
  owner serialization/EMIT, and late sticky-before-transient chunk deferral
  outside the ordinary exception-to-permanent-denial conversion. Unknown,
  nonbirth, stale or already-protected owners cannot borrow the hold. Immutable
  origin remains distinct from the one-row revised current expectation.
- Source/tool/drop seams, exact quantity/metadata/capability policy and numeric
  shape/work/count bounds remain OPEN. Existing resource codecs invoke native
  serialization and gameplay/LOAD predicates; their post-result envelopes are
  not general preallocation/time limits or post-retirement outcome witnesses.
  Ordinary tools/sources cannot silently become bare-hand/tag-free subsets.
- Disk FULL capture is supported by the observed native event. Authentic disk
  Proto-to-FULL transfer and completed generated origin, including copied live
  and pending owners, remain missing bindings. Coordinates, attachment emptiness,
  `isNewChunk`, timeouts or outgoing NBT cannot replace them. The full scope is
  not reduced to previously observed FULL chunks.
- Ordinary unload establishes Unload event, attempted save with discarded
  boolean, then native BE clearing. It does not prove durable success, shutdown,
  final writer, provider survival, other-listener invalidation or abnormal-stop
  handling. Retention/disposal and actual restart/store-cut tests remain required.
- O1/O2/O3 still lack recorded adoption. ADR-068 remains PROPOSED; R-021 remains
  OPEN. Exact refusal scope/duration/log cap/recovery, hook-loss behavior and
  cross-store conservation scope need owner disposition and independent review.
  Native return/throw preservation and synchronous holds do not provide
  chunk/player/drop crash atomicity or authorize refunds/journals.

These are retained declared prerequisites, not newly observed product defects.
The two Medium prerequisites in
[PRIVATE-OPERATION-REVIEW-01](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/PRIVATE-OPERATION-REVIEW-01.md)
remain open regardless of the three draft-finding dispositions.
[Matrix lines 49-58](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-hatches/COUPLED-VERIFICATION-MATRIX-23.md#L49)
now distinguishes implementable reviewed assignment design from actual integrated
activation proofs. All P1-P24 remain OPEN/NOT_RUN; the clarification is not a
claim of either phase's completion.

## Exact inputs, original/new diffs and preservation

| Input | SHA-256 |
| --- | --- |
| Complete revision2 candidate | `4749db7b3931a6ca98efdb8c98f4deaecefeb0f2a1e0ea6114a78ff7869f5d5a` |
| Complete revision2 matrix | `8e4a78463a1c7da138810dc690784cce0d41582413a42669c043c2c4bd8a19b2` |
| Original complete candidate | `ce353fb442edd2610d01a730127c41345f10e9fa6b8b9736df3831685ff91159` |
| Original complete matrix | `d5a79dee8bd87e1eed8cacded1a9aec5b3b2909adf298ca343637c502e441323` |
| Original independent REPORT | `9e363684b564261f6ddf2a32c734c9bd42546eba9bb2af28d813a8db57b99d18` |
| Original sealed evidence manifest | `78e6ba371d9bf92f70cd8f5870ced15e5dbb5704ce3fb6c17d2e479eaafc6fd9` |
| Mapped Forge47.4.10 JAR | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Bundled Mixin0.8.5 JAR | `ca15a907e4d1f6b38cefed51d7df96a83347dcfb0bc8ced53111519e991d887d` |

Full current/original draft snapshots and original report are retained under
`inputs/`; original-to-revision2 unified diffs are under `diffs/`. `input-pins.json`
records 35 named inputs, including applicable governance, v1.0 acceptance cursor,
v1.8 active development/ADR-060, private owner/qualification/risk records.
`fixed-source-pins.json` records 16 Git path/blob/content identities. Source is
read from the fixed Git objects and kept only as pins/bounded excerpts, not a
full source export or cache. `native-identities.json` pins 18 named members,
each below 512 KiB, and their newly generated disassembly outputs.

Every original enumerated payload and checksum validates: **137 payloads /138
checksum rows**, including its manifest controller. The original sealed leaf
and Root primary files are not changed. Final rechecks find 34/35 named inputs
unchanged. Only Root's concurrently updated disposition changes from
`468f329a32668a079e97380df9c8827bc881ac1b06c9457663b3a20bdaa5800f`
to `0ac364f24c2ca81524e7e1147cebd05a19ab5527b9e5fadd1fbd45a0e81691fb`.
The candidate/matrix, all 16 fixed source pins, both archives and all named Root
primary inputs remain unchanged. HEAD/index/status display also remain
unchanged. This is qualified input drift, not a reviewer repository write or
a claim of zero total working-tree changes.

## Commands actually executed and results

The three script commands below use `python -B` and this new absolute evidence
leaf. Exact child argv/working directories/exit codes/timestamps are in
`commands-inputs-native.json`, `commands-static-source*.json` and
`commands-final-controls.json`; top-level observed results are in
`launch-results.json`. Read-only PowerShell/`rg` exploration is described in
`INSTRUMENTATION.md` and the chat, not represented as a build/test run.

| Actual check | Result |
| --- | --- |
| `python -B review_inputs.py` | Exit 0; original 137-payload/138-row seal verified; 16 fixed-source pins and 18 native member pins match. |
| Explicit `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -p -c -s -classpath <pinned JAR> <named member>` | All 18 commands exit 0; all newly generated outputs byte-identical to original independent outputs. |
| `python -B check_revision.py` | Exit 1; 39/40. Newly added LOAD count was incorrectly class-wide; first script/results retained. |
| `python -B check_revision_r2.py` | Exit 0; 40/40 after method-bounded count correction. 18 native facts, 12 source facts, 7 draft-coverage and 3 hygiene checks; no runtime proof. |
| `python -B final_controls.py` | Exit 0; 16 source pins, both archives, HEAD/index and named Root input hashes stable; one disclosed Root disposition change. |
| Read-only `git status --short`, `branch --show-current`, `rev-parse HEAD`, `worktree list`, `show`, `diff` and source blob `rev-parse` | Fixed reads completed; original dirty work remains untouched. |
| `git diff --check`, initial and final | Exit 0; empty outputs. |
| `git diff --exit-code -- src build.gradle settings.gradle gradle.properties gradle` | Exit 0; empty source/build diff. Not a DataGen run or generated-resource proof. |
| Draft UTF-8/trailing-whitespace/local-link checks | Exit 0 as part of 40/40; both complete drafts decode without replacement characters, no trailing-space lines, all current local links resolve. |

The failed new count instrument counted LOAD acquisitions in retained checkpoint
revalidation/raw installed loading as well as the two fresh methods. The corrected
selector counts only `prepareLoaded`/`recordCompletedLoad`; fresh checkpoint-null
birth bypasses retained revalidation. No target assertion, native behavior,
timeout or source was changed. Nonexistent exploratory filename reads and one
directory-name display error are disclosed in `INSTRUMENTATION.md`; they are
not product findings or silently successful commands.

### Prior validator attribution, not revision2 execution

No ledger, bootstrap provenance or full strict validator is rerun in this focused
revision review. The original sealed independent runs retain their actual
timestamps/commands/hashes in `prior-validation-attribution.json`:

- Ledger: 2026-10-08 14:12:15 UTC, exit 0, 653 units /186 PLANNED /154 REVIEW
  assets. Bootstrap provenance: 14:12:15-14:12:43 UTC, exit 0.
- Unchanged strict validator: 14:16:27-14:21:23 UTC, exit 1, 44 PASS /one
  inherited broken-link check. Its original log SHA-256 is
  `32d28fc9a5553bcddde509311b80211680210e3208bda7d76f402a2b181baf53`.
  The original arbitrary 180-second launcher timeout and Root's separately
  attributed validator/selector failures remain in their sealed records.

These are **prior runs**, not fresh checks of revision2 or a newer Gate result.
Qualifications 21/22 likewise remain associated with their recorded tested
source SHAs; their native/JUnit counts are not rebound to this draft.

## Completion scope, proof limits, files and release

Completed: independent actual-draft revision review, original/new snapshot/diff
retention, original seal verification, fresh bounded fixed-source/native/static
checks and finding dispositions. New tests are only the local static review
controls; no repository runtime test is added/modified.

Not completed/NOT_RUN: Gradle clean build/test/runData/generated empty diff/
runGameTestServer, native game/server, transformation/package/player paths,
restart/S2, V1/V2, performance/long-load and release rebuild. None is
NOT_APPLICABLE. Technical/policy prerequisites and all v1.8 G0-G9 remain open;
this review satisfies no complete Required Gate and authorizes no source
assignment, physical writer, hook, dependency, schema, ledger delivery or risk
acceptance.

Reviewer-created files are only TASK-adjacent REPORT/scripts/logs, draft/report
snapshots, original/new diffs, bounded excerpts, pins/results/manifests in this
NEW independent leaf. Repository/index/HEAD/source/build/config, other
worktrees, sealed originals, Root inputs and player/world data are read-only.
No subagent, Claude, OpenPet, game process or disposable source/server/build
directory is created; no cleanup is performed. Root coordinates progress.

The new seal uses only an explicit enumerated payload list with an in-package
`evidence-manifest.json` and `SHA256SUMS.txt`; no full source/tree ZIP. The
manifest records actual file/count/byte/hash budgets. Old evidence is never
resealed or amended. Evidence location:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-revision-independent-20261008-01`.

Recommended next action stays in current v1.8: retain both independent reviews,
then resolve the complete coupled technical bindings and O1/O2/O3/final
ADR/risk prerequisites before any physical source assignment. After authorized
inactive implementation, obtain actual transformed/native/package/player/save/
restart proofs before activation. Do not assign an unused helper or infer
readiness from the three corrected drafting issues.

All owned commands have ended. Final HEAD is
`a01703366c51a0e06788b95a1793b312dfa8a9a4`. This reviewer **releases all
repository, HEAD, draft, source and native-input read interests**; Root may
proceed after retaining this report/payload. No write/commit/HEAD interest is held.
