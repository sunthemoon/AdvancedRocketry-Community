"""Bounded static facts; this script does not execute the candidate operation."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
assert not (LEAF/'SHA256SUMS.txt').exists()
checks = []
commands = []
excerpts = []

def check(name, condition, kind, evidence=''):
    checks.append({'id':name,'passed':bool(condition),'kind':kind,'evidence':evidence})

def method(filename, header):
    text = (LEAF/'native'/filename).read_text(encoding='utf-8')
    parts = re.split(r'(?m)(?=^  (?:public|private|protected|static)[^\n]*\([^\n]*\);\r?$)', text)
    matches = [p for p in parts if p.splitlines()[0].strip()==header]
    assert len(matches)==1, (filename,header,len(matches))
    return matches[0]

def calls(body, suffix):
    return [line.strip() for line in body.splitlines() if suffix in line and re.search(r'\binvoke',line)]

def selected(body, fragments):
    return '\n'.join(line for line in body.splitlines() if any(f in line for f in fragments))

lc = method('LevelChunk-javap.txt','public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.world.level.Level, net.minecraft.world.level.ChunkPos, net.minecraft.world.level.chunk.UpgradeData, net.minecraft.world.ticks.LevelChunkTicks<net.minecraft.world.level.block.Block>, net.minecraft.world.ticks.LevelChunkTicks<net.minecraft.world.level.material.Fluid>, long, net.minecraft.world.level.chunk.LevelChunkSection[], net.minecraft.world.level.chunk.LevelChunk$PostLoadProcessor, net.minecraft.world.level.levelgen.blending.BlendingData);')
check('LevelChunk exact carrier and gather','37: ldc' in lc and '// class net/minecraft/world/level/chunk/LevelChunk' in lc and 'AsField' in lc and '153: invokevirtual' in lc,'static_native',selected(lc,['37:','AsField','153:']))
proto = method('LevelChunk-javap.txt','public net.minecraft.world.level.chunk.LevelChunk(net.minecraft.server.level.ServerLevel, net.minecraft.world.level.chunk.ProtoChunk, net.minecraft.world.level.chunk.LevelChunk$PostLoadProcessor);')
check('Proto constructor copies after base constructor','75: invokevirtual' in proto and 'Method setBlockEntity:' in proto and '89: invokevirtual' in proto and 'getBlockEntityNbts' in proto,'static_native',selected(proto,['invokespecial','75:','89:','pendingBlockEntities']))
setblock = method('LevelChunk-javap.txt','public net.minecraft.world.level.block.state.BlockState setBlockState(net.minecraft.core.BlockPos, net.minecraft.world.level.block.state.BlockState, boolean);')
check('Allocation follows native section write',setblock.index('LevelChunkSection.setBlockState')<setblock.index('EntityBlock.newBlockEntity')<setblock.index('addAndRegisterBlockEntity'),'static_native',selected(setblock,['LevelChunkSection.setBlockState','newBlockEntity','addAndRegisterBlockEntity']))
registration = method('LevelChunk-javap.txt','public void addAndRegisterBlockEntity(net.minecraft.world.level.block.entity.BlockEntity);')
check('Fresh direct onLoad follows map installation',registration.index('setBlockEntity')<registration.index('BlockEntity.onLoad'),'static_native',selected(registration,['setBlockEntity','isInLevel','onLoad']))
promote = method('ChunkMap-javap.txt','private net.minecraft.world.level.chunk.ChunkAccess lambda$protoChunkToFullChunk$34(net.minecraft.server.level.ChunkHolder, net.minecraft.world.level.chunk.ChunkAccess);')
check('Promotion constructs actual non-Imposter Proto','50: invokespecial' in promote and 'LevelChunk."<init>"' in promote and 'ProtoChunk;' in promote,'static_native',selected(promote,['ImposterProtoChunk','50:','ChunkEvent$Load']))
check('isNewChunk is NOT Imposter test',re.search(r'138: instanceof[^\n]*ImposterProtoChunk',promote) is not None and '149: invokespecial' in promote,'static_native',selected(promote,[str(pc)+':' for pc in [138,141,144,145,148,149]]))
read = method('ChunkSerializer-javap.txt','public static net.minecraft.world.level.chunk.ProtoChunk read(net.minecraft.server.level.ServerLevel, net.minecraft.world.entity.ai.village.poi.PoiManager, net.minecraft.world.level.ChunkPos, net.minecraft.nbt.CompoundTag);')
check('FULL event before Imposter wrapper',read.index('1199: invokespecial')<read.index('1218: invokespecial') and 'ChunkDataEvent$Load' in read,'static_native',selected(read,[str(pc)+':' for pc in [1194,1196,1197,1199,1202,1212,1214,1218,1221]]))
check('Proto event retains actual Proto local','1403: aload' in read and '1408: invokespecial' in read,'static_native',selected(read,[str(pc)+':' for pc in range(1395,1424)]))
parts = re.split(r'(?m)(?=^  (?:public|private|protected|static)[^\n]*\([^\n]*\);\r?$)',(LEAF/'native/ChunkMap-javap.txt').read_text())
unloads = [p for p in parts if 'ChunkEvent$Unload' in p and 'ServerLevel.unload:' in p]
check('One ordinary unload body',len(unloads)==1,'static_native')
unload = unloads[0]
check('Unload event precedes attempted save and BE clear',unload.index('IEventBus.post')<unload.index('Method save:')<unload.index('ServerLevel.unload'),'static_native',selected(unload,['IEventBus.post','Method save:','ServerLevel.unload','79: pop']))
check('Unload discards save boolean',re.search(r'76: invokevirtual[^\n]*Method save:[^\n]*\n\s+79: pop',unload) is not None,'static_native')
injection = method('InjectionInfo-javap.txt','public void postInject();')
check('Mixin hard lower and upper injection checks',all(s in injection for s in ['requiredCallbackCount','maxCallbackCount','InjectionError','if_icmpge','if_icmple']),'static_native',selected(injection,['requiredCallbackCount','maxCallbackCount','InjectionError','if_icmpge','if_icmple']))
for file,header,target in [
    ('ServerGamePacketListenerImpl-javap.txt','public void handleUseItemOn(net.minecraft.network.protocol.game.ServerboundUseItemOnPacket);','ServerPlayerGameMode.useItemOn:'),
    ('ServerPlayerGameMode-javap.txt','public void tick();','Method destroyBlock:'),
    ('ServerPlayerGameMode-javap.txt','public void destroyAndAck(net.minecraft.core.BlockPos, int, java.lang.String);','Method destroyBlock:')]:
    found = calls(method(file,header),target)
    check('One selected invocation: '+header,len(found)==1,'static_native','\n'.join(found))
place = method('BlockItem-javap.txt','public net.minecraft.world.InteractionResult place(net.minecraft.world.item.context.BlockPlaceContext);')
check('updatePlacementContext returned local reaches placeBlock',len(calls(place,'updatePlacementContext:'))==1 and len(calls(place,'placeBlock:'))==1 and place.index('updatePlacementContext:')<place.index('37: astore_2')<place.index('placeBlock:'),'static_native',selected(place,['updatePlacementContext:','astore_2','aload_2','placeBlock:']))
check('No getPlacementContext member at this pin','getPlacementContext' not in (LEAF/'native/BlockItem-javap.txt').read_text(),'static_native')
stack = method('ItemStack-javap.txt','public net.minecraft.world.InteractionResult useOn(net.minecraft.world.item.context.UseOnContext);')
check('ItemStack uses Forge placement wrapper','ForgeHooks.onPlaceItemIntoWorld' in stack,'static_native','\n'.join(calls(stack,'ForgeHooks.onPlaceItemIntoWorld:')))

def source(name):
    row = next(x for x in json.loads((LEAF/'fixed-source-pins.json').read_text()) if x['source'].endswith('/'+name+'.java'))
    argv = ['git','show',row['source'][4:]]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv,cwd=REPO,capture_output=True)
    commands.append({'argv':argv,'cwd':str(REPO),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode})
    assert result.returncode==0 and hashlib.sha256(result.stdout).hexdigest()==row['sha256']
    return result.stdout.decode('utf-8')

def excerpt(name,text,start,end):
    assert end-start<40
    excerpts.append({'name':name,'start':start,'end':end,'lines':text.splitlines()[start-1:end]})

hatch = source('ClassicHatchBlockEntity')
check('First LOAD closes before separate second LOAD',hatch.index('loadJoinCandidate = new LoadJoinCandidate')<hatch.index('joined = recordCompletedLoad(service);') and hatch.count('service.access().enterLoad(this)')==2,'fixed_source')
check('Second LOAD followed by unconditional temporary clear','joined = recordCompletedLoad(service);' in hatch and 'loadJoinCandidate = null; preparingLoad = false;' in hatch,'fixed_source')
check('Current second LOAD installs availability','if (loadJoinCandidate.pending() == null) { storage.installed(); }' in hatch,'fixed_source')
check('Retirement invokes explicit clearLoadJoin','void retireAccess() { clearLoadJoin(); storage.retire(); }' in hatch,'fixed_source')
check('Initial onLoad retires access before preparation',hatch.index('retireAccess(); super.onLoad();')<hatch.index('if (service != null) { prepareLoaded(service); }'),'fixed_source')
for start,end in [(84,115),(124,145),(264,287),(302,315)]:
    excerpt('ClassicHatchBlockEntity',hatch,start,end)
owner = source('ClassicOwnerState')
check('Existing installed primitive calls owner.isRemoved','if (!owner.isRemoved()) { gameplayAvailable = true; }' in owner,'fixed_source')
excerpt('ClassicOwnerState',owner,35,47)
observation = source('ClassicChunkObservation')
check('Current capture takes actual LevelChunk only','event.getChunk() instanceof LevelChunk chunk' in observation,'fixed_source')
check('Current save compares outgoing with origin and retained cardinality','outgoing.records().equals(selected.scan().records())' in observation and 'retained.size() != selected.scan().records().size()' in observation,'fixed_source')
excerpt('ClassicChunkObservation',observation,66,84)
excerpt('ClassicChunkObservation',observation,293,328)
world = source('ClassicLoadedWorld')
check('Installed path requires ordinary raw observation','!ClassicSaveProtection.ownerObservationMatches(level, chunk, owner)' in world,'fixed_source')
excerpt('ClassicLoadedWorld',world,47,57)
ticket = source('GuardTicket')
check('Current ticket acquire requires installed world predicate','!installed(world, owner)' in ticket,'fixed_source')
check('Ticket close releases without requiring live gameplay validity','if (!closed) { closed = true; release(witnesses); }' in ticket,'fixed_source')
excerpt('GuardTicket',ticket,94,105)
excerpt('GuardTicket',ticket,361,369)
save = source('ClassicSaveProtection')
check('No existing Proto transfer','return; // No Proto-to-FULL owner promotion or observation transfer.' in save,'fixed_source')
excerpt('ClassicSaveProtection',save,34,44)

candidate = (LEAF/'inputs/current/COUPLED-CONTRACT-23.md').read_text(encoding='utf-8')
matrix = (LEAF/'inputs/current/COUPLED-VERIFICATION-MATRIX-23.md').read_text(encoding='utf-8')
# These are coverage assertions about draft wording, not implementation tests.
check('Revision2 names completed receipt transfer and independent validation',all(s in candidate for s in ['OperationCompletedLoadReceipt','does NOT invalidate the','no longer calls loadJoinStillCurrent','Subsequent retireAccess/clearLoadJoin']),'draft_coverage')
check('Revision2 describes unselected delegation and no-selection cleanup',all(s in candidate for s in ['DELEGATING_UNSELECTED','originalStarted','without invoking the','no-selection cleanup','never','a second time']),'draft_coverage')
check('Revision2 IDLE allows the unselected Level slot','No selected-cell operation; the Level slot may still be DELEGATING_UNSELECTED' in candidate,'draft_coverage')
check('Revision2 corrects context method name','updatePlacementContext' in candidate and 'getPlacementContext' not in candidate,'draft_coverage')
check('Revision2 prohibits existing installed native getter in terminal',all(s in candidate for s in ['Existing storage.installed calls owner.isRemoved','new private local publication primitive','without another native getter']),'draft_coverage')
check('Matrix retains every P1-P24 without duplicate IDs',re.findall(r'^\| (P\d+) \|',matrix,re.M)==['P'+str(i) for i in range(1,25)],'draft_coverage')
check('Matrix separates assignment design and actual activation',all(s in matrix for s in ['Assignment phase requires','Activation phase requires','Documentation/static','rows remain OPEN/NOT_RUN']),'draft_coverage')

links = []
for name,text in [('COUPLED-CONTRACT-23.md',candidate),('COUPLED-VERIFICATION-MATRIX-23.md',matrix)]:
    data=(LEAF/'inputs/current'/name).read_bytes()
    check('UTF8/trailing whitespace: '+name,'\ufffd' not in text and all(line.rstrip(' \t')==line for line in text.splitlines()),'draft_hygiene')
    for relative in re.findall(r'\]\(([^)]+)\)',text):
        if re.match(r'https?://',relative):
            continue
        target = (REPO/'docs/work/v1.8.0-c16a-hatches'/relative.split('#')[0]).resolve()
        links.append({'draft':name,'target':relative,'exists':target.is_file()})
check('Current draft local links exist',all(x['exists'] for x in links),'draft_hygiene')

(LEAF/'source-excerpts.json').write_text(json.dumps(excerpts,indent=2)+'\n',encoding='utf-8')
(LEAF/'static-check-results.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
(LEAF/'new-local-links.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')
(LEAF/'commands-static-source.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
summary={'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failures':[x['id'] for x in checks if not x['passed']],
         'by_kind':{k:sum(x['kind']==k for x in checks) for k in sorted(set(x['kind'] for x in checks))},'runtime_proof':False}
(LEAF/'static-check-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if all(x['passed'] for x in checks) else 1)
