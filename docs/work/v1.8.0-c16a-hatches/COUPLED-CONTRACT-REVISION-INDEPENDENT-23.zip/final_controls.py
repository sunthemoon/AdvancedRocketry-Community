"""Final read-only pin rechecks and attributed original validation results."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/AdvancedRocketry-Community')
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-independent-20261008-01')
assert not (LEAF/'SHA256SUMS.txt').exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
commands = []

def save(path,value):
    (LEAF/path).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def run(args,log=None):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(args,cwd=REPO,capture_output=True)
    row={'argv':args,'cwd':str(REPO),'started_utc':start,
         'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'exit_code':result.returncode}
    if log:
        (LEAF/log).write_bytes(result.stdout+result.stderr)
        row['log']=log
    commands.append(row)
    assert result.returncode==0, row
    return result.stdout

rechecks=[]
for row in json.loads((LEAF/'input-pins.json').read_text()):
    path=Path(row['source'])
    data=path.read_bytes()
    rechecks.append({'source':str(path),'initial_sha256':row['sha256'],
           'final_sha256':sha(data),'unchanged':sha(data)==row['sha256']})
source_rechecks=[]
for row in json.loads((LEAF/'fixed-source-pins.json').read_text()):
    data=run(['git','show',row['source'][4:]])
    source_rechecks.append({'source':row['source'],'sha256':sha(data),'unchanged':sha(data)==row['sha256']})
native_rechecks=[]
seen=set()
for row in json.loads((LEAF/'native-identities.json').read_text()):
    if row['jar'] in seen:
        continue
    seen.add(row['jar'])
    with Path(row['jar']).open('rb') as file:
        final=hashlib.file_digest(file,'sha256').hexdigest()
    native_rechecks.append({'jar':row['jar'],'sha256':final,'unchanged':final==row['jar_sha256']})
root_rechecks=[]
for row in json.loads((LEAF/'root-primary-input-pins.json').read_text()):
    final=sha(Path(row['path']).read_bytes())
    root_rechecks.append({'path':row['path'],'sha256':final,'unchanged':final==row['sha256']})
for name,args in [
    ('final-head.txt',['git','rev-parse','HEAD']),
    ('final-status.txt',['git','status','--short']),
    ('final-index.txt',['git','diff','--cached','--stat']),
    ('final-diff-check.txt',['git','diff','--check']),
    ('final-source-build-diff.txt',['git','diff','--exit-code','--','src','build.gradle','settings.gradle','gradle.properties','gradle'])]:
    run(args,'logs/'+name)
result={'inputs':rechecks,'fixed_source':source_rechecks,'native_archives':native_rechecks,'named_root_primary_inputs':root_rechecks,
       'all_input_pins_unchanged':all(x['unchanged'] for x in rechecks),
       'all_fixed_source_pins_unchanged':all(x['unchanged'] for x in source_rechecks),
       'all_native_archives_unchanged':all(x['unchanged'] for x in native_rechecks),
       'all_named_root_inputs_unchanged':all(x['unchanged'] for x in root_rechecks),
       'head_unchanged':(LEAF/'logs/final-head.txt').read_bytes()==(LEAF/'logs/initial-head.txt').read_bytes(),
       'index_stat_unchanged':(LEAF/'logs/final-index.txt').read_bytes()==(LEAF/'logs/initial-index.txt').read_bytes(),
       'status_display_unchanged':(LEAF/'logs/final-status.txt').read_bytes()==(LEAF/'logs/initial-status.txt').read_bytes()}
save('final-pins.json',result)
save('commands-final-controls.json',commands)

attribution=[]
for file in ['commands-validators.json','commands-followup-strict.json']:
    for row in json.loads((OLD/file).read_text()):
        if 'validate_' not in ' '.join(row['argv']):
            continue
        record={'review':'original independent review, not this revision2 run',
                'command_record':str(OLD/file),'record':row}
        log=row.get('log') or row.get('output',{}).get('path')
        if log:
            data=(OLD/log).read_bytes()
            text=data.decode('utf-8')
            record['retained_log']=str(OLD/log)
            record['log_sha256']=sha(data)
            record['bounded_excerpt']=[line for line in text.splitlines() if line.startswith('Summary:') or '653' in line or 'PLANNED' in line or 'REVIEW' in line]
        attribution.append(record)
save('prior-validation-attribution.json',attribution)
print(json.dumps({key:value for key,value in result.items() if isinstance(value,bool)},indent=2))
assert result['all_fixed_source_pins_unchanged'] and result['all_native_archives_unchanged'] and result['head_unchanged'] and result['index_stat_unchanged']
