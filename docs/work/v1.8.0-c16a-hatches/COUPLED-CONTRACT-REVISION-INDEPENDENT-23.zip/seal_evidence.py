"""Seal only the declared review payload; never recursively export the leaf."""
from pathlib import Path
import hashlib
import json

LEAF=Path(__file__).resolve().parent
assert not (LEAF/'SHA256SUMS.txt').exists(), 'Already sealed; do not amend.'
sha=lambda data:hashlib.sha256(data).hexdigest()
names=[
    'TASK.md','REPORT.md','INSTRUMENTATION.md','review_inputs.py','check_revision.py',
    'check_revision_r2.py','final_controls.py','seal_evidence.py','launch-results.json',
    'original-seal-verification.json','root-primary-input-pins.json','fixed-source-pins.json',
    'native-identities.json','input-pins.json','commands-inputs-native.json',
    'source-excerpts.json','static-check-results.json','new-local-links.json',
    'commands-static-source.json','static-check-summary.json',
    'source-excerpts-r2.json','static-check-results-r2.json','new-local-links-r2.json',
    'commands-static-source-r2.json','static-check-summary-r2.json',
    'final-pins.json','commands-final-controls.json','prior-validation-attribution.json',
    'inputs/current/COUPLED-CONTRACT-23.md','inputs/current/COUPLED-VERIFICATION-MATRIX-23.md',
    'inputs/original/COUPLED-CONTRACT-23.md','inputs/original/COUPLED-VERIFICATION-MATRIX-23.md',
    'inputs/original/REPORT.md','diffs/COUPLED-CONTRACT-23.md.diff',
    'diffs/COUPLED-VERIFICATION-MATRIX-23.md.diff'
]
names += ['logs/'+name for name in [
    'initial-status.txt','initial-head.txt','initial-branch.txt','initial-worktrees.txt',
    'initial-diff.txt','initial-index.txt','initial-diff-check.txt','final-head.txt',
    'final-status.txt','final-index.txt','final-diff-check.txt','final-source-build-diff.txt']]
names += [row['javap_log'] for row in json.loads((LEAF/'native-identities.json').read_text())]
assert len(names)==len(set(names))
rows=[]
for name in sorted(names):
    path=LEAF/name
    assert path.resolve().is_relative_to(LEAF.resolve())
    assert not path.is_symlink()
    data=path.read_bytes()
    assert len(data)<=50*1024*1024
    assert not name.startswith(('source/','build/','world/','server/'))
    rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
total=sum(row['bytes'] for row in rows)
assert total<=100*1024*1024
manifest={'payloads':rows,'payload_count':len(rows),'payload_bytes':total,
          'scope':'Independent read-only complete revision2 contract review; explicit payload only.',
          'exclusions':['full source trees/caches/ZIPs','native class binaries/JAR copies',
                        'world/server/build/dependency copies','original sealed payload alteration'],
          'report':'REPORT.md','source_pins':'fixed-source-pins.json','source_excerpts':'source-excerpts-r2.json',
          'new_runtime_proof':False,'strict_validator_rerun':False}
data=(json.dumps(manifest,indent=2)+'\n').encode('utf-8')
(LEAF/'evidence-manifest.json').write_bytes(data)
checks=''.join(row['sha256']+'  '+row['path']+'\n' for row in rows)+sha(data)+'  evidence-manifest.json\n'
(LEAF/'SHA256SUMS.txt').write_text(checks,encoding='utf-8')
# Actual read-back validates exactly the enumerated rows and controller.
for line in (LEAF/'SHA256SUMS.txt').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert sha((LEAF/name).read_bytes())==digest
print(json.dumps({'payload_count':len(rows),'payload_bytes':total,
       'report_sha256':sha((LEAF/'REPORT.md').read_bytes()),
       'manifest_sha256':sha(data),'checksum_sha256':sha((LEAF/'SHA256SUMS.txt').read_bytes()),
       'read_back_verified':True},indent=2))
