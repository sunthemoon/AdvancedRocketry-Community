# Review instrumentation history

The first `python -B check_revision.py` run exits 1: 39/40 bounded static
checks pass. Its new first/second LOAD selector incorrectly counts
`service.access().enterLoad(this)` across the complete hatch class. The fixed
source also has LOAD acquisition in retained checkpoint revalidation and raw
installed loading, not only the fresh `prepareLoaded`/`recordCompletedLoad`
pair. A fresh checkpoint-null birth bypasses retained revalidation. This is a
review-selector scope error, not a discovered runtime third LOAD or a product
failure.

`check_revision_r2.py` preserves the first script and results, narrowing only
that count to the two exact methods. It does not remove an assertion or change
the target source/draft/native inputs. Corrected outputs use separate `-r2`
filenames. Native inspection remains static and runtime proofs are NOT_RUN.

Earlier read-only exploration included two nonexistent-file reads: the guessed
`EVIDENCE-PAYLOAD.json` (actual controller is `evidence-manifest.json`) and
the guessed `ADR-068-V180-EMPTY-HATCH-ORDINARY-OPERATION-BOUNDARY.md` (actual
file is `ADR-068-V180-CLASSIC-NATIVE-OUTER-OPERATIONS.md`). Both produced
PowerShell Cannot find path errors. No file was created or modified by those
reads; the actual files are used and pinned. Exploratory tool responses remain
in the chat; they are not represented as successful reads.

One exploratory evidence-directory rendering command used an incorrect fixed
`FullName.Substring(125)` offset and produced PowerShell range errors for
shorter filenames. It was only display formatting, performed no file writes,
and is not used as inventory evidence. The final payload inventory uses
`Path.relative_to` and an explicitly named payload list instead.
