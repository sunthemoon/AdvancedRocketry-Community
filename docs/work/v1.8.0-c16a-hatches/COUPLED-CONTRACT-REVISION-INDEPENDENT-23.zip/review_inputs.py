"""Read-only bounded inputs and fixed-source/native inspection for revision2."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import zipfile

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/AdvancedRocketry-Community')
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-independent-20261008-01')
ROOT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-coupled-contract-root-20261008-01')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
JAVAP = 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'
assert LEAF.name == 'hatch-coupled-contract-revision-independent-20261008-01'
assert not (LEAF/'SHA256SUMS.txt').exists()
commands = []
pins = []
sha = lambda data: hashlib.sha256(data).hexdigest()

def write(path, data):
    target = LEAF/path
    assert target.resolve().is_relative_to(LEAF.resolve())
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data if isinstance(data, bytes) else data.encode('utf-8'))

def jsonout(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def run(args, log=None):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, cwd=REPO, capture_output=True)
    record = {'argv':args, 'cwd':str(REPO), 'started_utc':start,
              'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit_code':result.returncode, 'stdout_bytes':len(result.stdout),
              'stderr_bytes':len(result.stderr)}
    if log:
        write(log,result.stdout+result.stderr)
        record['log'] = log
    commands.append(record)
    assert result.returncode == 0, record
    return result.stdout

def pin(path, role, snapshot=None):
    data = path.read_bytes()
    assert len(data) < 10*1024*1024, str(path)
    row = {'source':str(path), 'role':role, 'bytes':len(data), 'sha256':sha(data)}
    if snapshot:
        write(snapshot, data)
        row['snapshot'] = snapshot
    pins.append(row)
    return data

for name, args in [
    ('initial-status.txt',['git','status','--short']),
    ('initial-head.txt',['git','rev-parse','HEAD']),
    ('initial-branch.txt',['git','branch','--show-current']),
    ('initial-worktrees.txt',['git','worktree','list']),
    ('initial-diff.txt',['git','diff','--stat']),
    ('initial-index.txt',['git','diff','--cached','--stat']),
    ('initial-diff-check.txt',['git','diff','--check'])]:
    run(args,'logs/'+name)
assert (LEAF/'logs/initial-head.txt').read_text().strip() == BASE

# Enumerated original payload only: no recursive export of trees or caches.
manifest_bytes = pin(OLD/'evidence-manifest.json','original sealed controller')
checksum_bytes = pin(OLD/'SHA256SUMS.txt','original sealed checksum controller')
manifest = json.loads(manifest_bytes)
old_results = []
for row in manifest['payloads']:
    path = OLD/row['path']
    assert path.resolve().is_relative_to(OLD.resolve())
    data = path.read_bytes()
    old_results.append({'path':row['path'], 'bytes':len(data), 'sha256':sha(data),
                        'matches':len(data)==row['bytes'] and sha(data)==row['sha256']})
checksum_results = []
for line in checksum_bytes.decode('utf-8').splitlines():
    digest, relative = line.split('  ',1)
    path = OLD/relative
    assert path.resolve().is_relative_to(OLD.resolve())
    checksum_results.append({'path':relative, 'matches':sha(path.read_bytes())==digest})
assert all(x['matches'] for x in old_results+checksum_results)
jsonout('original-seal-verification.json',{'payloads':old_results,'checksums':checksum_results,
        'payload_count':len(old_results), 'checksums_count':len(checksum_results)})

folder = Path('docs/work/v1.8.0-c16a-hatches')
for name, expected in [
    ('COUPLED-CONTRACT-23.md','4749db7b3931a6ca98efdb8c98f4deaecefeb0f2a1e0ea6114a78ff7869f5d5a'),
    ('COUPLED-VERIFICATION-MATRIX-23.md','8e4a78463a1c7da138810dc690784cce0d41582413a42669c043c2c4bd8a19b2')]:
    current = pin(REPO/folder/name,'complete revision2 draft','inputs/current/'+name)
    assert sha(current)==expected
    original = pin(OLD/'inputs'/folder/name,'complete original reviewed draft','inputs/original/'+name)
    diff = ''.join(difflib.unified_diff(original.decode('utf-8').splitlines(keepends=True),
               current.decode('utf-8').splitlines(keepends=True),
               fromfile='original/'+name,tofile='revision2/'+name))
    write('diffs/'+name+'.diff',diff)
pin(OLD/'REPORT.md','original sealed independent report','inputs/original/REPORT.md')
pin(LEAF/'TASK.md','this review task')
pin(REPO/folder/'COUPLED-CONTRACT-TASK-23.md','Root task23 revision')
pin(REPO/folder/'COUPLED-CONTRACT-DISPOSITION-23.md','Root in-progress disposition')

# Read/pin governance and relevant prior records without duplicating them all.
old_inputs = json.loads((OLD/'input-manifest.json').read_text(encoding='utf-8'))
for row in old_inputs:
    source = Path(row['source'])
    if source.is_relative_to(REPO) and source.is_file() and source.name not in {
            'COUPLED-CONTRACT-23.md','COUPLED-VERIFICATION-MATRIX-23.md',
            'COUPLED-CONTRACT-TASK-23.md'}:
        pin(source,'mandatory governance/private/qualification record')

root_pins = []
for path in sorted(ROOT.iterdir()):
    if path.is_file():
        data = path.read_bytes()
        assert len(data)<10*1024*1024
        root_pins.append({'path':str(path),'bytes':len(data),'sha256':sha(data)})
jsonout('root-primary-input-pins.json',root_pins)

source_pins = []
source_specs = json.loads((OLD/'source-pins.json').read_text())
source_specs += json.loads((OLD/'extra-source-pins-excerpts.json').read_text())
for old in source_specs:
    spec = old['source'][4:]
    data = run(['git','show',spec])
    assert len(data)<=512*1024 and sha(data)==old['sha256']
    blob = run(['git','rev-parse',spec]).decode().strip()
    assert blob == old['git_blob_sha1']
    source_pins.append({'source':old['source'],'bytes':len(data),'sha256':sha(data),'git_blob_sha1':blob})
jsonout('fixed-source-pins.json',source_pins)

native_specs = json.loads((OLD/'native-identities.json').read_text())
native_specs += json.loads((OLD/'native-extra-identities.json').read_text())
jars = {}
native_pins = []
for spec in native_specs:
    jar = Path(spec['jar'])
    if str(jar) not in jars:
        with jar.open('rb') as stream:
            jars[str(jar)] = hashlib.file_digest(stream,'sha256').hexdigest()
    assert jars[str(jar)] == spec['jar_sha256']
    with zipfile.ZipFile(jar) as archive:
        info = archive.getinfo(spec['member'])
        assert info.file_size<=512*1024
        member = archive.read(info)
        assert len(member)==spec['bytes'] and sha(member)==spec['sha256']
    name = spec['member'][:-6].replace('/','.')
    log = 'native/'+Path(spec['javap_log']).name
    result = run([JAVAP,'-p','-c','-s','-classpath',str(jar),name],log)
    old_output = (OLD/spec['javap_log']).read_bytes()
    native_pins.append({'jar':str(jar),'jar_sha256':jars[str(jar)],
           'member':spec['member'],'bytes':len(member),'sha256':sha(member),
           'javap_log':log,'javap_sha256':sha(result), 'exit_code':0,
           'same_as_original_javap':result==old_output})
assert all(x['same_as_original_javap'] for x in native_pins)
jsonout('native-identities.json',native_pins)
jsonout('input-pins.json',pins)
jsonout('commands-inputs-native.json',commands)
print(json.dumps({'fixed_source_pins':len(source_pins),'javap_commands':len(native_pins),
     'all_native_outputs_equal_original':True, 'old_sealed_payloads_verified':len(old_results),
     'old_checksums_verified':len(checksum_results),'input_pins':len(pins)},indent=2))
