"""Preserve first instrumentation; narrow fresh LOAD count to its actual methods."""
from pathlib import Path

leaf = Path(__file__).resolve().parent
script = (leaf/'check_revision.py').read_text(encoding='utf-8')
old = "hatch.count('service.access().enterLoad(this)')==2"
new = "hatch[hatch.index('void prepareLoaded('):hatch.index('boolean loadJoinReady(')].count('service.access().enterLoad(this)')==2"
assert script.count(old)==1
script = script.replace(old,new)
for name in ['source-excerpts','static-check-results','new-local-links','commands-static-source','static-check-summary']:
    script = script.replace(name+'.json',name+'-r2.json')
exec(compile(script,str(leaf/'check_revision.py')+' [method-bounded fresh LOAD count]','exec'))
