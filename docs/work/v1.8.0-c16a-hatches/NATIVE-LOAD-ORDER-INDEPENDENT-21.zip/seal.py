"""Seal retained reviewer evidence only, never source/build/world/TEMP copies."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

old = json.loads((ROOT / "cohort-02/results.json").read_text("utf-8"))
new = json.loads((ROOT / "cohort-03/results.json").read_text("utf-8"))
assert old["source"] == "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"
assert new["source"] == "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"
for result in (old, new):
    assert result["clean"] and result["head_unchanged"] and len(result["records"]) == 11
    assert any(row["name"] == "native" and row["ended"] for row in result["records"])
jar = Path(json.loads((ROOT / "native-identity.json").read_text("utf-8"))["jar"])
after = sha(jar)
before = json.loads((ROOT / "native-identity.json").read_text("utf-8"))["jar_sha256_before"]
assert after == before
(ROOT / "native-after.json").write_text(json.dumps({"path": str(jar), "sha256_before": before,
    "sha256_after": after, "unchanged": after == before}, indent=2) + "\n", "utf-8")
assert (ROOT / "REPORT.md").is_file()
excluded_dirs = {"snapshot", "snapshot-corrected", "temp"}
excluded_names = {"SHA256SUMS.txt", "retained-manifest.json", "review-evidence.zip", "review-evidence.zip.sha256"}
payloads = []
for child in sorted(ROOT.iterdir()):
    if child.is_file() and child.name not in excluded_names:
        payloads.append(child)
    elif child.is_dir() and child.name in ("cohort-02", "cohort-03"):
        payloads.extend(sorted(path for path in child.iterdir() if path.is_file()))
assert not any(path.relative_to(ROOT).parts[0] in excluded_dirs for path in payloads)
assert not any(path.stat().st_size > 50 * 1024**2 for path in payloads)
total = sum(path.stat().st_size for path in payloads)
assert total < 100 * 1024**2
manifest = {"sealed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "original_candidate": old["source"], "corrected_candidate": new["source"],
    "payload_count_before_manifest": len(payloads), "payload_bytes_before_manifest": total,
    "files": [{"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size,
               "sha256": sha(path)} for path in payloads],
    "excluded_disposable_roots": sorted(excluded_dirs), "cleanup": json.loads((ROOT / "cleanup.json").read_text("utf-8-sig"))}
manifest_path = ROOT / "retained-manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", "utf-8")
payloads.append(manifest_path)
checksums = ROOT / "SHA256SUMS.txt"
checksums.write_text("".join(sha(path) + "  " + path.relative_to(ROOT).as_posix() + "\n" for path in sorted(payloads)), "utf-8")
packet = ROOT / "review-evidence.zip"
with zipfile.ZipFile(packet, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(payloads + [checksums]):
        archive.write(path, path.relative_to(ROOT).as_posix())
(ROOT / "review-evidence.zip.sha256").write_text(sha(packet) + "  review-evidence.zip\n", "utf-8")
assert total + packet.stat().st_size < 100 * 1024**2
with zipfile.ZipFile(packet) as archive:
    assert archive.testzip() is None
    for path in payloads:
        member = path.relative_to(ROOT).as_posix()
        assert hashlib.sha256(archive.read(member)).hexdigest() == sha(path), member
print(json.dumps({"payloads_including_manifest": len(payloads), "bytes_before_manifest": total,
                  "zip_bytes": packet.stat().st_size, "zip_sha256": sha(packet),
                  "native_jar_unchanged": after == before}, indent=2))
