"""Independent pinned offline checks; writes only this new review leaf."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "snapshot"
OUT = ROOT / sys.argv[1]
OUT.mkdir()
TEMP = OUT / "temp"
JDK = Path("C:/Program Files/Java/jdk-17.0.7")
PIN = "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-c", "core.longpaths=true", "-C", str(TREE), *args], text=True)

assert git("rev-parse", "HEAD").strip() == PIN
assert not git("status", "--porcelain")
TEMP.mkdir()
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / "bin") + os.pathsep + os.environ["PATH"],
           TEMP=str(TEMP), TMP=str(TEMP), TMPDIR=str(TEMP),
           JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=" + TEMP.as_posix(), PYTHONDONTWRITEBYTECODE="1")
gradle = [str(Path("C:/Windows/System32/cmd.exe")), "/d", "/c", "gradlew.bat"]
options = ["--offline", "--no-daemon", "--no-build-cache"]
commands = [
    ("java", [str(JDK / "bin/java.exe"), "-version"]),
    ("build", gradle + ["clean", "build"] + options),
    ("data-1", gradle + ["runData"] + options),
    ("data-1-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("data-2", gradle + ["runData"] + options),
    ("data-2-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("provenance", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py"]),
    ("repository", [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]),
    ("whitespace", ["git", "--no-optional-locks", "diff", "--check"]),
    ("native", gradle + ["runGameTestServer"] + options),
]
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
    assert all(value > 10 * 1024**3 for value in free.values()), free
    started = utc()
    print(json.dumps(dict(starting=name, utc=started, argv=argv)), flush=True)
    log = OUT / (name + ".log")
    with log.open("xb") as out:
        result = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                stdout=out, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    record = dict(name=name, argv=argv, cwd=str(TREE), source=PIN, started=started, ended=utc(),
                  exit_code=result.returncode, free_bytes=free, bytes=log.stat().st_size, log_sha256=sha(log))
    records.append(record)
    (OUT / "commands.json").write_text(json.dumps(records, indent=2) + "\n", "utf-8")
    print(json.dumps(record), flush=True)
    if name in ("build", "data-1", "data-2") and result.returncode:
        break

xmls = sorted((TREE / "build/test-results/test").glob("TEST-*.xml"))
totals = dict(tests=0, failures=0, errors=0, skipped=0)
actual = 0
with zipfile.ZipFile(OUT / "unit-results.zip", "x", compression=zipfile.ZIP_DEFLATED) as out:
    for path in xmls:
        xml = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(xml.get(key, "0"))
        actual += len(xml.findall("testcase"))
        out.write(path, path.name)
native = ""
if any(row["name"] == "native" for row in records):
    for name in ("latest", "debug"):
        path = TREE / "build/gametest/logs" / (name + ".log")
        if path.is_file():
            shutil.copy2(path, OUT / ("native-" + name + ".log"))
    native = (OUT / "native-latest.log").read_text("utf-8")
summary = dict(source=PIN, src_tree=git("rev-parse", "HEAD:src").strip(), records=records,
               unit_suites=len(xmls), unit_totals=totals, actual_testcase_nodes=actual,
               native_errors=len(re.findall(r"/ERROR]", native)), native_fatals=len(re.findall(r"/FATAL]", native)),
               native_terminal=[line for line in native.splitlines() if re.search(r"GAME TESTS COMPLETE|All \d+ required tests passed|\d+ required tests failed", line)],
               native_probe_batches=[line for line in native.splitlines() if "Running test batch 'native_load_order" in line],
               native_failures=[line for line in native.splitlines() if "failed!" in line],
               head_unchanged=git("rev-parse", "HEAD").strip() == PIN, clean=not git("status", "--porcelain"),
               artifacts={p.name: sha(p) for p in sorted((TREE / "build/libs").glob("*.jar"))})
(OUT / "results.json").write_text(json.dumps(summary, indent=2) + "\n", "utf-8")
print(json.dumps(summary), flush=True)
sys.exit(0 if all(r["exit_code"] == 0 for r in records) and summary["clean"] and summary["head_unchanged"] else 1)
