"""Recheck retained raw results and owned outputs before disposal/sealing."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
ROOT_PACKET = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-root-20261008-01")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

checks = []
for cohort, tree, expected in (
    ("cohort-02", "snapshot", "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"),
    ("cohort-03", "snapshot-corrected", "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"),
):
    directory = ROOT / cohort
    result = json.loads((directory / "results.json").read_text("utf-8"))
    assert result["source"] == expected
    assert len(result["records"]) == 11
    for row in result["records"]:
        log = directory / (row["name"] + ".log")
        assert sha(log) == row["log_sha256"]
        assert log.stat().st_size == row["bytes"]
        assert row["started"] <= row["ended"] and row["source"] == expected
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    nodes = 0
    with zipfile.ZipFile(directory / "unit-results.zip") as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        for name in names:
            xml = ET.fromstring(archive.read(name))
            for key in totals:
                totals[key] += int(xml.get(key, "0"))
            nodes += len(xml.findall("testcase"))
    assert totals == result["unit_totals"] and nodes == result["actual_testcase_nodes"]
    assert len(names) == result["unit_suites"] == 378 and nodes == 2179
    native = (directory / "native-latest.log").read_text("utf-8")
    terminal = [line for line in native.splitlines() if re.search(r"GAME TESTS COMPLETE|All \d+ required tests passed|\d+ required tests failed", line)]
    failures = [line for line in native.splitlines() if "failed!" in line]
    assert terminal == result["native_terminal"] and failures == result["native_failures"]
    assert len(re.findall(r"/ERROR]", native)) == result["native_errors"]
    assert len(re.findall(r"/FATAL]", native)) == result["native_fatals"] == 0
    for name, digest in result["artifacts"].items():
        assert sha(ROOT / tree / "build/libs" / name) == digest
    git = ["git", "--no-optional-locks", "-c", "core.longpaths=true", "-C", str(ROOT / tree)]
    assert subprocess.check_output(git + ["rev-parse", "HEAD"], text=True).strip() == expected
    assert not subprocess.check_output(git + ["status", "--porcelain"], text=True)
    checks.append(dict(cohort=cohort, source=expected, command_hashes_verified=11,
                       archived_unit_totals=totals, actual_testcase_nodes=nodes,
                       native_terminal=terminal, native_failure_count=len(failures),
                       native_errors=result["native_errors"], artifacts=result["artifacts"],
                       head_and_status_rechecked=True))

root_result = json.loads((ROOT_PACKET / "cohort-02/results.json").read_text("utf-8"))
new = json.loads((ROOT / "cohort-03/results.json").read_text("utf-8"))
assert root_result["source"] == new["source"]
assert root_result["artifacts"] == new["artifacts"]
assert root_result["unit_totals"] == new["unit_totals"]
assert root_result["actual_testcase_nodes"] == new["actual_testcase_nodes"]
identity = json.loads((ROOT / "native-identity.json").read_text("utf-8"))
jar = Path(identity["jar"])
assert sha(jar) == identity["jar_sha256_before"]
with zipfile.ZipFile(jar) as archive:
    for member, digest in identity["members"].items():
        assert hashlib.sha256(archive.read(member)).hexdigest() == digest
strict_identical = (ROOT / "cohort-02/repository.log").read_bytes() == (ROOT / "cohort-03/repository.log").read_bytes()
assert strict_identical
javap = Path("C:/Program Files/Java/jdk-17.0.7/bin/javap.exe")
argv = [str(javap), "-p", "-c", "-classpath", str(jar), "net.minecraft.gametest.framework.GameTestInfo"]
native_info = subprocess.run(argv, text=True, capture_output=True, check=True)
(ROOT / "native-terminal-bytecode.txt").write_text(native_info.stdout, "utf-8")
audit = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), cohorts=checks,
             root_corrected_artifacts_match=True, root_results_read_after_independent_completion=True,
             pinned_native_archive_and_all_13_members_unchanged=True,
             strict_original_corrected_logs_byte_identical=strict_identical,
             terminal_bytecode_command=dict(argv=argv, exit_code=native_info.returncode))
(ROOT / "AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n", "utf-8")
print(json.dumps(audit, indent=2))
