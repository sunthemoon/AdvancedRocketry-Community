"""Run the same independent cohort on the separately authorized corrected pin."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
source = (ROOT / "review_runner.py").read_text("utf-8")
old_pin = 'PIN = "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"'
old_tree = 'TREE = ROOT / "snapshot"'
assert source.count(old_pin) == 1 and source.count(old_tree) == 1
source = source.replace(old_pin, 'PIN = "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"')
source = source.replace(old_tree, 'TREE = ROOT / "snapshot-corrected"')
exec(compile(source, str(ROOT / "review_runner.py"), "exec"), {"__file__": __file__, "__name__": "__main__"})
