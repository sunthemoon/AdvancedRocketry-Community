$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$expected = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\hatch-native-load-order-independent-20261008-01'
if ($root -cne $expected) { throw 'Unexpected cleanup leaf' }
$record = [ordered]@{ root = $root; started_utc = [DateTime]::UtcNow.ToString('o'); status = 'CHECKING'; targets = @(); workers = @() }
try {
    foreach ($cohort in @('cohort-02', 'cohort-03')) {
        $result = Get-Content -LiteralPath (Join-Path $root "$cohort\results.json") -Raw | ConvertFrom-Json
        if (-not $result.head_unchanged -or -not $result.clean -or $result.records.Count -ne 11) {
            throw "Incomplete or changed cohort: $cohort"
        }
        if (@($result.records | Where-Object { $_.name -eq 'native' -and $_.ended }).Count -ne 1) {
            throw "Native process completion not recorded: $cohort"
        }
    }
    $ancestor = $root
    while ($ancestor) {
        if ((Get-Item -LiteralPath $ancestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw "Cleanup ancestor is a reparse point: $ancestor"
        }
        $parent = [IO.Directory]::GetParent($ancestor)
        $ancestor = if ($parent) { $parent.FullName } else { $null }
    }
    $workers = @(Get-CimInstance Win32_Process | Where-Object {
        $_.ProcessId -ne $PID -and $_.Name -in @('java.exe', 'javaw.exe', 'python.exe', 'cmd.exe') -and
        $_.CommandLine -and $_.CommandLine.IndexOf($root, [StringComparison]::OrdinalIgnoreCase) -ge 0
    } | Select-Object ProcessId, ParentProcessId, Name, CommandLine)
    $record.workers = $workers
    if ($workers.Count) { throw 'Owned output still has a visible worker' }
    $targets = @()
    foreach ($name in @('snapshot', 'snapshot-corrected', 'temp', 'cohort-02\temp', 'cohort-03\temp')) {
        $target = [IO.Path]::GetFullPath((Join-Path $root $name)).TrimEnd('\')
        if (-not $target.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase) -or $target -eq $root) {
            throw "Containment failure: $target"
        }
        $resolved = (Resolve-Path -LiteralPath $target).ProviderPath.TrimEnd('\')
        if ($resolved -cne $target) { throw "Resolution mismatch: $target" }
        $node = Get-Item -LiteralPath $target -Force
        $children = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        $reparse = @(@($node) + $children | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
        if ($reparse.Count) { throw "Reparse target refused: $target" }
        $files = @($children | Where-Object { -not $_.PSIsContainer })
        $bytes = ($files | Measure-Object -Property Length -Sum).Sum
        $targets += [ordered]@{ path = $target; files = $files.Count; bytes = $bytes; status = 'VERIFIED' }
    }
    $record.targets = $targets
    $record.status = 'CONTAINMENT_PROCESS_AND_REPARSE_CHECKS_PASSED'
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $root 'cleanup.json') -Encoding utf8
    foreach ($target in $targets) {
        Remove-Item -LiteralPath $target.path -Recurse -Force -ErrorAction Stop
        $target.status = 'REMOVED'
    }
    $record.status = 'COMPLETE'
} catch {
    $record.status = 'STOPPED_WITHOUT_RETRY'
    $record.error = $_.Exception.Message
    throw
} finally {
    $record.ended_utc = [DateTime]::UtcNow.ToString('o')
    $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $root 'cleanup.json') -Encoding utf8
    $record | ConvertTo-Json -Depth 8
}
