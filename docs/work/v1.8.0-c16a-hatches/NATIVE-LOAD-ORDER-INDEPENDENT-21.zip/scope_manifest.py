"""Record independent Git-object boundary checks without relying on a live HEAD."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "snapshot"
BASE = "355766c6841137c8e8b5977be1fc3e25bc074fa7"
PIN = "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"
PROBE = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/BlockEntityLoadOrderingGameTests.java"
def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(TREE), *args])
def objects(commit, *paths):
    return {row.rsplit(b"\t", 1)[1].decode(): row.split()[2].decode() for row in git("ls-tree", "-r", commit, "--", *paths).splitlines()}
before = objects(BASE, "src")
after = objects(PIN, "src")
delta = [path for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)]
assert delta == [PROBE], delta
build_paths = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat", "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties"]
build_before = objects(BASE, *build_paths)
build_after = objects(PIN, *build_paths)
assert build_before == build_after
changed = git("diff", "--name-only", BASE, PIN).decode().splitlines()
expected = ["docs/work/v1.8.0-c16a-hatches/NATIVE-LOAD-ORDER-TASK-21.md", "docs/work/v1.8.0-implementation-log.md", PROBE]
assert changed == expected, changed
(ROOT / "candidate.patch").write_bytes(git("diff", "--binary", BASE, PIN))
manifest = dict(base=BASE, candidate=PIN, candidate_src_tree=git("rev-parse", PIN + ":src").decode().strip(),
                changed_paths=changed, source_changed_paths=delta, unchanged_source_files=len(before),
                build_input_objects=build_after, new_test_blob=after[PROBE],
                unchanged_policy_inputs={p: objects(BASE,p) == objects(PIN,p) for p in ("AGENTS.md", "PROJECT-CONFIG.md", "docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md", "docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md", "docs/decisions/ADR-068-V180-CLASSIC-NATIVE-OUTER-OPERATIONS.md")},
                git_status=git("status", "--porcelain").decode())
(ROOT / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", "utf-8")
print(json.dumps(manifest, indent=2))
