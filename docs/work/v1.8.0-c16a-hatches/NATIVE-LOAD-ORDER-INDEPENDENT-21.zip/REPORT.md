# Independent native LOAD-order source review and verification

Date: 2026-10-08. Delegated read-only Codex reviewer; no implementation,
further delegation or Claude invocation. This report covers committed test-side
development evidence, not physical hatch activation or release acceptance.

## Findings, ordered by severity

**Medium, original candidate only; resolved in corrected candidate:** original
`673ef97f` fixture calls `helper.makeMockServerPlayerInLevel()` at source line
125 ([retained original patch, line 222](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/candidate.patch#L222)).
The pinned helper constructs a bare Connection without a Channel. Independent
unfiltered native execution reproduced both new required tests failing at
`Connection.channel().pipeline()` during player login, before the helper returns
or placement assertions run. Consequently that candidate establishes no native
placement/LOAD scheduling observation. This is an executable fixture defect,
not an observed negative result about native LOAD timing.

The correction assigns a plain ServerPlayer before login and owns one
EmbeddedChannel ([corrected source lines 135-140](D:/GitHub/arce-v180-hatch-load-order-20261008/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/BlockEntityLoadOrderingGameTests.java#L135-L140)).
Its independent full native rerun passes both new cases and all 548 required
tests. Original complete results remain preserved, separate from corrected
results. The original exception occurs at the pinned PlayerList's login
registration call before player-list/UUID-map insertion; it does not demonstrate
a registered-player leak. The corrected fixture nevertheless handles an owned
player that becomes partially registered before a subsequent login failure.

**No unresolved introduced Critical, High, Medium or Low code finding was
identified in corrected candidate `3939dd55`.** Remaining limitations below are
explicit evidence boundaries, not newly invented acceptance obligations.
Strict repository validation still fails; native ERROR headers are not waived.

## Candidate identity and unchanged boundaries

- Base: `355766c6841137c8e8b5977be1fc3e25bc074fa7`.
- Original: `673ef97f4f1c19d1bfa6497b7709770e1d09aa28`;
  source tree `e100687e1d36189e16f76fde40b295fedea42dca`.
- Corrected: `3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b`;
  source tree `3a9ae41d52b04d47db0d0f5b29ce97803757aaef`;
  new probe blob `371280209cc495111ef212c6f0ef7832f82bbc81`.

Actual changed paths against base, for both candidates, are only:
[new GameTests](D:/GitHub/arce-v180-hatch-load-order-20261008/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/BlockEntityLoadOrderingGameTests.java),
[task record](D:/GitHub/arce-v180-hatch-load-order-20261008/docs/work/v1.8.0-c16a-hatches/NATIVE-LOAD-ORDER-TASK-21.md)
and [implementation log](D:/GitHub/arce-v180-hatch-load-order-20261008/docs/work/v1.8.0-implementation-log.md).
All 3,014 pre-existing source files and seven build inputs match base objects.
Identity, governance and ADR-060/064/068 inputs are unchanged. There is no
production behavior, registration, schema/ID, network, asset, source-cap,
save-policy, hook or physical hatch change. Reviewer edits are confined to this
new evidence leaf. Existing checkouts, indexes, user AGENTS changes, untracked
historical evidence, unmerged draft and sealed packets were not modified.

Mandatory applicable governance and context were read, including the owner
interception decision, pending private-operation review and LOAD-BINDING-20 at
`932600d9`. Native test observation cannot adopt that draft or accept ADR-068
PROPOSED/R-021 OPEN. Source-object boundaries are retained in
[original manifest](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/source-manifest.json)
and [corrected manifest](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/source-manifest-corrected.json),
with both candidate patches and the isolated correction patch.

## Test route, assertions and fixture assessment

The two new required tests retain their original 20-tick deadlines. They call
ordinary ServerPlayerGameMode.useItemOn with a registered vanilla chest Item
in SURVIVAL and CREATIVE, not a direct placement adapter or synthetic owner.
The correction adds player mode/abilities agreement assertions and does not
remove or relax original assertions. Each route verifies action completion;
installed registered ChestBlockEntity, correct Level and nonremoved state;
exact source ItemStack identity, Item/count/tag; native metadata ID/position and
empty Items before the next scheduled tick; queue absence at three observations;
and unchanged owner identity after natural delay 1. Source counts distinguish
survival debit from creative preservation.

The original helper subclass unconditionally overrides `isCreative()` to true,
even after selecting survival. Pinned placement bytecode distinguishes this
from source debit via Abilities.instabuild and source-count restoration via
ServerPlayerGameMode.isCreative; the helper override is not proof those native
branches had changed. Original execution never reached placement. The corrected
plain ServerPlayer removes that atypical override, and the added assertions
verify game mode, Player.isCreative and instabuild agree. An embedded connection
is a native server test fixture, not a real network/client observation.

Fixture source captures only two already-loaded BE-free cells at a bounded
position, registers a terminal GameTestListener before mutation, and owns one
player/channel. Constructor failures and synchronous RuntimeException/Error
perform cleanup; native terminal pass/failure/timeout listeners also close it.
Pinned GameTestInfo tick/terminal bytecode confirms the listener dispatch.
Identity-aware cleanup removes a player only if PlayerList maps its UUID to the
exact owned object, releases the owned channel and attempts both captured-state
restorations. It is idempotent, continues after caught removal/channel/restore
exceptions, retains them as suppressed on a primary failure, and propagates a
cleanup RuntimeException/Error when closing an otherwise successful test
([source lines 150-180](D:/GitHub/arce-v180-hatch-load-order-20261008/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/BlockEntityLoadOrderingGameTests.java#L150-L180)).

Restoration uses Block.UPDATE_ALL and does not inspect setBlock's boolean or
assert final state equality. Closing is marked before attempts, so failed
restoration is not retried. Native listener exceptions can propagate; this is
not protection against process death or arbitrary listener failure. Normal
cohort completion supports the exercised terminal route, not comprehensive
restoration or exception fault-injection proof. No broader rollback obligation
is inferred from these test-only cells.

Reflection reads the GameTestHelper testInfo reference and Level's two fresh
owner queues; it never mutates/drains/enqueues them or invokes onLoad.
Collection type and a 4,096-entry cap are checked before each bounded scan.
Unavailable/changed reflection fails explicitly. There are no chunk tickets,
unbounded world traversal or unmanaged static world collections.

## Pinned native dispatcher observation and hatch-ticket distinction

Mapped Forge `1.20.1-47.4.10_mapped_official_1.20.1` JAR SHA-256:
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Independent javap inspection and 13 relevant class-member hashes are retained in
[native identity](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/native-identity.json),
[selected bytecode](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/native-bytecode.txt)
and [full terminal bytecode](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/native-terminal-bytecode.txt).
Archive and all inspected members were rehashed unchanged after execution.

LevelChunk.setBlockState's fresh-owner route calls addAndRegisterBlockEntity.
That method installs the owner and, **when isInLevel is true**, adds its native
listeners/ticker and invokes onLoad directly at bytecode offset 41 before
returning. Whole-chunk registerAllBlockEntitiesAfterLevelLoad instead passes
owners into Level.addFreshBlockEntities; Level.tickBlockEntities drains fresh
and pending-fresh queues and invokes IForgeBlockEntity.onLoad through its pinned
bootstrap target. These distinct branches must not be conflated.

The passing tests observe installed chest identity, queue absence and pre-tick
serialization. **They do not directly instrument onLoad or count callbacks.**
Queue absence alone is not evidence of a callback. The synchronous dispatcher
conclusion combines the pinned bytecode with the exercised normal in-Level
placement route; it is not an installed physical hatch callback trace.

In unchanged
[ClassicHatchBlockEntity lines 53-117](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicHatchBlockEntity.java#L53-L117),
prepareLoaded opens one fresh LOAD GuardTicket, closes it and invokes
recordCompletedLoad, which opens another fresh LOAD GuardTicket. Both occur
inside the same
[onLoad invocation](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/classic/adapter/ClassicHatchBlockEntity.java#L305-L310),
not two callbacks or two native ticks. Its object matches the draft's unchanged
blob `6ad0200b1795be6408ed6e822849c10ec11f32ee`. Existing ordinary admission still
requires its observation context; this patch introduces no provisional authority.
Only LOAD-BINDING-20 U2's normal in-Level scheduling concern is qualified. It
does not establish both hatch ticket successes, adopt the proposal or close
the full physical LOAD/publication prerequisite.

## Actual independent commands and results

Two new detached local clones were pinned independently; the original run was
allowed to finish unchanged while corrected commands ran in a different clone.
Existing HEAD dependencies were released upon isolation. Java 17.0.7 and installed
offline Gradle caches were used; no full cache copy, manual cache editing,
install or global configuration occurred. Every command recorded C/D free space
above 10 GiB and received owned TEMP/TMP/TMPDIR/java.io.tmpdir settings.

All Gradle invocations below use `gradlew.bat` with
`--offline --no-daemon --no-build-cache`. Validators use installed Python with
`-B`; exact executable argv, cwd, times and command log hashes are in the
[original commands](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/cohort-02/commands.json)
and [corrected commands](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/cohort-03/commands.json).

| Actual command | Original cohort-02 (673ef97f) | Corrected cohort-03 (3939dd55) |
|---|---|---|
| Java `-version` | 0; 17.0.7 | 0; 17.0.7 |
| `clean build` | 0; actual :test | 0; actual :test |
| `runData` first | 0 | 0 |
| `git diff --exit-code` after first | 0; empty | 0; empty |
| `runData` second | 0 | 0 |
| `git diff --exit-code` after second | 0; empty | 0; empty |
| `scripts/validate_v180_content_ledger.py --require-accepted` | 0 | 0 |
| `scripts/validate_bootstrap_provenance.py` | 0 | 0 |
| `scripts/validate_repository.py --require-approved-identity` | 1; 44 passed/1 failed | 1; 44 passed/1 failed |
| `git diff --check` | 0 | 0 |
| Unfiltered `runGameTestServer` | 1; 548 complete, exactly both new cases failed | 0; all 548 required passed |

Each clean build has 378 archived JUnit suites, **2,179 actual testcase nodes**,
2,179 declared tests and zero failures/errors/skips; all 20 build tasks executed.
This is XML-counted execution, not a Gradle success banner substituted for units.
Original native ended `2026-10-08T11:22:25.032059Z`, with 64 ERROR/0 FATAL headers.
Corrected native ended `2026-10-08T11:36:29.314434Z`, with 62 ERROR/0 FATAL and
no reported test failures. Both logs contain the new two-test batch and complete
548-test terminal. These ERROR headers remain unwaived and are not individually
classified or cleared by this slice.

Strict validation logs are byte-identical between the two candidates:
SHA-256 `3ae8c961953f2ae7923345daf041a0621bade77583e3deb097267696c422d1ec`.
They retain pre-existing unsafe/oversized external Markdown targets and missing
inherited untracked ZIP links in the clean clones, capped at 256 link errors.
The task changes introduce no new Markdown links. The failure is retained,
not repaired, ignored or relabeled. **Both complete runners exit 1**; corrected
build/native success is not an overall verification PASS.

The initial instrumentation attempt returned build exit 1 before Gradle startup
because of forward-slash cmd.exe executable spelling; no tests ran. Its original
empty unit archive and raw logs/results remain at this leaf's top level. Only
the owned runner spelling was corrected, with a separate original-source cohort.
All discovery failures and permission clarifications are recorded in
[instrumentation notes](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/INSTRUMENTATION-NOTES.md).

Before cleanup, [independent audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/AUDIT.json)
reverified all 22 command hashes/byte counts, reparsed both archived XML sets,
recounted native terminals/failures/headers, rehashed owned artifacts and checked
both pinned clean HEADs. Root's corrected results were read only after our own
complete run. All three corrected artifact hashes match Root exactly:

| Development artifact | SHA-256 |
|---|---|
| Runtime JAR | `dd93cb968430eba12fb13539bbdfb29e943af1f16a6b6a8ebb3257a14d9a6b87` |
| API JAR | `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b` |
| Sources JAR | `ed57d4d0923c1571b421979a8e6068165b70dc048b755b8d8bdd8faf1c27d2a9` |

These hashes identify development artifacts, not S1 packaged server acceptance.

## Cleanup, retained evidence and completion boundary

One native PowerShell cleanup operation completed with exit 0 after terminal
process, resolved absolute containment, ancestor/subtree reparse checks and an
empty owned-worker list. It removed only our two newly created ended clones and
three local TEMP directories: **2,808,916,827 logical bytes**, 32,565 files.
No previously refused directory, source checkout, prior world, old packet,
shared cache or other agent output was targeted. No reviewer-owned disposable
output debt remains. This does not close inherited cleanup debt.
[Cleanup script](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/cleanup.ps1),
[log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/cleanup.log)
and [actual outcome](D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01/cleanup.json)
are retained. Source/build/world/TEMP copies are excluded from the evidence.

This leaf retains commands, failed and successful logs, XML ZIPs, results,
patches, inspection/audit/seal scripts and identity manifests. Its compact
checksum inventory and review-evidence ZIP seal the retained files; the ZIP
hash is adjacent. No candidate source was edited by the reviewer.

Completed scope: independent actual-diff/context/native inspection and both
committed-candidate reruns, including correction disposition and owned cleanup.
Unfinished scope/known risks: registered physical hatch callbacks, authentic
invocation and outcome provenance, exact provisional predicates/availability
fencing, both guarded save consumers, callback-free terminal publication,
Proto/generated/disk origins, final writer/unload/disposal, restart/crash or
cross-store conservation, real packets/clients/multiplayer, Forge 47.4.23,
V1/V2, progression and performance acceptance. U1/U3-U7, owner O1/O2/O3 choices
and both Medium physical-admission prerequisites remain open. No S1/S2 or
physical implementation/source assignment is approved by this review.

**Not all current-version Required Gates are satisfied.** v1.8 remains IN
PROGRESS with G0-G9 open; ADR-068 remains PROPOSED and R-021 OPEN. Scope is
eligible to record as reviewed test-side development evidence, preserving the
original failure and strict/log limitations, not a release or Gate PASS.

Next current-version action: integrate the exact corrected test-only source and
qualified U2 scheduling observation with its evidence. Continue the coupled
authentic placement/outcome and provisional LOAD/save/terminal contract review,
including origins and owner options, before assigning physical hatch work. Do
not interpret the two-ticket distinction as full M2 closure or start v1.9.
