"""Retain corrected-source boundaries without overwriting the original manifest."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / "scope_manifest.py").read_text("utf-8")
replacements = {
    'TREE = ROOT / "snapshot"': 'TREE = ROOT / "snapshot-corrected"',
    'PIN = "673ef97f4f1c19d1bfa6497b7709770e1d09aa28"': 'PIN = "3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b"',
    '"candidate.patch"': '"candidate-corrected.patch"',
    '"source-manifest.json"': '"source-manifest-corrected.json"',
}
for old, new in replacements.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(ROOT / "scope_manifest.py"), "exec"), {"__file__": __file__, "__name__": "__main__"})
