"""Independently retain selected native bytecode and archive/member identities."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
JAR = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
JAVAP = Path("C:/Program Files/Java/jdk-17.0.7/bin/javap.exe")
TARGETS = {
    "net.minecraft.world.level.Level": ["addFreshBlockEntities(", "tickBlockEntities(", "lambda$tickBlockEntities"],
    "net.minecraft.world.level.chunk.LevelChunk": ["addAndRegisterBlockEntity(", "registerAllBlockEntitiesAfterLevelLoad(", "setBlockEntity(", "setBlockState(", "isInLevel("],
    "net.minecraft.world.level.block.entity.BlockEntity": ["onLoad(", "saveWithFullMetadata("],
    "net.minecraft.gametest.framework.GameTestHelper": ["makeMockServerPlayerInLevel(", "runAfterDelay("],
    "net.minecraft.gametest.framework.GameTestHelper$3": ["isCreative(", "isSpectator("],
    "net.minecraft.gametest.framework.GameTestInfo": ["succeed(", "fail(", "finish(", "tickInternal(", "tick(", "addListener("],
    "net.minecraft.gametest.framework.GameTestServer": ["tickServer("],
    "net.minecraft.server.level.ServerPlayerGameMode": ["useItemOn("],
    "net.minecraft.server.players.PlayerList": ["placeNewPlayer(", "remove("],
    "net.minecraft.world.item.BlockItem": ["place(", "placeBlock("],
    "net.minecraft.world.item.ItemStack": ["useOn("],
    "net.minecraftforge.common.extensions.IForgeBlockEntity": ["onLoad("],
    "net.minecraftforge.common.ForgeHooks": ["onPlaceItemIntoWorld("],
}
identity = {"jar": str(JAR), "jar_sha256_before": hashlib.sha256(JAR.read_bytes()).hexdigest(), "members": {}, "commands": []}
output = []
with zipfile.ZipFile(JAR) as archive:
    for name, methods in TARGETS.items():
        member = name.replace(".", "/") + ".class"
        identity["members"][member] = hashlib.sha256(archive.read(member)).hexdigest()
        argv = [str(JAVAP), "-p", "-c", "-classpath", str(JAR), name]
        result = subprocess.run(argv, text=True, capture_output=True, check=True)
        identity["commands"].append({"argv": argv, "exit_code": result.returncode})
        sections = []
        for line in result.stdout.splitlines():
            if line.startswith("  ") and not line.startswith("    ") and line.rstrip().endswith(";"):
                sections.append([line])
            elif sections:
                sections[-1].append(line)
        selected = ["\n".join(part) for part in sections if any(key in part[0] for key in methods)]
        assert selected, name
        output.extend(["CLASS " + name, *selected])
argv = [str(JAVAP), "-p", "-v", "-classpath", str(JAR), "net.minecraft.world.level.Level"]
verbose = subprocess.run(argv, text=True, capture_output=True, check=True)
identity["commands"].append({"argv": argv, "exit_code": verbose.returncode})
start = verbose.stdout.index("BootstrapMethods:")
end = verbose.stdout.find("InnerClasses:", start)
output.extend(["CLASS net.minecraft.world.level.Level: bootstrap targets", verbose.stdout[start:end if end >= 0 else None]])
(ROOT / "native-bytecode.txt").write_text("\n\n".join(output) + "\n", "utf-8")
(ROOT / "native-identity.json").write_text(json.dumps(identity, indent=2) + "\n", "utf-8")
print(json.dumps(identity, indent=2))
