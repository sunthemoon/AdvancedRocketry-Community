# Independent native LOAD-order candidate review

You are a delegated read-only Codex reviewer. Do not use persona style, implement,
delegate further or call Claude. Review candidate 673ef97f4f1c19d1bfa6497b7709770e1d09aa28
against base 355766c6841137c8e8b5977be1fc3e25bc074fa7 in the repository
D:/GitHub/AdvancedRocketry-Community. The candidate also exists in Root's owned
D:/GitHub/arce-v180-hatch-load-order-20261008 worktree. Root retains implementation,
integration, commit and central-document ownership. Release your HEAD dependency
when you use an isolated pinned snapshot; do not move an existing HEAD.

Read live user AGENTS.md and its applicable mandatory governance, the candidate
NATIVE-LOAD-ORDER-TASK-21, owner interception decision, pending private-operation
review and LOAD-BINDING-20 at committed draft 932600d9. Inspect actual changed
source, surrounding native lifecycle APIs and applicable existing test utilities.

## Read/write/command permissions

Existing checkouts, pinned mapped-native JAR bytes, drafts and sealed packets
are read-only. Normal offline Gradle use of installed shared caches, including
Gradle's own lock/runtime metadata, is permitted; do not manually edit caches,
copy the complete cache or change global configuration. Rehash pinned native
inputs before/after. Manual writes and all clone/build/run/TEMP outputs are
limited to a NEW own leaf:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/hatch-native-load-order-independent-20261008-01.
You may create one clean local pinned clone and local TEMP under that leaf for
independent Java 17 build/unit and full unfiltered native GameTest execution.
Use command-local long-path support if necessary, not global Git configuration.
Allowed commands: read-only Git/status/hash/ZIP/XML/log/API inspection, offline
Gradle build/test/GameTest/DataGen/validators in that owned snapshot and owned
evidence script/report generation. Check free disk >10 GiB before sustained
commands. No edits to candidate code or test expectations. Cleanup is limited
to this review's personally created ended disposable output, using native
PowerShell after absolute containment, process ownership and reparse checks.
If that new cleanup is rejected, stop without retry or alternate-tool deletion.
Never target a previously refused directory. No installs, global configuration,
network player or external process termination.
No source build in an existing checkout.

## Duties and report

Evaluate test route fidelity, fixture lifetime/cleanup/ownership/bounds, native
reflection safety, meaningful assertions, source/context unchanged boundaries
and what the evidence does or does not establish for physical hatch LOAD timing.
Independently inspect pinned Forge bytecode and rerun relevant candidate checks,
including actual clean build unit results and complete native GameTests. Keep
all failed attempts and do not widen deadlines or weaken assertions. Interpret
only observed results; passing native tests are not Gate or physical activation
approval. Documentation changes do not grant an unadopted save or hook policy.

Report findings first ordered by severity with tight file/line references;
then candidate identity, actual commands/exit codes/test counts, observations,
limitations and next current-version action. Write REPORT.md and seal only compact
retained logs/results/patches/scripts/manifest, excluding source/build/TEMP/world
copies. Disclose actual cleanup outcomes and any retained disposable-output debt.
Return the final report path and notify Root of meaningful results or blockers.
