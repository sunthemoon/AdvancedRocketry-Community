# Reviewer instrumentation and ownership notes

This is a delegated read-only review of candidate
673ef97f4f1c19d1bfa6497b7709770e1d09aa28 against
355766c6841137c8e8b5977be1fc3e25bc074fa7. No implementation, delegation,
Claude invocation, existing checkout build or existing HEAD/index mutation occurs.

## Permission clarifications

Root clarified the task before cleanup: one native PowerShell cleanup of this
review's personally created ended disposable output is permitted after resolved
absolute containment, process and reparse checks. A rejected attempt must not be
retried or routed through another tool. No previously refused target is allowed.
The copied READ-TASK.md contains this boundary.

Root also clarified that ordinary offline Gradle operations on the installed
shared cache, including Gradle-managed lock/runtime metadata, are permitted.
The pinned mapped-native JAR bytes, existing checkouts and sealed packets remain
read-only. No manual cache modification/global configuration/install is allowed.
The original unexecuted runner cache-copy section was removed before any copy
started; no private cache tree was created. The original cache JAR is rehashed.

## Retained failed attempts

The first actual build invocation passed the cmd.exe executable as
`C:/Windows/System32/cmd.exe`. It returned exit 1 before Gradle startup, writing
`The syntax of the command is incorrect.` No unit test, compilation or native
test occurred in that attempt. Root-level commands.json/results.json/java.log/
build.log/unit-results.zip and review_runner-attempt-01.py retain it unchanged.
An independent simple `echo test` check reproduced the executable spelling
problem: a native Windows-backslash spelling printed the text, whereas the
forward-slash spelling did not. Only the owned runner executable spelling was
corrected. Cohort-02 has separate output and the same source, assertions and
20-tick new-test deadlines. No product test failure was removed or weakened.

Initial read-only discovery also used nonexistent guessed document names
`docs/versions/v1.8.0.md` and
`docs/decisions/ADR-064-CLASSIC-MACHINE-FAMILY-HATCH-AND-PUMP-CONTRACT.md`.
PowerShell emitted Cannot find path diagnostics. File discovery corrected these
to V1.8.0-CLASSIC-CONTENT-COMPLETION.md and
ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md, which were read.
An rg invocation using a literal `docs/decisions/ADR-064*` Windows argument
emitted OS error 123; native PowerShell file discovery supplied the exact file.
An early progress read of the not-yet-created GameTest latest.log returned exit 1.
These are reviewer instrumentation attempts, not candidate test failures.

Final source-reference discovery also tried a nonexistent `classic/` directory.
That read-only rg returned OS error 2; recursive filename discovery located
ClassicHatchBlockEntity under `machine/classic/adapter/`, which was read.

## Isolation

A new local clone was created with command-local core.longpaths=true,
--no-hardlinks and --no-checkout, then pinned to the candidate in detached state.
It initially has no Git status entries. Existing/main/candidate HEAD dependencies
were released immediately after pinning. Manual writes belong only to this new
review leaf. Every sustained verification command checks both C and D free space
above 10 GiB and receives owned TEMP/TMP/TMPDIR/java.io.tmpdir settings.
The root agent coordinates OpenPet; the reviewer does not send pet updates.

## Separate corrected candidate

After Root's original full native execution failed the two new cases, Root
authorized a second clean pinned snapshot/cohort under this same review leaf.
The corrected commit is 3939dd55f8f020a33d7f1c7c5d55bd6caa237c7b, with the
same base and three task-owned paths. The reviewer created snapshot-corrected
without changing the original snapshot or any existing checkout HEAD.
review_runner_corrected.py applies only candidate/snapshot substitutions to the
retained independent runner in memory and writes cohort-03 separately.

The reviewer's original complete cohort at 673ef97f ended on
2026-10-08T11:22:25.032059Z with native exit 1. It completed all 548 tests;
exactly both new LOAD-order cases failed during helper player login, before the
placement/source/serialization/queue assertions. That log has 64 ERROR headers
and zero FATAL. Both original JUnit/DataGen and the strict-link failure are
retained in cohort-02. No original test/source/output was changed to obtain a
different verdict. Corrected results remain a separate measured candidate.
