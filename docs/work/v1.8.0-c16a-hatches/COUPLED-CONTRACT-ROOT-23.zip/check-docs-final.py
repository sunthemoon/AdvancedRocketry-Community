import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a01703366c51a0e06788b95a1793b312dfa8a9a4'
DIR = 'docs/work/v1.8.0-c16a-hatches/'
FILES = [DIR + name for name in ['COUPLED-CONTRACT-TASK-23.md', 'COUPLED-CONTRACT-23.md',
          'COUPLED-VERIFICATION-MATRIX-23.md', 'COUPLED-CONTRACT-DISPOSITION-23.md']]
FILES += ['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
          'docs/work/v1.8.0-implementation-log.md']
checks = []
links = []
pins = []
for name in FILES:
    path = REPO / name
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    checks.append({'name': name + ': UTF8/no replacement chars/NUL',
                   'passed': '\ufffd' not in text and '\x00' not in text})
    checks.append({'name': name + ': no trailing whitespace',
                   'passed': all(line == line.rstrip(' \t') for line in text.splitlines())})
    pins.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    scan = text if 'COUPLED-' in name else '\n'.join(line for line in text.splitlines() if 'COUPLED-' in line)
    for target in re.findall(r'\]\(([^)]+)\)', scan):
        if re.match(r'https?://', target):
            continue
        target = target.split('#', 1)[0]
        resolved = path.parent / target
        good = resolved.is_file()
        links.append({'source': name, 'target': target, 'exists': good})
        checks.append({'name': name + ': link ' + target, 'passed': good})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
checks.append({'name': 'HEAD still review base', 'passed': head == BASE})
ag = hashlib.sha256((REPO / 'AGENTS.md').read_bytes()).hexdigest()
checks.append({'name': 'user AGENTS unchanged', 'passed': ag == 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'})
log = (REPO / FILES[-1]).read_bytes().replace(b'\r\n', b'\n')
original = subprocess.check_output(['git', 'show', BASE + ':' + FILES[-1]], cwd=REPO).replace(b'\r\n', b'\n')
marker = b'## 2026-10-08 verified native placement invocation qualification'
checks.append({'name': 'prior log body preserved', 'passed': log[log.index(marker):] == original[original.index(marker):]})
src = subprocess.check_output(['git', 'rev-parse', 'HEAD:src'], cwd=REPO).decode().strip()
checks.append({'name': 'complete src identity unchanged', 'passed': src == 'd12da7cfbb3aab3fc6bd21eab60dc08d56ce2025'})
result = {'checks': checks, 'passed': sum(row['passed'] for row in checks),
          'failed': sum(not row['passed'] for row in checks), 'input_pins': pins,
          'local_links': links, 'scope': 'Only new task23 local links; not the full inherited broken-link Gate.'}
(ROOT / 'doc-checks-final.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
raise SystemExit(bool(result['failed']))
