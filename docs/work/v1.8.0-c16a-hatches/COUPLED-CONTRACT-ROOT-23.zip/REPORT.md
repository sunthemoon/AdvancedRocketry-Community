# Root: coupled hatch contract 23

Date: 2026-10-08. Base/source: a01703366c51a0e06788b95a1793b312dfa8a9a4.
Branch: codex/v1.8.0-classic-content. Documentation/static-primary slice only.
Revision2 is independently reviewed at specification level only.
No physical source assignment/activation or release approval.

## Completed scope and design

Root directly authors the complete useful ordinary empty Item/Fluid hatch
successor and unexecuted verification matrix, then corrects independently found
assignment ambiguities. No Claude, delegated authorship, public API, ID/schema,
network, asset import, production source, build/dependency configuration, hook,
registration, runtime writer, risk acceptance, Gate waiver or tag is introduced.

The candidate connects a Level-lifecycle invocation slot and exact real inner
pre-write selection/allocation to two fresh actual LOAD tickets, provisional
receipt transfer, availability withholding, immutable origin/separate evolving
expectation, phase-specific removal/outcome checks, both early/late save
consumers and a callback-free terminal. All bindings are proposed, not installed.
Source/tool/drop numeric bounds and actual seams, authentic Proto/generated
origin and final writer/disposal still require concrete proof and policy. Both
prior Medium prerequisites, O1/O2/O3, ADR068 PROPOSED/R021 OPEN stay unchanged.

Primary native facts establish the correct LevelChunk carrier/FULL event,
Proto event/promotion and constructor copying, unreliable newChunk origin
shortcut, allocation-before-install and ordinary unload save-before-clearing
attempt, plus bundled Mixin0.8.5 injection-count checks. They do not prove
transformed coverage, ordinary authentication, provisional availability, final
flush, arbitrary callbacks, cross-store crash conservation or release readiness.

## Independent original review and corrections

Fresh reviewer /root/coupled_contract_review reviews original actual candidate
and fixed source/native inputs in its separate owned external leaf. Root reads
the complete original REPORT (14,807 bytes /SHA-256
9e363684b564261f6ddf2a32c734c9bd42546eba9bb2af28d813a8db57b99d18).
Its 2 Medium/1 Low findings remain sealed with original candidate/matrix bytes.

Revision2 transfers the successful second LOAD's temporary candidate into a
distinct operation-owned completed receipt before return/ticket close. Normal
prepareLoaded finally cleanup does not withdraw that receipt; later retirement,
clearLoadJoin, explicit receipt withdrawal or changed checkpoint/encoding/lifetime
does. It models unselected already-delegating Level state separately from the
selected-cell state, preserves once-only outer invocation and no-selection
return/throw/nested cleanup, and corrects updatePlacementContext nomenclature.
It explicitly avoids existing storage.installed's owner.isRemoved call in the
future local tail and adds positive/negative unexecuted matrix cases.

Frozen revised candidate SHA-256:
4749db7b3931a6ca98efdb8c98f4deaecefeb0f2a1e0ea6114a78ff7869f5d5a.
Frozen revised matrix SHA-256:
8e4a78463a1c7da138810dc690784cce0d41582413a42669c043c2c4bd8a19b2.
Fresh reviewer /root/coupled_contract_revision_review independently assesses
the complete revision and original report, not a source implementation. Root
reads its complete final REPORT, SHA-256
3a011910a4ec33f549f4471a41acbd08b05a631031bdc01b8b38467ce8770eff.
It finds no new introduced contract issue and confirms M1/M2/L1 addressed only
at draft level. The two prior full assignment prerequisites remain open.
The revision payload is sealed: 65 files /2,376,182 bytes; its archive has 67
entries /382,489 bytes /SHAa98b60c36daa3aa47fb6b7561453273ff52fd8ea6d201923de003cdc40fd9556.
Original/revision reports and their exact old/new inputs remain unchanged.

## Actual commands and results

Exact bounded native argv/member hashes/timestamps are in native-commands.json,
native-identities.json and extra-identities-commands.json. All eleven JDK17
javap invocations exit0; no game JVM/server is launched. Forge47.4.10 mapped
archive SHA95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e;
local bundled Mixin0.8.5 SHAca15a907e4d1f6b38cefed51d7df96a83347dcfb0bc8ced53111519e991d887d.

| Actually executed | Result |
| --- | --- |
| inspect-native.py / inspect-extra.py | 8+3 named <=512KiB native members and javap exits0. |
| check-primary.py | Exit1: wrong unload helper selector; script/trace preserved. |
| check-primary-r2.py | Exit1: 22/24, selected short rather than extended constructor; preserved. |
| check-primary-r3.py | Exit0: unchanged factual assertions pass 24/24 with exact constructor selector. |
| run-checks.py | Exit1 because its required revision2 selector failed; not retroactively replaced by revision3. |
| validate_v180_content_ledger.py | Exit0: 653 units, 186 PLANNED /154 REVIEW assets. |
| validate_bootstrap_provenance.py | Exit0: mechanically valid approved bootstrap provenance. |
| validate_repository.py --require-approved-identity | Exit1: 44 pass /one inherited broken-link check; 26,803 bytes /SHA26957c232ef8a3d33132ae6c51bd5b9846992708a4862df691f29f40dc0573f9. |
| git diff --check | Exit0, empty. |
| Initial check-docs.py | Exit0: 31 UTF-8/whitespace/new-link/HEAD/AGENTS/source/prior-log preservation checks. |
| Final check-docs-final.py | Exit0: 34/34 updated scoped document/link/identity/preservation checks. |
| 15 fixed private source/build input identities | Exact working bytes match BASE; no reproducible source exported. |

Original independent reviewer separately reruns 18 named javap members, with
all 11 shared primary outputs byte-identical; corrected static selectors pass
24/24. Ledger --require-accepted/provenance/whitespace pass. Its initial strict
launcher times out at its arbitrary 180 seconds; the unchanged normal follow-up
exits1 with 44 pass /one inherited link failure. Its log SHA-256 is
32d28fc9a5553bcddde509311b80211680210e3208bda7d76f402a2b181baf53,
different from Root's own log identity; equal counts do not imply equal logs.
All original instrument failures
and timeout remain in that sealed payload. The final revision review does not
reattribute these commands to its changed draft. It freshly executes 18 bounded
javap commands and 40/40 corrected native/source/draft controls after a preserved
39/40 class-wide LOAD-count instrumentation error, verifies 16 fixed source
pins and the original seal. No source export/cache/disposable build is created.
Both reviewers disclose concurrent Root-owned record changes and release all
read/HEAD interests; no zero total working-document drift is claimed.

All generic Gradle/native/player/restart/S2/V1/V2/package/runtime regression
commands are NOT_RUN for task23, not NOT_APPLICABLE. Qualification21/22 actual
source regressions remain attached only to their recorded SHAs; this is not
a rebuild or rerun of a017 or of the documentation delivery commit.

## Evidence, ownership and remaining work

Original independent payload is sealed: 137 files /3,493,871 bytes; 138 in-package
checksum rows verified. Its original archive is 139 entries /617,797 bytes,
SHAfcb15a08a5cbda72e40992f2f2e62303f6328e9c953fc6201fbedd838cae8a26.
Root packages only enumerated payload, not complete source/exports/build/worlds.
The reviewer removes its two own read caches once after inventory/hash/excerpt
retention: 269,521 logical bytes, no measured physical free-space gain. Inherited
files/other worktrees and old denied cleanup targets remain untouched.

Root-owned task docs/current associations/new log section and NEW evidence
archives are the only intended staged files. User AGENTS stays dirty and
SHAc2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09 unchanged.
No source/version/ledger delivery or risk adoption is inferred. Acceptance
cursor stays v1.0; v1.8 IN_PROGRESS/IMPLEMENTING and G0-G9 remain open.

The next v1.8 work is to resolve actual provenance/outcome, authentic origin/
handoff and final-writer technical bindings and the necessary owner dispositions
as a whole, not assign an unused helper or enable physical hatch prematurely.
No owner policy reply is recorded. OpenPet is unreachable; tooling/editing errors
are transparently retained in INSTRUMENTATION-NOTES.md. Root creates no game,
server/world copy or disposable build directory in this documentation task.

Root retains the exact revised candidate/matrix snapshots and only the three
tracked task-record diffs; no full historic implementation log or reproducible
source is exported. seal-root.py enumerates this new payload, checks each file
below 50MiB/total below 100MiB, creates only the NEW Root ZIP, verifies its CRC
and every in-package SHA row. The two independent packages are separately
generated from their original unmodified enumerated seals and verified against
all payload rows. Final source/build diff and whitespace checks exit0; index is
empty before scoped staging. Root commits/pushes only the ten declared task
records/archives after both reviewers' explicit release, not user AGENTS.
Actual commit/push/ZIP receipts are outside this immutable primary payload;
no future delivery SHA is prefilled into the evidence.
