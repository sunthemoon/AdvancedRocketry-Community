import hashlib
import json
import pathlib
import sys
import zipfile

LEAF = pathlib.Path(sys.argv[1]).resolve()
DEST = pathlib.Path(sys.argv[2]).resolve()
assert not DEST.exists()
checks = LEAF / 'SHA256SUMS.txt'
assert checks.is_file()
entries = []
for line in checks.read_text(encoding='utf-8').splitlines():
    digest, name = line.split('  ', 1)
    path = LEAF / name
    assert pathlib.Path(name).is_absolute() is False and '..' not in pathlib.Path(name).parts
    assert path.resolve().is_relative_to(LEAF)
    assert path.is_file() and path.stat().st_size < 50 * 1024 * 1024
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    entries.append(name)
assert sum((LEAF / name).stat().st_size for name in entries) < 100 * 1024 * 1024
entries.append('SHA256SUMS.txt')
assert len(entries) == len(set(entries))
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(entries):
        archive.write(LEAF / name, name)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for name in entries:
        assert archive.read(name) == (LEAF / name).read_bytes()
print(json.dumps({'archive': str(DEST), 'bytes': DEST.stat().st_size,
    'sha256': hashlib.sha256(DEST.read_bytes()).hexdigest(), 'entries': len(entries),
    'report_sha256': hashlib.sha256((LEAF / 'REPORT.md').read_bytes()).hexdigest()}))
