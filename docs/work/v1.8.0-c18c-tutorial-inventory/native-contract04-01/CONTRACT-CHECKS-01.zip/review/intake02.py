"""Correct prior-manifest list handling/known disposition locator; add exact Root Task04."""
import hashlib
import json
import pathlib

out = pathlib.Path(__file__).resolve().parent
old = (out / 'intake01.py').read_text(encoding='utf-8')
corrections = {
    "for name, expected in previous_review_manifest['files'].items():\n    assert pin(REVIEW / name) == {k: expected[k] for k in ('bytes', 'sha256')}":
        "for expected in previous_review_manifest['files']:\n    assert pin(REVIEW / expected['path']) == {k: expected[k] for k in ('bytes', 'sha256')}",
    'NATIVE-CONTRACT-03-DISPOSITION.md': 'NATIVE-REVIEW-DISPOSITION-03.md',
    "'Root Task04 not yet supplied; no cumulative verdict.'": "'Root Task04 received; no cumulative verdict from intake.'",
    "'qualification': 'Proposal03 and historical contexts only; Root Task04 not yet supplied; no cumulative verdict.'":
        "'qualification': 'Exact proposal03, historical contexts and received Root Task04 intake; no cumulative verdict.'",
    "(OUT / 'INPUTS-01.json')": "(OUT / 'INPUTS-02.json')",
}
new = old
for before, after in corrections.items():
    if before not in new and before == "'Root Task04 not yet supplied; no cumulative verdict.'": continue
    assert new.count(before) == 1, before
    new = new.replace(before, after)
insert = """
task4 = ROOT / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md'
task_pin = pin(task4)
assert task_pin == dict(bytes=7055, sha256='3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43')
(OUT / 'NATIVE-TASK-04.md').write_bytes(task4.read_bytes())
result['root_task04'] = {'path': str(task4), **task_pin, 'committed_at_intake': False}
"""
assert new.count("(OUT / 'INPUTS-02.json').write_text") == 1
new = new.replace("(OUT / 'INPUTS-02.json').write_text", insert + "\n(OUT / 'INPUTS-02.json').write_text")
(out / 'INTAKE-CORRECTION-02.json').write_text(json.dumps({'before_sha256': hashlib.sha256(old.encode()).hexdigest(),
    'after_derived_sha256': hashlib.sha256(new.encode()).hexdigest(), 'corrections': corrections,
    'qualification': 'Reader-only tooling correction; no source/proposal changes; original failure preserved.'}, indent=2) + '\n', encoding='utf-8')
exec(compile(new, str(out / 'intake02.py'), 'exec'))
