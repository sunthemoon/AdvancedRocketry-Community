# Independent C18 native proposal03 / cumulative Task04 review

Date: 2026-10-05. Role: delegated independent technical contract reviewer.

## Findings

No unresolved Critical, High, Medium or Low finding was identified in the exact
proposal03 + Task04 technical scope inspected here (**0 C /0 H /0 M /0 L**).
This is not an implementation, native-run, gameplay/API, ledger or version-Gate
verdict. The two original Task03 Medium findings remain immutable historical
findings; the corrections below resolve their contract-level incompatibilities,
not a previously executed native failure.

### Historical M1: phase properties provenance — addressed in the proposed contract

[Cumulative proposal](OWNERSHIP-PROPOSAL-03.md), lines 112–183, and
[Task04](NATIVE-TASK-04.md), lines 45–79, distinguish configured snapshot,
driver-observed prelaunch, independently observed live and actual stopped bytes.
The marker/snapshot remain byte-exact; seed preboot equals that snapshot, reload
preboot equals the actual seed-stopped receipt, and each stopped file equals its
own host's observed live file. Native startup serialization may change raw bytes
only when the entire bounded decoded map, including unknown entries, agrees.
No restore, normalization, default insertion or progress reconstruction is allowed.

The native Main → forceSave → Settings.store → Forge SortedProperties route and
the configured JDK Writer Date header are independently re-inspected in
[selected primary facts](PRIMARY-04.json). The former same raw hash across boots
is therefore no longer required. The fixed launch digest is explicitly a trusted
driver's past observation, not a claim that the hook observed preboot bytes.
The immutable snapshot and same-host live/stopped equality still detect
unexplained rewrites. Reader restrictions are a test-host eligibility subset,
not a general Java Properties or gameplay parser policy.

### Historical M2: repeated forced-add after restart — addressed in the proposed contract

[Cumulative proposal](OWNERSHIP-PROPOSAL-03.md), lines 185–228, and
[Task04](NATIVE-TASK-04.md), lines 80–96, allow one seed-only literal add; reload
has no add/remove/query/replacement setup. Both phases must separately observe
all 121 fixed persistent members and all 121 loaded `getChunkNow` results before
either constructor. Missing state refuses without repair, retry or new budget.

The independently pinned `getForcedChunks()` route returns the SavedData member
set/empty set and does not issue a world-chunk creation request. This does not
claim that native SavedData observation or normal server startup is globally
side-effect-free. The actual forced-set save/load/startup references remain pinned
in [primary facts](PRIMARY-04.json).

The multiple-success lambda's first template argument is its ChunkPos parameter,
not the changed counter (descriptor and local-1 reference at offset 24 checked).
The fixed native English template keys were independently verified directly in
their named primary archive. The final protocol correctly refuses numeric-count
substitution and does not equate acknowledgement text with 121 newly added
members. Exact rendered success, member restoration and loaded-state observations
remain future native obligations; no command was executed in this review.

## Exact reviewed identities

| Input | SHA-256 / qualification |
|---|---|
| Root Task04, 7,055 bytes | `3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43`; proposed and uncommitted at intake |
| Author proposal03 manifest | `2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1`; all 80 payloads /875,858 bytes independently checked |
| Cumulative proposal Markdown | `f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca` |
| Protocol03 | `fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc` |
| Two-document comparative diff | `986f67a1791813fa19e1564fc67aa438a8984b0ed4e254d51c673cc9296404f9`; 51,094 bytes; raw-byte regeneration exact |
| Author handoff | `cf434cbac4b2977c8521c1580944a5523fa9ce38bd1e7c88424bce32192b2afa` |
| Original Task03 | `c75fec1a7f1cb5291147abb838712ed695c7c011f060bff1f6f7378011a6b6d4`; fixed Git object at `16e555111ad957e80570317cb103fb9dadc9895a` |
| Original independent two-Medium report | `1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0`; [preserved report](PRIOR-REVIEW-03.md) |
| Proposal02 manifest | `f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955`; all 52 payloads checked |
| Live governance AGENTS | `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`; mandatory governance inputs postchecked unchanged |
| Configured mapped Forge 47.4.10 primary JAR | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`; nine selected class entries checked |
| Configured JDK17.0.7 source archive | `eb661f48670025c35656435c2f716180dd913968daa7000e79c3a27288500059`; selected Properties member only |

Actual proposal source facts are fixed at
`a5abc34809891d6b10724ee60ab9b5e97f036bae`. The independently read
ClassicInventoryAdvancements and ConnectedTestPlayers Git objects are pinned in
[final input check](FINAL-07.json). Mutable Root HEAD was observed separately as
`9fce551ea9389ce37a94f804aa0e817399586a7e`; it is context, not a rebind of source
facts or earlier dispositions. No current status or moving HEAD was substituted
for normative protocol bytes.

Original provenance locations (inline, not implied bundled archive closure):

- Author: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e`.
- Prior author: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a`.
- Prior review: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f`.
- Root Task04: `D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md`.

[Intake ledger](INPUTS-03.json) records exact author/prior/governance identities.
[Final checks](FINAL-07.json) verify all 80 +52 +46 manifested payloads remain
unchanged and all four Task04 normative companion hashes match. The selected
Markdown/protocol/diff/handoff and old report are copied individually for exact
review-reference closure, not a full source/archive/runtime export.

## Scope preservation and actual checks

Actual structured comparison has 15 unchanged top-level fields, seven changed,
three added and no removed field. The only corrections are test-only phase
provenance/setup and their explicit observation fields/revision. The final host
revision is 3; old markers/receipts refuse rather than migrate.

The unchanged fields independently compared include both identities/positions,
all six goals/targets, criterion, empty-native-inventory shape, seed12/reload11
events, common/player/saved-criterion schemas, failures, all original byte/depth/
node/count ceilings and deadlines, and forbidden progression authorities.
All original host-admission fields except its revision and every non-PREFLIGHT
payload are byte-value equal. Current-inventory suit conjunction, connected
non-FakePlayer/ordinary listener, dual preconstruction admission, local partial
join/disposal, raw native locations and vanilla reload obligations remain.

The properties addition admits only the explicit native-compatible subset:
16,384 raw bytes, 1,023 pairs /2,048 nodes, strict UTF-8/line/escape/key rules,
duplicate refusal, whole-map equality and no secret-value logging. The new
receipt object has only actual bytes/hash and grants no loaded progress.
The whole 300-second budget and two 110-second hosts remain; probes/setup consume
existing remaining time, and native calls are not claimed preemptible.

| Actual command | Result and preserved evidence |
|---|---|
| `python -B intake01.py` | exit 1: reviewer treated a manifest list as a dictionary; [raw](intake-01.log) |
| `python -B intake02.py` | exit 1: reviewer guessed nonexistent generic version filename; [raw](intake-02.log) |
| `python -B intake03.py` | exit 0: corrected read-only intake; [raw](intake-03.log), [pins](INPUTS-03.json) |
| `python -B primary04.py` | exit 0: nine selected native classes /JDK writer+separator facts, unchanged inputs; [raw](primary-04.log), [facts](PRIMARY-04.json) |
| `python -B controls05.py` | exit 0: actual 44 tests, 0 failures/errors/skips; [raw](controls-05.log), [counts](CONTROLS-05.json) |
| `python -B final06.py` | exit 1: reviewer text-mode newline normalization made raw comparative diff unequal; [raw](final-06.log), [command](final-06.command.json) |
| `python -B final07.py` | exit 0: preserve original CRLF/LF bytes; exact diff/Task04/178 payload postchecks/native English keys; [raw](final-07.log), [command](final-07.command.json), [correction](FINAL-CORRECTION-07.json) |

The 44 tests are the exact extracted 18 prior +20 final author model bodies plus
six independently written controls. Only AST function/class bodies execute;
sealed author runners/top-level writes do not. Independent controls exercise
all fixed member-loss edges independently of loaded state, distinct raw Date
headers with whole-map equality/unknown-value changes, syntax/escape/duplicate/
control/UTF-8 refusals, byte/pair ceilings, unchanged goals/events/limits, and
receipt/no-reload-command boundaries. They are specification/parser models,
not actual native parser, logger, world, callback or server outcomes.

The initial missing manifest exploratory read is qualified separately in
[exploration record](EXPLORATION-01.md), not represented as an original raw
native failure. The original final06 helper/log is not overwritten: old protocol
CRLF versus new LF requires raw decoding, not `read_text` normalization. The
final exact comparative diff is valid; that tooling failure is not a proposal
defect. All original author locator/assertion/extraction and 37-test /3-failure
acknowledgement attempts remain bound by its unchanged 80-entry manifest.

## Disposition and remaining obligations

The exact cumulative technical contract is eligible for Root's separate
bounded implementation assignment after preservation/adoption. This review
neither adopts it nor authorizes configuration changes or a native run. Task04
correctly names the frozen cumulative protocol as normative rather than letting
its overview replace omitted details; Task03 and earlier reviews remain history.

Still required, without increased budgets or repair:

1. Select an independently pinned copy-only source host meeting the strict
   properties subset, native default map, scene, ownership/cache and error rules.
2. Implement and independently review the actual four test-only responsibilities,
   bounded parser/record readers, getters/reflection identities and failure/local
   channel cleanup; preserve all original controls and add actual caller checks.
3. Bind the future committed source/JAR/library cohort and full source regression.
   Verify the actual rendered native acknowledgement, startup/live/stopped hash
   chain, restored forced membership and all loaded cells under the unchanged time.
4. Observe both real hosts' six ordinary inventory listeners, pre-acquisition
   loaded progress, clean stop and actual vanilla UUID/timestamp native records;
   independently audit results and unchanged original worlds/artifacts.

No suitable host has been selected here. No Java, Gradle, configuration, native
server, profile lookup, client, deletion, source/Git mutation or dependency
installation ran. No official class body, JAR, mapping, asset or world was copied.
No V1/V2/GPU, arbitrary background load/crash durability, R-021/Guard writer,
other C18 capability, ledger delivery or G0–G9 closure follows. v1.8 Required
Gates remain open. This leaf produces only small read-only review evidence under
the requested D project-parent directory; it creates no C helper/output.
