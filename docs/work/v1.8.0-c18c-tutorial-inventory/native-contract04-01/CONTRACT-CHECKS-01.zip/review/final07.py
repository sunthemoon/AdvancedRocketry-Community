"""Preserve failed final06; correct only reviewer newline intake semantics."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
old = (OUT / 'final06.py').read_bytes()
text = old.decode('utf-8')
before = "a, b = (OLD / old_name).read_text(encoding='utf-8'), (AUTHOR / new_name).read_text(encoding='utf-8')"
after = "a, b = (OLD / old_name).read_bytes().decode('utf-8'), (AUTHOR / new_name).read_bytes().decode('utf-8')"
assert text.count(before) == 1
text = text.replace(before, after).replace("'FINAL-06.json'", "'FINAL-07.json'")
(OUT / 'FINAL-CORRECTION-07.json').write_text(json.dumps({
    'original_source_sha256': hashlib.sha256(old).hexdigest(),
    'derived_source_sha256': hashlib.sha256(text.encode('utf-8')).hexdigest(),
    'actual_correction': {'before': before, 'after': after},
    'cause': 'read_text normalizes old protocol CRLF; exact comparison preserves original line endings with read_bytes().decode().',
    'qualification': 'Reviewer tooling correction, not a candidate change; original final06 source/log/exit1 remains intact.'
}, indent=2) + '\n', encoding='utf-8')
exec(compile(text, str(OUT / 'final06.py') + '[newline-preserving-derived]', 'exec'))
