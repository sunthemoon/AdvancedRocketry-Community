import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
OLD = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
REVIEW = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
FIXED = '16e555111ad957e80570317cb103fb9dadc9895a'
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def manifest(directory, filename, expected):
    actual = pin(directory / filename); assert actual['sha256'] == expected
    data = load(directory / filename)
    raw = data['files']; entries = raw if isinstance(raw, list) else [{'path': p, **e} for p, e in raw.items()]
    checked = {}
    for entry in entries:
        name = entry['path']; rel = pathlib.PurePosixPath(name)
        assert not rel.is_absolute() and '..' not in rel.parts
        value = pin(directory / name)
        assert value == {k: entry[k] for k in ('bytes', 'sha256')}, name
        checked[name] = value
    return {'manifest': actual, 'files': checked, 'bytes': sum(v['bytes'] for v in checked.values())}
new = manifest(AUTHOR, 'EVIDENCE-MANIFEST.json', '2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1')
prior = manifest(OLD, 'EVIDENCE-MANIFEST.json', 'f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955')
previous_review_manifest = load(REVIEW / 'INTERNAL-MANIFEST.json')
previous_review = {'report': pin(REVIEW / 'REVIEW-03.md'), 'manifest': pin(REVIEW / 'INTERNAL-MANIFEST.json')}
assert previous_review['report']['sha256'] == '1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0'
for name, expected in previous_review_manifest['files'].items():
    assert pin(REVIEW / name) == {k: expected[k] for k in ('bytes', 'sha256')}
delta = load(AUTHOR / 'PROTOCOL-DELTA-03.json')
old_protocol = load(OLD / 'PROTOCOL-02.json'); protocol = load(AUTHOR / 'PROTOCOL-03.json')
actual_delta = {'unchanged_top_level_keys': [k for k in old_protocol if k in protocol and old_protocol[k] == protocol[k]],
               'changed_top_level_keys': [k for k in old_protocol if k in protocol and old_protocol[k] != protocol[k]],
               'new_top_level_keys': [k for k in protocol if k not in old_protocol],
               'removed_top_level_keys': [k for k in old_protocol if k not in protocol]}
for key, value in actual_delta.items(): assert value == delta[key], key
assert pin(OLD / 'OWNERSHIP-PROPOSAL-02.md')['sha256'] == delta['base_proposal_sha256']
assert pin(OLD / 'PROTOCOL-02.json')['sha256'] == delta['base_protocol_sha256']
assert pin(AUTHOR / 'OWNERSHIP-PROPOSAL-03.md')['sha256'] == delta['new_proposal_sha256']
assert pin(AUTHOR / 'PROTOCOL-03.json')['sha256'] == delta['new_protocol_sha256']
assert pin(AUTHOR / 'PROPOSAL-03.diff')['sha256'] == delta['comparison_diff_sha256']
governance_names = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/v1.8.0.md', 'docs/05-MASTER-TEST-PLAN.md',
    'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md', 'docs/16-POST-1.0-VERSION-ROADMAP.md',
    'docs/17-V1PLUS-QUALITY-BUDGETS.md', 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
governance = {name: pin(ROOT / name) for name in governance_names}
git_objects = {}
for name in ['docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md',
             'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-CONTRACT-03-DISPOSITION.md']:
    r = subprocess.run(['git', 'show', FIXED + ':' + name], cwd=ROOT, capture_output=True)
    git_objects[name] = {'command': ['git', 'show', FIXED + ':' + name], 'exit': r.returncode,
        'stderr': r.stderr.decode('utf-8', errors='replace')}
    if r.returncode == 0:
        git_objects[name].update(bytes=len(r.stdout), sha256=hashlib.sha256(r.stdout).hexdigest())
        (OUT / pathlib.PurePosixPath(name).name).write_bytes(r.stdout)
result = {'qualification': 'Proposal03 and historical contexts only; Root Task04 not yet supplied; no cumulative verdict.',
    'proposal03': new, 'proposal02': prior, 'prior_review': previous_review, 'actual_top_level_delta': actual_delta,
    'governance': governance, 'fixed_git_objects': git_objects,
    'source_basis': protocol['source_commit'], 'task_context_commit': FIXED}
(OUT / 'INPUTS-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Proposal03 payloads', len(new['files']), new['bytes'], 'all hashes exact; proposal02', len(prior['files']), 'prior review all entries exact.')
print('Structured delta exact:', actual_delta)
print('Named Git intake outcomes:', [(name, entry['exit']) for name, entry in git_objects.items()])
