# Read-locator observation

The first exploratory PowerShell command requested `INTERNAL-MANIFEST.json` in
the new proposal03 leaf. That literal file does not exist; the actual locator is
`EVIDENCE-MANIFEST.json`. Get-Content produced its missing-path error, while the
combined shell later read AGENTS and exited0. This is a transcription of the
visible tool observation, not an invented original raw log or a candidate defect.
The correction does not change any proposal/packet. No Java/native/configuration
or source action occurred.
