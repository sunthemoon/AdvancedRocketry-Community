"""Replay exact author model bodies read-only, plus independent phase/grammar controls."""
import ast
import copy
import hashlib
import json
import math
import pathlib
import re
import struct
import unittest

OUT = pathlib.Path(__file__).resolve().parent
B = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
P = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
ORIGINAL = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
NEW = load(B / 'PROTOCOL-03.json'); OLD = load(P / 'PROTOCOL-02.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
inputs = {str(p): sha(p.read_bytes()) for p in [B / 'controls01.py', B / 'controls02.py', B / 'controls03.py',
    B / 'PROTOCOL-03.json', B / 'PRIMARY-05.json', B / 'PRIMARY-06.json', P / 'controls06.py', P / 'PROTOCOL-02.json', ORIGINAL / 'PROTOCOL-01.json']}
def definitions(path, ns):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
    for node in nodes:
        for call in (n for n in ast.walk(node) if isinstance(n, ast.Call)):
            assert not isinstance(call.func, ast.Attribute) or call.func.attr not in {'write_text', 'write_bytes', 'mkdir', 'unlink', 'Popen', 'run'}, (path, node.name)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), ns)
base = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'NEW': NEW, 'OLD': load(ORIGINAL / 'PROTOCOL-01.json'), 'HOST': NEW['host_admission'],
    'FLOAT': lambda s: struct.unpack('>f', bytes.fromhex(s))[0], 'DOUBLE': lambda s: struct.unpack('>d', bytes.fromhex(s))[0],
    'BITS': lambda d: struct.pack('>d', d).hex(), 'ENVELOPE': [(x, z) for x in range(-5, 6) for z in range(-5, 6)],
    'WIDTH': struct.unpack('>f', bytes.fromhex('3f19999a'))[0], 'HEIGHT': struct.unpack('>f', bytes.fromhex('3fe66666'))[0],
    'EPSILON': struct.unpack('>d', bytes.fromhex('3e7ad7f29abcaf48'))[0]}
definitions(P / 'controls06.py', base)
revision = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'Path': pathlib.Path, 're': re, 'NEW': NEW, 'OLD': OLD, 'B': B, 'P': P, 'sha': sha}
definitions(B / 'controls01.py', revision)
revision['OriginalRevisionControls'] = revision['RevisionControls']
revision['original_ack'] = revision['ack_payload_model']
definitions(B / 'controls02.py', revision)
revision['ack_payload_model'] = revision['native_ack_payload_model']
revision['prior_properties'] = revision['properties_model']
definitions(B / 'controls03.py', revision)
revision['properties_model'] = revision['final_properties_model']

def independent_properties(raw):
    """Small independently written parser for the specified test-only line subset."""
    if type(raw) is not bytes or not 1 <= len(raw) <= 16384 or raw.startswith(b'\xef\xbb\xbf'): raise ValueError('bytes')
    text = raw.decode('utf-8', errors='strict')
    text = text.replace('\r\n', '\n')
    if '\r' in text or any((ord(c) < 32 and c != '\n') or ord(c) == 127 for c in text): raise ValueError('line')
    result = {}
    def piece(s):
        value = ''; cursor = 0
        while cursor < len(s):
            c = s[cursor]
            if c == '\\':
                cursor += 1
                if cursor == len(s) or s[cursor] not in NEW['properties_reader']['escapes']: raise ValueError('escape')
                value += NEW['properties_reader']['escapes'][s[cursor]]
            else: value += c
            cursor += 1
        return value
    for line in text.split('\n'):
        if not line or line[0] in '#!': continue
        cursor = 0
        while cursor < len(line):
            c = line[cursor]
            if c == '\\': cursor += 2; continue
            if c == '=': break
            if c == ':' or c.isspace(): raise ValueError('key syntax')
            cursor += 1
        if cursor >= len(line): raise ValueError('separator')
        key, val = piece(line[:cursor]), piece(line[cursor+1:])
        if not key or key in result or (line[cursor+1:] and line[cursor+1].isspace()): raise ValueError('key/value')
        if len(result) >= 1023: raise ValueError('pairs')
        result[key] = val
    return result

class IndependentControls(unittest.TestCase):
    def test_every_fixed_member_edge_is_separate_from_loading(self):
        envelope = [(x, z) for x in range(-5, 6) for z in range(-5, 6)]
        self.assertEqual(121, len(envelope)); self.assertEqual(len(envelope), len(set(envelope)))
        self.assertEqual([], NEW['forced_setup']['reload']['commands'])
        for lost in envelope:
            members = set(envelope) - {lost}; loaded = set(envelope)
            self.assertFalse(all(p in members and p in loaded for p in envelope))
            self.assertFalse(all(p in loaded and p in members for p in envelope))
    def test_phase_hash_chain_is_not_same_header_assumption(self):
        configured = b'#configured\ngamemode=adventure\nunknown=opaque\n'
        stopped1 = b'#Sun Oct 05 00:00:01 UTC 2026\nunknown=opaque\ngamemode=adventure\n'
        stopped2 = b'#Sun Oct 05 00:00:02 UTC 2026\ngamemode=adventure\nunknown=opaque\n'
        self.assertEqual(independent_properties(configured), independent_properties(stopped1))
        self.assertEqual(independent_properties(configured), independent_properties(stopped2))
        self.assertEqual(3, len({sha(configured), sha(stopped1), sha(stopped2)}))
        self.assertIn('seedstopped', NEW['properties_lifecycle']['reload_boot'].replace('_', '').replace(' ', ''))
        self.assertNotEqual(independent_properties(configured), independent_properties(stopped2.replace(b'opaque', b'different')))
    def test_subset_alias_duplicates_and_escape_values(self):
        accepted = [b'a\\:b=c:d\n', b'a\\=b=value\n', b'escaped=\\ leading\\tvalue\n', 'unicode=中文\n'.encode(), b'a=one\r\nb=two\r\n']
        for raw in accepted:
            with self.subTest(raw=raw): self.assertEqual(independent_properties(raw), revision['properties_model'](raw))
        refused = [b'a:b=value\n', b'a=one\na=two\n', b'a\\:b=x\na\:b=y\n', b'a= leading\n', b'a=\\u0020\n',
                   b'#comment\x00\na=b\n', b'a=x\r', b'a=x\\\nnext=value\n', b'\xef\xbb\xbfa=b\n', b'a=\xff\n']
        for raw in refused:
            with self.subTest(raw=raw):
                with self.assertRaises((ValueError, UnicodeError)): independent_properties(raw)
                with self.assertRaises((ValueError, UnicodeError)): revision['properties_model'](raw)
    def test_pair_byte_ceiling_before_growth(self):
        accepted = b''.join(('k%d=v\n' % i).encode() for i in range(1023))
        self.assertEqual(1023, len(independent_properties(accepted)))
        with self.assertRaises(ValueError): independent_properties(accepted + b'overflow=v\n')
        with self.assertRaises(ValueError): independent_properties(b'x=' + b'v' * 16383)
    def test_cumulative_limits_events_goals_are_exact(self):
        for key in ('fixed_identities', 'goal_ids', 'criterion', 'native_empty_inventory_shape', 'item_counts_order',
                    'seed_events', 'reload_events', 'deadlines_seconds', 'ceilings', 'forbidden_authorities'):
            self.assertEqual(OLD[key], NEW[key], key)
        self.assertEqual(23, len(NEW['seed_events']) + len(NEW['reload_events']))
    def test_properties_supplement_has_no_progress_authority(self):
        self.assertEqual({'bytes', 'sha256'}, set(NEW['external_receipt_fields']['seed_stopped_properties']))
        self.assertEqual([], NEW['forced_setup']['reload']['commands'])
        self.assertEqual('seed_only', NEW['host_admission']['console_setup_phase'])
        self.assertTrue(NEW['properties_lifecycle']['no_receipt_on_failure'])

suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(base['Controls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(revision['CompletedRevisionControls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(IndependentControls)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert all(sha(pathlib.Path(p).read_bytes()) == value for p, value in inputs.items())
(OUT / 'CONTROLS-05.json').write_text(json.dumps({'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skipped': len(result.skipped), 'author_bodies_extraction': 'AST function/class definitions only, unchanged 18+20 controls; sealed runners/writes not executed.',
    'independent_methods': 6, 'inputs': inputs, 'inputs_unchanged': True,
    'qualification': 'Pure specification/parser models and primary facts; no actual JDK/native writer/log/callback/host outcomes.'}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
