# C18c native contract revision03 independent review

Date: 2026-10-05. Role: delegated independent contract reviewer. No implementation or runtime execution.

## Findings

### M1 — The same raw properties hash across native boots conflicts with the native startup writer

**Medium.** [Task03](NATIVE-TASK-03.md), lines 42–44, adopts the exact properties binding in [proposal02](OWNERSHIP-PROPOSAL-02.md), lines 104–110: hash the pre-boot `server.properties` into the marker and use the same file/hash on reload. `PROTOCOL-02.json` additionally describes `copy_properties_sha256` as the actual configured-copy hash. No native rewrite qualification or distinct before/after phase binding is defined.

Independently parsed pinned primary routes:

- `net.minecraft.server.Main.main(String[])`, offset 471: `DedicatedServerSettings.forceSave()` before host startup. [Primary02](PRIMARY-02.json).
- `DedicatedServerSettings.forceSave()`, offset 8: invokes the properties store; `Settings.store(Path)`, offset 19: delegates to Forge `SortedProperties.store(Properties,Writer,String)`. [Primary01](PRIMARY-01.json).
- Forge `SortedProperties` declares the static three-argument store, not an override of `Properties.store(Writer,String)`; its delegate at offset 16 uses that inherited writer. [Primary02](PRIMARY-02.json).
- The configured JDK 17.0.7 source member `java.base/java/util/Properties.java`, line 906, and compiled `Properties.store0` independently identify a fresh Date comment. The compiled Date construction/toString references are offsets 22/26/29. Both source archive and binary module/member identities are pinned in [Properties01](PROPERTIES-01.json).

Consequently, two normal native stores at different wall-clock seconds can produce different raw hashes despite identical admitted property values. The first native rewrite can already differ from the marker's pre-boot file. A strict same-hash reload binding therefore refuses an otherwise valid cohort, or pressures an implementation to restore/rewrite or silently normalize bytes outside the specified policy. This is a static writer/contract incompatibility, **not an observed native failure**. The independent two-header control demonstrates the hash distinction only; it does not impersonate an emitted Minecraft file.

**Minimal required revision:** define phase-specific raw properties provenance for configured/pre-boot, actual native-written stopped state and reload, together with exact non-mutating validation of the allowed configuration values. Preserve every raw hash and reject unexpected property changes. The contract must explicitly define the binding rather than silently removing comments, resetting the file, or relabelling unequal hashes as equal. No product policy or gameplay change is required to describe this test-host lifecycle.

### M2 — Repeating the fixed add command on reload reaches the native already-added refusal

**Medium.** [Task03](NATIVE-TASK-03.md), lines 45–48, incorporates [proposal02](OWNERSHIP-PROPOSAL-02.md), lines 112–119: issue `forceload add -80 -80 95 95` after **each** startup; a native refusal fails. A successful seed adds all 121 members and the contract requires a real clean stop in that same copy. It neither removes those members nor defines a reload observation alternative.

[Primary03](PRIMARY-03.json) independently establishes:

- `ServerLevel.setChunkForced(int,int,boolean)` uses `LongSet.add` at 54; only changed membership dirties/updates state (94/109).
- `ForcedChunksSavedData.save/load` writes and reads the `Forced` long array. `MinecraftServer.prepareLevels` iterates saved members (186–208) and reinstates forced chunks (234).
- `ForceLoadCommand.changeForceLoad` calls `setChunkForced` at 213. With zero additions, its branch at 262 does not reach success; add-mode selects `ERROR_ALL_ADDED` at 269 and creates the command exception at 278.

The unchanged same-copy reload has all requested members, so the repeated add normally has zero new additions and takes precisely the failure route the contract requires the driver to reject. The independent set-membership control measures seed=121 and reload=0; no command/world/server was executed. Ineligible source-world preexisting membership could also cause first-host refusal, but selection remains unrun and is not presented as an actual cohort outcome.

**Minimal required revision:** distinguish seed mutation from reload verification in the exact phase/setup contract. A separately reviewed reload observation may validate the retained fixed forced set and all 121 loaded results without repeating the add. Alternatively, an explicitly defined and independently verified acknowledgement policy is needed. Do not remove historical members, enlarge the envelope/deadlines, silently ignore a command refusal, or infer loaded status solely from the persistent set.

**Finding count:** 0 Critical, 0 High, 2 Medium, 0 Low. These are contract findings, not implementation defects or executed runtime failures.

## Other independently justified observations

1. **The earlier constructor/join scene gap is materially addressed in this proposed scope.** The private constructor route reads server WorldData, not the mock's creative override: `fudgeSpawnLocation` reads `WorldData.getGameType` at 22, compares ADVENTURE at 27/30 and jumps to the alternate route at 240. Ordinary dedicated startup assigns the properties game type at 198 before loadLevel at 491. The raw-spawn/border precheck precedes the native heightmap fallback, and the finite padded collision bounds are mechanically supported by 174 horizontal/256 vertical models. This does not prove actual callbacks, timing or a native loaded footprint.
2. **Reload dimension/position admission is relevant to the real join.** `PlayerList.placeNewPlayer` loads at 69, reads `Dimension` at 88, assigns ServerLevel at 181, adds the player at 843 and may load RootVehicle entities at 972. The two-constructor-before-either-join rule, preassigned unlisted locations and strict native `Dimension/Pos/Motion/Rotation/playerGameType/RootVehicle` rules avoid relying on a later corrective teleport. The literal model trace is not an actual executed trace.
3. **Ownership remains narrow.** Both UUID/name/file/cache preflights precede constructors; CREATE_NEW driver receipt follows disposal, real exit 0 and stopped-file inspection. It is not progress authority or a cryptographic ownership system against the trusted administrator. Partial failures abandon the copy, attempt all exact-owned cleanup and provide no rollback/receipt claim. Read-only seven-field reflection remains proposed/test-only; native packaged resolution still requires proof. Public GameProfileCache.get has MRU mutator references and is not a safe substitute.
4. **Empty saved Inventory is a native list, not a hatch schema.** The actual Inventory.save route checks each of its three partitions for empty stacks before adding compounds to the provided ListTag. The proposal preserves the separately checked native tag9/subtype0/count0 path; no shared codec policy is adopted. Positive native record fixtures are still required before implementation admission.
5. **Native events remain real dependencies.** Entity construction calls Forge `getEntitySizeForge` at 418 and uses the returned size at 424. The proposal's no-extra-mod/source pin and native-result verification matter; type dimensions alone are not a runtime callback proof. Join posts EntityJoinLevelEvent and registration/tracking is not a pure insertion. The proposed statement that ordinary startup/tracking/background behavior is not globally load-free is retained.
6. **Bounds and authority were not silently widened.** The 23 rows, six goal IDs/criterion, fixed identities/items, original event order, all byte/node/depth/count ceilings and 300-second partitioned deadline equal protocol01. The unchanged author models were rerun, not assumed. All additional host/native-location fields remain exact test-only observation/admission requirements. Unknown ERROR/FATAL is not waived; the historic protected Guard world is not automatically a clean C18 source.
7. **Source basis is separate from documentation publication.** The fixed `a5abc348...` source objects include the actual six inventory tutorial definition with `minecraft:inventory_changed`, a current-inventory suit conjunction and empty rewards. Live documentation HEAD moved from `9135c20c...` to Root-notified docs-only `6a54f835...`; no source basis, exact Task03 or proposal payload was substituted. This report does not claim whole-repository identity.
8. **Accepted ADR-066 section 6.2 remains the gameplay authority.** Its six matching obtain/suit inventory goals and prohibition on console grants as trigger proof agree with the narrow ordinary-listener cohort. The additional world-first advancement source/receipt obligations are outside this fixture, not closed by its connected players. The separately named [ADR input check](ADR-INPUT-01.json) pins the actual canonical file and relevant source-object equality; no ADR text was changed.

## Actual checks and preserved failures

All helper subprocesses used Python `-B` with own process-local TEMP/TMP/TMPDIR in `tmp`. Zero Java, Gradle, Minecraft/native, client, network, Git-mutating, cleanup or nested-agent operations were performed.

| Command | Actual exit / observation | Evidence |
|---|---|---|
| `python -B intake01.py` | 0; exact Task03 and all 52 proposal payloads/400,726 bytes; 78 named files pinned | [log](intake-01.log), [pins](INPUT-PINS-01.json) |
| `python -B primary01.py` | 0; 14 selected native classes /39 methods | [log](primary-01.log), [facts](PRIMARY-01.json) |
| `python -B primary02.py` | 0; 9 classes /12 methods | [log](primary-02.log), [facts](PRIMARY-02.json) |
| `python -B properties01.py` | 0; 3 JDK property methods and Date writer references; static only | [log](properties-01.log), [facts](PROPERTIES-01.json) |
| `python -B primary03.py` | 0; 4 classes /8 methods, persistent forced-set command/startup routes | [log](primary-03.log), [facts](PRIMARY-03.json) |
| `python -B controls01.py` | 1; 30 controls, 1 failure +1 error from reviewer wording/offset mistakes | [raw failure](controls-01.log), [original counts](CONTROLS-01.json) |
| `python -B controls02.py` | 0; unchanged 18 author bodies +12 independent controls =30 /0 failure,error,skip | [log](controls-02.log), [counts](CONTROLS-02.json) |
| `python -B postcheck01.py` | 1; reviewer treated an integer count as an iterable | [raw failure](postcheck-01.log) |
| `python -B postcheck02.py` | 0; all 78 named files unchanged, 12 fixed Git objects, 23 independent +20 author selected native class identities, JDK archive/module pins and companion links verified | [log](postcheck-02.log), [postcheck](INPUT-POSTCHECK-02.json) |

The initial exploratory missing manifest locator, later guessed nonexistent old fact/ADR/helper paths and their actual tool-exit qualifications are separately documented in [exploration record](EXPLORATION-FAILURES.md). These are not native/source test failures. `controls02.py` corrects the actual opcode reference offset from 24 to 22 and the reviewer-only textual qualification check; it does not modify the original 18 author methods, any source/protocol or a runtime budget. `postcheck02.py` reads the actual class-pin dictionary and leaves the original failed helper/log unchanged. All original proposal failures and earlier independent reviews are input-pinned, not rewritten.

## Disposition, limitations and remaining work

**Technical eligibility:** the exact cumulative Task03/proposal02 is not ready to freeze unchanged because M1 and M2 leave the two-host execution contract internally incompatible with the inspected native writer/forced-set lifecycle. Root may request a separately versioned narrow technical correction and independent review. This is not Root acceptance and grants no implementation authority.

**Completed scope:** identity/manifest/companion intake, actual selected primary route inspection, cumulative authority/schema/bounds/lifecycle assessment and 30 bounded source/specification controls. Only this own external loose evidence directory was written.

**Uncompleted/unrun:** source-host selection, scene setup, actual default-mode/constructor/callback/tracking footprint, mapped/SRG reflection in a real packaged host, Java/unit/GT compilation or execution, exact positive native-emission records, partial join/channel disposal, ordinary listener save/load, both clean hosts, real-client/GPU/multiplayer, arbitrary-crash proof, R-021/Guard writer admission, tutorial ledger delivery and every version Required Gate. Native calls are not shown preemptible by a 10-second between-stage guard. No naturally clean host or source-world properties rewrite is inferred from this static assessment.

**Required next action within v1.8:** separately define and review phase-specific raw properties bindings and seed/reload forced-set preparation/observation; keep all current ownership, loaded-envelope, output/resource, original failure, record and timing requirements intact. Dependent implementation and actual result review follow only Root's explicit disposition.

## Exact input identities and portable evidence

- Task03: 9,718 bytes; SHA-256 `c75fec1a7f1cb5291147abb838712ed695c7c011f060bff1f6f7378011a6b6d4`.
- Proposal02 manifest: `f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955`; 52 payloads/400,726 bytes. Normative Markdown `62470a5586e320bc7bdeec337b81d9ee27226c6f7c84285b94d67a50b0b0c823`; protocol `9e4834fcc8555af28d9b918a87bcfcc79c5262d15f5adb5c179493672cb0cc5e`.
- Historical proposal01 independent review: `9569049b655529fc33808d2145ecbf81b94cd2fe8eb81525ba1e59ebcd710cd6`; original report/manifest unchanged. Spawn primary supplement report `dfd35b6f0d66bf5904c1a05ca45b049da83678dcf103d7e72d41363973184d18`, manifest `0ac21a34a0b77e2d0b4eaa30e16e5463a605af392e734bde165131da3eabc5e9`, unchanged.
- Mapped Forge JAR: 19,355,242 bytes; `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`. The parser is AST-loaded declarations only, SHA `001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167`; no top-level old writes ran.
- Inline provenance: author packet `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a`; own independent directory `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f`.

The compact own [internal manifest](INTERNAL-MANIFEST.json) and checksum sidecar bind report, raw helper logs/results, own controls and copied normative snapshots. Selected declaration/reference/branch facts are retained; no official class body, JAR, full source/world export or redundant ZIP is redistributed. External primary/Git input locators are qualified pinned dependencies, not promised permanent portable copies.
