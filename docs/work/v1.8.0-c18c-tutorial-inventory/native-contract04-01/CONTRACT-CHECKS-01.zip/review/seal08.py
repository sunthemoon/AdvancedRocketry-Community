"""Small loose review sealing; no ZIP, official body, source tree or runtime export."""
import hashlib
import json
import pathlib
import re
from urllib.parse import unquote

OUT = pathlib.Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))

report = OUT / 'REVIEW-04.md'
references = []
for raw in re.findall(r'\[[^\]]+\]\(([^)]+)\)', report.read_text(encoding='utf-8')):
    rel = unquote(raw.split('#', 1)[0])
    assert not pathlib.PurePosixPath(rel).is_absolute() and '..' not in pathlib.PurePosixPath(rel).parts, rel
    p = OUT / rel
    assert p.is_file(), rel
    references.append(dict(path=rel, **pin(p)))
assert pin(OUT / 'NATIVE-TASK-04.md')['sha256'] == '3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43'
final = json.loads((OUT / 'FINAL-07.json').read_text(encoding='utf-8'))
assert final['payload_postchecks']['proposal03']['unchanged']
assert final['payload_postchecks']['proposal02']['unchanged']
assert final['payload_postchecks']['prior_review']['unchanged']
assert final['diff']['regenerated_exact']
counts = json.loads((OUT / 'CONTROLS-05.json').read_text(encoding='utf-8'))
assert counts['tests'] == 44 and counts['failures'] == counts['errors'] == counts['skipped'] == 0
assert not (OUT / 'INTERNAL-MANIFEST.json').exists()
excluded = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-08.json', 'seal-08.log', 'seal-08.exit', 'seal-08.command.json'}
files = []
for p in sorted(OUT.iterdir(), key=lambda p: p.name):
    if p.is_file() and p.name not in excluded:
        files.append(dict(path=p.name, **pin(p)))
manifest = dict(schema=1, scope='Independent exact proposal03/cumulative Task04 technical review only; small loose evidence, no source/native/API/Gate admission.',
    source_basis='a5abc34809891d6b10724ee60ab9b5e97f036bae',
    task03_context='16e555111ad957e80570317cb103fb9dadc9895a',
    task04_sha256='3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43',
    files=files, payload_count=len(files), payload_bytes=sum(e['bytes'] for e in files),
    excludes=sorted(excluded | {'process-temp/'}),
    original_failures_retained=True, original_author_and_repository_unchanged=True)
manifest_bytes=(json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(OUT / 'INTERNAL-MANIFEST.json').write_bytes(manifest_bytes)
checksums=''.join(f"{e['sha256']}  {e['path']}\n" for e in files)
checksums+=f"{sha(manifest_bytes)}  INTERNAL-MANIFEST.json\n"
(OUT / 'SHA256SUMS.txt').write_text(checksums, encoding='utf-8')
for e in files: assert pin(OUT / e['path']) == {k: e[k] for k in ('bytes', 'sha256')}
result=dict(report=pin(report), manifest=pin(OUT / 'INTERNAL-MANIFEST.json'), checksums=pin(OUT / 'SHA256SUMS.txt'),
    payload_count=len(files), payload_bytes=manifest['payload_bytes'], report_links=len(references), missing_links=0,
    all_payload_checksums_exact=True, result='SEALED_LOOSE_REVIEW', java_native_launches=0,
    archive_created=False, source_API_Gate_admission=False)
(OUT / 'SEAL-08.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
