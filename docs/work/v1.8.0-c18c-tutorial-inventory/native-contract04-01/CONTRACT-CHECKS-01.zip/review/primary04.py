"""Selected primary semantic facts only; no official bodies/classes/JARs emitted."""
import ast
import hashlib
import json
import pathlib
import struct
import zipfile

OUT = pathlib.Path(__file__).resolve().parent
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
def pin(p):
    b = p.read_bytes(); return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def sha(b): return hashlib.sha256(b).hexdigest()
prior = json.loads((AUTHOR / 'PRIMARY-03.json').read_text(encoding='utf-8'))
parser = pathlib.Path(prior['parser']['path']); raw = parser.read_bytes()
assert sha(raw) == prior['parser']['sha256']
tree = ast.parse(raw.decode('utf-8')); ns = {'struct': struct}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')], type_ignores=[]), str(parser), 'exec'), ns)
jar = pathlib.Path(prior['jar']['path']); before = pin(jar)
assert before['sha256'] == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
selections = {
    'net/minecraft/server/commands/ForceLoadCommand.class': {'changeForceLoad', 'lambda$changeForceLoad$15', 'lambda$changeForceLoad$16'},
    'net/minecraft/world/level/ChunkPos.class': {'toString'},
    'net/minecraft/server/level/ServerLevel.class': {'getForcedChunks', 'setChunkForced'},
    'net/minecraft/world/level/ForcedChunksSavedData.class': {'save', 'load'},
    'net/minecraft/server/MinecraftServer.class': {'prepareLevels'},
    'net/minecraft/server/Main.class': {'main'},
    'net/minecraft/server/dedicated/DedicatedServerSettings.class': {'forceSave'},
    'net/minecraft/server/dedicated/Settings.class': {'store', 'loadFromFile'},
    'net/minecraftforge/common/util/SortedProperties.class': {'store'},
}
facts = {}
with zipfile.ZipFile(jar) as archive:
    for name, wanted in selections.items():
        raw = archive.read(name); parsed = ns['parse'](raw, wanted)
        assert parsed['selected_methods'], name
        methods = {}
        for key, method in parsed['selected_methods'].items():
            refs = [{'offset': item['offset'], 'reference': item['reference']} for item in method['instructions'] if item.get('reference')]
            methods[key] = {'access': method['access'], 'references': refs}
        facts[name] = {'bytes': len(raw), 'sha256': sha(raw), 'methods': methods}
    force_raw = archive.read('net/minecraft/server/commands/ForceLoadCommand.class')
    force = ns['parse'](force_raw, {'lambda$changeForceLoad$16'})
    key, method = next(iter(force['selected_methods'].items()))
    assert key.startswith('lambda$changeForceLoad$16(ZLnet/minecraft/world/level/ChunkPos;')
    row = next(i for i in method['instructions'] if i['offset'] == 24)
    assert row['opcode_hex'] == '0x2b'  # local1 reference, matching the method's ChunkPos parameter.
    facts['multiple_first_template_argument'] = {'method': key, 'array_first_value_offset': 24,
        'semantic': 'Loads local1 ChunkPos as first Object[] argument; not a boxed changed counter.'}
    chunk = ns['parse'](archive.read('net/minecraft/world/level/ChunkPos.class'), {'toString'})
    concat_refs = next(iter(chunk['selected_methods'].values()))['instructions']
    facts['chunk_string_rendering_refs'] = [{'offset': r['offset'], 'reference': r['reference']} for r in concat_refs if r.get('reference')]
source = pathlib.Path(prior['jdk']['source_archive']['path']); source_before = pin(source)
assert source_before == {k: prior['jdk']['source_archive'][k] for k in ('bytes', 'sha256')}
with zipfile.ZipFile(source) as archive:
    member = archive.read(prior['jdk']['member']); assert sha(member) == prior['jdk']['member_sha256']
    lines = member.decode('utf-8').splitlines()
    selected = [(851, 'false);'), (906, 'bw.write("#" + new Date().toString());')]
    for index, expected in selected: assert lines[index-1].strip() == expected, (index, lines[index-1])
    assert any("(c == '=' ||  c == ':') && !precedingBackslash" in line for line in lines)
    jdk = {'member': prior['jdk']['member'], 'bytes': len(member), 'sha256': sha(member),
        'Writer_store_unicode_escape_flag_line': 851, 'Writer_store_unicode_escape_flag': False,
        'store0_date_comment_line': 906, 'unescaped_key_equal_or_colon_is_separator': True}
assert pin(jar) == before and pin(source) == source_before and pin(parser)['sha256'] == prior['parser']['sha256']
result = {'qualification': 'Static selected configured-primary routes, no runtime/rendered-host claim or official bodies copied.',
    'jar': {'path': str(jar), **before}, 'parser': {'path': str(parser), **pin(parser)},
    'jdk_source': {'path': str(source), **source_before}, 'native': facts, 'jdk': jdk,
    'pre_post_inputs_unchanged': True, 'java_launches': 0}
(OUT / 'PRIMARY-04.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Selected native9 classes and JDK Writer/load separator facts verified; all primary inputs unchanged; no Java/native.')
