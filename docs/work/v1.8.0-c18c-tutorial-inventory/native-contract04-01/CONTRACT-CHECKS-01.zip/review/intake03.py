"""Correct the exact existing uppercase version-document locator; preserve failed02."""
import pathlib
out = pathlib.Path(__file__).resolve().parent
source = (out / 'intake02.py').read_text(encoding='utf-8')
source = source.replace('INTAKE-CORRECTION-02.json', 'INTAKE-CORRECTION-03.json')
source = source.replace('INPUTS-02.json', 'INPUTS-03.json')
before = "exec(compile(new, str(out / 'intake02.py'), 'exec'))"
assert source.count(before) == 1
source = source.replace(before, "new = new.replace('docs/versions/v1.8.0.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md')\n" + before)
exec(compile(source, str(out / 'intake03.py'), 'exec'))
