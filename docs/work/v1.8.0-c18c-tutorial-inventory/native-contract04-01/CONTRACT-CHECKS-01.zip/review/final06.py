"""Independent exact comparison, cumulative task and unchanged-input checks."""
import difflib
import hashlib
import json
import pathlib
import subprocess
import zipfile

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
OLD = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
REVIEW = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
sha = lambda b: hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))

intake = load(OUT / 'INPUTS-03.json')
verified = {}
for label, directory, expected in [('proposal03', AUTHOR, intake['proposal03']), ('proposal02', OLD, intake['proposal02'])]:
    assert pin(directory / 'EVIDENCE-MANIFEST.json') == expected['manifest']
    for name, entry in expected['files'].items(): assert pin(directory / name) == entry, (label, name)
    verified[label] = dict(entries=len(expected['files']), bytes=sum(e['bytes'] for e in expected['files'].values()), unchanged=True)
prior_manifest = load(REVIEW / 'INTERNAL-MANIFEST.json')
assert pin(REVIEW / 'INTERNAL-MANIFEST.json') == intake['prior_review']['manifest']
for e in prior_manifest['files']:
    assert pin(REVIEW / e['path']) == {k: e[k] for k in ('bytes', 'sha256')}, e['path']
verified['prior_review'] = dict(entries=len(prior_manifest['files']), unchanged=True)

parts = []
for stem, ext in [('OWNERSHIP-PROPOSAL', 'md'), ('PROTOCOL', 'json')]:
    old_name, new_name = f'{stem}-02.{ext}', f'{stem}-03.{ext}'
    a, b = (OLD / old_name).read_text(encoding='utf-8'), (AUTHOR / new_name).read_text(encoding='utf-8')
    parts.append(''.join(difflib.unified_diff(a.splitlines(keepends=True), b.splitlines(keepends=True),
        fromfile='proposal02/' + old_name, tofile='proposal03/' + new_name)))
actual_diff = ''.join(parts).encode('utf-8')
assert actual_diff == (AUTHOR / 'PROPOSAL-03.diff').read_bytes()
diff = dict(bytes=len(actual_diff), sha256=sha(actual_diff), regenerated_exact=True,
            scope='Two-document comparative diff only; no source patch applied.')

old, new = load(OLD / 'PROTOCOL-02.json'), load(AUTHOR / 'PROTOCOL-03.json')
preserved = ['fixed_identities', 'goal_ids', 'criterion', 'native_empty_inventory_shape', 'item_counts_order',
             'seed_events', 'reload_events', 'common_fields', 'saved_criterion_fields', 'failure_codes',
             'deadlines_seconds', 'ceilings', 'forbidden_authorities']
for key in preserved: assert old[key] == new[key], key
for key in old['host_admission']:
    if key != 'revision': assert old['host_admission'][key] == new['host_admission'][key], key
for key in old['payload_schemas']:
    if key != 'PREFLIGHT': assert old['payload_schemas'][key] == new['payload_schemas'][key], key
assert new['host_admission']['revision'] == 3
assert new['forced_setup']['reload']['commands'] == []
assert set(new['external_receipt_fields']['seed_stopped_properties']) == {'bytes', 'sha256'}
assert sum([new['deadlines_seconds']['copy_intake'], new['deadlines_seconds']['seed_host'],
            new['deadlines_seconds']['reload_host'], new['deadlines_seconds']['final_validation']]) == 300

task_path = ROOT / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md'
assert pin(task_path) == {k: intake['root_task04'][k] for k in ('bytes', 'sha256')}
task = task_path.read_text(encoding='utf-8')
for name in ['OWNERSHIP-PROPOSAL-03.md', 'PROTOCOL-03.json', 'PROPOSAL-03.diff', 'HANDOFF-03.md']:
    assert name in task and pin(AUTHOR / name)['sha256'] in task, name
assert intake['proposal03']['manifest']['sha256'] in task
assert 'PROPOSED_FOR_INDEPENDENT_REVIEW' in task
assert 'No native execution or source implementation is authorized' in task
assert 'reload issues no' in task and 'forceload add/remove/query' in task
assert 'bootPropertiesSha256' in task and 'seed_stopped_properties' in task

governance = {}
for name, expected in intake['governance'].items():
    actual = pin(ROOT / name)
    assert actual == expected, name
    governance[name] = actual

primary = load(OUT / 'PRIMARY-04.json')
for key in ('jar', 'jdk_source', 'parser'):
    p = primary[key]
    assert pin(pathlib.Path(p['path'])) == {k: p[k] for k in ('bytes', 'sha256')}, key
with zipfile.ZipFile(primary['jar']['path']) as z:
    classes = {name: e for name, e in primary['native'].items() if name.endswith('.class')}
    for name, entry in classes.items():
        raw = z.read(name)
        assert dict(bytes=len(raw), sha256=sha(raw)) == {k: entry[k] for k in ('bytes', 'sha256')}
language = load(AUTHOR / 'FORCELOAD-LANGUAGE-01.json')
assert pin(pathlib.Path(language['jar_path']))['sha256'] == language['jar_sha256']
with zipfile.ZipFile(language['jar_path']) as z:
    raw = z.read(language['member'])
    assert sha(raw) == language['member_sha256']
    actual = json.loads(raw)
    keys = ['commands.forceload.added.single', 'commands.forceload.added.multiple']
    assert all(actual[k] == language['templates'][k] for k in keys)
language_fact = dict(jar_sha256=language['jar_sha256'], member=language['member'],
    member_sha256=language['member_sha256'], selected_keys=keys, exact_templates_verified=True,
    qualification='Static native English templates; no rendered host output or official resource copied.')

objects = {}
fixed = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
for name in ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/progression/classic/ClassicInventoryAdvancements.java',
             'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ConnectedTestPlayers.java']:
    cmd = ['git', 'show', fixed + ':' + name]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    assert r.returncode == 0, (name, r.stderr)
    text = r.stdout.decode('utf-8')
    if name.endswith('ClassicInventoryAdvancements.java'):
        assert 'suited_up' in text and 'space_suit_helmet' in text and 'space_suit_boots' in text
    else: assert 'ServerPlayer' in text and 'EmbeddedChannel' in text
    objects[name] = dict(command=cmd, exit=r.returncode, bytes=len(r.stdout), sha256=sha(r.stdout))
head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True)
assert head.returncode == 0

for name in ['OWNERSHIP-PROPOSAL-03.md', 'PROTOCOL-03.json', 'PROPOSAL-03.diff', 'HANDOFF-03.md']:
    target = OUT / name
    assert not target.exists()
    target.write_bytes((AUTHOR / name).read_bytes())
target = OUT / 'PRIOR-REVIEW-03.md'; assert not target.exists()
target.write_bytes((REVIEW / 'REVIEW-03.md').read_bytes())
result = dict(qualification='Independent cumulative technical review controls only; no source/config/native execution or acceptance.',
    payload_postchecks=verified, diff=diff, preserved_protocol_keys=preserved,
    original_host_admission_except_revision_preserved=True, non_PREFLIGHT_payloads_preserved=True,
    root_task04=dict(path=str(task_path), **pin(task_path)), primary_classes=len(classes),
    language=language_fact, fixed_source_objects=objects, governance=governance,
    observed_root_HEAD=head.stdout.decode().strip(), fixed_source_basis=fixed,
    root_HEAD_is_context_not_a_rebinding=True, java_launches=0, source_writes=0)
(OUT / 'FINAL-06.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Exact two-document diff, cumulative Task04 bindings, 80+52+46 payload postchecks, nine primary class pins and two native English keys: OK.')
print('Original host/PLAYER_STATE/deadlines/goal fields preserved. No Java/native or repository/source/config write.')
