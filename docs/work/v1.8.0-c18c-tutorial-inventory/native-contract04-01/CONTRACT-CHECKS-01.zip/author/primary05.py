"""Retain primary04's assertion failure; select the multiline Writer flag exactly."""
from pathlib import Path

B = Path(__file__).resolve().parent
source = (B / 'primary04.py').read_text(encoding='utf-8')
source = source.replace("'new Date().toString()')", "'new Date().toString()', 'false);')")
source = source.replace("assert any('false' in item['text'] for item in source_facts if 'store0(' in item['text'])",
                        "assert lines[850].strip() == 'false);'")
source = source.replace("'PRIMARY-04.json'", "'PRIMARY-05.json'")
exec(compile(source, str(B / 'primary05.py'), 'exec'), {'__file__': __file__, '__name__': '__main__'})
