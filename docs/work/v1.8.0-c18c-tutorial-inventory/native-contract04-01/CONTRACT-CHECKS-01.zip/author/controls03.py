"""Final subset boundary model, retaining prior acknowledgement red/green files."""
import ast
import hashlib
import json
import os
from pathlib import Path
import unittest

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
prior = (B / 'controls02.py').read_text(encoding='utf-8')
exec(compile(prior.split("nodes = [n for n in ast.parse(")[0], str(B / 'controls02.py'), 'exec'))
prior_properties = properties_model

def final_properties_model(raw):
    # First perform the inherited raw-size/encoding/escape/pair checks.
    result = prior_properties(raw)
    text = raw.decode('utf-8').replace('\r\n', '\n')
    if any((ord(c) < 32 and c != '\n') or ord(c) == 127 for c in text):
        raise ValueError('literal control')
    for line in text.split('\n'):
        if not line or line.startswith(('#', '!')):
            continue
        escaped = False
        for c in line:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '=':
                break
            elif c == ':':
                raise ValueError('native key separator')
    return result

properties_model = final_properties_model

class CompletedRevisionControls(FinalRevisionControls):
    def test_native_key_separator_and_comment_control_boundary(self):
        fact = json.loads((B / 'PRIMARY-06.json').read_text(encoding='utf-8'))
        self.assertTrue(any("(c == '=' ||  c == ':') && !precedingBackslash" in item['text']
                            for item in fact['selected_lines']))
        self.assertEqual({'a:b': 'value'}, properties_model(b'a\\:b=value\n'))
        self.assertEqual({'a': 'b:value'}, properties_model(b'a=b:value\n'))
        for raw in (b'a:b=value\n', b'#comment\x00\na=b\n', b'!comment\t\na=b\n'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                properties_model(raw)

nodes = [n for n in ast.parse((P / 'controls06.py').read_bytes()).body
         if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
ns = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'NEW': NEW, 'OLD': json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json').read_text()),
    'HOST': NEW['host_admission'], 'FLOAT': lambda s: struct.unpack('>f', bytes.fromhex(s))[0],
    'DOUBLE': lambda s: struct.unpack('>d', bytes.fromhex(s))[0], 'BITS': lambda d: struct.pack('>d', d).hex(),
    'ENVELOPE': [(x, z) for x in range(-5, 6) for z in range(-5, 6)],
    'WIDTH': struct.unpack('>f', bytes.fromhex('3f19999a'))[0], 'HEIGHT': struct.unpack('>f', bytes.fromhex('3fe66666'))[0],
    'EPSILON': struct.unpack('>d', bytes.fromhex('3e7ad7f29abcaf48'))[0]}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P / 'controls06.py'), 'exec'), ns)
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(ns['Controls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(CompletedRevisionControls)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
(B / 'CONTROL-RESULT-03.json').write_text(json.dumps({'tests': result.testsRun,
    'unchanged_author02_methods': 18, 'revision_models': 20, 'failures': len(result.failures),
    'errors': len(result.errors), 'skips': len(result.skipped),
    'scope': 'Partial executable specification models plus native/JDK fact controls, not Java/runtime/parser/Gate proof.'}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
