"""Source-derived acknowledgement correction; original controls01 stays unchanged."""
import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import unittest

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
original = (B / 'controls01.py').read_text(encoding='utf-8')
# Retain the existing definitions and their source assertions; skip their runner.
exec(compile(original.split("nodes = [n for n in ast.parse(")[0], str(B / 'controls01.py'), 'exec'))
OriginalRevisionControls = RevisionControls
original_ack = ack_payload_model

def native_ack_payload_model(payload):
    if type(payload) is not str:
        return None
    coordinate = r'(-?[1-5]|0)'
    single = re.fullmatch(r'Marked chunk \[' + coordinate + ', ' + coordinate
        + r'\] in minecraft:overworld to be force loaded', payload)
    if single:
        return ('single', tuple(map(int, single.groups())))
    multiple = re.fullmatch(r'Marked \[' + coordinate + ', ' + coordinate
        + r'\] chunks in minecraft:overworld from \[-5, -5\] to \[5, 5\] to be force loaded', payload)
    if multiple:
        return ('multiple', tuple(map(int, multiple.groups())))
    return None

ack_payload_model = original_ack if '--original-ack' in sys.argv else native_ack_payload_model

class FinalRevisionControls(OriginalRevisionControls):
    def test_single_and_multiple_seed_acknowledgements(self):
        for x, z in ((-5, -5), (5, 5), (0, 0)):
            self.assertEqual(('multiple', (x, z)), ack_payload_model(
                f'Marked [{x}, {z}] chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'))
            self.assertEqual(('single', (x, z)), ack_payload_model(
                f'Marked chunk [{x}, {z}] in minecraft:overworld to be force loaded'))

    def test_freshness_origin_duplicates_and_reload_no_command(self):
        line = {'index': 11, 'origin': 'console INFO/server-thread minecraft/MinecraftServer',
            'payload': 'Marked [5, 5] chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'}
        self.assertTrue(fresh_ack_model([line], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([line], 11, True, 'seed'))
        self.assertFalse(fresh_ack_model([line, line], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([{**line, 'origin': 'foreign'}], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([line], 10, False, 'seed'))
        self.assertFalse(fresh_ack_model([line], 10, True, 'reload'))

    def test_native_descriptor_arguments_writer_and_rendering_recipe(self):
        facts = json.loads((B / 'PRIMARY-05.json').read_text(encoding='utf-8'))
        force = facts['native']['net/minecraft/server/commands/ForceLoadCommand.class']
        multiple = next((key, value) for key, value in force['methods'].items()
                        if key.startswith('lambda$changeForceLoad$16('))
        self.assertTrue(multiple[0].startswith('lambda$changeForceLoad$16(ZLnet/minecraft/world/level/ChunkPos;'))
        instructions = {item['offset']: item for item in multiple[1]['instructions']}
        self.assertEqual('0x2b', instructions[24]['opcode_hex'])  # first Object[] value: local1 ChunkPos
        self.assertEqual('net/minecraft/resources/ResourceKey.location()Lnet/minecraft/resources/ResourceLocation;',
                         instructions[29]['reference'])
        self.assertEqual('[\x01, \x01]', facts['native']['net/minecraft/world/level/ChunkPos.class']['header']['string_concat_recipe'])
        self.assertEqual('java/util/Properties', facts['native']['net/minecraftforge/common/util/SortedProperties.class']['header']['superclass'])
        self.assertEqual('false);', next(item['text'] for item in facts['jdk_source_facts'] if item['line'] == 851))

    def test_every_fixed_pair_and_noncanonical_numeric_count_rejection(self):
        for x in range(-5, 6):
            for z in range(-5, 6):
                self.assertEqual(('multiple', (x, z)), ack_payload_model(
                    f'Marked [{x}, {z}] chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'))
                self.assertEqual(('single', (x, z)), ack_payload_model(
                    f'Marked chunk [{x}, {z}] in minecraft:overworld to be force loaded'))
        for pair in ('[-0, 0]', '[00, 0]', '[+1, 0]', '[６, 0]', '[6, 0]', '[0, -6]', '[1,1]'):
            self.assertIsNone(ack_payload_model('Marked ' + pair
                + ' chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'))
        for count in (0, 1, 2, 121, 122):
            self.assertIsNone(ack_payload_model(f'Marked {count} chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'))

nodes = [n for n in ast.parse((P / 'controls06.py').read_bytes()).body
         if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
ns = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'NEW': NEW, 'OLD': json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json').read_text()),
    'HOST': NEW['host_admission'], 'FLOAT': lambda s: struct.unpack('>f', bytes.fromhex(s))[0],
    'DOUBLE': lambda s: struct.unpack('>d', bytes.fromhex(s))[0], 'BITS': lambda d: struct.pack('>d', d).hex(),
    'ENVELOPE': [(x, z) for x in range(-5, 6) for z in range(-5, 6)],
    'WIDTH': struct.unpack('>f', bytes.fromhex('3f19999a'))[0], 'HEIGHT': struct.unpack('>f', bytes.fromhex('3fe66666'))[0],
    'EPSILON': struct.unpack('>d', bytes.fromhex('3e7ad7f29abcaf48'))[0]}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P / 'controls06.py'), 'exec'), ns)
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(ns['Controls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(FinalRevisionControls)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
label = 'original-ack' if '--original-ack' in sys.argv else 'final'
(B / ('CONTROL-RESULT-02-' + label + '.json')).write_text(json.dumps({'tests': result.testsRun,
    'unchanged_author02_methods': 18, 'revision_models': 19, 'failures': len(result.failures),
    'errors': len(result.errors), 'skips': len(result.skipped), 'ack_model': label,
    'scope': 'Partial symbolic models and pinned static descriptor facts, not real host/log parser/native emission proof.'}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
