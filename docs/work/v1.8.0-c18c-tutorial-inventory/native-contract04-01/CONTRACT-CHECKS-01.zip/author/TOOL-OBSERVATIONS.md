# Author preparation failures and attribution

These are retained preparation records, not native or implementation results.

1. [primary-02.log](primary-02.log), exit1: guessed cached class
   `net/minecraftforge/common/util/ForgeSortedProperties.class` is absent. The actual
   Settings.store reference names `SortedProperties`; separate primary03 corrected
   only that locator. No original failure/script was changed.
2. [primary-04.log](primary-04.log), exit1: inspector assumed the Writer's `false`
   flag was on its `store0(` source line. It is on multiline source line851.
   Separate primary05 pins that exact line. This is not a native writer failure.
3. [controls-02-red.log](controls-02-red.log), exit1:37 models/3 failures using
   the original newly authored numeric acknowledgement model. The unchanged
   source-derived controls expose pair rendering and freshness rejection; the
   corrected-model green run is a different receipt, not native execution.
4. [controls-03.log](controls-03.log), exit1 before tests: splitting the nested
   runner text matched an inner string literal and produced unterminated syntax.
   Separate controls04 uses top-level AST extraction; every inherited assertion
   and budget remains. No test count is credited to controls03.
5. One exploratory Get-Content call guessed old-review `POSTCHECK-02.json` and
   reported that path missing. The actual retained filename is
   `INPUT-POSTCHECK-02.json`, subsequently read without editing it. The PowerShell
   cell continued to later successful reads and returned exit0; this observation
   is an authored record of the tool output, not an invented raw failure log.

Initial normative checkpoint01's retained old paragraph/protocol label and
checkpoint02's numeric acknowledgement grammar were corrected before final
sealing. Their bytes remain separate; neither is represented as runtime-tested
or adopted. Historical builders are retained as preparation history and must not
be rerun to replace final source-backed postimages.
