"""Executable partial specification models, not Java/Python fixture implementations."""
import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import unittest

B = Path(__file__).resolve().parent
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
OLD = json.loads((P / 'PROTOCOL-02.json').read_text())
NEW = json.loads((B / 'PROTOCOL-03.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
def decode_piece(text):
    result = []
    i = 0
    while i < len(text):
        c = text[i]
        if c == '\\':
            i += 1
            if i >= len(text) or text[i] not in NEW['properties_reader']['escapes']:
                raise ValueError('escape')
            result.append(NEW['properties_reader']['escapes'][text[i]])
        elif ord(c) < 32 or ord(c) == 127:
            raise ValueError('control')
        else:
            result.append(c)
        i += 1
    return ''.join(result)
def properties_model(raw):
    if type(raw) is not bytes or not 1 <= len(raw) <= 16384 or raw.startswith(b'\xef\xbb\xbf'):
        raise ValueError('bytes')
    text = raw.decode('utf-8', errors='strict')
    if '\r' in text.replace('\r\n', ''):
        raise ValueError('CR')
    result = {}
    for line in text.replace('\r\n', '\n').split('\n'):
        if not line or line.startswith(('#', '!')):
            continue
        escaped = False
        split = None
        for i, c in enumerate(line):
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '=':
                split = i
                break
            elif c.isspace():
                raise ValueError('key whitespace')
        if split is None:
            raise ValueError('separator')
        encoded_key, encoded_value = line[:split], line[split + 1:]
        if encoded_value[:1].isspace():
            raise ValueError('leading value whitespace')
        key, value = decode_piece(encoded_key), decode_piece(encoded_value)
        if not key or key in result:
            raise ValueError('duplicate/key')
        if len(result) == 1023:
            raise ValueError('entry overflow')
        result[key] = value
    return result
def configuration_sample(comment):
    return ('#Minecraft server properties\n#' + comment + '\n'
        'force-gamemode=false\ngamemode=adventure\n'
        'motd=owned fixture\nsimulation-distance=3\nview-distance=2\n').encode()
def phase_binding_model(snapshot, phase, boot, launch, live, stopped, receipt=None):
    # Symbolic raw/map binding only: there is no process or mutable world.
    if phase not in ('seed', 'reload') or type(launch) is not str or not re.fullmatch('[0-9a-f]{64}', launch):
        return False
    configured = properties_model(snapshot)
    if any(configured.get(k) != v for k, v in NEW['host_admission']['copy_properties'].items()):
        return False
    expected = sha(snapshot) if phase == 'seed' else (receipt or {}).get('sha256')
    if phase == 'seed' and receipt is not None:
        return False
    if phase == 'reload':
        if type(receipt) is not dict or set(receipt) != {'bytes', 'sha256'}:
            return False
        if type(receipt['bytes']) is not int or not 1 <= receipt['bytes'] <= 16384 or len(boot) != receipt['bytes']:
            return False
    if sha(boot) != expected or launch != expected:
        return False
    return properties_model(boot) == configured == properties_model(live) and live == stopped
def ack_payload_model(payload):
    single = re.fullmatch(r'Marked chunk \[(-?\d+), (-?\d+)\] in minecraft:overworld to be force loaded', payload)
    if single:
        x, z = map(int, single.groups())
        return 1 if -5 <= x <= 5 and -5 <= z <= 5 else None
    multiple = re.fullmatch(r'Marked (\d+) chunks in minecraft:overworld from \[-5, -5\] to \[5, 5\] to be force loaded', payload)
    if multiple:
        n = int(multiple.group(1))
        return n if 2 <= n <= 121 else None
    return None
def fresh_ack_model(lines, send_index, command_sent, phase):
    if phase != 'seed' or not command_sent:
        return False
    # Origin is symbolic metadata here, not a production logger/parser.
    candidates = [line for line in lines if line['index'] > send_index]
    if len(candidates) != 1:
        return False
    line = candidates[0]
    return line['origin'] == 'console INFO/server-thread minecraft/MinecraftServer' and ack_payload_model(line['payload']) is not None
def targets_model(phase, commands, members, loaded):
    expected = NEW['forced_setup'][phase]['commands']
    return commands == expected and type(members) is list and len(members) == 121 and all(type(x) is bool and x for x in members) and type(loaded) is list and len(loaded) == 121 and all(type(x) is bool and x for x in loaded)

class RevisionControls(unittest.TestCase):
    def test_all_original_critical_protocol_surfaces_exact(self):
        for key in ('fixed_identities', 'goal_ids', 'criterion', 'native_empty_inventory_shape', 'item_counts_order',
            'seed_events', 'reload_events', 'common_fields', 'saved_criterion_fields', 'failure_codes',
            'deadlines_seconds', 'ceilings', 'forbidden_authorities'):
            self.assertEqual(OLD[key], NEW[key], key)
        for k, v in OLD['payload_schemas']['PLAYER_STATE'].items():
            self.assertEqual(v, NEW['payload_schemas']['PLAYER_STATE'][k])

    def test_semantics_equal_with_raw_date_order_and_line_changes(self):
        a = configuration_sample('date A')
        b = configuration_sample('date B').replace(b'\n', b'\r\n')
        self.assertNotEqual(sha(a), sha(b))
        self.assertEqual(properties_model(a), properties_model(b))
        self.assertEqual(properties_model(b), properties_model(b'\n'.join(reversed(a.splitlines()))))

    def test_unknown_properties_are_retained_in_comparison(self):
        a = configuration_sample('A') + b'unknown-key=retained\n'
        for changed in (configuration_sample('B'), configuration_sample('B') + b'unknown-key=changed\n'):
            self.assertNotEqual(properties_model(a), properties_model(changed))

    def test_valid_native_line_escapes_and_literal_unicode(self):
        v = properties_model('key\\=alias=\\ leading\\\\u literal\\t\\n\\r\\f\\:你好\n'.encode())
        self.assertEqual({'key=alias': ' leading\\u literal\t\n\r\f:你好'}, v)

    def test_duplicate_decoded_aliases_refuse(self):
        for data in (b'a=1\na=2\n', b'a\\:b=1\na:b=2\n'):
            with self.assertRaises(ValueError): properties_model(data)

    def test_malformed_unsupported_native_subset_refuses(self):
        for data in (b'\xef\xbb\xbfa=b', b'\xff', b'a=b\r', b'a=b\\', b'a=\\u0041',
            b'a=\\q', b'a=\\\ncontinued', b'a=\x00', b' a=b', b'a= b', b'=v', b'a b=v', b'no separator'):
            with self.subTest(data=data), self.assertRaises((ValueError, UnicodeError)):
                properties_model(data)

    def test_raw_and_entry_boundary_not_increased(self):
        self.assertEqual({'a': 'x' * 16382}, properties_model(b'a=' + b'x' * 16382))
        with self.assertRaises(ValueError): properties_model(b'a=' + b'x' * 16383)
        maximal = ''.join(f'k{i}=v\n' for i in range(1023)).encode()
        self.assertEqual(1023, len(properties_model(maximal)))
        with self.assertRaises(ValueError): properties_model(maximal + b'k1023=v\n')
        self.assertLessEqual(2 * 1023 + 1, 2048)

    def test_two_hosts_distinct_native_raw_hashes_keep_exact_bindings(self):
        a, b, c = (configuration_sample(s) for s in ('configured', 'seed native date', 'reload native date'))
        self.assertTrue(phase_binding_model(a, 'seed', a, sha(a), b, b))
        receipt = {'bytes': len(b), 'sha256': sha(b)}
        self.assertTrue(phase_binding_model(a, 'reload', b, sha(b), c, c, receipt))
        self.assertNotEqual(sha(a), sha(b)); self.assertNotEqual(sha(b), sha(c))

    def test_reload_restore_or_preboot_binding_mismatch_refuses(self):
        a, b = configuration_sample('A'), configuration_sample('B')
        receipt = {'bytes': len(b), 'sha256': sha(b)}
        self.assertFalse(phase_binding_model(a, 'reload', a, sha(a), b, b, receipt))
        self.assertFalse(phase_binding_model(a, 'reload', b, sha(a), b, b, receipt))

    def test_native_changed_settings_and_inhost_rewrite_refuse(self):
        a, b = configuration_sample('A'), configuration_sample('B')
        changed = b.replace(b'view-distance=2', b'view-distance=3')
        self.assertFalse(phase_binding_model(a, 'seed', a, sha(a), changed, changed))
        self.assertFalse(phase_binding_model(a, 'seed', a, sha(a), b, configuration_sample('C')))
        self.assertFalse(phase_binding_model(a, 'seed', a, sha(a), b + b'new-default=v\n', b + b'new-default=v\n'))

    def test_receipt_missing_unknown_or_wrong_types_refuse(self):
        a, b = configuration_sample('A'), configuration_sample('B')
        for receipt in (None, {}, {'bytes': True, 'sha256': sha(b)}, {'bytes': len(b), 'sha256': sha(b), 'extra': 1},
            {'bytes': len(b) + 1, 'sha256': sha(b)}):
            self.assertFalse(phase_binding_model(a, 'reload', b, sha(b), b, b, receipt))
        self.assertFalse(phase_binding_model(a, 'seed', a, sha(a), b, b, {'bytes': len(b), 'sha256': sha(b)}))

    def test_single_and_multiple_seed_acknowledgements(self):
        for count in (2, 121):
            self.assertEqual(count, ack_payload_model(f'Marked {count} chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'))
        for x, z in ((-5, -5), (5, 5), (0, 0)):
            self.assertEqual(1, ack_payload_model(f'Marked chunk [{x}, {z}] in minecraft:overworld to be force loaded'))

    def test_malformed_refusal_outside_target_and_zero_ack_fail(self):
        for text in ('No chunks were marked for force loading',
            'Marked 0 chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded',
            'Marked 122 chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded',
            'Marked 2 chunks in minecraft:the_nether from [-5, -5] to [5, 5] to be force loaded',
            'Marked chunk [6, 0] in minecraft:overworld to be force loaded',
            'Marked chunk [0.0, 0] in minecraft:overworld to be force loaded'):
            self.assertIsNone(ack_payload_model(text))

    def test_freshness_origin_duplicates_and_reload_no_command(self):
        line = {'index': 11, 'origin': 'console INFO/server-thread minecraft/MinecraftServer',
            'payload': 'Marked 121 chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded'}
        self.assertTrue(fresh_ack_model([line], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([line], 11, True, 'seed'))
        self.assertFalse(fresh_ack_model([line, line], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([{**line, 'origin': 'foreign'}], 10, True, 'seed'))
        self.assertFalse(fresh_ack_model([line], 10, False, 'seed'))
        self.assertFalse(fresh_ack_model([line], 10, True, 'reload'))

    def test_each_target_missing_membership_or_loading_refuses(self):
        for phase in ('seed', 'reload'):
            command = NEW['forced_setup'][phase]['commands']
            self.assertTrue(targets_model(phase, command, [True] * 121, [True] * 121))
            for i in range(121):
                missing = [True] * 121; missing[i] = False
                self.assertFalse(targets_model(phase, command, missing, [True] * 121))
                self.assertFalse(targets_model(phase, command, [True] * 121, missing))
            self.assertFalse(targets_model(phase, command, [1] * 121, [True] * 121))
            self.assertFalse(targets_model(phase, command, [True] * 120, [True] * 121))
        self.assertFalse(targets_model('reload', ['forceload add -80 -80 95 95'], [True] * 121, [True] * 121))

    def test_revision_and_phase_provenance_are_explicit(self):
        self.assertEqual(3, NEW['proposal_revision'])
        self.assertEqual(3, NEW['host_admission']['revision'])
        self.assertEqual('integer3', NEW['external_marker_fields']['host_revision'])
        self.assertEqual([], NEW['forced_setup']['reload']['commands'])
        self.assertEqual('seed_only', NEW['host_admission']['console_setup_phase'])
        self.assertEqual('has_inventory', NEW['criterion'])
        self.assertEqual(23, len(NEW['seed_events']) + len(NEW['reload_events']))

    def test_added_report_component_stays_small_but_not_full_emitter_proof(self):
        value = {'revision': 3, 'setup_mode': 'reload_retained', 'forced_target_membership': [True] * 121,
            'properties': {'configured_bytes': 16384, 'configured_sha256': 'f' * 64, 'boot_sha256': 'f' * 64,
                'live_bytes': 16384, 'live_sha256': 'f' * 64, 'logical_map_equal': True, 'reader_version': 1}}
        size = len(json.dumps(value, separators=(',', ':')).encode())
        self.assertLess(size, 16384)
        self.assertLess(size, 1500)

nodes = [n for n in ast.parse((P / 'controls06.py').read_bytes()).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
ns = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'NEW': NEW, 'OLD': json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json').read_text()),
    'HOST': NEW['host_admission'], 'FLOAT': lambda s: struct.unpack('>f', bytes.fromhex(s))[0],
    'DOUBLE': lambda s: struct.unpack('>d', bytes.fromhex(s))[0], 'BITS': lambda d: struct.pack('>d', d).hex(),
    'ENVELOPE': [(x, z) for x in range(-5, 6) for z in range(-5, 6)],
    'WIDTH': struct.unpack('>f', bytes.fromhex('3f19999a'))[0], 'HEIGHT': struct.unpack('>f', bytes.fromhex('3fe66666'))[0],
    'EPSILON': struct.unpack('>d', bytes.fromhex('3e7ad7f29abcaf48'))[0]}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P / 'controls06.py'), 'exec'), ns)
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(ns['Controls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(RevisionControls)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
(B / 'CONTROL-RESULT-01.json').write_text(json.dumps({'tests': result.testsRun, 'unchanged_author02_methods': 18,
    'new_revision_models': 17, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
    'scope': 'symbolic configuration/phase/ack payload/budget controls; not fixture/JDK emission/log origin/Java/native proof'}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
