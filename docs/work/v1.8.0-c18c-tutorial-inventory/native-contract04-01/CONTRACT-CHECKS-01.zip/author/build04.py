from pathlib import Path

B = Path(__file__).resolve().parent
text = (B / 'build03.py').read_text(encoding='utf-8')
needle = "marker = doc.index('## 7. Actual preparation checks and unresolved matters')"
addition = """doc = doc.replace('checks the same property hash/default mode/raw shared spawn/min-max height/view-',
    'checks the receipt-bound boot hash, equal decoded settings/default mode/raw shared spawn/min-max height/view-')
doc = doc.replace('Protocol02 retains schema1', 'Protocol03 retains schema1')
doc = doc.replace('- Marker adds the exact copy server.properties hash; receipt adds the strict\\n  PREFLIGHT host observation digest and two fixed role native_locations.',
    '- Marker binds the exact configured snapshot bytes/hash/name; the launch adds\\n  one required driver-observed bootPropertiesSha256 digest. Receipt adds the strict\\n  seed_stopped_properties bytes/hash alongside the unchanged host digest and two\\n  native_locations. PREFLIGHT adds actual properties/forced-target observations\\n  and phase setup mode, as detailed in section 3.2 and PROTOCOL-03.')
doc = doc.replace('reflection described', 'reflection described')
"""
assert needle in text
text = text.replace(needle, addition + '\n' + needle)
text = text.replace('assertionfromtrustedriver', 'assertionfromtrusteddriver')
exec(compile(text, str(B / 'build03.py'), 'exec'))
for name in ('RECORD-PRIMARY-07.json', 'RECORD-PRIMARY-08.json'):
    (B / name).write_bytes((P / name).read_bytes())
