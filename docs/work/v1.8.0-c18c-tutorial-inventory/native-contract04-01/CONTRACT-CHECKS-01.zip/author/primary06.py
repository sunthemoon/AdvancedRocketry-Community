"""Pin the JDK load-side separator fact relied upon by the test-only subset."""
import hashlib
import json
from pathlib import Path
import zipfile

B = Path(__file__).resolve().parent
old = json.loads((B / 'PRIMARY-03.json').read_text(encoding='utf-8'))['jdk']
archive = Path(old['source_archive']['path'])
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(archive.read_bytes()) == old['source_archive']['sha256']
with zipfile.ZipFile(archive) as source:
    raw = source.read(old['member'])
    assert sha(raw) == old['member_sha256']
    lines = raw.decode('utf-8').splitlines()
    assert "(c == '=' ||  c == ':') && !precedingBackslash" in lines[428]
    facts = [{'line': index, 'text': lines[index - 1].strip()}
             for index in (411, 426, 427, 429, 430, 431, 432, 433)]
(B / 'PRIMARY-06.json').write_text(json.dumps({'source_archive': old['source_archive'],
    'member': old['member'], 'member_sha256': old['member_sha256'], 'selected_lines': facts,
    'implication': 'Unescaped colon before equals must refuse in an equals-only native-compatible key subset.',
    'java_launches': 0}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'selected_source_lines': len(facts), 'java_launches': 0}))
