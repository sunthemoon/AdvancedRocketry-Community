"""Check native properties Reader and console routing, without runtime invocation."""
import ast
import hashlib
import json
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
prior = json.loads((B / 'PRIMARY-03.json').read_text(encoding='utf-8'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = Path(prior['parser']['path']).read_bytes()
assert sha(source) == prior['parser']['sha256']
ns = {'struct': struct}
exec(compile(ast.Module(body=[node for node in ast.parse(source).body
    if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in ('R', 'parse')],
    type_ignores=[]), prior['parser']['path'], 'exec'), ns)
jar = Path(prior['jar']['path'])
assert sha(jar.read_bytes()) == prior['jar']['sha256']
facts = {}
with zipfile.ZipFile(jar) as archive:
    for name, methods in {
        'net/minecraft/server/dedicated/Settings.class': {'loadFromFile'},
        'net/minecraft/server/MinecraftServer.class': {'sendSystemMessage'},
        'net/minecraft/commands/CommandSourceStack.class': {'sendSuccess'},
    }.items():
        raw = archive.read(name)
        parsed = ns['parse'](raw, methods)
        assert parsed['selected_methods'], (name, parsed['all_methods'])
        facts[name] = {'sha256': sha(raw), 'bytes': len(raw), 'methods': {key:
            {'references': [{'offset': ins['offset'], 'reference': ins['reference']}
                            for ins in value['instructions'] if ins['reference'] is not None]}
                      for key, value in parsed['selected_methods'].items()}}
(B / 'PRIMARY-07.json').write_text(json.dumps({'jar': prior['jar'], 'parser': prior['parser'],
    'classes': facts, 'scope': 'Native Reader and send route only, not rendered logger/freshness/runtime proof.',
    'java_launches': 0}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(facts), 'java_launches': 0}))
print(json.dumps(facts, indent=2))
