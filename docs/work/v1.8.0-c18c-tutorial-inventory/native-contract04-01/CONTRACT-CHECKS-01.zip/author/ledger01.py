"""Bind actual retained commands, logs and exits; do not invent launch timestamps."""
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
runs = [
    ('intake01.py', 'intake-01', [], 0),
    ('build03.py', 'build-03', [], 0),
    ('build04.py', 'build-04', [], 0),
    ('controls01.py', 'controls-01', [], 0),
    ('primary02.py', 'primary-02', [], 1),
    ('primary03.py', 'primary-03', [], 0),
    ('primary04.py', 'primary-04', [], 1),
    ('primary05.py', 'primary-05', [], 0),
    ('checkpoint02.py', 'checkpoint-02', [], 0),
    ('controls02.py', 'controls-02-red', ['--original-ack'], 1),
    ('controls02.py', 'controls-02-green', [], 0),
    ('primary06.py', 'primary-06', [], 0),
    ('controls03.py', 'controls-03', [], 1),
    ('controls04.py', 'controls-04', [], 0),
    ('primary07.py', 'primary-07', [], 0),
    ('postcheck01.py', 'postcheck-01', [], 0),
]
entries = []
for script, label, args, wanted in runs:
    files = {}
    for name in (script, label + '.log', label + '.exit'):
        raw = (B / name).read_bytes()
        files[name] = {'bytes': len(raw), 'sha256': sha(raw)}
    code = int((B / (label + '.exit')).read_text().strip())
    assert code == wanted, (label, code)
    entries.append({'argv': ['python', '-B', str(B / script)] + args,
        'working_directory': 'D:/GitHub/AdvancedRocketry-Community',
        'TEMP_TMP_TMPDIR_process_local': str(B / 'process-temp'), 'exit_code': code,
        'files': files, 'qualification': 'Script bytes still retained; dependent final/history proposal bindings are distinguished in HANDOFF, not an assertion that every exploratory run had a full input manifest.'})
final_inputs = {}
for name in ('OWNERSHIP-PROPOSAL-03.md', 'PROTOCOL-03.json', 'PRIMARY-05.json', 'PRIMARY-06.json',
    'controls01.py', 'controls02.py', 'controls03.py', 'controls04.py', 'CONTROL-RESULT-04.json'):
    raw = (B / name).read_bytes()
    final_inputs[name] = {'bytes': len(raw), 'sha256': sha(raw)}
result = {'schema': 1, 'commands': entries, 'substantive_retained_commands': len(entries),
    'final38_control_input_pins': final_inputs,
    'history': 'Initial35 model reads initial checkpoint02. The source-derived37 intermediate model receipts are partial specifications; final38 inputs above bind the final current candidate. No complete native/runtime input manifest existed or is claimed for any model.',
    'unlogged_exploratory_shell_reads': 'Named read-only content/JSON inspections; the missing old POSTCHECK filename and continuing exit0 cell are attributed in TOOL-OBSERVATIONS.md.',
    'timestamps': 'No reconstructed process timestamps are supplied.', 'java_native_launches': 0}
(B / 'COMMANDS-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'retained_commands': len(entries), 'command_failures_preserved': sum(x['exit_code'] != 0 for x in entries),
    'final_control_result': json.loads((B / 'CONTROL-RESULT-04.json').read_text()), 'java_native_launches': 0}))
