import copy
import difflib
import hashlib
import json
import os
from pathlib import Path

B = Path(__file__).resolve().parent
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
Q = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda b: hashlib.sha256(b).hexdigest()
old_doc = (P / 'OWNERSHIP-PROPOSAL-02.md').read_text(encoding='utf-8')
old = json.loads((P / 'PROTOCOL-02.json').read_text(encoding='utf-8'))
assert sha((P / 'OWNERSHIP-PROPOSAL-02.md').read_bytes()) == '62470a5586e320bc7bdeec337b81d9ee27226c6f7c84285b94d67a50b0b0c823'
assert sha((P / 'PROTOCOL-02.json').read_bytes()) == '9e4834fcc8555af28d9b918a87bcfcc79c5262d15f5adb5c179493672cb0cc5e'
section = """### 3.2 Phase-specific configuration provenance and fixed setup

This revision replaces only proposal02's identical raw properties hash across
boots and repeated add operation. All other admission/goal/record/lifecycle and
budget rules remain. Host revision is now exactly 3; old revision-2 markers or
receipts refuse rather than migrate. No historical file is rewritten by this
proposal, and no native host has been executed.

**Initial configuration and one immutable observation snapshot.** Before seed
boot, configure only the disposable copy as already permitted: Adventure default,
force-gamemode false, view distance 2 and simulation distance 3, retaining the
earlier localhost/offline/empty-whitelist/no-extra-mod restrictions. The driver
creates once with CREATE_NEW the fixed
`<server>/.classic-inventory-fixture/snapshot-server-properties-v1.txt`: the exact
configured `server.properties` bytes, not reconstructed values. Its bytes/hash
are bound by `copy_properties_bytes`/`copy_properties_sha256` in the immutable
run marker. Snapshot and marker remain byte-exact through both hosts. These
test-owned configuration observations are separate from the unchanged eight
player-record paths; they are not player progress or gameplay persistence.

Only the native startup writer may change the active copy's `server.properties`
after launch. Do not restore the old raw file, strip comments, rewrite defaults,
change configuration between hosts or claim the snapshot hash is the live file
hash. Preserve all actual configured, boot, live and stopped hashes separately.

**Bounded read-only logical comparison.** The snapshot, actual pre-boot and live
properties must use the native store-compatible line subset described exactly
by `properties_reader` in PROTOCOL-03. Before decoding read at most 16,384 bytes
plus one overflow observation; reject nonregular/reparse paths, missing/empty,
BOM, malformed UTF-8, lone CR, physical continuations or unsupported syntax.
LF and CRLF delimiters are recognized without rewriting the raw file. Blank
and #/! comment lines have no configuration meaning; raw hashes still include
them. Each data line has one first unescaped `=` separator and a nonempty key;
no unescaped key whitespace, no literal leading value whitespace. Only native
writer escapes for backslash, space, =, :, #, !, t/n/r/f are decoded; unknown or
trailing escape and backslash-u syntax refuse (native Writer emits Unicode
literally; an encoded literal backslash followed by u is not that syntax).
Literal control characters refuse; decoded keys must be nonempty. Duplicate
decoded keys refuse, including aliases written with different escape spelling.
Build at most 1,023 key/value pairs, with two string nodes/pair plus root <=2,048;
reject the next before insertion. No sorting or canonical configuration hash
is introduced. Exact decoded maps, including all unknown keys/values, must agree
with the configured snapshot; no coercion, trim, default insertion, ignored
unknown entry, secret-value logging or Java/native mutable configuration lookup.
Native startup-added/normalized keys or values make that selected input ineligible
under this test-only subset, not an opportunity to edit or repair it.

**Actual phase bindings.** Before each process launch the driver boundedly reads
and records the current active properties. Seed boot must equal the configured
snapshot raw bytes/hash. Reload boot must equal `seed_stopped_properties` from
the driver-owned clean-stop receipt. Pass exactly one additional bounded launch
property, `advancedrocketrycommunity.classicInventoryFixture.bootPropertiesSha256`;
it is the driver's independently observed pre-launch hash and must equal the
phase's required hash. The hook validates that binding but does not pretend to
have observed past pre-boot bytes itself. It then independently hashes/decodes the
actual live properties at the fixed server path and requires exact logical-map
equality to the immutable snapshot. PREFLIGHT's strict `properties` object labels
the configured/driver-boot/live observations separately. The driver captures
the live file after startup, matches the hook's live hash and, after clean stop,
requires the stopped raw bytes/hash equal that same host's reported live file.
An unexplained in-host rewrite fails and produces no receipt/reuse. Native startup
Date/comment/ordering/escape serialization can change raw bytes across boots only
when the whole logical map remains equal. Native calls are not preemptible.

The receipt adds only `seed_stopped_properties` (exact bytes/hash of the real
stopped active file). Reload starts with those exact raw bytes, permits the next
normal native startup serialization and applies the same live/stopped comparison.
The active file is never compared as raw-equal to an earlier startup output merely
because its logical settings agree. Source config/world/artifacts remain untouched.

**Seed mutation, reload observation.** Only seed issues the one literal copy-local
console command `forceload add -80 -80 95 95` after readiness and before fixture
construction. It requests the same 121 chunk pairs [-5..5] x [-5..5]. The driver
must observe exactly one fresh native success acknowledgement after that command
and before the action, using the existing strict INFO/server-thread console
origin and bounded log position/deadline rules. The exact pinned English single
and multiple templates are in FORCELOAD-LANGUAGE-01. Multiple acknowledgement:
added count is integer 2..121, dimension minecraft:overworld, range exactly
[-5, -5] through [5, 5]. Single acknowledgement: one added pair strictly within
the same fixed envelope, dimension minecraft:overworld. Parsed data can never
select another command/coordinate. Failure, no success, duplicate/stale/foreign
origin, out-of-range or malformed acknowledgement fails; a zero-addition result
is not success. An initially all-forced target range is ineligible, not repaired.
Partial preexisting membership is allowed only when native add really succeeds
and the subsequent exact whole target membership and loaded observations pass.

Reload issues **no** forceload add/remove/query or replacement setup command.
Normal native startup reinstates the seed-retained Forced members. Before either
constructor each phase reads the public native `ServerLevel.getForcedChunks()`
observation and checks `contains` for all 121 fixed literal chunk identities, in
lexicographic order; every actual membership must be true. This read does not
mutate tickets or issue a world-chunk load; native SavedData observation is not
mislabelled as world-chunk loading or a new reflection permission. Runtime source
tests must bind this exact native getter/return path and reject unsupported or
failed observations. Membership does not prove loaded state: both phases still
independently require all 121 `getChunkNow` results and every old host/air/entity/
ownership gate. Missing membership or loaded state fails; do not add again, remove
historical forced chunks, widen bounds, reset records or retry admission.

Seed command/membership/loading and reload retained-membership/loading consume
the original startup/host/cohort remaining time. There is no new 60-second grant,
barrier retry or relaxed ERROR/FATAL treatment. Both phases retain the unchanged
ordinary connected-player/listener/reload sequence and clean-stop requirement.

Normal vanilla startup/tracking remains real native behavior, not globally
load-free automation. This is bounded fixture constructor/join admission; the
finite copy request and read-only target probes do not prove arbitrary background
generation, crash durability, real-client or version Gates.

"""
start = old_doc.index('### 3.2 Fixed settings')
end = old_doc.index('### 3.3 Exact pre-constructor host gate')
doc = old_doc[:start] + section + old_doc[end:]
doc = doc.replace('proposal 02\n', 'proposal 03\n', 1)
doc = doc.replace('This independently\nversioned correction concerns test-host admission only.',
    'This independently\nversioned cumulative correction concerns test-host admission and phase provenance only.', 1)
doc = doc.replace('PROTOCOL-02.json', 'PROTOCOL-03.json')
doc = doc.replace('PROTOCOL-DELTA-04.json', 'PROTOCOL-DELTA-03.json')
doc = doc.replace('## 1. Finding addressed and exact context', '## 1. Historical findings and exact context')
needle = 'No earlier finding is erased or asserted resolved by authoring this proposal.'
doc = doc.replace(needle, needle + "\n\nThe later exact Task03 independent review is\n`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f/REVIEW-03.md`,\nSHA `1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0`.\nIts two Medium findings concern pre-boot/raw native properties binding and the\nrepeated add command against persisted forced membership. This revision proposes\nonly the explicit phase provenance/operation correction in section 3.2 and\nmatching protocol fields. The review and all earlier packets remain immutable.\nAuthoring this document is not independent resolution or acceptance.\n")
doc = doc.replace('schema 1 with exact `host_revision=2`', 'schema 1 with exact `host_revision=3`')
doc = doc.replace('host_revision=2', 'host_revision=3')
doc = doc.replace('reload requires the same properties hash/default mode/raw shared spawn, build',
    'reload requires the receipt-bound boot hash/logically equal properties/default mode/raw shared spawn, build')
doc = doc.replace('requires the same properties hash', 'requires the receipt-bound boot hash and equal decoded properties')
marker = doc.index('## 7. Actual preparation checks and unresolved matters')
doc = doc[:marker] + """## 7. Preparation evidence and unresolved matters

Actual commands, failures, controls, raw outputs and immutable input pins are
reported in [HANDOFF-03.md](HANDOFF-03.md), not inferred from proposal02's earlier
18 models. [Comparative delta](PROPOSAL-03.diff) and
[protocol delta](PROTOCOL-DELTA-03.json) expose every actual changed section/key.
The [selected primary justification](PRIMARY-JUSTIFICATION-03.json) and
[native language facts](FORCELOAD-LANGUAGE-01.json) are static source evidence,
not emitted configuration/command/callback/ownership/native results.

Remaining gates: independent exact contract review; source-host selection that
meets the strict native-line subset and original scene/error restrictions; exact
source implementation and bounded properties/parser/phase/native-getter/cache/
record/partial-disposal controls; packaged mapping/formatter/callback/footprint/
deadline observation; two-host ordinary listener and stopped native reload proof.
Any contradicting native output retains failure and requires separate revision,
not record normalization, forced-member reset, time expansion or source repair.
No gameplay policy, Guard writer, R-021, source implementation or Gate admission
is inferred. No Java/native execution occurred in this proposal task.
"""
new = copy.deepcopy(old)
new['proposal_revision'] = 3
new['host_admission']['revision'] = 3
new['host_admission']['console_setup_phase'] = 'seed_only'
new['host_admission']['reload_console_setup'] = []
new['host_admission']['forced_target_probe'] = 'public native getForcedChunks().contains for all121 fixed literal pairs, then independent getChunkNow121; no mutation/world-chunk load'
schema = new['payload_schemas']['PREFLIGHT']['host_admission']
schema['revision'] = 'integer3'
schema['setup_mode'] = 'exactseed_add for seed;exactreload_retained for reload'
schema['forced_target_membership'] = 'exact121Booleans actualtrue in fixed lexicographic [-5..5]x[-5..5] order; not loaded proof'
schema['properties'] = {
    'configured_bytes': 'integer1..16384 equalimmutable snapshot and marker',
    'configured_sha256': 'lower64hex equalmarker copy_properties_sha256',
    'boot_sha256': 'lower64hex driver pre-launch observation via exact launch property; seed=snapshot,reload=receiptseedstopped; not hook past-byte observation',
    'live_bytes': 'integer1..16384 actualfixed active server.properties',
    'live_sha256': 'lower64hex actualfixed live file read by hook and matched bydriver',
    'logical_map_equal': 'Booleanactualtrue for whole bounded map including unknownentries versus snapshot',
    'reader_version': 'integer1 exact properties_reader subset'
}
new['external_marker_fields']['host_revision'] = 'integer3'
new['external_marker_fields']['copy_properties_sha256'] = 'lower64hex exactinitial configured snapshot bytes, not subsequent native-written file identity'
new['external_marker_fields']['copy_properties_bytes'] = 'integer1..16384 exactsnapshotbytes'
new['external_marker_fields']['configured_properties_name'] = 'exactsnapshot-server-properties-v1.txt; fixed metadata sibling under .classic-inventory-fixture, not path selector'
new['cohort_inputs_fields']['host_revision'] = 'integer3'
new['external_receipt_fields']['host_revision'] = 'integer3'
new['external_receipt_fields']['seed_stopped_properties'] = {
    'bytes': 'integer1..16384 actualstopped activeproperties equal seedreportedlivebytes',
    'sha256': 'lower64hex actualstopped activeproperties equal seedreportedlivehash; required reloadbootbinding'
}
new['properties_reader'] = {
    'version': 1, 'raw_bytes': 16384, 'pairs': 1023, 'string_nodes_plus_root': 2048,
    'encoding': 'strictUTF8 noBOM; LF orCRLF, loneCRrefuses',
    'ignored_semantically': ['blank_lines', 'hash_comment_lines', 'bang_comment_lines'],
    'raw_hash_includes_ignored_bytes': True,
    'data_separator': 'firstunescaped equals; nonemptydecodedkey; no unescapedkeywhitespace or literal leadingvaluewhitespace',
    'escapes': {'\\': '\\', ' ': ' ', '=': '=', ':': ':', '#': '#', '!': '!', 't': '\t', 'n': '\n', 'r': '\r', 'f': '\f'},
    'refused': ['unknown_escape', 'trailing_escape', 'backslash_u_escape', 'physical_continuation', 'literal_control_character', 'duplicate_decoded_key'],
    'comparison': 'exactwholedecodedmap equality including unknownkeys/values; no default/coercion/trim/canonicalhash/filewrites',
    'configured_snapshot': 'fixedsnapshot-server-properties-v1.txt CREATE_NEW driveronly; opaque raw file bound by markerhostrevision3',
    'scope': 'test-owned native store-compatible configuration subset only, not general Properties/JSON/NBT gameplay policy'
}
new['properties_lifecycle'] = {
    'seed_boot': 'actualraw equalsconfigured snapshot/marker; driverpins beforelaunch',
    'seed_live': 'native startup rewrite permitted only with equaldecodedmap; hookanddrivermatchactualrawhash',
    'seed_stopped': 'actualrawequals samehostreportedlive; driverreceipt stores bytes+hash afteractualcleanstop',
    'reload_boot': 'actualrawequalsreceiptseedstopped; no restoration/reset/edit',
    'reload_live': 'nextnative startup rewrite permitted only with equaldecodedmap; hookanddrivermatchactualrawhash',
    'reload_stopped': 'actualrawequals samehostreportedlive; independentdriverpostcheck',
    'snapshot': 'initialconfiguredraw remainsbyteexact throughbothhosts',
    'launch_property': 'advancedrocketrycommunity.classicInventoryFixture.bootPropertiesSha256',
    'launch_type': 'requiredlower64hex exactphaseexpectedhash; assertionfromtrustedriver, not hookobservedpastbytes',
    'no_receipt_on_failure': True
}
new['forced_setup'] = {
    'seed': {'commands': ['forceload add -80 -80 95 95'],
        'acknowledgement': 'exactonefresh authoritativeconsole success beforeaction; single1fixedenvelopepair or multiple2..121/fixedrange; zero/stale/duplicate/foreign/malformed/refusal fails'},
    'reload': {'commands': [], 'admission': 'nativepersistedall121 memberships and independentlyall121getChunkNow results; no newadd/remove/query orretry'},
    'both': 'fixed121publicnative membership probes before eitherconstructor; no decoded coordinate can select a command',
    'deadlines': 'onlyoriginalstartup/host/cohortremainingbudgets; none renewed',
    'metadata_membership_is_not_loaded_state': True
}
new['runtime_limits'] = old['runtime_limits'] + ' Revision3 adds only test-owned raw property provenance/logical equality and phase-specific fixed forced-set observations; no execution is claimed.'
doc_bytes = doc.encode('utf-8')
protocol_bytes = (json.dumps(new, indent=2) + '\n').encode('utf-8')
(B / 'OWNERSHIP-PROPOSAL-03.md').write_bytes(doc_bytes)
(B / 'PROTOCOL-03.json').write_bytes(protocol_bytes)
delta = {
    'base_proposal_sha256': sha((P / 'OWNERSHIP-PROPOSAL-02.md').read_bytes()),
    'base_protocol_sha256': sha((P / 'PROTOCOL-02.json').read_bytes()),
    'new_proposal_sha256': sha(doc_bytes), 'new_protocol_sha256': sha(protocol_bytes),
    'unchanged_top_level_keys': [k for k in old if old[k] == new[k]],
    'changed_top_level_keys': [k for k in old if old[k] != new[k]],
    'new_top_level_keys': [k for k in new if k not in old],
    'scope': 'comparison only; no patch applied to Root/old documents or production source'
}
(B / 'PROTOCOL-DELTA-03.json').write_text(json.dumps(delta, indent=2) + '\n', encoding='utf-8')
patch = ''.join(difflib.unified_diff(old_doc.splitlines(keepends=True), doc.splitlines(keepends=True),
    fromfile='proposal02/OWNERSHIP-PROPOSAL-02.md', tofile='proposal03/OWNERSHIP-PROPOSAL-03.md'))
patch += ''.join(difflib.unified_diff((P / 'PROTOCOL-02.json').read_text().splitlines(keepends=True),
    protocol_bytes.decode().splitlines(keepends=True), fromfile='proposal02/PROTOCOL-02.json', tofile='proposal03/PROTOCOL-03.json'))
(B / 'PROPOSAL-03.diff').write_bytes(patch.encode('utf-8'))
facts = {}
for file in ('PRIMARY-01.json', 'PRIMARY-02.json', 'PRIMARY-03.json'):
    value = json.loads((Q / file).read_text())
    wanted = {'net/minecraft/server/Main.class': ('main(',),
        'net/minecraft/server/dedicated/DedicatedServerSettings.class': ('forceSave(',),
        'net/minecraft/server/dedicated/Settings.class': ('store(',),
        'net/minecraftforge/common/util/SortedProperties.class': ('store(',),
        'net/minecraft/server/commands/ForceLoadCommand.class': ('changeForceLoad(',),
        'net/minecraft/server/level/ServerLevel.class': ('getForcedChunks(', 'setChunkForced('),
        'net/minecraft/world/level/ForcedChunksSavedData.class': ('save(', 'load('),
        'net/minecraft/server/MinecraftServer.class': ('prepareLevels(',)}
    for name, prefixes in wanted.items():
        if name not in value['classes']:
            continue
        v = value['classes'][name]
        selected = {sig: {'access': m['access'], 'references': m['references'], 'branches': m['branches']}
            for sig, m in v['selected_methods'].items() if sig.startswith(prefixes)}
        if selected:
            existing = facts.setdefault(name, {'bytes': v['bytes'], 'sha256': v['sha256'], 'methods': {}})
            existing['methods'].update(selected)
props = json.loads((Q / 'PROPERTIES-01.json').read_text())
(B / 'PRIMARY-JUSTIFICATION-03.json').write_text(json.dumps({'mapped_jar_sha256': '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e',
    'class_facts': facts, 'jdk_properties_writer': props,
    'upstream_fact_provenance': str(Q), 'scope': 'selected static declarations/references, not body import/native execution'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'proposal_bytes': len(doc_bytes), 'proposal_sha256': sha(doc_bytes),
    'protocol_bytes': len(protocol_bytes), 'protocol_sha256': sha(protocol_bytes),
    'unchanged_top_level_keys': len(delta['unchanged_top_level_keys']), 'new_top_level_keys': delta['new_top_level_keys'],
    'diff_sha256': sha(patch.encode('utf-8'))}))
