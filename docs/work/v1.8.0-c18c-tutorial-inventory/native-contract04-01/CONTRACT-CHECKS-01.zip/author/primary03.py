"""Correct only the failed cached class locator; preserve primary02.py/log/exit."""
from pathlib import Path

B = Path(__file__).resolve().parent
source = (B / 'primary02.py').read_text(encoding='utf-8')
source = source.replace('net/minecraftforge/common/util/ForgeSortedProperties.class',
                        'net/minecraftforge/common/util/SortedProperties.class')
source = source.replace("'PRIMARY-02.json'", "'PRIMARY-03.json'")
source = source.replace("'lambda$changeForceLoad$8'", 
    "'lambda$changeForceLoad$8', 'lambda$changeForceLoad$9', 'lambda$changeForceLoad$10', "
    "'lambda$changeForceLoad$11', 'lambda$changeForceLoad$12', 'lambda$changeForceLoad$13'")
exec(compile(source, str(B / 'primary03.py'), 'exec'), {'__file__': __file__, '__name__': '__main__'})
