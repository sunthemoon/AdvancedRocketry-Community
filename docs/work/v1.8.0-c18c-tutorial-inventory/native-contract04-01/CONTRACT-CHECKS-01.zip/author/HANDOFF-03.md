# C18c native fixture technical proposal03 handoff

Date: 2026-10-05. Author preparation only; **not independent review, implementation,
Root acceptance, native execution, ledger delivery or a Required Gate result**.

## Scope and proposed changes

The exact cumulative candidates are [OWNERSHIP-PROPOSAL-03.md](OWNERSHIP-PROPOSAL-03.md)
and [PROTOCOL-03.json](PROTOCOL-03.json). The [comparison](PROPOSAL-03.diff) and
[structured delta](PROTOCOL-DELTA-03.json) bind proposal02 to these postimages;
they have not been applied to Root or any implementation checkout.

1. Bind immutable configured-copy properties separately from each actual
   pre-boot/live/stopped native file. Add a fixed CREATE_NEW observation snapshot,
   driver-observed boot hash launch property and strict seed-stopped bytes/hash in
   the existing driver-owned clean-stop receipt. Reload uses that actual stopped
   file, not restored initial bytes. Normal startup serialization may change raw
   bytes only when the entire bounded decoded map remains equal.
2. Add an exact, intentionally restricted native-store-compatible properties
   line reader contract. Unsupported syntax, duplicate decoded keys, changed
   unknown entries, inserted defaults or normalization refuse that selected host.
   This does not authorize repairing/reselecting its files or changing gameplay.
3. Run the existing fixed forceload command only in seed. Reload is observation
   only. In each phase separately observe all121 fixed native Forced memberships
   and all121 non-null getChunkNow results before either constructor. No metadata
   membership claim substitutes for loading, and no retry repairs a refusal.
4. Require host revision3 on the test marker/cohort/receipt and the explicit new
   host fields. Old revision2 inputs refuse; this is not a public schema migration.

All15 unchanged protocol top-level values, old host fields except revision,
old PLAYER_STATE fields, six goals, two identities, inventory listener/reload
meaning,23 events, original ceilings and deadlines are preserved. Both native
constructors still follow complete dual preflight and precede either native join.
Record admission, cache/reflection ownership, partial cleanup, ERROR/FATAL
refusal and driver-only clean-stop receipt remain cumulative proposal02 rules.

## Source facts and preparation history

The original Task03 review remains immutable at its recorded location and SHA
`1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0`.
Its two Medium findings have not been independently closed by this author task.
The old proposal02 manifest is
`f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955`.

Native/JDK facts in [PRIMARY-03](PRIMARY-03.json), [PRIMARY-05](PRIMARY-05.json),
[PRIMARY-06](PRIMARY-06.json), [PRIMARY-07](PRIMARY-07.json) and the retained
[earlier justification](PRIMARY-JUSTIFICATION-03.json) explain the proposed
bindings. The mapped47.4.10 JAR is pinned as
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`;
JDK17.0.7 Properties source member as
`39b59b3bbf0d11dddcc7657a850da601dd7b6846408744a11bcba3b9ce3e4412`.
These are selected cached primary facts, not official code imported into the
project and not an emitted native host record.

Additional primary inspection corrected an initially authored, unsealed numeric
acknowledgement grammar. In the actual native multiple-success lambda the first
Object[] argument is the last changed ChunkPos, not the integer counter, although
the English template says `chunks`. The command separately returns its counter.
The proposal now admits only that exact canonical pair rendering; it never
claims acknowledgement text measured the number of newly added chunks.
The [native templates](FORCELOAD-LANGUAGE-01.json), lambda descriptor/arguments
and ChunkPos concat constant are separately pinned. No rendered success line
was observed in this task. The earlier [checkpoint](CHECKPOINT-02.json),
[35-control result](CONTROL-RESULT-01.json), and all later red/green logs remain.

The properties subset also refuses an unescaped key colon: native JDK load0
treats it as a separator. This is a test-input eligibility restriction, not an
alternative interpretation of native keys or an adopted universal decoder.

## Actual commands and results

All substantive commands used `python -B` with process-local TEMP/TMP/TMPDIR in
this leaf's process-temp. [COMMANDS-01.json](COMMANDS-01.json) records argv,
source/log/exit pins; [TOOL-OBSERVATIONS.md](TOOL-OBSERVATIONS.md) distinguishes
inspector/runner failures and the exploratory missing locator.

- Intake: exit0;119 named inputs, original52 author and46 reviewer payloads pinned.
- Initial preparation builders03/04: exit0. Their historical outputs are retained
  as checkpoints, not final candidate regenerators or implementation receipts.
- Primary02: exit1, wrong guessed ForgeSortedProperties class locator; no fact
  output or Java/native run. Primary03: exit0, actual SortedProperties class.
- Primary04: exit1, inspector's multiline Writer flag assertion; no Java/native
  run. Primary05: exit0, exact source line851 false flag plus actual lambda facts.
  Primary06/07: exit0, native key separator and Reader/console route facts.
- Controls01:35/0FES, partial initial models; not native acknowledgement proof.
- Controls02 with original acknowledgement model: **37/3 failures**, exit1.
  Same controls with corrected source-derived model:37/0FES, exit0. These are
  author specification model observations, not a before/after implementation run.
- Controls03: exit1 **before tests**, nested text-based runner extraction failed.
  Separate controls04 corrects only extraction: **38/0FES**, exit0, consisting of
 18 unchanged proposal02 controls and20 revision controls. No old assertions or
  time/size ceilings were removed or relaxed.
- Input postcheck: exit0;119 named files and12 fixed `a5abc348...` Git objects
  unchanged, including the original52/46 frozen payloads. See
  [INPUT-POSTCHECK-01.json](INPUT-POSTCHECK-01.json). No whole-repository identity
  is asserted; observed docs publication and unrelated analyzer work are separate.

## Required but unexecuted checks

The final executable controls are **partial specifications**. They model raw/map
phase binding, malformed subset refusal,121 target vectors, native payload syntax
and symbolic freshness/origin metadata. They do not implement the real logger
parser, file safety, host callbacks, JDK/native writer, native codec or lifecycle.

Before a future implementation/native assignment, independently review the exact
postimages, then verify at least:

- A separately selected source/copy/mod/library/cache/world passes all original
  source and host restrictions; a historic Guard fixture is not presumed clean.
- Exact snapshot/marker/boot property/live/stopped reads, strict unknown-field and
  malformed-path/type/size cases, logical-map equality and no file restoration.
  Actual native default insertion/normalization may make an input ineligible.
- Actual whole-runtime JSON rows/marker/receipt fit the unchanged16,384-byte and
  node/depth caps. The protocol specification document itself is not a runtime
  row. A small added-component model is not full-emitter allocation proof.
- One fresh seed acknowledgement from the actual console route, strict native
  canonical pair spelling, original deadline accounting, zero-addition refusal,
  both public native membership observations and independent loaded probes.
- Actual pre-constructor Adventure/shared-spawn/border/entity/loaded admission,
  two constructors before either join, saved location before any corrective action,
  cache/channel/partial failure handling and no newly introduced load request.
- Ordinary listener acquisition of all six goals, empty/unrelated controls and
  actual native stopped player/advancement/stats files; driver clean-stop receipt
  created only after all its independent assertions pass.
- Reload sends no setup command, observes already restored membership/loading,
  validates receipt-bound boot file and actual current live map, inspects loaded
  progress before positive replay, and proves unchanged timestamps/idempotence.
- Unknown ERROR/FATAL, refusal, failed cleanup, missing/mismatched native output
  or timeout retains failure and prevents success receipt/retry-as-pass.

No suitable source has been selected here. Runtime costs, actual native string
rendering, callbacks, ownership/cache/channel disposal, file reload and successful
stop remain unrun. Native calls are not claimed preemptible. Two clean stops would
not prove arbitrary-crash recovery, real-client/GPU/V1/V2 or all version Gates.
No GuardTicket/resource/canonical hash/API authority or R-021 closure is granted.

## Delivery and integration boundary

Only this fresh external directory was written. No Root/author/worktree/source,
configuration, original records/forced chunks, old packet, AGENTS, Git index/HEAD,
Java/native/client/server process or C output was changed. No commit or cleanup
was performed. Root must author a separately pinned replacement leaf after a
different-agent review; the current Root Task03 still points at proposal02.

The small loose [EVIDENCE-MANIFEST.json](EVIDENCE-MANIFEST.json) and
[SHA256SUMS.txt](SHA256SUMS.txt) freeze the exact candidates, helpers, controls,
primary facts, checkpoints and raw command failures. No source/JAR/world export
or redundant archive is created. Runtime/source admission and all Required Gates
remain open.
