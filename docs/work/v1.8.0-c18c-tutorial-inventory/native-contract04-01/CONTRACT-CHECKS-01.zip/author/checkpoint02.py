"""Preserve unsealed acknowledgement grammar before the source-derived correction."""
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent
items = {}
for name in ('OWNERSHIP-PROPOSAL-03.md', 'PROTOCOL-03.json', 'PROPOSAL-03.diff'):
    path = B / name
    raw = path.read_bytes()
    destination = B / (path.stem + '.checkpoint-02' + path.suffix)
    assert not destination.exists()
    destination.write_bytes(raw)
    items[name] = {'preserved': destination.name, 'bytes': len(raw),
                   'sha256': hashlib.sha256(raw).hexdigest()}
(B / 'CHECKPOINT-02.json').write_text(json.dumps({'files': items,
    'reason': 'Unsealed newly authored numeric acknowledgement grammar contradicted by native lambda argument descriptor; no host or native parser was executed.'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(items))
