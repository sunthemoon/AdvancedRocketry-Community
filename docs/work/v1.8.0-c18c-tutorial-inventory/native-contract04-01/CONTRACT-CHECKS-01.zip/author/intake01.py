import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
Q = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = {}
def pin(path, wanted=None):
    raw = path.read_bytes()
    result = {'bytes': len(raw), 'sha256': sha(raw)}
    assert wanted is None or result['sha256'] == wanted, (path, result, wanted)
    pins[str(path)] = result
    return raw
for relative in ('AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md'):
    pin(R / relative)
assert pins[str(R / 'AGENTS.md')]['sha256'] == '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
assert pins[str(R / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md')]['sha256'] == 'c75fec1a7f1cb5291147abb838712ed695c7c011f060bff1f6f7378011a6b6d4'
for path, expected in ((P / 'EVIDENCE-MANIFEST.json', 'f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955'),
    (Q / 'INTERNAL-MANIFEST.json', '744258fd63b5a8571d90ecb764ae7c463f80298c1127bb1cdfc7a3f7d6a61afa'),
    (Q / 'REVIEW-03.md', '1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0')):
    manifest = json.loads(pin(path, expected)) if path.suffix == '.json' else None
    if manifest is not None:
        for e in manifest['files']:
            raw = pin(path.parent / e['path'], e['sha256'])
            assert len(raw) == e['bytes']
annotation = Path('D:/ARCE-Task-Evidence/v1.8.0/agnf-1b7aa2336c/ANNOTATION-MESSAGE-05.json')
old = json.loads(pin(annotation, '667b05dbb13301a592bb7ef1105a6e174e327ba4544347c64bda4d3f5532b33b'))
jar = Path(old['message']['jar_path'])
pin(jar, old['message']['jar_sha256'])
with zipfile.ZipFile(jar) as z:
    raw = z.read('assets/minecraft/lang/en_us.json')
    assert sha(raw) == old['message']['member_sha256']
    lang = json.loads(raw)
    facts = {k: v for k, v in lang.items() if k.startswith('commands.forceload.')}
(B / 'FORCELOAD-LANGUAGE-01.json').write_text(json.dumps({'jar_path': str(jar),
    'jar_sha256': old['message']['jar_sha256'], 'member': 'assets/minecraft/lang/en_us.json',
    'member_sha256': sha(raw), 'templates': facts, 'scope': 'primary text templates only, no command or rendered native observation'}, indent=2) + '\n', encoding='utf-8')
for f in ('PRIMARY-01.json', 'PRIMARY-02.json', 'PRIMARY-03.json', 'PROPERTIES-01.json'):
    value = json.loads((Q / f).read_text())
    if 'jar' in value:
        pin(Path(value['jar']['path']), value['jar']['sha256'])
        pin(Path(value['parser']['path']), value['parser']['sha256'])
    if f == 'PROPERTIES-01.json':
        for key in ('source_archive', 'binary_module'):
            pin(Path(value[key]['path']), value[key]['sha256'])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip()
(B / 'INPUT-PINS-01.json').write_text(json.dumps({'schema': 1, 'fixed_source': 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
    'documentation_head_at_intake': head, 'files': pins, 'old_author_payloads': 52, 'old_review_payloads': 46,
    'scope': 'named read-only inputs, not current analyzer work or whole-repository identity'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'named_pins': len(pins), 'old_author_payloads_verified': 52, 'old_review_payloads_verified': 46,
    'native_language_templates': facts, 'java_launches': 0, 'documentation_head': head}))
