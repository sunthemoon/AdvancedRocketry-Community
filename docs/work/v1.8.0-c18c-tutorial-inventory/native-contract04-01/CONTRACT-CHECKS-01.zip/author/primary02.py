"""Read only named cached native/JDK members; no Java or host execution."""
import ast
import hashlib
import json
import os
from pathlib import Path
import zipfile

B = Path(__file__).resolve().parent
Q = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
old = json.loads((Q / 'PRIMARY-01.json').read_text(encoding='utf-8'))
parser_path = Path(old['parser']['path'])
parser_raw = parser_path.read_bytes()
assert sha(parser_raw) == old['parser']['sha256']
tree = ast.parse(parser_raw.decode('utf-8'))
subset = ast.Module(body=[n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
                         and n.name in ('R', 'parse')], type_ignores=[])
namespace = {'struct': __import__('struct')}
exec(compile(subset, str(parser_path), 'exec'), namespace)
parse = namespace['parse']
jar = Path(old['jar']['path'])
assert sha(jar.read_bytes()) == old['jar']['sha256']
selection = {
    'net/minecraft/server/commands/ForceLoadCommand.class': {'changeForceLoad', 'lambda$changeForceLoad$5',
        'lambda$changeForceLoad$6', 'lambda$changeForceLoad$7', 'lambda$changeForceLoad$8'},
    'net/minecraft/world/level/ChunkPos.class': {'toString'},
    'net/minecraft/server/level/ServerLevel.class': {'getForcedChunks', 'setChunkForced'},
    'net/minecraft/server/MinecraftServer.class': {'prepareLevels'},
    'net/minecraft/server/dedicated/Settings.class': {'store'},
    'net/minecraftforge/common/util/ForgeSortedProperties.class': {'store'},
}
facts = {}
with zipfile.ZipFile(jar) as archive:
    for name, selected in selection.items():
        raw = archive.read(name)
        data = parse(raw, selected)
        facts[name] = {'bytes': len(raw), 'sha256': sha(raw), 'declared_methods': data['all_methods'],
            'selected': {key: {'descriptor': key, 'access': value['access'], 'code_hex': value['code_hex'],
                'instructions': value['instructions']}
                for key, value in data['selected_methods'].items()}}
props = json.loads((Q / 'PROPERTIES-01.json').read_text(encoding='utf-8'))
src = Path(props['source_archive']['path'])
assert sha(src.read_bytes()) == props['source_archive']['sha256']
with zipfile.ZipFile(src) as archive:
    raw = archive.read('java.base/java/util/Properties.java')
    lines = raw.decode('utf-8').splitlines()
    needles = ('store0(bw, comments, false)', 'saveConvert(key, true, escapeUnicode)',
               'saveConvert(val, false, escapeUnicode)', 'outBuffer.append("\\\\ ")',
               "case '\\t'", "case '\\n'", "case '\\r'", "case '\\f'",
               "case '='", "case ':'", "case '#'", "case '!'", 'escapeUnicode', 'new Date().toString()')
    selected_lines = [{'line': index + 1, 'text': line.strip()} for index, line in enumerate(lines)
                      if any(needle in line for needle in needles)]
    jdk = {'source_archive': props['source_archive'], 'member': 'java.base/java/util/Properties.java',
           'member_bytes': len(raw), 'member_sha256': sha(raw), 'selected_lines': selected_lines}
result = {'schema': 1, 'jar': old['jar'], 'parser': old['parser'], 'native': facts,
          'jdk': jdk, 'java_launches': 0, 'native_runs': 0,
          'scope': 'Named class and source facts only; no emitted console/properties observations.'}
(B / 'PRIMARY-02.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
for name in ('HOST-PRIMARY-03.json', 'HOST-PRIMARY-05.json'):
    raw = (P / name).read_bytes()
    expected = next(item for item in json.loads((P / 'EVIDENCE-MANIFEST.json').read_text())['files']
                    if item['path'] == name)
    assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
    assert not (B / name).exists()
    (B / name).write_bytes(raw)
print(json.dumps({'native_class_facts': len(facts), 'jdk_selected_lines': len(selected_lines),
                  'exact_host_companions': 2, 'java_launches': 0, 'native_runs': 0}))
for name, item in facts.items():
    print(name, item['sha256'])
    for key, method in item['selected'].items():
        print(key)
        for ins in method['instructions']:
            if ins['reference'] is not None:
                print(ins['offset'], ins['reference'])
print(json.dumps(jdk['selected_lines'], indent=2))
