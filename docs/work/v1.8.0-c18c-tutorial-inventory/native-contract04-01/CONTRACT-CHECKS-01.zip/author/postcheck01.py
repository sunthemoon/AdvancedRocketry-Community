"""Check named read-only inputs and construct a comparison-only final delta."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

B = Path(__file__).resolve().parent
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
Q = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-contract03-review-8c51604d2f')
R = Path('D:/GitHub/AdvancedRocketry-Community')
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = json.loads((B / 'INPUT-PINS-01.json').read_text(encoding='utf-8'))
checks = []
for path, expected in before['files'].items():
    raw = Path(path).read_bytes()
    actual = {'bytes': len(raw), 'sha256': sha(raw)}
    checks.append({'path': path, 'before': expected, 'after': actual, 'unchanged': actual == expected})
old_check = json.loads((Q / 'INPUT-POSTCHECK-02.json').read_text(encoding='utf-8'))
git_checks = []
for item in old_check['fixed_git_objects']:
    raw = subprocess.check_output(['git', 'show', item['source']], cwd=R)
    actual = {'bytes': len(raw), 'sha256': sha(raw)}
    expected = {key: item[key] for key in ('bytes', 'sha256')}
    git_checks.append({'object': item['source'], 'before': expected, 'after': actual,
                       'unchanged': expected == actual})
old_proposal = (P / 'OWNERSHIP-PROPOSAL-02.md').read_text(encoding='utf-8')
new_proposal = (B / 'OWNERSHIP-PROPOSAL-03.md').read_text(encoding='utf-8')
old_raw, new_raw = (P / 'PROTOCOL-02.json').read_bytes(), (B / 'PROTOCOL-03.json').read_bytes()
old_protocol, new_protocol = json.loads(old_raw), json.loads(new_raw)
changed = [key for key in old_protocol if old_protocol[key] != new_protocol[key]]
unchanged = [key for key in old_protocol if old_protocol[key] == new_protocol[key]]
added = [key for key in new_protocol if key not in old_protocol]
removed = [key for key in old_protocol if key not in new_protocol]
assert not removed
assert set(changed) == {'payload_schemas', 'external_marker_fields', 'cohort_inputs_fields',
                       'external_receipt_fields', 'runtime_limits', 'proposal_revision', 'host_admission'}
assert set(added) == {'properties_reader', 'properties_lifecycle', 'forced_setup'}
assert len(unchanged) == 15
for key in old_protocol['host_admission']:
    if key != 'revision':
        assert old_protocol['host_admission'][key] == new_protocol['host_admission'][key], key
assert all(old_protocol['payload_schemas']['PLAYER_STATE'][key]
           == new_protocol['payload_schemas']['PLAYER_STATE'][key]
           for key in old_protocol['payload_schemas']['PLAYER_STATE'])
assert new_protocol['deadlines_seconds'] == old_protocol['deadlines_seconds']
assert new_protocol['ceilings'] == old_protocol['ceilings']
assert len(new_protocol['seed_events']) + len(new_protocol['reload_events']) == 23
assert new_protocol['forced_setup']['reload']['commands'] == []
assert new_protocol['host_admission']['console_setup'] == ['forceload add -80 -80 95 95']
assert 'same properties hash' not in new_proposal
diff = ''.join(difflib.unified_diff(old_proposal.splitlines(keepends=True), new_proposal.splitlines(keepends=True),
    fromfile='proposal02/OWNERSHIP-PROPOSAL-02.md', tofile='proposal03/OWNERSHIP-PROPOSAL-03.md'))
diff += ''.join(difflib.unified_diff(old_raw.decode().splitlines(keepends=True), new_raw.decode().splitlines(keepends=True),
    fromfile='proposal02/PROTOCOL-02.json', tofile='proposal03/PROTOCOL-03.json'))
(B / 'PROPOSAL-03.diff').write_bytes(diff.encode('utf-8'))
delta = {'base_proposal_sha256': sha((P / 'OWNERSHIP-PROPOSAL-02.md').read_bytes()),
         'base_protocol_sha256': sha(old_raw), 'new_proposal_sha256': sha((B / 'OWNERSHIP-PROPOSAL-03.md').read_bytes()),
         'new_protocol_sha256': sha(new_raw), 'unchanged_top_level_keys': unchanged,
         'changed_top_level_keys': changed, 'new_top_level_keys': added, 'removed_top_level_keys': removed,
         'comparison_diff_sha256': sha(diff.encode('utf-8')),
         'scope': 'Comparison only; Root/old documents/source/Git/config/world are not patched.'}
(B / 'PROTOCOL-DELTA-03.json').write_text(json.dumps(delta, indent=2) + '\n', encoding='utf-8')
drift = [item for item in checks + git_checks if not item['unchanged']]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip()
out = {'schema': 1, 'named_file_checks': len(checks), 'fixed_git_object_checks': len(git_checks),
       'files': checks, 'fixed_git_objects': git_checks, 'drift': drift,
       'old_author_payloads_unchanged': 52, 'old_review_payloads_unchanged': 46,
       'initial_documentation_head': before['documentation_head_at_intake'], 'final_documentation_head': head,
       'head_qualification': 'Observed docs publication is separate from fixed a5abc source and named input identity.',
       'critical_surface_checks': '15 top-level values, existing host fields except revision, PLAYER_STATE existing fields, all goals/events/identities/time and ceilings retained.',
       'java_native_launches': 0}
(B / 'INPUT-POSTCHECK-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'named_files': len(checks), 'fixed_git_objects': len(git_checks), 'drift': len(drift),
                  'old_author_payloads': 52, 'old_review_payloads': 46, **delta}))
assert not drift, drift
