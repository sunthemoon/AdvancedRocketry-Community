"""Freeze only this owned loose bundle; no archive, tree export or old-input write."""
import hashlib
import json
import os
from pathlib import Path
import re

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
expected_candidates = {
    'OWNERSHIP-PROPOSAL-03.md': 'f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca',
    'PROTOCOL-03.json': 'fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc',
    'HANDOFF-03.md': 'cf434cbac4b2977c8521c1580944a5523fa9ce38bd1e7c88424bce32192b2afa',
}
for name, wanted in expected_candidates.items():
    assert sha((B / name).read_bytes()) == wanted, name
pins = json.loads((B / 'INPUT-PINS-01.json').read_text(encoding='utf-8'))
for name, expected in pins['files'].items():
    raw = Path(name).read_bytes()
    assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], name
assert json.loads((B / 'CONTROL-RESULT-04.json').read_text())['tests'] == 38
assert int((B / 'controls-04.exit').read_text()) == 0
assert int((B / 'controls-02-red.exit').read_text()) == 1
outer = {'EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-RESULT-01.json', 'seal-01.log', 'seal-01.exit'}
for name in outer - {'seal-01.log'}:
    assert not (B / name).exists(), name
files = []
for path in sorted(B.iterdir(), key=lambda value: value.name):
    assert not path.is_symlink(), path
    if path.is_dir():
        assert path.name == 'process-temp' and not list(path.iterdir()), path
        continue
    assert path.resolve().parent == B.resolve(), path
    if path.name in outer:
        continue
    raw = path.read_bytes()
    assert len(raw) <= 2_000_000, path
    files.append({'path': path.name, 'bytes': len(raw), 'sha256': sha(raw)})
manifest = {'schema': 1, 'scope': 'Author cumulative proposal03 and preparation evidence only; no source/native/Gate admission.',
    'files': files, 'payload_count': len(files), 'payload_bytes': sum(item['bytes'] for item in files),
    'external_attestations': sorted(outer),
    'named_inputs': {'original_author02_manifest_sha256': 'f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955',
        'original_task03_review_sha256': '1670cf847adff69ce01679b159e6e37b779ca00314ed134587f8dd37b69edea0',
        '119_input_pins': 'INPUT-PINS-01.json', 'postcheck_12_fixed_git_objects': 'INPUT-POSTCHECK-01.json'},
    'archive': 'None: small loose bundle only; no whole source/JAR/world copies.'}
(B / 'EVIDENCE-MANIFEST.json').write_bytes((json.dumps(manifest, indent=2) + '\n').encode('utf-8'))
checksums = ''.join(item['sha256'] + '  ' + item['path'] + '\n' for item in files)
checksums += sha((B / 'EVIDENCE-MANIFEST.json').read_bytes()) + '  EVIDENCE-MANIFEST.json\n'
(B / 'SHA256SUMS.txt').write_bytes(checksums.encode('ascii'))
active_links = []
for name in ('OWNERSHIP-PROPOSAL-03.md', 'HANDOFF-03.md', 'TOOL-OBSERVATIONS.md'):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (B / name).read_text(encoding='utf-8')):
        assert not target.startswith(('http:', 'https:', 'file:', '/'))
        destination = (B / target).resolve()
        assert destination.parent == B.resolve() and destination.is_file(), (name, target)
        active_links.append({'document': name, 'target': target})
for item in files:
    raw = (B / item['path']).read_bytes()
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
result = {'payload_count': len(files), 'payload_bytes': manifest['payload_bytes'],
    'manifest_sha256': sha((B / 'EVIDENCE-MANIFEST.json').read_bytes()),
    'checksums_sha256': sha((B / 'SHA256SUMS.txt').read_bytes()),
    'candidate_and_handoff_sha256': expected_candidates, 'active_relative_links': active_links,
    'missing_links': 0, 'named_inputs_rechecked': len(pins['files']),
    'all_payloads_verified': True, 'java_native_launches': 0, 'archive_created': False}
(B / 'SEAL-RESULT-01.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'payload_count': result['payload_count'], 'payload_bytes': result['payload_bytes'],
    'manifest_sha256': result['manifest_sha256'], 'checksums_sha256': result['checksums_sha256'],
    'candidate_and_handoff_sha256': expected_candidates, 'active_links': len(active_links),
    'missing_links': 0, 'named_inputs_rechecked': len(pins['files']), 'archive_created': False}))
