"""Supplement exact lambda/Writer/ChunkPos facts, without launching Java."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
prior = json.loads((B / 'PRIMARY-03.json').read_text(encoding='utf-8'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
raw = Path(prior['parser']['path']).read_bytes()
assert sha(raw) == prior['parser']['sha256']
tree = ast.parse(raw.decode('utf-8'))
ns = {'struct': struct}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
    and n.name in ('R', 'parse')], type_ignores=[]), prior['parser']['path'], 'exec'), ns)
jar = Path(prior['jar']['path'])
assert sha(jar.read_bytes()) == prior['jar']['sha256']

def class_header(data):
    r = ns['R'](data)
    assert r.u4() == 0xcafebabe
    r.n(4)
    cp = [None] * r.u2()
    i = 1
    while i < len(cp):
        tag = r.u1()
        if tag == 1:
            cp[i] = r.n(r.u2()).decode('utf-8')
        elif tag in (7, 8, 16, 19, 20):
            cp[i] = (tag, r.u2())
        elif tag in (3, 4):
            r.n(4)
        elif tag in (5, 6):
            r.n(8)
            i += 1
        elif tag in (9, 10, 11, 12, 17, 18):
            r.n(4)
        elif tag == 15:
            r.n(3)
        else:
            raise AssertionError(tag)
        i += 1
    access, this_class, super_class = r.u2(), r.u2(), r.u2()
    return {'access': access, 'class': cp[cp[this_class][1]],
            'superclass': cp[cp[super_class][1]],
            'string_concat_recipe': next((v for v in cp if isinstance(v, str)
                                         and v == '[\x01, \x01]'), None)}

facts = {}
with zipfile.ZipFile(jar) as archive:
    for name, methods in {
        'net/minecraft/server/commands/ForceLoadCommand.class': {'lambda$changeForceLoad$15', 'lambda$changeForceLoad$16'},
        'net/minecraft/world/level/ChunkPos.class': {'toString'},
        'net/minecraftforge/common/util/SortedProperties.class': {'store'},
    }.items():
        raw = archive.read(name)
        parsed = ns['parse'](raw, methods)
        assert parsed['selected_methods']
        facts[name] = {'bytes': len(raw), 'sha256': sha(raw), 'header': class_header(raw),
            'methods': {key: {'access': method['access'], 'code_hex': method['code_hex'],
                             'instructions': method['instructions']}
                        for key, method in parsed['selected_methods'].items()}}
src = Path(prior['jdk']['source_archive']['path'])
assert sha(src.read_bytes()) == prior['jdk']['source_archive']['sha256']
with zipfile.ZipFile(src) as archive:
    raw = archive.read(prior['jdk']['member'])
    assert sha(raw) == prior['jdk']['member_sha256']
    lines = raw.decode('utf-8').splitlines()
    wanted = ('store0(', 'saveConvert(key', 'saveConvert(val', 'if (x == 0 || escapeSpace)',
              'if (((aChar < 0x0020)', 'new Date().toString()')
    source_facts = [{'line': i + 1, 'text': line.strip()} for i, line in enumerate(lines)
                    if any(part in line for part in wanted)]
assert facts['net/minecraft/world/level/ChunkPos.class']['header']['string_concat_recipe'] == '[\x01, \x01]'
assert facts['net/minecraftforge/common/util/SortedProperties.class']['header']['superclass'] == 'java/util/Properties'
assert any('false' in item['text'] for item in source_facts if 'store0(' in item['text'])
out = {'schema': 1, 'jar': prior['jar'], 'parser': prior['parser'], 'native': facts,
       'jdk_member_sha256': prior['jdk']['member_sha256'], 'jdk_source_facts': source_facts,
       'scope': 'Static class argument/string-constant/source facts, not observed rendered output.',
       'java_launches': 0, 'native_runs': 0}
(B / 'PRIMARY-04.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'class_facts': len(facts), 'jdk_source_lines': len(source_facts), 'java_launches': 0}))
for name, fact in facts.items():
    print(name, json.dumps(fact['header']))
    for key, method in fact['methods'].items():
        print(key)
        for ins in method['instructions']:
            print(ins['offset'], ins['opcode_hex'], ins['operand_hex'], ins['reference'])
print(json.dumps(source_facts, indent=2))
