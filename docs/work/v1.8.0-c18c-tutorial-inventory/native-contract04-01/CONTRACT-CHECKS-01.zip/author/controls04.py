"""Correct nested runner extraction only; retain controls03 failure/no-tests receipt."""
from pathlib import Path

B = Path(__file__).resolve().parent
source = (B / 'controls03.py').read_text(encoding='utf-8')
old = 'exec(compile(prior.split("nodes = [n for n in ast.parse(")[0], str(B / \'controls02.py\'), \'exec\'))'
new = '''prefix = []
for node in ast.parse(prior).body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'nodes' for target in node.targets):
        break
    prefix.append(node)
exec(compile(ast.Module(body=prefix, type_ignores=[]), str(B / 'controls02.py'), 'exec'))'''
assert source.count(old) == 1
source = source.replace(old, new).replace("'CONTROL-RESULT-03.json'", "'CONTROL-RESULT-04.json'")
exec(compile(source, str(B / 'controls04.py'), 'exec'), {'__file__': __file__, '__name__': '__main__'})
