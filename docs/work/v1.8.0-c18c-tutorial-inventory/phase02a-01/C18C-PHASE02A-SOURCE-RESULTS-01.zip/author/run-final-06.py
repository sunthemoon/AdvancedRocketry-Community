"""Run only the two named Python suites, retaining raw output and source pins."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
NAMES = ("scripts/classic_inventory_fixture_inputs.py", "scripts/test_classic_inventory_fixture_inputs.py",
         "scripts/run_v180_classic_inventory_smoke.py", "scripts/test_run_v180_classic_inventory_smoke.py")
assert all(Path(os.environ[name]) == HERE for name in ("TEMP", "TMP", "TMPDIR"))

def pins():
    return [{"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
            for name in NAMES for raw in [(WT / name).read_bytes()]]

before = pins()
rows = []
for label, script in (("focused-final-06", NAMES[1]), ("phase01-final-06", NAMES[3])):
    env = dict(os.environ)
    env["ARCE_C18C_INPUT_TEST_ROOT"] = str(HERE / "fixtures-06")
    command = [sys.executable, "-B", script, "-v"]
    start = time.monotonic()
    result = subprocess.run(command, cwd=WT, env=env, capture_output=True)
    raw = result.stdout + result.stderr
    (HERE / (label + ".log")).write_bytes(raw)
    row = {"command": command, "cwd": str(WT), "exit": result.returncode,
           "elapsed_seconds": time.monotonic() - start, "before": before,
           "after": pins(), "log_bytes": len(raw), "log_sha256": hashlib.sha256(raw).hexdigest(),
           "process_temp": str(HERE), "fixture_root": env["ARCE_C18C_INPUT_TEST_ROOT"]}
    (HERE / (label + ".receipt.json")).write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
    rows.append(row)
    print(label, "exit", result.returncode)
    assert row["after"] == before
    assert result.returncode == 0
(HERE / "final-06-results.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
