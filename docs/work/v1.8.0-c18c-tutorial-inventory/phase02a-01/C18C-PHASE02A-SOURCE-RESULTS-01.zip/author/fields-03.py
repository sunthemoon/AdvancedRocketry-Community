from pathlib import Path
import json
import os
import sys

root = Path(__file__).parent / "fields-03-fixture"
root.mkdir(exist_ok=False)
target = root / "server.properties"
names = ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_ctime_ns",
         "st_birthtime_ns", "st_nlink", "st_file_attributes", "st_reparse_tag")
rows = []
for content in (b"active=opaque\n", b"changed", b"", b"x" * 16_384):
    target.write_bytes(content)
    before = target.lstat()
    with target.open("rb", buffering=0) as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(16_385)
        after_descriptor = os.fstat(stream.fileno())
    after = target.lstat()
    rows.append({"length": len(content), "read": len(raw), "observations": {
        label: {name: getattr(value, name, None) for name in names}
        for label, value in (("before", before), ("opened", opened),
                             ("descriptor_after", after_descriptor), ("after", after))}})
result = {"python": sys.version, "rows": rows}
(Path(__file__).parent / "fields-03.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
