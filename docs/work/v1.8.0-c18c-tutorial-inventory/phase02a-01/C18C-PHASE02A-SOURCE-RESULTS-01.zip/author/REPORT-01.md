# C18c phase02a author source packet

Status: REVIEW_READY source proposal. This is implementation evidence, not the
independent review, native/host admission, owner proof or version Gate.

## Completed scope and exact input

Fixed WT base `b6299c86f7bcb99b00b89b4dd38479e035321954`, branch
`codex/v1.8.0-inventory-properties-inputs`. Exactly four new additions are in
[source manifest](SOURCE-MANIFEST-01.json) and [Git patch](SOURCE-01.patch).
The proposed [handoff](postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md)
and [progress](postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md)
state caller ownership/quiescence prerequisites and all unimplemented boundaries.
The private bytes reader does not select a host, consume a receipt, decode
properties or act as live/authoritative transport. No central lines are proposed.

The effective live Root AGENTS and older WT AGENTS are separately pinned in
[governance inputs](GOVERNANCE-INPUTS-01.json). [Source qualification](SOURCE-POSTCHECK-08.json)
finds 2,930 existing named source/build/script/license inputs and 14 governance
inputs unchanged, tracked diff empty and only four assigned new files. This is
named qualification metadata, not a complete source/JAR/runtime export.

## Actual commands/results and original failures

[Final source-pinned runner](run-final-06.py) executes the two real Python
suites with `-B`, all process temp under this D leaf. [Focused receipt](focused-final-06.receipt.json)
and [raw log](focused-final-06.log): **34 tests, 0 failure/error/skip**, exit 0.
[Original phase01 receipt](phase01-final-06.receipt.json) and [raw log](phase01-final-06.log):
**39 unchanged tests, 0 failure/error/skip**, exit 0. Before/after source pins agree.
No Java, Gradle, host, server, client, network or dependency installation ran.

Preserved failures: [first intake](intake-01.log) refuses a wrong binary-fixture
selection assumption before source reads; [first focused import](focused-01.log)
fails syntax before discovery; [second focused run](focused-02.log) executes 31
methods with 5 failures/5 errors. [Actual field observations](fields-03.json)
show why lstat and fstat ctime are not one comparable field after ordinary writes
on this Windows Python 3.13.15 host. Explicit birthtime is compared instead;
missing capability refuses. Original red helpers/source/logs are retained.
Later 31-method green and final additional three controls do not rewrite those
failures. Permission/short-read/close/selected metadata cases use labelled
controlled negative seams; real file/reparse/replacement checks are separately
recorded in [platform observations](fixtures-06-platform.json).

[Patch replay](PATCH-REPLAY-09.json) uses a fresh external empty directory:
Git-generated new-file diffs each return 1 because differences exist, then
`git apply --check` and actual `git apply` each return 0. All four exact LF
postimages match and no other replay file is created. No Git index/repository
mutation occurs.

## Cleanup, remaining limits and next step

[Native literal cleanup precheck](CLEANUP-PRECHECK-07.json) bounds all five fresh
fixture roots and their reparse targets. [Actual result](CLEANUP-RESULT-07.json):
22 aliases first removed without recursion, all five fixture roots absent,
413,698 regular-file bytes deleted, no failure. All raw evidence remains outside
those targets. A later disposable four-file replay cleanup is **tool rejected
before OS launch**, so 39,792 bytes remain there; [exact observation](TOOL-OBSERVATIONS-10.md)
records no OS exit or alternate attempt. Old refused targets/worlds were not
touched or retried. All new helpers/fixtures/output are D-local.

Actual Windows capabilities were exercised, not other platforms or every special
file/reparse kind. Actual ACL denial, hostile races, hidden same-identity changes
and interruptible OS deadlines are not proved. The strict reader refuses missing
proof capability; this is quiescent caller-trusted use only. Live properties,
JSON/NBT accounting, ownership/freshness transport, CREATE_NEW marker/receipt,
driver/Java/native and all G0-G9 remain separate. Root owns independent review,
integration and any current-version continuation. Source postimages are frozen;
no independent review outcome is prefilled by this author packet.
