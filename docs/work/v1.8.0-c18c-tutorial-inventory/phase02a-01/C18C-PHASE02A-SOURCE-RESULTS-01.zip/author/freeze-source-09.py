"""Freeze only four additions and replay their Git-generated patch outside Git."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
OWN = ("scripts/classic_inventory_fixture_inputs.py", "scripts/test_classic_inventory_fixture_inputs.py",
       "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md",
       "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md")
assert all(Path(os.environ[name]) == HERE for name in ("TEMP", "TMP", "TMPDIR"))
postimages = HERE / "postimages"
postimages.mkdir(exist_ok=False)
parts, rows, commands = [], [], []
for name in OWN:
    raw = (WT / name).read_bytes()
    target = postimages / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    command = ["git", "-c", "core.autocrlf=false", "diff", "--no-index", "--", "/dev/null", name]
    result = subprocess.run(command, cwd=WT, capture_output=True)
    commands.append({"command": command, "cwd": str(WT), "exit": result.returncode,
                     "meaning": "1 is actual no-index difference, not a failed application",
                     "stderr": result.stderr.decode("utf-8", errors="strict")})
    assert result.returncode == 1
    assert result.stdout.startswith(("diff --git a/" + name + " b/" + name + "\n").encode())
    parts.append(result.stdout)
    rows.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                 "new_file": True, "crlf_count": raw.count(b"\r\n"), "lines": len(raw.splitlines())})
patch = b"".join(parts)
patch_path = HERE / "SOURCE-01.patch"
patch_path.write_bytes(patch)
replay = HERE / "patch-replay-09"
replay.mkdir(exist_ok=False)
for suffix, args in (("check", ["--check"]), ("apply", [])):
    command = ["git", "-c", "core.autocrlf=false", "apply", *args, str(patch_path)]
    result = subprocess.run(command, cwd=replay, capture_output=True)
    (HERE / ("patch-09-" + suffix + ".log")).write_bytes(result.stdout + result.stderr)
    commands.append({"command": command, "cwd": str(replay), "exit": result.returncode})
    assert result.returncode == 0
drift = [row["path"] for row in rows
         if (replay / row["path"]).read_bytes() != (postimages / row["path"]).read_bytes()]
observed = sorted(path.relative_to(replay).as_posix() for path in replay.rglob("*") if path.is_file())
assert observed == sorted(OWN) and not drift
assert all((WT / row["path"]).read_bytes() == (postimages / row["path"]).read_bytes() for row in rows)
manifest = {"fixed_base": "b6299c86f7bcb99b00b89b4dd38479e035321954", "files": rows,
            "patch": {"path": "SOURCE-01.patch", "bytes": len(patch), "sha256": hashlib.sha256(patch).hexdigest()}}
(HERE / "SOURCE-MANIFEST-01.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
receipt = {"commands": commands, "fresh_replay_initial_files": 0, "actual_postimage_files": observed,
           "postimage_drift": drift, "patch": manifest["patch"],
           "not_git_mutation": "no init/index/commit/checkout or repository source write; only four fresh external files"}
(HERE / "PATCH-REPLAY-09.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"four_postimages": rows, "patch": manifest["patch"], "check_apply_exits": [0, 0], "drift": drift}, indent=2))
