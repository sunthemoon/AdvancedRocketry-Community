$ErrorActionPreference = 'Stop'
$owned = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-author-20261005-1b8f40')
$names = @('fixtures-02', 'fixtures-03', 'fixtures-05', 'fixtures-06', 'fields-03-fixture')
$roots = @()
$all = @()
foreach ($name in $names) {
    $literal = Join-Path $owned $name
    $resolved = (Resolve-Path -LiteralPath $literal -ErrorAction Stop).ProviderPath
    $absolute = [IO.Path]::GetFullPath($resolved)
    if (-not $absolute.StartsWith($owned + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'OUTSIDE_OWNED_ROOT' }
    if ([IO.Path]::GetFileName($absolute) -cne $name) { throw 'UNEXPECTED_ROOT_NAME' }
    $root = Get-Item -LiteralPath $absolute -Force
    if (-not $root.PSIsContainer -or ($root.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'UNEXPECTED_ROOT_TYPE' }
    $roots += $absolute
    $stack = [Collections.Generic.Stack[string]]::new()
    $stack.Push($absolute)
    while ($stack.Count -gt 0) {
        $directory = $stack.Pop()
        foreach ($item in @(Get-ChildItem -LiteralPath $directory -Force)) {
            $path = [IO.Path]::GetFullPath($item.FullName)
            if (-not $path.StartsWith($absolute + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'ENUMERATION_OUTSIDE_FIXTURE' }
            if ($all.Count -ge 10000) { throw 'FIXTURE_ENTRY_BOUND' }
            $link = [bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint)
            $targets = @()
            if ($link) {
                foreach ($target in @($item.Target)) {
                    if (-not [IO.Path]::IsPathFullyQualified($target)) { throw 'UNEXPECTED_RELATIVE_LINK' }
                    $targetAbsolute = [IO.Path]::GetFullPath($target)
                    if (-not ($targetAbsolute.Equals($absolute, [StringComparison]::OrdinalIgnoreCase) -or
                              $targetAbsolute.StartsWith($absolute + '\', [StringComparison]::OrdinalIgnoreCase))) { throw 'LINK_TARGET_OUTSIDE_FIXTURE' }
                    $targets += $targetAbsolute
                }
                if ($targets.Count -ne 1) { throw 'UNEXPECTED_LINK_TARGET_COUNT' }
            } elseif ($item.PSIsContainer) {
                $stack.Push($path)
            }
            $all += [pscustomobject]@{ path=$path; root=$absolute; directory=[bool]$item.PSIsContainer; reparse=$link;
                targets=$targets; bytes=$(if (-not $item.PSIsContainer -and -not $link) { [long]$item.Length } else { 0L }) }
        }
    }
}
$pre = [ordered]@{ task='owned phase02a fresh disposable file fixtures only'; root=$owned; roots=$roots;
    process_scope='all own Python test commands terminal; no host/process launched'; entries=$all;
    regular_file_bytes=[long](($all | Measure-Object -Property bytes -Sum).Sum); entry_count=$all.Count;
    evidence_excluded='all logs/results/platform records/source postimages/manifests remain outside fixture targets' }
$pre | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $owned 'CLEANUP-PRECHECK-07.json') -Encoding utf8
$removed = @()
$failure = $null
try {
    foreach ($entry in @($all | Where-Object reparse | Sort-Object { $_.path.Length } -Descending)) {
        Remove-Item -LiteralPath $entry.path -Force -ErrorAction Stop
        $removed += [pscustomobject]@{ path=$entry.path; kind='reparse alias only'; absent=(-not (Test-Path -LiteralPath $entry.path)) }
    }
    foreach ($root in $roots) {
        if (-not $root.StartsWith($owned + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'PREDELETE_OUTSIDE_OWNED' }
        Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction Stop
        $removed += [pscustomobject]@{ path=$root; kind='owned disposable fixture directory'; absent=(-not (Test-Path -LiteralPath $root)) }
    }
} catch {
    $failure = [pscustomobject]@{ message=$_.Exception.Message; stopped_target=$true; no_alternate_attempt=$true }
}
[ordered]@{ removed=$removed; failure=$failure; precheck_bytes=$pre.regular_file_bytes;
    all_roots_absent=(@($roots | Where-Object { Test-Path -LiteralPath $_ }).Count -eq 0);
    preserved='all source/evidence, older targets/worlds and other owners untouched' } |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $owned 'CLEANUP-RESULT-07.json') -Encoding utf8
if ($failure) { throw 'OWN_FIXTURE_CLEANUP_STOPPED' }
Write-Output ('Removed own regular-file bytes: ' + $pre.regular_file_bytes)
