"""Named source qualification and static controls; no tree/export/host actions."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
BASE = "b6299c86f7bcb99b00b89b4dd38479e035321954"
OWN = ("scripts/classic_inventory_fixture_inputs.py", "scripts/test_classic_inventory_fixture_inputs.py",
       "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md",
       "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md")
assert all(Path(os.environ[name]) == HERE for name in ("TEMP", "TMP", "TMPDIR"))

def raw(path):
    name = str(path.absolute())
    return Path(name if name.startswith("\\\\?\\") else "\\\\?\\" + name).read_bytes()

def git(*args):
    value = subprocess.run(["git", *args], cwd=WT, capture_output=True)
    assert value.returncode == 0, (args, value.returncode)
    return value.stdout

def compare(rows):
    drift = []
    for row in rows:
        path = Path(row["path"])
        path = path if path.is_absolute() else WT / path
        value = raw(path)
        if len(value) != row["bytes"] or hashlib.sha256(value).hexdigest() != row["sha256"]:
            drift.append(row["path"])
    return drift

baseline = json.loads((HERE / "BASELINE-SOURCE-01.json").read_text(encoding="utf-8"))
governance = json.loads((HERE / "GOVERNANCE-INPUTS-01.json").read_text(encoding="utf-8"))
drift = compare(baseline["files"])
gov_drift = compare(governance["inputs"])
head = git("rev-parse", "HEAD").decode().strip()
branch = git("branch", "--show-current").decode().strip()
tracked_diff = git("diff", "--exit-code")
git("diff", "--check")
others = sorted(name for name in git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0") if name)
tree = ast.parse(raw(WT / OWN[0]).decode("utf-8"))
imports = sorted(node.module if isinstance(node, ast.ImportFrom) else alias.name
                 for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))
                 for alias in ([None] if isinstance(node, ast.ImportFrom) else node.names))
assert imports == ["__future__", "os", "pathlib", "stat", "types"]
forbidden = {"write", "write_bytes", "write_text", "mkdir", "unlink", "replace", "rename", "remove",
             "iterdir", "glob", "rglob", "walk", "read_bytes", "read_text", "system", "run", "Popen"}
calls = [node.func.attr for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)]
assert not (set(calls) & forbidden)
assert calls.count("read") == 1
assert not any(isinstance(node, ast.Name) and node.id == "__name__" for node in ast.walk(tree))
methods = lambda name: sorted(node.name for node in ast.walk(ast.parse(raw(WT / name).decode("utf-8")))
                              if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))
assert len(methods(OWN[1])) == 34
assert len(methods("scripts/test_run_v180_classic_inventory_smoke.py")) == 39
assert git("show", BASE + ":scripts/test_run_v180_classic_inventory_smoke.py") == raw(WT / "scripts/test_run_v180_classic_inventory_smoke.py")
cleanup = json.loads((HERE / "CLEANUP-RESULT-07.json").read_text(encoding="utf-8-sig"))
assert cleanup["failure"] is None and cleanup["all_roots_absent"]
assert all(not (HERE / name).exists() for name in ("fixtures-02", "fixtures-03", "fixtures-05", "fixtures-06", "fields-03-fixture"))
result = {"base_commit": BASE, "actual_head": head, "branch": branch,
          "source_input_count": len(baseline["files"]), "source_drift": drift,
          "governance_count": len(governance["inputs"]), "governance_drift": gov_drift,
          "tracked_diff_bytes": len(tracked_diff), "untracked": others, "exclusive_scope": list(OWN),
          "static": {"private_imports": imports, "one_read_call": True, "no_helper_write_enumeration_driver_cli": True,
                     "focused_methods": len(methods(OWN[1])), "phase01_original_methods": 39,
                     "phase01_fixed_git_blob_equal": True},
          "cleanup_all_owned_fixture_roots_absent": True, "cleanup_regular_file_bytes": cleanup["precheck_bytes"]}
(HERE / "SOURCE-POSTCHECK-08.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
assert head == BASE and branch == "codex/v1.8.0-inventory-properties-inputs"
assert not drift and not gov_drift and others == sorted(OWN)
print(json.dumps(result, indent=2))
