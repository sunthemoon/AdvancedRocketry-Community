"""Pin the named source/build/scripts and task inputs without exporting their bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WT = Path('D:/GitHub/arce-v180-c18c-inputs-20261005')
BASE = 'b6299c86f7bcb99b00b89b4dd38479e035321954'
required = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
            'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
            'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
            'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04-PHASE02A.md',
            'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md']
def read(path):
    absolute = str(path.absolute())
    return Path(absolute if absolute.startswith('\\\\?\\') else '\\\\?\\' + absolute).read_bytes()
def pin(path, relative):
    raw = read(path)
    return {'path': relative, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
assert all(os.environ.get(name) == str(HERE) for name in ('TEMP', 'TMP', 'TMPDIR'))
head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=WT, capture_output=True, text=True, check=True).stdout.strip()
assert head == BASE
status = subprocess.run(['git', 'status', '--porcelain'], cwd=WT, capture_output=True, text=True, check=True).stdout
assert not status
names = subprocess.run(['git', 'ls-files', '-z', '--', 'src', 'scripts', 'build.gradle', 'settings.gradle',
                        'gradle.properties', 'gradlew', 'gradlew.bat', 'gradle', 'LICENSE', 'NOTICE.md'],
                       cwd=WT, capture_output=True, check=True).stdout.decode('utf-8').split('\0')
names = sorted(set(name for name in names if name))
assert all('Development-Docs' not in name and not name.endswith(('.jar', '.zip')) for name in names)
rows = [pin(WT / name, name) for name in names]
governance = [pin(WT / name, name) for name in required]
live = Path('D:/GitHub/AdvancedRocketry-Community/AGENTS.md')
governance.append(pin(live, live.as_posix()))
(HERE / 'BASELINE-SOURCE-01.json').write_text(json.dumps({'base_commit': BASE, 'scope': 'named tracked src/scripts/build/license inputs; not whole repository',
    'files': rows}, indent=2) + '\n', encoding='utf-8')
(HERE / 'GOVERNANCE-INPUTS-01.json').write_text(json.dumps({'fixed_wt_base': BASE, 'inputs': governance}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'base': head, 'status': status, 'source_inputs': len(rows), 'governance_inputs': len(governance),
                  'live_agents': governance[-1], 'wt_agents': governance[0]}))
