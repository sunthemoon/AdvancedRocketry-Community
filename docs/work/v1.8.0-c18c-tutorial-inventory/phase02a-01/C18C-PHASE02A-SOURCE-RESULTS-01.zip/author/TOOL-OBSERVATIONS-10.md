# Actual final tool observation

Date: 2026-10-05. This observation is separate from the successful fixture
cleanup-07 and the successful patch check/apply-09.

A native PowerShell command proposed checking the resolved absolute
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-author-20261005-1b8f40/patch-replay-09`
against its explicit owned parent, hashing its four replay files against the
source manifest, then using `Remove-Item -LiteralPath` recursively. The tool
rejects the command during `CreateProcess` with `blocked by policy`; no OS
process starts and there is no OS exit code. The proposed precheck/result files
are not execution evidence. This target is stopped without an alternate tool
or retry. The four fresh replay files remain, 39,792 regular-file bytes.

The exact command requested was:

```powershell
$ErrorActionPreference='Stop'; $e=[IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-author-20261005-1b8f40'); $p=(Resolve-Path -LiteralPath (Join-Path $e 'patch-replay-09')).ProviderPath; $p=[IO.Path]::GetFullPath($p); if (-not $p.StartsWith($e+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'OUTSIDE_OWNED' }; $m=Get-Content -LiteralPath (Join-Path $e 'SOURCE-MANIFEST-01.json') -Raw | ConvertFrom-Json; $sum=0L; foreach($r in $m.files) { $f=Join-Path $p $r.path; $i=Get-Item -LiteralPath $f; if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'UNEXPECTED_REPARSE' }; if ((Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLowerInvariant() -ne $r.sha256) { throw 'REPLAY_DRIFT' }; $sum+=$i.Length }; [ordered]@{path=$p; exact_four_postimages=$true; bytes=$sum; preserved_source='postimages plus SOURCE-MANIFEST/SOURCE.patch/PATCH-REPLAY receipts outside target'; native_literal_cleanup=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $e 'PATCH-REPLAY-CLEANUP-PRECHECK-10.json') -Encoding utf8; Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop; [ordered]@{path=$p; bytes=$sum; absent=(-not(Test-Path -LiteralPath $p)); failure=$null} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $e 'PATCH-REPLAY-CLEANUP-RESULT-10.json') -Encoding utf8; Write-Output "Fresh replay copy cleaned: $sum bytes"
```

All old rejected targets, other owners, source worlds and sealed evidence remain
untouched. No successful cleanup result is invented for this replay target.
