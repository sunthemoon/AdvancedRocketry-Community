"""Seal the small explicitly owned loose payload; never recurse old/root trees."""
import hashlib
import json
import os
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
assert all(Path(os.environ[name]) == HERE for name in ("TEMP", "TMP", "TMPDIR"))
source = json.loads((HERE / "SOURCE-MANIFEST-01.json").read_text(encoding="utf-8"))
for row in source["files"]:
    raw = (WT / row["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
    assert raw == (HERE / "postimages" / row["path"]).read_bytes()
    assert (HERE / "patch-replay-09" / row["path"]).read_bytes() == raw
assert not (HERE / "PATCH-REPLAY-CLEANUP-PRECHECK-10.json").exists()
assert not (HERE / "PATCH-REPLAY-CLEANUP-RESULT-10.json").exists()
for label, total in (("focused-final-06", 34), ("phase01-final-06", 39)):
    row = json.loads((HERE / (label + ".receipt.json")).read_text(encoding="utf-8"))
    raw = (HERE / (label + ".log")).read_bytes()
    assert row["exit"] == 0 and row["before"] == row["after"]
    assert hashlib.sha256(raw).hexdigest() == row["log_sha256"]
    assert re.search(rb"Ran " + str(total).encode() + rb" tests in [0-9.]+s\r?\n", raw)
    assert raw.rstrip().endswith(b"OK") and b"skipped=" not in raw
names = sorted(path.name for path in HERE.iterdir() if path.is_file()
               and path.name not in ("EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt",
                                     "seal-11.log", "seal-11.exit", "SEAL-RESULT-11.json"))
names += ["postimages/" + row["path"] for row in source["files"]]
links = []
for name in ["REPORT-01.md", *["postimages/" + row["path"] for row in source["files"] if row["path"].endswith(".md")]]:
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", (HERE / name).read_text(encoding="utf-8")):
        assert not target.startswith(("D:/", "C:/", "file:"))
        assert (HERE / name).parent.joinpath(target).is_file()
        links.append({"from": name, "target": target})
rows = []
for name in sorted(names):
    raw = (HERE / name).read_bytes()
    rows.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
manifest = {"status": "author REVIEW_READY source proposal, not independent source/native/Gate acceptance",
            "fixed_wt_base": source["fixed_base"], "files": rows,
            "payload_count": len(rows), "payload_bytes": sum(row["bytes"] for row in rows),
            "postimage_count": 4, "active_relative_links": links,
            "exclusions": ["whole source tree/JAR/classes/runtime/worlds", "old/private paths and prior ZIPs",
                           "disposed own fixtures; their platform/cleanup records retained",
                           "tool-rejected four-file disposable replay folder remains outside sealed payload",
                           "seal runtime log/exit/result are a separate post-seal metadata companion"],
            "actual_tests": {"focused": 34, "unchanged_phase01": 39, "failures_errors_skips": [0, 0, 0]},
            "actual_cleanup": {"five_fixture_roots_absent": True, "regular_file_bytes_deleted": 413698,
                               "replay_cleanup": "tool rejected before OS; no alternate attempt; 39792 bytes remain"}}
manifest_path = HERE / "EVIDENCE-MANIFEST-01.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
manifest_raw = manifest_path.read_bytes()
sums = [row["sha256"] + "  " + row["path"] for row in rows]
sums += [hashlib.sha256(manifest_raw).hexdigest() + "  EVIDENCE-MANIFEST-01.json"]
(HERE / "SHA256SUMS-01.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")
for row in rows:
    assert hashlib.sha256((HERE / row["path"]).read_bytes()).hexdigest() == row["sha256"]
result = {"payload_count": len(rows), "payload_bytes": manifest["payload_bytes"], "checksum_entries": len(sums),
          "manifest_sha256": hashlib.sha256(manifest_raw).hexdigest(),
          "sums_sha256": hashlib.sha256((HERE / "SHA256SUMS-01.txt").read_bytes()).hexdigest(),
          "report_sha256": hashlib.sha256((HERE / "REPORT-01.md").read_bytes()).hexdigest(),
          "relative_link_count": len(links), "postimage_drift": [], "checksum_recheck_mismatch": []}
(HERE / "SEAL-RESULT-11.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
