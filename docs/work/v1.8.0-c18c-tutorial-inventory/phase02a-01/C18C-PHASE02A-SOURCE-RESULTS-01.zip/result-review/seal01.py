"""Freeze compact result audit; no previous helper reexecution or big export."""
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote

HERE = Path(__file__).parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path): return json.loads(path.read_text(encoding="utf-8"))
def pin(path):
    raw = path.read_bytes()
    return {"path": path.relative_to(HERE).as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
initial = load(HERE / "READ-INPUTS-01.json")
last = load(HERE / "POSTCHECK-02.json")
for row in initial["root_raw_files"] + initial["source_postimages"] + [initial["governance"]] + last["current_doc_pins"]:
    path = Path(row["path"])
    assert len(path.read_bytes()) == row["bytes"] and sha(path) == row["sha256"]
groups = []
for group in (initial["author_group"], initial["review_group"]):
    folder = Path(group["folder"])
    manifest = load(Path(group["manifest"]["path"]))
    for row in manifest["files"]:
        path = folder / row["path"]
        assert len(path.read_bytes()) == row["bytes"] and sha(path) == row["sha256"]
    for row in (group["manifest"], group["sums"]):
        assert sha(Path(row["path"])) == row["sha256"]
    groups.append({"payloads": group["payloads"], "checksums": group["checksums"], "unchanged": True})
links = []
for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", (HERE / "REVIEW-01.md").read_text(encoding="utf-8")):
    target = match.group(1)
    path = (HERE / unquote(target.split("#", 1)[0])).resolve()
    assert path.is_relative_to(HERE.resolve()) and path.is_file()
    links.append(target)
controls = {"root_original_files": len(initial["root_raw_files"]), "root_raw_drift": 0, "source_eight_drift": 0, "final_four_docs_drift": 0, "original_manifest_groups": groups, "report_links": links, "missing": 0, "no_native_or_owner_admission": True}
(HERE / "SEAL-CONTROLS-01.json").write_text(json.dumps(controls, indent=2)+"\n", encoding="utf-8")
excluded = {"EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt", "SEAL-RESULT-01.json", "seal-01.log", "seal-01.stderr.txt", "seal-01.exit"}
files = [pin(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name not in excluded]
manifest = {"schema": 1, "scope": "independent phase02a committed result and final pending-record audit", "files": files, "payload_count": len(files), "payload_bytes": sum(row["bytes"] for row in files), "not_complete_publication_or_native_closure": True, "excluded_standalone_seal_receipts": sorted(excluded - {"EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt"})}
(HERE / "EVIDENCE-MANIFEST-01.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
manifest_pin = pin(HERE / "EVIDENCE-MANIFEST-01.json")
with (HERE / "SHA256SUMS-01.txt").open("w", encoding="utf-8", newline="\n") as stream:
    for row in [*files, manifest_pin]:
        stream.write(row["sha256"]+"  "+row["path"]+"\n")
for row in files:
    assert pin(HERE / row["path"]) == row
result = {"payloads": len(files), "payload_bytes": manifest["payload_bytes"], "checksum_entries": len(files)+1, "report": pin(HERE / "REVIEW-01.md"), "manifest": manifest_pin, "sums": pin(HERE / "SHA256SUMS-01.txt"), "all_sha_mismatches": 0, "zip_created": False}
(HERE / "SEAL-RESULT-01.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps(result, indent=2))
