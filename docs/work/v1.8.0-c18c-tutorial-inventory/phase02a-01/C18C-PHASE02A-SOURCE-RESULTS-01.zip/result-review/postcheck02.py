"""Preserve initial read pins and qualify the one intentional pending-log edit."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
COMMIT = "254af9e4b7f2fe007eea87989e1534a238b140b7"
def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
initial = json.loads((HERE / "READ-INPUTS-01.json").read_text(encoding="utf-8"))
for row in initial["root_raw_files"] + initial["source_postimages"] + [initial["governance"]]:
    assert pin(Path(row["path"])) == {k: row[k] for k in ("path", "bytes", "sha256")}
old_sentence = b"The five-role\nJSON payload supplement remains PROPOSED under separate independent review."
new_sentence = b"The five-role\nJSON payload supplement remains PROPOSED pending explicit Root adoption and\ncorrection of its source-location evidence."
current_docs = []
log_delta = None
for old in initial["pending_docs"]:
    path = Path(old["path"])
    now = pin(path)
    if path.name == "v1.8.0-implementation-log.md":
        raw = path.read_bytes()
        assert raw.count(new_sentence) == 1
        restored = raw.replace(new_sentence, old_sentence, 1)
        assert len(restored) == old["bytes"] and hashlib.sha256(restored).hexdigest() == old["sha256"]
        log_delta = {"initial": old, "current": now, "only_change": {"old": old_sentence.decode(), "new": new_sentence.decode()}, "initial_bytes_reconstructed_exact": True}
    else:
        assert now == old
    current_docs.append(now)
argv = ["git", "rev-parse", "HEAD"]
child = subprocess.run(argv, cwd=ROOT, capture_output=True)
assert child.returncode == 0 and child.stdout.decode().strip() == COMMIT and not child.stderr
diff_argv = ["git", "diff", "--no-ext-diff", "--", "docs/status/CURRENT_VERSION.md", "docs/status/COMPLETION-PLAN.md", "docs/work/v1.8.0-implementation-log.md"]
diff = subprocess.run(diff_argv, cwd=ROOT, capture_output=True)
assert diff.returncode == 0 and not diff.stderr
(HERE / "PENDING-DOC-DIFF-02.patch").write_bytes(diff.stdout)
contexts = []
for literal, expected in (("c18-analyzer-profile-amendment-review-20261005-d1a704/REVIEW-01.md", "8930e178480f7b651853747529e65aacdb3416ea37bf5a25930774488417b746"), ("c18-analyzer-profile-amendment-review-20261005-d1a704/INTERNAL-MANIFEST-01.json", "2597424b3b2a9eddc5731a876b9d4a8bd361ad6920a31c52ca794a5f993baebc"), ("c18-analyzer-profile-contract-portable-65af2b009e/FINAL-REPORT.md", "00a19d6056b65e2886eed069b2f89dcc27a95850f9121089191a53140483d878"), ("c18-analyzer-profile-contract-portable-65af2b009e/PACKAGED-PROFILE-CONTRACT-01.zip", "f338f8cbc8df705e85a9fa68a6ddc6d2c0f00903c9613fe6a4afcdd212f57243")):
    path = HERE.parent / literal
    row = pin(path)
    assert row["sha256"] == expected
    if path.suffix == ".md":
        path.read_text(encoding="utf-8")
    contexts.append(row)
result = {"fixed_head": COMMIT, "source_eight_postimages_unchanged": True, "root_initial_named_files_unchanged": len(initial["root_raw_files"]), "governance_unchanged": True, "current_doc_pins": current_docs, "intentional_log_delta": log_delta, "peripheral_context_only_locators": contexts, "peripheral_original_package_or_json_contract_not_reaudited": True, "git_reads": [{"argv": argv, "exit": child.returncode, "stdout": child.stdout.decode()}, {"argv": diff_argv, "exit": diff.returncode, "stdout_sha256": hashlib.sha256(diff.stdout).hexdigest()}]}
(HERE / "POSTCHECK-02.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"root_initial_files_unchanged": len(initial["root_raw_files"]), "source_postimages": 8, "docs_unchanged": 3, "log_changed_sentences": 1, "peripheral_locators": len(contexts)}))
