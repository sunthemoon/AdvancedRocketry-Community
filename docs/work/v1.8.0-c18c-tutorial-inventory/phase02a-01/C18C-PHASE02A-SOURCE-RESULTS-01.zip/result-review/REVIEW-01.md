# Phase02a committed results and pending-record review

Date: 2026-10-05. Independent result/record review, not a new source verdict or
native replay. Fixed source/Root HEAD: `254af9e4b7f2fe007eea87989e1534a238b140b7`.
The prior phase02a source review remains sealed and unchanged.

## Findings first

**No unresolved Critical, High, Medium or Low finding observed** in the exact
phase02a publication/results and four pending-document changes inspected here.
The records support committed, independently source-reviewed private quiescent
properties input and Root's 34 + 39 local Python checks. They do not support
live/ownership/native/driver, Java requalification, ledger completion or Gates.

Qualification: native cleanup shell exits 1/0 come from Root's actual tool
API observations, now explicitly transcribed **retrospectively**; they are not
separate contemporaneous captured child-exit receipts. Original emitted JSON,
precheck inventory, script/control-flow correction and currently absent root
independently support the narrower cleanup observation. No fictional raw exit
or stderr file is substituted.

## Fixed source/publication observations

Root raw input location:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02a-root-integration-20261005-01`.
[Named intake](READ-INPUTS-01.json) binds 71 individually read raw/text records,
including both cleanup scripts/failure/pass and the new retrospective note.
The exact record names, sizes and SHA-256 are preserved in that input ledger.

[Actual audit](AUDIT-RESULTS-01.json) and [readonly Git command ledger](READONLY-GIT-COMMANDS-01.json)
verify commit parent `bd66158d15f0f702b6c5804dab202dba3a78f6ec` and **exactly
four Add paths**, with no central/Java/generated/AGENTS change in this commit.
All four phase02a and four phase01 current bytes equal raw fixed Git and their
original source pin tables. The original Java cohort is not rebound or rerun.
The publisher's prior 3,039-input qualification remains its separately recorded
observation, not a new 3,039-file/native check by this reviewer.

All 19 publication child-command records have their literal raw stdout/stderr.
The staged list is exactly the four additions; four staged Git stdout blobs
equal the corresponding final committed bytes. Recorded commit/push/remote
identity is 254af9e4, final index output is empty. Publication's `git diff
--exit-code` is **1** (the preserved user-owned AGENTS difference), not a passed
Required Gate. This reviewer made no network call or independent remote query.
The publisher's status PASS/7.5357368-second record and recorded Git exits are
consistent with the narrow publication claim; no independent wall-time replay
is asserted.

## Actual fixed Python results and controls

`FIXED-PYTHON-CHECKS-01.json` identifies the actual Root script paths, `-B -v`,
fixed commit and cwd. `run_fixed01.py` checks all eight source postimages against
that commit before/after each child; its environment puts process temp/fixtures
on the owned D leaf. Actual raw stderr has matching unique summaries, individual
method lines and no failures/errors/skips:

| Actual Root cohort | Observed result |
| --- | --- |
| `scripts/test_classic_inventory_fixture_inputs.py` | child exit 0; 34 methods; 0FES; unit 0.125 s; recorded wall 0.2698276 s |
| `scripts/test_run_v180_classic_inventory_smoke.py` | child exit 0; 39 methods; 0FES; unit 0.020 s; recorded wall 0.1173056 s |

This is **73** actual Root methods, separate from the earlier independent
source review's 83 methods. No extra Root JUnit/Java, GameTest/native or 16/8
protocol-cohort result is invented at 254af9e4. Source/script-path qualification
is based on literal child argv, actual fixed bytes and standard Python script
import location; no class-load instrumentation is claimed.

The new [audit helper](audit01.py) executes six in-memory LF/CRLF/false-summary
controls, and independently parses the existing raw method/suite output. These
controls validate this review's forensic parser, not an unimplemented native
driver or blanket output-authentication guarantee. No sealed helper or real
file test suite was rerun and no new fixture root was created.

## Cleanup failure, correction and evidence strength

Original `cleanup_fixed01.ps1` and `ROOT-FIXTURE-CLEANUP-01.json` record
`LITERAL_ANCESTOR_TYPE_OR_REPARSE` / FAILURE / zero removed bytes. The captured
ancestor rows show the initial Get-Item object has PSIsContainer true, while
DirectoryInfo.Parent rows have that added property null despite native Directory
attributes and no reparse attributes. This explains the first helper's early
precheck refusal; it is not a tool-policy CreateProcess rejection.

The second helper differs **only** by using the native Directory attribute in
that ancestor test and changing 01 receipt/precheck names to 02. Literal target,
containment, alias handling, 512-entry/1-MiB inventory budgets and terminal-test
requirements remain unchanged. Its precheck contains six aliases inside the
same fresh root. Summing its ordinary-file lengths gives **99,375 B**, exactly
matching its PASS receipt; the root is independently observed absent now.
This is regular-file length accounting, not measured disk-space recovery.

`CLEANUP-EXIT-TOOL-OBSERVATIONS-03.md` SHA
`8e78e1630e32bd34d411f74718e60df25ee30ad91696ef37eab421fc2f84b087`
explicitly records its retrospective basis and actual commands. The original
logs contain the finally-emitted JSON, not process-exit/stderr captures. The
reported API shell exit 1/0 and elapsed values therefore remain **supplied Root
tool observations**, not this review's independently captured process returns.
No cleanup was rerun by this reviewer. Old C/D rejected targets, source worlds,
the author's separate 39,792-B failed replay cleanup and eleven C scripts were
not inspected/deleted/admitted here. The review's older null-byte cleanup is
not converted into a freed-byte claim.

## Pending documentation diff and deliberate drift

Reviewed Root-owned paths:

* `docs/status/CURRENT_VERSION.md`, phase02a paragraph at lines 108–118:
  latest Python commit updates to 254af9e4; runtime/Java commit remains a0873a30.
  Current 34 + 39 local cohort and quiescent-only remaining boundaries are clear.
* `docs/status/COMPLETION-PLAN.md`, phase02a lines 118–124: exact committed source
  and fixed local checks replace the obsolete assignment-only status. Remaining
  live/file-role/JSON/NBT/transport/Java/native work remains open.
* `docs/work/v1.8.0-implementation-log.md`, new top checkpoint: source 83 versus
  Root 73 results, failure/correction, old cleanup debts and Gate openness remain
  distinct. This historical log does not rewrite original failures.
* New `NATIVE-SOURCE-REVIEW-DISPOSITION-04-PHASE02A.md`, lines 6–30/39–65/67–81:
  exactly private source adoption, original review pins, actual local cohort and
  qualified cleanup, no caller-ownership/live/native/Gate authority.

The [initial diff](PENDING-DOC-DIFF-01.patch) and [initial pins](READ-INPUTS-01.json)
remain unchanged. Root then intentionally changed one peripheral JSON-status
sentence, including its line wrap. The [separate postcheck](POSTCHECK-02.json)
reconstructs the exact initial log bytes/hash from that one replacement and
verifies the other three documents unchanged. The [current diff](PENDING-DOC-DIFF-02.patch)
preserves the final pending postimage. These four documents are **not yet
committed**; no future documentation commit SHA is fabricated. All 203 original
local Markdown references resolve in their actual repository context.

| Final reviewed document | Bytes | SHA-256 |
| --- | ---: | --- |
| CURRENT_VERSION.md | 13,188 | `70d8e1ce7d9ab72a9179e0756ec870442658d3ac37bbf036a5c154656857b596` |
| COMPLETION-PLAN.md | 13,172 | `539325789f3410bd774088ca4b38ae517b9a594b8de128cd1d4f8023b9e56add` |
| implementation-log.md | 180,809 | `5988e65b57c70df0ff22aaab65a792f0509a4fff43105efd8effde6a3786cb68` |
| new source disposition | 4,621 | `30047b8e3731d06156417371ccd4bcfea06afe5180da776893ae412f0b9f1303` |

Normal packaged-profile amendment/collector statements are distinct task
context, not phase02a runtime results. Four supplied exact report/manifest/
archive locators are hash-pinned in the postcheck only; their whole packages,
libraries, JSON semantic contract and registration outcomes are **not** reaudited
here or copied. Final JSON sentence now explicitly remains PROPOSED pending
Root adoption/source-location correction. No packaged implementation permission
or assumed registry observation is inferred from that context.

## Actual commands, original reviewer failure and boundaries

* `python -B audit01.py`: actual exit 0; exact four Add/eight sources, 19 raw
  publisher commands, two actual 34/39 logs, six pure controls, cleanup inventory,
  203 local references. No host/test-suite replay.
* `python -B postcheck01.py`: exit 1, preserved original helper/stderr; a
  reviewer expected the new sentence without its actual newline after `and`.
  This is own input-comparison setup failure, not a source/Root result defect.
* `python -B postcheck02.py`: new corrected helper/run03, actual exit 0;
  same original 71 Root files/eight source pins/governance unchanged, three
  pending docs unchanged and exactly one intended log-sentence replacement.

The live authoritative AGENTS is readonly and separately pinned, not staged,
normalized or treated as the older WT bytes. All process TEMP/TMP/TMPDIR/output
is in this fresh D leaf; no C helper, fixture, ZIP/world/JAR export, Java,
Gradle/native, network, deletion or Git mutation ran. The original author
64/65 and source-review 53/54 manifest groups are verified byte-exact.

Root may consider publishing the four pending records under these exact pins.
This recommendation does not close C18c-01, the ledger, R-021 or G0-G9. A later
thin collection may carry exact source/author/reviewer/Root/result provenance;
duplicate Git stdout exclusions must retain explicit commit:path/SHA locators
and must not be advertised as a full publication-output/archive closure.
