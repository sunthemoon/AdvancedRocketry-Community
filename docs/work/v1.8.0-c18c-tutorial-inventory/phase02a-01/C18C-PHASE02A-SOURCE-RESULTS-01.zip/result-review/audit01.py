"""Readonly fixed-result and pending-record evidence audit, no old helpers run."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
RAW = HERE.parent / "c18c-phase02a-root-integration-20261005-01"
AUTHOR = HERE.parent / "c18c-inputs-author-20261005-1b8f40"
REVIEW = HERE.parent / "c18c-inputs-source-review-f24051fdb9"
COMMIT = "254af9e4b7f2fe007eea87989e1534a238b140b7"
DOCS = ["docs/status/CURRENT_VERSION.md", "docs/status/COMPLETION-PLAN.md", "docs/work/v1.8.0-implementation-log.md", "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-SOURCE-REVIEW-DISPOSITION-04-PHASE02A.md"]

def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}
def write(name, value): (HERE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
def verify_group(folder, manifest_name, sums_name):
    manifest = load(folder / manifest_name)
    rows = manifest["files"]
    for row in rows:
        rel = Path(row["path"])
        assert not rel.is_absolute() and ".." not in rel.parts
        actual = pin(folder / rel)
        assert actual["bytes"] == row["bytes"] and actual["sha256"] == row["sha256"]
    lines = (folder / sums_name).read_text(encoding="utf-8").splitlines()
    for line in lines:
        expected, relative = line.split("  ", 1)
        assert digest((folder / relative).read_bytes()) == expected
    return {"folder": str(folder), "payloads": len(rows), "bytes": sum(row["bytes"] for row in rows), "checksums": len(lines), "manifest": pin(folder / manifest_name), "sums": pin(folder / sums_name)}

commands = []
def git(arguments, allowed=(0,)):
    argv = ["git", *arguments]
    child = subprocess.run(argv, cwd=ROOT, capture_output=True)
    commands.append({"argv": argv, "cwd": str(ROOT), "exit": child.returncode, "stdout_bytes": len(child.stdout), "stdout_sha256": digest(child.stdout), "stderr_bytes": len(child.stderr), "stderr_sha256": digest(child.stderr)})
    assert child.returncode in allowed and not child.stderr, argv
    return child.stdout

assert git(["rev-parse", "HEAD"]).decode().strip() == COMMIT
author_group = verify_group(AUTHOR, "EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt")
review_group = verify_group(REVIEW, "EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt")
raw_files = [pin(path) for path in sorted(RAW.iterdir()) if path.is_file()]
assert all(Path(row["path"]).suffix.lower() not in (".jar", ".zip", ".class") for row in raw_files)
publication = load(RAW / "SOURCE-PUBLICATION-01.json")
assert publication["commit"] == publication["remote_commit"] == COMMIT
assert publication["status"] == "PASS" and publication["required_gates_passed"] is False
changed = git(["diff-tree", "--no-commit-id", "--name-status", "-r", COMMIT]).decode().splitlines()
expected_paths = sorted(publication["paths"])
assert sorted(changed) == ["A\t" + path for path in expected_paths]
parent = git(["rev-parse", COMMIT + "^"]).decode().strip()
assert parent == "bd66158d15f0f702b6c5804dab202dba3a78f6ec"

owned = load(RAW / "AUTHOR-INTAKE-01.json")["four_new_postimages"]
phase01 = load(HERE.parent / "c18c-native-phase01-integration-20261005-01/PACKET-INTAKE-01.json")["four_new_postimages"]
source_pins = []
for group in (owned, phase01):
    for relative, expected in group.items():
        current = (ROOT / relative).read_bytes()
        committed = git(["show", COMMIT + ":" + relative])
        assert current == committed and len(current) == expected["bytes"] and digest(current) == expected["sha256"]
        source_pins.append({"commit_locator": COMMIT + ":" + relative, "path": str(ROOT / relative), "bytes": len(current), "sha256": digest(current)})

publisher_commands = load(RAW / "SOURCE-PUBLICATION-COMMANDS-01.json")
assert len(publisher_commands) == 19
assert [row["exit"] for row in publisher_commands] == [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0]
for row in publisher_commands:
    assert (RAW / row["stdout"]).is_file() and (RAW / row["stderr"]).is_file()
assert (RAW / publisher_commands[15]["stdout"]).read_text().strip() == COMMIT
assert (RAW / publisher_commands[17]["stdout"]).read_text().split()[0] == COMMIT
assert (RAW / publisher_commands[18]["stdout"]).read_bytes() == b""
assert sorted((RAW / publisher_commands[7]["stdout"]).read_text().splitlines()) == expected_paths
for row in publisher_commands[8:12]:
    relative = row["argv"][-1][1:]
    assert (RAW / row["stdout"]).read_bytes() == (ROOT / relative).read_bytes()

def strict_summary(raw):
    text = raw.decode("utf-8", errors="strict")
    summaries = re.findall(r"^Ran (\d+) tests? in ([0-9.]+)s\r?$", text, re.MULTILINE)
    methods = re.findall(r"^test_.* \.\.\. (ok|FAIL|ERROR|skipped[^\r\n]*)\r?$", text, re.MULTILINE)
    ok_lines = re.findall(r"^OK\r?$", text, re.MULTILINE)
    if len(summaries) != 1 or len(ok_lines) != 1 or re.search(r"^FAILED\b", text, re.MULTILINE):
        raise ValueError("NONUNIQUE_OR_FAILED_SUMMARY")
    count = int(summaries[0][0])
    if len(methods) != count or any(status != "ok" for status in methods):
        raise ValueError("METHOD_SUMMARY_MISMATCH")
    return {"methods": count, "unit_seconds": float(summaries[0][1]), "failures": 0, "errors": 0, "skips": 0}

checks = load(RAW / "FIXED-PYTHON-CHECKS-01.json")
assert checks["fixed_code_commit"] == COMMIT and not checks["required_gates_passed"]
observed_suites = []
for job, count in zip(checks["jobs"], (34, 39), strict=True):
    assert job["exit"] == 0 and Path(job["cwd"]) == ROOT
    assert job["argv"][1] == "-B" and Path(job["argv"][2]).parent == ROOT / "scripts" and job["argv"][-1] == "-v"
    parsed = strict_summary((RAW / job["stdout"]).read_bytes() + (RAW / job["stderr"]).read_bytes())
    assert parsed["methods"] == count
    assert all(job[key] == value for key, value in parsed.items())
    observed_suites.append({"argv": job["argv"], "actual": parsed, "wall_seconds_recorded": job["seconds"], "stdout": pin(RAW / job["stdout"]), "stderr": pin(RAW / job["stderr"])})

# New in-memory controls only; no original runner/helper is executed.
positive = b"test_control (Control) ... ok\n\nRan 1 test in 0.001s\n\nOK\n"
models = []
for label, sample, accepted in (("LF", positive, True), ("CRLF", positive.replace(b"\n", b"\r\n"), True), ("FALSE_OK_WITH_FAILED", positive+b"FAILED (failures=1)\n", False), ("FALSE_COUNT", positive.replace(b"Ran 1", b"Ran 2"), False), ("FAIL_METHOD", positive.replace(b"... ok", b"... FAIL"), False), ("SECOND_SUMMARY", positive+positive, False)):
    try:
        parsed = strict_summary(sample)
        actual = True
    except ValueError:
        parsed = None
        actual = False
    assert actual == accepted
    models.append({"name": label, "accepted": actual, "raw_sha256": digest(sample), "parsed": parsed})

cleanup01 = load(RAW / "ROOT-FIXTURE-CLEANUP-01.json")
cleanup02 = load(RAW / "ROOT-FIXTURE-CLEANUP-02.json")
precheck = load(RAW / "ROOT-FIXTURE-PRECHECK-02.json")
assert cleanup01["status"] == "FAILURE" and cleanup01["removed_bytes"] == 0
assert cleanup01["failures"] == ["LITERAL_ANCESTOR_TYPE_OR_REPARSE"]
assert cleanup02["status"] == "PASS" and not cleanup02["failures"]
target = Path(cleanup02["target"])
assert target == Path(checks["fixture_root"]) and target.parent == RAW and not target.exists()
aliases = [row for row in precheck["entries"] if row["reparse"]]
regular = [row for row in precheck["entries"] if not row["reparse"] and not row["directory"]]
assert len(aliases) == cleanup02["removed_aliases"] == 6
assert sum(row["bytes"] for row in regular) == precheck["regular_bytes"] == cleanup02["removed_bytes"] == 99375
assert len(precheck["entries"]) <= 512 and precheck["regular_bytes"] <= 1048576
for row in precheck["entries"]:
    assert Path(row["path"]).is_relative_to(target) and Path(row["path"]) != target
for row in aliases:
    assert Path(row["target"]).is_relative_to(target)
one = (RAW / "cleanup_fixed01.ps1").read_text(encoding="utf-8")
two = (RAW / "cleanup_fixed02.ps1").read_text(encoding="utf-8")
translated = one.replace("CLEANUP-01.json", "CLEANUP-02.json").replace("PRECHECK-01.json", "PRECHECK-02.json").replace("-not $ancestor.PSIsContainer", "-not ($ancestor.Attributes -band [IO.FileAttributes]::Directory)")
assert translated == two
ancestor = load(RAW / "ancestor-observations-01.json")
assert ancestor[0]["ps_is_container"] is True and all(row["native_directory"] and not row["reparse"] for row in ancestor)
assert all(row["ps_is_container"] is None for row in ancestor[1:])

doc_pins = [pin(ROOT / name) for name in DOCS]
doc_diff = git(["diff", "--no-ext-diff", "--", *DOCS[:3]])
disposition = (ROOT / DOCS[3]).read_text(encoding="utf-8")
assert git(["ls-tree", "--name-only", COMMIT, "--", DOCS[3]]) == b""
(HERE / "PENDING-DOC-DIFF-01.patch").write_bytes(doc_diff)
(HERE / "PENDING-SOURCE-DISPOSITION-01.md").write_text(disposition, encoding="utf-8", newline="")
current = (ROOT / DOCS[0]).read_text(encoding="utf-8")
assert "tested_python_commit: " + COMMIT in current
assert "tested_code_commit: a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c" in current
new_checkpoint = (ROOT / DOCS[2]).read_text(encoding="utf-8").split("## ", 2)[1]
assert COMMIT in new_checkpoint and "99,375" in new_checkpoint and "null byte" in new_checkpoint
links = []
for relative in DOCS:
    path = ROOT / relative
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        link = match.group(1)
        if "://" in link or link.startswith("#"):
            continue
        literal = (path.parent / link.split("#", 1)[0]).resolve()
        assert "Development-Docs" not in str(literal)
        assert literal.exists(), str(literal)
        links.append({"from": relative, "link": link, "exists": True})

write("READ-INPUTS-01.json", {"root_raw_files": raw_files, "author_group": author_group, "review_group": review_group, "pending_docs": doc_pins, "source_postimages": source_pins, "governance": pin(ROOT / "AGENTS.md"), "phase01_manifest_locator": pin(HERE.parent / "c18c-native-phase01-integration-20261005-01/PACKET-INTAKE-01.json")})
write("AUDIT-RESULTS-01.json", {"fixed_commit": COMMIT, "parent": parent, "actual_commit_delta": changed, "publisher_commands": 19, "publisher_global_diff_exit": 1, "actual_suites": observed_suites, "new_pure_summary_controls": models, "cleanup": {"first_failure_before_delete": True, "second_fixture_absent": True, "aliases": 6, "regular_file_bytes": 99375, "regular_file_entries": len(regular), "source_correction_only": True, "external_exit_codes": "Root retrospective tool API observation, not a captured child-process exit receipt"}, "all_raw_input_drift": [], "pending_doc_local_links": len(links), "no_java_rebind_or_reexecution": True})
write("READONLY-GIT-COMMANDS-01.json", commands)
print(json.dumps({"commit_additions": 4, "raw_suites": [34,39], "new_pure_controls": len(models), "aliases": 6, "fixture_absent": True, "cleanup_bytes": 99375, "pending_doc_links": len(links)}))
