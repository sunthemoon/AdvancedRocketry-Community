"""Thin source/result collection; provenance-preserving exclusions are explicit."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

HERE = Path(__file__).parent
PARENT = HERE.parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
COMMIT = "254af9e4b7f2fe007eea87989e1534a238b140b7"
AUTHOR = PARENT / "c18c-inputs-author-20261005-1b8f40"
SOURCE_REVIEW = PARENT / "c18c-inputs-source-review-f24051fdb9"
RESULT_REVIEW = PARENT / "c18c-phase02a-result-review-78a060f4cf"
RAW = PARENT / "c18c-phase02a-root-integration-20261005-01"
TREE = HERE / "packet"
TREE.mkdir(exist_ok=False)
origins = []
copied = []
exclusions = []
external = []
git_reads = []

def sha(raw): return hashlib.sha256(raw).hexdigest()
def js(path): return json.loads(path.read_text(encoding="utf-8"))
def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}
def write(relative, value):
    path = TREE / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+"\n", encoding="utf-8")
def git(args):
    child = subprocess.run(["git", *args], cwd=ROOT, capture_output=True)
    git_reads.append({"argv": ["git", *args], "exit": child.returncode, "stdout_sha256": sha(child.stdout), "stdout_bytes": len(child.stdout), "stderr_bytes": len(child.stderr)})
    assert child.returncode == 0 and not child.stderr
    return child.stdout
def copy(prefix, source, relative, expected=None):
    raw = source.read_bytes()
    row = {"path": str(source), "bytes": len(raw), "sha256": sha(raw)}
    if expected:
        assert row["bytes"] == expected["bytes"] and row["sha256"] == expected["sha256"]
    destination = prefix + "/" + relative
    path = TREE / destination
    assert not path.exists() and ".." not in Path(destination).parts and not Path(destination).is_absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    copied.append({"member": destination, "origin": row})
    origins.append(row)

assert git(["rev-parse", "HEAD"]).decode().strip() == COMMIT
for prefix, folder in (("author", AUTHOR), ("source-review", SOURCE_REVIEW), ("result-review", RESULT_REVIEW)):
    manifest = js(folder / "EVIDENCE-MANIFEST-01.json")
    for row in manifest["files"]:
        copy(prefix, folder / row["path"], row["path"], row)
    copy(prefix, folder / "EVIDENCE-MANIFEST-01.json", "EVIDENCE-MANIFEST-01.json")
    copy(prefix, folder / "SHA256SUMS-01.txt", "SHA256SUMS-01.txt")
    for line in (folder / "SHA256SUMS-01.txt").read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        assert sha((TREE / prefix / relative).read_bytes()) == expected

initial = js(RESULT_REVIEW / "READ-INPUTS-01.json")
commands = js(RAW / "SOURCE-PUBLICATION-COMMANDS-01.json")
excluded_stdout = {row["stdout"]: row["argv"][-1][1:] for row in commands[8:12]}
assert len(excluded_stdout) == 4
for row in initial["root_raw_files"]:
    source = Path(row["path"])
    raw = source.read_bytes()
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    if source.name in excluded_stdout:
        relative = excluded_stdout[source.name]
        committed = git(["show", COMMIT + ":" + relative])
        bundled = TREE / "author/postimages" / relative
        assert raw == committed == bundled.read_bytes()
        origins.append(row)
        exclusions.append({"omitted_member": "root-fixed/" + source.name, "origin": row, "reason": "duplicate exact committed source stdout; not a raw publication-output closure claim", "commit_locator": COMMIT + ":" + relative, "identical_bundled_member": "author/postimages/" + relative})
    else:
        copy("root-fixed", source, source.name, row)

# Reconstruct only the three pending document postimages in memory from fixed
# Git plus the already captured diff; do not export the implementation log/tree.
last = js(RESULT_REVIEW / "POSTCHECK-02.json")
diff = (RESULT_REVIEW / "PENDING-DOC-DIFF-02.patch").read_text(encoding="utf-8")
document_controls = []
for block in re.split(r"(?m)^diff --git ", diff)[1:]:
    lines = block.splitlines(keepends=True)
    pair = lines[0].strip().split(" ")
    assert len(pair) == 2 and pair[0][2:] == pair[1][2:]
    relative = pair[1][2:]
    original = git(["show", COMMIT + ":" + relative])
    before = original.decode("utf-8").splitlines(keepends=True)
    after = []
    cursor = 0
    index = next(i for i, line in enumerate(lines) if line.startswith("@@ "))
    while index < len(lines):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        assert match
        start = int(match[1]) - 1
        assert start >= cursor
        after.extend(before[cursor:start])
        cursor = start
        index += 1
        consumed = emitted = 0
        while index < len(lines) and not lines[index].startswith("@@ "):
            line = lines[index]
            assert line[:1] in (" ", "+", "-")
            if line[:1] in (" ", "-"):
                assert before[cursor] == line[1:]
                cursor += 1
                consumed += 1
            if line[:1] in (" ", "+"):
                after.append(line[1:])
                emitted += 1
            index += 1
        assert consumed == int(match[2] or 1) and emitted == int(match[4] or 1)
    after.extend(before[cursor:])
    reconstructed = "".join(after).encode("utf-8")
    current = (ROOT / relative).read_bytes()
    expected = next(row for row in last["current_doc_pins"] if Path(row["path"]) == ROOT / relative)
    assert reconstructed == current and len(current) == expected["bytes"] and sha(current) == expected["sha256"]
    document_controls.append({"base_locator": COMMIT+":"+relative, "base_bytes": len(original), "base_sha256": sha(original), "pending_postimage_bytes": len(current), "pending_postimage_sha256": sha(current), "pure_patch_reconstructed_exact": True})
assert len(document_controls) == 3
for row in last["current_doc_pins"]:
    assert pin(Path(row["path"])) == row
disposition = next(row for row in last["current_doc_pins"] if Path(row["path"]).name.startswith("NATIVE-SOURCE"))
assert (TREE / "result-review/PENDING-SOURCE-DISPOSITION-01.md").read_bytes() == Path(disposition["path"]).read_bytes()

# A limited packet intentionally does not recursively duplicate earlier contract
# ZIPs, whole Source27, peripheral packaged/JSON tasks or future doc publication.
external.append({"from_member": "source-review/selected-context/NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md", "relative_link": "file-input-contract01/FILE-INPUT-CONTRACT-CHECKS-01.zip", "commit_locator": "b6299c86f7bcb99b00b89b4dd38479e035321954:docs/work/v1.8.0-c18c-tutorial-inventory/file-input-contract01/FILE-INPUT-CONTRACT-CHECKS-01.zip", "bytes": 92015, "sha256": "0a8c3299c5d16064ded9b97ea892f78f9196f2d07cadd9bcd464ca35919616a7", "qualification": "same external companion qualified in sealed source review; ZIP not duplicated"})
external.append({"from_member": "result-review/PENDING-SOURCE-DISPOSITION-01.md", "relative_link": "NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md", "identical_bundled_member": "source-review/selected-context/NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md", "qualification": "snapshot retains original repository-relative context"})
external.append({"unbundled_context": "publisher historical Source27 manifest/Java/artifacts and earlier phase01 metadata; peripheral packaged/JSON reports; future four-doc commit", "qualification": "precise read locators in sealed audit metadata, not recursively copied/requalified; no full publisher-input/runtime/publication closure"})
write("ORIGINS-01.json", copied)
write("EXCLUSIONS-01.json", exclusions)
write("EXTERNAL-COMPANIONS-01.json", external)
write("DOCUMENT-CONTROLS-01.json", document_controls)
write("READONLY-GIT-COMMANDS-01.json", git_reads)

link_controls = []
for path in sorted(TREE.rglob("*.md")):
    member = path.relative_to(TREE).as_posix()
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        link = match.group(1)
        if "://" in link or link.startswith("#"):
            continue
        target = path.parent / link.split("#", 1)[0]
        exists = target.exists()
        if not exists:
            assert any(row.get("from_member") == member and row.get("relative_link") == link for row in external), (member, link)
        link_controls.append({"from_member": member, "link": link, "physical_exists": exists, "explicit_external_or_context_locator": not exists})
for row in origins:
    assert pin(Path(row["path"])) == row
write("COLLECTION-CONTROLS-01.json", {"original_files_reverified": len(origins), "original_drift": 0, "copied_original_files": len(copied), "duplicate_stdout_exclusions": len(exclusions), "markdown_links": link_controls, "unknown_missing_companions": 0, "physical_external_companion_links": sum(not row["physical_exists"] for row in link_controls), "three_pending_doc_models_exact": True, "no_future_commit_identity": True, "no_host_or_full_publication_closure": True})
report = """# Phase02a thin source/results collection

Fixed source commit: `254af9e4b7f2fe007eea87989e1534a238b140b7`.
This is a limited portable evidence collection, not source/native/Gate admission.

* [Author](author/REPORT-01.md): all 64 original payloads + original manifest/sums.
* [Independent source review](source-review/REVIEW-01.md): all 53 payloads + manifest/sums.
* [Independent committed-result/pending-record review](result-review/REVIEW-01.md): all 23 payloads + manifest/sums.
* Root exact fixed records: 71 named inputs; four duplicate Git stdout bodies omitted.
  [Exclusions](EXCLUSIONS-01.json) preserve exact SHA/size/origin plus immutable
  commit:path and identical bundled author postimage; this is **not a full raw
  publication-output closure**.

[Origins](ORIGINS-01.json) preserve each included source path and byte identity.
[Collection controls](COLLECTION-CONTROLS-01.json) verify original groups unchanged,
all copied bytes and every declared local/external companion. No prior ZIP,
JAR/class/library/world/runtime/full-source tree is duplicated. The author's
original syntax/31-method red, original field observations, replay cleanup policy
rejection and source-review null-byte accounting remain unchanged. Root cleanup
01 FAILURE and 02 PASS stay separate; retrospective API exits are explicitly
qualified, not forged child-exit receipts. Reviewer postcheck line-wrap failure
and corrected helper are both retained.

[Pending document reconstruction](DOCUMENT-CONTROLS-01.json) applies only the
captured three-document diff in memory to fixed Git, with exact final postimages.
The new fourth disposition is captured separately. These are reviewed pending
records, not a future documentation commit; no fake SHA or publication receipt
is appended. [External companions](EXTERNAL-COMPANIONS-01.json) explicitly bound
historical contract ZIP/context that is not materialized at the old relative
path. It is not a recursive prior-package/publisher-input/runtime closure.

No Java/native/test-suite rerun, repository/Git change, deletion or host action
was executed during collection. All output is a fresh project-parent D leaf.
"""
(TREE / "FINAL-REPORT-01.md").write_text(report, encoding="utf-8", newline="\n")
collector_helper = TREE / "collector/collect01.py"
collector_helper.parent.mkdir(parents=True, exist_ok=True)
collector_helper.write_bytes((HERE / "collect01.py").read_bytes())
files = []
for path in sorted(TREE.rglob("*")):
    if path.is_file():
        raw = path.read_bytes()
        relative = path.relative_to(TREE).as_posix()
        assert not relative.startswith("/") and ".." not in Path(relative).parts
        assert path.suffix.lower() not in (".jar", ".zip", ".class")
        files.append({"path": relative, "bytes": len(raw), "sha256": sha(raw)})
write("EVIDENCE-MANIFEST-01.json", {"schema": 1, "files": files, "payload_count": len(files), "payload_bytes": sum(row["bytes"] for row in files), "limited_not_full_publication_closure": True})
manifest_raw = (TREE / "EVIDENCE-MANIFEST-01.json").read_bytes()
with (TREE / "SHA256SUMS-01.txt").open("w", encoding="utf-8", newline="\n") as stream:
    for row in files + [{"path": "EVIDENCE-MANIFEST-01.json", "bytes": len(manifest_raw), "sha256": sha(manifest_raw)}]:
        stream.write(row["sha256"]+"  "+row["path"]+"\n")
archive = HERE / "C18C-PHASE02A-SOURCE-RESULTS-01.zip"
assert not archive.exists()
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path in sorted(TREE.rglob("*")):
        if path.is_file():
            relative = path.relative_to(TREE).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2026,10,5,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(set(zipped.namelist())) == len(files) + 2
    for row in files:
        raw = zipped.read(row["path"])
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    for line in zipped.read("SHA256SUMS-01.txt").decode().splitlines():
        expected, relative = line.split("  ", 1)
        assert sha(zipped.read(relative)) == expected
for row in origins:
    assert pin(Path(row["path"])) == row
archive_pin = pin(archive)
sidecar = HERE / (archive.name + ".sha256")
sidecar.write_text(archive_pin["sha256"]+"  "+archive.name+"\n", encoding="ascii")
result = {"archive": archive_pin, "archive_members": len(files)+2, "payloads": len(files), "payload_bytes": sum(row["bytes"] for row in files), "manifest": pin(TREE / "EVIDENCE-MANIFEST-01.json"), "sums": pin(TREE / "SHA256SUMS-01.txt"), "sidecar": pin(sidecar), "crc_failures": 0, "sha_failures": 0, "originals_reverified": len(origins), "original_drift": 0, "excluded_root_stdout": len(exclusions), "unbundled_companion_links_qualified": sum(not row["physical_exists"] for row in link_controls), "not_full_publication_input_or_runtime_closure": True}
(HERE / "COLLECTION-RESULT-01.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps(result, indent=2))
