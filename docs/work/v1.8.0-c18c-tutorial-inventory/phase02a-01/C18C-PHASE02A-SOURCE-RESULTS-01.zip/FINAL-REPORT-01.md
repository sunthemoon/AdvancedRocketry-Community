# Phase02a thin source/results collection

Fixed source commit: `254af9e4b7f2fe007eea87989e1534a238b140b7`.
This is a limited portable evidence collection, not source/native/Gate admission.

* [Author](author/REPORT-01.md): all 64 original payloads + original manifest/sums.
* [Independent source review](source-review/REVIEW-01.md): all 53 payloads + manifest/sums.
* [Independent committed-result/pending-record review](result-review/REVIEW-01.md): all 23 payloads + manifest/sums.
* Root exact fixed records: 71 named inputs; four duplicate Git stdout bodies omitted.
  [Exclusions](EXCLUSIONS-01.json) preserve exact SHA/size/origin plus immutable
  commit:path and identical bundled author postimage; this is **not a full raw
  publication-output closure**.

[Origins](ORIGINS-01.json) preserve each included source path and byte identity.
[Collection controls](COLLECTION-CONTROLS-01.json) verify original groups unchanged,
all copied bytes and every declared local/external companion. No prior ZIP,
JAR/class/library/world/runtime/full-source tree is duplicated. The author's
original syntax/31-method red, original field observations, replay cleanup policy
rejection and source-review null-byte accounting remain unchanged. Root cleanup
01 FAILURE and 02 PASS stay separate; retrospective API exits are explicitly
qualified, not forged child-exit receipts. Reviewer postcheck line-wrap failure
and corrected helper are both retained.

[Pending document reconstruction](DOCUMENT-CONTROLS-01.json) applies only the
captured three-document diff in memory to fixed Git, with exact final postimages.
The new fourth disposition is captured separately. These are reviewed pending
records, not a future documentation commit; no fake SHA or publication receipt
is appended. [External companions](EXTERNAL-COMPANIONS-01.json) explicitly bound
historical contract ZIP/context that is not materialized at the old relative
path. It is not a recursive prior-package/publisher-input/runtime closure.

No Java/native/test-suite rerun, repository/Git change, deletion or host action
was executed during collection. All output is a fresh project-parent D leaf.
