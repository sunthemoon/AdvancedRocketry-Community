# Retrospective Root cleanup command observations

This record transcribes Root's actually observed exec_command API results.
It is retrospective, not a contemporaneous native process-exit receipt or an
independent replay. The original log files contain only the helper's emitted
result JSON; no separate raw OS exit/stderr file was captured by those commands.
The original scripts, logs, result and precheck records remain unchanged.

First actually executed PowerShell command:

```powershell
& 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02a-root-integration-20261005-01/cleanup_fixed01.ps1' *> 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02a-root-integration-20261005-01/cleanup-fixed-01.log'; $rc=$LASTEXITCODE; Get-Content -LiteralPath 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02a-root-integration-20261005-01/cleanup-fixed-01.log'; if($rc){exit $rc}
```

The API reports shell exit 1, elapsed 0.3175282 seconds. Emitted result is
FAILURE / removed_bytes 0 / LITERAL_ANCESTOR_TYPE_OR_REPARSE. This is an executed
precheck refusal, not a CreateProcess tool-policy refusal.

Second actually executed command is identical except `cleanup_fixed02.ps1`
and `cleanup-fixed-02.log`. The API reports shell exit 0, elapsed 0.6957416
seconds. Emitted result is PASS / removed_bytes 99375 / removed_aliases 6.
These are supplied Root tool observations, not independently captured child
process return codes. The result/precheck and checked absent root support the
limited deletion observation separately. No older rejected C/D target was
involved or retried, and these observations do not establish native-server or
version-Gate success.
