# Read-only locator observations

Root's exploratory reads guessed a historical server helper filename and the
packaged review manifest without its numbered suffix. Both paths were absent.
Root subsequently inspected the actual helper and enumerated the named review
directory to locate the actual manifest. These were read-only failures, not
source checks or successful native observations.

The author handoff names `SHA256SUMS-01.txt`; Root first requested
`SHA256SUMS.txt`, which was absent. The following handoff read supplied the actual
filename, and a separate literal read succeeded. The independent reviewer was
sent the corrected filename before its source intake. Combined shells continued
to other successful reads, so their final 0 does not make the absent-path reads
pass. Original diagnostics exist in the tool transcript; no raw stderr file is
invented. The dedicated intake uses the actual metadata filenames and preserves
its own command log/result separately. No source import, cleanup or Java occurs.
