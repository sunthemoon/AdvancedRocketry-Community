"""Publish four independently reviewed exact additions, not native delivery."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = 'bd66158d15f0f702b6c5804dab202dba3a78f6ec'
BRANCH = 'codex/v1.8.0-classic-content'
owned = json.loads((OUT / 'AUTHOR-INTAKE-01.json').read_bytes())['four_new_postimages']
PATHS = sorted(owned)
java = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01/SOURCE27-MANIFEST-01.json').read_bytes())
phase01 = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-integration-20261005-01/PACKET-INTAKE-01.json').read_bytes())['four_new_postimages']
owner = (ROOT / 'AGENTS.md').read_bytes()
commands = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(argv, allowed=(0,)):
    start = time.monotonic()
    child = subprocess.run(argv, cwd=ROOT, capture_output=True)
    stem = 'source-pub-command-%02d' % (len(commands) + 1)
    (OUT / (stem + '.stdout')).write_bytes(child.stdout)
    (OUT / (stem + '.stderr')).write_bytes(child.stderr)
    commands.append({'argv': argv, 'exit': child.returncode, 'seconds': time.monotonic() - start,
                     'stdout': stem + '.stdout', 'stderr': stem + '.stderr'})
    (OUT / 'SOURCE-PUBLICATION-COMMANDS-01.json').write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8')
    assert child.returncode in allowed, (stem, child.returncode)
    return child.stdout

def source_check():
    for group in (java, phase01, owned):
        for path, row in group.items():
            data = (ROOT / path).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256'], path

start = time.monotonic()
result = {'paths': PATHS, 'scope': 'four reviewed private quiescent-input additions only',
          'required_gates_passed': False, 'fixed_root_tests_pending': True}
try:
    assert len(PATHS) == 4 and len(set(PATHS)) == 4
    assert json.loads((OUT / 'REVIEW-INTAKE-01.json').read_bytes())['review_payloads'] == 53
    assert run(['git', 'rev-parse', 'HEAD']).decode().strip() == BASE
    assert not run(['git', 'diff', '--cached', '--name-only'])
    assert run(['git', 'diff', '--name-only']).decode().splitlines() == ['AGENTS.md']
    source_check()
    assert sha(owner) == '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
    images = {path: (ROOT / path).read_bytes() for path in PATHS}
    for path, data in images.items():
        assert len(data) < 50_000_000 and b'\r' not in data
        if path.endswith('.py'):
            ast.parse(data.decode('utf-8'), filename=path)
    run(['python', '-B', 'scripts/validate_v1plus_planning.py'])
    run(['git', 'diff', '--check'])
    run(['git', 'diff', '--exit-code'], allowed=(1,))
    run(['git', 'add', '--'] + PATHS)
    assert sorted(run(['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == PATHS
    for path, data in images.items():
        assert run(['git', 'show', ':' + path]) == data, path
    run(['git', 'diff', '--cached', '--stat'])
    run(['git', 'diff', '--cached', '--check'])
    run(['git', 'commit', '-m', 'test(inventory): add bounded quiescent property file inputs'])
    head = run(['git', 'rev-parse', 'HEAD']).decode().strip()
    run(['git', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH])
    remote = run(['git', 'ls-remote', 'origin', 'refs/heads/' + BRANCH]).decode().split()[0]
    assert remote == head and not run(['git', 'diff', '--cached', '--name-only'])
    source_check()
    assert (ROOT / 'AGENTS.md').read_bytes() == owner
    result.update(status='PASS', commit=head, remote_commit=remote,
                  java_named_inputs_unchanged=len(java), phase01_postimages_unchanged=len(phase01),
                  new_postimages_exact=len(owned))
finally:
    result['seconds'] = time.monotonic() - start
    (OUT / 'SOURCE-PUBLICATION-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))
