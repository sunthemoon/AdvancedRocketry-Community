# Root fresh-fixture cleanup precheck correction

The first native cleanup attempt starts and returns exit 1 before any deletion.
Its literal ancestor test uses PSIsContainer, a PowerShell-added property present
on the initial Get-Item object but absent on raw DirectoryInfo.Parent objects.
The actual ancestor observation shows ordinary directories with that property
null, Directory attribute set, and no reparse attribute. This is a Root helper
precheck defect, not a source-test failure or a tool-policy deletion rejection.
The original script, log and FAILURE receipt remain unchanged, with zero deleted
bytes. No earlier rejected C/D target is involved.

The separate second helper changes only this check to the actual Directory
attribute and uses new numbered result/precheck files. Target, ownership,
containment, reparse, alias, bounds and terminal-test requirements remain.
It makes no source/world change or budget exemption. Its actual result is
recorded separately; this note does not itself assert cleanup success.
