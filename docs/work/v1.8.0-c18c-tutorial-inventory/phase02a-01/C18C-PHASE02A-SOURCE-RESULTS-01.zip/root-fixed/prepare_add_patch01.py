"""Prepare four exact manual additions outside Root; does not apply them."""
import hashlib
import json
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
WT = Path('D:/GitHub/arce-v180-c18c-inputs-20261005')
OUT = Path(__file__).resolve().parent
pins = json.loads((OUT / 'AUTHOR-INTAKE-01.json').read_bytes())['four_new_postimages']
parts = ['*** Begin Patch']
for path, row in pins.items():
    data = (WT / path).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], path
    assert data.endswith(b'\n') and b'\r' not in data
    assert not (ROOT / path).exists(), path
    parts.append('*** Add File: ' + (ROOT / path).as_posix())
    parts.extend('+' + line for line in data.decode('utf-8').split('\n')[:-1])
parts.append('*** End Patch')
patch = ('\n'.join(parts) + '\n').encode('utf-8')
target = OUT / 'ROOT-ADD-PATCH-01.txt'
assert not target.exists()
target.write_bytes(patch)
print(json.dumps({'prepared_only': True, 'paths': list(pins), 'bytes': len(patch),
                  'sha256': hashlib.sha256(patch).hexdigest()}))
