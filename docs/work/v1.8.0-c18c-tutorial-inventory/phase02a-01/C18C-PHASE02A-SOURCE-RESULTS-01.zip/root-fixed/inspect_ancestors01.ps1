$ErrorActionPreference = 'Stop'
$path = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\c18c-phase02a-root-integration-20261005-01\root-fixed-fixtures-01'
$ancestor = Get-Item -LiteralPath $path -Force
$rows = @()
while ($null -ne $ancestor) {
    $rows += [ordered]@{ path=$ancestor.FullName; dotnet_type=$ancestor.GetType().FullName;
        ps_is_container=$ancestor.PSIsContainer; attributes=[long]$ancestor.Attributes;
        native_directory=[bool]($ancestor.Attributes -band [IO.FileAttributes]::Directory);
        reparse=[bool]($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) }
    $ancestor = $ancestor.Parent
}
$rows | ConvertTo-Json -Depth 6
