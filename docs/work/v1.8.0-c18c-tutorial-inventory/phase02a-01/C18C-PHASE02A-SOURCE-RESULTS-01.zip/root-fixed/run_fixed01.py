"""Run two exact committed private-tool suites, never Java/native."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
PINS = json.loads((OUT / 'AUTHOR-INTAKE-01.json').read_bytes())['four_new_postimages']
PHASE01 = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-integration-20261005-01/PACKET-INTAKE-01.json').read_bytes())['four_new_postimages']
FIXTURE = OUT / 'root-fixed-fixtures-01'

def source_check(commit):
    for group in (PINS, PHASE01):
        for path, row in group.items():
            data = (ROOT / path).read_bytes()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], path
            assert subprocess.check_output(['git', 'show', commit + ':' + path], cwd=ROOT) == data, path

def summary(data):
    text = data.decode('utf-8', errors='strict')
    matches = re.findall(r'(?m)^Ran ([0-9]+) tests? in ([0-9.]+)s\r?$', text)
    assert len(matches) == 1, matches
    assert re.search(r'(?m)^OK\r?$', text), text[-2048:]
    assert 'skipped=' not in text
    return {'methods': int(matches[0][0]), 'unit_seconds': float(matches[0][1]),
            'failures': 0, 'errors': 0, 'skips': 0}

assert len(sys.argv) == 2
commit = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', commit)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == commit
assert not FIXTURE.exists()
source_check(commit)
environment = dict(os.environ)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    environment[key] = str(OUT)
environment.update(PYTHONPATH=str(ROOT / 'scripts'), PYTHONDONTWRITEBYTECODE='1',
                   PYTHONUTF8='1', PYTHONIOENCODING='utf-8', ARCE_C18C_INPUT_TEST_ROOT=str(FIXTURE))
jobs = [('focused-fixed-01', 'scripts/test_classic_inventory_fixture_inputs.py', 34),
        ('phase01-fixed-01', 'scripts/test_run_v180_classic_inventory_smoke.py', 39)]
rows = []
try:
    for stem, path, expected in jobs:
        argv = [sys.executable, '-B', str(ROOT / path), '-v']
        start = time.monotonic()
        try:
            child = subprocess.run(argv, cwd=ROOT, env=environment, capture_output=True, timeout=30)
        except subprocess.TimeoutExpired as error:
            (OUT / (stem + '.timeout.stdout')).write_bytes(error.output or b'')
            (OUT / (stem + '.timeout.stderr')).write_bytes(error.stderr or b'')
            rows.append({'argv': argv, 'cwd': str(ROOT), 'exit': None, 'timed_out': True,
                         'seconds': time.monotonic() - start,
                         'stdout': stem + '.timeout.stdout', 'stderr': stem + '.timeout.stderr'})
            raise
        (OUT / (stem + '.stdout')).write_bytes(child.stdout)
        (OUT / (stem + '.stderr')).write_bytes(child.stderr)
        row = {'argv': argv, 'cwd': str(ROOT), 'exit': child.returncode,
               'seconds': time.monotonic() - start, 'stdout': stem + '.stdout',
               'stderr': stem + '.stderr'}
        rows.append(row)
        assert child.returncode == 0, row
        row.update(summary(child.stdout + child.stderr))
        assert row['methods'] == expected, row
        source_check(commit)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == commit
finally:
    result = {'fixed_code_commit': commit, 'scope': 'committed pure/local file tests only',
              'jobs': rows, 'fixture_root': str(FIXTURE), 'cleanup_performed_by_runner': False,
              'required_gates_passed': False}
    (OUT / 'FIXED-PYTHON-CHECKS-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))
