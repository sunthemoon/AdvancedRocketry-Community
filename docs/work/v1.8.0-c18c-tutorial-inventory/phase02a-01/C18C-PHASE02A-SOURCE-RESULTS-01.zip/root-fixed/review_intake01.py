"""Verify independent source-review metadata before exact Root additions."""
import hashlib
import json
from pathlib import Path

REVIEW = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-source-review-f24051fdb9')
OUT = Path(__file__).resolve().parent
pins = {'REVIEW-01.md': '695fdb1675deb3a4aecc813f29bab2c0fe1953c7abb32d09976d0f421ddbea9d',
        'EVIDENCE-MANIFEST-01.json': '5ae405285e797e346bc63ee4e92c2abd14324b8ca02cda1e3d234a34b265c964',
        'SHA256SUMS-01.txt': '80ecc89aef44bfd1d7808b6d7b4f2c5bf213e37cecb7379351984747e0243d59'}

def digest(name):
    relative = Path(name)
    assert not relative.is_absolute() and not relative.drive and '..' not in relative.parts
    path = REVIEW / relative
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(REVIEW.resolve())
    data = path.read_bytes()
    return len(data), hashlib.sha256(data).hexdigest()

for name, expected in pins.items():
    assert digest(name)[1] == expected, name
rows = json.loads((REVIEW / 'EVIDENCE-MANIFEST-01.json').read_bytes())['files']
assert len(rows) == 53 and len({row['path'] for row in rows}) == 53
for row in rows:
    assert digest(row['path']) == (row['bytes'], row['sha256']), row['path']
assert sum(row['bytes'] for row in rows) == 152166
sums = {}
for line in (REVIEW / 'SHA256SUMS-01.txt').read_text(encoding='utf-8').splitlines():
    expected, name = line.split('  ', 1)
    assert name not in sums and digest(name)[1] == expected, name
    sums[name] = expected
assert len(sums) == 54 and set(sums) == {row['path'] for row in rows} | {'EVIDENCE-MANIFEST-01.json'}
result = {'report_sha256': pins['REVIEW-01.md'], 'review_payloads': 53,
          'payload_bytes': 152166, 'checksum_entries': 54,
          'scope': 'independent exact-source recommendation; not native or Gate admission'}
(OUT / 'REVIEW-INTAKE-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
