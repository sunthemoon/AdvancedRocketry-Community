"""Read-only exact author packet intake; not independent source acceptance."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-author-20261005-1b8f40')
WT = Path('D:/GitHub/arce-v180-c18c-inputs-20261005')
OUT = Path(__file__).resolve().parent
NAMES = {'scripts/classic_inventory_fixture_inputs.py',
         'scripts/test_classic_inventory_fixture_inputs.py',
         'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md',
         'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def observed(path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

def named(name):
    relative = Path(name)
    assert not relative.is_absolute() and not relative.drive and '..' not in relative.parts
    candidate = AUTHOR / relative
    assert candidate.resolve().is_relative_to(AUTHOR.resolve()), name
    return candidate

manifest_path = AUTHOR / 'EVIDENCE-MANIFEST-01.json'
sums_path = AUTHOR / 'SHA256SUMS-01.txt'
assert observed(manifest_path)['sha256'] == '9f94cee5655c4a99cb4b4052c1144584aa36975215ab8d2cc217cd8d1598b978'
assert observed(sums_path)['sha256'] == '5cdef3ab932e46e03ca19a67f3d4b020915e5aca843c1dbfb160ae6c882a601b'
manifest = json.loads(manifest_path.read_bytes())
rows = manifest['files']
assert len(rows) == 64 and len({row['path'] for row in rows}) == 64
for row in rows:
    assert observed(named(row['path'])) == {'bytes': row['bytes'], 'sha256': row['sha256']}, row['path']
assert sum(row['bytes'] for row in rows) == 1_188_121
sums = {}
for line in sums_path.read_text(encoding='utf-8').splitlines():
    digest, name = line.split('  ', 1)
    assert name not in sums
    sums[name] = digest
    assert observed(named(name))['sha256'] == digest, name
assert len(sums) == 65 and set(sums) == {row['path'] for row in rows} | {'EVIDENCE-MANIFEST-01.json'}
source = json.loads((AUTHOR / 'SOURCE-MANIFEST-01.json').read_bytes())
assert source['fixed_base'] == 'b6299c86f7bcb99b00b89b4dd38479e035321954'
assert len(source['files']) == 4 and {row['path'] for row in source['files']} == NAMES
images = {}
for row in source['files']:
    path = row['path']
    expected = {'bytes': row['bytes'], 'sha256': row['sha256']}
    assert observed(WT / path) == expected and observed(AUTHOR / 'postimages' / path) == expected
    assert not (ROOT / path).exists(), path
    assert b'\r' not in (WT / path).read_bytes(), path
    images[path] = expected
assert observed(AUTHOR / source['patch']['path']) == {
    'bytes': 41574, 'sha256': 'fe4792d566f114bf2e42b44fbca074094475c5ff83f0669cdc92a808fef24393'}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == 'bd66158d15f0f702b6c5804dab202dba3a78f6ec'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT).decode().splitlines() == ['AGENTS.md']
result = {'scope': 'author packet read-only identities only; no source review/import or native admission',
          'payloads': 64, 'payload_bytes': 1_188_121, 'checksum_entries': 65,
          'four_new_postimages': images, 'source_patch': source['patch'],
          'root_tracked_diff': ['AGENTS.md'], 'required_gates_passed': False}
(OUT / 'AUTHOR-INTAKE-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
