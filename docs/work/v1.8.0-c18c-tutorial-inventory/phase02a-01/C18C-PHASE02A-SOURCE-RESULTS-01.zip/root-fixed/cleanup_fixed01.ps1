$ErrorActionPreference = 'Stop'
$out = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\c18c-phase02a-root-integration-20261005-01'
$fixture = $out + '\root-fixed-fixtures-01'
$resultPath = $out + '\ROOT-FIXTURE-CLEANUP-01.json'
$result = [ordered]@{ target = $fixture; status = 'PRECHECK'; removed_bytes = 0; failures = @() }
try {
    if (Test-Path -LiteralPath $resultPath) { throw 'CLEANUP_RECEIPT_ALREADY_EXISTS' }
    $checks = Get-Content -LiteralPath ($out + '\FIXED-PYTHON-CHECKS-01.json') -Raw | ConvertFrom-Json
    if ($checks.jobs.Count -ne 2 -or @($checks.jobs | Where-Object { $_.exit -ne 0 }).Count -ne 0) {
        throw 'TERMINAL_SUCCESSFUL_OWNED_TESTS_REQUIRED'
    }
    if ([IO.Path]::GetFullPath($checks.fixture_root) -cne $fixture) { throw 'OWNED_TARGET_MISMATCH' }
    $resolved = (Resolve-Path -LiteralPath $fixture).Path
    if ($resolved -cne $fixture -or -not $resolved.StartsWith($out + '\', [StringComparison]::Ordinal)) {
        throw 'TARGET_CONTAINMENT'
    }
    $ancestor = Get-Item -LiteralPath $fixture -Force
    while ($null -ne $ancestor) {
        if (-not $ancestor.PSIsContainer -or ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'LITERAL_ANCESTOR_TYPE_OR_REPARSE'
        }
        $ancestor = $ancestor.Parent
    }
    # Enumerate only ordinary directories; never descend into an alias.
    $entries = @()
    $stack = [Collections.Generic.Stack[string]]::new()
    $stack.Push($fixture)
    while ($stack.Count -gt 0) {
        foreach ($entry in @(Get-ChildItem -LiteralPath ($stack.Pop()) -Force)) {
            if ($entries.Count -ge 512) { throw 'FIXTURE_ENTRY_LIMIT' }
            if (-not $entry.FullName.StartsWith($fixture + '\', [StringComparison]::Ordinal)) {
                throw 'ENUMERATION_CONTAINMENT'
            }
            $entries += $entry
            if ($entry.PSIsContainer -and -not ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                $stack.Push($entry.FullName)
            }
        }
    }
    $aliases = @()
    $regularBytes = [long]0
    $inventory = @()
    foreach ($entry in $entries) {
        if (-not $entry.FullName.StartsWith($fixture + '\', [StringComparison]::Ordinal)) {
            throw 'ENTRY_CONTAINMENT'
        }
        $isAlias = [bool]($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)
        $record = [ordered]@{ path = $entry.FullName; directory = $entry.PSIsContainer; reparse = $isAlias }
        if ($isAlias) {
            $targets = @($entry.Target)
            if ($targets.Count -ne 1 -or [string]::IsNullOrEmpty($targets[0])) { throw 'ALIAS_TARGET_UNKNOWN' }
            $target = [IO.Path]::GetFullPath($targets[0])
            if (-not ($target.Equals($fixture, [StringComparison]::Ordinal) -or
                      $target.StartsWith($fixture + '\', [StringComparison]::Ordinal))) {
                throw 'ALIAS_TARGET_OUTSIDE_OWN_FIXTURE'
            }
            $record.target = $target
            $aliases += $entry
        } elseif (-not $entry.PSIsContainer) {
            $record.bytes = $entry.Length
            $record.sha256 = (Get-FileHash -LiteralPath $entry.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            $regularBytes += $entry.Length
        }
        $inventory += $record
    }
    if ($regularBytes -gt 1048576) { throw 'FIXTURE_BYTE_LIMIT' }
    [ordered]@{ target = $fixture; entries = $inventory; regular_bytes = $regularBytes } |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($out + '\ROOT-FIXTURE-PRECHECK-01.json') -Encoding utf8
    foreach ($alias in $aliases) {
        Remove-Item -LiteralPath $alias.FullName -Force -Confirm:$false
    }
    if (@(Get-ChildItem -LiteralPath $fixture -Recurse -Force |
            Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) {
        throw 'REPARSE_REMAINS'
    }
    Remove-Item -LiteralPath $fixture -Recurse -Force -Confirm:$false
    if (Test-Path -LiteralPath $fixture) { throw 'TARGET_STILL_EXISTS' }
    $result.status = 'PASS'
    $result.removed_bytes = $regularBytes
    $result.removed_aliases = $aliases.Count
} catch {
    $result.status = 'FAILURE'
    $result.failures = @($_.Exception.Message)
} finally {
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $resultPath -Encoding utf8
    $result | ConvertTo-Json -Depth 8
}
if ($result.status -ne 'PASS') { exit 1 }
