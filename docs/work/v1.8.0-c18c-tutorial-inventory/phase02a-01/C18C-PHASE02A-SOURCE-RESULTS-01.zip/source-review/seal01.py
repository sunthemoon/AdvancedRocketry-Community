"""Thin own-evidence sealer, not an archive or source export."""
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote

HERE = Path(__file__).parent
def pin(path):
    raw = path.read_bytes()
    return {"path": path.relative_to(HERE).as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

for name in ("fixtures-focused-01", "fixtures-independent-01", "process-temp"):
    assert not (HERE / name).exists(), name
assert json.loads((HERE / "FINAL-POSTCHECK-01.json").read_text(encoding="utf-8"))["original_drift"] == []
links = []
for md in (HERE / "REVIEW-01.md", HERE / "CLEANUP-ACCOUNTING-01.md"):
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", md.read_text(encoding="utf-8")):
        target = match.group(1)
        assert "://" not in target and not target.startswith("/")
        literal = (md.parent / unquote(target.split("#", 1)[0])).resolve()
        assert literal.is_relative_to(HERE.resolve()) and literal.is_file(), target
        links.append({"from": md.name, "target": target, "exists": True})
write(HERE / "SEAL-CONTROLS-01.json", {"report_local_links": links, "missing": 0, "fresh_fixture_roots_absent": True, "zip_created": False, "metadata_does_not_imply_native_or_owner_admission": True})
excluded = {"EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt", "SEAL-RESULT-01.json", "seal-01.log", "seal-01.stderr.txt", "seal-01.exit"}
files = []
for path in sorted(HERE.rglob("*")):
    if path.is_file() and path.name not in excluded:
        assert "__pycache__" not in path.parts and path.suffix.lower() not in (".zip", ".jar", ".class")
        files.append(pin(path))
manifest = {"schema": 1, "scope": "independent quiescent phase02a source/diff/replay review; no runtime/archive export", "files": files, "payload_count": len(files), "payload_bytes": sum(row["bytes"] for row in files), "excluded_standalone_seal_receipts": sorted(excluded - {"EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt"})}
write(HERE / "EVIDENCE-MANIFEST-01.json", manifest)
manifest_pin = pin(HERE / "EVIDENCE-MANIFEST-01.json")
with (HERE / "SHA256SUMS-01.txt").open("w", encoding="utf-8", newline="\n") as stream:
    for row in [*files, manifest_pin]:
        stream.write(row["sha256"] + "  " + row["path"] + "\n")
for row in files:
    assert pin(HERE / row["path"]) == row
for line in (HERE / "SHA256SUMS-01.txt").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    assert pin(HERE / relative)["sha256"] == expected
result = {"payloads": len(files), "payload_bytes": manifest["payload_bytes"], "checksum_entries": len(files) + 1, "all_checksum_mismatches": 0, "report_links": len(links), "report": pin(HERE / "REVIEW-01.md"), "manifest": manifest_pin, "sums": pin(HERE / "SHA256SUMS-01.txt"), "no_zip": True}
write(HERE / "SEAL-RESULT-01.json", result)
print(json.dumps(result, indent=2))
