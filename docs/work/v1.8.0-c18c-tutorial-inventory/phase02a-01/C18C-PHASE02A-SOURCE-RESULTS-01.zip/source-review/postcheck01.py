"""Final named input and original evidence qualification, no source writes."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

HERE = Path(__file__).parent
AUTHOR = HERE.parent / "c18c-inputs-author-20261005-1b8f40"
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
def read(path):
    return json.loads(path.read_text(encoding="utf-8"))
def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
def check(path, row):
    actual = pin(path)
    assert actual["bytes"] == row["bytes"] and actual["sha256"] == row["sha256"], str(path)
    return actual
intake = read(HERE / "INTAKE-PINS-01.json")
author = [check(Path(row["path"]), row) for row in intake["author"]]
governance = [check(Path(row["path"]), row) for row in intake["governance"]]
source = [check(Path(row["path"]), row) for row in intake["postimages"]]
baseline = read(AUTHOR / "BASELINE-SOURCE-01.json")
for row in baseline["files"]:
    assert "Development-Docs" not in row["path"]
    check(WT / row["path"], row)
commands = []
for args, expected in ((["rev-parse", "HEAD"], intake["base"]), (["diff", "--no-ext-diff", "--name-only"], "")):
    argv = ["git", *args]
    run = subprocess.run(argv, cwd=WT, capture_output=True)
    assert run.returncode == 0 and not run.stderr and run.stdout.decode().strip() == expected
    commands.append({"argv": argv, "cwd": str(WT), "exit": run.returncode, "stdout": run.stdout.decode(), "stderr": run.stderr.decode()})
helper = WT / "scripts/classic_inventory_fixture_inputs.py"
tree = ast.parse(helper.read_text(encoding="utf-8"))
calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
attrs = [n.func.attr for n in calls if isinstance(n.func, ast.Attribute)]
forbidden = {"write", "write_text", "write_bytes", "mkdir", "iterdir", "glob", "rglob", "walk", "read_bytes", "read_text", "decode", "Popen", "run", "unlink", "replace"}
assert not (set(attrs) & forbidden)
assert attrs.count("read") == 1
read_call = next(n for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == "read")
assert ast.unparse(read_call) == "stream.read(MAX_PROPERTIES_BYTES + 1)"
test_methods = [n.name for n in ast.walk(ast.parse((WT / "scripts/test_classic_inventory_fixture_inputs.py").read_text(encoding="utf-8"))) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")]
assert len(test_methods) == 34
links = []
for path in (AUTHOR / "REPORT-01.md", WT / "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md", WT / "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md"):
    text = path.read_text(encoding="utf-8")
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", text):
        target = match.group(1)
        if "://" in target or target.startswith("#"):
            continue
        literal = (path.parent / unquote(target.split("#", 1)[0])).resolve()
        assert literal.exists(), str(literal)
        links.append({"from": str(path), "target": target, "exists": True})
result = {"author_original_files": len(author), "original_drift": [], "baseline_named_inputs": len(baseline["files"]), "baseline_drift": [], "governance": governance, "four_source_postimages": source, "git_reads": commands, "read_call_line": read_call.lineno, "single_bounded_read_ast": ast.unparse(read_call), "forbidden_calls_absent": sorted(forbidden), "focused_method_count": len(test_methods), "original_report_companion_links": links, "not_whole_source_or_live_host_proof": True}
(HERE / "FINAL-POSTCHECK-01.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"original_files": len(author), "baseline": len(baseline["files"]), "governance": len(governance), "postimages": len(source), "links": len(links), "all_drift": 0}))
