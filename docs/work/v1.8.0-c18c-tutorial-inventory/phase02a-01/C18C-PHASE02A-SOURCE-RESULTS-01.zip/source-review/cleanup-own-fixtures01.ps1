$ErrorActionPreference = 'Stop'
$owner = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-source-review-f24051fdb9')
$roots = @(
    'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-source-review-f24051fdb9/fixtures-focused-01',
    'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-source-review-f24051fdb9/fixtures-independent-01',
    'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-source-review-f24051fdb9/process-temp'
)
$aliases = [Collections.Generic.List[object]]::new()
$files = [Collections.Generic.List[object]]::new()
$directories = [Collections.Generic.List[string]]::new()
foreach ($literal in $roots) {
    $absolute = [IO.Path]::GetFullPath($literal)
    if (-not $absolute.StartsWith($owner + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'OUTSIDE_OWN_REVIEW' }
    $resolved = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $literal).ProviderPath)
    if ($absolute -ne $resolved) { throw 'ROOT_REDIRECTION' }
    $rootItem = Get-Item -LiteralPath $literal -Force
    if (-not $rootItem.PSIsContainer -or ($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'UNEXPECTED_ROOT_TYPE' }
    $stack = [Collections.Generic.Stack[string]]::new()
    $stack.Push($absolute)
    while ($stack.Count -gt 0) {
        $current = $stack.Pop()
        $directories.Add($current)
        foreach ($item in @(Get-ChildItem -LiteralPath $current -Force)) {
            $path = [IO.Path]::GetFullPath($item.FullName)
            if (-not $path.StartsWith($absolute + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'OUTSIDE_FIXTURE' }
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                $aliases.Add([ordered]@{path=$path; attributes=[int]$item.Attributes; target=@($item.Target)})
            } elseif ($item.PSIsContainer) {
                $stack.Push($path)
            } else {
                $files.Add([ordered]@{path=$path; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()})
            }
            if ($files.Count + $directories.Count + $aliases.Count -gt 2048) { throw 'BOUNDED_OWN_CLEANUP_LIMIT' }
        }
    }
}
$bytes = ($files | Measure-Object -Property bytes -Sum).Sum
[ordered]@{owner=$owner; roots=$roots; aliases=@($aliases.ToArray()); regular_file_count=$files.Count; regular_file_bytes=$bytes; directories=$directories.Count; method='native single-shell literal containment; no reparse traversal; aliases removed without recursion before bounded directories'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $owner 'CLEANUP-PRECHECK-01.json') -Encoding UTF8
foreach ($alias in $aliases) {
    Remove-Item -LiteralPath $alias.path -Force -ErrorAction Stop
    if (Test-Path -LiteralPath $alias.path) { throw 'ALIAS_STILL_PRESENT' }
}
# All remaining inspected nodes were ordinary directories/files. Remove only the
# exact fresh roots checked above; reports and raw observations are siblings.
foreach ($literal in $roots) {
    $absolute = [IO.Path]::GetFullPath($literal)
    if (-not $absolute.StartsWith($owner + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'OUTSIDE_OWN_REVIEW' }
    Remove-Item -LiteralPath $literal -Recurse -Force -ErrorAction Stop
}
$after = @($roots | ForEach-Object { [ordered]@{path=$_; absent=(-not (Test-Path -LiteralPath $_))} })
[ordered]@{roots=$after; removed_aliases=$aliases.Count; regular_file_bytes=$bytes; failure=$null; untouched='all author/repository/sealed/old refused targets'; accounting='regular-file lengths, not physical filesystem allocation'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $owner 'CLEANUP-RESULT-01.json') -Encoding UTF8
Write-Output "Fresh own fixtures removed: $bytes regular-file bytes, $($aliases.Count) aliases"
