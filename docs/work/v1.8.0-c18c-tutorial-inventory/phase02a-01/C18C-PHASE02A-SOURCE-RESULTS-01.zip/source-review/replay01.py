"""Own-scope subprocess evidence collection; no sealed helper execution."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

OUT = Path(__file__).parent
WT = Path("D:/GitHub/arce-v180-c18c-inputs-20261005")
scripts = WT / "scripts"
temp = OUT / "process-temp"
temp.mkdir(exist_ok=True)
env = os.environ.copy()
env.update(TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(scripts), ARCE_C18C_INPUT_TEST_ROOT=str(OUT / "fixtures-focused-01"))
paths = [scripts / name for name in ("classic_inventory_fixture_inputs.py", "test_classic_inventory_fixture_inputs.py", "run_v180_classic_inventory_smoke.py", "test_run_v180_classic_inventory_smoke.py")]
def pins():
    return [{"path": str(p), "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
before = pins()
(OUT / "REPLAY-PRECHECK-01.json").write_text(json.dumps(before, indent=2) + "\n", encoding="utf-8")
results = []
for label, script in (("focused-01", scripts / "test_classic_inventory_fixture_inputs.py"), ("phase01-01", scripts / "test_run_v180_classic_inventory_smoke.py"), ("independent-01", OUT / "independent_controls.py")):
    argv = [sys.executable, "-B", str(script), "-v"]
    command = {"argv": argv, "cwd": str(OUT), "environment": {k: env[k] for k in ("TEMP", "TMP", "TMPDIR", "PYTHONPATH", "ARCE_C18C_INPUT_TEST_ROOT", "PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE")}, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_pins": before}
    (OUT / (label + ".command.json")).write_text(json.dumps(command, indent=2) + "\n", encoding="utf-8")
    start = time.monotonic()
    run = subprocess.run(argv, cwd=OUT, env=env, capture_output=True, timeout=120)
    elapsed = time.monotonic() - start
    (OUT / (label + ".stdout.txt")).write_bytes(run.stdout)
    (OUT / (label + ".stderr.txt")).write_bytes(run.stderr)
    (OUT / (label + ".exit")).write_text(str(run.returncode) + "\n", encoding="ascii")
    output = (run.stdout + run.stderr).decode("utf-8", errors="strict")
    counts = re.findall(r"^Ran (\d+) tests? in ([0-9.]+)s\r?$", output, flags=re.MULTILINE)
    if len(counts) != 1:
        raise RuntimeError("SINGLE_ACTUAL_TEST_SUMMARY_REQUIRED")
    statuses = re.findall(r"^test_.* \.\.\. (ok|FAIL|ERROR|skipped .*)\r?$", output, flags=re.MULTILINE)
    result = {"label": label, "exit": run.returncode, "tests": int(counts[0][0]), "unittest_seconds": counts[0][1], "wall_seconds": elapsed, "failures": statuses.count("FAIL"), "errors": statuses.count("ERROR"), "skips": sum(s.startswith("skipped") for s in statuses), "method_lines": len(statuses), "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest()}
    (OUT / (label + ".result.json")).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    results.append(result)
after = pins()
(OUT / "REPLAY-POSTCHECK-01.json").write_text(json.dumps({"pins": after, "unchanged": before == after, "results": results}, indent=2) + "\n", encoding="utf-8")
if before != after:
    raise RuntimeError("SOURCE_DRIFT")
print(json.dumps(results, indent=2))
sys.exit(0 if all(r["exit"] == 0 for r in results) else 1)
