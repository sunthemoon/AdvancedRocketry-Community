# C18c phase02a independent actual-source review

Date: 2026-10-05. Scope: four new files on fixed worktree base
`b6299c86f7bcb99b00b89b4dd38479e035321954`. This reviewer did not author them.
The result is a bounded source recommendation, not a native fixture, ownership,
delivery, API or version-Gate admission.

## Findings first

**No introduced Critical, High, Medium or Low source finding observed** in the
exact private quiescent properties-input leaf. The implemented boundary matches
the [phase02a task](selected-context/NATIVE-TASK-04-PHASE02A.md) together with
its [published disposition](selected-context/NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md).
The task's historical PROPOSED header is not substituted for that disposition.
No change to gameplay, persistence, properties grammar, limits or host authority
is recommended by this review.

There is one reviewer-tool accounting qualification, not a candidate finding:
fresh fixture cleanup returned 0 and removed the checked roots, but its byte
sum was null. The original records and [separate explanation/control](CLEANUP-ACCOUNTING-01.md)
are retained; no freed-byte count is claimed.

## Exact source and input qualification

Readonly executing worktree: `D:/GitHub/arce-v180-c18c-inputs-20261005`, branch
`codex/v1.8.0-inventory-properties-inputs`. Author sealed evidence:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-inputs-author-20261005-1b8f40`.
The author `EVIDENCE-MANIFEST-01.json` SHA is
`9f94cee5655c4a99cb4b4052c1144584aa36975215ab8d2cc217cd8d1598b978`;
the actual checksum filename is **SHA256SUMS-01.txt**, SHA
`5cdef3ab932e46e03ca19a67f3d4b020915e5aca843c1dbfb160ae6c882a601b`.
The report SHA is `dd75361ffb2695555d261e082fcdd42e3b04c2556d4e0f92a87dd544c9138f5f`.

[Intake pins](INTAKE-PINS-01.json) verify all 64 author payloads / 1,188,121 B,
65 checksum entries, four WT/author postimages and the exact additive patch.
[Source controls](SOURCE-CONTROLS-01.json) reconstruct all four new-file hunks
to exact postimages without writing/replaying source or mutating Git. Patch SHA:
`fe4792d566f114bf2e42b44fbca074094475c5ff83f0669cdc92a808fef24393`.

| New path | SHA-256 |
| --- | --- |
| `scripts/classic_inventory_fixture_inputs.py` | `42dc3299f5b973761926267ed5c69a37cd1be067e951fde515a4c3e55269667e` |
| `scripts/test_classic_inventory_fixture_inputs.py` | `c7d7b760b7c800a1096481094b8135d65b896aa25cf4a90592126ba36fe95b9f` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04-PHASE02A.md` | `2998de8c1d7e0b8efec1ab30dd6a7ecb2f955e2e3eb080e4d1480e28e3ce7941` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04-PHASE02A.md` | `10ab3a8313cf421e17c80c40a5655ff3a95c010baae09246b80c6f0f8c0cbece` |

The [final postcheck](FINAL-POSTCHECK-01.json) verifies all 66 original author
payload/manifest/checksum files, all 2,930 individually named existing WT
source/build/script/license inputs, 14 governance inputs and four postimages
unchanged. Git HEAD remains b629; tracked diff is empty. The original phase01
implementation/test are unchanged. Twenty-two report/handoff/progress local
companion references resolve. This is named-input qualification, not a whole
repository, private-document, JAR, world or cache export.
The byte-exact selected disposition retains one intentionally external prior
contract-ZIP companion, separately pinned in [companion locators](COMPANION-LOCATORS-01.md);
this thin review does not claim a recursive archive closure.

Effective live Root AGENTS is separately pinned: 12,047 B,
`1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`.
The readonly WT's older AGENTS is 8,379 B,
`725dd46344046bcdb802872e08fbc3cd9da0bf876e680eeba4c82dda801a9503`.
They are not treated as identical. No moving Root HEAD is used as the source
basis; this review changes neither file nor the repository.

## Actual review and execution

The [helper snapshot](selected-context/classic_inventory_fixture_inputs.py)
is 141 lines. Lines 41–54 bind exact native Path type, strict UTF-8 size and
literal local-D root shape. Lines 57–88 require comparable native identity,
regular/directory types and reparse refusal; 91–109 inspect literal ancestors
before strict canonical containment. Lines 112–141 bind exact selectors,
before/open/post observations, one unbuffered 16,385-byte request, immutable
raw result, descriptor closure and fixed errors without OS exception chaining.
AST inspection confirms the sole byte-read call at line 129 and no write,
directory enumeration, structural decode, process or retry call. The helper
does not import the runnable phase01 decoder/driver or create a framework.

Only own-D Python/static and readonly Git commands ran. [Replay runner](replay01.py)
executes the actual readonly WT test scripts, with `-B`, D-only process
TEMP/TMP/TMPDIR, controlled PYTHONPATH and fresh own fixture root. Raw stdout,
stderr, source-pinned command JSON and individual receipts are preserved.

| Actual command/cohort | Exit / methods / failure-error-skip |
| --- | --- |
| `python -B intake01.py` | 0; 64 payload / 65 checksum / 2,930 baseline / four exact additions |
| `python -B <WT>/scripts/test_classic_inventory_fixture_inputs.py -v` | 0 / 34 / 0-0-0; [receipt](focused-01.result.json), [raw stderr](focused-01.stderr.txt) |
| `python -B <WT>/scripts/test_run_v180_classic_inventory_smoke.py -v` | 0 / 39 / 0-0-0; [receipt](phase01-01.result.json), [raw stderr](phase01-01.stderr.txt) |
| `python -B independent_controls.py -v` | 0 / 10 / 0-0-0; [receipt](independent-01.result.json), [raw stderr](independent-01.stderr.txt) |
| native `cleanup-own-fixtures01.ps1` | 0; own-only literal cleanup, byte-total qualification above |
| `python -B postcheck01.py` | 0; all named original/source/governance pins unchanged |

Total independently executed: **83 methods, zero failure/error/skip**, not
borrowed author outcomes. Each subprocess supplies one real unittest summary
and the matching verbose method count. [Replay postcheck](REPLAY-POSTCHECK-01.json)
binds the four executable source pins unchanged. No Java/Gradle/server/native,
live host/config, network, fixture integration or source mutation occurred.
No fresh helper or output was created on C.

## Platform observations versus seams

[Actual Windows observations](fixtures-focused-01-platform.json) include leaf,
dangling and root symlinks; intermediate and ancestor junctions; explicit native
reparse attributes/tags; descriptor IDs/creation/write/type/size; and an exact
16,384-byte read using one 16,385-byte request with a closed descriptor. None of
these tests skipped on Windows Python 3.13.15. Actual file replacement and
post-read mutation were triggered at controlled scheduling points; they are
real filesystem operations, not hostile concurrent-race proofs.

The [ten reviewer controls](independent_controls.py) and [observations](INDEPENDENT-OBSERVATIONS-01.json)
exercise strict ASCII/multibyte root-byte boundaries, a real readonly regular
file with opaque invalid-UTF8/NUL bytes and closed descriptor, an actual
directory write-time change, callback-bearing selector refusal, capability
refusal and fixed-code secret suppression. Actual owned-directory hardlinks
share one native ID with nlink 2 and remain a regular-file observation; the
contract does not require nlink 1. This acceptance does **not** prove ownership
of links elsewhere or authorize untrusted roots.

Injected fstat birthtime/reparse observations, permission exceptions, short
reads, canonical redirection and close failure are labelled negative seams,
not actual ACL denial, native creation-time mutation or hostile race evidence.
Readonly file attributes are not an ACL test. Explicit birthtime is comparable
on this host; missing/invalid capability refuses, without assuming older Python
versions or other platforms are supported.

## Failure lineage and cleanup boundaries

The immutable author packet retains the initial binary-selection intake
failure, syntax import failure (zero discovered tests), original 31-method
five-failure/five-error run, actual lstat/fstat field observations and subsequent
source-pinned 34/39 green runs. This review reverified those original files but
did not rerun sealed helpers, revise their verdicts or erase the reds. The
author's five fresh fixture roots/22 aliases/413,698 regular-file bytes cleanup
and its later 39,792-B patch-copy cleanup rejection are separate. The rejected
target remains outside this review; no alternate cleanup attempt was made.

The review's own fresh roots were checked/cleaned in one native PowerShell
shell: six aliases removed without recursion, then exact ordinary fixture
roots removed; all three roots absent. Original logs/platform observations,
source pins and this report remain. No whole-source duplicate, ZIP or runtime
export was created. Null cleanup byte accounting is retained as an honest
tool-observation boundary rather than a claimed storage total.

## Recommendation and residual acceptance obligations

Root may consider exact-source integration of the four additions under the
already published phase02a scope, with this actual-diff/replay evidence. Root
alone owns commit/publication and any delivery qualification; this reviewer
does not mark a ledger leaf or version Gate complete.

Caller-owned root, actual quiescence/clean stop, process absence, snapshot
freshness and host admission remain external prerequisites. Static selectors
and equal metadata cannot establish them. Hidden same-identity mutations,
malicious ancestor races, interruptible OS deadlines, every nonregular/reparse
kind, actual ACL-denial behavior and unsupported platforms remain unproved.
No live read, JSON/NBT intake, eight-record absence scan, CREATE_NEW receipt,
profile-cache ownership, Java hook, bounded host/driver, native outcome or V1/V2
is delivered. The current version's Required Gates remain open. The only
continuation suggested here is Root's separately assigned current-v1.8
composition/remaining fixture dependencies, not a silent expansion of this API.
