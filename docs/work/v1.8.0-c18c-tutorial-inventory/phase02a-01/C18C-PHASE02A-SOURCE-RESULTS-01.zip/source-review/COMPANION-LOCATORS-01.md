# Selected normative snapshot companion

The individually necessary, byte-exact
`selected-context/NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md` retains its original
relative historical link to `file-input-contract01/FILE-INPUT-CONTRACT-CHECKS-01.zip`.
That earlier contract ZIP is intentionally **not duplicated** into this thin
source-review leaf. The disposition's task sibling is included here; the ZIP
remains a separate repository companion, not an absent source-review result.

Original literal readonly WT location:
`D:/GitHub/arce-v180-c18c-inputs-20261005/docs/work/v1.8.0-c18c-tutorial-inventory/file-input-contract01/FILE-INPUT-CONTRACT-CHECKS-01.zip`.
Observed size: 92,015 B. Observed SHA-256:
`0a8c3299c5d16064ded9b97ea892f78f9196f2d07cadd9bcd464ca35919616a7`.
Repository locator uses fixed base `b6299c86f7bcb99b00b89b4dd38479e035321954`
and the same relative `docs/work/.../file-input-contract01/` path. No ZIP body,
whole source or previous report tree is copied. This document qualifies the
deliberately limited transitive closure; it is not a substitute archive or a
new verification of all earlier contract observations.
