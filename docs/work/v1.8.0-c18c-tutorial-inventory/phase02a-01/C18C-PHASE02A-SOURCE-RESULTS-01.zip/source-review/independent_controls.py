"""Independent controls against the actual readonly phase02a Windows helper."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import traceback
from types import SimpleNamespace
import unittest
from unittest import mock

SOURCE = Path("D:/GitHub/arce-v180-c18c-inputs-20261005/scripts")
sys.path.insert(0, str(SOURCE))
import classic_inventory_fixture_inputs as subject

OUTPUT = Path(__file__).parent
FIXTURES = OUTPUT / "fixtures-independent-01"
OBSERVATIONS = []


class StreamObservation:
    def __init__(self, stream):
        self.stream = stream
        self.requests = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.stream.close()

    def fileno(self):
        return self.stream.fileno()

    def read(self, amount):
        self.requests.append(amount)
        return self.stream.read(amount)


class IndependentPropertiesInputTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if os.name != "nt" or Path(subject.__file__).resolve() != (SOURCE / "classic_inventory_fixture_inputs.py").resolve():
            raise RuntimeError("ACTUAL_WINDOWS_SUBJECT_REQUIRED")
        FIXTURES.mkdir(exist_ok=False)

    @classmethod
    def tearDownClass(cls):
        path = Path(subject.__file__)
        result = {
            "loaded_module": str(path),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "python": sys.version,
            "platform": os.name,
            "observations": OBSERVATIONS,
            "cleanup": "separate literal own-fixture cleanup required",
        }
        (OUTPUT / "INDEPENDENT-OBSERVATIONS-01.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    def setUp(self):
        self.root = FIXTURES / self._testMethodName
        self.root.mkdir()
        self.target = self.root / "server.properties"
        self.target.write_bytes(b"opaque=\xff\x00\r\n")

    def read(self):
        return subject.read_quiescent_properties(self.root, "active", "stopped")

    def refusal(self, operation, code):
        with self.assertRaises(subject.PropertiesFileInputError) as caught:
            operation()
        self.assertEqual(code, caught.exception.code)
        self.assertIsNone(caught.exception.__cause__)
        self.assertTrue(caught.exception.__suppress_context__)
        return caught.exception

    def tracked_open(self):
        native = Path.open
        streams = []
        def opened(path, mode="r", buffering=-1, **kwargs):
            stream = StreamObservation(native(path, mode, buffering=buffering, **kwargs))
            streams.append(stream)
            return stream
        return mock.patch.object(Path, "open", opened), streams

    def test_root_strict_utf8_exact_boundary_without_filesystem(self):
        exact = Path("D:/" + "x" * 1021)
        self.assertEqual(1024, len(str(exact).encode("utf-8")))
        self.assertEqual(exact, subject._root_path(exact))
        self.refusal(lambda: subject._root_path(Path("D:/" + "x" * 1022)), "ROOT")
        multibyte = Path("D:/" + "\u00e9" * 510 + "x")
        self.assertEqual(1024, len(str(multibyte).encode("utf-8")))
        self.assertEqual(multibyte, subject._root_path(multibyte))
        self.refusal(lambda: subject._root_path(Path(str(multibyte) + "x")), "ROOT")

    def test_actual_readonly_file_raw_bytes_and_closed_descriptor(self):
        self.target.chmod(stat.S_IREAD)
        try:
            native_before = self.target.stat()
            patch, streams = self.tracked_open()
            with patch:
                actual = self.read()
            self.assertEqual(b"opaque=\xff\x00\r\n", actual)
            self.assertIs(type(actual), bytes)
            self.assertEqual([16385], streams[0].requests)
            self.assertTrue(streams[0].stream.closed)
            native_after = self.target.stat()
            self.assertEqual(subject._identity(native_before), subject._identity(native_after))
            OBSERVATIONS.append({"kind": "actual_readonly_file", "attributes": native_after.st_file_attributes, "closed": True, "not_acl_denial": True})
        finally:
            self.target.chmod(stat.S_IREAD | stat.S_IWRITE)

    def test_actual_hardlink_is_regular_observation_not_ownership_proof(self):
        sibling = self.root / "own-hardlink.properties"
        os.link(self.target, sibling)
        target_status = self.target.lstat()
        sibling_status = sibling.lstat()
        self.assertEqual(target_status.st_ino, sibling_status.st_ino)
        self.assertEqual(2, target_status.st_nlink)
        self.assertEqual(0, target_status.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
        self.assertEqual(b"opaque=\xff\x00\r\n", self.read())
        OBSERVATIONS.append({"kind": "actual_same_owned_directory_hardlink", "nlink": target_status.st_nlink, "accepted_regular_shape": True, "ownership_not_established": True})

    def test_actual_directory_mtime_change_after_read_refuses(self):
        original = subject._literal_observations
        calls = 0
        def observed(*args):
            nonlocal calls
            calls += 1
            if calls == 2:
                status = self.root.stat()
                os.utime(self.root, ns=(status.st_atime_ns, status.st_mtime_ns + 1_000_000_000))
            return original(*args)
        patch, streams = self.tracked_open()
        with patch, mock.patch.object(subject, "_literal_observations", observed):
            self.refusal(self.read, "CHANGED")
        self.assertEqual(2, calls)
        self.assertTrue(streams[0].stream.closed)
        OBSERVATIONS.append({"kind": "actual_directory_write_time_change", "controlled_postread_scheduling": True, "refused": "CHANGED"})

    def test_descriptor_birthtime_change_seam_refuses_closes(self):
        original = os.fstat
        calls = 0
        def observed(fd):
            nonlocal calls
            calls += 1
            status = original(fd)
            if calls == 2:
                fields = {name: getattr(status, name) for name in ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_birthtime_ns", "st_nlink", "st_file_attributes", "st_reparse_tag")}
                fields["st_birthtime_ns"] += 1
                return SimpleNamespace(**fields)
            return status
        patch, streams = self.tracked_open()
        with patch, mock.patch.object(os, "fstat", observed):
            self.refusal(self.read, "CHANGED")
        self.assertEqual(2, calls)
        self.assertTrue(streams[0].stream.closed)
        OBSERVATIONS.append({"kind": "controlled_fstat_birthtime_change", "refused": "CHANGED", "real_os_birthtime_mutation_not_claimed": True})

    def test_descriptor_reparse_attribute_seam_refuses_closes(self):
        original = os.fstat
        def observed(fd):
            status = original(fd)
            fields = {name: getattr(status, name) for name in ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_birthtime_ns", "st_nlink", "st_file_attributes", "st_reparse_tag")}
            fields["st_file_attributes"] |= stat.FILE_ATTRIBUTE_REPARSE_POINT
            return SimpleNamespace(**fields)
        patch, streams = self.tracked_open()
        with patch, mock.patch.object(os, "fstat", observed):
            self.refusal(self.read, "PATH")
        self.assertEqual([], streams[0].requests)
        self.assertTrue(streams[0].stream.closed)

    def test_open_error_no_secret_default_traceback(self):
        secret = "fixture-sensitive-value-7be4"
        with mock.patch.object(Path, "open", side_effect=PermissionError(secret)):
            error = self.refusal(self.read, "IO")
        rendered = "".join(traceback.format_exception(error))
        self.assertNotIn(secret, rendered)
        self.assertNotIn(str(self.root), str(error))
        self.assertEqual("IO", str(error))
        OBSERVATIONS.append({"kind": "controlled_permission_exception", "secret_absent_default_traceback": True, "actual_acl_denial_not_claimed": True})

    def test_string_selector_subclass_no_callbacks_or_io(self):
        calls = []
        class CallbackString(str):
            def __hash__(self):
                calls.append("hash")
                raise AssertionError("CALLBACK")
            def __eq__(self, value):
                calls.append("equals")
                raise AssertionError("CALLBACK")
        with mock.patch.object(Path, "lstat", side_effect=AssertionError("IO_REACHED")):
            self.refusal(lambda: subject.read_quiescent_properties(self.root, CallbackString("active"), "stopped"), "SELECTOR")
            self.refusal(lambda: subject.read_quiescent_properties(self.root, "active", CallbackString("stopped")), "SELECTOR")
        self.assertEqual([], calls)

    def test_missing_explicit_creation_capability_refuses(self):
        status = self.target.stat()
        fields = {name: getattr(status, name) for name in ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_nlink", "st_file_attributes", "st_reparse_tag")}
        self.refusal(lambda: subject._identity(SimpleNamespace(**fields)), "PLATFORM")
        fields["st_birthtime_ns"] = float(status.st_birthtime_ns)
        self.refusal(lambda: subject._identity(SimpleNamespace(**fields)), "PLATFORM")

    def test_unknown_error_code_cannot_echo_input(self):
        for value in ("private-config", None, 7, b"IO"):
            error = subject.PropertiesFileInputError(value)
            self.assertEqual("IO", str(error))
            self.assertEqual("IO", error.code)


if __name__ == "__main__":
    unittest.main(verbosity=2)
