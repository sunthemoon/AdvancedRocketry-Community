# Reviewer-owned fixture cleanup qualification

The single native PowerShell [cleanup script](cleanup-own-fixtures01.ps1)
returned exit 0. Its [precheck](CLEANUP-PRECHECK-01.json) enumerated only three
literal fresh reviewer roots, 81 ordinary files, 90 directories and six reparse
aliases, without traversing aliases. Aliases were removed nonrecursively first.
The [result](CLEANUP-RESULT-01.json) records all three roots absent. These roots
were `fixtures-focused-01`, `fixtures-independent-01` and `process-temp` under
this reviewer directory; evidence is outside them. No old rejected or author
target was attempted.

The script's `Measure-Object -Property bytes` over OrderedDictionary rows
produced **null**, not a valid total. The original precheck/result/log remain
unchanged. A separate [in-memory control](CLEANUP-ACCOUNTING-PROBE-01.json)
reproduced null from the same expression on rows containing 7 and 11, while
explicit dictionary indexing summed 18. This control accessed no filesystem.
It does not recover the original 81 file lengths after removal. Therefore this
review claims the observed absence/counts, **not a freed-byte or disk-allocation
total**. There was no cleanup failure exit, retry, replacement receipt or
attempt to infer bytes from reconstructed fixtures.
