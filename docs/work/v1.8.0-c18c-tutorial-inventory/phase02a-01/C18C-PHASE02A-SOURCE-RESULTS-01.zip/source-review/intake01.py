import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = HERE.parent / 'c18c-inputs-author-20261005-1b8f40'
WT = Path('D:/GitHub/arce-v180-c18c-inputs-20261005')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'b6299c86f7bcb99b00b89b4dd38479e035321954'


def digest(raw): return hashlib.sha256(raw).hexdigest()
def js(path): return json.loads(path.read_text(encoding='utf-8'))
def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}
def verify(path, row):
    actual = pin(path)
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], str(path)
    return actual
def save(name, value): (HERE / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


assert digest((AUTHOR / 'EVIDENCE-MANIFEST-01.json').read_bytes()) == '9f94cee5655c4a99cb4b4052c1144584aa36975215ab8d2cc217cd8d1598b978'
assert digest((AUTHOR / 'SHA256SUMS-01.txt').read_bytes()) == '5cdef3ab932e46e03ca19a67f3d4b020915e5aca843c1dbfb160ae6c882a601b'
assert digest((AUTHOR / 'REPORT-01.md').read_bytes()) == 'dd75361ffb2695555d261e082fcdd42e3b04c2556d4e0f92a87dd544c9138f5f'
manifest = js(AUTHOR / 'EVIDENCE-MANIFEST-01.json')
author = []
for row in manifest['files']:
    rel = Path(row['path'])
    assert not rel.is_absolute() and '..' not in rel.parts and 'Development-Docs' not in str(rel)
    author.append(verify(AUTHOR / rel, row))
assert len(author) == 64 and sum(row['bytes'] for row in author) == 1188121
for name in ('EVIDENCE-MANIFEST-01.json', 'SHA256SUMS-01.txt'):
    author.append(pin(AUTHOR / name))
sums = (AUTHOR / 'SHA256SUMS-01.txt').read_text(encoding='utf-8').splitlines()
for line in sums:
    expected, rel = line.split('  ', 1)
    assert digest((AUTHOR / rel).read_bytes()) == expected
assert len(sums) == 65
source = js(AUTHOR / 'SOURCE-MANIFEST-01.json')
assert source['fixed_base'] == BASE and len(source['files']) == 4
postimages = [verify(WT / row['path'], row) for row in source['files']]
for row in source['files']:
    assert (WT / row['path']).read_bytes() == (AUTHOR / 'postimages' / row['path']).read_bytes()
baseline = js(AUTHOR / 'BASELINE-SOURCE-01.json')
assert baseline['base_commit'] == BASE and len(baseline['files']) == 2930
for row in baseline['files']:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts and 'Development-Docs' not in str(relative)
    verify(WT / relative, row)
governance = js(AUTHOR / 'GOVERNANCE-INPUTS-01.json')
governance_pins = []
for row in governance['inputs']:
    literal = Path(row['path']) if Path(row['path']).is_absolute() else WT / row['path']
    literal.read_text(encoding='utf-8')
    governance_pins.append(verify(literal, row))
assert len(governance_pins) == 14

git_calls = []
for arguments, expected in ((['rev-parse', 'HEAD'], BASE),
                            (['branch', '--show-current'], 'codex/v1.8.0-inventory-properties-inputs'),
                            (['diff', '--no-ext-diff', '--name-only'], '')):
    argv = ['git', *arguments]
    actual = subprocess.run(argv, cwd=WT, capture_output=True)
    assert actual.returncode == 0 and not actual.stderr and actual.stdout.decode().strip() == expected
    git_calls.append({'argv': argv, 'exit': 0, 'stdout_sha256': digest(actual.stdout), 'stdout_value': actual.stdout.decode().strip()})

# Pure new-file patch reconstruction, not git apply/index/source mutation.
patch = (AUTHOR / 'SOURCE-01.patch').read_text(encoding='utf-8')
assert digest(patch.encode()) == source['patch']['sha256']
blocks = re.split(r'(?m)^diff --git ', patch)[1:]
reconstructed = []
for block in blocks:
    lines = block.splitlines(keepends=True)
    header = lines[0].strip()
    old, new = header.split(' ')
    assert old.startswith('a/') and new.startswith('b/') and old[2:] == new[2:]
    rel = new[2:]
    hunk = next(i for i, line in enumerate(lines) if line.startswith('@@ '))
    match = re.fullmatch(r'@@ -0,0 \+1,(\d+) @@\n', lines[hunk])
    assert match and 'new file mode 100644\n' in lines[:hunk]
    added = lines[hunk + 1:]
    assert len(added) == int(match[1]) and all(line.startswith('+') for line in added)
    raw = ''.join(line[1:] for line in added).encode('utf-8')
    assert raw == (WT / rel).read_bytes()
    reconstructed.append({'path': rel, 'bytes': len(raw), 'sha256': digest(raw)})
assert {row['path'] for row in reconstructed} == {row['path'] for row in source['files']}

context = HERE / 'selected-context'
context.mkdir()
for row in source['files'][:2]:
    shutil.copyfile(WT / row['path'], context / Path(row['path']).name)
for name in ('NATIVE-TASK-04-PHASE02A.md', 'NATIVE-REVIEW-DISPOSITION-04-PHASE02A.md'):
    shutil.copyfile(WT / 'docs/work/v1.8.0-c18c-tutorial-inventory' / name, context / name)
tree = ast.parse((WT / source['files'][0]['path']).read_text(encoding='utf-8'))
read_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'read']
assert len(read_calls) == 1
save('SOURCE-CONTROLS-01.json', {'frozen_author_payloads': 64, 'author_checksums': 65,
     'four_source_postimages': postimages, 'pure_patch_reconstructed_postimages': reconstructed,
     'tracked_named_baseline_count': 2930, 'baseline_mismatches': [], 'governance': governance_pins,
     'git_read_commands': git_calls, 'single_source_read_call_line': read_calls[0].lineno,
     'no_patch_or_repository_mutation': True})
save('INTAKE-PINS-01.json', {'author': author, 'governance': governance_pins, 'postimages': postimages,
     'base': BASE, 'baseline_manifest_reference': pin(AUTHOR / 'BASELINE-SOURCE-01.json'),
     'source_manifest_reference': pin(AUTHOR / 'SOURCE-MANIFEST-01.json'), 'original_drift': []})
print(json.dumps({'author_payloads': 64, 'checksums': 65, 'baseline': 2930, 'postimages': 4, 'pure_patch_exact': True}))
