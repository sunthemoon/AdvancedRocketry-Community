# Correction of historical collector wording

TOOL-OBSERVATIONS-02.md is retained as an incorrect historical record, not an
artifact-audit result. Its claim that the packaged synthetic class equals the
development compiled bytes is false; its wording also must not imply that
artifact_audit02.py completed its checks. That script failed, as recorded
separately in TOOL-OBSERVATIONS-03.md. No ARTIFACT-MEMBER-AUDIT-02.json or
ARTIFACT-MEMBER-AUDIT-04.json completed-result file is claimed to exist.

The later independent auditor derives actual member/source/class facts from
the archives without those assumptions. The final verification record must
cite that independent evidence and retain all original collector failures.
This explicit correction changes no source/artifact, assertion, byte/count
bound, build execution or previously sealed observation. It is not a new build
or a pass of the failed Root collectors.
