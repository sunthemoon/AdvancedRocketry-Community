"""Capture fresh scoped validations without converting open closure into PASS."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-observation-04/artifacts-01')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


py = [sys.executable, '-B']
jobs = [
    ('common-client', py + ['scripts/check_client_imports.py'], 0),
    ('ledger-strict', py + ['scripts/validate_v180_content_ledger.py', '--require-accepted'], 0),
    ('ledger-closure', py + ['scripts/validate_v180_content_ledger.py', '--closure'], 1),
    ('planning', py + ['scripts/validate_v1plus_planning.py'], 0),
    ('provenance', py + ['scripts/validate_bootstrap_provenance.py', '--require-approved-review'], 0),
    ('machine-resources', py + ['scripts/validate_v120_machine_resources.py'], 0),
    ('artifact', py + ['scripts/validate_build_artifact.py',
        str(OUT / 'artifacts-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'),
        '--expected-version', '1.20.1-1.8.0-dev'], 0),
    ('generated-diff', ['git', 'diff', '--exit-code', '--', 'src/generated'], 0),
    ('diff-check', ['git', 'diff', '--check'], 0),
    ('dirty-diff', ['git', 'diff', '--exit-code'], 1),
]
rows = []
for label, command, expected in jobs:
    write(label + '-01.command.json', {'command': command, 'cwd': str(ROOT),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    start = time.monotonic()
    log = OUT / (label + '-01.log')
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': label, 'command': command, 'exit': result.returncode,
        'expected_exit': expected, 'elapsed_seconds': time.monotonic() - start,
        'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    print(json.dumps(row), flush=True)
write('STATIC-RESULTS-01.json', {'jobs': rows, 'required_gates_passed': False})
assert all(row['exit'] == row['expected_exit'] for row in rows), rows

base = 'advancedrocketry-community-1.20.1-1.8.0-dev'
prefix = 'io/github/sunthemoon/advancedrocketrycommunity/'
resource = 'data/advancedrocketrycommunity/advancements/classic/'
langs = {'assets/advancedrocketrycommunity_v180/lang/' + name + '.json' for name in ('en_us', 'zh_cn')}
suffixes = ('root', 'block_press', 'rolling', 'electrolysis', 'suited_up', 'warp_core')
resources = {resource + name + '.json' for name in suffixes}
new_source = {prefix + name for name in (
    'progression/classic/ClassicInventoryAdvancements.java',
    'datagen/V180ClassicAdvancementData.java', 'datagen/V180ClassicAdvancementLanguage.java',
    'gametest/ClassicInventoryAdvancementGameTests.java')}
new_classes = {name[:-5] + '.class' for name in new_source}
new_classes.add(prefix + 'progression/classic/ClassicInventoryAdvancements$Goal.class')
central = {prefix + 'datagen/' + name for name in ('BootstrapDataGenerators', 'V180LanguageProvider')}
audit = []
for suffix in ('', '-sources', '-api'):
    name = base + suffix + '.jar'
    with zipfile.ZipFile(OLD / name) as old, zipfile.ZipFile(OUT / 'artifacts-01' / name) as actual:
        oldnames = [entry.filename for entry in old.infolist() if not entry.is_dir()]
        names = [entry.filename for entry in actual.infolist() if not entry.is_dir()]
        assert len(names) == len(set(names)), name
        assert old.testzip() is None and actual.testzip() is None
        removed = set(oldnames) - set(names)
        added = set(names) - set(oldnames)
        changed = {entry for entry in oldnames if entry in set(names) and old.read(entry) != actual.read(entry)}
        expected_added = (resources | (new_source if suffix == '-sources' else new_classes)) if suffix != '-api' else set()
        expected_changed = (langs | {entry + ('.java' if suffix == '-sources' else '.class') for entry in central}) if suffix != '-api' else set()
        audit.append({'artifact': name, 'old_members': len(oldnames), 'new_members': len(names),
            'removed': sorted(removed), 'added': sorted(added), 'changed': sorted(changed),
            'expected_added': sorted(expected_added), 'expected_changed': sorted(expected_changed)})
        assert not removed, removed
        assert added == expected_added, (name, added, expected_added)
        assert changed == expected_changed, (name, changed, expected_changed)
        if suffix == '-api':
            assert (OLD / name).read_bytes() == (OUT / 'artifacts-01' / name).read_bytes()
write('ARTIFACT-MEMBER-AUDIT-01.json', {'artifacts': audit,
    'all_other_members_unchanged': True, 'API_byte_exact': True, 'required_gates_passed': False})
print(json.dumps({'artifact_member_audit': 'PASS', 'required_gates_passed': False}), flush=True)
