"""Correct the collector's omitted javac enum-switch synthetic class, not source."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-observation-04/artifacts-01')
PREFIX = 'io/github/sunthemoon/advancedrocketrycommunity/'
source = json.loads((OUT / 'SOURCE25-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, expected in source.items():
    data = (ROOT / name).read_bytes()
    assert {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == expected, name
language = (ROOT / ('src/main/java/' + PREFIX + 'datagen/V180ClassicAdvancementLanguage.java')).read_text(encoding='utf-8')
assert 'switch (goal)' in language
classes = {PREFIX + name for name in (
    'progression/classic/ClassicInventoryAdvancements.class',
    'progression/classic/ClassicInventoryAdvancements$Goal.class',
    'datagen/V180ClassicAdvancementData.class', 'datagen/V180ClassicAdvancementLanguage.class',
    'datagen/V180ClassicAdvancementLanguage$1.class',
    'gametest/ClassicInventoryAdvancementGameTests.class')}
new_source = {PREFIX + name for name in (
    'progression/classic/ClassicInventoryAdvancements.java',
    'datagen/V180ClassicAdvancementData.java', 'datagen/V180ClassicAdvancementLanguage.java',
    'gametest/ClassicInventoryAdvancementGameTests.java')}
resources = {'data/advancedrocketrycommunity/advancements/classic/' + name + '.json'
             for name in ('root', 'block_press', 'rolling', 'electrolysis', 'suited_up', 'warp_core')}
langs = {'assets/advancedrocketrycommunity_v180/lang/' + name + '.json' for name in ('en_us', 'zh_cn')}
central = {PREFIX + 'datagen/' + name for name in ('BootstrapDataGenerators', 'V180LanguageProvider')}
audit = []
for suffix in ('', '-sources', '-api'):
    name = 'advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar'
    with zipfile.ZipFile(OLD / name) as old, zipfile.ZipFile(OUT / 'artifacts-01' / name) as actual:
        oldnames = [entry.filename for entry in old.infolist() if not entry.is_dir()]
        names = [entry.filename for entry in actual.infolist() if not entry.is_dir()]
        assert len(names) == len(set(names)) and len(oldnames) == len(set(oldnames))
        assert old.testzip() is None and actual.testzip() is None
        removed = set(oldnames) - set(names)
        added = set(names) - set(oldnames)
        changed = {entry for entry in set(oldnames) & set(names) if old.read(entry) != actual.read(entry)}
        expected_added = resources | (new_source if suffix == '-sources' else classes) if suffix != '-api' else set()
        expected_changed = langs | {entry + ('.java' if suffix == '-sources' else '.class') for entry in central} if suffix != '-api' else set()
        if suffix == '':
            expected_changed.add(PREFIX + 'datagen/V180LanguageProvider$1.class')
        audit.append({'artifact': name, 'old_members': len(oldnames), 'new_members': len(names),
            'removed': sorted(removed), 'added': sorted(added), 'changed': sorted(changed),
            'expected_added': sorted(expected_added), 'expected_changed': sorted(expected_changed)})
        assert not removed and added == expected_added and changed == expected_changed, audit[-1]
        if suffix == '':
            compiled = actual.read(PREFIX + 'datagen/V180ClassicAdvancementLanguage$1.class')
            assert compiled == (ROOT / ('build/classes/java/main/' + PREFIX + 'datagen/V180ClassicAdvancementLanguage$1.class')).read_bytes()
            assert b'$SwitchMap$io$github$sunthemoon$advancedrocketrycommunity$progression$classic$ClassicInventoryAdvancements$Goal' in compiled
        if suffix == '-api':
            assert (OLD / name).read_bytes() == (OUT / 'artifacts-01' / name).read_bytes()
result = {'artifacts': audit, 'all_other_members_unchanged': True, 'API_byte_exact': True,
    'source_inputs_unchanged': len(source), 'required_gates_passed': False,
    'preserved_previous_collector_exit': 1,
    'correction': 'Explicit new language switch synthetic class and changed existing provider synthetic class; no source/artifact change'}
path = OUT / 'ARTIFACT-MEMBER-AUDIT-04.json'
assert not path.exists()
path.write_bytes((json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
print(json.dumps(result), flush=True)
