"""Run a fresh committed Source25 cohort; preserve commands and actual outcomes."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
HEAD = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
TEMP = OUT / 'tmp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == HEAD
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
source = json.loads((OUT / 'C18-REVIEWED-SOURCE-MANIFEST-01.json').read_text())
assert len(source) == 3009
for name, expected in source.items():
    assert pin(ROOT / name) == expected, name
write('SOURCE25-MANIFEST-01.json', source)
write('SOURCE25-BOUNDARY-01.json', {'tested_commit': HEAD, 'named_inputs': len(source),
    'not_whole_repository': True, 'previous_full_cohort': 'Source24 at a385ba45',
    'reviewed_source_publication': 'SOURCE-PUBLICATION-01.json',
    'AGENTS_live_not_git': source['AGENTS.md'],
    'wrapper_qualification': 'Existing 92 LF/CRLF expansions; no wrapper changes',
    'TEMP_TMP_TMPDIR': str(TEMP), 'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
flags = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
         '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix()]
jobs = [('full-build-01', flags + ['clean', 'build', 'test', 'runData']),
        ('gametest-01', flags + ['runGameTestServer'])]
rows = []
try:
    for label, command in jobs:
        free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
        assert all(value >= 10_000_000_000 for value in free.values()), free
        write(label + '.command.json', {'command': command, 'cwd': str(ROOT),
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'tested_commit': HEAD, 'free_bytes': free, 'threshold_bytes': 10_000_000_000,
            'TEMP_TMP_TMPDIR': str(TEMP), 'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
        log = OUT / (label + '.log')
        assert not log.exists()
        start = time.monotonic()
        with log.open('xb') as output:
            result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
        row = {'name': label, 'exit': result.returncode,
               'elapsed_seconds': time.monotonic() - start, 'log': pin(log)}
        rows.append(row)
        write(label + '.result.json', row)
        print(json.dumps(row), flush=True)
        if label == 'full-build-01':
            junit = OUT / 'junit-01'
            junit.mkdir()
            totals = {'suites': 0, 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
            for file in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
                shutil.copyfile(file, junit / file.name)
                suite = ET.parse(file).getroot()
                totals['suites'] += 1
                for key in ('tests', 'failures', 'errors', 'skipped'):
                    totals[key] += int(suite.attrib[key])
            write('JUNIT-01.json', totals)
            if result.returncode == 0:
                assert totals == {'suites': 333, 'tests': 1785, 'failures': 0, 'errors': 0, 'skipped': 0}, totals
                artifacts = OUT / 'artifacts-01'
                artifacts.mkdir()
                captures = {}
                for suffix in ('', '-sources', '-api'):
                    name = 'advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar'
                    src = ROOT / 'build/libs' / name
                    shutil.copyfile(src, artifacts / name)
                    assert pin(src) == pin(artifacts / name)
                    captures[name] = pin(artifacts / name)
                write('ARTIFACTS-01.json', captures)
        if label == 'gametest-01':
            for name in ('latest.log', 'debug.log'):
                src = ROOT / 'build/gametest/logs' / name
                if src.is_file():
                    shutil.copyfile(src, OUT / ('gametest-01-' + name))
        if result.returncode:
            break
finally:
    changed = [name for name, expected in source.items() if pin(ROOT / name) != expected]
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    write('SOURCE25-POSTCHECK-01.json', {'named_inputs': len(source), 'mismatches': changed,
        'tested_head_unchanged': current_head == HEAD, 'required_gates_passed': False})
    write('FULL-CHECKS-01.json', {'commands': rows, 'tested_commit': HEAD,
        'source_unchanged': not changed and current_head == HEAD, 'required_gates_passed': False})
assert not changed and current_head == HEAD
assert len(rows) == 2
sys.exit(rows[-1]['exit'])
