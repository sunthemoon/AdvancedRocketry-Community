# Additional artifact collector failures

This note transcribes tool-return observations, not archived raw stderr files.
The actual build/JUnit/GameTest logs and artifacts are separate and unchanged.

1. First artifact_audit02.py invocation exited 1 before writing its result:
   read_text used the Windows GBK default on the UTF-8 Chinese source and raised
   UnicodeDecodeError. The script remains unchanged.
2. A separate `python -X utf8 -B artifact_audit02.py` invocation exited 1 on its
   old-member allowlist: V180LanguageProvider$1.class also changed. The preceding
   stdout-only Tee pipeline had only stderr; artifact-audit-03.log was not
   created. A later named read reported that missing locator; no such raw log
   is claimed. The exact archived artifacts remain unchanged.
3. The separate artifact_audit04.py invocation uses explicit UTF-8 and records
   that additional exact member. It exits 1 at its assumption that the packaged
   new synthetic class equals build/classes/java/main bytes. Packaged Forge
   reobfuscation requires independent mapping inspection; that assumption is
   not a production/source test and its failed result is not rewritten as PASS.

All attempted collector scripts remain separately preserved. A delegated
independent auditor is inspecting the actual source/member facts without using
these assumptions or enabling native/client/Gate delivery. No production
source, assertion, resource, artifact or full-build result is changed.
