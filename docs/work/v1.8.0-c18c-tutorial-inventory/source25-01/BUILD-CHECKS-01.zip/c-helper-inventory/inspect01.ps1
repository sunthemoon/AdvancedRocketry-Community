$ErrorActionPreference = 'Stop'
$owned = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\c-helper-inventory-740c8a0692'
$env:TEMP = "$owned\process-temp"
$env:TMP = $env:TEMP
$env:TMPDIR = $env:TEMP
$context = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\guard-lifecycle-publication-01'
$names = @('C-SCRIPT-PRECHECK-01.json', 'C-TEMP-ROOT-CANDIDATES-01.json',
    'C-CLEANUP-TOOL-FAILURE-01.md', 'ACTIVE-PROCESSES-01.json')
$inputPins = foreach ($name in $names) {
    $path = Join-Path $context $name
    $item = Get-Item -LiteralPath $path
    [ordered]@{ path = $path; bytes = $item.Length;
        sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$governance = 'D:\GitHub\AdvancedRocketry-Community\AGENTS.md'
$item = Get-Item -LiteralPath $governance
$inputPins += [ordered]@{ path = $governance; bytes = $item.Length;
    sha256 = (Get-FileHash -LiteralPath $governance -Algorithm SHA256).Hash.ToLowerInvariant() }
$precheck = Get-Content -LiteralPath "$context\C-SCRIPT-PRECHECK-01.json" -Raw | ConvertFrom-Json
if ($precheck.Count -ne 11) { throw 'Scope must contain exactly the eleven recorded direct files' }
$allowedParents = @(
    'C:\Users\Administrator\AppData\Local\Temp\arce-v180-motor-root-79a12d61d241424eb3ea3ab0d1a3782d',
    'C:\Users\Administrator\AppData\Local\Temp\arce-v180-preparation-7ab047faa03449238fbf4da5149d956b'
)
$seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$rows = foreach ($entry in $precheck) {
    $literal = [string]$entry.source
    $full = [System.IO.Path]::GetFullPath($literal)
    if ($full -cne $literal) { throw "Noncanonical recorded file: $literal" }
    if ($allowedParents -notcontains [System.IO.Path]::GetDirectoryName($full)) {
        throw "Out-of-scope parent: $literal"
    }
    if (-not $seen.Add($full)) { throw "Duplicate recorded file: $literal" }
    $row = [ordered]@{
        literal_path = $literal; exists = (Test-Path -LiteralPath $literal);
        declared_owner = 'Root prior task, per C-CLEANUP-TOOL-FAILURE-01.md';
        ownership_basis = "$context\C-SCRIPT-PRECHECK-01.json";
        expected_bytes = [long]$entry.bytes; expected_sha256 = [string]$entry.sha256;
        prior_rejection_scope = 'The entire eleven-file backup/removal command was rejected before OS execution';
        proposed_preservation_path = [string]$entry.destination;
        current_type = 'absent'; current_bytes = $null; current_sha256 = $null;
        attributes = $null; full_name = $null; reparse_point = $false;
        expected_match = $false; inspection = 'literal read only'
    }
    if ($row.exists) {
        $current = Get-Item -LiteralPath $literal -Force
        $row.full_name = $current.FullName
        $row.attributes = [string]$current.Attributes
        $row.reparse_point = [bool]($current.Attributes -band [System.IO.FileAttributes]::ReparsePoint)
        if ($row.reparse_point) {
            $row.current_type = 'reparse point; bytes not followed'
        } elseif ($current.PSIsContainer) {
            $row.current_type = 'directory; not inspected recursively'
        } else {
            $row.current_type = 'regular file'
            $row.current_bytes = $current.Length
            $row.current_sha256 = (Get-FileHash -LiteralPath $literal -Algorithm SHA256).Hash.ToLowerInvariant()
            $row.expected_match = $row.current_bytes -eq $row.expected_bytes -and
                $row.current_sha256 -ceq $row.expected_sha256
        }
    }
    [pscustomobject]$row
}
$result = [ordered]@{
    captured_utc = (Get-Date).ToUniversalTime().ToString('o');
    command = 'inspect01.ps1; Get-Content/Get-Item/Test-Path/Get-FileHash with explicit literal targets only';
    input_pins = @($inputPins); candidate_count = $rows.Count;
    candidates = @($rows); existing_count = @($rows | Where-Object exists).Count;
    regular_file_count = @($rows | Where-Object current_type -EQ 'regular file').Count;
    bytes_current = [long](($rows | Measure-Object -Property current_bytes -Sum).Sum);
    expected_match_count = @($rows | Where-Object expected_match).Count;
    cleanup_executed = $false; backups_created = $false; processes_terminated = $false;
    no_C_enumeration = $true; no_C_outputs = $true;
    limitations = @('Ownership is the recorded task declaration, not independent OS ACL/creation attribution.',
        'Historical process inventory is not a fresh active-task check; no process was queried or terminated.',
        'Only the eleven exact files were inspected; no parent children, globals, worlds, seals or other C files were read.',
        'Recorded D backup destinations were not created or inspected; prior rejection states no backup occurred.',
        'The previous policy rejection remains historical and is not bypassed or converted to cleanup success.')
}
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$owned\RESULT-01.json" -Encoding utf8
$inputPins | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$owned\INPUT-MANIFEST-01.json" -Encoding utf8
$rows | Select-Object literal_path, current_type, current_bytes, current_sha256, expected_match | Format-Table -AutoSize
[pscustomobject]@{ Candidates = $rows.Count; Existing = $result.existing_count;
    RegularFiles = $result.regular_file_count; Bytes = $result.bytes_current;
    ExactMatches = $result.expected_match_count; CleanupExecuted = $false } | Format-List
