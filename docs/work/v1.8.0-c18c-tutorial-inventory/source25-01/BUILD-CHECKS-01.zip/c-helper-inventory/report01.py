"""Render the actual literal-file result and seal a small read-only inventory."""
import hashlib
import json
import os
from pathlib import Path

B=Path(__file__).resolve().parent
for name in ('TEMP','TMP','TMPDIR'):
    os.environ[name]=str(B/'process-temp')
sha=lambda data:hashlib.sha256(data).hexdigest()
result=json.loads((B/'RESULT-01.json').read_text(encoding='utf-8-sig'))
assert (B/'inspect-01.exit').read_text(encoding='utf-8-sig').strip()=='0'
lines=['# Eleven-file C helper inventory', '',
       '## Findings and qualification', '',
       f"- Cleanup remains open: {result['existing_count']} of the eleven literal recorded candidates currently exist; "
       f"{result['regular_file_count']} are regular files, totaling {result['bytes_current']:,} bytes. "
       f"{result['expected_match_count']} match the original precheck size and SHA-256 exactly.",
       '- The original eleven-file backup/removal command was rejected by the execution tool before OS execution. '
       'That historical rejection covers all eleven candidates. This inventory does not retry it or use another '
       'deletion mechanism; no cleanup or backup occurred in this task.',
       '- Root ownership is the prior task declaration in the original precheck/cleanup note, not independently '
       'established OS ACL ownership or a reconstructed creation history. The files are under two explicitly '
       'named prior Root task parents. They are not declared to be this worker\'s newly created files.',
       '- The historical process inventory is not a fresh active-task check. No process was inspected or terminated. '
       'Unowned Java processes and all other-agent data remain outside this scope.', '',
       '## Literal current observations', '',
       '| Literal path | Current type | Bytes | SHA-256 | Original precheck match |',
       '|---|---|---:|---|---|']
for row in result['candidates']:
    lines.append(f"| `{row['literal_path']}` | {row['current_type']} | {row['current_bytes']} | "
                 f"`{row['current_sha256']}` | {row['expected_match']} |")
lines += ['', 'Every row has the same declared owner: Root, per the original cleanup note. '
          'Every row is in the previously rejected whole-command scope; none has a completed-removal receipt.', '',
          '## Preservation and safe Root cleanup scope', '',
          'The only eligible candidate scope is these eleven individual files, not either parent directory, '
          'any recursive subtree, any other Temp entry, a source world, a sealed packet or a process. '
          'The original manifest lists proposed D backup destinations but the rejection note explicitly states '
          'the rejected command did not create those backups. This task did not create or inspect backups.', '',
          'If Root subsequently obtains an execution path accepted by the tool policy, perform any cleanup '
          'entirely in one PowerShell session using the original literal allowlist. Re-check exact file identity, '
          'regular-file/reparse state and current owner activity first. Preserve/verify the required evidence '
          'before removing anything. Use only native PowerShell individual-file operations with `-LiteralPath`; '
          'never `-Recurse`, a wildcard, an enumerated parent tree, `cmd /c`, a string-built shell command, or '
          'cross-shell deletion. A file-only removal has the form `Remove-Item -LiteralPath <one exact verified file>`; '
          'it is a scope description, not a command executed or authorized by this read-only task. '
          'A fresh policy rejection must be reported rather than bypassed.', '',
          'No parent seal/ancestor metadata or active-process recheck was performed in this new bounded inventory. '
          'Those safety checks must be established by Root before any separately permitted cleanup. '
          'The original note records its earlier parent/seal observations, but they are not relabeled as current proof.', '',
          '## Actual commands and evidence', '',
          '- `inspect01.ps1` used only explicitly named `Get-Content`, `Get-Item`, `Test-Path`, and '
          '`Get-FileHash -LiteralPath` targets; exit 0. No C directory enumeration or file contents were exported.',
          '- `python -B report01.py` rendered this result and hashed this small owned evidence set. '
          'No Java, native server, Gradle, network, Git write, deletion, movement or process termination was run.',
          '- New helpers and all process TEMP/TMP/TMPDIR use this fresh project-parent D task directory. '
          'No C output was created.', '',
          '[Actual result](RESULT-01.json) · [Input pins](INPUT-MANIFEST-01.json) · '
          '[Raw read-only output](inspect-01.log) · [Inspection source](inspect01.ps1)', '',
          'The four exact original context files are under '
          '`D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-publication-01`: '
          '`C-SCRIPT-PRECHECK-01.json`, `C-TEMP-ROOT-CANDIDATES-01.json`, '
          '`C-CLEANUP-TOOL-FAILURE-01.md`, and `ACTIVE-PROCESSES-01.json`. '
          'Their individual byte counts/hashes and live governance pin are in the input manifest. '
          'No original/sealed evidence was changed.', '',
          '## Limits', '',
          'This is a current literal-file existence/type/size/hash inventory only. '
          'It makes no whole-C cleanup, disk-space recovery, backup-completion, code/runtime or version Gate claim. '
          'Any earlier worker-created C artifacts not among this exact eleven-file manifest remain unexamined '
          'and are not declared cleaned or absent.']
(B/'REPORT-01.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
names=['REPORT-01.md','RESULT-01.json','INPUT-MANIFEST-01.json','inspect01.ps1','inspect-01.log',
       'inspect-01.exit','started-01.txt','finished-01.txt','report01.py']
entries=[]
for name in names:
    data=(B/name).read_bytes()
    entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
manifest={'scope':'read-only eleven literal C-file inventory; no cleanup performed',
          'entries':entries,'entry_count':len(entries),'payload_bytes':sum(e['bytes'] for e in entries),
          'no_archive':'small loose evidence; no source export or redundant ZIP'}
(B/'INTERNAL-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(B/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  '+e['path']+'\n' for e in entries)+
                               sha((B/'INTERNAL-MANIFEST.json').read_bytes())+'  INTERNAL-MANIFEST.json\n',
                               encoding='utf-8')
for e in entries:
    assert sha((B/e['path']).read_bytes())==e['sha256']
print(json.dumps({'report_sha256':sha((B/'REPORT-01.md').read_bytes()),
                  'manifest_sha256':sha((B/'INTERNAL-MANIFEST.json').read_bytes()),
                  'entries':len(entries),'bytes':manifest['payload_bytes'],
                  'existing':result['existing_count'],'regular':result['regular_file_count'],
                  'current_bytes':result['bytes_current'],'exact_matches':result['expected_match_count'],
                  'cleanup_performed':False},indent=2))
