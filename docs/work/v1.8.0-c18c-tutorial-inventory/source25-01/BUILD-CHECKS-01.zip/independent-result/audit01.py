from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import struct
import subprocess
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
INPUT = OUT.parent / 'c18-integration-01'
PRIOR = OUT.parent / 'guard-observation-04'
COMMIT = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
commands = []


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read_json(path):
    return json.loads(path.read_bytes().decode('utf-8'))


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode())


def git(*args, input=None):
    command = ['git', '-C', str(ROOT), *args]
    result = subprocess.run(command, input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    commands.append({'command': command, 'exit': result.returncode,
                     'stdout': pin(result.stdout), 'stderr': result.stderr.decode('utf-8', errors='replace')})
    assert result.returncode == 0, commands[-1]
    return result.stdout


def class_info(raw):
    # Parse classfile framing and attributes directly, without loading Java classes.
    offset = 0
    def take(n):
        nonlocal offset
        assert n >= 0 and offset + n <= len(raw)
        value = raw[offset:offset+n]
        offset += n
        return value
    def u1(): return int.from_bytes(take(1), 'big')
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    assert take(4) == b'\xca\xfe\xba\xbe'
    minor, major, count = u2(), u2(), u2()
    cp = [None] * count
    idx = 1
    while idx < count:
        kind = u1()
        if kind == 1:
            cp[idx] = (kind, take(u2()).decode('utf-8', errors='replace'))
        elif kind in (3, 4): cp[idx] = (kind, take(4))
        elif kind in (5, 6):
            cp[idx] = (kind, take(8)); idx += 1
        elif kind in (7, 8, 16, 19, 20): cp[idx] = (kind, u2())
        elif kind in (9, 10, 11, 12, 17, 18): cp[idx] = (kind, u2(), u2())
        elif kind == 15: cp[idx] = (kind, u1(), u2())
        else: raise AssertionError(('unknown cp type', kind))
        idx += 1
    def text(index):
        assert cp[index][0] == 1
        return cp[index][1]
    def klass(index):
        return None if index == 0 else text(cp[index][1])
    access, this, superclass = u2(), u2(), u2()
    interfaces = [klass(u2()) for _ in range(u2())]
    def attrs():
        return [(text(u2()), take(u4())) for _ in range(u2())]
    def members():
        values = []
        for _ in range(u2()):
            flags, name, descriptor = u2(), text(u2()), text(u2())
            attributes = attrs()
            values.append({'access': flags, 'name': name, 'descriptor': descriptor,
                           'attributes': {key: pin(value) for key, value in attributes}})
        return values
    fields, methods = members(), members()
    attributes = attrs()
    assert offset == len(raw)
    source = None
    for key, data in attributes:
        if key == 'SourceFile':
            assert len(data) == 2
            source = text(int.from_bytes(data, 'big'))
    return {'internal_name': klass(this), 'access': access, 'major': major, 'minor': minor,
            'super': klass(superclass), 'interfaces': interfaces, 'source_file': source,
            'fields': fields, 'methods': methods,
            'utf8_constants': [entry[1] for entry in cp if entry and entry[0] == 1],
            'class_attributes': {key: pin(data) for key, data in attributes}}


assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
manifest = read_json(INPUT / 'SOURCE25-MANIFEST-01.json')
prior_manifest = read_json(PRIOR / 'SOURCE24-MANIFEST-01.json')
for path in manifest:
    p = PurePosixPath(path)
    assert not p.is_absolute() and p.as_posix() == path and '..' not in p.parts and ':' not in path
    assert not path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
ordered = list(sorted(manifest))
batch = git('cat-file', '--batch', input=(''.join(COMMIT + ':' + path + '\n' for path in ordered)).encode())
position = 0
objects = {}
git_deltas = []
disk_deltas = []
for path in ordered:
    end = batch.index(b'\n', position)
    header = batch[position:end].decode('ascii')
    sha, kind, size = header.split(' ')
    assert kind == 'blob'
    size = int(size)
    raw = batch[end+1:end+1+size]
    position = end+1+size
    assert batch[position:position+1] == b'\n'
    position += 1
    objects[path] = raw
    if pin(raw) != manifest[path]:
        diskraw = (ROOT / path).read_bytes()
        git_deltas.append({'path': path, 'manifest': manifest[path], 'git': pin(raw),
                           'manifest_equals_live': pin(diskraw) == manifest[path],
                           'git_to_manifest_crlf_only': diskraw.replace(b'\r\n', b'\n') == raw,
                           'crlf_count': diskraw.count(b'\r\n')})
    if pin((ROOT / path).read_bytes()) != manifest[path]: disk_deltas.append(path)
assert position == len(batch)
source_delta = {'added': sorted(set(manifest)-set(prior_manifest)),
                'removed': sorted(set(prior_manifest)-set(manifest)),
                'changed': sorted(path for path in set(manifest)&set(prior_manifest)
                                  if manifest[path] != prior_manifest[path])}
author = OUT.parent / 'c18-author-83b6107d4f'
reviewed = read_json(author / 'SOURCE-MANIFEST-01.json')
reviewed_rows = []
for row in reviewed['own']:
    raw = (author / 'candidate-01' / row['path']).read_bytes()
    expected = {'bytes': row['bytes'], 'sha256': row['sha256']}
    assert pin(raw) == expected == pin(objects[row['path']])
    reviewed_rows.append({'path': row['path'], **expected})
write('SOURCE-BINDING-01.json', {'tested_commit': COMMIT, 'named_inputs': len(manifest),
      'safe_paths': True, 'git_object_qualifications': git_deltas,
      'live_disk_mismatches': disk_deltas, 'source_delta_from24': source_delta,
      'reviewed_six_exact': reviewed_rows, 'not_whole_git_snapshot': True})

audits = []
members_by_artifact = {}
for suffix in ('', '-sources', '-api'):
    name = 'advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar'
    with zipfile.ZipFile(PRIOR / 'artifacts-01' / name) as old, zipfile.ZipFile(INPUT / 'artifacts-01' / name) as new:
        oldentries = old.infolist(); entries = new.infolist()
        oldnames = [entry.filename for entry in oldentries if not entry.is_dir()]
        names = [entry.filename for entry in entries if not entry.is_dir()]
        assert len(oldnames) == len(set(oldnames)) and len(names) == len(set(names))
        for entry in oldentries + entries:
            path = PurePosixPath(entry.filename)
            assert not path.is_absolute() and '..' not in path.parts and ':' not in entry.filename
            assert entry.file_size <= 64000000
        assert old.testzip() is None and new.testzip() is None
        removed = sorted(set(oldnames)-set(names))
        added = sorted(set(names)-set(oldnames))
        changed = sorted(n for n in set(names)&set(oldnames) if old.read(n) != new.read(n))
        class_rows = []
        for n in added + changed:
            if n.endswith('.class'):
                info = class_info(new.read(n))
                assert info['internal_name'] + '.class' == n
                classname = info['internal_name'].split('/')[-1].split('$')[0]
                sourcepath = 'src/main/java/' + info['internal_name'].rsplit('/', 1)[0] + '/' + info['source_file']
                class_rows.append({'member': n, 'archive': pin(new.read(n)), 'source_path': sourcepath,
                                   'source_pin': pin(objects[sourcepath]), 'class_info': info,
                                   'old_class_info': class_info(old.read(n)) if n in oldnames else None})
        audits.append({'artifact': name, 'old_pin': pin((PRIOR / 'artifacts-01' / name).read_bytes()),
                       'pin': pin((INPUT / 'artifacts-01' / name).read_bytes()),
                       'old_members': len(oldnames), 'members': len(names),
                       'crc_ok': True, 'no_duplicate_members': True,
                       'added': added, 'changed': changed, 'removed': removed,
                       'unchanged_members': len(set(oldnames)&set(names))-len(changed),
                       'class_source_map': class_rows})
        members_by_artifact[suffix] = {n: new.read(n) for n in names}
write('ARCHIVE-DELTA-01.json', {'artifacts': audits, 'derived_without_allowlist': True,
      'api_whole_bytes_equal': audits[2]['old_pin'] == audits[2]['pin']})
mapping = []
generated = []
prefix = 'src/main/java/'
for path, raw in objects.items():
    if path.startswith(prefix) and path.endswith('.java'):
        entry = path[len(prefix):]
        assert members_by_artifact['-sources'][entry] == raw, path
        mapping.append(path)
    if path.startswith('src/generated/') and '/resources/' in path and '/.cache/' not in path:
        entry = path.split('/resources/', 1)[1]
        assert members_by_artifact[''][entry] == raw == members_by_artifact['-sources'][entry], path
        generated.append(path)
languages = []
for row in audits[:2]:
    for name in row['changed']:
        if name.startswith('assets/') and name.endswith('.json'):
            suffix = '' if row is audits[0] else '-sources'
            with zipfile.ZipFile(PRIOR / 'artifacts-01' / row['artifact']) as z:
                old = json.loads(z.read(name))
            new = json.loads(members_by_artifact[suffix][name])
            languages.append({'artifact': row['artifact'], 'path': name, 'old_keys': len(old), 'new_keys': len(new),
                              'added': sorted(set(new)-set(old)), 'removed': sorted(set(old)-set(new)),
                              'changed': sorted(k for k in set(new)&set(old) if new[k] != old[k])})
write('RESOURCE-MAPPING-01.json', {'main_java_source_objects_equal_sources_jar': len(mapping),
       'generated_objects_equal_main_and_sources': len(generated), 'language_delta': languages})

junit_audits = []
for folder, collector in (('junit-01', 'JUNIT-01.json'), ('integrated-data-01-xml', 'INTEGRATED-JUNIT-01.json')):
    suites = []
    count = {'tests': 0, 'suites': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
    for path in sorted((INPUT / folder).rglob('*.xml')):
        root = ET.fromstring(path.read_bytes())
        assert root.tag == 'testsuite'
        cases = root.findall('testcase')
        assert len(cases) == int(root.attrib['tests'])
        count['suites'] += 1; count['tests'] += len(cases)
        for tag in ('failure', 'error', 'skipped'):
            key = {'failure': 'failures', 'error': 'errors', 'skipped': 'skipped'}[tag]
            observed = sum(case.find(tag) is not None for case in cases)
            assert observed == int(root.attrib[key])
            count[key] += observed
        suites.append({'file': path.relative_to(INPUT).as_posix(), 'name': root.attrib['name'],
                       'timestamp': root.attrib.get('timestamp'), 'cases': len(cases), 'pin': pin(path.read_bytes())})
    collected = read_json(INPUT / collector)
    junit_audits.append({'folder': folder, 'counts': count, 'collector': collected, 'suites': suites})
write('XML-COUNTS-01.json', {'audits': junit_audits})
logrows = []
for name in ('full-build-01', 'gametest-01', 'integrated-data-01'):
    log = (INPUT / (name + '.log')).read_bytes()
    receipt = read_json(INPUT / (name + '.result.json'))
    assert receipt['log'] == pin(log)
    text = log.decode('utf-8', errors='strict')
    logrows.append({'name': name, 'result': receipt,
                    'build_outcomes': [line for line in text.splitlines() if 'BUILD ' in line],
                    'datagen_written': [line for line in text.splitlines() if 'written' in line.lower()],
                    'gametest_outcomes': [line for line in text.splitlines()
                       if re.search(r'(GameTests? complete|required tests? passed|required tests? failed)', line)]})
for name in ('gametest-01-latest.log', 'gametest-01-debug.log'):
    text = (INPUT / name).read_bytes().decode('utf-8', errors='strict')
    logrows.append({'name': name, 'outcomes': [line for line in text.splitlines()
                       if re.search(r'(GameTests? complete|required tests? passed|required tests? failed)', line)]})
staticrows = []
for row in read_json(INPUT / 'STATIC-RESULTS-01.json')['jobs']:
    command = read_json(INPUT / (row['name'] + '-01.command.json'))
    raw = (INPUT / (row['name'] + '-01.log')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['log_sha256']
    assert command['command'] == row['command']
    staticrows.append({'name': row['name'], 'exit': row['exit'], 'expected_exit': row['expected_exit'],
                       'log': pin(raw), 'tail': raw.decode('utf-8', errors='replace').splitlines()[-3:]})
write('COMMAND-OBSERVATIONS-01.json', {'logs': logrows, 'static_commands': staticrows,
      'closure_dirty_diff_remain_exit1': True, 'no_runtime_replay_or_gate_acceptance': True})
write('GIT-READ-COMMANDS-01.json', commands)
print(json.dumps({'source': source_delta, 'git_qualifications': git_deltas, 'live_deltas': disk_deltas,
                  'junit': [item['counts'] for item in junit_audits],
                  'artifacts': [{key: row[key] for key in ('artifact','old_members','members','added','changed','removed')}
                                for row in audits], 'java_sources': len(mapping), 'generated': len(generated)}))
