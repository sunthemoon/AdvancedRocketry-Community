from pathlib import Path
import hashlib
import json
import os
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
INPUT = OUT.parent / 'c18-integration-01'
PRIOR = OUT.parent / 'guard-observation-04'
COMMIT = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(name, value):
    target = OUT / name
    assert not target.exists()
    target.write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode())


assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
named = ['SOURCE25-MANIFEST-01.json', 'SOURCE25-BOUNDARY-01.json',
         'SOURCE25-POSTCHECK-01.json', 'FULL-CHECKS-01.json', 'full-build-01.command.json',
         'full-build-01.result.json', 'full-build-01.log', 'JUNIT-01.json',
         'gametest-01.command.json', 'gametest-01.result.json', 'gametest-01.log',
         'gametest-01-latest.log', 'gametest-01-debug.log', 'ARTIFACTS-01.json',
         'STATIC-RESULTS-01.json', 'SOURCE-PUBLICATION-01.json',
         'C18-REVIEWED-SOURCE-MANIFEST-01.json', 'run_static01.py', 'artifact_audit02.py',
         'TOOL-OBSERVATIONS-02.md', 'integrated-data-01.command.json',
         'integrated-data-01.result.json', 'integrated-data-01.log', 'INTEGRATED-JUNIT-01.json']
pins = {str(INPUT / name): pin(INPUT / name) for name in named}
static = json.loads((INPUT / 'STATIC-RESULTS-01.json').read_text(encoding='utf-8'))
for row in static['jobs']:
    for suffix in ('.command.json', '.log'):
        path = INPUT / (row['name'] + '-01' + suffix)
        pins[str(path)] = pin(path)
for folder in ('junit-01', 'integrated-data-01-xml'):
    for path in sorted((INPUT / folder).rglob('*.xml')):
        assert path.is_relative_to(INPUT / folder) and not path.is_symlink()
        pins[str(path)] = pin(path)
for folder in (INPUT / 'artifacts-01', PRIOR / 'artifacts-01'):
    for suffix in ('', '-sources', '-api'):
        path = folder / ('advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar')
        pins[str(path)] = pin(path)
pins[str(PRIOR / 'SOURCE24-MANIFEST-01.json')] = pin(PRIOR / 'SOURCE24-MANIFEST-01.json')
author = OUT.parent / 'c18-author-83b6107d4f'
pins[str(author / 'SOURCE-MANIFEST-01.json')] = pin(author / 'SOURCE-MANIFEST-01.json')
authority = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
             'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
             'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
             'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
             'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
             'docs/work/v1.8.0-c18c-tutorial-inventory/TASK.md',
             'docs/work/v1.8.0-c18c-tutorial-inventory/SOURCE-INTEGRATION-01.md']
read_commands = []
for relative in authority:
    command = ['git', '-C', str(ROOT), 'show', COMMIT + ':' + relative]
    result = subprocess.run(command, capture_output=True, check=False)
    assert result.returncode == 0, (relative, result.stderr)
    text = result.stdout.decode('utf-8')
    read_commands.append({'command': command, 'exit': result.returncode,
                          'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest(),
                          'headings': [line for line in text.splitlines() if line.startswith('#')]})
pins[str(ROOT / 'AGENTS.md')] = pin(ROOT / 'AGENTS.md')
write('INPUT-PINS-01.json', {'tested_commit': COMMIT, 'named_external_inputs': pins,
                           'read_governance_git_objects': read_commands,
                           'live_agents_separate': pins[str(ROOT / 'AGENTS.md')],
                           'no_source_export_java_native_git_write': True})
manifest = json.loads((INPUT / 'SOURCE25-MANIFEST-01.json').read_text(encoding='utf-8'))
prior = json.loads((PRIOR / 'SOURCE24-MANIFEST-01.json').read_text(encoding='utf-8'))
own = json.loads((author / 'SOURCE-MANIFEST-01.json').read_text(encoding='utf-8'))
write('INTAKE-01.json', {'pin_count': len(pins), 'source_manifest_count': len(manifest),
                       'prior_manifest_count': len(prior), 'reviewed_manifest_type': type(own).__name__,
                       'reviewed_manifest_keys': list(own), 'scope': 'archived-result audit, not runtime replay'})
print(json.dumps(json.loads((OUT / 'INTAKE-01.json').read_text())))
