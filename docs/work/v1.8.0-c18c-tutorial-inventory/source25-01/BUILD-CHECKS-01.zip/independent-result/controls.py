from pathlib import Path
import ast
import copy
from datetime import datetime, timedelta, timezone
import io
import json
import re
import struct
import subprocess
import unittest
import xml.etree.ElementTree as ET
import zipfile

# Reuse only the independently authored read/parse functions, not its audit body.
source = Path(__file__).with_name('audit01.py').read_text(encoding='utf-8')
exec(compile(source[:source.index('assert all(')], 'audit01.py (definitions only)', 'exec'))


def validate_suite(raw):
    root = ET.fromstring(raw)
    assert root.tag == 'testsuite'
    cases = root.findall('testcase')
    assert len(cases) == int(root.attrib['tests'])
    counts = {'tests': len(cases)}
    for tag, key in (('failure', 'failures'), ('error', 'errors'), ('skipped', 'skipped')):
        counts[key] = sum(case.find(tag) is not None for case in cases)
        assert counts[key] == int(root.attrib[key])
    return counts


def authoritative_gt(text, runtime=False):
    time_prefix = r'\[04Oct2026 \d{2}:\d{2}:\d{2}\.\d{3}\]' if runtime else r'\[\d{2}:\d{2}:\d{2}\]'
    logger = r'net\.minecraft\.gametest\.framework\.GameTestServer/' if runtime else r'minecraft/GameTestServer'
    passed = re.findall('^' + time_prefix + r' \[Server thread/INFO\] \[' + logger +
                        r'\]: All (\d+) required tests passed :\)$', text, re.M)
    completed = re.findall('^' + time_prefix + r' \[Server thread/INFO\] \[' + logger +
                           r'\]: =+ (\d+) GAME TESTS COMPLETE =+$', text, re.M)
    assert len(passed) == 1 and len(completed) == 1 and passed == completed
    assert not re.search(r'\b\d+ required tests failed\b', text)
    return int(passed[0])


class Controls(unittest.TestCase):
    def test_actual_xml_arithmetic(self):
        totals = dict(tests=0, failures=0, errors=0, skipped=0)
        for path in (INPUT / 'junit-01').glob('*.xml'):
            values = validate_suite(path.read_bytes())
            for key in totals: totals[key] += values[key]
        self.assertEqual(totals, dict(tests=1785, failures=0, errors=0, skipped=0))

    def test_forged_suite_total_is_not_a_testcount(self):
        with self.assertRaises(AssertionError):
            validate_suite(b'<testsuite tests="9" failures="0" errors="0" skipped="0"><testcase/></testsuite>')

    def test_failure_nodes_cannot_be_hidden_by_zero_stats(self):
        with self.assertRaises(AssertionError):
            validate_suite(b'<testsuite tests="1" failures="0" errors="0" skipped="0"><testcase><failure/></testcase></testsuite>')

    def test_actual_gt_agrees_across_three_logs(self):
        self.assertEqual(authoritative_gt((INPUT / 'gametest-01.log').read_text(encoding='utf-8')), 467)
        for name in ('gametest-01-latest.log', 'gametest-01-debug.log'):
            self.assertEqual(authoritative_gt((INPUT / name).read_text(encoding='utf-8'), True), 467)

    def test_gt_fake_logger_cannot_establish_pass(self):
        with self.assertRaises(AssertionError):
            authoritative_gt('[00:00:00] [Server thread/INFO] [arbitrary]: All 467 required tests passed :)')

    def test_gt_conflicting_or_duplicate_success_fails(self):
        text = (INPUT / 'gametest-01.log').read_text(encoding='utf-8')
        for changed in (text + '\n[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: All 467 required tests passed :)\n',
                        text.replace('All 467 required tests passed', 'All 466 required tests passed')):
            with self.subTest():
                with self.assertRaises(AssertionError): authoritative_gt(changed)

    def test_no_members_are_silently_removed_or_unknown_classes_ignored(self):
        audit = read_json(OUT / 'ARCHIVE-DELTA-02.json')
        for row in audit['artifacts']:
            self.assertEqual(row['removed'], [])
            for member in row['added'] + row['changed']:
                if member.endswith('.class'):
                    maps = [entry for entry in row['class_source_map'] if entry['member'] == member]
                    self.assertEqual(len(maps), 1)
                    self.assertEqual(maps[0]['class_info']['major'], 61)

    def test_exact_new_and_changed_compiler_switch_sources(self):
        rows = read_json(OUT / 'ARCHIVE-DELTA-02.json')['artifacts'][0]['class_source_map']
        for suffix, expected_source, names in (
            ('V180ClassicAdvancementLanguage$1.class', 'V180ClassicAdvancementLanguage.java', ('Goal',)),
            ('V180LanguageProvider$1.class', 'V180LanguageProvider.java', ('MaterialCatalog$Kind', 'MaterialCatalog$Product'))):
            row = next(entry for entry in rows if entry['member'].endswith(suffix))
            info = row['class_info']
            self.assertEqual(info['source_file'], expected_source)
            self.assertTrue(info['access'] & 0x1000)
            for name in names:
                self.assertTrue(any(name in field['name'] and field['descriptor'] == '[I' for field in info['fields']))
            self.assertEqual([method['name'] for method in info['methods']], ['<clinit>'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
