from pathlib import Path

# Preserve facts03's real missing-timestamp KeyError; do not invent chronology.
source = Path(__file__).with_name('facts03.py').read_text(encoding='utf-8')
source = source.replace('SYNTHETIC-LINE-DELTA-01.json', 'SYNTHETIC-LINE-DELTA-02.json')
source = source.replace('CENTRAL-DIFF-01.txt', 'CENTRAL-DIFF-02.txt')
source = source.replace('FINAL-FACTS-01.json', 'FINAL-FACTS-02.json')
old = """    start = datetime.fromisoformat(command['started_utc']); end = start + timedelta(seconds=result['elapsed_seconds'])
    timestamps = [datetime.fromisoformat(suite['timestamp']).replace(tzinfo=timezone.utc) for suite in row['suites']]
    assert all(start <= stamp <= end for stamp in timestamps)"""
new = """    timestamps = [datetime.fromisoformat(suite['timestamp']).replace(tzinfo=timezone.utc) for suite in row['suites']]
    has_start = 'started_utc' in command
    if has_start:
        start = datetime.fromisoformat(command['started_utc']); end = start + timedelta(seconds=result['elapsed_seconds'])
        assert all(start <= stamp <= end for stamp in timestamps)"""
assert source.count(old) == 1
source = source.replace(old,new)
source = source.replace("'all_within_recorded_command':True", "'all_within_recorded_command':True if has_start else None, 'command_start_timestamp_recorded':has_start, 'scope':'committed full job' if has_start else 'earlier uncommitted development job; absent command-start timestamp'")
source = source.replace("assert publication['tested_commit'] == COMMIT", "assert any(item['command'][0] == 'git' and item['command'][-2:] == ['rev-parse', 'HEAD'] and item['output'].strip() == COMMIT for item in publication['commands'])")
exec(compile(source, 'facts03.py (explicit absent timestamp/publication schema)', 'exec'))
