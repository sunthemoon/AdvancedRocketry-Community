from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
COHORT = OUT.parent / 'c18-integration-01'


def pin(path):
    raw = path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def dump(name,value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value,indent=2,ensure_ascii=True)+'\n').encode())


assert all(Path(os.environ[k]).resolve() == (OUT/'tmp').resolve() for k in ('TEMP','TMP','TMPDIR'))
original = json.loads((OUT/'INPUT-PINS-01.json').read_text(encoding='utf-8'))
for path,expected in original['named_external_inputs'].items():
    assert pin(Path(path)) == expected, path
extra = {}
for name in ('artifact_audit04.py','TOOL-OBSERVATIONS-03.md','C18-INTEGRATION-POSTCHECK-01.json'):
    extra[str(COHORT/name)] = pin(COHORT/name)
source = json.loads((COHORT/'SOURCE25-MANIFEST-01.json').read_text(encoding='utf-8'))
for relative,expected in source.items():
    assert pin(ROOT/relative) == expected, relative
commands = []
for args in (['rev-parse','a5abc34809891d6b10724ee60ab9b5e97f036bae^{commit}'],
             ['show','--format=','--name-only','a5abc34809891d6b10724ee60ab9b5e97f036bae']):
    command = ['git','-C',str(ROOT),*args]
    result = subprocess.run(command,capture_output=True,check=False)
    assert result.returncode == 0
    commands.append({'command':command,'exit':0,'stdout':result.stdout.decode('utf-8'),
                     'stderr':result.stderr.decode('utf-8')})
assert commands[0]['stdout'].strip() == 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
report = (OUT/'REVIEW-01.md').read_text(encoding='utf-8')
links = re.findall(r'\]\(([^)]+)\)', report)
for target in links:
    path = (OUT/target).resolve()
    assert path.is_relative_to(OUT) and path.is_file(), target
dump('FINAL-INPUT-CHECKS-01.json', {'named_external_inputs_verified':len(original['named_external_inputs']),
     'additional_external_pins':extra,'named_source_inputs_verified':len(source),
     'commands':commands,'report_local_links':links,'links_missing':0,
     'no_head_dependency_or_runtime_replay':True})
dump('AUDITOR-COMMAND-INDEX-01.json', {'recording':'Exact commands used; raw exit/log companions are primary. No invented subprocess-start timestamps.',
    'process_local_temp':str(OUT/'tmp'), 'cwd':str(ROOT),
    'commands':[{'command':['D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe','-B',str(OUT/file)],
                 'raw_log':label+'.log','exit_file':label+'.exit'}
                for file,label in (('intake.py','intake-01'),('audit01.py','audit-01'),('audit02.py','audit-02'),
                                   ('controls.py','controls-01'),('facts03.py','facts-03'),('facts04.py','facts-04'))]})
files={}
excluded={'INTERNAL-MANIFEST.json','INTERNAL-MANIFEST.sha256','FREEZE-01.json','seal-01.log','seal-01.exit'}
for path in sorted(OUT.rglob('*')):
    relative=path.relative_to(OUT)
    if relative.parts[0]=='tmp' or relative.as_posix() in excluded: continue
    assert not path.is_symlink(), path
    if path.is_file(): files[relative.as_posix()]=pin(path)
assert sum(row['bytes'] for row in files.values())<2500000
dump('INTERNAL-MANIFEST.json',{'format':'loose-evidence-manifest-v1','files':files,
    'scope':'Fixed Source25 named result audit only; no native/client/Required Gate or source self-review'})
manifest=pin(OUT/'INTERNAL-MANIFEST.json')
(OUT/'INTERNAL-MANIFEST.sha256').write_bytes((manifest['sha256']+'  INTERNAL-MANIFEST.json\n').encode())
for path,expected in files.items(): assert pin(OUT/path)==expected,path
dump('FREEZE-01.json',{'sealed_utc':datetime.now(timezone.utc).isoformat(),
    'manifest':manifest,'report':pin(OUT/'REVIEW-01.md'),'payload_count':len(files),
    'payload_bytes':sum(row['bytes'] for row in files.values()),'links_checked':len(links),
    'links_missing':0,'all_payloads_and_original_inputs_verified':True,
    'no_zip_jar_source_export_or_runtime_launch':True})
print((OUT/'FREEZE-01.json').read_text(encoding='utf-8'))
