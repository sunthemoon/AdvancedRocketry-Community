from pathlib import Path

# Preserve the first auditor's actual failed historical-resource assumption.
source = Path(__file__).with_name('audit01.py').read_text(encoding='utf-8')
original = "        assert members_by_artifact[''][entry] == raw == members_by_artifact['-sources'][entry], path"
replacement = """        actual = members_by_artifact[''].get(entry)
        source_actual = members_by_artifact['-sources'].get(entry)
        assert actual == source_actual, path
        resource_rows.append({'path': path, 'member': entry, 'input': pin(raw),
                              'packaged': pin(actual) if actual is not None else None,
                              'equal': actual == raw})"""
assert source.count(original) == 1
source = source.replace(original, replacement)
source = source.replace('generated = []', 'generated = []\nresource_rows = []')
source = source.replace("'generated_objects_equal_main_and_sources': len(generated)",
                        "'generated_input_count': len(generated), 'generated_equal_count': sum(r['equal'] for r in resource_rows), 'generated_input_relations': resource_rows")
for name in ('SOURCE-BINDING', 'ARCHIVE-DELTA', 'RESOURCE-MAPPING', 'XML-COUNTS',
             'COMMAND-OBSERVATIONS', 'GIT-READ-COMMANDS'):
    source = source.replace(name + '-01.json', name + '-02.json')
exec(compile(source, 'audit01.py (explicit historical-resource relation collection)', 'exec'))
