# C18 Source25 result audit

## Findings first

**Low, historical collector claim qualification:**
`c18-integration-01/TOOL-OBSERVATIONS-02.md:7-13` asserts packaged/compiler byte
equality and describes an artifact audit that had not completed. The separate
`TOOL-OBSERVATIONS-03.md:6-18` correctly preserves the GBK, changed-member and
packaged/compiler equality failures. The earlier note is historical, not a
successful artifact-audit receipt. Keep both unchanged and use this independently
derived archive comparison for the final qualified record. No build/test failure
is inferred from those failed collectors, and no compiler/reobfuscation whole-byte
equivalence is asserted here.

No additional build, JUnit, GameTest or packaged-member discrepancy was identified
in the named cohort. This is an evidence audit, not a new source-acceptance decision,
independent Java/native replay, clean-log waiver or v1.8 Gate admission.

## Fixed scope and named-source boundary

Source25 means commit `a5abc34809891d6b10724ee60ab9b5e97f036bae`. Source24 means
the prior OBS04 cohort at `a385ba452ab756b5689a1cbf21e2177129b93dc9`.
Inputs are the named immutable receipts/artifacts in
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01` and the prior named
artifact directory; no current-HEAD identity is substituted.

[Source binding](SOURCE-BINDING-02.json) reconstructs all 3,009 named Git blobs
and checks all 3,009 actual disk inputs. Every path is bounded/relative and outside
the protected private directory. Disk mismatches are zero. Exactly two Git/raw
qualifications remain:

- Owner-maintained AGENTS: live12,047 bytes /SHA256
  `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`,
  distinct from committed8,379-byte object
  `725dd46344046bcdb802872e08fbc3cd9da0bf876e680eeba4c82dda801a9503`.
- Unchanged gradlew.bat: raw2,868 bytes /SHA256
  `8e327fcb99d29ce0fe3ee2fec6e6a25de815a2df83a6a44a553dea89ffc92955`,
  committed2,776 bytes /SHA256
  `18774a0ac0203f6893bf1db3291a0d77f06cd1b4dca2a43b51e7009da3e28cfa`;
  precisely92 CRLF expansions, with no other byte difference.

Thus the source claim is a qualified named-input boundary, not a whole-repository
Git snapshot. Six frozen C18 author postimages match the fixed commit exactly.
The independently reconstructed Source24→25 manifest delta is12 additions
(six Java/test inputs and six advancement JSON files), four changes (two central
Java files and two language resources), and zero removals. The two central source
changes are exactly the provider/translation registrations in
[CENTRAL-DIFF-02.txt](CENTRAL-DIFF-02.txt).

## Independently measured completed checks

| Executed Root cohort | Observed result |
|---|---|
| clean/build/test/runData | exit0 /178.700430s; raw BUILD SUCCESSFUL |
| fresh JUnit XML |1,785 testcase elements /333 suites /0 failures,errors,skips |
| full GameTest | exit0 /242.148896s;467 complete and all467 required passed in raw/latest/debug logs |
| repeated DataGen | written0; cache log total777 /old777 /new778 /removed0 |
| ten scoped static commands | eight exit0; content closure1 and dirty diff1 retained as failures |

[XML counts](XML-COUNTS-02.json) check each testcase against its suite counters;
[final facts](FINAL-FACTS-02.json) bind all333 suite timestamps within the actual
committed command window (UTC13:54:23.415668 start,13:54:55–13:57:05 suite stamps).
Raw runtime logging uses local+08:00. The earlier development-only integrated
run is separate:12 tests /2 suites /0FES and initial DataGen written8. Its command
receipt has no start timestamp, so a start-window freshness proof is explicitly
unavailable; it is not relabelled as committed full-build evidence.

[Command observations](COMMAND-OBSERVATIONS-02.json) verify raw log hashes against
the retained results, each static command against its command receipt, and exact
static log hashes. The full command includes actual clean/test execution but
compile tasks report FROM-CACHE; no clean compiler-cache claim is made. All
recorded Required-Gate flags remain false. Source24's45 repository checks were
not rerun for Source25 and are not borrowed here.

## Archive/source/resource reconstruction

Actual artifacts:

| Artifact | Bytes | SHA256 |
|---|---:|---|
| main |5,465,573 | `61c5499318dcd17d929acd9f3d28ab1e99066ba2c29da1de34603096f10f3921` |
| sources |2,633,856 | `f7135fc6243581d5e1fc0214ef2ddffe572f0dbfcc04d85d094149330d069a1c` |
| API |51,045 | `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da` |

[Raw archive delta](ARCHIVE-DELTA-02.json) derives sets from actual bytes without
the Root collectors' allowlists. All six old/new archives have valid CRCs, safe
member names and no duplicate payload members. Counts below exclude directory
entries, rather than implying a changed payload count from ZIP directory records:

- Main:3,028→3,040 files;12 additions, five changes, no removals;3,023 old member
  payloads unchanged. Additions are six advancement JSON files and six classes.
  Changes are two language JSONs, two central classes and the existing provider's
  compiler-generated `$1.class`.
- Sources:2,382→2,392 files;ten additions, four changes, no removals;2,378 old
  payloads unchanged. Additions are six JSONs and four production Java sources;
  changes are two central Java sources and two language JSONs.
- API:35 files unchanged, with the entire JAR byte-identical to Source24.

All1,217 main Java source objects equal their sources-JAR member bytes. All777
current v1.8 generated resource inputs equal both main and sources members.
Across historical generated roots,1,172 named inputs include26 intentionally
superseded nonmatching inputs;1,146 distinct matching packaged members remain.
Their complete relationships are recorded in [resource mapping](RESOURCE-MAPPING-02.json),
not silently normalized into equality. All older packaged resources and art
are unchanged except the two known language resources; each retains its176
existing key/value pairs and adds exactly12 title/description keys.

Direct classfile parsing (no Java/javap) binds every added/changed class to its
SourceFile and exact source object. All use class major61. The new
`V180ClassicAdvancementLanguage$1.class` is ACC_SYNTHETIC with the Goal switch
map and `<clinit>`, consistent with its exact source enum switch. The existing
`V180LanguageProvider$1.class` has identical constant pool order, opcode bytes,
exception table and other attributes across the old/new packaged classes. Its
only change is LineNumberTable entries127→128 and115→116, matching the inserted
registration line; [synthetic line evidence](SYNTHETIC-LINE-DELTA-02.json) records
this explicitly. Forge reobfJar executed in the build log; raw javac output
equality is neither required nor used as archive/source identity proof.

## Actual auditor commands and retained failures

All helpers/results remain in this small external D-drive folder. Python uses
`-B`; TEMP/TMP/TMPDIR are process-local under its tmp subdirectory. No Java,
Gradle, server, network, source/Git write, world inspection or deletion occurred.

| Auditor command | Actual result |
|---|---|
| intake.py | exit0;388 named external pins, required governance read |
| audit01.py | exit1;my overbroad equality assumption at historical pickaxe resource; original helper/log retained |
| audit02.py | exit0;explicit historical resource relationships plus full archive/XML/log/source comparison |
| controls.py |8 independent tests,0FES;0.281s unittest time |
| facts03.py | exit1;earlier development command lacks started_utc; original KeyError preserved |
| facts04.py | exit0;absence qualified, committed freshness and synthetic line/source facts bound |

Read-only git show/cat-file/diff commands are recorded in the companion JSONs.
Independent controls reject forged XML totals/hidden failures, wrong logger,
duplicate/conflicting GameTest completions and unmapped compiler classes. The
collector GBK/allowlist/compiled-byte failures are separately preserved Root
tool-return observations, not archived stderr logs; no absent raw log is invented.

## Limits and recommended disposition

The named committed C18 build/JUnit/GameTest/DataGen/artifact evidence can be
recorded with the explicit raw/Git and collector qualifications above. Source
review remains the previously separate six-file/two-line review; this audit does
not replace it or prove source/runtime behavior outside the measured tests.

Unrun here: independent Java/native replay, actual client/GPU/peer tutorial
interaction, restarted-player native observations, full Source25 repository
validation, physical hatch/GuardTicket/lifecycle work, arbitrary-crash recovery,
R-021 closure and all v1.8 Required Gates. Do not publish an all-version PASS or
reuse earlier native/Source24 successes. The minimal safe publication action is
to append this qualified audit identity while retaining every failed collector
and open Gate; remaining execution should stay within current v1.8 scope.
