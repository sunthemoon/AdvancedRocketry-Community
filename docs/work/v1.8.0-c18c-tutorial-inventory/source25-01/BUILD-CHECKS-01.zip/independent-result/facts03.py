from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import zipfile
from datetime import datetime, timedelta, timezone

src = Path(__file__).with_name('audit01.py').read_text(encoding='utf-8')
exec(compile(src[:src.index('assert all(')], 'audit01.py (definitions only)', 'exec'))


def detailed(raw):
    offset = 8
    def take(n):
        nonlocal offset
        assert offset + n <= len(raw)
        value = raw[offset:offset+n]; offset += n
        return value
    def u1(): return int.from_bytes(take(1), 'big')
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    count = u2(); cp = [None] * count; index = 1
    while index < count:
        kind = u1()
        if kind == 1: cp[index] = (kind, take(u2()).decode('utf-8', errors='replace'))
        elif kind in (3,4): cp[index] = (kind, take(4).hex())
        elif kind in (5,6): cp[index] = (kind, take(8).hex()); index += 1
        elif kind in (7,8,16,19,20): cp[index] = (kind, u2())
        elif kind in (9,10,11,12,17,18): cp[index] = (kind, u2(), u2())
        elif kind == 15: cp[index] = (kind, u1(), u2())
        else: raise AssertionError(kind)
        index += 1
    def text(index): return cp[index][1]
    def resolve(index):
        value = cp[index]; kind = value[0]
        if kind in (1,3,4,5,6): return value
        if kind in (7,8,16,19,20): return kind, resolve(value[1])
        if kind in (9,10,11,12): return kind, resolve(value[1]), resolve(value[2])
        return value
    access, this, superclass = u2(),u2(),u2()
    interfaces = take(u2()*2)
    def attributes():
        return [(text(u2()), take(u4())) for _ in range(u2())]
    fields = []
    for _ in range(u2()):
        fields.append((u2(),text(u2()),text(u2()),attributes()))
    methods = []
    for _ in range(u2()):
        flags,name,descriptor = u2(),text(u2()),text(u2()); attrs = attributes()
        code = next((data for key,data in attrs if key == 'Code'), None)
        if code:
            stack,locals_,size = struct.unpack('>HHI', code[:8]); bytecode = code[8:8+size]
            p = 8+size; exceptions = int.from_bytes(code[p:p+2], 'big'); p += 2
            exception_bytes = code[p:p+8*exceptions]; p += 8*exceptions
            attrs_count = int.from_bytes(code[p:p+2], 'big'); p += 2; subattrs = []
            for _ in range(attrs_count):
                key = text(int.from_bytes(code[p:p+2],'big')); length = int.from_bytes(code[p+2:p+6],'big'); p += 6
                data = code[p:p+length]; p += length
                item = {'name': key, 'pin': pin(data)}
                if key == 'LineNumberTable':
                    item['entries'] = [list(struct.unpack('>HH',data[n:n+4])) for n in range(2,len(data),4)]
                subattrs.append(item)
            assert p == len(code)
            methods.append({'name': name, 'descriptor': descriptor, 'bytecode': pin(bytecode),
                            'stack':stack,'locals':locals_, 'exceptions':pin(exception_bytes), 'subattributes':subattrs})
    attributes()
    assert offset == len(raw)
    return {'constant_pool_order': [resolve(i) for i in range(1,count) if cp[i]], 'methods':methods}


base_name = 'advancedrocketry-community-1.20.1-1.8.0-dev.jar'
member = 'io/github/sunthemoon/advancedrocketrycommunity/datagen/V180LanguageProvider$1.class'
with zipfile.ZipFile(PRIOR / 'artifacts-01' / base_name) as old, zipfile.ZipFile(INPUT / 'artifacts-01' / base_name) as actual:
    a,b = detailed(old.read(member)), detailed(actual.read(member))
    assert a['constant_pool_order'] == b['constant_pool_order']
    assert len(a['methods']) == len(b['methods']) == 1
    assert a['methods'][0]['bytecode'] == b['methods'][0]['bytecode']
    assert a['methods'][0]['exceptions'] == b['methods'][0]['exceptions']
    diffs = []
    for oldattr,newattr in zip(a['methods'][0]['subattributes'], b['methods'][0]['subattributes']):
        if oldattr != newattr: diffs.append({'old':oldattr,'new':newattr})
    assert [row['old']['name'] for row in diffs] == ['LineNumberTable']
    write('SYNTHETIC-LINE-DELTA-01.json', {'member':member,'constant_pool_equal':True,
          'bytecode_equal':True,'exception_table_equal':True,'diff':diffs,
          'source_line_shift_not_new_functionality':True})

resource = read_json(OUT / 'RESOURCE-MAPPING-02.json')
current = [row for row in resource['generated_input_relations'] if row['path'].startswith('src/generated/v1.8/resources/')]
assert len(current) == 777 and all(row['equal'] for row in current)
distinct_generated = len({row['member'] for row in resource['generated_input_relations'] if row['equal']})
source_diff = git('diff', 'a385ba452ab756b5689a1cbf21e2177129b93dc9', COMMIT, '--',
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/BootstrapDataGenerators.java',
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/V180LanguageProvider.java')
(OUT / 'CENTRAL-DIFF-01.txt').write_bytes(source_diff)
xml = read_json(OUT / 'XML-COUNTS-02.json')
freshness = []
for row in xml['audits']:
    label = 'full-build-01' if row['folder']=='junit-01' else 'integrated-data-01'
    command = read_json(INPUT / (label+'.command.json')); result = read_json(INPUT / (label+'.result.json'))
    start = datetime.fromisoformat(command['started_utc']); end = start + timedelta(seconds=result['elapsed_seconds'])
    timestamps = [datetime.fromisoformat(suite['timestamp']).replace(tzinfo=timezone.utc) for suite in row['suites']]
    assert all(start <= stamp <= end for stamp in timestamps)
    assert row['counts'] == row['collector']
    freshness.append({'command':label,'suite_count':len(timestamps),'first_timestamp':min(timestamps).isoformat(),
                      'last_timestamp':max(timestamps).isoformat(),'all_within_recorded_command':True,
                      'timestamp_qualification':'Gradle XML timestamps interpreted as UTC; raw runtime log uses local +08:00'})
publication = read_json(INPUT / 'SOURCE-PUBLICATION-01.json')
assert publication['tested_commit'] == COMMIT
assert all(item['exit']==0 for item in publication['commands'] if item['command'][0]=='git')
write('FINAL-FACTS-01.json', {'current_v18_generated':777,'current_generated_equal_main_sources':True,
      'generated_equal_distinct_members':distinct_generated,'historical_input_nonmatching':26,
      'xml_freshness':freshness,'source_publication_git_commands_exit0':True,
      'native_client_gates_not_audited':True})
print(json.dumps(read_json(OUT / 'FINAL-FACTS-01.json')))
