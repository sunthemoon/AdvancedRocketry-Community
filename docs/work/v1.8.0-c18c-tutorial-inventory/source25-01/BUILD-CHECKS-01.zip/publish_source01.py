"""Publish only the reviewed tutorial integration and its checkpoint docs."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
sys.path.insert(0, str(ROOT))
from scripts import validate_repository as validator


def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


manifest = json.loads((OUT / 'C18-REVIEWED-SOURCE-MANIFEST-01.json').read_text())
author = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-author-83b6107d4f/SOURCE-MANIFEST-01.json').read_text())
scope = [row['path'] for row in author['own']]
scope += [
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/BootstrapDataGenerators.java',
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/V180LanguageProvider.java',
    'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/en_us.json',
    'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/zh_cn.json',
]
scope += json.loads((OUT / 'C18-INTEGRATION-POSTCHECK-01.json').read_text())['new_advancements']
scope += [
    'docs/work/v1.8.0-c18c-tutorial-inventory/TASK.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/SOURCE-INTEGRATION-01.md',
    'docs/status/COMPLETION-PLAN.md', 'docs/status/CURRENT_VERSION.md',
    'docs/work/v1.8.0-implementation-log.md',
]
assert len(scope) == 21 and len(set(scope)) == 21
assert not any('AGENTS.md' in name or 'NATIVE-TASK' in name for name in scope)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == '73fc017ac3b121b34216e660e66b0cb583ff289a'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
for name, expected in manifest.items():
    assert pin((ROOT / name).read_bytes()) == expected, name
agents = pin((ROOT / 'AGENTS.md').read_bytes())
assert agents == {'bytes': 12047, 'sha256': '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'}
native = pin((ROOT / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-01.md').read_bytes())
assert native['sha256'] == '5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a'
owned = {name: pin((ROOT / name).read_bytes()) for name in scope}
paths = sorted(set(validator.tracked_markdown_files(ROOT)) |
               {ROOT / name for name in scope if name.endswith('.md')})
assert not any('AdvancedRocketry-Community-v1plus-Development-Docs' in path.parts for path in paths)
errors, links = validator.markdown_link_errors(ROOT, paths)
assert not errors, errors
commands = []
receipt = OUT / 'SOURCE-PUBLICATION-01.json'
assert not receipt.exists()


def run(command, expected=0):
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = result.stdout.decode('utf-8', errors='replace')
    print(output, end='', flush=True)
    commands.append({'command': command, 'exit': result.returncode, 'output': output})
    assert result.returncode == expected, command
    return result.stdout


try:
    run([sys.executable, '-B', 'scripts/validate_v1plus_planning.py'])
    run([sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
    run([sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--closure'], expected=1)
    run(['git', 'diff', '--check'])
    run(['git', 'add', '--'] + scope)
    assert set(run(['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == set(scope)
    for name, expected in owned.items():
        assert pin(subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT)) == expected, name
    run(['git', 'diff', '--cached', '--stat'])
    run(['git', 'diff', '--cached', '--check'])
    run(['git', 'commit', '-m', 'feat(progression): add inventory tutorial advancements'])
    head = run(['git', 'rev-parse', 'HEAD']).decode().strip()
    run(['git', 'push', 'origin', 'HEAD:refs/heads/codex/v1.8.0-classic-content'])
    assert run(['git', 'rev-parse', 'refs/remotes/origin/codex/v1.8.0-classic-content']).decode().strip() == head
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
    run(['git', 'diff', '--exit-code', '--', 'src/generated'])
    for name, expected in manifest.items():
        assert pin((ROOT / name).read_bytes()) == expected, name
    assert pin((ROOT / 'AGENTS.md').read_bytes()) == agents
    assert pin((ROOT / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-01.md').read_bytes()) == native
finally:
    receipt.write_bytes((json.dumps({'scope': scope, 'owned_pins': owned,
        'named_inputs': len(manifest), 'commands': commands,
        'markdown_files': len(paths), 'markdown_links': links, 'markdown_errors': errors,
        'source_only': True, 'required_gates_passed': False}, indent=2, sort_keys=True) + '\n').encode())
