# Source25 collector observations

The ten static commands in run_static01.py completed with their actual expected
statuses: eight exit 0, content closure and global dirty diff exit 1. Those
nonzero commands remain failures, not release acceptance.

The collector then exited 1 because its exact member allowlist omitted the new
javac enum-switch helper V180ClassicAdvancementLanguage$1.class. Its source has
an enum switch; the archived class is byte-identical to the compiled output
and names the corresponding Goal switch map. The original runner, command
results and artifact are unchanged. artifact_audit02.py checks a new exact
allowlist with this one explicit member, all old-member bytes, singleton/CRC
integrity, reviewed source input pins and the unchanged API. No source repair,
new build, broader unknown-member acceptance or assertion budget change occurs.

An earlier read command requested nonexistent RESULT-01.json instead of the
actual integrated-data-01.result.json; Get-Content reported that exact missing
locator. A separate correct read used the actual retained result. It is not a
failed Gradle command or replaced evidence.
