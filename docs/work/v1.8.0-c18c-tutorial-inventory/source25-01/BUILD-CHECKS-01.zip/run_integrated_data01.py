"""Verify reviewed postimages and run actual integrated tutorial DataGen."""
import hashlib
import json
import os
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-author-83b6107d4f')
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-observation-04')
TEMP = OUT / 'tmp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()


def pin(file):
    return {'bytes': file.stat().st_size, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


author = json.loads((AUTHOR / 'SOURCE-MANIFEST-01.json').read_text(encoding='utf-8'))
own = {row['path']: {'bytes': row['bytes'], 'sha256': row['sha256']} for row in author['own']}
assert len(own) == 6
for name, row in own.items():
    assert pin(ROOT / name) == row, name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == '73fc017ac3b121b34216e660e66b0cb583ff289a'
old = json.loads((OLD / 'SOURCE24-MANIFEST-01.json').read_text(encoding='utf-8'))
central = ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/BootstrapDataGenerators.java',
           'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/datagen/V180LanguageProvider.java']
for name, row in old.items():
    assert name in central or pin(ROOT / name) == row, name
stat = subprocess.check_output(['git', 'diff', '--numstat', '--'] + central, cwd=ROOT).decode().splitlines()
assert set(stat) == {'1\t0\t' + name for name in central}
before = {name: json.loads((ROOT / name).read_text(encoding='utf-8')) for name in old
          if name.startswith('src/generated/v1.8/resources/') and '/lang/' in name}
assert len(before) == 2
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
command = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
           '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix(),
           'test', '--tests', '*.ClassicInventoryAdvancementsTest',
           '--tests', '*.ClassicInventoryAdvancementResourcesTest', 'runData']
write('integrated-data-01.command.json', {'command': command, 'cwd': str(ROOT),
    'source_status': 'Reviewed uncommitted integration; development intermediate only',
    'base_commit': '73fc017ac3b121b34216e660e66b0cb583ff289a', 'free_bytes': free,
    'process_TEMP_TMP_TMPDIR': str(TEMP), 'process_JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
start = time.monotonic()
with (OUT / 'integrated-data-01.log').open('xb') as output:
    result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
write('integrated-data-01.result.json', {'exit': result.returncode,
    'elapsed_seconds': time.monotonic() - start, 'log': pin(OUT / 'integrated-data-01.log')})
assert result.returncode == 0, result.returncode
xml = OUT / 'integrated-data-01-xml'
xml.mkdir()
summary = {'suites': 0, 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
for file in sorted((ROOT / 'build/test-results/test').glob('TEST-*ClassicInventoryAdvancement*.xml')):
    shutil.copyfile(file, xml / file.name)
    suite = ET.parse(file).getroot()
    summary['suites'] += 1
    for key in ('tests', 'failures', 'errors', 'skipped'):
        summary[key] += int(suite.attrib[key])
assert summary == {'suites': 2, 'tests': 12, 'failures': 0, 'errors': 0, 'skipped': 0}, summary
write('INTEGRATED-JUNIT-01.json', summary)
suffixes = ['root', 'block_press', 'rolling', 'electrolysis', 'suited_up', 'warp_core']
items = [['minecraft:crafting_table'], ['advancedrocketrycommunity:small_plate_press'],
         ['advancedrocketrycommunity:rolling_machine'], ['advancedrocketrycommunity:electrolyzer'],
         ['advancedrocketrycommunity:space_suit_' + piece for piece in ('helmet', 'chestplate', 'leggings', 'boots')],
         ['advancedrocketrycommunity:warp_core']]
new = []
for suffix, targets in zip(suffixes, items):
    name = 'src/generated/v1.8/resources/data/advancedrocketrycommunity/advancements/classic/' + suffix + '.json'
    data = json.loads((ROOT / name).read_text(encoding='utf-8'))
    assert data['requirements'] == [['has_inventory']] and data['rewards'] == {}
    assert data['criteria'] == {'has_inventory': {'trigger': 'minecraft:inventory_changed',
        'conditions': {'items': [{'items': [target]} for target in targets]}}}, name
    new.append(name)
keys = {'advancement.advancedrocketrycommunity.classic.' + suffix + '.' + kind
        for suffix in suffixes for kind in ('title', 'description')}
for name, previous in before.items():
    actual = json.loads((ROOT / name).read_text(encoding='utf-8'))
    assert set(actual) - set(previous) == keys, name
    assert all(actual[key] == value for key, value in previous.items()), name
    assert all(isinstance(actual[key], str) and actual[key].strip() for key in keys)
for name, row in old.items():
    assert name in central or name in before or pin(ROOT / name) == row, name
for name, row in own.items():
    assert pin(ROOT / name) == row, name
source = dict(old)
source.update({name: pin(ROOT / name) for name in central + list(before) + new})
source.update(own)
assert len(source) == 3009, len(source)
generated = {name: row for name, row in source.items() if name.startswith('src/generated/v1.8/resources/')}
assert len(generated) == 777
write('C18-REVIEWED-SOURCE-MANIFEST-01.json', source)
write('C18-INTEGRATION-POSTCHECK-01.json', {'named_inputs': len(source), 'source_status': 'Uncommitted development check',
    'generated_v18_files': len(generated), 'new_advancements': new, 'language_changes': list(before),
    'old_keys_unchanged': True, 'reviewed_source_unchanged': True,
    'actual_registered_GameTests': 'NOT_RUN', 'native_restart': 'NOT_RUN', 'required_gates_passed': False})
print(json.dumps({'gradle_exit': result.returncode, 'junit': summary,
                  'generated_v18_files': len(generated), 'named_inputs': len(source)}), flush=True)
