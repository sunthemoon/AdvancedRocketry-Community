from pathlib import Path
import json, hashlib, re, collections

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
BUNDLES=[
 ('author01',AUTHOR,'EVIDENCE-MANIFEST-01.json','SHA256SUMS-01.txt','author'),
 ('author02',AUTHOR/'candidate02','EVIDENCE-MANIFEST-02.json','SHA256SUMS-02.txt','author/candidate02'),
 ('author03',AUTHOR/'candidate03','EVIDENCE-MANIFEST-03.json','SHA256SUMS-03.txt','author/candidate03'),
 ('norm',Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e'),'EVIDENCE-MANIFEST.json','SHA256SUMS.txt','norm'),
 ('review02',Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review-20261005-4a82c3'),'INTERNAL-MANIFEST-01.json','SHA256SUMS.txt','review02'),
 ('review03',Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review03-20261005-91bc2d'),'INTERNAL-MANIFEST-03.json','SHA256SUMS.txt','review03')]

def sha(b):return hashlib.sha256(b).hexdigest()
def read(base,name):
    p=Path(name)
    assert not p.is_absolute() and '..' not in p.parts and 'Development-Docs' not in name
    assert p.suffix.lower() not in ('.jar','.zip','.class','.mca','.mcc','.dat','.nbt','.png','.dll','.so')
    return (base/name).read_bytes()

result=[];origins=[];mdlinks=[];checksum_failures=[];hash_failures=[]
for label,base,mname,sname,dest in BUNDLES:
    raw=read(base,mname);manifest=json.loads(raw)
    if label=='review03':assert sha(raw)=='dfa867b88dafdf5e28d545cf39f5fcd468f2d57129ed7057e463b86424c20444'
    if label=='norm':assert sha(raw)=='2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1'
    files=manifest['files'];rows=[];names=set()
    for row in files:
        name=row['path']; b=read(base,name); names.add(name)
        if (len(b),sha(b))!=(row['bytes'],row['sha256']):hash_failures.append(label+'/'+name)
        rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
    sidecar=read(base,sname);checks=[]
    for line in sidecar.decode('utf-8-sig').splitlines():
        if not line.strip():continue
        m=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line)
        if not m:checksum_failures.append({'bundle':label,'line':line,'reason':'unparsed'});continue
        name=m[2];actual=read(base,name);checks.append(name)
        if sha(actual)!=m[1].lower():checksum_failures.append({'bundle':label,'path':name,'reason':'hash'})
    for name in sorted(names|{mname,sname}):
        b=read(base,name);origins.append({'source':str(base/name),'destination':dest+'/'+name,'bytes':len(b),'sha256':sha(b),'bundle':label})
        if name.lower().endswith('.md'):
            for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',b.decode('utf-8')):
                if '://' in link or link.startswith('#'):continue
                target=link.split('#',1)[0]
                resolved=(base/name).parent/target
                exists=resolved.is_file()
                mdlinks.append({'bundle':label,'report':name,'link':link,'source_exists':exists,
                    'resolved_source':str(resolved.resolve()),'inside_bundle':resolved.resolve().is_relative_to(base.resolve())})
    result.append({'label':label,'root':str(base),'destination':dest,'manifest':mname,'manifest_sha256':sha(raw),
                   'manifest_payloads':len(rows),'manifest_payload_bytes':sum(x['bytes'] for x in rows),
                   'sidecar':sname,'sidecar_sha256':sha(sidecar),'sidecar_entries':len(checks),
                   'sidecar_covers_all_payloads':set(names)<=set(checks),'suffixes':dict(collections.Counter(Path(x['path']).suffix for x in rows))})
out={'bundles':result,'origins':origins,'markdown_links':mdlinks,'hash_failures':hash_failures,'checksum_failures':checksum_failures,
     'selected_reference_only':'No archive/JAR/world/runtime or command execution; manifest-named thin members only.'}
(HERE/'INTAKE-01.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'bundles':len(result),'manifest_payloads':sum(x['manifest_payloads'] for x in result),'origins':len(origins),
   'hash_failures':hash_failures,'sidecar_failures':checksum_failures,'relative_links':len(mdlinks),
   'missing_links':[x for x in mdlinks if not x['source_exists']],'outside_links':[x for x in mdlinks if not x['inside_bundle']]},indent=2))
assert not hash_failures and not checksum_failures
