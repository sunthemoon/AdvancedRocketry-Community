from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
PACKET = HERE / 'packet'
old = json.loads((PACKET / 'PRESERVED-OBSERVATIONS-01.json').read_text(encoding='utf-8'))
origins = json.loads((HERE / 'INTAKE-01.json').read_text(encoding='utf-8'))['origins']
rows = []
for origin in origins:
    if not origin['destination'].endswith(('.log', '.txt')):
        continue
    raw = Path(origin['source']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == origin['sha256']
    text = raw.decode('utf-8-sig')
    for match in re.finditer(r'Ran (\d+) tests? in ([0-9.]+)s\r?\n(?:[ \t\r]*\n)+(OK(?:[^\n]*)|FAILED\s*\([^\n]*\))', text):
        rows.append({'member': origin['destination'], 'tests': int(match[1]), 'seconds': match[2],
                     'status': match[3].rstrip('\r'), 'sha256': origin['sha256']})
assert len(rows) >= len(old['raw_unittest_summaries'])
for member, tests, status in [('author/candidate02/python-02.stderr.log', 36, 'OK'),
                               ('author/candidate03/python-red-03.stderr.log', 39, 'FAILED (errors=7)'),
                               ('author/candidate03/python-green-03.stderr.log', 39, 'OK'),
                               ('review03/legacy-negative.stderr.log', 36, 'FAILED (failures=1)')]:
    assert any((r['member'], r['tests'], r['status']) == (member, tests, status) for r in rows)
obj = {'scope': old['scope'], 'raw_unittest_summaries': rows,
       'nonzero_command_receipts': old['nonzero_command_receipts'],
       'duplicated_summary_locations_are_not_added_together': True,
       'correction': 'Summary01 regex admitted CRLF summaries but missed LF-only summaries. Original raw bytes/first helper/result are preserved; this separate parser handles both without changing input.'}
(PACKET / 'PRESERVED-OBSERVATIONS-02.json').write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'raw_summary_locations': len(rows), 'nonzero_receipts': len(obj['nonzero_command_receipts']),
                  'LF_and_CRLF_controls': 'pass', 'source_changes': []}, indent=2))
