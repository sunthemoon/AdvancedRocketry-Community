from pathlib import Path
import collections
import hashlib
import json
import os
import re
import shutil

HERE = Path(__file__).resolve().parent
PACKET = HERE / 'packet'
intake = json.loads((HERE / 'INTAKE-01.json').read_text(encoding='utf-8'))
origins = intake['origins']
by_source = {str(Path(x['source']).resolve()): x for x in origins}
by_dest = {x['destination']: x for x in origins}
assert len(by_source) == len(origins) == len(by_dest)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write_json(name, obj):
    (PACKET / name).write_text(json.dumps(obj, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')

def checked(origin):
    raw = Path(origin['source']).read_bytes()
    assert (len(raw), sha(raw)) == (origin['bytes'], origin['sha256']), origin['source']
    return raw

assert not PACKET.exists(), 'fresh destination required'
PACKET.mkdir()
for origin in origins:
    dest = PACKET / origin['destination']
    assert dest.resolve().is_relative_to(PACKET.resolve())
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(checked(origin))

# Report context is preserved by a locator, not by modifying or duplicating old reports.
# The report copy must equal the original named report before its relative context is used.
contexts = {
    'review02/inputs/AUTHOR-REPORT-02.md': 'author/candidate02/REPORT-02.md',
    'review02/inputs/OWNERSHIP-PROPOSAL-03.md': 'norm/OWNERSHIP-PROPOSAL-03.md',
    'review03/inputs/OWNERSHIP-PROPOSAL-03.md': 'norm/OWNERSHIP-PROPOSAL-03.md',
    'review03/inputs/REPORT-03.md': 'author/candidate03/REPORT-03.md',
    'review03/prior-review/REVIEW-CANDIDATE02.md': 'review02/REVIEW-CANDIDATE02.md',
}
for copied, original in contexts.items():
    assert by_dest[copied]['sha256'] == by_dest[original]['sha256'], (copied, original)

def directory_destination(original_path):
    selected = [x for x in origins if Path(x['source']).resolve().is_relative_to(original_path)]
    if not selected:
        return None
    candidates = set()
    for x in selected:
        relative = Path(x['source']).resolve().relative_to(original_path)
        dest = Path(x['destination'])
        for _ in relative.parts:
            dest = dest.parent
        candidates.add(dest.as_posix())
    assert len(candidates) == 1, candidates
    return next(iter(candidates)) + '/'

links = []
for observed in intake['markdown_links']:
    bundle = next(x for x in intake['bundles'] if x['label'] == observed['bundle'])
    report_dest = bundle['destination'] + '/' + observed['report']
    original_path = Path(observed['resolved_source'])
    entry = dict(observed)
    entry['report_member'] = report_dest
    entry['source_is_file'] = original_path.is_file()
    entry['source_is_directory'] = original_path.is_dir()
    entry['portable_target'] = None
    if str(original_path) in by_source:
        entry['portable_target'] = by_source[str(original_path)]['destination']
        entry['classification'] = 'original-file-in-selected-closure'
    elif original_path.is_dir():
        entry['portable_target'] = directory_destination(original_path)
        entry['classification'] = 'original-directory-with-selected-members'
    elif report_dest in contexts:
        context_origin = by_dest[contexts[report_dest]]
        target = (Path(context_origin['source']).parent / observed['link'].split('#', 1)[0]).resolve()
        if str(target) in by_source:
            entry['portable_target'] = by_source[str(target)]['destination']
            entry['classification'] = 'byte-exact-copied-report-original-context'
        elif target.is_dir():
            entry['portable_target'] = directory_destination(target)
            entry['classification'] = 'byte-exact-copied-report-original-directory-context'
    if not entry['portable_target'] and Path(observed['link']).name in ('NATIVE-TASK-04.md', 'NATIVE-REVIEW-DISPOSITION-04.md'):
        name = Path(observed['link']).name
        selected = [x for x in origins if Path(x['destination']).name == name]
        hashes = {x['sha256'] for x in selected}
        assert len(hashes) == 1, (name, hashes)
        expected = {'NATIVE-TASK-04.md': '3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43',
                    'NATIVE-REVIEW-DISPOSITION-04.md': '8d679d97de9ff04f27880ed01071b43fccc4c66e2cac89bc20540b853d9bc28d'}[name]
        assert hashes == {expected}
        # Exact identities are stated by the immutable independent source report.
        reviewed = checked(by_dest['review03/REVIEW-CANDIDATE03.md']).decode('utf-8')
        assert expected in reviewed
        entry['portable_target'] = 'review03/inputs/' + name
        entry['classification'] = 'frozen-task-context-pinned-by-independent-report'
    if not entry['portable_target']:
        entry['classification'] = 'absent-original-companion-outside-thin-intake'
    else:
        assert (PACKET / entry['portable_target']).exists(), entry
    links.append(entry)

unresolved = [x for x in links if not x['portable_target']]
assert {Path(x['link']).name for x in unresolved} <= {'NATIVE-TASK-03.md', 'NATIVE-REVIEW-DISPOSITION-03.md', 'CONTRACT-CHECKS-01.zip'}, unresolved
write_json('COMPANION-LOCATORS-01.json', links)
md = ['# Original report companion locators', '',
      'Old reports/snapshots remain byte-exact. This table restores reading context without rewriting their Markdown.',
      'A copied-report locator is used only after matching the copied report SHA to its original source report.',
      'Task04/disposition04 targets are separately tied to the hashes stated in the frozen independent candidate03 report.',
      'Six historical ancestor/archive links remain outside the authorized thin intake; no mutable Root replacement is used.', '',
      '| Original report member | Original link | Provided exact companion / qualification |',
      '|---|---|---|']
for link in links:
    if link['classification'] == 'original-file-in-selected-closure':
        continue
    target = link['portable_target']
    provided = '[' + target + '](' + target + ')' if target else 'NOT INCLUDED: historical ancestor/archive outside intake'
    md.append('| `' + link['report_member'] + '` | `' + link['link'] + '` | ' + provided + ' |')
(PACKET / 'COMPANION-LOCATORS-01.md').write_text('\n'.join(md) + '\n', encoding='utf-8')

raw_runs = []
nonzero = []
for origin in origins:
    dest = origin['destination']
    if not dest.endswith(('.log', '.json', '.exit', '.txt')):
        continue
    text = checked(origin).decode('utf-8-sig')
    for match in re.finditer(r'Ran (\d+) tests? in ([0-9.]+)s\s+\r?\n\s*\r?\n(OK(?:[^\n]*)|FAILED\s*\([^\n]*\))', text):
        raw_runs.append({'member': dest, 'tests': int(match[1]), 'seconds': match[2], 'status': match[3], 'sha256': origin['sha256']})
    if dest.endswith('.exit'):
        code = int(text.strip())
        if code:
            nonzero.append({'member': dest, 'exit': code, 'sha256': origin['sha256']})
    elif dest.endswith('.json'):
        obj = json.loads(text)
        if isinstance(obj, dict) and isinstance(obj.get('exit'), int) and obj['exit']:
            nonzero.append({'member': dest, 'exit': obj['exit'], 'sha256': origin['sha256']})
summary = {'scope': 'collector parses preserved raw results; no test/native/command replay',
           'raw_unittest_summaries': raw_runs, 'nonzero_command_receipts': nonzero,
           'duplicated_summary_locations_are_not_added_together': True}
write_json('PRESERVED-OBSERVATIONS-01.json', summary)
for fragment, count, status in [('author/candidate03/python-red-03.stderr.log', 39, 'errors=7'),
                                 ('review03/legacy-negative.stderr.log', 36, 'failures=1')]:
    # Literal names are verified below via any original matching location; historical errors are not omitted.
    matching = [r for r in raw_runs if r['tests'] == count and status in r['status']]
    assert matching, (fragment, count, status)
assert any(x['exit'] == 2 and 'entrypoint' in x['member'] for x in nonzero)
assert any(x['exit'] == 1 and x['member'] == 'author/intake-01.exit' for x in nonzero)

hash_groups = collections.defaultdict(list)
for origin in origins:
    hash_groups[origin['sha256']].append(origin['destination'])
write_json('SOURCE-ORIGINS-01.json', {'files': origins,
    'physical_deduplication': 'none; every original selected layout and sidecar member retained',
    'same_byte_groups': [v for v in hash_groups.values() if len(v) > 1]})

# Lightweight original-input postcheck; no input changes are repaired or normalized.
for origin in origins:
    checked(origin)
    assert (PACKET / origin['destination']).read_bytes() == checked(origin)
write_json('COLLECTION-CONTROLS-02.json', {
    'selected_source_origins': len(origins), 'manifest_payloads': sum(x['manifest_payloads'] for x in intake['bundles']),
    'manifest_and_sidecar_failures': [], 'original_pre_post_drift': [], 'copy_mismatches': [],
    'relative_link_occurrences': len(links), 'provided_exact_companion_occurrences': len(links) - len(unresolved),
    'absent_original_outside_scope_occurrences': len(unresolved), 'absent_original_outside_scope': unresolved,
    'first_intake_file_only_directory_false_negatives': sum(x['source_is_directory'] and not x['source_exists'] for x in links),
    'historical_test_summary_records': len(raw_runs), 'nonzero_command_receipts': len(nonzero),
    'bundles': intake['bundles'], 'no_execution_of_sealed_helpers': True,
})
for name in ('collect_intake01.py', 'collect_intake01.log', 'collect_intake01.exit', 'INTAKE-01.json', 'collect_portable02.py'):
    out = PACKET / 'collector' / name
    out.parent.mkdir(exist_ok=True)
    shutil.copyfile(HERE / name, out)
print(json.dumps({'selected_origins': len(origins), 'links': len(links), 'provided': len(links) - len(unresolved),
                  'unresolved_external_history': len(unresolved), 'raw_summaries': raw_runs,
                  'preserved_nonzero_count': len(nonzero)}, indent=2))
