from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

HERE = Path(__file__).resolve().parent
PACKET = HERE / 'packet'
ARCHIVE = HERE / 'c18c-native-phase01-thin-collection-01.zip'
assert not ARCHIVE.exists()
def sha(b): return hashlib.sha256(b).hexdigest()
for name in ('collect-portable-02.log', 'collect-portable-02.exit', 'parse_summary03.py', 'parse-summary-03.log', 'parse-summary-03.exit', 'seal04.py'):
    shutil.copyfile(HERE / name, PACKET / 'collector' / name)
intake = json.loads((HERE / 'INTAKE-01.json').read_text(encoding='utf-8'))
original_postcheck = []
for row in intake['origins']:
    raw = Path(row['source']).read_bytes()
    if (len(raw), sha(raw)) != (row['bytes'], row['sha256']): original_postcheck.append(row['source'])
    assert (PACKET / row['destination']).read_bytes() == raw
assert not original_postcheck
assert sha((PACKET / 'review03/REVIEW-CANDIDATE03.md').read_bytes()) == '6769bc584dc3d816101c0ac0cc3272ead3fbf43df75acd244aa8ef815f31c72e'

# Validate every original nested manifest and checksum after materialization.
for bundle in intake['bundles']:
    base = PACKET / bundle['destination']
    raw = (base / bundle['manifest']).read_bytes()
    assert sha(raw) == bundle['manifest_sha256']
    for row in json.loads(raw)['files']:
        member = (base / row['path']).read_bytes()
        assert (len(member), sha(member)) == (row['bytes'], row['sha256'])
    sidecar = (base / bundle['sidecar']).read_bytes()
    assert sha(sidecar) == bundle['sidecar_sha256']
    for line in sidecar.decode('utf-8-sig').splitlines():
        if not line.strip(): continue
        match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
        assert match
        assert sha((base / match[2]).read_bytes()) == match[1].lower()

own_missing = []
for name in ('REPORT-01.md', 'COMPANION-LOCATORS-01.md'):
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (PACKET / name).read_text(encoding='utf-8')):
        assert not '://' in link and not link.startswith('/')
        if not (PACKET / link.split('#', 1)[0]).exists(): own_missing.append((name, link))
assert not own_missing
rows = []
for p in sorted(PACKET.rglob('*')):
    if not p.is_file(): continue
    name = p.relative_to(PACKET).as_posix()
    assert p.suffix.lower() not in ('.jar', '.zip', '.class', '.mca', '.mcc', '.dat', '.nbt', '.png', '.dll', '.so')
    raw = p.read_bytes()
    rows.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw)})
manifest = {'scope': 'Thin collection only; historical candidate02 1M retained; no native/driver/runtime/API/Gate admission',
            'files': rows, 'payload_count': len(rows), 'payload_bytes': sum(x['bytes'] for x in rows)}
raw = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(PACKET / 'INTERNAL-MANIFEST-01.json').write_bytes(raw)
all_rows = rows + [{'path': 'INTERNAL-MANIFEST-01.json', 'bytes': len(raw), 'sha256': sha(raw)}]
(PACKET / 'SHA256SUMS.txt').write_text(''.join(x['sha256'] + '  ' + x['path'] + '\n' for x in all_rows), encoding='utf-8')
with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(PACKET.rglob('*')):
        if not p.is_file(): continue
        info = zipfile.ZipInfo(p.relative_to(PACKET).as_posix(), (2026, 10, 5, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        z.writestr(info, p.read_bytes())
members = all_rows + [{'path': 'SHA256SUMS.txt', 'bytes': (PACKET / 'SHA256SUMS.txt').stat().st_size, 'sha256': sha((PACKET / 'SHA256SUMS.txt').read_bytes())}]
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {x['path'] for x in members}
    for row in members:
        b = z.read(row['path'])
        assert (len(b), sha(b)) == (row['bytes'], row['sha256'])
receipt = {'archive': str(ARCHIVE), 'archive_bytes': ARCHIVE.stat().st_size, 'archive_sha256': sha(ARCHIVE.read_bytes()),
           'archive_members': len(members), 'uncompressed_bytes': sum(x['bytes'] for x in members),
           'internal_manifest_sha256': sha(raw), 'checksum_sha256': sha((PACKET / 'SHA256SUMS.txt').read_bytes()),
           'report_sha256': sha((PACKET / 'REPORT-01.md').read_bytes()), 'original_source_origins': len(intake['origins']),
           'original_postcheck_drift': original_postcheck, 'CRC_failures': [], 'member_hash_failures': [],
           'new_report_and_locator_link_failures': own_missing,
           'original_links_exact_locators': 269, 'original_links_outside_scope': 6}
(HERE / 'ARCHIVE-VERIFICATION-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
(HERE / (ARCHIVE.name + '.sha256')).write_text(receipt['archive_sha256'] + '  ' + ARCHIVE.name + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
