# C18c native Python phase01 thin collection

Date: 2026-10-05. Delegated evidence collector `/root/c18_contract`.
This is packaging and integrity inspection, not an independent source verdict,
test replay, complete native fixture or version Gate admission.

## Findings / qualification

1. **Original companion closure is qualified, not universally complete.**
   Of 275 original local Markdown link occurrences, 269 have exact provided
   file/directory or context locators. Six links in copied Task04/disposition04
   point to historical Task03/disposition03 or `CONTRACT-CHECKS-01.zip`, outside
   the six authorized thin inputs. They remain explicitly NOT INCLUDED; no
   mutable Root file or recursive old archive is substituted. See the
   [machine-readable locator](COMPANION-LOCATORS-01.json) and
   [portable reading-context table](COMPANION-LOCATORS-01.md).
2. **Historical Medium and failures remain intact.** Candidate02's
   [1 Medium report](review02/REVIEW-CANDIDATE02.md) and original
   [16-test / one-error probe](review02/independent-unit.stderr.log) are not
   rewritten. Candidate03's separately bounded
   [source review](review03/REVIEW-CANDIDATE03.md) and unchanged probe green are
   preserved as distinct later observations, not substituted for older reds.

No source/runtime verdict is added by this collection. All six manifests and
checksum sidecars verify; no selected original byte drift was observed.

## Exact collection inputs

Original author root: inline provenance
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af`.
Candidate02 and candidate03 are its named `candidate02` / `candidate03`
subdirectories, not guessed top-level files. The normative proposal root and
both independent review roots are recorded literally with each file in
[source origins](SOURCE-ORIGINS-01.json).

| Bundle | Original payloads | Portable manifest |
|---|---:|---|
| Author candidate01 | 49 | [manifest01](author/EVIDENCE-MANIFEST-01.json) |
| Author candidate02 | 44 | [manifest02](author/candidate02/EVIDENCE-MANIFEST-02.json) |
| Author candidate03 | 57 | [manifest03](author/candidate03/EVIDENCE-MANIFEST-03.json) |
| Ownership / protocol proposal03 | 80 | [norm manifest](norm/EVIDENCE-MANIFEST.json) |
| Independent candidate02 | 59 | [review02 manifest](review02/INTERNAL-MANIFEST-01.json) |
| Independent candidate03 | 65 | [review03 manifest](review03/INTERNAL-MANIFEST-03.json) |

Total: 354 original manifested payloads / 2,011,118 bytes, plus six original
manifests and six original checksum sidecars, yielding 366 exact source-origin
members. All layouts are retained; there is **no physical deduplication**.
Same-byte groups are provenance-recorded only and test summaries at duplicated
locations must not be summed as independent executions.

The normative manifest is
`2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1`;
review03 manifest is
`dfa867b88dafdf5e28d545cf39f5fcd468f2d57129ed7057e463b86424c20444`;
review03 report is
`6769bc584dc3d816101c0ac0cc3272ead3fbf43df75acd244aa8ef815f31c72e`.
All hashes are actual inspected bytes; all other source identities are in the
origin ledger and [collection controls](COLLECTION-CONTROLS-02.json).

## Actual controls and preserved command observations

The collector ran only bounded Python/file checks. `TEMP`, `TMP`, `TMPDIR`
were process-local inside the new D-parent collector; Python used `-B`.
No sealed helper, author/reviewer suite or fixture CLI was re-executed.

| Collector command | Actual result |
|---|---|
| `python -B collect_intake01.py` | exit0; 6 manifests / 6 sidecars / 354 member hashes; 0 mismatch |
| `python -B collect_portable02.py` | exit0; 366 exact copies; original pre/post0 drift; 269 exact companion locators / 6 explicit external omissions |
| `python -B parse_summary03.py` | exit0; LF and CRLF raw summary controls; 17 summary locations / 15 nonzero command receipts preserved |

Raw [intake](collector/collect_intake01.log),
[portable collection](collector/collect-portable-02.log), and
[summary correction](collector/parse-summary-03.log) logs and exits are retained.
The first link intake used `is_file`, producing five directory false negatives;
the separate portable checker qualifies them as original directories. The first
summary parser missed three LF-only summary locations; its helper/output remain
intact, while [summary02](PRESERVED-OBSERVATIONS-02.json) is the separately
corrected parse. Neither observation is relabelled as an original input failure.

Important original execution observations, **not fresh collector executions**:

- Author candidate01 and candidate02 each have raw36/0 results.
- Author candidate03 new39-method suite against old source is exit1 with seven
  errors; separate green is39/0. Both raw sources/results are present.
- Independent candidate02 has original36/0 plus16/one-error, and its failed
  first static helper is preserved.
- Independent candidate03 has39/0, unchanged16/0, added8/0, but the unchanged
  old36-method negative suite is exit1 / one failure. That old assertion is not
  erased or called a current green outcome.
- Direct parsing-module CLI refusals exit2 remain explicit incomplete-driver
  boundaries. Author intake SyntaxError, normative locator/helper errors and
  normative37/three-failure red controls remain original bytes.

[Preserved raw summaries/nonzero receipts](PRESERVED-OBSERVATIONS-02.json) bind
these observations to member SHA and exact raw files. Reported author/reviewer
counts are not borrowed as new independent validation or native completion.

## Limits / rollback

Only named thin text, scripts, patches, JSON and sidecars are included. No JAR,
class body, world, NBT binary, archive recursion or runtime export is present.
Source snapshots are the explicitly reviewed phase01 modules/owned records,
not full-source trees. Original commands may mention historical absolute paths;
those command logs are provenance and are not portable execution entrypoints.

The full native Java hook, two-host driver, connected players, progression
reload, client/multiplayer proof and Required Gates remain outside this packet.
Root retains sole source/integration/acceptance/status/Git authority. The
collector changed only its own new external D directory and packet.
