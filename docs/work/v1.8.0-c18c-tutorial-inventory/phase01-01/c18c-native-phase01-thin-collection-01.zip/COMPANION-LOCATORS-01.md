# Original report companion locators

Old reports/snapshots remain byte-exact. This table restores reading context without rewriting their Markdown.
A copied-report locator is used only after matching the copied report SHA to its original source report.
Task04/disposition04 targets are separately tied to the hashes stated in the frozen independent candidate03 report.
Six historical ancestor/archive links remain outside the authorized thin intake; no mutable Root replacement is used.

| Original report member | Original link | Provided exact companion / qualification |
|---|---|---|
| `author/REPORT-01.md` | `postimages/` | [author/postimages/](author/postimages/) |
| `author/patch-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/patch-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `author/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `author/candidate02/REPORT-02.md` | `postimages/` | [author/candidate02/postimages/](author/candidate02/postimages/) |
| `author/candidate02/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/candidate02/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `author/candidate02/revision-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/candidate02/revision-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `author/candidate03/REPORT-03.md` | `postimages/` | [author/candidate03/postimages/](author/candidate03/postimages/) |
| `author/candidate03/REPORT-03.md` | `red-source/` | [author/candidate03/red-source/](author/candidate03/red-source/) |
| `author/candidate03/REPORT-03.md` | `green-source/` | [author/candidate03/green-source/](author/candidate03/green-source/) |
| `author/candidate03/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/candidate03/postimages/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `author/candidate03/revision-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `author/candidate03/revision-replay/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `review02/candidate01/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `review02/candidate01/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `review02/candidate02/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `review02/candidate02/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `../REPORT-01.md` | [author/REPORT-01.md](author/REPORT-01.md) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `postimages/` | [author/candidate02/postimages/](author/candidate02/postimages/) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `verify02.py` | [author/candidate02/verify02.py](author/candidate02/verify02.py) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `verify-02.log` | [author/candidate02/verify-02.log](author/candidate02/verify-02.log) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `verify-02.exit` | [author/candidate02/verify-02.exit](author/candidate02/verify-02.exit) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `../EVIDENCE-MANIFEST-01.json` | [author/EVIDENCE-MANIFEST-01.json](author/EVIDENCE-MANIFEST-01.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `../SHA256SUMS-01.txt` | [author/SHA256SUMS-01.txt](author/SHA256SUMS-01.txt) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `revision-check-02.command.json` | [author/candidate02/revision-check-02.command.json](author/candidate02/revision-check-02.command.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `revision-apply-02.command.json` | [author/candidate02/revision-apply-02.command.json](author/candidate02/revision-apply-02.command.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `python-02.command.json` | [author/candidate02/python-02.command.json](author/candidate02/python-02.command.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `python-02.stderr.log` | [author/candidate02/python-02.stderr.log](author/candidate02/python-02.stderr.log) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `python-02.result.json` | [author/candidate02/python-02.result.json](author/candidate02/python-02.result.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `entrypoint-refusal-02.command.json` | [author/candidate02/entrypoint-refusal-02.command.json](author/candidate02/entrypoint-refusal-02.command.json) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `entrypoint-refusal-02.stderr.log` | [author/candidate02/entrypoint-refusal-02.stderr.log](author/candidate02/entrypoint-refusal-02.stderr.log) |
| `review02/inputs/AUTHOR-REPORT-02.md` | `entrypoint-refusal-02.result.json` | [author/candidate02/entrypoint-refusal-02.result.json](author/candidate02/entrypoint-refusal-02.result.json) |
| `review02/inputs/NATIVE-REVIEW-DISPOSITION-04.md` | `native-contract04-01/CONTRACT-CHECKS-01.zip` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review02/inputs/NATIVE-TASK-04.md` | `NATIVE-TASK-03.md` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review02/inputs/NATIVE-TASK-04.md` | `NATIVE-REVIEW-DISPOSITION-03.md` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROTOCOL-DELTA-03.json` | [norm/PROTOCOL-DELTA-03.json](norm/PROTOCOL-DELTA-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-05.json` | [norm/PRIMARY-05.json](norm/PRIMARY-05.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-03.json` | [norm/PRIMARY-03.json](norm/PRIMARY-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `HOST-PRIMARY-03.json` | [norm/HOST-PRIMARY-03.json](norm/HOST-PRIMARY-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `HOST-PRIMARY-05.json` | [norm/HOST-PRIMARY-05.json](norm/HOST-PRIMARY-05.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `RECORD-PRIMARY-07.json` | [norm/RECORD-PRIMARY-07.json](norm/RECORD-PRIMARY-07.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `RECORD-PRIMARY-08.json` | [norm/RECORD-PRIMARY-08.json](norm/RECORD-PRIMARY-08.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `HANDOFF-03.md` | [norm/HANDOFF-03.md](norm/HANDOFF-03.md) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROPOSAL-03.diff` | [norm/PROPOSAL-03.diff](norm/PROPOSAL-03.diff) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROTOCOL-DELTA-03.json` | [norm/PROTOCOL-DELTA-03.json](norm/PROTOCOL-DELTA-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-JUSTIFICATION-03.json` | [norm/PRIMARY-JUSTIFICATION-03.json](norm/PRIMARY-JUSTIFICATION-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-03.json` | [norm/PRIMARY-03.json](norm/PRIMARY-03.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-05.json` | [norm/PRIMARY-05.json](norm/PRIMARY-05.json) |
| `review02/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-06.json` | [norm/PRIMARY-06.json](norm/PRIMARY-06.json) |
| `review03/before02/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `review03/before02/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `review03/candidate03/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-REVIEW-DISPOSITION-04.md` | [review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md](review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md) |
| `review03/candidate03/docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | `NATIVE-TASK-04.md` | [review03/inputs/NATIVE-TASK-04.md](review03/inputs/NATIVE-TASK-04.md) |
| `review03/inputs/NATIVE-REVIEW-DISPOSITION-04.md` | `native-contract04-01/CONTRACT-CHECKS-01.zip` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review03/inputs/NATIVE-TASK-04.md` | `NATIVE-TASK-03.md` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review03/inputs/NATIVE-TASK-04.md` | `NATIVE-REVIEW-DISPOSITION-03.md` | NOT INCLUDED: historical ancestor/archive outside intake |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROTOCOL-DELTA-03.json` | [norm/PROTOCOL-DELTA-03.json](norm/PROTOCOL-DELTA-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-05.json` | [norm/PRIMARY-05.json](norm/PRIMARY-05.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-03.json` | [norm/PRIMARY-03.json](norm/PRIMARY-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `HOST-PRIMARY-03.json` | [norm/HOST-PRIMARY-03.json](norm/HOST-PRIMARY-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `HOST-PRIMARY-05.json` | [norm/HOST-PRIMARY-05.json](norm/HOST-PRIMARY-05.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `RECORD-PRIMARY-07.json` | [norm/RECORD-PRIMARY-07.json](norm/RECORD-PRIMARY-07.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `RECORD-PRIMARY-08.json` | [norm/RECORD-PRIMARY-08.json](norm/RECORD-PRIMARY-08.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `HANDOFF-03.md` | [norm/HANDOFF-03.md](norm/HANDOFF-03.md) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROPOSAL-03.diff` | [norm/PROPOSAL-03.diff](norm/PROPOSAL-03.diff) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PROTOCOL-DELTA-03.json` | [norm/PROTOCOL-DELTA-03.json](norm/PROTOCOL-DELTA-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-JUSTIFICATION-03.json` | [norm/PRIMARY-JUSTIFICATION-03.json](norm/PRIMARY-JUSTIFICATION-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `FORCELOAD-LANGUAGE-01.json` | [norm/FORCELOAD-LANGUAGE-01.json](norm/FORCELOAD-LANGUAGE-01.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-03.json` | [norm/PRIMARY-03.json](norm/PRIMARY-03.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-05.json` | [norm/PRIMARY-05.json](norm/PRIMARY-05.json) |
| `review03/inputs/OWNERSHIP-PROPOSAL-03.md` | `PRIMARY-06.json` | [norm/PRIMARY-06.json](norm/PRIMARY-06.json) |
| `review03/inputs/REPORT-03.md` | `postimages/` | [author/candidate03/postimages/](author/candidate03/postimages/) |
| `review03/inputs/REPORT-03.md` | `python-red-03.command.json` | [author/candidate03/python-red-03.command.json](author/candidate03/python-red-03.command.json) |
| `review03/inputs/REPORT-03.md` | `python-red-03.stderr.log` | [author/candidate03/python-red-03.stderr.log](author/candidate03/python-red-03.stderr.log) |
| `review03/inputs/REPORT-03.md` | `python-red-03.result.json` | [author/candidate03/python-red-03.result.json](author/candidate03/python-red-03.result.json) |
| `review03/inputs/REPORT-03.md` | `red-source/` | [author/candidate03/red-source/](author/candidate03/red-source/) |
| `review03/inputs/REPORT-03.md` | `python-green-03.command.json` | [author/candidate03/python-green-03.command.json](author/candidate03/python-green-03.command.json) |
| `review03/inputs/REPORT-03.md` | `python-green-03.stderr.log` | [author/candidate03/python-green-03.stderr.log](author/candidate03/python-green-03.stderr.log) |
| `review03/inputs/REPORT-03.md` | `python-green-03.result.json` | [author/candidate03/python-green-03.result.json](author/candidate03/python-green-03.result.json) |
| `review03/inputs/REPORT-03.md` | `green-source/` | [author/candidate03/green-source/](author/candidate03/green-source/) |
| `review03/inputs/REPORT-03.md` | `freeze03.py` | [author/candidate03/freeze03.py](author/candidate03/freeze03.py) |
| `review03/inputs/REPORT-03.md` | `freeze-03.log` | [author/candidate03/freeze-03.log](author/candidate03/freeze-03.log) |
| `review03/inputs/REPORT-03.md` | `freeze-03.exit` | [author/candidate03/freeze-03.exit](author/candidate03/freeze-03.exit) |
| `review03/inputs/REPORT-03.md` | `revision-check-03.command.json` | [author/candidate03/revision-check-03.command.json](author/candidate03/revision-check-03.command.json) |
| `review03/inputs/REPORT-03.md` | `revision-apply-03.command.json` | [author/candidate03/revision-apply-03.command.json](author/candidate03/revision-apply-03.command.json) |
| `review03/inputs/REPORT-03.md` | `entrypoint-refusal-03.command.json` | [author/candidate03/entrypoint-refusal-03.command.json](author/candidate03/entrypoint-refusal-03.command.json) |
| `review03/inputs/REPORT-03.md` | `entrypoint-refusal-03.stderr.log` | [author/candidate03/entrypoint-refusal-03.stderr.log](author/candidate03/entrypoint-refusal-03.stderr.log) |
| `review03/inputs/REPORT-03.md` | `entrypoint-refusal-03.result.json` | [author/candidate03/entrypoint-refusal-03.result.json](author/candidate03/entrypoint-refusal-03.result.json) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `candidate02/scripts/run_v180_classic_inventory_smoke.py` | [review02/candidate02/scripts/run_v180_classic_inventory_smoke.py](review02/candidate02/scripts/run_v180_classic_inventory_smoke.py) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `candidate02/scripts/test_run_v180_classic_inventory_smoke.py` | [review02/candidate02/scripts/test_run_v180_classic_inventory_smoke.py](review02/candidate02/scripts/test_run_v180_classic_inventory_smoke.py) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `test_independent.py` | [review02/test_independent.py](review02/test_independent.py) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `INPUT-PINS-01.json` | [review02/INPUT-PINS-01.json](review02/INPUT-PINS-01.json) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `RUN-RESULTS-01.json` | [review02/RUN-RESULTS-01.json](review02/RUN-RESULTS-01.json) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `STATIC-RESULTS-01.json` | [review02/STATIC-RESULTS-01.json](review02/STATIC-RESULTS-01.json) |
| `review03/prior-review/REVIEW-CANDIDATE02.md` | `TOOL-OBSERVATIONS-01.md` | [review02/TOOL-OBSERVATIONS-01.md](review02/TOOL-OBSERVATIONS-01.md) |
