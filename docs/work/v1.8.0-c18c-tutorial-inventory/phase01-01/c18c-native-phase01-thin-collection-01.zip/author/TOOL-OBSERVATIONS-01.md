# Phase01 tool observations

These entries describe actual task tool responses. They do not create raw logs
for responses that were not captured as files or rerun errors for packaging.

1. An earlier read guessed the nonexistent proposal03 `INTERNAL-MANIFEST.json`.
   PowerShell Select-String reported the missing file. The actual metadata is
   `EVIDENCE-MANIFEST.json`; intake02 verified its exact identity and 80 payloads.
2. A bounded earlier rg filter found no JSON-count hits and returned exit1.
   A separately expanded named Python script search returned the concrete
   validator functions documented in progress/report. Neither is a test result.
3. The current directory's `intake-01.log`/exit1 preserve a Python -c quoting
   SyntaxError before any input reads or implementation write. `intake02.py`
   is a separate file-based correction with actual exit0; the failed command
   was not overwritten or counted as a successful intake.
4. One manual apply_patch progress edit failed its expected-context check.
   The tool reported `Failed to find expected lines`; no file changed. A separate
   patch with the actual context succeeded. Source postimages were frozen only
   after that successful edit. No source assertion was weakened.
5. Direct entrypoint exit2 is intentional unfinished-driver refusal. The unit
   suite's 36/0 and patch/static exit0 are separately attributed; no native
   launch or clean-stop/restart claim is inferred.
