"""Seal original candidate01 loose evidence without altering any payload."""
import hashlib
import json
import pathlib

out = pathlib.Path(__file__).parent
entries = []
for path in sorted(out.rglob("*")):
    if not path.is_file() or "process-temp" in path.relative_to(out).parts:
        continue
    assert path.name not in {"EVIDENCE-MANIFEST-01.json", "SHA256SUMS-01.txt"}
    data = path.read_bytes()
    entries.append({"path": path.relative_to(out).as_posix(), "bytes": len(data),
                    "sha256": hashlib.sha256(data).hexdigest()})
manifest = out / "EVIDENCE-MANIFEST-01.json"
assert not manifest.exists()
manifest.write_text(json.dumps({"schema": 1, "scope": "candidate01 partial implementation evidence",
                                "files": entries, "payload_count": len(entries),
                                "payload_bytes": sum(row["bytes"] for row in entries)}, indent=2) + "\n",
                    encoding="utf-8", newline="\n")
hash_manifest = hashlib.sha256(manifest.read_bytes()).hexdigest()
sums = out / "SHA256SUMS-01.txt"
assert not sums.exists()
sums.write_text("".join(row["sha256"] + "  " + row["path"] + "\n" for row in entries)
                + hash_manifest + "  EVIDENCE-MANIFEST-01.json\n", encoding="utf-8", newline="\n")
for row in entries:
    data = (out / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({"manifest_sha256": hash_manifest, "payloads": len(entries),
                  "payload_bytes": sum(row["bytes"] for row in entries),
                  "report_sha256": hashlib.sha256((out / "REPORT-01.md").read_bytes()).hexdigest()}, indent=2))
