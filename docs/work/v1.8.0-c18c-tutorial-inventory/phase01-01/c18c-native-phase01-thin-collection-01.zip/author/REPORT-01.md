# C18c Task04 phase01 implementation report

Date: 2026-10-05. Role: delegated implementer, not independent reviewer.
Integrator: Root. This is a partial source candidate, not delivered native proof.

## Scope and readiness

The four new postimages are frozen in [SOURCE-CANDIDATE-01.json](SOURCE-CANDIDATE-01.json).
The fixed registered worktree base is `d04a116e6e6001f166bbf5e8f31fb78623a6b392`,
branch `codex/v1.8.0-classic-inventory-native`. No existing tracked worktree
files, Git index, commit, source world, native file or old sealed payload were
modified. Only Root may integrate/commit. Independent source review is pending.

This phase implements pure properties/phase command/acknowledgement-payload
primitives. It does not implement the two-host runner, the four Java fixture
classes/tests, file/reparse reads, logger authority/freshness transport, record
JSON/NBT parsing, cache/ownership/receipt/player lifecycle or native listener
and reload proof. Direct invocation intentionally refuses with exit2.

## Exact source

| New path | Bytes | SHA-256 |
|---|---:|---|
| `scripts/run_v180_classic_inventory_smoke.py` | 8,176 | `dc5a5a7ab91f823958885865cf2d34609a36daadf3f59d71e00f522d99efac3b` |
| `scripts/test_run_v180_classic_inventory_smoke.py` | 14,467 | `075d25599ea17a365307026cfe7aeceef407963e1c54af19e059a74ee696b05b` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | 6,137 | `6002d468f214368fa9935220c1d4cb1a2554a5821d165edd5a7b83cb2949dbf8` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md` | 4,857 | `fcc1265c41ba052cbfcfa96a03a30f803dc79d875c551685bf0bb86b24853b8e` |

[SOURCE-01.patch](SOURCE-01.patch) is a creation-only four-file patch, 34,691 bytes,
SHA-256 `dcfecad15142757f4ed90240ea194fe47775cf4b08dc7c9d064c6f88e0056444`.
The four [postimages](postimages/) and independent empty scratch patch replay
retain exact LF bytes. No whole-source/JAR/world export or duplicate archive is
made. Rollback is removal of these four newly introduced files only, before a
dependent driver is admitted; this worker performs no rollback or Git mutation.

## Design and authority

[Intake02](INTAKE-02.json) pins 26 named governance/source/protocol inputs and
the clean branch/base. The cumulative normative protocol is
`fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc`.
Its actual `EVIDENCE-MANIFEST.json` identity is
`2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1`.
All 80 original payloads /875,858 bytes were verified. The Root Task04
disposition, not its stale proposed header or earlier Task01-03, supplies the
limited implementation authority. Old a5abc source facts do not stand in for
this worktree's actual source observations.

Production lines 95-135 parse only already-read bytes: strict UTF-8, no leading
BOM, LF/CRLF, no lone CR, no raw C0/DEL/C1, first unescaped equals, literal key
and leading-value whitespace/colon rules, exact writer escape allowlist,
duplicate decoded-key refusal and original 16,384 bytes /1,023 pairs /
2,048 string-nodes-plus-root ceilings. Unknown entries are retained. Root's
explicit 2026-10-05 interpretation includes C1; the old specification model's
C0/DEL-only predicate is not adopted as authority. Decoded escaped t/n/r/f
remain valid, distinct from raw literal controls. There is no native input
repair or claim that every native properties file satisfies this subset.

Lines 138-200 retain immutable raw bytes with actual raw SHA-256, an immutable
newly owned whole logical map and pure configured/boot/live/stopped checks.
Seed boot requires configured raw equality; reload boot requires supplied
seed-stopped raw equality. Live permits a logically identical native rewrite
only with the supplied hook hash; stopped must equal same-host live raw.
These checks do not establish real reads, receipt origin or runtime authority.
Errors use fixed codes without echoing untrusted secret values.

Lines 203-227 select the single literal seed command; reload has none. Only the
exact single/multiple English payloads parse. All fixed coordinates are
canonical integers in [-5,5]. Multiple text yields last changed ChunkPos, not
a numerical changed count. No parsed data chooses a command or proves all121
membership/loading. Full origin/order/freshness/deadline handling is unfinished.

## Deferred JSON accounting evidence

`scripts/validate_bootstrap_provenance.py:1735-1760` starts root depth at one,
counts visited value/container nodes, and checks keys' UTF-8 without counting
keys; that validator's own ceilings are depth64/nodes100000.
`scripts/collect_v002_manual_evidence.py:605-625` uses root depth one and
values/list traversal with depth64 but no node cap. Pump/Signature report
parsers enforce their own fixed shapes, not a general C18c structural count.
These are bounded named reads recorded in intake, not transplanted code or a
new contract selection. Root explicitly postponed C18c JSON structural parsing
until root depth and object-key node accounting are fixed. All external JSON
and native record/receipt admission therefore remain unimplemented.

## Actual commands and results

All Python commands use `-B` and process-local TEMP/TMP/TMPDIR under this D
evidence directory. No Java/Gradle/native/client/network or server launch ran.

- Initial inline intake exits1 with a Python quoting SyntaxError before reads:
  [raw log](intake-01.log), [exit](intake-01.exit). Corrected file-based
  [intake02 helper](intake02.py) exits0: [log](intake-02.log), [exit](intake-02.exit).
- `python -B -m unittest discover -s scripts -p test_run_v180_classic_inventory_smoke.py -v`
  exits0, **36 tests /0 failures/errors/skips**, 0.019 seconds:
  [command](python-01.command.txt), [raw log](python-01.log), [exit](python-01.exit).
  Bounded subcases include raw C0/DEL/C1 in data/comments, escapes, UTF-8 and
  byte/pair boundaries, unknown key changes, raw/logical phase distinctions,
  hash/type/phase refusals, all121 coordinates in both payload forms and
  malformed/counter/foreign/log-wrapped acknowledgement refusals.
- [freeze01 helper](freeze01.py) exits0: [log](freeze-01.log), [exit](freeze-01.exit).
  Its recorded Git reads confirm unchanged fixed HEAD and tracked content,
  exactly four owned new paths, AST compilation/import/forbidden-call checks,
  36 declared test methods and exact raw postimages. Git tracked diff0 is a Git
  content comparison, not a whole-repository raw-byte identity claim.
- Empty owned scratch `git -c core.autocrlf=false apply --no-index --check` and
  actual apply both exit0: [check](patch-check-01.command.json),
  [apply](patch-apply-01.command.json). All four replay hashes equal postimages.
- Real direct entrypoint exits2 with only the incomplete-driver message:
  [command](entrypoint-refusal-01.command.json),
  [stderr](entrypoint-refusal-01.stderr.log), [exit](entrypoint-refusal-01.exit).
  This is expected incomplete-driver refusal, not a native failure relabelled.
- All 26 named raw input pre/post pins and four final source pins match.
  No JSON/node convention, counter interpretation or budget was loosened.

An earlier read-only guessed `INTERNAL-MANIFEST.json` locator was missing, then
corrected to the actual metadata above. One apply_patch progress-edit context
mismatch changed nothing and was corrected. These tool transcript errors are
preserved in [tool observations](TOOL-OBSERVATIONS-01.md), not invented raw logs
or rerun failures. All previous analyzer/native failures remain outside this
new partial source candidate and unchanged.

## Remaining work and risks

The module name does not imply an executable smoke runner: it deliberately
cannot do so. A future implementation must prove bounded raw file reads,
fixed-path/reparse/ownership intake, exact JSON convention, source/host selection,
server-thread/console/opt-in authority, both identities' complete pre-constructor
collision and loaded envelope gates, current-source native fields, actual
ordinary inventory listener, strict timestamp/native record reload, attempt-all
owned disposal and driver clean-stop receipt. Native deadlines, clean stops,
unknown ERROR/FATAL refusal and loaded/membership oracles are unexecuted here,
not waived. No crash proof, normal-server/client, physical API, ledger or
whole-version Required Gate is satisfied by these pure tests.

Root can assign an independent source reviewer using the exact creation patch
and postimages. Future C18c work remains within the adopted Task04 and must not
silently reuse dirty host fixtures, original player records or old facts as new
source/runtime proof. No central integration is required for this partial pure
module; future hook registration is separately Root-owned.
