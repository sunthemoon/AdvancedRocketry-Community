"""Freeze the four new postimages; no Git index or repository writes."""
import ast
import difflib
import hashlib
import json
import pathlib
import subprocess
import sys

OUT = pathlib.Path(__file__).parent
ROOT = pathlib.Path("D:/GitHub/arce-v180-c18c-native-20261005")
OWN = (
    "scripts/run_v180_classic_inventory_smoke.py",
    "scripts/test_run_v180_classic_inventory_smoke.py",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md",
)


def pin_bytes(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def pin_file(path):
    return pin_bytes(path.read_bytes())


def command(name, args, cwd):
    result = subprocess.run(args, cwd=cwd, capture_output=True, encoding="utf-8")
    (OUT / (name + ".command.json")).write_text(
        json.dumps({"args": args, "cwd": str(cwd)}, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    (OUT / (name + ".stdout.log")).write_text(result.stdout, encoding="utf-8", newline="\n")
    (OUT / (name + ".stderr.log")).write_text(result.stderr, encoding="utf-8", newline="\n")
    (OUT / (name + ".exit")).write_text(str(result.returncode) + "\n", encoding="ascii", newline="\n")
    return result


intake = json.loads((OUT / "INTAKE-02.json").read_text(encoding="utf-8"))
drift = [path for path, expected in intake["input_pins"].items()
         if pin_file(pathlib.Path(path)) != expected]
assert not drift, drift
head = command("head-postcheck-01", ["git", "rev-parse", "HEAD"], ROOT)
assert head.returncode == 0 and head.stdout.strip() == intake["fixed_base"]
tracked = command("tracked-diff-01", ["git", "diff", "--exit-code", "HEAD", "--"], ROOT)
assert tracked.returncode == 0
others = command("owned-scope-01", ["git", "ls-files", "--others", "--exclude-standard"], ROOT)
assert others.returncode == 0 and set(others.stdout.splitlines()) == set(OWN)
records = {}
patch_parts = []
for relative in OWN:
    data = (ROOT / relative).read_bytes()
    assert b"\r" not in data and data.endswith(b"\n"), relative
    records[relative] = pin_bytes(data)
    postimage = OUT / "postimages" / relative
    postimage.parent.mkdir(parents=True, exist_ok=True)
    assert not postimage.exists()
    postimage.write_bytes(data)
    patch_parts.extend(difflib.unified_diff(
        [], data.decode("utf-8").splitlines(keepends=True),
        fromfile="/dev/null", tofile="b/" + relative, lineterm="\n"
    ))
patch = OUT / "SOURCE-01.patch"
assert not patch.exists()
patch.write_bytes("".join(patch_parts).encode("utf-8"))
replay = OUT / "patch-replay"
assert not replay.exists()
replay.mkdir()
check = command("patch-check-01", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", "--check", str(patch)], replay)
assert check.returncode == 0
apply = command("patch-apply-01", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", str(patch)], replay)
assert apply.returncode == 0
for relative, expected in records.items():
    assert pin_file(replay / relative) == expected
production = ast.parse((ROOT / OWN[0]).read_text(encoding="utf-8"))
tests = ast.parse((ROOT / OWN[1]).read_text(encoding="utf-8"))
imports = {node.names[0].name for node in ast.walk(production) if isinstance(node, ast.Import)}
assert imports == {"hashlib", "re", "sys"}, imports
assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
               and node.func.id in {"open", "eval", "exec", "input", "__import__"}
               for node in ast.walk(production))
assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and node.func.attr in {"read_bytes", "write_bytes", "write_text", "Popen", "run", "system", "unlink"}
               for node in ast.walk(production))
methods = [node.name for node in ast.walk(tests)
           if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
assert len(methods) == 36
compile(production, OWN[0], "exec")
compile(tests, OWN[1], "exec")
refusal = command("entrypoint-refusal-01", [sys.executable, "-B", str(ROOT / OWN[0])], ROOT)
assert refusal.returncode == 2 and not refusal.stdout
assert "driver are not implemented" in refusal.stderr
post_drift = [path for path, expected in intake["input_pins"].items()
              if pin_file(pathlib.Path(path)) != expected]
assert not post_drift
for relative, expected in records.items():
    assert pin_file(ROOT / relative) == expected
result = {
    "schema": 1, "fixed_base": intake["fixed_base"], "branch": intake["branch"],
    "files": records, "creation_patch": pin_file(patch), "postimage_replay_mismatches": [],
    "named_input_pre_post_mismatches": [], "named_inputs": len(intake["input_pins"]),
    "tracked_git_diff_exit": tracked.returncode,
    "tracked_git_diff_qualification": "Git content comparison, not raw whole-repository identity; exact raw hashes cover the named inputs separately",
    "owned_new_paths": sorted(OWN), "test_methods": len(methods),
    "scope": "pure bytes/maps/binding/command/acknowledgement-payload primitives only",
    "entrypoint_refusal_exit": refusal.returncode,
    "java_native_world_receipt_writes": False,
    "deferred": ["JSON depth/key/node accounting", "bounded file/reparse reads", "console origin/freshness transport",
                 "four Java fixture classes/tests", "two-host driver", "native records/ownership/cache/cleanup"],
}
(OUT / "SOURCE-CANDIDATE-01.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
