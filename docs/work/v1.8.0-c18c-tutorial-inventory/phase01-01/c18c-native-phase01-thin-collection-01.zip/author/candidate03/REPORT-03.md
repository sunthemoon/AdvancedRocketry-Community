# Inventory fixture phase01 candidate03 handoff

Date: 2026-10-05. Role: delegated source author. Integrator: Root.
Independent source review remains required; no native driver is implemented.

## Completed narrow correction

Root's 2026-10-05 task message explicitly interprets test-owned properties
`blank_lines` as empty physical lines or lines consisting only of ASCII space
U+0020. TAB/form-feed/NBSP/other Unicode whitespace are not admitted as blank.
LF/CRLF delimiters, raw C0/DEL/C1 refusal and supported decoded escapes remain
unchanged. Comments require initial #/!; indented comments stay unsupported.
The interpretation resolves candidate02's reported boundary; the old prototype
and old empty-only assertion are not used as normative authority.

Candidate03 adds exactly one `all(char == " " for char in line)` alternative
to the existing blank/comment condition, **after** unchanged raw control refusal.
No file or raw-byte rewriting, data trim, default insertion or canonical hash
is introduced. All unknown property entries, duplicate/escape rules, caps,
phase/raw/live/stopped bindings, fixed commands and acknowledgement grammar
remain unchanged. The public code/CLI does not reproduce the Root conversation.

Only the old `b" "` negative subcase is removed under that explicit clarification.
All 36 original methods remain; their assertion bodies are AST-identical after
that single authorized tuple-item removal. Three new methods cover ASCII-only
blank lines, nonblank whitespace/indented comments and data preservation, and
raw hash differences versus logical equality. The hash test still requires
seed-boot and same-host stopped bindings to refuse logically equal but
raw-different inputs. No other assertion or budget is relaxed.

## Exact source and patch pins

Fixed registered worktree is `D:/GitHub/arce-v180-c18c-native-20261005`, branch
`codex/v1.8.0-classic-inventory-native`, committed base
`d04a116e6e6001f166bbf5e8f31fb78623a6b392`. Only the four declared new files
exist; no tracked source, Root/central, Git index, old sealed evidence, config,
world or native record is written.

| New path | Candidate03 bytes | SHA-256 |
|---|---:|---|
| `scripts/run_v180_classic_inventory_smoke.py` | 8,205 | `dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56` |
| `scripts/test_run_v180_classic_inventory_smoke.py` | 16,081 | `4a24f52fa245b677b129e7247de554e7ac83f58b121eae7725e2b922a51cdfb7` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | 9,475 | `9918bd7b3a8ec2cc36b5610b99efeb884f4d87a1ec3f8297b3b6513a9ada8a29` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md` | 6,694 | `f7378241f061caedf8df5a37c4412882e79df5d638b80bf7fc3a1b88169032c6` |

[SOURCE-CANDIDATE-03.json](SOURCE-CANDIDATE-03.json) binds exact before/after
postimages, observed red/green cuts, AST comparisons and qualifications.
[SOURCE-03.patch](SOURCE-03.patch) creates the four new files, 41,617 bytes,
SHA-256 `8130cc94cc00f3e7a87c9b87bec1797735983d85c4101f5b40406a6ce356cc3c`.
[REVISION-03.patch](REVISION-03.patch) is the candidate02-to03 comparison,
10,128 bytes, SHA-256
`a7241baba5280465499dda7ecc19544d640cb216bfa724cd22029c1a2ddf519a`.
Four exact [postimages](postimages/) and bounded Python red/green inputs are
retained; no whole-source/JAR/world export or archive is made.

## Actual red/green and static checks

- New 39-method tests executed against unchanged candidate02 production,
  exit1, **seven error records /0 assertion failures**, unittest0.023s,
  subprocess0.12189289997331798s. Five positive blank-line subcases and two
  method-level errors report `PROPERTIES_SEPARATOR`:
  [command](python-red-03.command.json), [full raw log](python-red-03.stderr.log),
  [source-bound result](python-red-03.result.json). The exact
  [red inputs](red-source/) remain, not overwritten by the correction.
- After the one-condition correction, fresh39 methods /0 failures/errors/skips
  exit0, unittest0.020s, subprocess0.11877289996482432s:
  [command](python-green-03.command.json), [raw log](python-green-03.stderr.log),
  [source-bound result](python-green-03.result.json), [green inputs](green-source/).
  The same new tests run both times; no assertion changes occur between red/green.
- [freeze03 helper](freeze03.py) exits0 with [log](freeze-03.log) and
  [exit](freeze-03.exit). Production AST equals candidate02 after replacing only
  the exact new blank condition by the old condition. Every other production
  statement/docstring/constant matches. Original36 method bodies are equal
  after the authorized old blank tuple-item removal; exactly three methods
  are added, none deleted.
- Empty owned revision scratch starts with exact candidate02 four postimages.
  `git -c core.autocrlf=false apply --no-index --check` and actual apply both
  exit0, final replay bytes match all four candidate03 files:
  [check](revision-check-03.command.json), [apply](revision-apply-03.command.json).
  No worktree/Root Git writes occur.
- Fresh actual direct entrypoint exits2 and emits only the same stable
  incomplete-driver message, stdout empty:
  [command](entrypoint-refusal-03.command.json),
  [stderr](entrypoint-refusal-03.stderr.log), [result](entrypoint-refusal-03.result.json).
  This deliberate refusal is not a native launch or failed host reclassified.
- Fixed HEAD, existing tracked Git diff0, exactly four owned new paths and
  26 named raw inputs match. Git content comparison is not a raw whole-tree
  identity claim. Candidate01's original49 payloads plus metadata and
  candidate02's original44 payloads plus metadata all verify unchanged both
  before and after. Original results/failures and reviewer probes are untouched.

All Python commands use `-B`, process-only D TEMP/TMP/TMPDIR. No Java/Gradle,
native server/client/network/process deletion or Git mutation is authorized.

## Authority, integration and remaining scope

Task04 adoption remains the Root's limited technical disposition; proposal03
and protocol03 original bytes stay exact. Their old source facts do not provide
actual new host/source proof. This correction uses only the explicit blank-line
interpretation, not broader comment/native configuration permissiveness.

The properties API accepts already-read immutable bytes. Bounded file/reparse
reads, exact JSON structural depth/key/node accounting, authoritative console
origin/freshness/deadlines, Java fixture classes/tests, fixed host/copy admission,
cache reflection, player construction/join/disposal, native listener/reload
records, clean-stop ownership receipt and two-host driver remain unimplemented.
No new timeout, loaded-membership proof, raw record fix, arbitrary coordinate,
normal-server/client or natural crash authority is implied.

Root can assign different-agent source replay of this exact partial candidate,
then alone decide integration/commit. No central hook patch is needed or supplied
for these pure primitives. Rollback would remove these four new files before
dependent driver admission; this worker does not stage/commit/push/delete.
Current v1.8 Required Gates, full leaf/driver delivery and ledger acceptance
remain unfulfilled. All old native/analyzer failures retain their original scope
and disposition; parser packaging cannot turn them into a pass.
