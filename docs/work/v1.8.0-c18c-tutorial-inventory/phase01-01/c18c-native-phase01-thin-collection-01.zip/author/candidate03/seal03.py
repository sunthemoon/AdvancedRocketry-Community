"""Seal new revision03 payloads without altering either original bundle."""
import hashlib
import json
import pathlib
import re

out = pathlib.Path(__file__).parent
parent = out.parent
prior = (
    (parent, "01", "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd"),
    (parent / "candidate02", "02", "53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d"),
)
for folder, number, digest in prior:
    manifest = folder / ("EVIDENCE-MANIFEST-" + number + ".json")
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == digest
    for row in json.loads(manifest.read_text(encoding="utf-8"))["files"]:
        data = (folder / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
report = out / "REPORT-03.md"
links = re.findall(r"\[[^\]]*\]\(([^)]+)\)", report.read_text(encoding="utf-8"))
for link in links:
    assert (out / link).exists(), link
source = json.loads((out / "SOURCE-CANDIDATE-03.json").read_text(encoding="utf-8"))
for relative, record in source["files"].items():
    data = (out / "postimages" / relative).read_bytes()
    assert len(data) == record["after"]["bytes"] and hashlib.sha256(data).hexdigest() == record["after"]["sha256"]
entries = []
for path in sorted(out.rglob("*")):
    if not path.is_file():
        continue
    assert path.name not in {"EVIDENCE-MANIFEST-03.json", "SHA256SUMS-03.txt"}
    data = path.read_bytes()
    entries.append({"path": path.relative_to(out).as_posix(), "bytes": len(data),
                    "sha256": hashlib.sha256(data).hexdigest()})
manifest = out / "EVIDENCE-MANIFEST-03.json"
assert not manifest.exists()
manifest.write_text(json.dumps({
    "schema": 1, "scope": "candidate03 ASCII-space blank interpretation; partial primitives only",
    "files": entries, "payload_count": len(entries), "payload_bytes": sum(row["bytes"] for row in entries),
    "prior_manifests": [{"relative": "../EVIDENCE-MANIFEST-01.json", "sha256": prior[0][2], "payloads": 49},
                        {"relative": "../candidate02/EVIDENCE-MANIFEST-02.json", "sha256": prior[1][2], "payloads": 44}],
    "prior_payloads_unchanged": True, "report_companion_links_checked": len(links), "missing_companions": [],
}, indent=2) + "\n", encoding="utf-8", newline="\n")
hash_manifest = hashlib.sha256(manifest.read_bytes()).hexdigest()
sums = out / "SHA256SUMS-03.txt"
assert not sums.exists()
sums.write_text("".join(row["sha256"] + "  " + row["path"] + "\n" for row in entries)
                + hash_manifest + "  EVIDENCE-MANIFEST-03.json\n", encoding="utf-8", newline="\n")
for row in entries:
    data = (out / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({"manifest_sha256": hash_manifest, "payloads": len(entries),
                  "payload_bytes": sum(row["bytes"] for row in entries), "report_links": len(links),
                  "report_sha256": hashlib.sha256(report.read_bytes()).hexdigest(),
                  "checksum_sha256": hashlib.sha256(sums.read_bytes()).hexdigest(),
                  "candidate_sha256": hashlib.sha256((out / "SOURCE-CANDIDATE-03.json").read_bytes()).hexdigest(),
                  "prior_payloads_unchanged": 93}, indent=2))
