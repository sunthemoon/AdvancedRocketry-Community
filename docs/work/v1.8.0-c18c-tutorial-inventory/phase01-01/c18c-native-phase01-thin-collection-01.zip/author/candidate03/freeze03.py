"""Freeze the narrow ASCII-blank revision and preserve both prior loose bundles."""
import ast
import copy
import difflib
import hashlib
import json
import pathlib
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).parent
OLDER = OUT.parent
OLD = OLDER / "candidate02"
ROOT = pathlib.Path("D:/GitHub/arce-v180-c18c-native-20261005")
OWN = (
    "scripts/run_v180_classic_inventory_smoke.py",
    "scripts/test_run_v180_classic_inventory_smoke.py",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md",
)


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def verify_prior(folder, number, expected_manifest):
    path = folder / ("EVIDENCE-MANIFEST-" + number + ".json")
    assert pin(path)["sha256"] == expected_manifest
    document = json.loads(path.read_text(encoding="utf-8"))
    for row in document["files"]:
        assert pin(folder / row["path"]) == {"bytes": row["bytes"], "sha256": row["sha256"]}
    return len(document["files"])


def command(name, args, cwd, expected):
    started = time.monotonic()
    result = subprocess.run(args, cwd=cwd, capture_output=True, encoding="utf-8")
    elapsed = time.monotonic() - started
    (OUT / (name + ".command.json")).write_text(json.dumps({"args": args, "cwd": str(cwd)}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (OUT / (name + ".stdout.log")).write_text(result.stdout, encoding="utf-8", newline="\n")
    (OUT / (name + ".stderr.log")).write_text(result.stderr, encoding="utf-8", newline="\n")
    (OUT / (name + ".result.json")).write_text(json.dumps({"exit": result.returncode, "elapsed_seconds": elapsed}, indent=2) + "\n", encoding="utf-8", newline="\n")
    assert result.returncode == expected, name
    return result


prior01 = verify_prior(OLDER, "01", "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd")
prior02 = verify_prior(OLD, "02", "53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d")
checksum_pins = {
    str(OLDER / "SHA256SUMS-01.txt"): pin(OLDER / "SHA256SUMS-01.txt"),
    str(OLD / "SHA256SUMS-02.txt"): pin(OLD / "SHA256SUMS-02.txt"),
}
assert checksum_pins[str(OLDER / "SHA256SUMS-01.txt")]["sha256"] == "53bcf0611f8cbdddb2d3b3afa19992952d1b3e91faf31606d1457d5a16e359dd"
assert checksum_pins[str(OLD / "SHA256SUMS-02.txt")]["sha256"] == "eb40b40ea9dc521ad3bb44cb9fb5685d8eaadf18ce8f82244d35b9f69cc395ea"
intake = json.loads((OLDER / "INTAKE-02.json").read_text(encoding="utf-8"))
for path, expected in intake["input_pins"].items():
    assert pin(pathlib.Path(path)) == expected
assert command("head-postcheck-03", ["git", "rev-parse", "HEAD"], ROOT, 0).stdout.strip() == intake["fixed_base"]
command("tracked-diff-03", ["git", "diff", "--exit-code", "HEAD", "--"], ROOT, 0)
scope = command("owned-scope-03", ["git", "ls-files", "--others", "--exclude-standard"], ROOT, 0)
assert set(scope.stdout.splitlines()) == set(OWN)

before_production = ast.parse((OLD / "postimages" / OWN[0]).read_text(encoding="utf-8"))
after_production = ast.parse((ROOT / OWN[0]).read_text(encoding="utf-8"))
before_condition = ast.parse('not line or line.startswith(("#", "!"))', mode="eval").body
after_condition = ast.parse('not line or all(char == " " for char in line) or line.startswith(("#", "!"))', mode="eval").body
normalized = copy.deepcopy(after_production)
replacements = 0
for node in ast.walk(normalized):
    if isinstance(node, ast.If) and ast.dump(node.test) == ast.dump(after_condition):
        node.test = copy.deepcopy(before_condition)
        replacements += 1
assert replacements == 1
assert ast.dump(normalized) == ast.dump(before_production), "Unexpected production AST delta"
before_tests = ast.parse((OLD / "postimages" / OWN[1]).read_text(encoding="utf-8"))
after_tests = ast.parse((ROOT / OWN[1]).read_text(encoding="utf-8"))
old_methods = {node.name: copy.deepcopy(node) for node in ast.walk(before_tests)
               if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
new_methods = {node.name: node for node in ast.walk(after_tests)
               if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
added = set(new_methods) - set(old_methods)
assert added == {"test_ascii_space_only_physical_lines_are_blank",
                 "test_other_whitespace_and_indented_comments_are_not_blank",
                 "test_blank_ascii_spaces_change_raw_hash_not_logical_map"}
assert not (set(old_methods) - set(new_methods))
authorized = old_methods["test_no_whitespace_colon_or_default_separator_fallback"]
changes = 0
for node in ast.walk(authorized):
    if isinstance(node, ast.For) and isinstance(node.iter, ast.Tuple):
        blank_items = [element for element in node.iter.elts if isinstance(element, ast.Constant) and element.value == b" "]
        if blank_items:
            assert len(blank_items) == 1
            node.iter.elts.remove(blank_items[0])
            changes += 1
assert changes == 1
for name, method in old_methods.items():
    assert ast.dump(method) == ast.dump(new_methods[name]), name
red = json.loads((OUT / "python-red-03.result.json").read_text(encoding="utf-8"))
green = json.loads((OUT / "python-green-03.result.json").read_text(encoding="utf-8"))
assert red["exit"] == 1 and green["exit"] == 0
red_log = (OUT / "python-red-03.stderr.log").read_text(encoding="utf-8")
green_log = (OUT / "python-green-03.stderr.log").read_text(encoding="utf-8")
assert "Ran 39 tests" in red_log and "FAILED (errors=7)" in red_log
assert "Ran 39 tests" in green_log and green_log.rstrip().endswith("OK")
for relative in OWN[:2]:
    assert pin(ROOT / relative) == green["source"][relative]
assert red["source"][OWN[0]] == pin(OLD / "postimages" / OWN[0])
assert red["source"][OWN[1]] == green["source"][OWN[1]]

records, revision_parts, creation_parts = {}, [], []
for relative in OWN:
    before = (OLD / "postimages" / relative).read_bytes()
    after = (ROOT / relative).read_bytes()
    assert b"\r" not in after and after.endswith(b"\n")
    records[relative] = {"before": pin(OLD / "postimages" / relative), "after": pin(ROOT / relative)}
    destination = OUT / "postimages" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(after)
    revision_parts.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile="a/" + relative, tofile="b/" + relative, lineterm="\n"))
    creation_parts.extend(difflib.unified_diff([], after.decode().splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + relative, lineterm="\n"))
revision = OUT / "REVISION-03.patch"
creation = OUT / "SOURCE-03.patch"
assert not revision.exists() and not creation.exists()
revision.write_bytes("".join(revision_parts).encode("utf-8"))
creation.write_bytes("".join(creation_parts).encode("utf-8"))
replay = OUT / "revision-replay"
assert not replay.exists()
replay.mkdir()
for relative in OWN:
    destination = replay / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((OLD / "postimages" / relative).read_bytes())
command("revision-check-03", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", "--check", str(revision)], replay, 0)
command("revision-apply-03", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", str(revision)], replay, 0)
for relative, record in records.items():
    assert pin(replay / relative) == record["after"]
refusal = command("entrypoint-refusal-03", [sys.executable, "-B", str(ROOT / OWN[0])], ROOT, 2)
assert not refusal.stdout and refusal.stderr.strip() == "Inventory restart verification parsing primitives only; two-host fixture and driver are not implemented."
assert verify_prior(OLDER, "01", "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd") == prior01
assert verify_prior(OLD, "02", "53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d") == prior02
for path, expected in checksum_pins.items():
    assert pin(pathlib.Path(path)) == expected
for path, expected in intake["input_pins"].items():
    assert pin(pathlib.Path(path)) == expected
for relative, record in records.items():
    assert pin(ROOT / relative) == record["after"]
result = {
    "schema": 1, "candidate": 3, "fixed_base": intake["fixed_base"], "branch": intake["branch"],
    "files": records, "source_patch": pin(creation), "revision_patch": pin(revision),
    "prior01_payloads_unchanged": prior01, "prior02_payloads_unchanged": prior02,
    "named_inputs_unchanged": 26, "existing_tracked_diff_exit": 0,
    "production_ast_delta": "one exact ASCII-space-only physical-line condition; all other statements/docstrings/constants equal",
    "test_lineage": "36 existing methods preserved; only original b' ' negative removed per Root clarification; 3 new methods",
    "unit_red": {"methods": 39, "errors": 7, "failures": 0, "exit": 1},
    "unit_green": {"methods": 39, "errors": 0, "failures": 0, "skips": 0, "exit": 0},
    "cli_refusal_exit": 2,
    "blank_line_semantics": "empty OR only ASCII U+0020; raw bytes/hash preserved; C0/DEL/C1 first refuses; initial comments only",
    "deferred": ["JSON structural accounting", "bounded filesystem/reparse reads", "console authority/freshness transport",
                 "Java fixture", "two-host driver", "native listener/record/cache/ownership/disposal proof"],
    "java_native_launched": False, "root_source_world_receipt_writes": False,
}
(OUT / "SOURCE-CANDIDATE-03.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
