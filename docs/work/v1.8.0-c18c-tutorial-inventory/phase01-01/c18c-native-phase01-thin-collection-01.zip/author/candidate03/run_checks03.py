"""Capture fresh pure test receipts and exact tested Python inputs."""
import hashlib
import json
import pathlib
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).parent
ROOT = pathlib.Path("D:/GitHub/arce-v180-c18c-native-20261005")
stage = sys.argv[1]
assert stage in {"red", "green"}
destination = OUT / (stage + "-source")
assert not destination.exists()
destination.mkdir()
files = {}
for relative in ("scripts/run_v180_classic_inventory_smoke.py", "scripts/test_run_v180_classic_inventory_smoke.py"):
    data = (ROOT / relative).read_bytes()
    copy = destination / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(data)
    files[relative] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
args = [sys.executable, "-B", "-m", "unittest", "discover", "-s", "scripts", "-p",
        "test_run_v180_classic_inventory_smoke.py", "-v"]
started = time.monotonic()
result = subprocess.run(args, cwd=ROOT, capture_output=True, encoding="utf-8")
elapsed = time.monotonic() - started
prefix = OUT / ("python-" + stage + "-03")
pathlib.Path(str(prefix) + ".stdout.log").write_text(result.stdout, encoding="utf-8", newline="\n")
pathlib.Path(str(prefix) + ".stderr.log").write_text(result.stderr, encoding="utf-8", newline="\n")
pathlib.Path(str(prefix) + ".command.json").write_text(json.dumps({"args": args, "cwd": str(ROOT)}, indent=2) + "\n", encoding="utf-8", newline="\n")
pathlib.Path(str(prefix) + ".result.json").write_text(json.dumps({"exit": result.returncode, "elapsed_seconds": elapsed,
                                                                  "source": files}, indent=2) + "\n", encoding="utf-8", newline="\n")
for relative, record in files.items():
    data = (ROOT / relative).read_bytes()
    assert len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"]
print(json.dumps({"stage": stage, "exit": result.returncode, "elapsed_seconds": elapsed,
                  "source_unchanged": True}, indent=2))
print(result.stderr)
raise SystemExit(result.returncode)
