"""Verify wording-only candidate02, preserving all original candidate01 bytes."""
import ast
import copy
import difflib
import hashlib
import json
import pathlib
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).parent
OLD = OUT.parent
ROOT = pathlib.Path("D:/GitHub/arce-v180-c18c-native-20261005")
OWN = (
    "scripts/run_v180_classic_inventory_smoke.py",
    "scripts/test_run_v180_classic_inventory_smoke.py",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md",
)


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def command(name, args, cwd, expected):
    started = time.time()
    result = subprocess.run(args, cwd=cwd, capture_output=True, encoding="utf-8")
    elapsed = time.time() - started
    (OUT / (name + ".command.json")).write_text(json.dumps({"args": args, "cwd": str(cwd)}, indent=2) + "\n",
                                                  encoding="utf-8", newline="\n")
    (OUT / (name + ".stdout.log")).write_text(result.stdout, encoding="utf-8", newline="\n")
    (OUT / (name + ".stderr.log")).write_text(result.stderr, encoding="utf-8", newline="\n")
    (OUT / (name + ".result.json")).write_text(json.dumps({"exit": result.returncode, "elapsed_seconds": elapsed}, indent=2) + "\n",
                                                 encoding="utf-8", newline="\n")
    assert result.returncode == expected, name
    return result


old_manifest = json.loads((OLD / "EVIDENCE-MANIFEST-01.json").read_text(encoding="utf-8"))
assert pin(OLD / "EVIDENCE-MANIFEST-01.json")["sha256"] == "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd"
for row in old_manifest["files"]:
    assert pin(OLD / row["path"]) == {"bytes": row["bytes"], "sha256": row["sha256"]}, row["path"]
assert len(old_manifest["files"]) == 49
intake = json.loads((OLD / "INTAKE-02.json").read_text(encoding="utf-8"))
for path, expected in intake["input_pins"].items():
    assert pin(pathlib.Path(path)) == expected, path
assert command("head-postcheck-02", ["git", "rev-parse", "HEAD"], ROOT, 0).stdout.strip() == intake["fixed_base"]
command("tracked-diff-02", ["git", "diff", "--exit-code", "HEAD", "--"], ROOT, 0)
scope = command("owned-scope-02", ["git", "ls-files", "--others", "--exclude-standard"], ROOT, 0)
assert set(scope.stdout.splitlines()) == set(OWN)


class DropDocstrings(ast.NodeTransformer):
    def remove(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) \
                and type(node.body[0].value.value) is str:
            node.body.pop(0)
        return node
    visit_Module = remove
    visit_ClassDef = remove
    visit_FunctionDef = remove


old_production = ast.parse((OLD / "postimages" / OWN[0]).read_text(encoding="utf-8"))
new_production = ast.parse((ROOT / OWN[0]).read_text(encoding="utf-8"))
old_normalized = DropDocstrings().visit(copy.deepcopy(old_production))
new_normalized = DropDocstrings().visit(copy.deepcopy(new_production))
old_message = "C18c Task04 phase01 primitives only; native fixture and driver are not implemented."
new_message = "Inventory restart verification parsing primitives only; two-host fixture and driver are not implemented."
assert sum(isinstance(node, ast.Constant) and node.value == old_message for node in ast.walk(old_normalized)) == 1
assert sum(isinstance(node, ast.Constant) and node.value == new_message for node in ast.walk(new_normalized)) == 1
for node in ast.walk(old_normalized):
    if isinstance(node, ast.Constant) and node.value == old_message:
        node.value = new_message
assert ast.dump(old_normalized) == ast.dump(new_normalized), "Nonwording production AST change"
old_tests = ast.parse((OLD / "postimages" / OWN[1]).read_text(encoding="utf-8"))
new_tests = ast.parse((ROOT / OWN[1]).read_text(encoding="utf-8"))
assert ast.dump(DropDocstrings().visit(copy.deepcopy(old_tests))) == ast.dump(DropDocstrings().visit(copy.deepcopy(new_tests)))
assert len([node for node in ast.walk(new_tests) if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]) == 36

records, revision_parts, creation_parts = {}, [], []
for relative in OWN:
    before = (OLD / "postimages" / relative).read_bytes()
    after = (ROOT / relative).read_bytes()
    assert b"\r" not in after and after.endswith(b"\n")
    records[relative] = {"before": pin(OLD / "postimages" / relative), "after": pin(ROOT / relative)}
    destination = OUT / "postimages" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(after)
    revision_parts.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
                                             fromfile="a/" + relative, tofile="b/" + relative, lineterm="\n"))
    creation_parts.extend(difflib.unified_diff([], after.decode().splitlines(keepends=True),
                                             fromfile="/dev/null", tofile="b/" + relative, lineterm="\n"))
revision = OUT / "REVISION-02.patch"
creation = OUT / "SOURCE-02.patch"
revision.write_bytes("".join(revision_parts).encode("utf-8"))
creation.write_bytes("".join(creation_parts).encode("utf-8"))
replay = OUT / "revision-replay"
replay.mkdir()
for relative in OWN:
    destination = replay / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((OLD / "postimages" / relative).read_bytes())
command("revision-check-02", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", "--check", str(revision)], replay, 0)
command("revision-apply-02", ["git", "-c", "core.autocrlf=false", "apply", "--no-index", str(revision)], replay, 0)
for relative, record in records.items():
    assert pin(replay / relative) == record["after"]
unit = command("python-02", [sys.executable, "-B", "-m", "unittest", "discover", "-s", "scripts", "-p",
                              "test_run_v180_classic_inventory_smoke.py", "-v"], ROOT, 0)
assert "Ran 36 tests" in unit.stderr and unit.stderr.rstrip().endswith("OK")
refusal = command("entrypoint-refusal-02", [sys.executable, "-B", str(ROOT / OWN[0])], ROOT, 2)
assert not refusal.stdout and refusal.stderr.strip() == new_message
for row in old_manifest["files"]:
    assert pin(OLD / row["path"]) == {"bytes": row["bytes"], "sha256": row["sha256"]}
for path, expected in intake["input_pins"].items():
    assert pin(pathlib.Path(path)) == expected
for relative, record in records.items():
    assert pin(ROOT / relative) == record["after"]
result = {
    "schema": 1, "candidate": 2, "fixed_base": intake["fixed_base"], "branch": intake["branch"],
    "original_manifest_sha256": pin(OLD / "EVIDENCE-MANIFEST-01.json")["sha256"],
    "original_payloads_unchanged": 49, "named_inputs_unchanged": 26,
    "files": records, "source_patch": pin(creation), "revision_patch": pin(revision),
    "production_ast_except_docstrings_and_exact_cli_message": "equal",
    "tests_ast_except_module_docstring": "equal", "unit_tests": 36, "unit_exit": 0,
    "cli_exit": 2, "scope": "wording-only revision of partial parsing primitives; no executable driver",
    "pending_interpretation": "blank_lines: empty-only implemented; whitespace-only classification not explicitly fixed by normative text",
    "java_native_launched": False, "runtime_source_world_receipt_writes": False,
}
(OUT / "SOURCE-CANDIDATE-02.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
