# Inventory native fixture phase01 candidate02 handoff

Date: 2026-10-05. Role: delegated source implementer, not independent reviewer.
Integrator: Root. Source review/admission remains pending; this is not a driver.

## Actual scope and unresolved boundary

Exactly four new worktree files are frozen at fixed base
`d04a116e6e6001f166bbf5e8f31fb78623a6b392`, branch
`codex/v1.8.0-classic-inventory-native`. No existing tracked file, Git index,
central hook, source-world/config/record, Java or old sealed evidence was written.

Candidate02 changes only public module/function explanations and CLI wording,
plus the two internal task records. Reader-facing code now names inventory
restart parsing primitives and directly describes C0/DEL/C1 instead of temporary
task stages or chat provenance. The original Root interpretation remains in
internal progress. All parser behavior, constants, assertions and fixed commands
are unchanged. CLI still exits2 and explicitly says the two-host fixture/driver
is not implemented. No placeholder host launch, successful receipt or API
admission is introduced.

**Pending interpretation:** normative `properties_reader.ignored_semantically`
contains `blank_lines` without explicitly specifying whether whitespace-only
physical lines count. The implementation currently ignores empty physical lines
only and refuses e.g. `b" "` under data-line separator/key rules. There is no
direct normative clarification authorizing that empty-only meaning; the old
prototype is not authority. The original negative test is retained rather than
silently changed. Independent review and Root's explicit interpretation may
require a subsequent revision before parser admission.

JSON root depth and object-key node accounting remain unresolved and unimplemented.
The original [phase01 report](../REPORT-01.md) records bounded named searches:
bootstrap provenance root depth1/value visits/no key node, manual evidence
depth1/no node count, separate Pump/Signature report shapes. Those definitions
are not selected or transplanted as C18c contract rules.

## Exact candidate pins

[SOURCE-CANDIDATE-02.json](SOURCE-CANDIDATE-02.json), SHA-256
`3c48778a3510f0d5ee3570f968798a6a9232bd381fe8ab5f000f61c4864b3dac`,
records every original/final postimage and comparison result.

| New path | Final bytes | Final SHA-256 |
|---|---:|---|
| `scripts/run_v180_classic_inventory_smoke.py` | 8,168 | `2bbb4edafa8f25a777bab48ccfb7cada869593ddbc6b5de95e4ce6ba532b6f6c` |
| `scripts/test_run_v180_classic_inventory_smoke.py` | 14,468 | `e7b68b697eda8727c02a5fe593634e6eb1a09da3d32b80dddda0aaaeed6de4a1` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md` | 7,499 | `dcba88b91e6113e28ac4aaec2495a3ef69d5f1c5006ba4b1dcd721b61172db3f` |
| `docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md` | 5,953 | `722b147db3ddcb77fe68dbfc60b80fab46683ff0b0d72521b02a714c58b9b252` |

[SOURCE-02.patch](SOURCE-02.patch) is the four-file creation patch, 37,180 bytes,
SHA-256 `827e33b8392cdbe29b6d49f8790836d1cbc7a155c6bc2ba75233de4f9cdec918`.
[REVISION-02.patch](REVISION-02.patch) compares candidate01 to candidate02,
5,368 bytes, SHA-256
`1b14eb9604c55a990b248eca563580b0ea6ad87980faee63a4be7cdee81ac453`.
All four [postimages](postimages/) are exact and unchanged after checks.

## Actual checks

[verify02 helper](verify02.py) exits0 with separately retained
[raw log](verify-02.log) and [exit](verify-02.exit). Its recorded operations are:

- Original candidate01's 49 payload hashes all match its immutable
  [manifest](../EVIDENCE-MANIFEST-01.json), SHA-256
  `f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd`.
  Original [checksum metadata](../SHA256SUMS-01.txt), SHA-256
  `53bcf0611f8cbdddb2d3b3afa19992952d1b3e91faf31606d1457d5a16e359dd`,
  original 36/0 receipts, incomplete CLI exit2 and original failures remain exact.
- 26 named governance/source/protocol raw pins are unchanged. Fixed HEAD is d04,
  tracked Git diff exits0, and exactly four declared new paths exist.
  This is not a raw-byte whole Git/repository identity assertion.
- Production AST is equal after removing docstrings and replacing only the one
  exact original CLI refusal string with its stable-language counterpart.
  Tests AST is equal after removing module docstring. **Every original test
  body/assertion and production behavior/constant/command is preserved.**
- `git -c core.autocrlf=false apply --no-index --check` and actual revision apply
  in newly owned scratch both exit0; all four replay bytes equal final postimages:
  [check command](revision-check-02.command.json),
  [apply command](revision-apply-02.command.json). No Root/worktree Git write occurs.
- Fresh `python -B -m unittest discover -s scripts -p test_run_v180_classic_inventory_smoke.py -v`
  executes **36 tests /0 failures/errors/skips**, exits0; unittest reports0.019s,
  captured subprocess wall time0.11523032188415527s:
  [command](python-02.command.json), [raw log](python-02.stderr.log),
  [result](python-02.result.json). This is a new candidate02 run, not renamed01.
- Real direct CLI executes and exits2, stderr exactly the new incomplete-driver
  message and stdout empty: [command](entrypoint-refusal-02.command.json),
  [stderr](entrypoint-refusal-02.stderr.log), [result](entrypoint-refusal-02.result.json).
  It creates no host or native mutation. Process-only TEMP/TMP/TMPDIR are D-owned,
  Python uses `-B`; no Java/Gradle/native/client or network launch is authorized.
- The original49 payloads, 26 inputs and all final four source pins still match
  after the checks. Original intake quoting/locator/context failures remain
  [separately described](../TOOL-OBSERVATIONS-01.md) and are not counted as passes.

## Not implemented / required verification

Properties input is already-read bytes. Bounded file/reparse/owned-path reads,
complete JSON/NBT/record parsers, hook/console freshness/deadline transport,
four Java fixture classes/tests, exact cache reflection, all pre-constructor
identity and host gates, owned local players/channel disposal, ordinary listener
and reload observations, external clean-stop receipt and the actual two-host
driver remain absent. Six goals and all original time/byte/node bounds are not
changed or waived. Literal command/payload parsing is not native success,
membership/loading, a changed count or permission to issue that command.

Root can send this frozen partial candidate for different-agent actual source
review. No central registration patch is needed or supplied for these pure
primitives; future central fixture integration remains Root-owned and separately
assigned. Root integration/commit of this four-file creation patch is not yet
accepted. Rollback would remove only these new files before dependent driver
admission, with no native records or worlds to revert; this worker does not
commit/push/delete the worktree.

v1.8 Required Gates, source delivery/ledger admission, normal-server/client,
physical API, natural crash and native two-host proof remain unfulfilled here.
No whole source/JAR/world/archive is exported. The small loose candidate02
bundle and original49-payload bundle stay separate and immutable after sealing.
