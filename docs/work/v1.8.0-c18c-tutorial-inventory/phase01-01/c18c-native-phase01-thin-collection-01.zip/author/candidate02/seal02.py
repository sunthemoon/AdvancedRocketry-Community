"""Seal candidate02 alone and bind the unchanged original loose bundle."""
import hashlib
import json
import pathlib
import re

out = pathlib.Path(__file__).parent
old = out.parent
manifest01 = old / "EVIDENCE-MANIFEST-01.json"
assert hashlib.sha256(manifest01.read_bytes()).hexdigest() == "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd"
original = json.loads(manifest01.read_text(encoding="utf-8"))
for row in original["files"]:
    data = (old / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
assert hashlib.sha256((old / "SHA256SUMS-01.txt").read_bytes()).hexdigest() == "53bcf0611f8cbdddb2d3b3afa19992952d1b3e91faf31606d1457d5a16e359dd"
candidate = json.loads((out / "SOURCE-CANDIDATE-02.json").read_text(encoding="utf-8"))
for relative, row in candidate["files"].items():
    data = (out / "postimages" / relative).read_bytes()
    assert len(data) == row["after"]["bytes"] and hashlib.sha256(data).hexdigest() == row["after"]["sha256"]
report = out / "REPORT-02.md"
links = re.findall(r"\[[^\]]*\]\(([^)]+)\)", report.read_text(encoding="utf-8"))
for link in links:
    assert not link.startswith(("http:", "https:")), link
    assert (out / link).exists(), link
entries = []
for path in sorted(out.rglob("*")):
    if not path.is_file():
        continue
    assert path.name not in {"EVIDENCE-MANIFEST-02.json", "SHA256SUMS-02.txt"}
    data = path.read_bytes()
    entries.append({"path": path.relative_to(out).as_posix(), "bytes": len(data),
                    "sha256": hashlib.sha256(data).hexdigest()})
manifest = out / "EVIDENCE-MANIFEST-02.json"
assert not manifest.exists()
manifest.write_text(json.dumps({
    "schema": 1, "scope": "wording-only candidate02 partial source; no driver/native admission",
    "files": entries, "payload_count": len(entries), "payload_bytes": sum(row["bytes"] for row in entries),
    "prior_bundle": {"manifest": "../EVIDENCE-MANIFEST-01.json",
                     "sha256": "f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd",
                     "payloads": 49, "unchanged": True},
    "report_companion_links_checked": len(links), "missing_companions": [],
}, indent=2) + "\n", encoding="utf-8", newline="\n")
hash_manifest = hashlib.sha256(manifest.read_bytes()).hexdigest()
sums = out / "SHA256SUMS-02.txt"
assert not sums.exists()
sums.write_text("".join(row["sha256"] + "  " + row["path"] + "\n" for row in entries)
                + hash_manifest + "  EVIDENCE-MANIFEST-02.json\n", encoding="utf-8", newline="\n")
for row in entries:
    data = (out / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({"manifest_sha256": hash_manifest, "payloads": len(entries),
                  "payload_bytes": sum(row["bytes"] for row in entries), "report_links": len(links),
                  "report_sha256": hashlib.sha256(report.read_bytes()).hexdigest(),
                  "checksum_sha256": hashlib.sha256(sums.read_bytes()).hexdigest(),
                  "original_payloads_unchanged": 49}, indent=2))
