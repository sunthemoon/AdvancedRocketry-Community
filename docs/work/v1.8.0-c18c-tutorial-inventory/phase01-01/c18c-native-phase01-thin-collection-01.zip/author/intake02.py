"""Named read-only inputs for the phase01 primitive implementation."""
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path("D:/GitHub/arce-v180-c18c-native-20261005")
OUT = pathlib.Path(__file__).parent
PROPOSAL = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e")
RELATIVE = [
    "PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md",
    "docs/04-VERSION-ROADMAP.md", "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md",
    "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
    "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
    "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-04.md",
    "docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md",
    "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/progression/classic/ClassicInventoryAdvancements.java",
    "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ClassicInventoryAdvancementGameTests.java",
    "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ConnectedTestPlayers.java",
    "scripts/validate_bootstrap_provenance.py", "scripts/collect_v002_manual_evidence.py",
    "scripts/run_v180_pump_smoke.py", "scripts/run_v180_signature_smoke.py",
]


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


paths = [ROOT / relative for relative in RELATIVE]
paths.append(pathlib.Path("D:/GitHub/AdvancedRocketry-Community/AGENTS.md"))
paths += [PROPOSAL / name for name in (
    "OWNERSHIP-PROPOSAL-03.md", "PROTOCOL-03.json", "EVIDENCE-MANIFEST.json",
    "SHA256SUMS.txt", "FORCELOAD-LANGUAGE-01.json",
)]
pins = {str(path): pin(path) for path in paths}
assert pins[str(PROPOSAL / "EVIDENCE-MANIFEST.json")]["sha256"] == (
    "2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1"
)
manifest = json.loads((PROPOSAL / "EVIDENCE-MANIFEST.json").read_text(encoding="utf-8"))
payloads = manifest["files"]
for entry in payloads:
    path = pathlib.PurePosixPath(entry["path"])
    assert not path.is_absolute() and ".." not in path.parts
    assert pin(PROPOSAL / path) == {"bytes": entry["bytes"], "sha256": entry["sha256"]}
head = git("rev-parse", "HEAD")
branch = git("branch", "--show-current")
status = git("status", "--short")
assert head == "d04a116e6e6001f166bbf5e8f31fb78623a6b392"
assert branch == "codex/v1.8.0-classic-inventory-native"
assert not status
result = {
    "schema": 1, "fixed_base": head, "branch": branch, "initial_status": status,
    "input_pins": pins, "proposal_manifest_payloads": len(payloads),
    "proposal_payload_bytes": sum(entry["bytes"] for entry in payloads),
    "proposal_mismatches": [], "java_native_launched": False,
    "existing_source_writes": False,
    "intake01": "Python -c quoting SyntaxError before input reads; original log preserved",
    "earlier_manifest_locator": "INTERNAL-MANIFEST.json was a missing guessed locator; actual EVIDENCE-MANIFEST.json above",
}
(OUT / "INTAKE-02.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({key: value for key, value in result.items() if key != "input_pins"}, indent=2))
