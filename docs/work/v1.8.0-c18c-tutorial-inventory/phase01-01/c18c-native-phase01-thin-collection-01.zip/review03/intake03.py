import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
PREVIOUS=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review-20261005-4a82c3')
WT=Path('D:/GitHub/arce-v180-c18c-native-20261005')
NORM=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')

def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def retain(source,target):
    data=source.read_bytes()
    target=HERE/target
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:
        out.write(data)
    return {'source_path':str(source),'evidence_path':target.relative_to(HERE).as_posix(),**pin(data)}

checks=[]
for folder,name,expected,count in [
    (AUTHOR,'EVIDENCE-MANIFEST-01.json','f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd',49),
    (AUTHOR/'candidate02','EVIDENCE-MANIFEST-02.json','53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d',44),
    (AUTHOR/'candidate03','EVIDENCE-MANIFEST-03.json','411f1a6f96e06737389cc9f354286981858902c30e64783d9d6be9aa60982b80',57),
    (NORM,'EVIDENCE-MANIFEST.json','2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1',80),
    (PREVIOUS,'INTERNAL-MANIFEST-01.json','766842c62b1376d95bde96459d5faa05647fa8ba4be43b2cf8c0cb518c68f76a',59),
]:
    data=(folder/name).read_bytes()
    assert pin(data)['sha256']==expected
    rows=json.loads(data)['files']
    assert len(rows)==count
    for row in rows:
        assert pin((folder/row['path']).read_bytes())=={k:row[k] for k in ['bytes','sha256']},row['path']
    checks.append({'manifest_path':str(folder/name),**pin(data),'payloads':count,'mismatches':0})
meta_data=(AUTHOR/'candidate03/SOURCE-CANDIDATE-03.json').read_bytes()
assert pin(meta_data)['sha256']=='b2fea7693626a6fa36ecd37a7168e7a5e0eebd54413e97bb512f598ea5dfd76b'
meta=json.loads(meta_data)
copies=[]
for name,row in meta['files'].items():
    assert pin((AUTHOR/'candidate03/postimages'/name).read_bytes())==row['after']
    assert pin((AUTHOR/'candidate02/postimages'/name).read_bytes())==row['before']
    copies.append(retain(AUTHOR/'candidate03/postimages'/name,'candidate03/'+name))
    copies.append(retain(AUTHOR/'candidate02/postimages'/name,'before02/'+name))
for name in ['SOURCE-CANDIDATE-03.json','SOURCE-03.patch','REVISION-03.patch','EVIDENCE-MANIFEST-03.json','REPORT-03.md']:
    copies.append(retain(AUTHOR/'candidate03'/name,'inputs/'+name))
for name in ['ROOT-CLARIFICATION-01.md','REVIEW-CANDIDATE02.md','independent-unit.stderr.log']:
    copies.append(retain(PREVIOUS/name,'prior-review/'+name))
probe=PREVIOUS/'test_independent.py'
assert pin(probe.read_bytes())['sha256']=='51c16616e47de8619f5c4b5c1b2eef5342e079a878f65e5cdfaf97a99152909c'
copies.append(retain(probe,'test_independent.py'))
copies.append(retain(AUTHOR/'candidate02/postimages/scripts/test_run_v180_classic_inventory_smoke.py',
                     'legacy-tests/test_run_v180_classic_inventory_smoke.py'))
for name in ['NATIVE-TASK-04.md','NATIVE-REVIEW-DISPOSITION-04.md','OWNERSHIP-PROPOSAL-03.md','PROTOCOL-03.json']:
    copies.append(retain(PREVIOUS/'inputs'/name,'inputs/'+name))
base=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD']).decode().strip()
assert base=='d04a116e6e6001f166bbf5e8f31fb78623a6b392'
(HERE/'INPUT-PINS-03.json').write_text(json.dumps({'base':base,'copies':copies,'manifest_checks':checks,
    'source_authority':'Frozen candidate03, not a moving live checkout.',
    'unchanged_probe_loading':'PYTHONPATH explicitly supplies candidate03/scripts; original candidate02/scripts relative path does not exist in this fresh leaf.'},indent=2)+'\n')
print(json.dumps({'exit':0,'copied_inputs':len(copies),'manifest_checks':checks},indent=2))
