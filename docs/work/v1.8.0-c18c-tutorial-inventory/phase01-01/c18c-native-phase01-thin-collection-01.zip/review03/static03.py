import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
META=json.loads((HERE/'inputs/SOURCE-CANDIDATE-03.json').read_text())

def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def replay(raw,before):
    assert len(raw)<=65536
    lines=raw.splitlines(keepends=True)
    index=0
    output=dict(before)
    changed=[]
    while index<len(lines):
        assert lines[index].startswith(b'--- ')
        old=lines[index][4:].rstrip(b'\n').decode()
        index+=1
        assert lines[index].startswith(b'+++ b/')
        name=lines[index][6:].rstrip(b'\n').decode()
        assert name in META['files'] and name not in changed
        index+=1
        old_lines=before.get(name,b'').splitlines(keepends=True)
        cursor=0
        new_lines=[]
        while index<len(lines) and lines[index].startswith(b'@@ '):
            match=re.fullmatch(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n',lines[index])
            assert match
            start_old,count_old,start_new,count_new=[int(n) if n is not None else 1 for n in match.groups()]
            begin=max(0,start_old-1)
            assert begin>=cursor
            new_lines.extend(old_lines[cursor:begin])
            cursor=begin
            assert len(new_lines)==max(0,start_new-1)
            index+=1
            seen_old=seen_new=0
            while index<len(lines) and not lines[index].startswith((b'@@ ',b'--- ')):
                line=lines[index]
                assert line[:1] in [b'+',b'-',b' ']
                if line[:1] in [b'-',b' ']:
                    assert cursor<len(old_lines) and line[1:]==old_lines[cursor]
                    cursor+=1
                    seen_old+=1
                if line[:1] in [b'+',b' ']:
                    new_lines.append(line[1:])
                    seen_new+=1
                index+=1
            assert (seen_old,seen_new)==(count_old,count_new)
        new_lines.extend(old_lines[cursor:])
        if old=='/dev/null':
            assert name not in before
        else:
            assert old=='a/'+name and name in before
        output[name]=b''.join(new_lines)
        changed.append(name)
    assert set(changed)==set(META['files'])
    return output

before={name:(HERE/'before02'/name).read_bytes() for name in META['files']}
creation=replay((HERE/'inputs/SOURCE-03.patch').read_bytes(),{})
revision=replay((HERE/'inputs/REVISION-03.patch').read_bytes(),before)
for name,row in META['files'].items():
    actual=(HERE/'candidate03'/name).read_bytes()
    assert creation[name]==revision[name]==actual
    assert pin(actual)==row['after']
    assert pin(before[name])==row['before']
    assert (AUTHOR/'candidate03/postimages'/name).read_bytes()==actual

script='scripts/run_v180_classic_inventory_smoke.py'
tests='scripts/test_run_v180_classic_inventory_smoke.py'
old=b'if not line or line.startswith(("#", "!")):'
new=b'if not line or all(char == " " for char in line) or line.startswith(("#", "!")):'
assert before[script].count(old)==1
after=(HERE/'candidate03'/script).read_bytes()
assert before[script].replace(old,new)==after
assert after.index(b'"PROPERTIES_LITERAL_CONTROL"')<after.index(new)

def methods(data):
    tree=ast.parse(data)
    return {node.name:node for node in ast.walk(tree)
            if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}

old_methods=methods(before[tests])
new_methods=methods((HERE/'candidate03'/tests).read_bytes())
assert len(old_methods)==36 and len(new_methods)==39
changed=[]
for name,node in old_methods.items():
    current=new_methods[name]
    if ast.dump(node,include_attributes=False)!=ast.dump(current,include_attributes=False):
        changed.append(name)
        assert name=='test_no_whitespace_colon_or_default_separator_fallback'
        loop=node.body[0]
        assert isinstance(loop,ast.For) and isinstance(loop.iter,ast.Tuple)
        elements=loop.iter.elts
        indexes=[i for i,e in enumerate(elements) if isinstance(e,ast.Constant) and e.value==b' ']
        assert len(indexes)==1
        elements.pop(indexes[0])
        assert ast.dump(node,include_attributes=False)==ast.dump(current,include_attributes=False)
assert changed==['test_no_whitespace_colon_or_default_separator_fallback']
assert set(new_methods)-set(old_methods)=={
    'test_ascii_space_only_physical_lines_are_blank',
    'test_other_whitespace_and_indented_comments_are_not_blank',
    'test_blank_ascii_spaces_change_raw_hash_not_logical_map'}
code=ast.parse(after)
imports=sorted({node.module if isinstance(node,ast.ImportFrom) else alias.name
    for node in ast.walk(code) if isinstance(node,(ast.Import,ast.ImportFrom))
    for alias in (node.names if isinstance(node,ast.Import) else [None])})
assert imports==['__future__','dataclasses','hashlib','re','sys','types','typing']
assert not any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
    and node.func.id in ['open','exec','eval','compile','__import__'] for node in ast.walk(code))
protocol=json.loads((HERE/'inputs/PROTOCOL-03.json').read_text())
constants={node.targets[0].id:ast.literal_eval(node.value) for node in code.body
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and isinstance(node.value,ast.Constant)}
assert constants['MAX_PROPERTIES_BYTES']==protocol['properties_reader']['raw_bytes']==16384
assert constants['MAX_PROPERTIES_PAIRS']==protocol['properties_reader']['pairs']==1023
assert constants['MAX_PROPERTIES_NODES']==protocol['properties_reader']['string_nodes_plus_root']==2048
identity=json.loads((HERE/'module-identity.stdout.log').read_text())
assert Path(identity['loaded_file']).resolve()==(HERE/'candidate03'/script).resolve()
assert identity['sha256']==META['files'][script]['after']['sha256']
probe=(HERE/'test_independent.py').read_bytes()
assert pin(probe)['sha256']=='51c16616e47de8619f5c4b5c1b2eef5342e079a878f65e5cdfaf97a99152909c'
assert not (HERE/'candidate02').exists()
result={'exit':0,'creation_exact_postimages':4,'revision_exact_postimages':4,
    'module_change':'one exact ASCII-space-only condition after unchanged literal-control gate',
    'other_module_bytes_exact':True,'old_test_methods':36,'old_methods_ast_exact':35,
    'one_authorized_old_method_change':'only remove the single b" " negative tuple element',
    'new_test_methods':3,'constants_and_other_module_logic_exact':True,'no_new_reader_writer_or_process_import':True,
    'original_reviewer_probe_sha256':pin(probe)['sha256'],'actual_probe_module_sha256':identity['sha256'],
    'future_file_transport_json_host_and_native_scope_unimplemented':True}
(HERE/'STATIC-RESULTS-03.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
