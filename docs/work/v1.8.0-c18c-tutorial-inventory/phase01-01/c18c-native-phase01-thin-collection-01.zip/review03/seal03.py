import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
PRIOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review-20261005-4a82c3')

def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

meta=json.loads((HERE/'inputs/SOURCE-CANDIDATE-03.json').read_text())
for name,row in meta['files'].items():
    assert pin((HERE/'candidate03'/name).read_bytes())==row['after']
    assert pin((AUTHOR/'candidate03/postimages'/name).read_bytes())==row['after']
    assert pin((HERE/'before02'/name).read_bytes())==row['before']
assert pin((HERE/'test_independent.py').read_bytes())['sha256']=='51c16616e47de8619f5c4b5c1b2eef5342e079a878f65e5cdfaf97a99152909c'
checks=[]
for directory,filename,expected in [
    (AUTHOR/'candidate03','EVIDENCE-MANIFEST-03.json','411f1a6f96e06737389cc9f354286981858902c30e64783d9d6be9aa60982b80'),
    (PRIOR,'INTERNAL-MANIFEST-01.json','766842c62b1376d95bde96459d5faa05647fa8ba4be43b2cf8c0cb518c68f76a')]:
    data=(directory/filename).read_bytes()
    assert pin(data)['sha256']==expected
    rows=json.loads(data)['files']
    for row in rows:
        assert pin((directory/row['path']).read_bytes())=={k:row[k] for k in ['bytes','sha256']}
    checks.append({'manifest':str(directory/filename),'payloads':len(rows),'mismatches':0,**pin(data)})
results=json.loads((HERE/'RUN-RESULTS-03.json').read_text())
assert {r['job']:r['exit'] for r in results}=={
    'candidate03-unit':0,'unchanged-probe':0,'boundary03':0,'legacy-negative':1,'cli':2,'module-identity':0}
(HERE/'POSTCHECK-03.json').write_text(json.dumps({'exit':0,'frozen_postimages_exact':4,
    'checks':checks,'original_probe_exact':True,'no_repo_source_java_native_cleanup_or_gate_action':True},indent=2)+'\n')
rows=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        rows.append({'path':path.relative_to(HERE).as_posix(),**pin(path.read_bytes())})
with (HERE/'INTERNAL-MANIFEST-03.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps({'schema':1,'scope':'Candidate03 pure-source independent review;0C/0H/0M/0L;not native/driver/whole Task04/Gates.',
        'files':rows,'payloads':len(rows),'payload_bytes':sum(r['bytes'] for r in rows)},indent=2)+'\n')
with (HERE/'SHA256SUMS.txt').open('x',encoding='utf-8',newline='\n') as out:
    for row in rows:
        out.write(row['sha256']+'  '+row['path']+'\n')
    out.write(pin((HERE/'INTERNAL-MANIFEST-03.json').read_bytes())['sha256']+'  INTERNAL-MANIFEST-03.json\n')
print(json.dumps({'report':pin((HERE/'REVIEW-CANDIDATE03.md').read_bytes()),
    'manifest':pin((HERE/'INTERNAL-MANIFEST-03.json').read_bytes()),
    'checksums':pin((HERE/'SHA256SUMS.txt').read_bytes()),
    'payloads':len(rows),'payload_bytes':sum(r['bytes'] for r in rows)},indent=2))
