import hashlib
import unittest

import run_v180_classic_inventory_smoke as f


class NewBoundaryControls(unittest.TestCase):
    def test_full_byte_budget_of_spaces_is_blank_but_overflow_is_not_admitted(self):
        raw = b' ' * 16384
        observed = f.PropertiesObservation(raw)
        self.assertEqual({}, observed.values)
        self.assertEqual(raw, observed.raw)
        self.assertEqual(hashlib.sha256(raw).hexdigest(), observed.sha256)
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_BYTES$'):
            f.parse_properties(raw + b' ')

    def test_space_blanks_do_not_consume_pair_nodes(self):
        raw = b' \n' + b'\n'.join(('k'+str(i)+'=v').encode() for i in range(1023)) + b'\n '
        self.assertEqual(1023, len(f.parse_properties(raw)))
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_PAIRS$'):
            f.parse_properties(raw+b'\nk1023=v')

    def test_unicode_and_control_whitespace_do_not_gain_blank_admission(self):
        for code in [9,12,127,128,133,159,160,5760,8192,8195,8232,8233,8239,8287,12288]:
            with self.subTest(code=code), self.assertRaises(f.FixtureInputError):
                f.parse_properties((' '+chr(code)+' ').encode('utf-8'))

    def test_literal_controls_are_refused_before_ignoring_comment_or_blank(self):
        for raw in [b' \x00 ', b' \t ', b'#\x00', b'!\x7f', ' \u0085 '.encode()]:
            with self.subTest(raw=raw), self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_LITERAL_CONTROL$'):
                f.parse_properties(raw)
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_LINE_ENDING$'):
            f.parse_properties(b' \r ')

    def test_only_literal_ascii_space_physical_line_is_blank(self):
        self.assertEqual({' ': 'x'}, f.parse_properties(br'\ =x'))
        for raw in [br'\ ', b' #comment', b' !comment', b' k=v', b'k= v']:
            with self.subTest(raw=raw), self.assertRaises(f.FixtureInputError):
                f.parse_properties(raw)

    def test_trailing_spaces_and_escaped_leading_values_remain_data(self):
        self.assertEqual({'k': 'v  ', 'x': '  y'}, f.parse_properties(b' \nk=v  \nx=\\ \\ y\n '))

    def test_blank_rewrite_changes_raw_boot_and_stop_identity_not_logical_equality(self):
        raw=b'gamemode=adventure\nforce-gamemode=false\nview-distance=2\nsimulation-distance=3\n'
        first=f.PropertiesObservation(raw)
        second=f.PropertiesObservation(b' \r\n'+raw+b'  ')
        f.require_logical_equality(first,second)
        f.require_live_binding(first,second,second.sha256)
        self.assertNotEqual(first.sha256,second.sha256)
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_BOOT_RAW$'):
            f.require_boot_binding('seed',first,second,second.sha256)
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_STOPPED_RAW$'):
            f.require_stopped_binding(first,second)
        f.require_boot_binding('reload',first,second,second.sha256,seed_stopped=second)

    def test_empty_file_is_still_refused_not_replaced_with_defaults(self):
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_BYTES$'):
            f.parse_properties(b'')
        with self.assertRaisesRegex(f.FixtureInputError, '^PROPERTIES_HOST_SETTINGS$'):
            f.require_host_settings(f.PropertiesObservation(b' '))


if __name__ == '__main__':
    unittest.main()
