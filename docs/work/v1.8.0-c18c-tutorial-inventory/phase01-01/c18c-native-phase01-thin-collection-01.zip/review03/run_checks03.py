import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
COPY=HERE/'candidate03'
env=os.environ.copy()
for key in ['TEMP','TMP','TMPDIR']:
    env[key]=str(HERE)
# Unchanged reviewer probe inserts a nonexistent old host path first; this exact
# explicit module path supplies candidate03, without editing the old probe.
env['PYTHONPATH']=str(COPY/'scripts')
jobs=[
    ('candidate03-unit',[sys.executable,'-B','-m','unittest','discover','-s','scripts','-p','test_run_v180_classic_inventory_smoke.py','-v'],COPY),
    ('unchanged-probe',[sys.executable,'-B','-m','unittest','test_independent','-v'],HERE),
    ('boundary03',[sys.executable,'-B','-m','unittest','test_boundary03','-v'],HERE),
    ('legacy-negative',[sys.executable,'-B','-m','unittest','discover','-s','legacy-tests','-p','test_run_v180_classic_inventory_smoke.py','-v'],HERE),
    ('cli',[sys.executable,'-B',str(COPY/'scripts/run_v180_classic_inventory_smoke.py')],HERE),
    ('module-identity',[sys.executable,'-B','-c',
        'import hashlib,json,pathlib,run_v180_classic_inventory_smoke as f; p=pathlib.Path(f.__file__); print(json.dumps({"loaded_file":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}))'],HERE),
]
results=[]
for name,command,cwd in jobs:
    (HERE/(name+'.command.json')).write_text(json.dumps({'command':command,'cwd':str(cwd),
        'process_temp':str(HERE),'PYTHONPATH':env['PYTHONPATH'],
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
    done=subprocess.run(command,cwd=cwd,env=env,capture_output=True)
    (HERE/(name+'.stdout.log')).write_bytes(done.stdout)
    (HERE/(name+'.stderr.log')).write_bytes(done.stderr)
    (HERE/(name+'.exit')).write_text(str(done.returncode)+'\n')
    results.append({'job':name,'exit':done.returncode,'stdout_sha256':hashlib.sha256(done.stdout).hexdigest(),
                    'stderr_sha256':hashlib.sha256(done.stderr).hexdigest()})
(HERE/'RUN-RESULTS-03.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
