# Individually received test-only clarification

Source: Root's direct coordination message, 2026-10-05, during candidate02 review.
This is not an owner gameplay choice, source change, old protocol rewrite or
native observation. The exact applicable instruction is transcribed below:

> Root 明确本测试子集的 blank_lines 指 empty line 或仅由 ASCII space U+0020 组成的物理行；原 LF/CRLF 识别与 raw C0/DEL/C1 拒绝不变，因此 TAB/form-feed、NBSP/其他Unicode whitespace不因blank规则获准。Raw bytes/hash必须全保留，只有logical comparison跳过空白行，不写/trim/canonicalize文件。Comment范围此次不扩：现有#或!开头的行，leading-space comment输入暂仍unsupported，不以blank澄清扩大数据/key/value/escape语义。请据实际规范及源证独立核查此 test-only 澄清和作者接下来的 candidate03；不能把旧02 literal-space负例当契约权威，也不得预填新verdict。Root会在最终自己的处置中保留此词义/旧候选/实际变更和所有failed receipts，不改原sealed协议。

The unchanged candidate02 snapshot is reviewed against this clarified meaning.
Any later candidate is a separate source identity and review. The reviewer does
not edit the author candidate, assertions, protocol or old sealed evidence.
