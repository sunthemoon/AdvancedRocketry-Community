import ast
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
WT = Path('D:/GitHub/arce-v180-c18c-native-20261005')
BASE = 'd04a116e6e6001f166bbf5e8f31fb78623a6b392'
NORM = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')

def pin(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}

def retain(path, target):
    data = path.read_bytes()
    out = HERE/target
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        assert out.read_bytes() == data
        return pin(data)
    with out.open('xb') as f:
        f.write(data)
    return pin(data)

final = (AUTHOR/'candidate02/EVIDENCE-MANIFEST-02.json').read_bytes()
assert pin(final)['sha256'] == '53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d'
author_rows = json.loads(final)['files']
assert len(author_rows) == 44
for row in author_rows:
    assert pin((AUTHOR/'candidate02'/row['path']).read_bytes()) == {k:row[k] for k in ['bytes','sha256']}
retain(AUTHOR/'candidate02/EVIDENCE-MANIFEST-02.json', 'inputs/EVIDENCE-MANIFEST-02.json')
retain(AUTHOR/'candidate02/REPORT-02.md', 'inputs/AUTHOR-REPORT-02.md')
norm_manifest = (NORM/'EVIDENCE-MANIFEST.json').read_bytes()
assert pin(norm_manifest)['sha256'] == '2dd72c12a8bf7bffcc6dd10ade9863f48b7e57ee7e0c361484a19f4cf0df8de1'
norm_rows = json.loads(norm_manifest)['files']
assert len(norm_rows) == 80
for row in norm_rows:
    assert pin((NORM/row['path']).read_bytes()) == {k:row[k] for k in ['bytes','sha256']}
retain(NORM/'EVIDENCE-MANIFEST.json', 'inputs/NORMATIVE-MANIFEST.json')
retain(NORM/'FORCELOAD-LANGUAGE-01.json', 'inputs/FORCELOAD-LANGUAGE-01.json')
metadata = json.loads((HERE/'inputs/SOURCE-CANDIDATE-02.json').read_text())
preimages = {}
for name,row in metadata['files'].items():
    data = (AUTHOR/'postimages'/name).read_bytes()
    assert pin(data) == row['before']
    retain(AUTHOR/'postimages'/name, 'candidate01/'+name)
    preimages[name] = data

def replay(raw, before):
    # Bounded exact unified-diff replay; source bytes are never normalized.
    assert len(raw) <= 65536
    lines = raw.splitlines(keepends=True)
    index = 0
    output = dict(before)
    changed = []
    while index < len(lines):
        assert lines[index].startswith(b'--- '), (index,lines[index])
        old = lines[index][4:].rstrip(b'\n').decode()
        index += 1
        assert lines[index].startswith(b'+++ b/')
        name = lines[index][6:].rstrip(b'\n').decode()
        assert name in metadata['files']
        assert name not in changed
        index += 1
        old_lines = before.get(name,b'').splitlines(keepends=True)
        cursor = 0
        new_lines = []
        while index < len(lines) and lines[index].startswith(b'@@ '):
            match = re.fullmatch(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n', lines[index])
            assert match
            start_old,count_old,start_new,count_new = [int(n) if n is not None else 1 for n in match.groups()]
            begin = max(0,start_old-1)
            assert begin >= cursor
            new_lines.extend(old_lines[cursor:begin])
            cursor = begin
            assert len(new_lines) == max(0,start_new-1)
            index += 1
            seen_old = seen_new = 0
            while index < len(lines) and not lines[index].startswith((b'@@ ',b'--- ')):
                line = lines[index]
                assert line[:1] in [b'+',b'-',b' ']
                if line[:1] in [b'-',b' ']:
                    assert cursor < len(old_lines) and line[1:] == old_lines[cursor]
                    cursor += 1
                    seen_old += 1
                if line[:1] in [b'+',b' ']:
                    new_lines.append(line[1:])
                    seen_new += 1
                index += 1
            assert (seen_old,seen_new) == (count_old,count_new)
        new_lines.extend(old_lines[cursor:])
        if old == '/dev/null':
            assert name not in before
        else:
            assert old == 'a/'+name and name in before
        output[name] = b''.join(new_lines)
        changed.append(name)
    assert set(changed) == set(metadata['files'])
    return output

creation = replay((HERE/'inputs/SOURCE-02.patch').read_bytes(), {})
revision = replay((HERE/'inputs/REVISION-02.patch').read_bytes(), preimages)
for name,row in metadata['files'].items():
    actual = (HERE/'candidate02'/name).read_bytes()
    assert creation[name] == revision[name] == actual
    assert pin(actual) == row['after']

def normalized(tree):
    tree = copy.deepcopy(tree)
    for node in ast.walk(tree):
        if isinstance(node,(ast.Module,ast.FunctionDef,ast.ClassDef)) and node.body:
            first = node.body[0]
            if isinstance(first,ast.Expr) and isinstance(first.value,ast.Constant) and isinstance(first.value.value,str):
                node.body.pop(0)
        if isinstance(node,ast.FunctionDef) and node.name == 'main':
            message = node.body[0].value
            assert isinstance(message,ast.Call) and isinstance(message.func,ast.Name) and message.func.id == 'print'
            assert len(message.args) == 1 and isinstance(message.args[0],ast.Constant)
            message.args[0].value = 'EXACT_CLI_MESSAGE_ONLY'
    return ast.dump(tree,include_attributes=False)

script = 'scripts/run_v180_classic_inventory_smoke.py'
tests = 'scripts/test_run_v180_classic_inventory_smoke.py'
code = ast.parse((HERE/'candidate02'/script).read_text())
assert normalized(code) == normalized(ast.parse(preimages[script].decode()))
assert normalized(ast.parse((HERE/'candidate02'/tests).read_text())) == normalized(ast.parse(preimages[tests].decode()))
imports = sorted({node.module if isinstance(node,ast.ImportFrom) else alias.name
    for node in ast.walk(code) if isinstance(node,(ast.Import,ast.ImportFrom))
    for alias in (node.names if isinstance(node,ast.Import) else [None])})
assert imports == ['__future__','dataclasses','hashlib','re','sys','types','typing']
assert not any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
    and node.func.id in ['open','exec','eval','compile','__import__'] for node in ast.walk(code))
constants = {node.targets[0].id:ast.literal_eval(node.value) for node in code.body
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name)
    and isinstance(node.value,ast.Constant)}
protocol = json.loads((HERE/'inputs/PROTOCOL-03.json').read_text())
assert constants['MAX_PROPERTIES_BYTES'] == protocol['properties_reader']['raw_bytes'] == 16384
assert constants['MAX_PROPERTIES_PAIRS'] == protocol['properties_reader']['pairs'] == 1023
assert constants['MAX_PROPERTIES_NODES'] == protocol['properties_reader']['string_nodes_plus_root'] == 2048
assert constants['HOST_REVISION'] == 3
assert constants['PROPERTIES_READER_VERSION'] == protocol['properties_reader']['version'] == 1
assert constants['SEED_FORCED_COMMAND'] == protocol['forced_setup']['seed']['commands'][0]
assert protocol['forced_setup']['reload']['commands'] == []
status = subprocess.check_output(['git','-C',str(WT),'status','--porcelain=v1','--untracked-files=all']).decode()
assert {line[3:] for line in status.splitlines()} == set(metadata['files'])
assert subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD']).decode().strip() == BASE
result = {'exit':0, 'author_candidate02_payloads_verified':44, 'normative_payloads_verified':80,
    'creation_patch_exact_postimages':4, 'revision_patch_exact_postimages':4,
    'source_imports':imports, 'no_file_process_world_reader_writer_imports':True,
    'budget_constants_exact':True, 'candidate01_to_02_ast_except_docstrings_and_cli_message':'equal',
    'author_scope_and_fixed_head_exact':True,
    'frozen_candidate02_and_reviewer_copy_unchanged_after_independent_runs':True,
    'live_worktree_postimages':{name:pin((WT/name).read_bytes()) for name in metadata['files']},
    'live_worktree_qualification':'Author is independently authorized to prepare candidate03; live bytes are observations, not the candidate02 source authority.',
    'qualification':'Static/Python source checks only; acknowledged payloads carry no transport authority.'}
(HERE/'STATIC-RESULTS-01.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
