import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
WT = Path('D:/GitHub/arce-v180-c18c-native-20261005')
NORM = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
BASE = 'd04a116e6e6001f166bbf5e8f31fb78623a6b392'

def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def copy(source, target):
    data = source.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as out:
        out.write(data)
    return {'source_path': str(source), 'evidence_path': target.relative_to(HERE).as_posix(), **pin(data)}

original_manifest = (AUTHOR / 'EVIDENCE-MANIFEST-01.json').read_bytes()
assert pin(original_manifest)['sha256'] == 'f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd'
old = json.loads(original_manifest)
for row in old['files']:
    assert pin((AUTHOR / row['path']).read_bytes()) == {k: row[k] for k in ('bytes', 'sha256')}, row['path']
assert len(old['files']) == 49
manifest = (AUTHOR / 'candidate02/SOURCE-CANDIDATE-02.json').read_bytes()
assert pin(manifest)['sha256'] == '3c48778a3510f0d5ee3570f968798a6a9232bd381fe8ab5f000f61c4864b3dac'
meta = json.loads(manifest)
pins = []
for name, row in meta['files'].items():
    source = AUTHOR / 'candidate02/postimages' / name
    data = source.read_bytes()
    assert pin(data) == row['after']
    assert (WT / name).read_bytes() == data
    pins.append(copy(source, HERE / 'candidate02' / name))
for name in ['SOURCE-CANDIDATE-02.json', 'SOURCE-02.patch', 'REVISION-02.patch']:
    pins.append(copy(AUTHOR / 'candidate02' / name, HERE / 'inputs' / name))
for name, expected in [('OWNERSHIP-PROPOSAL-03.md', 'f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca'),
                       ('PROTOCOL-03.json', 'fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc')]:
    assert pin((NORM / name).read_bytes())['sha256'] == expected
    pins.append(copy(NORM / name, HERE / 'inputs' / name))
for name in ['NATIVE-TASK-04.md', 'NATIVE-REVIEW-DISPOSITION-04.md']:
    source = WT / 'docs/work/v1.8.0-c18c-tutorial-inventory' / name
    actual = subprocess.check_output(['git', '-C', str(WT), 'show', BASE + ':docs/work/v1.8.0-c18c-tutorial-inventory/' + name])
    assert actual == source.read_bytes()
    pins.append(copy(source, HERE / 'inputs' / name))
head = subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip()
assert head == BASE
(HERE / 'INPUT-PINS-01.json').write_text(json.dumps({'base': BASE, 'inputs': pins,
    'original_author_payloads_verified': len(old['files']), 'candidate02_source_exact': True,
    'scope': 'Source intake only; author final evidence seal not yet part of this control.'}, indent=2) + '\n')
print(json.dumps({'exit': 0, 'copied_inputs': len(pins), 'source_candidate02': pin(manifest),
                  'original_author_payloads_verified': len(old['files'])}, indent=2))
