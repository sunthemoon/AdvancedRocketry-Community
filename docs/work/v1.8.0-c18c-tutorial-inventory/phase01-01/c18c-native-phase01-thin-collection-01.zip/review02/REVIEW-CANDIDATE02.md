# C18c Task04 phase01 candidate02 independent source review

Date: 2026-10-05. Reviewer: delegated independent worker `/root/c17_contract`.
This reviewer did not author these primitives. Its earlier analyzer correction
and historical C18 reviews are separate scopes. Root owns all adoption and Git.

## Findings

**0 Critical / 0 High / 1 Medium / 0 Low in the reviewed candidate02.**

### M1 — ASCII-space-only blank lines are rejected by the properties subset

Location: [run_v180_classic_inventory_smoke.py](candidate02/scripts/run_v180_classic_inventory_smoke.py)
lines 104–109, especially 107; `_separator` line 83. The old negative assertion
is [test_run_v180_classic_inventory_smoke.py](candidate02/scripts/test_run_v180_classic_inventory_smoke.py)
lines 95–100, with `b" "` on line 96.

The immutable proposal03 section 3.2 says blank lines have no configuration
meaning; protocol03 `properties_reader.ignored_semantically` names `blank_lines`.
That phrase initially left empty versus whitespace-only interpretation unclear.
The reviewer asked Root rather than treating the original prototype/negative
test as authority. [Root's individually recorded clarification](ROOT-CLARIFICATION-01.md)
now defines this test-only category as empty or ASCII U+0020-only physical lines.
It does not admit other whitespace, leading-space comments or configuration
normalization, and does not rewrite the old sealed protocol.

Candidate02 skips only `not line` or initial `#`/`!`. Therefore the concrete
supported input `b' \r\nk=v\n   \n'` enters `_separator` and raises
`FixtureInputError("PROPERTIES_SEPARATOR")`, rather than yielding `{'k': 'v'}`.
The unchanged executable [reviewer probe](test_independent.py), method
`test_ascii_space_only_physical_lines_have_no_logical_entries`, reproduces this
with actual exit 1 /16 tests /one error; [raw stderr](independent-unit.stderr.log)
contains the exact call and candidate02 source locations. The other 15 methods
pass. The author's 36 tests pass independently, but their old space-only
negative expectation is not a substitute for the clarified normative meaning.

Impact: an admitted test-owned configuration representation is refused by a
required primitive. This is a Medium source-conformance defect, not an observed
Minecraft failure, corrupted player record or completed native cohort. Correct
it in a separately frozen candidate, preserving the literal-control gate first,
raw bytes/hash, all data/escape limits and initial-only comments. Do not use a
generic Unicode trim or rewrite input files. Candidate02 must remain unchanged.
This review does not infer a later candidate's outcome or accept it.

## Exact reviewed identity

Fixed author base: `d04a116e6e6001f166bbf5e8f31fb78623a6b392`.
Author WT: `D:/GitHub/arce-v180-c18c-native-20261005`.
Frozen source authority is the author's `candidate02/postimages`, not moving WT
bytes after Root separately authorized candidate03. All four candidate02 files
were copied into the reviewer leaf before executable checks.

| File / evidence | Bytes | SHA-256 |
|---|---:|---|
| Parsing module | 8,168 | `2bbb4edafa8f25a777bab48ccfb7cada869593ddbc6b5de95e4ce6ba532b6f6c` |
| Original test module | 14,468 | `e7b68b697eda8727c02a5fe593634e6eb1a09da3d32b80dddda0aaaeed6de4a1` |
| NATIVE-PROGRESS-04 | 7,499 | `dcba88b91e6113e28ac4aaec2495a3ef69d5f1c5006ba4b1dcd721b61172db3f` |
| NATIVE-HANDOFF-04 | 5,953 | `722b147db3ddcb77fe68dbfc60b80fab46683ff0b0d72521b02a714c58b9b252` |
| Source candidate manifest | 2,421 | `3c48778a3510f0d5ee3570f968798a6a9232bd381fe8ab5f000f61c4864b3dac` |
| Four-file creation patch | 37,180 | `827e33b8392cdbe29b6d49f8790836d1cbc7a155c6bc2ba75233de4f9cdec918` |
| Candidate01→02 patch | 5,368 | `1b14eb9604c55a990b248eca563580b0ea6ad87980faee63a4be7cdee81ac453` |
| Author candidate02 evidence manifest | — | `53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d` |

[Input pins](INPUT-PINS-01.json) bind the selected source and normative copies.
Task04 SHA is `3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43`;
its limited disposition is `8d679d97de9ff04f27880ed01071b43fccc4c66e2cac89bc20540b853d9bc28d`.
Normative proposal03 is `f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca`;
protocol03 is `fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc`.
The adopted disposition, not the retained PROPOSED historical header alone,
supplies limited test-fixture implementation authority.

## Actual independent commands and checks

All executable commands use Python `-B` with process-local TEMP/TMP/TMPDIR in
this own D project-parent evidence leaf. No Java/Gradle/native/client/network,
Root/author edit, Git mutation, cleanup or private-directory read occurs.

| Command / control | Actual result |
|---|---|
| `python -B intake.py` | exit 0; exact four source postimages and 49 original author payloads |
| `python -B -m unittest discover -s scripts -p test_run_v180_classic_inventory_smoke.py -v` in own candidate02 | exit 0;36 tests,0 failures/errors/skips |
| `python -B -m unittest test_independent -v` in own leaf | exit 1;16 methods,1 error M1;15 pass |
| Direct copied parsing-script invocation | exit 2;empty stdout and explicit incomplete-driver stderr |
| `python -B static_checks.py`, first run | exit 1; erroneous final comparison to concurrently advancing live WT; preserved separately |
| Same bounded static helper, revised source authority | exit 0;44 candidate02 and 80 normative payloads verified, exact four creation and four revision postimages |

[Run results](RUN-RESULTS-01.json) preserve each job's actual return code.
The outer `run_checks.py` returns 0 after collecting results; it is **not** a
test PASS and does not override the independent unit command's exit 1.
[Static results](STATIC-RESULTS-01.json) and [tool observations](TOOL-OBSERVATIONS-01.md)
retain the first live-byte assumption failure and separately labelled later
WT candidate03 hashes. Frozen candidate02 /reviewer copies remain byte-exact.
No Git apply command is claimed: a bounded exact unified-diff replay verifies
creation/revision context and all four native postimage byte strings without
normalization or writing another repository. Original failures are retained.

## Source behavior covered without additional findings

* Actual 16,384-byte,1,023-pair,2,048-node constants match protocol03. Parsing
  first enforces exact `bytes`, finite raw size, strict UTF-8/no initial BOM,
  physical LF/CRLF/lone-CR distinction, and raw C0 plus DEL/C1 refusal including
  comments. Recognized escaped controls remain separate. No source ceiling moves.
* The first unescaped equals separator, strict key/value rules, escape allowlist,
  continuation refusal and decoded duplicate-key gate are inspected and tested.
  Unknown entries and scalar strings remain exact; no default insertion/coercion.
* `PropertiesObservation` owns immutable raw bytes, an inaccessible backing map
  exposed via MappingProxyType, and an actual raw SHA-256. The newly owned parsed
  map does not alias a later observation. Frozen assignment/map mutation refusal
  is executed, not a filesystem or adversarial Python reflection guarantee.
* Seed boot requires initial raw identity; reload boot binds real supplied
  seed-stopped bytes instead. Native-style comment/order/escape rewrites can have
  equal whole maps but different raw hashes; pure live/stop comparisons preserve
  this distinction. Unknown map changes, wrong host strings, phase/hash/types
  refuse. This is not decoded receipt validation or past-byte hook observation.
* Seed returns the sole immutable literal command tuple; reload returns empty.
  Acknowledgement forms accept canonical fixed-range pairs only. They do not
  normalize log prefixes or derive commands from parsed coordinates. The returned
  last-changed ChunkPos is neither changed count, origin/freshness authority,
  whole121 membership nor loaded state. Scope prose accurately states these limits.
* Imported modules are only future annotations,dataclasses,hashlib,re,sys,types,
  typing; no file/process/world reader/writer or eval/open API is introduced.
  CLI merely prints refusal and returns2. Candidate01→02 AST is equal after
  precisely identified docstring and CLI-message changes. Reader-facing wording
  no longer presents task/chat-stage text as executable native guidance.

## Eligibility, exclusions and remaining work

Recommendation: **CHANGES_REQUESTED for candidate02 M1**, with its original
source/probe/failure preserved. Other reviewed pure-function behavior has no
additional severity finding in this bounded review; that is not whole Task04
source completion, runtime admission or an owner/Gate verdict.

File/path/reparse bounded reading,16,384+one-overflow observation from a real
file,JSON counting/depth policy,record/cache/ownership receipt validation,
native authority/freshness/deadline transport,all121 membership/loading probes,
Java hooks/player lifecycle,host setup/selection,two-host driver/clean stops and
disposal are explicitly unimplemented. Their absence is the authorized phase01
boundary, not claimed PASS. No native English rendered output is newly observed
by parser tests. No gameplay schema/migration,player progression grant/reset,
resource writer or gameplay policy is admitted. G0–G9,normal server and V1/V2
remain open. Root alone can decide later integration after a separate revision
and independent final-source review.

This compact loose bundle contains selected pre/postimages,normative text,
raw Python commands/results,probes,patches and manifests; no whole-source/JAR/
runtime/world/old huge ZIP duplication. The original author candidate01/02
sealed evidence is verified read-only and remains untouched.
