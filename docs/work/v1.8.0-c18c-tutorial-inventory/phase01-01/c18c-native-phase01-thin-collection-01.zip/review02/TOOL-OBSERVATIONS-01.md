# Independent tool observations

The first static control returned exit 1 at the final equality with the live
author worktree. The original helper is preserved as `static_checks.failed-01.py`,
and actual stdout/stderr/exit are `static-checks-01.*`. That helper already
verified the frozen candidate02 and normative manifest before this assertion.

The separately captured `live-drift-observation-01.*` shows the author's four
live postimages now differ from the frozen candidate02. Root separately
authorized candidate03 after the blank-line clarification. This is not evidence
that the frozen candidate02 or the reviewer copy changed, nor a failure of the
original source patch or native behavior. The updated static control checks
creation/revision exact postimages against the frozen snapshots and retains
the live-worktree hashes as separately qualified observations only. No author
or Root source is edited by the reviewer; the original failed command remains.
