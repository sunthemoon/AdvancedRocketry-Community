import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af')
WT = Path('D:/GitHub/arce-v180-c18c-native-20261005')
BASE = 'd04a116e6e6001f166bbf5e8f31fb78623a6b392'

def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

meta = json.loads((HERE/'inputs/SOURCE-CANDIDATE-02.json').read_text())
for name,row in meta['files'].items():
    assert pin((AUTHOR/'candidate02/postimages'/name).read_bytes()) == row['after']
    assert pin((HERE/'candidate02'/name).read_bytes()) == row['after']
manifest = (AUTHOR/'candidate02/EVIDENCE-MANIFEST-02.json').read_bytes()
assert pin(manifest)['sha256'] == '53dbf08b92e89ebe71c1a70edfc872d462f321a52390dee0e558fd0b8ce9664d'
for row in json.loads(manifest)['files']:
    assert pin((AUTHOR/'candidate02'/row['path']).read_bytes()) == {k:row[k] for k in ['bytes','sha256']}
governance = ['PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
govpins = [{'commit':BASE,'path':name,**pin(subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+name]))}
           for name in governance]
root_agents = Path('D:/GitHub/AdvancedRocketry-Community/AGENTS.md')
govpins.append({'scope':'effective live Root governance observation','path':str(root_agents),**pin(root_agents.read_bytes())})
(HERE/'POSTCHECK-01.json').write_text(json.dumps({'exit':0,'frozen_candidate02_files_exact':4,
    'author_candidate02_manifest_payloads_exact':44,'review_source_authority':'Frozen candidate02, not moving author WT.',
    'governance_named_pins':govpins,'author_old_manifest_sha256':'f751cf9bfb04ed770b7937e4d8609644d5bed8cb7adedc0d4876af71653b74fd',
    'reviewer_probe_sha256':pin((HERE/'test_independent.py').read_bytes())['sha256'],
    'no_root_author_source_edits_java_native_or_cleanup':True},indent=2)+'\n')
rows=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        rows.append({'path':path.relative_to(HERE).as_posix(),**pin(path.read_bytes())})
payload = {'schema':1,'scope':'Independent candidate02 source review;0C/0H/1M/0L;not candidate03/native/Gates.',
           'files':rows,'payloads':len(rows),'payload_bytes':sum(r['bytes'] for r in rows)}
with (HERE/'INTERNAL-MANIFEST-01.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps(payload,indent=2)+'\n')
with (HERE/'SHA256SUMS.txt').open('x',encoding='utf-8',newline='\n') as out:
    for row in rows:
        out.write(row['sha256']+'  '+row['path']+'\n')
    out.write(pin((HERE/'INTERNAL-MANIFEST-01.json').read_bytes())['sha256']+'  INTERNAL-MANIFEST-01.json\n')
print(json.dumps({'report':pin((HERE/'REVIEW-CANDIDATE02.md').read_bytes()),
    'manifest':pin((HERE/'INTERNAL-MANIFEST-01.json').read_bytes()),
    'checksums':pin((HERE/'SHA256SUMS.txt').read_bytes()),'payloads':len(rows),
    'payload_bytes':sum(r['bytes'] for r in rows)},indent=2))
