import dataclasses
import hashlib
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent / 'candidate02/scripts'))
import run_v180_classic_inventory_smoke as f

RAW = b'gamemode=adventure\nforce-gamemode=false\nview-distance=2\nsimulation-distance=3\nu=v\n'


class IndependentPrimitivesTest(unittest.TestCase):
    def reject(self, raw, code=None):
        with self.assertRaises(f.FixtureInputError) as found:
            f.parse_properties(raw)
        if code is not None:
            self.assertEqual(code, str(found.exception))

    def test_ascii_space_only_physical_lines_have_no_logical_entries(self):
        # Root's individually recorded clarification, not the old model's rule.
        self.assertEqual({'k': 'v'}, f.parse_properties(b' \r\nk=v\n   \n'))

    def test_empty_lf_crlf_comments_remain_logically_ignored(self):
        self.assertEqual({'k': 'v'}, f.parse_properties(b'\n\r\n#x\n!x\r\nk=v'))

    def test_other_whitespace_is_not_blank_or_a_comment_prefix(self):
        for text in ['\t', '\f', '\u00a0', '\u2003', ' #x', ' !x', 'k= v', ' k=v']:
            with self.subTest(text=text):
                self.reject(text.encode('utf-8'))

    def test_raw_controls_and_decoded_escapes_remain_distinct(self):
        for code in [0, 9, 12, 31, 127, 128, 159]:
            with self.subTest(code=code):
                self.reject(('!comment' + chr(code)).encode(), 'PROPERTIES_LITERAL_CONTROL')
        self.assertEqual({'k\t': '\n\r\f'}, f.parse_properties(br'k\t=\n\r\f'))

    def test_utf8_scalar_encoding_and_literal_unicode_are_separate(self):
        self.assertEqual({'k': '\u00e9\U0001f642'}, f.parse_properties('k=\u00e9\U0001f642'.encode()))
        for bad in [b'k=\xc0\xaf', b'k=\xed\xa0\x80', b'k=\xf4\x90\x80\x80']:
            self.reject(bad, 'PROPERTIES_ENCODING')

    def test_escaped_separator_and_alias_duplicate_boundary(self):
        self.assertEqual({'k=:#': '=:#'}, f.parse_properties(br'k\=\:\#==\:\#'))
        self.reject(br'k#=v' + b'\n' + br'k\#=v', 'PROPERTIES_DUPLICATE')
        self.reject(br'k\=v', 'PROPERTIES_SEPARATOR')

    def test_byte_count_and_pairs_are_independent_limits(self):
        self.assertEqual(16382, len(f.parse_properties(b'k=' + b'x'*16382)['k']))
        self.reject(b'k=' + b'x'*16383, 'PROPERTIES_BYTES')
        exact = b'\n'.join(('k'+str(i)+'=v').encode() for i in range(1023))
        self.assertEqual(1023, len(f.parse_properties(exact)))
        self.reject(exact + b'\nk1023=v', 'PROPERTIES_PAIRS')

    def test_physical_continuation_is_not_escape_content(self):
        self.reject(b'k=v\\\r\nx=y', 'PROPERTIES_ESCAPE')
        self.assertEqual({'k': 'v\\', 'x': 'y'}, f.parse_properties(b'k=v\\\\\r\nx=y'))

    def test_observation_raw_map_and_hash_do_not_alias_parsed_dictionary(self):
        obs = f.PropertiesObservation(RAW)
        owned = f.parse_properties(RAW)
        owned['u'] = 'different'
        self.assertEqual('v', obs.values['u'])
        self.assertEqual(hashlib.sha256(RAW).hexdigest(), obs.sha256)
        with self.assertRaises(TypeError):
            obs.values['u'] = 'other'
        with self.assertRaises(dataclasses.FrozenInstanceError):
            obs.raw = b'x=y'

    def test_comments_order_and_escape_spelling_can_change_raw_not_whole_map(self):
        first = f.PropertiesObservation(RAW)
        rewrite = f.PropertiesObservation(b'!new\r\nu=v\r\nsimulation-distance=3\r\n'
            b'view-distance=2\r\nforce-gamemode=false\r\ngamemode=adventure\r\n')
        f.require_logical_equality(first, rewrite)
        self.assertNotEqual(first.raw, rewrite.raw)
        self.assertNotEqual(first.sha256, rewrite.sha256)
        with self.assertRaises(f.FixtureInputError):
            f.require_boot_binding('seed', first, rewrite, rewrite.sha256)
        f.require_boot_binding('reload', first, rewrite, rewrite.sha256, seed_stopped=rewrite)
        f.require_live_binding(first, rewrite, rewrite.sha256)
        with self.assertRaises(f.FixtureInputError):
            f.require_stopped_binding(first, rewrite)

    def test_unknown_map_entries_and_scalar_strings_are_never_defaulted(self):
        first = f.PropertiesObservation(RAW)
        for raw in [RAW+b'new=v\n', RAW.replace(b'u=v\n', b''), RAW.replace(b'u=v', b'u=w'),
                    RAW.replace(b'view-distance=2', b'view-distance=02')]:
            with self.subTest(raw=raw), self.assertRaises(f.FixtureInputError):
                f.require_live_binding(first, f.PropertiesObservation(raw), hashlib.sha256(raw).hexdigest())

    def test_strict_input_types_do_not_call_foreign_callbacks(self):
        class Foreign:
            def __bool__(self):
                raise AssertionError('foreign callback')
            def __str__(self):
                raise AssertionError('foreign callback')
        for value in [Foreign(), memoryview(RAW), bytearray(RAW), None, True]:
            with self.subTest(kind=type(value)), self.assertRaises(f.FixtureInputError):
                f.parse_properties(value)
        with self.assertRaises(f.FixtureInputError):
            f.commands_for_phase(Foreign())

    def test_command_selection_is_closed_and_independent_of_ack_coordinates(self):
        for x in range(-5, 6):
            for z in range(-5, 6):
                ack = f.parse_seed_acknowledgement(f'Marked chunk [{x}, {z}] in minecraft:overworld to be force loaded')
                self.assertEqual((x,z), ack.last_changed_chunk)
        self.assertEqual(('forceload add -80 -80 95 95',), f.commands_for_phase('seed'))
        self.assertEqual((), f.commands_for_phase('reload'))
        for value in ['', ' seed', 'reload\nstop', 1, True, None]:
            with self.subTest(value=value), self.assertRaises(f.FixtureInputError):
                f.commands_for_phase(value)

    def test_multiple_ack_is_position_not_count_or_authority(self):
        ack = f.parse_seed_acknowledgement('Marked [-5, 5] chunks in minecraft:overworld from [-5, -5] to [5, 5] to be force loaded')
        self.assertEqual(('multiple', (-5,5)), (ack.form,ack.last_changed_chunk))
        self.assertFalse(hasattr(ack,'changed_count'))
        with self.assertRaises(dataclasses.FrozenInstanceError):
            ack.form = 'other'

    def test_native_ack_payload_has_no_origin_or_whitespace_normalization(self):
        valid = 'Marked chunk [0, 0] in minecraft:overworld to be force loaded'
        for text in [valid+'\n', valid+'\x00', ' '+valid, valid+' ', '[Server thread/INFO] '+valid,
                     valid.replace('[0, 0]', '[00, 0]'), valid.replace('[0, 0]', '[-0, 0]'),
                     valid.replace('[0, 0]', '[\u0660, 0]'), valid.replace('[0, 0]', '[6, 0]')]:
            with self.subTest(text=text), self.assertRaises(f.FixtureInputError):
                f.parse_seed_acknowledgement(text)

    def test_error_codes_do_not_disclose_property_values(self):
        try:
            f.parse_properties(b'secret=password\nsecret=do-not-log')
        except f.FixtureInputError as error:
            self.assertEqual('PROPERTIES_DUPLICATE', str(error))
        else:
            self.fail('duplicate accepted')


if __name__ == '__main__':
    unittest.main()
