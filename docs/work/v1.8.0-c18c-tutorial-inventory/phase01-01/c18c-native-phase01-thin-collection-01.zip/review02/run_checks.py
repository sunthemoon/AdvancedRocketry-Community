import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
COPY = HERE / 'candidate02'
env = os.environ.copy()
for key in ['TEMP', 'TMP', 'TMPDIR']:
    env[key] = str(HERE)
jobs = [
    ('author-unit', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p',
                    'test_run_v180_classic_inventory_smoke.py', '-v'], COPY),
    ('independent-unit', [sys.executable, '-B', '-m', 'unittest', 'test_independent', '-v'], HERE),
    ('cli', [sys.executable, '-B', str(COPY/'scripts/run_v180_classic_inventory_smoke.py')], HERE),
]
results = []
for name, command, cwd in jobs:
    (HERE / (name + '.command.json')).write_text(json.dumps({'command':command, 'cwd':str(cwd),
        'process_temp':str(HERE), 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2)+'\n')
    done = subprocess.run(command, cwd=cwd, env=env, capture_output=True)
    (HERE / (name + '.stdout.log')).write_bytes(done.stdout)
    (HERE / (name + '.stderr.log')).write_bytes(done.stderr)
    (HERE / (name + '.exit')).write_text(str(done.returncode)+'\n')
    results.append({'job':name, 'exit':done.returncode,
                    'stdout_sha256':hashlib.sha256(done.stdout).hexdigest(),
                    'stderr_sha256':hashlib.sha256(done.stderr).hexdigest()})
(HERE / 'RUN-RESULTS-01.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
