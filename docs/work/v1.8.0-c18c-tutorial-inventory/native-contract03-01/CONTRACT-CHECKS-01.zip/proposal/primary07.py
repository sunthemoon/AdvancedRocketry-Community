"""Selected native emitted location/game-mode field references, no native write."""
from pathlib import Path

base = Path(__file__).resolve().parent
text = (base / 'primary01.py').read_text(encoding='utf-8')
text = text.replace('net/minecraft/commands/arguments/BlockPosArgument.class',
                    'net/minecraft/commands/arguments/coordinates/BlockPosArgument.class')
text = text.replace("out = {'jar_sha256':", "requests = {\n"
    " 'net/minecraft/server/level/ServerPlayer.class': {'addAdditionalSaveData'},\n"
    " 'net/minecraft/world/entity/Entity.class': {'saveWithoutId', 'newDoubleList', 'newFloatList'},\n"
    " 'net/minecraft/world/level/GameType.class': {'getId', '<clinit>'},\n"
    "}\nout = {'jar_sha256':")
text = text.replace('HOST-PRIMARY-01.json', 'RECORD-PRIMARY-07.json')
exec(compile(text, str(base / 'primary01.py'), 'exec'))
