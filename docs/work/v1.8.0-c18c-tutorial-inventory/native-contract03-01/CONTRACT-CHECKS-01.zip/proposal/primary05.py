"""Follow only native tracking/loaded-cell references needed by host preflight."""
from pathlib import Path

base = Path(__file__).resolve().parent
text = (base / 'primary01.py').read_text(encoding='utf-8')
text = text.replace('net/minecraft/commands/arguments/BlockPosArgument.class',
                    'net/minecraft/commands/arguments/coordinates/BlockPosArgument.class')
text = text.replace("out = {'jar_sha256':", "requests = {\n"
    " 'net/minecraft/server/level/ChunkTracker.class': {'checkNeighborsAfterUpdate'},\n"
    " 'net/minecraft/world/level/Level.class': {'getBlockState'},\n"
    " 'net/minecraft/server/level/ServerLevel.class': {'getAllEntities'},\n"
    " 'net/minecraft/world/level/entity/LevelEntityGetterAdapter.class': {'getAll'},\n"
    " 'net/minecraft/world/level/entity/EntityLookup.class': {'getAllEntities'},\n"
    " 'net/minecraft/server/players/PlayerList.class': {'getViewDistance', 'getSimulationDistance'},\n"
    "}\nout = {'jar_sha256':")
text = text.replace('HOST-PRIMARY-01.json', 'HOST-PRIMARY-05.json')
exec(compile(text, str(base / 'primary01.py'), 'exec'))
