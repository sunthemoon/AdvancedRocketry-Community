"""Selected host-admission declaration/constant facts; no Java or native launch."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
P = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(P.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P), 'exec'), ns)
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/'
         'net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/'
         'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(J.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/server/level/ChunkMap.class': {'setViewDistance', 'updatePlayerStatus'},
    'net/minecraft/server/level/DistanceManager.class': {'getPlayerTicketLevel', 'updateSimulationDistance'},
    'net/minecraft/server/level/DistanceManager$PlayerTicketTracker.class': {
        '<init>', 'updateViewDistance', 'haveTicketFor'},
    'net/minecraft/server/players/PlayerList.class': {'setViewDistance', 'setSimulationDistance'},
    'net/minecraft/server/dedicated/DedicatedServerProperties.class': {'<init>'},
    'net/minecraft/world/level/BlockCollisions.class': {'<init>'},
    'net/minecraft/world/entity/EntityType.class': {'<clinit>', 'getDimensions'},
    'net/minecraft/world/entity/Entity.class': {'load', 'reapplyPosition', 'moveTo'},
    'net/minecraft/server/network/ServerGamePacketListenerImpl.class': {'teleport'},
    'net/minecraft/server/commands/SetWorldSpawnCommand.class': {'register', 'setSpawn'},
    'net/minecraft/commands/arguments/BlockPosArgument.class': {'getSpawnablePos'},
}
out = {'jar_sha256': sha(J.read_bytes()), 'classes': {}, 'java_launches': 0}
parsed = {}
with zipfile.ZipFile(J) as archive:
    for name, wanted in requests.items():
        data = archive.read(name)
        value = ns['parse'](data, wanted)
        parsed[name] = value
        methods = {}
        for method, info in value['selected_methods'].items():
            selected = info['instructions']
            if name.endswith('DedicatedServerProperties.class'):
                # Configuration key declarations; neighboring numeric defaults/clamps only.
                keys = [i['offset'] for i in selected if i['reference'] in ('view-distance', 'simulation-distance')]
                selected = [i for i in selected if any(k <= i['offset'] <= k + 18 for k in keys)]
            if name.endswith('EntityType.class') and method == '<clinit>()V':
                player = next(i['offset'] for i in selected if i['reference'] and 'EntityType.PLAYER' in i['reference'])
                selected = [i for i in selected if player - 35 <= i['offset'] <= player]
            if name.endswith('Entity.class') and method.startswith('load('):
                selected = [i for i in selected if i['reference'] in ('Pos', 'Motion', 'Rotation', 'NaN entity position',
                    'RootVehicle') or (i['reference'] and any(part in i['reference'] for part in (
                    '.getList', '.getDouble', '.getFloat', '.setPos', '.setDeltaMovement', '.readAdditionalSaveData',
                    'Doubles', 'Double.isNaN', 'Double.isFinite', 'Math.min', 'Math.max')))]
            methods[method] = {'access': info['access'],
                'references': [{'offset': i['offset'], 'reference': i['reference']}
                               for i in selected if i['reference'] is not None],
                'branches': [{'offset': i['offset'], 'opcode': i['opcode_hex'],
                              'target': i['branch_target']}
                             for i in selected if i['branch_target'] is not None],
                'literal_constants': [{'offset': i['offset'], 'opcode': i['opcode_hex'],
                                      'operand': i['operand_hex']}
                    for i in selected if i['opcode_hex'] in ('0x3', '0x4', '0x5', '0x6', '0x7',
                                                          '0x8', '0x10', '0x11')]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data), 'selected_methods': methods}
(B / 'HOST-PRIMARY-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(out['classes']), 'methods': sum(len(x['selected_methods'])
      for x in out['classes'].values()), 'java_launches': 0}))
