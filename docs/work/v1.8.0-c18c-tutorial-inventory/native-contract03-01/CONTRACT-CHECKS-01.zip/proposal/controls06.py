"""Finite proposed-policy/primary-consistency controls; not fixture implementation."""
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import unittest

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
NEW = json.loads((B / 'PROTOCOL-02.json').read_text(encoding='utf-8'))
OLD_PATH = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json')
OLD = json.loads(OLD_PATH.read_text(encoding='utf-8'))
HOST = NEW['host_admission']
FLOAT = lambda s: struct.unpack('>f', bytes.fromhex(s))[0]
DOUBLE = lambda s: struct.unpack('>d', bytes.fromhex(s))[0]
BITS = lambda d: struct.pack('>d', d).hex()
WIDTH = FLOAT(HOST['player_dimensions_float_bits']['width'])
HEIGHT = FLOAT(HOST['player_dimensions_float_bits']['height'])
EPSILON = DOUBLE('3e7ad7f29abcaf48')
ENVELOPE = [(x, z) for x in range(-5, 6) for z in range(-5, 6)]


def sample_host():
    return {'world_data_game_type': 'adventure', 'raw_spawn': [0, 64, 0],
        'shared_spawn': [0, 64, 0], 'minimum_height': -64, 'maximum_height': 320,
        'view_distance': 2, 'simulation_distance': 3, 'dimensions': ['3f19999a', '3fe66666'],
        'border': [-1000.0, -1000.0, 1000.0, 1000.0],
        'loaded': list(ENVELOPE), 'visible_entities': 0, 'target_occupied': False,
        'fixed_cells_air': True, 'dual_ownership': True}


def admission_model(h):
    # This pure predicate intentionally has no constructor/cache/native API.
    if h['world_data_game_type'] != 'adventure':
        return False
    for key, expected in (('minimum_height', -64), ('maximum_height', 320),
                          ('view_distance', 2), ('simulation_distance', 3)):
        if type(h[key]) is not int or h[key] != expected:
            return False
    raw = h['raw_spawn']
    if type(raw) is not list or len(raw) != 3 or any(type(x) is not int for x in raw):
        return False
    if not -79 <= raw[0] <= 94 or not 64 <= raw[1] <= 256 or not -79 <= raw[2] <= 94:
        return False
    if h['shared_spawn'] != raw or h['dimensions'] != ['3f19999a', '3fe66666']:
        return False
    border = h['border']
    if len(border) != 4 or any(type(x) not in (float, int) or not math.isfinite(x) for x in border):
        return False
    if not (border[0] <= raw[0] - 1 and border[2] >= raw[0] + 2
            and border[1] <= raw[2] - 1 and border[3] >= raw[2] + 2):
        return False
    if h['loaded'] != ENVELOPE or type(h['visible_entities']) is not int or not 0 <= h['visible_entities'] <= 1024:
        return False
    return h['dual_ownership'] is True and h['fixed_cells_air'] is True and h['target_occupied'] is False


def sample_native_location(role):
    pos = NEW['fixed_identities'][role]['position']
    return {'Dimension': {'tag': 8, 'value': 'minecraft:overworld'},
        'Pos': {'tag': 9, 'element': 6, 'bits': [BITS(float(x)) for x in pos]},
        'Motion': {'tag': 9, 'element': 6, 'bits': ['0000000000000000'] * 3},
        'Rotation': {'tag': 9, 'element': 5, 'bits': ['00000000'] * 2},
        'playerGameType': {'tag': 3, 'value': 1}}


def native_location_model(fields, role):
    # Symbolic typed-field model only, not an NBT reader or native emitted input.
    if 'RootVehicle' in fields:
        return False
    wanted = sample_native_location(role)
    return all(key in fields and fields[key] == value for key, value in wanted.items())


class Controls(unittest.TestCase):
    def test_original_critical_protocol_is_exact(self):
        keys = ('source_commit', 'fixed_identities', 'goal_ids', 'criterion',
            'native_empty_inventory_shape', 'item_counts_order', 'seed_events', 'reload_events',
            'common_fields', 'saved_criterion_fields', 'failure_codes', 'deadlines_seconds',
            'ceilings', 'forbidden_authorities')
        for key in keys:
            with self.subTest(key=key): self.assertEqual(OLD[key], NEW[key])

    def test_original_payload_fields_are_not_changed(self):
        for schema, fields in OLD['payload_schemas'].items():
            for key, value in fields.items():
                with self.subTest(schema=schema, key=key):
                    self.assertEqual(value, NEW['payload_schemas'][schema][key])

    def test_all_original_external_fields_are_preserved(self):
        for section in ('external_marker_fields', 'cohort_inputs_fields', 'external_receipt_fields'):
            for key, value in OLD[section].items():
                with self.subTest(section=section, key=key): self.assertEqual(value, NEW[section][key])

    def test_finite_copy_request_exact_chunks(self):
        xs = range(-80 // 16, 95 // 16 + 1)
        zs = range(-80 // 16, 95 // 16 + 1)
        self.assertEqual(ENVELOPE, [(x, z) for x in xs for z in zs])
        self.assertEqual(121, len(ENVELOPE))
        self.assertLessEqual(len(ENVELOPE), 256)
        self.assertEqual(['forceload add -80 -80 95 95'], HOST['console_setup'])

    def test_every_allowed_spawn_horizontal_cursor_is_loaded(self):
        cases = 0
        for spawn in range(-79, 95):
            center = spawn + 0.5
            low = math.floor(center - WIDTH / 2 - EPSILON) - 1
            high = math.floor(center + WIDTH / 2 + EPSILON) + 1
            self.assertEqual(3, high - low + 1)
            self.assertGreaterEqual(low, -80)
            self.assertLessEqual(high, 95)
            cases += 1
        self.assertEqual(174, cases)

    def test_vertical_cursor_and_native_iteration_bounds(self):
        for y in range(64, 320):
            low = math.floor(y - EPSILON) - 1
            high = math.floor(y + HEIGHT + EPSILON) + 1
            self.assertEqual(5, high - low + 1)
            self.assertEqual(45, 3 * 3 * (high - low + 1))
        self.assertEqual(256, len(range(64, 320)))
        self.assertEqual(11520, 256 * 45)

    def test_safe_samples_are_only_predicate_results(self):
        self.assertTrue(admission_model(sample_host()))
        for raw in ([-79, 64, -79], [94, 256, 94]):
            h = sample_host(); h['raw_spawn'] = raw; h['shared_spawn'] = raw.copy()
            self.assertTrue(admission_model(h))

    def test_each_mode_non_adventure_refuses_without_model_calls(self):
        for mode in ('survival', 'creative', 'spectator', None):
            h = sample_host(); h['world_data_game_type'] = mode
            self.assertFalse(admission_model(h))

    def test_raw_spawn_and_fallback_bounds(self):
        for raw in ([-80, 64, 0], [95, 64, 0], [0, 63, 0], [0, 257, 0],
                    [0, 64, -80], [0, 64, 95], [True, 64, 0]):
            h = sample_host(); h['raw_spawn'] = raw; h['shared_spawn'] = raw.copy()
            self.assertFalse(admission_model(h))
        h = sample_host(); h['shared_spawn'] = [1, 64, 0]
        self.assertFalse(admission_model(h))

    def test_border_invalid_or_insufficient_refuses(self):
        for border in ([math.nan, -1000, 1000, 1000], [-1000, -1000, math.inf, 1000],
                       [0, -1000, 1000, 1000], [-1000, -1000, 1, 1000]):
            h = sample_host(); h['border'] = border
            self.assertFalse(admission_model(h))

    def test_each_loaded_chunk_missing_and_order_not_partial(self):
        for index in range(121):
            h = sample_host(); h['loaded'].pop(index)
            self.assertFalse(admission_model(h))
        h = sample_host(); h['loaded'].reverse()
        self.assertFalse(admission_model(h))

    def test_height_distances_dimensions_not_coerced(self):
        for key, value in (('minimum_height', 0), ('maximum_height', 384),
                           ('view_distance', 3), ('simulation_distance', 2), ('view_distance', True)):
            h = sample_host(); h[key] = value
            self.assertFalse(admission_model(h))
        h = sample_host(); h['dimensions'] = ['3f800000', '3fe66666']
        self.assertFalse(admission_model(h))

    def test_collision_entity_overflow_and_second_ownership_refuse(self):
        for key, value in (('visible_entities', 1025), ('visible_entities', True),
                           ('target_occupied', True), ('fixed_cells_air', False), ('dual_ownership', False)):
            h = sample_host(); h[key] = value
            self.assertFalse(admission_model(h))

    def test_native_role_positions_and_dimensions_are_exact(self):
        for role in (0, 1):
            fields = sample_native_location(role)
            self.assertTrue(native_location_model(fields, role))
            self.assertFalse(native_location_model(fields, 1 - role))
            fields['Dimension']['value'] = 'minecraft:the_nether'
            self.assertFalse(native_location_model(fields, role))

    def test_each_extra_native_field_missing_and_wrong_type(self):
        for key in sample_native_location(0):
            fields = sample_native_location(0); fields.pop(key)
            self.assertFalse(native_location_model(fields, 0))
            fields = sample_native_location(0); fields[key]['tag'] = 0
            self.assertFalse(native_location_model(fields, 0))

    def test_motion_rotation_nan_negative_zero_and_wrong_lengths(self):
        for field, bits in (('Motion', ['8000000000000000'] * 3),
                            ('Motion', ['7ff8000000000000'] * 3),
                            ('Motion', ['0000000000000000'] * 2),
                            ('Rotation', ['80000000'] * 2), ('Rotation', ['7f800000'] * 2)):
            fields = sample_native_location(0); fields[field]['bits'] = bits
            self.assertFalse(native_location_model(fields, 0))

    def test_vehicle_and_noncreative_save_refuse(self):
        fields = sample_native_location(0); fields['RootVehicle'] = {'tag': 10, 'value': {}}
        self.assertFalse(native_location_model(fields, 0))
        fields = sample_native_location(0); fields['playerGameType']['value'] = 2
        self.assertFalse(native_location_model(fields, 0))

    def test_order_is_two_constructors_before_either_join(self):
        allowed_trace = ['dual-admission', 'construct-earned', 'construct-control',
            'check-both', 'move-earned-unlisted', 'move-control-unlisted', 'join-earned', 'join-control',
            'observe-loaded', 'inventory-positive', 'dispose']
        self.assertLess(allowed_trace.index('construct-control'), allowed_trace.index('join-earned'))
        self.assertLess(allowed_trace.index('move-control-unlisted'), allowed_trace.index('join-earned'))
        self.assertLess(allowed_trace.index('observe-loaded'), allowed_trace.index('inventory-positive'))
        self.assertNotIn('corrective-teleport', allowed_trace)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {'tests': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'skips': len(result.skipped),
        'scope': 'pure specification models and exact protocol comparisons; not native/parser/fixture code',
        'horizontal_cursor_values': 174, 'vertical_cursor_values': 256,
        'missing_chunk_models': 121, 'java_launches': 0}
    (B / 'CONTROL-RESULT-06.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    raise SystemExit(not result.wasSuccessful())
