"""New final postimage check; keep the earlier checkpoint11 output unchanged."""
import ast
from pathlib import Path

B = Path(__file__).resolve().parent
tree = ast.parse((B / 'final11.py').read_text(encoding='utf-8'))


class OutputOnly(ast.NodeTransformer):
    replacements = 0

    def visit_Constant(self, node):
        if node.value == 'INPUT-POSTCHECK-11.json':
            self.replacements += 1
            return ast.copy_location(ast.Constant('INPUT-POSTCHECK-12.json'), node)
        return node


change = OutputOnly()
tree = change.visit(tree)
assert change.replacements == 3
exec(compile(ast.fix_missing_locations(tree), str(B / 'final12.py'), 'exec'),
     {'__file__': str(B / 'final12.py'), '__name__': '__main__'})
