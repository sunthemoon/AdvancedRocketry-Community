# C18 inventory fixture ownership and host admission proposal 02

Date: 2026-10-05. **PROPOSED, NOT IMPLEMENTED OR ACCEPTED.** This independently
versioned correction concerns test-host admission only. It leaves the sealed
proposal01, primary supplement, Root task and historical failures unchanged.
Root must obtain independent review and assign a new implementation task before
any source/configuration/native action. No original-world gameplay setting changes
are proposed or authorized here.

## 1. Finding addressed and exact context

The independent proposal01 review identifies Medium M1: a loaded final chunk and
post-join teleport do not bound the earlier constructor spawn search or the native
join's loaded dimension/position. Its immutable report SHA is
`9569049b655529fc33808d2145ecbf81b94cd2fe8eb81525ba1e59ebcd710cd6`, at
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-review-4ea16d018d/REVIEW-01.md`.
This is a source-backed specification gap, not an observed forced load or data loss.

Source basis remains `a5abc34809891d6b10724ee60ab9b5e97f036bae`, not a future
fixture artifact. Original proposal SHA
`5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581`;
original protocol `1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf`.
Original provenance is
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1`.
The separate frozen spawn/join supplement is
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-spawn-facts-02165b7f3c`;
report SHA `dfd35b6f0d66bf5904c1a05ca45b049da83678dcf103d7e72d41363973184d18`,
manifest `0ac21a34a0b77e2d0b4eaa30e16e5463a605af392e734bde165131da3eabc5e9`.
No earlier finding is erased or asserted resolved by authoring this proposal.

The exact machine-readable cumulative surface is [PROTOCOL-02.json](PROTOCOL-02.json).
The old ownership/reflection/receipt/disposal rules remain normative except for
the explicitly identified host, position-order and extra native-record checks
below. [Structured delta](PROTOCOL-DELTA-04.json) identifies every changed key.
Unchanged rules are restated here sufficiently to prevent relying on an informal
memo or a future guessed implementation. This document is not a public gameplay API.

## 2. Unchanged authority, targets and ownership

- Only `arce classic-inventory release-test seed` and
  `arce classic-inventory release-test reload`. No path/identity/item/position
  arguments. Both `advancedrocketrycommunity.releaseTestHooks` and
  `.classicInventoryFixture` must be true; phase/runId/receiptSha256 launch
  binding, UTC JVM timezone, native permission 4/entity-null/exact `Server` name,
  actual dedicated-server thread and no connected players are unchanged.
- Earned identity is `180c1800-0000-4000-8000-000000000001`, `ArceC18Owned`,
  `(8.5,200,8.5)`; control is UUID ending `0002`, `ArceC18Control`,
  `(10.5,200,8.5)`. These are proposed test identities, not gameplay IDs or proof
  of ownership. Both have nonoperator permissions and actual Creative mode after
  admitted join; neither is FakePlayer.
- Six ordered tutorial IDs remain `root`, `block_press`, `rolling`, `electrolysis`,
  `suited_up`, `warp_core` under `advancedrocketrycommunity:classic/`, each
  criterion `has_inventory`. The targets remain crafting table, small plate
  press, rolling machine, electrolyzer, all four distinct suit pieces in the
  same current inventory, and warp core. Every target count is 1, no metadata;
  cobblestone is the unrelated control. Tree/localizations/empty rewards are not
  changed. Only inventory.setItem and ordinary inventoryMenu.broadcastChanges
  drive the actual listener; no grant/direct trigger/reward simulation.
- First seed requires both UUIDs' fixed dat/dat_old/advancement/stats files absent,
  no matching temporary UUID-prefix dat, no online/name/UUID/profile/cache collision
  and no orphan native stats/advancement entry, **before either constructor**.
  Refuse, never reset/delete/adopt existing records. Directory cap is 1,024.
- Read-only native profile/name/UUID/request and PlayerList stats/advancement
  inspection remains test-only proposed reflection on the exact mapped/SRG fields
  and classes frozen in proposal01. No new reflection field is added here.
  Descriptors/modifiers, exact ConcurrentHashMap/HashMap/native entry classes,
  <=1,000 entry maps, two consistent snapshots, empty requests/native progress
  caches and cache file/path binding remain. No public get(name/UUID), network
  lookup, Field.set, AT/coremod or map mutation is admissible for collision checks.
  Expired/cross-name entries are collisions; seed <=998 unrelated profiles.
- Marker uses CREATE_NEW in the fixed copy-local `.classic-inventory-fixture`
  directory. Only the trusted driver creates ownership-v1.json after a complete
  seed action, explicit disposal, independently verified clean stop and bounded
  native record inspection. It binds actual future source/JAR/library/real paths,
  run, eight exact files and stopped observations. The receipt supplies no loaded
  progress, awards, repair or replacement data. Wrong/missing/partial/future/
  duplicate/world/run/artifact/hash/record inputs refuse before construction.
- Local owned handles and attempt-all finally/disposal are unchanged: remove only
  exact owned listed objects; handle partly registered/unlisted objects without
  foreign UUID removal; stop native listeners, disconnect/close/drain/release
  exact channels with <=2,048 messages. Failures are not rollback. Preserve
  partial files/maps/logs, emit no success receipt and abandon a failed copy.

## 3. Copy-only host setup and finite native route

### 3.1 Selected correction

Use a narrowly restricted copy-local default **Adventure** game type, rather than
adding an override or bounding the non-Adventure random spawn search. Keep native
shared spawn unchanged and restrict its observed coordinates. Construct both
owned objects before either join; move the unlisted objects to the already-fixed
role positions before native join. On reload independently validate the native
saved location first, so PlayerList.load cannot select a foreign dimension or
position. Do not use a later ServerPlayer.teleportTo as the loaded-only proof.

Root's proposal-only authority permits copy-local host restrictions. This is not
permission to execute or change the original server/world. Selection of a suitable
named source server/world remains unrun. If it does not meet these restrictions,
keep refusal; Root must select another separately pinned suitable input, not
repair/reset source records, change the six recipes/goals or enlarge deadlines.

### 3.2 Fixed settings and one bounded setup command

Before the first boot, configure only the owned disposable copy with:
`gamemode=adventure`, `force-gamemode=false`, `view-distance=2`,
`simulation-distance=3`. Hash its exact server.properties into the run marker;
use the same file/hash on reload. Existing localhost/offline/empty-whitelist/
no-extra-mod/no-other-command restrictions remain. Preserve the original config
and source world by pre/post manifest. Do not reset a nonempty whitelist or adopt
colliding ops/bans/cache records. No gameplay production setting changes.

After each startup and before the fixture action, the only new literal setup
command is `forceload add -80 -80 95 95`, scoped to the admitted Overworld copy.
This requests exactly the 121 chunk pairs `[-5..5] × [-5..5]`; it has no dynamic
coordinates, paths or identity. A native command refusal or incomplete loading
fails under the unchanged host/action/cohort deadlines. Do not remove historical
forced chunks, repeat with wider bounds, use setworldspawn, fill, teleport or terrain
editing to manufacture admission. The hook never issues a load request: it checks
every pair using `getChunkNow`, in fixed lexicographic order, before construction.

Normal server startup/vanilla player tracking are real native behavior, not
globally load-free automation. The claim is bounded **fixture constructor/join
admission**, not that an ordinary server cannot load anything else. The finite
copy-driver request is explicit; no player/client position can expand it.

### 3.3 Exact pre-constructor host gate

After the fixed driver setup, validate all of the following on the server thread
in the same synchronous action, before either constructor/Connection/channel:

1. Actual server WorldData.getGameType is ADVENTURE. Observed PlayerList view
   distance is 2 and simulation distance is 3. Min build height is -64 and
   max build height is 320. These are narrow test-host eligibility, not accepted
   global dimension limits or property-file-only assertions.
2. Read raw level-data spawn X/Y/Z **before** getSharedSpawnPos. X and Z must each
   be integers in `[-79,94]`; Y in `[64,256]`. Native world-border min/max must be
   finite and fully contain the raw spawn collision region with an extra cell:
   `[X-1,X+2] × [Z-1,Z+2]`. Its native isWithinBounds(raw BlockPos) must also be true.
   Then getSharedSpawnPos must equal the raw coordinates. Do not admit the
   border-center/heightmap fallback or call it before checking the raw border gate.
3. Actual EntityType.PLAYER dimensions have float bits width `3f19999a` and height
   `3fe66666` (0.6f/1.8f). Fixed mod/library inputs and no size-altering fixture or
   extra mod are required; no public dimension override is added. Unexpected
   dimensions refuse; actual constructor bounds need later packaged proof.
4. All 121 chunk pairs are already returned by getChunkNow. Missing/null/future
   chunk state refuses; no getChunk(create=true), chunk generation, forced lookup,
   world-border fallback or recursive retry is used by the gate.
5. The four unchanged target foot/head cells are air, read directly from the
   admitted chunk0 LevelChunk rather than a world getter with create=true.
   Require bounded enumeration of visible native loaded entity objects using
   public ServerLevel.getAllEntities (at most 1,024 plus one overflow observation) with no
   existing object occupying either fixed target body. No global world scan or
   new loaded-chunk query is permitted. A future implementation must use native
   loaded entity getters; never create an observer player, scan an unbounded list
   or invoke foreign callback implementations. Count overflow refuses.
6. The complete unchanged two-identity ownership/file/cache gate also passes.
   All observations are finished before either constructor. Scene/cache/default
   changes during a later owned stage are failure, not a refreshed admission.

Raw-spawn X/Z bounds are derived from the native centered 0.6f box and padded
collision cursor: its horizontal read cells range from X-1 to X+1 (and likewise
Z), hence remain within block coordinates -80..95. Adventure skips the create=true
spawn-search branch; the alternate collision chunks use create=false. With
min shared Y64 and native max320, the alternate route checks at most 256 integer
Y positions (64..319). The 1.8f box's padded cursor has at most `3 × 5 × 3 = 45`
candidate cells per iteration, so at most 11,520 per constructor. Solid terrain
may cause the finite native vertical adjustment; no terrain must be cleared and
no exact initial spawn Y is presumed as an executed outcome. Failure to achieve
a usable native object aborts its owned action. This source-derived bound is not
an interruptible Java-call or successful performance measurement.

The fixed loaded radius5 also covers the native tracking neighborhood after each
object is at chunk0: the inspected view-distance clamp2 and updatePlayerStatus
loop reach at most radius3; simulation distance3 and native ENTITY_TICKING31 versus
FULL33 yield a conservative full-status influence radius5 at unit neighbor cost.
This is an observed constant/reference derivation, not a proof that every native
loader/generator dependency or background tick is limited to those 121 chunks.
The construction/join path must not contain an extra fixture portal/teleport/load
request; actual-source and native checks remain required.
Primary facts: [host declarations/constants](HOST-PRIMARY-03.json),
[public loaded-only observers](HOST-PRIMARY-05.json), plus the
unchanged separately pinned spawn/join supplement above. No official bodies/JARs
or mappings are copied into this proposal.

## 4. Construction, join and reload record order

Inside one command-local try/finally:

1. Finish dual ownership and host admission. Capture only observational values,
   not a fake permission token/GuardTicket. No global player/host cache is introduced.
2. Construct the earned object, immediately retain the returned owned reference;
   construct the control object and retain it. **Neither is joined/listed yet.**
   Thus the first player cannot become a new listed entity obstructing the second's
   constructor route. Partial constructor failure has no rollback promise.
3. Validate both native objects' level, coordinates/dimensions and unlisted state
   against the admitted finite constructor route. Any unexpected native default,
   callback or ownership result aborts; do not refresh a changed host/cache snapshot.
4. Use ordinary Entity.moveTo on each **unlisted owned object**, assigning the
   unchanged fixed role position and yaw/pitch +0.0. Do not use ServerPlayer's
   cross-level teleportTo, create a ticket, change terrain or bypass native load.
5. Create the owned connections/channels and call native placeNewPlayer in role
   order. For seed, absent dat means the preassigned fixed location remains the
   initial native join location. For reload, the independently inspected native
   dat must load exactly that same role's Overworld location. Before moving,
   clearing or acquiring anything after join, verify actual native level/position,
   no vehicle, zero motion/rotation and actual cache/list object membership.
   Unexpected position/dimension is failure, **never corrected by teleport**.
6. Set/verify actual Creative mode as previously specified, then retain the
   unchanged INITIAL/CONTROL/ACQUIRE or LOADED/REPLAY sequence. All inventory
   listener events, exact receipts, control negatives, experience/counts, target
   removal and disposal are unchanged. The action remains synchronous; no server
   tick service, sleep/wait/re-entry to let players move, external login or extra
   console command is admitted during it.

The native record reader gains only these explicit fixture-observation fields,
for `.dat` and optional `.dat_old`, before any constructor on reload:

| Field | Exact native input shape/value |
|---|---|
| Dimension | TAG_String 8, `minecraft:overworld` |
| Pos | TAG_List 9 of Double 6, count 3; exactly the fixed role position |
| Motion | TAG_List 9 of Double 6, count 3; three raw positive-zero bits |
| Rotation | TAG_List 9 of Float 5, count 2; two raw positive-zero bits |
| playerGameType | TAG_Int 3, value 1 (Creative native save) |
| RootVehicle | absent, not an empty Compound or an adopted vehicle |

Reject missing/duplicate/wrong-type/length/nonfinite/out-of-bound/foreign values.
No number coercion, signed-zero normalization, replacement position, fallback
dimension, backup repair or additional player-state writer is authorized. All
other bounded valid native fields are retained/read, not normalized. These are
test-owned-record admission, not a new playerdata migration or global NBT policy.
Native field/type references are independently pinned in
[record save facts](RECORD-PRIMARY-07.json) and the actual referenced
[storeGameTypes helper](RECORD-PRIMARY-08.json). These are static native emission
paths, not an emitted or successfully reloaded record.
The receipt's new native_locations observations must be derived from actual stopped
files, equal the fixed expectations, and match later files before reload. Raw native
file hashes remain authoritative binding; a JSON location claim alone is insufficient.
Its host_admission_sha256 preserves the exact **seed** observed host object and
must agree with the independently preserved seed report. Reload independently
checks the same property hash/default mode/raw shared spawn/min-max height/view-
simulation distances/dimension bits and fixed envelope. It need not match the
seed's dynamic visible-entity count or world-border numbers: each phase must
separately satisfy their count/containment gates. Do not treat a receipt digest
as a substitute for current native observation or invent observed loop counts.

Native UUID IntArray4, Inventory tag9/subtype0/count0, gzip single-member/trailing
rules, all41 live empty cells, exact saved UTC criterion strings/seconds and
within-host milliseconds are unchanged. Loaded progress is inspected before any
positive acquisition/replay; receipt values never reconstruct or grant progress.

## 5. Exact additive parser/report changes; unchanged limits

Protocol02 retains schema1 on observational rows, marker and receipt, but adds an
exact host_revision=2 field to marker/cohort/receipt and requires the additional
field sets. This is a separately versioned test contract; no old schema1 marker
or pre-existing plausible player record is adopted. The future driver/hook must
both implement this exact shape; extra/missing fields still refuse.

- PREFLIGHT adds one actual host_admission object: revision, WorldData game type,
  raw/shared spawn, border qualification, min/max height, view/simulation distance,
  loaded envelope/count, loaded entity count and native dimension bits. The 256
  bound is explicitly derived, not a fabricated observed loop count.
- PLAYER_STATE adds native_location: actual dimension/position/motion/rotation/
  vehicle observation. No new gameplay state is stored or controlled by that row.
- Marker adds the exact copy server.properties hash; receipt adds the strict
  PREFLIGHT host observation digest and two fixed role native_locations.
- No new command, goal, item, event, criterion, failure-code enum, player identity,
  cache reflection field or gameplay/persistence/protocol is introduced.

All23 success events remain the original seed12/reload11 order. INFO native server
logger `ARCE_C18_INVENTORY`, exact authority/header/strict JSON/phase/index parsing,
unknown ERROR/FATAL failure and no arbitrary exception-controlled reason text remain.
The unchanged bounds are 16,384 bytes/row and each external JSON, depths8/12,
2,048 nodes, 393,216 bytes/cohort; native dat 262,144 compressed/1,048,576 raw,
depth32/65,536 nodes; advancements262,144/depth16/32,768 nodes/2,048 IDs;
stats131,072/depth16/16,384 nodes/2,048 entries; usercache262,144/depth8/16,384
nodes/1,000 profiles; fixed directories1,024 and channels2,048 messages.

**No deadline is increased.** One monotonic 300-second cohort: copy/intake60,
each host110 (startup60/action including cleanup20/stop30), final validation20;
hook internal checks10 and poll0.2. Setup/loading consumes the existing startup
and cohort remaining budget. Bounds are checked before allocation. Native calls
are not claimed preemptible. Timeout/refusal/unknown error preserves raw evidence,
stops only the started host, prevents success receipt and forbids retry-as-pass.

## 6. Required implementation and evidence obligations

This task writes no implementation. The same four proposed test-only responsibilities
remain: fixture command/report coordination, local owned player/channel lifecycle,
ownership/cache/host admission, and bounded native/JSON observational records.
Host checks fit the ownership class; position ordering fits the owned-player class;
the six native fields fit the record reader. No production helper, world writer,
large framework, public reflection or advancement authority is required.

Future source tests must examine actual branch/default mode rather than assuming
player.isCreative chooses it; raw border fallback, shared-spawn bounds, every
loaded-envelope edge/missing chunk, wrong native dimensions/height/default mode,
wrong view/simulation distance, entity overflow and first/second-object failures.
Construction/join call ordering must be traced: complete dual preflight, two
constructors, two preassigned positions, then native joins, loaded observations,
then inventory. Verify no later corrective teleport or automatic reload repair.

Add strict bounded native record fixtures for every extra field and malformed,
nonfinite, signed-zero, wrong dimension/position/vehicle/gamemode alternative;
positive fixture data must come from an independently inspected native emission,
not an invented loader result. Preserve all earlier ownership/map/file/header/
channel tests. Refusal before construction must have zero constructor/join/cache
mutator/connection/load calls; admitted partial failure remains owned-only cleanup,
not rollback. Source-only specification models cannot establish these calls.

The future real host must pin committed fixture source/JAR/libraries/copy settings,
raw setup/command/time/exits, all authoritative rows and stopped native files.
It must establish the Adventure branch/loaded footprint and actual constructor/join
location before any acquisition, real inventory listener and vanilla progress
reload, with original source-world/artifacts byte-exact. An unknown ERROR/FATAL
or refusal remains failed; the historical Guard world is not automatically an
eligible C18 source. Connected mocks are not real-client V1/V2/GPU or version Gate
evidence. No production API/admission, Guard lifecycle or R-021 closure is implied.

## 7. Actual preparation checks and unresolved matters

The old protocol's critical goals/identities/events/deadlines/ceilings/native empty
Inventory and forbidden authorities are compared exactly in
[PROTOCOL-DELTA-04.json](PROTOCOL-DELTA-04.json). New source-backed constants and
finite abstract controls are not a native outcome. The actual
[control results](CONTROL-RESULT-06.json) are 18 pure specification tests, zero
failures/errors/skips. These include all174 allowed horizontal cursor values,
256 vertical cursor values, 121 missing-chunk alternatives, host/location/refusal
models and unchanged protocol fields; the invented order trace is a declared
specification sample, not an observed call trace. No Java/native was launched.

First primary inspector used an incorrect BlockPosArgument declaration package and
exited1; its [raw failure](primary-01.log) is preserved. Separately corrected named
reads `primary02.py` and `primary03.py` exited0. No source or old evidence was edited.

Remaining technical gates: independent review of this exact cumulative document/
protocol; actual-source implementation and callback/record/cache mapping tests;
suitable immutable source host selection; native constructor/tracking/loading and
bounded deadline observation; clean stopped-file and two-host vanilla reload proof.
No owner gameplay choice is selected or newly required by the proposed copy-local
default-mode restriction. If primary/runtime observations contradict these bounds,
retain the failure and separately revise the technical contract; do not silently
normalize, widen limits, override private spawn or rewrite original records.
