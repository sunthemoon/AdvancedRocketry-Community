"""Preserve an exact textual/structured proposal delta; no patch is applied."""
import difflib
import hashlib
import json
import os
from pathlib import Path

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
old = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
pairs = [(old / 'OWNERSHIP-PROPOSAL-01.md', B / 'OWNERSHIP-PROPOSAL-02.md'),
         (old / 'PROTOCOL-01.json', B / 'PROTOCOL-02.json')]
records = []
parts = []
sha = lambda data: hashlib.sha256(data).hexdigest()
for before, after in pairs:
    a, b = before.read_bytes(), after.read_bytes()
    parts.append(''.join(difflib.unified_diff(a.decode('utf-8').splitlines(keepends=True),
        b.decode('utf-8').splitlines(keepends=True), fromfile='proposal01/' + before.name,
        tofile='proposal02/' + after.name)))
    records.append({'before_path': str(before), 'before_bytes': len(a), 'before_sha256': sha(a),
                    'after_path': after.name, 'after_bytes': len(b), 'after_sha256': sha(b)})
text = ''.join(parts).encode('utf-8')
(B / 'PROPOSAL-02.diff').write_bytes(text)
(B / 'DIFF-IDENTITY-10.json').write_text(json.dumps({'pairs': records,
    'diff_path': 'PROPOSAL-02.diff', 'diff_bytes': len(text), 'diff_sha256': sha(text),
    'scope': 'comparison only; no Root/task/old input edited or patch applied'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'document_sha256': records[0]['after_sha256'],
    'protocol_sha256': records[1]['after_sha256'], 'diff_sha256': sha(text), 'diff_bytes': len(text)}))
