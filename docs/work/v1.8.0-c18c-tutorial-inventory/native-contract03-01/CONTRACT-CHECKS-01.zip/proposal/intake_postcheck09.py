"""Pin exact named immutable context; avoid mutable HEAD and broad tree reads."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
root = Path('D:/GitHub/AdvancedRocketry-Community')
old = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
facts = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-spawn-facts-02165b7f3c')
review = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-review-4ea16d018d')
named = {
    root / 'AGENTS.md': '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0',
    root / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-02.md':
        'd1eebd7b4683ff9da0cacafa2e72f9bf98ed98d1552047c880b5310884e44ced',
    old / 'OWNERSHIP-PROPOSAL-01.md': '5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581',
    old / 'PROTOCOL-01.json': '1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf',
    old / 'EVIDENCE-MANIFEST.json': 'cc689403716863d8885092c1e26ab5eee720621d06058c1581166d37d03af2ae',
    review / 'REVIEW-01.md': '9569049b655529fc33808d2145ecbf81b94cd2fe8eb81525ba1e59ebcd710cd6',
    review / 'INTERNAL-MANIFEST.json': '7120aa8d39c369a96d903b8e33897b77db6adfabf4933ea9d95c30f3499416e3',
    facts / 'REPORT-01.md': 'dfd35b6f0d66bf5904c1a05ca45b049da83678dcf103d7e72d41363973184d18',
    facts / 'EVIDENCE-MANIFEST.json': '0ac21a34a0b77e2d0b4eaa30e16e5463a605af392e734bde165131da3eabc5e9',
    Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py'):
        '001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167',
    Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/'
         'net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/'
         'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'):
        '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e',
}
inputs = []
for path, wanted in named.items():
    data = path.read_bytes()
    entry = {'path': str(path), 'bytes': len(data), 'sha256': sha(data), 'expected_sha256': wanted,
             'unchanged': sha(data) == wanted}
    inputs.append(entry)
assert all(e['unchanged'] for e in inputs)
# Governance and relevant source were read in proposal01; re-read the named fixed
# Git objects, not current mutable status or a source export, and validate those pins.
prior = json.loads((old / 'INPUTS-01.json').read_text(encoding='utf-8'))
selected_paths = ('PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ConnectedTestPlayers.java')
git_pins = []
for path in selected_paths:
    identity = 'a5abc34809891d6b10724ee60ab9b5e97f036bae:' + path
    previous = next(e for e in prior['inputs'] if e['source'] == identity)
    command = ['git', 'show', identity]
    result = subprocess.run(command, cwd=root, capture_output=True, check=False)
    assert result.returncode == 0
    git_pins.append({'source': identity, 'bytes': len(result.stdout), 'sha256': sha(result.stdout),
        'unchanged': sha(result.stdout) == previous['sha256'], 'command': command, 'exit': result.returncode})
assert all(e['unchanged'] for e in git_pins)
class_pins = {}
for name in ('HOST-PRIMARY-02.json', 'HOST-PRIMARY-03.json', 'HOST-PRIMARY-05.json',
             'RECORD-PRIMARY-07.json', 'RECORD-PRIMARY-08.json'):
    for member, value in json.loads((B / name).read_text(encoding='utf-8'))['classes'].items():
        if member in class_pins:
            assert value['sha256'] == class_pins[member]['sha256']
        class_pins[member] = {'bytes': value['bytes'], 'sha256': value['sha256']}
links = []
for path in B.glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            links.append({'file': path.name, 'target': target,
                          'exists': (path.parent / target.split('#')[0]).exists()})
assert all(e['exists'] for e in links)
delta = json.loads((B / 'PROTOCOL-DELTA-04.json').read_text(encoding='utf-8'))
assert all(delta['unchanged_critical'].values())
out = {'external_inputs': inputs, 'fixed_git_inputs': git_pins, 'primary_class_pins': class_pins,
       'links': links, 'missing_links': 0, 'unchanged_critical': delta['unchanged_critical'],
       'scope': 'fixed named inputs; mutable live HEAD/status not used', 'java_launches': 0}
(B / 'INPUT-POSTCHECK-09.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'external_inputs': len(inputs), 'external_unchanged': sum(e['unchanged'] for e in inputs),
    'fixed_git_inputs': len(git_pins), 'fixed_git_unchanged': sum(e['unchanged'] for e in git_pins),
    'primary_classes': len(class_pins), 'links': len(links), 'missing_links': 0, 'java_launches': 0}))
