"""Separate corrected declaration locator; preserve primary01's failed attempt."""
from pathlib import Path

base = Path(__file__).resolve().parent
text = (base / 'primary01.py').read_text(encoding='utf-8')
text = text.replace('net/minecraft/commands/arguments/BlockPosArgument.class',
                    'net/minecraft/commands/arguments/coordinates/BlockPosArgument.class')
text = text.replace('HOST-PRIMARY-01.json', 'HOST-PRIMARY-02.json')
exec(compile(text, str(base / 'primary01.py'), 'exec'))
