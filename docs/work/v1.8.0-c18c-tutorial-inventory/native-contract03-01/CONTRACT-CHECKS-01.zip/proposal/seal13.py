"""Seal this small owned loose proposal only; no archive or external write."""
import hashlib
import json
import os
from pathlib import Path
import re

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
digest = lambda data: hashlib.sha256(data).hexdigest()
excluded = {'EVIDENCE-MANIFEST.json', 'SHA256SUMS', 'seal-13.log', 'seal-13.exit'}
assert not (B / 'EVIDENCE-MANIFEST.json').exists()
assert not (B / 'SHA256SUMS').exists()
files = sorted((p for p in B.iterdir() if p.is_file() and p.name not in excluded),
               key=lambda p: p.name)
entries = []
for path in files:
    data = path.read_bytes()
    entries.append({'path': path.name, 'bytes': len(data), 'sha256': digest(data)})
pins = json.loads((B / 'INPUT-POSTCHECK-12.json').read_text(encoding='utf-8'))
assert all(e['unchanged'] for e in pins['external_inputs'])
assert all(e['unchanged'] for e in pins['fixed_git_inputs'])
assert pins['actual_primary_member_checks'] == 20
assert pins['missing_links'] == 0
for entry in pins['proposal_postimages']:
    data = (B / entry['path']).read_bytes()
    assert entry['bytes'] == len(data) and entry['sha256'] == digest(data)
links = []
for path in files:
    if path.suffix == '.md':
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' not in target and not target.startswith('#'):
                plain = target.split('#')[0]
                destination = path.parent / plain
                assert destination.resolve().is_relative_to(B.resolve())
                assert destination.is_file()
                links.append({'file': path.name, 'target': target,
                              'sha256': digest(destination.read_bytes())})
for name in ('HOST-PRIMARY-02.json', 'HOST-PRIMARY-03.json', 'HOST-PRIMARY-05.json',
             'RECORD-PRIMARY-07.json', 'RECORD-PRIMARY-08.json'):
    raw = (B / name).read_text(encoding='utf-8')
    assert 'code_hex' not in raw and 'constant_pool' not in raw and 'instructions' not in raw
controls = json.loads((B / 'CONTROL-RESULT-06.json').read_text(encoding='utf-8'))
assert controls['tests'] == 18 and all(controls[k] == 0 for k in ('failures', 'errors', 'skips'))
exit_receipts = {}
for p in files:
    if p.suffix == '.exit':
        # PowerShell writes its retained exit text with a possible UTF BOM.
        data = p.read_bytes()
        text = data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
        exit_receipts[p.name] = int(text.strip())
assert exit_receipts['primary-01.exit'] == 1
assert all(e == 0 for name, e in exit_receipts.items() if name != 'primary-01.exit')
manifest = {'schema': 1, 'scope': 'proposal02 static preparation only; no source/config/native implementation',
    'fixed_source_commit': 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
    'files': entries, 'file_count': len(entries), 'total_bytes': sum(e['bytes'] for e in entries),
    'links': links, 'link_count': len(links), 'missing_links': 0,
    'external_input_postcheck': 'INPUT-POSTCHECK-12.json',
    'exit_receipts': exit_receipts, 'tests': controls,
    'java_launches': 0, 'new_C_outputs': 0, 'archives_created': 0,
    'excluded_seal_outputs': sorted(excluded), 'excluded_directory': 'process-temp',
    'limits': 'models/facts only; actual cache mapping, record parser, callbacks, join/listener/disposal/reload and eligible host remain unrun'}
(B / 'EVIDENCE-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
sums = ''.join(e['sha256'] + '  ' + e['path'] + '\n' for e in entries)
sums += digest((B / 'EVIDENCE-MANIFEST.json').read_bytes()) + '  EVIDENCE-MANIFEST.json\n'
(B / 'SHA256SUMS').write_text(sums, encoding='utf-8')
for e in entries:
    data = (B / e['path']).read_bytes()
    assert len(data) == e['bytes'] and digest(data) == e['sha256']
print(json.dumps({'files': len(entries), 'bytes': manifest['total_bytes'],
    'links': len(links), 'missing_links': 0, 'all_payload_hashes_verified': True,
    'manifest_sha256': digest((B / 'EVIDENCE-MANIFEST.json').read_bytes()),
    'checksum_sha256': digest((B / 'SHA256SUMS').read_bytes()),
    'proposal_sha256': digest((B / 'OWNERSHIP-PROPOSAL-02.md').read_bytes()),
    'protocol_sha256': digest((B / 'PROTOCOL-02.json').read_bytes()),
    'handoff_sha256': digest((B / 'HANDOFF-02.md').read_bytes()),
    'java_launches': 0, 'archives_created': 0}))
