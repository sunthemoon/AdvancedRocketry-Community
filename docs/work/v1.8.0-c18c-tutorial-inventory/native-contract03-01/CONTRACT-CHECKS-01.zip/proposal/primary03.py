"""Selected ticket-level constants needed to qualify a finite copy-local envelope."""
from pathlib import Path

base = Path(__file__).resolve().parent
text = (base / 'primary01.py').read_text(encoding='utf-8')
text = text.replace('net/minecraft/commands/arguments/BlockPosArgument.class',
                    'net/minecraft/commands/arguments/coordinates/BlockPosArgument.class')
text = text.replace("out = {'jar_sha256':", "requests.update({\n"
    " 'net/minecraft/server/level/ChunkLevel.class': {'byStatus', 'fullStatus', '<clinit>'},\n"
    " 'net/minecraft/server/level/ChunkTracker.class': {'computeLevelFromNeighbor'},\n"
    " 'net/minecraft/server/level/ServerChunkCache.class': {'getChunkNow'},\n"
    "})\nout = {'jar_sha256':")
text = text.replace('HOST-PRIMARY-01.json', 'HOST-PRIMARY-03.json')
exec(compile(text, str(base / 'primary01.py'), 'exec'))
