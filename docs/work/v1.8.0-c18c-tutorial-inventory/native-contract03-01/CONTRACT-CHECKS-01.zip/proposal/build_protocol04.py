"""Derive only a new proposal protocol from the immutable proposal01 input."""
import copy
import hashlib
import json
import os
from pathlib import Path

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
old_path = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json')
data = old_path.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf'
old = json.loads(data)
new = copy.deepcopy(old)
new['proposal_revision'] = 2
new['host_admission'] = {
    'revision': 2,
    'copy_properties': {'gamemode': 'adventure', 'force-gamemode': 'false',
                        'view-distance': '2', 'simulation-distance': '3'},
    'world': 'minecraft:overworld',
    'world_data_game_type': 'adventure',
    'level_height': {'minimum': -64, 'maximum_exclusive': 320},
    'raw_shared_spawn_bounds_inclusive': {'x': [-79, 94], 'y': [64, 256], 'z': [-79, 94]},
    'player_dimensions_float_bits': {'width': '3f19999a', 'height': '3fe66666'},
    'loaded_envelope_inclusive': [-5, -5, 5, 5],
    'loaded_chunk_count': 121,
    'loaded_probe': 'getChunkNow only; check every pair lexicographically before both constructors',
    'loaded_entities_cap': 1024,
    'constructor_collision_iteration_upper_bound': 256,
    'constructor_collision_candidate_cells_per_iteration_upper_bound': 45,
    'console_setup': ['forceload add -80 -80 95 95'],
    'no_setworldspawn_or_terrain_edit': True,
    'all_constructors_before_any_join': True,
    'position_assignment': 'moveTo fixed role position on unlisted owned objects before placeNewPlayer',
    'post_join_cross_dimension_teleport': 'forbidden; verify native loaded location instead',
    'reload_native_fields': {
        'Dimension': {'tag': 8, 'value': 'minecraft:overworld'},
        'Pos': {'tag': 9, 'element_tag': 6, 'count': 3, 'value': 'exact role position'},
        'Motion': {'tag': 9, 'element_tag': 6, 'count': 3, 'raw_bits': ['0000000000000000'] * 3},
        'Rotation': {'tag': 9, 'element_tag': 5, 'count': 2, 'raw_bits': ['00000000'] * 2},
        'playerGameType': {'tag': 3, 'value': 1},
        'RootVehicle': {'presence': False},
    },
    'scope': 'test-host admission only; normal native startup/tracking is not globally load-free',
}
host_observation = {
    'revision': 'integer2', 'world_data_game_type': 'exactadventure',
    'raw_spawn': 'exact3integers in frozen inclusive ranges',
    'shared_spawn': 'exact3integers equalrawspawn',
    'border_contains_collision_region': 'Booleanactualtrue',
    'minimum_height': 'integer-64', 'maximum_height': 'integer320',
    'view_distance': 'integer2', 'simulation_distance': 'integer3',
    'loaded_envelope': 'exact4integers[-5,-5,5,5]', 'loaded_chunks': 'integer121',
    'loaded_entities': 'integer0..1024',
    'player_dimensions_bits': 'exact2lower8hex[3f19999a,3fe66666]',
    'constructor_iteration_upper_bound': 'integer256; derived bound, not executed loop count',
}
new['payload_schemas']['PREFLIGHT']['host_admission'] = host_observation
new['payload_schemas']['PLAYER_STATE']['native_location'] = {
    'dimension': 'exactminecraft:overworld', 'position': 'exact3finiteJSONnumbers equalroleposition',
    'motion_bits': 'exact3lower16hexall0000000000000000',
    'rotation_bits': 'exact2lower8hexall00000000', 'vehicle_present': 'Booleanfalse',
}
new['external_marker_fields']['host_revision'] = 'integer2'
new['external_marker_fields']['copy_properties_sha256'] = 'lower64hex of actual configured copy server.properties'
new['external_receipt_fields']['host_revision'] = 'integer2'
new['external_receipt_fields']['host_admission_sha256'] = 'lower64hex of actual strictPREFLIGHT host_admission object'
new['external_receipt_fields']['native_locations'] = 'exact2roleordered objects matching fixed reload_native_fields'
new['cohort_inputs_fields']['host_revision'] = 'integer2'
new['runtime_limits'] = ('No Java/native executed. Loaded-envelope/control models do not admit native constructor, '
    'join, reflection, listener, cleanup or vanilla reload. Constructor admission uses copy-local default Adventure '
    'mode; it is not global non-loading or a gameplay setting change. No gameplay/API/Gate admission.')
unchanged = [key for key in old if new.get(key) == old[key]]
changed = [key for key in old if new.get(key) != old[key]]
(B / 'PROTOCOL-02.json').write_text(json.dumps(new, indent=2) + '\n', encoding='utf-8')
(B / 'PROTOCOL-DELTA-04.json').write_text(json.dumps({
    'base_path': str(old_path), 'base_sha256': hashlib.sha256(data).hexdigest(),
    'unchanged_top_level_keys': unchanged, 'changed_top_level_keys': changed,
    'added_top_level_keys': [key for key in new if key not in old],
    'unchanged_critical': {key: new[key] == old[key] for key in (
        'source_commit', 'fixed_identities', 'goal_ids', 'criterion', 'native_empty_inventory_shape',
        'item_counts_order', 'seed_events', 'reload_events', 'common_fields', 'saved_criterion_fields',
        'failure_codes', 'deadlines_seconds', 'ceilings', 'forbidden_authorities')}
}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'unchanged_top_level': len(unchanged), 'changed_top_level': changed,
                  'added': ['proposal_revision', 'host_admission'], 'java_launches': 0}, indent=2))
