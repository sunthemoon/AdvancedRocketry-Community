# Proposal02 handoff: C18 fixture ownership / host admission

This is a technical proposal, **not fixture implementation, accepted contract,
native result, source admission or version Gate conclusion**. The original
proposal01, independent Medium report and spawn/join supplement remain unchanged.

## Proposed correction and remaining constraints

[OWNERSHIP-PROPOSAL-02.md](OWNERSHIP-PROPOSAL-02.md) restricts only a disposable
copy's host default to Adventure, fixes low view/simulation distances, admits a
finite already-loaded chunk envelope and bounds native shared spawn/border/height.
No setworldspawn, terrain clearing, original-player record edit or global setting
change is proposed. Two constructors precede either join; ordinary unlisted moves
assign the existing fixed positions before join; unexpected native reload position
is refused rather than corrected by teleport. The bounded native record reader
gains exact Dimension/Pos/Motion/Rotation/playerGameType/absent RootVehicle checks.

All six goals/identities/current-inventory conjunction/events/criterion/target
counts/empty rewards/ownership receipt/disposal/byte-node-depth bounds/deadlines
remain. The machine-readable [protocol](PROTOCOL-02.json) and
[structured delta](PROTOCOL-DELTA-04.json) expose the added observations/host fields.
Existing test-only seven-field reflection remains proposed as before; no new
reflection member or gameplay authority is introduced.

Source context is fixed commit `a5abc34809891d6b10724ee60ab9b5e97f036bae` and
configured mapped Forge47.4.10 JAR SHA
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Root's unrelated documentation-only HEAD publication is not this fixed code basis
and no mutable status/HEAD replacement was used. The unchanged old Root task hash
is `d1eebd7b4683ff9da0cacafa2e72f9bf98ed98d1552047c880b5310884e44ced`.

## Actual checks

| Command | Actual observation | Evidence |
|---|---|---|
| `python -B primary01.py` | exit1, incorrect BlockPosArgument package locator; no native call | [original raw failure](primary-01.log) |
| `python -B primary02.py` | exit0, corrected named class locator, 11 classes/24 selected methods | [log](primary-02.log), [facts](HOST-PRIMARY-02.json) |
| `python -B primary03.py` | exit0, 14 classes/30 selected declaration/reference sets | [log](primary-03.log), [facts](HOST-PRIMARY-03.json) |
| `python -B build_protocol04.py` | exit0, 15 old top-level keys unchanged; 5 extended/replaced, 2 added | [log](protocol-04.log), [delta](PROTOCOL-DELTA-04.json) |
| `python -B primary05.py` | exit0, 6 classes/7 selected methods: public loaded-entity/distance getters, native chunk neighbors/out-of-height branch | [log](primary-05.log), [facts](HOST-PRIMARY-05.json) |
| `python -B controls06.py` | exit0, 18 pure specification tests/0 failure/error/skip; not fixture/NBT-reader/native proof | [raw log](controls-06.log), [counts](CONTROL-RESULT-06.json) |
| `python -B primary07.py` | exit0, 3 classes/6 selected native record emission helpers | [log](primary-07.log), [facts](RECORD-PRIMARY-07.json) |
| `python -B primary08.py` | exit0, actual private storeGameTypes helper, putInt/playerGameType reference | [log](primary-08.log), [facts](RECORD-PRIMARY-08.json) |
| `python -B intake_postcheck09.py` | exit0, 11 external and 11 fixed Git-object pins unchanged; 20 primary member identities consistent; 9 proposal links/0 missing at that checkpoint | [log](intake-postcheck-09.log), [pins](INPUT-POSTCHECK-09.json) |
| `python -B diff10.py` | exit0, comparative old/new Markdown+JSON delta, no patch application | [log](diff-10.log), [exact postimage identities](DIFF-IDENTITY-10.json) |
| `python -B final11.py` | exit0, final named intake and actual 20 native class-entry SHA checks; 30 companion links/0 missing before this table addition | [log](final-11.log), [postcheck](INPUT-POSTCHECK-11.json) |

All commands used process-local TEMP/TMP/TMPDIR in this own D-parent process-temp
and Python -B. No C helper, Java/Gradle/server/client/network/Git write/deletion,
Root/source/world/old-evidence edit or private directory read occurred. No ZIP or
whole-source export is needed; this is a small loose report/facts/controls packet.

The 174 horizontal and 256 vertical coordinate cases and 121 missing-chunk models
are mechanical bounds/predicate controls. The literal sequencing sample is a
specified trace, not actual constructor/callback execution. No positive NBT fixture
was represented as an emitted native player record. The exact
[document/protocol delta](PROPOSAL-02.diff) is comparative only; no patch was applied.

## Required follow-up

Root must independently review/adopt the exact technical correction, choose and
pin an eligible source host, and issue a disjoint source implementation leaf.
Actual scene/dimension callbacks, native cache mapping, owned partial cleanup,
record parser allocation/negative fixtures, real listener and stopped-file vanilla
reload remain unrun. The 300-second total and all existing subdeadlines remain;
incomplete 121-chunk preparation must fail, not enlarge the request/time budget.
Global vanilla startup/tracking is not claimed load-free. The connected mock is
not V1/V2/GPU/public multiplayer or full-v1.8 completion evidence.
