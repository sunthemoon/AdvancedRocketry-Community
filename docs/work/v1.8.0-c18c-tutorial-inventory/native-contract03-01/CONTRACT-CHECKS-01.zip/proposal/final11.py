"""Repeat named intake checks without overwriting checkpoint09; bind final facts."""
import ast
import hashlib
import json
import os
from pathlib import Path
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
original = (B / 'intake_postcheck09.py').read_text(encoding='utf-8')
tree = ast.parse(original)


class OutputOnly(ast.NodeTransformer):
    replacements = 0

    def visit_Constant(self, node):
        if node.value == 'INPUT-POSTCHECK-09.json':
            self.replacements += 1
            return ast.copy_location(ast.Constant('INPUT-POSTCHECK-11.json'), node)
        return node


change = OutputOnly()
tree = change.visit(tree)
assert change.replacements == 1
exec(compile(ast.fix_missing_locations(tree), str(B / 'final11.py'), 'exec'),
     {'__file__': str(B / 'final11.py'), '__name__': '__main__'})
out = json.loads((B / 'INPUT-POSTCHECK-11.json').read_text(encoding='utf-8'))
jar = next(e for e in out['external_inputs'] if e['path'].endswith('.jar'))
with zipfile.ZipFile(jar['path']) as archive:
    for name, pin in out['primary_class_pins'].items():
        value = archive.read(name)
        assert len(value) == pin['bytes']
        assert hashlib.sha256(value).hexdigest() == pin['sha256']
out['actual_primary_member_checks'] = len(out['primary_class_pins'])
out['native_classes_exported'] = 0
out['checkpoint09_preserved'] = True
out['proposal_postimages'] = []
for name in ('OWNERSHIP-PROPOSAL-02.md', 'PROTOCOL-02.json', 'HANDOFF-02.md',
             'PROPOSAL-02.diff'):
    data = (B / name).read_bytes()
    out['proposal_postimages'].append({'path': name, 'bytes': len(data),
                                      'sha256': hashlib.sha256(data).hexdigest()})
(B / 'INPUT-POSTCHECK-11.json').write_text(json.dumps(out, indent=2) + '\n',
                                         encoding='utf-8')
print(json.dumps({'primary_actual_member_hashes': len(out['primary_class_pins']),
                  'proposal_postimages': len(out['proposal_postimages']),
                  'java_launches': 0}))
