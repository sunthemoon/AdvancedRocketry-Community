import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import unittest

B = Path(__file__).resolve().parent
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'tmp')
new = json.loads((P / 'PROTOCOL-02.json').read_text(encoding='utf-8'))
old = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json').read_text(encoding='utf-8'))
host = new['host_admission']
author = P / 'controls06.py'
nodes = [n for n in ast.parse(author.read_bytes()).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
ns = {'copy': copy, 'hashlib': hashlib, 'json': json, 'math': math, 'struct': struct, 'unittest': unittest,
    'NEW': new, 'OLD': old, 'HOST': host,
    'FLOAT': lambda s: struct.unpack('>f', bytes.fromhex(s))[0],
    'DOUBLE': lambda s: struct.unpack('>d', bytes.fromhex(s))[0],
    'BITS': lambda d: struct.pack('>d', d).hex(),
    'ENVELOPE': [(x, z) for x in range(-5, 6) for z in range(-5, 6)],
    'WIDTH': struct.unpack('>f', bytes.fromhex('3f19999a'))[0],
    'HEIGHT': struct.unpack('>f', bytes.fromhex('3fe66666'))[0],
    'EPSILON': struct.unpack('>d', bytes.fromhex('3e7ad7f29abcaf48'))[0]}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(author), 'exec'), ns)
primary = json.loads((B / 'PRIMARY-01.json').read_text())
extra = json.loads((B / 'PRIMARY-02.json').read_text())
forced = json.loads((B / 'PRIMARY-03.json').read_text())
props = json.loads((B / 'PROPERTIES-01.json').read_text())
def method(v, name, prefix):
    methods = v['classes'][name]['selected_methods']
    selected = [(s, m) for s, m in methods.items() if s.startswith(prefix)]
    assert len(selected) == 1, (name, prefix, [s for s, m in selected])
    return selected[0][1]
def refs(m):
    return {i['offset']: i['reference'] for i in m['references']}

class IndependentControls(unittest.TestCase):
    def test_native_constructor_mode_not_player_ability(self):
        m = method(primary, 'net/minecraft/server/level/ServerPlayer.class', 'fudgeSpawnLocation(')
        r = refs(m)
        self.assertEqual(2, m['access'])
        self.assertIn('WorldData.getGameType', r[24])
        self.assertIn('GameType.ADVENTURE', r[27])
        self.assertTrue(any(i['offset'] == 30 and i['branch_target'] == 240 for i in m['branches']))
        self.assertIn('getOverworldRespawnPos', r[202])
        self.assertFalse(any('isCreative' in s for s in r.values()))

    def test_startup_assigns_default_mode(self):
        m = method(primary, 'net/minecraft/server/dedicated/DedicatedServer.class', 'initServer(')
        r = refs(m)
        self.assertIn('WorldData.setGameType', r[198])
        self.assertIn('loadLevel', r[491])

    def test_raw_spawn_border_check_precedes_heightmap_fallback(self):
        m = method(extra, 'net/minecraft/world/level/Level.class', 'getSharedSpawnPos(')
        r = refs(m)
        self.assertIn('isWithinBounds', r[40])
        self.assertIn('getHeightmapPos', r[68])
        self.assertTrue(any(i['offset'] == 43 and i['branch_target'] == 72 for i in m['branches']))

    def test_join_uses_native_record_and_registers_after_load(self):
        r = refs(method(primary, 'net/minecraft/server/players/PlayerList.class', 'placeNewPlayer('))
        self.assertIn('PlayerList.load', r[69])
        self.assertIn('Dimension', r[88])
        self.assertIn('setServerLevel', r[181])
        self.assertIn('ServerLevel.addNewPlayer', r[843])
        self.assertIn('loadEntityRecursive', r[972])
        self.assertLess(69, 843)

    def test_empty_inventory_native_save_is_not_fixed_compound_list(self):
        r = refs(method(primary, 'net/minecraft/world/entity/player/Inventory.class', 'save('))
        self.assertEqual(3, sum('ItemStack.isEmpty' in s for s in r.values()))
        self.assertEqual(3, sum('ListTag.add' in s for s in r.values()))
        self.assertEqual({'named_tag_id': 9, 'element_type_byte': 0, 'signed_element_count': 0,
            'partitions': [36, 4, 1], 'primary_fact_file': 'NATIVE-INVENTORY-02.json'}, new['native_empty_inventory_shape'])

    def test_cache_public_get_has_mutators_and_is_forbidden(self):
        methods = primary['classes']['net/minecraft/server/players/GameProfileCache.class']['selected_methods']
        combined = [i['reference'] for s, m in methods.items() if s.startswith('get(') for i in m['references']]
        self.assertTrue(any('getNextOperation' in r for r in combined))
        self.assertTrue(any('setLastAccess' in r for r in combined))
        self.assertIn('Field.set', new['forbidden_authorities'])

    def test_constructor_native_size_event_is_not_runtime_proof(self):
        r = refs(method(extra, 'net/minecraft/world/entity/Entity.class', '<init>('))
        self.assertIn('getEntitySizeForge', r[418])
        self.assertIn('Size.getNewSize', r[424])
        self.assertIn('runtime', new['runtime_limits'])
        self.assertEqual('test-host admission only; normal native startup/tracking is not globally load-free', host['scope'])

    def test_properties_store_is_reached_before_native_host_startup(self):
        r = refs(method(extra, 'net/minecraft/server/Main.class', 'main('))
        self.assertIn('DedicatedServerSettings.forceSave', r[471])
        r = refs(method(primary, 'net/minecraft/server/dedicated/DedicatedServerSettings.class', 'forceSave('))
        self.assertIn('DedicatedServerProperties.store', r[8])
        r = refs(method(primary, 'net/minecraft/server/dedicated/Settings.class', 'store('))
        self.assertIn('SortedProperties.store', r[19])
        sorted_methods = extra['classes']['net/minecraftforge/common/util/SortedProperties.class']['declared_method_signatures']
        self.assertNotIn('store(Ljava/io/Writer;Ljava/lang/String;)V', sorted_methods)
        native_methods = props['methods']
        zero = next(m for s, m in native_methods.items() if s.startswith('store0('))
        self.assertTrue(any(r['reference'] == 'java/util/Date.toString()Ljava/lang/String;' for r in zero['references']))

    def test_distinct_native_date_headers_break_raw_same_hash_spec(self):
        a = b'#Minecraft server properties\n#Mon Oct 05 12:00:00 UTC 2026\ngamemode=adventure\n'
        b = b'#Minecraft server properties\n#Mon Oct 05 12:00:01 UTC 2026\ngamemode=adventure\n'
        self.assertNotEqual(hashlib.sha256(a).digest(), hashlib.sha256(b).digest())
        self.assertEqual(a.splitlines()[2:], b.splitlines()[2:])
        self.assertIn('copy_properties_sha256', new['external_marker_fields'])
        self.assertIn('same file/hash on reload', (P / 'OWNERSHIP-PROPOSAL-02.md').read_text())

    def test_forced_membership_is_persisted_and_reinstated(self):
        r = refs(method(forced, 'net/minecraft/server/level/ServerLevel.class', 'setChunkForced('))
        self.assertIn('LongSet.add', r[54])
        self.assertIn('setDirty', r[94])
        r = refs(method(forced, 'net/minecraft/world/level/ForcedChunksSavedData.class', 'save('))
        self.assertEqual('Forced', r[1])
        self.assertIn('putLongArray', r[12])
        r = refs(method(forced, 'net/minecraft/server/MinecraftServer.class', 'prepareLevels('))
        self.assertIn('getChunks', r[186])
        self.assertIn('updateChunkForced', r[234])

    def test_zero_changed_additions_reach_native_all_added_refusal(self):
        m = method(forced, 'net/minecraft/server/commands/ForceLoadCommand.class', 'changeForceLoad(')
        r = refs(m)
        self.assertIn('setChunkForced', r[213])
        self.assertIn('ERROR_ALL_ADDED', r[269])
        self.assertIn('SimpleCommandExceptionType.create', r[278])
        self.assertTrue(any(i['offset'] == 262 and i['branch_target'] == 282 for i in m['branches']))
        requested = set(ns['ENVELOPE'])
        seed_before = set()
        seed_added = len(requested - seed_before)
        stopped_forced = seed_before | requested
        reload_added = len(requested - stopped_forced)
        self.assertEqual(121, seed_added)
        self.assertEqual(0, reload_added)
        self.assertIn('After each startup', (P / 'OWNERSHIP-PROPOSAL-02.md').read_text())
        self.assertIn('A native command refusal', (P / 'OWNERSHIP-PROPOSAL-02.md').read_text())

    def test_frozen_phase_rows_and_deadlines_are_separate_from_runtime(self):
        self.assertEqual(23, len(new['seed_events']) + len(new['reload_events']))
        self.assertEqual(300, new['deadlines_seconds']['cohort'])
        self.assertEqual(60, new['deadlines_seconds']['copy_intake'])
        self.assertEqual(110, new['deadlines_seconds']['seed_host'])
        self.assertEqual(110, new['deadlines_seconds']['reload_host'])
        self.assertEqual(20, new['deadlines_seconds']['final_validation'])
        self.assertEqual(10, new['deadlines_seconds']['hook_stage_checks'])
        self.assertEqual('PROPOSED_TEST_ONLY_NOT_IMPLEMENTED', new['status'])

suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(ns['Controls']),
    unittest.defaultTestLoader.loadTestsFromTestCase(IndependentControls)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
(B / 'CONTROLS-01.json').write_text(json.dumps({'tests': result.testsRun, 'author_unchanged_body_tests': 18,
    'independent_tests': 12, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
    'scope': 'pure specification and binary-reference controls; no native/Java/fixture implementation execution',
    'author_controls_sha256': hashlib.sha256(author.read_bytes()).hexdigest()}, indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
