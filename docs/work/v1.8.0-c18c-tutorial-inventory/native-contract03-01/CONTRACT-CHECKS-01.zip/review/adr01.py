import hashlib
import json
import os
from pathlib import Path
import subprocess

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'tmp')
relative = 'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md'
raw = (R / relative).read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(raw) == '8a5e06789b94595f26ae04cd9bf0ee63ff37710835224a0750055427486bf63a'
git = subprocess.check_output(['git', 'show', 'a5abc34809891d6b10724ee60ab9b5e97f036bae:' + relative], cwd=R)
assert raw == git
text = raw.decode('utf-8')
assert '### 6.2 Advancement identities and triggers' in text
assert 'No console/grant statement is accepted' in text
assert sha((R / relative).read_bytes()) == sha(raw)
(B / 'ADR-INPUT-01.json').write_text(json.dumps({'path': str(R / relative), 'bytes': len(raw),
    'sha256': sha(raw), 'fixed_source': 'a5abc34809891d6b10724ee60ab9b5e97f036bae:' + relative,
    'git_bytes_equal': True, 'before_after_equal': True, 'section_6_2_line': 644,
    'scope': 'gameplay authority comparison only; no whole-ADR implementation or gates'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'adr_bytes': len(raw), 'sha256': sha(raw), 'git_equal': True}))
