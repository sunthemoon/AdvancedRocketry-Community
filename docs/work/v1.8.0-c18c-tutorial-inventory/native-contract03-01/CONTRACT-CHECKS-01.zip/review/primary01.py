import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'tmp')
P = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(P.read_bytes()) == '001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167'
assert sha(J.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
nodes = [n for n in ast.parse(P.read_bytes()).body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P), 'exec'), ns)
requests = {
    'net/minecraft/server/dedicated/DedicatedServerSettings.class': {'<init>', 'forceSave'},
    'net/minecraft/server/dedicated/Settings.class': {'store', 'loadFromFile'},
    'net/minecraft/server/dedicated/DedicatedServer.class': {'initServer'},
    'net/minecraft/server/level/ServerPlayer.class': {'<init>', 'fudgeSpawnLocation', 'addAdditionalSaveData'},
    'net/minecraft/server/players/PlayerList.class': {'placeNewPlayer', 'load', 'remove', 'getPlayerStats', 'getPlayerAdvancements'},
    'net/minecraft/server/players/GameProfileCache.class': {'get', 'load', 'save', 'add'},
    'net/minecraft/world/entity/player/Inventory.class': {'save'},
    'net/minecraft/world/level/CollisionGetter.class': {'noCollision', 'getEntityCollisions', 'getChunkForCollisions'},
    'net/minecraft/world/level/Level.class': {'getChunkForCollisions'},
    'net/minecraft/server/level/ServerLevel.class': {'getAllEntities', 'getSharedSpawnPos', 'addNewPlayer', 'addPlayer'},
    'net/minecraft/world/entity/Entity.class': {'saveWithoutId', 'newDoubleList', 'newFloatList', 'moveTo'},
    'net/minecraft/world/level/storage/PlayerDataStorage.class': {'load', 'save'},
    'net/minecraft/server/level/ChunkMap.class': {'setViewDistance', 'updatePlayerStatus'},
    'net/minecraft/world/level/BlockCollisions.class': {'<init>', 'computeNext'},
}
out = {'jar': {'path': str(J), 'bytes': J.stat().st_size, 'sha256': sha(J.read_bytes())},
    'parser': {'path': str(P), 'sha256': sha(P.read_bytes())}, 'classes': {}, 'java_launches': 0}
with zipfile.ZipFile(J) as z:
    for name, wanted in requests.items():
        raw = z.read(name)
        parsed = ns['parse'](raw, wanted)
        methods = {}
        for sig, method in parsed['selected_methods'].items():
            ins = method['instructions']
            methods[sig] = {'access': method['access'],
                'references': [i for i in ins if i['reference'] is not None],
                'branches': [i for i in ins if i['branch_target'] is not None],
                'small_constants': [i for i in ins if i['opcode_hex'] in ('0x3','0x4','0x5','0x6','0x7','0x8','0x10','0x11')]}
        out['classes'][name] = {'bytes': len(raw), 'sha256': sha(raw), 'fields': parsed['fields'],
            'selected_methods': methods, 'declared_method_signatures': list(parsed['all_methods'])}
(B / 'PRIMARY-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(out['classes']), 'methods': sum(len(v['selected_methods']) for v in out['classes'].values()), 'java_launches': 0}))
