from pathlib import Path

B = Path(__file__).resolve().parent
text = (B / 'primary01.py').read_text(encoding='utf-8')
start = text.index('requests = {')
end = text.index('\nout = ', start)
text = text[:start] + """requests = {
    'net/minecraft/server/commands/ForceLoadCommand.class': {'register', 'changeForceLoad'},
    'net/minecraft/server/level/ServerLevel.class': {'setChunkForced', 'getForcedChunks'},
    'net/minecraft/world/level/ForcedChunksSavedData.class': {'save', 'load', 'getChunks'},
    'net/minecraft/server/MinecraftServer.class': {'prepareLevels'},
}\n""" + text[end:]
text = text.replace("'PRIMARY-01.json'", "'PRIMARY-03.json'")
exec(compile(text, str(B / 'primary01.py'), 'exec'))
