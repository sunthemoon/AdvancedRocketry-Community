from pathlib import Path

B = Path(__file__).resolve().parent
text = (B / 'controls01.py').read_text(encoding='utf-8')
text = text.replace("self.assertIn('WorldData.getGameType', r[24])", "self.assertIn('WorldData.getGameType', r[22])")
text = text.replace("self.assertIn('GameType.ADVENTURE', r[27])", "self.assertIn('GameType.ADVENTURE', r[27])")
text = text.replace("self.assertIn('runtime', new['runtime_limits'])", "self.assertIn('do not admit native constructor', new['runtime_limits'])")
text = text.replace("'CONTROLS-01.json'", "'CONTROLS-02.json'")
exec(compile(text, str(B / 'controls01.py'), 'exec'))
