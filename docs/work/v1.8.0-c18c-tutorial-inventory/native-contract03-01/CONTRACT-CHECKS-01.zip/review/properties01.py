import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'tmp')
P = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
src = Path('C:/Program Files/Java/jdk-17.0.7/lib/src.zip')
mod = Path('C:/Program Files/Java/jdk-17.0.7/jmods/java.base.jmod')
sha = lambda b: hashlib.sha256(b).hexdigest()
nodes = [n for n in ast.parse(P.read_bytes()).body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P), 'exec'), ns)
with zipfile.ZipFile(src) as z:
    text = z.read('java.base/java/util/Properties.java')
with zipfile.ZipFile(mod) as z:
    data = z.read('classes/java/util/Properties.class')
parsed = ns['parse'](data, {'store', 'store0'})
facts = {}
for sig, m in parsed['selected_methods'].items():
    facts[sig] = {'access': m['access'],
        'references': [{'offset': i['offset'], 'reference': i['reference']} for i in m['instructions'] if i['reference'] is not None]}
source_lines = text.decode('utf-8').splitlines()
out = {'source_archive': {'path': str(src), 'bytes': src.stat().st_size, 'sha256': sha(src.read_bytes())},
    'source_member': {'path': 'java.base/java/util/Properties.java', 'bytes': len(text), 'sha256': sha(text)},
    'binary_module': {'path': str(mod), 'bytes': mod.stat().st_size, 'sha256': sha(mod.read_bytes())},
    'binary_member': {'path': 'classes/java/util/Properties.class', 'bytes': len(data), 'sha256': sha(data)},
    'source_date_to_string_line': [i for i, line in enumerate(source_lines, 1) if 'new Date().toString()' in line],
    'methods': facts, 'java_launches': 0,
    'scope': 'static writer semantics, not an executed Minecraft properties write'}
assert out['source_date_to_string_line']
date_refs = [r for s, m in facts.items() if s.startswith('store0(') for r in m['references'] if 'java/util/Date' in r['reference']]
assert len(date_refs) >= 3
(B / 'PROPERTIES-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'properties_methods': len(facts), 'date_refs': date_refs, 'source_lines': out['source_date_to_string_line'], 'java_launches': 0}))
