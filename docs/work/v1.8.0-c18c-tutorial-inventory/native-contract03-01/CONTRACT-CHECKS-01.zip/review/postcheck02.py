from pathlib import Path

B = Path(__file__).resolve().parent
text = (B / 'postcheck01.py').read_text(encoding='utf-8')
text = text.replace("for e in foreign['actual_primary_member_checks']:", "for name, e in foreign['primary_class_pins'].items():")
text = text.replace("name = e.get('entry') or e.get('class') or e.get('path')", "name = name")
text = text.replace("len(foreign['actual_primary_member_checks'])", "foreign['actual_primary_member_checks']")
text = text.replace("'INPUT-POSTCHECK-01.json'", "'INPUT-POSTCHECK-02.json'")
exec(compile(text, str(B / 'postcheck01.py'), 'exec'))
