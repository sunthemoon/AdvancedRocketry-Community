import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'tmp')
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}
initial = json.loads((B / 'INPUT-PINS-01.json').read_text())
checked = []
for path, expected in initial['files'].items():
    actual = pin(Path(path))
    assert actual == expected, (path, actual, expected)
    checked.append({'path': path, 'before': expected, 'after': actual, 'unchanged': True})
foreign = json.loads((P / 'INPUT-POSTCHECK-12.json').read_text())
objects = []
for e in foreign['fixed_git_inputs']:
    assert e['source'].startswith('a5abc34809891d6b10724ee60ab9b5e97f036bae:')
    assert 'Development-Docs' not in e['source'] and '..' not in e['source'].split(':', 1)[1].split('/')
    data = subprocess.check_output(['git', 'show', e['source']], cwd=R)
    actual = {'bytes': len(data), 'sha256': sha(data)}
    assert actual['bytes'] == e['bytes'] and actual['sha256'] == e['sha256'], e['source']
    objects.append({'source': e['source'], **actual, 'unchanged': True})
data = subprocess.check_output(['git', 'show', 'a5abc34809891d6b10724ee60ab9b5e97f036bae:src/main/java/io/github/sunthemoon/advancedrocketrycommunity/progression/classic/ClassicInventoryAdvancements.java'], cwd=R)
assert b'"minecraft:inventory_changed"' in data
assert b'json.add("rewards", new JsonObject())' in data
assert data.count(b'has_inventory') == 1
objects.append({'source': 'a5abc34809891d6b10724ee60ab9b5e97f036bae:src/main/java/io/github/sunthemoon/advancedrocketrycommunity/progression/classic/ClassicInventoryAdvancements.java', 'bytes': len(data), 'sha256': sha(data), 'unchanged': True})
facts = [json.loads((B / f).read_text()) for f in ('PRIMARY-01.json', 'PRIMARY-02.json', 'PRIMARY-03.json')]
all_classes = {}
for v in facts:
    for name, info in v['classes'].items():
        expected = {'bytes': info['bytes'], 'sha256': info['sha256']}
        assert name not in all_classes or all_classes[name] == expected
        all_classes[name] = expected
jar = Path(facts[0]['jar']['path'])
assert pin(jar) == {'bytes': facts[0]['jar']['bytes'], 'sha256': facts[0]['jar']['sha256']}
with zipfile.ZipFile(jar) as z:
    for name, expected in all_classes.items():
        raw = z.read(name)
        assert {'bytes': len(raw), 'sha256': sha(raw)} == expected, name
    for e in foreign['actual_primary_member_checks']:
        name = e.get('entry') or e.get('class') or e.get('path')
        assert name, e
        raw = z.read(name)
        expected = e.get('expected') or e.get('expected_pin') or e
        assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes'], name
properties = json.loads((B / 'PROPERTIES-01.json').read_text())
for key in ('source_archive', 'binary_module'):
    expected = properties[key]
    assert pin(Path(expected['path'])) == {'bytes': expected['bytes'], 'sha256': expected['sha256']}
links = []
for f in ('OWNERSHIP-PROPOSAL-02.md', 'HANDOFF-02.md'):
    for target in re.findall(r'\]\(([^)]+)\)', (P / f).read_text(encoding='utf-8')):
        assert '://' not in target
        resolved = (P / target.split('#', 1)[0]).resolve()
        assert resolved.is_file(), target
        links.append({'document': f, 'target': target, 'exists': True})
new_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip()
out = {'scope': 'named inputs and immutable source/native objects, not whole repository identity',
    'named_file_checks': len(checked), 'files': checked, 'fixed_git_objects': objects,
    'independent_primary_class_entries': len(all_classes), 'author_primary_class_entries': len(foreign['actual_primary_member_checks']),
    'proposal_links': links, 'missing_links': 0, 'drift': [], 'initial_doc_head': initial['head'], 'final_doc_head': new_head,
    'head_qualification': 'Root notified documentation-only publication 6a54f835; fixed a5abc source and exact Task03/52 payloads did not move',
    'jdk_static_archives_unchanged': True, 'java_native_launches': 0}
(B / 'INPUT-POSTCHECK-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: out[k] for k in ('named_file_checks', 'independent_primary_class_entries', 'author_primary_class_entries', 'missing_links', 'drift', 'final_doc_head')}))
