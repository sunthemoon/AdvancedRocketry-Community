import hashlib
import json
import os
from pathlib import Path
import subprocess

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal02-96f3d2e40a')
S = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-spawn-facts-02165b7f3c')
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'tmp')
sha = lambda data: hashlib.sha256(data).hexdigest()
pins = {}
def pin(path, expected=None):
    data = path.read_bytes()
    value = {'bytes': len(data), 'sha256': sha(data)}
    if expected is not None:
        assert value['sha256'] == expected, (str(path), value, expected)
    pins[str(path)] = value
    return data

task = R / 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md'
pin(task, 'c75fec1a7f1cb5291147abb838712ed695c7c011f060bff1f6f7378011a6b6d4')
assert pins[str(task)]['bytes'] == 9718
manifest_data = pin(P / 'EVIDENCE-MANIFEST.json', 'f53b381b572a64d4b561f3125e3e7c0c416868ce37cc0349d6c46eec82499955')
manifest = json.loads(manifest_data)
for entry in manifest['files']:
    relative = Path(entry['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    data = pin(P / relative, entry['sha256'])
    assert len(data) == entry['bytes']
assert len(manifest['files']) == 52
assert sum(entry['bytes'] for entry in manifest['files']) == 400726
for path in ('AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
    'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-01.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-02.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-02.md'):
    pin(R / path)
pin(S / 'REPORT-01.md', 'dfd35b6f0d66bf5904c1a05ca45b049da83678dcf103d7e72d41363973184d18')
pin(S / 'EVIDENCE-MANIFEST.json', '0ac21a34a0b77e2d0b4eaa30e16e5463a605af392e734bde165131da3eabc5e9')
for relative in ('PRIMARY-SPAWN-01.json', 'PRIMARY-DEPENDENCIES-02.json',
    'PRIMARY-BRANCHES-03.json', 'PRIMARY-DETAILS-04.json', 'PRIMARY-EXTRA-06.json'):
    pin(S / relative)
original = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-review-4ea16d018d')
pin(original / 'REVIEW-01.md', '9569049b655529fc33808d2145ecbf81b94cd2fe8eb81525ba1e59ebcd710cd6')
pin(original / 'INTERNAL-MANIFEST.json', '7120aa8d39c369a96d903b8e33897b77db6adfabf4933ea9d95c30f3499416e3')
pin(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/PROTOCOL-01.json'), '1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf')
for name in ('NATIVE-TASK-03.md',):
    (B / name).write_bytes(task.read_bytes())
for name in ('OWNERSHIP-PROPOSAL-02.md', 'PROTOCOL-02.json'):
    (B / name).write_bytes((P / name).read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert head == '9135c20c34a402b7cf0715148aeb6683a35c1f50'
(B / 'INPUT-PINS-01.json').write_text(json.dumps({'schema': 1, 'head': head, 'files': pins,
    'proposal_payloads_verified': 52, 'proposal_payload_bytes': 400726}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'inputs': len(pins), 'proposal_payloads': 52, 'proposal_payload_bytes': 400726, 'head': head}))
