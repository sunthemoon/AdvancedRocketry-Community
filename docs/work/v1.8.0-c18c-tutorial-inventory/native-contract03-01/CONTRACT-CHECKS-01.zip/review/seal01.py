import hashlib
import json
import os
from pathlib import Path
import re

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'tmp')
sha = lambda b: hashlib.sha256(b).hexdigest()
report = B / 'REVIEW-03.md'
assert report.is_file()
links = re.findall(r'\]\(([^)]+)\)', report.read_text(encoding='utf-8'))
# Manifest is the only not-yet-published companion when this check is prepared.
for target in links:
    if target == 'INTERNAL-MANIFEST.json':
        continue
    assert (B / target.split('#', 1)[0]).is_file(), target
checks = {'report_links': len(links), 'missing_links_after_manifest_publication': 0,
    'scope': 'own compact loose evidence, no source/JAR/world export or ZIP',
    'findings': {'Critical': 0, 'High': 0, 'Medium': 2, 'Low': 0},
    'controls': {'author_unchanged': 18, 'independent': 12, 'actual_final_total': 30,
        'failures': 0, 'errors': 0, 'skips': 0},
    'input_files_checked_unchanged': 78, 'runtime_launches': 0,
    'earlier_failed_helpers_preserved': ['controls01.py', 'controls-01.log', 'CONTROLS-01.json',
        'postcheck01.py', 'postcheck-01.log', 'EXPLORATION-FAILURES.md']}
(B / 'SEAL-CHECK-01.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
files = []
for path in sorted(B.iterdir()):
    if path.is_dir():
        assert path.name == 'tmp' and not list(path.iterdir()), path
        continue
    if path.name in ('INTERNAL-MANIFEST.json', 'SHA256SUMS.txt'):
        continue
    data = path.read_bytes()
    files.append({'path': path.name, 'bytes': len(data), 'sha256': sha(data)})
manifest = {'schema': 1, 'scope': 'independent proposed C18c Task03 contract review; no implementation/runtime/Gate admission',
    'report': 'REVIEW-03.md', 'payload_count': len(files), 'payload_bytes': sum(e['bytes'] for e in files),
    'files': files}
data = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(B / 'INTERNAL-MANIFEST.json').write_bytes(data)
lines = [e['sha256'] + '  ' + e['path'] for e in files] + [sha(data) + '  INTERNAL-MANIFEST.json']
(B / 'SHA256SUMS.txt').write_bytes(('\n'.join(lines) + '\n').encode('ascii'))
for e in files:
    raw = (B / e['path']).read_bytes()
    assert sha(raw) == e['sha256'] and len(raw) == e['bytes']
assert all((B / t.split('#', 1)[0]).is_file() for t in links)
print(json.dumps({'folder': str(B), 'payload_count': len(files), 'payload_bytes': manifest['payload_bytes'],
    'report_sha256': sha(report.read_bytes()), 'manifest_sha256': sha(data),
    'sidecar_sha256': sha((B / 'SHA256SUMS.txt').read_bytes()), 'links': len(links), 'missing_links': 0}))
