from pathlib import Path

B = Path(__file__).resolve().parent
text = (B / 'primary01.py').read_text(encoding='utf-8')
start = text.index('requests = {')
end = text.index('\nout = ', start)
text = text[:start] + """requests = {
    'net/minecraftforge/common/util/SortedProperties.class': {'store'},
    'net/minecraft/server/Main.class': {'main'},
    'net/minecraft/world/entity/Entity.class': {'<init>', 'refreshDimensions', 'getBoundingBox'},
    'net/minecraft/world/level/EntityGetter.class': {'getEntityCollisions'},
    'net/minecraft/world/level/entity/LevelEntityGetterAdapter.class': {'getAll'},
    'net/minecraft/world/level/entity/EntityLookup.class': {'getAllEntities', 'get'},
    'net/minecraft/world/level/storage/DerivedLevelData.class': {'getXSpawn', 'getYSpawn', 'getZSpawn'},
    'net/minecraft/server/level/ServerLevel.class': {'getSharedSpawnPos'},
    'net/minecraft/world/level/Level.class': {'getSharedSpawnPos'},
}\n""" + text[end:]
text = text.replace("'PRIMARY-01.json'", "'PRIMARY-02.json'")
exec(compile(text, str(B / 'primary01.py'), 'exec'))
