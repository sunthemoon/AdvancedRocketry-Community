# Exploratory tool errors retained separately

This is a transcript-based error note, not a substitute for a captured full raw subprocess log. The stored named helper logs/results retain their actual stdout/stderr independently.

1. Before own intake, a combined PowerShell read correctly read Task03 and proposal02 but guessed `INTERNAL-MANIFEST.json` in the author folder. It was absent; actual combined command exit 1. The actual frozen name is `EVIDENCE-MANIFEST.json`, verified by intake01.
2. A later combined read guessed `c18-native-proposal-review-4ea16d018d/PRIMARY-01.json`. It was absent; PowerShell printed Cannot find path, then a following valid read returned combined exit 0. No raw missing-file read is labelled successful. The actual old selected primary file is named `INDEPENDENT-PRIMARY-01.json`; it was not used to replace the newly parsed primary facts.
3. A bounded source lookup guessed `docs/adr/ADR-066*`. That directory was absent; combined command exit 1. The actual catalog directory is `docs/decisions`; no ADR change or acceptance was inferred.
4. A bounded fixed-Git read guessed `datagen/V180ClassicTutorialDefinitions.java`. Git reported that path absent, exit 1. The actual provider imports `progression/classic/ClassicInventoryAdvancements.java`; that exact immutable Git object was subsequently read and pinned. No guessed definition entered the contract findings.

No guessed path was created, modified, substituted into an old sealed record or hidden. The own control errors (wrong opcode offset and overly specific qualification wording) and postcheck shape error are preserved in their original scripts/raw logs, with separately named corrected invocations.
