"""Repeat committed Root pure-source checks, without native authority."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-integration-20261005-01')
REVIEW = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review03-20261005-91bc2d')
BASE = 'd0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad'
pins = json.loads((OLD/'PACKET-INTAKE-01.json').read_bytes())['four_new_postimages']
env = os.environ.copy()
for key in ('TEMP','TMP','TMPDIR'):
    env[key] = str(OUT)
env['PYTHONPATH'] = str(ROOT/'scripts')+os.pathsep+str(REVIEW)
assert not (REVIEW/'candidate02/scripts').exists()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check_source():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
    for name,row in pins.items():
        data = (ROOT/name).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
        assert subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)==data,name
check_source()
runner = (
    'import hashlib,json,pathlib,unittest; import run_v180_classic_inventory_smoke as f; '
    'p=pathlib.Path(f.__file__).resolve(); '
    'assert p==pathlib.Path('+repr(str(ROOT/'scripts/run_v180_classic_inventory_smoke.py'))+').resolve(); '
    'assert hashlib.sha256(p.read_bytes()).hexdigest()=='+repr(pins['scripts/run_v180_classic_inventory_smoke.py']['sha256'])+'; '
    'print(json.dumps({"loaded_module":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})); '
    'unittest.main(module=MODULE,verbosity=2)')
jobs = [('root-unit',[sys.executable,'-B','-m','unittest','discover','-s','scripts',
    '-p','test_run_v180_classic_inventory_smoke.py','-v'],0,39),
    ('unchanged-probe',[sys.executable,'-B','-c',runner.replace('MODULE',repr('test_independent'))],0,16),
    ('boundary-probe',[sys.executable,'-B','-c',runner.replace('MODULE',repr('test_boundary03'))],0,8),
    ('cli-refusal',[sys.executable,'-B','scripts/run_v180_classic_inventory_smoke.py'],2,None)]
rows = []
for label,args,expected,count in jobs:
    command = {'command':args,'cwd':str(ROOT),'tested_commit':BASE,'source_uncommitted':False,
        'TEMP_TMP_TMPDIR':str(OUT),'PYTHONPATH':env['PYTHONPATH']}
    (OUT/(label+'-02.command.json')).write_bytes((json.dumps(command,indent=2)+'\n').encode())
    started = time.monotonic()
    actual = subprocess.run(args,cwd=ROOT,env=env,capture_output=True)
    (OUT/(label+'-02.stdout.log')).write_bytes(actual.stdout)
    (OUT/(label+'-02.stderr.log')).write_bytes(actual.stderr)
    totals = re.findall(rb'^Ran (\d+) tests in ([0-9.]+)s\r?,actual.stderr,re.MULTILINE)
    row = {'name':label,'exit':actual.returncode,'seconds':time.monotonic()-started,
        'unittest_summaries':[[a.decode(),b.decode()] for a,b in totals],
        'stdout_sha256':sha(actual.stdout),'stderr_sha256':sha(actual.stderr)}
    rows.append(row)
    (OUT/(label+'-02.result.json')).write_bytes((json.dumps(row,indent=2)+'\n').encode())
    print(json.dumps(row),flush=True)
    assert actual.returncode==expected,row
    if count is not None:
        assert len(totals)==1 and totals[0][0]==str(count).encode() and actual.stderr.rstrip().endswith(b'OK'),row
    else:
        assert not actual.stdout and b'two-host fixture and driver are not implemented' in actual.stderr
check_source()
java_source = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01/SOURCE27-MANIFEST-01.json').read_bytes())
for name,row in java_source.items():
    data = (ROOT/name).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
result = {'commands':rows,'tested_commit':BASE,'source_uncommitted':False,'four_postimages_raw_Git_exact':True,
    'previous_Java_named_inputs_still_exact':len(java_source),'Java_not_rerun_or_rebound':True,
    'native_launched':False,'required_gates_passed':False}
(OUT/'PYTHON-CHECKS-02.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
,actual.stderr,re.MULTILINE)
    row = {'name':label,'exit':actual.returncode,'seconds':time.monotonic()-started,
        'unittest_summaries':[[a.decode(),b.decode()] for a,b in totals],
        'stdout_sha256':sha(actual.stdout),'stderr_sha256':sha(actual.stderr)}
    rows.append(row)
    (OUT/(label+'-02.result.json')).write_bytes((json.dumps(row,indent=2)+'\n').encode())
    print(json.dumps(row),flush=True)
    assert actual.returncode==expected,row
    if count is not None:
        assert len(totals)==1 and totals[0][0]==str(count).encode() and actual.stderr.rstrip().endswith(b'OK'),row
    else:
        assert not actual.stdout and b'two-host fixture and driver are not implemented' in actual.stderr
check_source()
java_source = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01/SOURCE27-MANIFEST-01.json').read_bytes())
for name,row in java_source.items():
    data = (ROOT/name).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
result = {'commands':rows,'tested_commit':BASE,'source_uncommitted':False,'four_postimages_raw_Git_exact':True,
    'previous_Java_named_inputs_still_exact':len(java_source),'Java_not_rerun_or_rebound':True,
    'native_launched':False,'required_gates_passed':False}
(OUT/'PYTHON-CHECKS-01.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
