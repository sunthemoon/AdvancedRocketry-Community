# First committed receipt parser failure

run_python01.py actually executes Root's 39-method suite with exit0, but its
byte-regex summary observer omits CR before LF. It records an empty summary
and raises AssertionError; the other three jobs do not run. Original helper,
command/result/stdout/stderr and outer exit1 remain unchanged. This is not a
39-test failure, nor a complete passing committed cohort.

run_python02.py is a separate action/output set. Its only semantic helper
change is admitting the optional CR delimiter in the strict summary regex;
count/exact OK requirements, test inputs, CLI refusal and source pins are
unchanged. Every output suffix is02, preserving all prior records.

Actual attempt02 fails SyntaxError before executing any job: the preparer's
JavaScript replacement string interprets its `$` plus quote as replacement
metasyntax and produces an unterminated Python literal. The intended-only
change above is not a successful attempt02 byte/AST claim. Original02 helper
and outer error log remain. Attempt03 starts again from unchanged01 using
a function replacement, verifies the exact expression and parses AST before
execution. All03 job/output names are distinct; no source/test input changes.
