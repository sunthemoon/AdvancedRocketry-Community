# Committed helper preparation observation

The first inline PowerShell/Python transformation command has invalid shell
quoting and returns ParserError before Python executes. It emits/applies no
patch, creates no prepared helper and runs no tests. The separate direct
apply_patch creates run_python01.py here. No original helper, source or
intermediate result is changed; this committed cohort is a new execution.
