"""Read-only phase01 committed result audit; never execute sealed drivers."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import re
import subprocess
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
COMMITTED = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-committed-20261005-01')
INTEGRATION = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-integration-20261005-01')
SOURCE27 = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01/SOURCE27-MANIFEST-01.json')
COMMIT = 'd0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad'

def sha(b): return hashlib.sha256(b).hexdigest()
def row(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def write(name, v): (HERE / name).write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8')
assert all(Path(os.environ[k]).resolve() == HERE for k in ('TEMP', 'TMP', 'TMPDIR'))
original_files = [p for base in (COMMITTED, INTEGRATION) for p in sorted(base.iterdir()) if p.is_file()]
before = [row(p) for p in original_files]
pins = json.loads((INTEGRATION / 'PACKET-INTAKE-01.json').read_bytes())['four_new_postimages']
publication = json.loads((INTEGRATION / 'PUBLICATION-01.json').read_bytes())
summary = json.loads((COMMITTED / 'PYTHON-CHECKS-03.json').read_bytes())
commands = []
def git(args):
    command = ['git'] + args
    r = subprocess.run(command, cwd=ROOT, capture_output=True)
    commands.append({'command': command, 'exit': r.returncode, 'stdout_bytes': len(r.stdout),
                     'stdout_sha256': sha(r.stdout), 'stderr': r.stderr.decode('utf-8', 'strict')})
    assert r.returncode == 0, commands[-1]
    return r.stdout

source_before = []
for name, expected in pins.items():
    raw = (ROOT / name).read_bytes()
    assert (len(raw), sha(raw)) == (expected['bytes'], expected['sha256']), name
    obj = git(['show', COMMIT + ':' + name])
    assert obj == raw, name
    source_before.append({'relative_path': name, 'bytes': len(raw), 'sha256': sha(raw), 'raw_Git_exact': True})
assert summary['tested_commit'] == publication['commit'] == COMMIT
parent = git(['rev-parse', COMMIT + '^']).decode().strip()
assert parent == json.loads((INTEGRATION / 'SOURCE-IMPORT-01.json').read_bytes())['before_commit']
actual_paths = git(['diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT]).decode().splitlines()
assert set(actual_paths) == set(publication['paths'])

def raw_summary(raw, code, expected_count):
    """Independent audit classification, not a production log/authority parser."""
    lines = raw.splitlines()
    totals = [re.fullmatch(rb'Ran (\d+) tests in ([0-9.]+)s', line) for line in lines]
    totals = [m for m in totals if m]
    assert len(totals) == 1 and int(totals[0][1]) == expected_count
    assert code == 0 and lines[-1:] == [b'OK']
    assert not any(line.startswith((b'FAIL:', b'ERROR:', b'FAILED (')) for line in lines)
    methods = [line for line in lines if line.startswith(b'test_') and line.endswith(b' ... ok')]
    assert len(methods) == expected_count
    return {'tests': expected_count, 'seconds': totals[0][2].decode(), 'FES': [0, 0, 0], 'method_lines': len(methods)}

verified_jobs = []
for label, count in (('root-unit', 39), ('unchanged-probe', 16), ('boundary-probe', 8), ('cli-refusal', None)):
    command = json.loads((COMMITTED / (label + '-03.command.json')).read_bytes())
    result = json.loads((COMMITTED / (label + '-03.result.json')).read_bytes())
    stdout = (COMMITTED / (label + '-03.stdout.log')).read_bytes()
    stderr = (COMMITTED / (label + '-03.stderr.log')).read_bytes()
    assert sha(stdout) == result['stdout_sha256'] and sha(stderr) == result['stderr_sha256']
    assert result == next(x for x in summary['commands'] if x['name'] == label)
    assert command['tested_commit'] == COMMIT and command['source_uncommitted'] is False
    assert Path(command['cwd']).resolve() == ROOT
    assert Path(command['TEMP_TMP_TMPDIR']).resolve() == COMMITTED
    observed = {'label': label, 'command': command, 'result': result}
    if count is not None:
        observed['independent_raw_parse'] = raw_summary(stderr, result['exit'], count)
        assert result['unittest_summaries'] == [[str(count), observed['independent_raw_parse']['seconds']]]
        if label != 'root-unit':
            loaded = json.loads(stdout)
            assert Path(loaded['loaded_module']).resolve() == (ROOT / 'scripts/run_v180_classic_inventory_smoke.py').resolve()
            assert loaded['sha256'] == pins['scripts/run_v180_classic_inventory_smoke.py']['sha256']
            observed['actual_loaded_module_stdout'] = loaded
    else:
        assert result['exit'] == 2 and not stdout
        assert stderr == b'Inventory restart verification parsing primitives only; two-host fixture and driver are not implemented.\r\n'
    verified_jobs.append(observed)

# The plain discovery command itself emits no module-path attestation. Verify its
# actual source/test import mechanics without claiming an independent new suite run.
test_raw = (ROOT / 'scripts/test_run_v180_classic_inventory_smoke.py').read_bytes()
test_ast = ast.parse(test_raw)
method_count = sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(test_ast))
assert method_count == 39
assert any((isinstance(n, ast.ImportFrom) and n.module == 'run_v180_classic_inventory_smoke')
           or (isinstance(n, ast.Import) and any(a.name == 'run_v180_classic_inventory_smoke' for a in n.names))
           for n in ast.walk(test_ast))

one = (COMMITTED / 'run_python01.py').read_text(encoding='utf-8')
three = (COMMITTED / 'run_python03.py').read_text(encoding='utf-8')
ast_one = ast.parse(one)
ast_three = ast.parse(three)
def patterns(tree):
    return [n.args[0].value for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
            and n.func.attr == 'findall' and n.args and isinstance(n.args[0], ast.Constant)]
old_pattern, new_pattern = patterns(ast_one)[0], patterns(ast_three)[0]
assert old_pattern == rb'^Ran (\d+) tests in ([0-9.]+)s$'
assert new_pattern == rb'^Ran (\d+) tests in ([0-9.]+)s\r?$'
# Normalize only the exact output suffixes and the delimiter token before AST comparison.
normalized = three.replace('-03.', '-01.').replace('PYTHON-CHECKS-03.json', 'PYTHON-CHECKS-01.json')
normalized = normalized.replace("s\\r?$'", "s$'")
assert ast.dump(ast.parse(normalized), include_attributes=False) == ast.dump(ast_one, include_attributes=False)
(HERE / 'HELPER01-03.diff').write_text(''.join(difflib.unified_diff(one.splitlines(True), three.splitlines(True), fromfile='run_python01.py', tofile='run_python03.py')), encoding='utf-8')
first_result = json.loads((COMMITTED / 'root-unit-01.result.json').read_bytes())
first_raw = (COMMITTED / 'root-unit-01.stderr.log').read_bytes()
assert sha(first_raw) == first_result['stderr_sha256']
first_count = raw_summary(first_raw, first_result['exit'], 39)
assert first_result['unittest_summaries'] == [] and not re.findall(old_pattern, first_raw, re.MULTILINE)
assert re.findall(new_pattern, first_raw, re.MULTILINE)
try:
    ast.parse((COMMITTED / 'run_python02.py').read_bytes())
except SyntaxError as e:
    syntax = {'line': e.lineno, 'offset': e.offset, 'message': e.msg}
else: raise AssertionError('attempt02 should remain syntactically invalid')
assert syntax['line'] == 52
assert b'SyntaxError: unterminated string literal' in (COMMITTED / 'python-driver-02.log').read_bytes()
assert b'AssertionError' in (COMMITTED / 'python-driver-01.log').read_bytes()
preparation = (COMMITTED / 'PREPARATION-TOOL-FAILURE-01.md').read_text(encoding='utf-8')
assert 'ParserError before Python executes' in preparation

class SummaryControls(unittest.TestCase):
    def good(self, raw, code=0, count=1): return raw_summary(raw, code, count)
    def test_LF_and_CRLF_positive_controls(self):
        raw = b'test_x (test.Example.test_x) ... ok\n\nRan 1 tests in 0.001s\n\nOK\n'
        self.good(raw)
        self.good(raw.replace(b'\n', b'\r\n'))
        self.assertFalse(re.findall(old_pattern, raw.replace(b'\n', b'\r\n'), re.MULTILINE))
    def test_wrong_count_and_false_method_count_refuse(self):
        for raw in (b'Ran 1 tests in 0.001s\n\nOK\n', b'test_x ... ok\nRan 2 tests in 0.001s\n\nOK\n'):
            with self.assertRaises(AssertionError): self.good(raw)
    def test_duplicate_summary_refuses(self):
        raw = b'test_x ... ok\nRan 1 tests in 0.001s\nRan 1 tests in 0.001s\n\nOK\n'
        with self.assertRaises(AssertionError): self.good(raw)
    def test_failed_or_skipped_or_trailing_status_refuses(self):
        for end in (b'FAILED (failures=1)', b'OK (skipped=1)', b'OK\nforeign'):
            with self.assertRaises(AssertionError): self.good(b'test_x ... ok\nRan 1 tests in 0.001s\n\n' + end)
    def test_exit_nonzero_and_hidden_error_refuse(self):
        raw = b'test_x ... ok\nRan 1 tests in 0.001s\n\nOK\n'
        with self.assertRaises(AssertionError): self.good(raw, code=1)
        with self.assertRaises(AssertionError): self.good(b'ERROR: fake\n' + raw)

controlled = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SummaryControls))
assert controlled.wasSuccessful()

java_manifest_raw = SOURCE27.read_bytes()
java_inputs = json.loads(java_manifest_raw)
assert len(java_inputs) == summary['previous_Java_named_inputs_still_exact'] == 3039
java_mismatch = []
for name, expected in java_inputs.items():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts and 'Development-Docs' not in name
    b = (ROOT / name).read_bytes()
    if (len(b), sha(b)) != (expected['bytes'], expected['sha256']): java_mismatch.append(name)
assert not java_mismatch, java_mismatch

# Validate all captured publication blob outputs against the immutable committed
# objects; do not store/export duplicate source/blob bytes in this audit leaf.
pub_commands = json.loads((INTEGRATION / 'PUBLICATION-COMMANDS-01.json').read_bytes())
blob_rows = []
for entry in pub_commands:
    if entry['command'][:2] != ['git', 'show']: continue
    name = entry['command'][2].removeprefix(':')
    raw = (INTEGRATION / entry['stdout']).read_bytes()
    fixed = git(['show', COMMIT + ':' + name])
    assert raw == fixed
    blob_rows.append({'original_file': str(INTEGRATION / entry['stdout']), 'source_commit': COMMIT,
                      'repository_path': name, 'bytes': len(raw), 'sha256': sha(raw), 'raw_commit_exact': True})
assert len(blob_rows) == 10
assert (INTEGRATION / 'publication-command-22.stdout').read_text(encoding='utf-8').strip() == COMMIT
assert (INTEGRATION / 'publication-command-24.stdout').read_text(encoding='utf-8').split()[0] == COMMIT
assert publication['remote_commit'] == COMMIT
assert next(x for x in pub_commands if x['command'][:2] == ['git', 'diff'] and '--exit-code' in x['command'])['exit'] == 1

assert before == [row(p) for p in original_files]
for old in source_before:
    assert row(ROOT / old['relative_path'])['sha256'] == old['sha256']
write('ORIGINAL-INPUT-PINS-01.json', {'files': before, 'source_files': source_before, 'source27_manifest': row(SOURCE27),
    'original_evidence_pre_post_drift': [], 'four_sources_pre_post_drift': [], 'source27_inputs_mismatch': []})
write('RAW-RESULT-CONTROLS-01.json', {'jobs': verified_jobs, 'root_discovery_test_methods': method_count,
    'root_discovery_module_identity': 'command/discovery path and source import checked; separate two probe stdout attestations are actual; no per-test class-load attestation claimed',
    'attempt01': {'root_unittest_raw': first_count, 'observer_result': first_result, 'original_regex_no_CR_match': True, 'partial_cohort_only': True},
    'attempt02': {'ast_syntax_error': syntax, 'no_jobs_executed': True},
    'preparation_PS_failure': 'author-transcribed Markdown only; no raw shell stderr in these named leaves',
    'own_summary_controls': {'tests': controlled.testsRun, 'FES': [len(controlled.failures), len(controlled.errors), len(controlled.skipped)]},
    'native_execution_or_result_admission': False})
write('PUBLICATION-CONTROLS-01.json', {'source_commit': COMMIT, 'parent': parent, 'commit_paths': actual_paths,
    'captured_blob_outputs': blob_rows, 'git_read_commands': commands,
    'remote_observation': 'original push/ls-remote receipts inspected; no fresh network query',
    'source27_named_inputs': len(java_inputs), 'source27_mismatches': java_mismatch,
    'source27_results_not_reexecuted_or_rebound': True})
print(json.dumps({'committed_jobs': '39/16/8 actual0; CLI2', 'own_controls': controlled.testsRun,
                  'evidence_files': len(before), 'four_source_drift': [], 'source27_mismatches': [],
                  'helper_ast_only_optional_CR_and_output_suffixes': True}))
