# Committed C18c phase01 result audit

Date: 2026-10-05. Independent delegated result auditor `/root/c18_contract`,
not phase01 author. Scope: recorded Root Python results/publication at immutable
`d0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad`; not new source admission or native replay.

## Findings and limitations

**No Critical/High/Medium/Low contradiction is observed in the audited committed
result claims.** Actual raw outputs support attempt03's39/16/8 passing pure suites
and explicit CLI exit2. Full native fixture/driver, Java rerun/rebinding and
version Required Gates are not claimed by `PYTHON-CHECKS-03.json` or this audit.

Evidence qualification: the earlier PowerShell ParserError is preserved only
as `PREPARATION-TOOL-FAILURE-01.md`, an author-transcribed observation in the
supplied committed leaf. No original shell stderr file for that event exists
among the108 inspected named-leaf files. That transcript must not be called an
independent raw shell capture or full publication-raw closure.

The plain Root unittest discovery job has no module-path stdout attestation.
Its Root cwd/scripts discovery,39-method committed test import, before/after
source checks and pinned command are consistent with the intended module.
The two separate probe jobs **do** provide actual stdout module path/hash
attestations. No per-test class-load trace is invented.

## Exact source and actual execution observations

The [raw result controls](RAW-RESULT-CONTROLS-01.json) bind each command/result
and stdout/stderr digest. Audited original evidence roots:

- `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-committed-20261005-01`
- `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-integration-20261005-01`

| Recorded attempt03 job | Actual exit | Raw tests /FES | Actual unittest seconds |
|---|---:|---:|---:|
|Root discovery|0|39 /0,0,0|0.020|
|Unchanged independent probe|0|16 /0,0,0|0.012|
|Independent boundary probe|0|8 /0,0,0|0.009|
|Direct incomplete-driver CLI|2|not a test suite|not applicable|

Each suite has exactly one raw summary, an exact final `OK`, the expected number
of verbose method lines and no FAIL/ERROR/FAILED records. All recorded stdout /
stderr hashes independently match the actual files, and each per-job result
equals its row in Root's combined result. CLI stdout is empty and stderr is
the exact incomplete-driver message; exit2 is not relabelled native success.

Both probe stdout objects identify actual loaded
`D:/GitHub/AdvancedRocketry-Community/scripts/run_v180_classic_inventory_smoke.py`
and SHA `dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56`.
Commands use Root cwd, process-only own-D temp and Root/scripts ahead of the
unchanged reviewer probe directory in PYTHONPATH. Native/server/Java is absent
from the tested commands.

All four committed source/record files independently match both their frozen
postimage hashes and raw `git show d0f9cbde…:<path>` bytes:

| File | SHA256 |
|---|---|
|Parsing module|`dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56`|
|39-method test module|`4a24f52fa245b677b129e7247de554e7ac83f58b121eae7725e2b922a51cdfb7`|
|NATIVE-PROGRESS-04|`9918bd7b3a8ec2cc36b5610b99efeb884f4d87a1ec3f8297b3b6513a9ada8a29`|
|NATIVE-HANDOFF-04|`f7378241f061caedf8df5a37c4412882e79df5d638b80bf7fc3a1b88169032c6`|

They remain byte-exact at audit postcheck. The prior Source27 named-input
manifest is independently read and all3,039 current named files match its
byte/SHA entries. This proves source identity only: it neither reruns nor
rebinds prior Java/GameTest/native results to this Python phase.
See [input/source postcheck ledger](ORIGINAL-INPUT-PINS-01.json).

## Failure chronology and helper equivalence

Committed `run_python01.py:51,60–61` executes the actual Root39-method suite,
receives exit0, but the raw byte regex omits optional CR before LF. Its actual
CRLF stderr yields no summary under that regex, and the outer helper then
raises AssertionError. Independent parsing recovers39/0FES from that same raw
stderr. No remaining three committed jobs execute in attempt01; it is a
partial cohort, not a test failure and not a complete passing cohort.

Attempt02's unchanged original helper has an independently reproduced AST
SyntaxError at line52: the replacement produces an unterminated bytes literal.
`python-driver-02.log` records the same syntax failure; no tests/jobs execute.
The intended change described in Root's failure note is not claimed as an
actual equivalent attempt02 implementation.

Attempt03 starts from01. After normalizing **only** exact output suffixes01→03
and the regex's optional CR token, all remaining helper AST is equal, including
job arguments, source assertions, expected counts/exits and exact-OK checks.
[Actual helper diff](HELPER01-03.diff) is retained. Original helpers/logs/raw
results are not overwritten or rerun by this auditor.

## Publication checks and qualified omissions

Fixed commit parent independently equals the Source-Import receipt's
`accda38883276e645394ad7a538294d1cef0c766`; its actual10 changed paths equal the
publication path table. All10 captured staged `git show :<path>` stdout files
are byte-equal to immutable committed blobs, including the old thin ZIP and
sidecar. Physical/staged sidecar newline qualification is retained in the
original publication record, not generalized to source normalization.

The recorded commit/push/ls-remote outputs agree on d0f9cbde…. No new network
query is made; this is audit of the original remote observation, not proof of
the remote ref's present value. The original global `git diff --exit-code`
exit1 is retained, distinct from successful scoped whitespace/staging checks.
All [publication command/blob identities](PUBLICATION-CONTROLS-01.json) are
recorded without exporting another source tree or binary archive.

Any later thin collection may omit captured immutable Git blob dumps and the
old phase01 ZIP by exact SHA/bytes plus a commit/repository member locator.
Such a packet will explicitly not claim whole publication-raw closure. Failure
logs, command metadata, source-import/result records and this new audit stay
included; omission is not deletion or a modified original record.

## Actual independent controls, commands and integrity

Own `python -B audit01.py` exits1 before the new summary-control suite because
it assumed a `from … import …` statement; actual committed test source uses
`import run_v180_classic_inventory_smoke as fixture`. [Original log](audit-01.log)
and helper remain unchanged. This is an audit-tool predicate error, not a
candidate/source failure or executed new test suite.

The separately prepared `audit02.py` changes only that own AST import-form
predicate. Actual [second log](audit-02.log) has **5/0FES**, exit0: LF/CRLF positives,
wrong count/method count, duplicate summaries, failed/skipped/trailing status,
nonzero exit and hidden-error negatives. These controls parse crafted records
and inspect original results; they are not another execution of Root's63 tests.
All Git commands are bounded local read-only `show`, `rev-parse <fixed>^` and
`diff-tree <fixed>` operations, recorded in the publication controls.

108 original files have zero audit pre/post drift; four new-source pins and
3,039 Source27 pins match. All new subprocess TEMP/TMP/TMPDIR are inside this
fresh own D-parent leaf; Python uses `-B`. No sealed helper, Java/Gradle/native,
client/network, source/Root/WT/Git write, deletion or OpenPet operation occurs.
No source code review/Gate/ledger/native admission follows from this result audit.
