from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
pins = json.loads((HERE / 'ORIGINAL-INPUT-PINS-01.json').read_bytes())
for expected in pins['files']:
    p = Path(expected['path']); b = p.read_bytes()
    assert (len(b), sha(b)) == (expected['bytes'], expected['sha256'])
root = Path('D:/GitHub/AdvancedRocketry-Community')
for expected in pins['source_files']:
    b = (root / expected['relative_path']).read_bytes()
    assert (len(b), sha(b)) == (expected['bytes'], expected['sha256'])
links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', (HERE / 'REVIEW-01.md').read_text(encoding='utf-8'))
for link in links: assert (HERE / link.split('#', 1)[0]).is_file(), link
rows = []
for p in sorted(HERE.iterdir()):
    if not p.is_file(): continue
    assert p.name not in ('INTERNAL-MANIFEST-01.json', 'SHA256SUMS.txt'), 'fresh seal only'
    b = p.read_bytes(); rows.append({'path': p.name, 'bytes': len(b), 'sha256': sha(b)})
manifest = {'scope': 'independent committed result audit, not phase01 source author or native/Gate admission',
            'files': rows, 'payload_count': len(rows), 'payload_bytes': sum(x['bytes'] for x in rows),
            'original_evidence_postcheck_drift': [], 'four_source_postcheck_drift': [],
            'report_links': len(links), 'report_link_failures': []}
b = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(HERE / 'INTERNAL-MANIFEST-01.json').write_bytes(b)
checks = rows + [{'path': 'INTERNAL-MANIFEST-01.json', 'sha256': sha(b)}]
(HERE / 'SHA256SUMS.txt').write_text(''.join(x['sha256'] + '  ' + x['path'] + '\n' for x in checks), encoding='utf-8')
for x in checks: assert sha((HERE / x['path']).read_bytes()) == x['sha256']
print(json.dumps({'report_sha256': sha((HERE / 'REVIEW-01.md').read_bytes()), 'manifest_sha256': sha(b),
                 'checksum_sha256': sha((HERE / 'SHA256SUMS.txt').read_bytes()), 'payload_count': len(rows),
                 'payload_bytes': manifest['payload_bytes'], 'relative_links': len(links), 'source_post_drift': []}, indent=2))
