"""Publish the four reviewed phase01 postimages and six owned integration records."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = 'accda38883276e645394ad7a538294d1cef0c766'
BRANCH = 'codex/v1.8.0-classic-content'
PREFIX = 'docs/work/v1.8.0-c18c-tutorial-inventory/'
intake = json.loads((OUT/'PACKET-INTAKE-01.json').read_bytes())
owned = intake['four_new_postimages']
PATHS = sorted(list(owned)+['docs/status/CURRENT_VERSION.md','docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',PREFIX+'NATIVE-SOURCE-REVIEW-DISPOSITION-04-PHASE01.md',
    PREFIX+'phase01-01/c18c-native-phase01-thin-collection-01.zip',
    PREFIX+'phase01-01/c18c-native-phase01-thin-collection-01.zip.sha256'])
JAVA = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01')
pins = json.loads((JAVA/'SOURCE27-MANIFEST-01.json').read_bytes())
owner_before = (ROOT/'AGENTS.md').read_bytes()
commands = []
def sha(data):
    return hashlib.sha256(data).hexdigest()
def run(args, allowed=(0,)):
    start = time.monotonic()
    actual = subprocess.run(args,cwd=ROOT,capture_output=True)
    stem = 'publication-command-%02d' % (len(commands)+1)
    (OUT/(stem+'.stdout')).write_bytes(actual.stdout)
    (OUT/(stem+'.stderr')).write_bytes(actual.stderr)
    commands.append({'command':args,'exit':actual.returncode,'seconds':time.monotonic()-start,
        'stdout':stem+'.stdout','stderr':stem+'.stderr'})
    (OUT/'PUBLICATION-COMMANDS-01.json').write_bytes((json.dumps(commands,indent=2)+'\n').encode())
    assert actual.returncode in allowed,(stem,actual.returncode)
    return actual.stdout
def source_check():
    for group in (pins,owned):
        for path,row in group.items():
            data = (ROOT/path).read_bytes()
            assert len(data)==row['bytes'] and sha(data)==row['sha256'],path

start = time.monotonic()
result = {'paths':PATHS,'scope':'phase01 primitives only; complete file/Java/native driver and all version Gates remain open'}
try:
    assert len(PATHS)==10 and len(set(PATHS))==10
    assert run(['git','rev-parse','HEAD']).decode().strip()==BASE
    assert not run(['git','diff','--cached','--name-only'])
    assert not run(['git','diff','--name-only','--','src/main','src/test','src/generated','scripts'])
    source_check()
    assert sha(owner_before)=='1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
    links = 0
    for path in PATHS:
        if path.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(ROOT/path).read_text(encoding='utf-8')):
                if not target.startswith(('http:','https:','#')):
                    assert (ROOT/path).parent.joinpath(target.split('#')[0]).exists(),(path,target)
                    links += 1
    result['local_links'] = links
    run(['python','-B','scripts/validate_v1plus_planning.py'])
    run(['git','diff','--check'])
    run(['git','diff','--exit-code'],allowed=(1,))
    images = {path:(ROOT/path).read_bytes() for path in PATHS}
    assert sha(images[PREFIX+'phase01-01/c18c-native-phase01-thin-collection-01.zip'])=='97a87662986b9b1a47dc2d9995e1630191ed62319573085c2dbad196e830c84a'
    run(['git','add','--']+PATHS)
    assert sorted(run(['git','diff','--cached','--name-only']).decode().splitlines())==PATHS
    result['staged_identities'] = {}
    for path,data in images.items():
        staged = run(['git','show',':'+path])
        assert staged==data or staged==data.replace(b'\r\n',b'\n'),path
        result['staged_identities'][path] = {'physical_sha256':sha(data),'staged_sha256':sha(staged),
            'qualification':'literal' if data==staged else 'exact CRLF-to-LF only'}
    run(['git','diff','--cached','--stat'])
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','test(inventory): add bounded native restart parsing primitives'])
    head = run(['git','rev-parse','HEAD']).decode().strip()
    run(['git','push','origin','HEAD:refs/heads/'+BRANCH])
    remote = run(['git','ls-remote','origin','refs/heads/'+BRANCH]).decode().split()[0]
    assert remote==head and not run(['git','diff','--cached','--name-only'])
    source_check()
    assert (ROOT/'AGENTS.md').read_bytes()==owner_before
    assert all((ROOT/path).read_bytes()==data for path,data in images.items())
    result.update(status='PASS',commit=head,remote_commit=remote,previous_Java_named_inputs_unchanged=len(pins),
        exact_new_postimages=4,required_gates_passed=False)
finally:
    result['seconds'] = time.monotonic()-start
    (OUT/'PUBLICATION-01.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
    print(json.dumps({key:value for key,value in result.items() if key!='staged_identities'}))
