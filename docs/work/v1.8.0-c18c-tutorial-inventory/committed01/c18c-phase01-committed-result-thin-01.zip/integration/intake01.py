"""Verify the thin phase01 packet and prepare four exact new-file patches."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
COLLECT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-collector-95f679bbc0')
PACKET = COLLECT/'c18c-native-phase01-thin-collection-01.zip'
EXPECTED = '97a87662986b9b1a47dc2d9995e1630191ed62319573085c2dbad196e830c84a'
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af/candidate03')

def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def save(name, value):
    target = OUT/name
    assert not target.exists(), name
    target.write_bytes((json.dumps(value,indent=2)+'\n').encode())

data = PACKET.read_bytes()
assert pin(data)=={'bytes':763236,'sha256':EXPECTED}
sidecar = PACKET.with_name(PACKET.name+'.sha256').read_text(encoding='utf-8').splitlines()
assert sidecar==[EXPECTED+'  '+PACKET.name]
with zipfile.ZipFile(PACKET) as archive:
    names = archive.namelist()
    assert len(names)==len(set(names))==386 and archive.testzip() is None
    assert all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        and '\\' not in name and ':' not in name for name in names)
    assert all(not name.lower().endswith(('.jar','.mca','.dll','.exe')) for name in names)
    manifest = archive.read('INTERNAL-MANIFEST-01.json')
    assert pin(manifest)['sha256']=='713cb4b5dc43726b9c8a8199a24991ad84d099b6e024fef09a0c7caf322e7a5a'
    rows = json.loads(manifest)['files']
    assert len(rows)==len({row['path'] for row in rows})
    for row in rows:
        assert pin(archive.read(row['path']))=={k:row[k] for k in ('bytes','sha256')},row['path']
    checks = archive.read('SHA256SUMS.txt')
    assert pin(checks)['sha256']=='702256bec6d9444db0db52c37f20d8c387e986a379708811ae45a33ff3c0ea5c'
    checksum_names = []
    for line in checks.decode('utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
        assert match, line
        checksum_names.append(match[2])
        assert pin(archive.read(match[2]))['sha256']==match[1],match[2]
    assert len(checksum_names)==len(set(checksum_names))
    assert set(checksum_names)==set(names)-{'SHA256SUMS.txt'}
    origins = json.loads(archive.read('SOURCE-ORIGINS-01.json'))['files']
    assert len(origins)==366
    for row in origins:
        original = Path(row['source']).read_bytes()
        assert original==archive.read(row['destination']),row['source']
        assert pin(original)=={k:row[k] for k in ('bytes','sha256')}
    reviewed = archive.read('review03/REVIEW-CANDIDATE03.md')
    assert pin(reviewed)['sha256']=='6769bc584dc3d816101c0ac0cc3272ead3fbf43df75acd244aa8ef815f31c72e'

source = json.loads((AUTHOR/'SOURCE-CANDIDATE-03.json').read_bytes())
assert len(source['files'])==4
patch = ['*** Begin Patch']
for name,row in source['files'].items():
    image = (AUTHOR/'postimages'/name).read_bytes()
    assert pin(image)==row['after'], name
    assert not (ROOT/name).exists(), name
    assert bytes([13]) not in image and image.endswith(bytes([10]))
    patch.append('*** Add File: '+(ROOT/name).as_posix())
    patch.extend('+'+line for line in image.decode('utf-8').split('\n')[:-1])
patch.extend(['*** End Patch',''])
payload = '\n'.join(patch).encode()
target = OUT/'APPLY-01.patch'
assert not target.exists()
target.write_bytes(payload)
save('PACKET-INTAKE-01.json',{'verified':True,'packet':pin(data),'members':len(names),
    'internal_manifest':pin(manifest),'original_members_postchecked':len(origins),
    'review03_report':pin(reviewed),'four_new_postimages':{n:r['after'] for n,r in source['files'].items()},
    'prepared_apply_patch':pin(payload),'source_and_native_admission':False,'required_gates_passed':False})
print(json.dumps({'packet_verified':True,'members':len(names),'original_postchecked':len(origins),
    'prepared_new_files':list(source['files']),'root_written':False,'native_admitted':False}))
