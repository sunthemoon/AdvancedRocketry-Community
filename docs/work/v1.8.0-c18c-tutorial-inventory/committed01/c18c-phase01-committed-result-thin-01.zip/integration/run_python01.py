"""Run Root's imported pure-source checks, without Java or native authority."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
REVIEW = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-primitives-review03-20261005-91bc2d')
COLLECT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-phase01-collector-95f679bbc0')
BASE = 'accda38883276e645394ad7a538294d1cef0c766'
pins = json.loads((OUT/'PACKET-INTAKE-01.json').read_bytes())['four_new_postimages']
env = os.environ.copy()
for key in ('TEMP','TMP','TMPDIR'):
    env[key] = str(OUT)
env['PYTHONPATH'] = str(ROOT/'scripts')+os.pathsep+str(REVIEW)
assert not (REVIEW/'candidate02/scripts').exists()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def source_check():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
    for name,row in pins.items():
        data = (ROOT/name).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
source_check()
runner = (
    'import hashlib,json,pathlib,unittest; import run_v180_classic_inventory_smoke as f; '
    'p=pathlib.Path(f.__file__).resolve(); '
    'assert p==pathlib.Path('+repr(str(ROOT/'scripts/run_v180_classic_inventory_smoke.py'))+').resolve(); '
    'assert hashlib.sha256(p.read_bytes()).hexdigest()=='+repr(pins['scripts/run_v180_classic_inventory_smoke.py']['sha256'])+'; '
    'print(json.dumps({"loaded_module":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})); '
    'unittest.main(module=MODULE,verbosity=2)')
jobs = [('root-unit', [sys.executable,'-B','-m','unittest','discover','-s','scripts',
    '-p','test_run_v180_classic_inventory_smoke.py','-v'],0),
    ('unchanged-probe',[sys.executable,'-B','-c',runner.replace('MODULE',repr('test_independent'))],0),
    ('boundary-probe',[sys.executable,'-B','-c',runner.replace('MODULE',repr('test_boundary03'))],0),
    ('cli-refusal',[sys.executable,'-B','scripts/run_v180_classic_inventory_smoke.py'],2)]
rows = []
for label,args,expected in jobs:
    started = time.monotonic()
    command = {'command':args,'cwd':str(ROOT),'base_commit':BASE,'source_uncommitted':True,
        'TEMP_TMP_TMPDIR':str(OUT),'PYTHONPATH':env['PYTHONPATH']}
    (OUT/(label+'-01.command.json')).write_bytes((json.dumps(command,indent=2)+'\n').encode())
    actual = subprocess.run(args,cwd=ROOT,env=env,capture_output=True)
    (OUT/(label+'-01.stdout.log')).write_bytes(actual.stdout)
    (OUT/(label+'-01.stderr.log')).write_bytes(actual.stderr)
    row = {'name':label,'exit':actual.returncode,'expected_exit':expected,'seconds':time.monotonic()-started,
        'stdout_sha256':sha(actual.stdout),'stderr_sha256':sha(actual.stderr)}
    rows.append(row)
    (OUT/(label+'-01.result.json')).write_bytes((json.dumps(row,indent=2)+'\n').encode())
    print(json.dumps(row),flush=True)
    assert actual.returncode==expected,row
    if label=='cli-refusal':
        assert not actual.stdout and b'two-host fixture and driver are not implemented' in actual.stderr
source_check()
packet = COLLECT/'c18c-native-phase01-thin-collection-01.zip'
assert sha(packet.read_bytes())=='97a87662986b9b1a47dc2d9995e1630191ed62319573085c2dbad196e830c84a'
target = ROOT/'docs/work/v1.8.0-c18c-tutorial-inventory/phase01-01'/packet.name
assert not target.exists()
target.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(packet,target)
shutil.copyfile(packet.with_name(packet.name+'.sha256'),target.with_name(target.name+'.sha256'))
assert packet.read_bytes()==target.read_bytes()
result = {'commands':rows,'source_postimages_exact':True,'base_commit':BASE,'source_uncommitted':True,
    'packet_copied_byte_exact':True,'native_launched':False,'required_gates_passed':False}
(OUT/'PYTHON-CHECKS-01.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
