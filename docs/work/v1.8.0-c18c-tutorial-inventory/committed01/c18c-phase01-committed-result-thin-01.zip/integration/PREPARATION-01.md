# Root phase01 intake preparation observations

The source authority is candidate03/postimages, not a guessed top-level
SOURCE-CANDIDATE path. Earlier exploratory reads used three wrong locators
(the analyzer task subdirectory, native source-manifest top level, and a
CREATION patch filename); actual directory listings corrected them. They were
read-only tooling observations, not test outcomes or source drift.
An exploratory packet probe also assumes files is a mapping and raises
AttributeError; the separate shape probe shows a list. The intake helper uses
that actual shape and is a separate execution, not a rewritten first result.
One inline delimiter probe tests literal backslash-r rather than byte13;
separate numeric-byte checks show all four source postimages have zero CR bytes.

The prepared four-file patch is not applied here. Root source/status/Git
integration remains separate from packet CRC/hash/source-origin verification.
No sealed author/reviewer helper is rerun, no Java/native is launched, and
historical Medium/red/CLI failures remain unchanged.
