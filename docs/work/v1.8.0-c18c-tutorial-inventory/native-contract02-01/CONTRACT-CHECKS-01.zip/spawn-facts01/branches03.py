"""Branch/constant facts on named inherited access and spawn bounds."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
         and n.name in ('R', 'parse')]
ns = {'struct': struct}; exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/world/level/LevelReader.class': {'getChunk'},
    'net/minecraft/world/level/Level.class': {'hasChunk', 'getHeightmapPos', 'getChunkForCollisions'},
    'net/minecraft/server/level/ServerChunkCache.class': {'hasChunk', 'getChunkNow'},
    'net/minecraft/server/level/ServerPlayer.class': {'fudgeSpawnLocation'},
    'net/minecraft/server/dedicated/DedicatedServer.class': {'initServer'},
}
out = {'jar_sha256': sha(jar.read_bytes()), 'classes': {}, 'java_launches': 0}
all_parsed = {}
with zipfile.ZipFile(jar) as archive:
    for name, methods in requests.items():
        data = archive.read(name); parsed = ns['parse'](data, methods); all_parsed[name] = parsed
        details = {}
        for method, info in parsed['selected_methods'].items():
            if name.endswith('DedicatedServer.class'):
                continue
            details[method] = {'access': info['access'], 'references': [
                {'offset': i['offset'], 'reference': i['reference']}
                for i in info['instructions'] if i['reference'] is not None],
                'branches': [{'offset': i['offset'], 'opcode': i['opcode_hex'], 'target': i['branch_target']}
                             for i in info['instructions'] if i['branch_target'] is not None]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data), 'selected_methods': details}
fudge = all_parsed['net/minecraft/server/level/ServerPlayer.class']['selected_methods'][
    'fudgeSpawnLocation(Lnet/minecraft/server/level/ServerLevel;)V']['instructions']
out['fudge_numeric_branch_facts'] = [
    {'offset': i['offset'], 'opcode': i['opcode_hex'], 'operand': i['operand_hex'],
     'reference': i['reference'], 'target': i['branch_target']}
    for i in fudge if (i['offset'] <= 34 or 63 <= i['offset'] <= 183 or i['offset'] >= 236)
    and (i['branch_target'] is not None or i['opcode_hex'] in
         ('0x3', '0x4', '0x5', '0x10', '0x11', '0x12', '0x13', '0x14', '0x60', '0x61',
          '0x64', '0x68', '0x69', '0x6c', '0x70', '0x85', '0x88', '0x94', '0x84'))]
reader = all_parsed['net/minecraft/world/level/LevelReader.class']['selected_methods']
get3 = reader['getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;)Lnet/minecraft/world/level/chunk/ChunkAccess;']['instructions']
call = next(i for i, ins in enumerate(get3) if ins['reference'] and 'getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)' in ins['reference'])
assert get3[call - 1]['opcode_hex'] == '0x4'
out['chunk_creation_fact'] = {'method': 'LevelReader.getChunk(int,int,ChunkStatus)',
    'create_argument': True, 'argument_offset': get3[call - 1]['offset'], 'call_offset': get3[call]['offset']}
collisions = all_parsed['net/minecraft/world/level/Level.class']['selected_methods'][
    'getChunkForCollisions(II)Lnet/minecraft/world/level/BlockGetter;']['instructions']
call = next(i for i, ins in enumerate(collisions) if ins['reference'] and 'getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)' in ins['reference'])
assert collisions[call - 1]['opcode_hex'] == '0x3'
out['collision_chunk_fact'] = {'method': 'Level.getChunkForCollisions(int,int)',
    'create_argument': False, 'argument_offset': collisions[call - 1]['offset'], 'call_offset': collisions[call]['offset']}
init = all_parsed['net/minecraft/server/dedicated/DedicatedServer.class']['selected_methods']['initServer()Z']['instructions']
out['dedicated_gamemode_route'] = [{'offset': i['offset'], 'reference': i['reference']}
                                  for i in init if 185 <= i['offset'] <= 216 and i['reference'] is not None]
(B / 'PRIMARY-BRANCHES-03.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'fudge_numeric_branch_facts': out['fudge_numeric_branch_facts'],
                  'create': out['chunk_creation_fact'], 'collisions': out['collision_chunk_fact'],
                  'gamemode': out['dedicated_gamemode_route']}, indent=2))
