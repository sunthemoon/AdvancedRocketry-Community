# C18 native constructor/join primary facts supplement

## Material facts and implications

1. **A later fixture teleport cannot bound construction.** The pinned
   `ServerPlayer.<init>(MinecraftServer,ServerLevel,GameProfile)` invokes private
   `fudgeSpawnLocation(ServerLevel)` at bytecode offset 249. That method reads the
   level's shared spawn before its branch. In the skylight, non-Adventure branch,
   it calls `PlayerRespawnLogic.getOverworldRespawnPos` at 202, whose chunk read at
   17 leads to `ChunkStatus.FULL` with **create=true**. The coordinates derive from
   shared spawn, spawn-radius gamerule and world border, not from the future
   fixture teleport. This is an available creation/loading path in the inspected
   code, not a claim that a particular native run loaded/generated a chunk.
   [Constructor and spawn facts](PRIMARY-SPAWN-01.json),
   [dependent chunk facts](PRIMARY-DEPENDENCIES-02.json),
   [creation/branch facts](PRIMARY-BRANCHES-03.json).

2. **The alternate route is selected by server WorldData, not player abilities.**
   At offsets 6–12, no skylight jumps to 240. Otherwise offsets 16–30 read
   `level.getServer().getWorldData().getGameType()` and jump to 240 when it is
   `GameType.ADVENTURE`. Overriding the new player's `isCreative`, `isSpectator`
   or permission methods does not replace that inspected comparison. The method
   is private (access flag 2); the examined branch is not a public overridable
   spawn-policy hook. [Exact branch facts](PRIMARY-BRANCHES-03.json).

3. **An ordinary dedicated copy's startup `gamemode=adventure` can select that
   alternate branch, conditionally.** The ordinary properties parser's `gamemode`
   key uses the `GameType.byId`/`GameType.byName` dispatch and `GameType.getName`
   serialization; the enum's name is `adventure`. `DedicatedServer.initServer`
   reads `properties.gamemode` at 195 and calls `WorldData.setGameType` at 198,
   before its later `loadLevel` call. Once that normal startup assignment has
   completed and absent a later default-mode change, the same server WorldData
   comparison is Adventure. This does **not** require `force-gamemode` merely to
   select the constructor branch. It does not itself prove loaded-only join or
   authorize configuration changes; no server properties were written here.
   [Property method-handle targets](PRIMARY-DETAILS-04.json),
   [ordinary string-dispatch follow-up](PRIMARY-EXTRA-06.json),
   [startup assignment](PRIMARY-BRANCHES-03.json).

4. **The alternate route still performs location and collision reads.** At 244 it
   moves to the shared spawn; at 249 it checks `noCollision`. When obstructed and
   below `getMaxBuildHeight()-1`, it increments Y and repeats (288→247). Shared
   spawn normally reads level-data X/Y/Z, but an out-of-border shared spawn instead
   selects the border center via a heightmap path. `Level.getHeight` checks
   `hasChunk` before its chunk read. The collision iterator uses
   `getChunkForCollisions`, whose native Level implementation passes
   **create=false**, and probes a padded bounding-box region, not only the entity's
   center cell. These are distinct from the search route's create=true read.
   Therefore one preflight of chunk (0,0) is not an established bound for all
   constructor inputs. The actual shared spawn, border branch, bounding region
   and obstruction/height must be qualified by a later host-admission design.
   [Level/collision dependencies](PRIMARY-DEPENDENCIES-02.json),
   [collision flag](PRIMARY-BRANCHES-03.json),
   [shared-spawn branch](PRIMARY-DETAILS-04.json),
   [collision iterator](PRIMARY-EXTRA-06.json).

5. **Joining can change dimension/position and register tracking before the
   fixture teleport.** `PlayerList.placeNewPlayer` loads native player data at 69,
   reads its `Dimension` at 88/97, selects a server level at 139 (with overworld
   fallback), sets the player's ServerLevel at 181, teleports its connection to
   the current loaded coordinates at 759, and calls `ServerLevel.addNewPlayer` at
   843. Optional retained `RootVehicle` data reaches `EntityType.loadEntityRecursive`
   at 972; it is not absent merely because Inventory is empty. The separate
   `PlayerList.load` has a singleplayer-owner loaded-tag branch and a normal
   PlayerDataStorage branch. A dedicated fixture boundary must not accidentally
   inherit the former. [PlayerList facts](PRIMARY-SPAWN-01.json).

6. **Registration is not a side-effect-free list insertion.** `ServerLevel.addPlayer`
   posts `EntityJoinLevelEvent`, checks the live UUID lookup and registers with
   the entity manager. Player's inherited `isAlwaysTicking()` is true; the
   effective status therefore reaches the tracking callback in this inspected
   path. Tracking calls `ServerChunkCache.addEntity` → `ChunkMap.addEntity` →
   `updatePlayerStatus`. That route updates player position/maps, adds a player
   to DistanceManager when not skipped, updates the player-ticket trackers and
   adds a `TicketType.PLAYER` ticking ticket. Existing loaded chunks may also be
   sent to the new connection. This establishes native authority/tracking side
   effects before a later fixture teleport, not the exact number/timing of chunks
   generated by a native host. Event cancellation, exceptions and external
   listeners are not suppressed by these facts. The duplicate-UUID path is also
   not a safe substitute for collision preflight.
   [Join/tracking facts](PRIMARY-DETAILS-04.json),
   [Player always-ticking declaration](PRIMARY-EXTRA-06.json).

## Bounds and scope of inference

- The constructor search has a candidate-count calculation capped at
  `Integer.MAX_VALUE`, an early-exit path and a candidate loop. Its diameter is
  calculated using int arithmetic before promotion, so this report does not
  present the ordinary non-overflowing square formula as a universally safe
  fixture budget. It is not the fixture's finite, fixed per-command work bound.
- The alternate route's vertical scan is limited by native maximum build height,
  not by a small fixture-specific iteration ceiling. Loaded collision chunk
  access is create=false, but that alone is not proof that construction plus
  native join is globally non-loading.
- The exact existing committed `ConnectedTestPlayers.join` constructs, then calls
  `placeNewPlayer`, then explicitly teleports. Its overrides do not intercept the
  private constructor spawn method. This is a source-order observation only.
  [Fixed source hash/order check](FINAL-CHECKS-09.json).
- The old proposal remains immutable and is **not amended or accepted** by this
  supplement. The inspected constructor/join routes require a separate concrete
  technical host-admission disposition before relying on its loaded-only claim.
  No game design, original-world setting, six-goal semantics or owner choice has
  been selected by this facts task.
- No native host, player join, callback, chunk generation, gameplay or vanilla
  reload was executed. Runtime mapped/SRG reflection availability and exact
  live scene geometry remain unproven. No public API, persistence, resource,
  GuardTicket or version Required Gate admission is claimed.

## Identity and methods

- Fixed code context: `a5abc34809891d6b10724ee60ab9b5e97f036bae`; no live HEAD was
  used as a replacement for that identity.
- Configured mapped Forge 47.4.10 JAR SHA-256:
  `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
  Exact selected class-member sizes and hashes are recorded in the fact JSONs
  and consolidated [postcheck](FINAL-CHECKS-09.json).
- Original frozen proposal SHA-256:
  `5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581`;
  manifest `cc689403716863d8885092c1e26ab5eee720621d06058c1581166d37d03af2ae`.
  Inline provenance: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1`.
- No official class bodies/JAR/full mappings are redistributed. The bounded own
  parser is loaded from its pinned named file using AST extraction of `R`/`parse`
  only; its old top-level writes are never executed. Exported facts are selected
  symbolic declarations, references, branches and constants.

## Actual checks and preserved errors

- `python -B read01.py`, `dependencies02.py`, `branches03.py`, `details04.py`:
  each exited 0. Each has its own raw log and exit file in this loose packet.
- A read-only inline JSON selector requested a class absent from that particular
  earlier result and exited 1. Its literal exception is retained in
  [exploratory failure](EXPLORATORY-FAILURE-01.txt); no native defect is inferred.
- `python -B extra05.py` exited 1 because `isAlwaysTicking` is inherited from
  Player, not declared in ServerPlayer. [Original failure](extra-05.log) remains
  unchanged. `extra06.py` corrects the declaration owner in a separately named
  invocation and exited 0. It preserves the original script and failure.
- `python -B check07.py` reached a publication-order assertion and exited 1: this
  report linked its not-yet-created result. [Original check failure](check-07.log)
  is retained. The attempted ordering correction `check08.py` also exited 1
  because a second uncreated result was linked; [that raw failure](check-08.log)
  is retained. Separately named `check09.py` emits its input result before testing
  actual companion existence. The bounded checks verify input/member identity
  consistency, exact branch references, eight derived branch controls, fixed
  source ordering and actual final links. Its observations are
  [FINAL-CHECKS-09.json](FINAL-CHECKS-09.json), not Java/native evidence.
- All subprocess TEMP/TMP/TMPDIR values point to this own D-parent `process-temp`;
  no C-drive helper/output, global environment or filesystem cleanup was created.

## Follow-up boundary

A separately reviewed proposal may specify a bounded disposable-host admission
for the actual constructor branch, shared-spawn collision region, native loaded
dimension/position and tracking. This report neither implements that protocol nor
prescribes a review verdict. Source-only facts cannot substitute for the later
actual native inventory-listener and clean-stop/reload evidence.
