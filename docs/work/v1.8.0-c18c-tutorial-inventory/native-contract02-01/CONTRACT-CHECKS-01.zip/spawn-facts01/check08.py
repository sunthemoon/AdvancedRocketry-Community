"""Preserve check07's publication-order failure; check links after first output."""
from pathlib import Path
import json

base = Path(__file__).resolve().parent
text = (base / 'check07.py').read_text(encoding='utf-8')
text = text.replace("assert all(x['exists'] for x in links)",
                    "assert all(x['exists'] or x['target'] == 'CHECKS-07.json' for x in links)")
exec(compile(text, str(base / 'check07.py'), 'exec'))
actual_links = [{**x, 'exists': (base / x['target'].split('#')[0]).exists()} for x in links]
assert all(x['exists'] for x in actual_links)
out = {'actual_relative_links': actual_links, 'missing_links': 0,
       'input_checks_result': 'CHECKS-07.json', 'java_launches': 0,
       'publication_order': 'output first, then actual companion existence check'}
(base / 'CHECKS-08.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'post_output_relative_links': len(actual_links), 'missing_links': 0}))
