"""Narrow follow-ups to symbolic references actually encountered in spawn/join."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
P = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(P.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P), 'exec'), ns)
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/'
         'net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/'
         'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(J.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/server/dedicated/Settings.class': {'lambda$dispatchNumberOrString$1'},
    'net/minecraft/server/level/ServerPlayer.class': {'isAlwaysTicking'},
    'net/minecraft/world/level/CollisionGetter.class': {'lambda$getBlockCollisions$0'},
    'net/minecraft/world/level/BlockCollisions.class': {'<init>', 'getChunk'},
    'net/minecraft/world/entity/Entity.class': {'moveTo'},
}
out = {'jar_sha256': sha(J.read_bytes()), 'classes': {}, 'java_launches': 0}
parsed = {}
with zipfile.ZipFile(J) as archive:
    for name, wanted in requests.items():
        data = archive.read(name)
        value = ns['parse'](data, wanted)
        parsed[name] = value
        methods = {}
        for method, info in value['selected_methods'].items():
            methods[method] = {'access': info['access'],
                'references': [{'offset': i['offset'], 'reference': i['reference']}
                               for i in info['instructions'] if i['reference'] is not None],
                'branches': [{'offset': i['offset'], 'opcode': i['opcode_hex'],
                              'target': i['branch_target']}
                             for i in info['instructions'] if i['branch_target'] is not None]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data),
                               'selected_methods': methods}
settings = parsed['net/minecraft/server/dedicated/Settings.class']['selected_methods']
assert len(settings) == 1
refs = next(iter(settings.values()))['instructions']
assert any(i['reference'] and 'Integer.parseInt' in i['reference'] for i in refs)
assert any(i['reference'] and 'Function.apply' in i['reference'] for i in refs)
always = parsed['net/minecraft/server/level/ServerPlayer.class']['selected_methods']['isAlwaysTicking()Z']
assert [i['opcode_hex'] for i in always['instructions']] == ['0x4', '0xac']
out['always_ticking_fact'] = {'method': 'ServerPlayer.isAlwaysTicking()Z', 'constant_return': True}
bc = parsed['net/minecraft/world/level/BlockCollisions.class']['selected_methods']
ctor = next(i for k, i in bc.items() if k.startswith('<init>'))
out['collision_iterator_boundary_constants'] = [
    {'offset': i['offset'], 'constant': i['reference']} for i in ctor['instructions']
    if i['reference'] and i['reference'].startswith('(6,')]
(B / 'PRIMARY-EXTRA-05.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(out['classes']), 'methods': sum(len(c['selected_methods'])
      for c in out['classes'].values()), 'always_ticking_fact': out['always_ticking_fact'],
      'java_launches': 0}, indent=2))
