"""Narrow primary spawn/join reference facts. No official body export or Java."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
data = parser.read_bytes()
nodes = [n for n in ast.parse(data).body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
         and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
old = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
inputs = []
for path in (parser, jar, R / 'AGENTS.md', old / 'PRIMARY-01.json', old / 'EVIDENCE-MANIFEST.json', old / 'OWNERSHIP-PROPOSAL-01.md'):
    data = path.read_bytes()
    inputs.append({'path': str(path), 'bytes': len(data), 'sha256': sha(data)})
assert inputs[4]['sha256'] == 'cc689403716863d8885092c1e26ab5eee720621d06058c1581166d37d03af2ae'
assert inputs[5]['sha256'] == '5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581'
requests = {
    'net/minecraft/server/level/ServerPlayer.class': {'<init>', 'fudgeSpawnLocation'},
    'net/minecraft/server/players/PlayerList.class': {'placeNewPlayer', 'load'},
    'net/minecraft/server/level/PlayerRespawnLogic.class': {'getOverworldRespawnPos'},
}
out = {'jar': inputs[1], 'classes': {}, 'java_launches': 0}
with zipfile.ZipFile(jar) as archive:
    for name, selected in requests.items():
        data = archive.read(name); parsed = ns['parse'](data, selected)
        methods = {}
        for method, info in parsed['selected_methods'].items():
            methods[method] = {'access': info['access'], 'reference_facts': [
                {'offset': ins['offset'], 'reference': ins['reference']}
                for ins in info['instructions'] if ins['reference'] is not None],
                'branch_facts': [{'offset': ins['offset'], 'opcode': ins['opcode_hex'],
                                  'target': ins['branch_target']}
                                 for ins in info['instructions'] if ins['branch_target'] is not None]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data), 'selected_methods': methods}
(B / 'PRIMARY-SPAWN-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
(B / 'INPUTS-01.json').write_text(json.dumps({'inputs': inputs, 'limits': 'six named pins, three primary classes; no world/source writes'}, indent=2) + '\n', encoding='utf-8')
for name, detail in out['classes'].items():
    print(name, detail['sha256'])
    for method, facts in detail['selected_methods'].items():
        print('METHOD', method, 'ACCESS', facts['access'])
        for fact in facts['reference_facts']:
            if not method.startswith('<init>') or 'fudgeSpawnLocation' in fact['reference']:
                print(fact)
