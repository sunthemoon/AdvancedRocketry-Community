"""Named methods on actual spawn/join/config call paths, compact references only."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
         and n.name in ('R', 'parse')]
ns = {'struct': struct}; exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/world/level/Level.class': {'getChunk', 'getChunkAt', 'getSharedSpawnPos', 'getHeight', 'getChunkForCollisions'},
    'net/minecraft/server/level/ServerChunkCache.class': {'getChunk', 'getChunkFutureMainThread'},
    'net/minecraft/server/level/ServerLevel.class': {'addNewPlayer', 'addPlayer', 'getEntity'},
    'net/minecraft/world/level/CollisionGetter.class': {'noCollision', 'getBlockCollisions'},
    'net/minecraft/world/level/BlockCollisions.class': {'getChunk'},
    'net/minecraft/server/dedicated/DedicatedServer.class': {'initServer', 'getDefaultGameType', 'setDefaultGameType'},
    'net/minecraft/server/MinecraftServer.class': {'setDefaultGameType', 'getSpawnRadius'},
    'net/minecraft/server/dedicated/DedicatedServerProperties.class': {'<init>'},
}
out = {'jar_sha256': sha(jar.read_bytes()), 'classes': {}, 'java_launches': 0}
with zipfile.ZipFile(jar) as archive:
    for name, methods in requests.items():
        data = archive.read(name); parsed = ns['parse'](data, methods)
        selected = {}
        for method, info in parsed['selected_methods'].items():
            refs = [{'offset': i['offset'], 'reference': i['reference']}
                    for i in info['instructions'] if i['reference'] is not None]
            if name.endswith('DedicatedServer.class') and method.startswith('initServer'):
                refs = [r for r in refs if any(s in r['reference'] for s in
                        ('GameType', 'gamemode', 'Properties', 'forceGame', 'getWorldData', 'loadLevel'))]
            if name.endswith('DedicatedServerProperties.class'):
                refs = [r for r in refs if any(s in r['reference'] for s in ('GameType', 'gamemode', 'get(', 'getString'))]
            selected[method] = {'access': info['access'], 'references': refs,
                'branch_targets': [{'offset': i['offset'], 'opcode': i['opcode_hex'], 'target': i['branch_target']}
                                   for i in info['instructions'] if i['branch_target'] is not None]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data), 'selected_methods': selected}
(B / 'PRIMARY-DEPENDENCIES-02.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
for name, detail in out['classes'].items():
    print(name, detail['sha256'])
    for method, facts in detail['selected_methods'].items():
        print('METHOD', method, 'ACCESS', facts['access'])
        for fact in facts['references']:
            print(fact)
