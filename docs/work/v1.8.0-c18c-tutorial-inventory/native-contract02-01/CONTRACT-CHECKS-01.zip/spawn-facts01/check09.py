"""Run input checks, emit their result, then validate real companion files."""
from pathlib import Path
import json
import re

base = Path(__file__).resolve().parent
prefix = (base / 'check07.py').read_text(encoding='utf-8').split('links = []\n')[0]
exec(compile(prefix, str(base / 'check07.py'), 'exec'))
out = {'external_inputs': post, 'unique_primary_classes': len(classes),
       'class_pins': classes, 'model_controls': controls,
       'fixed_source': {'commit': base if isinstance(base, str) else 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
          'path': rel, 'bytes': len(result.stdout), 'sha256': sha(result.stdout),
          'git_command': command, 'git_exit': result.returncode,
          'construction_join_then_teleport': True},
       'prior_input_manifest': {'path': str(prior), 'bytes': prior.stat().st_size,
                                'sha256': sha(prior.read_bytes())},
       'native_execution': False, 'java_launches': 0}
(B / 'FINAL-CHECKS-09.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
links = []
for path in B.glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            links.append({'file': path.name, 'target': target,
                          'exists': (path.parent / target.split('#')[0]).exists()})
assert all(x['exists'] for x in links)
(B / 'FINAL-LINKS-09.json').write_text(json.dumps({'links': links, 'missing': 0}, indent=2)
                                    + '\n', encoding='utf-8')
print(json.dumps({'input_pins': len(post), 'unchanged': sum(e['unchanged'] for e in post),
      'unique_primary_classes': len(classes), 'branch_model_controls': len(controls),
      'relative_links': len(links), 'missing_links': 0, 'java_launches': 0}, indent=2))
