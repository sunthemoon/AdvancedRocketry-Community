"""Bounded independent input/reference consistency checks, not native execution."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda b: hashlib.sha256(b).hexdigest()
inputs = json.loads((B / 'INPUTS-01.json').read_text(encoding='utf-8'))['inputs']
post = []
for entry in inputs:
    data = Path(entry['path']).read_bytes()
    item = {'path': entry['path'], 'bytes': len(data), 'sha256': sha(data),
            'unchanged': len(data) == entry['bytes'] and sha(data) == entry['sha256']}
    post.append(item)
assert all(e['unchanged'] for e in post)
facts = [json.loads((B / name).read_text(encoding='utf-8')) for name in (
    'PRIMARY-SPAWN-01.json', 'PRIMARY-DEPENDENCIES-02.json', 'PRIMARY-BRANCHES-03.json',
    'PRIMARY-DETAILS-04.json', 'PRIMARY-EXTRA-06.json')]
classes = {}
for fact in facts:
    for name, value in fact['classes'].items():
        if name in classes:
            assert classes[name]['sha256'] == value['sha256']
        classes[name] = {'bytes': value['bytes'], 'sha256': value['sha256']}
branches = facts[2]
fudge = branches['classes']['net/minecraft/server/level/ServerPlayer.class']['selected_methods'][
    'fudgeSpawnLocation(Lnet/minecraft/server/level/ServerLevel;)V']
assert fudge['access'] == 2
assert {12: 240, 30: 240, 237: 291, 252: 291, 267: 291, 288: 247}.items() <= {
    x['offset']: x['target'] for x in fudge['branches']}.items()
assert any(x['offset'] == 22 and 'WorldData.getGameType' in x['reference']
           for x in fudge['references'])
assert branches['chunk_creation_fact']['create_argument'] is True
assert branches['collision_chunk_fact']['create_argument'] is False
controls = []
for skylight in (False, True):
    for game_type in ('survival', 'creative', 'adventure', 'spectator'):
        route = 'shared-spawn/vertical-collision' if not skylight or game_type == 'adventure' else 'spawn-search'
        controls.append({'skylight': skylight, 'world_data_game_type': game_type, 'derived_route': route})
# These eight rows are a model of the inspected two branch instructions, not server proof.
base = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
rel = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ConnectedTestPlayers.java'
command = ['git', 'show', base + ':' + rel]
result = subprocess.run(command, cwd='D:/GitHub/AdvancedRocketry-Community', capture_output=True, check=False)
assert result.returncode == 0, result.stderr.decode('utf-8', errors='replace')
source = result.stdout.decode('utf-8')
assert source.index('new ServerPlayer(') < source.index('placeNewPlayer(connection, player)') < source.index('player.teleportTo(')
prior = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1/INPUTS-01.json')
context = json.loads(prior.read_text(encoding='utf-8'))
existing = next(e for e in context['inputs'] if e['source'] == base + ':' + rel)
assert sha(result.stdout) == existing['sha256']
links = []
for path in B.glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            links.append({'file': path.name, 'target': target,
                          'exists': (path.parent / target.split('#')[0]).exists()})
assert all(x['exists'] for x in links)
out = {'external_inputs': post, 'unique_primary_classes': len(classes),
       'class_pins': classes, 'model_controls': controls,
       'fixed_source': {'commit': base, 'path': rel, 'bytes': len(result.stdout),
                        'sha256': sha(result.stdout), 'git_command': command,
                        'git_exit': result.returncode, 'construction_join_then_teleport': True},
       'prior_input_manifest': {'path': str(prior), 'bytes': prior.stat().st_size,
                                'sha256': sha(prior.read_bytes())},
       'relative_links': links, 'native_execution': False, 'java_launches': 0}
(B / 'CHECKS-07.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'input_pins': len(post), 'unchanged': sum(e['unchanged'] for e in post),
      'unique_primary_classes': len(classes), 'branch_model_controls': len(controls),
      'relative_links': len(links), 'missing_links': sum(not x['exists'] for x in links),
      'fixed_source_sha256': sha(result.stdout), 'java_launches': 0}, indent=2))
