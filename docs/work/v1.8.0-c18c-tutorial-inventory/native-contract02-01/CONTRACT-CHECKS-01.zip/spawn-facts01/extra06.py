"""Correct the declaration owner after extra05's preserved lookup failure."""
from pathlib import Path

base = Path(__file__).resolve().parent
text = (base / 'extra05.py').read_text(encoding='utf-8')
text = text.replace("'net/minecraft/server/level/ServerPlayer.class': {'isAlwaysTicking'},",
                    "'net/minecraft/world/entity/player/Player.class': {'isAlwaysTicking'},")
text = text.replace("parsed['net/minecraft/server/level/ServerPlayer.class']",
                    "parsed['net/minecraft/world/entity/player/Player.class']")
text = text.replace('ServerPlayer.isAlwaysTicking()Z', 'Player.isAlwaysTicking()Z')
text = text.replace('PRIMARY-EXTRA-05.json', 'PRIMARY-EXTRA-06.json')
exec(compile(text, str(base / 'extra05.py'), 'exec'))
