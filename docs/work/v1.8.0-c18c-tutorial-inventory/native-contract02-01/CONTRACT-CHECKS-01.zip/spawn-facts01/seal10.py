"""Freeze only this small loose facts packet; no archive/source export."""
import hashlib
import json
import os
from pathlib import Path

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
assert not (B / 'EVIDENCE-MANIFEST.json').exists()
assert not (B / 'SHA256SUMS.txt').exists()
checks = json.loads((B / 'FINAL-CHECKS-09.json').read_text(encoding='utf-8'))
assert all(x['unchanged'] for x in checks['external_inputs'])
assert json.loads((B / 'FINAL-LINKS-09.json').read_text(encoding='utf-8'))['missing'] == 0
entries = []
for p in sorted(B.iterdir(), key=lambda p: p.name):
    if p.is_file() and p.name not in ('seal-10.log', 'seal-10.exit'):
        data = p.read_bytes()
        entries.append({'path': p.name, 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'scope': 'read-only selected native spawn/join facts; no proposal amendment or runtime proof',
            'source_context': 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
            'entries': entries, 'files': len(entries), 'bytes': sum(e['bytes'] for e in entries),
            'external_input_unchanged': 6, 'primary_class_members': 20,
            'derived_branch_controls': 8, 'relative_links': 21, 'java_launches': 0,
            'exclusions': ['process-temp directory', 'this sealer invocation log/exit (no raw native evidence)',
                           'manifest/checksum self-reference', 'official class bodies/JAR/full mappings',
                           'source/world exports or ZIPs']}
m = B / 'EVIDENCE-MANIFEST.json'
m.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
sums = '\n'.join(e['sha256'] + '  ' + e['path'] for e in entries)
sums += '\n' + hashlib.sha256(m.read_bytes()).hexdigest() + '  EVIDENCE-MANIFEST.json\n'
(B / 'SHA256SUMS.txt').write_text(sums, encoding='ascii')
assert all(hashlib.sha256((B / e['path']).read_bytes()).hexdigest() == e['sha256'] for e in entries)
print(json.dumps({'report_sha256': hashlib.sha256((B / 'REPORT-01.md').read_bytes()).hexdigest(),
                  'manifest_sha256': hashlib.sha256(m.read_bytes()).hexdigest(),
                  'checksum_sha256': hashlib.sha256((B / 'SHA256SUMS.txt').read_bytes()).hexdigest(),
                  'files': len(entries), 'bytes': manifest['bytes'], 'verified': len(entries)}, indent=2))
