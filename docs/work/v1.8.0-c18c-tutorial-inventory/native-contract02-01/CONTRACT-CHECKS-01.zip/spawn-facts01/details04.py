"""Export selected native declarations/references and lambda targets, never class bodies."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
P = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(P.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(P), 'exec'), ns)
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/'
         'net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/'
         'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(J.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'


def bootstrap_targets(data):
    """Read class metadata; retain symbolic bootstrap method references only."""
    r = ns['R'](data)
    assert r.u4() == 0xcafebabe
    r.n(4)
    cp = [None] * r.u2()
    i = 1
    while i < len(cp):
        t = r.u1()
        if t == 1:
            cp[i] = r.n(r.u2()).decode('utf-8')
        elif t in (7, 8, 16, 19, 20):
            cp[i] = (t, r.u2())
        elif t in (3, 4):
            cp[i] = (t, r.n(4).hex())
        elif t in (5, 6):
            cp[i] = (t, r.n(8).hex())
            i += 1
        elif t in (9, 10, 11, 12, 17, 18):
            cp[i] = (t, r.u2(), r.u2())
        elif t == 15:
            cp[i] = (t, r.u1(), r.u2())
        else:
            raise AssertionError(t)
        i += 1

    def ref(index):
        value = cp[index]
        if isinstance(value, str):
            return value
        if value[0] in (7, 8, 16, 19, 20):
            return cp[value[1]]
        if value[0] in (9, 10, 11):
            nt = cp[value[2]]
            return ref(value[1]) + '.' + cp[nt[1]] + cp[nt[2]]
        if value[0] == 15:
            return ref(value[2])
        return str(value)

    def attributes():
        out = {}
        for _ in range(r.u2()):
            name, length = cp[r.u2()], r.u4()
            out[name] = r.n(length)
        return out

    r.n(6)
    r.n(2 * r.u2())
    for _ in range(2):
        for _ in range(r.u2()):
            r.n(6)
            attributes()
    attrs = attributes()
    raw = ns['R'](attrs['BootstrapMethods'])
    out = []
    for _ in range(raw.u2()):
        method = ref(raw.u2())
        args = [ref(raw.u2()) for _ in range(raw.u2())]
        out.append({'bootstrap': method, 'arguments': args})
    return out


requests = {
    'net/minecraft/server/dedicated/DedicatedServerProperties.class': {'<init>'},
    'net/minecraft/server/dedicated/Settings.class': {'get', 'dispatchNumberOrString'},
    'net/minecraft/world/level/GameType.class': {'byName', 'byId', '<clinit>'},
    'net/minecraft/world/level/LevelReader.class': {'getHeightmapPos'},
    'net/minecraft/world/level/Level.class': {'hasChunk', 'getHeight', 'getSharedSpawnPos'},
    'net/minecraft/server/level/ServerLevel.class': {'addPlayer'},
    'net/minecraft/world/level/entity/PersistentEntitySectionManager.class': {
        'addNewEntityWithoutEvent', 'addEntityWithoutEvent', 'getEffectiveStatus', 'startTracking'},
    'net/minecraft/server/level/ServerLevel$EntityCallbacks.class': {'onTrackingStart'},
    'net/minecraft/server/level/ServerChunkCache.class': {'addEntity'},
    'net/minecraft/server/level/ChunkMap.class': {'addEntity', 'updatePlayerStatus'},
    'net/minecraft/server/level/DistanceManager.class': {'addPlayer'},
    'net/minecraft/world/level/CollisionGetter.class': {'lambda$getBlockCollisions$1'},
}
out = {'jar_sha256': sha(J.read_bytes()), 'classes': {}, 'java_launches': 0}
parsed = {}
with zipfile.ZipFile(J) as archive:
    for name, wanted in requests.items():
        data = archive.read(name)
        value = ns['parse'](data, wanted)
        parsed[name] = value
        methods = {}
        for method, info in value['selected_methods'].items():
            # Constructor and enum initializer only need this small property/constant slice.
            selected = info['instructions']
            if name.endswith('DedicatedServerProperties.class'):
                selected = [i for i in selected if 153 <= i['offset'] <= 182]
            if name.endswith('GameType.class') and method == '<clinit>()V':
                selected = [i for i in selected if i['reference'] == 'adventure'
                            or (i['reference'] and 'GameType.ADVENTURE' in i['reference'])]
            methods[method] = {'access': info['access'],
                'references': [{'offset': i['offset'], 'reference': i['reference']}
                               for i in selected if i['reference'] is not None],
                'branches': [{'offset': i['offset'], 'opcode': i['opcode_hex'],
                              'target': i['branch_target']}
                             for i in selected if i['branch_target'] is not None]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data),
                                'selected_methods': methods}
        if name.endswith('DedicatedServerProperties.class'):
            bootstraps = bootstrap_targets(data)
            targets = []
            for i in value['selected_methods']['<init>(Ljava/util/Properties;)V']['instructions']:
                if 153 <= i['offset'] <= 182 and i['reference'] and i['reference'].startswith('dynamic#'):
                    index = int(re.match(r'dynamic#(\d+)', i['reference']).group(1))
                    targets.append({'offset': i['offset'], 'dynamic': i['reference'],
                                    **bootstraps[index]})
            out['gamemode_parser_targets'] = targets

assert any('GameType.byName' in a for b in out['gamemode_parser_targets'] for a in b['arguments'])
assert any('GameType.byId' in a for b in out['gamemode_parser_targets'] for a in b['arguments'])
assert out['classes']['net/minecraft/world/level/GameType.class']['selected_methods'][
    '<clinit>()V']['references'][0]['reference'] == 'adventure'
assert any('DistanceManager.addPlayer' in i['reference'] for m in out['classes'][
    'net/minecraft/server/level/ChunkMap.class']['selected_methods'].values() for i in m['references'])
(B / 'PRIMARY-DETAILS-04.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(out['classes']), 'methods': sum(len(c['selected_methods'])
      for c in out['classes'].values()), 'gamemode_parser_targets': out['gamemode_parser_targets'],
      'java_launches': 0}, indent=2))
