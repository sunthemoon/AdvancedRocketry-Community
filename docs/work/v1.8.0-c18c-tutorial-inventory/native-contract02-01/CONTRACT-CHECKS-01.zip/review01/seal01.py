from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
inputs = json.loads((OUT / 'INPUT-PINS-01.json').read_bytes())
for path, expected in inputs['external'].items():
    assert pin(Path(path).read_bytes()) == expected, path
for old in inputs['git_object_reads']:
    run = subprocess.run(old['command'], capture_output=True, check=False)
    assert run.returncode == 0 and pin(run.stdout) == {k: old[k] for k in ('bytes', 'sha256')}
report = OUT / 'REVIEW-01.md'
links = []
for target in re.findall(r'\]\(([^)]+)\)', report.read_text(encoding='utf-8')):
    assert ':' not in target and '..' not in Path(target).parts, target
    assert (OUT / target.split('#', 1)[0]).is_file(), target
    links.append(target)
exclude = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-CHECK-01.json'}
files = []
for path in sorted(OUT.iterdir(), key=lambda p: p.name):
    if path.is_dir():
        assert path.name == 'tmp'
        continue
    assert path.is_file() and not path.is_symlink()
    if path.name in exclude:
        raise AssertionError('Pre-existing seal output: ' + path.name)
    files.append({'path': path.name, **pin(path.read_bytes())})
manifest = {'schema': 1, 'scope': 'Independent proposed C18 native ownership/leaf review only',
            'files': files, 'payload_bytes': sum(row['bytes'] for row in files),
            'report': {'path': report.name, **pin(report.read_bytes())},
            'report_relative_links': len(links), 'missing_links': 0,
            'excluded': sorted(exclude), 'java_native_runs': 0}
manifestpath = OUT / 'INTERNAL-MANIFEST.json'
manifestpath.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
manifestpin = pin(manifestpath.read_bytes())
checksums = ''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in files)
checksums += manifestpin['sha256'] + '  INTERNAL-MANIFEST.json\n'
checksumspath = OUT / 'SHA256SUMS.txt'
checksumspath.write_bytes(checksums.encode('ascii'))
for row in files:
    assert pin((OUT / row['path']).read_bytes()) == {k: row[k] for k in ('bytes', 'sha256')}
receipt = {'exit': 0, 'payloads': len(files), 'payload_bytes': manifest['payload_bytes'],
           'report': manifest['report'], 'manifest': manifestpin,
           'checksums': pin(checksumspath.read_bytes()),
           'inputs_postchecked': len(inputs['external']) + len(inputs['git_object_reads']),
           'report_relative_links': len(links), 'missing_links': 0,
           'java_native_git_writes': 0, 'archive_created': False}
(OUT / 'SEAL-CHECK-01.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2))
