from pathlib import Path

source = Path(__file__).with_name('loading_route03.py').read_text(encoding='utf-8')
source = source.replace("assert not any(m['name'] == 'getChunk' and m['descriptor'] == '(II)Lnet/minecraft/world/level/chunk/LevelChunk;'\n               for m in server_methods)",
                        "assert 'getChunk(II)Lnet/minecraft/world/level/chunk/LevelChunk;' not in server_methods")
source = source.replace('LOADING-ROUTE-03.json', 'LOADING-ROUTE-04.json')
exec(compile(source, 'loading_route03.py (correct dictionary declaration check)', 'exec'))
