from pathlib import Path
import ast
import hashlib
import json
import os
import struct
import zipfile

OUT=Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve()==(OUT/'tmp').resolve() for k in ('TEMP','TMP','TMPDIR'))
parser=Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes=[node for node in ast.parse(parser.read_bytes()).body
       if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ('R','parse')]
ns={'struct':struct};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(parser),'exec'),ns)
jar=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
         '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert hashlib.sha256(jar.read_bytes()).hexdigest()=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests={'net/minecraft/server/level/PlayerRespawnLogic.class':{'getOverworldRespawnPos'},
          'net/minecraft/world/level/Level.class':{'getChunk','getChunkAt'},
          'net/minecraft/server/level/ServerPlayer.class':{'<init>','fudgeSpawnLocation'}}
facts={}
with zipfile.ZipFile(jar) as archive:
    for path,methods in requests.items():
        raw=archive.read(path);parsed=ns['parse'](raw,methods)
        selected={}
        for name,method in parsed['selected_methods'].items():
            refs=[]
            for i,ins in enumerate(method['instructions']):
                if ins['reference'] is not None:
                    refs.append({'offset':ins['offset'],'reference':ins['reference'],
                                 'preceding_opcode':method['instructions'][i-1]['opcode_hex'] if i else None,
                                 'preceding_operand':method['instructions'][i-1]['operand_hex'] if i else None})
            selected[name]=refs
        facts[path]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'selected':selected}
respawn=facts['net/minecraft/server/level/PlayerRespawnLogic.class']['selected']
calls=[row for rows in respawn.values() for row in rows if '.getChunk(' in row['reference']]
assert calls
level=facts['net/minecraft/world/level/Level.class']['selected']
force_calls=[row for rows in level.values() for row in rows
             if '.getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)' in row['reference']]
assert any(row['preceding_opcode']=='0x4' for row in force_calls)
out={'classes':facts,'respawn_chunk_accesses':calls,'true_create_chunk_route':force_calls,
     'scope':'Source-backed conditional constructor route, not an executed forced-load or chosen host observation',
     'java_launches':0}
path=OUT/'SPAWN-PRIMARY-01.json';assert not path.exists()
path.write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps({'respawn_calls':calls,'true_create_route':force_calls,'java_launches':0}))
