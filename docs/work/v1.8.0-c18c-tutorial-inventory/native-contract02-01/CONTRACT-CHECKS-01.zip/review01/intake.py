from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import os
import struct
import subprocess
import zipfile

OUT=Path(__file__).resolve().parent
AUTHOR=OUT.parent/'c18-native-proposal-8a05f49bd1'
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT='a5abc34809891d6b10724ee60ab9b5e97f036bae'


def pin(data): return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def dump(name,value):
    path=OUT/name
    assert not path.exists(),name
    path.write_bytes((json.dumps(value,indent=2,ensure_ascii=True)+'\n').encode())


assert all(Path(os.environ[key]).resolve()==(OUT/'tmp').resolve() for key in ('TEMP','TMP','TMPDIR'))
manifestraw=(AUTHOR/'EVIDENCE-MANIFEST.json').read_bytes()
assert pin(manifestraw)['sha256']=='cc689403716863d8885092c1e26ab5eee720621d06058c1581166d37d03af2ae'
manifest=json.loads(manifestraw)
pins={str(AUTHOR/'EVIDENCE-MANIFEST.json'):pin(manifestraw)}
for row in manifest['files']:
    relative=PurePosixPath(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts and ':' not in row['path']
    raw=(AUTHOR/row['path']).read_bytes()
    assert pin(raw)=={key:row[key] for key in ('bytes','sha256')},row['path']
    pins[str(AUTHOR/row['path'])]=pin(raw)
checksums=(AUTHOR/'SHA256SUMS.txt').read_bytes()
pins[str(AUTHOR/'SHA256SUMS.txt')]=pin(checksums)
for line in checksums.decode('ascii').splitlines():
    expected,path=line.split('  ',1)
    assert pin((AUTHOR/path).read_bytes())['sha256']==expected,path
expected={'OWNERSHIP-PROPOSAL-01.md':'5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581',
          'PROTOCOL-01.json':'1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf'}
for name,sha in expected.items(): assert pins[str(AUTHOR/name)]['sha256']==sha
task=ROOT/'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-02.md'
assert pin(task.read_bytes())['sha256']=='d1eebd7b4683ff9da0cacafa2e72f9bf98ed98d1552047c880b5310884e44ced'
pins[str(task)]=pin(task.read_bytes())
(OUT/'NATIVE-TASK-02.input.md').write_bytes(task.read_bytes())
old=ROOT/'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-01.md'
assert pin(old.read_bytes())['sha256']=='5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a'
pins[str(old)]=pin(old.read_bytes())
commands=[]
inputs=json.loads((AUTHOR/'INPUTS-01.json').read_bytes())['inputs']
inputs+=json.loads((AUTHOR/'SUPPLEMENT-01.json').read_bytes())['named_inputs']
unique={row['source']:row for row in inputs}
for locator,row in unique.items():
    if locator.startswith(COMMIT+':'):
        command=['git','-C',str(ROOT),'show',locator]
        result=subprocess.run(command,capture_output=True,check=False)
        assert result.returncode==0,(locator,result.stderr)
        raw=result.stdout
        commands.append({'command':command,'exit':0,**pin(raw)})
    else:
        raw=Path(locator).read_bytes()
        pins[locator]=pin(raw)
    assert pin(raw)=={key:row[key] for key in ('bytes','sha256')},locator
dump('INPUT-PINS-01.json',{'external':pins,'git_object_reads':commands,'proposal_payloads':len(manifest['files']),
                        'author_named_inputs_verified':len(unique),'no_runtime_or_world_read':True})
parser=Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes=[node for node in ast.parse(parser.read_bytes()).body
       if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ('R','parse')]
ns={'struct':struct}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(parser),'exec'),ns)
jar=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
         '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert pin(jar.read_bytes())['sha256']=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests={
 'net/minecraft/server/players/GameProfileCache.class':{'<init>','get','load','save','getTopMRUProfiles'},
 'net/minecraft/server/players/GameProfileCache$GameProfileInfo.class':{'getProfile','getLastAccess','setLastAccess'},
 'net/minecraft/server/players/PlayerList.class':{'<init>','getPlayers','getPlayer','getPlayerStats','getPlayerAdvancements','placeNewPlayer','load','save','remove'},
 'net/minecraft/server/level/ServerPlayer.class':{'<init>','fudgeSpawnLocation','teleportTo'},
 'net/minecraft/network/Connection.class':{'disconnect','isConnected'},
 'net/minecraft/world/entity/player/Player.class':{'addAdditionalSaveData'},
 'net/minecraft/world/entity/player/Inventory.class':{'<init>','save','getContainerSize'},
 'net/minecraft/nbt/ListTag.class':{'<init>','write'},
 'net/minecraft/world/level/storage/PlayerDataStorage.class':{'load','save'},
 'net/minecraft/server/PlayerAdvancements.class':{'<init>','load','save','stopListening'},
}
facts={}
with zipfile.ZipFile(jar) as archive:
    for name,methods in requests.items():
        raw=archive.read(name)
        parsed=ns['parse'](raw,methods)
        facts[name]={'pin':pin(raw),'fields':parsed['fields'],
                    'selected':{method:{'access':info['access'],'references':[
                        {'offset':ins['offset'],'opcode':ins['opcode_hex'],'reference':ins['reference'],
                         'branch_target':ins['branch_target']}
                        for ins in info['instructions'] if ins['reference'] is not None]}
                      for method,info in parsed['selected_methods'].items()}}
dump('INDEPENDENT-PRIMARY-01.json',{'jar_sha256':pin(jar.read_bytes())['sha256'],'classes':facts,
                                 'class_bodies_not_exported':True,'java_launches':0})
print(json.dumps({'proposal_payloads':len(manifest['files']),'original_inputs_verified':len(unique),
                  'external_pins':len(pins),'primary_classes':len(facts),'no_java_native':True}))
