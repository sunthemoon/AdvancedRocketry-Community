from pathlib import Path

# Preserve the failed assertion about a direct true operand; inspect the actual route.
source=Path(__file__).with_name('spawn_probe.py').read_text(encoding='utf-8')
source=source.replace("assert any(row['preceding_opcode']=='0x4' for row in force_calls)",
                      "assert force_calls  # default boolean forwarding still requires caller inspection")
source=source.replace('SPAWN-PRIMARY-01.json','SPAWN-PRIMARY-02.json')
source=source.replace("'true_create_chunk_route':force_calls", "'boolean_forwarding_chunk_route':force_calls")
source=source.replace("'true_create_route':force_calls", "'boolean_forwarding_route':force_calls")
exec(compile(source,'spawn_probe.py (actual forwarding operand recorded)','exec'))
