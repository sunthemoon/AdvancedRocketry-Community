from pathlib import Path
import ast
import hashlib
import json
import os
import struct
import zipfile

OUT = Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
assert hashlib.sha256(parser.read_bytes()).hexdigest() == '001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167'
nodes = [node for node in ast.parse(parser.read_bytes()).body
         if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert hashlib.sha256(jar.read_bytes()).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/world/level/Level.class': {'getChunk'},
    'net/minecraft/world/level/LevelReader.class': {'getChunk'},
    'net/minecraft/server/level/ServerLevel.class': {'getChunk'},
    'net/minecraft/server/level/ServerPlayer.class': {'<init>', 'fudgeSpawnLocation'},
    'net/minecraft/server/players/PlayerList.class': {'placeNewPlayer', 'load'},
    'net/minecraft/server/level/PlayerRespawnLogic.class': {'getOverworldRespawnPos'},
}
facts = {}
parsed_classes = {}
with zipfile.ZipFile(jar) as archive:
    for path, methods in requests.items():
        raw = archive.read(path)
        parsed = ns['parse'](raw, methods)
        parsed_classes[path] = parsed
        refs = {}
        for name, method in parsed['selected_methods'].items():
            refs[name] = [
                {'offset': ins['offset'], 'reference': ins['reference'],
                 'preceding_opcode': method['instructions'][i - 1]['opcode_hex'] if i else None,
                 'preceding_operand': method['instructions'][i - 1]['operand_hex'] if i else None}
                for i, ins in enumerate(method['instructions']) if ins['reference'] is not None
            ]
        facts[path] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                       'method_references': refs}

level = parsed_classes['net/minecraft/world/level/Level.class']['selected_methods']
two = level['getChunk(II)Lnet/minecraft/world/level/chunk/LevelChunk;']['instructions']
two_refs = [i['reference'] for i in two if i['reference']]
assert any('.FULL' in r for r in two_refs)
assert any('.getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;)' in r for r in two_refs)
reader = parsed_classes['net/minecraft/world/level/LevelReader.class']['selected_methods']
three = reader['getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;)Lnet/minecraft/world/level/chunk/ChunkAccess;']['instructions']
call_idx = next(i for i, ins in enumerate(three) if ins['reference']
                and '.getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)' in ins['reference'])
assert three[call_idx - 1]['opcode_hex'] == '0x4', three
four = level['getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)Lnet/minecraft/world/level/chunk/ChunkAccess;']['instructions']
forward_idx = next(i for i, ins in enumerate(four) if ins['reference']
                   and '.getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)' in ins['reference'])
assert four[forward_idx - 1]['opcode_hex'] == '0x15' and four[forward_idx - 1]['operand_hex'] == '04'
server_methods = parsed_classes['net/minecraft/server/level/ServerLevel.class']['all_methods']
assert not any(m['name'] == 'getChunk' and m['descriptor'] == '(II)Lnet/minecraft/world/level/chunk/LevelChunk;'
               for m in server_methods)
respawn = facts['net/minecraft/server/level/PlayerRespawnLogic.class']['method_references']
assert any(r['offset'] == 17 and '.getChunk(II)' in r['reference']
           for rows in respawn.values() for r in rows)
player = facts['net/minecraft/server/level/ServerPlayer.class']['method_references']
assert any(r['offset'] == 249 and '.fudgeSpawnLocation(' in r['reference']
           for name, rows in player.items() if name.startswith('<init>') for r in rows)
assert any(r['offset'] == 202 and '.getOverworldRespawnPos(' in r['reference']
           for name, rows in player.items() if name.startswith('fudgeSpawnLocation') for r in rows)

result = {
    'jar_sha256': '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e',
    'classes': facts,
    'confirmed_route': ['constructor -> fudgeSpawnLocation', 'conditional skylight/non-ADVENTURE -> respawn helper',
                        'respawn helper -> inherited Level.getChunk(int,int)',
                        'Level -> FULL + LevelReader default create=true',
                        'Level four-argument overload -> ChunkSource.getChunk forwards true'],
    'scope': 'Static conditional native route; no chosen host or forced-load execution observed.',
    'java_launches': 0,
}
target = OUT / 'LOADING-ROUTE-03.json'
assert not target.exists()
target.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'confirmed_route': result['confirmed_route'], 'classes': len(facts), 'java_launches': 0}))
