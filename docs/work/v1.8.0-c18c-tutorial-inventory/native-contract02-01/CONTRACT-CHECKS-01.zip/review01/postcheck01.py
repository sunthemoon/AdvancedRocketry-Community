from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
inputs = json.loads((OUT / 'INPUT-PINS-01.json').read_bytes())
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
external = []
for path, expected in inputs['external'].items():
    actual = pin(Path(path).read_bytes())
    external.append({'path': path, 'expected': expected, 'actual': actual, 'equal': actual == expected})
git = []
for old in inputs['git_object_reads']:
    run = subprocess.run(old['command'], capture_output=True, check=False)
    actual = pin(run.stdout)
    git.append({'command': old['command'], 'exit': run.returncode, 'actual': actual,
                'equal': run.returncode == 0 and actual == {k: old[k] for k in ('bytes', 'sha256')}})
author = OUT.parent / 'c18-native-proposal-8a05f49bd1'
links = []
for name in ('OWNERSHIP-PROPOSAL-01.md', 'CHECKPOINT-01.md'):
    text = (author / name).read_text(encoding='utf-8')
    for link in re.findall(r'\]\(([^)]+)\)', text):
        if ':' in link or link.startswith('#'):
            continue
        path = author / link.split('#', 1)[0]
        links.append({'document': name, 'target': link, 'exists': path.is_file()})
record = {'external_inputs': len(external), 'git_objects': len(git),
          'external': external, 'git': git, 'author_companion_links': links,
          'all_inputs_unchanged': all(row['equal'] for row in external + git),
          'all_author_links_exist': all(row['exists'] for row in links),
          'java_native_git_writes': 0}
target = OUT / 'INPUT-POSTCHECK-01.json'
assert not target.exists()
target.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in record.items() if k not in ('external', 'git', 'author_companion_links')}))
assert record['all_inputs_unchanged']
assert record['all_author_links_exist']
