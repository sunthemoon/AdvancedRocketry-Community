"""Bounded proposal/fact controls, not a fixture or Minecraft runtime replay."""
from pathlib import Path
import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import struct
import subprocess
import unittest
import uuid
import zipfile

OUT = Path(__file__).resolve().parent
B = OUT.parent / 'c18-native-proposal-8a05f49bd1'
R = Path('D:/GitHub/AdvancedRocketry-Community')
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve()
           for k in ('TEMP', 'TMP', 'TMPDIR'))
P = json.loads((B / 'PROTOCOL-01.json').read_bytes())
BASE = P['source_commit']
N = json.loads((B / 'NATIVE-INVENTORY-02.json').read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
FACTS = json.loads((OUT / 'INDEPENDENT-PRIMARY-01.json').read_bytes())['classes']
LOAD = json.loads((OUT / 'LOADING-ROUTE-04.json').read_bytes())['classes']

# Execute only unmodified declarations, never author's environment/writing main.
author_ns = {name: globals()[name] for name in ('B', 'R', 'P', 'BASE', 'N', 'sha', 'copy',
             'datetime', 'timezone', 'hashlib', 'json', 'Path', 're', 'subprocess', 'unittest', 'uuid', 'struct')}
for source in ('controls01.py', 'field_check02.py'):
    tree = ast.parse((B / source).read_bytes())
    declarations = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
    exec(compile(ast.Module(body=declarations, type_ignores=[]), str(B / source), 'exec'), author_ns)

parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body
         if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in ('R', 'parse')]
reader_ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), reader_ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/world/entity/player/Inventory.class': {'<init>', 'save'},
    'net/minecraft/world/entity/player/Player.class': {'addAdditionalSaveData'},
    'net/minecraft/nbt/ListTag.class': {'<init>', 'write'},
}
PARSED = {}
with zipfile.ZipFile(jar) as archive:
    for name, methods in requests.items():
        PARSED[name] = reader_ns['parse'](archive.read(name), methods)['selected_methods']

def refs(class_name, method):
    return FACTS[class_name]['selected'][method]['references']

class IndependentControls(unittest.TestCase):
    def test_declared_inventory_route_is_native_not_hook_summary(self):
        instructions = PARSED['net/minecraft/world/entity/player/Player.class'][
            'addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V']['instructions']
        native_refs = [i['reference'] for i in instructions]
        self.assertIn('Inventory', native_refs)
        self.assertIn('net/minecraft/nbt/ListTag.<init>()V', native_refs)
        self.assertIn('net/minecraft/world/entity/player/Inventory.save(Lnet/minecraft/nbt/ListTag;)Lnet/minecraft/nbt/ListTag;', native_refs)
        self.assertIn('net/minecraft/nbt/CompoundTag.put(Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag;', native_refs)

    def test_default_and_emitted_empty_list_subtype_are_zero(self):
        methods = PARSED['net/minecraft/nbt/ListTag.class']
        ctor = methods['<init>()V']['instructions']
        call = next(i for i, row in enumerate(ctor) if row['reference']
                    == 'net/minecraft/nbt/ListTag.<init>(Ljava/util/List;B)V')
        self.assertEqual(ctor[call - 1]['opcode_hex'], '0x3')
        write = methods['write(Ljava/io/DataOutput;)V']['instructions']
        empty = next(i for i, row in enumerate(write) if row['reference'] == 'java/util/List.isEmpty()Z')
        reset = next(i for i, row in enumerate(write) if row['opcode_hex'] == '0xb5'
                     and row['reference'] == 'net/minecraft/nbt/ListTag.typeB')
        self.assertEqual(write[reset - 1]['opcode_hex'], '0x3')
        self.assertEqual(write[empty + 1]['opcode_hex'], '0x99')
        self.assertGreater(write[empty + 1]['branch_target'], write[reset]['offset'])

    def test_inventory_three_partitions_skip_empty_stack_emission(self):
        save = PARSED['net/minecraft/world/entity/player/Inventory.class'][
            'save(Lnet/minecraft/nbt/ListTag;)Lnet/minecraft/nbt/ListTag;']['instructions']
        branches = [save[i + 1] for i, row in enumerate(save)
                    if row['reference'] == 'net/minecraft/world/item/ItemStack.isEmpty()Z']
        self.assertEqual(len(branches), 3)
        self.assertTrue(all(b['opcode_hex'] == '0x9a' for b in branches))

    def test_public_player_list_observers_do_not_call_cache_getters(self):
        for method in ('getPlayers()Ljava/util/List;', 'getPlayer(Ljava/util/UUID;)Lnet/minecraft/server/level/ServerPlayer;'):
            method_refs = refs('net/minecraft/server/players/PlayerList.class', method)
            self.assertTrue(method_refs)
            self.assertFalse(any('GameProfileCache.' in row['reference'] for row in method_refs))
            self.assertFalse(any('.put(' in row['reference'] or '.save(' in row['reference'] for row in method_refs))

    def test_profile_lookup_uuid_mutates_and_name_can_lookup_remote(self):
        uuid_get = refs('net/minecraft/server/players/GameProfileCache.class', 'get(Ljava/util/UUID;)Ljava/util/Optional;')
        name_get = refs('net/minecraft/server/players/GameProfileCache.class', 'get(Ljava/lang/String;)Ljava/util/Optional;')
        self.assertTrue(any('.setLastAccess(' in row['reference'] for row in uuid_get))
        self.assertTrue(any('.getNextOperation(' in row['reference'] for row in uuid_get))
        self.assertTrue(any('.lookupGameProfile(' in row['reference'] for row in name_get))
        self.assertTrue(any('.save(' in row['reference'] for row in name_get))

    def test_declared_read_only_fields_have_native_descriptors_modifiers(self):
        targets = {
            'net/minecraft/server/players/GameProfileCache.class': {'profilesByName': 'Ljava/util/Map;',
                'profilesByUUID': 'Ljava/util/Map;', 'requests': 'Ljava/util/Map;', 'file': 'Ljava/io/File;'},
            'net/minecraft/server/players/GameProfileCache$GameProfileInfo.class': {'profile': 'Lcom/mojang/authlib/GameProfile;'},
            'net/minecraft/server/players/PlayerList.class': {'stats': 'Ljava/util/Map;', 'advancements': 'Ljava/util/Map;'},
        }
        for klass, names in targets.items():
            fields = FACTS[klass]['fields']
            for name, descriptor in names.items():
                matched = [row for row in fields if row['name'] == name]
                self.assertEqual(len(matched), 1)
                self.assertEqual(matched[0]['descriptor'], descriptor)
                self.assertEqual(matched[0]['access'], 0x12)

    def test_ctor_stats_and_advancement_precede_spawn_and_join(self):
        rows = next(rows for name, rows in LOAD['net/minecraft/server/level/ServerPlayer.class']['method_references'].items()
                    if name.startswith('<init>'))
        offsets = {row['reference']: row['offset'] for row in rows}
        stats = next(v for k, v in offsets.items() if '.getPlayerStats(' in k)
        advancement = next(v for k, v in offsets.items() if '.getPlayerAdvancements(' in k)
        spawn = next(v for k, v in offsets.items() if '.fudgeSpawnLocation(' in k)
        self.assertEqual((stats, advancement, spawn), (224, 236, 249))

    def test_loaded_target_does_not_cover_native_constructor_spawn_route(self):
        native = LOAD['net/minecraft/server/level/PlayerRespawnLogic.class']['method_references']
        calls = [row for rows in native.values() for row in rows if '.getChunk(II)' in row['reference']]
        self.assertEqual([row['offset'] for row in calls], [17])
        route = json.loads((OUT / 'LOADING-ROUTE-04.json').read_bytes())['confirmed_route']
        self.assertIn('Level -> FULL + LevelReader default create=true', route)
        # Set containment illustrates the actual contract gap, not a native run.
        target_loaded = {(0, 0)}
        distinct_spawn_chunk = (16, -2)
        self.assertNotIn(distinct_spawn_chunk, target_loaded)

    def test_join_load_selects_server_level_before_world_insertion(self):
        rows = refs('net/minecraft/server/players/PlayerList.class',
            'placeNewPlayer(Lnet/minecraft/network/Connection;Lnet/minecraft/server/level/ServerPlayer;)V')
        pick = lambda needle: next(row['offset'] for row in rows if needle in row['reference'])
        self.assertEqual(pick('PlayerList.load('), 69)
        self.assertEqual(pick('ServerPlayer.setServerLevel('), 181)
        self.assertEqual(pick('ServerLevel.addNewPlayer('), 843)
        self.assertLess(pick('PlayerList.load('), pick('ServerPlayer.setServerLevel('))
        self.assertLess(pick('ServerPlayer.setServerLevel('), pick('ServerLevel.addNewPlayer('))

    def test_cleanup_player_remove_is_not_connection_dispose(self):
        rows = refs('net/minecraft/server/players/PlayerList.class', 'remove(Lnet/minecraft/server/level/ServerPlayer;)V')
        self.assertTrue(any('PlayerList.save(' in row['reference'] for row in rows))
        self.assertFalse(any('EmbeddedChannel.' in row['reference'] for row in rows))
        self.assertFalse(any('Connection.disconnect(' in row['reference'] for row in rows))

    def test_seed_reload_different_observation_and_only_stopped_receipt(self):
        self.assertEqual(P['seed_events'][:3], ['PREFLIGHT', 'INITIAL', 'CONTROL'])
        self.assertEqual(P['reload_events'][:2], ['PREFLIGHT', 'LOADED'])
        self.assertEqual(P['external_receipt_fields']['phase'], 'seed')
        self.assertNotIn('advancement_progress', P['external_marker_fields'])
        self.assertIn('nativeprogresswritefromreceipt', P['forbidden_authorities'])

    def test_empty_native_inventory_oracle_rejects_wrong_count_and_type(self):
        framing = lambda subtype, count: struct.pack('>BH', 9, 9) + b'Inventory' + struct.pack('>bi', subtype, count)
        original = framing(0, 0)
        self.assertEqual(len(original), 17)
        for subtype, count in ((10, 0), (0, 1), (0, -1), (1, 0)):
            self.assertNotEqual(framing(subtype, count), original)

suite = unittest.TestSuite()
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(author_ns['ProposalControls']))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(author_ns['FinalControls']))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(IndependentControls))
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {'tests': result.testsRun, 'author_unmodified_declaration_tests': 18,
          'reviewer_tests': 12, 'failures': len(result.failures), 'errors': len(result.errors),
          'skipped': len(result.skipped), 'java_launches': 0, 'native_runs': 0,
          'scope': 'Abstract controls and independently reparsed native facts; no fixture implementation or chosen host.'}
path = OUT / 'CONTROLS-RESULT-01.json'
assert not path.exists()
path.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() else 1)
