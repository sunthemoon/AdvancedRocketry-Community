# C18 native ownership proposal / replacement leaf review 01

Date: 2026-10-04. Independent delegated reviewer. Scope is the exact proposed
test-fixture contract, not implementation, native execution or version admission.

## Findings

### M1 — The pre-construction loaded-area contract does not cover native spawn/join work

**Medium.** Frozen `OWNERSHIP-PROPOSAL-01.md:64–67,217–222` and Root
`NATIVE-TASK-02.md:62–66,86–99` admit only loaded chunk `(0,0)` and fixed air
cells, promise that the hook never loads a chunk, and place creative mode / the
fixed location after join. Neither contract freezes the constructor's shared
spawn/default-world-mode/radius inputs or proves its possible search area already
loaded. Checking the final target or teleporting there later cannot bound earlier
native constructor/join work.

Independently reparsed pinned native facts establish this conditional route:

- `ServerPlayer.<init>(MinecraftServer,ServerLevel,GameProfile)` calls native stats
  at bytecode offset 224, advancements at 236, and `fudgeSpawnLocation` at 249.
- `fudgeSpawnLocation` checks skylight / world game mode and, on the non-ADVENTURE
  search route, uses shared spawn / server spawn radius and calls
  `PlayerRespawnLogic.getOverworldRespawnPos` at 202.
- That helper calls `ServerLevel.getChunk(int,int)` at 17. The inherited
  `Level.getChunk(int,int)` requests FULL; the `LevelReader` three-argument default
  supplies `create=true`; the four-argument Level overload forwards that boolean
  to `ChunkSource.getChunk`. ServerLevel does not override the two-int method.
- `PlayerList.placeNewPlayer` calls `load` at 69, `setServerLevel` at 181 and
  `ServerLevel.addNewPlayer` at 843, before the proposed hook's later teleport.
  Thus actual reload dimension/position behavior also belongs in the admission
  inventory, rather than being bounded by the final destination alone.

The proposal permits an ordinary skylight, non-ADVENTURE Overworld without
constraining these spawn inputs. Its target-only loaded test therefore does not
establish the declared boundary for all admitted hosts. This is a source-backed
contract gap, **not an observed forced load, generated terrain, timed-out
constructor or native data loss**. The host has not been selected or executed.
The native route is conditional; `create=true` does not itself prove a new chunk
was loaded in a particular run.

**Minimal action:** revise and independently review the copy-local host and
pre-constructor admission specification before assigning implementation. Pin the
actual default-mode/shared-spawn/radius/search and initial join/reload location
inputs; establish a finite already-loaded/native route, with explicit refusal for
unsupported states and tests of the alternate route. Any additional copy-local
setup command needs explicit authority. Do not treat switching mode, a later
teleport, a driver forceload of `(0,0)`, or an unrun model as proof by itself. Keep
no arbitrary loading/terrain changes and current deadlines unchanged.

Evidence: [independent native route](LOADING-ROUTE-04.json),
[initial native facts](INDEPENDENT-PRIMARY-01.json),
[30-control raw log](review-controls-01.log),
[Root leaf snapshot](NATIVE-TASK-02.input.md).

No additional Critical/High/Medium/Low finding was identified in the reviewed
ownership/reflection/protocol specification. This is not a verdict on nonexistent
fixture code. The unchanged proposal / Root leaf are **not ready for loaded-only
implementation adoption** while M1 remains.

## Consistent proposed boundaries and evidence limits

- The old offline/fresh-criteria ownership counterexample is addressed at the
  **normative design level** by dual admission before either constructor, eight
  fixed paths plus temp prefixes, orphan native cache inspection, and the
  driver-only receipt after verified seed clean stop. The historical old report
  is preserved; there is no executed ownership/nonmutation/restart closure.
- Read-only reflection is explicitly proposed, not silently implied by public
  cache methods. All seven proposed fields have the pinned native descriptors
  and private-final modifiers. PlayerList public UUID/list observers have no
  profile-cache mutation route in their selected bodies; native profile UUID get
  performs MRU mutation and name get can perform repository lookup/save. The
  proposed exact-class/count/bijection/two-snapshot rules avoid accepting foreign
  callback implementations. Development mapped/SRG declarations are consistent;
  access and SRG resolution in the future packaged server remain unrun.
- Actual `Player.addAdditionalSaveData` creates a fresh ListTag, passes it through
  `Inventory.save`, and puts Inventory in the Compound. All three partitions skip
  empty stacks; the default constructor passes subtype 0 and write sets type 0
  for an empty list. The proposed named tag 9 / subtype 0 / count 0 is consistent
  with native source facts. These are static emission facts, not an emitted
  player file, native reader test or hatch typed-empty-list admission.
- Seed and reload are distinct: loaded state precedes positive replay, receipt
  cannot restore/grant progress, exact within-host milliseconds differ from saved
  second-resolution UTC comparison, and control state remains independent.
  Actual listener, saved criterion shape, backups, UUID and all 41 live cells
  still require implementation and stopped native evidence.
- PlayerList remove saves but does not dispose the owned EmbeddedChannel. Local
  partial handles / identity-only cleanup / bounded drains / attempt-all finally
  / no rollback / no receipt after failure are specified. Precise native/Netty
  ordering and partial-constructor/join cleanup remain source/runtime tests,
  not established by a method return or an abstract model.
- The fixed phase fields, caps, one monotonic 300-second cohort, finite failure
  rows, parser authority and driver/observer separation are internally consistent
  in the reviewed proposal. Parser/gzip/NBT/JSON implementations do not yet exist
  here, so their allocation and malformed-input behavior are not admitted.

## Source-world selection and unknown error boundary

The future source server/world is **not selected**. Proposal lines 90–108 bind a
Root-selected named copied host, no extra mods, no earlier fixture commands,
read-only original records and no reset/deletion. Lines 365–367 require failure on
unknown ERROR/FATAL, and NATIVE-TASK-02:119–122 retains that obligation. These
conditions do not authorize treating the historic Guard template (protected
oversized roots and previous error pairs) as a clean C18 result. Existing errors
cannot be waived as harmless or erased to manufacture a passing cohort.

No admissible world, cache, mod list, loaded geometry or clean runtime has been
observed in this review. Root must select and pin a suitable copied-world cohort;
if the selected preserved data produces unknown errors or fails admission, keep
the run failed / select another separately pinned suitable input, without repair,
reset, deletion or borrowing an earlier native result. This remains an unrun
selection/execution dependency in addition to M1, not an observed native failure.

## Actual commands and retained failures

All Python commands used `-B` and process-local TEMP/TMP/TMPDIR at this owned
directory's `tmp`. No Java, Gradle, native server/client, network, Git writes,
world inspection/deletion or protected directory traversal occurred.

| Command / check | Actual result | Raw evidence |
|---|---|---|
| `python -B intake.py` | exit 0; 38 author payloads and checksum sidecar exact; 32 distinct original inputs independently verified; 50 external pins; 10 native classes selected | [log](intake-01.log), [exit](intake-01.exit), [input pins](INPUT-PINS-01.json) |
| `python -B spawn_probe.py` | exit 1; reviewer incorrectly assumed a direct `iconst_1` immediately before the forwarded ChunkSource boolean | [original](spawn_probe.py), [log](spawn-probe-01.log), [exit](spawn-probe-01.exit) |
| `python -B spawn_probe02.py` | exit 0; recorded actual `iload 4` forwarding, leaving default caller inspection explicit | [log](spawn-probe-02.log), [exit](spawn-probe-02.exit), [facts](SPAWN-PRIMARY-02.json) |
| `python -B loading_route03.py` | exit 1; reviewer treated parser `all_methods` dictionary keys as field dictionaries | [original](loading_route03.py), [log](loading-route-03.log), [exit](loading-route-03.exit) |
| `python -B loading_route04.py` | exit 0; corrected only the inspector's declaration-container check; proved inherited FULL/default create=true route across six selected classes | [log](loading-route-04.log), [exit](loading-route-04.exit), [facts](LOADING-ROUTE-04.json) |
| `python -B review_controls01.py` | exit 0; **30 tests / 0 failures, errors, skips**: 18 unchanged author declaration tests plus 12 independent controls | [script](review_controls01.py), [log](review-controls-01.log), [exit](review-controls-01.exit), [counts](CONTROLS-RESULT-01.json) |
| `python -B postcheck01.py` | exit 0; all 50 external files and 24 fixed Git object reads unchanged; bounded author companion links exist | [log](postcheck-01.log), [exit](postcheck-01.exit), [post-pins](INPUT-POSTCHECK-01.json) |

The 18 author tests were executed from unchanged AST declarations in a new
namespace pointing read-only to the frozen input folder. Their top-level
environment assignment and writing `__main__` were not executed. The twelve
reviewer controls reparse native facts and check finite abstract examples;
**30 passing controls are not tested fixture/cache/IO/channel/native code**. The
constructed distinct-spawn-chunk set example is not a measured world position.

One preceding combined PowerShell read guessed absent `inventory02.py`; actual
manifest names `inventory_primary02.py`. Get-Content emitted a missing-path error,
then the combined read ended 0; the corrected read was successful. This is a
transcribed tool observation, not a separately saved raw failure, and not a
proposal or native failure. All stored failed helpers above remain unchanged.
The author's prior locator, inventory-inspector and tooling failures stay in its
unchanged 38-member evidence bundle.

## Identity and remaining verification

Exact named source basis: `a5abc34809891d6b10724ee60ab9b5e97f036bae`.
This is not a current-whole-repository identity or an artifact implementing the
future fixture. Owner-maintained AGENTS was independently pinned as
`1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`.

- Proposal: `5314b0ca92dac51fdeda7b7bb1d22db97af435a86c12b2410dcb0ade73d4d581`.
- Protocol: `1685e9a5404558c5b5fc35e17911118fb6f5b2d1426d8f98e663960fdbe211bf`.
- Author manifest: `cc689403716863d8885092c1e26ab5eee720621d06058c1581166d37d03af2ae`.
- Root leaf: `d1eebd7b4683ff9da0cacafa2e72f9bf98ed98d1552047c880b5310884e44ced`.
- Historical draft: `5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a`.
- Historical review: `3cab6768b1ae36d2a228cf5921abdf9df2ef57a5ad43a5da2223ea7f2aa7521d`.
- Configured mapped native JAR:
  `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
- Development mapping:
  `246dc9d32f075e71167debb9b4ad1bb75be6a0a8584c08c5c06cc6b7b73d5d15`.

No full official bodies, JARs, mappings, source/world trees or redundant archives
were exported. Selected reference/declaration facts and loose small report/raw
controls are retained; external original locators and all named input pins are
in INPUT-PINS-01 / INPUT-POSTCHECK-01. The final internal manifest seals only this
owned bundle, not future mutable work or the original external dependency tree.

Unexecuted: future fixture compilation/source review, packaged cache field
resolution, strict reader/parser negative probes, actual preflight nonmutation,
partial disposal, admitted loaded host, real inventory triggers, two clean native
hosts and stopped files. No natural crash, real peer/client, V1/V2/GPU, R-021,
migration, shared writer/API or whole-v1.8 Required Gate conclusion is made.
Completion here is the independent proposal review and evidence seal only.
