"""Named primary declarations and development mappings; no Java or official body export."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/server/players/PlayerList.class': {'<init>', 'getPlayerStats', 'getPlayerAdvancements'},
    'net/minecraft/stats/ServerStatsCounter.class': {'save'},
    'net/minecraft/world/level/storage/PlayerDataStorage.class': {'<init>', 'load', 'save'},
}
out = {'baseline': BASE, 'java_launches': 0, 'classes': {}, 'named_inputs': []}
with zipfile.ZipFile(jar) as archive:
    for name, methods in requests.items():
        data = archive.read(name)
        parsed = ns['parse'](data, methods)
        out['classes'][name] = {
            'bytes': len(data), 'sha256': sha(data), 'fields': parsed['fields'],
            'methods': parsed['all_methods'], 'selected_references': {
                method: [{'offset': i['offset'], 'reference': i['reference']}
                         for i in info['instructions'] if i['reference'] is not None]
                for method, info in parsed['selected_methods'].items()}}
path = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/command/ReleaseTestCommands.java'
data = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=R)
out['named_inputs'].append({'source': BASE + ':' + path, 'bytes': len(data), 'sha256': sha(data)})
out['release_hook_property_declaration'] = [line.strip() for line in data.decode('utf-8').splitlines()
                                             if 'PROPERTY =' in line]
mapping = R / 'build/createMcpToSrg/output.tsrg'
data = mapping.read_bytes()
out['named_inputs'].append({'source': str(mapping), 'bytes': len(data), 'sha256': sha(data)})
selected = []
active = False
for line in data.decode('utf-8').splitlines():
    if line and not line[0].isspace():
        active = line.split()[0] == 'net/minecraft/server/players/PlayerList'
    if active and (not line[0].isspace() or line.strip().split()[0] in ('stats', 'advancements')):
        selected.append(line)
out['additional_playerlist_mapping_records'] = selected
assert sha(mapping.read_bytes()) == out['named_inputs'][-1]['sha256']
(B / 'SUPPLEMENT-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(requests), 'mapping_records': selected,
                  'property': out['release_hook_property_declaration'], 'java_launches': 0}, indent=2))
