"""Corrected constructor-route inspection; original StopIteration attempt is retained."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
           '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(jar.read_bytes()) == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/world/entity/player/Inventory.class': {'<init>', 'save', 'getContainerSize'},
    'net/minecraft/world/entity/player/Player.class': {'addAdditionalSaveData'},
    'net/minecraft/nbt/ListTag.class': {'<init>', 'write'},
}
out = {'jar_sha256': sha(jar.read_bytes()), 'java_launches': 0, 'classes': {}}
parsed_classes = {}
with zipfile.ZipFile(jar) as archive:
    for name, methods in requests.items():
        data = archive.read(name); parsed = ns['parse'](data, methods); parsed_classes[name] = parsed
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data),
                                'selected_reference_facts': {
            method: [{'offset': i['offset'], 'reference': i['reference'], 'branch_target': i['branch_target']}
                     for i in info['instructions'] if i['reference'] is not None]
            for method, info in parsed['selected_methods'].items()}}
list_methods = parsed_classes['net/minecraft/nbt/ListTag.class']['selected_methods']
ctor = list_methods['<init>()V']['instructions']
delegated = next(i for i, ins in enumerate(ctor)
                 if ins['reference'] == 'net/minecraft/nbt/ListTag.<init>(Ljava/util/List;B)V')
assert ctor[delegated - 1]['opcode_hex'] == '0x3'
typed_ctor = list_methods['<init>(Ljava/util/List;B)V']['instructions']
type_put = next(i for i, ins in enumerate(typed_ctor)
                if ins['opcode_hex'] == '0xb5' and ins['reference'] == 'net/minecraft/nbt/ListTag.typeB')
assert typed_ctor[type_put - 1]['opcode_hex'] == '0x1c'  # iload_2 receives byte argument0
write = list_methods['write(Ljava/io/DataOutput;)V']['instructions']
is_empty = next(i for i, ins in enumerate(write) if ins['reference'] == 'java/util/List.isEmpty()Z')
reset = next(i for i, ins in enumerate(write) if ins['opcode_hex'] == '0xb5'
             and ins['reference'] == 'net/minecraft/nbt/ListTag.typeB')
assert write[reset - 1]['opcode_hex'] == '0x3'
branch = write[is_empty + 1]
assert branch['opcode_hex'] == '0x99'
assert branch['branch_target'] > write[reset]['offset']
inventory_methods = parsed_classes['net/minecraft/world/entity/player/Inventory.class']['selected_methods']
save = inventory_methods['save(Lnet/minecraft/nbt/ListTag;)Lnet/minecraft/nbt/ListTag;']['instructions']
guards = []
for i, ins in enumerate(save):
    if ins['reference'] == 'net/minecraft/world/item/ItemStack.isEmpty()Z':
        next_ins = save[i + 1]
        assert next_ins['opcode_hex'] == '0x9a'
        guards.append({'isEmpty_offset': ins['offset'], 'skip_target': next_ins['branch_target']})
assert len(guards) == 3
partitions = []
for method, info in inventory_methods.items():
    if not method.startswith('<init>'):
        continue
    for i, ins in enumerate(info['instructions']):
        if ins['reference'] == 'net/minecraft/core/NonNullList.withSize(ILjava/lang/Object;)Lnet/minecraft/core/NonNullList;':
            immediate = info['instructions'][i - 2]
            op = int(immediate['opcode_hex'], 16)
            size = op - 3 if 3 <= op <= 8 else int.from_bytes(bytes.fromhex(immediate['operand_hex']), 'big', signed=True)
            partitions.append(size)
assert partitions == [36, 4, 1]
player = parsed_classes['net/minecraft/world/entity/player/Player.class']['selected_methods'][
    'addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V']['instructions']
refs = [i['reference'] for i in player]
assert 'Inventory' in refs
assert 'net/minecraft/nbt/ListTag.<init>()V' in refs
assert 'net/minecraft/world/entity/player/Inventory.save(Lnet/minecraft/nbt/ListTag;)Lnet/minecraft/nbt/ListTag;' in refs
assert 'java/io/DataOutput.writeByte(I)V' in [i['reference'] for i in write]
assert 'java/io/DataOutput.writeInt(I)V' in [i['reference'] for i in write]
out['empty_inventory_semantic_facts'] = {
    'player_save_route': 'Inventory -> new ListTag() -> Inventory.save -> CompoundTag.put',
    'default_list_type_argument': 0, 'default_ctor_delegate_offset': ctor[delegated]['offset'],
    'delegated_ctor_type_set_offset': typed_ctor[type_put]['offset'],
    'inventory_partition_sizes': partitions, 'inventory_empty_stack_skip_guards': guards,
    'empty_inventory_added_elements': 0,
    'write_empty_guard_offset': write[is_empty]['offset'],
    'write_empty_type_reset_offset': write[reset]['offset'],
    'emitted_payload_shape': {'element_type_byte': 0, 'signed_int_element_count': 0},
    'policy': 'Native freshly saved empty Inventory only. Not borrowed hatch typed-empty admission. No native execution.'}
(B / 'NATIVE-INVENTORY-02.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps(out['empty_inventory_semantic_facts'], indent=2))
