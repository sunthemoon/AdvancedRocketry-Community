"""Bounded named input/field/link consistency and primary constant fact checks."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
intake = json.loads((B / 'INPUTS-01.json').read_text(encoding='utf-8'))
supplement = json.loads((B / 'SUPPLEMENT-01.json').read_text(encoding='utf-8'))
pins = {p['source']: p for p in intake['inputs'] + supplement['named_inputs']}
post = []
for source, pin in pins.items():
    if source.startswith(intake['base'] + ':'):
        data = subprocess.check_output(['git', 'show', source], cwd=R)
    else:
        data = Path(source).read_bytes()
    post.append({'source': source, 'bytes': len(data), 'sha256': sha(data),
                 'matches_initial': len(data) == pin['bytes'] and sha(data) == pin['sha256']})
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [n for n in ast.parse(parser.read_bytes()).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
ns = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), ns)
jar = next(Path(p['source']) for p in intake['inputs'] if p['source'].endswith('_1.20.1.jar'))
with zipfile.ZipFile(jar) as archive:
    data = archive.read('net/minecraft/server/players/GameProfileCache.class')
    parsed = ns['parse'](data, {'save'})
    instructions = parsed['selected_methods']['save()V']['instructions']
    call_index = next(i for i, ins in enumerate(instructions)
                      if ins['reference'] and '.getTopMRUProfiles(I)' in ins['reference'])
    constant = instructions[call_index - 1]
    assert constant['opcode_hex'] == '0x11'
    limit = int.from_bytes(bytes.fromhex(constant['operand_hex']), 'big', signed=True)
    assert limit == 1000
    facts = {'class_sha256': sha(data), 'method': 'GameProfileCache.save()V',
             'argument_offset': constant['offset'], 'native_save_profile_limit': limit,
             'call_offset': instructions[call_index]['offset'],
             'scope': 'one integer argument semantic fact, no official body export'}
protocol = json.loads((B / 'PROTOCOL-01.json').read_text(encoding='utf-8'))
proposal = (B / 'OWNERSHIP-PROPOSAL-01.md').read_text(encoding='utf-8')
checks = {
    'all_named_inputs_unchanged': all(p['matches_initial'] for p in post),
    'native_save_limit_matches_proposed_map_ceiling': limit == protocol['ceilings']['profile_entries'],
    'seed_reserves_exact_two_profiles': protocol['ceilings']['seed_unrelated_profiles'] + 2 == limit,
    'success_report_count': len(protocol['seed_events']) + len(protocol['reload_events']) == 23,
    'row_buffers_fit_cohort_limit': 23 * protocol['ceilings']['report_bytes'] <= protocol['ceilings']['cohort_report_bytes'],
    'all_payload_fields_named': all(k in proposal or k in (B / 'PROTOCOL-01.json').read_text(encoding='utf-8')
                                    for k in ('obtained_ms', 'native_progress_cache_counts', 'release_attempt_completed')),
    'explicit_no_adoption': 'not implementation, adoption' in proposal,
    'explicit_additional_native_cache_proposal': 'two PlayerList caches' in proposal,
    'source_basis_distinct_future_cohort': 'future actual tested committed cohort' in proposal,
}
links = []
for path in B.glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if ':' in target or target.startswith('#'):
            continue
        links.append({'file': path.name, 'target': target, 'exists': (B / target.split('#')[0]).is_file()})
# CHECKPOINT-01.md is written after this input check; its link is an explicit future companion.
missing = [link for link in links if not link['exists'] and link['target'] != 'CHECKPOINT-01.md']
result = {'baseline': intake['base'], 'named_count': len(post), 'postimages': post,
          'primary_constant_fact': facts, 'checks': checks, 'local_links': links,
          'unresolved_links_before_checkpoint': missing, 'java_launches': 0, 'native_runs': 0}
(B / 'FINAL-INPUT-CHECK-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'named_count': len(post), 'changed_inputs': [p['source'] for p in post if not p['matches_initial']],
                  'checks': checks, 'missing_companions': missing, 'native_limit_fact': facts}, indent=2))
raise SystemExit(0 if all(checks.values()) and not missing else 1)
