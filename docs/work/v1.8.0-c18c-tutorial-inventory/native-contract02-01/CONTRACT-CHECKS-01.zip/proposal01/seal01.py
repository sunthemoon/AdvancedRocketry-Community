"""Seal a small loose proposal only; no ZIP/export, no mutation after sums."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
assert not (B / 'SHA256SUMS.txt').exists(), 'already sealed'
sha = lambda data: hashlib.sha256(data).hexdigest()
pins = json.loads((B / 'INPUTS-01.json').read_text(encoding='utf-8'))
extra = json.loads((B / 'SUPPLEMENT-01.json').read_text(encoding='utf-8'))
observations = []
for source, pin in {p['source']: p for p in pins['inputs'] + extra['named_inputs']}.items():
    data = subprocess.check_output(['git', 'show', source], cwd=R) if source.startswith(pins['base'] + ':') else Path(source).read_bytes()
    observations.append({'source': source, 'bytes': len(data), 'sha256': sha(data),
                         'matches_initial': len(data) == pin['bytes'] and sha(data) == pin['sha256']})
assert all(p['matches_initial'] for p in observations)
links = []
for path in B.glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if ':' in target or target.startswith('#'):
            continue
        link = {'file': path.name, 'target': target, 'exists': (B / target.split('#')[0]).is_file()}
        links.append(link)
assert all(link['exists'] for link in links)
scope = {'source_basis': pins['base'], 'named_input_count': len(observations),
         'postimages': observations, 'local_links': links, 'java_launches': 0, 'native_runs': 0,
         'limits': 'loose proposal and specification/static evidence only; no Root/source writes; no acceptance'}
(B / 'SEAL-INPUT-POSTCHECK-01.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8')
files = [path for path in B.iterdir() if path.is_file()]
manifest = {'schema': 1, 'kind': 'C18_NATIVE_OWNERSHIP_PROPOSAL_NOT_IMPLEMENTATION',
            'source_basis': pins['base'], 'files': [
                {'path': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
                for path in sorted(files)], 'file_count': len(files),
            'payload_bytes': sum(path.stat().st_size for path in files),
            'excluded': ['empty process-temp directory', 'manifest/sums self-reference', 'external primary JAR/mapping/Root source and historical report'],
            'external_inputs': 'INPUTS-01.json + SUPPLEMENT-01.json; all32 unchanged at seal'}
data = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(B / 'EVIDENCE-MANIFEST.json').write_bytes(data)
sums = [(item['sha256'], item['path']) for item in manifest['files']]
sums.append((sha(data), 'EVIDENCE-MANIFEST.json'))
(B / 'SHA256SUMS.txt').write_text(''.join(h + '  ' + name + '\n' for h, name in sorted(sums, key=lambda p: p[1])), encoding='ascii')
for h, name in sums:
    assert sha((B / name).read_bytes()) == h
print(json.dumps({'folder': str(B), 'payload_files': manifest['file_count'], 'payload_bytes': manifest['payload_bytes'],
                  'proposal_sha256': sha((B / 'OWNERSHIP-PROPOSAL-01.md').read_bytes()),
                  'protocol_sha256': sha((B / 'PROTOCOL-01.json').read_bytes()),
                  'handoff_sha256': sha((B / 'CHECKPOINT-01.md').read_bytes()),
                  'manifest_sha256': sha(data), 'sums_sha256': sha((B / 'SHA256SUMS.txt').read_bytes()),
                  'local_links': len(links), 'missing_links': 0, 'unchanged_named_inputs': len(observations),
                  'java_launches': 0, 'native_runs': 0}, indent=2))
