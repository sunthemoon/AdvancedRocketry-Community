"""Proposal specification controls only; no fixture/native implementation or Java."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import unittest
import uuid

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
P = json.loads((B / 'PROTOCOL-01.json').read_text(encoding='utf-8'))
BASE = P['source_commit']
R = Path('D:/GitHub/AdvancedRocketry-Community')
sha = lambda data: hashlib.sha256(data).hexdigest()

def paths():
    return [f'{folder}/{person["uuid"]}.{suffix}'
            for person in P['fixed_identities']
            for folder, suffix in [('playerdata', 'dat'), ('playerdata', 'dat_old'),
                                   ('advancements', 'json'), ('stats', 'json')]]

def seed_model(state):
    """Abstract ordering counter, not a Java/cache/IO admission function."""
    if any(state['files']) or state['temporary'] or state['online']:
        return {'admitted': False, 'constructed': 0, 'joins': 0}
    if state['progress_caches'] != [0, 0] or state['requests']:
        return {'admitted': False, 'constructed': 0, 'joins': 0}
    for ident in P['fixed_identities']:
        if any(entry['uuid'] == ident['uuid'] or entry['name'].lower() == ident['name'].lower()
               for entry in state['profiles']):
            return {'admitted': False, 'constructed': 0, 'joins': 0}
    if len(state['profiles']) > P['ceilings']['seed_unrelated_profiles']:
        return {'admitted': False, 'constructed': 0, 'joins': 0}
    return {'admitted': True, 'constructed': 2, 'joins': 2}

def receipt_model(receipt, actual):
    """Finite explanatory binding model, never a native progress source."""
    if not isinstance(receipt, dict) or set(receipt) != {'schema', 'phase', 'run', 'world', 'files'}:
        return False
    return (type(receipt['schema']) is int and receipt['schema'] == 1
            and receipt['phase'] == 'seed' and receipt['run'] == actual['run']
            and receipt['world'] == actual['world']
            and set(receipt['files']) == set(paths())
            and receipt['files'] == actual['files'])

def strict_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate key')
        out[key] = value
    return out

class ProposalControls(unittest.TestCase):
    def state(self):
        return {'files': [False] * 8, 'temporary': False, 'online': False,
                'profiles': [], 'requests': 0, 'progress_caches': [0, 0]}

    def test_fixed_inputs_and_unchanged_old_finding(self):
        pins = json.loads((B / 'INPUTS-01.json').read_text(encoding='utf-8'))
        self.assertEqual(pins['base'], BASE)
        self.assertEqual(sha((B / 'OLD-DRAFT-01.md').read_bytes()),
                         '5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a')
        old = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/atnc-b8773371d9/REVIEW-01.md')
        self.assertEqual(sha(old.read_bytes()),
                         '3cab6768b1ae36d2a228cf5921abdf9df2ef57a5ad43a5da2223ea7f2aa7521d')

    def test_goals_and_item_cardinality_match_actual_fixed_source(self):
        source = subprocess.check_output(['git', 'show', BASE + ':src/main/java/io/github/'
                    'sunthemoon/advancedrocketrycommunity/progression/classic/ClassicInventoryAdvancements.java'], cwd=R).decode()
        suffixes = re.findall(r'^\s*[A-Z_]+\("([a-z_]+)"', source, re.MULTILINE)
        self.assertEqual(P['goal_ids'], ['advancedrocketrycommunity:classic/' + s for s in suffixes])
        for target in P['item_counts_order'][:-1]:
            self.assertIn('"' + target + '"', source)
        self.assertEqual(len(P['item_counts_order']), 10)
        self.assertEqual(len(set(P['item_counts_order'])), 10)

    def test_identity_names_and_same_loaded_chunk(self):
        for ident in P['fixed_identities']:
            self.assertEqual(str(uuid.UUID(ident['uuid'])), ident['uuid'])
            self.assertTrue(ident['name'].isascii())
            self.assertLessEqual(len(ident['name']), 16)
            x, y, z = ident['position']
            self.assertEqual((int(x) // 16, int(z) // 16), (0, 0))
            self.assertEqual(y, 200)
        self.assertEqual(len(set(i['uuid'] for i in P['fixed_identities'])), 2)

    def test_each_of_eight_offline_records_refuses_before_construction(self):
        for index in range(8):
            with self.subTest(path=paths()[index]):
                state = self.state(); state['files'][index] = True
                before = copy.deepcopy(state)
                self.assertEqual(seed_model(state), {'admitted': False, 'constructed': 0, 'joins': 0})
                self.assertEqual(state, before)

    def test_free_first_colliding_second_not_partially_joined(self):
        state = self.state(); state['files'][4] = True
        self.assertEqual(seed_model(state)['constructed'], 0)
        self.assertEqual(seed_model(state)['joins'], 0)

    def test_cached_uuid_and_casefolded_names_even_if_expired(self):
        for ident in P['fixed_identities']:
            for entry in [{'uuid': ident['uuid'], 'name': 'OtherName', 'expired': True},
                          {'uuid': str(uuid.UUID(int=3)), 'name': ident['name'].swapcase(), 'expired': True}]:
                with self.subTest(role=ident['role'], entry=entry):
                    state = self.state(); state['profiles'].append(entry)
                    before = copy.deepcopy(state)
                    self.assertFalse(seed_model(state)['admitted'])
                    self.assertEqual(state, before)

    def test_temporary_online_or_orphan_native_caches_refuse(self):
        for key, value in [('temporary', True), ('online', True), ('requests', 1),
                           ('progress_caches', [1, 0]), ('progress_caches', [0, 1])]:
            with self.subTest(key=key, value=value):
                state = self.state(); state[key] = value
                self.assertEqual(seed_model(state)['constructed'], 0)

    def test_map_save_limit_reserves_two_seed_entries(self):
        state = self.state()
        state['profiles'] = [{'uuid': str(uuid.UUID(int=i + 10)), 'name': 'Old' + str(i)} for i in range(998)]
        self.assertTrue(seed_model(state)['admitted'])
        state['profiles'].append({'uuid': str(uuid.UUID(int=2000)), 'name': 'OneTooMany'})
        self.assertFalse(seed_model(state)['admitted'])

    def test_reload_ownership_model_rejects_each_material_mismatch(self):
        actual = {'run': 'run-a', 'world': 'D:/owned/same-copy/world',
                  'files': {p: 'digest-' + str(i) for i, p in enumerate(paths())}}
        receipt = {'schema': 1, 'phase': 'seed', **copy.deepcopy(actual)}
        self.assertTrue(receipt_model(receipt, actual))
        cases = [None, {}, {**receipt, 'schema': 2}, {**receipt, 'schema': True},
                 {**receipt, 'phase': 'reload'}, {**receipt, 'run': 'run-b'},
                 {**receipt, 'world': 'D:/different/same-basename/world'},
                 {**receipt, 'extra': 'field'}]
        missing = copy.deepcopy(receipt); missing['files'].pop(paths()[0]); cases.append(missing)
        changed = copy.deepcopy(receipt); changed['files'][paths()[0]] = 'other'; cases.append(changed)
        for case in cases:
            with self.subTest(case=case):
                self.assertFalse(receipt_model(case, actual))

    def test_duplicate_json_not_collapsed_and_future_schema_not_coerced(self):
        with self.assertRaises(ValueError):
            json.loads('{"schema":1,"schema":2}', object_pairs_hook=strict_object)
        self.assertNotEqual(type(True), type(1))

    def test_exact_phase_order_keeps_loaded_observation_before_positive(self):
        self.assertEqual(len(P['seed_events']), 12)
        self.assertEqual(len(P['reload_events']), 11)
        self.assertLess(P['reload_events'].index('LOADED'), P['reload_events'].index('REPLAY'))
        self.assertEqual(P['reload_events'].count('REPLAY'), 6)
        self.assertEqual(P['seed_events'].count('ACQUIRE'), 6)
        self.assertLess(P['seed_events'].index('REMOVED'), P['seed_events'].index('DISPOSED'))
        self.assertLess(P['seed_events'].index('DISPOSED'), P['seed_events'].index('READY_FOR_STOP'))

    def test_saved_seconds_not_false_millisecond_roundtrip(self):
        ms = 1791028800123
        text = datetime.fromtimestamp(ms / 1000, timezone.utc).strftime('%Y-%m-%d %H:%M:%S %z')
        loaded = int(datetime.strptime(text, '%Y-%m-%d %H:%M:%S %z').timestamp() * 1000)
        self.assertEqual(len(text), 25)
        self.assertEqual(loaded // 1000, ms // 1000)
        self.assertNotEqual(loaded, ms)
        self.assertNotEqual(loaded + 1, loaded)  # within-host replay still compares exact milliseconds

    def test_deadlines_are_finite_one_absolute_cohort(self):
        d = P['deadlines_seconds']
        self.assertEqual(d['copy_intake'] + d['seed_host'] + d['reload_host'] + d['final_validation'], d['cohort'])
        self.assertEqual(d['host_startup'] + d['host_action_including_cleanup'] + d['host_stop'], d['seed_host'])
        self.assertLess(d['hook_stage_checks'], d['host_action_including_cleanup'])
        start = 1000; deadline = start + d['cohort']
        observations = [start + 60, start + 170, start + 280]
        self.assertEqual([deadline - t for t in observations], [240, 130, 20])

    def test_cleanup_model_never_removes_foreign_object_and_continues_after_error(self):
        owned = [object(), object()]; foreign = object()
        attempts = []
        listed = {0: owned[0], 1: foreign}
        for i, item in enumerate(owned):
            if listed[i] is item:
                attempts.append(('remove-own', i))
            attempts.extend([('disconnect', i), ('close-release', i)])
        self.assertNotIn(('remove-own', 1), attempts)
        self.assertIn(('close-release', 0), attempts)
        self.assertIn(('close-release', 1), attempts)
        self.assertEqual(listed[1], foreign)

    def test_primary_getters_and_constructor_routes_are_not_assumed_pure(self):
        primary = json.loads((B / 'PRIMARY-01.json').read_text(encoding='utf-8'))
        cache = primary['classes']['net/minecraft/server/players/GameProfileCache.class']['selected']
        refs = [r['reference'] for k, v in cache.items() if k.startswith('get(') for r in v['references']]
        self.assertTrue(any('lookupGameProfile' in r for r in refs))
        self.assertTrue(any('setLastAccess' in r for r in refs))
        ctor = primary['classes']['net/minecraft/server/level/ServerPlayer.class']['selected']
        refs = [r['reference'] for k, v in ctor.items() if k.startswith('<init>') for r in v['references']]
        self.assertTrue(any('getPlayerStats' in r for r in refs))
        self.assertTrue(any('getPlayerAdvancements' in r for r in refs))

    def test_mapping_is_development_fact_not_runtime_claim(self):
        mapping = json.loads((B / 'MAPPING-01.json').read_text(encoding='utf-8'))
        supplement = json.loads((B / 'SUPPLEMENT-01.json').read_text(encoding='utf-8'))
        self.assertIn('packaged SRG resolution unrun', mapping['authority'])
        self.assertEqual(supplement['additional_playerlist_mapping_records'][1:],
                         ['\tadvancements f_11203_', '\tstats f_11202_'])
        self.assertEqual(P['status'], 'PROPOSED_TEST_ONLY_NOT_IMPLEMENTED')

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ProposalControls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    observation = {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                   'skipped': len(result.skipped), 'java_launches': 0, 'native_runs': 0,
                   'scope': 'proposal field/order/primary-fact controls and abstract safety models only'}
    (B / 'CONTROLS-01.json').write_text(json.dumps(observation, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(observation, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
