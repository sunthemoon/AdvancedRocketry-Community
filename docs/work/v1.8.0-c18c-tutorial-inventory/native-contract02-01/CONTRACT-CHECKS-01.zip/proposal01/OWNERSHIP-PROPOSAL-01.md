# C18 inventory native fixture: phase ownership amendment proposal 01

Date: 2026-10-04. Status: PROPOSED; author is a delegated worker. This is a
test-fixture contract proposal, not implementation, adoption, a native result,
or a change to advancement/gameplay authority. Root must version the contract
and obtain independent review before assigning source writes.

## 1. Findings and evidence boundary

1. The unchanged old draft has independent Medium M1: being offline and having
   six fresh tutorial criteria does not establish ownership of existing UUID
   playerdata/advancement/stats records. Do not implement that draft unchanged.
2. Preflight must precede **ServerPlayer construction**, not merely join.
   The pinned constructor references `PlayerList.getPlayerStats` at offset 224
   and `getPlayerAdvancements` at 236. Construction can read/create cached
   native progress before `placeNewPlayer`, whose profile-cache add/load are
   at offsets 55/69. This proposal separates observation from creation.
3. Public profile-cache `get(name)` can perform repository lookup, expire/remove
   entries and save; `get(UUID)` changes last-access/operation count on a hit.
   Neither is an admissible read-only collision check. Disk usercache JSON does
   not prove live memory absence. The proposed read-only inspection below needs
   explicit technical adoption and packaged mapping tests.
4. `ConnectedTestPlayers.join` hides the Connection/EmbeddedChannel. Native
   `PlayerList.remove` saves and unregisters; it is not channel disposal. A new
   local handle is required, including partial construction/join failure.
5. PlayerList has private UUID `stats`/`advancements` caches, initialized by
   `Maps.newHashMap`; constructor/getters can populate them. Zero online
   players alone does not exclude an orphan constructed player. Section 4
   proposes an additional read-only key inspection, not implied authorization
   from the profile-cache permission. If not adopted, the source contract must
   freeze and substantiate a stricter no-other-construction host boundary.

Source identity: committed `a5abc34809891d6b10724ee60ab9b5e97f036bae`.
The separately pinned old draft SHA is
`5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a`.
Its unchanged independent report SHA is
`3cab6768b1ae36d2a228cf5921abdf9df2ef57a5ad43a5da2223ea7f2aa7521d`,
at `D:/GitHub/ARCE-Task-Evidence/v1.8.0/atnc-b8773371d9/REVIEW-01.md`.
The old finding is a source-backed counterexample, not an observed overwrite.
Exact facts and identities: [input pins](INPUTS-01.json),
[native declaration/reference facts](PRIMARY-01.json),
[development mappings](MAPPING-01.json), [additional facts](SUPPLEMENT-01.json).
No official class bodies, JARs or full mapping files are redistributed.

## 2. Fixed surface and six unchanged targets

Two literal actions only: `arce classic-inventory release-test seed` and
`arce classic-inventory release-test reload`. No identity, item, position,
dimension, path, progress or receipt arguments. Both opt-ins must be true:
`advancedrocketrycommunity.releaseTestHooks` and
`advancedrocketrycommunity.classicInventoryFixture`. Require permission 4,
source entity null, source text name exactly `Server`, actual server thread,
ordinary dedicated-server overworld and no currently connected players.
Rcon/player/command-block invocation is not eligible. Disabled in normal play.

Fixed identity table (proposal-only test identities; not gameplay IDs):

| Role | UUID | ASCII name | Overworld position |
|---|---|---|---|
| earned | `180c1800-0000-4000-8000-000000000001` | `ArceC18Owned` | `(8.5,200,8.5)` |
| control | `180c1800-0000-4000-8000-000000000002` | `ArceC18Control` | `(10.5,200,8.5)` |

Names are at most 16 code units. Never assume these identities are globally
unused: every phase checks collisions. Both locations share chunk `(0,0)`;
require `getChunkNow(0,0)` non-null and the four foot/head cells already air.
Hook never loads a chunk or changes terrain. Driver may issue the literal
`forceload add 8 8` only in the admitted disposable copy, before the action.
No loaded-predicate observation is called an unload/lifecycle proof.

Freeze goal order `root, block_press, rolling, electrolysis, suited_up, warp_core`
under `advancedrocketrycommunity:classic/`; criterion exactly `has_inventory`.
Targets are crafting_table, small_plate_press, rolling_machine, electrolyzer,
the four distinct built-in suit pieces together, and warp_core respectively.
Every target stack has count 1 and no metadata. The unrelated control is one
`minecraft:cobblestone`. Parents/display/rewards are not changed; generated
definitions must still use the real inventory trigger and empty rewards.
The suit remains a **same current inventory** conjunction, not history.

Additional fixed launch properties: `.classicInventoryFixture.phase=seed|reload`
and `.classicInventoryFixture.runId=<canonical lower-case UUID>` below the
`advancedrocketrycommunity` prefix. Reload additionally requires
`.classicInventoryFixture.receiptSha256=<64 lower-case hex>`; seed rejects that
property. Both hosts use `-Duser.timezone=UTC`, not a global timezone change.
No property selects a file/path/name/position. Phase/action disagreement refuses.
The future executed source commit/JAR must include the independently reviewed
new fixture. `a5abc348...` is this proposal's source basis, not a claim that its
unmodified JAR already implements these commands. Marker/receipt source_commit
binds the future actual tested committed cohort, not automatically the basis.

## 3. Driver-owned disposable-copy and external receipt

The Python driver has no positional/path command arguments. A Root-authored,
sealed `cohort-inputs.json` in its owned D run directory selects the **named**
source-server/artifact/library manifest, fixed source commit and output parent.
These inputs are hash-checked, not recursively discovered from arbitrary Temp.
Copy-only validation rejects overlap with the source server/world, repository,
sealed evidence and other-owned paths, symlink/reparse redirection and existing
output. Actual run root is a fresh child under
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/`; all process temp is inside that child.
No original/source world write or player-file deletion/reset is permitted.
No extra mods, earlier fixture commands or external player login are allowed;
copy-only server configuration binds localhost, offline mode, whitelist enabled
with an empty disposable whitelist and no fixture UUID/name in ops/bans.
These are test-host restrictions, not original-server configuration changes.
The driver inspects only the fixed local ops/banned-players/whitelist JSON files
under the same 262,144-byte/depth8/16,384-node/1,000-entry ceiling as usercache.
It may create an absent empty disposable whitelist, never reset an existing
nonempty one. Identity collisions refuse; none of these records grants ownership.

Before boot the driver creates with CREATE_NEW semantics the fixed file
`<server>/.classic-inventory-fixture/run-owner-v1.json`. It contains only schema 1,
canonical run UUID, canonical real server/world paths, source commit,
main-JAR/library manifest hashes, source-world manifest hash and exact two
identities. No gameplay root/award/progress is written. Its SHA is preserved
externally. Java reads only this fixed path under `server.getServerDirectory`;
world path is independently derived using `server.getWorldPath(LevelResource.ROOT)`.
Canonical path/run/artifact binding must agree; equal basenames are insufficient.

Only after a complete seed action, explicit disposal, verified clean process
stop and bounded inspection of actual native files does the **driver** create
`<server>/.classic-inventory-fixture/ownership-v1.json`, once. It contains schema 1,
the exact run marker SHA/binding, phase `seed`, clean-exit 0, seed report digest,
and native record manifest for both identities. A hook must never author/update
this receipt. It gives only permission to use these test-owned identities in
this same copy; it cannot supply/repair/reconstruct/award loaded progress.

Receipt records exactly eight fixed player paths (four per UUID), in table-role
order and within each role dat, dat_old, advancement, stats order:
`playerdata/<UUID>.dat`, `playerdata/<UUID>.dat_old`,
`advancements/<UUID>.json`, `stats/<UUID>.json`, all under the independently
derived world directory. For each: relative path, presence Boolean; bytes/hash
only if present. `.dat`, advancement JSON and stats JSON are required after seed;
native backup presence is recorded, not invented. Also require actual local
`usercache.json` presence/bytes/hash and the two unique profile tuples after
clean stop. Record six saved criterion strings plus parsed epoch seconds per
earned player and six nulls for the control, and empty inventory/experience
observations. These observations are comparisons, never replacement input.

Reload validates receipt hash against the launch property, marker and same
real paths, complete fixed identities/path set, actual current record hashes,
native typed shape/UUID/empty inventory, local cache tuples and saved criterion
state **before constructor/join**. A missing, partial, future, malformed,
wrong-world/run/identity/artifact/digest receipt or changed record refuses.
Never adopt plausible six-goal JSON as ownership, reuse an aborted copy,
overwrite a receipt, or turn a pre-stop hook label into clean-stop evidence.

Trust boundary: this is an owned isolated test run with a trusted driver/admin,
not cryptographic protection against an administrator copying/forging the whole
server, path, receipt and launch inputs. Do not claim a secret token or persistent
world gameplay identity. Other vanilla world files may change normally in the
copy; source-world and pinned artifacts remain byte-exact.

## 4. Dual non-mutating admission before any constructor

Validate authority/phase, fixed loaded area, marker/receipt and **both identities**
before creating even one ServerPlayer, Connection or EmbeddedChannel.

First seed rejects any existing fixed dat/backup/advancement/stats path, including
nonregular/dangling/reparse entries, any native temp whose filename starts with
the exact UUID and ends with `.dat`, and any online UUID/name
collision. Iterate only the three direct player-record directories, with a
1,024-entry cap each; exceeding the cap refuses, not a partial scan. Require the
whole connected player list empty. Read-only public `getPlayers/getPlayer(UUID)`
may validate native list/map consistency; never construct an observer player.

Proposed test-only READ-ONLY introspection on the actual native cache instance:

| Declaring class | Mapped field | SRG field | Descriptor |
|---|---|---|---|
| GameProfileCache | profilesByName | f_10966_ | java.util.Map |
| GameProfileCache | profilesByUUID | f_10967_ | java.util.Map |
| GameProfileCache | requests | f_143957_ | java.util.Map |
| GameProfileCache | file | f_10970_ | java.io.File |
| GameProfileCache.GameProfileInfo | profile | f_11018_ | com.mojang.authlib.GameProfile |
| PlayerList | stats | f_11202_ | java.util.Map |
| PlayerList | advancements | f_11203_ | java.util.Map |

Root explicitly authorized proposing profile-cache inspection and subsequently
the two PlayerList caches, all read-only and test-only. These remain **technical proposals**, not
accepted contract or authorized implementation. Later tests may inspect native
operationCount (`f_10971_`, AtomicLong) and entry lastAccess (`f_11020_`, long)
read-only to establish refusal nonmutation; they confer no admission authority.
No Field.set, cache get/getAsync/add/load/save, private mutator, AT/coremod,
network/profile repository lookup or class body copying. Resolve exactly one
mapped/SRG field per row on the named declaring class, exact descriptor/modifiers;
inaccessible, ambiguous or unexpected state refuses. `trySetAccessible` changes
only local reflection metadata. Runtime mapping still requires packaged proof.

Check maps' actual standard native classes before traversal: profile maps are
ConcurrentHashMap (source creates via Maps.newConcurrentMap), PlayerList maps
HashMap (source creates via Maps.newHashMap). Reject foreign map/entry/profile
classes instead of calling arbitrary implementations. Snapshot at most 1,000
entries per profile map, with consistent lowercase Locale.ROOT name keys/UUID
keys and exact native GameProfileInfo/GameProfile types. Count/iterator overflow,
null/invalid UUID/name, unexpected map key/value type or missing counterpart in
the other map refuses rather than skipping an entry. Verify native cache
`file` resolves to the fixed admitted server-root `usercache.json`, with no
reparse path or alternate selected cache. Reject any seed UUID
or case-folded name collision, **including expired entries**; do not evict them.
Require empty requests and, if the additional boundary is adopted, empty
PlayerList stats/advancements maps in each newly started host. Capture twice
on the server thread; changes or inconsistent two-map membership refuse.
No stale observation is refreshed after creation. Seed allows at most 998
unrelated cached profiles, leaving room for two within native 1,000-save bound.
Reload allows at most 1,000 and requires its two receipt-owned profiles exactly;
any UUID/name cross-collision refuses. Do not modify unrelated entries.

Profile operation-count/entry MRU mutation must remain absent on refusal, proven
by future targeted tests. Reflection is not generalized gameplay behavior.
If the two additional PlayerList fields are not adopted, leave source blocked
until an independently reviewed alternative proves orphan cache absence; disk
JSON/zero online players alone cannot be substituted. This is not an owner
gameplay choice, but a concrete technical freeze dependency.

## 5. Seed, loaded-state and replay protocol

After dual admission, locally hold two owned handles with references assigned
immediately as each stage succeeds: GameProfile, player, Connection, channel,
listing status. Standard non-FakePlayer ServerPlayers; nonoperator permissions;
creative mode only after admitted join, placement only in the checked loaded
area. No adopting a PlayerList entry or mutable static collection. A one-action
synchronous command needs no long-lived global keepalive/tick service.

Seed sequence: inspect both fresh native criteria and empty inventories before
mutation; put one cobblestone in control using inventory.setItem plus normal
inventoryMenu.broadcastChanges; inspect both. For each frozen goal, clear earned
inventory via its ordinary listener, put that goal's 1/4 exact stacks, broadcast,
and report both players. Current goal must be done; earlier earned receipts stay
unchanged; later goals remain fresh; control remains entirely fresh. Target
counts are unchanged and totalExperience matches the admitted value. No direct
award/grant/CriteriaTriggers call, custom progression store or reward simulation.
Other vanilla/recipe progress may react normally and is not reset/prohibited.

Reload sequence: after complete disk/receipt preflight, join both with empty
saved inventories, then inspect **loaded progress before any positive inventory
mutation**. Six earned criteria must match seed saved seconds; six control
criteria remain fresh. Only then replay each goal through the ordinary listener,
checking exact within-host obtained Date milliseconds unchanged across replay,
target counts/experience invariant and control independent. The receipt is not
used to load/reset/grant progress if vanilla load fails.

At successful action end remove all targets/control through ordinary inventory
changes, report empty inventories and unchanged criteria/experience, and clean
up both owned handles. Native saved JSON dates use `yyyy-MM-dd HH:mm:ss Z`;
driver compares exact UTC saved strings and parsed seconds across hosts, not
pre-save milliseconds. Within-host comparisons remain exact milliseconds.
First and final stopped earned strings must agree, control still has none.
Empty tutorial rewards are checked from pinned packaged definitions as well as
actual target counts/experience; unrelated recipe unlocks are not tutorial loot.

## 6. Partial joins and disposal are not rollback

Use try/finally covering construction onward. For each handle separately, attempt
all applicable cleanup even if an earlier cleanup fails; aggregate errors and
make the action fail. If a player is listed, remove it only when the native
UUID map/list refer to that **same object**. Never remove a foreign object by
UUID/name. A partially unlisted constructed player's listeners must be stopped;
if it reached the Level but not the list, dispose that exact owned entity only.
Do not call PlayerList.remove blindly when a join did not reach listing.

Explicitly disconnect the owned Connection, close the owned EmbeddedChannel,
finishAndReleaseAll, and inspect closed/inactive/not-connected state plus no
owned listed player. Drain/release any received/outbound ReferenceCounted object
with a fixed 2,048-message-per-channel cap. Reaching the cap fails and still
attempts channel close/release; report it rather than pretending complete drain.
Never treat finishAndReleaseAll's Boolean as a universal success flag.
Selected disposal Netty API/runtime ordering must be compiled and separately
tested; current facts establish necessity, not execution.

Native remove/save may mutate the admitted owned copy, profile/stat caches and
files even if later failure occurs. There is **no rollback promise** for an
admitted failing action or partial constructor. Preserve its original inputs,
raw failure and partial files; stop that host, emit no ownership receipt and
do not reuse the copy. A refusal before construction must leave player records,
native maps and connection count unchanged; reporting is the only allowed effect.
Save/load failures may be caught/logged by vanilla, so successful cleanup/action
label/exit alone never substitutes for stopped-file inspection.

## 7. Exact report and parser surface

Authoritative hook logger name `ARCE_C18_INVENTORY`, INFO, server thread only;
message starts `ARCE_C18_INVENTORY ` followed by one compact strict JSON object.
Future packaged logger abbreviation must be pinned by exact field/header tests,
not accepted by substring or any-log severity. Wrong logger/thread/severity,
duplicate/out-of-order/unknown fields or phase/run mismatch is a failure.

Every row has exactly schema=1, run_id, phase, event, index, payload. Events:

- seed indices 0..11: PREFLIGHT, INITIAL, CONTROL, ACQUIRE x6, REMOVED,
  DISPOSED, READY_FOR_STOP.
- reload indices 0..10: PREFLIGHT, LOADED, REPLAY x6, REMOVED, DISPOSED,
  READY_FOR_STOP.
- FAILED abort row may replace the next index; never coexist with successful
  completion or certify persistence. Extra/duplicate rows fail the driver.

Payload schemas are fixed in [PROTOCOL-01.json](PROTOCOL-01.json).
Player rows always contain both role-ordered states: UUID/name/listed,
10 item counts (nine exact target IDs plus cobblestone), other_nonempty_slots,
totalExperience, six Boolean done values, six nullable obtained_ms/seconds and
six criterion-key arrays. Only `has_inventory` is eligible; require matching
criterion shape, no unknown tutorial criteria. Nulls mean actually unearned,
not parse failure. REMOVED still observes live players before disposal.
PREFLIGHT has no fabricated player/progress state, only admission observations.
DISPOSED has the two actual resource/lifecycle observations, not inventory data.
READY_FOR_STOP means action completion only, not native PASS. All23 successful
rows together have a fixed 393,216-byte cap; one row at most16,384 UTF-8 bytes.

## 8. Fixed bounds, clocks and independent stopped-file oracles

The bounds below are proposed **test-fixture admission**, not new gameplay NBT
or global parser policy. All readers enforce byte budgets before allocations,
iterative depth/node/count checks, duplicate/type/extra-field rejection, no
symlink/reparse traversal. Numeric values have exact types/ranges, no coercion.

| Input | Byte limit | Depth | Node/count limit |
|---|---:|---:|---|
| run marker, ownership receipt, cohort-inputs each | 16,384 | 12 | 2,048 nodes; fixed fields/path set |
| report row | 16,384 | 8 | 2,048 nodes; 23 success rows/cohort |
| native dat/dat_old | 262,144 compressed; 1,048,576 decompressed | 32 | 65,536 NBT nodes; named Compound root |
| advancements JSON per UUID | 262,144 | 16 | 32,768 nodes; <=2,048 advancement IDs |
| stats JSON per UUID | 131,072 | 16 | 16,384 nodes; <=2,048 stat entries |
| usercache JSON | 262,144 | 8 | 16,384 nodes; <=1,000 profiles |
| direct player directories | not content-scanned generally | 1 | <=1,024 entries each |
| native profile maps | no serialized allocation | 1 | <=1,000 each; requests empty |
| channel messages drained | object count only | n/a | <=2,048 each; max two channels |

Bounded dat reader consumes exactly one gzip member/no trailing bytes, scans
native NBT lengths/types/names before unbounded native decoding, and rejects
negative/truncated/over-budget arrays/lists/strings or duplicate compound keys.
Validate root UUID as native IntArray length4 matching the fixed UUID and typed
Inventory List length0 (native emitted empty subtype0); all41 live inventory
cells must also be empty at REMOVED/load. Other valid native player fields are
preserved/read, not normalized. No arbitrary NbtIo.readCompressed allocation
before the bounded byte/shape gate. Fixed native .dat_old, if present, is
inspected under the same budget and checked as an owned backup, not used to
repair the current record. Native format/fixtures still need actual tests.

The deliberate empty Inventory admission is **named List tag ID9, element
subtype0, signed count0**, not any typed-empty list. It is derived independently
from vanilla [native inventory facts](NATIVE-INVENTORY-02.json): Player saves a
new ListTag through Inventory.save; all three inventory partitions skip empty
stacks; the zero-argument ListTag constructor delegates with type0; write checks
empty at offset4 and sets type0 at14 before writing type/count. The native
partitions are36/4/1. This is source/bytecode evidence, not an executed writer
or a policy borrowed from shared hatch codecs. Any other type/count refuses
this fixture's empty-input oracle instead of being silently normalized.

Advancement JSON is parsed strictly; all six IDs have only the declared tutorial
criterion and consistent done/timestamp semantics. Control may omit those IDs
or carry an actually unearned entry, but no obtained criterion. Unrelated
vanilla advancement IDs are bounded and preserved. Stats/other cache entry
changes caused by ordinary login/logout are distinguished from tutorial rewards.
Driver reads actual stopped files independently and preserves their hashes plus
compact typed observations; no hook-supplied summary replaces the files.

One absolute monotonic cohort deadline = **300 seconds**, never reset on polls:
copy/intake <=60; seed host <=110; reload host <=110; final stopped validation
<=20. Each host has startup <=60, action including cleanup <=20, clean stop <=30;
remaining subphase time is min(its bound, cohort remaining). Hook checks its
10-second internal operation deadline between bounded stages, never treats it
as interruptible native-call/preemptive Java guarantee. Driver's action deadline
includes finally/command processing. At any timeout preserve failure and stop
only its started process; no deadline increase, retry-as-success or lost-log
substitution. Poll interval at most0.2 seconds; exactly one action per host.
Clean native stop is explicit literal `stop`, process exit0 plus raw shutdown
completion and absence of player save/load/fixture errors. Unknown ERROR/FATAL
messages also fail; no generic tolerance list is authorized by this proposal.
Actual
records/resource/time comparisons remain required even after clean exit.

## 9. Proposed implementation responsibilities and evidence obligations

Future writes require a new Root source task; none are granted by this document.
Keep four current-version test-only classes, not one giant hook/framework:

1. `ClassicInventoryAdvancementNativeFixture`: two literal command actions,
   local phase/report coordination and inventory listener observations (~300 lines).
2. `ClassicInventoryFixturePlayers`: owned handle/partial join/disposal (~200).
3. `ClassicInventoryFixtureOwnership`: fixed path/marker/receipt/cache admission
   (~300; read-only introspection only after technical adoption).
4. `ClassicInventoryFixtureRecords`: bounded native/JSON readers and immutable
   observational records (~300; no writers/award/repair authority).
5. New copy-only Python driver and focused tests; narrowly scoped new Java
   tests. Root owns central event registration. Existing six tutorial sources,
   ConnectedTestPlayers/ReleaseTestPlayers and production save paths stay unchanged.

Required tests are evidence obligations, not a requested result:
all eight first-seed native-file collisions, native temporary prefix, both
online/name/UUID cache collisions (including expired), free-first/colliding-second,
orphan native progress cache, wrong phase/authority/loaded area; failed preflight
must perform zero constructors/joins/cache writes/network operations.
Receipt absence/partial/future/duplicates/wrong-world/run/identity/artifact/hash/
file set/native types/nonempty inventory must refuse before construction.
Partial construction/channel/join/listing/teleport/final disposal failures must
attempt cleanup only on owned resources and prevent completion/receipt creation.
Strict framing/limits/deadline failures, no direct award or trigger, live native
listener, loaded-progress-before-acquisition, replay milliseconds, stopped native
timestamps/UUID/empty inventory and real generated empty rewards all need tests.

Independent source review and scoped/registered tests must precede committed
packaged two-host evidence. Native execution must pin actual main JAR/libraries,
both process commands/time/exits/raw logs, observed reports and actual stopped
native files, driver receipt and source/artifact pre/postchecks. The connected
mock is not a real client, V1/V2/GPU proof or public multiplayer compatibility.
No original-player migration, crash atomicity, R-021/save-policy resolution or
whole-v1.8 Required Gate closure follows from this slice.

## 10. Decisions and unrun limits

- Required technical disposition: adopt or replace the bounded read-only cache
  inspection, including **additional PlayerList cache fields**, exact reflection
  descriptor/mapping fail-closed handling and local class assumptions. Root has
  authorized only preparing the proposal; no reflective source is admitted.
- Runtime unknowns: packaged SRG field resolution/security access; precise
  native/Netty partial-join cleanup; actual control-player file creation and
  native record framing; all proposed deadlines on a real owned test host.
  Unrepresentable inputs refuse; no alternative field guessing/normalization.
- The isolated trusted-driver boundary is not protection against concurrent
  administrators/mods editing files/maps; pending cache requests and changing
  snapshots refuse. Actual production interoperability is outside scope.
- No new owner gameplay choice is requested: acquisition/reward/tree behavior
  remains frozen. Root chooses technical task authority and independent review.
- All old failure evidence/draft findings remain immutable. This author's
  bounded Python specification checks, if passing, are not Java/native proof.

Actual commands and final pins will be in [CHECKPOINT-01.md](CHECKPOINT-01.md)
and the sealed internal manifest. This proposal contains no source implementation.
