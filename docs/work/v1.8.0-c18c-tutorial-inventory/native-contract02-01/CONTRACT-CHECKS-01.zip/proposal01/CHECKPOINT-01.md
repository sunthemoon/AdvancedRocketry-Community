# C18 native ownership proposal handoff

Date: 2026-10-04. Scope: delegated technical proposal only, against fixed
committed `a5abc34809891d6b10724ee60ab9b5e97f036bae`. Root owns contract adoption,
implementation permissions, source/status and all commits. No acceptance is
claimed by the proposal author.

## Findings / proposed correction

The old unchanged draft's independently observed Medium M1 remains historical:
offline/fresh-criterion state alone does not establish UUID-record ownership.
[Proposal](OWNERSHIP-PROPOSAL-01.md) sections 3-6 specify dual pre-constructor
absence/collision admission, driver-authored first-clean-stop external receipt,
same-copy exact record binding, loaded native progress before replay, and local
partial join/Connection/EmbeddedChannel cleanup without rollback claims.
[Fixed field protocol](PROTOCOL-01.json) separates observational progress from
test-identity permission; the receipt is never a progression writer/input.

Additional actual source facts matter: ServerPlayer construction requests
native stats/advancements before join; public GameProfileCache get methods are
not non-mutating absence checks; PlayerList.remove saves but does not release
the created channel. Root expressly permits proposing bounded read-only native
profile-cache and PlayerList UUID-cache inspection, with exact mapped/SRG
members. This permission is **not adopted implementation or reflection policy**.

Remaining technical freeze/execution conditions: independent review of exact
field/path/schema/deadline/collision/disposal requirements; packaged member
resolution and native class assumptions; actual bounded record readers; real
inventory listeners and two clean host native file observations. No gameplay
choice is requested and no original records may be reset/adopted. No new
fixture source, native run, resource writer, public API, owner policy, version
status, ledger or Gate was changed. Six committed advancement files stay intact.

## Actual commands and results

All writes are this fresh small external directory, with process-local
TEMP/TMP/TMPDIR at its `process-temp` child and Python `-B`. No C output, global
environment change, live-world read, Java/Gradle/server/client/network/dependency
installation, Git mutation/deletion or private Development-Docs access occurred.

| Actual bounded check | Observed result | Evidence |
|---|---|---|
| Fixed named Git objects / old proposal and review / live AGENTS read | 30 initial input pins; old two SHA identities exact | [inputs](INPUTS-01.json) |
| `python -B intake01.py` | exit 0, seven selected primary classes, zero Java | [raw](intake-01.log), [exit](intake-01.exit), [reader](intake01.py) |
| `python -B mapping01.py` | exit 0; only cache/member development mapping declarations retained | [raw](mapping-01.log), [exit](mapping-01.exit), [mapping](MAPPING-01.json), [reader](mapping01.py) |
| `python -B supplement01.py` | exit 0; three primary class reads (one overlaps); two PlayerList mappings and exact release-hook property | [raw](supplement-01.log), [exit](supplement-01.exit), [facts](SUPPLEMENT-01.json), [reader](supplement01.py) |
| `python -B controls01.py` | 16 specification controls, 0 failures/errors/skips, exit 0 | [raw](controls-01.log), [exit](controls-01.exit), [result](CONTROLS-01.json), [controls](controls01.py) |
| `python -B final_check01.py` | exit 0; all 32 distinct named inputs unchanged; field/order/finite budget consistency; one native 1,000-profile save-limit argument fact | [raw](final-check-01.log), [exit](final-check-01.exit), [result](FINAL-INPUT-CHECK-01.json), [check](final_check01.py) |
| `python -B inventory_primary01.py` | exit 1, StopIteration: first inspector incorrectly searched the delegating no-arg constructor for the field store; no native run | [raw](inventory-primary-01.log), [exit](inventory-primary-01.exit), [original](inventory_primary01.py) |
| `python -B inventory_primary02.py` | exit 0; actual delegated constructor/native Inventory.save/ListTag.write route pins exact empty subtype0/count0 and36/4/1 live partitions | [raw](inventory-primary-02.log), [exit](inventory-primary-02.exit), [facts](NATIVE-INVENTORY-02.json), [corrected inspector](inventory_primary02.py) |
| `python -B field_check02.py` | two additional field/native-shape specification controls, 0 failures/errors/skips; local companions all present; exit 0 | [raw](field-check-02.log), [exit](field-check-02.exit), [result](FIELD-CHECK-02.json), [controls](field_check02.py) |

The 16 controls are **Python specification/abstract safety models**, not tested
fixture code, native cache admission, disposal, saved player files or restart
proof. Their cases cover eight offline paths, both-identities-before-construction,
expired UUID/case-folded name collisions, orphan caches, external binding,
phase order, timestamp precision and fixed deadline arithmetic. Counts are
observations, not a prefilled independent verdict.

## Preserved read-only locator failures

These preceding exploration errors did not modify source or execute a fixture:

- `git show a5abc348...:docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-01.md`
  reported that the path exists on disk but is not in the commit. The proposal
  therefore pins the exact individually frozen old draft, not a fabricated Git
  object identity. The enclosing combined read continued with later successes.
- A guessed `gametest/PumpReleaseTestCommands.java` Git locator did not exist;
  the correct pinned path is `machine/pump/PumpReleaseTestCommands.java`.
- A later guessed `endgame/command/ReleaseTestCommands.java` did not exist;
  the enclosing tool returned exit 1. The actual pinned property source is
  `satellite/command/ReleaseTestCommands.java` in SUPPLEMENT-01.
- Named rg included an absent `src/main/java/.../command` directory and emitted
  a read error; the combined later Get-Content call returned 0. The matching
  endgame reads were not mistaken for the property declaration.

These are transcribed actual tool observations, **not separate stored raw
stderr receipts**, and are not source/Java/native failures. Later explicit
Python receipts above are preserved raw; no failure was relabeled native PASS.
One own-document multi-file apply_patch was rejected for a mismatched later
hunk before any writes; exact targeted hunks were then applied successfully.
That tooling correction is not a native/test defect or a repository edit.

## Pins, ownership and limitations

Exact full provenance is [INPUTS-01.json](INPUTS-01.json) plus
[SUPPLEMENT-01.json](SUPPLEMENT-01.json) and [final postcheck](FINAL-INPUT-CHECK-01.json).
Primary configured mapped Forge 47.4.10 JAR SHA is
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Development mapping input SHA is
`246dc9d32f075e71167debb9b4ad1bb75be6a0a8584c08c5c06cc6b7b73d5d15`.
These do not independently measure any native process runtime classpath or
prove packaged SRG reflection resolution. Only declarations/selected semantic
reference facts are retained, not official bodies/JAR/mapping copies.

This handoff preserves the old draft/report/counterexample identities without
rewriting them. Root source build/GameTests or separate Guard native results
are not this proposal's evidence. No V1/V2/real client, natural legacy-player
migration, crash atomicity, R-021 admission or whole-v1.8 Required Gate conclusion
is made. Proposed future write scope/responsibilities and verification obligations
are in proposal section 9; source implementation requires a different assignment.

No ZIP/full-source export is needed; the small loose internal manifest and
SHA256SUMS seal only this owned evidence. The final sealer also checks all local
companion links and actual field/report count consistency after this checkpoint.
