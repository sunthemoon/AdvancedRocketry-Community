"""Final proposal companion/native-shape consistency, not native execution."""
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import unittest

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
P = json.loads((B / 'PROTOCOL-01.json').read_text(encoding='utf-8'))
N = json.loads((B / 'NATIVE-INVENTORY-02.json').read_text(encoding='utf-8'))

class FinalControls(unittest.TestCase):
    def test_native_saved_empty_shape_is_explicit_not_hatch_admission(self):
        fact = N['empty_inventory_semantic_facts']['emitted_payload_shape']
        self.assertEqual(P['native_empty_inventory_shape']['element_type_byte'], fact['element_type_byte'])
        self.assertEqual(P['native_empty_inventory_shape']['signed_element_count'], fact['signed_int_element_count'])
        self.assertEqual(sum(P['native_empty_inventory_shape']['partitions']), 41)
        # This is independent Python framing arithmetic, not emitted Java/NBT bytes.
        framing = struct.pack('>BH', 9, 9) + b'Inventory' + struct.pack('>bi', 0, 0)
        self.assertEqual(len(framing), 17)
        accepts = lambda tag, subtype, count: (tag, subtype, count) == (9, 0, 0)
        self.assertTrue(accepts(9, 0, 0))
        for shape in [(9, 10, 0), (9, 1, 0), (9, 0, 1), (10, 0, 0), (9, 0, -1)]:
            self.assertFalse(accepts(*shape))

    def test_marker_receipt_records_are_not_native_uuid_ownership(self):
        text = (B / 'OWNERSHIP-PROPOSAL-01.md').read_text(encoding='utf-8')
        self.assertIn('before creating even one ServerPlayer', text)
        self.assertIn('Only after a complete seed action', text)
        self.assertIn('driver** create', text)
        self.assertIn('never reset an existing', text)
        self.assertNotEqual(set(P['external_marker_fields']), set(P['external_receipt_fields']))
        self.assertIn('nativeprogresswritefromreceipt', P['forbidden_authorities'])
        self.assertEqual(P['external_receipt_fields']['phase'], 'seed')

if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FinalControls))
    links = []
    for path in B.glob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if ':' in target or target.startswith('#'):
                continue
            links.append({'file': path.name, 'target': target, 'exists': (B / target.split('#')[0]).is_file()})
    observation = {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                   'skipped': len(result.skipped), 'local_links': links,
                   'missing_links': [link for link in links if not link['exists']],
                   'java_launches': 0, 'native_runs': 0,
                   'proposal_sha256': hashlib.sha256((B / 'OWNERSHIP-PROPOSAL-01.md').read_bytes()).hexdigest(),
                   'protocol_sha256': hashlib.sha256((B / 'PROTOCOL-01.json').read_bytes()).hexdigest(),
                   'scope': 'proposed exact native empty shape and marker/receipt field separation'}
    (B / 'FIELD-CHECK-02.json').write_text(json.dumps(observation, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in observation.items() if k != 'local_links'}, indent=2))
    raise SystemExit(0 if result.wasSuccessful() and not observation['missing_links'] else 1)
