"""Fixed named C18/source ownership inputs and pinned native declaration facts; no Java."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import zipfile

B=Path(__file__).resolve().parent
R=Path('D:/GitHub/AdvancedRocketry-Community')
BASE='a5abc34809891d6b10724ee60ab9b5e97f036bae'
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key]=str(B/'process-temp')
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=[]
def git(path):
    p=subprocess.run(['git','show',BASE+':'+path],cwd=R,capture_output=True)
    assert p.returncode==0,(path,p.stderr.decode(errors='replace'))
    return p.stdout
docs=['PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md',
      'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md','docs/05-MASTER-TEST-PLAN.md',
      'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/16-POST-1.0-VERSION-ROADMAP.md',
      'docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
      'docs/work/v1.8.0-c18c-tutorial-inventory/TASK.md','docs/work/v1.8.0-c18c-tutorial-inventory/REVIEW-DISPOSITION-01.md',
      'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
      'docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md']
pkg='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
sources=['gametest/ConnectedTestPlayers.java','gametest/ClassicInventoryAdvancementGameTests.java',
         'progression/classic/ClassicInventoryAdvancements.java','machine/pump/PumpReleaseTestCommands.java',
         'machine/recipe/RecipeSignatureReleaseTestCommands.java','endgame/command/ReleaseTestPlayers.java',
         'datagen/BootstrapDataGenerators.java','datagen/V180ClassicAdvancementData.java',
         'datagen/V180ClassicAdvancementLanguage.java']
texts={}
for path in docs+[pkg+p for p in sources]:
    data=git(path); texts[path]=data.decode('utf-8-sig')
    pins.append({'source':BASE+':'+path,'bytes':len(data),'sha256':sha(data)})
review=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/atnc-b8773371d9/REVIEW-01.md')
assert sha(review.read_bytes())=='3cab6768b1ae36d2a228cf5921abdf9df2ef57a5ad43a5da2223ea7f2aa7521d'
draft=review.parent/'NATIVE-TASK-01.md'
assert sha(draft.read_bytes())=='5f21c97023477d762bb317d56c43083756abf8d3f790bb5601090806f844a02a'
for path in (review,draft,review.parent/'PRIMARY-01.json',review.parent/'OFFLINE-COLLISION-COUNTEREXAMPLE-01.json',R/'AGENTS.md'):
    data=path.read_bytes(); pins.append({'source':str(path),'bytes':len(data),'sha256':sha(data)})
(B/'OLD-DRAFT-01.md').write_bytes(draft.read_bytes())
parser=Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
data=parser.read_bytes(); pins.append({'source':str(parser),'bytes':len(data),'sha256':sha(data)})
nodes=[n for n in ast.parse(data).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('R','parse')]
ns={'struct':struct}; exec(compile(ast.Module(body=nodes,type_ignores=[]),str(parser),'exec'),ns)
jar=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
         '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert sha(jar.read_bytes())=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
pins.append({'source':str(jar),'bytes':jar.stat().st_size,'sha256':sha(jar.read_bytes())})
requests={
 'net/minecraft/server/players/GameProfileCache.class':{'get','load','save','<init>','getTopMRUProfiles'},
 'net/minecraft/server/players/PlayerList.class':{'getPlayer','getPlayerByName','getPlayers','placeNewPlayer','remove'},
 'net/minecraft/server/level/ServerPlayer.class':{'<init>','teleportTo'},
 'net/minecraft/network/Connection.class':{'disconnect','isConnected'},
 'net/minecraft/world/level/storage/LevelResource.class':set(),
 'net/minecraft/server/MinecraftServer.class':set(),
 'net/minecraft/server/players/StoredUserList.class':set(),
}
primary={'jar_sha256':sha(jar.read_bytes()),'java_launches':0,'classes':{}}
with zipfile.ZipFile(jar) as archive:
    for name,methods in requests.items():
        data=archive.read(name); parsed=ns['parse'](data,methods)
        details={}
        for method,info in parsed['selected_methods'].items():
            details[method]={'access':info['access'],'references':[
                {'offset':ins['offset'],'reference':ins['reference'],'branch_target':ins['branch_target']}
                for ins in info['instructions'] if ins['reference'] is not None]}
        primary['classes'][name]={'bytes':len(data),'sha256':sha(data),'fields':parsed['fields'],
                                 'all_methods':parsed['all_methods'],'selected':details}
(B/'PRIMARY-01.json').write_text(json.dumps(primary,indent=2)+'\n',encoding='utf-8')
out={'base':BASE,'inputs':pins,'named_count':len(pins),
     'head_observed_not_baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),
     'limits':'named Git objects/old draft/native declarations only; no world/Java/source writes'}
(B/'INPUTS-01.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'named_inputs':len(pins),'classes':len(requests),'old_draft_sha256':sha(draft.read_bytes()),
                  'review_sha256':sha(review.read_bytes()),'java_launches':0},indent=2))
cache=primary['classes']['net/minecraft/server/players/GameProfileCache.class']
print('CACHE_FIELDS',cache['fields'])
print('CACHE_METHODS',cache['all_methods'])
for name,info in cache['selected'].items():
    if name.startswith('get('): print('CACHE_GET',name,info)
