"""Pin stable named Root mapping output; retain only relevant field/method mappings."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B=Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key]=str(B/'process-temp')
sha=lambda b:hashlib.sha256(b).hexdigest()
mapping=Path('D:/GitHub/AdvancedRocketry-Community/build/createMcpToSrg/output.tsrg')
data=mapping.read_bytes()
names={'net/minecraft/server/players/GameProfileCache','net/minecraft/server/players/GameProfileCache$GameProfileInfo'}
selected={}; current=None
for line in data.decode('utf-8').splitlines():
    if not line.startswith('\t'):
        current=line.split()[0] if line.strip() else None
        if current in names: selected[current]=[line]
    elif current in names and not line.startswith('\t\t'):
        selected[current].append(line)
assert set(selected)==names,selected
jar=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/'
         '1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
reader=Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
tree=ast.parse(reader.read_bytes()); nodes=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))
                                         and n.name in ('R','parse')]
ns={'struct':struct}; exec(compile(ast.Module(body=nodes,type_ignores=[]),str(reader),'exec'),ns)
with zipfile.ZipFile(jar) as archive:
    raw=archive.read('net/minecraft/server/players/GameProfileCache$GameProfileInfo.class')
    parsed=ns['parse'](raw,{'getProfile'})
out={'mapping':{'path':str(mapping),'bytes':len(data),'sha256':sha(data)},'selected_records':selected,
     'profile_entry':{'sha256':sha(raw),'bytes':len(raw),'fields':parsed['fields'],'methods':parsed['all_methods']},
     'authority':'development-tool mapping plus pinned mapped class facts; packaged SRG resolution unrun',
     'java_launches':0}
(B/'MAPPING-01.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
assert mapping.read_bytes()==data,'mapping input drifted while reading'
print(json.dumps(out,indent=2))
