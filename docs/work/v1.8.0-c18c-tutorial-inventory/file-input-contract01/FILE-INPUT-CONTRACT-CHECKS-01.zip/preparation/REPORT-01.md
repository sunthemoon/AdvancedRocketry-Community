# C18c Task04 phase02 implementation intake

Date: 2026-10-05. Delegated read-only preparation, not implementation, contract adoption, source admission or native result review.

## Findings and assignment blockers

No new existing-runtime defect is established by this intake. The following are implementation dependencies, not retroactive findings against the deliberately partial phase01 parser.

1. **JSON accounting still needs a technical decision before JSON readers can be frozen.** `PROTOCOL-03.json` gives byte/depth/node ceilings, but does not define root depth or whether object keys consume nodes. Candidate03 `NATIVE-HANDOFF-04.md:60–68,100–105` explicitly defers this. Properties' separate `string_nodes_plus_root` rule is not a JSON rule. Two precise alternatives are below; neither is selected here.
2. **A parsed acknowledgement is not fresh console authority.** Candidate03 `run_v180_classic_inventory_smoke.py:1–6,201–208` intentionally parses only payloads. Cumulative `OWNERSHIP-PROPOSAL-01.md:281–306` requires the exact logger/thread/INFO header, run/phase/index sequence and a future packaged abbreviation pin. Existing Signature `run_v180_signature_smoke.py:55–63` frames a different MinecraftServer logger, not the proposed `ARCE_C18_INVENTORY` logger. No Java hook/header emission or two-host driver is implemented through the inspected phase01 files.
3. **Existing file/NBT utilities are patterns, not drop-in Task04 admission.** `v120_precision_world_fixture.py:48–54` checks the leaf then uses unbounded `read_bytes`; `run_v130_adapter_recovery_smoke.py:72–88` adds ancestor link/junction checks but also reads the whole file after stat. These do not implement the Task04 limit-plus-one read or establish race-free reparse/file replacement refusal. `inspect_celestial_saved_data.py:25–29,41–130` uses depth16/nodes4096, erases scalar/list subtype and uses strict UTF-8. Signature's reader preserves more tag information but has depth16/nodes4096/collection4096 and strict UTF-8 (`run_v180_signature_smoke.py:62,109–165`). Task04 player dat is gzip, depth32/nodes65536 and requires typed empty Inventory, exact integer/float widths and positive-zero bits. Do not change the existing utilities' unrelated limits to make them fit.
4. **Phase01 is not currently integrated in the observed Root checkout.** All four Task04 phase01 paths were absent at intake. The reviewed implementation here is the frozen candidate03 postimage, not committed Root delivery. New work needs an explicit committed source base after Root integration, or an explicitly labelled proposal-only base; it cannot claim that a087 already contains phase01.

These do not require a new gameplay-owner decision. They require explicit technical parser/transport/source assignment. Suitable source-host selection remains a separate unsatisfied admission requirement; this report does not choose or repair a host.

## Exact basis and actual checks

Root fact object: `a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c`. The execution reads individual pinned files; a moving future HEAD is not a retroactive source pin. The second control compared all 31 named Root inputs with that fixed object: 30 are raw-byte equal; the only difference is the separately authoritative user-maintained live AGENTS (the object has SHA-256 `725dd46344046bcdb802872e08fbc3cd9da0bf876e680eeba4c82dda801a9503`). Live AGENTS is 12,047 bytes, SHA-256 `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`. No broad normalization waiver is used.

| Input | Exact SHA-256 |
|---|---|
| Root `NATIVE-TASK-04.md` | `3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43` |
| Root `NATIVE-REVIEW-DISPOSITION-04.md` | `8d679d97de9ff04f27880ed01071b43fccc4c66e2cac89bc20540b853d9bc28d` |
| Cumulative `OWNERSHIP-PROPOSAL-03.md` | `f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca` |
| `PROTOCOL-03.json` | `fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc` |
| Candidate03 phase01 production script | `dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56` |
| Candidate03 phase01 Python tests | `4a24f52fa245b677b129e7247de554e7ac83f58b121eae7725e2b922a51cdfb7` |
| Candidate03 progress / handoff | `9918bd7b3a8ec2cc36b5610b99efeb884f4d87a1ec3f8297b3b6513a9ada8a29` / `f7378241f061caedf8df5a37c4412882e79df5d638b80bf7fc3a1b88169032c6` |

Original proposal01 is read only for unchanged cumulative rules, especially file ownership, logger and bounded dat rules. Its bytes remain separately pinned; no earlier proposal header is treated as acceptance. Task04 disposition supplies limited technical fixture authority, not a native launch grant.

[Input observations](INPUTS-01.json) bind 42 named files, including governance, version/quality/parallel rules, the four frozen postimages and named existing utilities. [Thin control](facts01.py) executed `python -B` with all three process temp variables in this own D directory: **12 controls, exit 0**, zero input drift. The first [raw log](facts-01.log) is preserved; the second [raw log with added fixed-object observations](facts-02.log) binds the final helper. See [result](FACTS-01.json) and [postcheck](POSTCHECK-01.json). These are factual/introspection and explicitly hypothetical counting models, not a production parser or native call proof. No Java, server, dependency or network command ran.

The controls reproduce two relevant reuse limitations on crafted bytes: the existing SavedData reader maps both subtype0/count0 and subtype3/count0 Inventory to the same Python `[]`; it rejects a Modified-UTF-style NUL byte sequence under its strict UTF-8 decoder. This is not independently emitted native positive-fixture provenance or a defect verdict for that older SavedData-specific utility.

Initial read-command errors (wrong version filename and guessed absent validator/restart helper filenames) are preserved in [tool observations](TOOL-OBSERVATIONS-01.md). They are locator failures, not runtime failures or passing coverage.

## Smallest independently useful phase02 leaf

**Phase02a: fixed-path, bounded read-only properties intake and absence observations**, leaving every phase01 postimage and CLI inert boundary unchanged.

Suggested private helper responsibilities, not new gameplay/public API:

- Accept a caller-owned admitted server/world root, never a path selected by decoded JSON, acknowledgement or command payload. Enumerate only fixed snapshot/properties/marker/receipt and eight player-record names from the contract. Missing, dangling, directory, nonregular or any reparse path is distinct from an admissible absent seed record.
- Before reading, validate the resolved absolute location remains within that admitted owned root and reject `..`, alternate-drive/UNC/device redirection and linked/reparse ancestors. On Windows use actual `st_file_attributes`/`FILE_ATTRIBUTE_REPARSE_POINT` or an equivalently verified native read-only check; the optional `Path.is_junction` fallback alone is not evidence for every reparse kind.
- Open read-only, read **limit + 1** bytes at most, reject overflow before decoding, bind actual raw bytes/hash and compare pre/open/post file identity/size/reparse observations. Handle missing/permission/race exceptions with fixed failure codes and no untrusted/secret contents. No configuration rewrite, copy, CREATE_NEW marker/receipt or normalizer in this leaf.
- For properties only, feed owned bytes to the existing phase01 `PropertiesObservation`. Preserve its exact whole-map comparison, strict controls, LF/CRLF and clarified ASCII-space-only blank handling. Keep seed/reload raw binding separate. This does not independently establish that a supplied hook digest came from the hook.
- Directory seed absence checking may be a separately bounded function, with at most 1,024 entries per fixed direct directory, stop before collecting the next; match only the two fixed UUID prefixes. No broad recursive scan. A directory boundary race must refuse rather than refresh after an ownership decision.

All numeric choices above already exist in the cumulative contract: properties 1..16,384 bytes plus one overflow observation, 1,023 pairs / 2,048 properties nodes; fixed direct directories 1,024. No JSON or NBT semantic convention is needed to implement this narrow leaf. Directory enumeration/cache/native constructor authority remains outside it unless explicitly assigned.

### Disjoint ownership proposal

Task04 currently prescribes the two Python scripts, not arbitrary new modules. Two safe allocation shapes are available:

1. **No write-scope extension:** one worker owns only `scripts/run_v180_classic_inventory_smoke.py`, `scripts/test_run_v180_classic_inventory_smoke.py` and newly named own phase02 records, sequentially after a committed phase01 base. No other phase02 worker edits these files concurrently. Frozen candidate03 evidence itself is never changed.
2. **Explicit small scope supplement:** Root can assign new private `scripts/classic_inventory_fixture_inputs.py`, `scripts/test_classic_inventory_fixture_inputs.py` and own `NATIVE-PROGRESS-04-PHASE02A.md` / `NATIVE-HANDOFF-04-PHASE02A.md`. Phase01 scripts remain read-only. A separate records worker later owns two separate private record/test files; Root alone owns future driver integration and command wiring. This is an actionable disjoint option, **not an already granted expansion**. Keep it one-consumer test tooling, not a generic filesystem framework.

The implementer should document the quiescent owned-copy assumption and exactly what identity/reparse checks establish. Ordinary path/stat checking does not prove malicious concurrent ancestor swaps cannot occur. If the required platform cannot make the intended fail-closed read semantics verifiable, return the precise technical limitation before claiming eligibility; do not add a silent trust assumption.

## JSON convention options requiring explicit freeze

Both options keep every published byte/node/depth ceiling unchanged, count before constructing the over-budget node and use **root depth 1**. Container and value nesting each increases depth by 1; object keys sit at the value's depth. Both reject duplicate decoded keys, BOM/malformed UTF-8, trailing data, unsupported nonfinite numbers and unpaired surrogates; schema validators require exact types (`bool` is not an integer), field sets and ranges. No object-key normalization or progress defaults.

| Option | Node rule | Compatibility effect |
|---|---|---|
| A: JSON-value convention | Root/container/each value counts; object key strings are validated but do not count as nodes. | Matches the existing provenance validator's value traversal at `validate_bootstrap_provenance.py:1735–1760`. A flat 1,024-member object uses 1,025 nodes and fits 2,048. |
| B: keys-and-values convention | Same root/value rule, plus every decoded object key counts as a string node. | Aligns the shape of the separately specified properties pair accounting, but is stricter than Option A for object-heavy native files. The same object uses 2,049 nodes and refuses; unknown but otherwise bounded advancement/stat/cache objects near the limit may become ineligible. |

Existing NBT readers' depth 0 convention is not authorization for JSON root depth 0. A root-depth 0 choice would additionally admit one more layer than these two proposed root-depth 1 definitions and requires its own explicit decision. No current Task04 production JSON parser or native result exists whose compatibility can be claimed either way. The thin model measures the difference only; it does not decide the owner/integrator's answer.

Once selected, a small record-parser leaf can implement strict external marker/receipt/cohort objects and exact report payload objects using the respective 16,384-byte / depth 12 or 8 / 2,048-node ceilings. Budget-aware tokenization or another demonstrated bounded preflight is required; a post-`json.loads` tree walk alone is not evidence that depth/node refusal occurred before structural allocation. Oversized integer lexemes must not cause unbounded integer conversion; prove bounds without inventing an unstated new content ceiling. Preserve unknown native advancement/stat/cache fields under their own bounded valid schemas, rather than applying the marker's exact-field rejection to every native file.

## NBT and native record leaf, distinct from file safety

No current helper meets all the required dat checks by direct reuse. A private current-fixture reader can be proposed after a precise node/depth accounting definition is verified for native NBT (including how array payloads and TAG_End terminators count). Do not infer that generic JSON nodes define NBT nodes.

Required existing limits: compressed 262,144 / raw 1,048,576 bytes / depth 32 / nodes 65,536. Stream exactly one gzip member and reject trailing/concatenated/truncated input, then scan typed native tag lengths/names before native decoding. Preserve raw bytes, tag widths, list subtype/count and float/double bits; string handling must match native Modified UTF framing rather than silently reinterpret native bytes as ordinary UTF-8. Positive record fixtures need independently inspected native-emission provenance, not only the crafted negative probes in this intake.

Exact semantic checks are already specified: UUID IntArray of 4; Inventory List tag 9 / subtype 0 / count 0; Dimension String tag 8 / Overworld; Pos Double-list of 3 fixed coordinates; Motion Double-list of 3 / raw positive zero; Rotation Float-list of 2 / raw positive zero; playerGameType Int tag 3 / value 1; RootVehicle absent. Inspect both required dat and optional dat_old independently before any reload constructor; never use a backup to repair the current file. Unknown bounded valid native fields are retained/read, not rewritten. The separate JSON records have published advancement/stat/cache ceilings; saved criterion times are exact UTC 25-ASCII-character second-resolution strings, not raw millisecond identity after native save.

## Authority transport and host launch are later boundaries

The implemented `require_live_binding` accepts an independently supplied digest; it is not origin evidence (`candidate03 run_v180_classic_inventory_smoke.py:173–179`). Marker/receipt hash equality likewise does not confer offline-record ownership or clean-stop truth by itself.

Transport needs independently reviewed whole-line native logger framing, strict UTF-8 byte handling, per-row/cohort ceilings, a monotonic fresh start offset taken before the fixed command, exact run/phase/event/index state machine, one fresh setup acknowledgement and failure for duplicates/replays/late output/wrong source/unknown ERROR or FATAL. `CapturedProcess` at `run_dedicated_server_smoke.py:606–674` provides useful own-process/stdin/condition lifecycle patterns, but decodes with `errors='replace'`, stores an unbounded line list and uses regex search. It cannot be borrowed unchanged to prove Task04 byte fidelity, bounded transport or exact origin. A post-return deadline check is required to reject a late wake; a shared deadline must not reset on each report.

Receipt creation is **driver-only and later**: complete 12 seed rows plus owned disposal are action facts, not native PASS; require independent clean exit 0 / stop evidence and bounded stopped native file/criterion/cache/property observations before CREATE_NEW receipt. Reload must independently match marker, launch digest, same real copy/run/source/JAR/libraries/source-world, eight files and their actual hashes, exact owned profiles and seed-stopped properties before construction. Receipt cannot grant/reset/restore progression, refresh changed caches or salvage a failed copy.

Do not implement/start the native driver in phase02a. Future native work additionally requires four reviewed test-only Java fixture responsibilities, central opt-in listener registration owned by Root, a committed packaged artifact and eligible fixed source host. Existing Signature/Pump/Tank capture/patch/world-copy routines write evidence or mutate copied records and are outside a read-only input helper's scope. No host path, jar or world is selected by this memo.

Original time budgets remain one 300-second cohort, intake 60, two 110-second hosts, final 20; each host startup 60 / action-and-cleanup 20 / stop 30; hook checks 10, poll 0.2. Seed's sole literal add consumes those budgets; reload never adds/removes/queries force marks. Constructor preflight still requires both identities, all 121 native forced-membership reads and 121 getChunkNow reads plus raw-spawn/border/air/entities/cache gates. Neither fresh English acknowledgement nor a FULL marker substitutes for these observations.

## Minimal test decomposition and remaining gates

Phase02a executable Python tests should cover exact-limit/+1/empty, byte ownership/hash, missing-vs-dangling/directory/reparse ancestor, path escape/overlap, read-time replacement/size change, no leaked handles, fixed failure codes/no secret echo, 1,024/+1 directory entries and UUID temporary-prefix collision, immutable snapshots, whole-map unknown settings, seed/reload bindings and zero filesystem writes. Use only fresh own D fixtures; test reader refusal before any decoded record/construction operation. Keep the original 39 phase01 tests unchanged and run them after any integration; do not count this intake's 12 controls as implementation tests.

Later parser tests: exact schema/future/extra/missing/bool-int/duplicates/escaped-alias/nonfinite/surrogate/trailing/depth-and-node boundary, all fixed event sequences/FAILED rows, gzip member/type/width/listbit/timestamp negatives, raw-vs-logical and unsupported-record retention. Later transport tests need stale/wrong-thread/wrong-logger/partial-line/late-wake/cohort-overflow inputs, failed action/disposal and missing clean stop; no prescribed pass output. Later Java/native tests must prove real callback/call-order/owned cleanup, ordinary listener and fresh seed/reload saved records. Do not derive those from pure parser models.

Completed here: named-input audit and 12 bounded factual/model controls. Not completed: any new source, parser implementation, Java, full automatic regression, actual hook/driver/host admission, native listeners/restart/persistence, client V1/V2, R-021, shared writer or version G0–G9. No ledger or version status changes. The next independently assignable existing-policy leaf is **phase02a read-only bounded file/properties intake**, after Root freezes its precise file ownership; JSON accounting and packaged authoritative framing remain separately explicit technical prerequisites.
