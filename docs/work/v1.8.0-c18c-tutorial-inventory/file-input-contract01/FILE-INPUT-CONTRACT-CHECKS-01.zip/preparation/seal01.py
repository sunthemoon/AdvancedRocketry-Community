"""Seal only named small owned output files; do not export source trees."""
import hashlib
import json
from pathlib import Path
import re

here = Path(__file__).resolve().parent
names = ['facts01.py', 'seal01.py', 'REPORT-01.md', 'TOOL-OBSERVATIONS-01.md',
         'INPUTS-01.json', 'FACTS-01.json', 'POSTCHECK-01.json',
         'facts-01.log', 'facts-01.exit', 'facts-02.log', 'facts-02.exit']
inputs = json.loads((here / 'INPUTS-01.json').read_bytes())['inputs']
drift = []
for entry in inputs:
    raw = Path(entry['path']).read_bytes()
    if len(raw) != entry['bytes'] or hashlib.sha256(raw).hexdigest() != entry['sha256']:
        drift.append(entry['path'])
assert not drift, drift
links = []
for name in ('REPORT-01.md', 'TOOL-OBSERVATIONS-01.md'):
    text = (here / name).read_text(encoding='utf-8')
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        assert not re.match(r'(?:[A-Za-z]:|/|https?:)', link), link
        assert (here / link.split('#', 1)[0]).is_file(), link
        links.append(link)
result = {'kind': 'small immutable intake output; not implementation/native admission',
          'inputs_checked': len(inputs), 'input_drift': drift,
          'companion_links': len(links), 'missing_links': []}
(here / 'SEAL-RESULT-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
names.append('SEAL-RESULT-01.json')
rows = []
for name in sorted(names):
    raw = (here / name).read_bytes()
    rows.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'scope': result['kind'], 'payload_count': len(rows),
            'payload_bytes': sum(row['bytes'] for row in rows), 'files': rows}
(here / 'INTERNAL-MANIFEST-01.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(here / 'SHA256SUMS.txt').write_text(''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in rows)
                                  + hashlib.sha256((here / 'INTERNAL-MANIFEST-01.json').read_bytes()).hexdigest()
                                  + '  INTERNAL-MANIFEST-01.json\n', encoding='ascii')
print(json.dumps({'report_sha256': hashlib.sha256((here / 'REPORT-01.md').read_bytes()).hexdigest(),
                  'manifest_sha256': hashlib.sha256((here / 'INTERNAL-MANIFEST-01.json').read_bytes()).hexdigest(),
                  'checksum_sha256': hashlib.sha256((here / 'SHA256SUMS.txt').read_bytes()).hexdigest(),
                  **result, 'payload_count': len(rows), 'payload_bytes': manifest['payload_bytes']}))
