"""Read-only C18c phase02 intake controls; models are not adopted parsers."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af/candidate03')
PROPOSAL = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
ORIGINAL = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
PIN = 'a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c'
FILES = [
    'AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-04.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-03.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-02.md',
    'scripts/run_v180_signature_smoke.py', 'scripts/run_v180_pump_smoke.py',
    'scripts/run_v180_tank_smoke.py', 'scripts/run_v180_fluid_smoke.py',
    'scripts/run_dedicated_server_smoke.py', 'scripts/run_v050_rocket_server_smoke.py',
    'scripts/run_v180_motor_smoke.py', 'scripts/v120_precision_world_fixture.py',
    'scripts/v140_migration_fixture.py', 'scripts/inspect_celestial_saved_data.py',
    'scripts/run_v140_planetary_worlds_smoke.py', 'scripts/run_v130_satellite_payload_smoke.py',
    'scripts/run_v140_celestial_schema_smoke.py', 'scripts/run_v130_adapter_recovery_smoke.py',
    'scripts/validate_bootstrap_provenance.py', 'scripts/validate_v1plus_planning.py',
]
OWN = [
    'scripts/run_v180_classic_inventory_smoke.py',
    'scripts/test_run_v180_classic_inventory_smoke.py',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md',
]
EXTERNAL = [PROPOSAL / name for name in ('OWNERSHIP-PROPOSAL-03.md', 'PROTOCOL-03.json', 'EVIDENCE-MANIFEST.json')]
EXTERNAL += [ORIGINAL / 'OWNERSHIP-PROPOSAL-01.md', ORIGINAL / 'PROTOCOL-01.json']
EXTERNAL += [AUTHOR / 'postimages' / name for name in OWN]
EXTERNAL += [AUTHOR / 'SOURCE-CANDIDATE-03.json', AUTHOR / 'EVIDENCE-MANIFEST-03.json']


def digest(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def measure(value, keys: bool) -> tuple[int, int]:
    # Two EXPLICIT hypothetical conventions: root=1; keys either excluded/included.
    stack, nodes, maximum = [(value, 1)], 0, 0
    while stack:
        value, depth = stack.pop()
        nodes += 1
        maximum = max(maximum, depth)
        if type(value) is dict:
            stack.extend((item, depth + 1) for item in value.values())
            if keys:
                stack.extend((key, depth + 1) for key in value)
        elif type(value) is list:
            stack.extend((item, depth + 1) for item in value)
    return nodes, maximum


def run() -> None:
    assert all(os.environ.get(key) == str(HERE) for key in ('TEMP', 'TMP', 'TMPDIR'))
    paths = [ROOT / name for name in FILES] + EXTERNAL
    before = [digest(path) for path in paths]
    checks, observations = [], {}
    def check(name, condition):
        assert condition, name
        checks.append(name)
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
    observations['start_head'] = head
    observations['fixed_fact_base'] = PIN
    check('Root phase01 not integrated at intake', not any((ROOT / name).exists() for name in OWN))
    observations['root_phase01_presence'] = {name: (ROOT / name).exists() for name in OWN}
    fixed = subprocess.run(['git', 'cat-file', '-e', PIN + '^{commit}'], cwd=ROOT, capture_output=True, text=True)
    check('Pinned Root object exists', fixed.returncode == 0)
    object_comparisons = []
    for name in FILES:
        result = subprocess.run(['git', 'show', PIN + ':' + name], cwd=ROOT, capture_output=True)
        object_comparisons.append({'path': name, 'object_exit': result.returncode,
                                   'object_sha256': hashlib.sha256(result.stdout).hexdigest() if result.returncode == 0 else None,
                                   'live_raw_equals_object': result.returncode == 0 and result.stdout == (ROOT / name).read_bytes()})
    observations['fixed_object_comparisons'] = object_comparisons
    p = json.loads((PROPOSAL / 'PROTOCOL-03.json').read_bytes())
    observations['ceilings'] = p['ceilings']
    observations['deadlines_seconds'] = p['deadlines_seconds']
    check('Protocol defines structured schemas', all(key in p for key in ('common_fields', 'payload_schemas', 'external_receipt_fields')))
    # This is a lexical/introspection fact, not proof all historical prose has no convention.
    observations['protocol_node_depth_explicit_text'] = [line for line in (PROPOSAL / 'PROTOCOL-03.json').read_text(encoding='utf-8').splitlines() if 'node' in line or 'depth' in line]
    module_path = AUTHOR / 'postimages' / OWN[0]
    tree = ast.parse(module_path.read_bytes())
    imports = [node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
    imports += [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
    check('Phase01 has no filesystem/process/JSON/NBT imports', not set(imports) & {'os', 'pathlib', 'subprocess', 'json', 'gzip', 'zlib', 'struct'})
    observations['phase01_imports'] = imports
    observations['phase01_function_lines'] = {node.name: [node.lineno, node.end_lineno] for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    primitive = load_module('intake_classic_properties', module_path)
    raw = b'gamemode=adventure\nforce-gamemode=false\nview-distance=2\nsimulation-distance=3\n'
    configured = primitive.PropertiesObservation(raw)
    other = primitive.PropertiesObservation(b'# native comment\r\n' + raw.replace(b'\n', b'\r\n'))
    primitive.require_logical_equality(configured, other)
    check('Phase01 raw/logical distinction stays independent', configured.sha256 != other.sha256)
    check('Only seed literal command', primitive.commands_for_phase('seed') == ('forceload add -80 -80 95 95',) and primitive.commands_for_phase('reload') == ())
    width = {str(index): None for index in range(1024)}
    a, b = measure(width, False), measure(width, True)
    observations['json_count_options'] = {'root_depth': 1, 'wide1024_value_nodes': a, 'wide1024_key_and_value_nodes': b, 'limit': 2048}
    check('JSON conventions have different exact acceptance boundary', a[0] <= 2048 < b[0])
    check('Root depth also changes boundary', measure({'x': None}, False)[1] == 2)
    nbt = load_module('intake_existing_nbt', ROOT / 'scripts/inspect_celestial_saved_data.py')
    def empty_list(subtype: int) -> bytes:
        return b'\x0a\x00\x00\x09\x00\x09Inventory' + bytes((subtype,)) + struct.pack('>i', 0) + b'\x00'
    decoded0 = nbt.NbtReader(empty_list(0)).read_root()
    decoded3 = nbt.NbtReader(empty_list(3)).read_root()
    check('Existing SavedData reader loses typed-empty-list distinction', decoded0 == decoded3 == {'Inventory': []})
    mutf_null = b'\x0a\x00\x00\x08\x00\x01x\x00\x02\xc0\x80\x00'
    try:
        nbt.NbtReader(mutf_null).read_root()
    except nbt.NbtError as exc:
        observations['existing_reader_modified_utf_null'] = {'result': 'refused', 'error': str(exc)}
    else:
        raise AssertionError('Existing strict UTF-8 reader unexpectedly accepts Modified UTF NUL')
    check('Existing SavedData reader is not native-string universal reader', observations['existing_reader_modified_utf_null']['result'] == 'refused')
    check('Existing NBT node/depth limits differ', nbt.MAX_TAGS == 4096 and nbt.MAX_DEPTH == 16)
    check('All read inputs remain unchanged', before == [digest(path) for path in paths])
    (HERE / 'INPUTS-01.json').write_text(json.dumps({'kind': 'individual read-input observations, no copied mutable build artifacts', 'fixed_root_fact_base': PIN, 'inputs': before}, indent=2) + '\n', encoding='utf-8')
    (HERE / 'FACTS-01.json').write_text(json.dumps({'scope': 'intake facts and hypothetical convention model only', 'checks': checks, 'count': len(checks), 'observations': observations}, indent=2) + '\n', encoding='utf-8')
    (HERE / 'POSTCHECK-01.json').write_text(json.dumps({'input_count': len(paths), 'unchanged': True, 'head_at_end': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip(), 'phase01_candidate_unchanged': True}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'checks': len(checks), 'input_count': len(paths), 'input_drift': [], 'scope': 'Python/static only'}))


if __name__ == '__main__':
    run()
