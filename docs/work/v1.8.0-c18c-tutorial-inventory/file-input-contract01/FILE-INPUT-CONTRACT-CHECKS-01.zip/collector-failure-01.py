"""Thin publication collector. Never execute helpers in original sealed directories."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'd0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad'
ROOT_PROPOSAL = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-root-proposal-20261005-01')
GROUPS = [
    ('exact-review', Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-contract-review-20261005-6bd3ac'),
     'b8d6cde0612e40d293c089003af3681b2d14d8fd526f34184219d65c4d6fafed', 13),
    ('preparation', Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-intake-20261005-16db7a'),
     '074515c3b081efa2ef831e1a7995e8eff0b185206200a2dca8c4417ad43e8944', 12),
    ('peer-review', Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-file-intake-review-54244a2fe2'),
     'ad339e2d72c7fac121686c4cee212f75e101b8b2f5269117e12f25b07ac7c937', 18),
]


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_relative(name):
    p = PurePosixPath(name)
    assert name == p.as_posix() and not p.is_absolute() and p.parts
    assert all(part not in ('', '.', '..') and ':' not in part and '\\' not in part for part in p.parts)
    return p


def write(name, raw):
    safe_relative(name)
    path = HERE / name
    assert not path.exists(), name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def main():
    assert all(os.environ.get(key) == str(HERE) for key in ('TEMP', 'TMP', 'TMPDIR'))
    transfers, groups = [], []
    staged = ['SCOPE.md', 'collect01.py']
    def copy(source, member):
        raw = source.read_bytes()
        write(member, raw)
        copied = (HERE / member).read_bytes()
        assert raw == copied
        transfers.append({'source': source.as_posix(), 'member': member, 'bytes': len(raw),
                          'original_sha256': digest(raw), 'copied_sha256': digest(copied)})
        staged.append(member)
    for prefix, folder, expected, count in GROUPS:
        manifest_raw = (folder / 'INTERNAL-MANIFEST-01.json').read_bytes()
        assert digest(manifest_raw) == expected
        manifest = json.loads(manifest_raw)
        assert len(manifest['files']) == count
        for row in manifest['files']:
            name = row['path']
            safe_relative(name)
            raw = (folder / name).read_bytes()
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256'], (prefix, name)
            copy(folder / name, prefix + '/' + name)
        sums = (folder / 'SHA256SUMS.txt').read_bytes().decode('ascii').splitlines()
        assert len(sums) == count + 1 and len(sums) == len(set(sums))
        for line in sums:
            sha, name = line.split('  ', 1)
            safe_relative(name)
            assert digest((folder / name).read_bytes()) == sha
        for name in ('INTERNAL-MANIFEST-01.json', 'SHA256SUMS.txt'):
            copy(folder / name, prefix + '/' + name)
        groups.append({'prefix': prefix, 'original_manifest_sha256': expected,
                       'payloads_verified': count, 'checksums_verified': len(sums)})
    assert digest((ROOT_PROPOSAL / 'TASK-PROPOSAL-01.md').read_bytes()) == 'bec0d17ec6f149306e4bede4494329bc6e6b9742a7af9987ff4ee5b565482a78'
    for name in ('TASK-PROPOSAL-01.md', 'ROOT-REVIEW-INTAKE-01.json'):
        copy(ROOT_PROPOSAL / name, 'proposal/' + name)
    intake = json.loads((ROOT_PROPOSAL / 'ROOT-REVIEW-INTAKE-01.json').read_bytes())
    assert intake['review_report_sha256'] == '4165d6c8f98548203b70ac611f95a36d81e3e4432c57ad5d0fa719775f95c7c9'
    assert intake['source_or_native_admission'] is False and intake['required_gates_passed'] is False
    external = []
    for name in ('scripts/run_v180_classic_inventory_smoke.py', 'scripts/test_run_v180_classic_inventory_smoke.py',
                 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md',
                 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md',
                 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md',
                 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-04.md'):
        result = subprocess.run(['git', 'show', BASE + ':' + name], cwd=ROOT, capture_output=True)
        assert result.returncode == 0
        external.append({'kind': 'external immutable Git object, not embedded', 'commit': BASE,
                         'path': name, 'bytes': len(result.stdout), 'sha256': digest(result.stdout), 'git_show_exit': result.returncode})
    norm = ROOT / 'docs/work/v1.8.0-c18c-tutorial-inventory/native-contract04-01/CONTRACT-CHECKS-01.zip'
    norm_raw = norm.read_bytes()
    assert len(norm_raw) == 335006 and digest(norm_raw) == 'c43f6ae228bb664ceecc15b1ef7dfd788e77c988d45961b0bbd44b54812ac67f'
    with zipfile.ZipFile(norm) as archive:
        for name, expected in [('author/OWNERSHIP-PROPOSAL-03.md', 'f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca'),
                               ('author/PROTOCOL-03.json', 'fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc')]:
            raw = archive.read(name)
            assert digest(raw) == expected
            external.append({'kind': 'external Root normative archive member, not embedded',
                             'archive': norm.as_posix(), 'archive_bytes': len(norm_raw), 'archive_sha256': digest(norm_raw),
                             'member': name, 'bytes': len(raw), 'sha256': digest(raw)})
    write('EXTERNAL-QUALIFICATION-01.json', (json.dumps({'full_source_closure': False, 'inputs': external}, indent=2) + '\n').encode())
    staged.append('EXTERNAL-QUALIFICATION-01.json')
    source_drift = []
    for row in transfers:
        raw = Path(row['source']).read_bytes()
        row['original_post_bytes'] = len(raw)
        row['original_post_sha256'] = digest(raw)
        if len(raw) != row['bytes'] or digest(raw) != row['original_sha256']:
            source_drift.append(row['source'])
    assert not source_drift
    write('COLLECTOR-INPUTS-01.json', (json.dumps({'transfers': transfers, 'source_drift': source_drift}, indent=2) + '\n').encode())
    staged.append('COLLECTOR-INPUTS-01.json')
    links = []
    for member in staged:
        if not member.endswith('.md'):
            continue
        text = (HERE / member).read_text(encoding='utf-8')
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
            if link.startswith(('http:', 'https:')):
                continue
            target = (HERE / member).parent / link.split('#', 1)[0]
            assert not Path(link).is_absolute() and target.is_relative_to(HERE) and target.is_file(), (member, link)
            links.append({'member': member, 'link': link, 'exists': True})
    checks = {'kind': 'publication copying checks, no source/native acceptance', 'groups': groups,
              'original_files': len(transfers), 'source_drift': source_drift,
              'raw_copy_mismatches': [], 'relative_links': links, 'sealed_helpers_executed': 0,
              'no_full_source_closure': True}
    write('COLLECTOR-CHECKS-01.json', (json.dumps(checks, indent=2) + '\n').encode())
    staged.append('COLLECTOR-CHECKS-01.json')
    assert len(staged) == len(set(staged))
    rows = [{'path': name, 'bytes': len((HERE / name).read_bytes()), 'sha256': digest((HERE / name).read_bytes())}
            for name in sorted(staged)]
    manifest = {'kind': checks['kind'], 'payload_count': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows),
                'exclusions': ['whole source trees', 'JARs', 'runtime/worlds', 'old phase01 ZIP',
                               'external normative ZIP payload', 'Java/native execution', 'new source verdict'], 'files': rows}
    write('EVIDENCE-MANIFEST-01.json', (json.dumps(manifest, indent=2) + '\n').encode())
    manifest_sha = digest((HERE / 'EVIDENCE-MANIFEST-01.json').read_bytes())
    write('SHA256SUMS.txt', (''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in rows)
                            + manifest_sha + '  EVIDENCE-MANIFEST-01.json\n').encode('ascii'))
    members = sorted(staged + ['EVIDENCE-MANIFEST-01.json', 'SHA256SUMS.txt'])
    archive_path = HERE / 'FILE-INPUT-CONTRACT-CHECKS-01.zip'
    assert not archive_path.exists()
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as archive:
        for name in members:
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (HERE / name).read_bytes())
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and archive.namelist() == members
        assert len(members) == len(set(members))
        for name in members:
            assert archive.read(name) == (HERE / name).read_bytes(), name
    raw = archive_path.read_bytes()
    write('FILE-INPUT-CONTRACT-CHECKS-01.zip.sha256', (digest(raw) + '  FILE-INPUT-CONTRACT-CHECKS-01.zip\n').encode('ascii'))
    result = {'archive': archive_path.as_posix(), 'sha256': digest(raw), 'bytes': len(raw), 'members': len(members),
              'payloads': len(rows), 'payload_bytes': manifest['payload_bytes'], 'manifest_sha256': manifest_sha,
              'checksums_sha256': digest((HERE / 'SHA256SUMS.txt').read_bytes()),
              'source_drift': [], 'crc_mismatch': [], 'entry_byte_mismatch': [], 'companion_links': len(links),
              'original_group_payloads': [entry['payloads_verified'] for entry in groups],
              'full_closure': False, 'native_or_source_admission': False}
    write('ARCHIVE-RESULT-01.json', (json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(result))


if __name__ == '__main__':
    main()
