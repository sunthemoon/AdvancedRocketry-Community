# C18c quiescent file-input contract review collection

Date: 2026-10-05. This is a publication collector, not a new review, source implementation or native run. It preserves exact earlier bytes and verdict qualifications; no sealed helper is rerun.

## Included original evidence

- [Root exact proposal](proposal/TASK-PROPOSAL-01.md), SHA-256 `bec0d17ec6f149306e4bede4494329bc6e6b9742a7af9987ff4ee5b565482a78`, and Root's exact review-intake receipt.
- [Independent exact-text review](exact-review/REVIEW-01.md), SHA-256 `4165d6c8f98548203b70ac611f95a36d81e3e4432c57ad5d0fa719775f95c7c9`: all 13 original payloads and both metadata files, including its three small local API fixtures, original commands/results and unchanged 39-test regression log.
- [Earlier factual intake](preparation/REPORT-01.md), SHA-256 `1751baddcd610a995175fa8651c5482ff20f13b1262eb57ab2eb4ff9d039076e`: all 12 original payloads and both metadata files, including the separately qualified failed locator observations.
- [Peer factual assessment](peer-review/REVIEW-01.md), SHA-256 `35def280ecea442dbf8ef8d3f4c496d522cda1d5121ad872ed5b020dc338f0fd`: all 18 original payloads and both metadata files, including its failed first temp-string invocation, corrected second invocation and fixed-object checks.

The three original manifests/checksums remain byte-exact in their respective directories. Their report-relative companion links continue to resolve in this collection. Source paths printed inside original reports remain historical provenance, not new copies or purported fully portable source closure. Original reports and verdicts are not rewritten or attributed to a newer source cohort.

## External normative and source qualification

This deliberately is **not a full source/host/native closure**. No whole source tree, JAR, runtime/world, original phase01 ZIP or recursively nested historical archive is included. External qualification is recorded in [EXTERNAL-QUALIFICATION-01.json](EXTERNAL-QUALIFICATION-01.json):

- Root phase01 source is committed at `d0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad`. The four exact source/record paths are named individually with their raw Git-object hashes, rather than copied here.
- Task04 and its limited technical disposition are individually qualified against that same immutable commit.
- Cumulative proposal03 / protocol03 are published in Root `docs/work/v1.8.0-c18c-tutorial-inventory/native-contract04-01/CONTRACT-CHECKS-01.zip`, 335,006 bytes, SHA-256 `c43f6ae228bb664ceecc15b1ef7dfd788e77c988d45961b0bbd44b54812ac67f`. Its exact `author/OWNERSHIP-PROPOSAL-03.md` and `author/PROTOCOL-03.json` member hashes were checked in memory. The archive is an external locator, not embedded or claimed as newly executed authority.

Only the proposed quiescent fixed-path input contract may be considered for Root adoption. Future implementation/source review, live reading, JSON counting, NBT/records, ownership/receipt authority, driver/host launch, native persistence/client/Gates remain outside this collector. Root's receipt explicitly disclaims source/native admission and Required Gates passed.

## Collection checks

[Original-to-copy observations](COLLECTOR-INPUTS-01.json) and [collection checks](COLLECTOR-CHECKS-01.json) preserve original pre/post bytes/hash equality, all three original payload/metadata checksum validations, safe unique relative member names and relative companion-link checks. The collector creates only new publication copies under its own D directory; it never writes original inputs or runs sealed helpers.

The collector command is `python -B collect01.py`, with process-local TEMP/TMP/TMPDIR in this own project-parent D leaf. The first attempt exited 1 before archive creation because link validation preceded creation of its planned `COLLECTOR-CHECKS-01.json`. Its exact [failed helper](collector-failure-01.py), [raw failed log](collector-01.log) and [exit](collector-01.exit) remain included. The second invocation corrects only receipt/link-check ordering, permits reuse only of byte-identical unsealed publication copies and checks every companion exists before archive construction. It never reruns original sealed helpers or changes their input bytes. No Java, Gradle, native process, network, Root/worktree/source/Git mutation or cleanup occurs. Final archive verification and exact outer archive hash/bytes/count are in the separate `ARCHIVE-RESULT-01.json` beside the ZIP, avoiding a self-referential archive hash. These packaging checks do not add runtime proof to the original observations.
