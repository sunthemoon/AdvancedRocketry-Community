# Independent exact-contract review: C18c phase02a

Date: 2026-10-05. Reviewer is a delegated independent worker, not Root, proposal author or phase01 implementer. Scope is the exact Root-authored text, not a nonexistent phase02 implementation.

## Findings and disposition

**0 Critical / 0 High / 0 Medium / 0 Low findings within this exact proposed scope.** No additional mandatory clause or owner semantic decision is identified for this narrow quiescent-only reader. The text is sufficiently bounded to assign the four-file implementation after Root's independent disposition; this review does not itself adopt the contract or grant source/native admission.

The inspected text is `TASK-PROPOSAL-01.md`, 6,847 bytes, SHA-256 `bec0d17ec6f149306e4bede4494329bc6e6b9742a7af9987ff4ee5b565482a78`. Later amendments require separate pins and review; this verdict cannot be transferred to them.

### Qualifications preserved by the actual text

- **Source and write ownership:** lines 9–24 bind phase01 to committed `d0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad`, keep all four earlier files read-only, name exactly two new private Python files and two own task records, and leave composition/central driver/Git to Root. Returning raw bytes without importing the future runnable module prevents a helper/driver cycle. No public API or stub driver is introduced.
- **Trust/temporal boundary:** lines 28–34 make admitted owned-root and quiescence caller prerequisites, not an output of a role/phase string, hash or read. This is materially narrower than live-host reading. Malicious concurrent ancestor swaps are explicitly excluded; lines 78–81 prevent repeated stat equality being presented as hostile-race or live-authority proof. Same-identity changes that are undetectable through the selected observations are not covered by a new adversarial guarantee.
- **Finite selectors:** lines 36–55 define exact role/point strings and only two constant-derived paths. The root is a separately admitted absolute local D path of at most 1,024 strict UTF-8 bytes; literal ancestors are checked before resolution and target containment. Existing files are required: no missing optional-record/seed-absence authority is inferred. Role/point labels do not establish actual prelaunch or clean-stop timing. Invalid selectors/path syntax remain refused.
- **Read/exception boundaries:** lines 59–76 require actual Windows reparse attributes, meaningful pre/open/post descriptor/path identity, one unbuffered read requesting at most 16,385 bytes, nonempty/overflow/short/change refusal, no retries, handle closure and fixed no-secret errors. These address the generic helper's buffered-read and exception-text limitations without modifying that unrelated utility.
- **Deferred obligations:** lines 102–113 explicitly exclude live reads, JSON/NBT, player directories/cache, CREATE_NEW snapshot/marker/receipt, configuration writes, force setup, console freshness, Java and driver/host selection. JSON root/key-node accounting is still unselected and is not needed for this byte-only leaf. No save writer or time/Gate budget is opened.

This is a staged subset of cumulative Task04, not a waiver of its stronger live/ownership/native duties. Suitable source host, committed actual-source review and all later authoritative runtime evidence remain required.

## Normative comparison and source identities

The adoption authority remains Root `NATIVE-REVIEW-DISPOSITION-04.md`; the standalone proposal header remains PROPOSED. Cumulative `OWNERSHIP-PROPOSAL-03.md:120–183` distinguishes configured snapshot, actual preboot, hook live and stopped bytes. Its lines 137–158 already require bounded no-reparse properties observations and preserve full unknown-key logical maps and raw hashes. The new leaf implements only the quiescent byte-input prerequisite to those operations; existing `PropertiesObservation` still owns decoding/hash/map behavior. It does not certify a hook digest's origin.

Original cumulative `OWNERSHIP-PROPOSAL-01.md:90–149,281–336` retains owned-copy/receipt/authority/logger/record obligations. None is replaced by a successful properties file read. The text's exact four new paths fit the independently evaluated small-scope extension rather than silently enlarging the older two-script write scope.

Key pins:

| Input | SHA-256 |
|---|---|
| Exact Root phase02a proposal | `bec0d17ec6f149306e4bede4494329bc6e6b9742a7af9987ff4ee5b565482a78` |
| c18 frozen technical assessment | `35def280ecea442dbf8ef8d3f4c496d522cda1d5121ad872ed5b020dc338f0fd` |
| Earlier c17 factual intake report | `1751baddcd610a995175fa8651c5482ff20f13b1262eb57ab2eb4ff9d039076e` |
| Task04 | `3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43` |
| Task04 limited disposition | `8d679d97de9ff04f27880ed01071b43fccc4c66e2cac89bc20540b853d9bc28d` |
| Cumulative proposal03 | `f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca` |
| Protocol03 | `fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc` |
| Live AGENTS | `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0` |

All four phase01 Root files were independently compared byte-for-byte to fixed commit `d0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad` using bounded `git show` queries. They are now present, unlike the earlier a087 intake; the old absence observation remains historical, not silently rewritten. The exact input observations are in [INPUT-PINS-01.json](INPUT-PINS-01.json). Live user AGENTS is separately authoritative; no historical replacement is applied.

## Actual checks and local implementability facts

Commands ran from the read-only Root checkout; every new helper, fixture, log and process-local TEMP/TMP/TMPDIR output uses only `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-contract-review-20261005-6bd3ac`, with Python `-B`. The entries below name the helper basenames; the first command actually passed the full own-D helper path:

1. `python -B checks01.py`: **7 tests, 0 failures/errors/skips, exit 0**, 0.220 seconds. [Exact helper](checks01.py), [raw log](checks-01.log), [measured results](CHECK-RESULTS-01.json).
2. From Root's read-only checkout, `python -B scripts/test_run_v180_classic_inventory_smoke.py`: **39 existing tests, 0 failures/errors/skips, exit 0**, 0.020 seconds. [Raw log](phase01-regression-01.log). No phase01 test or assertion changed.
3. Four fixed-object `git show` controls execute inside the first control; all exit 0 and match actual phase01 bytes. Input postchecks and earlier sealed evidence checks are recorded separately at seal.

The local Python is **3.13.15 / Windows `nt`**. The control opens only newly created small own-D API fixtures, not a source world/server or the proposed fixture paths. These API observations support implementability on this host, not an implemented reader:

- `Path.open('rb', buffering=0)` returned native `FileIO`; one request of 16,385 bytes on a 16,384-byte regular file returned the exact 16,384 bytes.
- Actual `lstat` and `fstat` expose regular-file mode, matching `st_dev`/`st_ino`/size and comparable metadata, plus `st_file_attributes` and `st_reparse_tag`. The ordinary fixture had attributes 32 and reparse tag 0. Pre/open/after observations are stored, not inferred from convenience predicates.
- A separate 32,768-byte file returned only 16,385 bytes in one request. This demonstrates the API read bound; no phase02 refusal implementation exists yet.
- A controlled exception inside the actual read context closed its handle. `raise ... from None` suppressed the underlying controlled secret string in the default traceback. The exception's private `__context__` object still exists: this does not claim memory erasure, and is consistent with the proposal's public string/default-traceback boundary.

The useful older `_read_bounded_regular_file` at `prepare_v002_g0_review_packet.py:1315–1374` was read as a pattern only. Its `path.open('rb')` at 1343 is buffered, and its OSError wrapper at 1366–1367 includes OS exception text and chaining. Its ancestor checker at 1377–1396 is separate. The proposed helper must implement the new unbuffered/fixed-error/root-ancestor checks directly; this review does not bless importing the old utility unchanged.

No command failure or skipped test occurred in this new review. The controlled negative exceptions are test inputs, not lost command failures. Prior intake and c18 assessment failures remain in their original sealed evidence; they are not relabelled as these 46 actual successful tests.

## Implementation review conditions and remaining limits

The future source review must examine the actual path-type/error-code/identity-field choices and prove the entire literal ancestor chain is checked before following resolution. Windows reparse attributes must be inspected on required root/components/leaf; unsupported capability refuses. A private root/path selector cannot acquire authority by trusting the stage string. Native file operations may block despite finite byte/loop counts; a later driver still needs shared-deadline before/after checks and late-result refusal, not a new per-read timeout allowance.

Source tests must distinguish actual platform operations from IO seams. This review did **not** execute reparse/junction/permission/ancestor-replacement or short-read races, nor produce hostile-race proof. The proposed verification clauses at 92–100 assign those implementation tests and require actual failures/skips/platform limits to be qualified; this is adequate as a contract, not passing evidence for them. The three small own API fixture files remain in this review directory because deletion is not authorized in this read-only assignment; their exact hashes are included in the internal manifest.

No Java, Gradle, Minecraft, native server/client, network, Root/worktree/source/contract/Git modification, old sealed write, cleanup or whole-source/JAR/world export occurred. No JSON counting choice, writer/receipt authority, real host/live observation, progression grant, native restart, client V1/V2, R-021 or version G0–G9 is accepted. The existing-policy quiescent input leaf is assignable only after Root's exact disposition and independently reviewed implementation; full Task04 remains unfinished.
