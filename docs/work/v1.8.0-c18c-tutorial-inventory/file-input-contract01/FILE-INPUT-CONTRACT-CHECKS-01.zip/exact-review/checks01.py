"""Exact proposal intake and local API facts, not the proposed helper implementation."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import traceback
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = 'd0f9cbdeaf5921da7ee6157a99873dd47fb7f1ad'
PROPOSAL = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-root-proposal-20261005-01/TASK-PROPOSAL-01.md')
ASSESSMENT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-file-intake-review-54244a2fe2/REVIEW-01.md')
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-intake-20261005-16db7a')
NORM = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
ORIGINAL = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal-8a05f49bd1')
PHASE = [
    'scripts/run_v180_classic_inventory_smoke.py',
    'scripts/test_run_v180_classic_inventory_smoke.py',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-PROGRESS-04.md',
    'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-HANDOFF-04.md',
]
REQUIRED = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
            'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
            'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
            'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
            'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md',
            'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-REVIEW-DISPOSITION-04.md',
            'scripts/prepare_v002_g0_review_packet.py']
INPUTS = [ROOT / name for name in REQUIRED + PHASE] + [PROPOSAL, ASSESSMENT,
          OLD / 'REPORT-01.md', OLD / 'INTERNAL-MANIFEST-01.json',
          NORM / 'OWNERSHIP-PROPOSAL-03.md', NORM / 'PROTOCOL-03.json',
          ORIGINAL / 'OWNERSHIP-PROPOSAL-01.md']
OBSERVATIONS = {}


def pin(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def status(value) -> dict:
    return {key: getattr(value, key, None) for key in ('st_mode', 'st_dev', 'st_ino', 'st_size',
            'st_mtime_ns', 'st_ctime_ns', 'st_birthtime_ns', 'st_file_attributes', 'st_reparse_tag')}


class Controls(unittest.TestCase):
    def test_exact_candidate_and_assessment(self):
        self.assertEqual(pin(PROPOSAL)['bytes'], 6847)
        self.assertEqual(pin(PROPOSAL)['sha256'], 'bec0d17ec6f149306e4bede4494329bc6e6b9742a7af9987ff4ee5b565482a78')
        self.assertEqual(pin(ASSESSMENT)['sha256'], '35def280ecea442dbf8ef8d3f4c496d522cda1d5121ad872ed5b020dc338f0fd')

    def test_phase01_matches_fixed_commit(self):
        rows = []
        for name in PHASE:
            result = subprocess.run(['git', 'show', BASE + ':' + name], cwd=ROOT, capture_output=True)
            self.assertEqual(result.returncode, 0)
            raw = (ROOT / name).read_bytes()
            self.assertEqual(raw, result.stdout)
            rows.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'raw_equal': True})
        OBSERVATIONS['phase01_fixed_object_comparisons'] = rows

    def test_fixed_roles_and_unassigned_authority_are_explicit(self):
        text = PROPOSAL.read_text(encoding='utf-8')
        for clause in ('Roles are `configured` or', '`active`; points are `seed_preboot`, `reload_preboot` or `stopped`',
                       '.classic-inventory-fixture/snapshot-server-properties-v1.txt',
                       'Concurrent malicious ancestor swaps are outside',
                       'No live read, JSON/NBT/native record parser',
                       'Root owns central driver integration', 'imports from the existing runnable parsing module'):
            self.assertIn(clause, text)
        self.assertEqual(text.count('* `scripts/'), 2)
        self.assertEqual(text.count('* `docs/work/'), 2)

    def test_actual_windows_unbuffered_read_and_descriptor(self):
        self.assertEqual(os.name, 'nt')
        path = HERE / 'api-fixtures' / 'exact.bin'
        path.parent.mkdir(exist_ok=True)
        payload = b'x' * 16384
        path.write_bytes(payload)
        before = path.lstat()
        with path.open('rb', buffering=0) as handle:
            self.assertIsInstance(handle, io.FileIO)
            opened = os.fstat(handle.fileno())
            observed = handle.read(16385)
            after_open = os.fstat(handle.fileno())
        final = path.lstat()
        self.assertTrue(handle.closed)
        self.assertEqual(observed, payload)
        self.assertTrue(stat.S_ISREG(opened.st_mode))
        self.assertEqual((before.st_dev, before.st_ino, before.st_size),
                         (opened.st_dev, opened.st_ino, opened.st_size))
        self.assertEqual((opened.st_dev, opened.st_ino, opened.st_size),
                         (after_open.st_dev, after_open.st_ino, after_open.st_size))
        self.assertTrue(hasattr(before, 'st_file_attributes'))
        self.assertEqual(before.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT, 0)
        OBSERVATIONS['actual_unbuffered_regular_file'] = {'open_type': type(handle).__name__,
            'requested_bytes': 16385, 'returned_bytes': len(observed), 'closed': handle.closed,
            'before': status(before), 'opened': status(opened), 'after_open': status(after_open), 'final': status(final)}

    def test_single_api_read_never_returns_more_than_request(self):
        path = HERE / 'api-fixtures' / 'oversize.bin'
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(b'x' * 32768)
        with path.open('rb', buffering=0) as handle:
            raw = handle.read(16385)
        self.assertEqual(len(raw), 16385)
        OBSERVATIONS['actual_overflow_api_read'] = {'file_bytes': path.stat().st_size,
                                                    'requested_bytes': 16385, 'returned_bytes': len(raw),
                                                    'closed': handle.closed, 'helper_not_implemented': True}

    def test_actual_context_manager_closes_after_exception(self):
        path = HERE / 'api-fixtures' / 'failure.bin'
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(b'a')
        with self.assertRaises(RuntimeError):
            with path.open('rb', buffering=0) as handle:
                handle.read(16385)
                raise RuntimeError('CONTROLLED_NEGATIVE')
        self.assertTrue(handle.closed)
        OBSERVATIONS['controlled_exception_handle_closed'] = handle.closed

    def test_context_suppression_local_api_fact(self):
        try:
            try:
                raise OSError('TOKEN=secret-control')
            except OSError:
                raise ValueError('FIXED_CONTROL') from None
        except ValueError as error:
            text = ''.join(traceback.format_exception(error))
            self.assertNotIn('TOKEN=secret-control', text)
            self.assertTrue(error.__suppress_context__)
            OBSERVATIONS['context_suppression'] = {'public_message': str(error),
                'context_object_still_exists': error.__context__ is not None,
                'default_traceback_secret_suppressed': True}


def main() -> int:
    assert all(os.environ.get(key) == str(HERE) for key in ('TEMP', 'TMP', 'TMPDIR'))
    before = [pin(path) for path in INPUTS]
    OBSERVATIONS['python'] = sys.version
    OBSERVATIONS['os_name'] = os.name
    tests = unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    result = unittest.TextTestRunner(verbosity=2).run(tests)
    after = [pin(path) for path in INPUTS]
    drift = [row['path'] for row, other in zip(before, after) if row != other]
    (HERE / 'INPUT-PINS-01.json').write_text(json.dumps({'fixed_phase01_commit': BASE, 'inputs': before}, indent=2) + '\n', encoding='utf-8')
    (HERE / 'CHECK-RESULTS-01.json').write_text(json.dumps({'scope': 'exact-text and local API controls only',
        'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
        'input_drift': drift, 'observations': OBSERVATIONS}, indent=2) + '\n', encoding='utf-8')
    return 0 if result.wasSuccessful() and not drift else 1


if __name__ == '__main__':
    raise SystemExit(main())
