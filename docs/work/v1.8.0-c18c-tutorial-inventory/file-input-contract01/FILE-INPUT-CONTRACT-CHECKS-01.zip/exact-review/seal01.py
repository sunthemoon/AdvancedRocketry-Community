"""Named-file seal for this small exact-contract review; not a source export."""
import hashlib
import json
from pathlib import Path
import re

here = Path(__file__).resolve().parent
old = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-intake-20261005-16db7a')
inputs = json.loads((here / 'INPUT-PINS-01.json').read_bytes())['inputs']
def same(path, row):
    raw = path.read_bytes()
    return len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
drift = [row['path'] for row in inputs if not same(Path(row['path']), row)]
old_manifest = json.loads((old / 'INTERNAL-MANIFEST-01.json').read_bytes())
old_drift = [row['path'] for row in old_manifest['files'] if not same(old / row['path'], row)]
assert not drift and not old_drift, (drift, old_drift)
links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', (here / 'REVIEW-01.md').read_text(encoding='utf-8'))
assert all(not re.match(r'(?:[A-Za-z]:|/|https?:)', link) and (here / link).is_file() for link in links)
result = {'current_named_inputs': len(inputs), 'input_drift': drift,
          'prior_intake_payloads': len(old_manifest['files']), 'prior_intake_drift': old_drift,
          'relative_links': len(links), 'missing_links': [], 'scope': 'contract and local API, no native/source admission'}
(here / 'SEAL-RESULT-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
names = ['checks01.py', 'seal01.py', 'REVIEW-01.md', 'INPUT-PINS-01.json',
         'CHECK-RESULTS-01.json', 'checks-01.log', 'checks-01.exit',
         'phase01-regression-01.log', 'phase01-regression-01.exit', 'SEAL-RESULT-01.json',
         'api-fixtures/exact.bin', 'api-fixtures/oversize.bin', 'api-fixtures/failure.bin']
rows = []
for name in sorted(names):
    raw = (here / name).read_bytes()
    rows.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'kind': 'small independent exact-contract evidence, no redundant archive',
            'payload_count': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows), 'files': rows}
(here / 'INTERNAL-MANIFEST-01.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(here / 'SHA256SUMS.txt').write_text(''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in rows)
                                  + hashlib.sha256((here / 'INTERNAL-MANIFEST-01.json').read_bytes()).hexdigest()
                                  + '  INTERNAL-MANIFEST-01.json\n', encoding='ascii')
print(json.dumps({**result, 'payload_count': len(rows), 'payload_bytes': manifest['payload_bytes'],
                  'report_sha256': hashlib.sha256((here / 'REVIEW-01.md').read_bytes()).hexdigest(),
                  'manifest_sha256': hashlib.sha256((here / 'INTERNAL-MANIFEST-01.json').read_bytes()).hexdigest(),
                  'checksum_sha256': hashlib.sha256((here / 'SHA256SUMS.txt').read_bytes()).hexdigest()}))
