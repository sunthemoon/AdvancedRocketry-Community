# C18c phase02a file/properties intake technical assessment

Date: 2026-10-05. Independent delegated reviewer `/root/c18_contract`, not the
phase01 implementer or Root integrator. Collector evidence remains sealed.

## Findings, required qualifications and recommendation

**No existing phase01/runtime defect is established by this assessment. No
unconditional contract acceptance is given.** The exact scope messages are
[recorded separately](ROOT-SCOPE-PROPOSALS-01.md); a newly authored normative
Task/supplement remains necessary before implementation.

### Medium-priority future-parser prerequisite: JSON ceilings lack a frozen counting rule

Frozen `PROTOCOL-03.json:270–293` publishes byte/depth/node ceilings, but not root
depth/key counting. Frozen candidate03 `NATIVE-HANDOFF-04.md:66–68` explicitly
leaves that unresolved. The earlier intake `REPORT-01.md:9,61–72` identifies the
same dependency and does not select a convention. Root's proposed root-depth1 /
keys-plus-values rule is implementable as a precise **new technical supplement**;
it cannot be represented as an existing rule silently inferred from properties.
This blocks assigning a JSON parser without the supplement, **not** the proposed
phase02a leaf, which excludes JSON entirely. It is not a new source finding
against the deliberately partial phase01 module.

The concrete acceptance boundary changes: a flat1,024-member object is1,025
value-only nodes but2,049 key-and-value nodes, exceeding2,048. Unknown bounded
native fields are not dispensable budget: count them completely, and refuse the
whole selected input on overflow without stripping, truncating, rebuilding or
rewriting it. Published entry caps are independent maxima, not promises that
every possible object with that entry count fits the node/byte/depth caps.

### Qualified phase02a boundary: successful file intake is not host/ownership admission

`OWNERSHIP-PROPOSAL-03.md:120–183` and Task04 phase paragraphs distinguish snapshot,
driver preboot, hook live and stopped observations. The narrowed **quiescent
snapshot/preboot/stopped-only** reader remains useful: it can turn real bounded
read bytes into the existing immutable `PropertiesObservation`, then support
the existing raw/whole-map binding checks. It does not finish the mandatory
hook/driver **live** comparison. That gap must remain explicit in every future
driver task; no full Task04 admission follows from phase02a.

An owned/quiescent root is a trusted caller precondition, not a predicate proved
by a role enum, lexical containment, zero online players or successful stat.
Pre/open/post checks establish an observation only under the stated quiescent,
ordinary local-copy boundary. They do not prove defense against malicious
concurrent ancestor swaps, hidden same-identity mutation or hostile storage.
Phase02a should never start a host, infer clean stop or grant receipt authority.
This preserves the stronger lifecycle/ownership duties in Task04 and does not
waive them; stronger concurrent/live admission needs its own implementation and
evidence before the complete driver is assigned.

### Existing utilities are reusable patterns, not unchanged drop-ins

The stronger existing repository helper
`scripts/prepare_v002_g0_review_packet.py:1315–1374` already models one limit+1
read and pre/open/post file identity comparison; its ancestor checker is separate
at1377–1396. Independent unaltered-AST controls demonstrate bounded read requests,
overflow/identity/reparse refusal and handle closure. But the generic helper
accepts empty bytes, and its OSError wrapper at1366–1367 retains exception text.
The controls reproduce a crafted `TOKEN=secret` in that generic error. These
are not defects for that utility's unrelated contract; they show why the new
C18 reader must apply properties nonempty validation and fixed no-secret error
mapping rather than importing its behavior unchanged.

Recommendation: Root may author a narrow phase02a task with the clauses below.
The future task must be reviewed by its exact bytes; this report neither adopts
those bytes nor authorizes implementation/source/native/Gates.

## Precise minimal implementation boundary to put in the new Task

Proposed write scope is two new private fixture modules only, for example
`scripts/classic_inventory_fixture_inputs.py` and its matching scoped test file.
These are **proposed names**, not a granted scope expansion. Root freezes exact
names and a committed base containing the exact phase01 module first. The four
candidate03 source/record postimages and all original39 tests remain unchanged.

One possible minimal private signature is
`_observe_quiescent_properties(owned_server_root: Path, role: str) -> PropertiesObservation`.
Do not turn it into a public generic path/authority/receipt API or add a driver
stub. Before freezing a signature, Root must state its exact finite role names:
configured-snapshot selects only
`.classic-inventory-fixture/snapshot-server-properties-v1.txt`; preboot and
stopped select only `server.properties`. No parsed JSON, acknowledgement or
untrusted path field may choose another member. Stage labels alone are not
temporal evidence; the caller supplies the real quiescent lifecycle precondition.

Required source clauses:

1. The caller supplies an independently admitted ordinary own D copy root, not
   an original source server/world. The reader checks its declared bounded
   canonical root / fixed derived child and no-reparse lexical ancestor chain
   **before** following resolution. Containment after `resolve` alone cannot
   prove no link traversal. Root/path byte restrictions must reference existing
   Task04 bounds; no invented generic path-depth or filename policy.
2. Validate required file/ancestors as ordinary and nonreparse. A missing required
   properties/snapshot file, dangling path, directory, inaccessible component or
   inconsistent observation is refusal, not an admissible absent record. This
   leaf makes no decision about optional player records or whole-directory
   ownership. Hardlink/global-adversary security is not silently claimed from
   regular-file checks; copy ownership remains the caller's separate duty.
3. Open read-only; observe pre/open/post descriptor/path identity, type, size and
   reparse state, with one read bounded to16,385 bytes. Reject the overflow byte,
   empty bytes, inconsistent declared/read length and identity/size changes before
   any successful result escapes. Never retry, repair, normalize, create a file,
   seek an alternate path, refresh an ownership decision or leak an open handle.
4. Feed the **exact newly observed bytes** to existing `PropertiesObservation`.
   Hash and decoded map stay separate, with unknown key/value retention and no
   trimming, canonical config identity or default insertion. Failures use fixed
   internal codes without raw secret values, supplied labels or OS exception
   text; a later report layer owns mapping to the unchanged wire failure enum.
5. Quiescence is explicitly limited to configured snapshot, actual prelaunch and
   actual clean-stop caller points. No live-host read, process launch/stop claim,
   CREATE_NEW snapshot/marker/receipt, JSON/NBT, native cache, player files,
   directory scan, Java hook or progression operation is implemented here.
6. Size/loop limits do not imply preemptible OS I/O. Any later driver must retain
   the original shared intake/cohort deadline with before/after observation and
   late-result refusal; it must not reset it per read. Phase02a creates no new
   timeout or retry allowance.

## Root-proposed JSON supplement: necessary exact wording and measured impact

Freeze it as additive, separately versioned test-parser authority. Preserve
the old protocol, historical ambiguity, all published budgets and older reds.
The supplement should state:

- Every JSON document root has depth1 and counts as one node, including a root
  scalar/null. Each object/array/container and scalar value counts once.
- Every decoded object key string counts as one additional node, at the same
  child depth as its member value. An object member value or array element has
  parent depth+1; no extra artificial wrapper/closing-token node is counted.
- Count all retained unknown fields/values under native-document caps. Object
  key strings count even though they are not separate gameplay entries; integer
  digits/string code units are not individual nodes. Duplicate decoded keys
  remain invalid independently of their budget accounting.
- Apply this explicitly to the protocol's external/report/advancement/stats/cache
  JSON caps; it changes neither properties' already-frozen string-node rule nor
  NBT tag/array/end-node convention. Schema field/type/range checks remain separate.
- Reject an impending node/depth overflow before corresponding structural
  allocation/publication; ordinary post-`json.loads` traversal is not that proof.
  Keep the existing raw byte caps. Do not choose new numeric/string/surrogate,
  native unknown-value, JSON byte-framing or NBT admission policies in this
  counting supplement. Those remaining decisions need the later parser task.

Measured independent [structure models](JSON-CONVENTION-MODELS-01.json):

| Structure only | Keys+values nodes / depth | Existing nodes / depth cap |
|---|---:|---:|
| Declared PREFLIGHT row/cardinalities |244 /5|2,048 /8|
|1,000 three-field cache profile objects |7,001 /3|16,384 /8|
|2,048 advancements, one criterion each |16,385 /4|32,768 /16|
|2,048 simple stats values |4,103 /4|16,384 /16|

These are cardinality/structure models, with scalar placeholders—not emitted
native fixtures, fully validated report/receipt schemas, byte-size guarantees
or all-unknown-field compatibility. Unknown/deeper/wider fields can consume the
remaining budget. The selected host must still meet all caps simultaneously;
absence of native host inputs here prevents a universal compatibility verdict.

## Evidence-based tests for the eventual implementation

Phase02a tests should exercise real own-D regular files for nonempty/exact16,384
and+1, descriptor/path identity, file-close-on-refusal and byte/hash ownership;
platform-capable separate reparse/junction/ancestor fixtures need explicit
support/skip qualification. Controlled replacement/resize doubles supplement
but never substitute for actual platform behavior. Cover fixed role selection,
no decoded path control, containment, missing/dangling/dir/nonregular/permission
refusal, fixed no-secret errors, no writes/repair/retry and no progression/host
calls. All original39 tests remain byte-exact and run alongside the new suite.

JSON supplement boundary obligations: root atom/empty object/empty array; nested
object+key depth; depth8/12/16 and+1;2,048 exact nodes/+1;1,023 vs1,024 flat members;
unknown-field overflow with no pruning; each native entry cap concurrently with
its node/depth/byte cap; duplicate/escaped-alias controls. Later actual parser
tests must verify pre-allocation refusal and separate scalar/UTF8/number/schema
rules, not count this report's measuring model as the implemented preflight.

Live transport, authoritative logger freshness, hook/driver hash matching,
CREATE_NEW ownership receipt, JSON/NBT records, gzip/MUTF/type/width preservation,
both players' complete preconstructor admission, listener/reload and actual
clean-stop native proof remain later independently reviewed leaves. Suitable
source host, V1/V2, R-021 and version G0–G9 remain unverified.

## Exact inputs and actual controls

The [input ledger](INPUT-PINS-01.json) binds58 named read inputs before/after,
with0 drift, including required live governance and frozen candidate03 four
postimages. The prior intake's42 named observations remain byte-equal here.
Its12 sealed payloads/sidecar verify0 mismatch; no previous report/helper was
edited or executed in its sealed directory.

Key identities:

- Task04: `3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43`.
- Proposal03 /protocol03: `f1dea84831173ba4e59a77021b5c3ac7e7895ed4f51e60a3658468427a77f4ca` /
  `fc692c32fc3854d80cdbf6ead77fe4c3103925e3a603d68bea43e93504e63edc`.
- Candidate03 production: `dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56`.
- Earlier c17 intake report/manifest: `1751baddcd610a995175fa8651c5482ff20f13b1262eb57ab2eb4ff9d039076e` /
  `074515c3b081efa2ef831e1a7995e8eff0b185206200a2dca8c4417ad43e8944`.
- Generic helper source: `d6639dd9f8654dc905cfdc5b7da4f1583107d4c79050ebe226e2f8c664db6460`.
- Live Root AGENTS is separately authoritative
  `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`;
  no historical Git AGENTS replacement is applied.

Earlier handoff provenance is
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-intake-20261005-16db7a/REPORT-01.md`;
all cited line numbers above refer to exactly pinned text, not a moving HEAD.
The four selected repository source/contract files independently match raw Git
objects at fixed `a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c`:
[actual fixed-object commands/results](FIXED-OBJECT-CONTROLS-01.json).

Actual `python -B checks01.py` first attempt exits1 **before tests** on process
temp-string slash spelling; [original log](checks-01.log) and exit remain.
The unchanged helper's separately captured [second invocation](checks-02.log)
has real12 unittest controls /0FES, exit0,0.010s. It uses unaltered selected AST
from the old repository helper with model file/descriptor inputs and imports
the exact phase01 pure module; no phase02 code is implemented. See
[control receipt](CONTROL-RESULTS-01.json) and [failure qualification](TOOL-OBSERVATIONS-02.md).
The four bounded read-only `git show` controls also exit0/raw-equal.

All subprocess temp variables use only this new own project-parent D leaf and
Python `-B`. No Java/Gradle/native/server/client/network, Root/WT/source/Git
mutation, deletion, original-evidence rewrite or OpenPet occurred. Outputs are
small loose evidence; no new ZIP/whole-source/JAR/world export is made.
