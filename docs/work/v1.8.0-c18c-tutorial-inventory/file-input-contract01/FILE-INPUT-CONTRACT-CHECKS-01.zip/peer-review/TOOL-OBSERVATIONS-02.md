# Read/control failure qualification

1. The initial PowerShell directory command's unsupported `New-Item -LiteralPath`
   and missing-directory error are transcribed in TOOL-OBSERVATION-01.md; its
   outer exit0 did not mean successful directory creation. A separate fail-fast
   literal Directory.CreateDirectory call created only this own D leaf.
2. A read guessed the prior handoff name `INTAKE-FACTS-01.json`. The actual prior
   manifest names `FACTS-01.json`. Get-Content returned missing-file / outer exit1.
   This is a locator error, not a prior contract or control failure. No original
   file was written or renamed.
3. `checks-01.log` / exit1 contain a pre-test TEMP string assertion. PowerShell
   supplied forward slashes while Path.__str__ emitted backslashes. All paths
   pointed to the same new D leaf, but the exact-string setup predicate failed.
   Zero tests ran; no candidate-source failure or PASS is claimed. The helper
   is unchanged. A separately captured invocation used GetFullPath for the
   process-only temp strings; `checks-02.log` / exit0 has actual12/0FES.

No failed record was overwritten. No Java/native/Gradle or source changes occurred.
