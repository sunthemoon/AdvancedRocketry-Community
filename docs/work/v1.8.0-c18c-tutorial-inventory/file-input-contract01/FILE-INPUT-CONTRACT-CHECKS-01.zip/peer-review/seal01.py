from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
pins = json.loads((HERE / 'INPUT-PINS-01.json').read_text(encoding='utf-8'))['files']
drift = []
for row in pins:
    raw = Path(row['path']).read_bytes()
    if (len(raw), sha(raw)) != (row['bytes'], row['sha256']): drift.append(row['path'])
assert not drift, drift
links = []
for filename in ('REVIEW-01.md', 'ROOT-SCOPE-PROPOSALS-01.md', 'TOOL-OBSERVATION-01.md', 'TOOL-OBSERVATIONS-02.md'):
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (HERE / filename).read_text(encoding='utf-8-sig')):
        if '://' in link or link.startswith('#'): continue
        target = HERE / link.split('#', 1)[0]
        assert target.is_file(), (filename, link)
        links.append({'report': filename, 'target': link, 'sha256': sha(target.read_bytes())})
result = {'scope': 'independent technical assessment, not adopted phase02a contract/source/native/Gates',
          'input_count': len(pins), 'final_input_drift': drift,
          'new_report_relative_links': links, 'new_report_link_failures': [],
          'no_archive_full_source_or_official_payload_export': True}
(HERE / 'FINAL-CONTROLS-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
rows = []
for p in sorted(HERE.iterdir()):
    if not p.is_file(): continue
    assert p.name not in ('INTERNAL-MANIFEST-01.json', 'SHA256SUMS.txt'), 'fresh seal only'
    raw = p.read_bytes()
    rows.append({'path': p.name, 'bytes': len(raw), 'sha256': sha(raw)})
manifest = {'scope': result['scope'], 'files': rows, 'payload_count': len(rows), 'payload_bytes': sum(x['bytes'] for x in rows)}
raw = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(HERE / 'INTERNAL-MANIFEST-01.json').write_bytes(raw)
checks = rows + [{'path': 'INTERNAL-MANIFEST-01.json', 'sha256': sha(raw)}]
(HERE / 'SHA256SUMS.txt').write_text(''.join(x['sha256'] + '  ' + x['path'] + '\n' for x in checks), encoding='utf-8')
for row in checks: assert sha((HERE / row['path']).read_bytes()) == row['sha256']
print(json.dumps({'report_sha256': sha((HERE / 'REVIEW-01.md').read_bytes()),
                  'manifest_sha256': sha(raw), 'checksum_sha256': sha((HERE / 'SHA256SUMS.txt').read_bytes()),
                  'payloads': len(rows), 'payload_bytes': manifest['payload_bytes'],
                  'links': len(links), 'drift': []}, indent=2))
