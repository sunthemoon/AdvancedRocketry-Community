﻿# Initial directory setup observation

The initial PowerShell setup used New-Item -LiteralPath, which is unsupported by this cmdlet. It raised parameter-binding and missing-directory WriteAllText errors. The outer command nevertheless returned exit0 because errors were non-terminating. No directory or evidence payload was created by that command. A separate fail-fast command used literal System.IO.Directory.CreateDirectory for the same fresh owned D target. This note transcribes the tool result; it is not a raw stderr file.
