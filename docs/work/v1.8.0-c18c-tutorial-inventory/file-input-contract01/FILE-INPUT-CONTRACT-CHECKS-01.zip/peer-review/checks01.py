"""Independent bounded intake/JSON models; no phase02 implementation or admission."""
from pathlib import Path
from types import SimpleNamespace
import ast
import hashlib
import importlib.util
import json
import os
import re
import stat
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
PRIOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-phase02-intake-20261005-16db7a')
NORM = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-native-proposal03-5bb27f098e')
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18c-native-impl-01-598dc248af/candidate03/postimages')
UTILITY = ROOT / 'scripts/prepare_v002_g0_review_packet.py'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(p):
    raw = p.read_bytes()
    return {'path': p.as_posix(), 'bytes': len(raw), 'sha256': sha(raw)}

assert all(os.environ.get(x) == str(HERE) for x in ('TEMP', 'TMP', 'TMPDIR'))
prior_manifest_raw = (PRIOR / 'INTERNAL-MANIFEST-01.json').read_bytes()
assert sha(prior_manifest_raw) == '074515c3b081efa2ef831e1a7995e8eff0b185206200a2dca8c4417ad43e8944'
prior_manifest = json.loads(prior_manifest_raw)
for row in prior_manifest['files']:
    assert pin(PRIOR / row['path']) == {'path': (PRIOR / row['path']).as_posix(), 'bytes': row['bytes'], 'sha256': row['sha256']}
for line in (PRIOR / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    match = re.fullmatch(r'([0-9a-f]{64})\s+\*?(.+)', line)
    assert match and sha((PRIOR / match[2]).read_bytes()) == match[1]
assert sha((PRIOR / 'REPORT-01.md').read_bytes()) == '1751baddcd610a995175fa8651c5482ff20f13b1262eb57ab2eb4ff9d039076e'

prior_inputs = json.loads((PRIOR / 'INPUTS-01.json').read_text(encoding='utf-8'))['inputs']
paths = [Path(x['path']) for x in prior_inputs]
paths += [PRIOR / row['path'] for row in prior_manifest['files']]
paths += [PRIOR / 'INTERNAL-MANIFEST-01.json', PRIOR / 'SHA256SUMS.txt', UTILITY,
          ROOT / 'scripts/validate_v002_final_g0_review.py']
paths = list(dict.fromkeys(paths))
before = [pin(p) for p in paths]
prior_drift = [dict(old=x, current=pin(Path(x['path']))) for x in prior_inputs if pin(Path(x['path'])) != x]

module_path = AUTHOR / 'scripts/run_v180_classic_inventory_smoke.py'
spec = importlib.util.spec_from_file_location('independent_c18_phase01', module_path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert sha(module_path.read_bytes()) == 'dc5a20767380fe2afebc0ad3ce5418d28e0dc39cc3f503f296957133eade3c56'
protocol = json.loads((NORM / 'PROTOCOL-03.json').read_text(encoding='utf-8'))

def measure(value, include_keys=True):
    """Root depth1; each container/value1; key strings at child/value depth."""
    todo = [(value, 1)]
    count = depth = 0
    while todo:
        v, d = todo.pop()
        count += 1
        depth = max(depth, d)
        if type(v) is dict:
            for k, child in v.items():
                todo.append((child, d + 1))
                if include_keys: todo.append((k, d + 1))
        elif type(v) is list:
            todo.extend((child, d + 1) for child in v)
    return {'nodes': count, 'depth': depth}

class PatternError(ValueError): pass
selected = {'_is_reparse_point', '_stable_file_identity', '_read_bounded_regular_file'}
tree = ast.parse(UTILITY.read_bytes())
defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in selected]
assert {n.name for n in defs} == selected
namespace = {'Path': Path, 'stat': stat, 'os': os, 'PacketError': PatternError}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(UTILITY), 'exec'), namespace)
read_pattern = namespace['_read_bounded_regular_file']
original_fstat = os.fstat

def status(*, mode=stat.S_IFREG | 0o600, size=3, ino=3, attrs=0):
    return SimpleNamespace(st_mode=mode, st_dev=1, st_ino=ino, st_size=size,
                           st_mtime_ns=100, st_file_attributes=attrs)

class FakeStream:
    def __init__(self, raw): self.raw, self.read_calls, self.closed = raw, [], False
    def __enter__(self): return self
    def __exit__(self, *exc): self.closed = True
    def fileno(self): return 99
    def read(self, count): self.read_calls.append(count); return self.raw[:count]

class FakePath:
    def __init__(self, raw=b'a=b', before=None, after=None):
        self.stream = FakeStream(raw)
        self.before = before or status(size=len(raw))
        self.after = after or self.before
        self.lstats = 0
    def lstat(self):
        self.lstats += 1
        return self.before if self.lstats == 1 else self.after
    def open(self, mode):
        assert mode == 'rb'
        return self.stream
    def is_junction(self): return False

observations = []
class IndependentControls(unittest.TestCase):
    def tearDown(self): os.fstat = original_fstat
    def pattern(self, path, opened=None, opened_after=None):
        states = iter((opened or path.before, opened_after or opened or path.before))
        os.fstat = lambda fd: next(states)
        return read_pattern(path, 'test-owned properties', maximum_size=16384)
    def test_exact_limit_pattern_read_is_one_limit_plus_one_request(self):
        path = FakePath(b'#' + b'a' * 16383)
        self.assertEqual(len(self.pattern(path)), 16384)
        self.assertEqual(path.stream.read_calls, [16385])
        self.assertTrue(path.stream.closed)
    def test_declared_overflow_refuses_before_open(self):
        path = FakePath(b'a' * 16385)
        with self.assertRaises(PatternError): self.pattern(path)
        self.assertEqual(path.stream.read_calls, [])
    def test_growth_overflow_refuses_after_bounded_read(self):
        path = FakePath(b'a' * 16385, before=status(size=16384))
        with self.assertRaises(PatternError): self.pattern(path)
        self.assertEqual(path.stream.read_calls, [16385])
        self.assertTrue(path.stream.closed)
    def test_symlink_reparse_and_nonregular_refuse_before_open(self):
        for s in (status(mode=stat.S_IFLNK | 0o600), status(attrs=0x400), status(mode=stat.S_IFDIR | 0o700)):
            with self.subTest(mode=s.st_mode, attrs=s.st_file_attributes):
                path = FakePath(before=s)
                with self.assertRaises(PatternError): self.pattern(path)
                self.assertEqual(path.stream.read_calls, [])
    def test_open_and_after_identity_changes_close_then_refuse(self):
        for where in ('opened', 'opened_after', 'path_after'):
            path = FakePath(after=status(ino=4) if where == 'path_after' else None)
            kwargs = {where: status(ino=4)} if where != 'path_after' else {}
            with self.subTest(where=where), self.assertRaises(PatternError): self.pattern(path, **kwargs)
            self.assertTrue(path.stream.closed)
    def test_generic_pattern_does_not_imply_empty_properties_admission(self):
        path = FakePath(b'')
        raw = self.pattern(path)
        self.assertEqual(raw, b'')
        with self.assertRaises(module.FixtureInputError): module.PropertiesObservation(raw)
    def test_existing_pattern_is_not_fixed_no_secret_error_mapping(self):
        path = FakePath()
        path.open = lambda mode: (_ for _ in ()).throw(PermissionError('TOKEN=secret'))
        with self.assertRaises(PatternError) as caught: self.pattern(path)
        self.assertIn('TOKEN=secret', str(caught.exception))
    def test_pure_phase01_raw_map_and_stopped_bindings(self):
        raw = b'gamemode=adventure\nforce-gamemode=false\nview-distance=2\nsimulation-distance=3\nunknown=k\\=v\n'
        a = module.PropertiesObservation(raw)
        b = module.PropertiesObservation(b'# date\r\n' + raw.replace(b'\n', b'\r\n'))
        module.require_logical_equality(a, b)
        self.assertNotEqual(a.sha256, b.sha256)
        module.require_boot_binding('seed', a, a, a.sha256)
        module.require_boot_binding('reload', a, b, b.sha256, seed_stopped=b)
        with self.assertRaises(module.FixtureInputError): module.require_stopped_binding(a, b)
        with self.assertRaises(TypeError): a.values['unknown'] = 'changed'
    def test_root_container_key_value_counting_boundaries(self):
        self.assertEqual(measure(None), {'nodes': 1, 'depth': 1})
        self.assertEqual(measure({}), {'nodes': 1, 'depth': 1})
        self.assertEqual(measure({'x': None}), {'nodes': 3, 'depth': 2})
        self.assertEqual(measure([None]), {'nodes': 2, 'depth': 2})
        self.assertEqual(measure({'x': {'y': 0}}), {'nodes': 5, 'depth': 3})
    def test_2048_node_exact_and_overflow_do_not_change_entry_cap(self):
        self.assertEqual(measure({str(i): None for i in range(1023)})['nodes'], 2047)
        self.assertEqual(measure({str(i): None for i in range(1024)})['nodes'], 2049)
        self.assertEqual(measure({str(i): None for i in range(1024)}, False)['nodes'], 1025)
        self.assertEqual(measure([None] * 2047)['nodes'], 2048)
        self.assertEqual(measure([None] * 2048)['nodes'], 2049)
    def test_depth_root_one_boundary(self):
        for cap in (8, 12, 16):
            at = None
            for _ in range(cap - 1): at = [at]
            self.assertEqual(measure(at)['depth'], cap)
            self.assertEqual(measure([at])['depth'], cap + 1)
    def test_unknown_field_inclusion_not_silent_pruning(self):
        base = {str(i): 0 for i in range(1023)}
        self.assertEqual(measure(base)['nodes'], 2047)
        with_unknown = {**base, 'unknown': 0}
        self.assertGreater(measure(with_unknown)['nodes'], 2048)
        self.assertEqual(len(with_unknown), 1024)

def models():
    # Shape-only scalar placeholders do not claim schema-valid/native samples.
    preflight = {k: None for k in protocol['payload_schemas']['PREFLIGHT']}
    host = {k: None for k in protocol['payload_schemas']['PREFLIGHT']['host_admission']}
    host['properties'] = {k: None for k in protocol['payload_schemas']['PREFLIGHT']['host_admission']['properties']}
    host['raw_spawn'] = [0] * 3
    host['shared_spawn'] = [0] * 3
    host['loaded_envelope'] = [0] * 4
    host['player_dimensions_bits'] = [''] * 2
    host['forced_target_membership'] = [True] * 121
    preflight['host_admission'] = host
    preflight['identities'] = [{k: None for k in ('role', 'uuid', 'name')} for _ in range(2)]
    preflight['file_presence'] = [False] * 8
    preflight['profile_map_counts'] = [0, 0]
    preflight['native_progress_cache_counts'] = [0, 0]
    row = {k: None for k in protocol['common_fields']}
    row['payload'] = preflight
    cache = [{'name': 'profile', 'uuid': 'uuid', 'expiresOn': 'date'} for _ in range(1000)]
    advancements = {str(i): {'criteria': {'has_inventory': 'date'}, 'done': True} for i in range(2048)}
    stats = {'stats': {'minecraft:custom': {str(i): 1 for i in range(2048)}}, 'DataVersion': 3465}
    results = {name: {'keys_values': measure(value), 'values_only': measure(value, False)} for name, value in
        (('PREFLIGHT_declared_structure', row), ('vanilla_shaped_usercache1000', cache),
         ('advancement2048_one_criterion_each', advancements), ('stats2048_simple_values', stats))}
    results['qualification'] = 'Structural models only; no native fixtures, schema parser or host eligibility. Byte/string/cardinality ceilings remain independent; unknown fields counted fully or document refused, not discarded.'
    return results

suite = unittest.defaultTestLoader.loadTestsFromTestCase(IndependentControls)
result = unittest.TextTestRunner(verbosity=2).run(suite)
after = [pin(p) for p in paths]
assert before == after, 'named input drift during controls'
(HERE / 'INPUT-PINS-01.json').write_text(json.dumps({'files': before, 'prior_intake_input_drift': prior_drift}, indent=2) + '\n', encoding='utf-8')
(HERE / 'JSON-CONVENTION-MODELS-01.json').write_text(json.dumps(models(), indent=2) + '\n', encoding='utf-8')
(HERE / 'CONTROL-RESULTS-01.json').write_text(json.dumps({'tests': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'prior_manifest_payloads_verified': len(prior_manifest['files']), 'prior_checksum_verified': True,
    'named_input_count': len(paths), 'input_pre_post_drift': [],
    'extracted_helper': {'source': str(UTILITY), 'sha256': sha(UTILITY.read_bytes()), 'functions': sorted(selected), 'unaltered_ast': True},
    'scope': 'specification/property/existing utility models; no phase02 source or native/FS race-proof'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': result.testsRun, 'FES': [len(result.failures), len(result.errors), len(result.skipped)], 'named_inputs': len(paths), 'pre_post_drift': []}))
raise SystemExit(not result.wasSuccessful())
