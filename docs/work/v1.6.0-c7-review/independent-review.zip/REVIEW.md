# C7 independent review — v1.6 satellites (C7a–C7c) and ADR-049 revision 4

Reviewer: independent read-only review agent. Date: 2026-10-01.
Reviewed range: `2752776..bbc0f53` on `codex/v1.6.0-satellite-resource-missions`
(commits `4b744c8` C7a, `7e736b5` C7b, `bbc0f53` C7c).

## 1. Scope and method

- Tree extracted with `git archive bbc0f53` into `tree/` (this directory). All
  file:line references below are relative to
  `tree/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless a
  path starts with `docs/` or `src/`.
- Read: `AGENTS.md`; ADR-049 (rev 3 + proposed rev 4), ADR-050 (§2, §3, §9–§11),
  ADR-051 (§6–§7 where C7 prepares epochs); the three C7 `VERIFICATION.md` files
  and `docs/work/v1.6.0-implementation-log.md`.
- Read in full: the satellite model (`model/*`), registry and records
  (`mission/SatelliteMissionRegistry`, `MissionState`, `MissionPayload`,
  `AsteroidInstance`, `RewardEntry`, `MissionQuarantine`), persistence
  (`SatelliteNbtCodec`, `SatelliteRegistryPayload`, `SatelliteMissionSavedData`,
  `AtomicSavedData`, `ManagedSavedDataType`, `SavedDataSchemaMigrator`,
  pre-start `WorldDataMigrationService`/`ManagedSavedDataPayloadValidator`),
  item identity (`content/*`), services (`SatelliteManager`,
  `SatelliteKindLifecycle`, `SatelliteRuntime`, `SolarLinks`,
  `ReceiverDirectory`, catalog and reload listeners), builder (`builder/*`),
  receiver (`receiver/*`), scan (`scan/*`), network (`network/*`), terminal diff
  and terminal block entity/menu/inventory, commands diff, config, client
  screens/events, the protocol pin table, DataGen outputs, and the new unit and
  GameTests.
- Vanilla/Forge behaviour that findings depend on was confirmed by `javap` on the
  mapped Forge 1.20.1-47.4.10 jar: `ServerGamePacketListenerImpl.handleContainerButtonClick`
  and `handleContainerClick` call `broadcastChanges()`; `ServerPlayer.tick()` calls it;
  `LevelChunk$BoundTickingBlockEntity.tick()` throws `ReportedException` unless
  `removeErroringBlockEntities` is enabled; `ClientboundContainerSetDataPacket`
  writes values with `writeShort`.
- Ran (in `tree/`, JDK 17.0.7, log `gradle-test.log`):
  `./gradlew test --tests '*Satellite*' --tests '*SurveyScan*' --tests '*NetworkProtocolPin*' --offline --no-daemon`
  → BUILD SUCCESSFUL, 23 suites / 76 tests, 0 failures, 0 errors. GameTests were not run.
- Nothing in the repository was modified; the untracked
  `AdvancedRocketry-Community-v1plus-Development-Docs/` was not opened.

## 2. Findings

Severity counts: Critical 0, High 1, Medium 5, Low 12.

### Critical

None found.

### High

#### C7-H1 — A non-`data` launch replay consumes the package without the registry barrier flush

- Where: `satellite/service/SatelliteKindLifecycle.java:53-62` (early
  `IDEMPOTENT` return), used by `satellite/terminal/SatelliteTerminalBlockEntity.java:243-246`
  (package extracted on `result.success()`, which includes `IDEMPOTENT`).
  Compare the `data` path, `satellite/service/SatelliteManager.java:141-143`, which
  flushes on `result.changed() || data.isDirty()` even for an `IDEMPOTENT` replay.
- Scenario: (1) a survey/solar/miner package is launched; `data.launchIdle`
  registers the satellite in memory, then `data.flush(server)` throws (disk full,
  the registry file locked by an antivirus/backup tool so the atomic move fails, the
  read-back mismatch the project already failure-injects for `data` launches). The
  result is `UNSUPPORTED_DATA`, the package stays — as ADR-049 §6 requires.
  (2) The player presses Launch again. `existing != null` returns `IDEMPOTENT`
  immediately, **with no flush**, and the terminal extracts the package. (3) The
  registry is still not durable; the terminal chunk is saved by autosave or unload
  (chunk writes succeed while the registry move keeps failing), then the server
  stops or crashes. After restart the satellite is absent and the package is gone:
  the components are lost and the chip is bound to nothing. ADR-049 §6 states
  that this reverse order "cannot happen"; ADR-050 §2 requires the barrier before
  every extraction.
- Fix: in the replay branch do what the `data` path does — if `data.isDirty()`,
  `data.flush(server)` before returning `IDEMPOTENT`, and let a flush failure
  return an error so the package stays. Add a failure-injection GameTest for the
  non-`data` path: fail the first flush, replay, and assert that the package is kept
  until a flush succeeds.

### Medium

#### C7-M1 — A loaded Microwave Receiver crashes the server when the registry is blocked

- Where: `satellite/service/SolarLinks.java:82` (`check`) and `:110` (`release`) call
  `SatelliteMissionSavedData.linkedTo`, which starts with `requireOperational()`
  (`satellite/persistence/SatelliteMissionSavedData.java:164-167`). Callers:
  `satellite/receiver/MicrowaveReceiverBlockEntity.java:90-92,104` (block entity tick)
  and `satellite/receiver/MicrowaveReceiverBlock.java:95` (`onRemove`). No
  try/catch on the path (`SatelliteRuntime.checkReceiver`, `SatelliteManager.checkReceiver`).
- Scenario: the registry loads non-operational (the fail-closed state that ADR-050
  §9 and the ADR-051 §7 table "Registry not operational (blocked)" model). The loop
  over chips is safe (`satellite()` returns empty), but `linkedTo` then throws
  `IllegalStateException` on every receiver's 20-tick check, even with empty slots.
  With Forge's default `removeErroringBlockEntities=false`, the block-entity tick
  turns this into a `ReportedException` and the server crashes, and it crashes again
  whenever that chunk loads. Breaking a receiver throws inside `onRemove` after the
  chunk section has changed and before `super.onRemove`, which leaves the block entity
  (and its chips) orphaned. Every other C7 path tolerates a blocked registry.
  The pre-start validator refuses non-operational files, so this is rare today,
  but it is a latent crash on the path that is meant to fail closed.
- Fix: in `SolarLinks.check` and `release`, return `ReceiverCheck(all UNAVAILABLE, 0)`
  and do nothing when `!data.operational()`, and catch `RuntimeException` around the
  receiver check. Add a test with a blocked registry and a loaded receiver.

#### C7-M2 — The terminal-view pacing counts `broadcastChanges()` calls, not ticks

- Where: `satellite/terminal/SatelliteTerminalViews.java:37-48`, called from
  `satellite/terminal/SatelliteTerminalMenu.java:115-121`.
- Scenario: vanilla calls `broadcastChanges()` once per tick in `ServerPlayer.tick`,
  **and also** after every successful `clickMenuButton` and every container click.
  With no selection-intent rate limit yet (deferred to C8a), a modified client
  sends many `ServerboundContainerButtonClickPacket(BUTTON_NEXT)` per tick. Each one
  changes the selection, so every fifth call composes and sends a new view. For each
  3-byte button packet the server composes views, and it sends one view (≤ 12 KiB
  after C8b) per five inbound packets. ADR-049 §10 bounds this at "at most once per
  5 ticks per player", and the C7b verification claims that bound. It is not
  enforced, and no test exercises the pacing: the GameTest calls `compose` directly.
- Fix: pace on server time (store `lastComposeTick = server.getTickCount()` and
  compose only when `now - last >= 5`, remembering a pending change). Add a test
  that calls `broadcastChanges()` many times in one tick and asserts at most one
  send.

#### C7-M3 — The survey-scan tick is unguarded, and a long biome ID makes it throw

- Where: `satellite/service/SatelliteManager.java:85` (`scans.tick(server)` sits
  outside the scheduler's try/catch); `satellite/scan/SurveyScanService.java:138`;
  `satellite/scan/SurveyScanJob.java:163`; the constructor bound is at
  `satellite/network/SurveyScanResultPacket.java:33`.
- Scenario: a datapack or mod biome whose ID is longer than 128 characters dominates
  a scanned cell. `SurveyScanJob.result()` adds it to the palette, and the packet
  constructor throws `IllegalArgumentException`. The exception leaves the
  `ServerTickEvent` handler, and the server crashes. The same applies to any other
  unexpected runtime exception in `step`, `result` or `send`. Scans are
  player-triggered, so the crash can be repeated on demand.
- Fix: map a biome ID longer than 128 characters to `OTHER` when building the
  palette. Wrap `scans.tick` (or each job's step) in a try/catch that drops the job
  and logs it once. Add a unit test with an over-long biome ID.

#### C7-M4 — Important behaviour is untested, and some tests pass whether or not the ordering is right

- A failed barrier flush followed by a replay is untested for non-`data` launches
  (C7-H1).
- A blocked registry is not tested with receivers, scans, the builder's research
  gate or `blank-chip` (C7-M1, C7-L1).
- The barrier-before-extraction order is asserted only as `!data.isDirty()` after
  the button press (`gametest/SatelliteKindTerminalGameTests.java:80`, `:172`).
  That assertion passes even if the package were extracted before the flush, or
  if the flush happened on a later path. A committer or flush hook that records the
  inventory state at flush time would test the order.
- The menu-level intent checks are untested. The GameTests call
  `handleButton`/`assemble` directly, so `stillValid`, the catalog-generation
  check and view pacing through `broadcastChanges` never run.
- The survey scan in a real Level is untested: no `UNKNOWN` cell from an unloaded
  chunk, no assertion that the scan loads no chunk and adds no ticket (ADR-049
  Verification A1 "zero chunk tickets"), and the production `SatelliteManager`
  tick path and the chip `use()` path are not exercised (the GameTest builds its
  own `SurveyScanService`).
- The builder refusals `OUTPUT_BLOCKED` and `DEFINITION_NOT_FOUND` are not
  exercised, although the C7b verification says "the refusal sequence" is.
- Fix: add the tests listed under each finding, plus an unloaded-chunk scan
  GameTest that asserts the chunk-ticket count is unchanged.

#### C7-M5 — Normative deviations from the accepted contracts are recorded only in verification notes

ADR-049 rev 3 and ADR-050 rev 3 are frozen ("Later changes need a new revision and
review"). These behaviours differ from their text but are recorded only in
`docs/work/v1.6.0-c7a-model/VERIFICATION.md` or not at all:

1. **Save epoch** (ADR-050 §2 says every flush or save writes E + 1): the code writes
   E + 1 only after a change (`satellite/mission/SatelliteMissionRegistry.java:607-623`,
   `satellite/persistence/SatelliteMissionSavedData.java:278,298-302`). I checked
   it against ADR-051 §6–§7 (`save_epoch > start_epoch`, `ack_epoch < E`), and
   both rules still hold because every start and acknowledgement sets the changed
   flag. It is sound, but it must be written into ADR-050.
2. **Counters are not persisted**, although ADR-050 §10 says root 3 "adds … the
   counters". Deriving them on load is better, but the frozen root-3 shape
   changed.
3. **`target_body` is required** in the mission codec
   (`satellite/persistence/SatelliteNbtCodec.java:138`), but ADR-050 §3 lists it
   as optional. C7 claims that every root-3 shape is complete, so C8b must either
   always supply a target body for asteroid missions or change the codec. Decide
   and record which.
4. **Operator decommission**: `SatelliteKindLifecycle.decommission` and the
   registry accept operators. ADR-049 §7 names only the owner.
5. **Launch failure codes**: besides §6's `COMPONENT_UNAVAILABLE`, `STAT_LIMIT` and
   `REQUIREMENT_UNMET`, a launch can also return `INVALID_COMPONENTS` (a role
   changed), `TARGET_NOT_ALLOWED`, `DEFINITION_NOT_FOUND`, `RESEARCH_LOCKED`,
   `OWNER_LIMIT` and `CAPACITY_REACHED`.
6. **Rate limits**: the ADR-049 §10 per-player intent limits (10 and 2 ticks) are
   not implemented for the new `DECOMMISSION`/`UNLINK` intents. They are deferred
   to C8a in the verification notes but not in the ADR.

- Fix: fold items 1–5 into ADR-050 revision 4 and the ADR-049 revision-4 text
  before C7 closes. Record item 6 as a C8a obligation in the ADR, and keep the
  version `IN PROGRESS` until it lands.

### Low

- **C7-L1 — The `blank-chip` guard can be bypassed.**
  `satellite/command/SatelliteCommands.java:194-204` checks "still registered"
  with `satellite()`, which returns empty when the registry is blocked. The command
  therefore blanks chips of registered satellites in that state. It also blanks
  `FUTURE`/`INVALID` chips without trying to read the raw `satellite_id`, and it
  logs `satellite=unreadable`, which loses the ID that `recover-chip` needs.
  Fix: refuse when `!operational()`; for undecodable chips, read and log the raw
  UUID if present, and refuse when that UUID is registered.
- **C7-L2 — The component catalog is never cleared.**
  `SatelliteComponentReloadListener.Manager` (`AdvancedRocketryCommunity.java:101-102`)
  is never cleared in `onServerStopped` (`:340-362`), although its javadoc
  (`satellite/service/SatelliteComponentReloadListener.java:61`) says "cleared on
  stop". On an integrated server, an invalid component set in a second world keeps
  the previous world's catalog instead of failing the first load, which ADR-049 §2
  requires. Fix: clear it on stop.
- **C7-L3 — The builder preview's data stat is truncated.**
  `satellite/builder/SatelliteBuilderMenu.java:223` sends the `data` stat raw, but
  container data travels as a 16-bit short. Values above 32,767 are legal (up to
  100,000), wrap negative, and make `previewStats()` (`:170-178`) drop the whole
  preview. Fix: split it into two halves, as the battery stat already is.
- **C7-L4 — Launch does not re-check the definition of the primary component.**
  Launch (`satellite/service/SatelliteKindLifecycle.java:67-80`) looks up the
  definition by the ID on the item. It does not check that the identity's primary
  component still selects that definition (`kindDefinitionForPrimary`), so after a
  datapack change the satellite launches under a definition with another primary.
  Fix: re-check the mapping, refuse with `DEFINITION_NOT_FOUND`, and keep the
  package.
- **C7-L5 — A refused decommission can still run a barrier flush.**
  `satellite/service/SatelliteKindLifecycle.java:143` flushes on
  `result.changed() || data.isDirty()`, including refusals (for example an inert
  chip that returns `SATELLITE_NOT_FOUND`). With no intent rate limit yet, repeated
  clicks force a full synchronous registry write whenever anything else dirtied the
  registry. The button also has no confirmation for an irreversible action. Fix:
  flush only on `changed()`, and rate-limit or confirm in the UI.
- **C7-L6 — The target selection carries over between chips.** The terminal keeps
  its persisted target index across chips (`satellite/terminal/SatelliteTerminalBlockEntity.java:153,389`).
  A newly inserted non-`data` chip therefore inherits whatever index was selected,
  and its orbit body is fixed for life. The GameTest had to be reordered because of
  this. Fix: reset the index when the selected definition changes, or persist the
  selection per definition.
- **C7-L7 — Some result codes are ambiguous.** `MISSION_BUSY` is reused for "linked
  to a present or unknown receiver"
  (`satellite/mission/SatelliteMissionRegistry.java:281`,
  `satellite/service/SolarLinks.java:140`), so the owner cannot tell a running
  mission from a receiver link. Unlinking a non-solar satellite answers
  `IDEMPOTENT` (`SolarLinks.java:136`).
- **C7-L8 — Class size and layering.** `SatelliteTerminalBlockEntity` has 700 lines,
  `SatelliteMissionRegistry` 680 (+217 in C7, although the log's class-size plan
  says it "must not absorb the new work"), `SatelliteManager` 626,
  `SatelliteNbtCodec` 559 and `SatelliteBuilderBlockEntity` 513, all above the
  AGENTS §3.4 review threshold. On layering, the pure `SurveyScanJob` returns the
  network DTO `SurveyScanResultPacket`, and `SurveyScanService` sends packets
  itself (domain → network). Naming and dead code: the generic package reuses
  `DataSatellitePackageItem`, and `SatelliteKind.launchesIdle()` is unused.
- **C7-L9 — Builder and receiver roots skip the slot checks.**
  `SatelliteBuilderInventory.loadValidated` and
  `MicrowaveReceiverInventory.loadValidated` do not re-apply the slot rules; the
  terminal does, except for slot 2. For example, a receiver root that holds any
  registered item with count 1 loads. Assembly and the chip filter re-check, so
  this is benign, but it is inconsistent with the ADR-029 preflight style.
- **C7-L10 — The scan duration assumes a 384-block Level.** The ADR/verification
  figure of about 216 ticks for a worst-case scan holds only for a 384-high Level.
  A 4,064-high datapack dimension takes about 2,300 ticks; the per-tick budget still
  holds. Document it, or cap the scanned height.
- **C7-L11 — Automation can insert chips into the builder.** Automation can insert
  blank chips into builder slot 8
  (`satellite/builder/SatelliteBuilderInventory.java:63-66`). ADR-049 §5 allows
  automation to insert only matching components (and rev 4 adds redstone). This is
  harmless, but either state it or forbid it.
- **C7-L12 — Operator unlink and receiver access need documenting.** An operator
  `unlink` of a link held by a present receiver is undone by that receiver's next
  check, or taken by a copied chip in another receiver whose check runs first.
  Receivers also have no access control: any player can take chips from another
  player's receiver, as with a chest. Document the intended use of operator unlink.

Informational (no action required): the satellite channel stays at protocol `1`
while message index 1 was added between C7b and C7c. This is acceptable because
v1.6 is unreleased and ADR-049 §10 defines both messages under protocol 1. No
`net.minecraft.client.*` import was found outside `client/`. No new textures were
added; item models reference vanilla parents only.

### Checked and found correct

- Builder assembly consumes exactly one item per filled slot (slot limit 1) plus
  1,000 FE. Chips stack to 1. The output slot cannot be inserted into.
  Automation extracts only slot 9, and a blocked root refuses all item and energy
  transfer.
- The builder refusal order matches ADR-049 §4. The menu is bound to the block
  entity, the catalog generation and the 8-block range; the intent carries no data.
- Data launches keep the barrier and the `IDEMPOTENT` replay. The item identity
  keeps schema 1 for `data` and uses schema 2 otherwise. Launch re-derives stats from
  the current catalog and snapshots the kind parameters.
- Decommission blanks the chip only after a successful flush; the owner and link
  checks are in the registry. The owner count and link index are updated on every
  mutation and rebuilt on restore.
- Root 3 decoding is strict about kinds and payload keys. The upgrade copies
  records and keeps extra tags. The pre-start migration validates, backs up and
  stages. The over-cap legacy root loads. Record bounds are pinned by tests.
- The scan reads only `getChunkNow` chunks, a cell with an unloaded column becomes
  `UNKNOWN`, and nothing is paid before the last check. Scan limits cannot be
  configured past their maxima.
- A receiver keeps its link against a copied chip, releases links when broken,
  treats a receiver as missing only when that is confirmed, keeps its buffer
  output-only, and produces nothing while unloaded.
- Both new S2C packets decode strictly (size, trailing bytes, presence bytes,
  enums, counts) and are handled on the client main thread. The protocol pin table
  is updated.

## 3. ADR-049 revision-4 verdicts

| # | Item | Verdict | Reasons |
|---|---|---|---|
| 1 | Builder redstone charge slot (slot 10, 11-slot root) | **Accept** | The mod has no FE generator, and the rule mirrors the terminal (2,000 FE per item, 10,000 cap); automation rules are sound. Add to the text that automation may also insert blank chips into slot 8, or forbid it (C7-L11). |
| 2 | Terminal view carries the selected kind and orbit body; 8,405 B worst case | **Accept with changes** | The contents and bound are fine. The text must say that the kind comes from the chip (`data` when the chip slot is empty), and the "once per 5 ticks" pacing must be measured in server ticks, not menu broadcasts (C7-M2). |
| 3 | `blank-chip <player>` (level 2, audit line), refused for registered satellites; kind-aware `recover-chip` | **Accept with changes** | The design is right, but the stated guarantee ("an operator cannot strand a live satellite") fails when the registry is blocked and for FUTURE/INVALID chips. Refuse in both cases, or log the raw `satellite_id` (C7-L1). |
| 4 | `DEFINITION_NOT_FOUND` for a data-mission start with a non-`data` chip | **Accept** | It reuses an existing code, adds no new state, and resource starts come with ADR-051. |
| 5 | Scan request codes and their order; nothing paid before the last check; no refund on cancel | **Accept** | The code follows the order. The initial kind check cannot be reached from the item path (the item filters on survey), and a record-owner mismatch in `payScan` can only occur with forged chips. |
| 6 | Scan reading rules, palette/`OTHER`/`UNKNOWN`, 3,819 B maximum, COMMON-config limits | **Accept with changes** | Define what happens to a biome ID longer than 128 characters (map it to `OTHER`) so the result cannot throw (C7-M3). Record that the limits are COMMON config, not the "server config" of §8, and that the scan duration scales with Level height (C7-L10). |
| 7 | Receiver link rules, the "missing" definition, operator unlink, `UNLINK` button 7 | **Accept with changes** | The rules are sound and correctly implemented for an operational registry. Add the behaviour for a blocked registry (no exception, output 0, links untouched) (C7-M1). State that `MISSION_BUSY` is reused, or add a code (C7-L7). Record that a receiver not seen since start needs an operator (an intended trade-off). |

## 4. Overall verdict

**Accept with required changes.**

Required before C7 closes:

1. Fix C7-H1 and add its failure-injection test.
2. Fix C7-M1, C7-M2 and C7-M3, each with a test.
3. Add the missing tests in C7-M4.
4. Record the contract deviations in C7-M5 as ADR-050 revision 4 and ADR-049
   revision 4, with the changes above.

The Low findings may be scheduled into C8a/C8b, but C7-L1, C7-L2 and C7-L3 are
cheap and are best fixed together with the required changes. No Gate, candidate or
tag should be created on the basis of this review.
