"""Archive observed discovery checks; preserve failed and successful attempts separately."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/work/v1.4.0-discovery'
BASE = 'e810fb390dd30dbaa4506a59bffee00b1c78083b'
PRIOR = TEMP.parent / 'arce-v140-sky-8bdcd66a68c54fefadc350434c25b4fb/artifacts'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def bundle(name, groups):
    entries = []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            assert not path.is_symlink(), path
            if path.is_file():
                relative = path.relative_to(source).as_posix() if source.is_dir() else path.name
                entries.append((prefix + '/' + relative if prefix else relative, path))
    entries.sort()
    assert len(entries) == len({key for key, _ in entries})
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in entries:
            data = path.read_bytes()
            archive.writestr(key, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)


def junit(folder):
    suites = [ET.parse(path).getroot() for path in sorted((TEMP / folder).glob('*.xml'))]
    assert suites, folder
    return {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
                                  for key in ('tests', 'failures', 'errors', 'skipped')}}


def archive(reviews):
    groups = [('', path) for path in sorted(TEMP.glob('*.log'))]
    groups += [('', TEMP / 'archive_evidence.py')]
    groups += [(path.name, path) for path in sorted(TEMP.iterdir()) if path.is_dir()
               and (path.name.endswith('-xml') or path.name.endswith('-gametest-logs'))]
    bundle('root-checks', groups)
    bundle('failed-world', [('', TEMP / 'clean-all-03-failed-world')])
    bundle('native-failed', [('evidence', TEMP / 'native'), ('world', TEMP / 'server-native/world')])
    bundle('native-restart', [('', TEMP / 'native-02')])
    native = json.loads((TEMP / 'native-02/summary.json').read_text(encoding='utf-8'))
    assert native['result'] == 'PASS' and native['research_unlocks'] and len(native['research']) == 3
    write('native-summary.json', native)
    bundle('independent-review', [(path.name, path) for path in reviews])
    result = junit('all-reused-04-xml')
    assert result['tests'] == 898 and result['failures'] == result['errors'] == result['skipped'] == 0
    log = (TEMP / 'all-reused-04.log').read_text(encoding='utf-8')
    assert 'BUILD SUCCESSFUL' in log and '> Task :test\n' in log
    required = re.findall(r'All (\d+) required tests passed', log)
    assert required and int(required[-1]) == 235
    write('root-checks.json', {
        'base_commit': BASE, 'junit': result, 'required_gametests_passed': 235,
        'command': 'gradlew.bat build runData runGameTestServer --console=plain',
        'exit_code': 0, 'duration': re.findall(r'BUILD SUCCESSFUL in (.+)', log)[-1],
        'all_junit_attempts': {path.name: junit(path.name) for path in sorted(TEMP.glob('*-xml'))},
        'final_clean_build': {'log': 'clean-final-05.log', 'unit_execution': 'FROM-CACHE', 'exit_code': 0},
        'failed_gametest_attempt': {'log': 'clean-all-03.log', 'required': 235, 'failed': 3, 'archive': 'failed-world.zip'},
        'scope': 'Short development checks, not real-client/GPU/load/release acceptance'})
    artifacts = []
    for path in sorted((TEMP / 'artifacts-final').glob('*.jar')):
        data = path.read_bytes()
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': sha(data)})
        assert data == (ROOT / 'build/libs' / path.name).read_bytes(), path
    assert len(artifacts) == 3
    api = next(path for path in (TEMP / 'artifacts-final').glob('*-api.jar'))
    assert api.read_bytes() == (PRIOR / api.name).read_bytes()
    write('development-artifacts.json', {'artifacts': artifacts, 'public_api_unchanged': True, 'api_version': '1.7'})
    resources = ROOT / 'src/generated/v1.4/resources'
    rows = []
    with zipfile.ZipFile(TEMP / 'artifacts-final/advancedrocketry-community-1.20.1-1.4.0-dev.jar') as jar:
        assert len(jar.namelist()) == len(set(jar.namelist()))
        for path in sorted(resources.rglob('*.json')):
            if '.cache' in path.parts:
                continue
            data = path.read_bytes()
            entry = path.relative_to(resources).as_posix()
            assert jar.read(entry) == data, entry
            rows.append({'path': path.relative_to(ROOT).as_posix(), 'jar_entry': entry, 'bytes': len(data), 'sha256': sha(data)})
    assert len(rows) == 34
    name = 'data/advancedrocketrycommunity/satellite_definitions/data_satellite.json'
    with zipfile.ZipFile(TEMP / 'artifacts-final/advancedrocketry-community-1.20.1-1.4.0-dev-sources.jar') as sources:
        assert sources.namelist().count(name) == 1
        assert sources.read(name) == (resources / name).read_bytes()
    write('generated-resources.json', rows)
    print('PASS: root/native/review archives, test counts and artifact packaging')


def finalize():
    for name in ('SHA256SUMS.txt', 'links.json'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii', newline='\n')
    files = git('diff', '--cached', '--name-only', BASE).decode().splitlines()
    rows, documents = [], []
    for relative in files:
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if relative.endswith('.md'):
            documents.append(relative)
        if relative.startswith('docs/work/v1.4.0-discovery/'):
            continue
        staged, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
        assert staged == working.replace(b'\r\n', b'\n'), relative
        rows.append({'path': relative, 'bytes': len(staged), 'sha256': sha(staged), 'working_sha256': sha(working),
                     'git_blob': git('rev-parse', ':' + relative).decode().strip()})
    write('source-identity.json', {'base_commit': BASE, 'files': rows,
          'scope': 'Changed staged inputs outside evidence; raw digests identify executed worktree inputs'})
    links = []
    for relative in documents:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
            assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
            links.append({'document': relative, 'target': target, 'exists': True})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets, not URLs/anchors', 'links': links})
    for listing in OUT.glob('*-files.json'):
        with zipfile.ZipFile(listing.with_name(listing.name.replace('-files.json', '.zip'))) as archive:
            assert archive.testzip() is None
            expected = json.loads(listing.read_text(encoding='utf-8'))
            assert set(archive.namelist()) == {row['path'] for row in expected}
            for row in expected:
                data = archive.read(row['path'])
                assert len(data) == row['bytes'] and sha(data) == row['sha256']
    members = sorted(path for path in OUT.iterdir() if path.is_file() and path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(path.read_bytes())}  {path.name}\n' for path in members), encoding='ascii', newline='\n')
    print(f'PASS: {len(links)} local links and {len(members)} evidence members')


def check_index():
    for path in OUT.iterdir():
        if path.is_file():
            assert git('show', ':' + path.relative_to(ROOT).as_posix()) == path.read_bytes(), path
    for line in (OUT / 'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
        digest, relative = line.split('  ', 1)
        assert sha((OUT / relative).read_bytes()) == digest, relative
    print('PASS: staged evidence bytes and complete checksum manifest')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, action='append')
    parser.add_argument('--finalize', action='store_true')
    parser.add_argument('--check-index', action='store_true')
    args = parser.parse_args()
    if args.review:
        archive(args.review)
    if args.finalize:
        finalize()
    if args.check_index:
        check_index()
