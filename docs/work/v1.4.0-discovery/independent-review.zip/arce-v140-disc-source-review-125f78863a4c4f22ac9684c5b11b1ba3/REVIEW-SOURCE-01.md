# V140-DISC independent implementation source review 01

Baseline: `e810fb390dd30dbaa4506a59bffee00b1c78083b`, branch `codex/v1.4.0-planetary-expansion`. This is an evolving-source read-only pass before the delegated execution window. Root owns edits and concurrent Gradle. No test/build/native result is supplied by this report.

## Findings

### P2 — Initialization failure can bypass new GameTest cleanup

[PlanetaryDiscoveryGameTests.java:52-64](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/PlanetaryDiscoveryGameTests.java#L52) creates a local manager and both rocket entities before the cleanup closure and its protected `try` at line 65. If the second assembly or subsequent setup throws, the first successfully spawned rocket is never discarded and the local manager is not cleared. Later assertion paths are protected, but this partial-initialization case is not. Batch progress restoration only restores SavedData, not these resources. This is a fixture isolation issue, not evidence of a production failure.

Minimal correction: hold owned resources in a small test fixture or nullable locals and enter the protected setup before the first allocation; clean the successfully created subset on setup failure as well as the asynchronous final callback. Do not globally clear other rockets or journals. The helper at `RocketFlightGameTestFixtures.java:58-83` can throw assertions during assembly/lookup, making the partial setup trigger concrete.

### P2 — Initial native research oracle does not bind definition and captured duration

[run_v140_planetary_worlds_smoke.py:234-270](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_planetary_worlds_smoke.py#L234) checks top-level schemas, mission/satellite identities, owners, target, status, yield/cost/discovery flag, exact account totals, and subsequent restart equality. It does not initially require the mission and satellite `definition_id`, per-record schemas, or the captured `completes_at - started_at == 200`. An incorrect definition/duration present in the first native save can pass these checks and then remain identically incorrect across restart. The pure resource test verifies the definition object, but not these captured native mission fields.

Minimal correction: require the stable data-satellite ID on both records, current record schema constants, and exact captured duration (and coherent ready/resolved timestamps), with narrow negative-oracle mutants. Do not infer physical terminal use or player authorization from the operator release-test hooks. These fields actually exist in `SatelliteNbtCodec.java:22-64`; no new runtime schema is needed.

Both findings were sent to root while its build remained exclusive. This immutable report preserves the initial source observations; later corrections need a separate incremental receipt.

## Source checks and conclusions within scope

- Strict optional flag decode, explicit-null rejection, schema-1 field refusal, lossless legacy export rejection, and old Java constructor defaults are implemented by the existing Codec field adapter plus additive branches. New built-in planets opt in; Earth/Moon/Space authoring defaults remain false. No public API type is changed.
- [RocketFlightService.java:345-365](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/RocketFlightService.java#L345) checks physical admission first, exempts identical source/target from discovery, then calls the ordinary planner. [PlanetaryFlightAdmission.java:19-28](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/PlanetaryFlightAdmission.java#L19) resolves station orbit identity from committed server state and reads writable shared progress only for opted-in bodies. Both player and operator launch use that planner before transfer preparation. No resource mutation or chunk scan was added by the new check.
- Existing control, flight-state and station-access validation remain ahead of offered readiness/launch. Source discovery is not required. Prepared-transfer recovery is unchanged. The current pure planner remains an internal calculation utility rather than a new public permission API.
- Status 12 and launch refusal map are explicit; exact flight protocol increments to 8. Existing status IDs remain stable and unknown IDs reject. Client map rendering uses server status rather than constructing an unlock. Gas bodies still have no surface quote; terminal discovery state is the chosen indicator.
- `processResources` and `sourcesJar` add an exact-path historical v0.8 satellite exclusion and DataGen authors a v1.4 replacement. Source inspection alone does not prove unique packaged entries or API byte identity; artifact inspection remains pending. The original historical resource is not edited.
- `DiscoveryProgressFixture` is lifecycle-bound to serial BeforeBatch/AfterBatch hooks. It restores original CelestialSavedData and, for the isolated discovery batch, SatelliteMissionSavedData, marks originals dirty and saves them. Other known-progress batches copy original progress then discover Mars/Venus. This preserves originals rather than permanently unlocking a reused test world. Actual pass/failure hook execution and artifact contents have not been independently run in this task.
- The new GameTest checks locked surface/station, private station filtering, operator denial, unchanged flight/transfer/station/progress/chunk counts, local catalog replacement, ownership, shared unlock, repeated claim and saturated retained-progress pending/account behavior. Six new pure tests cover Codec/defaults, record/future/capacity behavior, captured fee replay and packaged definition values. One new Python method checks raw-projection account/status mutants. Presence is not execution evidence.

## Coverage and evidence limits

- `menu.quotes()` is read after the 230-tick research wait. This proves that an overdue refresh sees discovery; it does not itself measure propagation from a freshly cached pre-claim quote within the next 20 ticks. The unchanged menu timer supports the intended behavior, but a bounded cache-before-claim assertion would be stronger evidence.
- GameTest uses network-free FakePlayers and calls `SatelliteRuntime.launch/claim` with explicit identities. It exercises real service/owner paths, not item assembly or actual terminal click/network flow. The packaged runner uses existing operator hooks (including claim-as-recorded-owner), so it cannot establish player authorization or V1/V2.
- In-memory `applyCandidate` demonstrates changed planning inputs; this new test is not a native `/reload` rejection experiment. Future/absent/saturated tests include pure policy/storage checks; not every combination is an actual flight request.
- The native denial compares live rocket reports; the GameTest additionally checks journal/station/chunk mutation. Do not attribute the GameTest's full resource oracle to the packaged denial step.
- Research capture preserves raw `.dat` files before bounded decoding and retains whole mission/satellite/account authority for restart equality; the logical scheduler clock is intentionally not required byte-equal across elapsed time. Existing process ownership, finite waits, stop/failure receipts and raw capture infrastructure remain in place. No native process was started here.
- The unchanged historical two-SavedData claim workflow is not cross-file power-cut atomic; accepted ADR-037 explicitly leaves that recovery matrix open.

## Commands and inspected identities

Read-only commands actually used: `git diff --stat e810fb390dd30dbaa4506a59bffee00b1c78083b`, scoped `git diff e810fb3 -- ...`, `git rev-parse HEAD`, `git status --short --untracked-files=no`, scoped `git ls-files --others --exclude-standard -- ...`, `git check-ignore` on the single new generated satellite path, `rg -n`, `rg --files`, and numbered PowerShell `Get-Content -LiteralPath` for the affected and adjacent files. No command enumerated/read the excluded user documentation bundle.

An `rg` call with literal Windows wildcard path arguments was rejected and replaced with a scripts-directory search plus `--glob`. A first Temp snapshot command had a PowerShell parser error (`foreach {...} | Out-Null`); it executed no statements and was corrected to collect `@(foreach {...})`. This was an inspection-helper error, not a source/build failure. The corrected command created this fresh directory, preserved the actual tracked diff plus new files and recorded eight initial file hashes in `snapshot-inputs-01.sha256`.

Snapshot membership includes the new policy, batch fixture, GameTest, JUnit test, native runner, Python tests, generated satellite resource and accepted ADR. Source is still root-owned and may be revised; these snapshots identify this pass. No Gradle, JUnit, Python unittest, DataGen, game server, client, remote/network command or Git mutation was executed. Only this Temp directory was written. This report is not final implementation verification or Gate approval; await the exclusive test window and correction review.
