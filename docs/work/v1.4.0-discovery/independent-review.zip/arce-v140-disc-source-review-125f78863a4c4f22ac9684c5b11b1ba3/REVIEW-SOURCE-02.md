# V140-DISC incremental correction review 02

## Findings status

No unresolved finding remains from the finite source/oracle pass recorded in `REVIEW-SOURCE-01.md`. This is a read-only correction receipt, not an independently executed test result or final acceptance. Initial findings and source snapshots are preserved unchanged.

1. **P2 partial fixture cleanup addressed.** [PlanetaryDiscoveryGameTests.java:54-69,140-142](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/PlanetaryDiscoveryGameTests.java#L54) establishes cleanup before assembly, registers each successfully returned rocket, and cleans that subset on setup failure. The concrete first-success/second-assembly-failure leak is closed. It does not introduce global entity/journal clearing or change production transactions. Catastrophic failures inside the shared helper before it returns ownership are not independently fault-injected here.
2. **P2 native initial binding gap addressed.** [run_v140_planetary_worlds_smoke.py:256-271](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_planetary_worlds_smoke.py#L256) now checks mission/satellite/account record schema 1, both stable data-satellite definition IDs and exact 200-tick captured mission duration. [test_v140_planetary_worlds_smoke.py:254-261](D:/GitHub/AdvancedRocketry-Community/tests/test_v140_planetary_worlds_smoke.py#L254) mutates each independently and invokes the initial `upgrade` oracle, so failure cannot be attributed solely to restart inequality. Timestamp ordering beyond the checked duration remains dependent on production codec validity/native readback, not a separate new oracle claim.
3. **Menu refresh coverage strengthened.** [PlanetaryDiscoveryGameTests.java:109-121](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/PlanetaryDiscoveryGameTests.java#L109) refreshes a locked quote immediately before claim, asserts the cache remains locked in the same tick, and then checks readiness 21 ticks later. The original 280-tick test timeout remains unchanged. This covers cached discovery propagation, while the unchanged production 20-tick refresh constant supplies the exact interval; it is not a rendered/client-network timing measurement.
4. **Existing physical tests receive an explicit discovery precondition.** [DiscoveryProgressFixture.java:73-80](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/DiscoveryProgressFixture.java#L73) adds paired hooks for actual `planetary_physical_admission` and `planetary_changed_pad` batch names. Existing assertions were not changed by this correction. Known-progress fixtures now install a fresh temporary authority (lines 23-33), avoiding dependence on a saturated/future reused-world progress object; original objects are restored and saved by lines 42-54. This is a fixture setup adaptation to the new arrival precondition, not a weakening of physical admission/return assertions.

## Evidence and commands

Only numbered `Get-Content -LiteralPath`, scoped `rg -n` (`--glob 'Planetary*GameTests.java'`), `Copy-Item` into this Temp directory and `Get-FileHash` were used for this incremental pass. One initial literal wildcard path was rejected by Windows `rg`, then corrected to a directory plus `--glob`. No source/build/index write, Gradle/test/server/remote command or delegation occurred.

Four revised snapshots are saved as `revision-02-*`; exact source identities are in `snapshot-inputs-02.sha256`:

| File | SHA-256 |
|---|---|
| PlanetaryDiscoveryGameTests.java | `0f7b9b02a8b6341738479c91a2eebd3a0b2389f1eb00847857609cec6bd56f9d` |
| DiscoveryProgressFixture.java | `91091e91d47d76d962d27efcc3b3fa94e8c26f9d60bff5aa20cb47c5adf6df9b` |
| run_v140_planetary_worlds_smoke.py | `0217696e279506b9a0455d24fd148ac191b80912590f68589226a454e2f0ea74` |
| test_v140_planetary_worlds_smoke.py | `3a716ec3a4f6ac13807b4e910bf466bc8bed32ebd25b6967249a88db887d5880` |

Root reported an initial 898-JUnit pass and three older GameTest failures lacking discovery setup, followed by the above batch corrections and a live reused-world rerun. Those are **root-reported context**, not independently read logs or repeated commands in this source pass. Root still owns Gradle. All executable outcomes, final artifact/resource checks and native records remain pending independent verification after explicit slot release. The client/terminal, operator-hook, cross-file atomicity and Gate limitations in source report 01 remain applicable.
