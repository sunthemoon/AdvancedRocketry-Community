# v1.4.0 implementation log

## Goal and scope

Deliver [Planetary Expansion](../versions/V1.4.0-PLANETARY-EXPANSION.md):
explorable contrasting worlds, non-landable logical bodies, authoritative
environment, navigation/discovery and sky presentation. Complete the scoped
implementation before the deferred full acceptance campaign; do not equate
development progress with release approval.

```yaml
version: v1.4.0
status: IN_PROGRESS
phase: IMPLEMENTING
branch: codex/v1.4.0-planetary-expansion
accepted_development_baseline: 1a192b4b9b9a90372c11643e086f7b0fbdcd1860
runtime_implementation_allowed: true
last_updated: 2026-09-27
```

The baseline contains the reviewed v1.3 implementation and development handoff,
not a passed v1.3 candidate. Inherited acceptance remains open. Root is the sole
tracked writer; independent review is read-only with fresh Temp outputs. The
user-supplied untracked documentation bundle is excluded from reads and writes.

Preparation non-goals: runtime changes, new assets, changing an existing world,
candidate/tag/release approval, remote/client/long-load tests or v1.5+ features.
No physics, terrain, sky, discovery or API implementation is implied by contract
acceptance. Runtime permission is limited to the accepted current-version
contracts; later persistent/public changes still need their own decisions.

## Feature map

- [x] `V140-GOV-01` Version-limited development baseline decision — status: verified
- [x] `V140-CON-01` Fixed-Level strategy and definition contract — status: verified
- [x] `V140-DATA` Versioned definitions and coherent catalogs — status: verified
  - [x] `V140-DATA-01` Legacy-compatible schema and capability-aware consumers — status: verified
  - [x] `V140-DATA-02` Joint bounded celestial/route reload — status: verified
  - [x] `V140-DATA-03` Independent schema/reload and restart verification — status: verified
- [x] `V140-MAP` Mars-like/Venus-like worlds and non-landable gas giant — status: verified
  - [x] `V140-MAP-01` Cross-restart body/Level binding and initialization — status: verified
    - [x] `V140-MAP-01A` Persistent binding contract — status: verified
    - [x] `V140-MAP-01B` Bounded binding authority and checked disk commit — status: verified
    - [x] `V140-MAP-01C` Startup/reload integration and verification — status: verified
  - [x] `V140-MAP-02` World data, bounded landing and station integration — status: verified
    - [x] `V140-MAP-02A` Fixed planetary terrain and route data — status: verified
    - [x] `V140-MAP-02B` Physical travel admission and bounded surface pads — status: verified
    - [x] `V140-MAP-02C` Planetary player station creation — status: verified
    - [x] `V140-MAP-02D` Independent travel/world restart verification — status: verified
    - [x] `V140-MAP-02-DIAG` Clarify reverse-Level conflict diagnostic — status: verified
- [x] `V140-ENV` Environmental response and equipment protection — status: verified
  - [x] `V140-ENV-01` Opt-in exposure and protection contract/model — status: verified
  - [x] `V140-ENV-02` Server effects, equipment and controlled rooms — status: verified
  - [x] `V140-ENV-03` Data, player feedback and independent verification — status: verified
- [x] `V140-NAV` Star map, server-filtered reachability and synchronization — status: verified
  - [x] `V140-NAV-01` Navigation status and bounded wire contract — status: verified
  - [x] `V140-NAV-02` Server menu authority and coherent refresh — status: verified
  - [x] `V140-NAV-03` Interactive schematic star map and localized feedback — status: verified
  - [x] `V140-NAV-04` Independent short checks and development evidence — status: verified
- [x] `V140-SKY` Sky/fog/sun/sound and audited asset batches — status: verified
  - [x] `V140-SKY-01` Bounded resource profiles and selection contract — status: verified
  - [x] `V140-SKY-02` Cached sky geometry and conservative fog adaptation — status: verified
  - [x] `V140-SKY-03` Lifecycle-bound ambience and generated resources — status: verified
  - [x] `V140-SKY-04` Independent short checks and development evidence — status: verified
- [ ] `V140-DISC` Discovery/research policy and presentation — status: in-progress
  - [x] `V140-DISC-01` Shared discovery and private research contract — status: verified
  - [ ] `V140-DISC-02` Server arrival policy and mission target data — status: in-progress
  - [ ] `V140-DISC-03` Locked navigation feedback and strict protocol — status: planned
  - [ ] `V140-DISC-04` Independent short verification and restart evidence — status: planned
- [ ] `V140-MIG` Existing-world and removed-content recovery — status: planned
- [ ] `V140-ACC` Required G0-G9 evidence and human acceptance — status: planned

## Completed preparation

## Discovery slice

Base: `e810fb3`. Root is the sole tracked writer. Reuse the existing world-shared
celestial progress and owner-scoped satellite research; the accepted
[ADR-037](../decisions/ADR-037-PLANETARY-DISCOVERY-AND-RESEARCH.md) describes the
new definition/arrival contract before implementation. No new currency, player
discovery store, direct research shop, remote/long-load test or release approval.
Full arbitrary-crash and removed-content recovery is a separate MIG capability.

| Leaf | Outcome and dependencies | Acceptance / verification | Status / evidence |
|---|---|---|---|
| DISC-01 | Explicit shared discovery, individual research and old-world policy; depends on DATA/NAV and existing satellite missions | Actual-source contract review, stable IDs/compatibility/budgets/non-goals recorded | verified; ADR-037 accepted under standing authorization after independent source review; clarified Level-only visits, historical capacity and planner order |
| DISC-02 | Research missions unlock opt-in bodies for server travel; depends on DISC-01 | Strict flag/legacy codec, real mission owner/replay behavior, locked surface/station refusal without mutation, removed/future/missing data tests | in-progress |
| DISC-03 | Star map explains locked destinations; depends on DISC-02 | Explicit status, exact-match protocol, current/reloaded server quotes, packet bounds and localized guidance | planned |
| DISC-04 | Reproducible scoped development evidence; depends on DISC-02/03 | Clean build, DataGen stability, GameTests, packaged research/restart, independent diff/key reruns, provenance/manual cases | planned |

## Sky presentation slice

Base: `251de231612049f62721f8911a4f402a4f1157d0`. Root remains the only tracked
writer. Independent review is read-only, with fresh Temp evidence and an
exclusive Gradle slot. No remote, long-load, real-client or release work.

The accepted [ADR-036](../decisions/ADR-036-PLANETARY-SKY-PROFILES.md) separates
resource-pack presentation from authoritative environment and existing saves.
This slice includes Mars/Venus surfaces, Moon and generic shared-space sky;
Earth keeps its ordinary renderer. Station-specific parent discs, astronomical
ephemerides, shaders, custom music and v1.5 multi-star context are not included.

| Leaf | Observable result and dependencies | Acceptance and verification |
|---|---|---|
| SKY-01 | A bounded resource pack changes presentation selected by the synchronized unique Level mapping; depends on DATA/NAV | Strict profile decoding, finite values, count/byte/depth limits, atomic reload retention, missing/ambiguous mapping fallback; unit and independent contract checks |
| SKY-02 | Planet-specific sky, sun and stars with capped cached geometry; depends on SKY-01 | No per-frame geometry rebuild, finite projection inputs, fog never bypasses fluid/status restrictions, state restoration and resource cleanup; geometry/policy tests, source review; GPU observations remain unverified |
| SKY-03 | Exposed planetary ambience stops across Level/profile/logout/resource changes; depends on SKY-01/02 | One optional local sound, bounded cadence, ambient volume control, original generated profiles and reference-only vanilla audio; lifecycle/resource/DataGen tests and packaged-byte audit |
| SKY-04 | Reproducible development evidence without release claims; depends on all preceding leaves | Clean build, unit/GameTest, repeat DataGen, packaged local restart, independent actual-diff/key-command review, provenance and manual cases; retain every failure |

The [sky evidence](v1.4.0-sky/VERIFICATION.md) retains the initial compile/unit
failures, independent contract/source corrections and final artifact identities.
Root actually executed 891 JUnit and 234 GameTests; a final clean build restored
the passing unit cache, ran a fresh-world 234 GameTests and reproduced all three
frozen JARs. DataGen writes zero of 33 resources. Independent forced checks
passed 25 focused JUnit and 234 reused-world GameTests, with all 1187 runtime/
build/resource inputs and three artifact hashes unchanged.

A prior clean world failed four Earth-return cases because all eight candidate
areas had snow/grass at the heightmap-selected plane. Production correctly
rejects non-air. The original failed world remains archived. A batch-owned,
25-block test platform restores its original states after each batch, without
changing production behavior or existing assertions/time budgets; an added
regression preserves snow/grass refusal. The same failed world then passed.

Three packaged local JVMs passed upgrade, three-leg travel and restart; an
independent raw audit verifies the 138-member native manifest. These are scoped
development criteria only. SKY-02's source/geometry/state checks do not prove
actual GPU correctness; SKY-03's lifecycle/sound-factory checks do not prove
audio quality. V1/V2 and the full campaign remain separately pending under
ADR-018, with explicit [unexecuted manual cases](v1.4.0-sky/MANUAL-CASES.md).

### V140-GOV-01

- Observable outcome: a maintainer can distinguish the authorized v1.4
  development baseline from inherited acceptance and from later-version scope.
- Scope: a new version-limited decision; no extension of ADR-020's v1.3 scope.
- Dependencies: actual v1.3 commit/evidence, ADR-018 scheduling and maintainer
  authorization to use recommended implementation solutions.
- Acceptance: immutable baseline, owner/basis, expiry and recovery condition;
  no candidate, Gate PASS, publication or v1.5 production permission.
- Verification: independent authority/diff review, planning and local links.
- Status: verified; accepted [ADR-030](../decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md).
- Evidence: [preparation verification](v1.4.0-preparation/VERIFICATION.md),
  unchanged independent review and exact baseline identity. Acceptance uses the
  maintainer's standing authorization, not a new release approval.

### V140-CON-01

- Observable outcome: implementers can add a logical non-landable body without
  manufacturing a Level, and can identify exactly how old definitions and
  world identities remain usable.
- Scope: fixed startup data dimensions, definition schema/capabilities, bounded
  reload and display compatibility; later environmental effects/visual assets
  still need their own concrete task contracts.
- Dependencies: actual celestial, travel, station, network and API code; stable
  v1.1 target/context and v1.3 API contracts; current platform documentation.
- Acceptance: finite fields/defaults, mapping and source/destination distinction,
  joint-catalog visibility, missing-content policy, protocol/save separation,
  testable limits and explicit non-goals. No new import before provenance.
- Verification: source/caller inventory, independently reviewed ADR and finite
  data examples; distinguish example checking from runtime implementation.
- Status: verified; accepted [ADR-031](../decisions/ADR-031-PLANETARY-DEFINITIONS-AND-FIXED-LEVELS.md).
- Evidence: [preparation verification](v1.4.0-preparation/VERIFICATION.md),
  six documentation examples and 14 checks independently rerun. These checks
  do not implement the production decoder or prove runtime reload behavior.

## First implementation slice

### V140-DATA-01 execution scope

- Status: verified, starting from `8947fac9641dc11ce2dce1ed8a3877984be044ab`.
- Owner/write scope: root only; celestial model/catalog/commands/snapshot,
  typed flight planning/quotes, legacy target migration/import adaptation,
  station creation admission, legacy DataGen encoding, corresponding unit and
  GameTests, current development metadata and this slice's evidence.
  The root also owns the finite packaged schema smoke script and reader-facing
  [data guide](../CELESTIAL-DATA-GUIDE.md); no external asset is introduced.
- Dependencies: accepted ADR-030/031 and unchanged API 1.7/persistent contracts.
- Observable result: schema-2 unmapped bodies can load and synchronize without
  acquiring a surface; closed arrivals are rejected before fuel/journal mutation,
  while existing mapped sources and committed stations can depart.
- Non-goals: new actual worlds, durable custom mapping ledger, joint/raw reload
  (DATA-02), temperature/solar gameplay, sky/assets, new API exports, save schema
  changes, full acceptance, remote or long-load tests. Built-in v0.3 generated
  resources keep their original authoring format and hashes through an explicit
  checked legacy encoder, not silent downgrade of schema-2 intent.
- Verification: actual production Codec/constructor boundaries and legacy
  round trips, mapping/migration/planner/snapshot tests, live authority GameTests,
  clean build/DataGen, bounded packaged restart, API export identity and
  independent actual-diff/key-command review. Final independent execution passed
  792 JUnit tests, 213 GameTests and five Python runner tests; DataGen changed
  no resource. Two actual packaged processes passed the bounded same-world
  restart. Earlier failures and their corrections remain in
  [slice evidence](v1.4.0-data01/VERIFICATION.md).

`V140-DATA-01` adds the definition decoder/model and adapts every current
consumer of mandatory Level mappings, including snapshots and authoritative
destination checks. Its outcome is a usable non-landable definition in the
existing runtime, not a standalone unused model. Existing IDs, environment
values, physical Levels, station UUID/orbit-body records and flight journals
must not be rewritten merely because a data definition gets a version.

Acceptance includes legacy/default round trips, invalid capability/value input,
unmapped-body behavior, destination refusal without fuel mutation, departing a
still-mapped body closed to new arrivals, and matching display protocol checks.
The short unit/GameTest/build/DataGen checks and bounded packaged restart were
executed against the implementation; full acceptance was not started.
Joint resource reload is DATA-02;
DATA-01 alone must not advertise cross-catalog atomicity.
New-world travel also depends on MAP-01/02: the existing landing selector and
player station-creation flow still restrict physical destinations to Earth/Moon.
Schema support is not evidence that Mars is already reachable or that arbitrary
custom body remapping is safe across restarts.

### V140-DATA-02 execution scope

- Observable outcome: one operation observes one validated celestial/route
  generation; a bad raw resource cannot silently disappear from a candidate.
- Dependencies: DATA-01 and the accepted joint-publication/raw-reader portion
  of ADR-031. No persistent or public API contract change is authorized here.
- Scope: strict bounded resource preparation, graph/endpoint validation,
  immutable paired publication and current query/planner consumers, diagnostics
  and focused real-reload tests. Root remains the sole tracked writer.
- Acceptance: malformed/oversized/deep/duplicate-key input rejects the whole
  candidate; rejected reload retains both catalogs/generation/cache state;
  initial invalid data cannot appear as a ready partial catalog. Closed valid
  sources/reverse edges remain available for evacuation.
- Verification: production raw reader and actual reload failure/success tests,
  finite 100-body input, current budgets, independent review and short server
  reload/restart checks. No soak, new worlds, terrain or v1.5+ work.
- Status: verified, starting from `4db8b1bc573b6f9f20a20bd2a5a13a0836e055f2`.
- Root write scope: new `celestial/data` bounded-reader/pair owner/listener;
  celestial manager read projection and snapshot capture; route listener/owner
  replacement; central listener/lifecycle wiring; rocket planning/quote capture;
  provider directory reference; related unit/GameTest fixtures, bounded native
  smoke runner and DATA-02 documentation/evidence. No imported source or asset.
- Design: one lifecycle-owned immutable pair, one apply operation, and a
  read-only celestial view for existing environment/station consumers. The
  flight service captures the pair once per quote batch or launch. Isolated
  celestial-only unit fixtures remain separate from the runtime publication.
  Route files retain their stricter 4096 limit; raw UTF-8 bounds precede JSON
  allocation. Both resource directories share one bounded error collector.
- [x] `V140-DATA-02A` Raw preparation — status: verified. Checks cover UTF-8 byte
  boundaries, nesting 16, duplicate/escaped keys, malformed/trailing JSON,
  resource count, I/O failures and at most eight/2048-character diagnostics.
- [x] `V140-DATA-02B` Paired publication — status: verified. Checks cover graph/endpoint
  compatibility, one generation, retained object/cache identity on failure,
  initial failure and closed-source reverse edges with finite 100-body input.
- [x] `V140-DATA-02C` Runtime consumers — status: verified. Both old listeners
  replaced; capture one pair per operation and one catalog/generation per
  display snapshot. Existing gameplay GameTests and actual packaged reload
  passed; operator-only route inspection exposes the captured route/generation.
- [x] `V140-DATA-02D` Evidence — status: verified. Root short build/DataGen/
  GameTest and finite packaged reload/restart passed. Independent 167-case
  affected-consumer check, final 23-case reader/reload check and nine Python
  checks passed; independent raw-native audit also passed. Original failures and
  exact artifact identities are retained in [slice evidence](v1.4.0-data02/VERIFICATION.md).

### V140-DATA-03 verification scope

- Status: verified, using the DATA-02 final production artifacts, not a new
  feature implementation or a whole-world migration claim.
- Outcome: independent checks of the actual changed code, coupled resource
  behavior and exact packaged restart evidence.
- Acceptance: read-only reviewer checks source/diff and applicable commands;
  native fixtures/logs/commands/NBT distinguish accepted/rejected generations,
  final route/body values, retained station authority and no fake gas Level.
  All evidence includes tested identities and original unsuccessful attempts.
- Verification: root two-process native run passed six explicit rejected
  candidates, repair, save/stop/restart. Independent readback verified 40 native
  manifest files, all original fault inputs and actual route/body generation
  receipts, three byte-identical native station captures and both JVM exits 0.
  See [commands, identities and unchanged reports](v1.4.0-data02/VERIFICATION.md).
- Non-goals: forced-crash, real-client/GPU, remote, workload/soak and authentic
  historical-world upgrades. Those remain open, not inferred from this check.

## Active world-binding slice

Starting from `eee45f5010e1332c69c6eb18f127fc468cfea5df`, root alone owns
`celestial/binding/**`, paired catalog lifecycle integration, central event
registration, related tests/finite native runner and this version's documents.
Independent review is tracked-file read-only and writes fresh Temp evidence.
No source/asset import, new worlds, physics, rendering, broader acceptance or
v1.5 work is included. API 1.7, display protocol 2 and existing saves stay intact.

### V140-MAP-01A

- Outcome: an explicit first-adoption, retirement, reverse-Level and restart
  policy rather than inferred legacy mappings.
- Dependencies: DATA-02/03 and actual existing persistence/lifecycle consumers.
- Acceptance: stable schema/file ID, bounds, failure/publication order, startup
  lifecycle, upgrade limits and rollback are independently reviewed before use.
- Verification: actual source and pinned platform inspection; ADR draft review.
- Status: verified; [accepted ADR-032](../decisions/ADR-032-PERSISTENT-PLANETARY-BINDINGS.md).
  Independent source/draft and implementation reviews are preserved in
  [binding evidence](v1.4.0-map01/VERIFICATION.md).

### V140-MAP-01B

- Outcome: successful assignments survive process restart and body removal;
  changed identity and failed disk commits cannot replace accepted authority.
- Dependencies: accepted MAP-01A.
- Acceptance: strict bounded schema, immutable monotonic identity set, explicit
  unmapped records, exact baseline and reverse-Level reservation, checked atomic
  commit, no corrupt/changed file reset and no eviction at lifetime capacity.
- Verification: unit tests and real Temp file I/O/failure/readback checks.
- Status: verified; 17 new model/codec/store/lifecycle tests passed in root and
  independently forced runs. The checked-attribute regression resolves the
  initial P2; the P3 diagnostic follow-up remains explicit below.

### V140-MAP-01C

- Outcome: the actual server attaches before gameplay and publishes reloads only
  after binding validation/commit; no new world is made reachable by this alone.
- Dependencies: MAP-01B and DATA-02 paired owner.
- Acceptance: initial failure aborts, later failure retains pair/generation/cache,
  stop detaches world state; native restart validates the same recorded mapping.
- Verification: short build/DataGen/GameTest, packaged reload/restart, independent
  actual-diff review and key command rerun. No full test campaign.
- Status: verified; root full checks, two native clean processes, separate
  offline-remap refusal and independent actual-diff/key-command/raw evidence
  review completed. See [binding evidence](v1.4.0-map01/VERIFICATION.md).

MAP-01 verification checkpoint: final root Java passed 832 JUnit/149 suites and
213 required GameTests; DataGen wrote zero resources. Independent forced checks
passed 66 JUnit/7 suites and 10 Python tests. Two packaged same-world processes
passed removal/re-add, remap/reuse rejection and restart. A separate native
offline-remap probe refused before world readiness and preserved ledger/station
bytes; its platform crash/shutdown diagnostics and changed native `level.dat`
are retained, not relabeled a clean cycle. Independent native readback verified
33 clean-cycle and 11 refusal manifest files. Original unsuccessful supplemental
audit output is also retained in [binding evidence](v1.4.0-map01/VERIFICATION.md).

### V140-MAP-02-DIAG

- Outcome: reverse-Level conflict text identifies both conflicting body IDs or
  the retained owner without mislabeling a newly rejected alias as historical.
- Scope: low-severity wording/lookup correction only; rejection and persisted
  ownership already hold. It does not authorize remapping.
- Acceptance/verification: targeted conflict test with a new alias sorting before
  the recorded owner, plus the existing binding tests and independent review.
- Dependency: MAP-01. Status: verified; both IDs are named, with an alias-sorts-first
  regression. The original independent P3 report is retained, not edited.

## Active planetary-world slice

Base: `d41e42fb2118a060a7df4c0480e0887079e0d38e`. Root remains the only tracked
writer, including data generation, build/resource registration, Java/tests and
version records. Independent review is read-only and uses fresh Temp evidence.
The user documentation bundle remains excluded. No imported art/code, runtime
dimension creation, new save/network/API schema, warp, generic-orbit platform,
environmental damage, star map, discovery or custom sky implementation belongs
to this slice. Full remote/client/load acceptance stays deferred under ADR-018.

### V140-MAP-02A

- Outcome: actual startup Mars/Venus terrain plus an unmapped gas-giant subject,
  with routes consumed by the existing flight UI/planner; not metadata-only worlds.
- Dependencies: accepted ADR-031/032; additive stable content identities and
  world-admission details recorded in ADR-033 before implementation.
- Scope: data-driven noise terrain/biomes/dimension types, schema-2 bodies,
  route definitions and generated resource registration. Preserve old outputs.
- Acceptance: distinct terrain, six-body catalog, no gas Level, valid bidirectional
  surface/orbit routes, unique packaged resources and unchanged baseline IDs.
- Verification: production Codec/registry data checks, DataGen repeatability,
  actual Level/chunk observations and native restart. Status: verified.
  Twenty additive resources; old generated data unchanged. Terrain GameTests and
  a real pre-planet-artifact upgrade prove actual Levels rather than catalog-only data.

### V140-MAP-02B

- Outcome: registered data-defined surfaces can be reached by ordinary rockets;
  stale saved identity or unavailable physical Level rejects before mutation.
- Scope: physical source/target admission and existing deterministic eight-pad
  selector. No client coordinates, unbounded search or increased budgets.
- Dependencies: MAP-01, MAP-02A and existing transfer journal contract.
- Acceptance: live source agrees with saved body/Level/target, target Level is
  started and unambiguous, Space/gas/generic orbit cannot become a surface;
  border/height/occupied/unsafe pads reject without fuel/journal mutation.
- Verification: pure admission tests, real-world launches/cancels/transfers,
  fuel/authority conservation and bounded pad checks. Status: verified.
  Source review's pre-spawn support recheck is implemented; normal failed spawn
  retains the original source fuel ledger. Repeated quotes do not load chunks.

### V140-MAP-02C

- Outcome: players standing on an eligible mapped planet can create its station.
- Dependencies: MAP-02A/B; existing station UUID/region/permission authority.
- Acceptance: resolve the actual source Level from the current catalog rather
  than an Earth/Moon enum, check orbit capability, and retain player limits;
  Space/unmapped/ambiguous sources cannot create a surface-origin station.
- Verification: player-path GameTests, rejected registry conservation and
  exact persisted orbit/owner/region readback. Status: verified.
  Mars/Venus player creation and owner limit are tested; native operator Moon,
  Mars and unmapped-gas stations retain exact UUID/owner/orbit records on restart.

### V140-MAP-02D

- Outcome: independently reviewed actual world/flight changes and retained
  short packaged same-world save/restart evidence.
- Dependencies: MAP-02A/B/C and diagnostic correction.
- Acceptance: actual round-trip and new-body station authority, generated
  world content and bindings survive restart; capture exact artifacts and
  original failures. No inference of S2/V1/V2/full-version Gate approval.
- Verification: clean/build/DataGen/GameTest, independent key reruns, finite
  packaged command/log/NBT readback. Status: verified.
  Root 840 JUnit/220 GameTests, zero-change DataGen and 24 Python checks passed.
  Three native processes complete a preceding-MAP-01 upgrade and three surface
  flights with exact cargo/debits/stations/bindings. Independent 61 JUnit/220
  GameTests/24 Python checks passed with unchanged inputs/artifacts; independent
  raw readback verified all three original manifests. Earlier reviews and failures remain in
  [MAP-02 evidence](v1.4.0-map02/VERIFICATION.md).

## Environmental response slice

Start: `d120d4152689022473512329a44cd29a29317b2f`; root is the sole tracked
writer. [ADR-034](../decisions/ADR-034-PLANETARY-EXPOSURE-AND-PROTECTION.md)
records the recommended compatibility/protection rules under standing authority.
No new assets are imported. No sky, star map, discovery, radiation damage,
new equipment tier, API/export, save-schema change or v1.5 work is included.

- `V140-ENV-01`: observable opt-in temperature/pressure/solar rules and exact
  default compatibility; depends on DATA/MAP contracts. Verify strict production
  Codec round trips and pure bounded threshold/protection/cadence tests.
  Status: verified. Twelve new unit tests cover strict default/legacy/opt-in data,
  unique-surface resolution, finite thresholds and the protection/cadence matrix.
- `V140-ENV-02`: observable server damage, passive correctly slotted equipment
  protection and finite supplied-room protection, without ambient-air confusion.
  Depends on ENV-01 and existing atmosphere/suit authority. Verify actual damage,
  tags, oxygen conservation, room invalidation, loaded-column sunlight and
  server-owned lifecycle/reset behavior through focused GameTests.
  Status: verified. Nine new GameTests cover registered effects, equipment and
  finite room supply, ordinary immunity, initial spawn grace, replacement/reset
  and sunlight occlusion. Service-call/event-simulation limitations are explicit.
- `V140-ENV-03`: observable localized warnings and stable generated resources;
  depends on ENV-01/02. Verify clean build, stable DataGen, required GameTests,
  bounded packaged restart and independently rerun applicable checks. Retain
  concrete evidence before checking these tasks; no inferred V1/V2/Gate approval.
  Status: verified. Seven new and five changed original resources have exact
  packaged-byte checks; API 1.7 JAR bytes and existing save/network schemas remain
  unchanged. Localized messages are implemented, not real-client visually accepted.

Root implementation checks passed 852 JUnit tests and 229 required GameTests;
repeat DataGen wrote zero resources. Independent forced 77 JUnit and reused-world
229 GameTests passed; 1296 source/build/generated inputs and all three artifacts
were unchanged. Three local packaged processes passed upgrade/travel/restart,
with independent 144-member native readback. Root's final clean build reproduced
all three JARs. Initial fixture failures and corrections remain in
[environment evidence](v1.4.0-env/VERIFICATION.md). This does not verify real-player
environmental gameplay, native environmental reload, S2 or client/GPU acceptance.

## Navigation slice

Base: `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`. Root remains the sole tracked
writer, including central protocol, menu, server, client and DataGen registration.
The excluded untracked documentation bundle is not read or edited. No upstream
source/art is imported. No discovery persistence, warp, terrain, environmental
rule, save schema, public API or future-version change belongs to this slice.
The accepted contract is [ADR-035](../decisions/ADR-035-ROCKET-STAR-MAP-AND-NAVIGATION-SYNC.md),
using standing recommended-solution authority after independent source/contract
review. Its explicit status table, frame bounds and recovery retry rule resolve
the review clarifications; this is not a new numbered manual vote or Gate approval.

- `V140-NAV-01`: players receive bounded reasons and station metadata alongside
  one generation of quotes. Dependencies: DATA/MAP/ENV and existing typed plan
  protocol. Verify exact-version compatibility, bounds, malformed/duplicate
  records and packet round trips before integrating the client.
- `V140-NAV-02`: actual owner/access/state/route/fuel authority filters readiness,
  station changes refresh, and incoherent displays recover without chunk loads.
  Depends on NAV-01. Verify menu validity, cross-menu rate limits, generation
  changes, exact resource preservation and forged/stale intent refusal.
- `V140-NAV-03`: the existing console offers a bounded, navigable body/parent map,
  environment details and authorized station selection, with explicit Launch.
  Depends on NAV-01/02. Verify deterministic large-catalog layout, clipping,
  stable selection, localization and GUI bounds; list deferred real-client cases.
- `V140-NAV-04`: independently review the actual diff and rerun applicable key
  checks, with artifact-bound short server regression and original failures
  retained. Depends on NAV-01/02/03. No inferred full Gate or V1/V2 approval.

The NAV implementation and short root checks are recorded in
[navigation evidence](v1.4.0-nav/VERIFICATION.md). Root's final clean build,
866 JUnit, unchanged DataGen and 232 required GameTests pass; three frozen-artifact
operator-driven packaged processes also pass. Independent source review corrected
container click dispatch. An inherited sunlight fixture's fixed two-tick delay
failed in a clean world; bounded observation now preserves its 40-tick timeout
and all original assertions, with stronger roof-state checks. The original failure
remains recorded. Real-client cases remain explicitly deferred, not passed.
Independent forced checks passed 47 JUnit and 232 reused-world GameTests, with
1180 source/build/resource inputs and three JARs unchanged. Independent raw
readback verified the 147-member native manifest, rocket/cargo/fuel, station
and binding persistence; the native smoke is not a menu packet/UI test.
NAV-01/02 are verified by bounded codec/model and actual server/menu-service
checks; NAV-03 is implemented and checked by pure layout/input, source review,
compilation and localized resource packaging, not V1/V2. NAV-04's original logs,
failed attempts, independent reports and artifact identities are archived.
These checkboxes record the scoped development criteria only, not visual or
version Required Gate approval.

## Verification and remaining work

2026-09-27: GOV-01/CON-01 completed as preparation only. The unchanged runtime
passed the combined clean/build/DataGen/GameTest command (121 seconds): 210
required GameTests executed, 769 JUnit results in 143 suites restored from
cache, DataGen wrote zero files. Host/API/sources remain byte-identical v1.3
development artifacts; see [exact results](v1.4.0-preparation/VERIFICATION.md).

DATA-02 replaces the old platform JSON preparer for this pair: malformed raw
resources now reject the whole candidate. Actual native fault inputs verify
retention and later repair; the initial full run passed 815 JUnit/213 GameTests
with zero DataGen changes. The final four-route fixture was independently
rerun. MAP-01 now implements stable body/Level binding with explicitly prospective
first adoption; MAP-02 must still validate actual started Levels and existing
target authority before new-world admission.

DATA-01 is now verified as a development slice; its v1.4 main/source artifacts
are new while the full API JAR remains byte-identical to v1.3. See
[implementation and evidence](v1.4.0-data01/VERIFICATION.md). No candidate or
Gate approval has been assigned. Full mechanical/dimensional completion remains
outstanding; ADR-018's full-campaign trigger has not been met. DATA-02/03 are
verified development work, not Gate approvals. MAP-02 now implements actual
worlds, bounded physical landing and station integration, including the P3
diagnostic correction. Final independent evidence is archived with explicit
native-block, background-item and historical-world boundaries. ENV now adds
opt-in hazards, passive equipment and supplied climate-room protection, with
short automated and independently reviewed packaged regression evidence.
NAV implements and independently verifies the bounded navigation/star-map
development slice. SKY now implements bounded planetary presentation with
short automated checks and packaged compatibility evidence, not real-client
acceptance. The next current-version implementation is discovery/research;
remaining migration/recovery and full acceptance are still outstanding.
