# V140-DISC independent contract review

## Findings and resolution

No unresolved contract finding remains in the final ADR text inspected. This is a contract review, not implementation verification, release approval, or a Gate verdict. The following observations were raised independently against the original proposal and are retained here.

### P2 — Define what constitutes an authoritative visit (resolved in contract)

The original proposal said a recorded visit unlocks a body and administrative visits can discover it, without distinguishing surface-Level identity from station orbit identity. The existing tracker only uses the logged-in/changed-dimension player's physical Level. Entering shared Space therefore records Space, not the planet whose station region the player occupies. Treating those as equivalent would promise an unsupported gas-giant/station unlock and invite an unintended progression bypass through station creation.

- Source: [CelestialVisitTracker.java:16-42](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialVisitTracker.java#L16), baseline `e810fb390dd30dbaa4506a59bffee00b1c78083b`.
- Original contract: `ADR-037-proposed-initial.md:27-32,47-54` in this review directory.
- Resolution: [ADR-037:33-35](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-037-PLANETARY-DISCOVERY-AND-RESEARCH.md#L33) explicitly retains the Level-only tracker and says a station visit alone does not discover its planet. No new visit mechanism is required by this slice.

### P2 — Specify retained discovery-store saturation (resolved in contract)

The 128-body live catalog bound does not guarantee free space in the historical progress store, because records for removed bodies are retained. At 128 recorded IDs, discovering another body is rejected. Existing claim accounting credits the yield and spends the captured fee before discovery is applied; a refused discovery leaves the mission pending. Without explicit policy, a successful research mission could be described as granting arrival when it cannot, or an implementation could silently evict records to make it succeed.

- [CelestialSavedData.java:126-163](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L126): existing-record handling, future-schema refusal and 128-entry capacity.
- [SatelliteMissionRegistry.java:289-319](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/mission/SatelliteMissionRegistry.java#L289): pending/replay paths and single account update.
- [SatelliteManager.java:436-459](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L436): catalog check, refused discovery and pending result.
- Resolution: [ADR-037:91-97](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-037-PLANETARY-DISCOVERY-AND-RESEARCH.md#L91) freezes fail-closed pending behavior, no repeated accounting, no silent eviction/cap expansion, and the operator-recovery boundary. A saturated-store replay test remains required implementation evidence.

### P3 — Describe two authorities, not two acknowledged saves (resolved in contract)

The original phrase "two-save claim workflow" was imprecise. The current claim mutates the mission/account state, then applies discovery and invokes a whole DataStorage save. These are two SavedData authorities, not two checked durable transaction acknowledgments.

- [SatelliteManager.java:446-478](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L446).
- [SatelliteMissionSavedData.java:165-180,229-233](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/persistence/SatelliteMissionSavedData.java#L165).
- Resolution: [ADR-037:83-89](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-037-PLANETARY-DISCOVERY-AND-RESEARCH.md#L83) now describes the actual authorities/save call and explicitly excludes arbitrary write-failure/power-cut atomicity. This wording does not waive the later migration/recovery requirement.

### Precedence clarification (resolved; not a discovered production defect)

The root proposed keeping identical source/target CURRENT. Review confirmed that this must precede the new discovery check, while existing physical/control/state authority remains intact. Final [ADR-037:63-76](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-037-PLANETARY-DISCOVERY-AND-RESEARCH.md#L63) specifies the ordering. An undiscovered source may evacuate but gains no arrival permission for another locked destination.

## Actual source constraints checked

All source line references here describe the baseline read before implementation began, not the subsequent in-progress working diff.

- Schema-2 is strict, explicit null is not an absent optional field, schema-1 rejects schema-2 additions, and legacy export already rejects loss of newer metadata: [CelestialDefinitionCodec.java:17-20,59-64,79-120,130-150](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/model/CelestialDefinitionCodec.java#L17). The proposed opt-in flag/default/constructor preservation and downgrade warning fit this boundary. Public API 1.7 need not change for an internal record field.
- Shared progress is Overworld-owned; future schema preserves its payload and exposes no usable entries: [CelestialSavedData.java:58-105,122-124,166-182](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L58).
- Mission ownership is checked before account mutation, and discovery need is captured from absence of a progress record, not from the proposed celestial arrival flag: [SatelliteMissionRegistry.java:267-315](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/mission/SatelliteMissionRegistry.java#L267), [SatelliteManager.java:487-488](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L487). Preserve that distinction: an unrestricted legacy body can still require mission discovery/account cost if unrecorded.
- The actual historical data satellite has Earth/Moon/Space targets, duration 200, yield 120 and cost 100: [data_satellite.json:2-11](D:/GitHub/AdvancedRocketry-Community/src/generated/v0.8/resources/data/advancedrocketrycommunity/satellite_definitions/data_satellite.json#L2). A replacement can extend targets without rewriting frozen missions or importing assets.
- Player source/destination station access is checked before planning; operator launch shares the same launch path. Planning succeeds before countdown/preparation: [RocketFlightService.java:212-318](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/RocketFlightService.java#L212). This is the concrete place for one discovery authority shared with quotes, not a client-only filter.
- Metadata-only admission checks live Level identity, saved source identity and committed station orbit body without landing searches: [PlanetaryFlightAdmission.java:17-56](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/PlanetaryFlightAdmission.java#L17). The pure target planner resolves station targets from the supplied registry: [RocketTargetFlightPlanner.java:108-145](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/flight/RocketTargetFlightPlanner.java#L108).
- Navigation filters private stations and calls the same planner for every bounded target; menu quotes recompute after at most 20 ticks even without catalog/flight change: [RocketNavigationService.java:59-84](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/RocketNavigationService.java#L59), [RocketFlightMenu.java:223-236](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/menu/RocketFlightMenu.java#L223). No new generation bump or discovery field in the public celestial snapshot is necessary for the chosen surface/station status presentation.
- Existing wire status IDs are explicit 0..11 with unknown rejection; exact channel protocol is 7: [RocketNavigationStatus.java:7-42](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/menu/RocketNavigationStatus.java#L7), [RocketFlightNetwork.java:17-29](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/network/RocketFlightNetwork.java#L17). Adding status 12 and exact version 8 is consistent with unchanged packet framing, not wire interoperability with older clients.
- Terminal already exposes target discovery and viewer-scoped research data: [SatelliteTerminalMenu.java:214-238](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/terminal/SatelliteTerminalMenu.java#L214), [SatelliteTerminalMenuData.java:19-31](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/terminal/SatelliteTerminalMenuData.java#L19). Unmapped-body presentation therefore need not invent a new map unlock field.
- Station creation reserves/generates/commits a station, without writing discoveries: [StationCreationService.java:31-96](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationCreationService.java#L31). Discovery must not replace station access or imply a gas surface.

## Finite verification required later (not executed here)

1. Codec missing/false/true, null/string/number rejection, schema-1 rejection, existing constructors and checked legacy export; joint reload preserves current catalog on invalid input.
2. Owner/intruder claims, concurrent start snapshots, exactly one reward/fee, shared unlock without sharing balance; legacy unrestricted-but-unrecorded mission pricing remains unchanged.
3. Absent/future/saturated progress; pending replay and save/reload conserve account totals and records, without claiming arbitrary cross-file crash atomicity. Existing tests cover basic future preservation and single-claim behavior but not this new travel gate.
4. Locked surface and committed station rejection for player and operator; unauthorized/current/invalid-state/physical precedence; no fuel, transfer-journal, pad/chunk or discovery mutation; unlocked gas still rejects surface; a locked source can evacuate.
5. Existing open menu refresh after another owner's claim, stale-view launch fresh rejection after reload, removed/re-added records, bounded explicit status round-trip and unknown IDs.
6. Build/DataGen/GameTest and exact single packaged satellite resource; API classifier unchanged. Short packaged research/claim/restart must read native account/mission/discovery authority and artifact identities, not only command return text.
7. Fixtures temporarily granting shared progress must restore only their owned saved-data substitutions and not erase unrelated batches. Two real clients, actual UI legibility and arbitrary crash/load coverage remain separate unexecuted acceptance work.

## Commands and evidence

- Read-only Git: `git rev-parse HEAD`, `git branch --show-current`, `git status --short --untracked-files=no`, `git diff --stat`.
- PowerShell `Get-Content -LiteralPath` (numbered using `ForEach-Object`) read ADR-037, the active work log, required governance/version/quality documents, and source/test files referenced above.
- `rg --files` and `rg -n` searched explicit tracked source/test/generated directories for CelestialSavedData/recordVisit, planners/navigation, satellite discovery/claim/limits, and related ADR declarations. No search/read entered the excluded user bundle.
- Initial broad combined document output was truncated, so relevant version/gate/quality sections and source files were reread in bounded groups. An attempted `rg` wildcard path `src/generated/v*/resources/...` was rejected on Windows; `rg --files src/generated` then located the actual historical resource. An initial guessed `satellite/menu/SatelliteTerminalMenu.java` path did not exist; the actual `satellite/terminal` files were subsequently read. These were read-only inspection mistakes, not tests or product failures.
- `Get-FileHash -Algorithm SHA256`, `Copy-Item` and `Set-Content` created this Temp-only evidence: initial/final ADR and plan snapshots, 20 initial input hashes, baseline identity/status. No repository files were written.
- Branch: `codex/v1.4.0-planetary-expansion`; source review baseline HEAD: `e810fb390dd30dbaa4506a59bffee00b1c78083b`.
- Final reviewed ADR SHA-256: `2db9be8745139b3d8ab8303aa3af0e58f7a4eae1d3b8f4b49ff8d62c466e4cdc`.
- Root started implementation after freezing the contract; the final status read shows runtime edits beginning. Those edits are **not** reviewed or verified by this contract report. Acceptance metadata is root/maintainer authority, not a reviewer implementation approval.

## Scope and limitations

Reviewed the actual proposal, final revised contract and DISC-01/02/03/04 hierarchy against existing model, progress, mission/account, station and quote/launch boundaries. The active hierarchy separates contract, server/data, wire/UI and independent evidence, and leaves MIG/full acceptance open. No implementation, tests, packaged runtime, client, network or performance commands were executed. No tracked/generated/build/index file was modified; no Gate is approved. No additional unresolved contract decision was identified within this finite scope; implementation review and executable evidence remain necessary.
