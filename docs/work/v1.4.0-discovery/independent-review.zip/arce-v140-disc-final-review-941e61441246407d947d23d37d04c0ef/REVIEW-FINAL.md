# V140-DISC independent final review

## Findings

No unresolved finding was identified within the reviewed DISC implementation, targeted execution and bounded evidence audit. The initial two implementation-review findings were corrected: partial GameTest resource cleanup and incomplete initial native mission definition/duration binding. Initial reports remain immutable; this conclusion does not certify arbitrary crash atomicity, actual client gameplay, or any complete Required Gate.

Observed limitations retained rather than hidden:

- The existing claim spans two SavedData authorities; no S2/write-failure atomicity claim is made. A full historical discovery store preserves a paid claim as pending under ADR-037, rather than evicting old IDs or unlocking silently.
- Independent fresh-world GameTest emitted a startup `Can't keep up` warning of **2,771 ms / 55 ticks**. Native restart emitted **2,050 ms / 41 ticks**. These are retained; neither run is a performance acceptance result.
- Native research uses explicitly enabled operator hooks. Its two private owner accounts are not two connected players, and claim-as-recorded-owner is not evidence of player authorization. FakePlayer GameTest exercises real launch/claim ownership separately; no terminal assembly/click, V1 or V2 evidence is claimed.

## Independent execution

All commands ran from `D:/GitHub/AdvancedRocketry-Community`, with `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`. No clean/world deletion was used. Before commands, both `build/gametest` and `build/gametest/world` were absent (`environment-before.json`), so this was a fresh-world GameTest run. Root had released all Gradle/server slots.

```powershell
.\gradlew.bat test --tests '*PlanetaryDiscoveryTest' --tests '*CelestialDefinitionCodecTest' --tests '*CelestialSchemaV2Test' --tests '*CelestialSavedDataTest' --tests '*SatelliteMissionRegistryTest' --tests '*SatelliteMissionSavedDataTest' --tests '*RocketTargetFlightPlannerTest' --tests '*RocketNavigationTest' --tests '*RocketFlightPlanPacketTest' --tests '*RocketMaintenanceStructureTest' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
.\gradlew.bat runData runGameTestServer --offline --no-daemon --no-build-cache --console=plain
$env:PYTHONUTF8='1'
& 'D:/python/pyenv/pyenv-win/shims/python.bat' -B -m unittest tests.test_v140_planetary_worlds_smoke tests.test_v140_celestial_schema_smoke -v
git diff --check
```

| Execution | Actual result |
|---|---|
| Forced focused JUnit | Exit 0; **57 tests / 10 suites**, zero failures/errors/skips; 16 actionable tasks executed, no cached test result; **50.066 s** receipt wall time |
| DataGen + GameTest | Exit 0; **235/235 required GameTests passed**; **154.948 s** receipt wall time; 5 executed/13 up-to-date Gradle tasks |
| DataGen | 34 existing generated JSON files; **written 0**, removed stale 0; generated diff unchanged |
| Python | Exit 0; **26 tests passed**, unittest duration **0.477 s** |
| Diff whitespace check | Exit 0 |

Exact arrays/timestamps are retained in `focused-junit-result.json`, `datagen-gametest-result.json`, and `python-result.json`. Full output is in their corresponding `.log` files; all focused JUnit XML is under `focused-junit-xml/`; native GameTest logs are under `gametest-logs/`. The terminal tool display truncated long GameTest output, but the complete Tee-Object file and copied server logs are retained.

The actual GameTest log executes `planetary_discovery:1` (one test), `planetary_physical_admission:1` (two), and `planetary_changed_pad:1` (two). Four Earth-pad install/restore pairs each restore 25 blocks. The new discovery case, including cached menu refresh and saturated-store replay, is included in the 235-pass result. No old assertion or timeout was changed by this reviewer.

Root's complete 898-JUnit run is separate context: root reported actual execution in `all-reused-04`, while its later clean build restored that result from cache. This independent pass claims only its own 57 actually executed JUnit tests, not a repeated full 898-test suite.

## Input and artifact identity

Baseline source HEAD remained `e810fb390dd30dbaa4506a59bffee00b1c78083b` during the before/after captures; this task reviewed the current uncommitted slice against that base. Root may subsequently commit these bytes. **1,344 tracked and explicit new-task runtime/build/Python/generated inputs** were hashed before and after; **zero drift**. The generated-resource diff was byte-identical before/after. Documentation was root-owned and excluded from the runtime drift claim.

Final runner correction was independently read: satellite launch targets now use the built-in bare words accepted by the pre-existing `StringArgumentType.word()` command (`SatelliteCommands.java:64-66`, normalization at `193-198`), not invalid namespaced tokens. The dedicated Python regression verifies this shape. This changes no Java parser or timeout. The earlier failed native attempt is retained and not relabeled.

Final reviewed inputs:

- `scripts/run_v140_planetary_worlds_smoke.py`: `8317d39756f882b0ee7893f1efc3b238537dde88d8e1a4cddf3738eb65bf73de`
- `tests/test_v140_planetary_worlds_smoke.py`: `21a8361ea4c4b137752852f46a0c209556fea0c89859db6bd1098bfb29c777ee`
- `PlanetaryDiscoveryGameTests.java`: `92a503b5c86fc2661911b985142969cbb6e956ddaf59b803d87c13d8cad8d132`

All three `build/libs` JARs remained byte-identical to before execution and root's immutable `artifacts-final/`:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Main | 2,608,569 | `086029e364e2c54ce1b398db9542eabf0c02caf6420b4e7ac3a657ab7bd1d7e9` |
| API | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1,186,739 | `94c274d732713d24cf470b7fd93d2574278a1d96eb09dbd0d7ca3a479caef3b1` |

Independent ZIP checks: CRCs valid, no duplicate entries or external test-mod fixture leakage; exactly **27 API class files**, all byte-identical to corresponding main-JAR classes. API JAR hash matches the earlier NAV/SKY API 1.7 artifact. All **34 current-version generated JSONs** occur exactly once and match source bytes in both main and sources JARs. The single packaged data-satellite definition has six intended targets and unchanged 200/120/100 duration/yield/cost. No standalone consumer or real-client rebuild was performed in this DISC review.

## Independent native readback

Evidence read-only root:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-discovery-1b0774f342554387ab7d491c64e7af64/native-02/`

`audit_native.py` uses only existing bounded low-level NBT/Anvil decoding primitives plus independently written assertions; it does not call the runner's acceptance functions or trust summary PASS alone. It ran with Python `-B`, exit 0; raw log and derived facts are in `native-artifact-audit.log/json`. It verified:

- All **149** native manifest members have their recorded SHA-256; membership is exact and unique.
- Three phase receipts have JVM exit 0; raw startup/stop/save logs and command arrays agree. Dedicated command uses Java 17, Forge 47.4.10, 1 GiB heap and the evidence hook flag. Baseline actually used the older MAP-01 pre-planet JAR `9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`; upgrade/restart used the final DISC main hash above. This is not a newly executed stable-v1.3 upgrade matrix.
- The pre-research Mars launch reports DISCOVERY_REQUIRED, required fuel zero, and an identical live rocket report before/after refusal. Later accepted surface flights show fuel **2000 → 1552 → 1019 → 504**. Restart retains 504.
- Raw gzip SavedData contains exactly three discoveries (Mars, Venus, gas giant), three claimed missions and three operational satellites. Their mission/satellite/owner/target IDs bind to actual launch logs; record schemas are 1, top-level stores 2, definitions are data-satellite, captured duration exactly 200; `resolved_at >= ready_at >= completes_at`. No first-visit record was fabricated in this no-player run.
- Raw private account totals are **40 balance / 240 earned / 200 spent** for the owner of the Mars and Venus missions; **20 / 120 / 100** for the second owner of the gas mission. Six upgrade claims are success/replay pairs; three restart claims are ALREADY_CLAIMED. Mission/satellite/account arrays and complete discovery payload match exactly across restart. The scheduler clock is intentionally excluded from authority equality across elapsed time.
- Bounded raw Anvil entity readback finds exactly one rocket per phase (material regions 4/4/4; empty regions 4/20/20; decoded entity chunks 30/37/37). Six rocket blocks and the native chest payload retain **17 diamonds and 64 iron ingots**. Final whole RocketEntityData is equal across restart. Final COMMITTED transfer journal and source/destination fuel 1019/504 agree with the entity; the raw final journal bytes remain equal.
- Native station count **1 → 3 → 3** retains the original record; upgrade/restart full station data match. Body binding count **3 → 6 → 6** preserves old bindings and explicit unmapped gas entry. World identity marker remains equal; raw level.dat hashes are retained, not asserted byte-identical or decoded as a full-world migration oracle.

Native stdout WARN counts are **26 / 11 / 12**, including the noted restart lag warning. Stdout/latest have no ERROR/FATAL or linkage exception matches. A broad case-insensitive debug-log search found one `DEBUG` message per process (`Error cleaning class output directory: .mixin.out`); these are not ERROR-level events. The original broad-search counts remain in `native-log-audit.json`. No product/client-linkage error was identified by the inspected log strings.

The first attempt at `native/` remains FAIL: its upgrade command sent `advancedrocketrycommunity:mars` to the word parser, produced no satellite-launch receipt, timed out, and recorded upgrade process exit 1. Its original world/logs were not changed. Final success belongs only to the corrected `native-02` run; it is not a retroactive success for that attempt.

## Review lineage and remaining scope

- Contract report: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-disc-contract-review-9f6ee1e5fdeb4973a9de00c92d65b887/REVIEW-CONTRACT.md`, SHA `bb90098afb2e84a51a99de1da4d2817232aff78eb4ca67bc01f1af498fcdc3ba`.
- Initial source report: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-disc-source-review-125f78863a4c4f22ac9684c5b11b1ba3/REVIEW-SOURCE-01.md`, SHA `2c78b480131c9030c331dd09a40039c39b1e31f6e0f7914acfc03bd2c3800705`.
- Actual-correction receipt: same source-review directory, `REVIEW-SOURCE-02.md`, SHA `fdd6f91bd978bff4d772af7c955cdf3aa9645ccb1a0fecb9ce133d4214dcafef`.

All initial observations remain valid historical review records; the final Java difference after receipt 02 was indentation, and the final Python delta is the documented command-token fix. No repository/index file was manually edited by this reviewer. Only authorized Gradle outputs/cache and this fresh Temp directory were written; generated resources had no byte changes. The excluded user bundle was never read. No remote, additional native launch, client, long load or child-agent work occurred.

**Gradle ownership was explicitly released after both commands terminated and post-hashes completed.** No owned Gradle or test-server session remains. Report/manifest preparation is terminal; no further tests are requested or implied. Remaining V1/V2/S2, broad migration, performance and full G0-G9 decisions stay open under the existing version/ADR boundaries.
