"""Read-only independent assertions over the final DISC captures, using bounded NBT primitives."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import re
import sys
import uuid
import zipfile
import xml.etree.ElementTree as ET

REPO = Path(r'D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-discovery-1b0774f342554387ab7d491c64e7af64')
ROOT = BASE / 'native-02'
sys.path.insert(0, str(REPO))
from scripts import run_v140_celestial_schema_smoke as nbt
from scripts import run_v130_adapter_flight_smoke as raw

HOST = 'advancedrocketrycommunity'
MAIN_SHA = '086029e364e2c54ce1b398db9542eabf0c02caf6420b4e7ac3a657ab7bd1d7e9'
API_SHA = '50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf'
SRC_SHA = '94c274d732713d24cf470b7fd93d2574278a1d96eb09dbd0d7ca3a479caef3b1'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def js(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def uid(words):
    assert len(words) == 4
    return str(uuid.UUID(int=sum((value & 0xffffffff) << (96 - 32*i) for i, value in enumerate(words))))

def dat(path):
    # Existing bounded parser only; no runner acceptance/summary oracle reused.
    return nbt.read_nbt(path)['data']

result = {'scope': 'independent raw-read audit; no server/client launched'}
listed = {}
for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8-sig').splitlines():
    value, name = line.split('  ', 1)
    assert name not in listed and not Path(name).is_absolute() and '..' not in Path(name).parts
    path = ROOT / name
    assert digest(path) == value, name
    listed[name] = value
actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
assert set(listed) == actual, (set(listed)-actual, actual-set(listed))
result['native_manifest_members'] = len(listed)

artifact_paths = {kind: next((BASE/'artifacts-final').glob(pattern)) for kind, pattern in
                  [('main', '*-dev.jar'), ('api', '*-api.jar'), ('sources', '*-sources.jar')]}
expected = {'main': MAIN_SHA, 'api': API_SHA, 'sources': SRC_SHA}
artifacts = {}
for kind, path in artifact_paths.items():
    assert digest(path) == expected[kind]
    assert digest(REPO/'build/libs'/path.name) == expected[kind]
    with zipfile.ZipFile(path) as jar:
        names = jar.namelist()
        assert len(names) == len(set(names)) and jar.testzip() is None
        assert not any('arceadaptertest/' in name or 'arce_adapter_test/' in name for name in names)
        artifacts[kind] = {'name': path.name, 'sha256': digest(path), 'bytes': path.stat().st_size, 'entries':len(names)}

satpath = f'data/{HOST}/satellite_definitions/data_satellite.json'
with zipfile.ZipFile(artifact_paths['main']) as main, zipfile.ZipFile(artifact_paths['api']) as api, zipfile.ZipFile(artifact_paths['sources']) as sources:
    classes = sorted(name for name in api.namelist() if name.endswith('.class'))
    assert len(classes) == 27 and all('/api/' in name for name in classes)
    assert {name for name in main.namelist() if '/api/' in name and name.endswith('.class')} == set(classes)
    assert all(main.read(name) == api.read(name) for name in classes)
    assert main.namelist().count(satpath) == sources.namelist().count(satpath) == 1
    resource = main.read(satpath)
    assert resource == sources.read(satpath) == (REPO/'src/generated/v1.4/resources'/satpath).read_bytes()
    definition = json.loads(resource)
    assert definition == {'schema_version':1, 'id':HOST+':data_satellite', 'mission_duration_ticks':200,
                          'research_yield':120, 'discovery_cost':100,
                          'allowed_targets': [HOST+':'+name for name in ('earth','moon','space','mars','venus','gas_giant')]}
    generated = list((REPO/'src/generated/v1.4/resources').rglob('*.json'))
    for path in generated:
        name = path.relative_to(REPO/'src/generated/v1.4/resources').as_posix()
        assert main.namelist().count(name) == sources.namelist().count(name) == 1, name
        assert main.read(name) == sources.read(name) == path.read_bytes(), name
    result['current_generated_json_count'] = len(generated)
result.update(artifacts=artifacts, api_classes=classes, satellite_definition=definition)

phases = ('baseline','upgrade','restart')
logs, commands, observations = {}, {}, {}
for phase in phases:
    directory = ROOT/phase
    logs[phase] = (directory/'stdout.txt').read_text(encoding='utf-8-sig')
    commands[phase] = js(directory/'commands.json')
    observations[phase] = js(directory/'observations.json')
    assert observations[phase]['exit_code'] == 0 and observations[phase]['result'] == 'PASS'
    assert 'Done (' in logs[phase] and 'Stopping server' in logs[phase] and 'Saving chunks' in logs[phase]
    assert commands[phase][-1] == 'stop' and 'save-all flush' in commands[phase]
    bad = [line for line in logs[phase].splitlines() if re.search(r'\b(ERROR|FATAL)\b',line)]
    assert not bad, bad
    assert not re.search(r'NoClassDefFoundError|ClassNotFoundException|Exception in thread|OutOfMemoryError',logs[phase])
    launch = js(directory/'launch.json')
    assert '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
    assert '-Xmx1024M' in launch['command'] and launch['command'][-1] == 'nogui'
    artifact = launch['artifact']
    assert digest(Path(artifact['path'])) == artifact['sha256']
    assert artifact['sha256'] == ('9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf' if phase == 'baseline' else MAIN_SHA)
result['processes'] = {p:{'exit':observations[p]['exit_code'],
                          'warnings':sum(bool(re.search(r'\bWARN\b',line)) for line in logs[p].splitlines()),
                          'lag_warnings':[line for line in logs[p].splitlines() if "Can't keep up" in line]}
                       for p in phases}

launch_re = re.compile(r'ARCE_RELEASE_TEST_SATELLITE_LAUNCH satellite=(\S+) mission=(\S+) owner=(\S+) target=(\S+) code=SUCCESS deadline=(\d+)')
claim_re = re.compile(r'ARCE_RELEASE_TEST_SATELLITE_CLAIM mission=(\S+) owner=(\S+) target=(\S+) code=(\S+) status=(\S+) research=(\d+) discovered=(\S+)')
receipts = launch_re.findall(logs['upgrade'])
assert len(receipts) == 3 and len({entry[1] for entry in receipts}) == 3
assert {entry[3] for entry in receipts} == {HOST+':'+name for name in ('mars','venus','gas_giant')}
assert 'code=DISCOVERY_REQUIRED required_fuel=0 fuel_before=2000' in logs['upgrade']
report_re = re.compile(r'ARCE_RELEASE_TEST_FLIGHT_REPORT (.+)')
flight_reports = report_re.findall(logs['upgrade'])
assert flight_reports[0] == flight_reports[1] and 'fuel=2000 ' in flight_reports[0]
for phase, expected_codes in [('upgrade',['SUCCESS','ALREADY_CLAIMED']*3),('restart',['ALREADY_CLAIMED']*3)]:
    claims = claim_re.findall(logs[phase])
    assert [entry[3] for entry in claims] == expected_codes
    for mission, owner, body, code, status, balance, discovered in claims:
        launch = next(entry for entry in receipts if entry[1] == mission)
        assert (owner,body,status,discovered) == (launch[2],launch[3],'CLAIMED','true')
for command in commands['upgrade']:
    if command.startswith('arce satellite release-test launch '):
        assert command.split()[-1] in ('mars','venus','gas_giant') and ':' not in command

raw_authority = {}
for phase in ('upgrade','restart'):
    directory = ROOT/phase
    progress = dat(directory/f'{HOST}_celestial.dat')
    registry = dat(directory/f'{HOST}_satellite_missions.dat')
    assert progress['schema_version'] == registry['schema_version'] == 2
    assert len(progress['bodies']) == 3 and {p['id'] for p in progress['bodies']} == {e[3] for e in receipts}
    assert all(p['discovered_at'] >= 0 and 'first_visit_at' not in p for p in progress['bodies'])
    missions = {uid(m['mission_id']):m for m in registry['missions']}
    satellites = {uid(s['satellite_id']):s for s in registry['satellites']}
    accounts = {uid(a['owner_id']):a for a in registry['research_accounts']}
    assert len(missions) == len(registry['missions']) == len(satellites) == len(registry['satellites']) == 3
    owners = collections.Counter(e[2] for e in receipts)
    assert set(accounts) == set(owners) and len(accounts) == len(registry['research_accounts']) == 2
    for satellite_id, mission_id, owner, target, deadline in receipts:
        m, s = missions[mission_id], satellites[satellite_id]
        assert m['schema_version'] == s['schema_version'] == 1
        assert m['definition_id'] == s['definition_id'] == HOST+':data_satellite'
        assert uid(m['satellite_id']) == satellite_id and uid(m['owner_id']) == uid(s['owner_id']) == owner
        assert m['target_body_id'] == target and m['completes_at'] == int(deadline)
        assert m['completes_at']-m['started_at'] == 200 and m['started_at'] >= 0
        assert m['resolved_at'] >= m['ready_at'] >= m['completes_at']
        assert (m['status'],m['research_yield'],m['discovery_cost'],m['discovery_required']) == ('claimed',120,100,1)
        assert s['status'] == 'operational' and 'current_mission_id' not in s
    for owner,count in owners.items():
        a=accounts[owner]
        assert (a['schema_version'],a['balance'],a['lifetime_earned'],a['lifetime_spent']) == (1,20*count,120*count,100*count)
    authority={'progress':progress, **{k:registry[k] for k in ('missions','satellites','research_accounts')}}
    assert authority == js(directory/'research.json')
    raw_authority[phase]=authority
assert raw_authority['upgrade'] == raw_authority['restart']
result['research']={'launch_receipts':receipts,'accounts':raw_authority['upgrade']['research_accounts'],
                    'exact_authority_replay_equality':True,'claims_upgrade':6,'claims_restart':3}

stations = {phase:dat(ROOT/phase/'stations.dat') for phase in phases}
assert [len(stations[p]['stations']) for p in phases] == [1,3,3]
assert all(old in stations['upgrade']['stations'] for old in stations['baseline']['stations'])
assert stations['upgrade'] == stations['restart']
bindings = {phase:js(ROOT/phase/'bindings.json') for phase in phases}
assert [len(bindings[p]['bindings']) for p in phases] == [3,6,6]
assert all(old in bindings['upgrade']['bindings'] for old in bindings['baseline']['bindings'])
assert bindings['upgrade'] == bindings['restart']
assert {'body_id':HOST+':gas_giant'} in bindings['upgrade']['bindings']
result['station_counts']=[1,3,3]
result['binding_counts']=[3,6,6]

entities = {}
for phase in phases:
    found=[]; material=empty=chunks=0
    for path in (ROOT/phase/'native').rglob('*.mca'):
        payload=path.read_bytes()
        if not payload:
            empty+=1
            continue
        material+=1
        assert 8192 <= len(payload) <= raw.region_nbt.MAX_REGION_BYTES
        _,rx,rz,_=path.name.split('.')
        for index in range(1024):
            if payload[index*4:index*4+4] == b'\0'*4:
                continue
            chunks+=1
            x,z=int(rx)*32+index%32,int(rz)*32+index//32
            for entity in raw.decode_entities(raw.region_nbt._region_chunk(payload,x,z),x,z)['Entities']:
                if entity.get('id') == HOST+':rocket':
                    found.append(entity)
    assert material<=16 and empty<=32 and chunks<=128 and len(found)==1
    data=found[0]['RocketEntityData']; entities[phase]=data
    assert data['flight_data']['fuel']['amount'] == (2000 if phase=='baseline' else 504)
    assert data['flight_data']['state'] == ('FUELED' if phase=='baseline' else 'LANDED')
    assert data['flight_data']['current_dimension']=='minecraft:overworld'
    assert uid(data['owner_id'])=='00000000-0000-0000-0000-000000000005'
    snapshot=data['snapshot']; assert len(snapshot['relative_blocks'])==6
    payloads=[block['block_entity'] for block in snapshot['relative_blocks'] if 'block_entity' in block]
    assert len(payloads)==1 and payloads[0]['data']['Items']==[
        {'Slot':0,'id':'minecraft:diamond','Count':17},{'Slot':1,'id':'minecraft:iron_ingot','Count':64}]
    result.setdefault('entity_scan',{})[phase]={'material_regions':material,'empty_regions':empty,'chunks':chunks,'rockets':len(found)}
assert entities['upgrade']==entities['restart']
for phase in ('upgrade','restart'):
    journal=dat(ROOT/phase/'transfers.dat')
    assert journal['schema_version']==2 and len(journal['transfers'])==1
    record=journal['transfers'][0]
    assert record['phase']=='COMMITTED' and record['required_fuel']==515
    assert record['destination_snapshot']==entities[phase]['snapshot']
    assert record['source_flight']['fuel']['amount']==1019 and record['destination_flight']['fuel']['amount']==504
assert (ROOT/'upgrade/transfers.dat').read_bytes()==(ROOT/'restart/transfers.dat').read_bytes()
assert (ROOT/'upgrade/inputs/world/.v002-smoke-world-identity.json').read_bytes()==(ROOT/'restart/inputs/world/.v002-smoke-world-identity.json').read_bytes()
result['raw_saved_world']={'final_fuel':504,'cargo':[17,64],'retained_final_transfer':'COMMITTED',
                          'level_dat_hashes':{p:digest(ROOT/p/'inputs/world/level.dat') for p in phases}}

failed=BASE/'native'
failed_observation=js(failed/'upgrade/observations.json')
assert failed_observation['result']=='FAIL'
failed_commands=js(failed/'upgrade/commands.json')
assert any(c.startswith('arce satellite release-test launch ') and c.split()[-1]==HOST+':mars' for c in failed_commands)
failed_log=(failed/'upgrade/stdout.txt').read_text(encoding='utf-8-sig')
assert not launch_re.search(failed_log)
result['retained_initial_attempt']={'upgrade_exit_code':failed_observation['exit_code'],'error':failed_observation['error'],
                                  'no_mission_launch_receipt':True,'stdout_sha256':digest(failed/'upgrade/stdout.txt')}

xmls=list((OUT/'focused-junit-xml').glob('TEST-*.xml'))
totals=collections.Counter()
for path in xmls:
    root=ET.parse(path).getroot()
    for key in ('tests','failures','errors','skipped'):totals[key]+=int(root.attrib.get(key,0))
assert totals['failures']==totals['errors']==totals['skipped']==0
result['focused_junit']={'suites':len(xmls),**totals}
result['status']='PASS'
(OUT/'native-artifact-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
