from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path('D:/GitHub/AdvancedRocketry-Community')
temp = Path(__file__).parent
source = root / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
previous = temp / 'artifacts' / source.name
destination = temp / 'final-artifacts' / source.name
destination.parent.mkdir(exist_ok=True)
shutil.copyfile(source, destination)

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

assert digest(source) == digest(destination)
with zipfile.ZipFile(previous) as before, zipfile.ZipFile(destination) as after:
    names = set(before.namelist()) | set(after.namelist())
    delta = [name for name in sorted(names)
             if name not in before.namelist() or name not in after.namelist()
             or before.read(name) != after.read(name)]
record = {'name': source.name, 'bytes': destination.stat().st_size,
          'sha256': digest(destination), 'path': str(destination),
          'native_executed_sha256': digest(previous),
          'changed_archive_entries': delta,
          'scope': 'Final independent consumer after GameTest diagnostic-format fix; native processes used the earlier explicit hash'}
(temp / 'final-fixture-identity.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record, indent=2))
