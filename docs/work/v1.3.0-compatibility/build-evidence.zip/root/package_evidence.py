"""Archive this bounded compatibility slice without changing original captured bytes."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).parent
OUT = ROOT / 'docs/work/v1.3.0-compatibility'
REVIEW = TEMP.parent / 'arce-v130-compat-final-review-np14x25n'

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')

def archive(name, groups):
    with zipfile.ZipFile(OUT / name, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for source, prefix in groups:
            paths = [source] if source.is_file() else sorted(p for p in source.rglob('*') if p.is_file())
            for path in paths:
                assert not path.is_symlink(), path
                relative = path.name if source.is_file() else path.relative_to(source).as_posix()
                z.write(path, prefix + relative)

def summarize():
    tests = [ET.parse(p).getroot() for p in (TEMP / 'final-junit').glob('TEST-*.xml')]
    junit = {'suites': len(tests), **{k: sum(int(t.attrib.get(k, 0)) for t in tests)
                                    for k in ('tests', 'failures', 'errors', 'skipped')}}
    assert junit == {'suites': 143, 'tests': 769, 'failures': 0, 'errors': 0, 'skipped': 0}, junit
    write_json(TEMP / 'junit-summary.json', junit)
    runtime = TEMP / 'runtime-evidence'
    summary = json.loads((runtime / 'summary.json').read_text())
    assert summary['result'] == 'PASS'
    manifest = (runtime / 'SHA256SUMS').read_text().splitlines()
    for line in manifest:
        sha, relative = line.split('  ', 1)
        assert digest(runtime / relative) == sha, relative
    cycles = []
    for cycle in summary['cycles']:
        phase = cycle['phase']
        raw = (runtime / phase / 'stdout.txt').read_text(encoding='utf-8')
        count = raw.count('ARCE_ADAPTER_REGISTRATION_CONFLICTS rejected=2')
        assert count == 1 and 'ARCE_ADAPTER_FAULT' not in raw and cycle['exit_code'] == 0
        elapsed = (datetime.datetime.fromisoformat(cycle['completed_at'])
                   - datetime.datetime.fromisoformat(cycle['started_at'])).total_seconds()
        cycles.append({'phase': phase, 'exit_code': cycle['exit_code'], 'elapsed_seconds': elapsed,
                       'conflict_receipts': count, 'fault_receipts': 0,
                       'probes': len(cycle['probes']), 'log_counts': cycle['log_counts'],
                       'lag_warnings': [s for s in raw.splitlines() if "Can't keep up" in s]})
    audit = {'manifest_files': len(manifest), 'cycles': cycles,
             'elapsed_seconds': sum(c['elapsed_seconds'] for c in cycles),
             'probes': sum(c['probes'] for c in cycles)}
    write_json(TEMP / 'native-audit.json', audit)
    print(json.dumps({'junit': junit, 'native': audit}, indent=2))

def links():
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', '*.md'], cwd=ROOT).decode().split('\0')
    paths = {ROOT / p for p in tracked if p}
    paths.update((ROOT / 'docs/API-COMPATIBILITY.md', OUT / 'VERIFICATION.md'))
    failures, checked = [], 0
    for path in sorted(paths):
        if not path.exists():
            continue
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith(('#', 'mailto:')) or re.match(r'^[A-Za-z]:[/\\]', target):
                continue
            relative = urllib.parse.unquote(target.split('#', 1)[0])
            if not relative:
                continue
            checked += 1
            if not (path.parent / relative).exists():
                failures.append([str(path.relative_to(ROOT)), target])
    result = {'checked': checked, 'missing': failures, 'scope': 'tracked Markdown plus explicit new compatibility docs; excluded untracked user bundle'}
    write_json(TEMP / 'links.json', result)
    print(json.dumps(result))
    assert not failures

def package():
    assert (REVIEW / 'REVIEW.md').is_file(), 'Final independent review is not yet available'
    for line in (REVIEW / 'SHA256SUMS').read_text().splitlines():
        sha, relative = line.split('  ', 1)
        assert digest(REVIEW / relative) == sha, relative
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ('artifact-identities.json', 'final-fixture-identity.json', 'junit-summary.json', 'native-audit.json'):
        write_json(OUT / name, json.loads((TEMP / name).read_text()))
    write_json(OUT / 'runtime-summary.json', json.loads((TEMP / 'runtime-evidence/summary.json').read_text()))
    logs = [(p, 'root/') for p in sorted(TEMP.glob('*.log'))]
    logs.extend((TEMP / p, 'root/') for p in ('library-identities.json', 'links.json', 'package_evidence.py', 'freeze_final_fixture.py', 'verify_staged.py'))
    logs.append((TEMP / 'consumer-reports', 'consumer/'))
    archive('build-evidence.zip', logs)
    archive('junit-full.zip', [(TEMP / 'final-junit', 'test/')])
    archive('native-runtime.zip', [(TEMP / 'runtime-evidence', '')])
    archive('review-history.zip', [
        (TEMP.parent / 'arce-v130-compat-inventory-3ek4iqly', 'inventory/'),
        (TEMP.parent / 'arce-v130-compat-source-review-aj4hikyd', 'initial-source/')])
    archive('independent-review.zip', [(REVIEW, '')])
    sums = ''.join(f'{digest(p)}  {p.name}\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256SUMS')
    (OUT / 'SHA256SUMS').write_text(sums, encoding='ascii', newline='\n')
    print(sums)

if __name__ == '__main__':
    {'summarize': summarize, 'links': links, 'package': package}[sys.argv[1]]()
