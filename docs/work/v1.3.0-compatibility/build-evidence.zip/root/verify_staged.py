"""Read-only comparison of this slice's working and staged evidence bytes."""
from pathlib import Path
import hashlib
import subprocess

base = Path('docs/work/v1.3.0-compatibility')
lines = (base / 'SHA256SUMS').read_text().splitlines()
for line in lines:
    sha, name = line.split('  ', 1)
    path = base / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == sha, ('working', name)
    staged = subprocess.check_output(['git', 'show', ':' + path.as_posix()])
    assert hashlib.sha256(staged).hexdigest() == sha, ('staged', name)
assert len(lines) == 11
print('PASS: all 11 evidence hashes match both working and staged bytes')
