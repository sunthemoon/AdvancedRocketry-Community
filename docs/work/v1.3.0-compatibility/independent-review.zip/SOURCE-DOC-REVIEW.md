# V130-COMPAT — revised source/documentation review

Independent delegated review; tracked tree read-only. Baseline `c9b79e57a011b258ea09b713947ac2ed04e95d5e`. Root owns implementation and is still running builds. This is a pre-verification checkpoint, not a final result or Gate approval.

## Findings

No unresolved source/documentation finding in the revised scope inspected here. Both prior test-oracle findings are addressed in actual source:

- `AdapterFaultGameTests.java:108–110` now requires the bounded `RocketSnapshotException` diagnostic specifically for oversized capture. Given the generated otherwise-valid body, this distinguishes the payload-size validation from an earlier timing exception. An incidental slow callback now fails this test rather than falsely satisfying its oracle.
- `FixtureInventoryAdapter.java:19–20` counts captures while the synchronous restore scope is active. `AdapterFaultGameTests.java:136–137` requires one for RESTORE_MISMATCH and zero for the earlier false/throw/slow failures. Production cleanup does not otherwise capture the failed cargo target, so this observes the intended post-restore readback branch.
- Receipt logging moved out of the timed provider into `AdapterFaultGameTests.java:184–192`. Source-instance probes, finally-cleared restore scope, exact resource/authority comparisons and retry behavior remain intact. No production budget, assertion or timeout was weakened.

The previous report and source snapshot remain preserved separately at `../arce-v130-compat-source-review-aj4hikyd/`; they are not rewritten as if the fixes existed initially.

## Documentation and evidence boundary

- `docs/API-COMPATIBILITY.md:10–27` distinguishes the tested development platform, historical Forge compatibility lane, compile-only classifier, loader/network constraints and unknown combinations.
- Its inventory (`:29–52`) matches all 27 exported classes, including the nested environment enum, and minimum API minors 1.0–1.7. MOD-bus registration versus server-bound FORGE-bus query lifecycle is correctly distinguished.
- The seven-family matrix and linked per-slice evidence (`:54–69`) preserve historical artifact identities rather than claiming current universal certification. Removal/failure semantics (`:71–104`) retain opaque-resource and same-JVM/preemption/power-loss limitations. Support/deprecation wording (`:106–120`) follows ADR-021.
- `compat-test-mod/README.md` corrects the stale export count and supplies the missing flight/fuel/environment navigation. It explicitly distinguishes development source-set GameTests from packaged runtime evidence and same-mod conflicting registration attempts from two independently authored mods. Fixture faults are not advertised as normal gameplay or a sandbox.
- Public guide, root README and document index link to the new matrix without assigning a release/Gate verdict. The public guide's existing detailed limits and examples remain unchanged.

## Actual checks performed

Read actual tracked diffs and both new Java files, the new compatibility matrix, five reader-document changes, and the active plan entry. Checked revised behavior against the production wrapper, payload validation, restore readback/cleanup and ADR-022 reviewed earlier.

Ran read-only Git/PowerShell/rg inspection and a bounded Python `-B` helper. It found all **94** local Markdown link destinations present across the five reviewed reader documents and no direct non-API host imports in the fixture Java tree. `source-doc-review.json` contains actual source/document hashes. `source-doc.diff` and exact file copies are retained in `source-doc-snapshot/`.

No Gradle, Java/server, test, network or Git-mutation command was run at this checkpoint. Documentation files may still receive evidence updates by root. Independent GameTest/consumer verification is pending explicit shared-build release. No final completion is declared.
