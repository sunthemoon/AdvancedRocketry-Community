from pathlib import Path
import hashlib, json, re, shutil, subprocess, zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
EVIDENCE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-compat-1790486012553')
PREFIX = 'io/github/sunthemoon/advancedrocketrycommunity/'
FIXTURE = 'io/github/sunthemoon/arceadaptertest/'

def sha(path, algorithm='sha256'):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()

def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))

build = (ROOT / 'compat-test-mod/build.gradle').read_text()
expected = {PREFIX + s for s in re.findall(r"'(api/[^']+\.class)'", build.split('repositories {')[0])}
assert len(expected) == 27
api = ROOT / 'build/libs/advancedrocketry-community-1.20.1-1.3.0-dev-api.jar'
main = ROOT / 'build/libs/advancedrocketry-community-1.20.1-1.3.0-dev.jar'
sources = ROOT / 'build/libs/advancedrocketry-community-1.20.1-1.3.0-dev-sources.jar'
fixture = ROOT / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
with zipfile.ZipFile(api) as a, zipfile.ZipFile(main) as m:
    assert {n for n in a.namelist() if n.endswith('.class')} == expected
    assert {n for n in m.namelist() if n.startswith(PREFIX + 'api/') and n.endswith('.class')} == expected
    for name in expected:
        data = a.read(name)
        assert data == m.read(name)
        assert not re.search(PREFIX.encode() + rb'(?!api/)', data)
        assert b'net/minecraft/client/' not in data and b'net/minecraftforge/client/' not in data
        assert b'com/mojang/blaze3d/' not in data
for path in (main, api, sources):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert not any(FIXTURE in n or 'arce_adapter_test/' in n for n in names)
with zipfile.ZipFile(fixture) as archive:
    classes = [n for n in archive.namelist() if n.endswith('.class')]
    assert classes and all(n.startswith(FIXTURE) for n in classes)
    assert not any(n.startswith('META-INF/jarjar/') for n in archive.namelist())

report_dir = ROOT / 'compat-test-mod/build/reports/consumer'
destination = OUT / 'consumer-reports'
destination.mkdir(exist_ok=True)
for name in ('classpath.json', 'negative-import.json', 'fixture-artifact.json'):
    shutil.copy2(report_dir / name, destination / name)
classpath = load(destination / 'classpath.json')
negative = load(destination / 'negative-import.json')
fixture_report = load(destination / 'fixture-artifact.json')
assert fixture_report['sha256'] == sha(fixture)
assert classpath['requested_api'].endswith(':advancedrocketry-community:1.20.1-1.3.0-dev:api')
for field in ('published_file', 'raw_api'):
    assert sha(Path(classpath[field])) == sha(api)
mapped = Path(classpath['remapped_api'])
assert sha(mapped) == classpath['remapped_sha256']
with zipfile.ZipFile(mapped) as archive:
    assert {n for n in archive.namelist() if n.endswith('.class')} == expected
assert len(classpath['compile_classpath']) == 114
actual_host_artifacts = []
for dependency in classpath['compile_classpath']:
    path = Path(dependency['file'])
    assert path.is_file() and path.suffix == '.jar' and sha(path) == dependency['sha256']
    with zipfile.ZipFile(path) as archive:
        host = {n for n in archive.namelist() if PREFIX in n and n.endswith('.class')}
        if host:
            assert path.resolve() == mapped.resolve() and host == expected
            actual_host_artifacts.append(str(path))
assert len(actual_host_artifacts) == 1
assert negative['exit_code'] == 1
assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in negative['diagnostics']
with zipfile.ZipFile(Path(negative['inspected_host_jar'])) as archive:
    assert negative['existing_internal_type'] in archive.namelist()
assert sha(Path(negative['inspected_host_jar'])) == sha(main)
for source in classpath['fixture_sources']:
    assert sha(Path(source['file'])) == source['sha256']
cache_input = Path(str(mapped) + '.input')
cache_text = cache_input.read_text()
assert 'orig=' + sha(api, 'sha1') in cache_text
shutil.copy2(cache_input, OUT / 'mapped-api.jar.input')

original_fixture = EVIDENCE / 'artifacts' / fixture.name
with zipfile.ZipFile(original_fixture) as old, zipfile.ZipFile(fixture) as new:
    names = set(old.namelist()) | set(new.namelist())
    changed = [n for n in sorted(names) if n not in old.namelist() or n not in new.namelist() or old.read(n) != new.read(n)]
assert changed == [FIXTURE + 'AdapterFaultGameTests.class'], changed
before = load(OUT / 'before-reruns.json')
source_changes = []
for name, digest in before['source_sha256'].items():
    now = sha(ROOT / name)
    if now != digest: source_changes.append({'file': name, 'before': digest, 'after': now})
assert [x['file'] for x in source_changes] == ['src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterFaultGameTests.java']
for path in (main, api, sources):
    assert sha(path) == before['artifacts'][path.relative_to(ROOT).as_posix()]['sha256']
facts = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'api_classes': len(expected), 'fixture_classes': len(classes), 'classpath_jars': len(classpath['compile_classpath']),
    'fixture_sources': len(classpath['fixture_sources']), 'source_files_compared': len(before['source_sha256']),
    'source_changes': source_changes, 'fixture_native_to_final_changed_entries': changed,
    'mapped_api_sha256': sha(mapped), 'mapped_input': cache_text,
    'native_fixture_sha256': sha(original_fixture),
    'artifacts': {str(p.relative_to(ROOT)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in (main,api,sources,fixture)}}
(OUT / 'artifact-audit.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8')
print(json.dumps(facts, indent=2))
