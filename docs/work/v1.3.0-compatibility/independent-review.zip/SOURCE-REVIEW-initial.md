# V130-COMPAT — independent source review, pre-verification

Baseline HEAD `c9b79e57a011b258ea09b713947ac2ed04e95d5e`. This report covers the six actual new/changed adapter fixture Java files, inspected against ADR-022 and the installed wrapper/scanner/disassembly implementation. Root is the sole tracked writer. Source copies, hashes and tracked diff are retained here; no build or test was run by this reviewer. Documentation/matrix are not yet part of this review.

## Findings

### Medium — generic rejection can mask the intended oversized-payload validation

`src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterFaultGameTests.java:101–106` requires only `UNSUPPORTED_BLOCK_ENTITY` and a reached callback. `FixtureInventoryAdapter.java:18–24` logs/captures/allocates the oversized body inside the timed capture callback. If that callback takes over 5 ms, `ExternalRocketBlockEntityAdapter.java:76–84` rejects before envelope encoding/size validation. The oversized test could therefore pass without exercising the advertised size-check path.

Minimal correction: for CAPTURE_OVERSIZED, also check the already saved bounded diagnostic identifies `RocketSnapshotException`, rather than the timing `IllegalStateException`. The fixture's generated envelope is otherwise valid, so the size rejection at `rocket/model/RocketBlockEntityPayload.java:26–31` is distinguishable without internal imports or a production change. Do not weaken the 5 ms budget.

### Low — restore-mismatch callback occurrence does not prove readback occurrence

`AdapterFaultGameTests.java:125–142` proves the fault callback was entered, the rocket's full `RocketEntityData` survived, partial blocks/inventory were cleared and healthy retry succeeded. However, RESTORE_MISMATCH may also be rejected by incidental callback timing before the host reaches post-restore capture. `rocket/forge/RocketBlockEntityAdapters.java:54–56` short-circuits at restore before readback; the fixture records only restore entry.

If this test/evidence claims post-restore mismatch validation, add a fixture-only readback-capture observation while the synchronous restore scope is active and require exactly one for RESTORE_MISMATCH. This distinguishes the intended path without changing production APIs, timeout limits or resource semantics.

## Other inspected behavior

- Each scan fault lives on its source BE instance (`FixtureContainerBlockEntity.java:20–21`); it is absent from capture and native save. Healthy retry explicitly clears it. Even a failed assertion does not install a global source fault.
- Restore fault selection is a thread-local synchronous scope with `finally` removal and nested-scope rejection (`FixtureAdapterFaults.java:40–47`). The extra scope-cleanup GameTest checks propagation of the original thrown exception and removal.
- Production `RocketEntity.interact` synchronously invokes the installed runtime on the logical server; no replacement registry/manager or host-internal import is used by these tests. Restore faults run after writing the new target's owned inventory only. Existing checked cleanup and rollback are therefore exercised, not simulated by deleting test blocks.
- All physical fixtures use the 16-cube `rocket_test` template; source geometry and horizontal query bounds remain within that reserved footprint. Pure scope/conflict tests use `empty` without world fixtures. FakePlayer identities are per-test, not the global cache.
- Restore tests compare complete `RocketEntityData`, require one surviving rocket, air/no BE at every original block, no nearby item drops, then successful restore to a distinct BE and exact live/native item metadata. Scan tests require the original source BE and exact inventory survive, then successful assembly/disassembly. These are bounded loaded-region observations, not an unbounded whole-world search.
- Actual MOD-bus conflict probes use valid positive versions/owned IDs/known types, after the first successful registration. One duplicates the ID with an otherwise valid furnace type; one claims the already owned fixture type under a different ID. Unexpected success throws, and the new test requires exactly two caught `IllegalArgumentException`s. This is same-mod external registration conflict coverage, not two separately packaged malicious mods.
- No production Java, public API, schema or build change is in the inspected diff. API 1.7 remains the contract. A per-adapter warning is only emitted once by the production wrapper, so logs should not be expected to contain one warning per slow mode.

## Suggested bounded independent verification after release of shared build output

1. Re-run `runGameTestServer --offline --no-daemon --no-build-cache` (no clean), preserving all results and checking the eleven new fixture methods, all nine fault markers, actual conflict count and the single per-adapter slow warning. These new cases require real Forge execution; unchanged injected-clock JUnit tests cannot replace them.
2. Re-run `-p compat-test-mod verifyConsumerBoundary --offline --no-daemon --no-build-cache`, inspecting final raw/remapped API provenance, negative internal import and fixture exclusion. No host API additions should appear.
3. Optional complementary focused JUnit: `ExternalRocketBlockEntityAdapterBudgetTest`, `RocketAdapterPayloadsTest`, `RocketAdapterRegistryTest`, `RocketTransactionExceptionTest` and `RocketBlockRecoveryTest`, using `--rerun-tasks` if execution is claimed.

Root owns command scheduling and may select the minimal relevant rerun. No server/build has been launched here while root builds.

## Boundaries / commands actually run

Read-only `git status --short`, `git diff --stat HEAD`, `git diff HEAD -- src/adapterTest/...`, `rg` and numbered PowerShell `Get-Content`; bounded Python `-B` source hashing/copying only into this fresh Temp directory. One initial guessed source path and wildcard search were invalid; correct existing files were subsequently located/read. No test failure or execution is inferred from those lookup errors.

No native save/restart/journal-cut verification is added by these GameTests. The immediate successful retry indirectly tests release of blocking transaction state, but is not a raw persisted journal audit. No real player network, cross-mod side-effect sandbox, non-returning callback preemption, client/GPU, forced crash, load or Required Gate approval is inferred. Final report remains pending root's frozen source and independent runtime/artifact verification authorization.
