from pathlib import Path
import gzip, hashlib, importlib.util, io, json, re, struct, sys, uuid

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUNTIME = Path(sys.argv[1])
OUTPUT = Path(sys.argv[2])
spec = importlib.util.spec_from_file_location('bounded_nbt', ROOT / 'scripts/inspect_celestial_saved_data.py')
nbt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nbt)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def native(path, large=False):
    assert path.is_file() and not path.is_symlink() and path.stat().st_size < 4 * 1024**2
    nbt.MAX_DEPTH = 32 if large else 16
    nbt.MAX_TAGS = 65536 if large else 4096
    nbt.MAX_COLLECTION_ENTRIES = 65536 if large else 4096
    with gzip.GzipFile(fileobj=io.BytesIO(path.read_bytes())) as stream:
        data = stream.read(4 * 1024**2 + 1)
    assert len(data) <= 4 * 1024**2
    return nbt.NbtReader(data).read_root()

def identifier(words):
    assert len(words) == 4
    return str(uuid.UUID(bytes=b''.join(struct.pack('>I', x & 0xffffffff) for x in words)))

manifest = {}
for line in (RUNTIME / 'SHA256SUMS').read_text().splitlines():
    sha, name = line.split('  ', 1)
    assert name not in manifest
    path = (RUNTIME / name).resolve()
    assert path.is_relative_to(RUNTIME.resolve()) and digest(path) == sha
    manifest[name] = sha
actual_names = {p.relative_to(RUNTIME).as_posix() for p in RUNTIME.rglob('*') if p.is_file()}
assert actual_names == set(manifest) | {'SHA256SUMS'}

observations = {'runtime': str(RUNTIME), 'manifest_count': len(manifest),
                'manifest_sha256': digest(RUNTIME / 'SHA256SUMS'), 'phases': {}}
previous_station = None
previous_level = None
for phase in ('create', 'restart'):
    folder = RUNTIME / phase
    data = native(folder / 'world/data/advancedrocketrycommunity_stations.dat')['data']
    assert data['schema_version'] == 2 and data['reservations'] == [] and len(data['stations']) == 2
    stations = {identifier(s['station_id']): s for s in data['stations']}
    assert len(stations) == 2
    assert {s['orbit_body'] for s in stations.values()} == {
        'advancedrocketrycommunity:earth', 'advancedrocketrycommunity:moon'}
    for station in stations.values():
        assert station['environment']['gravity_milli'] == 0 and station['environment']['vacuum'] == 1
        assert station['members'] == [] and station['invitations'] == []
        assert station['landing_pad'][1] == 128
    level = native(folder / 'world/level.dat', large=True)['Data']
    if previous_station is not None:
        assert data == previous_station
        assert level['WorldGenSettings']['seed'] == previous_level['WorldGenSettings']['seed']
        assert level['Time'] > previous_level['Time']
        assert (folder / 'world/data/advancedrocketrycommunity_stations.dat').read_bytes() == (
            RUNTIME / 'create/world/data/advancedrocketrycommunity_stations.dat').read_bytes()
    previous_station, previous_level = data, level
    stdout = (folder / 'stdout.txt').read_text(encoding='utf-8')
    probes = [json.loads(line.split('ARCE_ENV_PROBE ', 1)[1]) for line in stdout.splitlines() if 'ARCE_ENV_PROBE ' in line]
    by_label = {p['label']: p for p in probes}
    labels = {'earth', 'moon', 'space_gap', 'unknown', 'earth_orbit', 'moon_orbit'}
    if phase == 'create': labels |= {'reloaded_moon', 'reloaded_orbit'}
    assert set(by_label) == labels and len(probes) == len(labels)
    for probe in probes:
        assert not probe['loaded_before'] and not probe['loaded_after']
    assert by_label['earth']['snapshot']['gravity'] == 1.0
    assert by_label['moon']['snapshot']['gravity'] == (0.165 if phase == 'create' else 0.4)
    assert not by_label['unknown']['resolved'] and not by_label['space_gap']['resolved']
    for body in ('earth', 'moon'):
        snap = by_label[body + '_orbit']['snapshot']
        assert snap['locus'] == 'STATION_ORBIT' and snap['instance'] in stations
        station = stations[snap['instance']]
        assert station['orbit_body'] == snap['body'] == 'advancedrocketrycommunity:' + body
        assert snap['gravity'] == 0.0 and snap['vacuum'] is True and 'atmosphere' not in snap
    if phase == 'create':
        assert by_label['reloaded_moon']['snapshot']['gravity'] == 0.4
        assert by_label['reloaded_orbit']['snapshot'] == by_label['moon_orbit']['snapshot']
        assert 'Accepted celestial catalog generation 2 with 3 bodies' in stdout
    log_observations = {}
    for name in ('stdout.txt', 'debug.log', 'latest.log'):
        text = (folder / name).read_text(encoding='utf-8')
        errors = [line for line in text.splitlines() if re.search(r'/(?:ERROR|FATAL)\]|\[(?:ERROR|FATAL)\]', line)]
        assert not errors, (phase, name, errors)
        assert 'ARCE_ADAPTER_FAULT mode=' not in text
        assert text.count('ARCE_ADAPTER_REGISTRATION_CONFLICTS rejected=2') == 1
        assert text.count('Environment query handle ready (API 1.7)') == 1
        assert text.count('Environment query handle expired at server stopping') == 1
        for receipt in ('Registered rocket adapter arce_adapter_test:cargo_inventory',
                        'Registered rocket components', 'Registered rocket fuels', 'Registered satellite payload',
                        'Registered atmosphere boundary', 'Registered suit equipment'):
            assert text.count(receipt) == 1, (phase, name, receipt)
        assert 'All dimensions are saved' in text and 'Stopping server' in text
        log_observations[name] = {'sha256': digest(folder / name), 'errors': errors,
                                 'lag_warnings': [x for x in text.splitlines() if "Can't keep up!" in x]}
    result = load(folder / 'result.json')
    assert result['exit_code'] == 0
    launch = load(folder / 'launch.json')
    assert len(launch['mods']) == 2
    for name, sha in launch['mods'].items():
        assert digest(Path(launch['cwd']) / 'mods' / name) == sha
    commands = load(folder / 'commands.json')
    assert commands[-2:] == ['save-all flush', 'stop']
    assert commands.count('reload') == (1 if phase == 'create' else 0)
    status = load(folder / 'status.json')
    assert status['players']['online'] == 0 and status['version']['name'] == '1.20.1'
    properties = (folder / 'server.properties').read_text()
    assert 'server-ip=127.0.0.1' in properties and 'online-mode=false' in properties
    moon = load(folder / 'world/datapacks/env_query/data/advancedrocketrycommunity/celestial_bodies/moon.json')
    assert moon['gravity_multiplier'] == 0.4
    observations['phases'][phase] = {'stations': stations, 'world_seed': level['WorldGenSettings']['seed'],
        'world_time': level['Time'], 'station_sha256': digest(folder / 'world/data/advancedrocketrycommunity_stations.dat'),
        'exit_code': result['exit_code'], 'probes': probes, 'launch': launch, 'logs': log_observations}

summary = load(RUNTIME / 'summary.json')
assert summary['result'] == 'PASS' and len(summary['cycles']) == 2
OUTPUT.write_text(json.dumps(observations, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'manifest_count': observations['manifest_count'], 'phases': {
    k: {'station_ids': list(v['stations']), 'world_time': v['world_time'], 'exit_code': v['exit_code'],
        'probe_count': len(v['probes']), 'lag_warnings': v['logs']['stdout.txt']['lag_warnings']} for k,v in observations['phases'].items()}}, indent=2))
