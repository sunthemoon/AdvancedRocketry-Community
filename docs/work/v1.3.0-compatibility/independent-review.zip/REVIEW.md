# V130-COMPAT independent final review

## Findings

**No unresolved actionable finding in the reviewed fixture, compatibility documentation, consumer packaging, or bounded native evidence.** This is a scoped engineering review, not approval of the v1.3 Required Gates or a release.

Resolved findings and retained failures:

1. The first fixture revision's generic rejection could not distinguish an oversized payload from an incidental callback-time failure. The final assertion requires the specific payload-validation diagnostic at `src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterFaultGameTests.java:109-111`. The first independent run then exposed a test-oracle formatting error: the expected suffix omitted the formatter's closing `}`. It failed exactly `oversizedCapturePreservesSource`; production had already rejected with `RocketSnapshotException`. The root corrected the suffix, without changing production, budgets, resources, or timeouts. Both attempts and the original source snapshot are retained.
2. Restoration refusal alone did not prove that mismatch detection reached readback. The final scoped counter and assertion at `AdapterFaultGameTests.java:136-137` establish one readback for `RESTORE_MISMATCH` and none for the earlier throwing/false/slow failures. Receipt logging is outside the timed callback (`:184-192`). Actual final execution observed all nine fault modes with those counts.
3. The documentation's initial wording suggesting exact 20 ms delay was corrected to a finite target with scheduling overshoot. Observed slow callback durations are retained below. No claim of preemption or same-JVM isolation is made.

## Identity, ownership, and inspected scope

- Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.3.0-public-api`.
- Full source comparison baseline: `c9b79e57a011b258ea09b713947ac2ed04e95d5e`.
- Final fixture commit: `0e90a68460a5be9f81a0203ac17b202b5ce41cef`. Root committed already-reviewed bytes while verification was in progress; that commit is not represented as a separate rebuild.
- Reviewer made no repository source/documentation edits, Git mutations, remote calls, or server operations beyond the explicitly delegated Gradle GameTest invocation. All review/helper/report writes are in this Temp directory; Gradle wrote authorized build/cache output. The user-supplied untracked documentation bundle was excluded.
- Read applicable repository governance/version/quality/coordination rules, ADR-020 through ADR-029, current work log and API policy; examined actual source and reader-doc differences, not an assumed verdict.
- Six fixture Java files changed: `AdapterTestMod`, `AdapterRegistrationGameTests`, `FixtureContainerBlockEntity`, `FixtureInventoryAdapter`, `FixtureAdapterFaults`, `AdapterFaultGameTests`. `git diff --exit-code <baseline> -- src/main src/generated build.gradle compat-test-mod/build.gradle` returned 0. There is no production Java, API, schema, generated-data or build-configuration change in this slice.
- Reader review includes `docs/API-COMPATIBILITY.md`, `docs/PUBLIC-API-GUIDE.md`, `compat-test-mod/README.md`, `README.md`, `DOCUMENT-INDEX.md`, and final scoped `VERIFICATION.md`. Original 94 local link destinations existed; the later fault-evidence link also points to the actual report. API 1.7 / 27 exports and historical evidence limits are accurately distinguished. The double-`Repository` publication task is valid for the configured repository name, not a typo.

## Source and assertion assessment

The eleven new GameTests cover five source-scan faults, four restoration faults, finally-scope cleanup, and actual MOD-bus registration conflicts. Faults execute through the installed public provider and production command/disassembly behavior rather than a substituted host registry.

Source faults are attached to the specific source BlockEntity; restoration uses a nested-scope-rejecting thread-local probe cleared in `finally`. Probe fields are not saved world state. Restoration faults deliberately modify the host-created target before throwing/returning false/returning slowly/restoring different content. Assertions retain full serialized rocket authority, check absence of partial blocks/BlockEntities/drops, and perform a healthy retry with exact cargo. Source failures retain the original source instance and inventory before retry. These synchronous assertions do not themselves prove journal persistence or crash recovery.

Actual duplicate-ID and type-mapping conflicts are two registration attempts by the same fixture mod, not two independently authored conflicting mods. The original usable provider remains installed. Test geometry uses the reserved `rocket_test` structure bounds; fake players have test-local identities. Existing production containment and returned-time policy remain unchanged.

A 1,085-file source/build/fixture hash inventory was compared before and after commands. Only the root-authorized `AdapterFaultGameTests.java` suffix correction changed source bytes. The final native-to-rebuilt consumer ZIP comparison has exactly two changed entries: `AdapterFaultGameTests.class` and `AdapterFaultGameTests$Fixture.class`. The latter has seven changed bytes, all within debug `LineNumberTable` attributes; every other byte matches after masking only those attributes. Normal runtime provider classes and resources are unchanged.

## Independently executed commands and actual results

Environment: Windows, `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, Forge 47.4.10. Commands ran from the repository, without `clean` or deleting the GameTest world.

| Command | Actual result |
|---|---|
| `.\gradlew.bat runGameTestServer --offline --no-daemon --no-build-cache --console=plain` (initial) | Exit 1; 105.929 s; 210 Required, exactly one failing oversized diagnostic assertion. Retained `gametest.txt`, result, original native logs and source snapshot. |
| Same command after the suffix correction | Exit 0; 101.079 s; all 210 Required passed; 17 tasks, 4 executed / 13 up-to-date. Reused world, not a clean-world claim. |
| `.\gradlew.bat test --tests '*ExternalRocketBlockEntityAdapterBudgetTest' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain` | Exit 0; 38.540 s; 5 tests / 1 suite, zero failures/errors/skips; all 16 tasks executed. Raw XML retained in `focused-junit/`. |
| `.\gradlew.bat -p compat-test-mod verifyConsumerBoundary --offline --no-daemon --no-build-cache --console=plain` | Exit 0; 21.305 s; 9 tasks, 6 executed / 3 up-to-date. Consumer compile/reobfuscation/boundary checks executed. No standalone JUnit result is inferred from its `test` task. |
| `D:/python/pyenv/pyenv-win/shims/python.bat -B audit_native.py <runtime-evidence> <native-initial.json>` | Exit 0; raw native manifest, NBT, logs, launch/configuration/status and artifact checks. |
| Same Python with `-B audit_artifacts.py` and `-B audit_supplemental.py` | Final executions exit 0; source/artifact/classpath/cache metadata/library/raw-log checks. Earlier helper attempts retained as described below. |
| `git diff --check` and the scoped production/build diff check above | Exit 0. |

Final callback observations: all nine modes called once; mismatch readbacks 1, others 0. Returned slow durations: `RESTORE_SLOW=20,421,800 ns`, `CAPTURE_SLOW=20,806,500 ns`, `CAN_MOVE_SLOW=20,182,700 ns`. One per-adapter time-budget warning and one `rejected=2` registration receipt appeared. The final GameTest log retains a 2,060 ms / 41 tick lag warning plus expected errors from unrelated deliberate Precision save-failure tests; this is not a zero-ERROR or performance result.

Root full-suite evidence is distinct: inspected `full-final.log` records `:test FROM-CACHE`. Its archived 769 tests / 143 suites are cached results, not 769 tests independently or newly executed by this reviewer. Root Python/repository/planning/full-build results are not claimed as independent reruns here.

## Artifacts and isolated consumer

Actual file digests after independent commands:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Host | 2,352,333 | `d1f9f564ed1dcd1df7ac0648b4091a07dfa9a02f63b36b827f36aad591224475` |
| API | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1,075,630 | `359a21d3c5bd7217ed39876d1fb88208438976e8baaa3acec4117c59e5bc2b8a` |
| Final standalone fixture | 86,554 | `759f214daae269964ab78ed771a2b3cf799a480061df1144f6075fd911881ec8` |
| Native-used fixture | 86,506 | `4207b9b3c686b7230cceaef946062f3dce8318acf587bea2263d0a990509f735` |

Host/API/sources are unchanged from the pre-rerun inventory. All three exclude the fixture package/resources. API contains exactly the 27 allowed classes, each byte-identical to the matching host class. No fixture dependency is shaded into it. The consumer contains 25 fixture classes and no host implementation classes or nested bundled JARs.

Independently rehashed all 114 compile classpath JARs and all 25 recorded fixture source inputs. Exactly one classpath JAR carries host classes: the mapped API, with precisely those 27 exports. Raw/published API bytes equal the artifact above. Mapped API SHA-256 is `b653a4fd8655ca05a71678fc5a3350e5407f7cb45fec49ac78b7494afee753e7`. Its actual ForgeGradle cache `.input` binds `orig=50091ee52c0a1b9efc8be2c7db2f8b6c302ee562` to the raw API and `names=f5fa2554c58505bbb05836b9b987b46853742a0f` to the actual cached mapping ZIP (SHA-256 `84e2278aeeabd496194dbe2fa08031be58bad277d7e3aee036b79d9222d8cbc7`).

Negative compilation exits 1 with `compiler.err.doesnt.exist` for the internal `rocket.forge` package; separately checked the exact prohibited type really exists in the published host. This is an actual API-only boundary check, not a failure caused by an invented missing internal class. Consumer reports are retained verbatim.

## Independent raw native audit

Audited `C:/Users/Administrator/AppData/Local/Temp/arce-v130-compat-1790486012553/runtime-evidence` without launching or modifying its server/world. `audit_native.py` uses a bounded structural NBT reader and reads native compressed SavedData/level.dat rather than trusting decoded JSON or runner PASS alone.

- All 31 manifest entries and the complete file set match their hashes. Separately rehashed all 104 installed server library entries against the preparation manifest; no claim is made here of re-reading their original source-library directory.
- Both captured process results are exit 0. Raw logs show stopping and saved dimensions, normal provider registration and environment readiness/expiry once per process. Exactly one `ARCE_ADAPTER_REGISTRATION_CONFLICTS rejected=2` appears in each stdout/debug/latest log, with no fault-probe activation or ERROR/FATAL. Loopback/offline configuration, no connected players, launch mod hashes and installed mod files were checked.
- Fourteen probes (8 create, 6 restart) all record query chunks unloaded before and after. Earth gravity is 1; Moon changes from 0.165 to 0.4 after the actual one `reload`, and restarts at 0.4. Actual captured datapack data specifies 0.4. Unknown/space-gap queries are empty. These are metadata queries, not gravity simulation.
- Raw schema-2 station SavedData contains exactly two stations, empty reservations, and stable station IDs `c3f57c54-bb4f-4bbf-ba7e-10984f6124f1` (Moon) and `caff8350-6303-433f-b099-d6f4bf3d4689` (Earth). Both full decoded contents and compressed station-file bytes match across restart. Probe IDs/body associations agree with native data. Station environments remain zero gravity/vacuum; no atmosphere-profile result is claimed.
- Raw level seed is unchanged; saved world time advances 15 to 23. Command receipts include save-all flush then stop. Create retains the actual 2,553 ms / 51 tick lag warning; restart has none. No performance acceptance follows.
- Native execution used the original `4207...` fixture, not the rebuilt `759f...` fixture. Only inactive GameTest classes differ, as independently compared above. Native normal-registration/lifecycle/restart observations remain attributable to their actual artifact. Deliberate callback faults are evidenced by GameTests, not this packaged run.

## Evidence history and limits

The original source findings, initial GameTest failure, raw command outputs/XML, before/after hashes, helpers and consumer reports remain here. No failed attempt was relabeled. The first artifact helper failed because Windows normal paths accepted the 258-character JAR path but not the 264-character `.input` path; using an extended path read the existing file. Two supplemental helper attempts assumed the mapping digest referred to a TSRG file; both failed and are preserved. Inspection located the actual mapping ZIP and the unchanged digest check then passed. These are audit-helper issues, not product failures.

Final raw log SHA-256:

- Initial GameTest: `419d406fc799bd6ea03498fbaeb025e33eab80499b990724f125a8871fdbcf4a`
- Final GameTest: `2629d0eb1208d3de58b06980c7a1abb967923275fcb841567e126646254111c1`
- Focused JUnit: `2eb72aff7ffad7d5863a651a4bb221ddeb7d47c93706d1170c8bd6dcee8401cc`
- Consumer: `7c896aa1e0c8b4a022ae34dcaeec6760f393f3e1c3681b4f89e04b5b52b474ae`

Not covered: real clients/GPU, multiplayer, arbitrary external modpacks, hostile non-returning providers, same-JVM callback side-effect sandboxing, forced crash/power-loss, Forge 47.4.23 execution, remote or long-duration tests. The reused GameTest world and original-fixture native run are explicitly scoped. No full machine/dimension campaign was added. v1.3 Required Gates remain incomplete; remaining acceptance is V130-ACC under the existing deferred-full-test policy. No new public contract or production repair is recommended from this bounded review.
