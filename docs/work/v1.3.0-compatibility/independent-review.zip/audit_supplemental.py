from pathlib import Path
import hashlib, json, re, shutil, struct, subprocess, zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
EVIDENCE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-compat-1790486012553')
def sha(p, kind='sha256'):
    with p.open('rb') as f: return hashlib.file_digest(f, kind).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))

native = OUT / 'gametest-native-final'
native.mkdir(exist_ok=True)
for name in ('latest.log', 'debug.log'):
    shutil.copy2(ROOT / 'build/gametest/logs' / name, native / name)
log = (OUT / 'gametest-final.txt').read_text(encoding='utf-8-sig')
probes = re.findall(r'ARCE_ADAPTER_FAULT mode=(\w+) calls=(\d+) delayed_ns=(\d+) readbacks=(\d+)', log)
assert len(probes) == 9 and len({p[0] for p in probes}) == 9
for mode, calls, delay, readbacks in probes:
    assert int(calls) == 1
    assert int(readbacks) == (1 if mode == 'RESTORE_MISMATCH' else 0)
    assert int(delay) >= 20_000_000 if mode.endswith('_SLOW') else int(delay) == 0
assert 'All 210 required tests passed' in log
assert log.count('ARCE_ADAPTER_REGISTRATION_CONFLICTS rejected=2') == 1
assert log.count('exceeded returned-time budget') == 1

libraries = load(EVIDENCE / 'library-identities.json')
assert len(libraries) == 104
for entry in libraries:
    p = EVIDENCE / 'server/libraries' / entry['path']
    assert p.stat().st_size == entry['bytes'] and sha(p) == entry['sha256']

# Ignore only bytecode debug line tables; all other class bytes remain binding.
def without_line_tables(blob):
    masked = bytearray(blob)
    cp = {}
    i, n = 10, struct.unpack_from('>H', blob, 8)[0]
    index = 1
    while index < n:
        tag = blob[i]; i += 1
        if tag == 1:
            length = struct.unpack_from('>H', blob, i)[0]; i += 2
            cp[index] = blob[i:i+length].decode('utf-8'); i += length
        elif tag in (3,4,9,10,11,12,17,18): i += 4
        elif tag in (5,6): i += 8; index += 1
        elif tag in (7,8,16,19,20): i += 2
        elif tag == 15: i += 3
        else: raise AssertionError(tag)
        index += 1
    i += 6
    interfaces = struct.unpack_from('>H', blob, i)[0]; i += 2 + interfaces * 2
    line_tables = []
    def attributes(pos):
        count = struct.unpack_from('>H', blob, pos)[0]; pos += 2
        for _ in range(count):
            name, size = struct.unpack_from('>HI', blob, pos); pos += 6
            if cp[name] == 'LineNumberTable':
                masked[pos:pos+size] = bytes(size)
                line_tables.append((pos, size))
            elif cp[name] == 'Code':
                code_size = struct.unpack_from('>I', blob, pos+4)[0]
                p = pos + 8 + code_size
                exceptions = struct.unpack_from('>H', blob, p)[0]
                attributes(p+2+8*exceptions)
            pos += size
        return pos
    for _ in range(2):
        count = struct.unpack_from('>H', blob, i)[0]; i += 2
        for _ in range(count): i = attributes(i+6)
    assert attributes(i) == len(blob)
    return bytes(masked), line_tables

fixture_name = 'arce-adapter-compat-test-1.0.0.jar'
old = EVIDENCE / 'artifacts' / fixture_name
new = ROOT / 'compat-test-mod/build/libs' / fixture_name
entry = 'io/github/sunthemoon/arceadaptertest/AdapterFaultGameTests$Fixture.class'
with zipfile.ZipFile(old) as a, zipfile.ZipFile(new) as b:
    original, latest = a.read(entry), b.read(entry)
    normalized_original, tables = without_line_tables(original)
    normalized_latest, _ = without_line_tables(latest)
    assert normalized_original == normalized_latest
    nested_delta = {'entry': entry, 'before_bytes': len(original), 'after_bytes': len(latest),
        'different_bytes': sum(x != y for x,y in zip(original, latest)), 'only_line_tables': True,
        'line_table_count': len(tables)}

mapping = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/mcp_repo/net/minecraft/mapping/1.20.1/mapping-1.20.1-mapping.zip')
mapping_sha1 = sha(mapping, 'sha1')
assert 'names=' + mapping_sha1 in (OUT / 'mapped-api.jar.input').read_text()
subprocess.run(['git','diff','c9b79e57a011b258ea09b713947ac2ed04e95d5e','--','src/adapterTest'], cwd=ROOT,
    stdout=(OUT/'final-source.diff').open('wb'), check=True)
facts = {'libraries_verified': len(libraries), 'probes': probes, 'nested_fixture_delta': nested_delta,
    'mapping_sha1': mapping_sha1, 'mapping_sha256': sha(mapping),
    'log_sha256': {p.name:sha(p) for p in OUT.glob('*.txt') if p.name in
        ('gametest.txt','gametest-final.txt','junit.txt','consumer.txt','native-initial.txt','artifact-audit-initial.txt')},
    'game_test_lag_warnings': re.findall(r"Can't keep up!.*", log)}
(OUT/'supplemental-audit.json').write_text(json.dumps(facts, indent=2)+'\n', encoding='utf-8')
print(json.dumps(facts, indent=2))
