"""C9 native evidence for v1.6 (ADR-050/051/052) on a COPY of the retained genuine v1.5 world.

Phases, each a finite dedicated-server process:
  legacy       v1.5 handoff host (26a25d02): 200 data missions written by the v1.5 registry (root 2).
  upgrade      v1.6 host: pre-start migration root 2 -> 3 with a backup; the missions survive; 800 more
               (32 stress owners) reach 1,000 unfinished; flush and tick timings at 500 and 1,000.
  backlog      restart with 1,000 missions (no remigration); the clock jumps so all are due at once; the
               scheduler drains them at 32 per pass while tick times and coalesced flushes are sampled.
  setup        four terminals in unloaded far chunks, each with a READY asteroid mission bound to it,
               set up through the real terminal buttons (release-test hooks, FakePlayer).
  cut-*/verify-*  ADR-051 section 11 cuts: claim, make one store durable, halt the JVM (exit 75); the
               next process loads the terminal (forceload) and reconciles. A: chunk ahead; B: registry
               ahead; C: chunk ahead, then an operator cancel before the terminal loads; D: both saved.
  final        restart: nothing forced, nothing pending; the reward exists exactly once per terminal.

No real clients. The source world is verified unchanged at the end.
"""
import gzip
import hashlib
import json
import re
import shutil
import sys
import time
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402
import inspect_celestial_saved_data as nbt  # noqa: E402
import v120_precision_world_fixture as region  # noqa: E402

nbt.MAX_TAGS = 2_000_000
nbt.MAX_COLLECTION_ENTRIES = 65_536
support, server = fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json

ROOT = Path(__file__).resolve().parent.parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-closure-d95cd36780924befbdea0321233c2187'
               '/c3-rerun/station-server')
SOURCE = HISTORY / 'world'
OLD_JAR = HISTORY / 'mods/advancedrocketry-community-1.20.1-1.5.0-dev.jar'
FIXTURE_JAR = HISTORY / 'mods/arce-adapter-compat-test-1.0.0.jar'
HOST_JAR = REPO / 'build/libs/advancedrocketry-community-1.20.1-1.6.0-dev.jar'
OLD_SHA = '26a25d024cdf33b31ec96be9534b34f47ab73099458472da7e751faba4060433'
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
HOST = 'advancedrocketrycommunity'
REGISTRY = HOST + '_satellite_missions.dat'
SERVER = ROOT / 'native-server'
OUT = ROOT / 'native'
HALT = 75
TERMINALS = {'A': (4096, 200, 4096), 'B': (4160, 200, 4096), 'C': (4224, 200, 4096), 'D': (4288, 200, 4096)}
OWNERS = {name: str(uuid.uuid5(uuid.NAMESPACE_URL, 'arce:v160:c9:owner:' + name)) for name in TERMINALS}
RELEASE = re.compile(r'ARCE_RELEASE_TEST (.*)$')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_registry(path):
    with gzip.open(path, 'rb') as stream:
        payload = stream.read(64 * 1024 ** 2 + 1)
    require(len(payload) <= 64 * 1024 ** 2, 'Registry exceeds 64 MiB expanded')
    root = nbt.NbtReader(payload).read_root()
    require(isinstance(root, dict) and isinstance(root.get('data'), dict), 'Registry has no data compound')
    return root['data']


def uid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def terminal_on_disk(world, position):
    x, y, z = position
    cx, cz = x >> 4, z >> 4
    raw = (world / 'region' / f'r.{cx >> 5}.{cz >> 5}.mca').read_bytes()
    chunk = region._decode_chunk(region._region_chunk(raw, cx, cz), cx, cz)
    entries = [entry for entry in chunk.get('block_entities', [])
               if (entry.get('x'), entry.get('y'), entry.get('z')) == (x, y, z)]
    require(len(entries) == 1 and entries[0]['id'] == HOST + ':satellite_terminal', 'Terminal missing on disk')
    data = entries[0]['SatelliteTerminal']
    return {'schema_version': data['schema_version'], 'terminal_id': uid(data['terminal_id']),
            'buffer_items': sum(entry['count'] for entry in data['reward_buffer']),
            'receipts': [uid(value) for value in data['receipts']]}


def summary(registry):
    missions = registry['missions']
    return {'root_keys': sorted(registry), 'save_epoch': registry.get('save_epoch'),
            'satellites': len(registry['satellites']), 'missions': len(missions),
            'instances': len(registry.get('asteroid_instances', registry.get('instances', []))),
            'unfinished': sum(1 for m in missions if m.get('status') in ('active', 'ready', 'quarantined',
                                                                       'claim_pending_discovery'))}


class Phase:
    def __init__(self, name, artifacts, expect_halt=False, allowed=()):
        self.name, self.artifacts, self.expect_halt, self.allowed = name, artifacts, expect_halt, list(allowed)
        self.directory = OUT / name
        self.commands, self.observations = [], {}

    def query(self, process, text, pattern, timeout=60):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern if hasattr(pattern, 'search') else re.compile(pattern),
                                              timeout, start_at=start)].rstrip()

    def release(self, process, text, prefix, timeout=120):
        line = self.query(process, text, re.compile(r'ARCE_RELEASE_TEST ' + re.escape(prefix)), timeout)
        return RELEASE.search(line).group(1)

    def wait(self, process, pattern, timeout=120, start_at=0):
        return process.lines[process.wait_for(re.compile(pattern), timeout, start_at=start_at)].rstrip()


def fields(text):
    return dict(part.split('=', 1) for part in text.split() if '=' in part)


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    command[2] = '-Xmx2G'
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    started = time.monotonic()
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 300)
        receipt['startup_seconds'] = round(time.monotonic() - started, 1)
        status = server.wait_for_status(port)
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        if phase.expect_halt:
            code = process.finish(120)
            require(code == HALT, f'Expected the crash-cut halt ({HALT}), got {code}')
        else:
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
            phase.commands.append('stop')
            process.command('stop')
            code = process.finish(180)
            require(code == 0, 'Server did not stop cleanly')
        findings = server.scan_log(process.lines)
        unexpected = [line for line in findings if not any(re.search(p, line) for p in phase.allowed)]
        require(not unexpected, 'Unexpected log findings: ' + json.dumps(unexpected[:10]))
        receipt.update(result='PASS', exit_code=code, log_counts=server.log_audit_counts(process.lines),
                       findings=findings, observations=phase.observations,
                       migration_lines=[l.rstrip() for l in process.lines if '[ARCE-BETA-' in l],
                       delivery_lines=[l.rstrip() for l in process.lines if 'ARCE_MISSION_DELIVERY' in l],
                       release_lines=[l.rstrip() for l in process.lines if 'ARCE_RELEASE_TEST' in l])
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    require(digest(OLD_JAR) == OLD_SHA, 'The v1.5 handoff host JAR is not the recorded one')
    old = support.artifact(OLD_JAR, HOST, '1.20.1-1.5.0-dev')
    host = support.artifact(HOST_JAR, HOST, '1.20.1-1.6.0-dev')
    consumer = support.artifact(FIXTURE_JAR, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    shutil.copytree(HISTORY / 'libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    write_json(OUT / 'inputs.json', {'source_world': str(SOURCE), 'artifacts': [old, host, consumer],
                                     'terminals': TERMINALS, 'owners': OWNERS})
    world = SERVER / 'world'
    before = read_registry(world / 'data' / REGISTRY)
    write_json(OUT / 'source-registry-summary.json', summary(before))
    receipts, results = [], {}

    def diagnostics(phase, process, label):
        line = phase.query(process, 'arce satellite admin diagnostics', r'ARCE_SATELLITE_DIAGNOSTICS ')
        phase.observations[label] = line.split('ARCE_SATELLITE_DIAGNOSTICS ', 1)[1]
        return fields(phase.observations[label])

    # 1. legacy: the v1.5 registry writes 200 data missions (two stress owners, the v1.5 hook).
    def legacy_actions(phase, process):
        for index in range(2):
            line = phase.query(process, 'arce satellite release-test batch 100',
                               r'ARCE_RELEASE_TEST_SATELLITE_BATCH requested=100')
            require('created=100' in line, 'The v1.5 batch did not create 100 missions: ' + line)
        phase.observations['batches'] = 2

    receipts.append(run_phase(Phase('legacy', [old, consumer]), port, legacy_actions))
    legacy = read_registry(world / 'data' / REGISTRY)
    results['legacy'] = summary(legacy)
    legacy_sha = digest(world / 'data' / REGISTRY)
    results['legacy_registry_sha256'] = legacy_sha
    require(results['legacy']['missions'] >= 200, 'The v1.5 registry does not hold the batch')

    # 2. upgrade: pre-start migration with a backup; 1,000 unfinished missions; timings at 500 and 1,000.
    def upgrade_actions(phase, process):
        migration = [l for l in process.lines if '[ARCE-BETA-1002]' in l]
        require(len(migration) == 1 and re.search(r'migrated=\d+, backup=\S+', migration[0]),
                'Missing the migration completion with a backup')
        results['forced_baseline'] = phase.query(process, 'forceload query', r'(No chunks were|force loaded)', 30)             .split(']: ', 1)[-1]
        first = diagnostics(phase, process, 'after_upgrade')
        require(int(first['missions']) == results['legacy']['missions'], 'The upgrade lost or added missions')
        for count in range(3):
            line = phase.query(process, 'arce satellite release-test batch 100 32',
                               r'ARCE_RELEASE_TEST_SATELLITE_BATCH requested=100')
            require('created=100' in line, 'Batch refused: ' + line)
        at500 = diagnostics(phase, process, 'at_500')
        require(int(at500['missions']) >= 500, 'Not 500 missions')
        phase.observations['flush_500'] = phase.release(process, 'arce satellite release-test perf flush 10', 'flush')
        time.sleep(6)
        phase.observations['ticks_500'] = phase.release(process, 'arce satellite release-test perf ticks', 'ticks')
        for count in range(5):
            line = phase.query(process, 'arce satellite release-test batch 100 32',
                               r'ARCE_RELEASE_TEST_SATELLITE_BATCH requested=100')
            require('created=100' in line, 'Batch refused: ' + line)
        at1000 = diagnostics(phase, process, 'at_1000')
        require(int(at1000['unfinished']) >= 1_000, 'Not 1,000 unfinished missions')
        phase.observations['flush_1000'] = phase.release(process, 'arce satellite release-test perf flush 10', 'flush')
        time.sleep(6)
        phase.observations['ticks_1000'] = phase.release(process, 'arce satellite release-test perf ticks', 'ticks')

    receipts.append(run_phase(Phase('upgrade', [host, consumer]), port, upgrade_actions))
    upgraded = read_registry(world / 'data' / REGISTRY)
    results['upgrade'] = summary(upgraded)
    line = next(l for l in receipts[-1]['migration_lines'] if '[ARCE-BETA-1002]' in l)
    backup = world / 'advancedrocketrycommunity-backups' / re.search(r'backup=(\S+)', line).group(1)
    require(backup.is_dir(), 'The named backup directory is missing')
    copies = [p for p in backup.rglob(REGISTRY)]
    require(len(copies) == 1 and digest(copies[0]) == legacy_sha,
            'The backup does not hold the v1.5 registry byte for byte')
    results['backup'] = {'directory': backup.name, 'registry_copy': str(copies[0].relative_to(backup)),
                         'registry_sha256': legacy_sha,
                         'files': sorted(str(p.relative_to(backup)) for p in backup.rglob('*') if p.is_file())}

    # 3. backlog: restart with 1,000 missions; all due at once; drain at 32 per pass.
    def backlog_actions(phase, process):
        require(any('[ARCE-BETA-1001]' in l and 'migrated=0' in l for l in process.lines), 'A restart remigrated')
        start = diagnostics(phase, process, 'restart')
        require(int(start['missions']) == results['upgrade']['missions'], 'The restart changed the mission count')
        phase.observations['advance'] = phase.release(process, 'arce satellite release-test advance 400000', 'advance')
        samples, began = [], time.monotonic()
        while time.monotonic() - began < 90:
            time.sleep(5)
            samples.append(phase.release(process, 'arce satellite release-test perf ticks', 'ticks'))
            if 'scheduled=0 ' in samples[-1]:
                break
        phase.observations['drain_seconds'] = round(time.monotonic() - began, 1)
        phase.observations['tick_samples'] = samples
        require('scheduled=0 ' in samples[-1], 'The backlog did not drain within 90 seconds')
        time.sleep(6)
        phase.observations['after_drain'] = diagnostics(phase, process, 'drained')

    receipts.append(run_phase(Phase('backlog', [host, consumer]), port, backlog_actions))
    results['backlog'] = summary(read_registry(world / 'data' / REGISTRY))

    # 4. setup: four terminals, each with a READY asteroid mission bound to it.
    missions = {}

    def setup_actions(phase, process):
        for name, (x, y, z) in TERMINALS.items():
            text = phase.release(process, f'arce satellite release-test terminal {x} {y} {z} setup {OWNERS[name]}',
                                 f'setup pos={x},{y},{z} ')
            values = fields(text)
            require(values['survey'] == 'SUCCESS/SUCCESS' and values['start'] == 'SUCCESS'
                    and values['persisted'] == 'true' and values['status'] == 'READY',
                    f'Terminal {name} setup failed: {text}')
            missions[name] = values
        phase.observations['setup'] = missions

    receipts.append(run_phase(Phase('setup', [host, consumer]), port, setup_actions))
    write_json(OUT / 'missions.json', missions)
    for name, position in TERMINALS.items():
        on_disk = terminal_on_disk(world, position)
        require(on_disk['schema_version'] == 2 and on_disk['terminal_id'] == missions[name]['terminal']
                and on_disk['buffer_items'] == 0 and not on_disk['receipts'], f'Terminal {name} setup on disk differs')

    def mission_line(phase, process, name):
        return phase.query(process, f'arce satellite admin mission inspect {missions[name]["mission"]}',
                           r'mission=' + missions[name]['mission'] + r' ')

    def instance_state(phase, process, name):
        line = phase.query(process, f'arce satellite admin instance inspect {missions[name]["instance"]}',
                           r'instance=' + missions[name]['instance'] + r' ')
        return fields(line.split('instance=', 1)[1] if 'instance=' in line else line)['state']

    def load_terminal(phase, process, name, events, timeout=180):
        x, y, z = TERMINALS[name]
        start = len(process.lines)
        phase.query(process, f'forceload add {x} {z}', r'(Marked chunk|chunk .* force loaded)', 30)
        for event in events:
            phase.wait(process, r'ARCE_MISSION_DELIVERY event=' + event + r' mission=' + missions[name]['mission'],
                       timeout, start)
        inspect = fields(phase.release(process, f'arce satellite release-test terminal {x} {y} {z} inspect',
                                       f'inspect pos={x},{y},{z} '))
        phase.query(process, f'forceload remove {x} {z}', r'(Unmarked chunk|chunk .* no longer force loaded)', 30)
        return inspect

    def cut(name, mode):
        x, y, z = TERMINALS[name]

        def actions(phase, process):
            start = len(process.lines)
            process.command(f'arce satellite release-test terminal {x} {y} {z} cut {mode}')
            phase.commands.append(f'arce satellite release-test terminal {x} {y} {z} cut {mode}')
            phase.observations['cut'] = mode
        return actions

    def reward(phase, process, name):
        return int(fields(mission_line(phase, process, name).split('mission=', 1)[1])['reward_items'])

    # 5. A: the chunk is saved, the registry is not.
    receipts.append(run_phase(Phase('cut-A', [host, consumer], expect_halt=True), port, cut('A', 'chunk')))

    def verify_a(phase, process):
        before_line = mission_line(phase, process, 'A')
        require(' status=READY ' in before_line, 'Cut A: the registry was not behind: ' + before_line)
        inspect = load_terminal(phase, process, 'A', ['CLAIM_RECOVERED', 'ACKNOWLEDGED', 'RECEIPT_DROPPED'])
        after = mission_line(phase, process, 'A')
        state = instance_state(phase, process, 'A')
        paid = reward(phase, process, 'A')
        require(' status=CLAIMED ' in after and state == 'DEPLETED' and int(inspect['buffer_items']) == paid,
                f'Cut A: not paid exactly once: {after} {state} {inspect}')
        phase.observations['A'] = {'before': before_line, 'after': after, 'instance': state, 'terminal': inspect,
                                   'reward_items': paid}
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        cut('B', 'registry')(phase, process)

    receipts.append(run_phase(Phase('verify-A-cut-B', [host, consumer], expect_halt=True), port, verify_a))

    def verify_b(phase, process):
        before_line = mission_line(phase, process, 'B')
        require(' status=CLAIMED ' in before_line and 'acknowledged=false' in before_line,
                'Cut B: the registry was not ahead: ' + before_line)
        inspect = load_terminal(phase, process, 'B', ['REMATERIALIZED', 'ACKNOWLEDGED', 'RECEIPT_DROPPED'], 240)
        state = instance_state(phase, process, 'B')
        paid = reward(phase, process, 'B')
        require(state == 'DEPLETED' and int(inspect['buffer_items']) == paid,
                f'Cut B: not paid exactly once: {state} {inspect}')
        phase.observations['B'] = {'before': before_line, 'instance': state, 'terminal': inspect,
                                   'reward_items': paid}
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        cut('C', 'chunk')(phase, process)

    receipts.append(run_phase(Phase('verify-B-cut-C', [host, consumer], expect_halt=True), port, verify_b))

    def verify_c(phase, process):
        before_line = mission_line(phase, process, 'C')
        require(' status=READY ' in before_line, 'Cut C: the registry was not behind: ' + before_line)
        cancel = phase.query(process, f'arce satellite admin mission cancel {missions["C"]["mission"]}',
                             r'mission_cancel ' + missions['C']['mission'])
        state = instance_state(phase, process, 'C')
        require(state == 'QUARANTINED', 'Cut C: the operator cancel did not hold the instance: ' + state)
        inspect = load_terminal(phase, process, 'C', ['PAID_THEN_CANCELLED'])
        paid = reward(phase, process, 'C')
        require(int(inspect['buffer_items']) == paid and int(inspect['receipts']) == 1,
                f'Cut C: not paid exactly once, or the receipt was dropped: {inspect}')
        phase.observations['C'] = {'before': before_line, 'cancel': cancel, 'instance': state, 'terminal': inspect,
                                   'reward_items': paid}
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        cut('D', 'both')(phase, process)

    receipts.append(run_phase(Phase('verify-C-cut-D', [host, consumer], expect_halt=True), port, verify_c))

    def verify_d(phase, process):
        before_line = mission_line(phase, process, 'D')
        require(' status=CLAIMED ' in before_line, 'Cut D: the registry was not saved: ' + before_line)
        inspect = load_terminal(phase, process, 'D', ['ACKNOWLEDGED', 'RECEIPT_DROPPED'])
        state = instance_state(phase, process, 'D')
        paid = reward(phase, process, 'D')
        require(state == 'DEPLETED' and int(inspect['buffer_items']) == paid and int(inspect['receipts']) == 0,
                f'Cut D: not paid exactly once: {state} {inspect}')
        phase.observations['D'] = {'before': before_line, 'instance': state, 'terminal': inspect,
                                   'reward_items': paid}
        forced = phase.query(process, 'forceload query', r'(No chunks were|force loaded)', 30).split(']: ', 1)[-1]
        require(forced == results['forced_baseline'], 'The forced chunks changed: ' + forced)
        phase.observations['forceload_query'] = forced
        time.sleep(10)
        phase.observations['ticks'] = phase.release(process, 'arce satellite release-test perf ticks', 'ticks')
        diagnostics(phase, process, 'verify_d')

    receipts.append(run_phase(Phase('verify-D', [host, consumer]), port, verify_d))

    # 6. final: a clean restart; nothing forced; every terminal still holds its reward exactly once.
    def final_actions(phase, process):
        forced = phase.query(process, 'forceload query', r'(No chunks were|force loaded)', 30).split(']: ', 1)[-1]
        require(forced == results['forced_baseline'], 'The forced chunks changed after a restart: ' + forced)
        phase.observations['forceload_query'] = forced
        for name, (x, y, z) in TERMINALS.items():
            phase.observations['inspect_' + name] = phase.release(
                process, f'arce satellite release-test terminal {x} {y} {z} inspect', f'inspect pos={x},{y},{z} ')
        diagnostics(phase, process, 'final')
        # ADR-050 section 2: flush cost of a synthetic worst-case root (the load bounds), off the world's file.
        worst = phase.release(process, 'arce satellite release-test perf worst-case', 'worst-case', 600)
        require(worst.startswith('worst-case missions=8192 satellites=4096'), 'Worst-case root not built: ' + worst)
        phase.observations['worst_case'] = worst

    receipts.append(run_phase(Phase('final', [host, consumer]), port, final_actions))
    final = read_registry(world / 'data' / REGISTRY)
    results['final'] = summary(final)
    terminals = {name: terminal_on_disk(world, position) for name, position in TERMINALS.items()}
    results['terminals_on_disk'] = terminals
    by_id = {uid(m['mission_id']): m for m in final['missions']}
    for name in TERMINALS:
        record = by_id[missions[name]['mission']]
        results.setdefault('missions_on_disk', {})[name] = {k: record.get(k) for k in ('status', 'kind')}
    require(fixture.inventory(SOURCE) == source_inventory, 'The source world was changed')
    write_json(OUT / 'summary.json', {'result': 'PASS', 'source_world_unchanged': True, 'results': results,
                                      'cycles': receipts})
    print('PASS: v1.6 native migration, 1,000-mission load and backlog, four crash cuts, final restart')


if __name__ == '__main__':
    main()
