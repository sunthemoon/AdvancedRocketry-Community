"""Archive the C9 reviewer's round-2 outputs (allow-list) into independent-review-2.zip plus a member index.

Round 1 is archived in docs/work/v1.6.0-c9-review. Excluded on purpose: tree/ and tree2/ (copies of this
repository); only the round-2 report, logs, probe results, the appended file list and the reviewer's two
round-2 probe sources are kept.
Usage: make_review2_zip.py <out dir>
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

REVIEW = Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v160-c9-review-69dc1b73dfe2418793b8cfec2493aab8")
FILES = ("REVIEW-2.md", "probe-results-round2.txt", "r2-unit.log", "r2-gametest.log", "files-reviewed.txt")
PROBES = ("C9Round2ProbeTest.java", "C9Round2ProbeGameTests.java")


def members():
    for name in FILES:
        yield name, REVIEW / name
    for path in sorted((REVIEW / "tree2").rglob("*.java")):
        if path.name in PROBES and "build" not in path.relative_to(REVIEW).parts:
            yield path.relative_to(REVIEW).as_posix(), path


def main(out):
    out = Path(out)
    rows = []
    with zipfile.ZipFile(out / "independent-review-2.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, path in members():
            data = path.read_bytes()
            bundle.writestr(zipfile.ZipInfo(name, (2026, 10, 1, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    (out / "independent-review-2-files.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n",
                                                          encoding="utf-8", newline="\n")
    raw = (out / "independent-review-2.zip").read_bytes()
    print("independent-review-2.zip", len(rows), "members", len(raw), "bytes", hashlib.sha256(raw).hexdigest())


if __name__ == "__main__":
    main(sys.argv[1])
