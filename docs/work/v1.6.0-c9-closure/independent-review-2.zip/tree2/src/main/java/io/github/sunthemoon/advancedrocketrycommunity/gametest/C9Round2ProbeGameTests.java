package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import com.mojang.authlib.GameProfile;
import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.ModIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.content.PlanetaryContent;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModBlocks;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModItems;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.content.SatelliteIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.content.SatelliteItemData;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.AsteroidInstance;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.InstanceState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.MissionKind;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.MissionPayload;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.MissionState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.ResourceMissions;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.RewardEntry;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.mission.SatelliteOperationCode;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteBlueprint;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteKind;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteKindState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteLimits;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteState;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteStats;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.persistence.SatelliteMissionSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalBlock;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalBlockEntity;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalMenu;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.terminal.SatelliteTerminalTargets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.storage.ChunkSerializer;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.level.ChunkDataEvent;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.registries.ForgeRegistries;

/** C9 round-2 probes against eb5b80e (reviewer's copy only; not part of the reviewed commit). */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class C9Round2ProbeGameTests {
    private static final String KEY = "SatelliteTerminal";
    private static final ResourceLocation HARVESTER = ModIdentity.id("gas_harvester");
    private static final ResourceLocation MINER = ModIdentity.id("asteroid_miner");
    private static final ResourceLocation SURVEYOR = ModIdentity.id("survey_satellite");
    private static final String VERSION = "0123456789abcdef";

    private C9Round2ProbeGameTests() {
    }

    /** Round-1 H1 probe through the real menu and limiter: 70 other missions bound, presses at game time 5 (mod 20). */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 300)
    public static void c9r2BusyTerminalThroughTheMenu(GameTestHelper helper) {
        MinecraftServer server = helper.getLevel().getServer();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.get(server);
        SatelliteTerminalBlockEntity terminal = place(helper, new BlockPos(1, 2, 1));
        FakePlayer owner = player(helper, terminal);
        observeChunkSave(helper, terminal);
        ResourceLocation hydrogen = key(ModItems.HYDROGEN_CANISTER.get());
        long now = server.overworld().getGameTime();
        for (int index = 0; index < 70; index++) {
            UUID other = UUID.randomUUID();
            UUID craft = craftGas(data, other, server);
            data.resources(missions -> missions.startResource(new ResourceMissions.ResourceStart(craft,
                    UUID.randomUUID(), other, MissionKind.GAS, PlanetaryContent.GAS_GIANT, Optional.empty(),
                    List.of(new RewardEntry(hydrogen, 1)), "gas-v1/probe/" + VERSION, 200, 1L, terminal.terminalId(),
                    Optional.empty()), now));
        }
        UUID mine = craftGas(data, owner.getUUID(), server);
        data.resources(missions -> missions.startResource(new ResourceMissions.ResourceStart(mine, UUID.randomUUID(),
                owner.getUUID(), MissionKind.GAS, PlanetaryContent.GAS_GIANT, Optional.empty(),
                List.of(new RewardEntry(hydrogen, 5)), "gas-v1/probe/" + VERSION, 200, 1L, terminal.terminalId(),
                Optional.empty()), now));
        chip(helper, terminal, new SatelliteIdentity(mine, owner.getUUID(), HARVESTER, SatelliteKind.GAS_HARVESTER,
                gasComponents()));
        data.completeDue(0L);
        data.completeDue(10_000L);
        data.flush(server);
        StringBuilder trace = new StringBuilder();
        int[] presses = {0};
        boolean[] done = {false};
        helper.onEachTick(() -> {
            long gameTime = helper.getLevel().getGameTime();
            if (done[0] || presses[0] >= 5 || gameTime % 20L != 5L || helper.getTick() < 10) {
                return;
            }
            SatelliteOperationCode code = menuPress(terminal, owner, SatelliteTerminalMenu.BUTTON_CLAIM);
            presses[0]++;
            trace.append(presses[0]).append('=').append(code.name()).append(' ');
            done[0] = code != SatelliteOperationCode.RECONCILING;
        });
        helper.runAfterDelay(200, () -> {
            AdvancedRocketryCommunity.LOGGER.info("C9R2_PROBE busy-terminal bound=71 menuPresses {} buffer={}", trace,
                    bufferItems(terminal));
            helper.succeed();
        });
    }

    /** A load pass larger than one step: 150 receipts of absent missions are loaded, then CLAIM is pressed. */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 200)
    public static void c9r2LoadPassWithManyReceipts(GameTestHelper helper) {
        MinecraftServer server = helper.getLevel().getServer();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.get(server);
        SatelliteTerminalBlockEntity terminal = place(helper, new BlockPos(1, 2, 1));
        FakePlayer owner = player(helper, terminal);
        observeChunkSave(helper, terminal);
        ResourceLocation hydrogen = key(ModItems.HYDROGEN_CANISTER.get());
        UUID mine = craftGas(data, owner.getUUID(), server);
        data.resources(missions -> missions.startResource(new ResourceMissions.ResourceStart(mine, UUID.randomUUID(),
                owner.getUUID(), MissionKind.GAS, PlanetaryContent.GAS_GIANT, Optional.empty(),
                List.of(new RewardEntry(hydrogen, 5)), "gas-v1/probe/" + VERSION, 200, 1L, terminal.terminalId(),
                Optional.empty()), server.overworld().getGameTime()));
        chip(helper, terminal, new SatelliteIdentity(mine, owner.getUUID(), HARVESTER, SatelliteKind.GAS_HARVESTER,
                gasComponents()));
        data.completeDue(0L);
        data.completeDue(10_000L);
        data.flush(server);
        CompoundTag root = terminal.saveWithoutMetadata();
        ListTag receipts = new ListTag();
        for (int index = 0; index < 150; index++) {
            receipts.add(NbtUtils.createUUID(UUID.randomUUID()));
        }
        root.getCompound(KEY).put("receipts", receipts);
        terminal.load(root);
        List<String> codes = new ArrayList<>();
        codes.add(menuPress(terminal, owner, SatelliteTerminalMenu.BUTTON_CLAIM).name());
        helper.runAfterDelay(12, () -> {
            codes.add(menuPress(terminal, owner, SatelliteTerminalMenu.BUTTON_CLAIM).name());
            AdvancedRocketryCommunity.LOGGER.info("C9R2_PROBE load-pass receipts=150 codes={} receiptsAfter={} buffer={}",
                    codes, receipts(terminal).size(), bufferItems(terminal));
            helper.succeed();
        });
    }

    /** Chunk ahead of the registry: the terminal holds the receipt and the reward of a READY mission; CLAIM. */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 60)
    public static void c9r2HeldReceiptThenClaim(GameTestHelper helper) {
        heldReceipt(helper, SatelliteTerminalMenu.BUTTON_CLAIM, "claim");
    }

    /** Chunk ahead of the registry: the terminal holds the receipt and the reward of a READY mission; CANCEL. */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 60)
    public static void c9r2HeldReceiptThenCancel(GameTestHelper helper) {
        heldReceipt(helper, SatelliteTerminalMenu.BUTTON_CANCEL, "cancel");
    }

    private static void heldReceipt(GameTestHelper helper, int button, String label) {
        MinecraftServer server = helper.getLevel().getServer();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.get(server);
        SatelliteTerminalBlockEntity terminal = place(helper, new BlockPos(1, 2, 1));
        FakePlayer owner = player(helper, terminal);
        observeChunkSave(helper, terminal);
        UUID ownerId = owner.getUUID();
        UUID survey = craft(data, ownerId, SatelliteKind.SURVEY, SURVEYOR, server);
        UUID miner = craft(data, ownerId, SatelliteKind.ASTEROID_MINER, MINER, server);
        UUID surveyMission = UUID.randomUUID();
        UUID instanceId = UUID.randomUUID();
        ResourceLocation iron = new ResourceLocation("minecraft", "iron_ore");
        List<RewardEntry> yield = List.of(new RewardEntry(iron, 40));
        long now = server.overworld().getGameTime();
        data.resources(missions -> missions.startSurvey(new ResourceMissions.SurveyStart(survey, surveyMission, ownerId,
                CelestialIds.EARTH_ID, VERSION, 1, 100, 1L, (count, time) -> List.of(new AsteroidInstance(
                SatelliteLimits.INSTANCE_SCHEMA_VERSION, instanceId, ownerId, CelestialIds.EARTH_ID,
                ModIdentity.id("small_asteroid"), VERSION, VERSION, 5L, yield, time, OptionalLong.empty(),
                InstanceState.PENDING, surveyMission, Optional.empty()))), now));
        data.completeDue(0L);
        data.completeDue(10_000L);
        data.resources(missions -> missions.claimSurvey(surveyMission, ownerId, 168_000L, 0L));
        UUID missionId = UUID.randomUUID();
        SatelliteOperationCode started = data.resources(missions -> missions.startResource(
                new ResourceMissions.ResourceStart(miner, missionId, ownerId, MissionKind.ASTEROID,
                        CelestialIds.EARTH_ID, Optional.of(instanceId), yield, "asteroid-v1/probe/" + VERSION, 200, 1L,
                        terminal.terminalId(), Optional.empty()), 0L)).code();
        data.completeDue(20_000L);
        data.flush(server);
        chip(helper, terminal, new SatelliteIdentity(miner, ownerId, MINER, SatelliteKind.ASTEROID_MINER,
                minerComponents()));
        // The chunk was saved after a claim the registry lost: the section holds the receipt and the reward.
        CompoundTag root = terminal.saveWithoutMetadata();
        ListTag receipts = new ListTag();
        receipts.add(NbtUtils.createUUID(missionId));
        root.getCompound(KEY).put("receipts", receipts);
        ListTag buffer = new ListTag();
        CompoundTag entry = new CompoundTag();
        entry.putString("item", iron.toString());
        entry.putInt("count", 40);
        buffer.add(entry);
        root.getCompound(KEY).put("reward_buffer", buffer);
        terminal.load(root);
        String before = data.mission(missionId).map(MissionState::status).map(Enum::name).orElse("none");
        SatelliteOperationCode code = menuPress(terminal, owner, button);
        MissionState after = data.mission(missionId).orElseThrow();
        AdvancedRocketryCommunity.LOGGER.info("C9R2_PROBE held-receipt-{} start={} registryBefore={} press={} "
                        + "registryAfter={} paidTerminal={} instance={} buffer={} receipts={}", label, started, before,
                code, after.status(), ((MissionPayload.Resource) after.payload()).paidTerminal().isPresent(),
                data.instance(instanceId).map(AsteroidInstance::state).orElse(null), bufferItems(terminal),
                receipts(terminal).size());
        helper.succeed();
    }

    /** H2 follow-up: correct tool, wrong tool, and explosion loot for a terminal holding a buffer. */
    @GameTest(template = "empty", batch = SatelliteRegistryFixture.RESOURCE_BATCH, timeoutTicks = 60)
    public static void c9r2BreakingTerminals(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        // (a) survival, iron pickaxe.
        SatelliteTerminalBlockEntity a = withBuffer(helper, new BlockPos(1, 2, 1));
        a.menuInventory().insertItem(SatelliteTerminalBlockEntity.SLOT_CHARGE, new ItemStack(Items.REDSTONE, 7), false);
        FakePlayer miner = player(helper, a);
        miner.setGameMode(GameType.SURVIVAL);
        miner.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_PICKAXE));
        BlockPos posA = a.getBlockPos();
        boolean brokeA = miner.gameMode.destroyBlock(posA);
        String dropsA = drops(level, posA);
        // (b) survival, bare hand.
        SatelliteTerminalBlockEntity b = withBuffer(helper, new BlockPos(4, 2, 1));
        FakePlayer hand = player(helper, b);
        hand.setGameMode(GameType.SURVIVAL);
        BlockPos posB = b.getBlockPos();
        boolean brokeB = hand.gameMode.destroyBlock(posB);
        String dropsB = drops(level, posB);
        // (c) explosion loot (radius 3, a creeper) for a terminal with a buffer, 60 rolls, no world change.
        SatelliteTerminalBlockEntity c = withBuffer(helper, new BlockPos(1, 2, 4));
        BlockState state = level.getBlockState(c.getBlockPos());
        int carried = 0;
        for (int roll = 0; roll < 60; roll++) {
            LootParams.Builder params = new LootParams.Builder(level)
                    .withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(c.getBlockPos()))
                    .withParameter(LootContextParams.TOOL, ItemStack.EMPTY)
                    .withOptionalParameter(LootContextParams.BLOCK_ENTITY, c)
                    .withParameter(LootContextParams.EXPLOSION_RADIUS, 3.0F);
            carried += (int) state.getDrops(params).stream().filter(stack -> stack.is(ModBlocks.SATELLITE_TERMINAL.get()
                    .asItem())).count();
        }
        AdvancedRocketryCommunity.LOGGER.info("C9R2_PROBE break ironPickaxe broke={} drops=[{}]; bareHand broke={} "
                + "drops=[{}]; explosionRadius3 terminalItemDropped={}/60", brokeA, dropsA, brokeB, dropsB, carried);
        helper.succeed();
    }

    private static SatelliteTerminalBlockEntity withBuffer(GameTestHelper helper, BlockPos relative) {
        SatelliteTerminalBlockEntity terminal = place(helper, relative);
        CompoundTag root = terminal.saveWithoutMetadata();
        ListTag buffer = new ListTag();
        CompoundTag entry = new CompoundTag();
        entry.putString("item", "minecraft:iron_ore");
        entry.putInt("count", 500);
        buffer.add(entry);
        root.getCompound(KEY).put("reward_buffer", buffer);
        ListTag receipts = new ListTag();
        receipts.add(NbtUtils.createUUID(UUID.randomUUID()));
        root.getCompound(KEY).put("receipts", receipts);
        terminal.load(root);
        return terminal;
    }

    private static String drops(ServerLevel level, BlockPos pos) {
        List<ItemEntity> entities = level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(2.0D));
        StringBuilder text = new StringBuilder();
        for (ItemEntity entity : entities) {
            ItemStack stack = entity.getItem();
            text.append(stack.getCount()).append(' ').append(key(stack.getItem()));
            CompoundTag tag = stack.getTag();
            if (tag != null && tag.contains("BlockEntityTag")) {
                CompoundTag data = tag.getCompound("BlockEntityTag").getCompound(KEY);
                int buffered = data.getList("reward_buffer", Tag.TAG_COMPOUND).stream()
                        .mapToInt(value -> ((CompoundTag) value).getInt("count")).sum();
                text.append("{buffer=").append(buffered).append(" receipts=")
                        .append(data.getList("receipts", Tag.TAG_INT_ARRAY).size()).append(" invItems=")
                        .append(data.getCompound("inventory").getList("Items", Tag.TAG_COMPOUND).size()).append('}');
            }
            text.append("; ");
            entity.discard();
        }
        return text.toString();
    }

    private static SatelliteOperationCode menuPress(SatelliteTerminalBlockEntity terminal, FakePlayer player, int button) {
        SatelliteTerminalMenu menu = new SatelliteTerminalMenu(7, player.getInventory(), terminal,
                SatelliteTerminalTargets.current());
        if (!menu.stillValid(player)) {
            return SatelliteOperationCode.OUT_OF_RANGE;
        }
        menu.clickMenuButton(player, button);
        return SatelliteOperationCode.values()[terminal.saveWithoutMetadata().getCompound(KEY).getInt("last_result")];
    }

    private static int bufferItems(SatelliteTerminalBlockEntity terminal) {
        return terminal.saveWithoutMetadata().getCompound(KEY).getList("reward_buffer", Tag.TAG_COMPOUND).stream()
                .mapToInt(tag -> ((CompoundTag) tag).getInt("count")).sum();
    }

    private static List<UUID> receipts(SatelliteTerminalBlockEntity terminal) {
        return terminal.saveWithoutMetadata().getCompound(KEY).getList("receipts", Tag.TAG_INT_ARRAY).stream()
                .map(NbtUtils::loadUUID).toList();
    }

    private static void observeChunkSave(GameTestHelper helper, SatelliteTerminalBlockEntity terminal) {
        ServerLevel level = helper.getLevel();
        LevelChunk chunk = level.getChunkAt(terminal.getBlockPos());
        MinecraftForge.EVENT_BUS.post(new ChunkDataEvent.Save(chunk, level, ChunkSerializer.write(level, chunk)));
    }

    private static UUID craftGas(SatelliteMissionSavedData data, UUID owner, MinecraftServer server) {
        UUID satelliteId = UUID.randomUUID();
        SatelliteBlueprint blueprint = new SatelliteBlueprint(gasComponents(), false,
                new SatelliteStats(4, 10_720, 1_000, 9, 10));
        data.launchIdle(time -> SatelliteState.launchIdle(satelliteId, HARVESTER, owner, time,
                PlanetaryContent.GAS_GIANT, blueprint, new SatelliteKindState.Plain(SatelliteKind.GAS_HARVESTER)),
                server.overworld().getGameTime());
        return satelliteId;
    }

    private static UUID craft(SatelliteMissionSavedData data, UUID owner, SatelliteKind kind, ResourceLocation definition,
                              MinecraftServer server) {
        UUID satelliteId = UUID.randomUUID();
        SatelliteKindState state = kind == SatelliteKind.SURVEY
                ? new SatelliteKindState.Survey(0L, 0L, 1_000, 32, 8) : new SatelliteKindState.Plain(kind);
        SatelliteBlueprint blueprint = new SatelliteBlueprint(kind == SatelliteKind.SURVEY ? surveyComponents()
                : minerComponents(), false, new SatelliteStats(4, 10_720, 1_000, 9, 10));
        data.launchIdle(time -> SatelliteState.launchIdle(satelliteId, definition, owner, time, CelestialIds.EARTH_ID,
                blueprint, state), server.overworld().getGameTime());
        return satelliteId;
    }

    private static List<ResourceLocation> gasComponents() {
        return List.of(key(ModItems.SATELLITE_CHASSIS.get()), key(ModItems.GAS_INTAKE_MODULE.get()),
                key(ModItems.SATELLITE_CARGO_HOLD.get()));
    }

    private static List<ResourceLocation> minerComponents() {
        return List.of(key(ModItems.SATELLITE_CHASSIS.get()), key(ModItems.ASTEROID_DRILL_MODULE.get()),
                key(ModItems.SATELLITE_CARGO_HOLD.get()));
    }

    private static List<ResourceLocation> surveyComponents() {
        return List.of(key(ModItems.SATELLITE_CHASSIS.get()), key(ModItems.SURVEY_SCANNER_MODULE.get()),
                key(ModItems.SATELLITE_CARGO_HOLD.get()));
    }

    private static void chip(GameTestHelper helper, SatelliteTerminalBlockEntity terminal, SatelliteIdentity identity) {
        var slots = terminal.menuInventory();
        slots.extractItem(SatelliteTerminalBlockEntity.SLOT_CONTROL_CHIP, 64, false);
        ItemStack chip = new ItemStack(ModItems.SATELLITE_CONTROL_CHIP.get());
        SatelliteItemData.write(chip, identity);
        helper.assertTrue(slots.insertItem(SatelliteTerminalBlockEntity.SLOT_CONTROL_CHIP, chip, false).isEmpty(),
                "Could not insert the control chip");
    }

    private static SatelliteTerminalBlockEntity place(GameTestHelper helper, BlockPos position) {
        helper.setBlock(position, ModBlocks.SATELLITE_TERMINAL.get().defaultBlockState()
                .setValue(SatelliteTerminalBlock.FACING, Direction.NORTH)
                .setValue(SatelliteTerminalBlock.LIT, false));
        SatelliteTerminalBlockEntity terminal = (SatelliteTerminalBlockEntity) helper.getBlockEntity(position);
        terminal.getCapability(ForgeCapabilities.ENERGY).resolve().orElseThrow()
                .receiveEnergy(SatelliteTerminalBlockEntity.ENERGY_CAPACITY, false);
        return terminal;
    }

    private static FakePlayer player(GameTestHelper helper, SatelliteTerminalBlockEntity terminal) {
        FakePlayer player = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "C9R2Probe"));
        BlockPos position = terminal.getBlockPos();
        player.setPos(position.getX() + 0.5D, position.getY() + 1.0D, position.getZ() + 0.5D);
        return player;
    }

    private static ResourceLocation key(Item item) {
        return ForgeRegistries.ITEMS.getKey(item);
    }
}
