# C9 independent review, round 2: fixes in eb5b80e

Reviewer: independent C9 reviewer (read-only toward the repository). Date: 2026-10-01.

## Scope

| Item | Value |
|---|---|
| Reviewed commit | `eb5b80e1aaa6d427e6e3f879f468a814c1bb336f` "fix(satellite): answer the C9 independent review of C8a and C8b" (parent `ce55ee3`) |
| Reviewed tree | `d9322253f86f61cbe0924be8f4b0075f1c2cd217`, exported with `git archive eb5b80e` into `tree2/` |
| Diff reviewed | `git diff ce55ee3 eb5b80e`: 33 files, +2,675/−155. All source and test changes were read. The evidence zips were not unpacked |
| Dispositions | `docs/work/v1.6.0-c9-review/VERIFICATION.md`, including implementation clarification 6 |
| Round-1 report | `REVIEW.md` (verdict ACCEPT WITH REQUIRED CHANGES: H1, H2, M1, M2, M3) |
| Not reviewed | Uncommitted working-tree changes made by other sessions during this round (`docs/status/*`, the implementation log, `docs/releases/v1.6.0/`, `docs/work/v1.6.0-c9-closure/`). `AdvancedRocketry-Community-v1plus-Development-Docs/` was not opened |

## Commands and results

All runs were in `tree2/` with `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`. Nothing was written to the repository.

| # | Command | Result |
|---|---|---|
| 1 | `git -C <repo> archive eb5b80e \| tar -x -C tree2`; `git diff --stat` and full `git diff ce55ee3 eb5b80e` | Tree `d9322253…` |
| 2 | `./gradlew test` with 12 suites: my `C9Round2ProbeTest`, plus `QueueBoundsTest`, `ResourceMissionsTest`, `DeliveryCrashCutTest`, `TerminalDeliveryTest`, `DeliveryReconciliationTest`, `RegistryLifecycleTest`, `SatelliteWritePolicyTest`, `RewardVerifierTest`, `ResourceAlgorithmsTest`, `DeliveryRuntimeTest`, `MissionDeadlineSchedulerTest` | Exit 0. **53 tests, 0 failures, 0 errors** |
| 3 | `./gradlew runGameTestServer` with my 5 `C9Round2ProbeGameTests` added to the resource batch | Exit 0. **All 295 required tests passed** (the implementers' 290 plus 5 probes) |

Probe output, verbatim (`probe-results-round2.txt`):

```text
C9R2_PROBE long level: display=Optional.empty start=SUCCESS reloadOperational=true
C9R2_PROBE ledger: cycles=2000 queueDuringChurn=1 instancesAfterTtl=0 queueAfter=0 passes=1
C9R2_PROBE retention-global: finished=1536 global=1536 owners=1536 prunedPerPass=[64, 64, 64, 64, 64, 64, 0, …]
C9R2_PROBE retention-owner: records=2 finished=1 global=1 owners=1
C9R2_PROBE busy-terminal bound=71 menuPresses 1=SUCCESS  buffer=5
C9R2_PROBE load-pass receipts=150 codes=[RECONCILING, SUCCESS] receiptsAfter=1 buffer=5
C9R2_PROBE held-receipt-claim  start=SUCCESS registryBefore=READY press=MISSION_NOT_FOUND registryAfter=CLAIMED paidTerminal=true instance=DEPLETED buffer=40 receipts=1
C9R2_PROBE held-receipt-cancel start=SUCCESS registryBefore=READY press=MISSION_NOT_FOUND registryAfter=CLAIMED paidTerminal=true instance=DEPLETED buffer=40 receipts=1
C9R2_PROBE break ironPickaxe broke=true drops=[7 minecraft:redstone; 1 satellite_terminal{buffer=500 receipts=1 invItems=0}]; bareHand broke=true drops=[]; explosionRadius3 terminalItemDropped=19/60
```

The GameTest probes go through `SatelliteTerminalMenu.clickMenuButton`, which includes the production
per-player intent limiter. "held-receipt" simulates the ADR-051 §11 cut "chunk saved, registry not": the
terminal holds the receipt and the reward of a mission the registry still has as READY. The press then goes
through the real menu.

## Status of the round-1 findings

Paths are relative to `tree2/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.

| ID | Status | Evidence |
|---|---|---|
| C9-H1 | **RESOLVED** | `satellite/terminal/TerminalResourceActions.java:68-107` (a pass now covers the receipts plus `awaitingDelivery`) and `:298-321` (the gate waits only for the first pass after a load, then applies the row of the acted-on mission). `satellite/mission/TerminalIndex.java` adds `awaiting`, which holds CLAIMED missions paid here and not yet acknowledged. The scope is complete for ADR-051 §7: without a receipt, every row except "CLAIMED, paid here, not acknowledged" is "nothing". Probe with 71 bound missions and the real menu and limiter: the first press **succeeded** (round 1: 25 of 25 refused). With 150 receipts loaded, the first press answered `RECONCILING` and the next press, about 10 ticks later, succeeded. The waiting is bounded. The implementers' `menuPress` test (80 pending receipts) also passes. |
| C9-H2 | **RESOLVED** for the reported scenario (a normal removal that yields the terminal item). Residual: see C9R2-L1 | `satellite/terminal/SatelliteTerminalBlock.java:81-95` and `SatelliteTerminalBlockEntity.java:684-696` (`carriedDeliveryData` at :688) (`carriedDeliveryData`: ID, buffer, receipts and owner, with `Items` emptied and energy 0). Probe with a survival iron pickaxe: the item carries buffer 500 and 1 receipt with `invItems=0`, and the 7 redstone in the charge slot dropped **once**. No slot item is copied. The implementers' `aBrokenTerminalCarriesItsDeliveryToItsNewPlace` re-places the terminal: same ID, unpersisted, and the bound mission is claimed at the new place. The quarantined raw carry is unchanged. |
| C9-M1 | **RESOLVED** | `satellite/mission/MissionRetention.java`: one indexed entry per record (`queued` map) sits in both ordered sets, `changed` re-files it, and `dequeue` removes it from both. Probes: after 2,000 per-owner-prune cycles the global set holds 1 entry and the owner sets 1 (round 1: 2,000). Global prune: the global set and the owner sets each hold 1,536 entries, which equals the finished count. The budgets hold (`prunedPerPass` is 64 until the threshold, then 0). The order is still oldest `eligibleAt` first. The inspection and removal budgets are shared by the owner and global loops as before. The removal no longer re-checks eligibility, but every mission write re-files the entry and durable acknowledgements are re-offered, so no stale entry can be removed early. |
| C9-M2 | **RESOLVED** | `satellite/mission/InstanceLedger.java`: one indexed entry per instance, re-filed on each change. Probe: 2,000 start/cancel cycles leave **1** entry (round 1: 2,001). After the TTL, one pass expires and removes the instance and leaves 0 entries. The pass keeps its 16-change and 32-inspection budget. When the callback re-files the head, the pass still makes progress: `queued.get(id) == head` before the `dequeue`. |
| C9-M3 | **RESOLVED** | `satellite/mission/MissionPayload.java:106-123`: `TerminalLocation` refuses more than 128 characters, and `of()` returns empty. `satellite/service/DeliveryTerminal.java:20-22` uses `of()`, and start, rebind and bind-back all go through `DeliveryTerminal.display()`. Probe: with a 200-character dimension the display is empty, the start is `SUCCESS`, and the reload is operational. `CodecRecordSizer` and `SatelliteRecordFit` use exactly 128 characters. |
| C9-L1 | RESOLVED | `TerminalResourceActions.java:161` pays only when `code == SUCCESS && changed()`. |
| C9-L2 | RESOLVED, with one follow-up (C9R2-L2) | `satellite/service/ResourceMissionService.java:261-268`: a failed barrier is logged and stays pending for the coalesced flush. `TerminalResourceActions.java:336-362`: a failing row is logged and skipped, and the ticker no longer throws. |
| C9-L3 | Accepted as a residual (see below). The record is missing from this commit (C9R2-L3) | — |
| C9-L4 | RESOLVED | `ResourceMissionService.java:385-398`: `DEFINITION_NOT_FOUND` when the current catalog lacks the craft's kind definition, or its kind differs. |
| C9-L5 | RESOLVED | `satellite/service/SatelliteManager.java:450`, `:473`, `:725-727`: only `data` cancels (or results without a mission) flush. Survey and resource cancels set "flush pending" through `SatelliteMissionSavedData.cancel`. |
| C9-L6 | RESOLVED | `satellite/resource/RewardVerifier.java:100-104` returns the instance outcome unless it is MATCH. Two new test cases cover it. |
| C9-L7 | RESOLVED | `satellite/mission/MissionDeadlineScheduler.java`: `TreeSet` plus a `byMission` index, logarithmic removal, and one entry per mission (a re-schedule replaces its entry). Drain order and budgets are unchanged. |
| C9-L8 | RESOLVED | (a) `menuPress` through the real menu and limiter with 80 receipts. (b) A break/re-place GameTest. (c) `SatelliteWritePolicyTest.everyResourceMissionChangeIsMarked` covers 14 resource changes. (d) Crash-cut restarts now parse a chunk tag with `TerminalChunkEvents.entries` and consume a `TerminalObservations` record. The Forge event handler itself is covered by the GameTest chunk-save path. |
| C9-L9 | RESOLVED | `TerminalResourceActions.java:131`: an asteroid or gas start sets the owner when there is none. The carried root keeps its owner. |
| Q1, Q2 | Recorded as operator and creative/tool scope; see C9R2-L3 for where the record is | — |
| Q3 | Answered (bytecode of `ChunkMap.save`). This matches the assumption in the code; I did not verify it again | — |

### Conservation check of the fixes

- **Clarification 6 does not break the §7 argument.**
  - A claim or cancel first applies the row of the chip's current mission. In both probe cases (a receipt held for a READY mission), the row set CLAIMED and DEPLETED the instance before the action. The press then answered `MISSION_NOT_FOUND`, the buffer kept exactly one reward (40), and the instance was not freed.
  - A start creates a new mission ID, and it can take only an AVAILABLE instance. An instance becomes AVAILABLE again only through an owner cancel at the bound terminal after that row, a survey claim, or an operator release.
  - Periodic passes cover every row that can need action. Receipts can be added only by a claim or a rematerialization, or by a `load()`, and `load()` resets the load pass.
- **No slot duplication from the carried root.** The inventory in the carried NBT is empty. The slots drop once through `onRemove`. Vanilla's `BlockItem` merge followed by the raw `load` in `setPlacedBy` restores the same single root.
- **Queue rewrites.** Each of the three queues holds at most one entry per record it serves. The drain orders (deadline or eligibility, then UUID) and all per-pass budgets are unchanged (probe and `QueueBoundsTest`).
- **Release-test hooks cannot run in normal play.**
  - `ReleaseTestCommands.register` returns before registering anything unless `Boolean.getBoolean("advancedrocketrycommunity.releaseTestHooks")`. It is also re-checked on every command registration, including `/reload`.
  - The commands also require permission level 2.
  - The C7 `release-test` literals and `releaseTestBatch(…, owners)` check the same property.
  - The only always-on addition is the post-tick timing: two `nanoTime` calls per tick into a 100-slot array. It only measures, and it is exposed only to the flag-gated `perf ticks` and the admin diagnostics.

## New findings

| ID | Severity | Location | Description | Scenario | Recommended fix |
|---|---|---|---|---|---|
| C9R2-L1 | Low | `satellite/terminal/SatelliteTerminalBlock.java:81-95` (the delivery travels only inside the dropped terminal item); `onRemove` `:131-139`; block properties `registry/ModBlocks.java:88-96` (`requiresCorrectToolForDrops`, `needs_iron_tool`, loot `survives_explosion`) | This is the H2 residual. A removal that does not yield the terminal item still deletes the reward buffer, the receipts and the ID, and strands the bound missions until an operator rebinds them. Those removals are a wrong tool or a bare hand, an explosion when the decay roll fails, and creative breaking. The probes show it: bare hand gives `drops=[]`; an explosion of radius 3 (a creeper) carried the item in 19 of 60 rolls, so about 2/3 of such explosions lose the buffer. Vanilla shulker boxes behave the same way, but chests drop their contents. ADR-051 §11 does not list this residual. | A creeper explodes next to a terminal that holds up to 3,456 unwithdrawn reward items. | Either record it as a known issue with the shulker-box rationale, or drop the buffer contents as items in `onRemove` whenever the removal will not carry the root. The ID and receipts may still be lost; only READY/ACTIVE bound missions then need a rebind. Alternatively, refuse a survival wrong-tool removal while the delivery section is non-empty, as is already done for uncarryable roots. |
| C9R2-L2 | Low | `satellite/terminal/TerminalResourceActions.java:314-318` (the gate calls `apply` and then returns `null`), `:336-362` (`apply` swallows a `RuntimeException`) | Clarification 6 relies on "an action on a mission sees that mission's receipt first". If the acted-on row throws, the failure is logged and skipped, and the claim or cancel goes ahead anyway. A cancel could then return the instance of a paid mission to AVAILABLE. The same applies to a failing load-pass row. No current code path throws there (the barrier failure is now caught), so this is hardening only. Also, `failureReported` is never reset in `reloaded()`, so the log says "once per load" but really reports once per block-entity lifetime. | A future defect in a reconciliation row turns into a silent conservation gap instead of a refused action. | Make `apply` report failure. Have the gate refuse (for example `UNSUPPORTED_DATA`) when the acted-on row, or a row of the pass it waited for, failed. Reset `failureReported` in `reloaded()`. |
| C9R2-L3 | Low (documentation) | `docs/work/v1.6.0-c9-review/VERIFICATION.md:39`, `:46-47` | The L3 residual and Q1/Q2 are said to be "recorded in the v1.6 handoff's KNOWN-ISSUES". No `docs/releases/v1.6.0/KNOWN-ISSUES.md` exists in `eb5b80e`. The working tree has an untracked `docs/releases/v1.6.0/`, so it seems to be on the way. | — | Commit the KNOWN-ISSUES entries (L3, Q1, Q2 and C9R2-L1 if it is not fixed) with the handoff, before any v1.6 Gate evidence cites them. |

Minor observations, not findings:
- `TerminalResourceActions.java:131` sets the owner before the start's own checks, so a press that fails still claims an unowned terminal. If an operator uses another player's chip at an unowned terminal, the operator becomes its owner.
- A moved terminal keeps the old display location in its bound missions (display-only), so `TERMINAL_MISSING` can show while the terminal exists elsewhere.
- `SatelliteMissionRegistry` is now 798 lines and `SatelliteTerminalBlockEntity` 793: both are close to the 800-line ADR threshold.

## Judgement of clarification 6 and the L3 residual

- **Clarification 6: acceptable.**
  - ADR-051 §7 says a terminal "reconciles its bound missions and every mission named by its receipts" before each action.
  - The implementation instead reconciles every receipt, plus the only row that needs action without a receipt (claims paid here and not acknowledged), at load and every 20 ticks. Before a claim or cancel it reconciles the acted-on mission's row.
  - By the §7 table, every row it omits is "Nothing". The acted-on row is the only one that can change the result of that action. A start cannot be affected.
  - Actions wait only for the load pass: at most about 512 rows, 8 ticks.
  - This keeps the conservation argument (confirmed by the held-receipt probes) and removes the H1 livelock.
  - It narrows the ADR wording, so it should be carried into the next ADR-051 revision or a recorded clarification, as VERIFICATION.md does. C9R2-L2 is recommended so the argument also holds when a row fails.
- **L3 residual: acceptable as a residual.**
  - The implementers are right that gating withdrawal does not close the class. Once the receipt is saved, a torn save of the player file and the chunk duplicates a withdrawn stack, exactly as for a vanilla chest.
  - The rematerialization variant duplicates at most what was withdrawn before the cut. It needs a registry flush and a player-data save (logout) inside the few seconds before the chunk's incremental save.
  - It must be written down (C9R2-L3).

## Verdict

**ACCEPT.** All five required round-1 findings (H1, H2, M1, M2, M3) are resolved, and each was confirmed by
re-running my probes through the fixed APIs and the real menu and limiter. L1, L2 and L4–L9 are resolved. The
fixes introduce no duplication path: the held-receipt claim and cancel paid once and kept the instance
DEPLETED, and the carried root copies no slot. The three new findings are Low and are recommended before the
v1.6 Gate evidence, not required for this slice:
- C9R2-L1: record the no-drop removal residual, or drop the buffer on uncarried removals.
- C9R2-L2: refuse an action whose acted-on row failed.
- C9R2-L3: commit the KNOWN-ISSUES entries.
