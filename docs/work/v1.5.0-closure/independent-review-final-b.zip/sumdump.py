import json,sys
s=json.load(open(sys.argv[1]))
def strip(o):
    if isinstance(o,dict):
        return {k:(('<%d lines>'%len(v)) if k=='station_lines' else strip(v)) for k,v in o.items()}
    if isinstance(o,list): return [strip(x) for x in o]
    return o
print(json.dumps(strip(s),indent=1)[:15000])
