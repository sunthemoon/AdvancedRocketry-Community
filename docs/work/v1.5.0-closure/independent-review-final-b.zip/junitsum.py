import glob,sys,xml.etree.ElementTree as ET
t=f=e=s=n=0
for p in glob.glob(sys.argv[1]+'/*.xml'):
    r=ET.parse(p).getroot(); n+=1
    t+=int(r.get('tests'));f+=int(r.get('failures'));e+=int(r.get('errors'));s+=int(r.get('skipped'))
print('suites',n,'tests',t,'failures',f,'errors',e,'skipped',s)
