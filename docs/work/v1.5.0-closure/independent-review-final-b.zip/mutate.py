import sys, json, pathlib
root = pathlib.Path(sys.argv[1]); mid = sys.argv[2]; mode = sys.argv[3]  # apply|restore
P = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
M = {
 'J1': (P+'celestial/network/StationSkyContextPacket.java',
        'if (buffer.readableBytes() > MAX_BYTES) {', 'if (false && buffer.readableBytes() > MAX_BYTES) {'),
 'J2': (P+'celestial/network/StationSkyContextPacket.java',
        'if (present != 0 && present != 1) {', 'if (false) {'),
 'J3': (P+'celestial/network/StationSkyContextPacket.java',
        'if (buffer.isReadable()) {', 'if (false) {'),
 'J4': (P+'celestial/visual/SkySelection.java',
        '&& orbit.equals(previousOrbit)) {', ') {'),
 'J5': (P+'celestial/visual/SkySelection.java',
        'orbited.map(Orbit::solarIntensity).orElse(match.solarIntensity())', 'match.solarIntensity()'),
 'J6': (P+'celestial/visual/SkyMath.java',
        'ORBITED_BODY_ELEVATION_DEGREES = -25;', 'ORBITED_BODY_ELEVATION_DEGREES = -70;'),
 'J7': (P+'celestial/visual/OrbitalAppearance.java',
        'ModIdentity.id("moon"), 0x8C8C8C,', 'ModIdentity.id("moon"), 0x010208,'),
 'G1': (P+'AdvancedRocketryCommunity.java',
        '''        MinecraftForge.EVENT_BUS.addListener(skyContexts::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerChangedDimension);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerRespawn);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerLoggedOut);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onServerStopping);
''', ''),
 'G2': (P+'station/orbit/StationSkyContextService.java',
        '''    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        sent.remove(event.getEntity().getUUID());''', '''    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {'''),
 'G3': (P+'station/orbit/StationSkyContextService.java',
        '''if (!data.operational() || !level.dimension().equals(CelestialIds.SPACE_LEVEL)
                || server.getLevel(CelestialIds.SPACE_LEVEL) != level) {''', '''if (!data.operational()) {'''),
}
f, old, new = M[mid]
path = root / f
backup = pathlib.Path(str(path) + '.orig')
if mode == 'apply':
    text = path.read_bytes().decode("utf-8")
    n = text.count(old)
    if n != 1: raise SystemExit(f'{mid}: expected 1 occurrence, found {n}')
    backup.write_bytes(text.encode("utf-8"))
    path.write_bytes(text.replace(old, new).encode("utf-8"))
    print(f'{mid} applied to {f}')
else:
    path.write_bytes(backup.read_bytes()); backup.unlink()
    print(f'{mid} restored')
