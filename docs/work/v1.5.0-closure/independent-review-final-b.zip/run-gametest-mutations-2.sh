#!/bin/bash
R=/c/Users/Administrator/AppData/Local/Temp/arce-v150-final-b-review-bafb0541855b40a4aeea9990e4e52684
M=$R/mut
export JAVA_HOME="/c/Program Files/Java/jdk-17.0.7"
cd $M
for id in S1 S2 O1; do
  python $R/mutate_extra.py $M $id apply || exit 9
  rm -rf $M/run/gameteststructures 2>/dev/null
  ./gradlew runGameTestServer --offline > $R/mutation-logs/$id.log 2>&1
  code=$?
  passed=$(grep -o "All [0-9]* required tests passed" $R/mutation-logs/$id.log | head -1)
  failed=$(grep -o "[0-9]* required tests failed" $R/mutation-logs/$id.log | head -1)
  which=$(grep -oE "LogTestReporter\]: [a-z0-9_]+ failed! .{0,160}" $R/mutation-logs/$id.log | head -4 | tr "
" ";")
  echo "$id exit=$code passed='$passed' failed='$failed' tests=$which"
  echo "$id|$code|$passed|$failed|$which" >> $R/mutation-logs/summary.txt
  python $R/mutate_extra.py $M $id restore
done
