#!/bin/bash
R=/c/Users/Administrator/AppData/Local/Temp/arce-v150-final-b-review-bafb0541855b40a4aeea9990e4e52684
M=$R/mut
export JAVA_HOME="/c/Program Files/Java/jdk-17.0.7"
cd $M
for id in G1 G2 G3; do
  python $R/mutate.py $M $id apply || exit 9
  rm -rf $M/run/gameteststructures 2>/dev/null
  ./gradlew runGameTestServer --offline > $R/mutation-logs/$id.log 2>&1
  code=$?
  passed=$(grep -o "All [0-9]* required tests passed" $R/mutation-logs/$id.log | head -1)
  failed=$(grep -o "[0-9]* required tests failed" $R/mutation-logs/$id.log | head -1)
  which=$(grep -o "stationskycontextgametests\.[a-z]*[A-Za-z]*\|theSkyContextIsServerDerived[A-Za-z]*" $R/mutation-logs/$id.log | sort -u | tr '\n' ';')
  echo "$id exit=$code passed='$passed' failed='$failed' tests=$which"
  echo "$id|$code|$passed|$failed|$which" >> $R/mutation-logs/summary.txt
  python $R/mutate.py $M $id restore
done
