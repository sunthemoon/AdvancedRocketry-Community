import json,uuid,copy
H='advancedrocketrycommunity'; S=H+'_stations.dat'
def u(v): return str(uuid.UUID(bytes=b''.join((p & 0xffffffff).to_bytes(4,'big') for p in v)))
b=json.load(open('native/before/decoded.json'))
up=json.load(open('native/upgrade-missing/state/decoded.json'))
rs=json.load(open('native/restart-missing/state/decoded.json'))
fi=json.load(open('native/restored/state/decoded.json'))
print('before registry schema', b[S]['schema_version'], 'stations', [(u(s['station_id'])[:8], s['orbit_body'], s.get('schema_version')) for s in b[S]['stations']])
print('upgraded registry schema', up[S]['schema_version'], 'keys', sorted(up[S].keys()))
print('stations after', [(u(s['station_id'])[:8], s['orbit_body'], s.get('schema_version')) for s in up[S]['stations']])
old={u(s['station_id']):s for s in b[S]['stations']}; new={u(s['station_id']):s for s in up[S]['stations']}
for k in old:
    diff={f:(old[k].get(f),new[k].get(f)) for f in set(old[k])|set(new[k]) if old[k].get(f)!=new[k].get(f)}
    print(k[:8],'diff',diff)
print('restart==upgraded', rs[S]==up[S], 'restored==upgraded', fi[S]==up[S])
print('registry non-station keys before', {k:v for k,v in b[S].items() if k!='stations'})
print('registry non-station keys after', {k:(v if not isinstance(v,list) or len(str(v))<300 else '<list>') for k,v in up[S].items() if k!='stations'})
