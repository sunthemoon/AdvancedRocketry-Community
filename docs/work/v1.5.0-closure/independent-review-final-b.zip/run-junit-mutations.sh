#!/bin/bash
R=/c/Users/Administrator/AppData/Local/Temp/arce-v150-final-b-review-bafb0541855b40a4aeea9990e4e52684
M=$R/mut
export JAVA_HOME="/c/Program Files/Java/jdk-17.0.7"
TESTS="--tests io.github.sunthemoon.advancedrocketrycommunity.celestial.network.StationSkyContextPacketTest --tests io.github.sunthemoon.advancedrocketrycommunity.celestial.visual.SkySelectionTest --tests io.github.sunthemoon.advancedrocketrycommunity.celestial.visual.OrbitalSkyTest"
mkdir -p $R/mutation-logs
TSV=$R/mutations.tsv
[ -f $TSV ] || printf "id\tfile\tchange\tcommand\texit\toutcome\tfailed_tests\n" > $TSV
cd $M
run() {
  id=$1
  ./gradlew test $TESTS --offline > $R/mutation-logs/$id.log 2>&1
  code=$?
  failed=$(grep -o "^[A-Za-z]*Test > [^ ]* FAILED" $R/mutation-logs/$id.log | tr '\n' ';')
  executed=$(grep -c "> Task :test$" $R/mutation-logs/$id.log)
  echo "$id exit=$code executed_test_task=$executed failed=$failed"
  echo "$id|$code|$failed|$executed" >> $R/mutation-logs/summary.txt
}
run BASELINE-J
for id in J1 J2 J3 J4 J5 J6 J7; do
  python $R/mutate.py $M $id apply || exit 9
  run $id
  python $R/mutate.py $M $id restore
done
