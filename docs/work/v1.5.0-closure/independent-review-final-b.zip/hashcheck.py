import json,hashlib,sys
root=sys.argv[1]; f=sys.argv[2]
d=json.load(open(f))
files=d.get('tested_implementation_files') or {}
bad=0
for p,h in files.items():
    try:
        a=hashlib.sha256(open(root+'/'+p,'rb').read()).hexdigest()
    except FileNotFoundError:
        print('MISSING',p); bad+=1; continue
    if a!=h: print('MISMATCH',p); bad+=1
print('checked',len(files),'mismatch',bad)
