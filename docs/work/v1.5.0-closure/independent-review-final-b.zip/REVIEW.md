# Final review B — v1.5 presentation, environment and open confirmations

- Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`,
  HEAD `d45534e` (read-only; this review modified nothing in the repository).
- Reviewer: independent agent (not the implementer). Date: 2026-09-30.
- Working directory for every build, mutation and extraction:
  `C:/Users/Administrator/AppData/Local/Temp/arce-v150-final-b-review-bafb0541855b40a4aeea9990e4e52684`
  (`tree-d45534e/` = pristine `git archive d45534e`; `mut/` = mutation copy, restored byte-exact after
  each mutation; `mutations.tsv`, `mutation-logs/`).
- Scope: (1) `d45534e` ORBIT-03 per-station sky against ADR-047 rev. 2; (2) `a569525` MIG-01a native
  missing-orbit evidence; (3) ORBIT-02 (`f27b11a`, `2fb9bce`, ADR-041) and ORBIT-04 (`30b9b11` and the
  scale measurement); (4) confirmation of the STATION-03/04 fixes (`fa00570`, `e3d136f`, `89600ae`,
  `442e4a7`, `2fb9bce`); AGENTS.md §3.3 and assertion weakening across these commits.
- The private bundle `AdvancedRocketry-Community-v1plus-Development-Docs/` was not read or listed.
- Process note: at the end of the review the repository working tree showed uncommitted changes I did
  not make (`AdvancedRocketryCommunity.java`, `StationManager.java`, `StationRuntime.java` modified;
  untracked `StationRuntimeLifecycleTest.java` and `docs/releases/v1.5.0/`), apparently the
  segment-9 runtime-bridge work. All source line numbers here come from the `git archive d45534e`
  export, and all builds ran there, so these changes are not part of this review.

## Verdicts

| Area | Verdict | Blocking for `verified`? |
|---|---|---|
| 1. ORBIT-03 per-station sky (`d45534e`, ADR-047 rev. 2) | **Accept with changes** (B1–B3 Low; B4–B5 Info). The implementation matches ADR-047 rev. 2; the lifecycle/ordering argument is sound on Forge 47.4.10, but for a reason the ADR does not state (B2). V0/V1/V2 remain open, as the ADR says. | No Critical/High/Medium. B1–B3 should be done before ORBIT-03 leaves `implemented-unverified`; visual acceptance (V1/V2) is separately open. |
| 2. MIG-01a native missing-orbit evidence (`a569525`) | **Accept with changes** (B6 Medium, B7 Info). Every claim in its VERIFICATION follows from the retained logs and decoded states, and the host JAR is bound to source. But the evidence never persists or restarts a station *while* it still orbits the missing body, so it does not by itself discharge ADR-042's "upgrade and restart … unknown-body handling intact" obligation, which the log now declares met. | B6 before ADR-042 is recorded as satisfied. |
| 3a. ORBIT-02 server gravity and effective solar (`f27b11a`, `2fb9bce`, ADR-041) | **Accept with changes** (B8 Medium, B9 Medium, B10 Low). Code matches ADR-041; the earlier review's M1–M3/L1–L6 are fixed. ADR-041's own native gravity restart item was never run, and the write-rate bound is per station only. | B8 (or an ADR waiver) and B9 before `verified`. |
| 3b. ORBIT-04 capacity fix and scale measurement (`30b9b11`) | **Accept** for the fix and the measurement (reproduced: 176.6 ms median at 4,096 stations vs. 172.4 ms claimed; lookup 125 ns). The ORBIT-04 leaf correctly stays `in-progress`; B9 and B11 apply. | ORBIT-04 remains in progress (plan §10 native multi-station/reload items). |
| 4. STATION-03/04 confirmation | **Accept with changes** (B12 Low, B13 Info). The re-review's M1, L1, L2 and L3 are fixed and I confirmed each (code, GameTests, second native run, FROM-CACHE disclosure). STATION-04's scope depends on ADR-042 → MIG-01a (B6) and MIG-01b (not reviewed here). | B12 wording only; STATION-04 also waits on B6. |

No Critical or High findings.

## Findings

### Area 1 — ORBIT-03 (`d45534e`)

What matches ADR-047 rev. 2 (verified by reading the code and by the tests/mutations below):

- Server `station/orbit/StationSkyContextService.java`: every 10 ticks (`:27`, `:47-51`), context
  from the player's own `serverLevel()` and block X/Z with one `findAt` (`:37-45`); Space-only and
  non-operational → none; send only on change, with "no entry" meaning "nothing sent" (`:59-65`);
  UUID-keyed map pruned every pass (`:67`), forgotten on respawn, Level change, logout (`:72-82`),
  cleared at stop (`:84-86`). Wired once at construction with `StationRegistrySavedData.get(server)`
  per pass (`AdvancedRocketryCommunity.java:184-189`). Dependencies: station → celestial only.
- Protocol: `CelestialNetwork.java:13` protocol `"3"`, message 1 `PLAY_TO_CLIENT` (`:29-33`);
  pin table and `CelestialSnapshotV2Test` updated; snapshot schema stays 2. Codec
  (`StationSkyContextPacket.java:21,35-56`): `MAX_BYTES = 131`, strict 0/1 byte, `readUtf(128)`,
  `tryParse` null → `DecoderException`, trailing bytes rejected. Forge validates direction
  (`IndexedMessageCodec.java:152`), so a client cannot push message 1 to a server.
- Client: `StationSkyContextCache` (common package, `AtomicReference`, no `net.minecraft.client`
  import; `check_client_imports.py` PASS); cleared on `LoggingOut` and `Clone`
  (`ClientSkyEvents.java:24-30`, `PlanetarySkyClient.java:67-75`); applied only in Space
  (`PlanetarySkyClient.java:36-40`); `SkySelection` cache key includes the orbit by value and the
  body lookup runs only on a miss (`SkySelection.java:28-35,52,60-69`); sun follows the orbited
  body's snapshot intensity with or without a profile, missing body → Space sun and no disc
  (`:52-54`); `OrbitalAppearance` table equals the ADR table and the 0.2-luminance/neutral rule
  (`OrbitalAppearance.java:15-35`); renderer draws stars → disc (sun mesh, `rotateZ(-115°)`,
  30° radius, opaque tint) → halo → sun (`PlanetarySkyRenderer.java:61-77`), all inside the existing
  `assertOnRenderThread` / state-restore block; no new mesh or upload.
- Geometry checked independently: `rotateZ(-115°)` maps +Y to (0.906, −0.423, 0) = 25° below the
  horizon toward +X; the sun transform `rotateY(-π/2).rotateX(π)` maps +Y to the nadir; separation
  65°; the halo actually reaches atan(2.5·tan 12°) ≈ 28°, so the ADR's 30° bound is conservative.
  `space.json` `fixed_time` 18000 confirmed (`src/generated/v1.4/.../dimension_type/space.json`).
- Server/client solar agree with ADR-041: `StationOrbitEnvironmentResolver.java:46-50` uses the
  orbited body's intensity, else Space's; the client uses the orbited snapshot entry, else the Space
  entry.
- Revision-1 review (`independent-review-sky.zip`, SHA-256 matches `SHA256SUMS.txt`): F1, F2, F3 (option
  B), F4, F5, F6, F9, F10 are applied. F7 and F8 are only partly applied (B3).

**Lifecycle and ordering (the question asked).** I checked the Forge 47.4.10 mapped bytecode
(`javap` of `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar`, outputs in `mc/`) and the Forge sources:

- Server: `ServerPlayer.teleportTo(ServerLevel,…)` sends `ClientboundRespawnPacket` (offset 116) and then
  fires `firePlayerChangedDimensionEvent` (offset 257); `changeDimension` sends it at 179 and fires the
  event at 473; `PlayerList.respawn` builds the respawn packet at offset 542 and fires
  `firePlayerRespawnEvent` at 733. The
  "forget" therefore always follows the respawn packet on the server thread, and every later pass
  sends after it. The project's own cross-Level moves use `teleportTo`
  (`SafeCelestialTravel.java:86`, `RocketTransferEntities.java:260`), which fires the event.
- Client: `ClientPacketListener.handleRespawn` calls `PacketUtils.ensureRunningOnSameThread` first
  (offset 6) and fires `ForgeHooksClient.firePlayerRespawn` → `ClientPlayerNetworkEvent.Clone` on the
  main thread (offset 462). `handleCustomPayload` calls `NetworkHooks.onCustomPayload` **before**
  `ensureRunningOnSameThread` (offsets 5 and 18), so SimpleChannel consumers run on the Netty thread;
  message 1 is registered with `consumerMainThread`, which is `ctx.enqueueWork(...)`
  (`SimpleChannel.java:269-276`) → `BlockableEventLoop.submitAsync` into the same FIFO queue as the
  respawn task (`NetworkEvent.java:205-215`). The respawn (and its `Clone` clear) therefore always runs
  before a context decoded after it, including on the integrated server (Netty local IO thread).
- Logout: `Minecraft.clearLevel` calls `dropAllTasks` (offset 10) and closes the connection (14)
  before `firePlayerLogout` (65), so no queued context task from the old connection can run after the
  logout clear; the rev-1 "defensive LoggingIn clear" is not needed.
- Same-tick changes (respawn + dimension change, A→B→A inside one window, logout + login) all end in
  "forgotten on the server, cleared on the client, next pass sends the current value", or "no change,
  nothing to send". I found no path that loses or keeps a stale context under vanilla/Forge paths.
  A mod that sends its own `ClientboundRespawnPacket` without the Forge events would leave the context
  cleared until the next change (presentation only).

#### B1 — Low — The lifecycle GameTest does not exercise the production wiring or a real respawn/Level change

- Evidence: `StationSkyContextGameTests.java:62-63` builds its own `StationSkyContextService` with a
  capturing sender; `:105-111` calls `onPlayerRespawn`/`onPlayerChangedDimension` directly with
  synthetic events (the "Level change" event is posted while the viewer never leaves Space). The
  production instance registered at `AdvancedRocketryCommunity.java:184-189` is never observed.
- Mutation G1 (delete all five `EVENT_BUS.addListener(skyContexts::…)` lines): full
  `runGameTestServer` exit 0, "All 257 required tests passed" (`mutation-logs/G1.log`). The rev-1
  review's F3 asked for GameTests of "a death respawn inside the same station" and "a Space → other
  Level → Space round trip within one pass"; these are simulated, not performed. The same class of
  gap was fixed for ORBIT-02 by posting a real `LivingTickEvent` on the bus (orbit-environment L3).
- Impact: a wiring regression (e.g. a lost respawn/dimension listener, or the tick listener) would
  leave players without an orbit disc after a respawn or re-entry until the context changes; no
  authority or data impact.
- Required change: drive the registered service. For example, make the production instance
  reachable to GameTests (package-private accessor or a small holder), perform a real
  `PlayerList.respawn` and a real `teleportTo` out of and back into Space for a connected mock
  player, and assert the re-send on the captured packets (or post the real Forge events on
  `MinecraftForge.EVENT_BUS` against that instance). Keep the existing direct-call test.

#### B2 — Low — The ordering argument in ADR-047 is incomplete; its real invariant is unpinned

- Evidence: ADR-047 "Lifecycle" (`ADR-047…md:90-91`) justifies correctness with "The reset and the
  re-send travel on the same ordered connection." Transmission order alone is not sufficient: the
  vanilla respawn is deferred to the main thread while Forge channel consumers run on the Netty
  thread (bytecode above). Correctness actually depends on message 1 being registered with
  `consumerMainThread` (`CelestialNetwork.java:32`). If it were changed to `consumerNetworkThread`
  (which is valid for a cache-only handler and is a plausible "optimization"), a context decoded
  while the respawn task is still queued would be applied first and then erased by `Clone`; the
  server, having already recorded it as sent, would not resend it.
- Required change: state the invariant in ADR-047 (the context handler must run on the client main
  thread so it is queued after the vanilla respawn handling that fires `Clone`) and at the
  registration site. Optionally let `NetworkProtocolPinTest`'s source scan also pin
  `consumerMainThread` for this message.

#### B3 — Low — Parts of the revision-1 required changes F7/F8 were not applied, while VERIFICATION says they were

- Evidence (rev-1 `REVIEW.md` F7/F8 vs. the implementation):
  - F7 asked for a quarantined-registry case; there is none (`StationSkyContextGameTests` covers the
    blocked registry only). ADR-047 (`:61`) states the quarantined behaviour without a test.
  - F7 asked for map cleanup "after logout and at stop"; only the logout pruning is tested
    (`:153-155`), not `onServerStopping`.
  - F7's V1 list asked for "no OpenGL errors", "frame time against a baseline", "release on logout"
    and a statement that an unattended agent client launch is not V1 evidence; ADR-047's V1 list
    (`Verification`) omits them.
  - F8 asked that a failure for one player not stop the pass for others; `pass` has no per-player
    isolation (`StationSkyContextService.java:57-66`) and ADR-047 does not state the choice. (Today
    nothing in the loop is expected to throw: IDs are already bounded by `StationState`.)
  - F8's "defensive LoggingIn clear" was not added; my bytecode check above shows it is unnecessary,
    but the disposition is not recorded.
  - `docs/work/v1.5.0-orbit-sky/VERIFICATION.md` "Review handling" lists F7 and F8 as handled.
- Required change: add the quarantined case (or record why it is equivalent to the operational case)
  and a stop-clearing assertion; add the missing V1 items to ADR-047's ACC-02 list; record the F8
  dispositions (per-player isolation not needed / LoggingIn clear unnecessary, with the reason); make
  the VERIFICATION table say "partly" where applicable.

#### B4 — Info — The geometry test checks a mirror of the renderer, not the renderer

`OrbitalSkyTest.theDiscNeverCoversTheSunOrItsHaloInTheSpaceLevel` uses `SkyMath.orbitedBodyDirection`
and `SkyMath.sunDirection`, which restate the transforms in `PlanetarySkyRenderer.java:61,67-69`; the
renderer does not call them. Mutation J6 (elevation −70°) is caught because the renderer and the test
share the constant, but a change to the renderer's rotation would not be. Suggested: have the renderer
take its rotation from a `SkyMath` helper so the tested function is the rendered one. V1 must confirm.

#### B5 — Info — The 131-byte pre-check is not independently tested (mutation J1 survives)

`StationSkyContextPacket.java:36-38` is redundant with `readUtf(128)` plus the trailing-byte check,
so removing it changes no outcome (J1: exit 0). Acceptable as defence in depth; no change required.

### Area 2 — MIG-01a (`a569525`)

#### B6 — Medium — The native run never persists or restarts a station while its orbit body is missing; the log treats ADR-042 as discharged

- Evidence: the harness evacuates the Mars station in the first process
  (`root-checks.zip:native_missing_orbit_check.py:228-273`, `upgrade_actions`), so the first
  persisted state already has `orbit_body = earth`. My decode of the retained states:
  before → upgraded differs only in `schema_version 1→2` and `orbit_body mars→earth`; `restart-missing`
  and `restored` registries equal the upgraded one (`migcheck.py`, exit 0). The only v1.5 observation
  of the unknown ID is the runtime `admin inspect` line (`orbit=…:mars`) and the one
  `ARCE_STATION_UNKNOWN_ORBIT_BODY` report at the upgrade start. Not exercised natively: the ordinary
  v1.5 `SavedData` save of a station with an unknown orbit, a restart with that record (report again,
  environment `(unavailable)`, ID kept), and restoring Mars while the station still orbits it.
- The VERIFICATION text itself is accurate ("restart-missing … The station orbits Earth"), but the
  implementation log (`v1.5.0-implementation-log.md:144-145`) says "ADR-042's deferred cases now both
  have native evidence; its expiry condition is met", and STATION-04's original acceptance, which
  ADR-042 moved to MIG-01, is "upgrade **and restart** … unknown-body handling intact".
- Required change: add a phase before the evacuation (restart with Mars still hidden: record and ID
  retained through an ordinary save, one report per start, `environment` unavailable) and a restore of
  Mars while the station still orbits it (environment available again, record unchanged), then
  evacuate; or narrow the log/ADR-042 closure statement and list these cases under "Not covered" with
  their owner.

#### B7 — Info — The remaining MIG-01a claims were confirmed

- `SHA256SUMS.txt` OK; host JAR `a99f78c0…` equals the WARP-05 artifact whose 13 tested files match
  `a96569b` byte-for-byte (`hashcheck.py`: 13 checked, 0 mismatch), and `git diff a96569b 2900e66 --
  src/ build.gradle gradle.properties compat-test-mod` is empty.
- Summary: `managed=4, migrated=1`; exactly one `ARCE_STATION_UNKNOWN_ORBIT_BODY`; 22 WARN, 0 project
  WARN; quote `interstellar warp, cost 8000000 FE`; commit `balance=0`; `restart-missing`/`restored`
  `migrated=0, backup=none`; source world unchanged; the other station (Moon) changed only
  `schema_version 1→2`. The harness asserts each (`:229-301`), so the PASS is not vacuous.
- Attempt 01's cause: the retained log has no stack trace, but the probe at `a569525`
  (`StationExpansionProbe.java:53,203-204`) allows only expansion/warp commands and throws
  `IllegalArgumentException` for `arce station environment`, consistent with the claimed harness
  defect. Attempt 02's "That position is not loaded" is in its `latest.log:84`.

### Area 3 — ORBIT-02 / ORBIT-04

Confirmed against ADR-041: the resolver (`StationOrbitEnvironmentResolver.java:24-63`, one `findAt`
plus one catalog lookup, Space only, blocked → empty, missing body → Space solar and `available=false`,
no catalog → 0); gravity override wired at construction (`AdvancedRocketryCommunity.java:169-170`,
`StationManager.java:290-294`, clamp to 4.0, `CelestialGravityController.java:35-46` falls back to the
Level profile); gravity command with the shared local-actor gate (`StationLocalActor.java:54-76`),
0..100 %, unchanged value writes nothing and starts no cooldown, committed/failed/unknown writes start
it (`StationGravityService.java:35-74`); checked transitions narrowed to growth or gravity-only
(`StationState.java:224-237`) and refused before any write (`StationRegistrySavedData.java:406-412`);
identity shown only to owner/members/operators (`StationCommands.java:239-241`). The earlier review's
L3 test gaps are closed (real `LivingTickEvent` on the bus, `StationOrbitGameTests.java:126`; API 5.0
vs physics 4.0, `:152-161`; cooldown, `:110`). Mutations O1 (ignore the station override) and S2 (skip the cooldown check) are both killed by
`StationOrbitGameTests`.

#### B8 — Medium — ADR-041's native gravity set/restart readback was never run

- Evidence: ADR-041 `Verification` (`ADR-041…md:148`): "Native (with STATION-04 harness): set gravity,
  restart, value retained." `docs/work/v1.5.0-orbit-environment/VERIFICATION.md:90` "not yet run";
  implementation log `:362` lists it as remaining; no later native packet (warp-native, mig-native,
  mig-missing-orbit) sets gravity (`git grep` over `docs/work` finds no such run).
- Required change: run it (the MIG/STATION probe needs `arce station gravity <n>` on its allow-list;
  read back `gravity_milli` from the decoded file after stop and after restart, and the attribute or
  `environment` line after restart), or record an ADR waiver with owner, expiry and recovery
  condition (AGENTS.md §5). Until then ORBIT-02 must stay `implemented-unverified`.

#### B9 — Medium — The rate bound on full-registry fsync writes is per station, not per server

- Evidence: each checked write re-encodes, validates, writes, forces, re-reads and decodes the whole
  station file on the server thread (`StationRegistrySavedData.java:392-459`). My rerun of
  `StationCheckedUpdateScaleTest` in the full build: 4,096 stations median 176.6 ms, max 176.7 ms
  (evidence claims 172.4 ms). The only bound is `StationWriteCooldown` keyed by station
  (`StationGravityService.java:14,17,39-41`); ADR-041 (`:73-74`) and
  `docs/work/v1.5.0-station-capacity/VERIFICATION.md:55` ("The 5-second per-station cooldown bounds its
  rate") treat that as the rate bound. With k owners (or operators moving between stations) each
  toggling 0 %/1 %, the server spends about k × 176 ms per 100 ticks at capacity: a single owner already
  puts 1 % of ticks at 176 ms (the P99 MSPT limit of 100 ms is then at its edge), two or more exceed it,
  and k ≈ 28 saturates the server thread.
  `docs/17-V1PLUS-QUALITY-BUDGETS.md` §4 (P99 ≤ 100 ms, single spike ≤ 500 ms) and §5 ("每个系统必须有
  可配置硬上限", with global as well as per-actor limits as the examples show) apply. Warp commits and
  expansions share the path but are costed or one-shot.
- Required change: add a server-wide bound for checked station writes (e.g. at most one checked write
  per N ticks server-wide, or a token bucket sized from the measured write time, with a "busy, retry"
  reply code and a config value), test it, and correct the ADR-041 and capacity-VERIFICATION wording;
  or record the residual in ADR-041 with a measured justification and an expiry.

#### B10 — Low — Stale status statements in the ORBIT-02 evidence and log

- `docs/work/v1.5.0-orbit-environment/VERIFICATION.md:7` still says ADR-041 "is **PROPOSED**: its
  independent contract review is pending"; ADR-041 is ACCEPTED and the review is archived in the same
  directory. `v1.5.0-implementation-log.md:352` says ORBIT-02 is "pending confirmation of the review
  fixes", but the capacity packet records that confirmation review (`station-capacity/VERIFICATION.md`
  "Also in this change").
- Required change: update both texts (the status stays `implemented-unverified` because of B8/B9).

#### B11 — Info — Heap-accounting headroom is empirical

`30b9b11` made the heap quota a multiple of the raw bound (later per type, `heapAccountingFactor()`).
Measured ratios in my full run: stations 5.67, satellites 5.02, rocket transfers 6.89 against a factor
of 8 (`ARCE_BOUNDED_IO_CAPACITY` lines in the JUnit XML). NBT whose content is dominated by small
compounds can account far more heap per raw byte, and every managed file is read through this path at
each start (`WorldDataMigrationService.java:112`), where an `OVERSIZED_DATA` refusal fails closed.
Residual risk only; a worst-case-composition bound per type (especially for block-entity NBT in rocket
transfers) would retire it.

### Area 4 — STATION-03/04 confirmation

Status of the re-review (`station-native/independent-review-2.zip`) findings at HEAD:

| Prior | Status | Basis |
|---|---|---|
| M1 (acceptance only partly covered; TODO dropped) | Fixed for STATION-04's own scope | Second native run: my decode of `native-checks-2.zip` shows the v1.4-written invitation, owner transfer and member retained; v14→upgrade changes only `schema_version` and the target region (`[-256..255]` → `[-384..383]`); restart equals upgrade; marker probes "Test passed" 4/8/4 in v14-team/upgrade/restart, 0 failed. Rocket and missing-orbit cases moved to MIG-01 by ADR-042 (see B6). |
| L1 (own-source silent paths accepted) | Fixed | `StationCommands.java:264-266` requires `source.source == player && source.withSuppressedOutput() != source`; bytecode: `withSuppressedOutput` returns `this` only when `silent` or `alwaysAccepts()`, and `ServerPlayer` does not override `alwaysAccepts`. |
| L2 (player-list check untested) | Fixed | `StationExpansionGameTests.java:104-120,141-146`: silent own source, FakePlayer with the owner's UUID and the stale logged-out object all rejected as `NOT_LOCAL_PLAYER`. Mutation S1 is killed by this test and by the A1 permission matrix. |
| L3 (FROM-CACHE JUnit reported as a run) | Fixed | `station-native/VERIFICATION.md` "restored FROM-CACHE"; the fix round's run executed `:test`. |

#### B12 — Low — The "/execute cannot" wording still overclaims

`StationManagementCode.java:12-13` ("command blocks, functions, signs and /execute cannot manage
stations") and ADR-041 `:92` list `/execute` as rejected, but a player's own, non-silent
`/execute as @s run arce station …` (or `/execute at`/`in` wrappers typed by that player) is accepted,
correctly, because the output source stays the player. The re-review's L1 wording point is therefore
only partly corrected. Required change: say "`/execute` run by someone else (console, command blocks,
other players)" or similar in both places.

#### B13 — Info — Caller-asserted `issuedByPlayer` remains a public parameter

`StationManager.requestExpansion/confirmExpansion/setGravity(ServerPlayer, boolean issuedByPlayer, …)`
(`StationManager.java:263-274`) still trust a boolean; only the command path calls them. Deriving the
flag from the `CommandSourceStack` inside the service would make a future caller unable to bypass the
gate by accident (re-review I3). No change required for v1.5.

### AGENTS.md §3.3 and assertion checks

- Server authority: the sky context, gravity, environment and expansion all derive position from the
  server's `player.blockPosition()`/`serverLevel()`; no client-supplied position, station or body is
  accepted (message 1 is S2C only and direction-validated by Forge).
- Chunk loading from input: none. `findAt` is an index lookup; `hasChunkAt` only inspects loaded
  chunks (`StationLocalActor.java:68-69`); the sky GameTest's loaded-chunk comparison passes.
- Per-tick budget: sky pass O(online players) every 10 ticks; gravity one indexed lookup per player
  tick (125 ns measured). Checked writes: see B9.
- Network/NBT bounds: message 1 ≤ 131 bytes, strict decoding (J2/J3 killed); managed files bounded
  by raw quota plus heap quota (B11).
- Schema versions: ORBIT-03 adds no persistence; channel protocol bumped 2 → 3 with the pin table.
- Common/server code never references `net.minecraft.client`: `check_client_imports.py` PASS on the
  export; the ORBIT-03 common classes (`StationSkyContextPacket`, `StationSkyContextCache`,
  `SkySelection`, `OrbitalAppearance`, `SkyMath`) import no client or client-package class.
- No weakened assertion: in `fa00570`, `e3d136f`, `442e4a7`, `f27b11a`, `2fb9bce`, `30b9b11`,
  `a569525`, `d45534e` every removed assertion line is a rename (`StationExpansionCode` →
  `StationManagementCode`, 18 removed / 18 added `expect(` in `f27b11a`), the re-reviewed `e3d136f`
  restructuring (its removed `CHUNK_UNLOADED` step is the re-review's I2), the mod-description literal,
  or the intended protocol pin `"2"` → `"3"`.

## Mutation results

Single-change mutations in `mut/` (restored byte-exact after each; full table in `mutations.tsv`,
logs in `mutation-logs/`):

JUnit command: `./gradlew test --tests …StationSkyContextPacketTest --tests …SkySelectionTest --tests
…OrbitalSkyTest --offline` (11 tests). GameTest command: `./gradlew runGameTestServer --offline`
(257 required GameTests).

| ID | Single change | Exit | Outcome |
|---|---|---|---|
| BASELINE-J | none | 0 | 11 tests pass |
| J1 | `StationSkyContextPacket`: disable the 131-byte pre-check | 0 | **Survived** (redundant guard; B5) |
| J2 | `StationSkyContextPacket`: disable the strict 0/1 presence check | 1 | Killed (`oversizedInvalidAndTrailingInputIsRejected`) |
| J3 | `StationSkyContextPacket`: disable the trailing-bytes check | 1 | Killed (same test) |
| J4 | `SkySelection`: drop the orbit from the cache key | 1 | Killed (`aStationContextAddsTheOrbitedBodyAndItsSun`) |
| J5 | `SkySelection`: sun always uses the Level's intensity | 1 | Killed (same test) |
| J6 | `SkyMath`: disc elevation −25° → −70° | 1 | Killed (`theDiscNeverCoversTheSunOrItsHaloInTheSpaceLevel`) |
| J7 | `OrbitalAppearance`: Moon colour → its dark surface day colour `0x010208` | 1 | Killed (`everyPackagedOrbitableBodyHasAVisibleColour`) |
| G1 | `AdvancedRocketryCommunity`: remove the five `EVENT_BUS` registrations of the production sky service | 0 | **Survived**: "All 257 required tests passed" (B1) |
| G2 | `StationSkyContextService.onPlayerRespawn` no longer forgets the player | 1 | Killed: "after a respawn: expected one context …moon but got []" |
| G3 | `StationSkyContextService.contextFor` ignores the Level | 1 | Killed: "outside Space: expected one context Optional.empty but got []" |
| S1 | `StationCommands.issuedBy` drops the non-silent requirement | 1 | Killed: "A silent own-source request was accepted"; permission matrix "6 cells differ" |
| S2 | `StationGravityService`: skip the cooldown check | 1 | Killed: "A second change inside the cooldown was written" |
| O1 | `CelestialGravityController`: ignore the station override | 1 | Killed: "Station gravity not applied: 0.0" |

The mutation copy was compared with a fresh `git archive d45534e src/main` after the campaigns
(`diff -r`: identical).

## Required changes

1. **B6 (Medium):** add a MIG-01a phase that restarts (ordinary save) and restores Mars while the
   station still orbits the missing body, or narrow the log's ADR-042 closure statement and list those
   cases as not covered with an owner.
2. **B8 (Medium):** run the native gravity set → restart → readback that ADR-041 requires, or waive it
   by ADR with owner, expiry and recovery condition.
3. **B9 (Medium):** add a server-wide bound (configurable) on checked station writes with a "busy"
   reply and a test, and correct the "cooldown bounds its rate" wording; or record the residual in
   ADR-041 with an expiry.
4. **B1 (Low):** exercise the production-registered sky context service with a real respawn and a real
   Level round trip (or real Forge events on the bus).
5. **B2 (Low):** document (and preferably pin) that message 1 must be handled on the client main thread.
6. **B3 (Low):** add the quarantined and stop-clearing cases, the missing V1 items, and the F8
   dispositions; correct the VERIFICATION "Review handling" table.
7. **B10 (Low):** update the stale ADR-041/ORBIT-02 status texts.
8. **B12 (Low):** correct the "/execute cannot" wording in `StationManagementCode` and ADR-041.

## Residual risks

- No real client has rendered the orbit disc or observed the context lifecycle (V0 not run, V1/V2
  open for ACC-02); the renderer transform is only mirrored by the geometry test (B4).
- A mod that sends its own respawn packet without the Forge events would leave the sky context cleared
  until the next change (presentation only).
- Checked-write timings come from one Windows development machine and one disk.
- Heap-accounting headroom is empirical (B11).
- Mods that dispatch non-silent commands as the player remain trusted for station management.
- STATION-04's deferred rocket case depends on MIG-01b, which this review did not examine.
- ORBIT-04's native multi-station/reload items (plan §10) remain open.

## Commands actually run (exit codes)

All builds ran with `JAVA_HOME=/c/Program Files/Java/jdk-17.0.7` in my Temp directory, never in the
repository. Repository commands were read-only.

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `git log --oneline -30`, `git status --short`, `git show --stat/-- <paths>` for the listed commits, `git grep`, `git diff --stat a96569b 2900e66 -- src/ build.gradle gradle.properties compat-test-mod`, `git diff --name-only 1a5763a a96569b -- src/` | 0 | read-only; the `a96569b..2900e66` source diff is empty |
| 2 | `git archive d45534e \| tar -x` into `tree-d45534e/` and `mut/`; `git archive a96569b \| tar -x` into `tree-a96569b/`; `git archive d45534e src/generated src/main` into `gen-pristine/` | 0 | exports outside the repository |
| 3 | `sha256sum -c SHA256SUMS.txt` in `docs/work/v1.5.0-{orbit-sky,mig-missing-orbit,station-native,station-expansion,orbit-environment,station-capacity}` | 0 | all OK |
| 4 | `python hashcheck.py` (tested-file SHA-256 vs. export): orbit-sky vs `d45534e`; warp-native vs `a96569b` | 0 | 19/0 and 13/0 mismatches; all 12 files changed `1a5763a..a96569b` are in the tested set |
| 5 | `javap -c -p` on `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar` (`ServerPlayer`, `ClientPacketListener`, `Minecraft`, `PlayerList`); `unzip` of Forge sources (`SimpleChannel`, `NetworkEvent`, `IndexedMessageCodec`) | 0 | outputs in `mc/`, `forge-src/` |
| 6 | `./gradlew clean build test runData runGameTestServer --no-daemon` in `tree-d45534e/` | 0 | BUILD SUCCESSFUL in 4m 29s; `:test` executed (not FROM-CACHE); 1,051 JUnit / 192 suites, 0 failures, 0 errors, 0 skipped; "All 257 required tests passed"; log `full-run-d45534e.log` |
| 7 | `diff -r gen-pristine/src/generated tree-d45534e/src/generated` | 1 | only `src/generated/v1.5/resources/.cache` (git-ignored, `.gitignore`); no generated content change |
| 8 | `python scripts/check_client_imports.py` in the export | 0 | PASS |
| 9 | `python migcheck.py` (MIG-01a decoded states), `python n2diff.py` (STATION-04 second run), marker `grep` | 0 | as reported in B6/B7 and Area 4 |
| 10 | JUnit mutation campaign `run-junit-mutations.sh` (BASELINE-J, J1–J7) | 0 (script) | per-mutation exits in the table above |
| 11 | GameTest mutation campaigns `run-gametest-mutations.sh` (G1–G3) and `run-gametest-mutations-2.sh` (S1, S2, O1) | 0 (scripts) | per-mutation exits in the table above |
| 12 | `diff -r gen-pristine/src/main mut/src/main` after the campaigns | 0 | identical. Note: the first JUnit campaign's restore step rewrote the mutated files with CRLF line endings (content otherwise identical); I re-copied the pristine sources and made the mutator byte-exact before the GameTest campaigns, then re-checked with this diff. |

One intermediate attempt to sum JUnit XML with Python failed on a Windows long path (exit 1); the
count in row 6 was taken with `grep` over the same XML files.

## Statement

This is an independent implementation and evidence review. It is **not a Gate approval**. It does not
mark ORBIT-02, ORBIT-03, ORBIT-04, MIG-01, STATION-03 or STATION-04 `verified`, does not accept or
waive any ADR item, does not change any version status, and does not replace the maintainer's
decision. v1.5 and G0–G9 remain `IN_PROGRESS`.
