import json,sys
s=json.load(open(sys.argv[1]))
for l in s['cycles'][0]['station_lines']:
    if 'charge_' in l: continue
    print(l[:500])
