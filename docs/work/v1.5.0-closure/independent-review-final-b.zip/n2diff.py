import json,uuid
H='advancedrocketrycommunity'; S=H+'_stations.dat'
def u(v): return str(uuid.UUID(bytes=b''.join((p & 0xffffffff).to_bytes(4,'big') for p in v)))
st={k:json.load(open(p))[S] for k,p in [('before','native/before/decoded.json'),('v14','native/v14-team/state/decoded.json'),('up','native/upgrade/state/decoded.json'),('rs','native/restart/state/decoded.json')]}
def rec(d): return {u(s['station_id']):s for s in d['stations']}
b,v,up,rs=[rec(st[k]) for k in ('before','v14','up','rs')]
for sid in b:
    print('station',sid[:8])
    print('  before->v14 diff', {f:(b[sid].get(f),v[sid].get(f)) for f in set(b[sid])|set(v[sid]) if b[sid].get(f)!=v[sid].get(f)})
    d={f:(v[sid].get(f),up[sid].get(f)) for f in set(v[sid])|set(up[sid]) if v[sid].get(f)!=up[sid].get(f)}
    print('  v14->upgrade diff keys', {k:(str(x)[:80],str(y)[:80]) for k,(x,y) in d.items()})
print('restart==upgrade', st['rs']==st['up'])
print('schema', st['before']['schema_version'], st['v14']['schema_version'], st['up']['schema_version'])
s=json.load(open('native/summary.json'))
print('markers', json.dumps(s['markers'])[:600])
print('regions', s['regions'])
