import json,uuid
H='advancedrocketrycommunity'; S=H+'_stations.dat'
def u(v): return str(uuid.UUID(bytes=b''.join((p & 0xffffffff).to_bytes(4,'big') for p in v)))
def load(p): return json.load(open(p))
paths={'before':'native/before/decoded.json'}
import glob,os
for ph in ['v14-team','upgrade','restart']:
    c=glob.glob(f'native/{ph}/**/decoded.json',recursive=True)
    paths[ph]=c
print(paths)
