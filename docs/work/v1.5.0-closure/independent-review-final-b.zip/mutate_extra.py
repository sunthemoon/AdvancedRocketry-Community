import sys, pathlib
root = pathlib.Path(sys.argv[1]); mid = sys.argv[2]; mode = sys.argv[3]
P = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
M = {
 'S1': (P+'station/command/StationCommands.java',
        'return source.source == player && source.withSuppressedOutput() != source;',
        'return source.source == player;'),
 'S2': (P+'station/service/StationGravityService.java',
        'if (!cooldown.ready(observed.stationId(), server.getTickCount())) {', 'if (false) {'),
 'O1': (P+'celestial/service/CelestialGravityController.java',
        'double multiplier = local.isPresent() ? local.getAsDouble()', 'double multiplier = false ? local.getAsDouble()'),
}
f, old, new = M[mid]
path = root / f
backup = pathlib.Path(str(path) + '.orig')
if mode == 'apply':
    text = path.read_bytes().decode('utf-8')
    n = text.count(old)
    if n != 1: raise SystemExit(f'{mid}: expected 1 occurrence, found {n}')
    backup.write_bytes(text.encode('utf-8'))
    path.write_bytes(text.replace(old, new).encode('utf-8'))
    print(f'{mid} applied to {f}')
else:
    path.write_bytes(backup.read_bytes()); backup.unlink()
    print(f'{mid} restored')
