import json, uuid, sys, re
from pathlib import Path
ROOT = Path(sys.argv[1])
N = ROOT / 'attempt-10' / 'native'
def u(v): return str(uuid.UUID(bytes=b''.join((p & 0xffffffff).to_bytes(4,'big') for p in v)))
summary = json.loads((N/'summary.json').read_text(encoding='utf-8'))
print('summary result', summary['result'], 'stations', summary['stations'])
print('r1', summary['r1']); print('r2', summary['r2'])
A, C = summary['stations']['A'], summary['stations']['C']
for phase in ['legacy','upgrade','concurrent','interrupted','final']:
    rec = json.loads((N/phase/'receipt.json').read_text(encoding='utf-8'))
    d = json.loads((N/phase/'state'/'decoded.json').read_text(encoding='utf-8'))
    st = d.get('advancedrocketrycommunity_stations.dat', {})
    tr = d.get('advancedrocketrycommunity_rocket_transfers.dat', {})
    bal = {u(e['station_id']): e['energy'] for e in st.get('warp_energy', [])}
    orbits = {u(s['station_id']): s.get('orbit_body') for s in st.get('stations', [])}
    recs = [(u(r['transfer_id']), r['phase'], u(r['logical_rocket_id'])) for r in tr.get('transfers', [])]
    print(f"== {phase}: result={rec['result']} exit={rec['exit_code']} finish={rec['finish']} schema={st.get('schema_version')}")
    print('   orbits A/C', orbits.get(A), orbits.get(C), 'balances', {k[:8]: v for k, v in bal.items()})
    print('   journal', recs)
    obs = rec.get('observations', {})
    for key in sorted(obs):
        v = obs[key]
        if isinstance(v, dict) and 'logical' in v:
            print('   obs', key, {k: v[k] for k in ('entity','logical','snapshot','dimension','state','fuel','origin') if k in v})
    for l in rec.get('warp_lines', []):
        if 'action=commit' in l or 'action=abort' in l:
            print('   warp', l[-200:])
    for l in rec.get('recovery_lines', []):
        print('   recovery', l[-220:])
