package io.github.sunthemoon.advancedrocketrycommunity.rocket.server;

import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightData;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightLimits;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightPlan;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightPlanner;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFuelState;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketPassengerManifest;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketTransferRecord;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.persistence.RocketTransferSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketBlock;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketBlockState;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketPosition;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketStructureSnapshot;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.stats.RocketStats;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/**
 * REVIEW PROBE (final review A), not part of the project: how many chunks one call of
 * {@code RocketTransferRecoveryService.recoverNext} loads synchronously when the journal holds several
 * unclassified records whose ends lie in unloaded chunks (a private journal; the server's is untouched).
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ReviewProbeRecoveryChunkLoadsGameTests {
    private static final int RECORDS = 8;

    private ReviewProbeRecoveryChunkLoadsGameTests() {
    }

    @GameTest(template = "empty", batch = "review_probe_recovery", timeoutTicks = 100)
    public static void oneRecoverNextCallLoadsEveryUnclassifiedRecordsEnds(GameTestHelper helper) {
        MinecraftServer server = helper.getLevel().getServer();
        ServerLevel overworld = server.overworld();
        ServerLevel moon = RocketTransferEntities.level(server, RocketFlightPlanner.MOON.dimensionId());
        RocketTransferSavedData journal = new RocketTransferSavedData();
        List<RocketPosition> ends = new ArrayList<>();
        for (int index = 0; index < RECORDS; index++) {
            RocketPosition source = new RocketPosition(40_000 + 256 * index, 80, 40_000);
            RocketPosition destination = new RocketPosition(40_000 + 256 * index, 80, 48_000);
            journal.put(record(source, destination));
            ends.add(source);
        }
        int loadedBefore = 0;
        for (RocketPosition end : ends) {
            loadedBefore += overworld.hasChunk(end.x() >> 4, end.z() >> 4) ? 1 : 0;
        }
        int moonBefore = 0;
        for (int index = 0; index < RECORDS && moon != null; index++) {
            moonBefore += moon.hasChunk((40_000 + 256 * index) >> 4, 48_000 >> 4) ? 1 : 0;
        }
        int holdersBefore = overworld.getChunkSource().getLoadedChunksCount();
        RocketTransferRecoveryService recovery = new RocketTransferRecoveryService(new HashSet<>(), new HashSet<>());
        long start = System.nanoTime();
        RocketTransferRecoveryService.Result result = recovery.recoverNext(server, journal);
        long nanos = System.nanoTime() - start;
        int loadedAfter = 0;
        for (RocketPosition end : ends) {
            loadedAfter += overworld.hasChunk(end.x() >> 4, end.z() >> 4) ? 1 : 0;
        }
        int holdersAfter = overworld.getChunkSource().getLoadedChunksCount();
        int moonAfter = 0;
        for (int index = 0; index < RECORDS && moon != null; index++) {
            moonAfter += moon.hasChunk((40_000 + 256 * index) >> 4, 48_000 >> 4) ? 1 : 0;
        }
        AdvancedRocketryCommunity.LOGGER.info("REVIEW_PROBE_RECOVERY_MOON moon_level_present={} destination_ends_loaded_before={}"
                + " destination_ends_loaded_after_one_call={}", moon != null, moonBefore, moonAfter);
        AdvancedRocketryCommunity.LOGGER.info(
                "REVIEW_PROBE_RECOVERY records={} source_ends={} source_ends_loaded_before={} source_ends_loaded_after_one_call={}"
                        + " holders_before={} holders_after={} call_ms={} result={}",
                RECORDS, ends.size(), loadedBefore, loadedAfter, holdersBefore, holdersAfter,
                String.format(java.util.Locale.ROOT, "%.1f", nanos / 1e6), result.status());
        helper.succeed();
    }

    private static RocketTransferRecord record(RocketPosition sourceOrigin, RocketPosition destinationOrigin) {
        UUID transfer = UUID.randomUUID();
        UUID logical = UUID.randomUUID();
        RocketBlockState iron = new RocketBlockState(ResourceLocation.tryParse("minecraft:iron_block"), Map.of());
        List<RocketBlock> blocks = List.of(new RocketBlock(new RocketPosition(0, 0, 0), iron),
                new RocketBlock(new RocketPosition(1, 1, 0), iron));
        RocketStats stats = new RocketStats(blocks.size(), 200L, 1_000L, 1_000L, 1, 1, 1, 0);
        ResourceLocation overworld = RocketFlightPlanner.EARTH.dimensionId();
        RocketStructureSnapshot source = RocketStructureSnapshot.create(UUID.randomUUID(), overworld, sourceOrigin,
                blocks, List.of(new RocketPosition(1, 1, 0)), stats, 0L);
        RocketStructureSnapshot destination = source.relocated(UUID.randomUUID(), RocketFlightPlanner.MOON.dimensionId(),
                destinationOrigin, 160L);
        RocketFuelState fuel = RocketFuelState.empty(1_000L).fill(1_000L).state();
        RocketFlightPlan plan = RocketFlightPlanner.plan(stats, fuel, RocketFlightPlanner.EARTH,
                RocketFlightPlanner.MOON, transfer, 0L).plan();
        long arrival = RocketFlightLimits.COUNTDOWN_TICKS + RocketFlightLimits.ASCENT_TICKS
                + RocketFlightLimits.TRANSIT_TICKS;
        RocketFlightData sourceFlight = RocketFlightData.initial(logical, stats.fuelCapacity(), stats.seatCount(),
                        RocketFlightPlanner.EARTH.bodyId(), overworld, sourceOrigin, 0L)
                .withFuel(fuel, 0L)
                .withPassengers(RocketPassengerManifest.empty(1))
                .withPlan(plan)
                .startCountdown(0L)
                .completeCountdown(RocketFlightLimits.COUNTDOWN_TICKS)
                .beginTransit(transfer, RocketFlightLimits.COUNTDOWN_TICKS + RocketFlightLimits.ASCENT_TICKS);
        RocketFlightData destinationFlight = sourceFlight.arriveAtDestination(
                sourceFlight.fuel().debit(transfer, plan.requiredFuel()).state(), RocketFlightPlanner.MOON.bodyId(),
                RocketFlightPlanner.MOON.dimensionId(), destinationOrigin, arrival);
        return RocketTransferRecord.create(transfer, logical, UUID.randomUUID(), UUID.randomUUID(), source,
                destination, sourceFlight, destinationFlight, plan.requiredFuel(), 0L);
    }
}
