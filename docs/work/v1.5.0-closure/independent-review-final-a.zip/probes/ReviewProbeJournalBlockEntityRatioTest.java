package io.github.sunthemoon.advancedrocketrycommunity.rocket.server;

import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.CheckedSavedDataFile;
import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.ManagedSavedDataType;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightData;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightLimits;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightPlan;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFlightPlanner;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketFuelState;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketPassengerManifest;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.RocketTransferRecord;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.flight.persistence.RocketTransferSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.forge.VanillaContainerRocketAdapter;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketBlock;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketBlockEntityPayload;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketBlockState;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketPosition;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.model.RocketStructureSnapshot;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.stats.RocketStats;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.resources.ResourceLocation;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * REVIEW PROBE (final review A), not part of the project: heap-accounting ratio of transfer-journal
 * records whose rockets carry chest block-entity payloads, and how many such records the journal can
 * save through the checked writer at heap factor 8.
 */
final class ReviewProbeJournalBlockEntityRatioTest {
    private static final RocketPosition EARTH_ORIGIN = new RocketPosition(12, 72, 12);
    private static final long ARRIVAL = RocketFlightLimits.COUNTDOWN_TICKS + RocketFlightLimits.ASCENT_TICKS
            + RocketFlightLimits.TRANSIT_TICKS;
    @TempDir Path root;

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    /** A normal survival chest: 27 stacks without item tags. */
    private static CompoundTag chest() {
        ListTag items = new ListTag();
        for (int slot = 0; slot < 27; slot++) {
            CompoundTag item = new CompoundTag();
            item.putByte("Slot", (byte) slot);
            item.putString("id", "minecraft:iron_ingot");
            item.putByte("Count", (byte) 64);
            items.add(item);
        }
        CompoundTag data = new CompoundTag();
        data.put("Items", items);
        return data;
    }

    /** A creative-made chest: one stack whose item tag is a list of empty compounds. */
    private static CompoundTag adversarialChest(int emptyCompounds) {
        ListTag filler = new ListTag();
        for (int index = 0; index < emptyCompounds; index++) {
            filler.add(new CompoundTag());
        }
        CompoundTag tag = new CompoundTag();
        tag.put("L", filler);
        CompoundTag item = new CompoundTag();
        item.putByte("Slot", (byte) 0);
        item.putString("id", "minecraft:stone");
        item.putByte("Count", (byte) 1);
        item.put("tag", tag);
        ListTag items = new ListTag();
        items.add(item);
        CompoundTag data = new CompoundTag();
        data.put("Items", items);
        return data;
    }

    @Test
    void probe() throws Exception {
        report("plain-2048-blocks", 0, () -> null);
        report("128-survival-chests", 128, ReviewProbeJournalBlockEntityRatioTest::chest);
        report("4-creative-chests-250k", 4, () -> adversarialChest(250_000));
    }

    private void report(String label, int payloads, Supplier<CompoundTag> payload) throws Exception {
        RocketTransferRecord record;
        try {
            record = record(new RocketPosition(100, 80, 8), payloads, payload);
        } catch (RuntimeException refused) {
            System.out.printf("REVIEW_PROBE_RATIO label=%s record_refused=%s%n", label, refused);
            return;
        }
        RocketTransferSavedData one = new RocketTransferSavedData();
        try {
            one.put(record);
        } catch (RuntimeException refused) {
            System.out.printf("REVIEW_PROBE_RATIO label=%s put_refused=%s%n", label, refused);
            return;
        }
        double ratio = measure(one)[2];
        long[] raw = {(long) measure(one)[0]};
        System.out.printf("REVIEW_PROBE_RATIO label=%s payloads=%d record_raw=%d ratio=%.2f%n", label, payloads,
                raw[0], ratio);
        ManagedSavedDataType type = ManagedSavedDataType.ROCKET_TRANSFERS;
        long quota = type.maxCompressedBytes() * type.heapAccountingFactor();
        // Grow a journal with records of this kind until the checked writer refuses it.
        double[] single = measure(one);
        System.out.printf("REVIEW_PROBE_RATIO label=%s record_heap=%d quota=%d records_to_exceed_quota=%d max_records=%d%n",
                label, (long) single[1], quota, (long) Math.ceil(quota / single[1]), RocketFlightLimits.MAX_ACTIVE_TRANSFERS);
        if (payloads > 0 && payloads < 5) {
            Path file = Files.createTempDirectory(root, "single").resolve(type.fileName());
            CompoundTag data = one.save(new CompoundTag());
            CheckedSavedDataFile.replace(file, type, () -> data);
            System.out.printf("REVIEW_PROBE_JOURNAL label=%s one_record_saved=true%n", label);
            return;
        }
        RocketTransferSavedData journal = new RocketTransferSavedData();
        int saved = 0;
        String failure = "none";
        for (int count = 1; count <= RocketFlightLimits.MAX_ACTIVE_TRANSFERS; count++) {
            journal.put(record(new RocketPosition(100 + 40 * count, 80, 8), payloads, payload));
            if (count % 4 != 0 && count != RocketFlightLimits.MAX_ACTIVE_TRANSFERS && payloads < 5) {
                continue;
            }
            Path file = Files.createTempDirectory(root, "j" + count).resolve(type.fileName());
            try {
                CompoundTag data = journal.save(new CompoundTag());
                CheckedSavedDataFile.replace(file, type, () -> data);
                saved = count;
            } catch (RuntimeException refused) {
                double[] m = measure(journal);
                failure = "count=" + count + " raw=" + (long) m[0] + " heap=" + (long) m[1] + " quota=" + quota
                        + " error=" + refused.getClass().getSimpleName() + ": " + refused.getMessage();
                break;
            }
        }
        System.out.printf("REVIEW_PROBE_JOURNAL label=%s largest_saved=%d first_refusal=%s%n", label, saved, failure);
    }

    private static double[] measure(RocketTransferSavedData journal) throws Exception {
        CompoundTag outer = new CompoundTag();
        outer.put("data", journal.save(new CompoundTag()));
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        NbtIo.write(outer, new DataOutputStream(buffer));
        byte[] bytes = buffer.toByteArray();
        NbtAccounter heap = new NbtAccounter(Long.MAX_VALUE);
        NbtIo.read(new DataInputStream(new ByteArrayInputStream(bytes)), heap);
        return new double[]{bytes.length, heap.getUsage(), heap.getUsage() / (double) bytes.length};
    }

    private static RocketTransferRecord record(RocketPosition destinationOrigin, int payloads,
                                               Supplier<CompoundTag> payload) {
        UUID transfer = UUID.randomUUID();
        UUID logical = UUID.randomUUID();
        RocketBlockState iron = new RocketBlockState(ResourceLocation.tryParse("minecraft:iron_block"), Map.of());
        RocketBlockState chest = new RocketBlockState(ResourceLocation.tryParse("minecraft:chest"),
                Map.of("facing", "north", "type", "single", "waterlogged", "false"));
        List<RocketBlock> blocks = new ArrayList<>();
        int count = payloads > 4 ? 2_048 : Math.max(payloads, 1) + 1;
        for (int index = 0; index < count; index++) {
            RocketPosition position = new RocketPosition(index % 16, index / 256, (index / 16) % 16);
            if (index < payloads) {
                blocks.add(new RocketBlock(position, chest,
                        new RocketBlockEntityPayload(VanillaContainerRocketAdapter.ID, payload.get())));
            } else {
                blocks.add(new RocketBlock(position, iron));
            }
        }
        if (payloads == 0) {
            blocks.clear();
            for (int index = 0; index < 2_048; index++) {
                blocks.add(new RocketBlock(new RocketPosition(index % 16, index / 256, (index / 16) % 16), iron));
            }
        }
        RocketStats stats = new RocketStats(blocks.size(), 200L, 1_000L, 1_000L, 1, 1, 1, payloads);
        RocketStructureSnapshot source = RocketStructureSnapshot.create(UUID.randomUUID(),
                RocketFlightPlanner.EARTH.dimensionId(), EARTH_ORIGIN, blocks,
                List.of(blocks.get(blocks.size() - 1).position()), stats, 0L);
        RocketStructureSnapshot destination = source.relocated(UUID.randomUUID(),
                RocketFlightPlanner.MOON.dimensionId(), destinationOrigin, 160L);
        RocketFuelState fuel = RocketFuelState.empty(1_000L).fill(1_000L).state();
        RocketFlightPlan plan = RocketFlightPlanner.plan(stats, fuel, RocketFlightPlanner.EARTH,
                RocketFlightPlanner.MOON, transfer, 0L).plan();
        RocketFlightData sourceFlight = RocketFlightData.initial(logical, stats.fuelCapacity(), stats.seatCount(),
                        RocketFlightPlanner.EARTH.bodyId(), RocketFlightPlanner.EARTH.dimensionId(), EARTH_ORIGIN, 0L)
                .withFuel(fuel, 0L)
                .withPassengers(RocketPassengerManifest.empty(1))
                .withPlan(plan)
                .startCountdown(0L)
                .completeCountdown(RocketFlightLimits.COUNTDOWN_TICKS)
                .beginTransit(transfer, RocketFlightLimits.COUNTDOWN_TICKS + RocketFlightLimits.ASCENT_TICKS);
        RocketFlightData destinationFlight = sourceFlight.arriveAtDestination(
                sourceFlight.fuel().debit(transfer, plan.requiredFuel()).state(), RocketFlightPlanner.MOON.bodyId(),
                RocketFlightPlanner.MOON.dimensionId(), destinationOrigin, ARRIVAL);
        return RocketTransferRecord.create(transfer, logical, UUID.randomUUID(), UUID.randomUUID(), source,
                destination, sourceFlight, destinationFlight, plan.requiredFuel(), 0L);
    }
}
