"""Single-change mutation runner for final review A (exports only, never the repository).

Usage: python mutate_a.py <lane-dir> <out-dir> <id> [<id> ...]
Each mutation is applied alone to the lane export, the named Gradle tasks run, the file is restored and
byte-compared, and one TSV row is appended to <out-dir>/mutations.tsv.
"""
import glob
import os
import re
import shutil
import subprocess
import sys
import time

P = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"
MTYPE = P + "persistence/migration/ManagedSavedDataType.java"
CONFIG = P + "config/CommonConfig.java"
WARP = P + "station/warp/StationWarpService.java"
ELEV = P + "station/elevator/ElevatorEndpointService.java"
FLIGHT = P + "rocket/server/RocketFlightService.java"
RECOV = P + "rocket/server/RocketTransferRecoveryService.java"
MANAGER = P + "station/service/StationManager.java"
CMDS = P + "station/command/StationCommands.java"

JUNIT = ["test"]
BOTH = ["test", "runGameTestServer"]
GT = ["runGameTestServer"]

MUTATIONS = {
    "MA-01": ("Heap factor 1 for CELESTIAL and ROCKET_TRANSACTIONS (R1 capacity pins)", JUNIT,
              [(MTYPE, "        return 8L;",
                "        return this == CELESTIAL || this == ROCKET_TRANSACTIONS ? 1L : 8L;")]),
    "MA-02": ("CommonConfig.warpSettings ignores stations.warpEnabled (kill-switch config binding)", BOTH,
              [(CONFIG, "return new WarpSettings(WARP_ENABLED.get(), WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());",
                "return new WarpSettings(true, WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());")]),
    "MA-02C": ("(control at cd3233e) CommonConfig.warpSettings ignores stations.warpEnabled", GT,
               [(CONFIG, "return new WarpSettings(WARP_ENABLED.get(), WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());",
                 "return new WarpSettings(true, WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());")]),
    "MA-03": ("admin warp diagnostics folds credits (read-only claim)", BOTH,
              [(WARP, "        Objects.requireNonNull(server, \"server\");\n        WarpSettings current = settings.get();",
                "        Objects.requireNonNull(server, \"server\");\n        fold(server);\n        WarpSettings current = settings.get();")]),
    "MA-04": ("Elevator check writes no ARCE_STATION_ELEVATOR_CHECK audit line", BOTH,
              [(ELEV, "        AdvancedRocketryCommunity.LOGGER.info(\n                \"ARCE_STATION_ELEVATOR_CHECK",
                "        if (false) AdvancedRocketryCommunity.LOGGER.info(\n                \"ARCE_STATION_ELEVATOR_CHECK")]),
    "MA-05": ("Flight C2S path skips both station VISIT checks", BOTH,
              [(FLIGHT, "            if (!stationAccess.allowed(\n                    sourceStation, actorId, operator, StationAccessAction.VISIT\n            )) {",
                "            if (false) {"),
               (FLIGHT, "            if (!stationAccess.allowed(target, actorId, operator, StationAccessAction.VISIT)) {",
                "            if (false) {")]),
    "MA-06": ("recoverNext reverts to 'first unclassified record only' (R7 wiring)", BOTH,
              [(RECOV, "        RocketTransferRecord record = nextRecoverable(entries, liveTransfers, settledTransfers,\n"
                       "                candidate -> RocketTransferEntities.recoveryEntityChunksLoaded(server, candidate)).orElse(null);",
                "        RocketTransferRecord first = firstUnclassified(entries, liveTransfers, settledTransfers).orElse(null);\n"
                "        RocketTransferRecord record = first != null\n"
                "                && RocketTransferEntities.recoveryEntityChunksLoaded(server, first) ? first : null;")]),
    "MA-07": ("Elevator check synchronously loads the anchor column's chunk", BOTH,
              [(ELEV, "return target != null && target.getWorldBorder().isWithinBounds(new BlockPos(x, 0, z));",
                "return target != null && target.getChunk(x >> 4, z >> 4) != null\n"
                "                            && target.getWorldBorder().isWithinBounds(new BlockPos(x, 0, z));")]),
    "MA-08": ("BUILD protection adds a deferred (ticket) chunk load in the Overworld", BOTH,
              [(MANAGER, "                && event.getPlayer() instanceof ServerPlayer player) {\n            protect(event, level, event.getPos(), player);",
                "                && event.getPlayer() instanceof ServerPlayer player) {\n"
                "            level.getServer().overworld().getChunkSource().addRegionTicket(\n"
                "                    net.minecraft.server.level.TicketType.PORTAL, new net.minecraft.world.level.ChunkPos(160, 160), 0,\n"
                "                    new net.minecraft.core.BlockPos(2560, 64, 2560));\n"
                "            protect(event, level, event.getPos(), player);")]),
    "MA-09": ("warp status folds credits again (R6)", BOTH,
              [(WARP, "            return StationWarpResult.of(StationManagementCode.UNAUTHORIZED, null);\n        }\n        UUID stationId = station.orElseThrow().stationId();",
                "            return StationWarpResult.of(StationManagementCode.UNAUTHORIZED, null);\n        }\n        fold(server);\n        UUID stationId = station.orElseThrow().stationId();")]),
    "MA-10": ("remove <id> uuid <member>: operator flag always true", BOTH,
              [(CMDS, "                context.getSource().hasPermission(2),\n                stationId,\n                member\n        ), \"Member \"",
                "                true,\n                stationId,\n                member\n        ), \"Member \"")]),
    "MA-11": ("remove <id> uuid <member>: removes the actor's UUID instead of the member", BOTH,
              [(CMDS, "                stationId,\n                member\n        ), \"Member \"",
                "                stationId,\n                actor.getUUID()\n        ), \"Member \"")]),
    "MA-12": ("A fourth rocket_flight message registered with a non-literal index (protocol pin)",
              ["test", "--tests", "*NetworkProtocolPinTest"],
              [(P + "rocket/network/RocketFlightNetwork.java", "        channel = created;\n",
                "        int nextIndex = 3;\n"
                "        created.messageBuilder(RocketFlightIntentPacket.class, nextIndex, NetworkDirection.PLAY_TO_SERVER)\n"
                "                .encoder(RocketFlightIntentPacket::encode)\n"
                "                .decoder(RocketFlightIntentPacket::decode)\n"
                "                .consumerMainThread(RocketFlightIntentPacket::handle)\n"
                "                .add();\n"
                "        channel = created;\n")]),
}


def gradle(lane, tasks, log):
    env = dict(os.environ)
    env["JAVA_HOME"] = "C:/Program Files/Java/jdk-17.0.7"
    gametest = os.path.join(lane, "build", "gametest")
    if "runGameTestServer" in tasks and os.path.isdir(gametest):
        shutil.rmtree(gametest, ignore_errors=True)
    results = os.path.join(lane, "build", "test-results", "test")
    if "test" in tasks and os.path.isdir(results):
        shutil.rmtree(results, ignore_errors=True)
    lane = os.path.normpath(lane)
    cmd = ["cmd", "/c", os.path.join(lane, "gradlew.bat"), "--offline", "--no-daemon", "--continue"] + (["cleanTest"] if "test" in tasks else []) + tasks
    start = time.time()
    with open(log, "w", encoding="utf-8", errors="replace") as out:
        proc = subprocess.run(cmd, cwd=lane, stdout=out, stderr=subprocess.STDOUT, env=env)
    return proc.returncode, time.time() - start


def junit_failures(lane):
    failed = []
    total = 0
    for path in glob.glob(os.path.join("\\\\?\\" + os.path.abspath(lane), "build", "test-results", "test", "*.xml")):
        text = open(path, encoding="utf-8", errors="replace").read()
        m = re.search(r'tests="(\d+)"', text)
        total += int(m.group(1)) if m else 0
        for case in re.finditer(r'<testcase name="([^"]+)" classname="([^"]+)"[^>]*>\s*<failure', text):
            failed.append(case.group(2).rsplit(".", 1)[-1] + "." + case.group(1))
    return total, failed


def gametest_summary(log):
    text = open(log, encoding="utf-8", errors="replace").read()
    summary = [l.split("]: ")[-1] for l in text.splitlines() if "GameTestServer]:" in l and "required tests" in l]
    failed = sorted({m.group(1) for m in re.finditer(r"LogTestReporter\]: (\S+) failed!", text)})
    matrix = [l.split("]: ")[-1] for l in text.splitlines() if "ARCE_STATION_PERMISSION_MATRIX_SUMMARY" in l]
    compile_failed = "compileJava FAILED" in text or "Compilation failed" in text
    return (summary[-1] if summary else "none"), failed, (matrix[-1] if matrix else "none"), compile_failed


def main():
    lane, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    tsv = os.path.join(out, "mutations.tsv")
    if not os.path.exists(tsv):
        with open(tsv, "w", encoding="utf-8") as f:
            f.write("id\tdescription\tlane\ttasks\texit\tseconds\tjunit_total\tjunit_failed\tgametest_summary\t"
                    "gametest_failed\tmatrix_summary\tcompile_failed\tresult\trestored\n")
    for mid in sys.argv[3:]:
        desc, tasks, edits = MUTATIONS[mid]
        originals = {}
        for path, old, new in edits:
            full = os.path.join(lane, path)
            data = originals.get(full) or open(full, "rb").read()
            originals.setdefault(full, data)
            text = open(full, encoding="utf-8").read()
            count = text.count(old)
            if count != 1:
                raise SystemExit(f"{mid}: anchor occurs {count} times in {path}")
            with open(full, "w", encoding="utf-8", newline="") as f:
                f.write(text.replace(old, new))
        log = os.path.join(out, f"{mid}.log")
        code, seconds = gradle(lane, tasks, log)
        total, jfailed = junit_failures(lane) if "test" in tasks else (0, [])
        gsum, gfailed, msum, cfail = gametest_summary(log)
        # Copy the GameTest server log for the record.
        gtlog = os.path.join(lane, "build", "gametest", "logs", "latest.log")
        if os.path.exists(gtlog):
            shutil.copyfile(gtlog, os.path.join(out, f"{mid}-gametest-latest.log"))
        for full, data in originals.items():
            with open(full, "wb") as f:
                f.write(data)
        restored = all(open(full, "rb").read() == data for full, data in originals.items())
        killed = code != 0 and (jfailed or gfailed) and not cfail
        result = "COMPILE_FAILED" if cfail else ("KILLED" if killed else ("SURVIVED" if code == 0 else "ERROR"))
        row = [mid, desc, os.path.basename(lane), "+".join(tasks), str(code), f"{seconds:.0f}", str(total),
               ",".join(jfailed), gsum, ",".join(gfailed), msum, str(cfail), result, str(restored)]
        with open(tsv, "a", encoding="utf-8") as f:
            f.write("\t".join(row) + "\n")
        print("\t".join(row), flush=True)


if __name__ == "__main__":
    main()
