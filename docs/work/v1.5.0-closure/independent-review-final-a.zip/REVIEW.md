# v1.5 final review A: authority and persistence

Reviewer: independent implementation reviewer (not the author). Date: 2026-09-30.
Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`, HEAD `d45534e`.

| Commit | Subject | Scope reviewed |
|---|---|---|
| `cd3233e` | close the WARP-03/04 review and accept ADR-045/046 | R1-R16 closure (heap factor, capacity tests, `StationStorageBudget`, status, `current_body`, mutation claims) |
| `b3d4cf3` | elevator endpoint check and the A1 permission matrix | ADR-045 validator/adapter/command, confirmation order, `remove ... uuid`, `NetworkProtocolPinTest`, permission matrix, `StationTeamCapsTest`, evidence |
| `50a0f42` | native rocket identity, concurrent warp and S1 | `nextRecoverable`, rewritten warp GameTests, fixture allow-list, native evidence, recovery matrix |
| `a96569b` | warp diagnostics and native warp restart evidence (WARP-05) | diagnostics bounds/read-only claim, native evidence |

**This review is not a Gate approval.** It does not verify, accept or reject any leaf, ADR, version or
release, and it changes no status. It is evidence for the maintainer.

## Method

- **Read-only on the repository.** Only `git log`, `git show`, `git diff`, `git status` and `git archive`
  (to directories inside this review directory) were used. Nothing under the repository was written. The
  private bundle directory was never listed or read.
- **Note on the working tree.** While this review ran, 30 tracked files in the repository working tree were
  modified by someone else (mtimes 19:04-19:14; for example `CHANGELOG.md`, `AdvancedRocketryCommunity.java`,
  ADR-041/044/047). They were not read. Every statement below refers to the committed trees.
- **Exports** (all in this directory): `tree-d45534e` (full run), `tree-mutA` and `tree-mutB` (mutation lanes,
  `d45534e`), `tree-cd3233e` (control mutation), `tree-probe` (`d45534e` plus two review probes, `probes/`).
- **Evidence integrity:** `verify_evidence_a.py` (adapted from the previous reviewer's checker) re-hashed all
  four packets through `git show`: `SHA256SUMS.txt`, archive bytes/SHA-256/member counts, every ZIP member
  against its `*-files.json`, `source-identity.json` against the blobs and the commit's changed-file list,
  and every `links.json` target. Result: **TOTAL PROBLEMS 0** (`evidence-integrity.log`).
- **Evidence content:** the four `root-checks.zip` archives and the previous review archive were extracted to
  `ev/` and read: the closure mutation logs, the elevator-ui G1-G4/V1-V3 mutation logs, the mig-native
  attempt-10 harness, receipts and decoded per-phase state (`analysis/mig_native_check.py`), the
  failed runs, and the warp-native packet.
- **Mutations:** 13 single-change mutations (`mutate_a.py`, results in `mutations-final-a.tsv` and
  `mutations/`). Each was applied alone, the named Gradle tasks ran, the file was restored and byte-compared
  (every recorded row `restored=True`; the blocked lane-A MA-06 attempt is the exception, see residual risks).
  GameTest runs use a deleted `build/gametest` (fresh world).
- **Probes:** a JUnit probe of the transfer journal's heap-accounting ratio with block-entity payloads, and
  a GameTest probe of how many chunks one `recoverNext` call loads (`probes/`, run only in `tree-probe`).

## Verdicts

| Commit | Verdict | Why |
|---|---|---|
| `cd3233e` | **ACCEPT WITH CHANGES** | Every claimed R1-R16 fix is real and, where claimed, tested (details below). Remaining: two managed types still have no capacity pin and the journal ratio claim excludes block-entity payloads (A6); `StationWarpGameTests` crossed 800 lines without an ADR (A8). |
| `b3d4cf3` | **ACCEPT WITH CHANGES** | ADR-045 validator is pure, ordered, authority-before-disclosure, chunk-free and dirty-free (MA-07 killed); the matrix table is faithful to ADR-046 and its observations are sound for authority. But the offline-removal *effect* is untested (A3, MA-11 survived), the per-cell chunk invariant is blind to ticket-deferred loads (A4, MA-08 survived), and two ADR-045 test-list items are unpinned (A5). |
| `50a0f42` | **ACCEPT WITH CHANGES** | Native claims follow from the retained state. But `nextRecoverable` turned a one-record-per-tick activation into "activate every unclassified record in one tick", with synchronous chunk loads (A1, Medium, probe-confirmed), and the GameTest rewrite dropped the only coverage of the kill-switch config binding while keeping the same shared-config race in another test (A2, Medium). |
| `a96569b` | **ACCEPT WITH CHANGES** (Low only) | Diagnostics are bounded, level-2 and read-only by inspection; native evidence is consistent. The read-only property is not pinned (A7, MA-03 survived). |

No Critical or High findings. 2 Medium, 6 Low, 5 Info.

## Findings

`…/` abbreviates `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`. Line numbers are at `d45534e`.

### A1 — Medium — `50a0f42`: transfer recovery now activates (ticket + synchronous load) every unclassified record's ends in one tick; the "reads loaded chunks only" claim is false

**Where.**
- `…/rocket/server/RocketTransferRecoveryService.java:69-89`: `recoverNext` streams all unclassified records
  through `recoveryEntityChunksLoaded` until one returns true. Javadoc line 84: "the loaded check reads loaded
  chunks only".
- `…/rocket/server/RocketTransferEntities.java:99-111, 303-336`: `recoveryEntityChunksLoaded` →
  `entityChunkLoaded` → `keepLoaded`, which calls `addRegionTicket(FLIGHT_TICKET, chunk, 2, transferId)` and
  `loadOrigin` → `level.getChunkAt(...)` (a **synchronous** load/generation) for both ends, before checking
  `areEntitiesLoaded`.
- Called every server tick (`RocketManager.tick` → `RocketFlightService.tick` → `RocketTransferService.tick:203`).

**Mechanism.** Entity sections load asynchronously, so right after a synchronous load `areEntitiesLoaded` is
false and the stream moves on to the next record and loads its ends too. Before `50a0f42` only the first
unclassified record was evaluated (≤ 2 synchronous loads per tick). Now one call loads both ends of every
unclassified record up to the first ready one: up to 64 records × 2 ends, plus a radius-2 ticket around each.
Every session starts with **all** journal records unclassified (live/settled sets are empty), and COMMITTED
records stay in the journal while rockets are landed (mig-native: "Landed reservations stay in the journal as
COMMITTED records"), so this burst happens at every server start with a non-trivial journal.

**Probe** (`probes/ReviewProbeRecoveryChunkLoadsGameTests.java`, private journal of 8 records, ends in
unloaded Overworld/Moon chunks, one `recoverNext` call on the server thread):

| Code | Source ends loaded | Destination ends loaded | Overworld holders | Call time | Log |
|---|---|---|---|---|---|
| `d45534e` (`nextRecoverable`) | 8 / 8 | 8 / 8 | 2,805 → 6,894 | **6,133 ms** | `probes/probe-run-02-gametest-latest.log` |
| pre-`50a0f42` selection (first record only) | 1 / 8 | 1 / 8 | 2,805 → 3,646 | 1,339 ms | `probes/probe-run-03-baseline-gametest-latest.log` |

(The probe positions are ungenerated, so absolute times include generation; the ratio is the point.)

**Impact.** A per-tick budget regression (AGENTS §3.3 "hard cap and per-tick budget"): the cap is now the
journal size, not one record. At 64 records a single tick can spend tens of seconds (vanilla's watchdog stops
the server at 60 s by default). Also the documented property of the R7 fix is wrong. Selection itself is
correct: a record is only recovered when **both** ends' entity sections are loaded (no partial recovery), and
journal constraints (one record per logical rocket, non-overlapping destinations) make out-of-order recovery
safe as far as I can see.

**Required change.**
- Split readiness from activation: select with a side-effect-free check (`hasChunk` + `areEntitiesLoaded`,
  no ticket, no `getChunkAt`), and activate (ticket + load) at most one record — or a small fixed budget — per
  tick, advancing a rotating cursor so an unloadable record still cannot starve the others.
- Add a test that one `recoverNext` call activates at most the budgeted number of records (the probe above can
  be turned into it), and a test that the wiring in `recoverNext` uses the new selection: MA-06 (`recoverNext`
  reverted to the pre-`50a0f42` "first unclassified record only" selection) **survived** all 1,051 JUnit and
  257 GameTests, because `RocketTransferRecoverySelectionTest` calls only the static helper.
- Correct the Javadoc and the RECOVERY-MATRIX row.

### A2 — Medium — `50a0f42`: the kill-switch config binding lost its only coverage; the shared-config race it cites remains in another test

**Where.**
- `…/gametest/StationWarpGameTests.java:268-279` (rejections test) and `:509-553` (`theKillSwitchAbortsARunningCountdown`)
  now use private `StationWarpService`s with their own `WarpSettings`; the rejections test adds
  `CommonConfig.warpSettings().equals(WarpSettings.DEFAULTS)` (line 278).
- `…/config/CommonConfig.java:66-71`: `warpSettings()` maps `stations.warpEnabled` into `WarpSettings`.
- `…/gametest/StationWarpGameTests.java:313, 331, 349, 359`: `cancelledChangedOrRepricedCountdownsNeverWarpOrCharge`
  still writes the shared config (`CommonConfig.WARP_COST_IN_SYSTEM.set(...)`).

**Evidence.**
- MA-02 (`warpSettings()` ignores `WARP_ENABLED`, i.e. the operator kill switch does nothing): **survived** at
  `d45534e` — 1,051 JUnit and all 257 GameTests passed (`mutations/laneA/MA-02*.log`).
- MA-02C (same mutation at `cd3233e`): **killed** by `requestswithoutauthoritycoretargetenergyorknownrocketstatearerejected`
  and `thekillswitchabortsarunningcountdown` (`mutations/control-cd3233e/`).
- The packet's VERIFICATION.md says both tests "keep their assertions". The service-level abort assertion is kept, but
  the end-to-end one (config value → production service → command reply `WARP_DISABLED`) is gone. The added
  equality only proves the config currently holds defaults, not that the service reads `warpEnabled`.
- Failed run 01 of the packet (`ev/mig-native/root/run-01/`) shows the watcher race also failed
  `cancelledchangedorrepricedcountdownsneverwarporcharge`; that test still toggles `warpCostInSystem`, so a stale
  re-applied cost can still leak into later tests (including the new `CommonConfig.warpSettings().equals(DEFAULTS)` check).

**Required change.** Restore an end-to-end kill-switch check that does not race the file watcher: e.g. a JUnit
test that loads `CommonConfig.SPEC` from an in-memory `CommentedConfig` with `warpEnabled=false` and asserts
`warpSettings().enabled()==false`, plus one GameTest (or unit test) that the production `StationWarpService` is
built with `CommonConfig::warpSettings` (inject the supplier and assert the wiring). Move the repricing test to
the same private-settings pattern, so no GameTest writes the shared config file.

### A3 — Low — `b3d4cf3`/`50a0f42`: the effect of `/arce station remove <id> uuid <member>` is never asserted (A1 matrix and S1)

**Where.**
- `…/gametest/StationPermissionMatrixGameTests.java:214-225`: an allowed TEAM/ANSWER cell passes when the
  registry did **not** change (only `changed && !mutates` is a problem); the resets are idempotent no-ops
  (`StationState.withMember/withoutMember/declineInvitation` return `this`), so "the reset did not restore"
  cannot fire either.
- S1 harness (`ev/mig-native/root/scripts/native_mig_c3_check.py`, cell `remove_uuid/owner`) checks the reply
  `said('removed immediately')`, and the reply text (`…/station/command/StationCommands.java:175`) echoes the
  argument, not the result.

**Evidence.** MA-11 (`removeByUuid` passes the actor's UUID instead of the member, a realistic copy bug):
**survived** all 1,051 JUnit and 257 GameTests, matrix 345/345 (`mutations/laneB/MA-11*`). MA-10 (operator flag
forced true) was killed by 7 matrix cells, so authority is covered; only the effect is not.

**Required change.** In the matrix, fail an allowed mutating cell whose registry did not change
(`mutates && !changed` → problem) and assert the specific change (for `REMOVE_UUID`, the offline member is gone).
In S1, check the decoded station record after `remove_uuid` (the harness already decodes state per phase).

### A4 — Low — `b3d4cf3`/`50a0f42`: the "no chunk loaded" invariant is only checked synchronously inside one tick

**Where.** `…/gametest/StationPermissionMatrixGameTests.java:195-240`: all 336 executed cells run inside one
tick, each comparing `getLoadedChunksCount()` before/after. A ticket-based load is only turned into chunk
holders on a later distance-manager update, so it is attributed to no cell (or to a later synchronous one).
The S1 probe (`loaded_chunks_before_command == loaded_chunks_after_command`) has the same property.

**Evidence.** MA-07 (a synchronous `getChunk` in the elevator check) was **killed** by
`endpointchecksreadonlyinruleorderandfollowwarpcatalogandborder` — the synchronous check works. MA-08 (the
BUILD protection handler adds a `PORTAL` region ticket in the Overworld) **survived**; every BUILD cell logged
`chunk_delta=none` (`mutations/laneB/MA-08*`).

**Required change.** After the last cell (and in S1 after each command), let the chunk source process pending
ticket updates (advance ≥ 1 tick, or wait for the counts to settle as the setup already does) and compare with
the settled pre-matrix baseline; keep operator create/delete in its own test so it does not pollute the
comparison. State the limitation in PERMISSION-MATRIX.md until then.

### A5 — Low — `b3d4cf3`: two ADR-045 test-list items are not pinned (audit line, leaf requirement)

**Where.**
- `…/station/elevator/ElevatorEndpointService.java:40-44` writes `ARCE_STATION_ELEVATOR_CHECK`; ADR-045 lists
  "output bounded to one line, with the audit line written". No test captures it (VERIFICATION.md only counts
  15 lines in a log). MA-04 (audit line removed): **survived**.
- `…/station/command/StationCommands.java:94-95` (`elevator` literal's own `requires`): the author's G1
  mutation survived and is disclosed. But `StationElevatorGameTests.java:113-114` still says "the leaf's own
  requirement is what refuses it", while both registered `admin` nodes require level 2
  (`StationCommands.java:73-74`, `StationWarpCommands.java:41-42`), so the test cannot tell.

**Required change.** Capture the audit line with the existing `AuditLogCapture` in the elevator GameTest.
Assert the leaf requirement directly: walk the dispatcher to `arce station admin elevator` and assert
`node.getRequirement().test(nonOperatorSource)` is false. Fix the comment.

### A6 — Low — `cd3233e`: R1 closure is complete for the types it names, but two types are unpinned and the journal ratio excludes block-entity payloads

**Verified.** `ManagedSavedDataType.heapAccountingFactor()` returns 8 for every type (`…/persistence/migration/ManagedSavedDataType.java:108-117`).
My full run reproduces the capacity lines: satellites 6,144 missions ratio 5.02; stations 4,096 ratio 5.67;
journal 64 × 2,048-block records ratio 6.89 < 8.

**Gaps.**
- MA-01 (factor 1 for `CELESTIAL` and `ROCKET_TRANSACTIONS`): **survived** all 1,051 JUnit tests. The previous
  review asked for a capacity test per managed type; two have none, so R1 could silently return for them.
- The journal test models no block-entity NBT (its Javadoc says so). Probe
  (`probes/ReviewProbeJournalBlockEntityRatioTest.java`, `probes/probe-junit-lines-02.txt`):
  - 128 survival chests (27 plain stacks each) per rocket: ratio **7.79** (64 records still save);
  - 4 creative-made chests whose item tag is a list of 250,000 empty compounds (legal: 2.0 MB raw per record,
    under the 2.25 MiB record bound): ratio **53.87**, 108 MB accounted per record, so **11** such records
    would exceed the journal's heap quota (1,175,453,696). Because the checked writer reads its staged file back
    through the bounded reader, journal flushes would then fail `OVERSIZED_DATA` (computed from the measured
    per-record charge, not run: the in-memory journal would need about 1 GB; the downstream effect on launches
    and in-flight transfers was not traced). One such record saves normally. `RocketTransferSavedData.put`
    bounds raw bytes only.
- The previous review's conditional advice ("if the journal factor is raised, tighten the array/list allowance
  or cap a single declaration absolutely") is neither applied nor recorded as declined.

**Required change.** Add capacity round trips for `CELESTIAL` and `ROCKET_TRANSACTIONS`. Admit journal records
(and, ideally, captured snapshots) by heap-accounted size as well as raw size (for example, quota /
`MAX_ACTIVE_TRANSFERS` per record), or record the creative-payload case as a known issue with an owner.

### A7 — Low — `a96569b`: the diagnostics' read-only property is not pinned

`…/station/warp/StationWarpService.java:120-151` does not fold (correct by inspection; its only port call,
`inMotion`, reads the journal). MA-03 (`fold(server)` added to `diagnostics`): **survived**. Command blocks run
at level 2, so a regression would recreate R6 (a registry dirtied every tick). **Required change:** in
`tenChargingStationsDirtyTheRegistryOnlyOncePerFoldWindow`, flush, run `admin warp`, and assert the registry is
not dirty and the pending credit is unchanged.

### A8 — Low — AGENTS §3.4: `StationWarpGameTests` is over 800 lines without an ADR

600 lines at `130a744`, **824** at `cd3233e`, **836** at `50a0f42`/`d45534e`. ADR-014 sets the precedent that
an over-800 GameTest class needs an ADR note. Also over 500 (responsibility check only): `RocketTransferService`
703 (grew +35 in `cd3233e`), `StationRegistrySavedData` 600, `StationPermissionMatrixGameTests` 503. **Required
change:** split the warp GameTests (fixture, authority, countdown, energy), or add the ADR note.

### A9 — Info — `NetworkProtocolPinTest` misses messages registered with a non-literal index

`src/test/java/…/network/NetworkProtocolPinTest.java:28-29` matches `messageBuilder(X.class, <digits>, …)` only.
MA-12 (a fourth `rocket_flight` message registered with index variable `nextIndex`): **survived** (the pin test
passed). Suggest also counting every `messageBuilder(` occurrence per file and failing on a mismatch.

### A10 — Info — permission matrix: faithful to ADR-046, with overstated totals and unstated choices

- The expected table (`…/gametest/StationPermissionMatrix.java:98-132`) matches every ADR-046 row. Choices the
  ADR does not state: console gets `NOT_PLAYER` on status/environment/team/answer rows; the stale owner object
  is allowed `status`, `environment` identity and team actions; the invitee sees the station in `list`;
  `FAKE_PLAYER_OWNER` is allowed to BUILD. Consider stating them in the table's next revision.
- "Asserts all 345 cells" / "345/345": 9 N/A cells are counted as passes without execution, and 2
  `ADMIN_CREATE_DELETE` cells (OPERATOR_OUTSIDE, EXECUTE_AS_OWNER) are parse-only. The run log itself is honest
  (`executed=336 not_applicable=9`).
- VISIT cells call `StationAccessService.allowed` directly, not the C2S flight path. The flight path is covered
  elsewhere: MA-05 (both `RocketFlightService` VISIT checks removed) was **killed** by three GameTests. Cite them.
- Observations are sound: silent/FakePlayer outcomes come from return values (status/environment return 0 on
  refusal, `list` returns the visible count) and from audit lines written after the mutation (`auditAccess(..., true)`
  follows `data.invite/removeMember`), cleared per cell.

### A11 — Info — RECOVERY-MATRIX cites a test for things it does not assert

`countdownSurvivesOwnerLogoutAndTheRocketRuleIsWired` (`StationWarpGameTests.java:369-414`) is cited for "Warp
refused (`WARP_ROCKETS_IN_MOTION`)" and "Passengers … not moved; player data untouched". It asserts only that
the installed port is not `FAIL_CLOSED`, that the countdown survives logout, and that the online member is
told. All other cited tests exist and say what is claimed.

### A12 — Info — R13 residual: no-op team mutations still grow the running bound and dirty the registry

`StationRegistrySavedData.java:158, 174, 183, 199` call `budget.grew(64)` and `setDirty()` even when the model
returned the same state (re-inviting an invitee/member/owner, adding an existing member). Only a re-measure
cost; a guard `if (result != before)` would avoid it.

### A13 — Info — R7 remains half open

Tracked by the author: no audited abandon path for a record whose Level is gone (warps stay refused). Also a
loaded record whose `recover()` keeps returning `RETRY_LATER` (only `addFreshEntity` failure) would still starve
the records behind it.

## Previous findings R1-R16: closure check (`cd3233e`)

| ID | Claimed | Checked | Status |
|---|---|---|---|
| R1 | 8× for every type; satellite and journal capacity tests | Code and tests present; ratios reproduced (5.02 / 6.89 / 5.67) | Closed for the named types; A6 |
| R2 | Tests kill M02, M03, M08-M12, M16, M22, M27; target-removal GameTest | Closure logs show set A failed exactly its 6 targets and set B `M16`; JUnit M22 killed; `serviceWiringUsesLiveAndSettledSetsAsSpecified` covers M08/M09; `aTargetRemovedDuringTheCountdownAborts` present | Closed (M10 coverage later changed by `50a0f42`, A2) |
| R3 | Tracked | Tracked in the log | Open (pre-existing) |
| R4 | Headroom belongs to balances; admission in `StationStorageBudget` | `admitsBalanceEntry` limit = 4 MiB, other growth = 4 MiB − 256 KiB; 4,096 × 64 B ≤ headroom asserted; storage-bound test now expects `(30, 0)` — a documented behaviour change, not a weakened assertion | Closed |
| R5 | `atStationOrbit` on station departures | `RocketFlightService.java:276-279`; asserted in `PlanetaryAdmissionGameTests` | Closed |
| R6 | `status` no longer folds | Code; MA-09 (fold restored) **killed** by the rejections test | Closed |
| R7 | Diagnostics now; recovery later | `journalDiagnostics` lists ≤ 4 records (unit-tested); recovery change in `50a0f42` (A1, A13) | Partly |
| R8 | Every growth path refused alone | `everyGrowthPathIsRefusedOnItsOwnAtTheBound` asserts the storage-bound message for each of 7 paths and an unchanged save; M06/M18/M20 killed | Closed |
| R9-R16 | Info | R10 CHANGELOG reworded; R11/R14 ADR-044 rev. 4; R13 `grew` after success (A12 residual); R15 `StationStorageBudget` extracted (registry 595 → 600 after `b3d4cf3`); R16 failed runs retained | Closed / recorded |

## Checked and found correct

- **ADR-045 validator** (`…/station/elevator/ElevatorEndpointValidator.java`): pure (no server, Level, chunk or
  SavedData access); rules 1-5 in order; `UNAUTHORIZED` returns no station view; rule 5 uses `long` arithmetic
  and the border predicate reads `WorldBorder` only. Adapter: no chunk access (MA-07 killed proves the GameTest
  would notice), no dirty SavedData (asserted), one line, returns 0 on failure. Parse bounds ±30,000,000 at the
  argument; the 30,000,001 case is asserted. Command reachable only at level 2.
- **Confirmation order** (`StationExpansionService.confirm`, `StationWarpService.confirm`): `localPlayer` then
  `locate` before `take`; `locate` again after `take`; no chunk loading (`hasChunkAt`). An actor who cannot act
  no longer consumes a confirmation. Author's G2/G3 kills confirmed in `ev/elevator-ui/root/mutations/`.
- **`remove … uuid`**: same `MANAGE_MEMBERS` authority as `remove <player>`; literal precedence is correct;
  console refused (`getPlayerOrException`), as ADR-046 specifies. MA-10 killed (7 cells).
- **`StationTeamCapsTest`**: 32/32 caps and self/owner/member/invitee no-ops at the model level.
- **Matrix setup**: the de-opped operator joins with server permissions on (not a vacuous `false`), the
  previous owner is asserted to remain a member, the operator outside stands in a verified gap.
- **Native mig evidence** (`analysis/mig_native_check.py` over attempt-10 decoded state and receipts):
  - R1: the same entity `acc3eefd…`, logical `6e8e71c8…`, snapshot `ff881e2f…`, fuel 670 and origin
    `1024,128,1024` in `upgrade` (after upgrade and after the warp), `concurrent`, `interrupted` and `final`
    (the harness asserts all but the snapshot; the retained observations show it unchanged too).
  - R2: `ARCE_TRANSFER_RECOVERY … phase=DESTINATION_SPAWNED source_count=1 destination_count=1
    action=REMOVE_SOURCE_KEEP_DESTINATION status=RECOVERED`; the harness counted exactly one rocket across both
    end columns, same logical ID, fuel 670; its record is COMMITTED afterwards.
  - Concurrent: two `WARP_COMMITTED` lines (A Moon→Earth, C Earth→Moon, each `balance=0` after a 2,000,000 charge);
    on disk after the kill: A `earth` with exactly the next 2,000,000 charge, C `moon` with no entry.
  - Killed countdown: A stays `earth` with its 2,000,000 on disk (the harness also rejects any late commit line).
  - Commit killed after its line: `stdout` ends at the `WARP_COMMITTED` line; `Popen.terminate()` on Windows is
    `TerminateProcess` (no shutdown save). On disk: C `earth` and no balance entry. The folded 2,000,000 was never
    saved before the commit, so a relocation written without its debit would have shown 2,000,000; the state
    therefore proves orbit and debit were written together by the checked write.
  - Final: registry equal to the post-kill registry; `unclassified=0`.
- **Fixture allow-list** (`src/adapterTest/…/StationExpansionProbe.java:52-65`): opt-in system property,
  level-2 command, full-match regex, 256 replies per player.
- **WARP-05 diagnostics**: ≤ 1 + 1 + 64 + 1 lines; the journal line lists ≤ 4 records; level 2; no fold.
- **AGENTS §3.3** for these commits: no new C2S packet (pin table unchanged apart from ADR-047's carve-out at
  `d45534e`), no client-supplied position loads a chunk (the elevator column is an operator argument and is
  never loaded), no new persisted object or schema (ADR-045 has no storage), bounded outputs. Exception: A1.
- **No weakened assertion** found in the four diffs: the only removed assertions are the storage-bound
  `(10, 20)` expectation (documented behaviour change, R4), a strengthened quarantine assertion, and the two
  config-toggling assertions discussed in A2.

## Mutation results

`mutations-final-a.tsv` (one row per mutation; logs under `mutations/`).

| ID | Commit | Mutation | Result | Caught by |
|---|---|---|---|---|
| MA-01 | `cd3233e` | Heap factor 1 for CELESTIAL and ROCKET_TRANSACTIONS | **Survived** | — (A6) |
| MA-02 | `50a0f42` | `warpSettings()` ignores `warpEnabled` | **Survived** | — (A2) |
| MA-02C | `cd3233e` (control) | same | Killed | rejections test, kill-switch test |
| MA-03 | `a96569b` | `diagnostics` folds | **Survived** | — (A7) |
| MA-04 | `b3d4cf3` | no elevator audit line | **Survived** | — (A5) |
| MA-05 | pre-existing | both flight VISIT checks removed | Killed | 3 flight/navigation GameTests (A10) |
| MA-06 | `50a0f42` | `recoverNext` back to "first unclassified only" | **Survived** | — (A1: the unit test calls only the static helper) |
| MA-07 | `b3d4cf3` | elevator check loads the column's chunk | Killed | elevator GameTest (chunk comparison) |
| MA-08 | `b3d4cf3` | BUILD handler adds a ticket-deferred load | **Survived** | — (A4) |
| MA-09 | `cd3233e` | `status` folds again | Killed | rejections test ("Member status differs") |
| MA-10 | `b3d4cf3` | `remove … uuid` operator flag forced true | Killed | matrix, 7 `REMOVE_UUID` cells |
| MA-11 | `b3d4cf3` | `remove … uuid` removes the actor instead | **Survived** | — (A3) |
| MA-12 | `b3d4cf3` | extra message with a non-literal index | **Survived** | — (A9) |

## Required changes

1. **A1** — make recovery selection side-effect free and activate at most a fixed budget of records per tick
   (rotating cursor); add a budget test and a wiring test; fix the Javadoc and RECOVERY-MATRIX.
2. **A2** — restore an end-to-end, race-free kill-switch binding test; stop GameTests writing the shared config
   (repricing test).
3. **A3** — assert the effect of allowed mutating matrix cells and of S1 `remove_uuid`.
4. **A4** — compare chunk holders after pending ticket updates are processed (matrix and S1), or document the limit.
5. **A5** — capture the elevator audit line; assert the `elevator` leaf requirement on the dispatcher node; fix the comment.
6. **A6** — capacity tests for `CELESTIAL` and `ROCKET_TRANSACTIONS`; heap-accounted admission for journal
   records, or a recorded known issue for creative block-entity payloads.
7. **A7** — assert `admin warp` leaves the registry clean and pending credit unchanged.
8. **A8** — split `StationWarpGameTests` or add the ADR note.

A9-A13 are recommendations.

## Residual risks

- **Operational.** Until A1 is fixed, a server start with many journal records does all their chunk
  activation in the first tick; magnitude depends on disk and generation.
- **Evidence levels.** S1 is a named subset on one native server with mock connected players; V2 (two real
  clients) and V1 remain open. Native in-flight recovery covers one phase from a station.
- **Race classes.** Config-file watcher races remain possible in any GameTest that calls `ConfigValue.set` (A2).
- **Method limits.** Each mutation ran once on a shared machine (up to three Gradle/GameTest JVMs at once).
  Probe timings include chunk generation at far coordinates. The lane-A run of MA-06 hung in its Gradle daemon
  (no output after daemon start, PIDs 28424/18444, forked 18:58); stopping those processes was refused by the
  environment's permission check; at the end of the review both were still running and should be stopped by
  the user. Because its driver is blocked, the export `tree-mutA` (in this directory, not the repository) still
  carries the MA-06 edit. MA-06 was re-run on lane B (`tree-mutB`), where it was applied, run and restored.
- **Not reviewed.** `d45534e` (ORBIT-03) beyond confirming it adds no persistence and updates the protocol table.

## Commands actually executed (in this directory's exports unless stated)

| # | Command | Exit | Result / evidence |
|---|---|---|---|
| 1 | `git log`, `git show --stat`, `git show <c> -- <paths>`, `git status` (repository, read-only) | 0 | diffs and stats of the four commits |
| 2 | `git archive d45534e \| tar -x` (×4: `tree-d45534e`, `tree-mutA`, `tree-mutB`, `tree-probe`), `git archive cd3233e` | 0 | exports |
| 3 | `tree-d45534e`: `./gradlew clean build test runData runGameTestServer` | **0** (4 m 21 s) | 1,051 JUnit / 192 suites, 0 failures, 0 errors, 0 skipped; "All 257 required tests passed"; `ARCE_STATION_PERMISSION_MATRIX_SUMMARY … cells=345 executed=336 not_applicable=9 pass=345 fail=0`; `src/generated` identical to the commit except the ignored `.cache` (`full-run-01.log`) |
| 4 | `python verify_evidence_a.py` | 0 | TOTAL PROBLEMS 0 (`evidence-integrity.log`) |
| 5 | `unzip` of the four `root-checks.zip` and `independent-review-warp.zip` into `ev/` | 0 | read-only analysis |
| 6 | `python analysis/mig_native_check.py ev/mig-native/root` | 0 | per-phase orbits, balances, journal, R1/R2 observations |
| 7 | `python mutate_a.py tree-mutA … MA-01…MA-06` (attempt 1) | 0 | invalid: `gradlew.bat` not found (cwd); retained as `mutations-laneA-console-attempt01.log` |
| 8 | `python mutate_a.py tree-mutA … MA-01…MA-06` | — | MA-01…MA-05 recorded; MA-06 hung (see residual risks) |
| 9 | `python mutate_a.py tree-mutB … MA-07…MA-11`, then `MA-12`, then `MA-06` | 0 | rows in `mutations/laneB/mutations.tsv` |
| 10 | `python mutate_a.py tree-cd3233e … MA-02C` | 0 | killed (2 GameTests) |
| 11 | `tree-probe`: `./gradlew --offline test --tests '*ReviewProbe*' runGameTestServer` (run 01) | 1 | JUnit probe OOM at the default 512 MB test heap; GameTest probe wrong destination Level (`probe-run-01*`) |
| 12 | same after fixing both probes and `maxHeapSize = '6g'` in the probe export only (run 02) | 0 | ratios 6.89 / 7.79 / 53.87; recovery probe 8/8 + 8/8 ends, 6,133 ms; 258 GameTests passed |
| 13 | `tree-probe` with the pre-`50a0f42` selection, `./gradlew runGameTestServer` (run 03) | 0 | recovery probe 1/8 + 1/8 ends, 1,339 ms; restored and byte-compared afterwards |
| 14 | `Stop-Process` on the hung lane-A daemon | refused | permission denied by the environment |

## Statement

This review is independent evidence for the maintainer. It is **not** a Gate approval. It does not mark any
leaf, ADR, version or release verified or accepted, and it changes no status.
