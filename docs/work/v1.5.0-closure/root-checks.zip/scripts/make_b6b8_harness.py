"""Derive the B6/B8 native harness from the MIG-01a harness: keep its helpers, replace the phases."""
from pathlib import Path

SOURCE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-mig01-c84eec47dbce47bfa558191bd957fb87/native_missing_orbit_check.py')
OUT = Path('C:/Users/Administrator/.claude/jobs/2bd39fc3/tmp/native_missing_orbit_restart_check.py')
s = SOURCE.read_text(encoding='utf-8')
head = s[:s.index('def main():')]
head = head.replace('''"""V150-MIG-01 (ADR-042): a v1.4-written station whose orbit body is missing, natively.''',
                    '''"""Final v1.5 review B6 and B8, natively, on a COPY of the retained v1.4 world.

B6 (ADR-042): a v1.4-written station whose orbit body is missing is kept (not evacuated) through
the upgrade, an ordinary save, a restart and the return of the body. B8 (ADR-041): a gravity set by
the owner of the other station is read back after a restart.

(Derived from the MIG-01a harness; its original description follows.)
V150-MIG-01 (ADR-042): a v1.4-written station whose orbit body is missing, natively.''', 1)

main = r'''def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    history = json.loads((HISTORY / 'native-final/summary.json').read_text(encoding='utf-8'))
    require(history['result'] == 'PASS' and history['source_unchanged'], 'Historical receipt incomplete')
    host = support.artifact(HOST_JAR, HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(CONSUMER, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    route_count = fixture.set_removal(SERVER, HOST_JAR, True)
    write_json(OUT / 'inputs.json', {'history_receipt': str(HISTORY / 'native-final/summary.json'),
               'history_receipt_sha256': digest(HISTORY / 'native-final/summary.json'),
               'source_world': str(SOURCE), 'artifacts': [host, consumer], 'routes_with_mars_hidden': route_count})
    before = observe_data(SERVER / 'world', OUT / 'before')
    old = before[STATION]
    require(old['schema_version'] == 2, 'Source is not the v1.4 world')
    mars = [s for s in old['stations'] if s['orbit_body'] == MARS]
    require(len(mars) == 1, 'The v1.4 world must have exactly one Mars-orbit station')
    station = mars[0]
    station_id = nbt_uuid(station['station_id'])
    owner = nbt_uuid(station['owner_id'])
    other_record = next(s for s in old['stations'] if nbt_uuid(s['station_id']) != station_id)
    other = nbt_uuid(other_record['station_id'])
    other_owner = nbt_uuid(other_record['owner_id'])
    pad = station['landing_pad']
    other_pad = other_record['landing_pad']
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    artifacts = [host, consumer]
    unknown = r'\[Server thread/ERROR\].*ARCE_STATION_UNKNOWN_ORBIT_BODY station=' + station_id

    def inspect(phase, process, label, station_uuid, orbit, gravity_milli=None):
        line = phase.query(process, f'arce station admin inspect {station_uuid}', re.compile(r'region=\S+ pad='))
        require(f' orbit={orbit} ' in line, f'{label}: inspect differs: {line.strip()}')
        if gravity_milli is not None:
            require(f' gravity_milli={gravity_milli} ' in line, f'{label}: gravity differs: {line.strip()}')
        phase.observations[label] = line.strip()

    def environment(phase, process, label, actor, stand, expected_fragments):
        phase.probe(process, f'arce_station_probe join {label}_join {actor} ' + ' '.join(map(str, stand)),
                    label + '_join')
        report = phase.run(process, label, actor, 'arce station environment')
        text = ' | '.join(report['messages'])
        for fragment in expected_fragments:
            require(fragment in text, f'{label}: environment lacks {fragment!r}: {text}')
        phase.observations[label] = report['messages']
        phase.probe(process, f'arce_station_probe leave {label}_leave {actor}', label + '_leave')
        return text

    # Phase 1: upgrade with Mars hidden; the station is kept on its missing body; the other station's
    # owner sets its gravity to 40 %.
    def upgrade_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1002\].*migrated=1, backup=\S+-managed', l) for l in process.lines),
                'Unexpected migration startup result')
        inspect(phase, process, 'inspect_missing', station_id, MARS)
        environment(phase, process, 'environment_missing', owner, pad, [f'orbit={MARS} (unavailable)'])
        stand = [other_pad[0], other_pad[1], other_pad[2]]
        phase.probe(process, f'arce_station_probe join gravity_join {other_owner} ' + ' '.join(map(str, stand)),
                    'gravity_join')
        report = phase.run(process, 'gravity_set', other_owner, 'arce station gravity 40')
        require(any('Station gravity set' in m and 'gravity=40%' in m for m in report['messages']),
                'Gravity was not set: ' + json.dumps(report))
        phase.probe(process, f'arce_station_probe leave gravity_leave {other_owner}', 'gravity_leave')
        inspect(phase, process, 'inspect_other_gravity', other, station_record(old, other)['orbit_body'], 400)

    upgrade = Phase('upgrade-missing', artifacts, [unknown])
    receipts = [run_phase(upgrade, port, upgrade_actions)]
    upgraded = observe_data(SERVER / 'world', upgrade.directory / 'state')
    kept = station_record(upgraded[STATION], station_id)
    expected_station = copy.deepcopy(station)
    expected_station.update(schema_version=2)
    require(upgraded[STATION]['schema_version'] == 4 and kept == expected_station,
            'The ordinary save changed the station on its missing body: ' + json.dumps(kept, default=str))
    require(station_record(upgraded[STATION], other)['environment']['gravity_milli'] == 400,
            'The gravity write is not in the saved registry')

    # Phase 2: restart with Mars still hidden: the ID is kept, reported again, environment unavailable,
    # and the gravity is read back.
    def restart_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'Restart remigrated')
        inspect(phase, process, 'inspect_restart_missing', station_id, MARS)
        environment(phase, process, 'environment_restart_missing', owner, pad, [f'orbit={MARS} (unavailable)'])
        inspect(phase, process, 'inspect_restart_gravity', other, station_record(old, other)['orbit_body'], 400)
        environment(phase, process, 'environment_restart_gravity', other_owner,
                    [other_pad[0], other_pad[1], other_pad[2]], ['gravity=40%'])

    restart = Phase('restart-missing', artifacts, [unknown])
    receipts.append(run_phase(restart, port, restart_actions))
    restarted = observe_data(SERVER / 'world', restart.directory / 'state')
    require(restarted[STATION] == upgraded[STATION], 'The restart changed the station registry')

    # Phase 3: Mars returns while the station still orbits it.
    fixture.set_removal(SERVER, HOST_JAR, False)

    def restored_actions(phase, process):
        inspect(phase, process, 'inspect_restored', station_id, MARS)
        text = environment(phase, process, 'environment_restored', owner, pad, [f'orbit={MARS}'])
        require('(unavailable)' not in text, 'Mars is still unavailable after it returned: ' + text)
        inspect(phase, process, 'inspect_restored_gravity', other, station_record(old, other)['orbit_body'], 400)

    restored = Phase('restored', artifacts, [])
    receipts.append(run_phase(restored, port, restored_actions))
    final = observe_data(SERVER / 'world', restored.directory / 'state')
    require(final[STATION] == upgraded[STATION], 'Restoring Mars changed the station registry')
    celestial = HOST + '_celestial.dat'
    visit_only_celestial_change(before[celestial], final[celestial])
    for name in before:
        if name not in (STATION, celestial):
            require(normalize_other(name, before[name]) == normalize_other(name, final[name]),
                    'Another authority changed: ' + name)
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
        'station': station_id, 'owner': owner, 'other_station': other, 'other_owner': other_owner,
        'orbit': {'v14': MARS, 'after_upgrade_save': MARS, 'after_restart': MARS, 'after_restore': MARS},
        'gravity_milli': {'set': 400, 'after_restart': 400, 'after_restore': 400},
        'cycles': receipts,
        'scope': ('genuine v1.4 world, Mars hidden by a data-pack filter -> v1.5 upgrade keeps the Mars-orbit '
                  'station through an ordinary save -> restart with Mars hidden (ID kept, reported again, '
                  'environment unavailable) -> Mars restored while the station still orbits it; the other '
                  'station\'s owner sets gravity 40 % and it is read back after the restart and the restore; '
                  'no real clients, rockets or crash cuts')})
    print('PASS: B6 missing-orbit station kept through save, restart and restore; B8 gravity read back')


if __name__ == '__main__':
    main()
'''
OUT.write_text(head + main, encoding='utf-8', newline='\n')
print('written', OUT)
