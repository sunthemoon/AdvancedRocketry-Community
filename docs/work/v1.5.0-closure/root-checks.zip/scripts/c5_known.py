"""C5: update KNOWN-ISSUES and REQUIREMENT-MAP for the final review."""
from pathlib import Path

R = Path('D:/GitHub/AdvancedRocketry-Community/docs/releases/v1.5.0')
p = R / 'KNOWN-ISSUES.md'
s = p.read_text(encoding='utf-8')


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:90]
    s = s.replace(old, new)


sub('''- **Stuck transfer records.** A rocket transfer record whose Level is gone stays
  unclassified. It keeps every warp refused until the Level or data pack is restored,
  or the pre-upgrade backup is restored. Recovery moves on to the other records, and
  the operator line lists the record with both ends. There is no audited abandon
  command yet (WARP review R7).''',
    '''- **Stuck transfer records.** A rocket transfer record whose Level is gone stays
  unclassified. It keeps every warp refused until the Level or data pack is restored,
  or the pre-upgrade backup is restored. Recovery handles one record per call,
  round-robin, so it reaches the other records, and the operator line lists the stuck
  record with both ends. There is no audited abandon command yet (WARP review R7,
  final review A13); it is planned with v1.6's mission recovery work at the earliest.
- **Many stations writing at once.** Checked station writes (expansion, gravity, warp
  commit) are spaced server-wide: after one, the next waits `floor(stations × N / 100)`
  ticks, with N from `stations.checkedWriteTicksPer100Stations` (default 3; 0 turns the
  spacing off). With 4,096 stations that is about one write every 6 seconds. A request
  in that window is refused with "the station registry is saving another change" and
  nothing changes; a due warp waits (final review B9).
- **Team changes that change nothing.** Repeating an invitation or a similar no-op team
  command still adds to the registry's growth estimate and marks the registry for
  saving. It stays within the growth bound (final review A12).''')
sub('''## Persistence bounds
''', '''## Persistence bounds

- **Heap headroom.** Loads are bounded by 8 × the file size for every managed type. The
  station registry's measured ratio is far below that, but the headroom is measured on
  the development host only, not on reference hardware (final review B11).
- **Rocket journal heap ratio.** Block-entity and item NBT inside a journalled rocket
  can raise the journal's heap-to-file ratio: 7.79 with filled survival chests and 53.9
  with a crafted creative item tag. The second exceeds the factor of 8, so such a
  journal can be refused at load rather than exhausting the heap (final review A6).
- **Capacity tests.** The CELESTIAL and ROCKET_TRANSACTIONS stores have no capacity
  test at their record limits yet (final review A6).
''')
sub('''- **Config toggling.** Tests must not toggle shared config values: the Forge config
  file watcher can re-apply a stale value on another thread. The two warp tests that
  did so now use private services (C3 packet).''',
    '''- **Config toggling.** Tests must not toggle shared config values: the Forge config
  file watcher can re-apply a stale value on another thread. No GameTest writes the
  shared config file any more: the warp tests use private services, and
  `CommonConfigWiringTest` checks the wiring on an in-memory config (final review A2).
- **Permission matrix counts.** "345/345" includes 9 not-applicable and 2 parse-only
  cells. Force-loaded chunk sets are compared per cell; loads through other ticket
  types are only seen through chunk-holder counts (final review A4, A10).''')
p.write_text(s, encoding='utf-8', newline='\n')

p = R / 'REQUIREMENT-MAP.md'
s = p.read_text(encoding='utf-8')
sub('''| Crash recovery at every journal stage | Crash-cut JUnit (`StationWarpRelocationTest`); transfer recovery decision tests; [recovery matrix](../../work/v1.5.0-mig-native/RECOVERY-MATRIX.md) | Automated; native for a subset |''',
    '''| Crash recovery at every journal stage | Crash-cut JUnit (`StationWarpRelocationTest`); transfer recovery decision tests; [recovery matrix](RECOVERY-MATRIX.md) | Automated; native for a subset |''')
sub('''| v1.4 station fixture migration | Native: [STATION-04](../../work/v1.5.0-station-native/VERIFICATION.md), [MIG-01a](../../work/v1.5.0-mig-missing-orbit/VERIFICATION.md), [MIG-01b/02](../../work/v1.5.0-mig-native/VERIFICATION.md) | Native |''',
    '''| v1.4 station fixture migration | Native: [STATION-04](../../work/v1.5.0-station-native/VERIFICATION.md), [MIG-01a](../../work/v1.5.0-mig-missing-orbit/VERIFICATION.md), [MIG-01b/02](../../work/v1.5.0-mig-native/VERIFICATION.md), [closure](../../work/v1.5.0-closure/VERIFICATION.md) (missing body kept through a save, restart and return; gravity through a restart) | Native |''')
sub('''| Concurrent records for 10+ stations; chunk unload | `tenChargingStationsDirtyTheRegistryOnlyOncePerFoldWindow`; `StationCheckedUpdateScaleTest` at 10, 100 and 4,096 stations ([WARP-05](../../work/v1.5.0-warp-native/VERIFICATION.md)) | Automated; no native load test |''',
    '''| Concurrent records for 10+ stations; chunk unload | `tenChargingStationsDirtyTheRegistryOnlyOncePerFoldWindow`; `StationCheckedUpdateScaleTest` at 10, 100 and 4,096 stations ([WARP-05](../../work/v1.5.0-warp-native/VERIFICATION.md)); server-wide write spacing, `checkedWritesShareOneServerWideSpacing` ([closure](../../work/v1.5.0-closure/VERIFICATION.md)) | Automated; no native load test |''')
sub('''| Catalog reload or target removal aborts safely | `aTargetRemovedDuringTheCountdownAborts`; native missing orbit body ([MIG-01a](../../work/v1.5.0-mig-missing-orbit/VERIFICATION.md)) | Automated and native |''',
    '''| Catalog reload or target removal aborts safely | `aTargetRemovedDuringTheCountdownAborts`, `aRepricedCountdownAborts`; native missing orbit body ([MIG-01a](../../work/v1.5.0-mig-missing-orbit/VERIFICATION.md), [closure](../../work/v1.5.0-closure/VERIFICATION.md)) | Automated and native |''')
sub('''| Zero Critical/High findings | See the final review in [RELEASE-EVIDENCE](RELEASE-EVIDENCE.md) |''',
    '''| Zero Critical/High findings | Development only: the final independent review of every v1.5 slice (areas A and B) found no Critical or High issue; all Medium findings are fixed ([closure](../../work/v1.5.0-closure/VERIFICATION.md)). The candidate-bound audit is ACC-03 |''')
sub('''| Recovery matrix | [RECOVERY-MATRIX](../../work/v1.5.0-mig-native/RECOVERY-MATRIX.md) |''',
    '''| Recovery matrix | [RECOVERY-MATRIX](RECOVERY-MATRIX.md) (corrected handoff copy of the [C3 copy](../../work/v1.5.0-mig-native/RECOVERY-MATRIX.md)) |''')
sub('''| Multiplayer permission report | [A1](../../work/v1.5.0-elevator-ui/PERMISSION-MATRIX.md), [S1](../../work/v1.5.0-mig-native/PERMISSION-S1.md); V2 open |''',
    '''| Multiplayer permission report | [A1](../../work/v1.5.0-elevator-ui/PERMISSION-MATRIX.md), [S1](../../work/v1.5.0-mig-native/PERMISSION-S1.md); V2 open |
| Final independent reviews | `independent-review-final-a.zip` and `independent-review-final-b.zip` in the [closure packet](../../work/v1.5.0-closure/VERIFICATION.md) |''')
p.write_text(s, encoding='utf-8', newline='\n')
print('ok')
