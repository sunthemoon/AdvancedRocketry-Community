"""C5 ACC-01: write docs/releases/v1.5.0 development-artifacts.json, evidence-index.json and checksums.txt.

Usage: c5_handoff.py <evidence dir> [--checksums]
Without --checksums: verifies every earlier v1.5 packet's SHA256SUMS and writes the two JSON indexes.
With --checksums: writes checksums.txt over the handoff directory (run last).
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = ROOT / 'docs/releases/v1.5.0'
E = Path(sys.argv[1])
PARENT = 'd45534ebc55a4005df511935ed34adf62a8a7b2e'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


if '--checksums' in sys.argv:
    paths = sorted((p for p in OUT.iterdir() if p.is_file() and p.name != 'checksums.txt'), key=lambda p: p.name)
    (OUT / 'checksums.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                       encoding='ascii', newline='\n')
    print('checksums:', len(paths))
    sys.exit(0)

artifacts = json.loads((E / 'artifacts.json').read_text())['artifacts']
for row in artifacts:
    assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
fixture = ROOT / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
fixture_bytes = fixture.read_bytes()
assert sha(fixture_bytes) == '765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'
write('development-artifacts.json', {
    'schema_version': 1,
    'build': '1.20.1-1.5.0-dev',
    'development_parent_commit': PARENT,
    'candidate_commit': None,
    'artifacts': artifacts,
    'native_fixture': {'name': fixture.name, 'bytes': len(fixture_bytes), 'sha256': sha(fixture_bytes),
                       'mod_id': 'arce_adapter_test', 'built_against': '1.20.1-1.5.0-dev'},
    'legacy_native_inputs': [
        {'name': 'advancedrocketry-community-1.20.1-1.4.0-dev.jar',
         'sha256': '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475'},
        {'name': 'arce-adapter-compat-test-1.0.0.jar (v1.4 build)',
         'sha256': 'e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47'}],
    'scope': ('Bytes built and tested by the closure run 01 and both closure native harnesses. '
              'Development artifacts, not a release candidate or a download.'),
})

records, failures = [], []
total_files = total_bytes = 0
for packet in sorted(p for p in (ROOT / 'docs/work').iterdir() if p.is_dir() and p.name.startswith('v1.5.0-')):
    if packet.name == 'v1.5.0-closure':
        continue
    sums = packet / 'SHA256SUMS.txt'
    assert sums.exists(), packet
    checked = checked_bytes = 0
    for line in sums.read_text(encoding='ascii').splitlines():
        digest, name = line.split('  ', 1)
        data = (packet / name).read_bytes()
        if sha(data) != digest:
            failures.append(f'{packet.name}/{name}')
        checked += 1
        checked_bytes += len(data)
    listed = {line.split('  ', 1)[1] for line in sums.read_text(encoding='ascii').splitlines()}
    unlisted = sorted(p.name for p in packet.iterdir() if p.name != 'SHA256SUMS.txt' and p.name not in listed)
    if unlisted:
        failures.append(f'{packet.name}: unlisted {unlisted}')
    report = packet / 'VERIFICATION.md'
    raw = sums.read_bytes()
    records.append({
        'packet': packet.relative_to(ROOT).as_posix(),
        'manifest': {'path': sums.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)},
        'report': ({'path': report.relative_to(ROOT).as_posix(), 'bytes': len(report.read_bytes()),
                    'sha256': sha(report.read_bytes())} if report.exists() else None),
        'files_checked': checked,
        'bytes_checked': checked_bytes,
        'artifact_scope': 'historical artifact of that slice',
    })
    total_files += checked
    total_bytes += checked_bytes
assert not failures, failures
write('evidence-index.json', {
    'schema_version': 1,
    'development_parent_commit': PARENT,
    'candidate_commit': None,
    'records': records,
    'manifest_count': len(records),
    'manifest_files_checked': total_files,
    'manifest_bytes_checked': total_bytes,
    'manifest_failures': failures,
    'not_indexed': {'packet': 'docs/work/v1.5.0-closure',
                    'reason': ('Committed with this handoff. Its source-identity.json and SHA256SUMS.txt bind '
                               'this directory, so indexing it here would be circular.')},
    'scope': ('Verifies each earlier v1.5 packet against its own SHA256SUMS. It does not relabel '
              'historical runs as tests of the current artifacts.'),
})
print('packets:', len(records), 'files:', total_files, 'bytes:', total_bytes)
