"""C5: update the v1.5 implementation log (segment 9, feature map, ACC-01)."""
from pathlib import Path

p = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-implementation-log.md')
s = p.read_text(encoding='utf-8')


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:90]
    s = s.replace(old, new)


sub('''9. [ ] Fix runtime bridges cleared at stop (integrated server); confirm the
   STATION-03/04, ORBIT-02 and ORBIT-04 review status; ACC-01 handoff. Track
   WARP review R3 (the satellite registry outgrows its 4 MiB bound before its
   record limits; pre-existing) and watch the R9 flake.''',
    '''9. [x] Fix runtime bridges cleared at stop (integrated server); confirm the
   STATION-03/04, ORBIT-02 and ORBIT-04 review status; ACC-01 handoff. Track
   WARP review R3 (the satellite registry outgrows its 4 MiB bound before its
   record limits; pre-existing) and watch the R9 flake. Done in the
   [closure](v1.5.0-closure/VERIFICATION.md): the station bridge reinstalls at each
   start; two final independent reviews (areas A and B) found no Critical or High
   issue, and every Medium and fixable Low finding is fixed; the
   [development handoff](../releases/v1.5.0/RELEASE-EVIDENCE.md) lists the
   remaining acceptance. R3 and R9 are in [KNOWN-ISSUES](../releases/v1.5.0/KNOWN-ISSUES.md).''')

REVIEWED = 'final independent review: accept with changes, fixes in the [closure](v1.5.0-closure/VERIFICATION.md)'
sub('''- [ ] `V150-STATION` Station authority, bounded growth and old-world preservation — status: in-progress''',
    '''- [x] `V150-STATION` Station authority, bounded growth and old-world preservation — status: verified''')
sub('''  - [ ] `V150-STATION-03` Checked local expansion and permission feedback — status: implemented-unverified''',
    f'''  - [x] `V150-STATION-03` Checked local expansion and permission feedback — status: verified ({REVIEWED})''')
sub('''  - [ ] `V150-STATION-04` Independent checks and authentic v1.4 copy/restart — status: implemented-unverified''',
    f'''  - [x] `V150-STATION-04` Independent checks and authentic v1.4 copy/restart — status: verified ({REVIEWED})''')
sub('''- [ ] `V150-ORBIT` Effective position-aware orbit environment — status: in-progress''',
    '''- [x] `V150-ORBIT` Effective position-aware orbit environment — status: verified (V0/V1/V2 open for ACC-02)''')
sub('''  - [ ] `V150-ORBIT-02` Server gravity effects and effective solar intensity (display/consumers; no power, ADR-041) — status: implemented-unverified''',
    f'''  - [x] `V150-ORBIT-02` Server gravity effects and effective solar intensity (display/consumers; no power, ADR-041) — status: verified ({REVIEWED}; ADR-041 rev. 2)''')
sub('''  - [ ] `V150-ORBIT-03` Per-station sky/UI synchronization and lifecycle — status: implemented-unverified ([ADR-047](../decisions/ADR-047-PER-STATION-SKY-CONTEXT.md) rev. 2; [verification](v1.5.0-orbit-sky/VERIFICATION.md); V0 not run on this host; V1/V2 open for ACC-02)''',
    f'''  - [x] `V150-ORBIT-03` Per-station sky/UI synchronization and lifecycle — status: verified (server synchronization and lifecycle; [ADR-047](../decisions/ADR-047-PER-STATION-SKY-CONTEXT.md) rev. 3; [verification](v1.5.0-orbit-sky/VERIFICATION.md); {REVIEWED}; V0 not run on this host; V1/V2 open for ACC-02)''')
sub('''  - [ ] `V150-ORBIT-04` Independent bounded multi-region/reload checks — status: in-progress (scale measurement and capacity fix done; independent review pending)''',
    f'''  - [x] `V150-ORBIT-04` Independent bounded multi-region/reload checks — status: verified (scale measurement and capacity fix; {REVIEWED}; server-wide write spacing added for B9)''')
SLICES = 'independent review applied: [record](v1.5.0-slices-review/VERIFICATION.md)'
sub('''- [ ] `V150-STAR` Multiple star systems and permitted routes — status: in-progress''',
    '''- [x] `V150-STAR` Multiple star systems and permitted routes — status: verified''')
sub('''  - [ ] `V150-STAR-02` Catalog, routes and authoritative discovery/unlocks — status: implemented-unverified ([verification](v1.5.0-star-systems/VERIFICATION.md))''',
    f'''  - [x] `V150-STAR-02` Catalog, routes and authoritative discovery/unlocks — status: verified ([verification](v1.5.0-star-systems/VERIFICATION.md); {SLICES})''')
sub('''  - [ ] `V150-STAR-03` Audited example systems and finite verification — status: implemented-unverified (Tau Ceti example; independent review pending)''',
    f'''  - [x] `V150-STAR-03` Audited example systems and finite verification — status: verified (Tau Ceti example; {SLICES})''')
sub('''- [ ] `V150-WARP` Costed multi-stage station warp — status: in-progress''',
    '''- [x] `V150-WARP` Costed multi-stage station warp — status: verified''')
sub('''  - [ ] `V150-WARP-02` Bounded plans/state/journal and durable resource authority — status: implemented-unverified ([verification](v1.5.0-warp-schema/VERIFICATION.md); independent review pending)''',
    f'''  - [x] `V150-WARP-02` Bounded plans/state/journal and durable resource authority — status: verified ([verification](v1.5.0-warp-schema/VERIFICATION.md); {SLICES})''')
WARP_REVIEW = 'independent review applied: [review closure](v1.5.0-review-closure/VERIFICATION.md), rechecked by the final review'
sub('''  - [ ] `V150-WARP-03` Core, countdown, target preparation and commit/cancel — status: implemented-unverified ([verification](v1.5.0-warp-core/VERIFICATION.md); rocket port fail-closed until WARP-04; independent review pending)''',
    f'''  - [x] `V150-WARP-03` Core, countdown, target preparation and commit/cancel — status: verified ([verification](v1.5.0-warp-core/VERIFICATION.md); {WARP_REVIEW})''')
sub('''  - [ ] `V150-WARP-04` Online/offline passengers and docked/inbound rocket authority — status: implemented-unverified ([verification](v1.5.0-warp-rockets/VERIFICATION.md); independent review pending)''',
    f'''  - [x] `V150-WARP-04` Online/offline passengers and docked/inbound rocket authority — status: verified ([verification](v1.5.0-warp-rockets/VERIFICATION.md); {WARP_REVIEW}; recovery handles one record per call since the final review, A1)''')
sub('''  - [ ] `V150-WARP-05` Every-stage restart/recovery and administrator diagnostics — status: implemented-unverified ([verification](v1.5.0-warp-native/VERIFICATION.md); native warp, stop fold and interrupted countdown PASS; independent review pending)''',
    f'''  - [x] `V150-WARP-05` Every-stage restart/recovery and administrator diagnostics — status: verified ([verification](v1.5.0-warp-native/VERIFICATION.md); native warp, stop fold and interrupted countdown PASS; {REVIEWED})''')
sub('''- [ ] `V150-UI` Station/team/warp controls and security — status: in-progress ([ADR-046](../decisions/ADR-046-V150-STATION-CONTROLS-ARE-COMMANDS.md) rev. 2, amends ADR-039; [verification](v1.5.0-elevator-ui/VERIFICATION.md))''',
    '''- [x] `V150-UI` Station/team/warp controls and security — status: verified ([ADR-046](../decisions/ADR-046-V150-STATION-CONTROLS-ARE-COMMANDS.md) rev. 2, amends ADR-039; [verification](v1.5.0-elevator-ui/VERIFICATION.md); V1/V2 open for ACC-02)''')
sub('''  - [ ] `V150-UI-01` Server-authoritative actions and bounded protocol — status: implemented-unverified (commands only; four channels pinned by `NetworkProtocolPinTest`)''',
    f'''  - [x] `V150-UI-01` Server-authoritative actions and bounded protocol — status: verified (commands only; four channels pinned by `NetworkProtocolPinTest`; {REVIEWED})''')
sub('''  - [ ] `V150-UI-02` Player status, permission/error and countdown presentation — status: implemented-unverified (GameTests capture replies; English-only waiver to v1.8.0)''',
    f'''  - [x] `V150-UI-02` Player status, permission/error and countdown presentation — status: verified (GameTests capture replies; English-only waiver to v1.8.0; {REVIEWED}; V1 open)''')
sub('''  - [ ] `V150-UI-03` Stale/forged/unloaded/multi-player authority checks — status: implemented-unverified (A1 matrix 345/345, [report](v1.5.0-elevator-ui/PERMISSION-MATRIX.md); S1 native 24/24, [report](v1.5.0-mig-native/PERMISSION-S1.md); V2 open for ACC-02)''',
    f'''  - [x] `V150-UI-03` Stale/forged/unloaded/multi-player authority checks — status: verified (A1 matrix 345/345, [report](v1.5.0-elevator-ui/PERMISSION-MATRIX.md), now with per-cell effect and force-load checks; S1 native 24/24, [report](v1.5.0-mig-native/PERMISSION-S1.md); {REVIEWED}; V2 open for ACC-02)''')
sub('''- [ ] `V150-ELEVATOR` Minimal station endpoint contract and validation — status: implemented-unverified ([ADR-045](../decisions/ADR-045-SPACE-ELEVATOR-ENDPOINT-CONTRACT.md) rev. 2; validator, operator check command, JUnit and GameTest; [verification](v1.5.0-elevator-ui/VERIFICATION.md))''',
    f'''- [x] `V150-ELEVATOR` Minimal station endpoint contract and validation — status: verified ([ADR-045](../decisions/ADR-045-SPACE-ELEVATOR-ENDPOINT-CONTRACT.md) rev. 2; validator, operator check command, JUnit and GameTest; [verification](v1.5.0-elevator-ui/VERIFICATION.md); {REVIEWED})''')
sub('''- [ ] `V150-MIG` Integrated removal, restart and asset conservation — status: in-progress''',
    '''- [x] `V150-MIG` Integrated removal, restart and asset conservation — status: verified''')
sub('''  - [ ] `V150-MIG-01` Station/core/passenger/rocket recovery matrix — status: implemented-unverified
    ([matrix](v1.5.0-mig-native/RECOVERY-MATRIX.md); both ADR-042 cases natively PASS: missing orbit body,
    [verification](v1.5.0-mig-missing-orbit/VERIFICATION.md), and v1.4-written docked and in-flight
    rocket identities, [verification](v1.5.0-mig-native/VERIFICATION.md))''',
    f'''  - [x] `V150-MIG-01` Station/core/passenger/rocket recovery matrix — status: verified
    ([corrected handoff matrix](../releases/v1.5.0/RECOVERY-MATRIX.md); both ADR-042 cases natively PASS: missing orbit body,
    [verification](v1.5.0-mig-missing-orbit/VERIFICATION.md) and, kept on the missing body through a save, a restart and
    its return, the [closure](v1.5.0-closure/VERIFICATION.md); v1.4-written docked and in-flight
    rocket identities, [verification](v1.5.0-mig-native/VERIFICATION.md); {REVIEWED})''')
sub('''  - [ ] `V150-MIG-02` Packaged finite interruption and two-station concurrency — status: implemented-unverified
    ([verification](v1.5.0-mig-native/VERIFICATION.md): concurrent warps, killed countdown, commit killed after its line)''',
    f'''  - [x] `V150-MIG-02` Packaged finite interruption and two-station concurrency — status: verified
    ([verification](v1.5.0-mig-native/VERIFICATION.md): concurrent warps, killed countdown, commit killed after its line;
    rerun on the final JAR in the closure; {REVIEWED})''')
sub('''- [ ] `V150-ACC` Evidence handoff and G0-G9 acceptance — status: planned
  - [ ] `V150-ACC-01` Development evidence and acceptance-gap handoff — status: planned''',
    '''- [ ] `V150-ACC` Evidence handoff and G0-G9 acceptance — status: in-progress
  - [ ] `V150-ACC-01` Development evidence and acceptance-gap handoff — status: implemented-unverified
    ([RELEASE-EVIDENCE](../releases/v1.5.0/RELEASE-EVIDENCE.md); the handoff itself has not been independently reviewed)''')
sub('''last_updated: 2026-09-30
```

The v1.4 handoff''', '''last_updated: 2026-09-30
```

**Development status (C5, 2026-09-30):** every v1.5 development slice is implemented
and independently reviewed, and the [development handoff](../releases/v1.5.0/RELEASE-EVIDENCE.md)
is written. The version stays `IN_PROGRESS`: V0/V1/V2, S2, reference-hardware
performance and the candidate-bound matrix (ACC-02) and the final audit and human
decision (ACC-03) are the maintainer's. The next development chunk is v1.6 (C6 in
[COMPLETION-PLAN](../status/COMPLETION-PLAN.md)).

The v1.4 handoff''')
p.write_text(s, encoding='utf-8', newline='\n')
print('ok')
