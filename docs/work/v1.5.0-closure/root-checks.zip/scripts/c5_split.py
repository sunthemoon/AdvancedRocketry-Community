"""Final review A8/A2: split StationWarpGameTests (836 lines) and remove the last shared-config write."""
from pathlib import Path

G = Path('D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest')
p = G / 'StationWarpGameTests.java'
s = p.read_text(encoding='utf-8')

start = s.index('    /** WARP review R2 (M10): the kill switch is rechecked at commit;')
end = s.index('    private static List<CelestialBodyDefinition> bodies(boolean withStarSystem) {')
moved = s[start:end]
bodies_start = end
bodies_end = s.index('    private static void expect(GameTestHelper helper')
bodies = s[bodies_start:bodies_end]
s = s[:start] + s[bodies_end:]


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (count, s.count(old), old[:90])
    s = s.replace(old, new)


# Shared members become package-visible for the new class.
sub('''    private static final ResourceLocation MOON = CelestialIds.MOON_ID;
    private static final StationRocketAuthority NOTHING_IN_MOTION = (server, station) -> false;
    private static final int COMMIT_DELAY = (int) StationLimits.WARP_COUNTDOWN_TICKS + 3;''',
    '''    static final ResourceLocation MOON = CelestialIds.MOON_ID;
    static final StationRocketAuthority NOTHING_IN_MOTION = (server, station) -> false;
    static final int COMMIT_DELAY = (int) StationLimits.WARP_COUNTDOWN_TICKS + 3;''')
sub('''    private static void expect(GameTestHelper helper, List<String> replies, StationManagementCode code, String label) {''',
    '''    static void expect(GameTestHelper helper, List<String> replies, StationManagementCode code, String label) {''')
sub('''    private static String last(List<String> replies) {''', '''    static String last(List<String> replies) {''')
sub('''    /** One station in Space with its owner UUID, connected players, placed cores and cleanup. */
    private static final class Fixture {''', '''    /** One station in Space with its owner UUID, connected players, placed cores and cleanup. */
    static final class Fixture {''')

# A2: the repricing case moves to a private service (no shared config write); cancel/change stay.
sub('''    public static void cancelledChangedOrRepricedCountdownsNeverWarpOrCharge(GameTestHelper helper) {
        Fixture cancelled = new Fixture(helper, "Cancelled warp", CelestialIds.EARTH_ID, 5_000_000);
        Fixture changed = new Fixture(helper, "Changed warp", CelestialIds.EARTH_ID, 5_000_000);
        Fixture repriced = new Fixture(helper, "Repriced warp", CelestialIds.EARTH_ID, 5_000_000);
        StationRocketAuthority previous = cancelled.warp.installRocketAuthority(NOTHING_IN_MOTION);
        int configuredCost = CommonConfig.WARP_COST_IN_SYSTEM.get();
        boolean scheduled = false;''', '''    public static void cancelledOrChangedCountdownsNeverWarpOrCharge(GameTestHelper helper) {
        Fixture cancelled = new Fixture(helper, "Cancelled warp", CelestialIds.EARTH_ID, 5_000_000);
        Fixture changed = new Fixture(helper, "Changed warp", CelestialIds.EARTH_ID, 5_000_000);
        StationRocketAuthority previous = cancelled.warp.installRocketAuthority(NOTHING_IN_MOTION);
        boolean scheduled = false;''')
sub('''            for (Fixture fixture : List.of(cancelled, changed, repriced)) {
                fixture.core(fixture.pad.east(2));''', '''            for (Fixture fixture : List.of(cancelled, changed)) {
                fixture.core(fixture.pad.east(2));''')
sub('''            changed.data.addMember(changed.id(), UUID.randomUUID());
            // A config change after consent changes the price: the commit must ask for new consent.
            CommonConfig.WARP_COST_IN_SYSTEM.set(configuredCost + 1_000_000);
            scheduled = true;''', '''            changed.data.addMember(changed.id(), UUID.randomUUID());
            scheduled = true;''')
sub('''                    for (Fixture fixture : List.of(cancelled, changed, repriced)) {''',
    '''                    for (Fixture fixture : List.of(cancelled, changed)) {''')
sub('''                    helper.assertTrue(owners.get(0).stream().noneMatch(line -> line.startsWith("Station warp aborted")
                            || line.startsWith("Station warped")), "A cancelled countdown still committed");
                    helper.assertTrue(owners.get(2).stream().anyMatch(line -> line.equals("Station warp aborted: "
                            + StationManagementCode.WARP_QUOTE_CHANGED.description() + ".")),
                            "Repricing did not abort: " + owners.get(2));
                } finally {
                    CommonConfig.WARP_COST_IN_SYSTEM.set(configuredCost);
                    cancelled.warp.installRocketAuthority(previous);
                    cancelled.close();
                    changed.close();
                    repriced.close();
                }''', '''                    helper.assertTrue(owners.get(0).stream().noneMatch(line -> line.startsWith("Station warp aborted")
                            || line.startsWith("Station warped")), "A cancelled countdown still committed");
                } finally {
                    cancelled.warp.installRocketAuthority(previous);
                    cancelled.close();
                    changed.close();
                }''')
sub('''            if (!scheduled) {
                CommonConfig.WARP_COST_IN_SYSTEM.set(configuredCost);
                cancelled.warp.installRocketAuthority(previous);
                cancelled.close();
                changed.close();
                repriced.close();
            }''', '''            if (!scheduled) {
                cancelled.warp.installRocketAuthority(previous);
                cancelled.close();
                changed.close();
            }''')
p.write_text(s, encoding='utf-8', newline='\n')

# The new class: moved tests plus the repricing test on a private service.
header_end = s.index('@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)')
imports = s[:header_end]
imports = imports[:imports.index('/**')] if '/**' in imports else imports
repriced = '''
    /**
     * ADR-044 §4: a price change after consent (a config reload) makes the commit ask for new consent.
     * A private service with switchable settings, so the shared config file is never written (final
     * review A2: Forge's file watcher can re-apply a stale value on another thread).
     */
    @GameTest(template = "empty", batch = "station_warp_repriced", timeoutTicks = 400)
    public static void aRepricedCountdownAborts(GameTestHelper helper) {
        Fixture fixture = new Fixture(helper, "Repriced warp", CelestialIds.EARTH_ID, 5_000_000);
        CelestialCatalogManager catalogs = new CelestialCatalogManager();
        java.util.concurrent.atomic.AtomicReference<WarpSettings> settings =
                new java.util.concurrent.atomic.AtomicReference<>(WarpSettings.DEFAULTS);
        StationWarpService isolated = new StationWarpService(catalogs, system -> false, settings::get);
        isolated.installRocketAuthority(NOTHING_IN_MOTION);
        boolean scheduled = false;
        try {
            helper.assertTrue(catalogs.applyCandidate(CelestialCatalog.create(bodies(false))),
                    "The private catalog was rejected");
            fixture.core(fixture.pad.east(2));
            List<String> owner = fixture.join(fixture.ownerId, "repricedOwner");
            fixture.look(fixture.ownerId, fixture.pad.east(2));
            ServerPlayer player = fixture.server.getPlayerList().getPlayer(fixture.ownerId);
            helper.assertTrue(isolated.request(player, true, MOON).code() == StationManagementCode.WARP_ISSUED,
                    "Request differs: " + owner);
            helper.assertTrue(isolated.confirm(player, true, fixture.id()).code() == StationManagementCode.WARP_STARTED,
                    "Countdown did not start: " + owner);
            settings.set(new WarpSettings(true, WarpSettings.DEFAULTS.inSystemCost() + 1_000_000,
                    WarpSettings.DEFAULTS.interstellarCost()));
            helper.onEachTick(() -> isolated.onServerTick(
                    new TickEvent.ServerTickEvent(TickEvent.Phase.END, () -> true, fixture.server)));
            scheduled = true;
            helper.runAfterDelay(COMMIT_DELAY, () -> {
                try {
                    helper.assertTrue(fixture.station().orbitBody().equals(CelestialIds.EARTH_ID)
                            && fixture.data.warpEnergy(fixture.id()) == 5_000_000, "A repriced warp moved or charged");
                    helper.assertTrue(owner.stream().anyMatch(line -> line.equals("Station warp aborted: "
                                    + StationManagementCode.WARP_QUOTE_CHANGED.description() + ".")),
                            "Repricing did not abort: " + owner);
                } finally {
                    fixture.close();
                }
                helper.succeed();
            });
        } finally {
            if (!scheduled) {
                fixture.close();
            }
        }
    }

'''
body = moved + repriced + bodies
body = body.replace('new Fixture(', 'new Fixture(')
new_class = imports + '''/**
 * Warp countdowns that must abort or wait: the kill switch, a de-opped operator, one commit per tick,
 * a removed target and a changed price (WARP review R2, final review A2). Split from
 * StationWarpGameTests (final review A8); it shares that class's fixture.
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class StationWarpAbortGameTests {
    private static final ResourceLocation MOON = StationWarpGameTests.MOON;
    private static final StationRocketAuthority NOTHING_IN_MOTION = StationWarpGameTests.NOTHING_IN_MOTION;
    private static final int COMMIT_DELAY = StationWarpGameTests.COMMIT_DELAY;

    private StationWarpAbortGameTests() {
    }

''' + body + '''    private static String last(List<String> replies) {
        return StationWarpGameTests.last(replies);
    }

    private static void expect(GameTestHelper helper, List<String> replies, StationManagementCode code, String label) {
        StationWarpGameTests.expect(helper, replies, code, label);
    }
}
'''
new_class = new_class.replace('        Fixture fixture = new Fixture(', '        StationWarpGameTests.Fixture fixture = new StationWarpGameTests.Fixture(')
new_class = new_class.replace('        Fixture first = new Fixture(', '        StationWarpGameTests.Fixture first = new StationWarpGameTests.Fixture(')
new_class = new_class.replace('        Fixture second = new Fixture(', '        StationWarpGameTests.Fixture second = new StationWarpGameTests.Fixture(')
new_class = new_class.replace('for (Fixture fixture : List.of(first, second))', 'for (StationWarpGameTests.Fixture fixture : List.of(first, second))')
(G / 'StationWarpAbortGameTests.java').write_text(new_class, encoding='utf-8', newline='\n')
print('ok', len(s.splitlines()), len(new_class.splitlines()))
