"""C5: archive both final independent reviews into docs/work/v1.5.0-closure and list them in evidence-archives.json.

Run after archive_evidence.py (which writes evidence-archives.json) and before --finalize.
"""
import hashlib
import json
import zipfile
from pathlib import Path

OUT = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-closure')
TEMP = Path('C:/Users/Administrator/AppData/Local/Temp')
REVIEWS = [
    ('independent-review-final-a', TEMP / 'arce-v150-final-a-review-6572801cef844e679252e3ea7bd650e4',
     ('tree-', 'ev/', 'gen-orig/'),
     'Final review area A (authority and persistence): report, mutation tables and logs, probes, scripts. '
     'Excluded: exported trees, re-extracted evidence copies, generated-file copies.'),
    ('independent-review-final-b', TEMP / 'arce-v150-final-b-review-bafb0541855b40a4aeea9990e4e52684',
     ('tree-', 'mut/', 'forge-src/', 'mc/', 'gen-pristine/', 'sky-root/', 'sky-review/', 'station-review2/',
      'orbit-review/', 'mig/', 'native2/'),
     'Final review area B (sky, MIG-01a, ORBIT-02/04, STATION-03/04): report, mutation tables and logs, scripts. '
     'Excluded: exported trees, the mutation tree, decompiled Minecraft/Forge sources and re-extracted evidence.'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


index_path = OUT / 'evidence-archives.json'
index = json.loads(index_path.read_text(encoding='utf-8'))
names = {row['name'] for row in index['archives']}
for name, source, excluded, scope in REVIEWS:
    assert name + '.zip' not in names, name
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sorted(source.rglob('*')):
            relative = path.relative_to(source).as_posix()
            if any(relative.startswith(prefix) for prefix in excluded) or '__pycache__/' in relative:
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                data = path.read_bytes()
                assert b'package net.minecraft' not in data and b'package net.minecraftforge' not in data, relative
                bundle.writestr(zipfile.ZipInfo(relative, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
    assert any(row['path'] == 'REVIEW.md' for row in rows), name
    (OUT / (name + '-files.json')).write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n', encoding='utf-8',
                                              newline='\n')
    raw = (OUT / (name + '.zip')).read_bytes()
    index['archives'].append({'name': name + '.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
                              'manifest': name + '-files.json', 'source_directory': str(source),
                              'excluded': list(excluded), 'scope': scope})
    print(name, len(rows), 'members', len(raw), 'bytes')
index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
