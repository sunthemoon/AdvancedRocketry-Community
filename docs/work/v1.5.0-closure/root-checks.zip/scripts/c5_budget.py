from pathlib import Path

S = Path('D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity')


def edit(rel, pairs):
    path = S / rel
    s = path.read_text(encoding='utf-8')
    for old, new in pairs:
        assert s.count(old) == 1, (rel, old[:100])
        s = s.replace(old, new)
    path.write_text(s, encoding='utf-8', newline='\n')


edit('station/service/StationManagementCode.java', [
    ('''    NOT_LOCAL_PLAYER(false, "run this command yourself as a connected player;"
            + " command blocks, functions, signs and /execute cannot manage stations"),''',
     '''    NOT_LOCAL_PLAYER(false, "run this command yourself as a connected player;"
            + " command blocks, functions, signs, the console and /execute run by anyone else cannot"
            + " manage stations"),
    REGISTRY_BUSY(false, "the station registry is saving another change; try again in a few seconds"),'''),
])

edit('station/persistence/StationRegistrySavedData.java', [
    ('''    private int recordCount() {''', '''    /** Committed stations plus pending reservations (0 while blocked). */
    public int recordCount() {'''),
])

edit('station/service/StationGravityService.java', [
    ('''    private final StationAccessService access;
    private final StationWriteCooldown cooldown = new StationWriteCooldown(WRITE_COOLDOWN_TICKS);

    public StationGravityService(StationAccessService access) {
        this.access = Objects.requireNonNull(access, "access");
    }''', '''    private final StationAccessService access;
    private final StationWriteBudget budget;
    private final StationWriteCooldown cooldown = new StationWriteCooldown(WRITE_COOLDOWN_TICKS);

    public StationGravityService(StationAccessService access, StationWriteBudget budget) {
        this.access = Objects.requireNonNull(access, "access");
        this.budget = Objects.requireNonNull(budget, "budget");
    }'''),
    ('''        if (!cooldown.ready(observed.stationId(), server.getTickCount())) {
            return audit(player, StationManagementResult.of(StationManagementCode.GRAVITY_COOLDOWN, observed));
        }''', '''        if (!cooldown.ready(observed.stationId(), server.getTickCount())) {
            return audit(player, StationManagementResult.of(StationManagementCode.GRAVITY_COOLDOWN, observed));
        }
        if (!budget.ready(server.getTickCount(), data.recordCount())) {
            return audit(player, StationManagementResult.of(StationManagementCode.REGISTRY_BUSY, observed));
        }'''),
    ('''            cooldown.record(observed.stationId(), server.getTickCount());
        }''', '''            cooldown.record(observed.stationId(), server.getTickCount());
            budget.record(server.getTickCount());
        }'''),
])

edit('station/service/StationExpansionService.java', [
    ('''    private final StationAccessService access;
    private final StationExpansionConfirmations confirmations = new StationExpansionConfirmations();

    public StationExpansionService(StationAccessService access) {
        this.access = Objects.requireNonNull(access, "access");
    }''', '''    private final StationAccessService access;
    private final StationWriteBudget budget;
    private final StationExpansionConfirmations confirmations = new StationExpansionConfirmations();

    public StationExpansionService(StationAccessService access, StationWriteBudget budget) {
        this.access = Objects.requireNonNull(access, "access");
        this.budget = Objects.requireNonNull(budget, "budget");
    }'''),
    ('''        StationLocalActor.Located actor = StationLocalActor.locate(access, player, issuedByPlayer);
        if (actor.code() != null) {
            return audit("confirm", player, StationManagementResult.of(actor.code(), actor.station()));
        }''', '''        StationLocalActor.Located actor = StationLocalActor.locate(access, player, issuedByPlayer);
        if (actor.code() != null) {
            return audit("confirm", player, StationManagementResult.of(actor.code(), actor.station()));
        }
        // Server-wide write spacing (review B9): refused before take(), so the confirmation stays usable.
        if (!budget.ready(server.getTickCount(), actor.authority().recordCount())) {
            return audit("confirm", player, StationManagementResult.of(StationManagementCode.REGISTRY_BUSY,
                    actor.station()));
        }'''),
    ('''        StationRegistrySavedData.CheckedUpdate written;
        try {
            written = data.checkedExpand(server, observed);''', '''        StationRegistrySavedData.CheckedUpdate written;
        budget.record(server.getTickCount());
        try {
            written = data.checkedExpand(server, observed);'''),
])

edit('station/service/StationManager.java', [
    ('''    private final StationExpansionService expansion = new StationExpansionService(access);
    private final StationGravityService gravity = new StationGravityService(access);''',
     '''    private final StationExpansionService expansion;
    private final StationGravityService gravity;'''),
    ('''    public StationManager(CelestialCatalogManager celestialCatalogs) {
        this.celestialCatalogs = Objects.requireNonNull(celestialCatalogs, "celestialCatalogs");''',
     '''    public StationManager(CelestialCatalogManager celestialCatalogs) {
        this(celestialCatalogs, StationWriteBudget.unbounded());
    }

    /** {@code writeBudget} is shared with the warp service: one server-wide spacing for checked writes. */
    public StationManager(CelestialCatalogManager celestialCatalogs, StationWriteBudget writeBudget) {
        this.celestialCatalogs = Objects.requireNonNull(celestialCatalogs, "celestialCatalogs");
        this.expansion = new StationExpansionService(access, writeBudget);
        this.gravity = new StationGravityService(access, writeBudget);'''),
])

edit('station/warp/StationWarpService.java', [
    ('''    public StationWarpService(CelestialCatalogManager catalogs, Predicate<ResourceLocation> systemHasRoutes,
                              Supplier<WarpSettings> settings) {
        this.catalogs = Objects.requireNonNull(catalogs, "catalogs");''', '''    public StationWarpService(CelestialCatalogManager catalogs, Predicate<ResourceLocation> systemHasRoutes,
                              Supplier<WarpSettings> settings) {
        this(catalogs, systemHasRoutes, settings, StationWriteBudget.unbounded());
    }

    /** {@code writeBudget} is shared with station expansion and gravity (review B9). */
    public StationWarpService(CelestialCatalogManager catalogs, Predicate<ResourceLocation> systemHasRoutes,
                              Supplier<WarpSettings> settings, StationWriteBudget writeBudget) {
        this.writeBudget = Objects.requireNonNull(writeBudget, "writeBudget");
        this.catalogs = Objects.requireNonNull(catalogs, "catalogs");'''),
    ('''    private volatile StationRocketAuthority rocketAuthority = StationRocketAuthority.FAIL_CLOSED;''',
     '''    private volatile StationRocketAuthority rocketAuthority = StationRocketAuthority.FAIL_CLOSED;
    private final StationWriteBudget writeBudget;'''),
    ('''        countdowns.nextDue(now).ifPresent(countdown -> {
            countdowns.cancel(countdown.quote().stationId());
            commit(server, countdown.quote());
        });''', '''        // A due countdown also waits for the server-wide write spacing (review B9); it stays due.
        countdowns.nextDue(now)
                .filter(countdown -> writeBudget.ready(now, StationRegistrySavedData.get(server).recordCount()))
                .ifPresent(countdown -> {
                    countdowns.cancel(countdown.quote().stationId());
                    commit(server, countdown.quote());
                });'''),
    ('''            // A failing disk is not retried every tick (ADR-041 cooldown).
            cooldown.record(confirmed.stationId(), server.getTickCount());''', '''            // A failing disk is not retried every tick (ADR-041 cooldown).
            cooldown.record(confirmed.stationId(), server.getTickCount());
            writeBudget.record(server.getTickCount());'''),
])

edit('station/service/StationRuntime.java', [])

edit('config/CommonConfig.java', [
    ('''    public static final ForgeConfigSpec SPEC = BUILDER.build();''', '''    public static final ForgeConfigSpec.IntValue CHECKED_WRITE_TICKS_PER_100_STATIONS = BUILDER
            .comment(
                    "Server-wide spacing between checked station writes (expansion, gravity, warp commit),",
                    "in ticks per 100 registry records: each such write rewrites the whole station file.",
                    "3 allows one write about every 6 seconds at 4,096 stations; 0 disables the spacing."
            )
            .defineInRange("stations.checkedWriteTicksPer100Stations", 3, 0, 100);

    public static final ForgeConfigSpec SPEC = BUILDER.build();'''),
    ('''    private CommonConfig() {
    }''', '''    /** Current checked-write spacing; the default until the COMMON config is loaded. */
    public static int checkedWriteTicksPer100Stations() {
        return SPEC.isLoaded() ? CHECKED_WRITE_TICKS_PER_100_STATIONS.get()
                : CHECKED_WRITE_TICKS_PER_100_STATIONS.getDefault();
    }

    private CommonConfig() {
    }'''),
])

edit('AdvancedRocketryCommunity.java', [
    ('''        stationManager = new StationManager(celestialCatalogs);''',
     '''        stationWriteBudget = new StationWriteBudget(CommonConfig::checkedWriteTicksPer100Stations);
        stationManager = new StationManager(celestialCatalogs, stationWriteBudget);'''),
    ('''        stationWarp = new StationWarpService(celestialCatalogs,
                StationWarpService.routesInSystem(planetaryCatalogs), CommonConfig::warpSettings);''',
     '''        stationWarp = new StationWarpService(celestialCatalogs,
                StationWarpService.routesInSystem(planetaryCatalogs), CommonConfig::warpSettings, stationWriteBudget);'''),
    ('''    private final StationWarpService stationWarp;''', '''    private final StationWarpService stationWarp;
    private final StationWriteBudget stationWriteBudget;'''),
    ('''        stationManager.clear();
        stationWarp.clear();''', '''        stationManager.clear();
        stationWarp.clear();
        stationWriteBudget.clear();'''),
    ('''import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextService;
''', '''import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextService;
import io.github.sunthemoon.advancedrocketrycommunity.station.service.StationWriteBudget;
'''),
])
print('ok')
