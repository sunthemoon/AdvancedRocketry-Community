"""C5 mutation checks for the final-review fixes. Usage: c5_mutate.py <E>."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

E = Path(sys.argv[1]) / 'mutations'
E.mkdir(parents=True, exist_ok=True)
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
S = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'
env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

JUNIT = [
    ('A1-scan-every-record', S / 'rocket/server/RocketTransferRecoveryService.java',
     '''        int index = Math.floorMod(cursor, unclassified.size());
        RocketTransferRecord candidate = unclassified.get(index);''',
     '''        int index = Math.floorMod(cursor, unclassified.size());
        for (int probe = 0; probe < unclassified.size(); probe++) {
            if (loaded.test(unclassified.get(probe))) {
                index = probe;
                break;
            }
        }
        RocketTransferRecord candidate = unclassified.get(index);''',
     ['--tests', '*RocketTransferRecoverySelectionTest']),
    ('A2-kill-switch-ignored', S / 'config/CommonConfig.java',
     '''return new WarpSettings(WARP_ENABLED.get(), WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());''',
     '''return new WarpSettings(true, WARP_COST_IN_SYSTEM.get(), WARP_COST_INTERSTELLAR.get());''',
     ['--tests', '*CommonConfigWiringTest']),
    ('B9-budget-never-spaces', S / 'station/service/StationWriteBudget.java',
     '''        return (long) records * ticksPer100Stations / 100L;''', '''        return 0L;''',
     ['--tests', '*StationWriteBudgetTest']),
]
GAMETEST = [
    ('A3-remove-uuid-wrong-member', S / 'station/command/StationCommands.java',
     '''                stationId,
                member
        ), "Member " + member + " removed immediately");''',
     '''                stationId,
                actor.getUUID()
        ), "Member " + member + " removed immediately");'''),
    ('A5-elevator-audit-removed', S / 'station/elevator/ElevatorEndpointService.java',
     '''        AdvancedRocketryCommunity.LOGGER.info(
                "ARCE_STATION_ELEVATOR_CHECK''', '''        if (false) AdvancedRocketryCommunity.LOGGER.info(
                "ARCE_STATION_ELEVATOR_CHECK'''),
    ('A7-diagnostics-fold', S / 'station/warp/StationWarpService.java',
     '''        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        long now = server.getTickCount();''', '''        fold(server);
        StationRegistrySavedData data = StationRegistrySavedData.get(server);
        long now = server.getTickCount();'''),
    ('B9-gravity-ignores-budget', S / 'station/service/StationGravityService.java',
     '''        if (!budget.ready(server.getTickCount(), data.recordCount())) {''', '''        if (false) {'''),
]


def apply(path, old, new):
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (path, 'anchor', old[:60])
    path.write_bytes(text.replace(old, new).encode('utf-8'))


results = []
for name, path, old, new, tests in JUNIT:
    original = path.read_bytes()
    try:
        apply(path, old, new)
        with open(E / f'{name}.log', 'wb') as log:
            code = subprocess.call(['sh', './gradlew', 'test', *tests], cwd=ROOT, env=env, stdout=log,
                                   stderr=subprocess.STDOUT)
    finally:
        path.write_bytes(original)
    results.append(f'{name}\t{"KILLED" if code else "SURVIVED"}\texit={code}')
    print(results[-1], flush=True)

originals = {}
try:
    for name, path, old, new in GAMETEST:
        originals.setdefault(path, path.read_bytes())
        apply(path, old, new)
    with open(E / 'gametest-combined.log', 'wb') as log:
        code = subprocess.call(['sh', './gradlew', 'runGameTestServer'], cwd=ROOT, env=env, stdout=log,
                               stderr=subprocess.STDOUT)
finally:
    for path, data in originals.items():
        path.write_bytes(data)
shutil.copy(ROOT / 'build/gametest/logs/latest.log', E / 'gametest-combined-latest.log')
results.append(f'gametest-combined({",".join(n for n, *_ in GAMETEST)})\texit={code}')
print(results[-1], flush=True)
(E / 'mutation-results.tsv').write_text('\n'.join(results) + '\n', encoding='utf-8', newline='\n')
