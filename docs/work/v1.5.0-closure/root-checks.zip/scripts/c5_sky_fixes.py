from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
S = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'


def edit(path, pairs):
    s = path.read_text(encoding='utf-8')
    for old, new in pairs:
        assert s.count(old) == 1, (path.name, old[:100])
        s = s.replace(old, new)
    path.write_text(s, encoding='utf-8', newline='\n')


(S / 'station/orbit/StationSkyContextRuntime.java').write_text('''package io.github.sunthemoon.advancedrocketrycommunity.station.orbit;

import java.util.Objects;
import java.util.Optional;

/**
 * Holds the one registered station sky context service, installed once at mod construction and kept
 * across integrated-server sessions (the service clears its own state at stop). GameTests use it to
 * observe the production wiring (final v1.5 review B1).
 */
public final class StationSkyContextRuntime {
    private static volatile StationSkyContextService service;

    private StationSkyContextRuntime() {
    }

    public static void install(StationSkyContextService installed) {
        service = Objects.requireNonNull(installed, "installed");
    }

    public static Optional<StationSkyContextService> service() {
        return Optional.ofNullable(service);
    }
}
''', encoding='utf-8', newline='\n')

edit(S / 'station/orbit/StationSkyContextService.java', [
    ('''    /** The context for one player: the orbit body of the committed station region they stand in. */
    public static Optional<ResourceLocation> contextFor(MinecraftServer server, StationRegistrySavedData data,
                                                        ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (!data.operational() || !level.dimension().equals(CelestialIds.SPACE_LEVEL)
                || server.getLevel(CelestialIds.SPACE_LEVEL) != level) {
            return Optional.empty();
        }
        return data.findAt(player.getBlockX(), player.getBlockZ()).map(StationState::orbitBody);
    }''', '''    /** The context for one player: the orbit body of the committed station region they stand in. */
    public static Optional<ResourceLocation> contextFor(MinecraftServer server, StationRegistrySavedData data,
                                                        ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        boolean inSpace = level.dimension().equals(CelestialIds.SPACE_LEVEL)
                && server.getLevel(CelestialIds.SPACE_LEVEL) == level;
        return contextFor(data, inSpace, player.getBlockX(), player.getBlockZ());
    }

    /**
     * The same rule without a server: none outside Space or while the registry is blocked. A
     * quarantined registry still resolves stations, as every read does (quarantine blocks checked
     * updates only).
     */
    public static Optional<ResourceLocation> contextFor(StationRegistrySavedData data, boolean inSpace, int x, int z) {
        if (!inSpace || !data.operational()) {
            return Optional.empty();
        }
        return data.findAt(x, z).map(StationState::orbitBody);
    }'''),
    ('''    /** One pass over the online players; returns the number of messages sent. */''',
     '''    /**
     * One pass over the online players; returns the number of messages sent. Nothing in the loop can
     * throw for a valid registry (orbit IDs are already bounded by the station record), so there is
     * no per-player isolation (final review B3, rev-1 F8).
     */'''),
    ('''    public int trackedPlayers() {
        return sent.size();
    }''', '''    public int trackedPlayers() {
        return sent.size();
    }

    /** Whether the player has an entry, i.e. a pass has run since their login, respawn or Level change. */
    public boolean tracked(UUID playerId) {
        return sent.containsKey(playerId);
    }

    /** The last context sent to (or recorded for) the player; empty when untracked or "none". */
    public Optional<ResourceLocation> lastSent(UUID playerId) {
        Optional<ResourceLocation> last = sent.get(playerId);
        return last == null ? Optional.empty() : last;
    }'''),
])

edit(S / 'AdvancedRocketryCommunity.java', [
    ('''        StationSkyContextService skyContexts = new StationSkyContextService(celestialNetwork::sendSkyContext);
''', '''        StationSkyContextService skyContexts = new StationSkyContextService(celestialNetwork::sendSkyContext);
        StationSkyContextRuntime.install(skyContexts);
'''),
    ('''import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextService;
''', '''import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextService;
'''),
])

edit(S / 'celestial/network/CelestialNetwork.java', [
    ('''        channel.messageBuilder(StationSkyContextPacket.class, 1, NetworkDirection.PLAY_TO_CLIENT)''',
     '''        // ADR-047: must run on the client main thread, so it is queued after the vanilla respawn handling
        // that fires ClientPlayerNetworkEvent.Clone (which clears the context); NetworkProtocolPinTest pins it.
        channel.messageBuilder(StationSkyContextPacket.class, 1, NetworkDirection.PLAY_TO_CLIENT)'''),
])

# B2: pin main-thread handling for every registered message.
edit(ROOT / 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/network/NetworkProtocolPinTest.java', [
    ('''                Matcher message = MESSAGE.matcher(source);
                int messages = 0;
                while (message.find()) {''', '''                Matcher message = MESSAGE.matcher(source);
                int messages = 0;
                while (message.find()) {
                    // Every handler runs on the main thread (ADR-047 relies on it for message ordering).
                    int end = source.indexOf(".add()", message.end());
                    assertTrue(end > 0 && source.substring(message.end(), end).contains(".consumerMainThread("),
                            "Not handled on the main thread: " + message.group(1) + " in " + file);'''),
])
print('ok')
