"""Read-only independent MIG-02 audit; reuse bounded byte decoders, not harness verdicts."""
import copy, hashlib, json, re, sys, uuid, zipfile
from pathlib import Path
REPO=Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0,str(REPO))
from scripts import run_v140_celestial_schema_smoke as codec
from scripts import run_v130_adapter_flight_smoke as entity_codec
region=entity_codec.region_nbt
OUT=Path(__file__).parent
BASE=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
N=BASE/'native-final'
H='advancedrocketrycommunity'
PHASES=['legacy-copy','upgrade-remove','removed-restore','restored-restart']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def uid(a): return str(uuid.UUID(int=int.from_bytes(b''.join((n&0xffffffff).to_bytes(4,'big') for n in a),'big')))
def keyed(rows,key):
    result={uid(r[key]):r for r in rows}
    assert len(result)==len(rows)
    return result
def state(folder, closed=True):
    result={}
    for k in ['satellite_missions','celestial','stations']:
        p=folder/(H+'_'+k+'.dat')
        result[k]=codec.read_nbt(p)['data'] if p.exists() else None
    result['bindings']=js(folder/'bindings.json') if (folder/'bindings.json').exists() else None
    if closed:
        raw=(folder/'terminal-region.mca').read_bytes()
        chunk=region._decode_chunk(region._region_chunk(raw,16,16),16,16)
        entries=[b for b in chunk['block_entities'] if [b.get(x) for x in ['x','y','z']]==[264,101,264]]
        assert len(entries)==1 and entries[0]['id']==H+':satellite_terminal'
        result['terminal']=entries[0]['SatelliteTerminal']
    else:
        assert not (folder/'terminal-region.mca').exists()
    assert result==js(folder/'decoded.json'), str(folder)
    p=folder/'transfers.dat'
    if p.exists():
        j=entity_codec.read_transfers(p)
        assert j['schema_version']==2 and j['transfers']==[]
    return result
def normalize(s):
    s=copy.deepcopy(s); s.pop('terminal',None)
    c=s['satellite_missions'].pop('clock')
    assert set(c)=={'last_observed_game_time','logical_game_time'} and all(type(v) is int and v>=0 for v in c.values())
    return s
report={'checks':[],'phases':{}}
manifest={}
for line in (N/'SHA256SUMS').read_text().splitlines():
    digest,rel=line.split('  ',1)
    assert rel not in manifest and (N/rel).resolve().is_relative_to(N.resolve())
    assert sha(N/rel)==digest, rel
    manifest[rel]=digest
assert set(manifest)=={p.relative_to(N).as_posix() for p in N.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
report['manifest']={'entries':len(manifest),'sha256':sha(N/'SHA256SUMS')}
summary=js(N/'summary.json')
artifacts=summary['artifacts']
expected=['d1f9f564ed1dcd1df7ac0648b4091a07dfa9a02f63b36b827f36aad591224475',
          'e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47',
          '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475']
for item,digest in zip(artifacts,expected,strict=True):
    p=Path(item['path']); assert sha(p)==digest==item['sha256'] and p.stat().st_size==item['bytes']
    with zipfile.ZipFile(p) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        assert item['version'] in z.read('META-INF/mods.toml').decode()
report['artifacts']=artifacts
source=Path(js(N/'source-provenance.json')['source'])
inventory=js(N/'source-world-files.json')
assert len(inventory)==34
for p in [source,N/'original-world']:
    assert {q.relative_to(p).as_posix() for q in p.rglob('*') if q.is_file()}=={r['path'] for r in inventory}
    for r in inventory:
        assert sha(p/r['path'])==r['sha256'] and (p/r['path']).stat().st_size==r['bytes']
assert js(N/'original-unchanged.json')=={'unchanged':True}
report['source']={'path':str(source),'files':len(inventory),'bytes':sum(r['bytes'] for r in inventory),'manifest_sha256':sha(N/'source-world-files.json')}
hist=source.parents[1]/'runtime-final'
for line in (hist/'SHA256SUMS').read_text().splitlines():
    digest,rel=line.split('  ',1); assert sha(hist/rel)==digest
h=js(hist/'summary.json')
assert [a['sha256'] for a in h['artifacts']]==expected[:2]
for rel,r in h['cycles'][-1]['disk_evidence'].items():
    assert sha(source/Path(rel).relative_to('world'))==r['sha256']
report['historical_manifest_entries']=len((hist/'SHA256SUMS').read_text().splitlines())
original=state(N/'original-state')
states={p:state(N/p/'state') for p in PHASES}
live={k:state(N/p/k/'state',False) for p,ks in [('upgrade-remove',['before-new-work']),('removed-restore',['before-restoration','automatic-restoration'])] for k in ks}
for p,k in [('upgrade-remove','before-new-work'),('removed-restore','before-restoration'),('removed-restore','automatic-restoration')]:
    assert not (N/p/k/'native').exists()
old=original['satellite_missions']
assert len(old['missions'])==2 and len(old['satellites'])==len(old['research_accounts'])==1
assert [(a['balance'],a['lifetime_earned'],a['lifetime_spent']) for a in old['research_accounts']]==[(337,348,11)]
assert original['celestial']['bodies']==[{'id':H+':earth','discovered_at':461}]
for s in list(states.values())+list(live.values()):
    for name,key in [('missions','mission_id'),('satellites','satellite_id'),('research_accounts','owner_id')]:
        before,after=keyed(old[name],key),keyed(s['satellite_missions'][name],key)
        assert all(after[k]==v for k,v in before.items())
    assert original['celestial']['bodies'][0] in s['celestial']['bodies']
    assert all('visited_at' not in b and 'first_visited_at' not in b for b in s['celestial']['bodies'])
for s in states.values(): assert s['terminal']==original['terminal']
assert original['terminal']['energy']==9000 and original['terminal']['last_result']==9
assert original['terminal']['inventory']['Items'][0]=={'Slot':2,'Count':1,'id':'minecraft:amethyst_shard'}
assert states['legacy-copy']['bindings'] is None
expected_bindings={'schema_version':1,'bindings':sorted([{'body_id':H+':'+name,**({'level':level} if level else {})} for name,level in [('earth','minecraft:overworld'),('moon',H+':moon'),('space',H+':space'),('mars',H+':mars'),('venus',H+':venus'),('gas_giant',None)]],key=lambda b:b['body_id'])}
for s in [*list(states.values())[1:],*live.values()]: assert s['bindings']==expected_bindings
upgraded=normalize(live['before-new-work']); old_copy=normalize(states['legacy-copy']); old_copy['bindings']=expected_bindings
assert upgraded==old_copy
assert normalize(states['upgrade-remove'])==normalize(live['before-restoration'])
new_owner='00000000-0000-0000-0000-000000000005'
mission_by_body={m['body']:m for m in summary['research']}
for name,s in [('pending',states['upgrade-remove']),('waiting',live['before-restoration']),('automatic',live['automatic-restoration']),('restored',states['removed-restore']),('restart',states['restored-restart'])]:
    reg=s['satellite_missions']; ms=keyed(reg['missions'],'mission_id'); sats=keyed(reg['satellites'],'satellite_id'); accts=keyed(reg['research_accounts'],'owner_id')
    assert len(ms)==4 and len(sats)==3 and len(accts)==2
    a=accts[new_owner]; assert (a['balance'],a['lifetime_earned'],a['lifetime_spent'])==(40,240,200)
    waiting=name in ['pending','waiting']
    assert {b['id'] for b in s['celestial']['bodies']}=={H+':earth',H+':mars'}|({H+':venus'} if not waiting else set())
    for body,m in mission_by_body.items():
        r=ms[m['mission']]; sat=sats[m['satellite']]
        assert r['schema_version']==sat['schema_version']==a['schema_version']==1
        assert uid(r['owner_id'])==uid(sat['owner_id'])==new_owner and uid(r['satellite_id'])==m['satellite']
        assert r['definition_id']==sat['definition_id']==H+':data_satellite' and r['target_body_id']==body
        assert (r['completes_at'],r['started_at'],r['research_yield'],r['discovery_cost'],r['discovery_required'])==(830,630,120,100,1)
        pending=waiting and body==H+':venus'
        assert r['status']==('claim_pending_discovery' if pending else 'claimed')
        assert (uid(sat['current_mission_id'])==m['mission']) if pending else ('current_mission_id' not in sat)
pending=normalize(states['upgrade-remove']); complete=normalize(live['automatic-restoration'])
delta=copy.deepcopy(pending)
vm=mission_by_body[H+':venus']
next(m for m in delta['satellite_missions']['missions'] if uid(m['mission_id'])==vm['mission'])['status']='claimed'
next(s for s in delta['satellite_missions']['satellites'] if uid(s['satellite_id'])==vm['satellite']).pop('current_mission_id')
venus=next(b for b in complete['celestial']['bodies'] if b['id']==H+':venus')
assert set(venus)=={'id','discovered_at'} and venus['discovered_at']>=0
delta['celestial']['bodies'].append(venus)
assert delta==complete
assert complete==normalize(states['removed-restore'])==normalize(states['restored-restart'])
moon=states['legacy-copy']['stations']['stations']; assert len(moon)==1 and moon[0]['orbit_body']==H+':moon'
for s in list(states.values())[1:]:
    assert moon[0] in s['stations']['stations'] and len(s['stations']['stations'])==2 and not s['stations']['reservations']
    assert {b['orbit_body'] for b in s['stations']['stations']}=={H+':mars',H+':moon'}
assert states['upgrade-remove']['stations']==states['removed-restore']['stations']==states['restored-restart']['stations']
report['authority']={'original_missions':2,'total_missions':4,'original_account':[337,348,11],'new_account':[40,240,200],'terminal':original['terminal'],'venus_discovery':venus,'mars_discovery':next(b for b in complete['celestial']['bodies'] if b['id']==H+':mars'),'stations':states['restored-restart']['stations'],'bindings':expected_bindings}
rockets=[]; snbts=[]; configs=[]
for phase in PHASES:
    folder=N/phase; obs=js(folder/'observations.json'); launch=js(folder/'launch.json'); commands=js(folder/'commands.json')
    assert obs['exit_code']==0 and commands[-1]=='stop'
    index=0 if phase=='legacy-copy' else 2
    assert launch['artifact']==artifacts[index] and '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
    assert Path(launch['cwd'])==Path(summary['server'])
    texts={f:(folder/f).read_text(encoding='utf-8') for f in ['stdout.txt','latest.log','debug.log']}
    logs={}
    for f,text in texts.items():
        lines=text.splitlines(); errors=[l for l in lines if re.search(r'/(ERROR|FATAL)\]',l)]
        if phase=='removed-restore':
            assert len(errors)==1 and errors[0].endswith('ARCE_STATION_UNKNOWN_ORBIT_BODY station=bca68d47-9961-4f2d-b798-26ffab48a74e')
        else: assert not errors,(phase,f,errors)
        assert 'NoClassDefFoundError' not in text and 'Exception in thread' not in text
        logs[f]={'warnings':sum(bool(re.search(r'/WARN\]',l)) for l in lines),'errors':errors,'lag':[l for l in lines if "Can't keep up" in l]}
    assert 'Done (' in texts['stdout.txt'] and 'Saved the game' in texts['stdout.txt'] and 'Stopping server' in texts['stdout.txt']
    entities=[]; file_count=chunks=0
    for p in sorted((folder/'native/world').rglob('r.*.*.mca')):
        assert p.parent.name=='entities'; raw=p.read_bytes(); file_count+=1
        if not raw: continue
        assert len(raw)>=8192
        rx,rz=map(int,p.name.split('.')[1:3])
        for i in range(1024):
            if raw[i*4:i*4+4]==bytes(4): continue
            chunks+=1; x,z=rx*32+i%32,rz*32+i//32
            root=entity_codec.decode_entities(region._region_chunk(raw,x,z),x,z)
            entities.extend(e for e in root['Entities'] if e.get('id')==H+':rocket')
    assert len(entities)==1
    e=entities[0]; rocket=e['RocketEntityData']; flight=rocket['flight_data']; snapshot=rocket['snapshot']
    assert uid(e['UUID'])=='aad40ec8-f39d-4c00-9a0d-e07861618da0' and e['Pos']==[520.5,101.0,520.5]
    assert uid(rocket['owner_id'])==new_owner and uid(rocket['assembly_transaction_id'])==uid(flight['logical_rocket_id'])=='edff1e56-3c2c-4645-b2dd-aa7f392965d5'
    assert flight['state']=='FUELED' and flight['fuel']=={'amount':2000,'capacity':2000,'committed_debits':[]} and 'plan' not in flight and 'active_transfer_id' not in flight
    assert flight['current_body']==H+':earth' and flight['current_target']=={'schema_version':1,'type':H+':body_surface','body_id':H+':earth'}
    payloads=[b['block_entity'] for b in snapshot['relative_blocks'] if 'block_entity' in b]
    assert len(snapshot['relative_blocks'])==6 and len(payloads)==1 and payloads[0]=={'adapter':H+':vanilla_container_v1','data':{'Items':[{'Slot':0,'id':'minecraft:diamond','Count':17},{'Slot':1,'id':'minecraft:iron_ingot','Count':64}]}}
    assert snapshot['content_hash']==summary['reports'][0]['snapshot'] and rocket==js(folder/'native/entity-regions.json')['rocket']
    rockets.append(rocket); snbts.append((folder/'rocket-entity.snbt').read_bytes())
    props=(folder/'inputs/server.properties').read_bytes().splitlines(keepends=True)
    assert props[0]==b'#Minecraft server properties\r\n' and re.fullmatch(rb'#[A-Z][a-z]{2} .+\r\n',props[1])
    configs.append(b''.join(props[:1]+props[2:]))
    assert (folder/'inputs/eula.txt').read_text().strip()=='eula=true'
    report['phases'][phase]={'exit_code':obs['exit_code'],'commands':len(commands),'logs':logs,'runner_log_counts':obs['log_counts'],'entity_files':file_count,'entity_chunks':chunks,'level_dat_sha256':sha(folder/'inputs/world/level.dat'),'clock':states[phase]['satellite_missions']['clock']}
assert all(v==rockets[0] for v in rockets) and len(set(snbts))==1 and len(set(configs))==1
u=(N/'upgrade-remove/stdout.txt').read_text(); r=(N/'removed-restore/stdout.txt').read_text(); c=js(N/'removed-restore/commands.json')
assert u.count('Release-test satellite claim rejected: CATALOG_UNAVAILABLE')==2
for text in [u,r]:
    for marker in ['Release-test surface launch failed: INVALID_DESTINATION','Release-test station launch failed: INVALID_DESTINATION','Station creation failed: UNKNOWN_ORBIT_BODY','Release-test satellite launch rejected: TARGET_NOT_ALLOWED']:
        assert marker in text
assert c.index('reload') < c.index('arce satellite admin mission '+vm['mission']) < min(i for i,x in enumerate(c) if x.startswith('arce satellite release-test claim '))
assert re.search('mission='+vm['mission']+r' .* status=CLAIMED deadline=',r)
assert r.index('status=CLAIMED deadline=')<r.index('ARCE_RELEASE_TEST_SATELLITE_CLAIM')
for phase in ['removed-restore','restored-restart']:
    text=(N/phase/'stdout.txt').read_text(); assert text.count('code=ALREADY_CLAIMED status=CLAIMED research=40 discovered=true')==2
with zipfile.ZipFile(artifacts[0]['path']) as oldjar,zipfile.ZipFile(artifacts[2]['path']) as newjar:
    for phase in PHASES:
        pack=N/phase/'probe-pack'; meta=js(pack/'pack.mcmeta')
        for body in ['earth','moon','space']:
            rel=f'data/{H}/celestial_bodies/{body}.json'
            assert (pack/rel).read_bytes()==oldjar.read(rel)
        if phase=='upgrade-remove':
            filters=meta['filter']['block']; assert len(filters)==6
            assert js(pack/f'data/{H}/satellite_definitions/data_satellite.json')['allowed_targets']==[H+':'+b for b in ['earth','moon','space','gas_giant']]
        else: assert 'filter' not in meta
        if phase in ['removed-restore','restored-restart']:
            rel=f'data/{H}/satellite_definitions/data_satellite.json'; assert js(pack/rel)==json.loads(newjar.read(rel))
report['rocket']={'entity_uuid':uid(e['UUID']),'logical':uid(rocket['assembly_transaction_id']),'fuel':flight['fuel'],'snapshot_hash':snapshot['content_hash'],'payloads':payloads}
report['checks']=['complete manifest and artifact identity','unchanged authentic source + original-world copy','bounded raw gzip SavedData and Anvil decodes (no complete level.dat decode)','historical and new exact research authorities','live projection excludes terminal/entity files','automatic restoration before manual claim replay','closed-world native terminal and rocket conservation','station and binding identities','raw commands / logs / receipts and actual expected removed-orbit diagnostic','raw property equality except generated timestamp','exact legacy JSON and restored target inputs']
report['result']='OBSERVATIONS_VERIFIED'
(OUT/'native-final-observations.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'manifest':report['manifest'],'source':report['source'],'phases':report['phases'],'result':report['result']},indent=2))
