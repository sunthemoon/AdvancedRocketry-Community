import hashlib,json,struct,zlib
from pathlib import Path
ROOT=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
path=ROOT/'native/upgrade-remove/before-new-work/native/world/entities/r.0.-1.mca'
raw=path.read_bytes(); x,z=20,-3
index=4*((x&31)+32*(z&31));sector=int.from_bytes(raw[index:index+3],'big');count=raw[index+3]
start=sector*4096;length=struct.unpack_from('>I',raw,start)[0];compression=raw[start+4]
stream=zlib.decompressobj();out=stream.decompress(raw[start+5:start+4+length],4*1024*1024+1)
result={'capture':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
        'chunk':[x,z],'sector':sector,'sector_count':count,'allocated_end':start+count*4096,
        'declared_payload_end':start+4+length,'compression':compression,
        'zlib_eof':stream.eof,'unconsumed_tail':len(stream.unconsumed_tail),'unused_data':len(stream.unused_data),'expanded_bytes':len(out),
        'stopped_after_abort_file_same':(ROOT/'server/world/entities/r.0.-1.mca').read_bytes()==raw}
baseline=ROOT/'native/legacy-copy/native/world/entities/r.0.-1.mca'
if baseline.exists():result['clean_legacy_capture_bytes']=baseline.stat().st_size
assert result['declared_payload_end']==len(raw)<result['allocated_end']
assert compression==2 and stream.eof and not stream.unconsumed_tail and not stream.unused_data and len(out)<=4*1024*1024
(Path(__file__).parent/'active-region-observation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
