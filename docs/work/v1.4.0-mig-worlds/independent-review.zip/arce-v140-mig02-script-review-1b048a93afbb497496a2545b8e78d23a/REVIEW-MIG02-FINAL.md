# V140-MIG-02 independent script and native-evidence review

Date: 2026-09-28. Reviewer: delegated independent session, repository read-only.
Repository: `D:/GitHub/AdvancedRocketry-Community`; baseline/production HEAD
`a9143c2b62d5daab412cefedcee198f1fd032588`.

## Findings and dispositions

No unresolved correctness finding in the final reviewed Python slice. This is
a scoped conclusion about the inspected harness/oracles and actual retained
captures, not approval of the version or all migration/recovery guarantees.

1. **Resolved P2 — implicit legacy schema:** the initial helper indexed
   `schema_version` even though the pinned v1.3 body's packaged JSON omits it.
   Actual old JAR bytes reproduced the initial `KeyError`. Final
   [fixture:86-96](D:/GitHub/AdvancedRocketry-Community/scripts/v140_migration_fixture.py#L86)
   accepts the existing implicit schema-1 default and copies those exact bytes;
   [test:232](D:/GitHub/AdvancedRocketry-Community/tests/test_v140_migration_smoke.py#L232)
   covers it. No old JSON is relabeled as newly authored schema 2.
2. **Resolved P2 — dependent child validation:** the initial removal checker
   looked for `parent_id`, not the actual `parent` JSON key. An independently
   authored surviving-child mutant was incorrectly accepted by the original
   snapshot and rejected by the final helper. See
   [fixture:99-118](D:/GitHub/AdvancedRocketry-Community/scripts/v140_migration_fixture.py#L99)
   and [test:226](D:/GitHub/AdvancedRocketry-Community/tests/test_v140_migration_smoke.py#L226).
3. **Resolved setup/coverage gaps:** the witness now checks all seven actual
   assembler/rocket cells for air before placement, and removed-content checks
   include arrival at the existing Mars station, not only surface travel and
   new station creation. The command is an operator admission probe; it does
   not certify ordinary player station membership. See
   [runner:36-57](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_migration_smoke.py#L36),
   [runner:101-111](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_migration_smoke.py#L101),
   [RocketCommands:309-336](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/command/RocketCommands.java#L309),
   [RocketFlightService:301-317](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/RocketFlightService.java#L301),
   [PlanetaryFlightAdmission:70-73](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/PlanetaryFlightAdmission.java#L70),
   and [StationAccessService:21](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationAccessService.java#L21).
4. **Resolved observation-boundary failure — original native attempt retained:**
   full strict entity-region decoding was attempted while the upgraded server
   was running. The actual captured 87,350-byte file declared a sector ending
   at 90,112; its declared zlib payload ended exactly at 87,350 and independently
   decompressed completely (5,653 bytes, EOF true, no unused/unconsumed data).
   This supports the live-region observation diagnosis, not a production
   data-loss conclusion. The strict closed-region decoder was not relaxed.
   Final [fixture:131-160](D:/GitHub/AdvancedRocketry-Community/scripts/v140_migration_fixture.py#L131)
   and [runner:112-153](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_migration_smoke.py#L112)
   explicitly omit live terminal/entity regions; no expected terminal value is
   substituted as an observation. Exact native terminal and rocket checks still
   execute after each clean stop through
   [runner:185-204](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_migration_smoke.py#L185).
   The narrower projection remains exact for the saved authorities it observes.

The reader-facing verification draft accurately distinguishes these scopes and
retains the expected absent-orbit ERROR, cached root JUnit run, original failed
attempt, newly added old-runtime witnesses, and open version Gates. Evidence ZIP
assembly and final staged-byte checks remain root-owned, not independently
certified here.

## Independently executed checks

All Python commands used `PYTHONUTF8=1`, executable
`D:/python/pyenv/pyenv-win/shims/python.bat`, `-B`, and the repository working
directory. No JVM, Gradle, native server or remote process was started by this
reviewer; no tracked file/index was edited. The excluded user documentation
bundle was not accessed.

```text
python.bat -B -m unittest tests.test_v140_migration_smoke tests.test_v140_celestial_schema_smoke tests.test_v140_planetary_worlds_smoke -v
```

- Initial reviewed revision: **40 tests passed**, exit 0, unittest 1.152 s;
  `python-independent.log` / `python-result.json` retained.
- Final revision: **43 tests passed**, exit 0, unittest **1.250 s**, outer
  elapsed **1.8492978 s**. These comprise **17 new migration**, 11 schema and
  15 adjacent planetary-harness methods. Raw output: `python-final-independent.log`;
  command/exit receipt: `python-final-result.json`.
- Final source hashes before and after tests match (`final-inputs-before.json`,
  `final-inputs-after.json`). Snapshots, earlier revisions and differences remain
  in this review directory. No timeout or production persistence budget was
  expanded by the final correction.
- `probe_static.py` independently checked real old JAR bytes, orphan-parent
  rejection and actual packaged filtering. Its first helper-only expectation
  incorrectly assumed four remaining routes; the actual nine minus four yields
  five. Original failed helper/log retained; corrected actual-count check passed.
- `inspect_active_region.py` independently inspected the original failed live
  allocation and bounded compressed payload; raw results retained.
- `audit_native_final.py` reread raw native stores/regions and compared claims,
  identities, timestamps, resources and logs independently of runner predicates.
  It reuses existing bounded byte decoders, **not the new fixture's acceptance
  functions**. Final exit 0: `native-final-audit.log` and
  `native-final-observations.json`. Initial helper assumed EULA contained only
  `eula=true`; the actual generated file has the explanatory first comment line.
  Original helper/log are retained as `audit-native-final-attempt01.py` and
  `native-final-audit-attempt01.log`; correction requires the exact actual two
  lines. No captured evidence was altered.
- Read-only commands included `git rev-parse HEAD`, `git status --short`,
  `git diff --stat`, `git diff --check`, `rg`, `Get-Content`, `Get-FileHash`,
  and bounded Python JSON/ZIP/NBT/hash inspection. `git diff --check` passed for
  the tracked working diff; newly untracked task files were explicitly read and
  exercised, not inferred from that Git command. Two read-only searches used
  incorrect old helper filenames and returned missing-file diagnostics; actual
  imported helper paths were then inspected. No result depends on those misses.

## Native evidence independently observed

Evidence root:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8/native-final`.

- **269 unique manifest members**, full actual file set and every SHA-256 match;
  manifest SHA-256
  `b96d7e6930df6099400869c2e56a67fa7557262d9f4b51d0378dc20d644042a0`.
- Authentic source world and complete copied `original-world` both match the
  exact **34-file / 13,580,236-byte** inventory. Original source remains unchanged.
  The historical **48-member** SAT manifest and five originally captured files
  match. The original celestial file is available in the retained world, but
  was not in that earlier five-file archive; no retrospective archive claim.
- Four actual phases have clean stop logs and exit 0 receipts: `legacy-copy`,
  `upgrade-remove`, `removed-restore`, `restored-restart`. Their retained command
  counts are 29/22/18/8. The first uses the exact v1.3 host; the other three use
  the exact v1.4 host, with the historical API-only consumer present throughout.
  Launch receipts, mod metadata, ZIP uniqueness, artifact bytes and hashes checked.
- Bounded raw gzip stores and native Anvil terminal/entity chunks were decoded.
  Derived JSON agrees with raw data; live capture directories contain no
  terminal region or entity-region surrogate. No full `level.dat` decode was
  attempted; its four changing identities are recorded, not asserted immutable.
- The historical **two claimed missions, custom satellite, private account and
  complete terminal root** are unchanged. Account balance/earned/spent remain
  **337/348/11**; Earth discovered-at remains **461**; terminal remains **9000 FE**,
  one amethyst shard and its bound control chip, with `last_result=9` retained.
- New owner's two captured 200-tick missions retain identity, definition,
  satellite/owner binding, yield **120**, fee **100**, required-discovery bit and
  timestamps. Account remains **40/240/200** from paid pending state through
  automatic completion and claim replays. Mars discovery timestamp is **841**;
  Venus is absent while pending and added at **890**, without a visit field.
- Raw pending versus automatic/restored/restarted comparisons change only Venus
  status to claimed, clear its current-mission binding and add that discovery,
  apart from the two validated advancing scheduler-clock fields. Commands and
  raw logs show actual `CLAIMED` observation **before** any post-restore manual
  claim. Subsequent Mars/Venus claim replays each return `ALREADY_CLAIMED` and
  retain research 40 in both restored phases.
- One unchanged physical rocket is found in every closed-world entity capture;
  entity UUID `aad40ec8-f39d-4c00-9a0d-e07861618da0`, logical UUID
  `edff1e56-3c2c-4645-b2dd-aa7f392965d5`, Earth origin (520,101,520), FUELED,
  **2000/2000 fuel**, empty debit list, no active plan/transfer. Complete
  RocketEntityData and SNBT agree across processes. Six-block snapshot contains
  exactly the vanilla-container payload of **17 diamonds and 64 iron ingots**.
  Entity capture file/chunk counts: 9/16, 13/20, 13/19, 13/19.
- The Moon station is explicitly new on the old-runtime copy; the Mars station
  is new after upgrade. Exact saved fields survive removal/restoration/restart.
  Six bindings, including explicit unmapped gas and removed Mars/Venus
  reservations, remain unchanged; no rejected-arrival transfer is observed.
- Exact implicit schema-1 Earth/Moon/Space JSON from the old artifact is retained.
  Actual removal pack filters two body/four route resources and removes those
  two satellite targets; same resources restore before automatic completion.
  This removes catalog definitions, **not physical dimension registrations**.
- Configuration equality excludes only its validated generated timestamp line.
  All EULA files contain the same exact generated two lines.
- Native bracketed WARN counts are **15/11/10/10** in stdout/latest/debug.
  Each stdout also has one initial **unbracketed Log4j WARN** excluded by those
  counts. There is exactly one expected project ERROR, in `removed-restore`:
  `ARCE_STATION_UNKNOWN_ORBIT_BODY station=bca68d47-9961-4f2d-b798-26ffab48a74e`.
  No other ERROR/FATAL, client-linkage failure or timing warning was found in
  these log checks. The DEBUG-level 'Error cleaning class output directory'
  line is not an ERROR event. This is not zero-warning or performance evidence.

## Reviewed identities

| Input | SHA-256 |
|---|---|
| final fixture helper | `3b3eb7d9f31eaaf224917f953e21919724fdff6d2b8b827bc0a363588d4cbe88` |
| final runner | `0bcb639eb1e809a1aa563cb5895637735a2323c9873d53bd3e352ae8af520d66` |
| final migration tests | `5cd5da0929363f65eec7438b7d57d5e7941bc467928770c28fc473358cc36303` |
| native old v1.3 host | `d1f9f564ed1dcd1df7ac0648b4091a07dfa9a02f63b36b827f36aad591224475` |
| native historical consumer | `e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47` |
| native v1.4 host | `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475` |

The prior exploration report is preserved separately at
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig02-fixture-review-2aad456d8336465f9de97d1f511a4fdf/REVIEW-MIG02-EXPLORATION.md`
(SHA-256 `abc864f08e950e8a73d776b898b8bfc6da3c2511da484d29ebafcc35876a4a4e`).
The original native failure and raw active file remain under root's `native/`,
not relabeled as final clean process evidence.

## Remaining boundaries and recommendation

This demonstrates a representative populated **v1.3 development-world copy**,
prospective binding adoption, legacy authoring defaults, catalog removal,
retained paid pending claim, automatic same-ID restoration, and clean restart.
Existing outer SavedData schemas are already schema 2: this is not a new native
schema-1 NBT migration test or a reconstruction of historical custom mappings.
It does not prove every prior subsystem, arbitrary power-loss/crash cuts,
unloaded historical targets, ordinary player visits/terminal interaction,
station membership, network clients, GPU behavior, Linux, load, V1/V2 or S2.
No whole-world byte immutability or global background-item conservation claim.

Root reports the required short command passed (922 JUnit results restored
FROM-CACHE, 236 actually executed GameTests, DataGen 0 writes). Those Java counts
are root evidence, **not independently executed here**. This reviewer performed
the applicable forced Python key checks and raw native readback for this
Python-only slice. Recommendation: scoped MIG-02 verification is supported by
these observations, subject to root's final archive/staged-byte checks. MIG-03
interruption work and all full-version Required Gates remain separate and open.
No repository modification or release/Gate approval is made by this report.
