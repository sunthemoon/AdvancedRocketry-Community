import hashlib, importlib.util, json, sys, zipfile
from pathlib import Path
HERE=Path(__file__).parent
REPO=Path(r'D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0,str(REPO))
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=load('scripts.review_mig02_frozen',HERE/'v140_migration_fixture.py')
from scripts import v140_migration_fixture as new
baseline=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436/final-artifacts/advancedrocketry-community-1.20.1-1.3.0-dev.jar')
current=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-claims-7ff01118440047f59bae982f7891efc6/artifacts-final/advancedrocketry-community-1.20.1-1.4.0-dev.jar')
results={'inputs':{str(p):sha(p) for p in (baseline,current,REPO/'scripts/v140_migration_fixture.py',REPO/'scripts/run_v140_migration_smoke.py')}}
try:old.install_legacy_pack(HERE/'old-probe',baseline)
except KeyError as e:results['old_legacy_failure']=str(e)
else:raise AssertionError('Original missing-schema issue did not reproduce')
new.install_legacy_pack(HERE/'revised-probe',baseline)
with zipfile.ZipFile(baseline) as z:
    for body in ('earth','moon','space'):
        rel=f'data/{new.HOST}/celestial_bodies/{body}.json'
        assert (HERE/'revised-probe'/new.PACK/rel).read_bytes()==z.read(rel)
results['revised_legacy_raw_identity']=True
mutant=HERE/'orphan-resources.zip'
with zipfile.ZipFile(current) as src, zipfile.ZipFile(mutant,'w') as dst:
    for name in src.namelist():
        if name.startswith(f'data/{new.HOST}/') and name.endswith('.json') and name.split('/')[2] in ('celestial_bodies','travel_routes','satellite_definitions'):
            raw=src.read(name)
            if name.endswith('/celestial_bodies/gas_giant.json'):
                value=json.loads(raw);value['parent']=new.HOST+':mars';raw=json.dumps(value).encode()
            dst.writestr(name,raw)
old.removal_resources(mutant,True)
results['old_orphan_preflight_accepted']=True
try:new.removal_resources(mutant,True)
except new.support.SmokeError as e:results['revised_orphan_rejected']=str(e)
else:raise AssertionError('Revised parent guard still accepts orphan')
metadata,sat,routes=new.removal_resources(current,True)
assert routes==4 and len(metadata['filter']['block'])==7 and all(x not in new.REMOVED for x in sat['allowed_targets'])
results['actual_removal']={'remaining_routes':routes,'filters':metadata['filter']['block'],'satellite_targets':sat['allowed_targets']}
(HERE/'probe-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
