import hashlib, json, sys
from pathlib import Path
sys.path.insert(0,r'D:/GitHub/AdvancedRocketry-Community')
from scripts import run_v130_adapter_recovery_smoke as raw
BASE=Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436')
OUT=Path(__file__).parent
world=BASE/'server-final/world'
p=world/'region/r.0.0.mca'
chunk=raw.region_nbt._decode_chunk(raw.region_nbt._region_chunk(p.read_bytes(),16,16),16,16)
terminals=[be for be in chunk.get('block_entities',[]) if be.get('id')=='advancedrocketrycommunity:satellite_terminal']
assert len(terminals)==1
result={'terminal':terminals[0]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
entries=[f'{sha(p)}  {p.relative_to(world).as_posix()}' for p in sorted(world.rglob('*')) if p.is_file()]
(OUT/'sat-full-world-SHA256SUMS').write_text('\n'.join(entries)+'\n',encoding='utf-8')
result['world_manifest_count']=len(entries)
result['world_manifest_sha256']=sha(OUT/'sat-full-world-SHA256SUMS')
(OUT/'terminal-and-world.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
