# V140-MIG-02 fixture and removal-scenario exploration

## Findings / requirements, in priority order

No new production defect is established by this read-only preparation. The
following are concrete scenario/claim constraints, not runtime results.

1. **P2 verification hazard: removal must actually publish an absent body.**
   Earth/Moon/Space are mandatory and cannot be used as successful removal
   subjects. Celestial parents, route endpoints and satellite allowed targets
   must remain coherent. Otherwise rejection keeps an earlier catalog and an
   apparent removal test exercises nothing. The planetary pair is atomic, but
   the satellite catalog is a separate listener/publication: require successful
   receipts from both, actual absent-body and route readback, and preserved
   unrelated data. References: `CelestialCatalog.java:52-79`,
   `RouteCatalog.java:76-85`, `SatelliteCatalog.java:49-60`,
   `PlanetaryCatalogManager.java:40-60`,
   `SatelliteDefinitionReloadListener.java:39-64`,
   `AdvancedRocketryCommunity.java:239-240`; ADR-031:148-170.

2. **P2 oracle hazard: pending discovery requires a captured discovery fee.**
   Starting a mission for an already discovered body captures
   `discoveryRequired=false`; its later claim cannot prove unavailable-target
   pending recovery. Root's selected Mars/Venus plan avoids this by starting
   Venus while undiscovered. While Venus is absent, the operation returns
   **CATALOG_UNAVAILABLE**, with the paid mission persisted as
   **CLAIM_PENDING_DISCOVERY**; these are different fields. Inspect raw account
   and mission state, then restore the body and observe automatic completion
   without issuing another claim. Only afterward replay explicitly to prove no
   second credit. References: `SatelliteManager.java:493-495,510-525,466-491`,
   `DiscoveryClaimRecovery.java:19-46`,
   `SatelliteMissionRegistry.java:260-339`.

3. **P2 evidence boundary: the authentic satellite world has no old station or
   rocket witness.** Do not merge another world's SavedData and call the result
   one original historical world. Root has selected a coherent alternative:
   copy the original SAT world, boot that copy under the exact old host/consumer,
   and create explicitly new v1.3-runtime station/rocket witnesses. Preserve
   separate before/after inventories and identify their creation as preparation,
   not as objects present in the historical archive. This meets a representative
   development-artifact upgrade scope, not a previously released stable world's
   acceptance. Work-log requirement: lines 92-97; version plan sections 8-9.

4. **P3 expected diagnostics and safe refusal require precise classification.**
   Booting with the created Mars station's orbit body absent emits
   `ARCE_STATION_UNKNOWN_ORBIT_BODY station=<exact UUID>` at ERROR while retaining
   the station; it is not itself a startup refusal. Allow only that exact induced
   record/phase, not generic project ERRORs. Missing source bodies also refuse
   new launches; this is not an evacuation guarantee for physically removed
   definitions. Restoration must return the same body/Level binding, not choose
   a replacement identity. References: `StationManager.java:258-266`,
   `PlanetaryFlightAdmission.java:33-73`,
   `PlanetaryBindings.java:48-63`; ADR-031:166-170, ADR-032:34-52.

All Java references below are relative to the absolute prefix
`D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`:

| Short name | Relative file |
|---|---|
| CelestialCatalog | `celestial/service/CelestialCatalog.java` |
| RouteCatalog | `travel/route/service/RouteCatalog.java` |
| SatelliteCatalog / SatelliteDefinitionReloadListener / SatelliteManager / DiscoveryClaimRecovery | `satellite/service/<name>.java` |
| PlanetaryCatalogManager | `celestial/data/PlanetaryCatalogManager.java` |
| PlanetaryBindings | `celestial/binding/PlanetaryBindings.java` |
| PlanetaryFlightAdmission | `rocket/server/PlanetaryFlightAdmission.java` |
| SatelliteMissionRegistry | `satellite/mission/SatelliteMissionRegistry.java` |
| StationManager | `station/service/StationManager.java` |
| AdvancedRocketryCommunity | `AdvancedRocketryCommunity.java` |

## Authenticated fixture candidate

Selected original:

`C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436/server-final/world`

Historical evidence:

`C:/Users/Administrator/AppData/Local/Temp/arce-v130-sat-1790482375436/runtime-final`

Committed description:
`D:/GitHub/AdvancedRocketry-Community/docs/work/v1.3.0-satellite-payloads/VERIFICATION.md`
(scope/identity and Native dedicated observations sections). Production commit
`1216d58`, runner `24cd0d2`. Its host bytes are identical to the final v1.3
development handoff's `development-artifacts.json`; this is not a v1.4 artifact
renamed to v1.3.

| Required artifact | Bytes | Independently computed SHA-256 |
|---|---:|---|
| `advancedrocketry-community-1.20.1-1.3.0-dev.jar` | 2,352,333 | `d1f9f564ed1dcd1df7ac0648b4091a07dfa9a02f63b36b827f36aad591224475` |
| `arce-adapter-compat-test-1.0.0.jar` | 72,583 | `e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47` |

Both remain in `server-final/mods` and the historical final-artifacts directory.
Keep the exact matching consumer installed during the selected upgrade; removing
it would introduce unrelated registry/provider-uninstall behavior. API 1.7
compatibility is not a substitute for checking actual launch receipts.

Independently verified all **48** historical native manifest members. All five
final phase captured files still match the retained complete server world:
`level.dat`, terminal region `r.0.0.mca`, mission SavedData, pack metadata and the
satellite override. The full retained world has **34 files / 13,580,236 bytes**.
It has no planetary binding ledger. A newly computed complete source-world
manifest is `sat-full-world-SHA256SUMS`, SHA-256
`2327b1e7418b99f0041033a8ddf4631d368505f3524d9a316c0133c7c4dab266`.
This retrospective full-tree inventory does not mean every file was in the
original 48-member archive; in particular, the original celestial progress file
is present in the retained world but was not captured by that runner's final
five-file subset. Freeze/copy the complete world now and recheck its source hash
inventory afterward; do not reconstruct it from mixed phase captures.

Raw SavedData/Anvil decode establishes:

- Minecraft DataVersion 3465; celestial/mission stores schema 2; terminal,
  satellite, mission and account records schema 1.
- Owner `c6fcdf97-8f10-450e-ad36-67a644d23c2b`, satellite
  `bbffb4d2-b917-4547-bc4e-c0c10151c06a`, definition
  `arce_adapter_test:research_payload`. Two CLAIMED Earth missions retain
  captured durations 400 and 20 ticks, rewards 137 and 211, fee 11 and original
  identity/timestamps. Account: balance **337**, earned **348**, spent **11**.
- Existing Earth discovery timestamp **461**, no first-visit timestamp.
- Terminal at **(264,101,264)** retains **9000 FE**, one amethyst shard and one
  matching control chip. Native last_result=9 is MISSION_NOT_FOUND after cleared
  terminal mission binding, not ALREADY_CLAIMED. Record identity and inventory
  should be compared before/after upgrade without reusing fixture creation code
  at that position.

Companion candidates were inspected, not selected/mixed:

- COMPAT `.../arce-v130-compat-1790486012553/server/world`: 31 manifest entries
  verified; four final captured files match; 47 files / 16,558,081 bytes, same
  host, consumer `4207b9b3c686b7230cceaef946062f3dce8318acf587bea2263d0a990509f735`.
  Two genuine Earth/Moon stations, empty mission/account store, no binding ledger.
- Fuel `.../arce-v130-comp02-1790476198004/server/world`: 61 manifest entries
  verified; four final files match; 31 files / 16,279,017 bytes. Older genuine
  v1.3 host `6de968c9db91840078864175b7685f531e991a3e0367283a6a5d039a5dbad56e`
  has no populated mission/account/station store. Not needed for this slice.

## Minimum coherent four-process scenario

Root's proposed sequence is consistent with inspected source, subject to actual
implementation review and execution:

1. Boot a verified complete **copy** under the exact v1.3 host/consumer. Preserve
   historic terminal/progress/mission/account data; add explicitly identified
   Moon-station and rocket witnesses at disjoint coordinates using production
   old-runtime operations. Save/stop; freeze this prepared old-runtime authority.
2. Boot that copy under v1.4. Verify exact historic records and new old-runtime
   witnesses before exercising new behavior. The missing binding ledger adopts
   the current validated catalog prospectively (ADR-032), without rewriting old
   progress or station identities. Start Mars/Venus tasks before discoveries;
   claim Mars, create its station. Remove Mars/Venus celestial resources and
   dependent routes coherently, trim satellite targets, and prove both catalogs
   accepted. Assert unavailable surface and station arrivals leave rocket/fuel/
   journal authority unchanged. Claim the still-undiscovered Venus mission and
   capture paid pending state before save/stop.
3. Restart while absent: preserve historical records, Mars discovery, station,
   binding reservations and paid pending Venus receipt/account. Classify the
   exact Mars station diagnostic. Restore identical resource bytes through real
   reload; prove both catalogs accepted and queue completion occurs without a
   manual claim. Then replay claims to verify exact account totals, unchanged
   prior timestamps and no duplicate reward. No synthetic visits or disk edits
   should be used to manufacture the scenario.
4. Final clean restart: all identities, completed receipts, inventories, energy,
   fuel, station orbits/regions and binding reservations persist. Compare
   semantic authorities separately from legitimate scheduler clock and native
   world metadata changes. Preserve failures and every phase's raw log/commands,
   JAR identities, stores, relevant chunks/entities and manifests.

Use body-word tokens for existing release-test launch commands:
`SatelliteCommands.java:64-75` uses `StringArgumentType.word()`. Sending a
namespaced colon-containing token reproduces the already documented harness
parse failure, not an unavailable-target result. Native negative assertions
must distinguish command parse failure from actual production admission refusal.

The absence phase must filter lower-priority built-in resources, not merely
delete an override and reveal the packaged definition again. Retain fixed
dimension registry/world data: removing a celestial definition is not removal
of the physical Minecraft dimension. First binding adoption cannot reconstruct
unknown pre-v1.4 custom mapping history, and restoration cannot release/reassign
retired Level reservations. No schema/API change is required by this scenario.

## Checks actually performed / boundaries

Reviewed HEAD `a9143c2b62d5daab412cefedcee198f1fd032588`, branch
`codex/v1.4.0-planetary-expansion`. Initial status contained only the excluded
user bundle; it was not read. Read AGENTS, required governance/version/quality
docs, ADR-031/032/033/037/038, current MIG plan, prior v1.3 evidence and relevant
celestial/route/satellite/station/persistence/command source. Read-only commands
were `git status --short`, `git branch --show-current`, `git rev-parse HEAD`,
targeted `rg`/`Get-Content`/`Get-ChildItem` and the two helpers below. An initial
version-document filename and two glob/path assumptions failed harmlessly;
correct tracked filenames were then read. No test result is inferred from them.

With `PYTHONUTF8=1`, both commands exited **0**:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B <this directory>/inspect_fixtures.py
D:/python/pyenv/pyenv-win/shims/python.bat -B <this directory>/inspect_terminal.py
```

Raw outputs are `fixture-inspection.log`, `terminal-inspection.log`; derived
inventories are `fixtures.json`, `terminal-and-world.json`. These helpers inspect
existing bytes only; they do not run Java or invoke the runtime harness verdict.
No source, tracked/index, build or native world file was written. No Gradle,
JVM/server, remote, process termination, OpenPet or further agent was started.

This is fixture/contract exploration, not implementation review or an executed
upgrade. The selected scenario still needs reviewed code/oracles, exact copies,
and actual bounded native evidence. It does not establish genuine player visits,
S2 interruptions, arbitrary hardware failure, clients/GPU, full migration of
every subsystem, prior release approval, or any version Required Gate.
