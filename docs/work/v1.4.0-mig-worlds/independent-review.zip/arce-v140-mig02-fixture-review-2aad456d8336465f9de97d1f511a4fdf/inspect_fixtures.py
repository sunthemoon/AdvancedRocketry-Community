import hashlib, json, sys
from pathlib import Path
sys.path.insert(0, r'D:/GitHub/AdvancedRocketry-Community')
from scripts.run_v140_celestial_schema_smoke import read_nbt

BASE=Path(r'C:/Users/Administrator/AppData/Local/Temp')
OUT=Path(__file__).parent
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):h.update(b)
    return h.hexdigest()
specs=[
 ('sat','arce-v130-sat-1790482375436','server-final','runtime-final','reinstalled'),
 ('compat','arce-v130-compat-1790486012553','server','runtime-evidence','restart'),
 ('fuel','arce-v130-comp02-1790476198004','server','runtime-evidence','restart')]
output={}
for label,dirname,server,evidence,last in specs:
    root=BASE/dirname; world=root/server/'world'; ev=root/evidence
    summary=json.loads((ev/'summary.json').read_text(encoding='utf-8-sig'))
    rec={'world':str(world),'summary_sha256':sha(ev/'summary.json'),'world_exists':world.is_dir(),
         'artifacts':summary.get('artifacts'), 'data_files':{},'capture_comparisons':[], 'manifest_count':0}
    manifest=ev/'SHA256SUMS'
    for line in manifest.read_text().splitlines():
        digest,rel=line.split(maxsplit=1); rel=rel.lstrip('*')
        p=ev/rel
        assert sha(p)==digest, str(p)
        rec['manifest_count']+=1
    phase=next(c for c in summary['cycles'] if c['phase']==last)
    rec['last_exit']=phase['exit_code']; rec['last_phase']=last
    for rel, metadata in phase['disk_evidence'].items():
        capture=ev/last/rel; original=root/server/rel
        rec['capture_comparisons'].append({'path':rel,'capture_present':capture.is_file(),
              'retained_present':original.is_file(),'retained_sha256':sha(original) if original.is_file() else None,
              'captured_sha256':metadata['sha256']})
        assert original.is_file() and sha(original)==metadata['sha256'], str(original)
    for p in sorted((world/'data').glob('advancedrocketrycommunity*.dat')):
        rec['data_files'][p.name]={'sha256':sha(p),'bytes':p.stat().st_size,'nbt':read_nbt(p)}
    rec['binding_exists']=(world/'data/advancedrocketrycommunity_planetary_bindings.json').exists()
    rec['mods']=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((root/server/'mods').glob('*.jar'))]
    rec['world_file_count']=sum(p.is_file() for p in world.rglob('*'))
    rec['world_total_bytes']=sum(p.stat().st_size for p in world.rglob('*') if p.is_file())
    output[label]=rec
(OUT/'fixtures.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
for key,v in output.items():
    print(key, 'manifest=',v['manifest_count'],'files=',v['world_file_count'],'bytes=',v['world_total_bytes'],
          'captured_matches=',len(v['capture_comparisons']),'binding_exists=',v['binding_exists'])
    for name,entry in v['data_files'].items():print(name,entry)
    print('mods',v['mods'])
