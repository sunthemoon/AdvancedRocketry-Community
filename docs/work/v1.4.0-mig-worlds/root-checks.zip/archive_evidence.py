"""Preserve MIG-02 observations and validate their exact archive members."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/work/v1.4.0-mig-worlds'
BASE = 'a9143c2b62d5daab412cefedcee198f1fd032588'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def manifest(source):
    rows = (source / 'SHA256SUMS').read_text(encoding='ascii').splitlines()
    for line in rows:
        digest, relative = line.split('  ', 1)
        path = (source / relative).resolve()
        assert path.is_relative_to(source.resolve()) and sha(path.read_bytes()) == digest, relative
    return len(rows)


def bundle(name, groups):
    members = []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            assert not path.is_symlink(), path
            if path.is_file():
                name_in_group = path.relative_to(source).as_posix() if source.is_dir() else path.name
                members.append((prefix + '/' + name_in_group if prefix else name_in_group, path))
    assert len(members) == len({name for name, _ in members})
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in sorted(members):
            data = path.read_bytes(); archive.writestr(key, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)


def archive(reviews):
    OUT.mkdir(exist_ok=True)
    counts = {name: manifest(TEMP / name) for name in ('native', 'native-final')}
    review_counts = {path.name: manifest(path) for path in reviews}
    bundle('native-migration', [(name, TEMP / name) for name in counts])
    bundle('independent-review', [(path.name, path) for path in reviews])
    bundle('root-checks', [('', path) for path in sorted(TEMP.glob('*.log'))]
           + [('junit', TEMP / 'root-junit'), ('', TEMP / 'archive_evidence.py'),
              ('', TEMP / 'archive-evidence-initial.py')])
    summary = json.loads((TEMP / 'native-final/summary.json').read_text())
    assert summary['result'] == 'PASS' and summary['source_unchanged']
    write('native-summary.json', summary)
    suites = [ET.parse(path).getroot() for path in (TEMP / 'root-junit').glob('TEST-*.xml')]
    junit = {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}}
    assert junit['tests'] == 922 and junit['failures'] == junit['errors'] == junit['skipped'] == 0
    log = (TEMP / 'root-gradle.log').read_text(encoding='utf-8')
    assert 'All 236 required tests passed' in log and 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log
    assert '> Task :test FROM-CACHE' in log
    write('root-checks.json', {'base_commit': BASE, 'junit': junit, 'junit_execution': 'FROM-CACHE',
          'gametests_executed': 236, 'python_executed': 43, 'native_manifest_counts': counts,
          'review_manifest_counts': review_counts, 'scope': 'Short development checks, not Required Gate approval'})
    artifacts = []
    for path in sorted((ROOT / 'build/libs').glob('*1.4.0-dev*.jar')):
        data = path.read_bytes()
        assert data == (TEMP / 'artifacts' / path.name).read_bytes(), path
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': sha(data)})
    assert len(artifacts) == 3
    prior = json.loads((ROOT / 'docs/work/v1.4.0-mig-claims/development-artifacts.json').read_text())
    assert artifacts == prior['artifacts']
    write('development-artifacts.json', {'artifacts': artifacts, 'runtime_unchanged': True,
          'production_commit': BASE, 'native_artifacts': summary['artifacts']})
    print('PASS: root, native and independent archives; all production artifacts unchanged')


def finalize():
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii')
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith('docs/work/v1.4.0-mig-worlds/'):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    write('source-identity.json', {'base_commit': BASE, 'files': rows})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    for path in OUT.glob('*-files.json'):
        with zipfile.ZipFile(path.with_name(path.name.replace('-files.json', '.zip'))) as archive:
            listing = json.loads(path.read_text())
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(row['path'] for row in listing)
            for row in listing:
                raw = archive.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(path for path in OUT.iterdir() if path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(path.read_bytes())}  {path.name}\n' for path in paths), encoding='ascii', newline='\n')
    print('PASS: staged source identities, local links, complete ZIP byte readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, action='append', default=[])
    parser.add_argument('--finalize', action='store_true')
    args = parser.parse_args()
    if args.finalize:
        finalize()
    else:
        archive(args.review)
