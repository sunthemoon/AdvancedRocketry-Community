"""Prepare a fresh libraries-only server from a previously verified installation."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
PREVIOUS = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v130-adapter-flight-corrected-cb65df26cfb34e3ca448c0979a5e6196")
SOURCE = PREVIOUS / "server/libraries"
TARGET = BASE / "server/libraries"

def digest(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()

manifest = PREVIOUS / "preparation.json"
expected = json.loads(manifest.read_text(encoding="utf-8"))["libraries"]
paths = sorted(SOURCE.rglob("*"))
for path in [SOURCE, *paths]:
    if path.is_symlink() or getattr(path.lstat(), "st_file_attributes", 0) & 0x400:
        raise RuntimeError(f"Refusing reparse point: {path}")
actual = {p.relative_to(SOURCE).as_posix(): p for p in paths if p.is_file()}
if len(expected) != 104 or set(actual) != {item["path"] for item in expected}:
    raise RuntimeError("Cached library inventory differs from the verified 104-file set")
for item in expected:
    source = actual[item["path"]]
    if source.stat().st_size != item["bytes"] or digest(source) != item["sha256"]:
        raise RuntimeError(f"Cached library identity changed: {source}")
TARGET.parent.mkdir()
shutil.copytree(SOURCE, TARGET)
for item in expected:
    target = TARGET / item["path"]
    if target.stat().st_size != item["bytes"] or digest(target) != item["sha256"]:
        raise RuntimeError(f"Copied library identity differs: {target}")
assert {p.name for p in TARGET.parent.iterdir()} == {"libraries"}
result = {
    "task": "V130-ROCKET-04",
    "prepared_at": datetime.now(timezone.utc).isoformat(),
    "source_libraries": str(SOURCE),
    "previous_manifest": str(manifest),
    "previous_manifest_sha256": digest(manifest),
    "libraries": expected,
    "copied_library_count": len(expected),
    "server_entries": ["libraries"],
    "java_launched": False,
}
(BASE / "preparation.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(f"Prepared {len(expected)} verified libraries in {BASE}; no world/mods/config or Java start.")

