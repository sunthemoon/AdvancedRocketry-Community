"""Archive full tests and final artifacts before any focused rerun."""
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
BASE = Path(__file__).resolve().parent
OUT = ROOT / "docs/work/v1.3.0-fueled-disassembly"

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

xmls = sorted((ROOT / "build/test-results/test").glob("TEST-*.xml"))
summary = {"suites": len(xmls), "tests": 0, "failures": 0, "errors": 0, "skipped": 0}
for xml in xmls:
    node = ET.parse(xml).getroot()
    for key in ("tests", "failures", "errors", "skipped"):
        summary[key] += int(node.attrib[key])
assert summary["suites"] > 0 and summary["failures"] == summary["errors"] == summary["skipped"] == 0
exists = (OUT / "junit-full.zip").exists()
with zipfile.ZipFile(OUT / "junit-full.zip", "r" if exists else "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for xml in xmls:
        if exists:
            assert archive.read(xml.name) == xml.read_bytes()
        else:
            archive.write(xml, xml.name)
(OUT / "junit-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
jars = sorted((ROOT / "build/libs").glob("*.jar"))
changes = {}
for jar in jars:
    with zipfile.ZipFile(BASE / "pre-notice-artifacts" / jar.name) as before, zipfile.ZipFile(jar) as after:
        assert set(before.namelist()) == set(after.namelist())
        changes[jar.name] = [n for n in after.namelist() if before.read(n) != after.read(n)]
        assert changes[jar.name] == ["META-INF/THIRD-PARTY-NOTICES.md"], changes
artifacts = BASE / "artifacts"
artifacts.mkdir(exist_ok=True)
identities = []
for jar in jars + sorted((ROOT / "compat-test-mod/build/libs").glob("*.jar")):
    target = artifacts / jar.name
    if target.exists():
        assert sha(jar) == sha(target)
    else:
        shutil.copy2(jar, target)
    assert sha(jar) == sha(target)
    identities.append({"name": jar.name, "bytes": jar.stat().st_size, "sha256": sha(jar)})
shutil.copytree(ROOT / "compat-test-mod/build/reports/consumer", OUT / "consumer-reports")
report = {"source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
          "junit": summary, "packaging_refresh_changed_entries": changes, "artifacts": identities}
(OUT / "artifact-identities.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
(BASE / "artifact-identities.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
