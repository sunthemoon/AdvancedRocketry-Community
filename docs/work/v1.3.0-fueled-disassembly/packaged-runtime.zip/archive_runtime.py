"""Verify and archive immutable raw runtime captures; no server execution."""
import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
BASE = Path(__file__).resolve().parent
CAPTURE = BASE / "flight-evidence"
OUT = ROOT / "docs/work/v1.3.0-fueled-disassembly"

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

listed = {}
for line in (CAPTURE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
    expected, relative = line.split("  ", 1)
    posix = PurePosixPath(relative)
    assert not posix.is_absolute() and ".." not in posix.parts
    path = CAPTURE.joinpath(*posix.parts)
    assert path.resolve().is_relative_to(CAPTURE.resolve()) and not path.is_symlink()
    assert sha(path) == expected, relative
    listed[relative] = expected
actual = {p.relative_to(CAPTURE).as_posix():p for p in CAPTURE.rglob("*")
          if p.is_file() and p.name != "SHA256SUMS"}
assert set(listed) == set(actual)
sources = {p.relative_to(BASE).as_posix():p for p in CAPTURE.rglob("*") if p.is_file()}
for name in ["prepare_runtime.py", "preparation.json", "archive_build.py", "archive_runtime.py",
             "artifact-identities.json", "runtime-command.txt", "runner-stdout.txt", "runner-exit.json"]:
    sources[name] = BASE / name
for name in ["run_v130_adapter_flight_smoke.py", "run_v130_adapter_recovery_smoke.py",
             "run_v002_server_smoke.py", "run_v060_rocket_flight_smoke.py"]:
    candidate = ROOT / "scripts" / name
    if candidate.is_file():
        sources["runner-source/" + name] = candidate
archive_path = OUT / "packaged-runtime.zip"
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(sources.items()):
        archive.write(path, name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, path in sources.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == sha(path), name
full = json.loads((CAPTURE / "summary.json").read_text(encoding="utf-8"))
report = {
    "source_commit": subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
    "raw_manifest_files": len(listed), "archive_entries": len(sources),
    "archive_sha256": sha(archive_path), "result": full["result"],
    "runtime_base": str(BASE), "artifacts": full["artifacts"],
    "cycles": [{k:v for k,v in c.items() if k in {
        "phase", "result", "exit_code", "observation_ticks", "explicit_fuel_disposal",
        "started_at", "completed_at", "log_counts"}} for c in full["cycles"]]}
(OUT / "runtime-summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
shutil.copy2(BASE / "runtime-command.txt", OUT / "runtime-command.txt")
print(json.dumps(report, indent=2))

