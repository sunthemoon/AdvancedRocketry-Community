"""V150-MIG-01 (ADR-042): a v1.4-written station whose orbit body is missing, natively.

Three finite dedicated-server processes on a COPY of the retained genuine v1.4 world. Its second
station ("neighbor") orbits Mars. The world's existing fixture data pack hides Mars and Venus (and
their routes) through a pack filter, using the v1.4 migration fixture's own helper.

1. upgrade-missing: the v1.5 host migrates the v1.4 world with Mars absent. The station and its
   Mars orbit ID are preserved, the unknown body is reported, `environment` marks the orbit
   unavailable, and the owner evacuates the station with a warp at the interstellar cost (charged
   through the public Forge Energy capability) to Earth.
2. restart-missing: Mars still hidden; the station now orbits Earth and nothing is reported.
3. restored: the filter is removed (Mars returns); the station stays at Earth, and the other
   station and all other authorities are unchanged.

No real clients, rockets or crash cuts. The source world is not modified.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = HISTORY / 'server-final/world'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
HOST_JAR = REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar'
CONSUMER = REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
SPACE = HOST + ':space'
EARTH, MARS = HOST + ':earth', HOST + ':mars'
PROBE = re.compile(r'ARCE_STATION_PROBE (\{.*\})\s*$')
PER_TICK = 200_000
INTERSTELLAR = 8_000_000


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def observe_data(world, directory):
    directory.mkdir(parents=True)
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def station_record(payload, station_id):
    matches = [s for s in payload['stations'] if nbt_uuid(s['station_id']) == station_id]
    require(len(matches) == 1, 'Station record missing')
    return matches[0]


def normalize_other(name, payload):
    value = copy.deepcopy(payload)
    if name == HOST + '_satellite_missions.dat':
        clock = value.pop('clock')
        require(set(clock) == {'logical_game_time', 'last_observed_game_time'}, 'Invalid mission clock')
    return value


def visit_only_celestial_change(before, after):
    """Connected probe players may record first Earth/Space visits; nothing else may change."""
    old = {body['id']: body for body in before['bodies']}
    new = {body['id']: body for body in after['bodies']}
    require({k: v for k, v in before.items() if k != 'bodies'} == {k: v for k, v in after.items() if k != 'bodies'},
            'Celestial root fields changed')
    require(set(old) <= set(new) and set(new) - set(old) <= {HOST + ':space'}, 'Unexpected celestial bodies')
    for body_id, body in new.items():
        previous = old.get(body_id)
        if previous == body:
            continue
        require(body_id in (EARTH, HOST + ':space'), 'Non-visit celestial change: ' + body_id)
        require(previous is None or all(body[k] == previous[k] for k in previous), 'Existing celestial field changed')
        require(set(k for k in body if previous is None or k not in previous) <= {'first_visit_at', 'discovered_at', 'id'},
                'Unexpected celestial fields')


class Phase:
    def __init__(self, name, artifacts, allowed_findings):
        self.name, self.artifacts, self.allowed = name, artifacts, allowed_findings
        self.directory = OUT / name
        self.commands, self.probes, self.observations = [], [], {}

    def query(self, process, text, pattern, timeout=30):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern, timeout, start_at=start)]

    def probe(self, process, text, label):
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        self.probes.append(report)
        return report

    def run(self, process, label, actor, command):
        report = self.probe(process, f'arce_station_probe run {label} {actor} {command}', label)
        require(report['command'] == command and report['level'] == SPACE, 'Probe run differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'A station command changed the loaded chunk count: ' + label)
        return report


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def check_findings(phase, lines):
    """Blocking log findings (ERROR/FATAL, project WARN) must be exactly the expected ones."""
    findings = server.scan_log(lines)
    unexpected = [line for line in findings if not any(re.search(pattern, line) for pattern in phase.allowed)]
    require(not unexpected, 'Unexpected log findings: ' + json.dumps(unexpected[:10]))
    for pattern in phase.allowed:
        require(sum(1 for line in findings if re.search(pattern, line)) == 1,
                'Expected finding missing or repeated: ' + pattern)
    return findings


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    command.insert(1, '-Darce_adapter_test.stationSmoke=true')
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 240)
        status = server.wait_for_status(port)
        support.validate_status(status, True, phase.artifacts[0]['version'])
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        phase.commands.append('stop')
        process.command('stop')
        require(process.finish() == 0, 'Server did not stop cleanly')
        findings = check_findings(phase, process.lines)
        receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                       expected_findings=[line.rstrip() for line in findings],
                       migration_lines=[line.rstrip() for line in process.lines if '[ARCE-BETA-' in line],
                       station_lines=[line.rstrip() for line in process.lines if 'ARCE_STATION_' in line],
                       observations=phase.observations)
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        write_json(phase.directory / 'probes.json', phase.probes)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    history = json.loads((HISTORY / 'native-final/summary.json').read_text(encoding='utf-8'))
    require(history['result'] == 'PASS' and history['source_unchanged'], 'Historical receipt incomplete')
    host = support.artifact(HOST_JAR, HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(CONSUMER, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    route_count = fixture.set_removal(SERVER, HOST_JAR, True)
    write_json(OUT / 'inputs.json', {'history_receipt': str(HISTORY / 'native-final/summary.json'),
               'history_receipt_sha256': digest(HISTORY / 'native-final/summary.json'),
               'source_world': str(SOURCE), 'artifacts': [host, consumer], 'routes_with_mars_hidden': route_count,
               'removal_pack': json.loads((SERVER / fixture.PACK / 'pack.mcmeta').read_text(encoding='utf-8'))})
    before = observe_data(SERVER / 'world', OUT / 'before')
    old = before[STATION]
    require(old['schema_version'] == 2, 'Source is not the v1.4 world')
    mars = [s for s in old['stations'] if s['orbit_body'] == MARS]
    require(len(mars) == 1, 'The v1.4 world must have exactly one Mars-orbit station')
    station = mars[0]
    station_id = nbt_uuid(station['station_id'])
    owner = nbt_uuid(station['owner_id'])
    other = next(nbt_uuid(s['station_id']) for s in old['stations'] if nbt_uuid(s['station_id']) != station_id)
    pad = station['landing_pad']
    stand, core = [pad[0], pad[1], pad[2]], [pad[0] + 2, pad[1], pad[2]]
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    artifacts = [host, consumer]
    unknown = r'\[Server thread/ERROR\].*ARCE_STATION_UNKNOWN_ORBIT_BODY station=' + station_id

    def inspect(phase, process, label, station_uuid, orbit):
        line = phase.query(process, f'arce station admin inspect {station_uuid}', re.compile(r'region=\S+ pad='))
        require(f' orbit={orbit} ' in line, f'{label}: inspect differs: {line.strip()}')
        phase.observations[label] = line.strip()

    def upgrade_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1002\].*migrated=1, backup=\S+-managed', l) for l in process.lines),
                'Unexpected migration startup result')
        inspect(phase, process, 'inspect_missing', station_id, MARS)
        phase.probe(process, f'arce_station_probe join owner_join {owner} ' + ' '.join(map(str, stand)), 'owner_join')
        # `environment` is read-only (no local-source rule); its reply reaches the console source.
        env = phase.query(process, f'execute as {owner} at {owner} run arce station environment',
                          re.compile(r' orbit=\S+'))
        require(f'orbit={MARS} (unavailable)' in env, 'Environment does not mark the missing orbit: ' + env.strip())
        phase.observations['environment_missing'] = env.strip()
        # Test setup: console commands need a loaded chunk; the probe player keeps it loaded afterwards.
        phase.query(process, f'execute in {SPACE} run forceload add {core[0]} {core[2]}',
                    re.compile(r'(Marked|Unmarked) chunk|No chunks were|already|isn|not'))
        line = phase.query(process, f'execute in {SPACE} run setblock {core[0]} {core[1]} {core[2]} {HOST}:warp_core',
                           re.compile(r'Changed the block at|Could not set the block|not loaded'))
        require('Changed the block at' in line, 'Warp core was not placed')
        phase.query(process, f'execute in {SPACE} run forceload remove {core[0]} {core[2]}',
                    re.compile(r'(Marked|Unmarked) chunk|No chunks were|already|isn|not'))
        for index in range(INTERSTELLAR // PER_TICK):
            report = phase.probe(process, f'arce_station_probe energy charge_{index} '
                                 + ' '.join(map(str, core)) + f' {PER_TICK}', f'charge_{index}')
            require(report['capability'] and report['accepted'] == PER_TICK, 'Charge differs: ' + json.dumps(report))
        phase.probe(process, f'arce_station_probe look owner_look {owner} ' + ' '.join(map(str, core)), 'owner_look')
        quote = phase.run(process, 'evacuation_request', owner, f'arce station warp {EARTH}')
        require(any(f'interstellar warp, cost {INTERSTELLAR} FE, warp energy {INTERSTELLAR} FE' in m
                    for m in quote['messages']), 'Evacuation quote differs: ' + json.dumps(quote))
        started = len(process.lines)
        confirm = phase.run(process, 'evacuation_confirm', owner, f'arce station warp confirm {station_id}')
        require(any('Warp countdown started' in m for m in confirm['messages']), 'Countdown did not start')
        process.wait_for(re.compile(r'ARCE_STATION_WARP action=commit code=WARP_COMMITTED station=' + station_id),
                         40, start_at=started)
        inspect(phase, process, 'inspect_evacuated', station_id, EARTH)
        inspect(phase, process, 'inspect_other', other, station_record(old, other)['orbit_body'])
        phase.probe(process, f'arce_station_probe leave owner_leave {owner}', 'owner_leave')

    upgrade = Phase('upgrade-missing', artifacts, [unknown])
    receipts = [run_phase(upgrade, port, upgrade_actions)]
    upgraded = observe_data(SERVER / 'world', upgrade.directory / 'state')
    evacuated = station_record(upgraded[STATION], station_id)
    require(upgraded[STATION]['schema_version'] == 4 and evacuated['orbit_body'] == EARTH
            and upgraded[STATION]['warp_energy'] == [], 'Evacuation result differs')
    expected_station = copy.deepcopy(station)
    expected_station.update(schema_version=2, orbit_body=EARTH)
    require(evacuated == expected_station, 'Evacuation changed more than the orbit')
    require(station_record(upgraded[STATION], other) == dict(station_record(old, other), schema_version=2),
            'The other station changed')

    def restart_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'Restart remigrated')
        inspect(phase, process, 'inspect_restart', station_id, EARTH)

    restart = Phase('restart-missing', artifacts, [])
    receipts.append(run_phase(restart, port, restart_actions))
    restarted = observe_data(SERVER / 'world', restart.directory / 'state')
    require(restarted[STATION] == upgraded[STATION], 'Restart changed the station registry')

    fixture.set_removal(SERVER, HOST_JAR, False)

    def restored_actions(phase, process):
        inspect(phase, process, 'inspect_restored', station_id, EARTH)
        inspect(phase, process, 'inspect_other_restored', other, station_record(old, other)['orbit_body'])

    restored = Phase('restored', artifacts, [])
    receipts.append(run_phase(restored, port, restored_actions))
    final = observe_data(SERVER / 'world', restored.directory / 'state')
    require(final[STATION] == upgraded[STATION], 'Restoring Mars changed the station registry')
    celestial = HOST + '_celestial.dat'
    visit_only_celestial_change(before[celestial], final[celestial])
    for name in before:
        if name not in (STATION, celestial):
            require(normalize_other(name, before[name]) == normalize_other(name, final[name]),
                    'Another authority changed: ' + name)
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
        'station': station_id, 'owner': owner, 'other_station': other,
        'orbit': {'v14': MARS, 'after_evacuation': EARTH}, 'cycles': receipts,
        'scope': ('genuine v1.4 world, Mars hidden by a data-pack filter -> v1.5 upgrade preserves the '
                  'Mars-orbit station and reports it -> owner evacuates it by warp at the interstellar cost -> '
                  'restart -> Mars restored; no real clients, rockets or crash cuts')})
    print('PASS: missing-orbit station preserved, reported, evacuated and stable across restarts')


if __name__ == '__main__':
    main()
