"""Archive scoped MIG-01 observations without touching the separate documentation bundle."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/work/v1.4.0-mig-claims'
BASE = 'cbff561a8e949c25e93d51365a260e0fd061be4d'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def bundle(name, groups):
    inputs = []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            assert not path.is_symlink(), path
            if path.is_file():
                part = path.relative_to(source).as_posix() if source.is_dir() else path.name
                inputs.append((prefix + '/' + part if prefix else part, path))
    inputs.sort()
    assert len(inputs) == len({key for key, _ in inputs})
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in inputs:
            data = path.read_bytes()
            archive.writestr(key, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': digest(data)})
    write(name + '-files.json', rows)


def junit(directory):
    suites = [ET.parse(path).getroot() for path in sorted(directory.rglob('TEST-*.xml'))]
    assert suites, directory
    return {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
                                   for key in ('tests', 'failures', 'errors', 'skipped')}}


def archive(reviews):
    review_counts = {}
    for review in reviews:
        entries = (review / 'SHA256SUMS').read_text(encoding='ascii').splitlines()
        for line in entries:
            sha, relative = line.split('  ', 1)
            path = (review / relative).resolve()
            assert path.is_relative_to(review.resolve()), relative
            assert digest(path.read_bytes()) == sha, relative
        review_counts[review.name] = len(entries)
    inputs = [('', path) for path in sorted(TEMP.glob('*.log'))]
    inputs += [('', TEMP / 'pinned-saveddata-bytecode.txt'), ('', TEMP / 'archive_evidence.py')]
    inputs += [(path.name, path) for path in sorted(TEMP.iterdir()) if path.is_dir() and path.name.endswith('-xml')]
    bundle('root-checks', inputs)
    bundle('independent-review', [(path.name, path) for path in reviews])
    native = TEMP / 'native'
    summary = json.loads((native / 'summary.json').read_text(encoding='utf-8'))
    assert summary['result'] == 'PASS' and summary['research_unlocks'] and len(summary['research']) == 3
    native_entries = (native / 'SHA256SUMS').read_text(encoding='ascii').splitlines()
    for line in native_entries:
        sha, relative = line.split('  ', 1)
        path = (native / relative).resolve()
        assert path.is_relative_to(native.resolve()), relative
        assert digest(path.read_bytes()) == sha, relative
    bundle('native-restart', [('', native)])
    write('native-summary.json', summary)
    results = {path.name: junit(path) for path in sorted(TEMP.iterdir()) if path.is_dir() and path.name.endswith('-xml')}
    final = results['clean-build-final-04-xml']
    assert final['tests'] == 922 and final['failures'] == final['errors'] == final['skipped'] == 0
    root_log = (TEMP / 'clean-all-02.log').read_text(encoding='utf-8')
    assert 'All 236 required tests passed' in root_log and 'BUILD SUCCESSFUL' in root_log
    write('root-checks.json', {'base_commit': BASE, 'junit_runs': results,
          'review_manifest_counts': review_counts, 'native_manifest_count': len(native_entries),
          'root_required_gametests': 236, 'root_gametest_log': 'clean-all-02.log',
          'scope': 'Development checks; final GameTest additions are independently rerun; no native forced cut/Gate approval'})
    artifacts = []
    for path in sorted((TEMP / 'artifacts-final').glob('*.jar')):
        data = path.read_bytes()
        assert data == (ROOT / 'build/libs' / path.name).read_bytes(), path
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': digest(data)})
    assert len(artifacts) == 3
    prior = json.loads((ROOT / 'docs/work/v1.4.0-discovery/development-artifacts.json').read_text(encoding='utf-8'))
    assert next(row for row in artifacts if row['name'].endswith('-api.jar')) == next(
        row for row in prior['artifacts'] if row['name'].endswith('-api.jar'))
    write('development-artifacts.json', {'artifacts': artifacts, 'public_api_unchanged': True, 'api_version': '1.7'})
    resources = ROOT / 'src/generated/v1.4/resources'
    rows = []
    with zipfile.ZipFile(TEMP / 'artifacts-final/advancedrocketry-community-1.20.1-1.4.0-dev.jar') as jar:
        assert len(jar.namelist()) == len(set(jar.namelist()))
        for path in sorted(resources.rglob('*.json')):
            if '.cache' in path.parts:
                continue
            data = path.read_bytes()
            entry = path.relative_to(resources).as_posix()
            assert jar.read(entry) == data, entry
            rows.append({'path': path.relative_to(ROOT).as_posix(), 'jar_entry': entry,
                         'bytes': len(data), 'sha256': digest(data)})
    assert len(rows) == 34
    write('generated-resources.json', rows)
    print('PASS: root/review/native archives, 922 JUnit, 236 initial GameTests, 34 resources and frozen artifacts')


def finalize():
    for name in ('SHA256SUMS.txt', 'links.json'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii', newline='\n')
    files = git('diff', '--cached', '--name-only', BASE).decode().splitlines()
    rows, documents = [], []
    for relative in files:
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if relative.endswith('.md'):
            documents.append(relative)
        if relative.startswith('docs/work/v1.4.0-mig-claims/'):
            continue
        staged, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
        assert staged == working.replace(b'\r\n', b'\n'), relative
        rows.append({'path': relative, 'bytes': len(staged), 'sha256': digest(staged),
                     'working_sha256': digest(working), 'git_blob': git('rev-parse', ':' + relative).decode().strip()})
    write('source-identity.json', {'base_commit': BASE, 'files': rows,
          'scope': 'Changed staged inputs outside evidence, including raw executed worktree identities'})
    links = []
    for relative in documents:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
            assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
            links.append({'document': relative, 'target': target, 'exists': True})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets, not URLs/anchors', 'links': links})
    for listing in OUT.glob('*-files.json'):
        with zipfile.ZipFile(listing.with_name(listing.name.replace('-files.json', '.zip'))) as archive:
            assert archive.testzip() is None
            expected = json.loads(listing.read_text(encoding='utf-8'))
            assert set(archive.namelist()) == {row['path'] for row in expected}
            for row in expected:
                data = archive.read(row['path'])
                assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
    members = sorted(path for path in OUT.iterdir() if path.is_file() and path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{digest(path.read_bytes())}  {path.name}\n' for path in members),
                                      encoding='ascii', newline='\n')
    print(f'PASS: {len(links)} local links and {len(members)} checksummed evidence members')


def check_index():
    for path in OUT.iterdir():
        if path.is_file():
            assert git('show', ':' + path.relative_to(ROOT).as_posix()) == path.read_bytes(), path
    for line in (OUT / 'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
        sha, relative = line.split('  ', 1)
        assert digest((OUT / relative).read_bytes()) == sha, relative
    print('PASS: staged evidence bytes match the complete checksum manifest')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, action='append')
    parser.add_argument('--finalize', action='store_true')
    parser.add_argument('--check-index', action='store_true')
    args = parser.parse_args()
    if args.review:
        archive(args.review)
    if args.finalize:
        finalize()
    if args.check_index:
        check_index()
