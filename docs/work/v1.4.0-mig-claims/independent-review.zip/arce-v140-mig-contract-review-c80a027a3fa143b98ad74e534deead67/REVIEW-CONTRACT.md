# V140-MIG independent scope and ADR-038 review

## Identity and conclusion boundary

Reviewed baseline `cbff561a8e949c25e93d51365a260e0fd061be4d` in
`D:/GitHub/AdvancedRocketry-Community`, plus the root-authored ADR-038 and MIG
plan. This is an independent **contract/source exploration**, not implementation
verification or Gate approval. Root recorded ADR-038 as ACCEPTED while this
review was in progress; that authority decision is not an executed-test result.
No production implementation is assessed by this report.

## Findings, highest severity first

### P1 — Baseline can retain a paid terminal mission without its discovery

[SatelliteManager.java:446–457](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L446)
mutates celestial progress, finishes the mission, then flushes the whole
DataStorage. [SatelliteMissionSavedData.java:229–233](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/persistence/SatelliteMissionSavedData.java#L229)
has no checked per-file acknowledgment. The supplied pinned bytecode shows
HashMap iteration and SavedData's IOException catch followed by dirty=false.

Concrete cut: mission/account CLAIMED bytes are saved, celestial bytes remain
old (interruption or failed write), then restart. Startup queues only
CLAIM_PENDING_DISCOVERY
([manager:410–418](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L410)).
The completed receipt is omitted; direct replay returns ALREADY_CLAIMED
([registry:289–293](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/mission/SatelliteMissionRegistry.java#L289)).
The paid unlock is not automatically repaired. Conversely, saving discovery
without the receipt cannot establish that the original fee was durable. This
does **not** prove two durable account credits: account and mission share one
file, and a rolled-back account is not a second retained credit.

ADR-038 addresses the concrete ordering defect and historical CLAIMED repair.
This remains an existing implementation gap until the new writer/coordinator
and cut/retry tests are implemented and executed. ADR-037 expressly excluded
arbitrary interruption guarantees; the finding is why MIG is necessary, not a
claim that DISC's normal-restart evidence was false.

### P2 — Runtime pending claims lack automatic same-session recovery enrollment

[SatelliteManager.java:469–478](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L469)
does not enqueue new paid pending receipts. The queue is populated only on
startup. A mission started before target removal can become paid/pending while
the body is unavailable; restoring that body does not by itself enroll it for
automatic replay. An explicit new claim or restart can recover it. ADR-038's
deduplicated runtime enrollment is the smallest direct correction.

Do not misclassify the existing `addLast` then `break` at lines 428–431 as
permanent head-of-line starvation: it rotates the unavailable entry, allowing
other entries on following ticks. It does reduce throughput. The queue still
needs bounded failure containment when new checked I/O can throw.

### P2, resolved in contract — Repeated barriers must acknowledge unchanged state

The initial draft described three writes but did not explicitly cover retries
where in-memory `claim()` already returns unchanged PENDING/CLAIMED or a
discovery already exists but its visit/progress is dirty. Presence or an
unchanged operation result alone is not disk acknowledgment. Skipping the first
or second barrier in these cases reopens the ordering gap.

[Revised ADR-038:44–48](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-038-ORDERED-PLANETARY-DISCOVERY-RECOVERY.md#L44)
now requires the acknowledgments, and lines 52–54 explicitly keep historical
CLAIMED receipts terminal while queued for repair. No outstanding contract
blocker was identified after these clarifications. Correct dirty/acknowledgment
implementation still needs actual diff review and executable evidence.

## Existing guarantees and compatibility constraints

- Mission/account ownership is colocated. The synchronized claim validates
  owner before mutation, atomically updates account and mission in memory, and
  bypasses a second credit for pending/claimed receipts
  ([registry:260–339](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/mission/SatelliteMissionRegistry.java#L260)).
  Captured target, definition, duration, reward, fee and discoveryRequired are
  not recalculated on restart. Final repair must not clear a newer mission
  already bound to the same satellite.
- Celestial progress retains removed IDs and existing timestamps; it is not
  filtered by live catalog. It caps historical entries at 128 and preserves a
  future root read-only
  ([CelestialSavedData:58–98,126–182](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L58)).
  A required unlock can be repaired without inventing a first visit. Repair
  timestamps use world game time, not the mission's monotonic logical clock.
- The pre-Level migration guard already bounded-reads, schema-checks and
  semantically validates managed files
  ([WorldDataMigrationService:99–125](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/WorldDataMigrationService.java#L99)).
  Preserve it: the pinned generic computeIfAbsent path alone can substitute a
  new object after a load exception. Current corrupt/future disk files are
  rejected by this preflight, rather than tested by proceeding into gameplay.
- Existing disk limits are centralized in
  [ManagedSavedDataType:13–49,83–88](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/ManagedSavedDataType.java#L13)
  and the wrapper decoder is bounded by both expanded bytes and NbtAccounter
  ([BoundedSavedDataIo:23–60](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/BoundedSavedDataIo.java#L23)).
  Reuse those compatible bounds; do not enlarge them to fit a failed test.
- Removing/re-adding a definition is not permission to rebind identity.
  [PlanetaryBindings:55–65](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindings.java#L55)
  retains historical body/Level reservations. Re-add the same ID/Level; do not
  delete the binding ledger or rewrite station orbits.
- Missing body definitions refuse new physical source/destination admission
  ([PlanetaryFlightAdmission:39–68](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/PlanetaryFlightAdmission.java#L39)).
  This is not a guarantee that a rocket at a removed body can fly out without
  restoring that definition. Already prepared transfers remain a separate
  journal-authority mechanism; MIG need not rewrite it.
- Valid body-removal fixtures must also remove dependent routes/children and
  update satellite allowedTargets. Otherwise the satellite catalog rejects
  dangling references
  ([SatelliteCatalog:48–52](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteCatalog.java#L48));
  startup rejection is not successful removed-body recovery. Missing orbit
  references are retained, with exact project ERROR diagnostics at startup
  ([StationManager:258–266](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationManager.java#L258)).
  Preserve/classify those expected lines rather than claim a zero-ERROR run or
  broadly ignore other failures.

## Smallest coherent implementation scope

1. A small internal checked SavedData writer used only by these two stores:
   same IDs, wrapper, schemas and values; bounded encode/readback; file force;
   same-directory ATOMIC_MOVE only; no symlink/non-regular staging authority;
   dirty retained on failure; explicit checked flush distinct from ordinary
   autosave error handling. The pinned public `save(File)` method is overridable.
2. One ordered coordinator: persist pending+account, persist a copy-on-write
   celestial candidate before publishing it, then finish/persist the mission.
   Failure must halt subsequent stages. Retry includes unchanged/terminal
   in-memory results. A fresh legitimate claim still saves its paid pending
   receipt even when the target cannot presently be applied.
3. A server-lifetime bounded/deduplicated replay queue for pending and historical
   paid terminal receipts needing repair. Keep 8192 maximum receipts and eight
   inspections/applications per tick, no world/chunk scanning, clear on stop.
   Check unavailable/full/future work before repeated disk writes; cap diagnostics.
   Eight receipts is a count bound, not evidence that multiple full-registry
   fsyncs per tick satisfy performance budgets.
4. Preserve prospective world adoption, existing progress, owner accounts,
   station records and mission snapshots. Add a finite actual-v1.3-world copy
   upgrade and coherent remove/re-add exercise. The committed V130-SAT native
   archive is useful prior evidence; reconstructed snippets alone must not be
   called an intact historical-world upgrade.

No new public API, network code, research currency, cross-system transaction
framework, dynamic dimension, broad load campaign or rollback of valid shared
discoveries is needed. Power-loss/directory durability and corrupted historical
files remain explicitly outside the ordered process-interruption guarantee.

## Recommended bounded checks (not executed here)

| Cut or condition | Required oracle |
|---|---|
| Before pending receipt commit | Disk remains READY/old account; no new discovery exposed |
| After receipt, before celestial commit | Reload has pending+one credit/fee; replay grants once |
| After celestial, before final mission commit | Reload completes pending without second account mutation |
| Final write fails in same process | Claimed in-memory state still retries/acknowledges; no stale queue loss |
| Historical CLAIMED + absent progress | Repair only discoveryRequired=true; account/current satellite binding unchanged |
| Existing dirty discovery/visit | Preserve timestamps/firstVisit; acknowledge before mission completion |
| Target absent, then restored | Newly pending work recovers without requiring another claim or restart |
| Missing target before another valid receipt | Valid work progresses within a bounded pass; no starvation |
| Full/future progress or blocked mission store | No eviction, fabricated unlock, repeated award or schema downgrade |
| Unauthorized, READY, ACTIVE, CANCELLED, non-discovery receipt | No new repair entitlement |
| Ordinary autosave and staging/write/force/readback/atomic-move failure | Old authoritative bytes intact or acknowledged replacement; dirty retained; retry succeeds |
| Repeated reload/retry/claim | Exact balance/lifetime earned/lifetime spent and mission IDs unchanged |
| Actual old-world upgrade and removed-body restart | Same body/Level reservations, station IDs/orbits, native resource authority; re-add unlock restored |

Use injected persistence failures around the real bounded Temp-file writer,
not fabricated success callbacks alone. Record authoritative file bytes after
each cut and reload those files. A finite packaged process interruption should
be distinguished from clean stop/restart and from machine power loss. Suggested
later commands are forced focused migration/celestial/satellite JUnit, short
clean build/DataGen/GameTests, and the scoped native runner plus independent raw
manifest/NBT readback. Exact test selectors depend on the implementation; none
were run for this contract review.

## Evidence and actual commands

- Read-only `git rev-parse HEAD`, `git status --short --untracked-files=no`,
  `git diff --stat`, `git ls-files` scoped source listings, `git show BASE:path`.
- PowerShell `Get-Content` with numbered excerpts and `rg` searches over the
  explicit governance, ADR, worklog, production and test directories above.
- Captured 95 initial file identities with SHA-256, initial/revised ADR, reviewed
  plan, six baseline source excerpts and the root-produced pinned bytecode.
  Baseline excerpts produced through PowerShell are UTF-8 transcription copies;
  their file hashes are not represented as original source-byte hashes. Original
  source identities are in `source-identities-initial.json`.
- Several exploratory path guesses failed harmlessly: lower-case
  `docs/versions/v1.4.0.md`, `satellite/SatelliteLimits.java`, `satellite/data`,
  direct Java filename glob arguments and two generated-directory spellings.
  Correct paths were found with tracked `git ls-files`/directory-scoped reads.
  No checks/builds were silently counted as passed from these reads.
- Initial ADR SHA-256:
  `800e30fc0c75fb95e397197543fcc18adb105cfacf1fa13fe656a92e60b83f5a`.
  Revised reviewed ADR SHA-256:
  `8e8091cec56f96cf228a8278c81dab27d84fc22334c0025efe9000a45db700f2`.

No Gradle, JVM, tests, native server, networking, repository writes, index
mutation, user-bundle reads or subdelegation occurred. Only this new Temp review
directory was written. Existing tests were inspected, not rerun. No API/JAR,
native cut, V1/V2, S2, performance or release/Gate outcome is certified.
