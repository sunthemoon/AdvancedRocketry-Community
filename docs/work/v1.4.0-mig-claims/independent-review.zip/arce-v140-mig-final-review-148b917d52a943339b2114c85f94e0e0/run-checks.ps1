$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Java/jdk-17.0.7'
$env:PYTHONUTF8='1'
$out=$PSScriptRoot
Set-Location -LiteralPath 'D:/GitHub/AdvancedRocketry-Community'
$focused=@('test','--tests','*AtomicSavedDataTest','--tests','*DiscoveryClaimRecoveryTest',
    '--tests','*DiscoveryReplayQueueTest','--tests','*SatelliteMissionSavedDataTest',
    '--tests','*SatelliteMissionRegistryTest','--tests','*CelestialSavedDataTest',
    '--tests','*PlanetaryDiscoveryTest','--tests','*WorldDataMigrationServiceTest',
    '--tests','*PopulatedWorldDataPreservationTest','--tests','*ManagedSavedDataLoaderMigrationTest',
    '--rerun-tasks','--offline','--no-daemon','--no-build-cache','--console=plain')
$integration=@('runData','runGameTestServer','--offline','--no-daemon','--no-build-cache','--console=plain')
foreach($stage in @('focused','integration')) {
    $argv=if($stage -eq 'focused'){$focused}else{$integration}
    $start=[DateTimeOffset]::Now
    $watch=[Diagnostics.Stopwatch]::StartNew()
    $worldBefore=Test-Path -LiteralPath 'build/gametest/world'
    & .\gradlew.bat @argv *> (Join-Path $out "$stage.log")
    $code=$LASTEXITCODE
    $watch.Stop()
    [pscustomobject]@{executable='.\gradlew.bat';argv=$argv;JAVA_HOME=$env:JAVA_HOME;
        cwd=(Get-Location).Path;started=$start.ToString('o');finished=([DateTimeOffset]::Now).ToString('o');
        duration_seconds=$watch.Elapsed.TotalSeconds;exit_code=$code;world_present_before=$worldBefore
    }|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $out "$stage-result.json") -Encoding utf8
    if($stage -eq 'focused' -and (Test-Path -LiteralPath 'build/test-results/test')) {
        Copy-Item -LiteralPath 'build/test-results/test' -Destination (Join-Path $out 'focused-xml') -Recurse
    }
    if($stage -eq 'integration' -and (Test-Path -LiteralPath 'build/gametest/logs')) {
        Copy-Item -LiteralPath 'build/gametest/logs' -Destination (Join-Path $out 'gametest-logs') -Recurse
    }
    Write-Output "$stage exit=$code seconds=$($watch.Elapsed.TotalSeconds) world_before=$worldBefore"
    if($code -ne 0){exit $code}
}
