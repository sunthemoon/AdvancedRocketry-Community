# V140-MIG-01 independent final source and executable review

## Findings and disposition

No unresolved concrete correctness finding remains in the inspected MIG-01
production/source scope. This is not a defect-free or release/Gate declaration.

**P3 wording observation, resolved by narrowing the contract:**
[SatelliteManager.java:319–323](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L319)
returns MISSION_NOT_FOUND before flushing when the satellite has no current
mission. If cancellation cleared that binding in memory but its save failed,
repeating player cancellation does not retry the dirty save. Both calls report
failure; this does not return a false success or establish resource duplication.
The root clarified that the guarantee covers mutation/idempotent-success paths,
not fully idempotent cancellation by satellite identity. Final
[ADR-038:38–43](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-038-ORDERED-PLANETARY-DISCOVERY-RECOVERY.md#L38)
now states the exception and ordinary-autosave eligibility. Java stayed frozen.

Recommended scoped disposition: MIG-01 implementation and its deterministic
file-cut/retry plus A0/A1 adapter checks can be recorded as **verified within
this tested scope**. The parent MIG task, actual old-world removal/restoration,
and packaged process-interruption/restart evidence remain separate. No V1/V2,
hardware power-loss, full S2 matrix, performance or Required Gate is approved.

## Final source review

Base HEAD remained `cbff561a8e949c25e93d51365a260e0fd061be4d` throughout execution.
Production/test changes were uncommitted at the independent run; identities
include explicitly new/untracked task source rather than relying on unstaged
diff alone.

- The earlier source report's ordered writer, copy-on-write progress, terminal
  receipt repair and bounded fair replay assessment remains applicable.
- The final launch/start/release-launch/cancel mutation handlers flush when
  changed **or dirty**, repairing the observed idempotent launch retry gap.
  [DiscoveryRecoveryGameTests.java:66–79](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryRecoveryGameTests.java#L66)
  installs its own empty staging-directory obstacle, requires unsupported-data
  on the failed launch, removes that obstacle in finally, retries and reads the
  actual mission file to prove the satellite was acknowledged.
- [DiscoveryClaimRecoveryTest.java:124–135](D:/GitHub/AdvancedRocketry-Community/src/test/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryClaimRecoveryTest.java#L124)
  now repairs a historical CLAIMED receipt while preserving the same satellite's
  newer ACTIVE/current mission, the complete mission root and the account.
- [DiscoveryRecoveryGameTests.java:112–119](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryRecoveryGameTests.java#L112)
  exercises actual DataStorage.save() dispatch and reads the saved visit,
  checking both dirty flags clear after success.
- The GameTest drives a local production manager synchronously; it does not
  replace SatelliteRuntime. A batch-owned fixture replaces/restores both
  SavedData objects. It tests lazy END-tick initialization, not an actually
  dispatched ServerStartedEvent; its direct local catalog change is not a
  native datapack uninstall/reload. These remain explicit evidence boundaries.

Final source snapshots are in `final-source/`; accepted final ADR wording is
`ADR-038-final-reviewed.md`. Prior immutable reviews remain at:

- `C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-contract-review-c80a027a3fa143b98ad74e534deead67/REVIEW-CONTRACT.md`
  SHA-256 `43ddd8760114d9341af7ce91934eb66389c7ab7f0d7c812936121bbf075bf7b7`.
- `C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-source-review-99f5dae5ba2140748ef51945b7fb17d7/REVIEW-SOURCE-01.md`
  SHA-256 `f913991c5dcdff60a702bc2b89e9020f8bdcebaa0ccc0ca5dc5d22d49d2ea5e8`.

## Independently executed commands

Working directory: `D:/GitHub/AdvancedRocketry-Community`.
`JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, `PYTHONUTF8=1`.
Exact argv, timestamps, durations and exits are preserved in
`focused-result.json` and `integration-result.json`; `run-checks.ps1` is the
executed driver.

```powershell
.\gradlew.bat test --tests '*AtomicSavedDataTest' --tests '*DiscoveryClaimRecoveryTest' --tests '*DiscoveryReplayQueueTest' --tests '*SatelliteMissionSavedDataTest' --tests '*SatelliteMissionRegistryTest' --tests '*CelestialSavedDataTest' --tests '*PlanetaryDiscoveryTest' --tests '*WorldDataMigrationServiceTest' --tests '*PopulatedWorldDataPreservationTest' --tests '*ManagedSavedDataLoaderMigrationTest' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain

.\gradlew.bat runData runGameTestServer --offline --no-daemon --no-build-cache --console=plain
```

| Execution | Observed result |
|---|---|
| Forced focused JUnit | Exit 0, 54.0043583 seconds; 71 cases / 10 suites; 0 failures, errors or skips; 16/16 tasks executed |
| DataGen + GameTest | Exit 0, 153.6317104 seconds; all 236 Required tests passed; 5 tasks executed, 13 up-to-date |
| DataGen output | 34 current-version JSON resources, written 0; existing generated diff unchanged |
| World provenance | `build/gametest/world` absent before both commands, present afterward; fresh-world run, no reviewer clean/deletion |

Focused suite counts are 5 CelestialSavedData, 6 PlanetaryDiscovery, 6
AtomicSavedData, 1 ManagedSavedDataLoaderMigration, 18 PopulatedWorldDataPreservation,
8 WorldDataMigrationService, 4 SatelliteMissionRegistry, 5 SatelliteMissionSavedData,
14 DiscoveryClaimRecovery, and 4 DiscoveryReplayQueue. Raw XML/binary test output
is copied under `focused-xml/`. This independent run did **not** rerun the entire
922-case JUnit suite; that count belongs to the root's separate build.

Full raw command logs:

- `focused.log`: SHA-256 `99ffff3fdeff250df7de163ae6169d776f386da648ec93393817be86f20fca99`.
- `integration.log`: SHA-256 `b61d7476b86f44b5e2428513bc50c7f936d6002786225281b2ac9bdaec31c1c1`.
- Original GameTest `latest.log` and `debug.log` are copied under `gametest-logs/`.

Both owned commands and the wrapper session terminated normally. The exclusive
Gradle/JVM slot was explicitly returned to root **after** terminal completion
and post-run identity comparison. No further reviewer JVM is running/planned.

## Warnings and intentional failures retained

- Fresh-world GameTest logged `Can't keep up` at 2,018 ms / 40 ticks. It is
  retained, not rerun away, and provides no performance-Gate evidence.
- The injected launch persistence failure is preceded by
  `ARCE_DISCOVERY_EXPECTED_SAVE_FAILURE testing launch acknowledgment`, followed
  by `Satellite launch operation failed` and the regular-file refusal cause.
  This single expected project ERROR is the negative test's real failure path,
  not an unexpected successful-save assertion.
- `gametest-error-lines.txt` retains all 15 ERROR lines in the command log:
  one fresh-world missing server.properties diagnostic, the one marked satellite
  fault, and 13 pre-existing Precision migration fault/readback diagnostics.
  No FATAL line or failed Required test was observed. This is **not** a zero-ERROR
  run claim. Full stack traces and surrounding markers remain in the raw logs.
- Compiler deprecation warnings and Gradle's future Gradle-9 compatibility
  warning remain in the logs. Test failure fixtures also retain their diagnostic
  output inside the JUnit XML. There was no independent command failure to erase.

## Input and artifact evidence

`capture.py before` and `capture.py after` ran with
`D:/python/pyenv/pyenv-win/shims/python.bat -B`. They hash tracked plus new task
runtime/build/Python/generated files selected through scoped `git ls-files`,
never traversing the excluded user bundle.

- 1,359 inputs before/after: **zero changes**.
- Generated-resource Git diff: unchanged; no generated writes were observed.
- All three build/libs JARs unchanged and byte-identical to root's immutable
  `artifacts-final/` copies.
- ZIP inventory: main 1,446 entries, API 45, sources 1,154; no duplicate names.
- Independent lightweight ZIP inspection found exactly 27 exported API class
  files, each byte-identical to its main-JAR class. All 34 v1.4 JSON resources
  match source bytes in both main and sources JARs. API hash remains the prior
  unchanged 1.7 classifier identity.

| Artifact | SHA-256 |
|---|---|
| Main, 2,624,223 bytes | `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475` |
| API, 48,469 bytes | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources, 1,193,936 bytes | `afc83ef63e3054657831bfb6e170cbc4a6cbffe3029738ec3a6bb562474dc8db` |

Inputs/results are recorded in `identity-before.json`, `identity-after.json`,
`identity-comparison.json`, `artifact-content.json` and `focused-counts.json`.
JAR comparison proves identity with the root's packaged build, not that the
reviewer independently rebuilt/reobfuscated those JARs with the focused test task.

## Remaining bounds

No native scripted server was launched by this reviewer. Root's later packaged
run has not been independently audited in this report; raw readback belongs in
a separate immutable supplement. Deterministic six file-barrier cuts are not a
hardware power-cut guarantee. No arbitrary external file tampering, unsupported
filesystem atomicity, terminal chunk/mission atomicity, broad migration matrix,
real client/network-player behavior, GPU, multiplayer or long-load campaign was
tested. Root-authored docs changed during verification, but runtime/build/Python/
generated inputs and artifacts did not. No tracked/index writes, excluded-bundle
reads, remotes, credentials, process termination or subdelegation were performed.
