# V140-MIG-01 independent native evidence supplement

## Findings and disposition

No additional concrete inconsistency was found in the captured clean-save,
upgrade and restart regression. This conclusion is confined to the raw evidence
listed below, not general migration/recovery or release acceptance. The earlier
source/contract observations and cancellation acknowledgment boundary remain in
`REVIEW-EXECUTION.md`; that report is unchanged.

Important applicability limits:

- The baseline is the earlier **MAP-01 v1.4 development JAR**, not a v1.3 release
  world. All three JVMs performed orderly save/stop. This is not native evidence
  of a process cut, missing/re-added body, failed file barrier or historical
  CLAIMED receipt repair. Those deterministic cases are separately covered to
  the extent recorded in the execution report.
- Native commands use the operator/release-test route with no network players.
  They establish ordinary research claims, replay conservation and planetary
  travel continuity, not real-client menu/permission or multiplayer behavior.
- The two warning inventories count different formats: runner observations have
  25/10/10 bracketed `/WARN]` events; the independent raw-token count is
  26/11/11. Each process also emits one unbracketed startup message,
  `main WARN Advanced terminal features are not available in this environment`.
  Neither count implies a zero-warning run.

The slice's implementation plus independently executed focused JUnit/GameTests
and this clean packaged regression support a scoped MIG-01 verification record.
They do not complete parent MIG work, S2/power-cut validation, V1/V2 or all
Required Gates.

## Evidence and method

Audited root evidence, read-only:

`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-claims-7ff01118440047f59bae982f7891efc6/native`

Phases: `baseline`, `upgrade`, `restart`. Independently recomputed all **150**
manifest hashes, rejected duplicate/unsafe entries, and matched the manifest to
the actual captured files. All three captured process receipts report exit 0;
raw logs contain readiness, saving chunks and stopping. Each command ledger
includes `save-all flush` and ends with `stop`. Launch receipts use Java 17.0.7,
Forge 47.4.10, 512 MiB initial/1 GiB maximum heap, `nogui` and the explicit
release-test-hook property. Root reports outer runner exit 0 in 125.2216328 s;
that duration is not an independently timed runtime execution.

No JVM, Gradle task or server was launched during this supplemental audit.
The independently authored `audit_native.py` reads compressed SavedData and
Anvil entity records using existing low-level bounded decoding primitives; it
does not call the runner's acceptance/oracle functions. It compares those raw
authorities and logs with derived captures only after decoding the originals.

Executed command, with `PYTHONUTF8=1`:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-final-review-148b917d52a943339b2114c85f94e0e0/audit_native.py
```

The first helper attempt exited 1 because its comparison incorrectly sliced
`observations['upgrade']['reports'][2:]`. Repeated diagnostic queries are not
appended to the harness's accumulated reports; both complete arrays contain
four assembly/landing reports. After inspecting the actual append sites, the
helper now requires equality of the complete arrays. The original helper
(`audit_native-attempt01.py`) and traceback (`native-audit-01.log`) are retained.
This was a reviewer-helper assumption, not a production/harness failure; no
runtime or evidence was modified. The corrected run exited **0**, retained in
`native-audit-02.log` and `native-artifact-audit.json`. Additional exact flight
receipt and phase assertions also passed in that run.

## Artifact and input identity

The frozen current artifacts match the independent execution report and
`build/libs`; no duplicate ZIP entries, CRC failures or fixture package leaks
were found. The API archive contains exactly **27** classes, all byte-identical
to the main archive. **34** current-version generated JSON resources match
repository/main/sources bytes.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Main | 2,624,223 | `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475` |
| API | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1,193,936 | `afc83ef63e3054657831bfb6e170cbc4a6cbffe3029738ec3a6bb562474dc8db` |

Baseline host: 2,412,477 bytes, SHA-256
`9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`,
from the MAP-01 artifact directory. Native gameplay loads the host, not the
API/sources archives; their checks are packaging evidence.

Unchanged reviewed harness `scripts/run_v140_planetary_worlds_smoke.py`:
`8317d39756f882b0ee7893f1efc3b238537dde88d8e1a4cddf3738eb65bf73de`.
The packaged satellite definition is schema 1, duration 200 ticks, yield 120,
discovery cost 100 and the six declared Earth/Moon/Space/Mars/Venus/gas targets.

## Raw research and replay authority

The decoded satellite and celestial stores have schema 2; mission, satellite and
account records have schema 1. Three logged launches bind actual mission,
satellite, owner and target identities to Mars, Venus and gas giant. Each uses
`advancedrocketrycommunity:data_satellite`, a captured 200-tick duration and
yield/cost 120/100; ready/resolved timestamps satisfy the captured deadline.

All three saved missions are CLAIMED, each satellite is operational with no
current mission binding. The two accounts are exactly:

| Owner | Balance | Lifetime earned | Lifetime spent |
|---|---:|---:|---:|
| `00000000-0000-0000-0000-000000000005` | 40 | 240 | 200 |
| `c191ac5f-97e5-4b8f-ab04-bb0a958d28b2` | 20 | 120 | 100 |

Celestial progress has exactly three discovered bodies, with nonnegative
discovery timestamps and no first-visit timestamps in this no-player run.
Upgrade logs contain SUCCESS then ALREADY_CLAIMED for each mission (six claim
receipts). Restart contains three ALREADY_CLAIMED receipts. Target, owner,
mission and discovery status match the raw authorities. Mission/satellite/
account arrays and the complete progress root are exactly equal across upgrade
and restart. Scheduler logical time is intentionally not required to remain
unchanged.

Before research, the attempted Mars launch returns DISCOVERY_REQUIRED with
required fuel 0 and available fuel 2000; repeated reports show no state mutation.

## Flight, cargo, station and binding authority

Each phase's captured entity regions contain exactly one rocket. Bounded scans
observed material/empty-region/chunk counts of 4/4/40, 4/20/52 and 4/20/51;
these are within the retained 16/32/128 limits. Its logical identity is
`5bc4fecf-a0a0-4364-8aff-0439608244ba`, with the same owner, six-block snapshot
and exactly 17 diamonds plus 64 iron in its single cargo block entity.

Actual launch and transfer-phase receipts bind the three positive fuel debits:

| Leg | Fuel before | Debit | Fuel after |
|---|---:|---:|---:|
| Earth to Mars | 2000 | 448 | 1552 |
| Mars to Venus | 1552 | 533 | 1019 |
| Venus to Earth | 1019 | 515 | 504 |

Each transfer has the exact eight logged transitions from countdown completion
through retained landed reservation, with consistent entity/logical/source/
target identities. Final saved state is LANDED on Earth, fuel 504, typed
BodySurface Earth target, no active plan/transfer and exactly those three fuel
debit IDs. The complete saved RocketEntityData is equal across restart.

The final schema-2 transfer journal contains one COMMITTED reservation, cost
515, source fuel 1019 and destination fuel 504. Its destination snapshot equals
the saved entity snapshot; transfer SavedData bytes are equal across restart.
Station counts are 1/3/3, retaining the original station and the entire final
station root. Binding counts are 3/6/6, retaining the original reservations,
explicit unmapped gas giant, and the complete final binding JSON. The same-world
marker is also unchanged across restart.

Raw `level.dat` hashes are retained but the registry-heavy file was **not fully
decoded**, nor claimed byte-immutable: baseline
`9a1f6b629e26a9148ddda616da03b636c80bd5f0738b5c0d75ce641c3fa22358`,
upgrade `e35b0c4fb374ddae9c35fae93e0b2243481f20be8e362dd7e546124109b735f9`,
restart `83f5a107d9a1bbfb0ba703a03a899da940f8582cd75a5e837630d03d26fba770`.
The compressed Forge status mod list was not independently decoded. Artifact
and launch identity checks do not imply that additional status-protocol check.

## Logs, preservation and remaining boundaries

All nine stdout/latest/debug variants were checked for ERROR/FATAL severity and
common class-linkage, OOM and uncaught-thread failure signatures; none were
found. No native `Can't keep up` warning was observed. The startup/configuration,
offline-server and terminal warnings remain in the evidence as described above.
This does not remove the independent GameTest warning or intentional fault logs
already recorded separately in `REVIEW-EXECUTION.md`.

No full-world block/item invariance, hardware crash guarantee, atomicity across
terminal chunks and mission files, unsupported filesystem behavior, actual
v1.3-to-v1.4 migration, real client/GPU, multiplayer, long-load or complete
removed/re-added-definition campaign is established here. The reviewed
clean-cycle evidence does not replace those remaining requirements.

The original execution report SHA-256 remains
`0670633b95ba6d1265b5c4eafec452d315af6e3dbe6149b69fb454e46f3fb6b3`.
Its original 41-member manifest is preserved as `SHA256SUMS-execution`, SHA-256
`a7422efba6d5495f248e0055afcd7b01cd31cb73bda00bece6ff144ac3dd9304`.
The updated `SHA256SUMS` adds this supplement and all retained native audit
attempts without replacing the execution report or changing root evidence.
