import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
FROZEN = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-claims-7ff01118440047f59bae982f7891efc6/artifacts-final')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode('utf-8')

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

label = sys.argv[1]
paths = sorted(set(git('ls-files', '--cached', '--others', '--exclude-standard', '--',
    'src', 'scripts', 'tests', 'compat-test-mod', 'gradle', 'build.gradle', 'settings.gradle',
    'gradle.properties', 'gradlew', 'gradlew.bat', 'LICENSE', 'NOTICE.md', 'THIRD-PARTY-NOTICES.md').splitlines()))
assert all('AdvancedRocketry-Community-v1plus-Development-Docs' not in p for p in paths)
inputs = {p: identity(REPO / p) for p in paths if (REPO / p).is_file()}
artifacts = {}
for path in sorted((REPO / 'build/libs').glob('*.jar')):
    frozen = FROZEN / path.name
    row = identity(path)
    row['frozen'] = identity(frozen)
    row['matches_frozen'] = row['sha256'] == row['frozen']['sha256']
    with zipfile.ZipFile(path) as jar:
        names = jar.namelist()
        row['entries'] = len(names)
        row['duplicate_entries'] = len(names) - len(set(names))
    artifacts[path.name] = row
result = {'head': git('rev-parse', 'HEAD').strip(), 'inputs': inputs, 'artifacts': artifacts,
          'world_present': (REPO / 'build/gametest/world').exists(),
          'generated_diff': git('diff', 'HEAD', '--', 'src/generated')}
(OUT / f'identity-{label}.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'label': label, 'head': result['head'], 'inputs': len(inputs),
                  'world_present': result['world_present'], 'artifacts': artifacts}, indent=2))
assert len(artifacts) == 3 and all(x['matches_frozen'] for x in artifacts.values())
assert all(x['duplicate_entries'] == 0 for x in artifacts.values())
if label == 'after':
    before = json.loads((OUT / 'identity-before.json').read_text(encoding='utf-8'))
    changed = [p for p in sorted(set(inputs) | set(before['inputs'])) if inputs.get(p) != before['inputs'].get(p)]
    checks = {'changed_inputs': changed, 'generated_diff_unchanged': result['generated_diff'] == before['generated_diff'],
              'artifacts_unchanged': artifacts == before['artifacts']}
    (OUT / 'identity-comparison.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(checks, indent=2))
    assert not changed and checks['generated_diff_unchanged'] and checks['artifacts_unchanged']
