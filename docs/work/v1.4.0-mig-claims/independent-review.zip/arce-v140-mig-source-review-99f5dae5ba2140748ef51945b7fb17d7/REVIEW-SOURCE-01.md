# V140-MIG-01 independent source review, revision 01

## Findings

No concrete unresolved correctness finding was identified in the inspected
production implementation. This is a source review of the actual tracked diff
and new files, **not** evidence that compilation, tests or native interruption
recovery passed. The root is still adding integration/native coverage.

The following verification gaps remain material to the scoped conclusion:

1. The new pure queue tests establish queue mechanics, not SatelliteManager's
   actual runtime enrollment, retry/backoff and stop/reinstall wiring. Exercise
   a newly paid unavailable claim, restore the same body without another claim,
   and observe automatic completion; include an I/O failure and stop cleanup.
2. Historical CLAIMED repair is tested with an idle satellite. Add a receipt
   whose satellite already has a newer active/current mission; repairing the
   old discovery must preserve that newer binding and all account values.
3. Ordinary `save(File)` is tested directly. A native or GameTest observation of
   DataStorage autosave dispatch and dirty retention would connect the override
   to the actual platform caller. Real process interruption is not established
   by throwing a test Error between synchronous writes.

These are explicitly unverified boundaries, not assertions that these code
paths currently fail.

## Inspected behavior and reasoning

- [AtomicSavedData.java:34–44,57–101](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData.java#L34)
  replaces ordinary save dispatch as well as explicit flush. Explicit flush
  marks dirty before all fallible work, validates the stable filename and real
  directory/file ancestry, writes the fixed scratch path with NOFOLLOW_LINKS,
  forces it, bounded-reads and compares the entire wrapper, then requests only
  ATOMIC_MOVE + REPLACE_EXISTING. No fallible operation follows successful
  replacement before dirty=false. Failure cleanup only removes the staged
  scratch file after this attempt opened it. An existing non-regular obstacle
  is refused, not deleted. Ordinary failure logs once and retains dirty;
  explicit failure propagates.
- The server flush destination is root/data, matching these Overworld-owned
  identities. It does not create parent directories itself. This is supported
  by the earlier world binding lifecycle:
  [PlanetaryBindingStore.java:46–53](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindingStore.java#L46)
  creates and validates that directory before Level startup. Tests use their
  existing Temp directory.
- [CelestialSavedData.java:145–163](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L145)
  rejects future/full state before committing, clones the complete valid root,
  applies discovery to that candidate, calls the checked writer, and only then
  publishes progress. The same path acknowledges an existing dirty visit without
  replacing discovery/visit timestamps. Failure before the callback returns
  leaves live progress unchanged. Existing ordinary visits retain their prior
  in-memory semantics; no stronger visit transaction is claimed.
- [DiscoveryClaimRecovery.java:19–46](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryClaimRecovery.java#L19)
  accepts only discoveryRequired pending/claimed receipts and a presently
  available target. The actual sequence is mission flush, candidate celestial
  flush, candidate publication, finishDiscovery, and final mission flush if
  changed. Historical CLAIMED stays terminal; barrier A still acknowledges it.
  Missing/full/future work does no repeated replay write. The manager separately
  saves a newly created paid pending receipt even when this path cannot apply it.
- [DiscoveryReplayQueue.java:14–35](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryReplayQueue.java#L14)
  deduplicates UUIDs, caps at the existing 8192 mission bound and captures a
  maximum eight-entry batch before iteration. Pending/error entries rotate to
  the tail in finally, including thrown callbacks. A single pending entry is
  therefore attempted once, not eight times in a tick.
- [SatelliteManager.java:413–489](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L413)
  enrolls startup pending and historical paid CLAIMED receipts missing progress;
  live pending/eligible claimed operations enroll before recovery. Dirty pending
  state is explicitly flushed after unavailable/full/future outcomes. Exceptions
  leave queue entries retained. The retry loop backs off by 20 ticks after an
  exception and suppresses repeated failure diagnostics until the queue clears.
  Its finally synchronization can expose a successfully committed discovery
  even if the final mission write fails, which is consistent with its already
  durable pending receipt and celestial record. Clear resets queue/backoff state.
- The two SavedData types retain IDs, schemas and record encoding. The checked
  mission flush no longer invokes a whole-DataStorage save. Other callers were
  inspected, including launch/start/cancel and terminal package consumption.
  This change does not make their inventory/chunk transaction or other SavedData
  files atomic, and their broader interruption guarantees are not certified here.

## Tests inspected, not executed

- `AtomicSavedDataTest`: full wrapper/ordinary save, explicit clean-object
  acknowledgment, refused atomic move with old bytes retained, ordinary failure
  dirty retention and retry, leftover scratch, wrong identity/non-regular target,
  oversized expanded output refusal. Uses actual Temp files/readback.
- `DiscoveryClaimRecoveryTest`: six before/after barrier cuts reload actual
  files; three same-process acknowledgment failures; dirty existing visit;
  historical terminal repair; absent/full/future refusal; unpaid/cancelled and
  non-discovery exclusions. The account oracle checks balance, lifetime earned
  and lifetime spent. `Cut extends Error` models an immediate stop between
  writes; it is not an actual killed JVM or filesystem power failure.
- `DiscoveryReplayQueueTest`: deduplication, fair bounded work, one pending
  receipt attempted once, exception retention/order, capacity and clear.

Potential further native failure cases remain stage creation/write/readback,
unsupported atomic replacement and actual autosave behavior. The checked writer
can validate ordinary process-interruption ordering; neither file force nor
rename proves portable directory durability after sudden hardware power loss.
The original pre-start migration corruption/future guards remain necessary.

## Evidence identity and commands

Base: `cbff561a8e949c25e93d51365a260e0fd061be4d`. Reviewed working inputs are copied
byte-for-byte in this directory with 10 entries in `reviewed-inputs.json`,
including the six production files, three new JUnit files and accepted ADR-038.
Tracked production diff is separately retained; new source snapshots are not
omitted merely because Git reports them as untracked.

Key SHA-256:

- AtomicSavedData: `6d23415f02c9fb9ed9c823ce2c1be96e99d2326997d4937dc3395684d5dd203f`
- DiscoveryClaimRecovery: `e5cef4f451924463c0f3bc08b6a577c31a45d2a84fffa214cb3d4dfb7ac5a906`
- DiscoveryReplayQueue: `89e4975d26b665e881eae8b732b4f0701d4bff9de5043bfde56c68de3bec63a6`
- SatelliteManager: `d33b7154355a1d93bd0db2372c96f335c965b57e6f12ac98513f3b8c16975ebc`
- ADR-038: `8e8091cec56f96cf228a8278c81dab27d84fc22334c0025efe9000a45db700f2`

Actual operations: scoped `git status`, `git diff --stat`, `git diff -- <source>`,
`git rev-parse HEAD`; numbered `Get-Content` source/test reads; `rg` caller
searches; read-only local Forge cache filename listing; SHA-256 and byte-for-byte
Copy-Item into this uniquely named Temp directory. One exploratory search for
`satellite/menu` failed because the actual caller is under `satellite/terminal`;
the correct file was read. No Gradle, JVM, Python test, native server, network,
tracked/index edits, excluded-bundle reads or subdelegation occurred.

This report does not approve implementation completion or any release Gate.
Subsequent GameTests, native harness and any revised source need their own
identity-bound review and executable results after root releases the test slot.
