# V140-ENV early implementation source review

## Findings

No concrete new correctness defect was identified in this evolving implementation snapshot. This is an early source review, not final runtime verification or a claim that the implementation/tests are complete.

The contract review is separately preserved in `arce-v140-env-contract-review-926cc35df9684b478aa57c1aec3e6cae`; the cadence wording clarification is resolved there. It must not be replaced by this implementation report.

## Actual source observations

- `CelestialDefinitionCodec:17-20,48-52,59-65,85-95,116-120`: new strict optional boolean is encoded explicitly, defaults only when absent, rejects legacy presence and lossy legacy encoding. Both existing model constructor forms remain available with false defaults (`CelestialBodyDefinition:60-77`). `PlanetaryContent:31-45` opts in only Mars/Venus surfaces, not the unmapped gas body.
- `CelestialEnvironmentService:30-38`: shared Space is explicitly disabled; ambiguous/missing catalog mappings produce disabled extra effects. Existing gravity and conservative oxygen resolution are unchanged. Display snapshot code remains unchanged and intentionally omits the server-only flag; no new exported API source/build change was present.
- `AtmosphereLevelService:93-105,193-215,224-248`: separate climate requirement preserves the breathable opt-out shortcut; room protection uses a loaded indexed volume and an active supplied loaded provider. The same bounded scan and provider-election/resource-debit machinery is reused. This query is not ambient breathability. Synchronous invalidation remains intact.
- `PlayerLifeSupportService:65-110`: exactly one existing oxygen read/transaction remains, then the new service receives whether suffocation was attempted. No duplicate oxygen-provider call path was added by exposure.
- `EnvironmentalExposure:17-49`: hazard masks, priority and shared 20-tick phase are bounded. Complete protection resets; partial mask changes retain cadence. `PlayerEnvironmentalService:34-59` resets phase on Level/condition changes, suppresses the environmental damage attempt when suffocation was attempted, handles exemptions/death, and throttles bounded localized warnings. `:62-64` guards sunlight checks by loaded chunk. Logout/stop cleanup is wired through the existing service.
- `EnvironmentalProtection:22-36`: passive protection requires count one and correctly slotted ArmorItem in all four slots, then checks the three tag memberships independently. It does not read oxygen or imply API registration.
- `PlanetaryExposureProvider:23-43` adds four damage definitions and three item tags; existing vacuum bypass tags are untouched. Language provider supplies warning names and base/player death messages. Generated resources were not yet rebuilt or inspected as executable artifact evidence.
- Initial `EnvironmentalExposureTest` and `EnvironmentalDefinitionTest` were read: finite boundaries, eight protection combinations, cadence/reset, invalid values, JSON/NBT opt-in, omitted/default/legacy rejection and ambiguous/missing/Space lookup are present. Their existence is not a PASS claim.

## Required remaining evidence

Runtime/fixture implementation was still being added. No Gradle, JUnit, Python test, GameTest, native server or client was run by this reviewer. Actual tests must establish breathable hostile-room resource consumption and invalidation, armor/tag application, damage/cancellation/immunity and coincident suffocation, reload/profile/exemption lifecycle, loaded sunlight without tickets, unchanged Earth/Moon/Space/oxygen behavior, generated resource validity and packaged restart resource/state observations. No long-load or full acceptance campaign is requested by this report.

## Identity, commands and write boundaries

Baseline `d120d4152689022473512329a44cd29a29317b2f`. The 17 explicitly scoped changed/new Java files are hashed in `source-inputs.json` and copied under `snapshot/`; `tracked-source-diff.patch` captures the actual tracked diff. This snapshot is intentionally time-bounded while the root continues adding tests.

Read commands: scoped `git diff`, `git status --short`, `git ls-files`, `rg --files`/`rg -n`, numbered PowerShell `Get-Content`; `git diff --check -- src/main/java src/test/java` produced no diagnostic. A Windows wildcard operand for `Planetary*Tests.java` was not expanded by rg and failed as a path lookup; no test execution occurred. Source snapshots/report/hash writes are confined to this fresh Temp directory. Repository tracked/index/build/generated files were not written; the excluded user bundle was not read. Root retains the Gradle slot.

Status: early read-only source review complete; final independent diff/key execution remains pending, not Gate approval.
