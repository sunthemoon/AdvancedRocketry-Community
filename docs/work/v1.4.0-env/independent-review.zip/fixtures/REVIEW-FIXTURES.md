# V140-ENV GameTest source review (initial fixture snapshot)

## Findings

### P2 - The power-exhaustion setup cannot remove any vent energy

`PlanetaryClimateGameTests.java:66-68` obtains the energy capability and calls `extractEnergy(stored, false)` before asserting stale climate protection is revoked. The actual vent constructs `EnergyStorage(capacity, capacity, 0)` at `OxygenVentBlockEntity.java:382-385`; ordinary extraction is disabled. The call therefore cannot create the intended exhausted state. With the preceding 21 supply ticks, the vent still has 39,580 energy and the ACTIVE, loaded provider remains valid. This is a deterministic fixture setup error, not a production protection failure.

Minimal correction: drive actual remaining consumption through bounded `applySupply(SEALED, true)` calls (at most 2,000 calls by the existing 40,000/20 limits), assert zero energy and the last ACTIVE status, then query `controlledAt` before another manager tick. This exercises the current-resource guard against stale provider authority. Loading a zero-energy native root also changes status to SCANNING, so by itself it does not isolate the same stale-ACTIVE condition. Do not alter production energy extraction policy. The finding was sent to root while its test command remained root-owned; this reviewer ran no Gradle.

## Actual fixture coverage and isolation

- `PlanetaryExposureGameTests:45-69` invokes the real environmental service and registered cold/pressure damage on existing Mars/Venus ServerLevels, then the existing gravity controller. Players, catalogs and services are fixture-local; no player is added to the global player list or world entity set. The 20 service calls are synchronous calls, not 20 naturally ticking player frames.
- `:71-98` uses the actual integrated life-support entry point and built-in tag membership; it verifies exact one-unit oxygen consumption, empty-suit vacuum damage, wrong-slot/count rejection, and one attempt at a coincident interval. This does not exercise an external oxygen provider callback counter.
- `:100-144` covers complete protection, warning clear, creative/spectator/dead exemptions, direct remove/clear lifecycle, private catalog replacement and legacy Levels. Private `applyCandidate` is not a native `/reload`; direct remove/clear is not an actual logout/server-stop event. Those are appropriate focused service tests if described accurately.
- `:146-169` verifies an overridden immunity hook and a hurt-return-false cancellation probe; the latter is not a registered Forge cancellation listener. The separate unaged FakePlayer test retains the spawn-grace case.
- `:171-198` probes daylight/night/roof and unloaded far columns with no chunk-count increase. The correction moves the query above existing terrain in the fixture's own x/z column, restoring the roof and day time in finally. Its dedicated batch avoids concurrent GameTests observing the temporary time change; the probe is outside template height but not another horizontal fixture column.
- `PlanetaryClimateGameTests:27-76` uses a private manager/catalog with a genuinely hostile breathable Earth profile and real vent storage. It checks exact shared supply cost, bounded scans, immediate dirty-wall revocation, ambient/controlled distinction and repair. The unload check directly invokes `onChunkUnload`; it does not unload an actual chunk.
- `:78-95` retains the old breathable Earth no-scan/no-consumption invariant. Rooms are inside the atmosphere template and the vent is removed in finally; ordinary scheduler cleanup owns the remaining template blocks. `room()` calls the actual vent serverTick, which also observes it in the runtime manager, but synchronous private-service testing does not interleave normal ticks, and removing the BE removes its runtime registration.

## Retained initial failures and test corrections

Read the root's preserved `targeted-gametest-1.log`: three required failures are the two initial environmental health assertions and the open-day column assertion. The report does not erase or relabel those failures. The root's `spawn-invulnerability-inspection.txt` shows ServerPlayer.hurt checks spawnInvulnerableTime before ordinary hurt and that the normal player tick decrements it. The revised fixture clears only mapped field `f_8921_` for post-spawn FakePlayers, while retaining a separate unaged spawn-grace test. New damage tags/production behavior were not changed to bypass grace. This is a scoped test setup correction; no final PASS is inferred from source or root progress output.

## Checks and remaining limits

Read-only commands: scoped git diff/status, numbered PowerShell source reads, root Temp directory/log/bytecode-text reads, and a local cache-directory listing. Three explicitly relevant source files were copied and hashed in this Temp directory (`inputs-initial.json`). No repository/index/generated/build edit, Gradle/JVM/server/test command, network, user-bundle read, agent or OpenPet update was performed.

Production source remains consistent with the previously reviewed strict opt-in, separate room authority, bounded masks/cadence, one oxygen transaction and unchanged damage bypass tags. Unfinished tests are not a claim of final coverage. Final source/fixture diff, generated artifacts, actual command outcomes and packaged native evidence remain for later authorized verification; this report is not full acceptance or Gate approval.
