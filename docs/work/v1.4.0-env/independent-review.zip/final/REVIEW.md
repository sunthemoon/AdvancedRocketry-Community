# V140-ENV independent final review

## Findings and resolution

No unresolved concrete correctness finding was identified within this source, focused-test, artifact and bounded native-readback scope. This is not full-version acceptance or Gate approval.

- **Resolved P2 fixture setup:** the prior `PlanetaryClimateGameTests` attempted to exhaust an input-only FE capability. The final `PlanetaryClimateGameTests.java:67-78,128-129` instead seeds exactly 22 existing supply intervals, consumes them through the real manager/vent, explicitly observes zero energy while status is still ACTIVE, checks immediate loss of control and verifies refill before synthetic unload. No production extraction policy, assertion, scan budget or timeout was weakened. The earlier finding report remains unchanged.
- **Resolved P3 contract ambiguity:** ADR-034:40-45 fixes shared cadence across partial hazard changes, suffocation-attempt interval consumption, and transient reset on entity replacement/Level/profile/lifecycle changes. The original contract report and separate resolution are retained.
- **Resolved P3 reader-document clarity:** `docs/CELESTIAL-DATA-GUIDE.md:126-131` now fully qualifies all three protection tag IDs. Both initial and corrected guide copies are retained here; Java/test/generated inputs did not change during the reruns.
- **Retained failed test attempts:** root's original spawn-grace, below-terrain sunlight, FE-extraction and immediate-lighting assertions remain in its Temp evidence. Post-spawn FakePlayers age only their mapped spawn-grace field; an unaged-player regression remains. The sunlight assertion waits two ticks for queued lighting within the original 40-tick timeout and restores the owned roof/time in finally. No production damage bypass tag was added to make those tests pass.

## Scope and source identity

Repository `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.4.0-planetary-expansion`, reviewed uncommitted slice against `d120d4152689022473512329a44cd29a29317b2f`. Root is the sole tracked writer. All reviewer writes were authorized Gradle build/cache outputs or this fresh Temp directory; no tracked/index/generated edit, excluded user-bundle read, remote/client/load run, other agent or OpenPet action occurred.

The final code was rechecked against ADR-034 and the reader guide. Relevant behavior includes:

- Strict absent-only opt-in, rejected malformed/legacy flag and rejected lossy downgrade; old authoring constructors default false. Mars/Venus enable effects and gas does not.
- `CelestialEnvironmentService.surfaceExposure` excludes shared Space and missing/ambiguous mappings; existing gravity and conservative oxygen resolution remain distinct.
- `AtmosphereLevelService` uses a separate loaded ACTIVE supplied-volume `controlledAt` query and opt-in climate-scanning reason, retaining the old breathable Earth no-scan/no-consumption shortcut and synchronous dirty revocation.
- `PlayerLifeSupportService` completes the existing oxygen transaction once, then passes its actual suffocation-attempt boolean to exposure. `PlayerEnvironmentalService:34-59` keeps one bounded phase, resets on entity ID/Level/conditions changes, and uses normal `hurt`; warning messages contain a fixed maximum of four localized hazard names. The new IDs do not enter the old vacuum bypass tags.
- Passive armor tags require exactly one correctly slotted ArmorItem in all four slots, independently of oxygen registration/data. Logout and server-stop cleanup remain in the existing server-owned lifecycle.

`inputs-before.json` and `inputs-after.json` cover **1,296** scoped tracked/new source, scripts, tests, generated resources and build inputs: **zero path/length/hash differences**. The tracked source/resource diff is preserved in `source-diff-before.patch`. Documentation was allowed to evolve separately; this is not an assertion that the entire working tree was clean or unchanged.

## Independently executed commands

Java: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`.

```text
.\gradlew.bat test --tests '*Environmental*Test' --tests '*PlayerLifeSupportEngineTest' --tests '*VentSupplyEngineTest' --tests '*VolumeScan*Test' --tests '*SuitEquipmentRegistryTest' --tests '*SuitOxygenAccessTest' --tests '*Api*Test' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

**Exit 0, 48.647 s; 77 tests / 10 suites; zero failures/errors/skips. All 16 tasks executed.** This is actual forced focused execution, not cached XML. Raw log, exact receipt and the ten XML files are retained. Counts: ApiArtifact 16, ApiVersions 9, PlayerLifeSupportEngine 5, VentSupplyEngine 3, VolumeScanCoordinator 6, VolumeScanTask 5, EnvironmentalDefinition 5, EnvironmentalExposure 7, SuitEquipmentRegistry 8, SuitOxygenAccess 13.

```text
.\gradlew.bat runGameTestServer --offline --no-daemon --no-build-cache --console=plain
```

**Exit 0, 97.833 s; all 229 Required GameTests passed.** This independently ran the new nine environment fixtures plus the existing suite in the **reused `build/gametest` world, without clean**. Three tasks executed, fourteen up-to-date; the GameTest task actually ran. Logs and exact receipt are retained. The log has thirteen expected ERROR-severity lines from deliberate Precision migration save-fault cases; `gametest-classification.txt` preserves them. No lag warning or unexpected failure was observed in this independent run. Do not describe it as a zero-ERROR log or performance acceptance.

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B <review-directory>/artifact_audit.py
D:/python/pyenv/pyenv-win/shims/python.bat -B <review-directory>/native_audit.py
```

Both **exit 0** with `PYTHONUTF8=1`. The native audit took 0.765 s. These are independent readback helpers, not a rerun of the root's 24 Python unittests. The native helper was adapted from the prior MAP-02 independent helper, uses only bounded binary NBT/Anvil parsing primitives, and does not call the planetary runner's validation/PASS functions. Its exact source SHA is `c9322ecd2405ec91279eb5dbd5c596f80996179a8a82cebe95baa9ffc206448d`.

Read-only `git diff --check` produced no diagnostic for the scoped source/tests/generated resources/guide. Source/doc inspection used explicit git/rg/PowerShell reads. A separate PowerShell readback checked recorded JVM launch arrays, their actual Forge argument-file digest, artifact association and Java/Forge log identity (`native-launch-check.json`).

**Gradle ownership was explicitly released after both processes terminated and before report assembly. No further Gradle/JVM/server execution is planned by this reviewer.**

## Artifact and resource evidence

All three build artifacts are unchanged before/after independent commands and equal the root's frozen copies:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Main | 2496740 | `0ac84a92b01ef193ea10f534145dff79983b65660d5b4a225f1333c6c7d47252` |
| API | 48469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1138211 | `485d5b790929e2da457135c0bac8b4e895bac8fd12b3cc4f9fc459073a836915` |

ZIP CRC/name-uniqueness checks passed. No adapter-test fixture namespace/resources occur in these artifacts. The **27 API class entries** are all API namespace entries and byte-equal to the main JAR; the full API hash also equals the v1.3 development-handoff API artifact. No isolated consumer rebuild was run or implied.

All **27 generated v1.4 JSON files** match their main-JAR bytes. Independent checks inspected the four new damage definitions (no planetary bypass-tag entries), three exact four-piece tag memberships, both locales' warning/death keys, and Mars/Venus true versus gas false flags. This confirms packaged resources, not action-bar appearance on a real client. The twelve current slice resource changes are five modified plus seven added files.

## Bounded native audit

Read-only root evidence: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-env-58c2564f75a940cb8643e4e3f9d1f8a1/native`.

The exact manifest member set and every digest passed: **144 members**, manifest SHA-256 `0da7bfb493728583c183297a13dc304d6b1e8eff80fa2e6853e46a19987a53aa`. An earlier progress message accidentally carried forward MAP-02's count 145; it was promptly corrected to the actual ENV count 144. Raw evidence was never modified.

Each baseline/upgrade/restart launch receipt binds Java 17.0.7, Forge 47.4.10, `-Xmx1024M`, release-test hooks and the same disposable working directory. All three observation receipts are exit 0 and are supported by ready/clean-stop/save sequences in raw stdout/latest/debug. Baseline actually uses archived pre-planet MAP-01 JAR `9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`; upgrade/restart use the final ENV JAR above. These are actual freshly authored previous-build-world upgrade observations, not arbitrary historical-world migration.

Independent raw Anvil, transfer-journal, station and binding observations:

- Exactly one logical rocket across the declared five-Level capture set, logical UUID `60530198-a1bc-463a-984e-14bbb6776212`, console owner `00000000-0000-0000-0000-000000000005`. Final physical UUID `28af8919-fd6f-404b-b878-066d799968fd` and Earth origin `[64,67,48]` persist through restart.
- Raw launch/event receipts establish Earth -> Mars -> Venus -> Earth, one initial fill, no top-up, fuel **2000 -> 1552 -> 1019 -> 504**, exact debits **448/533/515** (total **1496**), and a rejected gas surface request with zero debit. All eight expected phase events per successful leg bind the actual transfer/logical IDs and fuel values.
- The six-block snapshot's invariant content retains **17 diamond + 64 iron** in its single chest payload. Owner, logical ID, typed target, current body, snapshot relocation, physical position, empty passengers and three debit IDs agree. Complete final RocketEntityData is equal after restart.
- Final COMMITTED journal exactly binds the last Venus -> Earth transfer, required 515, source fuel 1019, destination fuel 504, matching source/destination entity and snapshot authority; compressed journal bytes are unchanged across restart. Intermediate leg persistence is not separately cut/restarted.
- The full existing Moon station record is retained; new Mars and gas stations match their exact UUID/owner/body/name/cell/region command receipts. The complete registry and compressed station file are unchanged upgrade/restart.
- Ledger grows additively from three to six bindings, preserving old entries and adding mapped Mars/Venus plus explicitly unmapped gas; upgrade/restart ledger is equal. Raw commands/logs establish fixed Level resolution and gas refusal.
- Properties compare after removing only the known generated timestamp line. World marker and baseline backup identities match; level.dat files are retained and hashed, **not fully decoded**, and legitimately differ between saves. No whole-world byte equality is claimed.
- Native logs retain **25/10/10 warnings** across the three phases in each raw log variant, **zero ERROR/FATAL**, and no lag finding. Ordinary ItemEntities elsewhere in captured regions are not asserted absent or conserved; only the specified rocket/payload authority and bounded live nearby-drop observations are in scope.

This unchanged planetary runner is **operator-driven travel/startup/save/restart evidence, not network-player environmental gameplay**. It does not prove natural exposure cadence, action-bar visuals, player vent protection on a packaged server, native logout/respawn, or external provider interaction. Native source/target vacated-block/no-nearby-drop checks remain live commands, not native block-section/palette readback. There was no disassembly, S2 crash cut, actual native environmental `/reload`, or additional server launch by this reviewer.

## Remaining coverage boundaries

The new GameTests call service ticks explicitly rather than naturally ticking network players. Private catalog replacement is not `/reload`; direct `onChunkUnload` is not actual chunk eviction. The cancellation probe returns false from an overridden `hurt`, not a registered Forge listener. Cold/pressure registered damage and complete built-in armor tags are directly exercised; the remaining pure matrix/generated-data checks are not a full external-mod armor/cancellation matrix. Fixture immunity/grace setup does not establish a real client session.

No new tests were deleted, asserted results widened, timeouts raised or production budgets reduced in resolving the reviewed fixture failures. Full JUnit count 852 is root evidence; this reviewer claims only its 77 focused fresh JUnit and 229 GameTest executions. No independent Python unittest, consumer build, full clean build, GPU/V1/V2, remote, long-load, broad migration or release reproducibility campaign was performed. Complete Required Gates and inherited acceptance remain open under the project plan/ADR-018.

## Prior reports and archival

Preserve the contract directory `arce-v140-env-contract-review-926cc35df9684b478aa57c1aec3e6cae`, early source directory `arce-v140-env-source-review-704906b06b804907bcc2f781ad5ecdf2`, and initial fixture directory `arce-v140-env-fixture-review-be952a2d325149acaaa2c9610194aff9` unchanged. This final report resolves their scoped items without rewriting the historical observations.

This directory retains exact receipts, raw command logs/XML, source/artifact inventories, both reviewed guide versions and independent artifact/native helper sources and results. Final `SHA256SUMS` enumerates these files except itself. Root owns subsequent final documentation, staged-byte and archival checks; no future success is inferred here.
