import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

repo = Path('D:/GitHub/AdvancedRocketry-Community')
out = Path(__file__).parent
names = json.loads((out / 'artifacts-before.json').read_text(encoding='utf-8-sig'))
artifacts = {}
for row in names:
    path = repo / 'build/libs' / row['name']
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == row['sha256'], (row['name'], 'changed')
    with ZipFile(path) as z:
        entries = z.namelist()
        assert len(entries) == len(set(entries)), 'Duplicate ZIP name'
        assert z.testzip() is None
        assert not any('arceadaptertest/' in n or 'arce_adapter_test/' in n for n in entries)
        artifacts[row['name']] = {'sha256': digest, 'bytes': len(raw), 'entries': len(entries)}

stem = 'advancedrocketry-community-1.20.1-1.4.0-dev'
with ZipFile(repo / f'build/libs/{stem}.jar') as main, ZipFile(repo / f'build/libs/{stem}-api.jar') as api:
    classes = sorted(n for n in api.namelist() if n.endswith('.class'))
    assert len(classes) == 27, len(classes)
    assert all(n.startswith('io/github/sunthemoon/advancedrocketrycommunity/api/') for n in classes)
    assert all(main.read(n) == api.read(n) for n in classes)
    generated = repo / 'src/generated/v1.4/resources'
    resources = sorted(generated.rglob('*.json'))
    for path in resources:
        name = path.relative_to(generated).as_posix()
        assert main.read(name) == path.read_bytes(), name
    damage = {}
    for hazard in ('cold', 'heat', 'pressure', 'solar'):
        name = f'data/advancedrocketrycommunity/damage_type/planetary_{hazard}.json'
        data = json.loads(main.read(name))
        assert data == {'message_id': f'advancedrocketrycommunity.planetary_{hazard}',
                        'scaling': 'never', 'exhaustion': 0, 'effects': 'hurt'}
        damage[name] = data
    tags = {}
    for protection in ('thermal', 'pressure', 'solar'):
        name = f'data/advancedrocketrycommunity/tags/items/{protection}_protection.json'
        data = json.loads(main.read(name))
        assert data['replace'] is False
        assert set(data['values']) == {f'advancedrocketrycommunity:space_suit_{slot}'
                                      for slot in ('helmet', 'chestplate', 'leggings', 'boots')}
        assert len(data['values']) == 4
        tags[name] = data
    for name in main.namelist():
        if '/tags/damage_type/' in name and name.endswith('.json'):
            assert b'planetary_' not in main.read(name), ('unexpected damage tag', name)
    for locale in ('en_us', 'zh_cn'):
        lang = json.loads(main.read(f'assets/advancedrocketrycommunity_v140/lang/{locale}.json'))
        for hazard in ('cold', 'heat', 'pressure', 'solar'):
            for key in (f'environment.advancedrocketrycommunity.{hazard}',
                        f'death.attack.advancedrocketrycommunity.planetary_{hazard}',
                        f'death.attack.advancedrocketrycommunity.planetary_{hazard}.player'):
                assert isinstance(lang[key], str) and lang[key]
        assert '%s' in lang['environment.advancedrocketrycommunity.exposed']
    body_flags = {body: json.loads(main.read(f'data/advancedrocketrycommunity/celestial_bodies/{body}.json'))['environment_effects']
                  for body in ('mars', 'venus', 'gas_giant')}
    assert body_flags == {'mars': True, 'venus': True, 'gas_giant': False}

result = {'artifacts': artifacts, 'api_classes': classes, 'generated_json_count': len(resources),
          'damage': damage, 'tags': tags, 'body_flags': body_flags, 'result': 'PASS'}
(out / 'artifact-audit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
