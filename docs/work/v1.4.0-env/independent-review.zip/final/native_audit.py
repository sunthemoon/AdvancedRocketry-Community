import gzip
import hashlib
import json
import re
import sys
import uuid
import zipfile
import zlib
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-env-58c2564f75a940cb8643e4e3f9d1f8a1')
OUT = Path(__file__).parent
sys.path.insert(0, str(REPO))
# Reuse only bounded binary decoding primitives, not the runner's verdict/oracles.
from scripts.run_v130_adapter_recovery_smoke import NbtReader
from scripts import v120_precision_world_fixture as region

H = 'advancedrocketrycommunity'
OWNER = '00000000-0000-0000-0000-000000000005'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def uid(value):
    assert isinstance(value, list) and len(value) == 4
    return str(uuid.UUID(int=sum((v & 0xffffffff) << shift for v, shift in zip(value, (96,64,32,0)))))
def nbt(path):
    assert path.stat().st_size <= 4 * 1024**2
    with gzip.open(path, 'rb') as stream: raw = stream.read(4 * 1024**2 + 1)
    assert len(raw) <= 4 * 1024**2
    return NbtReader(raw).read_root()
def manifest(root):
    listed = {}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        sha, rel = line.split('  ', 1)
        assert rel not in listed and re.fullmatch('[a-f0-9]{64}', sha)
        p = root/rel
        assert p.resolve().is_relative_to(root.resolve()) and p.is_file() and not p.is_symlink()
        assert digest(p) == sha, (p, 'digest')
        listed[rel] = sha
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    assert set(listed) == actual, (actual-set(listed), set(listed)-actual)
    return {'count':len(listed), 'sha256':digest(root/'SHA256SUMS')}
def entities(root):
    result, stats = [], {'empty':0,'material':0,'chunks':0,'items':0}
    for p in sorted((root/'native').rglob('r.*.*.mca')):
        rel = p.relative_to(root/'native').as_posix()
        assert '/entities/' in rel
        dimension = 'minecraft:overworld' if rel.startswith('world/entities/') else ':'.join(rel.split('/')[2:4])
        rx, rz = map(int, re.fullmatch(r'r\.(-?\d+)\.(-?\d+)\.mca', p.name).groups())
        assert abs(rx)<=128 and abs(rz)<=128 and p.stat().st_size<=region.MAX_REGION_BYTES
        raw=p.read_bytes()
        if not raw: stats['empty']+=1; continue
        stats['material']+=1
        assert len(raw)>=8192
        for i in range(1024):
            if raw[i*4:i*4+4]==b'\0'*4: continue
            stats['chunks']+=1
            x,z=rx*32+i%32,rz*32+i//32
            stream=zlib.decompressobj()
            expanded=stream.decompress(region._region_chunk(raw,x,z),region.MAX_EXPANDED_CHUNK+1)
            assert len(expanded)<=region.MAX_EXPANDED_CHUNK and stream.eof and not stream.unused_data and not stream.unconsumed_tail
            chunk=NbtReader(expanded).read_root()
            assert chunk['Position']==[x,z]
            for entity in chunk['Entities']:
                stats['items']+=entity.get('id')=='minecraft:item'
                if entity.get('id')==H+':rocket': result.append((dimension,entity))
    assert stats['empty']<=32 and stats['material']<=16 and stats['chunks']<=128 and len(result)==1
    return result[0], stats

def audit():
    root=BASE/'native'; summary=load(root/'summary.json')
    out={'manifests':{},'phases':{},'artifacts':[]}
    out['manifests']['native']=manifest(root)
    launch_re=re.compile(r'ARCE_RELEASE_TEST_SURFACE_LAUNCH request=([\w-]+) entity=([\w-]+) logical=([\w-]+) source=(\S+) body=(\S+) code=(\S+) required_fuel=(\d+) fuel_before=(\d+)')
    event_re=re.compile(r'ARCE_TRANSFER_PHASE transfer=(\S+) logical=(\S+) phase=(\S+) event=(\S+) entity=(\S+) fuel_before=(\d+) fuel_after=(\d+) required=(\d+)')
    text=(root/'upgrade/stdout.txt').read_text(encoding='utf-8')
    launches=launch_re.findall(text)
    assert len(launches)==4 and launches[0][4]==H+':gas_giant' and launches[0][5:] == ('INVALID_DESTINATION','0','2000')
    good=launches[1:]; assert [x[4] for x in good]==[H+':mars',H+':venus',H+':earth']
    assert [int(x[6]) for x in good]==[448,533,515] and [int(x[7]) for x in good]==[2000,1552,1019]
    events=event_re.findall(text)
    expected_events=['countdown_complete','ascent_complete','destination_spawned','passengers_transferred','source_removed','committed','landing_complete','landed_reservation_retained']
    for leg in good:
        current=[e for e in events if e[0]==leg[0]]
        assert [e[3] for e in current]==expected_events
        assert all(e[1]==leg[2] and int(e[5])==int(leg[7]) and int(e[6])==int(leg[7])-int(leg[6]) and e[7]==leg[6] for e in current)
    assert len(events)==24 and len({x[0] for x in good})==3
    raw_data={}; stations={}; bindings={}; properties=[]
    for phase, amount, state in [('baseline',2000,'FUELED'),('upgrade',504,'LANDED'),('restart',504,'LANDED')]:
        p=root/phase; receipt=load(p/'observations.json'); commands=load(p/'commands.json')
        assert receipt['exit_code']==0 and receipt['result']=='PASS'
        logs={}
        for name in ('stdout.txt','latest.log','debug.log'):
            lines=(p/name).read_text(encoding='utf-8').splitlines()
            errors=[s for s in lines if re.search(r'/ERROR\]|/FATAL\]',s)]
            assert not errors, (phase,name,errors)
            logs[name]={'warnings':sum('/WARN]' in s for s in lines),'errors':len(errors),'lag':[s for s in lines if "Can't keep up" in s]}
        stdout=(p/'stdout.txt').read_text(encoding='utf-8')
        assert 'Done (' in stdout and 'Stopping server' in stdout and 'All dimensions are saved' in stdout
        assert commands[-2:]==['save-all flush','stop']
        assert sum('release-test refuel' in c for c in commands)==(1 if phase=='baseline' else 0)
        assert "Unknown dimension 'advancedrocketrycommunity:gas_giant'" in stdout
        for body in ('mars','venus'):
            unknown=f"Unknown dimension '{H}:{body}'"
            assert (unknown in stdout)==(phase=='baseline')
        (dimension,entity),region_stats=entities(p); data=entity['RocketEntityData']; raw_data[phase]=data
        assert dimension=='minecraft:overworld' and uid(data['owner_id'])==OWNER and uid(data['assembly_transaction_id'])==good[0][2]
        flight=data['flight_data']; snapshot=data['snapshot']
        assert data['schema_version']==flight['schema_version']==2 and flight['state']==state
        assert uid(flight['logical_rocket_id'])==good[0][2] and flight['current_body']==H+':earth'
        assert flight['current_target']=={'schema_version':1,'type':H+':body_surface','body_id':H+':earth'}
        assert 'plan' not in flight and 'active_transfer_id' not in flight and flight['passengers']=={'seat_capacity':1,'assignments':[]}
        assert flight['fuel']['amount']==amount and flight['fuel']['capacity']==2000
        assert [uid(d['transaction_id']) for d in flight['fuel']['committed_debits']]==([] if phase=='baseline' else [x[0] for x in good])
        assert snapshot['source_dimension']==flight['current_dimension']==dimension and snapshot['source_origin']==flight['current_origin']
        x,y,z=snapshot['source_origin']; assert entity['Pos']==[x+.5,float(y),z+.5] and not entity.get('Passengers',[])
        blocks=snapshot['relative_blocks']; assert len(blocks)==6 and len({tuple(b['position']) for b in blocks})==6
        payloads=[b['block_entity'] for b in blocks if 'block_entity' in b]
        assert len(payloads)==1 and payloads[0]['data']['Items']==[{'Slot':0,'id':'minecraft:diamond','Count':17},{'Slot':1,'id':'minecraft:iron_ingot','Count':64}]
        decoded=load(p/'native/entity-regions.json'); assert decoded['rocket']==data and decoded['chunks']==region_stats['chunks']
        stations[phase]=nbt(p/'stations.dat')['data']; assert stations[phase]['schema_version']==2
        requests=[]
        for req in receipt['station_requests']:
            matches=[s for s in stations[phase]['stations'] if uid(s['station_id'])==req['station_id']]
            assert len(matches)==1; s=matches[0]
            assert s['schema_version']==1 and uid(s['owner_id'])==req['owner_id'] and s['orbit_body']==req['orbit_body'] and s['name']==req['name']
            requests.append({'id':req['station_id'],'body':s['orbit_body'],'region':s['region'],'cell':[s['cell_x'],s['cell_z']]})
        assert len(stations[phase]['stations'])==(1 if phase=='baseline' else 3)
        bindings[phase]=load(p/'bindings.json'); assert bindings[phase]['schema_version']==1
        raw_props=(p/'inputs/server.properties').read_bytes().splitlines(keepends=True)
        assert raw_props[0] in (b'#Minecraft server properties\n',b'#Minecraft server properties\r\n') and raw_props[1].startswith(b'#')
        props=b''.join(raw_props[:1]+raw_props[2:]); properties.append(props)
        assert hashlib.sha256(props).hexdigest()==receipt['configuration']
        assert (p/'inputs/world/level.dat').is_file()
        out['phases'][phase]={'regions':region_stats,'entity_uuid':uid(entity['UUID']),'logical':uid(data['assembly_transaction_id']),'origin':snapshot['source_origin'],'fuel':amount,'snapshot_hash':snapshot['content_hash'],'stations':requests,'logs':logs,'level_dat_sha256':digest(p/'inputs/world/level.dat')}
    assert properties[0]==properties[1]==properties[2] and raw_data['upgrade']==raw_data['restart']
    ignore={'snapshot_id','source_dimension','source_origin','created_at_game_time','content_hash'}
    assert {k:v for k,v in raw_data['baseline']['snapshot'].items() if k not in ignore}=={k:v for k,v in raw_data['upgrade']['snapshot'].items() if k not in ignore}
    assert stations['baseline']['stations'][0] in stations['upgrade']['stations'] and stations['upgrade']==stations['restart']
    assert {s['orbit_body'] for s in stations['upgrade']['stations']}=={H+':moon',H+':mars',H+':gas_giant'}
    assert (root/'upgrade/stations.dat').read_bytes()==(root/'restart/stations.dat').read_bytes()
    assert bindings['upgrade']==bindings['restart'] and len(bindings['baseline']['bindings'])==3
    additions=[{'body_id':H+':mars','level':H+':mars'},{'body_id':H+':venus','level':H+':venus'},{'body_id':H+':gas_giant'}]
    assert sorted(bindings['baseline']['bindings']+additions,key=lambda x:x['body_id'])==bindings['upgrade']['bindings']
    transfer=nbt(root/'upgrade/transfers.dat')['data']; assert transfer['schema_version']==2 and len(transfer['transfers'])==1
    r=transfer['transfers'][0]; assert r['schema_version']==2 and r['phase']=='COMMITTED' and uid(r['transfer_id'])==good[-1][0]
    assert uid(r['owner_id'])==OWNER and uid(r['logical_rocket_id'])==good[0][2] and r['required_fuel']==515
    assert r['destination_snapshot']==raw_data['upgrade']['snapshot'] and r['source_flight']['fuel']['amount']==1019 and r['destination_flight']['fuel']['amount']==504
    assert r['source_flight']['current_body']==H+':venus' and r['destination_flight']['current_body']==H+':earth'
    assert uid(r['source_entity_id'])==good[-1][1] and uid(r['destination_entity_id'])==out['phases']['upgrade']['entity_uuid']
    assert (root/'upgrade/transfers.dat').read_bytes()==(root/'restart/transfers.dat').read_bytes()
    assert (root/'baseline/inputs/world/level.dat').read_bytes()==(root/'baseline/world-backup/level.dat').read_bytes()
    identity=summary['world']; assert out['phases']['baseline']['level_dat_sha256']==identity['level_dat_before_restart_sha256'] and out['phases']['restart']['level_dat_sha256']==identity['level_dat_after_restart_sha256']
    for phase in ('upgrade','restart'):
        assert digest(root/phase/'inputs'/identity['identity_marker'])==identity['identity_marker_sha256']
    for a in summary['artifacts']:
        p=Path(a['path']); assert p.stat().st_size==a['bytes'] and digest(p)==a['sha256']; out['artifacts'].append(a)
    jar=BASE/'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar'; api=jar.with_name(jar.stem+'-api.jar'); sources=jar.with_name(jar.stem+'-sources.jar')
    with zipfile.ZipFile(jar) as main,zipfile.ZipFile(api) as public,zipfile.ZipFile(sources) as src:
        for archive in (main,public,src):
            names=archive.namelist(); assert len(names)==len(set(names)); assert not any('arceadaptertest/' in n or 'arce_adapter_test/' in n for n in names)
        prefix='io/github/sunthemoon/advancedrocketrycommunity/api/'
        classes=sorted(n for n in public.namelist() if n.endswith('.class'))
        assert len(classes)==27 and all(n.startswith(prefix) and public.read(n)==main.read(n) for n in classes)
        for p in (REPO/'src/generated/v1.4/resources').rglob('*.json'):
            if '.cache' not in p.parts: assert main.read(p.relative_to(REPO/'src/generated/v1.4/resources').as_posix())==p.read_bytes()
        out['api_classes']=classes
    release=load(REPO/'docs/releases/v1.3.0/development-artifacts.json')
    assert digest(api)==next(a['sha256'] for a in release['artifacts'] if a['name'].endswith('-api.jar'))
    recorded_inputs=load(OUT/'inputs-before.json')
    assert digest(REPO/'scripts/run_v140_planetary_worlds_smoke.py')==next(
        item['sha256'] for item in recorded_inputs if item['path']=='scripts/run_v140_planetary_worlds_smoke.py')
    out['runner_sha256']=digest(REPO/'scripts/run_v140_planetary_worlds_smoke.py')
    out['legs']=[{'request':x[0],'body':x[4],'before':int(x[7]),'required':int(x[6])} for x in good]
    out['fuel_total_debit']=sum(int(x[6]) for x in good)
    out['result']='PASS'; (OUT/'native-audit.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__': audit()
