import sys
from pathlib import Path
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').split('\n')
start = next(i for i, l in enumerate(lines) if 'whenLandingReady(helper, surface, new GameTestTickPacer' in l)
end = next(i for i in range(start + 1, len(lines)) if lines[i] == '                });')
for i in range(start + 1, end):
    if lines[i]:
        lines[i] = '    ' + lines[i]
p.write_text('\n'.join(lines), encoding='utf-8', newline='\n')
print(start + 1, end + 1)
