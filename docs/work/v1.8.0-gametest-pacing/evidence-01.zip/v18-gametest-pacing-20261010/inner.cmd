@echo off
rem %1 = source tree, %2 = output label, %3 = cpu count
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.7
set GRADLE_USER_HOME=D:\GitHub\ARCE-Task-Evidence\pre-v18-client-20261006\gradle-home
set TEMP=D:\GitHub\ARCE-Task-Evidence\v18-gametest-pacing-20261010\tmp
set TMP=%TEMP%
cd /d "%~1"
call "%~1\gradlew.bat" --offline --no-daemon runGameTestServer -ParceCpuCount=%3 > "D:\GitHub\ARCE-Task-Evidence\v18-gametest-pacing-20261010\evidence\%~2-gradle.txt" 2>&1
echo exit=%ERRORLEVEL%>> "D:\GitHub\ARCE-Task-Evidence\v18-gametest-pacing-20261010\evidence\%~2-gradle.txt"
copy /y "%~1\build\gametest\logs\latest.log" "D:\GitHub\ARCE-Task-Evidence\v18-gametest-pacing-20261010\evidence\%~2-latest.log" > nul
