"""Rewrites the --no-index diff headers of PATCH-01.diff to ordinary a/ b/ repository paths."""
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
text = re.sub(r"^diff --git patch-[ab]/(\S+) patch-b/\S+$", r"diff --git a/\1 b/\1", text, flags=re.M)
text = re.sub(r"^--- patch-a/", "--- a/", text, flags=re.M)
text = re.sub(r"^\+\+\+ patch-b/", "+++ b/", text, flags=re.M)
path.write_text(text, encoding="utf-8", newline="\n")
print("headers fixed")
