# Tau 往返与目的地就绪间歇失败：根因分析与测试修正

日期：2026-10-10。执行者：Claude（应维护者要求协助修复）。本记录只提供证据和修正建议，
不改变版本状态，不批准任何 Gate，也不代替 Root 的集成与独立审核。

## 1. 结论

两项间歇失败（`No rocket at Tau Ceti f` 与 `Ticketed destination did not become ready`）
不是生产缺陷，而是测试计时方式的缺陷：

1. 原版 `GameTestServer.waitUntilNextTick()` 只执行 `runAllTasks()`，从不休眠
   （由 Forge 47.4.10 映射 JAR 的 javap 反汇编确认）。GameTest 服务器因此全速运行：
   CI 日志中 `tau_ceti_path` 在 13:35:09 开始，13:35:11 失败时 `test_tick=743`，
   约 370 tick/秒；Root 10-08 的本地日志中，“10 秒后提交”的跃迁 200 tick 只用了 0.7 秒。
2. 目的地区块的生成、实体分区读取（`EntityStorage` 在后台执行器上反序列化）和光照
   都按墙钟时间在后台线程推进，tick 计数的等待实际测的是宿主机的 CPU 速度和核数。
3. 三次 CI 失败（`2a59cfac`、`b8136f0b` 及燃料诊断提交）的现场完全一致：目的地区块
   `loaded=YES`、`entities_loaded=NO`，转移服务处于 `WAIT_ENTITY_READY` 已 110 次；
   ChunkHolder 的 `ENTITY_TICKING` 只是 ticket level 31 推出的目标状态，不是已完成状态。
   270 tick 的飞行窗口在 CI 上约为 0.7 秒墙钟时间，冷的 Tau Ceti f 来不及就绪。
4. 其他飞行测试都先用 `RocketFlightGameTestFixtures.primePadChunks` 预热目的地着陆台；
   只有 Tau 路径测试直接降落到冷世界，所以只有它反复失败。
5. 已修复的气闸首次供气失败属于同一机制：`canSeeSky` 读取异步光照，tick 抢跑时光照滞后。
   该项已由 `23bcb6b1` 改为几何判定，本次不再改动。

生产服务器按 20 TPS 运行，`spawnDestination` 在就绪前保持 PREPARED 并继续等待，
行为正确；需要修正的是测试。

## 2. 修正（只改测试，三个文件）

| 文件 | 改动 |
|---|---|
| `gametest/GameTestTickPacer.java`（新） | 等待中的每个 tick 至少持续 50 ms（`MinecraftServer` 的 tick 长度）；只在服务器线程使用，每个等待一个实例 |
| `rocket/server/RocketDestinationReadinessGameTests.java` | 三处原有重试在重试前调用 `pace()`；`READINESS_ATTEMPTS = 80`、`timeoutTicks = 300` 和全部断言不变 |
| `gametest/TauCetiPathGameTests.java` | 测试开始时为 Tau Ceti f 第一个着陆台加测试自有 ticket（半径 2，与生产飞行 ticket 相同），清理时移除；下降发射前限速等待其实体就绪（最多 200 次，至少 10 秒）。`FLIGHT = 270`、`timeoutTicks = 1400` 和全部原断言不变 |

预算核对：270 + 203 + 200 + 270 + 270 = 1,213 tick，小于原 1,400 tick 超时。

没有放宽断言、延长超时或改变生产代码。限速只让等待异步就绪的 tick 恢复生产服务器的时长；
冷目的地的等待行为仍由 `RocketDestinationReadinessGameTests` 覆盖。

## 3. 同类遗留项（本次不改）

- `FuelLoaderPlacementGameTests.roundTrip`：结构放置当 tick 就 `destroyBlock` 并立即按
  AABB 查询掉落物；若该区块实体分区尚不可访问，查询结果为 0（CI 曾报 `count=0`）。
  `timeoutTicks = 20`，修正需要先等待区块实体可访问，宜另立任务。
- 其余依赖固定 tick 数并等待异步加载的测试应改为“预热＋限速等待”的同一模式。

## 4. 本地复现与对照实验

全部运行在 D 盘导出副本上（不是仓库工作区），基准源码为 `d1272416`（`src` 与构建输入同
`0cefe86e`），Java 17.0.7、Gradle 8.8、Forge 47.4.10，Gradle home 为 D 盘副本。

### 4.1 限制 CPU 不能复现

| 运行 | 条件 | 结果 |
|---|---|---|
| baseline-cpu4 | `-XX:ActiveProcessorCount=4`（3 个 Worker-Main，同 CI） | 597/597 通过，281 s |
| baseline-cpu2 | `ActiveProcessorCount=2`（1 个 Worker-Main） | 597/597 通过，351 s |
| baseline-aff3-cpu4 | 进程树亲和性限定 2 个逻辑核＋3 个 Worker-Main | 597/597 通过 |

本机即使只有 1 个工作线程，冷 Tau Ceti f 也约 0.67 s 就绪，而 270 tick 窗口约 0.8 s，余量很小。
限核时主线程和工作线程一起变慢，tick 速率同步下降，因此限核模拟不了 CI。

### 4.2 受控后台停顿（实验开关只在临时副本，不在补丁里）

实验开关在指定时刻向 `Util.backgroundExecutor()` 的每个工作线程提交一个 3 秒的 `sleep`，
模拟 CI 上后台执行器被积压占满。注入点在两组中相同：Tau 为下降发射后 1 tick
（中心区块已由生产代码同步加载为 FULL），就绪测试为加半径 2 ticket 之后。

| 运行 | 源码 | Tau 路径 | 目的地就绪 | 汇总 |
|---|---|---|---|---|
| unpatched-stall3000-b | 原版 | 失败：`No rocket at Tau Ceti f` | 失败：`Ticketed destination did not become ready` | 2 项 required 失败 |
| patched-stall3000-b | 修正版 | 通过（批次 5.25 s） | 通过（批次 3.4 s） | 597/597 通过 |

原版 Tau 失败现场与三次 CI 失败逐项一致：`test_tick=743`、`phase=PREPARED`、
`target_branch=WAIT_ENTITY_READY`、`target_wait_attempts=110`、
holder `31_St:__11minecraft:full_r_Ch:__11minecraft:full_r__3ENTITY_TICKING_r`。

先前把停顿注入在下降发射之前时，原版 Tau 测试不失败：生产 `keepLoaded` 会同步
`getChunkAt`，主线程等停顿结束，tick 不前进。这把失败点定位在“中心区块 FULL 之后、
实体分区与周边生成仍在后台”的阶段。

限速器第一版只做 `parkNanos`，在同样停顿下就绪测试仍失败：区块状态的每一步都要回到
主线程执行，停住主线程使冷区块每 50 ms 只能推进一跳，比生产服务器还慢。第二版改为在
等待剩余时间内轮询各维度 `ServerChunkCache.pollTask()`（与 `MinecraftServer.pollTaskInternal`
在 `haveTime()` 时的处理相同），空闲时才休眠 0.5 ms。上表的修正版结果是第二版。

## 5. 干净补丁验证

`PATCH-01.diff`（3 个文件，不含实验开关）对 `d1272416` 和随后 Root 的纯文档提交
`c8fe8c0f`（`src` 与构建输入不变）的 `git apply --check` 都通过。在 `d1272416` 的全新
`git archive` 导出上应用后，严格顺序执行（失败即停）：

| 命令 | 结果 |
|---|---|
| `git apply --verbose PATCH-01.diff` | 三个文件 cleanly applied |
| `gradlew --no-daemon clean build` | exit 0，154 s；381 个 XML、2,192 个用例，0 失败/错误/跳过 |
| `gradlew --offline --no-daemon runGameTestServer` | exit 0，226 s；`All 597 required tests passed`；62 ERROR、0 FATAL（与 Root 基线相同，未豁免） |
| `gradlew --offline --no-daemon runData` | exit 0，20 s |
| `src/generated` 与基准提交逐文件比较 | 只多出 `.gitignore` 第 34 行已忽略的 `src/generated/v1.8/resources/.cache/` |

不需要等待时限速器不介入：该次运行中 `tau_ceti_path` 批次 2.6 s，`destination_readiness` 0.4 s。
修复副本去掉实验开关行后与干净补丁树逐字相同（忽略 CRLF）。

运行偏差如实记录：

- D 盘 Gradle home 副本最初缺 `srgutils-0.4.11` 与 JUnit 5.10.2 构件，离线运行失败
  （`evidence/clean-build-offline-missing-junit.txt`）；之后以联网模式补齐，仅写 D 盘缓存。
- 第一次干净验证链在构建失败后没有停止，与随后启动的第二条链在同一目录重叠。两条链均作废，
  输出移入 `evidence/superseded/`，自有进程已结束；上表来自删除重建后的严格顺序运行。
- `baseline-aff3-cpu4` 的第一次启动因 CMD 引号错误没有执行，空结果已删除；表中结果来自
  继承亲和性的第二次启动。
- `unpatched-stall3000`/`patched-stall3000`（停顿注入在下降前，以及第一版限速器）保留为历史；
  结论只取 `-b` 两次运行。

## 6. 文件

- `PATCH-01.diff`：交付补丁（3 个文件）。
- `EXPERIMENT-HOOKS-UNPATCHED.diff`：原版对照组使用的实验开关（`ExperimentStall`、构建属性
  `arceCpuCount`/`arceStallMillis` 和两个注入点）；修正版对照组在 `PATCH-01.diff` 之上使用相同开关，
  Tau 注入点位于 `whenLandingReady` 内的下降发射之后。仅用于复现，不得集成。
- `evidence/`：各次运行的 Gradle 输出与 `latest.log`。
- 脚本：`edit_readiness.py`、`edit_tau.py`、`indent_tau.py`、`make_patch.sh`、`fix_headers.py`、
  `inner.cmd`、`run_affinity.cmd`。

## 7. 未做与建议

- 未修改仓库、未提交、未推送；集成方式待维护者决定，集成前需独立审核（AGENTS.md 第 11 节）。
- 未在 Linux 托管 CI 上运行修正版；建议集成后以托管 CI 复跑，确认 Tau 与就绪两项不再出现。
- 装载器 `count=0` 等其他“固定 tick 等待异步加载”的测试未改，建议按同一模式另立任务。
