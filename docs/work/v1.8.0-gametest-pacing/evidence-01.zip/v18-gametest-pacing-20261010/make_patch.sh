#!/bin/sh
# Builds the clean three-file patch (experiment hooks removed) against the base commit.
set -e
E=D:/GitHub/ARCE-Task-Evidence/v18-gametest-pacing-20261010
REPO=D:/GitHub/AdvancedRocketry-Community
P=src/main/java/io/github/sunthemoon/advancedrocketrycommunity
BASE=$(cat $E/evidence/base-commit.txt)
rm -rf $E/patch-a $E/patch-b; mkdir -p $E/patch-a $E/patch-b
for f in $P/gametest/TauCetiPathGameTests.java $P/rocket/server/RocketDestinationReadinessGameTests.java; do
  mkdir -p $E/patch-a/$(dirname $f) $E/patch-b/$(dirname $f)
  git -C $REPO show $BASE:$f > $E/patch-a/$f
  grep -v "ExperimentStall" $E/fix-tree/$f > $E/patch-b/$f
done
mkdir -p $E/patch-b/$P/gametest
cp $E/fix-tree/$P/gametest/GameTestTickPacer.java $E/patch-b/$P/gametest/
cd $E && git diff --no-index --no-prefix patch-a patch-b > PATCH-01.diff || true
python -I $E/fix_headers.py $E/PATCH-01.diff
grep -c "ExperimentStall" PATCH-01.diff || true
git -C $REPO apply --check --verbose $E/PATCH-01.diff
