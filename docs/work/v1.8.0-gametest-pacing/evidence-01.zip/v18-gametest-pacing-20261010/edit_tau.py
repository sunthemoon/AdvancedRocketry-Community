import sys
from pathlib import Path
p = Path(sys.argv[1])
t = p.read_text(encoding='utf-8')
def sub(old, new, count=1):
    global t
    assert t.count(old) == count, (old, t.count(old))
    t = t.replace(old, new)

sub("import java.util.List;\n", "import java.util.Comparator;\nimport java.util.List;\n")
sub("import net.minecraft.server.level.ServerLevel;\n",
    "import net.minecraft.server.level.ServerLevel;\nimport net.minecraft.server.level.TicketType;\n")
sub(" * runs on an empty discovery ledger ({@link DiscoveryProgressFixture}) under the production rocket-motion rule. On\n"
    " * both worlds the landing ground under the eight fixed pads is dry and clear.\n */",
    " * runs on an empty discovery ledger ({@link DiscoveryProgressFixture}) under the production rocket-motion rule. On\n"
    " * both worlds the landing ground under the eight fixed pads is dry and clear.\n"
    " *\n"
    " * <p>Like the pads {@code RocketFlightGameTestFixtures.primePadChunks} prepares for the other flights, Tau Ceti f's\n"
    " * first pad is requested when the test starts and must be entity-ready before the descent launches: this test\n"
    " * covers the path, while {@code RocketDestinationReadinessGameTests} covers a cold destination. The readiness wait\n"
    " * is paced ({@link GameTestTickPacer}), because generating a cold world takes wall-clock time that unpaced GameTest\n"
    " * ticks do not measure.\n */")
sub("    private static final String OBSERVATION_PREFIX = \"ARCE_TAU_CETI_MISSING\";\n",
    "    private static final String OBSERVATION_PREFIX = \"ARCE_TAU_CETI_MISSING\";\n"
    "    /** The chunk of the first pad, at the origin, where the descent lands. */\n"
    "    private static final ChunkPos FIRST_PAD = new ChunkPos(0, 0);\n"
    "    /** The production flight ticket's radius: entity-ticking at the pad's chunk. */\n"
    "    private static final int LANDING_TICKET_RADIUS = 2;\n"
    "    /** Paced attempts, at least ten seconds, within the test's unchanged 1,400-tick timeout. */\n"
    "    private static final int LANDING_READY_ATTEMPTS = 200;\n"
    "    private static final TicketType<ChunkPos> LANDING_TICKET = TicketType.create(\"arce_gametest_tau_ceti_landing\",\n"
    "            Comparator.comparingLong(ChunkPos::toLong));\n")
sub("            fixture.close();\n            clearTransferJournal(earth);\n        };\n",
    "            fixture.close();\n            clearTransferJournal(earth);\n"
    "            surface.getChunkSource().removeRegionTicket(LANDING_TICKET, FIRST_PAD, LANDING_TICKET_RADIUS, FIRST_PAD);\n"
    "        };\n")
sub("            fixture.keepLoaded();\n",
    "            fixture.keepLoaded();\n"
    "            surface.getChunkSource().addRegionTicket(LANDING_TICKET, FIRST_PAD, LANDING_TICKET_RADIUS, FIRST_PAD);\n")
old_down = """                RocketEntity docked = landed(helper, fixture.space, logical[0], "the warped station", observerJournal);
                RocketFlightRequestResult down = RocketRuntime.requestAdminFlight(docked,
                        new TravelTarget.BodySurface(ExoplanetContent.TAU_CETI_F), UUID.randomUUID());
                helper.assertTrue(down.success(), "Station-to-Tau Ceti f launch failed: " + down.code());
                helper.runAfterDelay(FLIGHT, () -> guarded(cleanup, () -> {"""
new_down = """                RocketEntity docked = landed(helper, fixture.space, logical[0], "the warped station", observerJournal);
                whenLandingReady(helper, surface, new GameTestTickPacer(fixture.server), 1, cleanup, () -> {
                RocketFlightRequestResult down = RocketRuntime.requestAdminFlight(docked,
                        new TravelTarget.BodySurface(ExoplanetContent.TAU_CETI_F), UUID.randomUUID());
                helper.assertTrue(down.success(), "Station-to-Tau Ceti f launch failed: " + down.code());
                helper.runAfterDelay(FLIGHT, () -> guarded(cleanup, () -> {"""
sub(old_down, new_down)
old_tail = """                        cleanup.run();
                        helper.succeed();
                    }));
                }));
            }));
        }));
    }
"""
new_tail = """                        cleanup.run();
                        helper.succeed();
                    }));
                }));
                });
            }));
        }));
    }

    /**
     * Runs {@code then} once Tau Ceti f's first pad has loaded entities and ticks them, checking once per paced tick;
     * a failed attempt bound fails the test through the caller's guarded cleanup.
     */
    private static void whenLandingReady(GameTestHelper helper, ServerLevel surface, GameTestTickPacer pacer,
            int attempt, Runnable cleanup, Runnable then) {
        if (surface.areEntitiesLoaded(FIRST_PAD.toLong())
                && surface.isPositionEntityTicking(FIRST_PAD.getMiddleBlockPosition(0))) {
            then.run();
            return;
        }
        helper.assertTrue(attempt < LANDING_READY_ATTEMPTS, "Tau Ceti f's first pad did not become entity-ready");
        pacer.pace();
        helper.runAfterDelay(1, () -> guarded(cleanup,
                () -> whenLandingReady(helper, surface, pacer, attempt + 1, cleanup, then)));
    }
"""
sub(old_tail, new_tail)
p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
