import sys
from pathlib import Path
p = Path(sys.argv[1])
t = p.read_text(encoding='utf-8')
def sub(old, new, count=1):
    global t
    assert t.count(old) == count, (old, t.count(old))
    t = t.replace(old, new)
sub("import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;\n",
    "import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;\n"
    "import io.github.sunthemoon.advancedrocketrycommunity.gametest.GameTestTickPacer;\n")
sub('                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Source entity chunk did not become ready");\n',
    '                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Source entity chunk did not become ready");\n'
    '                fixture.pacer.pace();\n')
sub('                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Remote entity data did not load");\n',
    '                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Remote entity data did not load");\n'
    '                fixture.pacer.pace();\n')
sub('                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Ticketed destination did not become ready");\n'
    '                fixture.assertWaitUnchanged();\n',
    '                fixture.helper.assertTrue(attempt < READINESS_ATTEMPTS, "Ticketed destination did not become ready");\n'
    '                fixture.assertWaitUnchanged();\n'
    '                fixture.pacer.pace();\n')
sub("        private final ServerLevel moon;\n        private final ChunkPos chunk = new ChunkPos(MOON_ORIGIN);\n",
    "        private final ServerLevel moon;\n"
    "        /** Retries wait for asynchronous chunk and entity loading; each lasts a server tick (GameTestTickPacer). */\n"
    "        private final GameTestTickPacer pacer;\n"
    "        private final ChunkPos chunk = new ChunkPos(MOON_ORIGIN);\n")
sub("            earth = helper.getLevel();\n            this.moon = moon;\n        }\n",
    "            earth = helper.getLevel();\n            this.moon = moon;\n            pacer = new GameTestTickPacer(earth.getServer());\n        }\n")
p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
