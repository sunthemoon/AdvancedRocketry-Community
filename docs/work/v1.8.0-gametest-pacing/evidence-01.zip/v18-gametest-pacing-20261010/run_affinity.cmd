@echo off
rem %1 = source tree, %2 = output label, %3 = affinity hex mask, %4 = cpu count
start "" /affinity %3 /wait /b "D:\GitHub\ARCE-Task-Evidence\v18-gametest-pacing-20261010\inner.cmd" "%~1" "%~2" %4
