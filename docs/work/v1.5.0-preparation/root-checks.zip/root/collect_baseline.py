from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/work/v1.5.0-preparation'
BASE = '6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    return result


checks = {}
for name, args in {
    'production-diff': ['diff', '--exit-code', BASE, '--', 'src', 'build.gradle', 'settings.gradle', 'gradle.properties', 'gradle', 'scripts'],
    'datagen-diff': ['diff', '--exit-code', '--', 'src/generated'],
    'whitespace': ['diff', '--check'],
}.items():
    result = git(*args)
    (OUT / (name + '.log')).write_text('git ' + ' '.join(args) + '\nexit_code=' + str(result.returncode)
                                        + '\n' + result.stdout + result.stderr, encoding='utf-8')
    checks[name] = result.returncode
    assert result.returncode == 0, name

expected = json.loads((ROOT / 'docs/releases/v1.4.0/development-artifacts.json').read_text(encoding='utf-8'))
artifacts = []
for entry in expected['artifacts']:
    path = ROOT / 'build/libs' / entry['name']
    actual = {'name': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
    assert actual == entry, (actual, entry)
    artifacts.append(actual)
api = ROOT / 'build/libs' / next(row['name'] for row in artifacts if row['name'].endswith('-api.jar'))
with zipfile.ZipFile(api) as z:
    classes = {name: hashlib.sha256(z.read(name)).hexdigest() for name in sorted(z.namelist()) if name.endswith('.class')}
assert len(classes) == expected['api_class_count']
(OUT / 'api-class-identities.json').write_text(json.dumps(classes, indent=2) + '\n', encoding='utf-8')

test_files = sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml'))
junit = {'suites': len(test_files), 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0,
         'execution': 'FROM-CACHE, not newly executed'}
(OUT / 'junit').mkdir(exist_ok=True)
for path in test_files:
    suite = ET.parse(path).getroot()
    for key in ('tests', 'failures', 'errors', 'skipped'):
        junit[key] += int(suite.get(key, '0'))
    shutil.copyfile(path, OUT / 'junit' / path.name)
assert junit['tests'] == 922 and junit['suites'] == 167
assert junit['failures'] == junit['errors'] == junit['skipped'] == 0
command = json.loads((OUT / 'gradle-command.json').read_text(encoding='utf-8-sig'))
log = (OUT / 'gradle-baseline.log').read_text(encoding='utf-8-sig')
assert command['exit_code'] == 0 and '> Task :test FROM-CACHE' in log
assert 'All 236 required tests passed' in log
assert 'written: 0' in log
assert 'BUILD SUCCESSFUL in 2m 31s' in log
runtime_log = ROOT / 'build/gametest/logs/latest.log'
if runtime_log.is_file():
    shutil.copyfile(runtime_log, OUT / 'gametest-latest.log')
generated = git('ls-files', 'src/generated/v1.4/resources').stdout.splitlines()
generated = [{'path': name, 'sha256': sha(ROOT / name)} for name in generated]
(OUT / 'generated-resource-identities.json').write_text(json.dumps(generated, indent=2) + '\n', encoding='utf-8')
summary = {
    'schema_version': 1, 'development_baseline': BASE, 'candidate_commit': None,
    'scope': 'Unchanged v1.4 runtime checks during v1.5 preparation; not v1.5 runtime evidence',
    'command': command, 'duration_seconds_reported_by_gradle': 151,
    'tasks': {'executed': 17, 'from_cache': 9, 'up_to_date': 1},
    'build_log_sha256': sha(OUT / 'gradle-baseline.log'),
    'required_gametests_passed': 236, 'junit': junit,
    'datagen_written': 0, 'tracked_generated_directory': 'src/generated/v1.4/resources',
    'tracked_generated_entries': len(generated),
    'git_checks': checks, 'api_class_count': len(classes), 'artifacts': artifacts,
    'log_diagnostics': {
        'error_lines': len(re.findall(r'\[[^\]\r\n]*/ERROR\]', log)),
        'fatal_lines': len(re.findall(r'\[[^\]\r\n]*/FATAL\]', log)),
        'lag_warnings': [line for line in log.splitlines() if "Can't keep up!" in line],
    },
    'new_runtime_implementation': False, 'native_restart_run': False,
}
for path in (OUT / 'baseline-checks.json', DEST / 'baseline-checks.json'):
    path.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(summary, indent=2))
