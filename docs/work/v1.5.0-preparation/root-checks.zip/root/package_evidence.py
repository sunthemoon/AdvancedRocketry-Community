from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/work/v1.5.0-preparation'
INVENTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-preparation-review-9400df81fbaa4aef805e1c3458937a99')
CONTRACT = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-contract-review-5c6b168c90aa4fdbbf686ff935970c90')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pack(name, sources, excluded=()):
    entries = {}
    for prefix, directory in sources:
        for path in sorted(directory.rglob('*')):
            if path.is_file() and not any(part == '__pycache__' for part in path.parts):
                relative = path.relative_to(directory).as_posix()
                if relative not in excluded:
                    entries[prefix + '/' + relative] = path.read_bytes()
    manifest = ''.join(f'{digest(data)}  {key}\n' for key, data in sorted(entries.items()))
    entries['MEMBER-SHA256SUMS.txt'] = manifest.encode('utf-8')
    destination = DEST / name
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for key, data in sorted(entries.items()):
            info = zipfile.ZipInfo(key, date_time=(2026, 9, 28, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        for key, data in entries.items():
            assert archive.read(key) == data
    return {
        'name': name, 'bytes': destination.stat().st_size, 'sha256': digest(destination.read_bytes()),
        'members': len(entries), 'manifest': 'MEMBER-SHA256SUMS.txt',
        'source_directories': [{'prefix': prefix, 'path': str(directory)} for prefix, directory in sources],
        'excluded_output_names': list(excluded),
    }


assert (CONTRACT / 'FINAL-SUBSTANTIVE-REVIEW.md').is_file(), 'final independent report required before packaging'
archives = [
    pack('root-checks.zip', [('root', OUT)], ('package-evidence.log', 'final-readback.log', 'final-readback.json', 'push-verification.log')),
    pack('independent-review.zip', [('inventory', INVENTORY), ('contract', CONTRACT)]),
]
(DEST / 'evidence-archives.json').write_text(json.dumps({
    'schema_version': 1, 'scope': 'v1.5 documentation/contract preparation, unchanged v1.4 runtime',
    'archives': archives,
}, indent=2) + '\n', encoding='utf-8', newline='\n')
reports = []
for prefix, folder in [('inventory', INVENTORY), ('contract', CONTRACT)]:
    for path in sorted(folder.glob('*.md')):
        reports.append({'member': prefix + '/' + path.name, 'bytes': path.stat().st_size,
                        'sha256': digest(path.read_bytes())})
(DEST / 'independent-review.json').write_text(json.dumps({
    'schema_version': 1, 'reviewer': '/root/prec04b_readback_review',
    'base_commit': '6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b',
    'archive': archives[1], 'reports': reports,
    'scope': 'Read-only source/draft/test/pointer review and short Python/Git checks; no JVM/native/remote commands or maintainer/Gate approval',
}, indent=2) + '\n', encoding='utf-8', newline='\n')
checksums = ''.join(f'{digest(path.read_bytes())}  {path.name}\n' for path in sorted(DEST.iterdir())
                    if path.is_file() and path.name != 'SHA256SUMS.txt')
(DEST / 'SHA256SUMS.txt').write_text(checksums, encoding='utf-8', newline='\n')
print(json.dumps({'archives': archives, 'reports': reports, 'checksums': checksums}, indent=2))
