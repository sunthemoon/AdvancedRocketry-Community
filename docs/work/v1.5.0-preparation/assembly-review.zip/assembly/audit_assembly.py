"""Read-only staged preparation assembly audit; outputs are only this new Temp."""
import difflib,hashlib,json,os,pathlib,subprocess,sys,time,zipfile
R=pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
O=pathlib.Path(__file__).resolve().parent
P=R/"docs/work/v1.5.0-preparation"
PRIOR=pathlib.Path("C:/Users/Administrator/AppData/Local/Temp/arce-v150-contract-review-5c6b168c90aa4fdbbf686ff935970c90/final")
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,obj):(O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
cmds=[["git","rev-parse","HEAD"],["git","branch","--show-current"],["git","diff","--exit-code"],["git","diff","--check"],["git","diff","--cached","--check"],["git","diff","6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b","--exit-code","--","src","scripts","build.gradle","settings.gradle","gradle.properties","gradle","gradlew","gradlew.bat"],["git","diff","--cached","--stat"],[sys.executable,"-B","scripts/validate_v1plus_planning.py"]]
receipts=[]
for i,cmd in enumerate(cmds):
    start=time.monotonic();r=subprocess.run(cmd,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONUTF8":"1"})
    log=f"command-{i:02d}.log";(O/log).write_bytes(r.stdout)
    receipts.append(dict(argv=cmd,exit=r.returncode,seconds=time.monotonic()-start,log=log))
dump("commands.json",receipts);assert all(c["exit"]==0 for c in receipts)
paths=subprocess.check_output(["git","diff","--cached","--name-only","-z"],cwd=R).decode().rstrip("\0").split("\0")
assert len(paths)==17 and not any(n.startswith("AdvancedRocketry-Community-v1plus-Development-Docs/") for n in paths)
staged=[]
for n in paths:
    b=(R/n).read_bytes();s=subprocess.check_output(["git","show",":"+n],cwd=R);assert b==s,n
    dest=O/"staged-inputs"/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
    staged.append(dict(path=n,bytes=len(b),sha256=sha(b),index_equal=True))
dump("staged-identities.json",staged)
delta=[]
for row in json.loads((PRIOR/"input-identities.json").read_text()):
    n=row["path"];old=(PRIOR/"inputs"/n).read_bytes();new=(R/n).read_bytes()
    if old!=new:
        delta.append(dict(path=n,before=sha(old),after=sha(new),newline_only=old.replace(b"\r\n",b"\n")==new.replace(b"\r\n",b"\n")))
        text="".join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile="previous/"+n,tofile="current/"+n))
        dst=O/"delta"/(n+".patch");dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(text,encoding="utf8")
dump("delta-identities.json",delta)
checks=[]
for line in (P/"SHA256SUMS.txt").read_text().splitlines():
    h,n=line.split("  ",1);b=(P/n).read_bytes();s=subprocess.check_output(["git","show",":docs/work/v1.5.0-preparation/"+n],cwd=R)
    assert sha(b)==h and sha(s)==h,n
    checks.append(dict(path=n,sha256=h,working_equal=True,index_equal=True))
dump("packet-checksums.json",checks);assert len(checks)==8
archives=[]
for meta in json.loads((P/"evidence-archives.json").read_text())["archives"]:
    path=P/meta["name"];b=path.read_bytes();assert len(b)==meta["bytes"] and sha(b)==meta["sha256"]
    with zipfile.ZipFile(path) as z:
        names=z.namelist();assert len(names)==meta["members"] and len(set(names))==len(names);assert z.testzip() is None
        assert all(not pathlib.PurePosixPath(n).is_absolute() and ".." not in pathlib.PurePosixPath(n).parts for n in names)
        manifest=z.read(meta["manifest"]).decode().splitlines();listed={}
        for line in manifest:
            h,n=line.split("  ",1);assert n not in listed;assert sha(z.read(n))==h,n;listed[n]=h
            parts=n.split("/",1);src=next(d for d in meta["source_directories"] if d["prefix"]==parts[0]);local=pathlib.Path(src["path"])/parts[1]
            assert local.read_bytes()==z.read(n),n
        assert set(names)==set(listed)|{meta["manifest"]}
        # Independently validate original per-review-directory manifests, too.
        originals=[]
        for n in names:
            if n.endswith("/SHA256SUMS"):
                lines=z.read(n).decode().splitlines();prefix=n.rsplit("/",1)[0]+"/"
                for line in lines:
                    h,rel=line.split("  ",1);assert sha(z.read(prefix+rel))==h,(n,rel)
                originals.append(dict(member=n,entries=len(lines),sha256=sha(z.read(n))))
        archives.append(dict(name=meta["name"],sha256=sha(b),entries=len(names),content_entries=len(listed),crc_errors=0,duplicate_entries=0,all_original_bytes_equal=True,embedded_review_manifests=originals))
dump("archives.json",archives);assert sum(x["content_entries"] for x in archives)==351
review=json.loads((P/"independent-review.json").read_text())
assert review["archive"]==next(a for a in json.loads((P/"evidence-archives.json").read_text())["archives"] if a["name"]=="independent-review.zip")
with zipfile.ZipFile(P/"independent-review.zip") as z:
    for e in review["reports"]:
        b=z.read(e["member"]);assert len(b)==e["bytes"] and sha(b)==e["sha256"]
dump("review-reports.json",review["reports"])
base=json.loads((P/"baseline-checks.json").read_text());hand=json.loads((R/"docs/releases/v1.4.0/development-artifacts.json").read_text())
assert base["artifacts"]==hand["artifacts"]
art=[]
for e in base["artifacts"]:
    b=(R/"build/libs"/e["name"]).read_bytes();assert len(b)==e["bytes"] and sha(b)==e["sha256"];art.append(e)
assert len(subprocess.check_output(["git","ls-files",base["tracked_generated_directory"]+"/*"],cwd=R).decode().splitlines())==base["tracked_generated_entries"]==34
dump("artifacts.json",dict(artifacts=art,generated_entries=34,api_class_count_metadata=base["api_class_count"],junit_execution=base["junit"]["execution"],gametests_metadata=base["required_gametests_passed"],jvm_run_by_reviewer=False))
sys.path.insert(0,str(R/"scripts"));import validate_repository as vr
mds=[n for n in paths if n.endswith(".md")];err,count=vr.markdown_link_errors(R,[R/n for n in mds]);assert not err
allmd=subprocess.check_output(["git","ls-files","*.md"],cwd=R).decode().splitlines();assert not any(n.startswith("AdvancedRocketry-Community-v1plus-Development-Docs/") for n in allmd)
allerr,allcount=vr.markdown_link_errors(R,[R/n for n in allmd]);assert not allerr
dump("links.json",dict(changed_documents=len(mds),changed_links=count,changed_errors=err,tracked_documents=len(allmd),tracked_links=allcount,tracked_errors=allerr))
print(json.dumps(dict(staged_files=len(staged),changed_since_substantive=delta,checksums=len(checks),archive_content_members=sum(x["content_entries"] for x in archives),reports=len(review["reports"]),changed_doc_links=count,tracked_links=allcount,links_missing=0,artifacts_match=3,generated_entries=34,commands_all_exit_zero=True),indent=2))

