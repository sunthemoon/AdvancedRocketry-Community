"""Audit captured staged packet; the root's subsequent attachment edits are not inputs."""
import hashlib,json,pathlib,zipfile,sys,re,io,subprocess
R=pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
O=pathlib.Path(__file__).resolve().parent
S=O/"staged-inputs";P=S/"docs/work/v1.5.0-preparation"
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,o):(O/n).write_text(json.dumps(o,indent=2)+"\n",encoding="utf8")
archives=[];comparisons=[];mapped=[]
for meta in json.loads((P/"evidence-archives.json").read_text())["archives"]:
    b=(P/meta["name"]).read_bytes();assert len(b)==meta["bytes"] and sha(b)==meta["sha256"]
    with zipfile.ZipFile(P/meta["name"]) as z:
        names=z.namelist();assert len(names)==meta["members"] and len(names)==len(set(names));assert z.testzip() is None
        listed={}
        for line in z.read(meta["manifest"]).decode().splitlines():
            h,n=line.split("  ",1);assert n not in listed and sha(z.read(n))==h
            assert ".." not in pathlib.PurePosixPath(n).parts and not pathlib.PurePosixPath(n).is_absolute();listed[n]=h
            prefix,rel=n.split("/",1);src=next(x for x in meta["source_directories"] if x["prefix"]==prefix)
            current=(pathlib.Path(src["path"])/rel).read_bytes()
            equal=current==z.read(n)
            if meta["name"]=="independent-review.zip":assert equal,n
            comparisons.append(dict(archive=meta["name"],member=n,archived_sha256=h,current_temp_sha256=sha(current),current_temp_equal=equal))
        assert set(names)==set(listed)|{meta["manifest"]}
        for n in names:
            if n.endswith("/SHA256SUMS"):
                prefix=n.rsplit("/",1)[0]+"/"
                for line in z.read(n).decode().splitlines():
                    h,rel=line.split("  ",1);original=rel
                    if n=="inventory/SHA256SUMS":
                        assert rel.startswith("7a99/");rel=rel[5:]
                    assert sha(z.read(prefix+rel))==h,(n,original)
                    mapped.append(dict(manifest=n,original_path=original,actual_member=prefix+rel,sha256=h))
        archives.append(dict(name=meta["name"],sha256=sha(b),entries=len(names),content_entries=len(listed),crc_errors=0,duplicate_entries=0))
assert sum(a["content_entries"] for a in archives)==351
dump("snapshot-archives.json",archives);dump("snapshot-current-temp-comparisons.json",comparisons);dump("historical-review-manifest-readback.json",mapped)
review=json.loads((P/"independent-review.json").read_text())
assert review["archive"]==next(a for a in json.loads((P/"evidence-archives.json").read_text())["archives"] if a["name"]=="independent-review.zip")
with zipfile.ZipFile(P/"independent-review.zip") as z:
    for e in review["reports"]:
        b=z.read(e["member"]);assert len(b)==e["bytes"] and sha(b)==e["sha256"]
checks=[]
for line in (P/"SHA256SUMS.txt").read_text().splitlines():
    h,n=line.split("  ",1);assert sha((P/n).read_bytes())==h;checks.append(n)
assert len(checks)==8
# Links use the captured staged text, resolving target existence inside actual repo.
sys.path.insert(0,str(R/"scripts"));import validate_repository as vr
missing=[];unsafe=[];count=0;rows=json.loads((O/"staged-identities.json").read_text())
for row in rows:
    n=row["path"]
    if not n.endswith(".md"):continue
    fenced=False
    for i,line in enumerate((S/n).read_text(encoding="utf8").splitlines(),1):
        if line.lstrip().startswith(("~~~","\x60\x60\x60")):fenced=not fenced;continue
        if fenced:continue
        line=re.sub(r"\x60[^\x60]*\x60","",line)
        for m in vr.MARKDOWN_LINK.finditer(line):
            target=vr.normalize_link_target(m.group(1))
            if not target or target.startswith(("#","http://","https://","mailto:")):continue
            target=target.split("#",1)[0].split("?",1)[0]
            if not target:continue
            count+=1;candidate=((R/n).parent/target).resolve()
            if not candidate.is_relative_to(R) or "AdvancedRocketry-Community-v1plus-Development-Docs" in candidate.parts:unsafe.append((n,i,target));continue
            if not candidate.exists():missing.append((n,i,target))
assert not missing and not unsafe and count==111
dump("snapshot-links.json",dict(changed_documents=sum(x["path"].endswith(".md") for x in rows),targets=count,missing=missing,unsafe=unsafe,scope="captured staged document text; target existence only"))
base=json.loads((P/"baseline-checks.json").read_text());handoff=json.loads((R/"docs/releases/v1.4.0/development-artifacts.json").read_text())
assert base["artifacts"]==handoff["artifacts"]
for e in base["artifacts"]:
    b=(R/"build/libs"/e["name"]).read_bytes();assert sha(b)==e["sha256"] and len(b)==e["bytes"]
generated=subprocess.check_output(["git","ls-files",base["tracked_generated_directory"]+"/*"],cwd=R).decode().splitlines()
assert len(generated)==base["tracked_generated_entries"]==34
api=next(e for e in base["artifacts"] if e["name"].endswith("-api.jar"));main=next(e for e in base["artifacts"] if not e["name"].endswith(("-api.jar","-sources.jar")))
with zipfile.ZipFile(R/"build/libs"/api["name"]) as a,zipfile.ZipFile(R/"build/libs"/main["name"]) as m:
    classes=[n for n in a.namelist() if n.endswith(".class")];assert len(classes)==27
    assert all(a.read(n)==m.read(n) for n in classes)
summary=dict(staged_files=len(rows),checksums=len(checks),archives=archives,archive_content_members=351,independent_reports=len(review["reports"]),historical_inventory_manifest_rows=sum(x["manifest"]=="inventory/SHA256SUMS" for x in mapped),changed_links=count,missing_links=0,artifact_matches=3,api_class_count=27,generated_entries=34,root_temp_drift=[x["member"] for x in comparisons if not x["current_temp_equal"]],jvm_executed=False)
dump("snapshot-audit-result.json",summary);print(json.dumps(summary,indent=2))

