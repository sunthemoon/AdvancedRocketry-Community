# V150 preparation — final assembly delta review

Date: 2026-09-28. Delegated independent reviewer; read-only repository/index.
Baseline `6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b`; branch
`codex/v1.5.0-orbital-station-warp`. Scope: the 17-file staged preparation
packet captured at the start of this audit, not subsequent attachment edits.

## Findings first

### P3 — Original inventory manifest paths are malformed; preserve and supplement

The immutable source-inventory manifest, archived as
`independent-review.zip!inventory/SHA256SUMS:1–82`, prefixes every relative
name with `7a99/`, although actual members are directly under `inventory/`.
For example the first row says `7a99/collect_inputs.py`. This is a defect in
the reviewer's original relative-path receipt, not a missing or modified source
file. Its original hash remains
`417c270ba5e131b7ac594b0600554d312da16d132398d0296563d0b66d746102`.

The initial nested-manifest audit failed with the actual missing-member
KeyError; original helper/log remain unchanged. No original manifest was fixed
or represented as valid as-is. The final supplemental audit:
- requires exactly the historical `7a99/` prefix on all 82 rows;
- removes only that prefix when locating the archived member;
- checks the original digest against each actual member;
- also verifies the independent root wrapper manifest and equality with every
  original immutable reviewer-directory file.

All 82 mapped rows match. The independent archive wrapper already names the
actual members correctly. The mapping and exact hashes are recorded in
`historical-review-manifest-readback.json`. Root acknowledged this defect and
added a documentation-only note for its post-review attachment. The explicit
supplement resolves the ability to verify these bytes without rewriting history;
the original manifest remains malformed.

**No additional substantive assembly finding** was identified in the captured
packet. The previously missing five evidence links now exist; contract/runtime
scope and cached-versus-executed evidence remain accurately separated.

## Actual delta reviewed

Compared with the previous immutable substantive snapshot, only:
1. Worklog marks GOV-01/CON-01 verified and STATION-01 ready, retaining every
   runtime leaf unchecked and Required Gates open; adds scoped evidence receipts.
   [Worklog:35–42](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-implementation-log.md#L35),
   [77–120](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-implementation-log.md#L77).
2. VERIFICATION adds the substantive report digest and accurately attributes
   the independent 15 planning/12 example checks and earlier missing assembly
   targets.
   [VERIFICATION:38–46](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-preparation/VERIFICATION.md#L38).
3. `baseline-checks.json` changes line endings only to LF, matching the Git blob.
4. Five new evidence/archive/checksum files are present in the staged packet.

The accepted ADRs, example checker/data, reader pointers and planning-test
correction are byte-identical to the preceding substantive reviewed inputs.
Runtime/build/scripts/generated files remain unchanged versus baseline.
No public API, new save schema, world migration or new v1.5 runtime is inferred.

Original checked-save and local-confirmation findings remain contract resolutions,
not claims of runtime repair. Only preparation leaves are verified; the acceptance
cursor stays v1.0 and the v1.5 runtime remains unimplemented work.

## Independently executed checks

Python launcher: `D:/python/pyenv/pyenv-win/shims/python.bat`, `-B`,
`PYTHONUTF8=1`; resolved Python 3.13.15. Cwd is the repository.
Exact raw argv/exits/times: `commands.json`, corresponding command logs and
three retained failed helper logs, followed by `audit-snapshot.log`.

- `git rev-parse HEAD`, `git branch --show-current`: baseline and branch match.
- Initial `git diff --exit-code`, working/cached `git diff --check`: exit 0.
- `git diff 6f530ac... --exit-code -- src scripts build.gradle settings.gradle
  gradle.properties gradle gradlew gradlew.bat`: exit 0.
- `python -B scripts/validate_v1plus_planning.py`: exit 0, 11 plans/33 inputs.
- `git show :<path>` compared with working bytes for all 17 staged files:
  exact equality at initial capture; hashes/snapshots retained.
- Eight packet checksum rows match captured bytes and staged blobs.
- Both ZIPs pass CRC and unique/safe-name checks; every wrapper member digest
  matches. 351 content members plus two wrapper manifests.
- All four declared reviewer reports match length/hash; both immutable source
  reviewer directories match their archived members. The 77-entry contract
  manifest validates without remapping; 82 inventory rows use the explicit
  historical mapping above.
- Captured staged Markdown: 111 local targets, zero missing/unsafe targets.
  Thus all five formerly missing evidence targets are resolved in this packet.
- Existing main/API/sources JARs exactly match baseline metadata and committed
  v1.4 handoff; 27 API class bytes equal main, current generated inventory 34.

### Frozen archive identities

| Archive | Entries / content | SHA256 |
|---|---|---|
| root-checks.zip | 191 / 190 | `ccbd9754bd4b2df118f6bdbcf9377b350e5d5cfa73dec7646eca4dec2a4cd986` |
| independent-review.zip | 162 / 161 | `9e812d3d9fae181cc174828d5baed28e9d490f877d703c0a3edb68cd54e30ba1` |

Baseline artifacts remain:
- Main `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475`
- API `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf`
- Sources `afc83ef63e3054657831bfb6e170cbc4a6cbffe3029738ec3a6bb562474dc8db`

922 JUnit / 167 suites FROM-CACHE and 236 executed GameTests remain attributed
to the root baseline run. The 15 ERROR / 0 FATAL and 2,656 ms / 53-tick warning
remain disclosed, not removed or promoted to performance acceptance. This
assembly review did not execute or freshly audit the whole JVM suite/log.

## Retained attempts and moving-workspace boundary

1. `audit_assembly.py` / `audit.log`: exit 1 at the malformed inventory
   manifest name. Genuine historical evidence defect described above.
2. `audit_corrected.py` / `audit-corrected.log`: exit 1 because archived
   `root/final_readback.py` no longer equalled the continuing root Temp helper.
   The retained diff shows it added support for the forthcoming assembly report.
   Root confirmed that this happened after ZIP creation. No frozen evidence bytes
   changed. Root Temp is a continuing workspace, not an immutable capture.
3. `audit_sealed.py` / `audit-sealed.log`: exit 1 at command checks because
   root then had an explicitly disclosed unstaged VERIFICATION note and pending
   assembly attachment link. Raw diff is retained. This does not retroactively
   change the initial 17 staged byte comparisons.
4. `audit_snapshot.py` / `audit-snapshot.log`: exit 0; validates the captured
   staged packet and frozen archives rather than treating later root helper/docs
   as frozen. It still requires immutable reviewer originals to match exactly.
   `snapshot-current-temp-comparisons.json` records the sole root-member drift,
   and `root-helper-postarchive-delta.patch` records its specific cause.

This final result is deliberately snapshot-scoped. Root's subsequent attachment
of this directory/report, note, metadata/checksum updates and final staged-byte
verification are separate actions; this report does not recursively certify its
own future archive. Root should retain the P3 note and original failed attempts.

## Completion and limitations

Completed finite assembly readback of the captured packet. No remaining
substantive preparation blocker beyond disclosing/supplementing the original P3
receipt defect and root's final attachment-byte verification. No tracked/index
writes, old reviewer-directory changes, excluded user-bundle reads, JVM/Gradle,
server/client/remote commands or subdelegation occurred.

This is neither a v1.5 runtime/migration test nor a release/Gate approval, candidate
selection or tag authorization. No additional test campaign is recommended for
this preparation delta; the next implementation scope remains V150-STATION-01.

