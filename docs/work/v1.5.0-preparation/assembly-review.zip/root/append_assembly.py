from pathlib import Path
import hashlib
import json
import sys
import zipfile

DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-preparation')
SOURCE = Path(sys.argv[1]).resolve()
assert SOURCE.is_relative_to(Path('C:/Users/Administrator/AppData/Local/Temp').resolve())
reports = sorted(SOURCE.glob('*.md'))
assert reports
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {'assembly/' + path.relative_to(SOURCE).as_posix(): path.read_bytes()
           for path in sorted(SOURCE.rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
entries['root/append_assembly.py'] = Path(__file__).read_bytes()
entries['root/final_readback.py'] = Path(__file__).with_name('final_readback.py').read_bytes()
manifest = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(entries.items()))
entries['MEMBER-SHA256SUMS.txt'] = manifest.encode('utf-8')
target = DEST / 'assembly-review.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 28, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
entry = {'name': target.name, 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
         'members': len(entries), 'manifest': 'MEMBER-SHA256SUMS.txt',
         'source_directories': [{'prefix': 'assembly', 'path': str(SOURCE)}],
         'scope': 'Independent pre-attachment packet readback; root appended this immutable report and reran final checks'}
metadata = json.loads((DEST / 'evidence-archives.json').read_text(encoding='utf-8'))
assert len(metadata['archives']) == 2
metadata['archives'].append(entry)
(DEST / 'evidence-archives.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8', newline='\n')
identity = json.loads((DEST / 'independent-review.json').read_text(encoding='utf-8'))
identity['assembly_review'] = {'archive': target.name, 'reports': [
    {'member': 'assembly/' + path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
    for path in reports]}
(DEST / 'independent-review.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
checksums = ''.join(f'{sha(path.read_bytes())}  {path.name}\n' for path in sorted(DEST.iterdir())
                    if path.is_file() and path.name != 'SHA256SUMS.txt')
(DEST / 'SHA256SUMS.txt').write_text(checksums, encoding='utf-8', newline='\n')
print(json.dumps(entry, indent=2))
