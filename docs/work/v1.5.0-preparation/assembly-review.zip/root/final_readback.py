from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/work/v1.5.0-preparation'
BASE = '6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b'
sys.path.insert(0, str(ROOT))
from scripts.validate_v1plus_planning import outside_fences


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, capture_output=True)
    assert result.returncode == 0, (args, result.returncode, result.stderr.decode('utf-8'))
    return result.stdout


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert git('branch', '--show-current').decode().strip() == 'codex/v1.5.0-orbital-station-warp'
git('diff', '--exit-code')
git('diff', '--cached', '--check')
git('diff', '--exit-code', BASE, '--', 'src', 'build.gradle', 'settings.gradle', 'gradle.properties', 'gradle', 'scripts', 'docs/status/GATE_STATUS.md')
names = git('diff', '--cached', '--name-only').decode().splitlines()
allowed = {
    'DOCUMENT-INDEX.md', 'README.md', 'docs/status/CURRENT_VERSION.md',
    'docs/versions/V1.5.0-ORBITAL-STATION-WARP.md', 'tests/test_v1plus_planning.py',
    'docs/decisions/ADR-039-V150-DEVELOPMENT-BASELINE-EXCEPTION.md',
    'docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md',
    'docs/work/v1.5.0-implementation-log.md',
}
assert names and all(name in allowed or name.startswith('docs/work/v1.5.0-preparation/') for name in names)
identities = []
links = 0
for name in names:
    working = (ROOT / name).read_bytes()
    staged = git('show', ':' + name)
    if Path(name).suffix in {'.md', '.txt', '.py', '.json'}:
        assert staged == working.replace(b'\r\n', b'\n'), name
    else:
        assert staged == working, name
    identities.append({'path': name, 'working_sha256': sha(working), 'index_sha256': sha(staged)})
    if name.endswith('.md'):
        for link in re.findall(r'\[[^\]\n]*\]\(([^)\s]+)\)', outside_fences(working.decode('utf-8'))):
            parsed = urlsplit(link)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            path = ((ROOT / name).parent / unquote(parsed.path)).resolve()
            assert path.is_relative_to(ROOT) and path.exists(), (name, link)
            links += 1

checksum_count = 0
for line in (DEST / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    expected, relative = line.split('  ', 1)
    path = DEST / relative
    assert path.parent == DEST and sha(path.read_bytes()) == expected, relative
    assert sha(git('show', ':' + path.relative_to(ROOT).as_posix())) == expected, ('index checksum', relative)
    checksum_count += 1
archives = json.loads((DEST / 'evidence-archives.json').read_text(encoding='utf-8'))['archives']
members = 0
for info in archives:
    path = DEST / info['name']
    assert info['bytes'] == path.stat().st_size and info['sha256'] == sha(path.read_bytes())
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(set(archive.namelist())) == info['members']
        rows = archive.read(info['manifest']).decode().splitlines()
        assert len(rows) + 1 == info['members']
        for row in rows:
            expected, name = row.split('  ', 1)
            assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
            assert sha(archive.read(name)) == expected, name
        members += len(rows)
review_identity = json.loads((DEST / 'independent-review.json').read_text(encoding='utf-8'))
reports = review_identity['reports']
with zipfile.ZipFile(DEST / 'independent-review.zip') as archive:
    for report in reports:
        data = archive.read(report['member'])
        assert len(data) == report['bytes'] and sha(data) == report['sha256']
assembly = review_identity.get('assembly_review')
if assembly:
    with zipfile.ZipFile(DEST / assembly['archive']) as archive:
        for report in assembly['reports']:
            data = archive.read(report['member'])
            assert len(data) == report['bytes'] and sha(data) == report['sha256']
summary = {'staged_files': identities, 'changed_markdown_links': links,
           'packet_checksums': checksum_count, 'archive_hashed_members': members,
           'independent_reports': len(reports) + (len(assembly['reports']) if assembly else 0), 'production_diff_exit': 0,
           'unstaged_diff_exit': 0, 'staged_whitespace_exit': 0,
           'base_commit': BASE, 'scope': 'Precommit readback, not runtime verification or Gate approval'}
(OUT / 'final-readback.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: len(value) if key == 'staged_files' else value for key, value in summary.items()}, indent=2))
