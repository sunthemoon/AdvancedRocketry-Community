"""Final independent preparation check, outputs confined to this Temp directory."""
import hashlib,json,pathlib,subprocess,sys,os,time,zipfile
ROOT=pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
OUT=pathlib.Path(__file__).resolve().parent/"final"
OUT.mkdir(exist_ok=True)
FILES=["docs/decisions/ADR-039-V150-DEVELOPMENT-BASELINE-EXCEPTION.md","docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md","docs/work/v1.5.0-implementation-log.md","docs/work/v1.5.0-preparation/check_examples.py","docs/work/v1.5.0-preparation/examples.json","docs/work/v1.5.0-preparation/VERIFICATION.md","docs/work/v1.5.0-preparation/baseline-checks.json","README.md","DOCUMENT-INDEX.md","docs/status/CURRENT_VERSION.md","docs/versions/V1.5.0-ORBITAL-STATION-WARP.md","tests/test_v1plus_planning.py","scripts/validate_v1plus_planning.py","scripts/validate_repository.py","build.gradle","docs/releases/v1.4.0/development-artifacts.json"]
def digest(raw):return hashlib.sha256(raw).hexdigest()
inputs=[]
for name in FILES:
    raw=(ROOT/name).read_bytes(); dst=OUT/"inputs"/name
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
    inputs.append(dict(path=name,bytes=len(raw),sha256=digest(raw)))
(OUT/"input-identities.json").write_text(json.dumps(inputs,indent=2)+"\n",encoding="utf8")
commands=[["git","rev-parse","HEAD"],["git","branch","--show-current"],["git","status","--short","--untracked-files=no"],["git","diff","--check"],["git","diff","--cached","--check"],["git","diff","6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b","--exit-code","--","src","scripts","build.gradle","settings.gradle","gradle.properties","gradle","gradlew","gradlew.bat"],[sys.executable,"-B","docs/work/v1.5.0-preparation/check_examples.py"],[sys.executable,"-B","scripts/validate_v1plus_planning.py"],["git","diff","--","tests/test_v1plus_planning.py"]]
results=[]
for i,cmd in enumerate(commands):
    started=time.monotonic()
    r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONUTF8":"1"})
    name=f"command-{i:02d}.log";(OUT/name).write_bytes(r.stdout)
    results.append(dict(argv=cmd,exit=r.returncode,seconds=time.monotonic()-started,log=name)); print(json.dumps(results[-1]))
(OUT/"commands.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf8")
assert all(r["exit"]==0 for r in results)
sys.path.insert(0,str(ROOT/"scripts"));import validate_repository
docs=sorted(set(subprocess.check_output(["git","ls-files","*.md"],cwd=ROOT).decode().splitlines()+[n for n in FILES if n.endswith(".md")]))
assert not any(n.startswith("AdvancedRocketry-Community-v1plus-Development-Docs/") for n in docs)
errors,count=validate_repository.markdown_link_errors(ROOT,[ROOT/n for n in docs])
links=dict(documents=len(docs),checked_links=count,errors=errors,scope="Tracked Markdown plus explicit task Markdown; evidence archives/metadata still being assembled by root. Raw missing targets retained, not declared passed.")
(OUT/"links.json").write_text(json.dumps(links,indent=2)+"\n",encoding="utf8");print(json.dumps(links))
base=json.loads((ROOT/"docs/work/v1.5.0-preparation/baseline-checks.json").read_text())
handoff=json.loads((ROOT/"docs/releases/v1.4.0/development-artifacts.json").read_text())
assert base["artifacts"]==handoff["artifacts"]
artifacts=[]
for e in base["artifacts"]:
    path=ROOT/"build/libs"/e["name"]; raw=path.read_bytes()
    assert len(raw)==e["bytes"] and digest(raw)==e["sha256"]
    with zipfile.ZipFile(path) as z:
        names=z.namelist();assert len(names)==len(set(names));assert z.testzip() is None
    artifacts.append(dict(**e,entries=len(names),duplicate_entries=0,zip_crc_errors=0))
api=next(e for e in artifacts if e["name"].endswith("-api.jar"))
main=next(e for e in artifacts if not e["name"].endswith(("-api.jar","-sources.jar")))
with zipfile.ZipFile(ROOT/"build/libs"/api["name"]) as a,zipfile.ZipFile(ROOT/"build/libs"/main["name"]) as m:
    classes=sorted(n for n in a.namelist() if n.endswith(".class"))
    assert len(classes)==base["api_class_count"]==27
    assert all(a.read(n)==m.read(n) for n in classes)
generated=subprocess.check_output(["git","ls-files",base["tracked_generated_directory"]+"/*"],cwd=ROOT).decode().splitlines()
assert len(generated)==base["tracked_generated_entries"]==34
generated_rows=[dict(path=n,bytes=(ROOT/n).stat().st_size,sha256=digest((ROOT/n).read_bytes())) for n in generated]
result=dict(artifacts=artifacts,api_classes=classes,api_classes_equal_main=True,generated_directory=base["tracked_generated_directory"],generated=generated_rows,jvm_executed=False)
(OUT/"artifact-resource-check.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
print(json.dumps(dict(artifacts_equal_v14_handoff=3,api_classes=27,api_class_bytes_equal_main=True,generated_entries=34,jvm_executed=False)))

