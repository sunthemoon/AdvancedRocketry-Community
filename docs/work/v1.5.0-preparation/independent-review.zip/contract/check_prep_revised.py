"""Independent prep-only checks; all outputs stay beside this script."""
import hashlib, json, os, pathlib, subprocess, sys, time
ROOT=pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
OUT=pathlib.Path(__file__).resolve().parent
FILES=[
"docs/decisions/ADR-039-V150-DEVELOPMENT-BASELINE-EXCEPTION.md",
"docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md",
"docs/work/v1.5.0-implementation-log.md",
"docs/work/v1.5.0-preparation/check_examples.py",
"docs/work/v1.5.0-preparation/examples.json",
"docs/work/v1.5.0-preparation/VERIFICATION.md",
"README.md", "DOCUMENT-INDEX.md", "docs/status/CURRENT_VERSION.md",
"docs/versions/V1.5.0-ORBITAL-STATION-WARP.md",
]
label=sys.argv[1] if len(sys.argv)>1 else "initial"
records=[]
for name in FILES:
    raw=(ROOT/name).read_bytes()
    dst=OUT/label/"inputs"/name
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(raw)
    records.append({"path":name,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()})
(OUT/label/"input-identities.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
commands=[
["git","rev-parse","HEAD"],
["git","branch","--show-current"],
["git","status","--short","--untracked-files=no"],
["git","diff","--check"],
["git","diff","--cached","--check"],
["git","diff","6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b","--exit-code","--","src","build.gradle","settings.gradle","gradle.properties","gradle","gradlew","gradlew.bat"],
[sys.executable,"-B","docs/work/v1.5.0-preparation/check_examples.py"],
[sys.executable,"-B","scripts/validate_v1plus_planning.py"],
]
results=[]
for index,cmd in enumerate(commands):
    start=time.monotonic()
    result=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONUTF8":"1"})
    log=f"command-{index:02d}.log"
    (OUT/label/log).write_bytes(result.stdout)
    results.append({"argv":cmd,"exit":result.returncode,"seconds":time.monotonic()-start,"log":log})
    print(json.dumps(results[-1]))
sys.path.insert(0,str(ROOT/"scripts"))
import validate_repository as validator
names=subprocess.check_output(["git","ls-files","*.md"],cwd=ROOT).decode().splitlines()
names+=[name for name in FILES if name.endswith('.md')]
names=sorted(set(names))
assert not any(name.startswith("AdvancedRocketry-Community-v1plus-Development-Docs/") for name in names)
errors, count=validator.markdown_link_errors(ROOT,[ROOT/name for name in names])
links={"documents":len(names),"checked_links":count,"errors":errors,"scope":"Tracked Markdown plus explicit task documents listed in FILES; no excluded-bundle content."}
(OUT/label/"links.json").write_text(json.dumps(links,indent=2)+"\n",encoding="utf-8")
(OUT/label/"commands.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
print(json.dumps(links))
assert all(result["exit"]==0 for result in results), "See retained command logs"
assert not errors
