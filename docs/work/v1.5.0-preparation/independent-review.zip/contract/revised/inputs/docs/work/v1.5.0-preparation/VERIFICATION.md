# V150-GOV-01 / V150-CON-01 preparation verification

Date: 2026-09-28. Status: IN_PROGRESS while independent review and evidence
assembly run. Scope: development baseline, station foundation contract and
documentation examples. **No v1.5 production feature, world migration,
candidate or Required Gate is delivered here.**

Baseline: `6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b`;
branch: `codex/v1.5.0-orbital-station-warp`.
[Implementation log](../v1.5.0-implementation-log.md) is the canonical task tree.
ADR-039/040 are proposed pending independent draft review; inherited G0-G9 stay
open. No upstream imports or public API changes.

## Checks in progress

- `gradlew.bat clean build test runData runGameTestServer --offline --no-daemon --console=plain`:
  exit 0, 151 seconds, 236 newly executed required GameTests passed.
- `python -B docs/work/v1.5.0-preparation/check_examples.py`: exit 0, 12 passed.
- Remaining evidence assembly: artifact/test identities, repository/planning
  checks and independent review receipts.

Examples are normalized JSON projections, not NBT decoders, authentic world
fixtures, migration/backups, permissions, runtime or performance evidence.
Existing runtime and build identity remain v1.4-dev. No native server migration,
real-client, remote or long-load checks were run for v1.5 preparation.
