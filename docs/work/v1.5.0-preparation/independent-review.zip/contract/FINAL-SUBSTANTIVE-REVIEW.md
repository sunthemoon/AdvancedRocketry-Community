# V150 preparation — final substantive independent review

Date: 2026-09-28. Baseline: `6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b`.
Branch: `codex/v1.5.0-orbital-station-warp`.
Scope: ADR-039/040, v1.5 first-leaf plan and reader pointers, documentation examples,
planning-test correction, preparation metadata and unchanged artifact readback.
This is preparation review, not runtime implementation or release/Gate approval.

## Findings and resolution

**No unresolved substantive contract/test finding was identified in the final
inspected preparation inputs.** Two initial P2 findings remain preserved in
`INITIAL-DRAFT-REVIEW.md`; their resolutions are contractual, not runtime fixes.

1. **P2 checked-save caller semantics — resolved in the contract.**
   [ADR-040:136–154](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L136)
   isolates the checked immutable expansion candidate commit from ordinary
   creation/member/delete flush callers. Wider exception changes require explicit
   caller adaptation and failure tests. This addresses the proposed integration
   hazard at
   [StationCreationService:76–95](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationCreationService.java#L76):
   post-commit catch/release cannot undo a committed registry entry.
   Failed expansion must not leave a rejected live candidate for later autosave.
2. **P2 local/operator/confirmation authority — resolved in the contract.**
   [ADR-040:55–76](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L55)
   now requires an actual local server player for both owner and operator, loaded
   current-position chunk, no console/remote bypass, actor/station/complete
   observed state/registry lifecycle binding, one pending per player, 128 total,
   200 ticks, commit-time revalidation and logout/stop cleanup.
   [STATION-03:147–161](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-implementation-log.md#L147)
   records matching implementation checks.
3. **Assembly identity corrections are now consistent.**
   ADR headers and CURRENT_VERSION now consistently record root's separate
   acceptance under standing direction, not reviewer authority. The generated
   inventory previously counted 29 legacy-directory entries; final
   `baseline-checks.json` explicitly identifies `src/generated/v1.4/resources`
   and 34 entries, independently confirmed against tracked inventory and
   [build.gradle:97](D:/GitHub/AdvancedRocketry-Community/build.gradle#L97).
   The old collector observations are root-retained history, not a final result.

**Evidence assembly remains pending, not a substantive contract failure.** The
final local-link read found 1,886 targets across 406 tracked/explicit documents
and exactly five unresolved targets in VERIFICATION: independent-review.zip,
independent-review.json, root-checks.zip, evidence-archives.json, SHA256SUMS.txt.
Root explicitly reserved these for packaging this report. Raw errors remain in
`final/links.json`; this report does not call that link check passed or certify
future archive/staged bytes. Earlier initial/revised link runs had zero errors.
Final assembly needs a separate short delta/integrity check.

## Actual test correction and scope

[tests/test_v1plus_planning.py:32–36](D:/GitHub/AdvancedRocketry-Community/tests/test_v1plus_planning.py#L32)
adds the actually linked `compat-test-mod/README.md` to the synthetic Temp
repository. Its
[new negative test:92–95](D:/GitHub/AdvancedRocketry-Community/tests/test_v1plus_planning.py#L92)
deletes that copied guide and requires the broken-link diagnostic. No production
validator or existing assertion was removed/weakened. The original root
14-test/two-failure run is documented as root evidence; the reviewer independently
executed the corrected 15 cases below.

Documentation examples check centered/inclusive 512/768 geometry, negative and
maximum cells, constant-index compatibility, 256-column separation, version-only
projection/preservation, reservation independence and invalid versions/geometry.
They are explicitly partial JSON projections: no production NBT decoder, actual
migration, backup/atomic failure, permissions or authentic-world evidence.

The proposed station root 3 / record 2 / reservation 1 split keeps other managed
roots unchanged. Copy-based migration preserves extra tags during upgrade while
ordinary later saves retain their existing known-field policy. Per-file atomic
replacement does not claim a cross-file or hardware-power-loss transaction.
Unknown orbit identities remain recoverable; blocked Space authority must fail
closed rather than look like a valid gap. Orbit/solar/sky, multi-star routes,
movement choice, docked/inbound/unloaded rockets and online/offline passengers
remain separately required work; no metadata-only warp substitute is accepted.

## Independently executed commands and results

All Python invocations used `-B`, `PYTHONUTF8=1`, launcher
`D:/python/pyenv/pyenv-win/shims/python.bat`; resolved Python 3.13.15.
Working directory: `D:/GitHub/AdvancedRocketry-Community`.

| Command/check | Actual result |
|---|---|
| `python.bat -B -m unittest tests.test_v1plus_planning -v` | Exit 0, 15/15 actual methods, 18.031 s unittest duration; 18.484 s outer receipt |
| `python -B docs/work/v1.5.0-preparation/check_examples.py` | Exit 0, 12/12, 0.002 s final run |
| `python -B scripts/validate_v1plus_planning.py` | Exit 0, 11 plans / 33-input source inventory |
| `git diff --check` and `git diff --cached --check` | Both exit 0 |
| `git diff 6f530ac... --exit-code -- src scripts build.gradle settings.gradle gradle.properties gradle gradlew gradlew.bat` | Exit 0: runtime/build/scripts/generated content unchanged |
| Read-only ZIP/hash/resource helper | Three artifact hashes/lengths match both final baseline metadata and committed v1.4 handoff; no duplicate entries or CRC errors; all 27 API class bytes equal main; 34 current generated entries |
| Local Markdown link helper | 406 documents / 1,886 targets; five explicitly pending assembly targets, retained verbatim |

Exact argv/exits/durations are in `planning-unittest-receipt.json` and
`final/commands.json`; logs are retained beside them. Initial and revised checks
and snapshots remain unchanged. Additional read-only review used Get-Content
with line numbers, rg, git inventory/status/diff and the existing source inventory.
No excluded-bundle argument or content was read.

Root's baseline Gradle metadata reports 922 JUnit results / 167 suites
**FROM-CACHE**, 236 executed GameTests, zero DataGen writes, exit 0 / 2m31s.
Its 15 ERROR / zero FATAL and 2,656 ms / 53-tick warning remain disclosed in
VERIFICATION. These are **root command/log classifications**, not independently
rerun JVM results or a newly audited complete raw JVM log in this preparation
review. Independent artifact readback does not turn cached tests into execution.

## Artifact and reviewed input identities

- Main: `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475`
- API: `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf`
- Sources: `afc83ef63e3054657831bfb6e170cbc4a6cbffe3029738ec3a6bb562474dc8db`

They remain v1.4-dev artifacts, not v1.5 candidate artifacts. Exact input bytes/
hashes for 16 final files, including ADRs, plan, examples, test, validator,
metadata and reader pointers, are in `final/input-identities.json` and snapshots.
Archive/resource details are in `final/artifact-resource-check.json`.

Prior immutable reports:
- Source inventory (separate directory):
  `C:/Users/Administrator/AppData/Local/Temp/arce-v150-preparation-review-9400df81fbaa4aef805e1c3458937a99/V150-PREPARATION-REVIEW.md`
  SHA256 `6594cb5c9b3529a388530fcfc028496b8eda4e4507136ad7340696f996c267f5`.
- INITIAL-DRAFT-REVIEW.md:
  `511236c82221d50504f01c9859cffc42d1bc2077d8110ec826c0f96ce6c825f2`.
- REVISED-CORE-REVIEW.md:
  `8d362153d85ff55279cec8f79a5bc6cf35ebfb2907db3d3d0327983a45cd408c`.

The prior revised helper's inaccurate descriptive phrase about the number of new
documents is retained in its raw output and explained in its report; final helper
uses the actual explicit list. No prior result or finding was discarded.

## Readiness and remaining limits

The contract and test correction are suitable for completing the preparation
leaf once root finishes evidence assembly/status consistency. This is not
implementation permission supplied by the reviewer: root separately recorded
maintainer authority, and every runtime leaf remains open.

No Gradle/JVM/GameTest/native/client/GPU/remote/load test was executed by this
reviewer. No repository/index/build/world writes, source edits or child agents;
review outputs only in this Temp. Planning unittest mutations were confined to
its disposable Temp fixture. No v1.5 migration/expansion behavior, actual orbit
effects, warp, concurrency, full acceptance, final archive, release or Gate is
approved. Next implementation remains V150-STATION-01 with its accepted bounds;
final archive verification is a later evidence-only delta.

