# V150 preparation draft review — initial findings

Baseline: 6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b.
Branch: codex/v1.5.0-orbital-station-warp. Review scope: proposed ADR-039,
ADR-040, canonical v1.5 task hierarchy and the two documentation example files.
Original bytes are retained in initial/inputs; this report is not amended when
the root writer revises the proposals.

## Findings

### P2 — Specify which runtime callers gain checked flush semantics

[ADR-040:123–132](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L123)
proposes station-specific checked persistence, reusing the atomic writer, without
saying whether the old void flush caller contract changes.

[StationCreationService:76–95](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationCreationService.java#L76)
commits the station into the registry, calls flush, and on a RuntimeException
removes the platform and releases the reservation.
[StationRegistryModel:49–68](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationRegistryModel.java#L49)
has already removed that reservation and inserted a committed station; release
then does nothing. Making its old flush throw on an I/O failure can therefore
leave a committed station without its platform, eligible for a later autosave,
despite returning failure. Membership/delete callers also mutate before flush.

This is a concrete integration hazard under the proposed change, not a failure
reproduced against unchanged production. “Not cross-file atomic” does not
determine the correct same-session cleanup semantics.

Minimum correction: isolate expansion's checked candidate-commit operation from
old ordinary flush semantics, or explicitly require adapting/regressing all
callers whose acknowledgement/failure behavior changes. State that adding an
ordinary atomic writer must not accidentally add a throwing checked barrier to
these existing operations. Later implementation must be reviewed/tested.

### P2 — Freeze local/operator and confirmation lifecycle authority

[ADR-040:54–60](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L54)
says local owner/operator and stale rejection, whereas
[work log:145–154](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-implementation-log.md#L145)
requires unloaded requests rejected without defining the position/load predicate
or operator-console exception. Existing StationCommands has both player-required
membership methods and permission-level-2 console operations; locality cannot
be inferred uniformly from these callers.

Minimum correction: explicitly bind normal owner action to an actual server
player in the current station's committed Space region with a loaded current
position, without probing/loading the larger region; state the audited console/
remote operator policy. A two-step confirmation must be actor/station/observed
authority bound, finite-lived and count-bounded, revalidate authority/locality on
commit and be lifecycle-cleaned. An equally bounded stateless mechanism is also
possible if it meets those conditions. No exact token format is mandated by this
finding.

## Source-backed positive observations (not acceptance)

- Centered 512/768 geometry fits the existing nearest-cell index, including
  negative and +/-1,000,000 cell extremes, without integer-coordinate overflow.
- Region expansion is correctly described as a permission/context adoption,
  not world-block movement or a proof of empty margins; foreign gap construction
  is explicitly disclosed.
- Record 2 / reservation 1 / only STATIONS root 3 avoids changing all five
  managed roots through the existing global schema constant.
- Legacy geometry must be validated before widening; copy-based migration
  preserves unknown tags/byte-valued fields during that step only.
- The proposed per-file manifests, old companion preservation, no non-atomic
  fallback for station migration and explicit mixed-file interruption limits
  describe feasible finite work without claiming hardware durability.
- Blocked registry versus valid gaps and real environment/warp follow-up are
  explicitly distinguished. No actual warp protocol/API is prematurely created.
- ADR-039 keeps version order exception, contracts and release/Gate authority
  separate; root baseline commands cannot verify these unimplemented behaviors.

## Actual independent checks

Executed via Python 3.13.15 with -B and PYTHONUTF8=1:
- docs/work/v1.5.0-preparation/check_examples.py: exit 0, 12 methods, 0.002 s.
- scripts/validate_v1plus_planning.py: exit 0, 11 plans/33 source inputs.
- Local-link helper using repository validator: 405 tracked/explicit draft
  Markdown documents; 1,873 targets; 0 errors.
- git diff --check and git diff --cached --check: exit 0.
- git diff 6f530ac... --exit-code -- src build.gradle settings.gradle
  gradle.properties gradle gradlew gradlew.bat: exit 0.

Exact argv, elapsed times and logs: initial/commands.json and command-00..07.log.
Inputs/digests: initial/input-identities.json. Read-only source analysis used
Get-Content/rg/git inventory for the migration service, schema migrator,
managed type/validator and station command/model/service callers.

No repository/index/source/build writes, Gradle/JVM/server/client/network run,
user-bundle reads or subdelegation. Reports/helpers only reside in this Temp.
These example checks are neither the production Codec nor authentic world
migration, checked-save failure recovery, permissions gameplay or warp evidence.

Readiness: draft review has two unresolved clarifications above. No contract
acceptance, runtime readiness, release or Gate approval is supplied.

