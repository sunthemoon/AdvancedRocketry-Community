# V150 preparation contract review — revised core

## Findings and resolution

No unresolved substantive finding in the revised ADR-039/040 core inspected here.
This is a **preparation-only** assessment; production migration, expansion,
persistence, player authority, orbit effects and warp have not been implemented
or verified by this review.

The unchanged INITIAL-DRAFT-REVIEW.md preserves both original P2 findings:

1. **Checked persistence caller semantics — resolved in the contract.**
   [ADR-040:133–151](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L133)
   now isolates immutable candidate expansion commit, forbids silently changing
   ordinary creation/member/delete flush exception semantics, and requires
   explicit adaptations/tests before changing those callers. Exact candidate
   replacement precedes live publication; failed writes cannot later autosave
   the rejected growth. This addresses the existing creation rollback hazard
   identified at StationCreationService:76–95; it is not a claim the hazard has
   already been fixed in runtime code.

2. **Local/operator and confirmation authority — resolved in the contract.**
   [ADR-040:54–73](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md#L54)
   now requires an actual local server player for both owner/operator,
   current-position loaded chunk, no console/remote bypass, actor/station/full
   observed state/lifecycle binding, one pending per player, 128 overall,
   200-tick maximum lifetime, revalidation and logout/stop cleanup.
   STATION-03 records the matching operation and failure checks.

The revised per-file atomic-move wording at ADR-040:115–123 avoids suggesting
a preflight can guarantee all future filesystem operations, rejects fallback
to non-atomic replacement and retains mixed-complete-file interruption limits.

**In-assembly wording observation:** CURRENT_VERSION.md initially said
“Under accepted ADR-039” while both ADRs were still PROPOSED. Root was notified
to align that wording when recording acceptance or retain “proposed” meanwhile.
This report does not supply that acceptance. Final metadata/evidence assembly is
not yet certified here; a later delta may verify its actual state.

## Reviewed policy and feasibility

- ADR-039 limits development authority to v1.5 and leaves the inherited
  acceptance cursor, candidate/tag/release decisions and all Gates unchanged.
- No new Java/build/generated-resource or public API/wire behavior is included.
  The baseline remains 6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b and the running
  build is still 1.20.1-1.4.0-dev.
- Station UUID/cell/pad/orbit identities remain stable; 512/768 centered extents
  preserve the current nearest-cell lookup and at least 256-column separation.
  Gap-content adoption is explicitly a permission/context tradeoff, not a
  detection or physical-movement guarantee.
- Root 3 is STATIONS-specific; records become 2 and reservations retain 1.
  Legacy 512 geometry is validated before migration, and copy-based tag
  preservation applies only to that migration step. Unknown orbit IDs remain
  recoverable. Old bytes/backups and per-file source/target schemas are explicit.
- Fail-closed unavailable station authority is distinct from a legitimate gap.
  Blocked registry behavior and old ordinary flush limitations remain assigned
  implementation work, not implicitly repaired by planning.
- Orbit physics/solar/presentation, multi-star identities, warp/docking and
  passenger recovery remain required subsequent outcomes. The plan explicitly
  reserves the logical-versus-physical movement decision and does not manufacture
  a generic station teleport protocol or unstable public extension API.
- The hierarchy has separately observable first station leaves, dependencies,
  acceptance and short verification; STATION-01 alone is explicitly not a
  deployable migration.

## Independently executed checks

Raw argv/exit/duration receipts are in initial/commands.json and
revised/commands.json; logs and input snapshots for both states remain unchanged.

| Check | Initial | Revised |
|---|---|---|
| Python -B documentation examples | exit 0; 12 methods; 0.002 s | exit 0; 12 methods; 0.002 s |
| validate_v1plus_planning.py | exit 0; 11 plans / 33 inputs | exit 0; 11 plans / 33 inputs |
| Local Markdown targets | 405 docs / 1,873 links / 0 errors | 406 docs / 1,874 links / 0 errors |
| Working and cached whitespace | both exit 0 | both exit 0 |
| Runtime/build diff against 6f530ac | exit 0 | exit 0 |

Execution launcher: D:/python/pyenv/pyenv-win/shims/python.bat with PYTHONUTF8=1;
resolved interpreter: D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe.
Every Python invocation used -B. The runtime/build comparison explicitly covers
src, build.gradle, settings.gradle, gradle.properties, gradle and both wrappers.

The revised helper's raw links.json retains an inherited description saying
“three explicit new draft documents”; its actual input list also included the
new VERIFICATION document (406 total). Only the explanatory label was corrected
in check_prep_revised.py for subsequent runs; original counts/output remain
unchanged. No result was discarded or relaxed.

Core revised SHA-256:
- ADR-039: 6e57fe4474a4da91e246667acc0de8b5c58c7b36e5d364199393e287a9c80bd8
- ADR-040: 5b89842844c29c69a51152ab6913d92132feeb824ef0c9db48dd443fb5443ccd
- Work log: f608cea7189e2cc0aa75b9274b5345103793ed562a7acbeba40f1abd090cdec8
- Example checker: eef5358a67a3d3b3b1080be6c800fcdf58b1858233f204f87f69e73cc5d9248f
- examples.json: 37e6d8abb739c2881601a6746cf259b04f93e587fbfa3fccb53c438865b1b0b5

The root-reported unchanged-runtime build/GameTest pass is **root evidence**,
not an independently repeated command in this review. No JUnit count/freshness,
JAR rebuild, runtime migration or native result is inferred from the examples.

## Readiness and boundaries

The revised core is suitable to finish the **preparation** leaf once the root
records its separate authority decision and final evidence/status consistency.
No additional substantive contract blocker was found in this bounded readback.

Not executed: Gradle/JVM, GameTests, native/client/server/GPU, remote or load
tests. No repository/index/build/world writes or excluded-user-bundle reads;
no new agents. All outputs are in this new reviewer Temp directory. This
assessment does not authorize implementation before contract acceptance, certify
the final yet-to-be-assembled archive, or approve any release/Gate.

