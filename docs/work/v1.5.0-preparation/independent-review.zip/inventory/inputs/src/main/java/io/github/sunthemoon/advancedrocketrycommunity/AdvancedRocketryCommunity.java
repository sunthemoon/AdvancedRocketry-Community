package io.github.sunthemoon.advancedrocketrycommunity;

import com.mojang.logging.LogUtils;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.CelestialCatalogManager;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.command.CelestialCommands;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.command.PlanetaryRouteCommands;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialNetwork;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialSnapshotSynchronizer;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.data.PlanetaryCatalogManager;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.data.PlanetaryDefinitionReloadListener;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.CelestialEnvironmentService;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.CelestialGravityController;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.CelestialVisitTracker;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.service.SafeCelestialTravel;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.binding.PlanetaryBindingLifecycle;
import io.github.sunthemoon.advancedrocketrycommunity.config.CommonConfig;
import io.github.sunthemoon.advancedrocketrycommunity.diagnostics.BetaDiagnosticId;
import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.BetaWorldMigrationEvents;
import io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.BetaDataCommands;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.command.AtmosphereCommands;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.network.LifeSupportNetwork;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.server.AtmosphereManager;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.server.AtmosphereRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.server.AtmosphereServerEvents;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.server.PlayerLifeSupportService;
import io.github.sunthemoon.advancedrocketrycommunity.machine.multiblock.pattern.service.MultiblockPatternCatalogManager;
import io.github.sunthemoon.advancedrocketrycommunity.machine.multiblock.pattern.service.MultiblockPatternReloadListener;
import io.github.sunthemoon.advancedrocketrycommunity.machine.precision.PrecisionAssemblerManager;
import io.github.sunthemoon.advancedrocketrycommunity.machine.precision.PrecisionAssemblerCommands;
import io.github.sunthemoon.advancedrocketrycommunity.machine.precision.PrecisionAssemblerRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.machine.precision.PrecisionAssemblerServerEvents;
import io.github.sunthemoon.advancedrocketrycommunity.machine.rolling.RollingMachineCommands;
import io.github.sunthemoon.advancedrocketrycommunity.machine.rolling.RollingMachineManager;
import io.github.sunthemoon.advancedrocketrycommunity.machine.rolling.RollingMachineRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.machine.rolling.RollingMachineServerEvents;
import io.github.sunthemoon.advancedrocketrycommunity.registry.ModRegistries;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.command.RocketCommands;
import io.github.sunthemoon.advancedrocketrycommunity.api.rocket.RegisterRocketAdaptersEvent;
import io.github.sunthemoon.advancedrocketrycommunity.api.rocket.RegisterRocketComponentsEvent;
import io.github.sunthemoon.advancedrocketrycommunity.api.rocket.RegisterRocketFuelsEvent;
import io.github.sunthemoon.advancedrocketrycommunity.compat.rocket.fuel.RocketFuelRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.fuel.RocketFuelRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.compat.rocket.component.RocketComponentCatalog;
import io.github.sunthemoon.advancedrocketrycommunity.compat.rocket.component.RocketComponentRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.compat.rocket.RocketAdapterRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.api.atmosphere.RegisterAtmosphereBoundariesEvent;
import io.github.sunthemoon.advancedrocketrycommunity.compat.atmosphere.AtmosphereBoundaryRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.api.atmosphere.RegisterSuitEquipmentEvent;
import io.github.sunthemoon.advancedrocketrycommunity.compat.atmosphere.SuitEquipmentRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.compat.atmosphere.SuitEquipmentService;
import io.github.sunthemoon.advancedrocketrycommunity.compat.environment.EnvironmentQueryLifecycle;
import io.github.sunthemoon.advancedrocketrycommunity.atmosphere.server.SuitEquipmentRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.server.RocketManager;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.server.RocketRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.network.RocketVisualNetwork;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.network.RocketVisualSynchronizer;
import io.github.sunthemoon.advancedrocketrycommunity.rocket.network.RocketFlightNetwork;
import io.github.sunthemoon.advancedrocketrycommunity.station.service.StationManager;
import io.github.sunthemoon.advancedrocketrycommunity.station.service.StationRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.station.command.StationCommands;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.command.SatelliteCommands;
import io.github.sunthemoon.advancedrocketrycommunity.api.satellite.RegisterSatellitePayloadsEvent;
import io.github.sunthemoon.advancedrocketrycommunity.compat.satellite.SatellitePayloadRegistry;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.service.SatellitePayloadRuntime;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.service.SatelliteCatalogManager;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.service.SatelliteDefinitionReloadListener;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.service.SatelliteManager;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.service.SatelliteRuntime;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.ModLoader;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(AdvancedRocketryCommunity.MOD_ID)
public final class AdvancedRocketryCommunity {
    public static final String MOD_ID = ModIdentity.MOD_ID;
    public static final Logger LOGGER = LogUtils.getLogger();

    private final PlanetaryCatalogManager planetaryCatalogs = new PlanetaryCatalogManager();
    private final CelestialCatalogManager celestialCatalogs = planetaryCatalogs.celestialView();
    private final SatelliteCatalogManager satelliteCatalogs = new SatelliteCatalogManager();
    private final MultiblockPatternCatalogManager multiblockPatterns =
            new MultiblockPatternCatalogManager();
    private final RollingMachineManager rollingMachines = new RollingMachineManager(multiblockPatterns);
    private final PrecisionAssemblerManager precisionAssemblers = new PrecisionAssemblerManager(multiblockPatterns);
    private final CelestialEnvironmentService environments = new CelestialEnvironmentService(celestialCatalogs);
    private final LifeSupportNetwork lifeSupportNetwork;
    private AtmosphereManager atmosphereManager;
    private PlayerLifeSupportService playerLifeSupport;
    private RocketManager rocketManager;
    private final StationManager stationManager;
    private final SatelliteManager satelliteManager;

    public AdvancedRocketryCommunity(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();

        ModRegistries.register(modBus);
        context.registerConfig(ModConfig.Type.COMMON, CommonConfig.SPEC);
        modBus.addListener(this::onCommonSetup);
        MinecraftForge.EVENT_BUS.addListener(this::onAddReloadListeners);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStopped);
        MinecraftForge.EVENT_BUS.addListener(new BetaWorldMigrationEvents()::onServerAboutToStart);
        MinecraftForge.EVENT_BUS.addListener(new PlanetaryBindingLifecycle(planetaryCatalogs)::onServerAboutToStart);
        MinecraftForge.EVENT_BUS.addListener(new BetaDataCommands()::register);
        RollingMachineRuntime.install(rollingMachines);
        RollingMachineServerEvents rollingEvents = new RollingMachineServerEvents(rollingMachines);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onBlockBroken);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onBlockPlaced);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onNeighborNotify);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onChunkLoad);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onChunkUnload);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onDatapackSync);
        MinecraftForge.EVENT_BUS.addListener(rollingEvents::onServerAboutToStart);
        MinecraftForge.EVENT_BUS.addListener(new RollingMachineCommands()::register);
        PrecisionAssemblerRuntime.install(precisionAssemblers);
        PrecisionAssemblerServerEvents precisionEvents = new PrecisionAssemblerServerEvents(precisionAssemblers);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onBlockBroken);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onBlockPlaced);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onNeighborNotify);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onChunkLoad);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onChunkUnload);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onDatapackSync);
        MinecraftForge.EVENT_BUS.addListener(precisionEvents::onServerAboutToStart);
        MinecraftForge.EVENT_BUS.addListener(new PrecisionAssemblerCommands()::register);
        CelestialVisitTracker visitTracker = new CelestialVisitTracker(celestialCatalogs);
        MinecraftForge.EVENT_BUS.addListener(visitTracker::onPlayerLoggedIn);
        MinecraftForge.EVENT_BUS.addListener(visitTracker::onPlayerChangedDimension);
        stationManager = new StationManager(celestialCatalogs);
        StationRuntime.install(stationManager);
        MinecraftForge.EVENT_BUS.addListener(stationManager::onServerStarted);
        EnvironmentQueryLifecycle environmentQueries = new EnvironmentQueryLifecycle(celestialCatalogs);
        MinecraftForge.EVENT_BUS.addListener(environmentQueries::onServerStarted);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, environmentQueries::onServerStopping);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, environmentQueries::onServerStopped);
        MinecraftForge.EVENT_BUS.addListener(stationManager::onBlockBroken);
        MinecraftForge.EVENT_BUS.addListener(stationManager::onBlockPlaced);
        MinecraftForge.EVENT_BUS.addListener(new StationCommands(stationManager)::register);
        new RocketFlightNetwork();
        RocketVisualNetwork rocketVisualNetwork = new RocketVisualNetwork();
        RocketVisualSynchronizer rocketVisualSynchronizer = new RocketVisualSynchronizer(rocketVisualNetwork);
        MinecraftForge.EVENT_BUS.addListener(rocketVisualSynchronizer::onStartTracking);
        lifeSupportNetwork = new LifeSupportNetwork();
        CelestialGravityController gravityController = new CelestialGravityController(environments);
        MinecraftForge.EVENT_BUS.addListener(gravityController::onLivingTick);
        CelestialCommands celestialCommands = new CelestialCommands(
                celestialCatalogs,
                new SafeCelestialTravel()
        );
        MinecraftForge.EVENT_BUS.addListener(celestialCommands::register);
        MinecraftForge.EVENT_BUS.addListener(new PlanetaryRouteCommands(planetaryCatalogs)::register);
        CelestialNetwork celestialNetwork = new CelestialNetwork();
        CelestialSnapshotSynchronizer snapshotSynchronizer = new CelestialSnapshotSynchronizer(
                celestialCatalogs,
                celestialNetwork
        );
        MinecraftForge.EVENT_BUS.addListener(snapshotSynchronizer::onDatapackSync);
        satelliteManager = new SatelliteManager(
                satelliteCatalogs,
                celestialCatalogs,
                snapshotSynchronizer
        );
        SatelliteRuntime.install(satelliteManager);
        MinecraftForge.EVENT_BUS.addListener(satelliteManager::onServerStarted);
        MinecraftForge.EVENT_BUS.addListener(satelliteManager::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(new SatelliteCommands(satelliteManager)::register);
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(this::initializeRocketAdapters);
        event.enqueueWork(this::initializeRocketFuels);
        event.enqueueWork(this::initializeSatellitePayloads);
        event.enqueueWork(this::initializeAtmosphereBoundaries);
        String version = ModList.get()
                .getModContainerById(MOD_ID)
                .map(container -> container.getModInfo().getVersion().toString())
                .orElse("unknown");
        LOGGER.info("{} {} initialized", ModIdentity.DISPLAY_NAME, version);
        String jeiVersion = ModList.get()
                .getModContainerById("jei")
                .map(container -> container.getModInfo().getVersion().toString())
                .orElse("absent");
        LOGGER.info(
                "{} optional_compat=jei status={} version={}",
                BetaDiagnosticId.OPTIONAL_COMPATIBILITY.code(),
                "absent".equals(jeiVersion) ? "absent" : "present",
                jeiVersion
        );
    }

    private void initializeRocketAdapters() {
        if (rocketManager != null) {
            throw new IllegalStateException("Rocket services were already initialized");
        }
        try (RocketAdapterRegistry registry = new RocketAdapterRegistry(
                ForgeRegistries.BLOCK_ENTITY_TYPES::containsKey)) {
            ModLoader.get().runEventGenerator(container -> new RegisterRocketAdaptersEvent(
                    registry.forOwner(container.getModId())));
            RocketManager manager = new RocketManager(registry.freeze(), celestialCatalogs, planetaryCatalogs,
                    initializeRocketComponents());
            RocketRuntime.install(manager);
            MinecraftForge.EVENT_BUS.addListener(manager::onServerTick);
            MinecraftForge.EVENT_BUS.addListener(manager::onPlayerLoggedIn);
            MinecraftForge.EVENT_BUS.addListener(manager::onPlayerLoggedOut);
            MinecraftForge.EVENT_BUS.addListener(new RocketCommands(manager)::register);
            rocketManager = manager;
        }
    }

    private RocketComponentCatalog initializeRocketComponents() {
        try (RocketComponentRegistry registry = new RocketComponentRegistry(id ->
                ForgeRegistries.BLOCKS.containsKey(id) ? ForgeRegistries.BLOCKS.getValue(id) : null)) {
            ModLoader.get().runEventGenerator(container -> new RegisterRocketComponentsEvent(
                    registry.forOwner(container.getModId())));
            return registry.freeze();
        }
    }

    private void initializeRocketFuels() {
        try (RocketFuelRegistry registry = new RocketFuelRegistry(id ->
                ForgeRegistries.ITEMS.containsKey(id) ? ForgeRegistries.ITEMS.getValue(id) : null)) {
            ModLoader.get().runEventGenerator(container -> new RegisterRocketFuelsEvent(
                    registry.forOwner(container.getModId())));
            RocketFuelRuntime.install(registry.freeze());
        }
    }

    private void onAddReloadListeners(AddReloadListenerEvent event) {
        event.addListener(new PlanetaryDefinitionReloadListener(planetaryCatalogs));
        event.addListener(new SatelliteDefinitionReloadListener(satelliteCatalogs, celestialCatalogs));
        event.addListener(new MultiblockPatternReloadListener(multiblockPatterns));
    }

    private void initializeSatellitePayloads() {
        try (SatellitePayloadRegistry registry = new SatellitePayloadRegistry(id ->
                ForgeRegistries.ITEMS.containsKey(id) ? ForgeRegistries.ITEMS.getValue(id) : null)) {
            ModLoader.get().runEventGenerator(container -> new RegisterSatellitePayloadsEvent(
                    registry.forOwner(container.getModId())));
            SatellitePayloadRuntime.install(registry.freeze());
        }
    }

    private void initializeAtmosphereBoundaries() {
        if (atmosphereManager != null) {
            throw new IllegalStateException("Atmosphere services were already initialized");
        }
        try (AtmosphereBoundaryRegistry registry = new AtmosphereBoundaryRegistry(id ->
                ForgeRegistries.BLOCKS.containsKey(id) ? ForgeRegistries.BLOCKS.getValue(id) : null)) {
            ModLoader.get().runEventGenerator(container -> new RegisterAtmosphereBoundariesEvent(
                    registry.forOwner(container.getModId())));
            atmosphereManager = new AtmosphereManager(environments, registry.freeze());
            AtmosphereRuntime.install(atmosphereManager);
            SuitEquipmentService equipment = initializeSuitEquipment();
            SuitEquipmentRuntime.install(equipment);
            playerLifeSupport = new PlayerLifeSupportService(atmosphereManager, lifeSupportNetwork::send, equipment);
            AtmosphereServerEvents events = new AtmosphereServerEvents(atmosphereManager);
            MinecraftForge.EVENT_BUS.addListener(events::onServerTick);
            MinecraftForge.EVENT_BUS.addListener(events::onBlockBroken);
            MinecraftForge.EVENT_BUS.addListener(events::onBlockPlaced);
            MinecraftForge.EVENT_BUS.addListener(events::onFluidPlaced);
            MinecraftForge.EVENT_BUS.addListener(events::onRightClickBlock);
            MinecraftForge.EVENT_BUS.addListener(events::onNeighborNotify);
            MinecraftForge.EVENT_BUS.addListener(events::onChunkLoad);
            MinecraftForge.EVENT_BUS.addListener(events::onChunkUnload);
            MinecraftForge.EVENT_BUS.addListener(events::onDatapackSync);
            MinecraftForge.EVENT_BUS.addListener(playerLifeSupport::onLivingTick);
            MinecraftForge.EVENT_BUS.addListener(playerLifeSupport::onPlayerLoggedOut);
            MinecraftForge.EVENT_BUS.addListener(new AtmosphereCommands(atmosphereManager)::register);
        }
    }

    private SuitEquipmentService initializeSuitEquipment() {
        try (SuitEquipmentRegistry registry = new SuitEquipmentRegistry(id ->
                ForgeRegistries.ITEMS.containsKey(id) ? ForgeRegistries.ITEMS.getValue(id) : null)) {
            ModLoader.get().runEventGenerator(container -> new RegisterSuitEquipmentEvent(
                    registry.forOwner(container.getModId())));
            return new SuitEquipmentService(registry.freeze());
        }
    }

    private void onServerStopped(ServerStoppedEvent event) {
        if (playerLifeSupport != null) {
            playerLifeSupport.clear();
        }
        if (atmosphereManager != null) {
            atmosphereManager.clear();
        }
        if (rocketManager != null) {
            rocketManager.clear();
        }
        stationManager.clear();
        satelliteManager.clear();
        rollingMachines.clear();
        RollingMachineRuntime.clear();
        precisionAssemblers.clear();
        PrecisionAssemblerRuntime.clear();
        multiblockPatterns.clear();
        StationRuntime.clear();
        SatelliteRuntime.clear();
        planetaryCatalogs.clear();
    }
}
