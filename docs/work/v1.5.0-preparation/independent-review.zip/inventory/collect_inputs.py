"""Read-only, tracked-only source inventory for the v1.5 preparation review."""
import hashlib, json, pathlib, subprocess
ROOT = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")
OUT = pathlib.Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT).decode("utf-8").strip()
tracked = git("ls-files").splitlines()
prefixes = (
    "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/",
    "src/test/java/io/github/sunthemoon/advancedrocketrycommunity/station/",
)
names = [
"AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md",
"docs/01-PORTING-PRINCIPLES.md", "docs/04-VERSION-ROADMAP.md", "docs/05-MASTER-TEST-PLAN.md",
"docs/06-RELEASE-AND-ACCEPTANCE-GATES.md", "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
"docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
"docs/versions/V1.5.0-ORBITAL-STATION-WARP.md",
"docs/decisions/ADR-008-SHARED-SPACE-STATION-REGIONS.md",
"docs/decisions/ADR-014-TRAVEL-TARGET-ROUTES-BODY-CONTEXT.md",
"docs/decisions/ADR-021-PUBLIC-API-VERSION-POLICY.md",
"docs/decisions/ADR-028-READ-ONLY-ENVIRONMENT-QUERIES.md",
"docs/decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md",
"docs/releases/v1.4.0/RELEASE-EVIDENCE.md", "docs/releases/v1.4.0/MIGRATION-REPORT.md",
"docs/releases/v1.4.0/KNOWN-ISSUES.md", "docs/releases/v1.4.0/development-artifacts.json",
"docs/releases/v1.4.0/REQUIREMENT-MAP.md",
]
base = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"
names += [base + x for x in [
"AdvancedRocketryCommunity.java",
"celestial/context/BodyContext.java", "celestial/context/BodyContextResolver.java",
"celestial/model/CelestialBodyDefinition.java", "celestial/model/OrbitDefinition.java",
"celestial/service/CelestialCatalog.java", "celestial/service/CelestialEnvironmentService.java",
"celestial/service/CelestialGravityController.java", "celestial/visual/SkySelection.java",
"compat/environment/ServerEnvironmentQueries.java", "compat/environment/EnvironmentQueryLifecycle.java",
"persistence/migration/AtomicSavedData.java", "persistence/migration/SavedDataSchemaMigrator.java",
"persistence/migration/ManagedSavedDataType.java",
"rocket/server/PlanetaryFlightAdmission.java", "rocket/server/RocketTargetContextService.java",
"rocket/server/RocketFlightService.java", "rocket/server/RocketTransferService.java",
"rocket/server/RocketTransferEntities.java",
"rocket/flight/RocketFlightPlan.java", "rocket/flight/RocketTargetFlightPlanner.java",
"rocket/flight/RocketTransferRecord.java", "rocket/flight/RocketFlightLimits.java",
"rocket/flight/RocketPassengerManifest.java", "rocket/flight/RocketPassengerReconnectQueue.java",
"travel/route/service/RoutePlanner.java", "gametest/StationGameTests.java"]]
names += [x for x in tracked if x.startswith(prefixes)]
names = sorted(set(names))
assert all(x in tracked and "AdvancedRocketry-Community-v1plus-Development-Docs/" not in x for x in names)
def digest(data):
    return hashlib.sha256(data).hexdigest()
items = []
for name in names:
    data = (ROOT / name).read_bytes()
    assert subprocess.check_output(["git", "show", "HEAD:" + name], cwd=ROOT).replace(b"\r\n", b"\n") == data.replace(b"\r\n", b"\n"), name
    target = OUT / "inputs" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    items.append({"path": name, "bytes": len(data), "sha256": digest(data)})
result = {"head": git("rev-parse", "HEAD"), "branch": git("branch", "--show-current"),
    "tracked_status": git("status", "--short", "--untracked-files=no"),
    "input_count": len(items), "inputs": items,
    "boundary": "Tracked-only read inventory; no builds, tests, worlds, excluded bundle or mutable build outputs read."}
(OUT / "input-identities.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k != "inputs"}, indent=2))

