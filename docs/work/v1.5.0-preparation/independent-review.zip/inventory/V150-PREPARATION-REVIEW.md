# v1.5 preparation: independent source and compatibility inventory

## Identity, scope and findings

Read-only preparation on `6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b`, branch
`codex/v1.4.0-planetary-expansion`. No v1.5 implementation or proposed new ADR was
reviewed. The numbered points below are prioritized requirements/risks for the
first contract, not claims that unimplemented warp behavior is defective.

1. **P1 — Existing station flush is not an acknowledged durable transaction barrier.**
   [StationRegistrySavedData.java:203–207](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/persistence/StationRegistrySavedData.java#L203)
   merely invokes ordinary DataStorage.save; this class extends vanilla SavedData
   (line 22), not the checked writer. Creation reserves, generates blocks, commits
   and calls that flush at each step
   ([StationCreationService.java:56–95](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationCreationService.java#L56)).
   [AtomicSavedData.java:22–30](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData.java#L22)
   explicitly supports only the two discovery authorities. Its successful cut
   evidence must not be inherited as station/energy/chunk/passenger atomicity.
   A warp contract needs its own acknowledged authority transition, idempotent
   cost receipt, and documented ordering relative to any core BE/resource save.
   A pure schema bump does not supply this guarantee.

2. **P2 — Freeze what “moving a station” means before schema or warp code.**
   The version simultaneously requires stable region position and describes
   target-station creation/source deletion
   ([version:49–53,181–186](D:/GitHub/AdvancedRocketry-Community/docs/versions/V1.5.0-ORBITAL-STATION-WARP.md#L49)).
   Existing stations are persistent UUIDs owning a fixed horizontal region in
   one shared Space Level, not movable block snapshots:
   [StationState.java:14–25,52–54](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationState.java#L14),
   [StationRegion.java:3–13](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationRegion.java#L3).
   Two defensible options:
   - Keep UUID/cell/blocks/players physically stationary and transactionally change
     orbit context. This avoids copying arbitrary BEs, but needs a real cost,
     countdown, authority commit, target checks and docked/inbound-rocket policy;
     it is not already implemented or automatically sufficient for all version
     requirements. Explicitly disposition the physical-copy wording.
   - Physically move an explicitly bounded station structure and actors. This
     needs a separate ownership/snapshot/BE/passenger transaction; a 512×512
     logical region is not a bounded station structure. Do not infer that all
     region blocks belong to a movable station, or reuse rocket snapshot limits
     as proof for arbitrary station content.

3. **P2 — Orbit mutation must reconcile or lock rocket authorities, including unloaded ones.**
   [PlanetaryFlightAdmission.java:44–54](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/PlanetaryFlightAdmission.java#L44)
   requires the physical station UUID and saved current body to agree (with the
   historical Space alias). Changing only station.orbitBody strands a nonlegacy
   landed rocket's next launch. Prepared plans and transfer records retain old
   body/dimension/target/snapshot/fuel authority
   ([RocketTransferService.java:75–144](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/server/RocketTransferService.java#L75),
   [RocketTransferRecord.java:8–84](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/flight/RocketTransferRecord.java#L8)).
   There is no persisted station docking roster. Deletion checks loaded rockets
   and transfer snapshots, not every unloaded assembled entity
   ([StationManager.java:209–237](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationManager.java#L209)).
   A future “no docked rockets” admission rule cannot prove absence by a loaded
   entity query alone. Define a station revision/frozen authority or other
   bounded reconciliation policy before allowing orbit changes; let preexisting
   active transfers recover under their recorded authority, not silently rewrite
   their checksums. Rocket passengers (max 16) are not a station occupant ledger.

4. **P2 — Quarantined station data currently does not protect Space building.**
   Unsupported/malformed station data is preserved and exposes no operational
   stations ([StationRegistrySavedData.java:37–81,166–175](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/persistence/StationRegistrySavedData.java#L37)).
   However, [StationManager.java:310–321](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationManager.java#L310)
   treats an empty findAt as unowned/allowed. Thus a blocked registry and a valid
   region gap are indistinguishable at that build boundary. This is an existing
   source-supported limitation, not a newly reproduced exploit. A first schema
   migration must explicitly decide fail-closed build behavior on unavailable
   authority; preserving raw NBT alone is not preservation of all permissions.

5. **P2 — Effective orbit environment is missing; metadata cannot substitute for it.**
   The public environment query already resolves indexed station context and
   returns persisted gravity/vacuum
   ([ServerEnvironmentQueries.java:55–82](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/compat/environment/ServerEnvironmentQueries.java#L55)).
   Actual player gravity remains Level-based
   ([CelestialGravityController.java:22–40](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialGravityController.java#L22));
   surface hazards explicitly disable Space
   ([CelestialEnvironmentService.java:18–37](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialEnvironmentService.java#L18));
   sky selection keys only Level/catalog/resource identities
   ([SkySelection.java:14–38](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/visual/SkySelection.java#L14)).
   Station gravity permits 0..10, whereas the existing gravity controller accepts
   at most 4. An effective orbit provider needs deliberate defaults/bounds,
   positional refresh and client snapshot invalidation; directly reusing the
   controller can throw for currently valid station records. Existing persisted
   solar angle is not solar generation. No solar-power or warp implementation
   was found in the inspected tracked Java inventory.

## Existing usable mechanisms and compatibility constraints

- **Identity/regions:** record schema 1; managed registry root schema 2; stable
  station UUID, owner, members/invitations, orbitBody, creation time, environment,
  cell-derived region/pad. Fixed budgets are 4,096 stations, 64 reservations,
  32 members, 32 invitations, one normal-play owned station, 32 visible
  destinations, 8 KiB/record and 4 MiB/root
  ([StationLimits.java:5–22](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationLimits.java#L5)).
  Geometry is 512 blocks wide at 1,024 spacing. The indexed nearest-cell lookup
  depends on this relationship; expanding across cell envelopes invalidates
  the existing constant-time lookup proof
  ([StationRegistryModel.java:107–122](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationRegistryModel.java#L107)).
  Fixed-center bounded expansion within exclusive envelopes is smaller than
  arbitrary overlapping rectangles, but needs an explicit new size/index policy.
- **Creation/access:** arbitrary known orbitable IDs are already accepted;
  player deployment derives a real surface body and normally enforces one owned
  station ([StationManager.java:44–78](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationManager.java#L44)).
  Owners/operators manage; members visit/build; invitations have no permission
  until accepted. No team role or warp action exists
  ([StationAccessService.java:12–39](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/service/StationAccessService.java#L12)).
  Player place/break hooks are not general automation/explosion/fluid protection.
- **World content:** generation writes 289 platform blocks in at most four chunks.
  Deletion removes only matching template blocks; arbitrary player construction
  remains. Registry deletion releases the cell
  ([StationPlatformGenerator.java:64–84](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/forge/StationPlatformGenerator.java#L64),
  [StationRegistryModel.java:71–76](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/model/StationRegistryModel.java#L71)).
  Expansion/deletion/reuse must not claim whole-region emptiness or ownership
  reconstruction from this template operation.
- **Travel:** station UUID targets resolve to orbit(body) plus shared Space.
  Arrival needs orbitable/discovered body plus live station/access checks;
  generic Orbit remains nonlaunchable at production admission. Same-orbit
  stations share a route anchor, and RoutePlanner rejects equal anchors
  ([RoutePlanner.java:41–43](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/travel/route/service/RoutePlanner.java#L41)).
  More stations do not automatically provide local station-to-station travel.
  Station planner gravity is hard-coded zero, so applying a new station gravity
  profile must explicitly decide whether fuel remains compatible
  ([RocketTargetFlightPlanner.java:136–145](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/rocket/flight/RocketTargetFlightPlanner.java#L136)).
- **Multi-star:** body parent trees and bounded routes exist; OrbitDefinition is
  metadata, not simulation. Earth is a required root, Moon/Space retain required
  Earth parentage. A root is not already an explicit star-system identity.
  Introduce star-system semantics without reparenting existing IDs or changing
  accepted body/Level reservations merely to fit a new tree.
- **Public compatibility:** current API 1.7 is separate from saves/channels.
  Station classes are internal. ADR-028 promises configured station profile
  values and no chunk reads; do not replace that API with effective oxygen,
  biome or live machinery queries. Additive exported capabilities require a
  minor change; incompatible semantics/signatures require ADR-021 treatment.
  Preserve old station IDs, accepted members/invitations, orbit and geometry;
  separately version any new record shape, migrate deterministically and retain
  unsupported roots. New missing-target behavior must preserve recoverable state.

## Plausible first vertical slices (recommendations, not approvals)

1. **Station authority/migration slice first:** freeze stable UUID/cell/region
   semantics, exact persisted additions actually needed, legacy defaults,
   quarantine/protection and checked save acknowledgment. Expose bounded
   inspect/diagnostic output through existing operator entry points; verify
   actual v1.4 station copy -> new save -> second restart with exact membership,
   orbit, geometry and neighboring blocks. Do not add a speculative warp framework
   or expand limits to make an example pass.
2. **Orbit environment slice next:** one indexed server view with explicit stored
   station versus live body responsibilities, actual player gravity and bounded
   client orbit presentation/solar semantics. Keep breathing/suit machinery
   separate unless this slice deliberately changes its contract. Test two regions
   in the same Level plus gap, removal/restoration, re-entry/reconnect and reload.
3. **Warp only after movement decision:** choose the authority unit, resource
   source and finite budgets; specify countdown cancellation, unavailable target,
   membership changes, save failures, two concurrent stations, unloaded/online/
   offline occupants and inbound/docked rockets. A stable-cell orbit rebind may
   be the smallest practical design, but it needs explicit requirement mapping,
   not retrospective relabeling of metadata as asset transfer.
4. Keep full space-elevator logistics out; the minimum endpoint contract should
   identify a station UUID and valid revision/context, not hand clients arbitrary
   coordinates or establish a premature general transfer API.

## Needed checks and remaining decisions

No tests were run in this exploration. Existing source tests cover station
round-trip/future/malformed data, unknown orbit preservation, unique allocation/
concurrency/indexing, invitation/member policy and three station GameTests.
They do not establish warp outcomes.

After a contract and execution slot exist: targeted station model/persistence/
access, BodyContext, ServerEnvironmentQueries, rocket target/planner/recovery
tests; new exact-bound/quarantine/migration fixtures; required offline
clean build/test/runData/GameTest commands; finite copied v1.4 packaged restart;
phase-specific persistence failures before resource/actor mutation. Full V1/V2,
reference-node load and all-original-content acceptance remain deferred under
the existing scheduling policy, never marked passed.

Before implementation, a new version-limited development-order decision is
needed: v1.5 prerequisite remains unmet
([version:19–25](D:/GitHub/AdvancedRocketry-Community/docs/versions/V1.5.0-ORBITAL-STATION-WARP.md#L19));
ADR-030 authorizes v1.4 only
([ADR-030:47–60](D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-030-V140-DEVELOPMENT-BASELINE-EXCEPTION.md#L47)).
The v1.4 handoff explicitly leaves Gates/candidate approval open. Selecting a
branch or this report cannot change that authority.

## Actual checks, evidence and limits

- Read mandatory governance/version/handoff/ADR documents and relevant tracked
  station, context, environment, flight, migration and test sources with
  PowerShell Get-Content, rg and git ls-files.
- Read-only git identity/status checks: baseline as above; tracked status empty;
  git diff --exit-code and git diff --cached --exit-code returned 0.
- Python: `PYTHONUTF8=1 D:/python/pyenv/pyenv-win/shims/python.bat -B collect_inputs.py`
  returned 0; retained 76 tracked input byte snapshots/digests; every input
  matched HEAD after CRLF normalization. Raw collection output:
  `collect-inputs.log`; full inventory: `input-identities.json`.
- Initial exploratory searches referenced absent guessed directories
  celestial/forge, celestial/validation and environment, and a wrong guessed
  ADR filename; corrected through tracked inventory. These are inspection-path
  mistakes, not product failures. No missing-path content was inferred.
- No repository/source/index/build/world writes; no excluded-bundle reads,
  Gradle/JVM/client/network/server commands, artifact rebuild, runtime or
  performance claims. Existing v1.4 evidence is documentation context, not
  independently rerun during this preparation.
- Completed scope: source capability/compatibility inventory and bounded options.
  Unfinished: actual new baseline/contract diff review, implementation, tests,
  native migration/warp, V1/V2 and all Required Gates. No Gate/release approval.

All reviewer-created files are under this report's Temp directory. `SHA256SUMS`
covers immutable report/helper/input receipts; it does not certify future drafts.

