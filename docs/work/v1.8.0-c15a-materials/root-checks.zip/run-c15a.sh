#!/usr/bin/env bash
# C15a review round 1 re-run: Gradle full run, test rerun, collection. Sequential, alone on the host.
C=/tmp/arce-v180-c15a-r1-f2dbed82f04d4394806bf00bf7141dee
cd /d/GitHub/AdvancedRocketry-Community || exit 1
export JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"
git rev-parse HEAD > $C/run-commit.txt
git status --porcelain > $C/pre-run-status.txt
./gradlew --offline clean build test runData runGameTestServer > $C/root-gradle-01.log 2>&1
echo $? > $C/root-gradle-01.exit
git status --porcelain -- src/generated > $C/generated-status.txt
git diff --stat > $C/post-gradle-diff.txt
./gradlew --offline test --rerun > $C/root-gradle-02.log 2>&1
echo $? > $C/root-gradle-02.exit
if [ "$(cat $C/root-gradle-01.exit)" != "0" ] || [ "$(cat $C/root-gradle-02.exit)" != "0" ]; then echo GRADLE_FAILED > $C/run.status; exit 1; fi
python $C/scripts/collect_run.py > $C/collect.log 2>&1 || { echo COLLECT_FAILED > $C/run.status; exit 1; }
echo DONE > $C/run.status
