"""Archive the independent reviewer's own outputs (allow-list) into independent-review.zip plus a member index.

Excluded on purpose: tree/ and tree2/ (copies of this repository), gen-ref/ (its generated output), mc/ and javap-*.txt
(Minecraft/Forge bytecode disassembly) and
upstream/*.java (upstream source bytes). Only the reviewer's report, logs, scripts and hash lists are kept.
Usage: make_review_zip.py <out dir>
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

REVIEW = Path(r"C:/Users/ADMINI~1/AppData/Local/Temp/arce-v180-c15a-review-251d3b5dc61fbe69")
ALLOWED_SUFFIXES = {".md", ".log", ".py", ".txt", ".json", ".csv"}
EXCLUDED_DIRS = {"tree", "tree2", "gen-ref", "mc", "upstream", "__pycache__", "t", "u", "javap", "evidence"}


def members():
    for path in sorted(REVIEW.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(REVIEW)
        parts = relative.parts
        if (parts[0] in EXCLUDED_DIRS or parts[0].startswith(("tree", "gen-ref")))                 and relative.as_posix() != "upstream/hashes.txt":
            continue
        if any(part in EXCLUDED_DIRS for part in parts[1:]) or path.suffix not in ALLOWED_SUFFIXES:
            continue
        if path.name.startswith("javap-") or "javap" in path.name:
            continue  # Disassembled Minecraft/Forge classes: not ours to distribute.
        yield relative.as_posix(), path


def main(out):
    out = Path(out)
    rows = []
    with zipfile.ZipFile(out / "independent-review.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, path in members():
            data = path.read_bytes()
            bundle.writestr(zipfile.ZipInfo(name, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    (out / "independent-review-files.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n",
                                                        encoding="utf-8", newline="\n")
    raw = (out / "independent-review.zip").read_bytes()
    print("independent-review.zip", len(rows), "members", len(raw), "bytes", hashlib.sha256(raw).hexdigest())
    for row in rows:
        print("  ", row["path"], row["bytes"], flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
