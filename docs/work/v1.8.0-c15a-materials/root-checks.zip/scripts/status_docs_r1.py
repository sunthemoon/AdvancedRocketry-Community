"""Record C15a implementation review round 1 in the status documents (documentation only)."""
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')


def edit(relative, old, new):
    path = ROOT / relative
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (relative, old[:80])
    path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')


LOG = 'docs/work/v1.8.0-implementation-log.md'
edit(LOG, '| C15 | C15a | Materials and ores, tags, plate press | delivered; implementation review pending |',
     '| C15 | C15a | Materials and ores, tags, plate press | delivered; review round 1 answered; owner decision on ADR-063 rev 4 / ADR-061 rev 7 open |')
edit(LOG, """- `V180MaterialArt` has 510 lines: 19 texture grids and the PNG encoder, one
  responsibility (the drawn art); it stays one class.
""", """- `V180MaterialArt` has 510 lines: 19 texture grids and the PNG encoder, one
  responsibility (the drawn art); it stays one class.
- Implementation review round 1 (`f95e851`): 0 Critical, 1 High, 3 Medium,
  3 Low, 7 Info; C15a accept with required changes, ADR-063 revision 4 accept
  with changes. Every finding is answered in its own commit
  ([dispositions](v1.8.0-c15a-materials/review-01-dispositions.md)): rutile no
  longer presses (H1), dilithium ore gives no mining XP (M1), kernel machine
  recipes refuse tag ingredients until C16a and ADR-061 revision 7 states it
  (M2), the press serializer, the ambiguity refusal, the ore tags and the
  Overworld numbers gained tests (M3, L1, L2), and the iron-plate paragraph
  states its condition, cost and the alternative. The sources JAR's
  difference was an empty untracked MDK directory in the working copy (I3).
  The packet was re-run on the fixed tree.
- Open C15 items: a client start with JEI installed and the JEI category on a
  real client (L3); the ADR-061 §4.5 human visual review of `coil_side`,
  `coil_top`, `storage` and the three press faces (I4).
- Known flakes outside C15a (I2): `debtandcreditsettleontheengine`
  (`LaserPhysicalGameTests`, v1.7) and
  `theskycontextisserverderivedsentonchangeandfollowseverychange`
  (`StationSkyContextGameTests`, v1.5) failed once in a review mutation run and
  passed in every clean run.
- Owner decisions open: ADR-063 revision 4 and ADR-061 revision 7, including the
  iron-plate route (the press, or re-keying `rolling_iron_bars`).
""")

PLAN = 'docs/status/COMPLETION-PLAN.md'
edit(PLAN, """  - C15：C15a 材料、矿石与小型压板机 `[x]`（开发完成，待独立实现审核与 ADR-063 第 4 版的接受；
    证据 `docs/work/v1.8.0-c15a-materials/`）；""", """  - C15：C15a 材料、矿石与小型压板机 `[x]`（开发完成；独立实现审核第 1 轮的发现已逐项修复并重跑证据；
    待维护者决定是否接受 ADR-063 第 4 版与 ADR-061 第 7 版；证据 `docs/work/v1.8.0-c15a-materials/`）；""")
edit(PLAN, """**C15a 收尾**：独立实现审核与修复；维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机、轧制配方
用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）。随后""", """**C15a 收尾**：维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机或改键 `rolling_iron_bars`、
金红石不压制、轧制配方用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）与 ADR-061 第 7 版
（内核机器配方在 C16a 前只用物品原料）。随后""")
print('status documents updated for round 1')
