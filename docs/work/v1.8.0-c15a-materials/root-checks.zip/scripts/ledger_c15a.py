"""Mark the C15a ledger rows delivered (ADR-062 section 1): 15 IMPLEMENTED, 2 REDESIGNED, with the C15a evidence."""
import csv
import io
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEDGER = ROOT / 'docs/work/v1.8.0-content-ledger.csv'
EVIDENCE = 'docs/work/v1.8.0-c15a-materials/VERIFICATION.md'
NS = 'advancedrocketrycommunity:'

DELIVERED = {
    'block:platepress': ('IMPLEMENTED', NS + 'small_plate_press'),
    'config_file:SmallPlatePress.xml': ('REDESIGNED', 'small_plate_press recipe type (data pack recipes)'),
    'integration:jei/platePresser': ('IMPLEMENTED', 'JEI small plate press category'),
    'material:Aluminum': ('IMPLEMENTED', NS + 'aluminum_ingot and the aluminum set'),
    'material:Copper': ('IMPLEMENTED', NS + 'copper_plate and the copper products'),
    'material:Dilithium': ('IMPLEMENTED', NS + 'dilithium_crystal and the dilithium set'),
    'material:Gold': ('IMPLEMENTED', NS + 'gold_plate and the gold products'),
    'material:Iridium': ('IMPLEMENTED', NS + 'iridium_ingot and the iridium set'),
    'material:Iron': ('IMPLEMENTED', NS + 'iron_plate and the iron products'),
    'material:Rutile': ('IMPLEMENTED', NS + 'rutile_ore'),
    'material:Silicon': ('IMPLEMENTED', NS + 'silicon_ingot and the silicon set'),
    'material:Steel': ('IMPLEMENTED', NS + 'steel_ingot and the steel set'),
    'material:Tin': ('IMPLEMENTED', NS + 'tin_ingot and the tin set'),
    'material:Titanium': ('IMPLEMENTED', NS + 'titanium_ingot and the titanium set'),
    'material:TitaniumAluminide': ('IMPLEMENTED', NS + 'titanium_aluminide_ingot and its set'),
    'material:TitaniumIridium': ('IMPLEMENTED', NS + 'titanium_iridium_ingot and its set'),
    'worldgen:OreGenerator': ('REDESIGNED', 'Overworld ore placed features and the overworld_ores biome modifier'),
}

raw = LEDGER.read_text(encoding='utf-8')
rows = list(csv.reader(io.StringIO(raw)))
seen = set()
for row in rows[1:]:
    if row[0] in DELIVERED:
        assert row[1] == 'PLANNED' and row[2] == 'C15a', row
        disposition, target = DELIVERED[row[0]]
        row[1], row[2], row[3], row[4], row[6] = disposition, 'v1.8.0', target, 'ADR-063', EVIDENCE
        seen.add(row[0])
assert seen == set(DELIVERED), set(DELIVERED) - seen
left = [row[0] for row in rows[1:] if row[2] == 'C15a']
assert not left, left
out = io.StringIO()
csv.writer(out, lineterminator='\n').writerows(rows)
LEDGER.write_text(out.getvalue(), encoding='utf-8', newline='')
print('delivered', len(seen))
