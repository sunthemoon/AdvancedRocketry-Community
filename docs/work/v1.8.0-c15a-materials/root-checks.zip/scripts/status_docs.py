"""Record the C15a delivery in the status documents (documentation only)."""
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')


def edit(relative, old, new):
    path = ROOT / relative
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (relative, old[:80])
    path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')


LOG = 'docs/work/v1.8.0-implementation-log.md'
edit(LOG, '| C15 | C15a | Materials and ores, tags, plate press | not started |',
     '| C15 | C15a | Materials and ores, tags, plate press | delivered; implementation review pending |')
edit(LOG, """- The two language files already used in v0.1.0 are handled as `IMPORTED`;
  later batches extract their own keys under their own records.
""", """- The two language files already used in v0.1.0 are handled as `IMPORTED`;
  later batches extract their own keys under their own records.

## C15a — materials, ores and the small plate press

Planned outputs (ADR-063 §1–§4 and §8):

- The material table of §1 (twelve materials, 86 registered entries), its tags,
  client tints and a creative tab; new art drawn as palette grids.
- Smelting, crafting, rolling and press recipes (§2); the small plate press with
  the piston exception (§3); the Overworld ores behind a server switch and a
  Forge biome modifier (§4); the v1.8 DataGen root and the superseded tool tags
  (§8); runtime `1.20.1-1.8.0-dev`.
- A0/A1 tests of §9 for C15a, the evidence packet, an independent
  implementation review.

Explicit C15a non-goals: the Moon, Mars and Venus surfaces and their ores
(C15b); exoplanet worlds (C15c); machines that make alloys, boules and crystals
(C16); world migration; imported assets; candidate, tag or Gate changes.

Progress:

- Implementation (`cb52c0b`, with `baa20f9` for two tests a mutation review
  found missing). Four points the accepted text did not settle became ADR-063
  revision 4, **proposed** (`f2006e8`): the v1.2 recipe `rolling_iron_bars`
  already takes iron ingots and the rolling machine refuses ambiguous inputs, so
  iron plates come from the press; rolling recipes name items because the
  kernel resolves ingredients before tags are bound; press tags resolve when it
  acts and an ambiguous match does nothing; the switch names.
- The thirteen `config:WORLDGEN.*` rows and `worldgen:CustomizableOreGen` moved
  to C15b (`d666aff`), which closes their Moon and Mars half.
- First GameTest run: two failures, both fixed before commit. Its log was
  overwritten by the rerun; the failure lines were
  `typedcapabilitiesrequireformationandretainresourcesacrossrebuild failed!
  Energy was lost on disassembly` (the v1.2 rolling capability fixture used gold
  ingots, which C15a now rolls; `920308e` stores diamonds, assertions unchanged)
  and `onlyarisingedgepresses failed! Expected 8 steel_plate, found 4` (the
  test placed a block on the first plates and pushed them away).
- Two art screens before commit changed the palette and the press top and
  bottom; the final screen is 19 `CLEAR` against both clients.
- Evidence run on `baa20f9`: 351 GameTests, 1,393 JUnit tests, clean DataGen
  diff ([C15a evidence](v1.8.0-c15a-materials/VERIFICATION.md)). After the run,
  four ledger-validator unit tests failed because their fixture tree lacked the
  batch evidence folders; `d8f80ed` fixed the fixture and the rerun passes.
- 17 ledger rows delivered: 15 IMPLEMENTED, 2 REDESIGNED.
- `V180MaterialArt` has 510 lines: 19 texture grids and the PNG encoder, one
  responsibility (the drawn art); it stays one class.
""")

PLAN = 'docs/status/COMPLETION-PLAN.md'
edit(PLAN, """  - C15：C15a 材料、矿石与小型压板机；C15b 月球、火星、金星地表与地物；C15c 经典系外行星世界
    （ADR-063 已接受）；""", """  - C15：C15a 材料、矿石与小型压板机 `[x]`（开发完成，待独立实现审核与 ADR-063 第 4 版的接受；
    证据 `docs/work/v1.8.0-c15a-materials/`）；C15b 月球、火星、金星地表与地物；C15c 经典系外行星世界
    （ADR-063 已接受）；""")
edit(PLAN, """**C15a 材料、矿石与小型压板机**（同一会话继续；在 `codex/v1.8.0-classic-content` 上按已接受的
ADR-061/062/063 实现：钛、铝、锡、钢、铱、二锂、硅与两种合金的产品、矿石与 Overworld 生成、
冶炼与轧制配方、通用标签、小型压板机及其 JEI 类别）。""", """**C15a 收尾**：独立实现审核与修复；维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机、轧制配方
用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）。随后 **C15b 月球、火星、金星地表与地物**
（同一会话继续；ADR-063 §5，含月球与火星矿石及从 C15a 移来的 `config:WORLDGEN.*` 行）。""")

CURRENT = 'docs/status/CURRENT_VERSION.md'
edit(CURRENT, 'runtime_build: 1.20.1-1.7.0-dev\n```\n\nv1.8 preparation (C14) is complete.',
     'runtime_build: 1.20.1-1.8.0-dev\n```\n\nv1.8 preparation (C14) is complete.')
edit(CURRENT, """hovercraft past v2.0. The runtime identity stays `1.20.1-1.7.0-dev` until C15 changes the
runtime. The next chunk is C15 in [COMPLETION-PLAN](COMPLETION-PLAN.md). No Gate is
claimed.""", """hovercraft past v2.0. C15a (the material set, ores and the small plate press) is delivered
and changes the runtime identity to `1.20.1-1.8.0-dev`
([C15a evidence](../work/v1.8.0-c15a-materials/VERIFICATION.md)); its independent review
and the owner's decision on ADR-063 revision 4 are pending. The next chunk is in
[COMPLETION-PLAN](COMPLETION-PLAN.md). No Gate is claimed.""")

MATRIX = 'docs/PORTING_MATRIX.md'
edit(MATRIX, "钛/铝/钢/锡/硅/铱/二锂/钛铝/钛铱材料组、Forge 通用标签、矿石与小型压板机（ADR-061 §2） | `v1.8.0` | C15a 批次 ADR + A0/A1 | PLANNED |",
     "钛/铝/钢/锡/硅/铱/二锂/钛铝/钛铱材料组、Forge 通用标签、矿石与小型压板机（ADR-061 §2）；C15a 已交付 Overworld 部分，月球与火星矿石在 C15b | `v1.8.0` | C15a 批次 ADR + A0/A1 | IN_PROGRESS |")

edit('docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md', 'status: IN_PROGRESS\nphase: CONTRACT_FROZEN\n',
     'status: IN_PROGRESS\nphase: IMPLEMENTING\n')
print('status documents updated')
