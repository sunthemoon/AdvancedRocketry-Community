"""Screen palette grids declared in a Java art class against the vanilla clients, without running DataGen.

Usage: probe_java_art.py <Java file> NAME=TINT [NAME=TINT ...]
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, 'D:/GitHub/AdvancedRocketry-Community/tools/audit')
import vanilla_derivation as d  # noqa: E402

GREYS = [20, 44, 72, 93, 117, 141, 169, 191, 210, 238]
EV = Path('C:/Users/ADMINI~1/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251/vanilla')


def grids(source):
    found = {}
    for match in re.finditer(r'static final String\[\] (\w+) = \{(.*?)\};', source, re.S):
        found[match.group(1)] = re.findall(r'"([^"]*)"', match.group(2))
    return found


def image(grid, tint):
    pixels = bytearray()
    for row in grid:
        assert len(row) == 16, row
        for c in row:
            if c == '.':
                pixels += b'\0\0\0\0'
            else:
                g = GREYS[int(c)]
                pixels += bytes([g * ((tint >> 16) & 255) // 255, g * ((tint >> 8) & 255) // 255,
                                 g * (tint & 255) // 255, 255])
    assert len(grid) == 16
    return d.Image(16, 16, bytes(pixels))


def main():
    source = Path(sys.argv[1]).read_text(encoding='utf-8')
    declared = grids(source)
    wanted = dict(arg.split('=') for arg in sys.argv[2:])
    candidates = [(name, image(declared[name], int(tint, 16))) for name, tint in wanted.items()]
    _, _, vanilla = d.load_vanilla([f'1.12.2={EV}/client-1.12.2.jar', f'1.20.1={EV}/client-1.20.1.jar'])
    best = d.analyse_images(candidates, vanilla)
    for name, _ in candidates:
        _, level, record = best.get(name, (None, 'CLEAR', {}))
        print(name, level, record.get('reference'),
              {k: record.get(k) for k in ('method', 'iou', 'rank', 'overlap', 'colours', 'exact', 'near', 'mapped')})


main()
