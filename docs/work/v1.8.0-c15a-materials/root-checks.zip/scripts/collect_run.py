"""Collect the C15a evidence run: JUnit XML and summary, GameTest logs and counts, hashes of every
non-documentation file changed since the C14 acceptance commit, and artifact hashes."""
import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
sha = lambda b: hashlib.sha256(b).hexdigest()

base = (E / 'base-commit.txt').read_text().strip()
junit = E / 'full-junit'
junit.mkdir()
tests = failures = errors = skipped = suites = 0
for f in sorted((ROOT / 'build/test-results/test').glob('*.xml')):
    shutil.copyfile(f, junit / f.name)
    r = ET.parse(f).getroot()
    suites += 1
    tests += int(r.get('tests')); failures += int(r.get('failures')); errors += int(r.get('errors'))
    skipped += int(r.get('skipped'))
summary = {'suites': suites, 'tests': tests, 'failures': failures, 'errors': errors, 'skipped': skipped}
(E / 'junit-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')

changed = subprocess.check_output(['git', 'diff', '--name-only', base, 'HEAD'], cwd=ROOT).decode().splitlines()
files = {}
for path in changed:
    if path.startswith('docs/') or path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/'):
        continue
    if (ROOT / path).is_file():
        files[path] = sha((ROOT / path).read_bytes())
(E / 'implementation-files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8',
                                            newline='\n')
(E / 'post-run-changes.json').write_text('{"files": []}\n', encoding='utf-8', newline='\n')

artifacts = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append({'name': jar.name, 'bytes': jar.stat().st_size, 'sha256': sha(jar.read_bytes())})
(E / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}, indent=2) + '\n', encoding='utf-8',
                                  newline='\n')

# C15aR1-I3: each JAR's entries (name, size, CRC-32), so a later rebuild can be compared entry by entry.
import zipfile
entries = {}
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    with zipfile.ZipFile(jar) as archive:
        entries[jar.name] = [{'name': i.filename, 'size': i.file_size, 'crc32': '%08x' % i.CRC}
                             for i in archive.infolist()]
(E / 'artifact-entries.json').write_text(json.dumps(entries, indent=1, sort_keys=True) + '\n', encoding='utf-8',
                                         newline='\n')

for name in ('latest.log', 'debug.log'):
    log = ROOT / 'build/gametest/logs' / name
    if log.exists():
        shutil.copyfile(log, E / ('gametest-' + name))
latest = (E / 'gametest-latest.log').read_text(encoding='utf-8', errors='replace')
passed = re.findall(r'All (\d+) required tests passed', latest)
(E / 'gametest-summary.json').write_text(json.dumps({'required_passed': int(passed[-1]) if passed else None,
                                                     'failed_lines': re.findall(r'.* failed!.*', latest)},
                                                    indent=2) + '\n', encoding='utf-8', newline='\n')
print(summary, len(files), 'non-documentation files changed since the base', [a['name'] for a in artifacts])
print('GameTests passed:', passed[-1] if passed else 'NONE')
