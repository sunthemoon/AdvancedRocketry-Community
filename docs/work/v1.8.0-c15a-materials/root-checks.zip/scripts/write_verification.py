"""Write docs/work/v1.8.0-c15a-materials/VERIFICATION.md from the run's facts (Python results from python/*.exit)."""
import json
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
lang = json.loads((ROOT / 'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/en_us.json')
                  .read_text(encoding='utf-8'))
ids = sorted(k.split('.', 2)[2] for k in lang
             if k.startswith(('block.advancedrocketrycommunity.', 'item.advancedrocketrycommunity.')))
registered = ', '.join('`advancedrocketrycommunity:%s`' % i for i in ids)

PYTHON = [
    ('py-01-ledger', '`python -B scripts/validate_v180_content_ledger.py`'),
    ('py-02-ledger-accepted', '`… --require-accepted`'),
    ('py-03-ledger-closure', '`… --closure` (expected to fail until C19)'),
    ('py-04-inventory', '`python -B tools/audit/inventory_v180_content.py --upstream <Temp> --check`'),
    ('py-05-derivation', '`python -B tools/audit/vanilla_derivation.py --upstream <Temp> --vanilla … --check`'),
    ('py-06-art-screen', '`python -B tools/audit/screen_generated_art.py --root src/generated/v1.8/resources '
                         '--vanilla 1.12.2=… --vanilla 1.20.1=…`'),
    ('py-07-unittest', '`python -B -m unittest tests.test_validate_v180_content_ledger '
                       'tests.test_vanilla_derivation tests.test_screen_generated_art`'),
    ('py-08-machine-resources', '`python -B scripts/validate_v120_machine_resources.py`'),
    ('py-09-beta-resources', '`python -B scripts/validate_v090_resources.py`'),
    ('py-10-client-imports', '`python -B scripts/check_client_imports.py`'),
]


def python_rows():
    rows = []
    for name, command in PYTHON:
        exit_file = E / 'python' / (name + '.exit')
        log_file = E / 'python' / (name + '.log')
        if not exit_file.exists():
            rows.append('| %s | not run |' % command)
            continue
        code = exit_file.read_text().strip()
        lines = [line.strip() for line in log_file.read_text(encoding='utf-8', errors='replace').splitlines()
                 if line.strip()]
        last = lines[-1] if lines else ''
        if name.startswith('py-0') and 'ledger' in name:
            result = next((line for line in lines if '"result"' in line), last)
            last = result.strip(',')
        if name.startswith('py-07'):
            verdict = next((line for line in reversed(lines) if line.startswith(('OK', 'FAILED'))), '')
            last = next((line for line in reversed(lines) if line.startswith('Ran ')), '') + '; ' + verdict
        rows.append('| %s | Exit %s; `%s` |' % (command, code, last.replace('|', '/')[:160]))
    return '\n'.join(rows)


import re


def facts():
    log1 = (E / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace')
    log2 = (E / 'root-gradle-02.log').read_text(encoding='utf-8', errors='replace')
    junit = json.loads((E / 'junit-summary.json').read_text())
    games = json.loads((E / 'gametest-summary.json').read_text())
    jars = {a['name']: a['sha256'][:8] for a in json.loads((E / 'artifacts.json').read_text())['artifacts']}
    pick = lambda suffix: next(v for k, v in jars.items() if k.endswith(suffix))
    return {
        '{RUN}': (E / 'run-commit.txt').read_text().strip()[:7],
        '{HEAD}': (E / 'post-run' / 'head.txt').read_text().strip()[:7],
        '{T1}': re.findall(r'BUILD SUCCESSFUL in (.*)', log1)[-1].strip(),
        '{T2}': re.findall(r'BUILD SUCCESSFUL in (.*)', log2)[-1].strip(),
        '{GT}': str(games['required_passed']),
        '{JUNIT}': '{:,}'.format(junit['tests']),
        '{SUITES}': str(junit['suites']),
        '{MAIN}': pick('-dev.jar'), '{API}': pick('-api.jar'), '{SRC}': pick('-sources.jar'),
        '{ERRORS}': str(log1.count('ERROR]')),
    }


TEMPLATE = (E / 'scripts' / 'verification-template.md').read_text(encoding='utf-8')
for key, value in facts().items():
    TEMPLATE = TEMPLATE.replace(key, value)
text = TEMPLATE.replace('{COUNT}', str(len(ids))).replace('{REGISTERED}', registered) \
    .replace('{PY_RESULTS}', python_rows())
final = E / 'packaging' / 'out' / 'validation-final.summary'
text = text.replace('{FINAL}', final.read_text(encoding='utf-8').strip() if final.exists()
                    else 'They need the finished packet and run after packaging.')
(ROOT / 'docs/work/v1.8.0-c15a-materials').mkdir(parents=True, exist_ok=True)
(ROOT / 'docs/work/v1.8.0-c15a-materials/VERIFICATION.md').write_text(text, encoding='utf-8', newline='\n')
print('written', len(ids), 'ids')
