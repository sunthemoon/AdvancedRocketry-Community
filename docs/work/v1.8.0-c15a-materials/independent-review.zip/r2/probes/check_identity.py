"""Compare source-identity.json with an exported tree; list changed-since-base files it does not name."""
import hashlib
import json
import os
import subprocess
import sys

tree, repo, commit = sys.argv[1], sys.argv[2], sys.argv[3]
identity = json.load(open(os.path.join(tree, 'docs/work/v1.8.0-c15a-materials/source-identity.json'), encoding='utf-8'))
files = identity['files']
print('entries', len(files), 'base', identity['base_commit'])
mismatch, missing, working = [], [], []
for entry in files:
    local = os.path.join(tree, entry['path'])
    if not os.path.isfile(local):
        missing.append(entry['path'])
        continue
    digest = hashlib.sha256(open(local, 'rb').read()).hexdigest()
    if digest != entry['sha256']:
        mismatch.append(entry['path'])
    if entry.get('working_sha256') and entry['working_sha256'] != entry['sha256']:
        working.append(entry['path'])
print('missing', len(missing), 'sha256 differs from tree', len(mismatch), 'working != committed', len(working))
for item in missing + mismatch + working:
    print('  ', item)
changed = subprocess.run(['git', '-C', repo, 'diff', '--name-only', identity['base_commit'], commit],
                         capture_output=True, text=True, check=True).stdout.split()
listed = {entry['path'] for entry in files}
unlisted = [p for p in changed if p not in listed]
print('changed since base but not listed:', len(unlisted))
for p in unlisted:
    print('  UNLISTED', p)
