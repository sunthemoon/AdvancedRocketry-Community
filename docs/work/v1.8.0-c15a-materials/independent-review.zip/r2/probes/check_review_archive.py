"""Compare the packet's independent-review-files.json and zip with the reviewer's own round-1 files."""
import hashlib
import json
import os
import sys
import zipfile

workdir, packet = sys.argv[1], sys.argv[2]
listing = json.load(open(os.path.join(packet, 'independent-review-files.json'), encoding='utf-8'))
entries = listing if isinstance(listing, list) else listing.get('files', [])
ok = differ = missing = 0
for entry in entries:
    local = os.path.join(workdir, entry['path'])
    if not os.path.isfile(local):
        missing += 1
        print('NOT IN WORKDIR', entry['path'])
        continue
    digest = hashlib.sha256(open(local, 'rb').read()).hexdigest()
    if digest == entry['sha256']:
        ok += 1
    else:
        differ += 1
        print('DIFFERS', entry['path'])
print('listed', len(entries), 'match', ok, 'differ', differ, 'not in workdir', missing)
with zipfile.ZipFile(os.path.join(packet, 'independent-review.zip')) as archive:
    names = archive.namelist()
    bad = 0
    for entry in entries:
        name = next((n for n in names if n.endswith(entry['path'])), None)
        if name is None or hashlib.sha256(archive.read(name)).hexdigest() != entry['sha256']:
            bad += 1
            print('ZIP MISMATCH', entry['path'], name)
    print('zip members', len(names), 'listed entries verified in zip', len(entries) - bad)
