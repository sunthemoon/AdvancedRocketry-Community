"""Compare built JAR entry lists (order, names, sizes, CRC-32) with the packet's artifact-entries.json."""
import json
import os
import sys
import zipfile

libs, entries_json = sys.argv[1], sys.argv[2]
recorded = json.load(open(entries_json, encoding='utf-8'))
for name, rec in recorded.items():
    with zipfile.ZipFile(os.path.join(libs, name)) as archive:
        mine = [{'crc32': format(info.CRC, '08x'), 'name': info.filename, 'size': info.file_size}
                for info in archive.infolist()]
    same_order = [e['name'] for e in rec] == [e['name'] for e in mine]
    rec_map = {e['name']: e for e in rec}
    mine_map = {e['name']: e for e in mine}
    missing = sorted(set(rec_map) - set(mine_map))
    extra = sorted(set(mine_map) - set(rec_map))
    differ = sorted(k for k in set(rec_map) & set(mine_map)
                    if (rec_map[k]['crc32'], rec_map[k]['size']) != (mine_map[k]['crc32'], mine_map[k]['size']))
    print(name, 'recorded', len(rec), 'built', len(mine), 'same order', same_order, 'missing', len(missing),
          'extra', len(extra), 'differ', len(differ))
    for item in (missing + extra + differ)[:10]:
        print('   ', item)
