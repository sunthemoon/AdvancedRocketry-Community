"""Round-2 mutants: apply one by name (exact single match), or restore every touched file from pristine copies.

usage: mutants2.py TREE PRISTINE apply NAME | restore | list
"""
import json
import os
import shutil
import sys

TREE, PRISTINE, ACTION = sys.argv[1], sys.argv[2], sys.argv[3]
PKG = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
GEN = 'src/generated/v1.8/resources/data/'
PRESS = PKG + 'material/press/SmallPlatePressRecipe.java'
CODEC = PKG + 'machine/recipe/BoundedItemIngredientCodec.java'

MUTANTS = {
    'M6': (PRESS, '        if (matches.size() > 1) {\n', '        if (false && matches.size() > 1) {\n',
           '*SmallPlatePressRecipeTest'),
    'M8': (GEN + 'forge/tags/items/ores/titanium.json', '    "advancedrocketrycommunity:rutile_ore",\n', '',
           '*V180MaterialResourcesTest'),
    'M9': (GEN + 'forge/tags/items/ores/aluminum.json', '    "advancedrocketrycommunity:aluminum_ore",\n', '',
           '*V180MaterialResourcesTest'),
    'M10': (GEN + 'advancedrocketrycommunity/worldgen/configured_feature/overworld_rutile_ore.json',
            '"size": 6,', '"size": 12,', '*V180MaterialResourcesTest'),
    'M11': (GEN + 'advancedrocketrycommunity/worldgen/placed_feature/overworld_aluminum_ore.json',
            '"absolute": -16', '"absolute": -64', '*V180MaterialResourcesTest'),
    'M12': (GEN + 'forge/tags/blocks/ores/dilithium.json',
            ',\n    "advancedrocketrycommunity:deepslate_dilithium_ore"', '', '*V180MaterialResourcesTest'),
    'M14': (PRESS, 'if (json.toString().getBytes(StandardCharsets.UTF_8).length > MAX_RECIPE_BYTES) {',
            'if (false && json.toString().getBytes(StandardCharsets.UTF_8).length > MAX_RECIPE_BYTES) {',
            '*SmallPlatePressRecipeSerializerTest'),
    'M15': (PRESS, 'if (!TOP_LEVEL_FIELDS.equals(json.keySet())) {',
            'if (false && !TOP_LEVEL_FIELDS.equals(json.keySet())) {', '*SmallPlatePressRecipeSerializerTest'),
    'M16': (PRESS, 'return new SmallPlatePressRecipe(id, ingredient, new ItemStack(item, buffer.readVarInt()));',
            'buffer.readVarInt(); return new SmallPlatePressRecipe(id, ingredient, new ItemStack(item, 4));',
            '*SmallPlatePressRecipeSerializerTest'),
    'M17': (PRESS, 'if (requireInt(json, "schema_version") != SCHEMA_VERSION) {',
            'if (false && requireInt(json, "schema_version") != SCHEMA_VERSION) {',
            '*SmallPlatePressRecipeSerializerTest'),
    'N1': (CODEC, 'if (!entry.has("item")) {', 'if (false && !entry.has("item")) {',
           '*RecipeTest *BoundedItemIngredientCodecTest'),
    'N2': (PKG + 'machine/electrolyzer/ElectrolyzerRecipe.java',
           '                BoundedItemIngredientCodec.requireItemsOnly(parsed);\n', '',
           '*ElectrolyzerRecipe* *BoundedItemIngredientCodecTest'),
    'N3': (PKG + 'machine/precision/PrecisionAssemblerRecipe.java',
           'BoundedItemIngredientCodec.decodeItemsOnly(JsonParser.parseString(ingredientJson)),',
           'BoundedItemIngredientCodec.decode(JsonParser.parseString(ingredientJson)),', '*PrecisionAssembler*'),
    'N4': (PKG + 'material/MaterialContent.java', '            return new Block(properties);\n',
           '            return material == Material.DILITHIUM ? new net.minecraft.world.level.block.DropExperienceBlock('
           'properties, net.minecraft.util.valueproviders.UniformInt.of(2, 5)) : new Block(properties);\n',
           'gametest'),
    'N6': (GEN + 'forge/tags/items/ores.json', '    "#forge:ores/tin",\n',
           '    "#forge:ores/tin",\n    "#forge:ores/tin",\n', '*V180MaterialResourcesTest'),
    'N7': (PKG + 'gametest/MaterialGameTests.java', '            recipes.replaceRecipes(original);\n', '', 'gametest'),
    'N8': (PKG + 'material/press/SmallPlatePressBlock.java', '        if (selection.ambiguous()) {\n',
           '        if (false && selection.ambiguous()) {\n', 'gametest'),
}


def touched():
    return sorted({value[0] for value in MUTANTS.values()})


if ACTION == 'list':
    print(json.dumps({name: {'file': value[0], 'tests': value[3]} for name, value in MUTANTS.items()}, indent=1))
elif ACTION == 'save':
    for rel in touched():
        dest = os.path.join(PRISTINE, rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copyfile(os.path.join(TREE, rel), dest)
    print('saved', len(touched()))
elif ACTION == 'restore':
    for rel in touched():
        shutil.copyfile(os.path.join(PRISTINE, rel), os.path.join(TREE, rel))
    print('restored', len(touched()))
elif ACTION == 'apply':
    for name in sys.argv[4].split(','):
        rel, old, new, _ = MUTANTS[name]
        path = os.path.join(TREE, rel)
        with open(path, encoding='utf-8', newline='') as handle:
            text = handle.read()
        if text.count(old) != 1:
            raise SystemExit(f'{name}: expected 1 match in {rel}, found {text.count(old)}')
        with open(path, 'w', encoding='utf-8', newline='') as handle:
            handle.write(text.replace(old, new))
        print('applied', name, rel)
