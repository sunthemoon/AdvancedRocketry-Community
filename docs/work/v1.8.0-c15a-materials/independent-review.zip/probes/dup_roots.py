import os, collections, sys

tree = sys.argv[1]
os.chdir(tree)
roots = ['src/main/resources']
for d in sorted(os.listdir('src/generated')):
    r = 'src/generated/resources' if d == 'resources' else 'src/generated/' + d + '/resources'
    if os.path.isdir(r):
        roots.append(r)
print(roots)
m = collections.defaultdict(list)
for r in roots:
    for dp, dn, fn in os.walk(r):
        if '.cache' in dp:
            continue
        for f in fn:
            p = os.path.relpath(os.path.join(dp, f), r).replace(os.sep, '/')
            m[p].append(r)
d = {k: v for k, v in m.items() if len(v) > 1}
for k, v in sorted(d.items()):
    print('DUP', k, v)
print(len(d), 'paths in >1 root')
