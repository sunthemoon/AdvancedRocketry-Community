"""Check that the review tree's tracked directories equal the commit (no stray or modified files)."""
import hashlib
import os
import subprocess
import sys

tree, repo, commit = sys.argv[1], sys.argv[2], sys.argv[3]
prefixes = ('src/', 'tests/', 'tools/', 'scripts/', 'docs/', 'build.gradle', 'gradle.properties')
listing = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', commit], capture_output=True, text=True,
                         check=True).stdout.splitlines()
tracked = {}
for line in listing:
    meta, path = line.split('\t', 1)
    if path.startswith(prefixes):
        tracked[path] = meta.split()[2]
present = set()
for top in ('src', 'tests', 'tools', 'scripts', 'docs'):
    for dirpath, dirnames, filenames in os.walk(os.path.join(tree, top)):
        dirnames[:] = [d for d in dirnames if d not in ('.cache', '__pycache__')]
        for name in filenames:
            present.add(os.path.relpath(os.path.join(dirpath, name), tree).replace(os.sep, '/'))
extra = sorted(present - set(tracked))
missing = sorted(p for p in tracked if p.startswith(('src/', 'tests/', 'tools/', 'scripts/', 'docs/')) and p not in present)
changed = []
for path, blob in tracked.items():
    local = os.path.join(tree, path)
    if not os.path.isfile(local):
        continue
    data = open(local, 'rb').read()
    digest = hashlib.sha1(b'blob %d\0' % len(data) + data).hexdigest()
    if digest != blob:
        changed.append(path)
print('tracked', len(tracked), 'extra', len(extra), 'missing', len(missing), 'changed', len(changed))
for group, items in (('EXTRA', extra), ('MISSING', missing), ('CHANGED', changed)):
    for item in items:
        print(group, item)
