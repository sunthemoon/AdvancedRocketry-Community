"""Apply named textual mutations to the review tree copy. Each mutation must match exactly once."""
import json
import os
import sys

TREE = sys.argv[1]
SET = sys.argv[2]
PKG = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
BLOCK = PKG + 'material/press/SmallPlatePressBlock.java'
SWITCH = PKG + 'material/worldgen/SwitchPlacement.java'
GEN = 'src/generated/v1.8/resources/data/'

MUTATIONS = {
    'A': [
        ('M1 obsidian check removed', BLOCK,
         '        if (!level.getBlockState(anvil).is(Blocks.OBSIDIAN)) {\n            return PressResult.NO_OBSIDIAN;\n        }\n',
         ''),
        ('M2 PistonEvent post removed', BLOCK,
         '        if (MinecraftForge.EVENT_BUS.post(new PistonEvent.Pre(level, pressPosition, Direction.DOWN,\n                PistonEvent.PistonMoveType.EXTEND))) {\n            return PressResult.CANCELLED;\n        }\n',
         ''),
        ('M3 isLoaded check removed', BLOCK,
         '        if (!level.isLoaded(target) || !level.isLoaded(anvil)) {\n            return PressResult.UNLOADED;\n        }\n',
         ''),
        ('M4 rising-edge check removed', BLOCK,
         '        if (powered == state.getValue(POWERED)) {\n            return;\n        }\n',
         ''),
        ('M5 press switch ignored', BLOCK,
         '        if (!CommonConfig.smallPlatePressEnabled()) {\n            return PressResult.DISABLED;\n        }\n',
         ''),
        ('M6 ambiguity refusal removed', BLOCK,
         '        if (matches.size() > 1) {\n',
         '        if (false && matches.size() > 1) {\n'),
        ('M7 ore switch ignored by placement', SWITCH,
         'return enabled() ? Stream.of(position) : Stream.empty();',
         'return Stream.of(position);'),
    ],
    'B': [
        ('M8 rutile_ore dropped from item tag forge:ores/titanium', GEN + 'forge/tags/items/ores/titanium.json',
         '    "advancedrocketrycommunity:rutile_ore",\n', ''),
        ('M9 aluminum_ore dropped from item tag forge:ores/aluminum', GEN + 'forge/tags/items/ores/aluminum.json',
         '    "advancedrocketrycommunity:aluminum_ore",\n', ''),
        ('M10 rutile vein size 6 -> 12', GEN + 'advancedrocketrycommunity/worldgen/configured_feature/overworld_rutile_ore.json',
         '"size": 6,', '"size": 12,'),
        ('M11 aluminum height min -16 -> -64', GEN + 'advancedrocketrycommunity/worldgen/placed_feature/overworld_aluminum_ore.json',
         '"absolute": -16', '"absolute": -64'),
        ('M12 forge:ores/dilithium block tag emptied of deepslate variant', GEN + 'forge/tags/blocks/ores/dilithium.json',
         ',\n    "advancedrocketrycommunity:deepslate_dilithium_ore"', ''),
        ('M13 dilithium press output 2 -> 3', GEN + 'advancedrocketrycommunity/recipes/pressing_dilithium_dust.json',
         '"count": 2,', '"count": 3,'),
    ],
    'C': [
        ('M14 press recipe JSON size bound removed', PKG + 'material/press/SmallPlatePressRecipe.java',
         'if (json.toString().getBytes(StandardCharsets.UTF_8).length > MAX_RECIPE_BYTES) {',
         'if (false && json.toString().getBytes(StandardCharsets.UTF_8).length > MAX_RECIPE_BYTES) {'),
        ('M15 press recipe field check removed', PKG + 'material/press/SmallPlatePressRecipe.java',
         'if (!TOP_LEVEL_FIELDS.equals(json.keySet())) {',
         'if (false && !TOP_LEVEL_FIELDS.equals(json.keySet())) {'),
        ('M16 press network count not read (writes count, reads 4)', PKG + 'material/press/SmallPlatePressRecipe.java',
         'return new SmallPlatePressRecipe(id, ingredient, new ItemStack(item, buffer.readVarInt()));',
         'buffer.readVarInt(); return new SmallPlatePressRecipe(id, ingredient, new ItemStack(item, 4));'),
        ('M17 press recipe schema_version check removed', PKG + 'material/press/SmallPlatePressRecipe.java',
         'if (requireInt(json, "schema_version") != SCHEMA_VERSION) {',
         'if (false && requireInt(json, "schema_version") != SCHEMA_VERSION) {'),
    ],
}


def main():
    applied = []
    for name, rel, old, new in MUTATIONS[SET]:
        path = os.path.join(TREE, rel)
        with open(path, encoding='utf-8', newline='') as handle:
            text = handle.read()
        count = text.count(old)
        if count != 1:
            raise SystemExit(f'{name}: expected 1 match in {rel}, found {count}')
        with open(path, 'w', encoding='utf-8', newline='') as handle:
            handle.write(text.replace(old, new))
        applied.append({'mutation': name, 'file': rel})
    print(json.dumps(applied, indent=1))


main()
