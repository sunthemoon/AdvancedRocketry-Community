import glob, re, sys, os

root = sys.argv[1]
t = f = e = s = 0
n = 0
failed = []
for x in glob.glob(os.path.join(root, '*.xml')):
    n += 1
    h = open(x, encoding='utf-8').read(4000)
    m = re.search(r'tests="(\d+)" skipped="(\d+)" failures="(\d+)" errors="(\d+)"', h)
    t += int(m[1]); s += int(m[2]); f += int(m[3]); e += int(m[4])
    if int(m[3]) or int(m[4]):
        failed.append(os.path.basename(x))
print('suites', n, 'tests', t, 'skipped', s, 'failures', f, 'errors', e)
for x in failed:
    print('FAILED', x)
