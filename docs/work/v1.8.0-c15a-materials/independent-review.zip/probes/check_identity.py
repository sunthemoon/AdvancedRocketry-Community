"""Compare source-identity.json with the exported tree and with git blobs at other commits."""
import hashlib
import json
import os
import subprocess
import sys

tree, repo = sys.argv[1], sys.argv[2]
identity = json.load(open(os.path.join(tree, 'docs/work/v1.8.0-c15a-materials/source-identity.json'), encoding='utf-8'))
files = identity['files']
print('entries', len(files), 'base', identity['base_commit'])


def blob_sha(commit, path):
    try:
        data = subprocess.run(['git', '-C', repo, 'show', f'{commit}:{path}'], capture_output=True, check=True).stdout
    except subprocess.CalledProcessError:
        return None
    return hashlib.sha256(data).hexdigest()


tree_mismatch, missing = [], []
commit_match = {'baa20f95': 0, 'f95e851a': 0}
for entry in files:
    path = entry['path']
    local = os.path.join(tree, path)
    if not os.path.isfile(local):
        missing.append(path)
        continue
    digest = hashlib.sha256(open(local, 'rb').read()).hexdigest()
    if digest != entry['sha256']:
        tree_mismatch.append((path, entry['sha256'][:12], digest[:12], entry.get('working_sha256', '')[:12]))
    for commit in commit_match:
        pass
print('missing in f95e851a tree:', len(missing))
for m in missing[:20]:
    print('  MISSING', m)
print('sha256 differs from f95e851a tree:', len(tree_mismatch))
for m in tree_mismatch[:40]:
    print('  DIFF', m)
# Compare the differing ones with baa20f9 blobs
for path, recorded, _, _ in tree_mismatch[:40]:
    at_run = blob_sha('baa20f95', path)
    print('  at baa20f9:', path, (at_run or 'absent')[:12], 'recorded', recorded)
# Files changed between base and f95e851a that are not in identity
changed = subprocess.run(['git', '-C', repo, 'diff', '--name-only', identity['base_commit'], 'f95e851a'],
                         capture_output=True, text=True, check=True).stdout.split()
listed = {entry['path'] for entry in files}
unlisted = [p for p in changed if p not in listed]
print('changed since base but not listed:', len(unlisted))
for p in unlisted[:40]:
    print('  UNLISTED', p)
