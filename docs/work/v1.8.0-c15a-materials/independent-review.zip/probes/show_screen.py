import json
import sys

d = json.load(open(sys.argv[1], encoding='utf-8'))
print('refs', d.get('references'), d['counts'])
for k, v in sorted(d['files'].items()):
    print(k.split('/')[-1], v['verdict'], v['best'], v.get('measures'))
