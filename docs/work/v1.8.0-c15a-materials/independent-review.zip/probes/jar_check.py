"""Check the built mod JAR: duplicate entries, the tool tags are the v1.8 copies, and every v1.8 generated file
is packaged byte-for-byte."""
import collections
import hashlib
import os
import sys
import zipfile

jar, tree = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(jar) as archive:
    names = archive.namelist()
    counts = collections.Counter(names)
    dups = [n for n, c in counts.items() if c > 1]
    print('entries', len(names), 'duplicates', len(dups), dups[:5])
    root = os.path.join(tree, 'src/generated/v1.8/resources')
    missing, differ = [], []
    total = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != '.cache']
        for name in filenames:
            rel = os.path.relpath(os.path.join(dirpath, name), root).replace(os.sep, '/')
            total += 1
            if rel not in counts:
                missing.append(rel)
                continue
            if archive.read(rel) != open(os.path.join(dirpath, name), 'rb').read():
                differ.append(rel)
    print('v1.8 files', total, 'missing from jar', len(missing), 'differ', len(differ))
    for rel in missing[:10] + differ[:10]:
        print('  ', rel)
    for tag in ('data/minecraft/tags/blocks/needs_iron_tool.json', 'data/minecraft/tags/blocks/mineable/pickaxe.json',
                'data/minecraft/tags/blocks/needs_stone_tool.json'):
        print(tag, 'count', counts[tag], 'sha', hashlib.sha256(archive.read(tag)).hexdigest()[:12],
              'v1.8 sha', hashlib.sha256(open(os.path.join(root, tag), 'rb').read()).hexdigest()[:12])
    print('cache entries in jar', len([n for n in names if '.cache' in n]))
