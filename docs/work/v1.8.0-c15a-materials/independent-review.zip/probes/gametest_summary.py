import re, sys

log = open(sys.argv[1], encoding='utf-8', errors='replace').read()
for line in log.splitlines():
    if re.search(r'required tests passed|required tests failed|tests failed|failed!|Failed test|optional tests|GameTest.*FAIL|ERROR\]', line):
        print(line[:400])
