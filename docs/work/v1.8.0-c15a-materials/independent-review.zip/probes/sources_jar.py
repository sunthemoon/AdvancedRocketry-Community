"""List sources-JAR entries whose bytes match no file of the same relative path under any source root."""
import os
import sys
import zipfile

jar, tree = sys.argv[1], sys.argv[2]
roots = []
for base in ('src/main/java', 'src/main/resources', 'src/api/java'):
    if os.path.isdir(os.path.join(tree, base)):
        roots.append(base)
for name in sorted(os.listdir(os.path.join(tree, 'src'))):
    for sub in ('java', 'resources'):
        path = os.path.join('src', name, sub)
        if os.path.isdir(os.path.join(tree, path)) and path not in roots:
            roots.append(path)
for name in sorted(os.listdir(os.path.join(tree, 'src/generated'))):
    path = 'src/generated/resources' if name == 'resources' else f'src/generated/{name}/resources'
    if os.path.isdir(os.path.join(tree, path)):
        roots.append(path)
unmatched = []
with zipfile.ZipFile(jar) as archive:
    for info in archive.infolist():
        if info.is_dir():
            continue
        data = archive.read(info.filename)
        found = False
        for root in roots:
            candidate = os.path.join(tree, root, info.filename)
            if os.path.isfile(candidate) and open(candidate, 'rb').read() == data:
                found = True
                break
        if not found:
            unmatched.append((info.filename, len(data)))
print('roots', len(roots), 'unmatched', len(unmatched))
for name, size in unmatched[:30]:
    print('  ', name, size)
