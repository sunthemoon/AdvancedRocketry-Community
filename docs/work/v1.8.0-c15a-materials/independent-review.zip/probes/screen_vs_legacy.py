"""Screen the v1.8 generated textures against the legacy Advanced Rocketry textures (review probe).

Uses the project's vanilla_derivation measures with the upstream AR PNG files as the reference set instead of the
vanilla clients, to see whether any NEW template resembles a legacy (possibly LibVulpes-derived) texture.
"""
import json
import sys
from pathlib import Path

tree = Path(sys.argv[1])
upstream = Path(sys.argv[2])
sys.path.insert(0, str(tree / 'tools' / 'audit'))
import vanilla_derivation as derivation  # noqa: E402

references = []
for path in sorted(upstream.rglob('*.png')):
    try:
        width, height, rgba = derivation.decode_rgba(path.read_bytes())
    except Exception:  # noqa: BLE001 - unreadable legacy images are skipped
        continue
    references.append(('legacy-ar', path.relative_to(upstream).as_posix(), derivation.Image(width, height, rgba)))
root = tree / 'src/generated/v1.8/resources'
candidates = []
for path in sorted(root.rglob('*.png')):
    width, height, rgba = derivation.decode_rgba(path.read_bytes())
    candidates.append((path.relative_to(root).as_posix(), derivation.Image(width, height, rgba)))
best = derivation.analyse_images(candidates, references)
out = {}
for name, _ in candidates:
    _, verdict, record = best.get(name, (None, 'CLEAR', {}))
    out[name] = {'verdict': verdict, 'best': record.get('reference'),
                 'measures': {k: record.get(k) for k in ('iou', 'rank', 'overlap') if k in record}}
counts = {}
for entry in out.values():
    counts[entry['verdict']] = counts.get(entry['verdict'], 0) + 1
print(json.dumps({'references': len(references), 'counts': counts, 'files': out}, indent=1, sort_keys=True))
