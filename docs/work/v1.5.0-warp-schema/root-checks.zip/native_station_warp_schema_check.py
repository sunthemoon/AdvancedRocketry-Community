"""V150-WARP-02 native evidence: the STATION-04 root-3 world upgrades to station root 4 and restarts.

Two finite dedicated-server processes on a COPY of the world the STATION-04 second native run left
behind (root 3, expanded 768 station with a member and an invitation, neighbor, markers):

1. upgrade: the WARP-02 host migrates the station file 3 -> 4 before start (one new backup); the
   station payload must equal the root-3 payload with only the root version, epoch and an empty
   `warp_energy` list changed; every other authority is unchanged.
2. restart: no migration or new backup; the payload and both backup trees are unchanged.

No players, warp cores, balances, countdowns, crash cuts or real clients. The source world is not modified.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
NATIVE2 = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-station-native2-4e9521bbae2045b4b808f3cf37181cc8')
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = NATIVE2 / 'station-server/world'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
BACKUPS = 'world/advancedrocketrycommunity-backups'
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
CONSUMER = REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
CONSUMER_SHA = '08c0ff3f9fce59f321ca5f33c14d4bd8e5ec98aa453a0501ba11ef552f33dd09'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def observe_data(world, directory):
    directory.mkdir(parents=True)
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def normalize_other(name, payload):
    value = copy.deepcopy(payload)
    if name == HOST + '_satellite_missions.dat':
        clock = value.pop('clock')
        require(set(clock) == {'logical_game_time', 'last_observed_game_time'}
                and all(type(v) is int and v >= 0 for v in clock.values()), 'Invalid mission clock')
    return value


def bounds(region):
    return f'{region[0]},{region[1]}..{region[2]},{region[3]}'


class Phase:
    def __init__(self, name, artifacts):
        self.name, self.artifacts = name, artifacts
        self.directory = OUT / name
        self.commands, self.observations = [], {}

    def query(self, process, text, pattern, timeout=30):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern, timeout, start_at=start)]


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 240)
        status = server.wait_for_status(port)
        support.validate_status(status, True, phase.artifacts[0]['version'])
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        phase.commands.append('stop')
        process.command('stop')
        require(process.finish() == 0, 'Server did not stop cleanly')
        schema.validate_log(process.lines, [])
        receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                       migration_lines=[line.rstrip() for line in process.lines if '[ARCE-BETA-' in line],
                       station_lines=[line.rstrip() for line in process.lines if 'ARCE_STATION_' in line],
                       observations=phase.observations)
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def backup_directories():
    return sorted(path.name for path in (SERVER / BACKUPS).iterdir())


def check_new_backup(name, source_state):
    backup = SERVER / BACKUPS / name
    manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
    require(manifest['manifestSchema'] == 2, 'Backup manifest is not per-file versioned')
    files = {row['file'] for row in manifest['files']}
    expected = {path.name for path in source_state.iterdir() if path.name.endswith('.dat')}
    require(files == expected and len(files) == len(manifest['files']), 'Backup manifest membership differs')
    require({path.name for path in backup.iterdir()} == files | {'manifest.json'}, 'Backup files differ')
    for row in manifest['files']:
        file = row['file']
        require(row['bytes'] == (backup / file).stat().st_size == (source_state / file).stat().st_size
                and digest(backup / file) == row['sha256'] == digest(source_state / file),
                'Backup differs from the root-3 input: ' + file)
        require(row['role'] == 'authority'
                and (row['sourceSchema'], row['targetSchema']) == ((3, 4) if file == STATION else (2, 2)),
                'Manifest schema differs: ' + file)
    return manifest


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    summary = json.loads((NATIVE2 / 'native/summary.json').read_text(encoding='utf-8'))
    require(summary['result'] == 'PASS' and summary['source_world_unchanged'], 'STATION-04 receipt incomplete')
    restart_state = NATIVE2 / 'native/restart/state'
    for path in restart_state.iterdir():
        if path.suffix == '.dat':
            require(digest(path) == digest(SOURCE / 'data' / path.name),
                    'Source world differs from the recorded STATION-04 end state: ' + path.name)
    host = support.artifact(REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar',
                            HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(CONSUMER, support.FIXTURE, '1.0.0')
    require(consumer['sha256'] == CONSUMER_SHA, 'Consumer fixture differs from the STATION-04 run')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    write_json(OUT / 'inputs.json', {'station_04_receipt': str(NATIVE2 / 'native/summary.json'),
               'station_04_receipt_sha256': digest(NATIVE2 / 'native/summary.json'),
               'source_world': str(SOURCE), 'artifacts': [host, consumer]})
    before = observe_data(SERVER / 'world', OUT / 'before')
    old = before[STATION]
    require(old['schema_version'] == 3 and old['format_epoch'] == 'v1.5.0-orbital-station'
            and 'warp_energy' not in old and len(old['stations']) == 2, 'Source is not the STATION-04 root-3 world')
    target_id, neighbor_id = summary['target_station'], summary['neighbor_station']
    stations = {nbt_uuid(station['station_id']): station for station in old['stations']}
    require(stations[target_id]['region'] == summary['regions']['after'], 'Target is not the expanded witness')
    require(stations[target_id]['members'] and stations[target_id]['invitations'], 'Target lost its team')
    prior_backups = backup_directories()
    require(len(prior_backups) == 1, 'Expected the one STATION-04 backup')
    prior_backup_inventory = fixture.inventory(SERVER / BACKUPS)
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    expected = copy.deepcopy(old)
    expected.update(schema_version=4, format_epoch='v1.5.0-station-warp', warp_energy=[])
    receipts = []

    def inspect(phase, process, station_id, label):
        line = phase.query(process, f'arce station admin inspect {station_id}', re.compile(r'region=\S+ pad='))
        require(f'region={bounds(stations[station_id]["region"])} ' in line, f'{label}: region differs: {line.strip()}')
        phase.observations[label] = line.strip()

    def upgrade_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1002\].*migrated=1, backup=\S+-managed', l) for l in process.lines),
                'Unexpected migration startup result')
        live = schema.read_nbt(SERVER / 'world/data' / STATION)['data']
        require(live == expected, 'Migrated station file is not the root-3 payload plus the root-4 fields')
        phase.observations['migrated_before_first_save'] = 'equals root 3 + schema 4 + epoch + empty warp_energy'
        inspect(phase, process, target_id, 'target_after_upgrade')
        inspect(phase, process, neighbor_id, 'neighbor_after_upgrade')

    upgrade = Phase('upgrade', [host, consumer])
    receipts.append(run_phase(upgrade, port, upgrade_actions))
    upgraded = observe_data(SERVER / 'world', upgrade.directory / 'state')
    require(upgraded[STATION] == expected, 'Upgraded station payload differs')
    require(set(upgraded) == set(before), 'Upgrade changed the managed authority set')
    for name in before:
        if name != STATION:
            require(normalize_other(name, before[name]) == normalize_other(name, upgraded[name]),
                    'Upgrade changed another authority: ' + name)
    after_backups = backup_directories()
    new_backups = [name for name in after_backups if name not in prior_backups]
    require(len(after_backups) == 2 and len(new_backups) == 1, 'Expected exactly one new backup')
    manifest = check_new_backup(new_backups[0], OUT / 'before')
    prior_rows = [row for row in fixture.inventory(SERVER / BACKUPS) if row['path'].startswith(prior_backups[0] + '/')]
    require(prior_rows == prior_backup_inventory, 'Upgrade modified the STATION-04 backup')
    fixture.copy_world(SERVER / BACKUPS, OUT / 'migration-backups')
    backup_snapshot = fixture.inventory(SERVER / BACKUPS)

    def restart_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'Restart remigrated or created a backup')
        inspect(phase, process, target_id, 'target_restart')
        inspect(phase, process, neighbor_id, 'neighbor_restart')

    restart = Phase('restart', [host, consumer])
    receipts.append(run_phase(restart, port, restart_actions))
    restarted = observe_data(SERVER / 'world', restart.directory / 'state')
    require(restarted[STATION] == upgraded[STATION] == expected, 'Restart changed the station payload')
    for name in upgraded:
        if name != STATION:
            require(normalize_other(name, upgraded[name]) == normalize_other(name, restarted[name]),
                    'Restart changed another authority: ' + name)
    require(fixture.inventory(SERVER / BACKUPS) == backup_snapshot, 'Restart modified a migration backup')
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
        'target_station': target_id, 'neighbor_station': neighbor_id,
        'station_root': {'before': 3, 'after': 4}, 'new_backup': new_backups[0],
        'manifest_files': manifest['files'], 'cycles': receipts,
        'scope': ('STATION-04 root-3 world -> WARP-02 pre-start migration to root 4 (empty warp_energy) -> '
                  'restart; no players, cores, balances, warps, crash cuts or real clients')})
    print('PASS: root 3 upgraded to root 4 losslessly, restart idempotent, backups intact, source unchanged')


if __name__ == '__main__':
    main()
