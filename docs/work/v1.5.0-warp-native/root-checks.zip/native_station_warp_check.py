"""V150-WARP-05 native evidence: a real warp and its restarts on a COPY of the WARP-02 root-4 world.

Three finite dedicated-server processes with the WARP-05 host and the opt-in fixture probe. The
probe connects mock players as vanilla GameTest does, aims them, runs only the host's public warp
commands as them, and pushes Forge Energy into the core through its public capability as any producer
mod would:

1. warp: place a warp core in the witness station (owner is a connected probe player), charge it
   within the per-tick allowance, request/confirm as the owner (a member and `/execute as` are
   refused), let the real 10-second countdown commit with the production rocket rule; the station
   file is read before save-all; then charge once more right before stop (the stop fold persists it).
2. restart: orbit, balance and core persist; an interrupted countdown (stop right after confirming).
3. restart-2: the interrupted countdown neither warped nor charged; nothing else changed.

No real clients, rockets, crash cuts (a stop is orderly) or load test. The source world is not modified.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
WARP02 = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-warp02-c080732dceae441a852a12c03d9c8f79')
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = WARP02 / 'station-server/world'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
CONSUMER = REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
SPACE = HOST + ':space'
EARTH, MOON = HOST + ':earth', HOST + ':moon'
PROBE = re.compile(r'ARCE_STATION_PROBE (\{.*\})\s*$')
EXECUTE_REJECTED = re.compile(r'Station warp rejected: run this command yourself as a connected player')
PER_TICK = 200_000
COST = 2_000_000


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def observe_data(world, directory):
    directory.mkdir(parents=True)
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def normalize_other(name, payload):
    value = copy.deepcopy(payload)
    if name == HOST + '_satellite_missions.dat':
        clock = value.pop('clock')
        require(set(clock) == {'logical_game_time', 'last_observed_game_time'}
                and all(type(v) is int and v >= 0 for v in clock.values()), 'Invalid mission clock')
    return value


def visit_only_celestial_change(before, after):
    """Connected probe players may record first Earth/Space visits; nothing else may change."""
    old = {body['id']: body for body in before['bodies']}
    new = {body['id']: body for body in after['bodies']}
    require({k: v for k, v in before.items() if k != 'bodies'} == {k: v for k, v in after.items() if k != 'bodies'},
            'Celestial root fields changed')
    require(set(old) <= set(new) and set(new) - set(old) <= {HOST + ':space'}, 'Unexpected celestial bodies')
    for body_id, body in new.items():
        previous = old.get(body_id)
        if previous == body:
            continue
        require(body_id in (EARTH, HOST + ':space'), 'Non-visit celestial change: ' + body_id)
        require(previous is None or all(body[k] == previous[k] for k in previous), 'Existing celestial field changed')
        require(set(k for k in body if previous is None or k not in previous) <= {'first_visit_at', 'discovered_at', 'id'},
                'Unexpected celestial fields')


def station_record(payload, station_id):
    matches = [s for s in payload['stations'] if nbt_uuid(s['station_id']) == station_id]
    require(len(matches) == 1, 'Station record missing')
    return matches[0]


def balances(payload):
    return {nbt_uuid(entry['station_id']): entry['energy'] for entry in payload['warp_energy']}


def expected_payload(base, station_id, orbit, energy):
    value = copy.deepcopy(base)
    station_record(value, station_id)['orbit_body'] = orbit
    value['warp_energy'] = [entry for entry in value['warp_energy'] if nbt_uuid(entry['station_id']) != station_id]
    if energy:
        value['warp_energy'].append({'station_id': station_record(value, station_id)['station_id'], 'energy': energy})
        value['warp_energy'].sort(key=lambda entry: uuid.UUID(nbt_uuid(entry['station_id'])))
    return value


class Phase:
    def __init__(self, name, artifacts):
        self.name, self.artifacts = name, artifacts
        self.directory = OUT / name
        self.commands, self.probes, self.observations = [], [], {}

    def query(self, process, text, pattern, timeout=30):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern, timeout, start_at=start)]

    def probe_report(self, process, text, label):
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        self.probes.append(report)
        return report

    def join(self, process, label, actor, position):
        report = self.probe_report(process, f'arce_station_probe join {label} {actor} ' + ' '.join(map(str, position)),
                                   label)
        require(report['connected'] is True, 'Probe player is not the connected player-list entity')

    def leave(self, process, label, actor):
        self.probe_report(process, f'arce_station_probe leave {label} {actor}', label)

    def look(self, process, label, actor, position):
        self.probe_report(process, f'arce_station_probe look {label} {actor} ' + ' '.join(map(str, position)), label)

    def energy(self, process, label, position, amount):
        return self.probe_report(process, f'arce_station_probe energy {label} ' + ' '.join(map(str, position))
                                 + f' {amount}', label)

    def run(self, process, label, actor, command):
        report = self.probe_report(process, f'arce_station_probe run {label} {actor} {command}', label)
        require(report['command'] == command and report['level'] == SPACE, 'Probe run differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'A warp command changed the loaded chunk count: ' + label)
        return report


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    command.insert(1, '-Darce_adapter_test.stationSmoke=true')
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 240)
        status = server.wait_for_status(port)
        support.validate_status(status, True, phase.artifacts[0]['version'])
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        phase.commands.append('stop')
        process.command('stop')
        require(process.finish() == 0, 'Server did not stop cleanly')
        schema.validate_log(process.lines, [])
        receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                       migration_lines=[line.rstrip() for line in process.lines if '[ARCE-BETA-' in line],
                       warp_lines=[line.rstrip() for line in process.lines if 'ARCE_STATION_WARP' in line],
                       observations=phase.observations)
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        write_json(phase.directory / 'probes.json', phase.probes)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    summary = json.loads((WARP02 / 'native/summary.json').read_text(encoding='utf-8'))
    require(summary['result'] == 'PASS' and summary['station_root'] == {'before': 3, 'after': 4},
            'WARP-02 receipt incomplete')
    for path in (WARP02 / 'native/restart/state').iterdir():
        if path.suffix == '.dat':
            require(digest(path) == digest(SOURCE / 'data' / path.name),
                    'Source world differs from the recorded WARP-02 end state: ' + path.name)
    host = support.artifact(REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar',
                            HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(CONSUMER, support.FIXTURE, '1.0.0')
    import zipfile
    with zipfile.ZipFile(CONSUMER) as jar:
        require('io/github/sunthemoon/arceadaptertest/StationExpansionProbe.class' in jar.namelist(),
                'Fixture lacks the station probe')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    write_json(OUT / 'inputs.json', {'warp02_receipt': str(WARP02 / 'native/summary.json'),
               'warp02_receipt_sha256': digest(WARP02 / 'native/summary.json'),
               'source_world': str(SOURCE), 'artifacts': [host, consumer]})
    before = observe_data(SERVER / 'world', OUT / 'before')
    base = before[STATION]
    require(base['schema_version'] == 4 and base['warp_energy'] == [], 'Source is not the empty root-4 world')
    target_id, neighbor_id = summary['target_station'], summary['neighbor_station']
    target = station_record(base, target_id)
    require(target['orbit_body'] == MOON, 'Witness does not orbit the Moon')
    owner = nbt_uuid(target['owner_id'])
    member = nbt_uuid(target['members'][0]['id'])
    pad = target['landing_pad']
    core = [pad[0] + 2, pad[1], pad[2]]
    stand = [pad[0], pad[1], pad[2]]
    backups_before = fixture.inventory(SERVER / 'world/advancedrocketrycommunity-backups')
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    artifacts = [host, consumer]
    receipts = []

    def inspect(phase, process, label, orbit, energy):
        line = phase.query(process, f'arce station admin inspect {target_id}', re.compile(r'region=\S+ pad='))
        require(f' orbit={orbit} ' in line and line.rstrip().endswith(f' warp_energy={energy}'),
                f'{label}: inspect differs: {line.strip()}')
        phase.observations[label] = line.strip()

    def charge(phase, process, label, calls):
        accepted = 0
        for index in range(calls):
            report = phase.energy(process, f'{label}_{index}', core, PER_TICK)
            require(report['capability'] and report['accepted'] == PER_TICK and report['stored_reported'] == 0
                    and report['can_extract'] is False, 'Charge differs: ' + json.dumps(report))
            accepted += report['accepted']
        return accepted

    def status(phase, process, label, energy):
        report = phase.run(process, label, owner, 'arce station warp status')
        require(any(f'energy={energy} FE' in m for m in report['messages']), f'{label}: status differs: {report}')

    # Phase 1: a real warp through the production rocket rule and the checked commit.
    def warp_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'The root-4 world was migrated again')
        inspect(phase, process, 'inspect_before', MOON, 0)
        phase.join(process, 'owner_join', owner, stand)
        phase.join(process, 'member_join', member, stand)
        line = phase.query(process, f'execute in {SPACE} run setblock {core[0]} {core[1]} {core[2]} {HOST}:warp_core',
                           re.compile(r'Changed the block at|Could not set the block|not loaded'))
        require('Changed the block at' in line, 'Warp core was not placed')
        first = phase.energy(process, 'charge_over_allowance', core, PER_TICK + 100_000)
        require(first['simulated'] == PER_TICK and first['accepted'] == PER_TICK and first['stored_reported'] == 0,
                'Per-tick allowance differs: ' + json.dumps(first))
        charge(phase, process, 'charge', 10)
        status(phase, process, 'status_charged', COST + PER_TICK)
        phase.look(process, 'owner_look', owner, core)
        phase.look(process, 'member_look', member, core)
        denied = phase.run(process, 'member_request', member, f'arce station warp {EARTH}')
        require(any('only the owner or an operator' in m for m in denied['messages']), 'Member warp was not refused')
        phase.query(process, f'execute as {owner} run arce station warp {EARTH}', EXECUTE_REJECTED)
        request = phase.run(process, 'owner_request', owner, f'arce station warp {EARTH}')
        require(any(f'in-system warp, cost {COST} FE, warp energy {COST + PER_TICK} FE' in m
                    and f'/arce station warp confirm {target_id}' in m for m in request['messages']),
                'Quote differs: ' + json.dumps(request))
        pending = schema.read_nbt(SERVER / 'world/data' / STATION)['data']
        require(station_record(pending, target_id)['orbit_body'] == MOON, 'A request alone changed the orbit')
        confirmed_at = len(process.lines)
        confirm = phase.run(process, 'owner_confirm', owner, f'arce station warp confirm {target_id}')
        require(any('Warp countdown started' in m for m in confirm['messages']), 'Countdown did not start')
        process.wait_for(re.compile(r'ARCE_STATION_WARP action=commit code=WARP_COMMITTED station=' + target_id),
                         40, start_at=confirmed_at)
        commit_messages = [l.strip() for l in process.lines[confirmed_at:] if 'ARCE_STATION_WARP' in l]
        phase.observations['commit_lines'] = commit_messages
        live = schema.read_nbt(SERVER / 'world/data' / STATION)['data']
        require(live == expected_payload(base, target_id, EARTH, PER_TICK),
                'The checked write is not the complete expected registry before save-all')
        shutil.copyfile(SERVER / 'world/data' / STATION, phase.directory / 'checked-write-before-save.dat')
        phase.observations['checked_write_before_save'] = 'orbit earth, balance 200000, all else unchanged'
        inspect(phase, process, 'inspect_after', EARTH, PER_TICK)
        lines = []
        start = len(process.lines)
        phase.commands.append(f'arce station admin warp {target_id}')
        process.command(f'arce station admin warp {target_id}')
        process.wait_for(re.compile(r'station=' + target_id + r' orbit='), 30, start_at=start)
        lines = [l.strip() for l in process.lines[start:] if 'warp enabled=' in l or 'transfer_journal=' in l
                 or 'station=' + target_id + ' orbit=' in l]
        require(any('transfer_journal=operational' in l and 'unclassified=0' in l for l in lines)
                and any(f'orbit={EARTH} balance={PER_TICK}' in l and 'rockets_in_motion=false' in l for l in lines),
                'Operator diagnostics differ: ' + json.dumps(lines))
        phase.observations['diagnostics'] = lines
        # Charged right before the stop. Unless a periodic fold happens first, only the stop fold
        # (ServerStoppingEvent, before the final save) can persist it; which one applied is recorded.
        charge(phase, process, 'charge_before_stop', 1)
        phase.leave(process, 'member_leave', member)
        phase.leave(process, 'owner_leave', owner)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        saved = balances(schema.read_nbt(SERVER / 'world/data' / STATION)['data']).get(target_id)
        require(saved in (PER_TICK, 2 * PER_TICK), f'Unexpected balance after save-all: {saved}')
        phase.observations['balance_after_save_all_before_stop'] = saved
        phase.observations['stop_fold_demonstrated'] = saved == PER_TICK

    warp = Phase('warp', artifacts)
    receipts.append(run_phase(warp, port, warp_actions))
    after_warp = observe_data(SERVER / 'world', warp.directory / 'state')
    require(after_warp[STATION] == expected_payload(base, target_id, EARTH, 2 * PER_TICK),
            'The stop fold did not persist the last charge, or something else changed')
    celestial = HOST + '_celestial.dat'
    visit_only_celestial_change(before[celestial], after_warp[celestial])
    for name in before:
        if name not in (STATION, celestial):
            require(normalize_other(name, before[name]) == normalize_other(name, after_warp[name]),
                    'The warp phase changed another authority: ' + name)

    # Phase 2: persistence, then a countdown interrupted by an orderly stop.
    def restart_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'Restart remigrated')
        inspect(phase, process, 'inspect_restart', EARTH, 2 * PER_TICK)
        phase.join(process, 'owner_join', owner, stand)
        line = phase.query(process, f'execute in {SPACE} if block {core[0]} {core[1]} {core[2]} {HOST}:warp_core',
                           re.compile(r'Test (passed|failed)|not loaded'))
        require('Test passed' in line, 'The warp core did not persist')
        phase.look(process, 'owner_look', owner, core)
        short = phase.run(process, 'owner_short', owner, f'arce station warp {MOON}')
        require(any('does not cover the cost' in m and f'warp energy {2 * PER_TICK} FE' in m
                    for m in short['messages']), 'Insufficient balance was not refused: ' + json.dumps(short))
        charge(phase, process, 'charge', 9)
        status(phase, process, 'status_charged', COST + PER_TICK)
        phase.run(process, 'owner_request', owner, f'arce station warp {MOON}')
        confirm = phase.run(process, 'owner_confirm', owner, f'arce station warp confirm {target_id}')
        require(any('Warp countdown started' in m for m in confirm['messages']), 'Countdown did not start')
        phase.observations['interrupted'] = 'orderly stop right after confirmation'

    restart = Phase('restart', artifacts)
    receipts.append(run_phase(restart, port, restart_actions))
    require(not any('action=commit' in l for l in receipts[-1]['warp_lines']), 'The interrupted countdown committed')
    after_restart = observe_data(SERVER / 'world', restart.directory / 'state')
    interrupted = expected_payload(base, target_id, EARTH, COST + PER_TICK)
    require(after_restart[STATION] == interrupted, 'The interrupted countdown changed the station or balance')

    # Phase 3: nothing from the interrupted countdown survives.
    def restart2_actions(phase, process):
        inspect(phase, process, 'inspect_restart_2', EARTH, COST + PER_TICK)
        start = len(process.lines)
        phase.commands.append('arce station admin warp')
        process.command('arce station admin warp')
        line = process.lines[process.wait_for(re.compile(r'warp enabled='), 30, start_at=start)]
        require('countdowns=0' in line and 'pending_energy=0' in line, 'Countdown or credit survived: ' + line)
        phase.observations['admin_warp'] = line.strip()

    restart2 = Phase('restart-2', artifacts)
    receipts.append(run_phase(restart2, port, restart2_actions))
    final = observe_data(SERVER / 'world', restart2.directory / 'state')
    require(final[STATION] == interrupted, 'The last restart changed the station registry')
    for name in after_warp:
        if name not in (STATION, celestial):
            require(normalize_other(name, after_warp[name]) == normalize_other(name, final[name]),
                    'A restart changed another authority: ' + name)
    require(fixture.inventory(SERVER / 'world/advancedrocketrycommunity-backups') == backups_before,
            'A phase created or changed a migration backup')
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
        'target_station': target_id, 'neighbor_station': neighbor_id, 'owner': owner, 'member': member,
        'core': core, 'orbit': {'before': MOON, 'after_warp': EARTH, 'after_interrupted_countdown': EARTH},
        'balance': {'after_warp_before_stop_charge': PER_TICK, 'after_stop_fold': 2 * PER_TICK,
                    'after_interrupted_countdown': COST + PER_TICK},
        'cycles': receipts,
        'scope': ('root-4 WARP-02 world -> charge via public Forge Energy capability -> owner warp through the '
                  'real countdown and production rocket rule -> stop fold -> restart with an interrupted '
                  'countdown -> restart; no real clients, rockets, crash cuts or load test')})
    print('PASS: warp committed and persisted; stop fold persisted; interrupted countdown neither warped nor charged')


if __name__ == '__main__':
    main()
