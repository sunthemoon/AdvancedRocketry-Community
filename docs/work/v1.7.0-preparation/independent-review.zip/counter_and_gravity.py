"""Reviewer re-derivations: ADR-055 debt bound and ADR-058 jump height under a field multiplier."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

BUFFER = 200_000  # ADR-055 section 1 controller buffer

print("ADR-055: largest debt the reference counter model reaches, and whether a full buffer can pay it")
for percent in (100, 223, 224, 500, 1000):
    cost = ce.laser_cost(percent)
    for layers in range(1, 11):
        events = ["OP"] * layers + ["SAVE_M", "CRASH"]
        # Run the model without its final unlimited top-up: start the controller with a full buffer.
        live_c = {"energy": BUFFER, "paid": 0}
        live_m = {"done": 0}
        dur_c, dur_m = dict(live_c), dict(live_m)
        for ev in events:
            if ev == "OP":
                # unlimited energy during operation (the controller is recharged between layers)
                live_c["paid"] += 1
                live_m["done"] += 1
            elif ev == "SAVE_M":
                dur_m = dict(live_m)
            elif ev == "CRASH":
                live_c, live_m = dict(dur_c), dict(dur_m)
        debt = (live_m["done"] - live_c["paid"]) * cost
        if debt > BUFFER:
            print(f"  energyPercent={percent:4d} cost={cost:6d}: {layers} unsaved controller layers -> debt {debt} > buffer {BUFFER}: ENERGY_DEBT forever (all-or-nothing payment)")
            break
    else:
        print(f"  energyPercent={percent:4d} cost={cost:6d}: up to 10 layers payable")

print()
print("ADR-058: maximum vanilla jump height (blocks) for a player under gravity multiplier m")
def jump_height(m, v0=0.42, drag=0.98, g=0.08):
    y, v, best = 0.0, v0, 0.0
    for _ in range(200):
        y += v
        best = max(best, y)
        v = (v - g * m) * drag
        if v < 0 and y < best:
            break
    return best
for m in (0.10, 0.50, 1.00, 1.25, 1.30, 1.35, 1.40, 1.50, 2.00):
    h = jump_height(m)
    print(f"  m={m:4.2f}: {h:5.2f}{'  (cannot jump onto a full block)' if h < 1.0 else ''}")
