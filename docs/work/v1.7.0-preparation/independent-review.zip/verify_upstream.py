import csv, hashlib, sys
from pathlib import Path
root = Path(sys.argv[1]); manifest = Path(sys.argv[2])
rows = {r["path"]: r for r in csv.DictReader(open(manifest, encoding="utf-8"))}
prefix = "src/main/java/zmaster587/advancedRocketry/"
ok = 0
for f in sorted(root.rglob("*.java")):
    rel = prefix + f.relative_to(root).as_posix()
    data = f.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    row = rows.get(rel)
    lines = data.count(b"\n") + (0 if data.endswith(b"\n") else 1)
    match = row is not None and row["sha256"] == sha
    ok += match
    print(f"{'MATCH' if match else 'MISMATCH'} {rel} sha={sha[:16]} lines={lines} manifest_lines={row['lines'] if row else None}")
print(f"{ok} matches")
