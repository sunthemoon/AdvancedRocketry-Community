# v1.7.0 Endgame Systems: round 4 confirmation (R4-L1..L5)

| Item | Value |
|---|---|
| Reviewed commit | `30ab77b4b62109d27bc798114c5529387fa670fd` (branch `codex/v1.7.0-endgame-systems`) |
| Previous | Round 4 at `1e7d6c8` (`../round-4/REVIEW.md`, unchanged): 0 Critical/High/Medium, 5 Low, 2 Info; all seven ADRs ACCEPT |
| Range | `git log 1e7d6c8..30ab77b`: 6 commits (`f7a4e33` R4-L2, `8f05410` R4-L1, `de90066` R4-L3, `a3fa20d` R4-L4, `d372340` R4-L5, `30ab77b` dispositions). Only ADR-054, `check_examples.py`, `check_mutations.py`, `examples.json`, the implementation log and `review-04-dispositions.md` changed. |
| Mode | Read-only on the repository: `git archive`/`log`/`diff`/`rev-parse`. No Gradle. `AdvancedRocketry-Community-v1plus-Development-Docs/` not read. All writes are under `round-4-confirm/`. Every run had a timeout. |

## 1. Commands run

| # | Command (abridged) | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive 30ab77b \| tar -x -C round-4-confirm/tree` | 0 | `tree/` |
| 2 | `git log --oneline 1e7d6c8..30ab77b`; `git diff --stat …`; `git rev-parse 30ab77b` | 0 | 6 commits, 6 files (+192/−55) |
| 3 | `git diff 1e7d6c8 30ab77b -- docs/decisions/ …/check_examples.py …/check_mutations.py` | 0 | `diff.txt` |
| 4 | `grep` for leftover `endpoint purge` and for `TRANSIT_LIMIT` / `tombstone settle` / "frozen for good" | 0 | Only the historical "earlier `endpoint purge` … is folded into it" remains. Every other "operator purge" means `transfer purge`. |
| 5 | `PYTHONUTF8=1 timeout 900 python -B check_examples.py` | 0 | **27 tests OK** (50.8 s on this host) |
| 6 | `timeout 2400 python -B check_mutations.py round-4-confirm/mutations-out` | 0 | All five controls clean (the redirect control is `[1]`); **26/26 mutations caught**; "all mutations caught" |
| 7 | `timeout 120 python -B r4c_source_retirement_trace.py` (unmodified model) | 0 | Each of three source-retirement paths gives exactly one delivery (`r4c_source_retirement_trace.log`) |

## 2. Resolution of the round-4 Lows

| ID | Status | Evidence |
|---|---|---|
| R4-L1 | **Resolved** | `endpoint retire` settles its tombstone at once, and `/arce endgame tombstone settle <id>` settles one for a removal whose chunk save never succeeds. Neither then holds an endpoint place forever. Both are audited and state what they give up: the one-lost-write audit guarantee for that endpoint, which the `evict-before-saved-absence` mutation demonstrates. A returning copy is still frozen by the content rule, so settling cannot create a duplicate. |
| R4-L2 | **Resolved** | `dispatched_through` is 0 from registration, so every tombstone records it. `resolve` returns frozen entries above it; only an evicted tombstone leaves entries unprovable. `SOURCE_ROLLBACK` is audited when the copy's persisted `next_seq` is at or below the value. The `Transit` model now retires S on removal (`("R", dispatched_through)`) and freezes and resolves a crash-restored retired copy. My round-4 trace `ESCROW SAVE_S REMOVE_S FLUSH_L CRASH` now gives `(1, 0, False)`; the payload goes back to the input buffer. So do the no-flush path and a path with one registered entry. The three new mutations are caught: `retired-source-registers-again`, `resolve-returns-delivered-entries`, and `resolve-without-rollback-audit` (the last with one lost write). |
| R4-L3 | **Resolved** | An ID frozen for its contents stays frozen for good. The block entity records the freeze in its own root, so it never registers again, even after `resolve`. It has no index record or tombstone, so it counts toward no limit. `endpoint purge` is folded into `endpoint retire`, which is refused while the endpoint's chunk is loaded; there, breaking the block settles it from live state. The §9/§11/§13 text and the command list are consistent. |
| R4-L4 | **Resolved** | While saves are off, no stub is pruned. Once live records plus stubs reach 256, escrow stops with `TRANSIT_LIMIT` until saving resumes, and in-flight delivery continues. `/arce endgame status` shows stubs, and the C13 operator guide lists this. |
| R4-L5 | **Resolved** | `report()` prints a search that hits the state limit as `INCONCLUSIVE (state limit)` and adds it to the failures, for both transit and redirect. `Redirect.explore` raises only at its limit, because `outcome` errors are caught as "stuck". No current mutation hits the limit. |
| R4-I1, R4-I2 | Noted | The evidence archive is due with the acceptance. |

## 3. New findings

### Critical, High, Medium

None.

### Low

None.

### Info

- **R4C-I1 (pre-existing wording).** §11 says an `OUTBOX_QUARANTINED` entry (an undecodable payload that is never registered) is removed "only by an operator purge". The only purge command, `transfer purge <source> <seq>`, is defined for records, and a quarantined outbox entry has none. State that `transfer purge` also accepts an outbox entry without a record, or name the command. This has been unchanged since revision 2 and does not affect the verdicts.

## 4. Per-ADR verdicts at `30ab77b`

| ADR | Revision | Verdict |
|---|---|---|
| ADR-053 | 3 | **ACCEPT** |
| ADR-054 | 4, with the R4 Low answers | **ACCEPT** |
| ADR-055 | 3 | **ACCEPT** |
| ADR-056 | 4 | **ACCEPT** |
| ADR-057 | 3 | **ACCEPT** |
| ADR-058 | 3 | **ACCEPT** |
| ADR-059 | 4 | **ACCEPT** |

The round-4 verdicts stand: all seven ADRs ACCEPT, with no open Critical, High, Medium or Low finding. **Counts for this confirmation:** Critical 0, High 0, Medium 0, Low 0, Info 1.

## 5. Not verified

- Runtime behaviour, C13 budgets and the operator guide content (it does not exist yet; it is a C13 item).
- Third-party block movers. The protocol does not rely on them.
- The models check the protocol rules, not the Java implementation.

## 6. Artifacts

`diff.txt`, `check_examples.log`, `check_mutations.log` (copies in `mutations-out/`), `r4c_source_retirement_trace.py`/`.log`, `tree/`.
