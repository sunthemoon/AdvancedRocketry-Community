"""Round 4 confirmation: the R4-L2 trace on the revision at 30ab77b (unmodified Transit model)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

T = ce.Transit
for path in (["ESCROW", "SAVE_S", "REMOVE_S", "FLUSH_L", "CRASH"],          # retirement written, chunk not
             ["ESCROW", "SAVE_S", "REMOVE_S", "CRASH"],                     # nothing written
             ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "FLUSH_L", "CRASH"]):  # one registered
    state = T.normalize(T.initial())
    for label in path:
        options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
        assert label in options, (path, label, sorted(options))
        state = options[label]
    print(" ".join(path), "->", "(delivered, destroyed, rollback) =", T.delivered(T.drain(state)))
