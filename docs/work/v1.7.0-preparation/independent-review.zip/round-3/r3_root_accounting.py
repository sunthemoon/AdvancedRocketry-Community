"""Round 3: ADR-054 §10 worst-case accounting (rev. 3) and tombstone growth under endpoint churn."""
MiB = 1024 * 1024
caps = {  # name: (count, worst-case bytes) as stated in ADR-054 rev. 3 §10
    "endpoints": (2048, 384), "dispatched_through": (2048, 32), "transit records": (256, 2560),
    "tombstones (pressure threshold)": (4096, 64), "elevator pairs": (1024, 512), "zones": (256, 768),
}
total = 0
for name, (count, size) in caps.items():
    total += count * size
    print(f"  {name:<32} {count:>6} x {size:>5} B = {count * size / MiB:6.3f} MiB")
print(f"  total {total} B = {total / MiB:.3f} MiB (ADR: 'about 2.4 MiB'); growth refused above 3 MiB, hard bound 4 MiB")
extra_at_full = (3 * MiB - total) // 64
print(f"  tombstones beyond 4,096 before endpoint registration/escrow/binds are refused, all other caps full: {extra_at_full}")
small = 200 * 384 + 200 * 32 + 50 * 2560 + 4096 * 64
print(f"  ... on a server with 200 endpoints and 50 records: {(3 * MiB - small) // 64}")
print()
print("Endpoint churn (every removal retires the ID, ADR-054 §9 rev. 3):")
per_cycle, cycle_s = 64, 20  # 64 endpoints per owner; an endpoint registers only after its ID is persisted (~10 s)
rate_h = per_cycle * 3600 // cycle_s
print(f"  one player placing and breaking 64 cheap endpoints (laser_target) every {cycle_s} s: {rate_h} tombstones/hour")
print(f"  past the 4,096 pressure threshold in {4096 * 60 / rate_h:.0f} min; at the growth limit (full caps) in"
      f" {(4096 + extra_at_full) * 60 / rate_h:.0f} min, (small server) {(4096 + (3 * MiB - small) // 64) * 60 / rate_h:.0f} min")
print("  tombstones are removable only after their absence is read back in a chunk-load tag and 6,000 ticks;")
print("  a player who keeps the churn chunk loaded keeps all of them, so only other players' tombstones are evicted.")
