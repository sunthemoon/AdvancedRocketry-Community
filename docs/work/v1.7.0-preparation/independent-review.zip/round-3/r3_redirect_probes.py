"""Round 3 probes on the unmodified revision-3 Redirect model (check_examples.Redirect, retire=True).

Probe 1 (tombstone eviction): ADR-054 §11 removes a tombstone (which is also the retired-ID entry, §9) under
table pressure. A player can create that pressure cheaply because every removed endpoint is retired (§9).
After eviction, a data-preserving mover that is not on the opt-out list places the old destination again;
its ID is no longer retired, so the revision-3 rules treat it as an ordinary endpoint.

Probe 2 (retirement without a live settlement): MISSING (§9) or `endpoint retire` (§11) retires D without
§9.1's live settlement, while the record is CLAIMED and paid at D. The model has no such event; we emulate it.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

RD = ce.Redirect
KEYS = ("rec", "rec_dur", "e", "e_dur", "retired", "retired_dur", "d", "d_dur", "carried", "ee", "ee_dur")


def step(state, label, crashes=1):
    options = {l: s for l, s, _ in RD.successors(state, True, crashes)}
    if label not in options:
        raise AssertionError(f"{label} not enabled; enabled={sorted(options)}")
    return options[label]


def patch(state, **changes):
    parts = dict(zip(KEYS, state))
    parts.update(changes)
    return RD.normalize(tuple(parts[k] for k in KEYS))


def show(tag, state):
    p = dict(zip(KEYS, state))
    print(f"  {tag:<34} rec={p['rec']} retired={p['retired']}/{p['retired_dur']} D={p['d']} carried={p['carried']} E={p['ee']}")


print("Probe 1: mover pickup, redirect, delivery at E, tombstone evicted under pressure, mover places D")
s = RD.normalize(RD.initial())
for label in ["CLAIM_D", "SAVE_D", "PICKUP_D", "REDIRECT", "CLAIM_E", "SAVE_E", "MOVE_E", "FLUSH_L", "PRUNE",
              "FLUSH_L"]:
    s = step(s, label)
    show(label, s)
# Tombstone eviction (ADR-054 §11: absence read back after a start, >= 6,000 ticks, table > 4,096 tombstones,
# oldest first). The tombstone is the retired-ID entry, so the ID is no longer retired.
s = patch(s, retired=False, retired_dur=False)
show("tombstone evicted (pressure)", s)
s = step(s, "PLACE_D")
show("PLACE_D", s)
# (the model keeps the carried flags persisted after PLACE_D; the ADR would need one more save first)
s = step(s, "MOVE_D")
show("MOVE_D ('pruned -> moves again')", s)
print("  outcome (delivered, frozen):", RD.outcome(s, True))
print()

print("Probe 2: D claimed, then D vanishes without onRemove settlement (MISSING) and is retired durably")
s = RD.normalize(RD.initial())
for label in ["CLAIM_D", "FLUSH_L", "SAVE_D"]:
    s = step(s, label)
# Emulate: D's chunk is loaded without D (no onRemove ran, e.g. a mover that removed the block entity first,
# a world edit, or a chunk restored from an older region file); the absence is observed and D is retired.
s = patch(s, d=("carried", 0, 0, None), carried=("P", "P"), d_dur=(False, 0, 0, False), retired=True,
          retired_dur=True)
show("D MISSING, retired, record unchanged", s)
enabled = sorted(l for l, *_ in RD.successors(s, True, 0))
print("  enabled events:", enabled)
try:
    print("  outcome:", RD.outcome(s, True))
except AssertionError as error:
    print("  outcome: no quiescent state; the record stays CLAIMED at the retired D (", str(error)[:80], ")")
s = step(s, "PLACE_D", 0)
show("mover places D (retired, frozen)", s)
try:
    print("  outcome:", RD.outcome(s, True))
except AssertionError:
    print("  outcome: still stuck; `endpoint resolve` would destroy D's frozen incoming copy -> the payload is lost")
