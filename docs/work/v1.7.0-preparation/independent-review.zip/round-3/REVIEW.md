# v1.7.0 Endgame Systems: independent contract review, round 3

| Item | Value |
|---|---|
| Reviewed commit | `9b57a61520849bdbc3533ec1ce21f77963665f2d` (revision 3) |
| Previous rounds | Round 1 at `10e3d2d` (`../REVIEW.md`); round 2 at `1b3923a` (`../round-2/REVIEW.md`). Both unchanged. |
| Changes reviewed | `git log 1b3923a..9b57a61`: 8 commits, one per round-2 finding plus the dispositions. ADR-053..059, `check_examples.py`, the new `check_mutations.py`, `examples.json`, `review-02-dispositions.md`, implementation log. |
| Mode | Read-only on the repository: only `git archive`/`log`/`diff`/`rev-parse`. No Gradle. `AdvancedRocketry-Community-v1plus-Development-Docs/` not read. All writes are under this `round-3/` directory. Every exploration was bounded by a timeout or a state cap. |

## 1. Commands run

| # | Command (abridged) | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive 9b57a61 \| tar -x -C round-3/tree` | 0 | `tree/` |
| 2 | `git log --oneline 1b3923a..9b57a61`; `git diff --stat 1b3923a 9b57a61`; `git rev-parse 9b57a61` | 0 | 8 commits, 12 files (+621/−123), documentation only |
| 3 | `git diff 1b3923a 9b57a61 -- <ADR-053..059, check_examples.py>` | 0 | read in full |
| 4 | `PYTHONUTF8=1 timeout 900 python -B check_examples.py` | 0 | 25 tests OK in 18.7 s (`check_examples.log`) |
| 5 | `timeout 1500 python -B check_mutations.py round-3/mutations-out` | 0 | control clean (0 and 1 lost writes); 14/14 mutations caught; 4.9 s (`check_mutations.log`) |
| 6 | `timeout 120 python -B r3_redirect_probes.py` (unmodified `Redirect` model, `retire=True`, two emulated events) | 0 | `r3_redirect_probes.log` |
| 7 | `python -B r3_root_accounting.py` | 0 | `r3_root_accounting.log` |
| 8 | `javap -c -p` of `ServerPlayer` (existing `../mc/` disassembly) and `javap -constants` of `Player` | 0 | `PERSISTED_NBT_TAG = "PlayerPersisted"`, copied in `ServerPlayer.restoreFrom` |
| 9 | `python -` printing the new `examples.json` sections (`redirect`, the consent vectors, named cuts) | 0 | 1,789 states with retirement; the R2-H2 named cut is present |

## 2. Resolution of round-2 findings

| ID | Status | Reason |
|---|---|---|
| R2-H1 | **Partially resolved** | The retirement rule closes the round-2 paths: a crash-restored destination, and a mover-returned destination while its tombstone exists. The `Redirect` model gives exactly once in all 1,789 states, and the no-retirement variant reproduces the mover duplicate. Two problems remain. A player can force eviction of the retired-ID tombstone, which reopens the duplicate (R3-H1). Retirement without a live §9.1 settlement leaves claims with no settlement path (R3-M1). |
| R2-H2 | Resolved | The removal barrier now also covers registered entries whose records are not yet durable. The model counts only unregistered entries as destroyed, and the fault-free test asserts delivered + destroyed = payloads. A named cut and a mutation were added. |
| R2-M1 | Resolved | Consent now comes from the affected player's own `field trust` list (≤ 32), stored under `PlayerPersisted`, which Forge copies on respawn (verified). Untrusting takes effect on the next tick. |
| R2-M2 | Resolved | A failed settlement stays in memory and is retried (`REMOVAL_SETTLEMENT_PENDING`). Outcomes are logged per record, and `transfer resettle` covers a stop before any successful write. It does not cover retirements without a §9.1 settlement (R3-M1). |
| R2-M3 | Resolved | Arithmetic checked: 2,048 × 384 + 2,048 × 32 + 256 × 2,560 + 4,096 × 64 + 1,024 × 512 + 256 × 768 = 2,490,368 B ≈ 2.375 MiB, so every cap fits below 3 MiB. The reference root is ≈ 1.1 MiB. Tombstones beyond 4,096 remain player-driven (R3-M2). |
| R2-L1 | Resolved | A tombstone is removed only after its absence is read back in a load tag after a start. The model checks this. |
| R2-L2 | Resolved | A barrier runs only when there is something to settle. Bulk removals are limited to operator tools, given the opt-out tags. |
| R2-L3 | Resolved | P99 excludes flush ticks; flush ticks have their own budget (≤ 60 ms at the reference root, ≤ 250 ms at the accounted maximum). |
| R2-L4 | Resolved | Validity is checked before the pre-load ticket, and a 100-tick wait follows a cancelled ride. |
| R2-L5 | Resolved | `ownerId` is defined and `actorId()` added. |
| R2-L6 | Resolved | Station fields are capped at 1.00 g, matching ADR-041's range. |
| R2-L7 | Resolved | The epoch check becomes type-aware. |
| R2-L8 | Resolved | The route rule and the barrier class are stated. |
| R2-L9 | Resolved | Spawn protection applies on dedicated servers only. |
| R2-L10 | Resolved | Unbinding is never refused. |
| R2-I2 | Verified | The harness is committed and run: control clean, all 14 caught. See R3-L7. |
| R2-I3, R2-I4 | Addressed | The purpose line is updated, the evidence archive is due at acceptance, and §14 now covers restoring an older endgame file. |

## 3. Findings (round 3)

### Critical

None.

### High

**R3-H1 — ADR-054 §9/§11: a player can force a retired destination's tombstone out, which reopens the R2-H1 duplicate.**

- *Problem.* The retired-ID entry is the tombstone ("one tombstone serves both purposes"). It is evicted when four conditions hold:
  - its absence was read back in a load tag after the start;
  - that observation is ≥ 6,000 ticks old;
  - the table holds > 4,096 tombstones;
  - it is among the oldest such observations.

  Revision 3 retires **every** removed endpoint (§9 "Removing an endpoint … retires its ID"), including ones that never carried cargo. Tombstones are therefore cheap for a player. Placing and breaking 64 `laser_target`s every ~20 s yields about 11,500 tombstones an hour, past 4,096 in about 21 minutes (`r3_root_accounting.py`). Breaking returns the block, so it costs nothing after the first craft. Tombstones whose chunk stays loaded are never eligible, so eviction falls only on the target's.
- *Failing scenario.*
  1. A data-preserving mover that is not on the opt-out list picks up a busy destination D. The ADR says the opt-outs are "not relied on".
  2. §9.1 retires D, the cargo is redirected, and E is paid.
  3. The player reloads D's old chunk, waits 6,000 ticks and churns tombstones. D's tombstone is evicted, so D's ID is no longer retired.
  4. D is placed back. Its incoming payload's record is pruned, so the payload "moves again".
  
  The payload now exists at both D and E. `r3_redirect_probes.py` Probe 1 shows this on the unmodified model (eviction emulated): outcome `(2, 0)`. The stated residual ("needs more than 4,096 later retirements in between") understates it, because the player can create those retirements on purpose.
- *Required change.* Any of the following closes it; the first is independent of eviction:
  - **(a)** An ID that registers for the first time, or again after its tombstone was removed, and arrives with incoming payloads, receipts or outbox entries has them frozen as for a retired ID. A legitimate endpoint never holds incoming payloads or receipts before its registration is durable, because any durable record naming it implies a durable registration.
  - **(b)** Retire, and keep tombstones, only for endpoints that held or were named by ledger state at removal. That covers an outbox entry, an incoming payload, a receipt, a record as source, destination or paid endpoint, or a pair.
  - **(c)** Never evict the tombstone of an endpoint retired while holding settled incoming payloads or receipts.
  
  Add an eviction event and a "first registration with carried contents" event to the `Redirect` model.

### Medium

**R3-M1 — ADR-054 §9/§11/§13: retirement without a live settlement (`MISSING`, `endpoint retire`) leaves `CLAIMED` records with no settlement, and `endpoint resolve` destroys the only copy.**

- §9.1 settles a removed endpoint's claims from its live state in `onRemove`. A `MISSING` endpoint is "retired the same way", but has no live state. The same holds for an operator `endpoint retire` of a lost endpoint, or a mover that drops the block entity before `onRemove` can read it.
- A record that is `CLAIMED`, unacknowledged and paid at that endpoint then has no settlement path:
  - redirect accepts only `IN_TRANSIT`/`ARRIVED` records;
  - `transfer resettle` applies only a logged §9.1 outcome;
  - the retired endpoint never rematerializes, moves or acknowledges.
- If the copy returns (a mover, or the chunk loads again after `endpoint retire`), `endpoint resolve` destroys frozen incoming payloads "because their records were settled at removal and are delivered elsewhere". That is false here: the record is still `CLAIMED` at this endpoint and the payload is lost.
- Probe 2 of `r3_redirect_probes.py` shows no quiescent state. The residual row "a `MISSING` or removed endpoint … cannot reach it, because §9.1 settles a loaded endpoint's claims" is wrong for `MISSING`.

*Required:*
- Once a non-live retirement is durable, return its `CLAIMED`, unacknowledged records to `ARRIVED`. This is safe because the retired copy stays frozen. Keep the moved-copy case under the documented ADR-051 §9 residual for `endpoint retire`.
- Make `resolve` check each frozen item against its record. Destroy an item only if its record is absent, acknowledged elsewhere or redirected. If its record is still `CLAIMED` at this endpoint, move the item and acknowledge it instead.
- Correct the residual row.

**R3-M2 — ADR-054 §10/§11: retired-ID tombstones grow without a per-player bound and can stop endgame admission server-wide.**
- Tombstones beyond 4,096 are "admitted up to the 4 MiB bound". Each player-made one is removable only after its chunk is read back in a load tag, which the player prevents by staying in that chunk.
- Endpoint registration, escrow and binds are refused once the accounted size passes 3 MiB. That is ~10,240 extra tombstones with all caps full (~75 min of one player's churn), or ~41,700 on a small server (~4 h) (`r3_root_accounting.py`).
- Flushes then exceed the 2.4 MiB budget (≤ 250 ms) with no stated limit up to 4 MiB, and no operator command can drop tombstones.

*Required:* bound tombstones per owner (for example, young tombstones count toward the owner's 64-endpoint limit until removable) and/or apply R3-H1 (b). Give the flush budget for roots above the accounted maximum, or admit tombstones only within it.

### Low

- **R3-L1 — §2/§9: quarantine vs `MISSING`.** A quarantined root whose ID the save/load observation cannot read, or a parser that skips quarantined roots as v1.6's `TerminalChunkEvents` does, makes the device look absent. It then becomes `MISSING` and is retired permanently, although quarantine is meant to be reversible. State that a block entity at the recorded position with an unreadable root counts as present.
- **R3-L2 — §9: retired devices for players.**
  - It is unclear whether a non-operator may break an `ENDPOINT_RETIRED` device that holds frozen entries (§9 refuses breaking busy endpoints, while "breaking it drops only its local buffers"). If allowed, frozen unregistered outbox entries that `resolve` would return are destroyed; if not, the inert block stays until an operator acts.
  - After any crash during a non-player removal, returning those entries needs an operator.
  - Even a plain player break followed by a crash brings back a retired, inert device.
  - State the player-facing behaviour.
- **R3-L3 — §11.** Receipts or payloads frozen with `REDIRECT_CONFLICT`/`REDIRECT_DOUBLE_PAY` in a **non-retired** endpoint have no resolve path (`resolve` is for retired IDs), and they block breaking. This is reachable only after a file restore, which is outside the guarantee; still, name the command.
- **R3-L4 — §11 elevator redirect.** Elevator cargo can only be redirected back to its source. If both ends were removed, only purge (destroying the payload) remains. Allow any endpoint of a new pair on the same station, or the owner's other endpoint of the same kind.
- **R3-L5 — §10/§11 sizes.**
  - The 2 KiB payload worst case holds only if "an encoded item tag of at most 512 bytes" bounds the whole encoded stack (ID, count and tag). The tag alone is not enough, since an item ID can be up to 128 characters.
  - 32 B per `dispatched_through` entry needs a compact encoding (for example, a long array).
  - State both.
- **R3-L6 — `Redirect` model fidelity.**
  - `PLACE_D` keeps the carried flags persisted, whereas the ADR says a mover's placement starts unpersisted. This is harmless with retirement.
  - A restored D and a carried copy cannot both be placed.
  - There is no tombstone eviction, `MISSING`, `endpoint retire`, or removal with a non-empty receive buffer or a due move, and E is never removed.
  - The eviction and non-live retirement gaps hide R3-H1 and R3-M1.
- **R3-L7 — `check_mutations.py`.**
  - `transit_violation` returns "no violation" when it hits its 300,000-state limit. A control that outgrows the limit would pass silently; truncation should fail closed.
  - No mutation targets the retirement rules themselves with `retire=True` (for example "redirect before a durable retirement" or "moves again wherever acknowledged"). The only `Redirect` check is the `retire=False` flag.

### Info

- **R3-I1 — Verified.**
  - 25 tests pass.
  - The harness's control is clean and it catches 14/14 mutations.
  - Forge copies `PlayerPersisted` in `ServerPlayer.restoreFrom`.
  - Accounting is 2,490,368 B; the reference root is ≈ 1.1 MiB.
  - The R2-H2 named cut is present.
  - The consent and station-cap vectors match ADR-058 §5.
  - The opt-out tag names (`create:non_movable`, `carryon:block_blacklist`) are plausible but were not checked against those mods.
- **R3-I2 — Evidence archive.** `root-checks.zip` is still deferred to acceptance.

## 4. Per-ADR verdicts

| ADR | Verdict | Required changes |
|---|---|---|
| ADR-053 | **ACCEPT** | — |
| ADR-054 | **ACCEPT WITH REQUIRED CHANGES** | R3-H1, R3-M1, R3-M2 (Lows recommended) |
| ADR-055 | **ACCEPT** | — |
| ADR-056 | **ACCEPT** | — (its cargo relies on ADR-054's ledger) |
| ADR-057 | **ACCEPT** | — |
| ADR-058 | **ACCEPT** | — (R2-M1 and R2-L6 resolved) |
| ADR-059 | **ACCEPT** | — (R3-L4 recommended; its cargo relies on ADR-054) |

**Counts:** Critical 0, High 1, Medium 2, Low 7, Info 2. "Zero Critical/High" is not yet met (R3-H1).

## 5. Not verified

- How third-party movers behave: whether they keep block-entity data, whether `onRemove` sees the block entity, and their tag names.
- The flush and MSPT budgets (C13, needs a running server).
- The rate of endpoint churn: ~20 s per cycle is assumed from the 10-second incremental chunk-save cooldown, not measured.
- Whether `laser_target` registers as an endpoint while physical mining is disabled. If not, the churn needs a costlier endpoint (railgun, terminal), but the rest of the argument holds.
- Runtime behaviour of any kind.

## 6. Artifacts

`check_examples.log`, `check_mutations.log` (copies in `mutations-out/`), `r3_redirect_probes.py`/`.log` (Probe 1: R3-H1; Probe 2: R3-M1), `r3_root_accounting.py`/`.log` (R2-M3 arithmetic, R3-M2), `tree/` (reviewed tree).
