"""Round 2 reviewer traces on the unmodified revision-2 reference models (check_examples.Transit / Delivery)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

T = ce.Transit


def step(state, label):
    options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
    if label not in options:
        raise AssertionError(f"{label} not enabled; enabled={sorted(options)}")
    return options[label]


def replay(labels):
    state = T.normalize(T.initial())
    for label in labels:
        state = step(state, label)
    return state


print("Trace A: a registered but not yet durable entry, then S removed by a non-player cause,")
print("         S's removal saved (for example by a chunk unload) before the coalesced ledger flush, then a crash")
a = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "REMOVE_S", "SAVE_S", "CRASH"])
s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback, destroyed = a
print("  ledger after restart:", l_live, "| S present:", s_live[3], "| model 'destroyed' counter:", destroyed)
drained = T.drain(a)
print("  outcome (delivered, destroyed, rollback):", T.delivered(drained))
print("  ADR-054 §9.1: 'Entries with seq <= dispatched_through[S] are delivered by the ledger' -> no")
print("  OUTBOX_LOST_ON_REMOVAL line is written for this entry, yet nothing delivers it: an unaudited loss.")
print("  The model counts every removed outbox entry, registered or not, as 'destroyed', so the test")
print("  'buffer + destroyed >= payloads' accepts this loss as an audited one.")
print()
print("Trace A': same, but the ledger flushes before S's removal is saved")
a2 = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "REMOVE_S", "FLUSH_L", "SAVE_S", "CRASH"])
print("  outcome:", T.delivered(T.drain(a2)), "(delivered once; the 'destroyed' counter still reads 1)")
