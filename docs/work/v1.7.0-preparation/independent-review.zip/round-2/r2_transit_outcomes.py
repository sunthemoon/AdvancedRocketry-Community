"""Round 2: bounded exploration of the unmodified Transit model (1 payload, 2 crashes, 0 faults) with a
classifier that separates an audited loss (an UNREGISTERED entry destroyed at removal) from an unaudited
one (a REGISTERED entry whose record never became durable). States are capped."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

T = ce.Transit
CAP = 200_000

start = T.normalize(T.initial(1))
seen, stack = set(), [(start, 2, 0, False)]
unaudited_examples = []
outcomes = {}
while stack and len(seen) < CAP:
    state, crashes, faults, unaudited = stack.pop()
    key = (state, crashes, faults, unaudited)
    if key in seen:
        continue
    seen.add(key)
    delivered, destroyed, rollback = T.delivered(T.drain(state))
    outcomes[(delivered, destroyed, unaudited)] = outcomes.get((delivered, destroyed, unaudited), 0) + 1
    if delivered == 0 and unaudited and len(unaudited_examples) < 1:
        unaudited_examples.append(state)
    s_live, s_dur, l_live = state[0], state[1], state[2]
    records, hw, _ = l_live
    for label, new_state, c, f in T.successors(state, crashes, faults):
        flag = unaudited
        if label == "REMOVE_S":
            # an entry with seq <= dispatched_through is 'registered': ADR-054 §9.1 writes no loss line for it
            hw_value = 0 if hw is None else hw
            flag = flag or any(o[0] <= hw_value for o in s_live[1])
        stack.append((new_state, c, f, flag))
print("states explored:", len(seen), "(cap", CAP, ")")
for k in sorted(outcomes):
    print("  delivered=%d destroyed_counter=%d removed_a_registered_entry=%s : %d states" % (k[0], k[1], k[2], outcomes[k]))
print("A state where a registered entry was removed and nothing was delivered exists:", bool(unaudited_examples))
