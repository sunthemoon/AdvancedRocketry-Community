"""Round 2: probe the revision-2 Delivery model's REDIRECT and REMOVE_D simplifications."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

D = ce.Delivery


def step(state, label, faults=1):
    options = {l: s for l, s, *_ in D.successors(state, True, 1, faults)}
    if label not in options:
        raise AssertionError(f"{label} not enabled; enabled={sorted(options)}")
    return options[label]


def show(label, state):
    rec, rec_dur, e, e_dur, d, d_dur, p, p_dur, vanilla = state
    print(f"  {label:<12} rec={rec} d_live={d} d_dur(incoming,buffer,receipt,present)={d_dur}")


s = D.normalize(D.initial())
for label in ["CLAIM", "SAVE_D", "REMOVE_D"]:
    s = step(s, label)
    show(label, s)
print("REDIRECT before the removal is saved (allowed by ADR-054 §11: 'its record was removed by §9.1'):")
enabled = {l for l, *_ in D.successors(s, True, 1, 1)}
print("  REDIRECT enabled in the model?", "REDIRECT" in enabled, "-> the model requires a persisted absence")
s_lost = step(s, "SAVE_D_LOST")
show("SAVE_D_LOST", s_lost)
s_lost = step(s_lost, "REDIRECT")
show("REDIRECT", s_lost)
print("  -> REDIRECT overwrote d_dur with a fresh endpoint although D's chunk on disk still holds D with its")
print("     incoming payload and receipt (the absence write was lost); a crash can no longer restore the old D.")
s_lost = step(s_lost, "CRASH")
show("CRASH", s_lost)
print("  outcome:", D.outcome(s_lost, True), "(the real system would restore the old D with a second copy)")
print()
print("REMOVE_D guard in the model: present and buffer == 0 and not due_move;")
print("removal with a non-empty receive buffer or a due move (ADR-054 §9.1 'drops with the local buffers') is not explored.")
