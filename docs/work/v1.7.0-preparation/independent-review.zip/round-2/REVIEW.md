# v1.7.0 Endgame Systems: independent contract review, round 2

| Item | Value |
|---|---|
| Reviewed commit | `1b3923aca6686f661a799db95f586bc8fcc60f02` (revision 2, branch `codex/v1.7.0-endgame-systems`) |
| Previous round | Round 1 at `10e3d2d` (report unchanged at `../REVIEW.md`) |
| Changes reviewed | `git log 10e3d2d..1b3923a`: 16 commits (S1–S4 `1175907`, F02 `7e9e231`, one per R1 finding, dispositions `1b3923a`); ADR-053..059, the coverage table, the implementation log, the legacy audit, `check_examples.py`, `examples.json` and `review-01-dispositions.md` |
| Mode | Read-only on the repository (only `git archive`/`log`/`diff`/`rev-parse`). No Gradle run. `AdvancedRocketry-Community-v1plus-Development-Docs/` not read. All writes are under this `round-2/` directory. |

## 1. Commands run

| # | Command (abridged) | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive 1b3923a \| tar -x -C round-2/tree` | 0 | `tree/` |
| 2 | `git log --oneline 10e3d2d..1b3923a`; `git diff --stat 10e3d2d 1b3923a`; `git rev-parse 1b3923a` | 0 | 16 commits, 13 files (+1,343/−219), documentation only |
| 3 | `git diff 10e3d2d 1b3923a -- <each ADR, audit, coverage, log>` | 0 | read in full |
| 4 | `PYTHONUTF8=1 timeout 600 python -B check_examples.py` | 0 | 23 tests OK in 24.6 s (`check_examples.log`) |
| 5 | `python -B r2_transit_traces.py` (unmodified `Transit` model) | 0 | `r2_transit_traces.log` |
| 6 | `timeout 300 python -B r2_transit_outcomes.py` (state cap 200,000; 1,750 states explored) | 0 | `r2_transit_outcomes.log` |
| 7 | `python -B r2_redirect_return.py` (small interpreter written from the ADR text, two destinations) | 0 | `r2_redirect_return.log` |
| 8 | `timeout 120 python -B r2_delivery_model_probe.py` (unmodified `Delivery` model) | 0 | `r2_delivery_model_probe.log` |
| 9 | `javap -c -p` on the Forge 47.4.10 jar: `TicketType`, `ServerChunkCache` (`-p`); round-1 `MinecraftServer`/`DedicatedServer` disassembly re-grepped | 0 | `../mc/TicketType.txt` |
| 10 | `grep` of the registry for the §16 recipe inputs (`machine_casing`, `silicon_wafer`, `basic_circuit`, `advanced_circuit`, `rocket_motor`) | 0 | all present (`ModBlocks`/`ModItems`) |
| 11 | `grep -n` of the round-1 upstream files for the corrected audit line numbers | 0 | `MiningDrill` 28–102 and 104–129, `VoidDrill` 99–113: correct |
| 12 | `python -` reading `examples.json` keys, state counts and the new vectors | 0 | 97,656 / 86,112 / 22,060 / 34,158 / 1,622 / 4,011 |

Every exploration I ran had a state cap or a timeout.

## 2. Resolution of round-1 and root findings

| ID | Answer in rev. 2 | Status | Reason |
|---|---|---|---|
| S1 | ADR-055: the gap between the counters is every layer between the two saves | Resolved | The text and model match. |
| S2 | Superseded by R1-M4 | Resolved | See R1-M4. |
| S3 | Harvest-tool requirements not applied | Resolved | Stated as a balance decision. |
| S4 | Structure-only multiblocks (§2.1) | Resolved | Bounded validation (8 per tick, loaded-chunk view); buffers in the controller. |
| F02 | Incoming gate | Resolved | The gated `Delivery` model leaves only the container/player torn-save class; the ungated shape reproduces F02. A new duplicate path goes through redirect (R2-H1). |
| R1-H1 | Tombstones, lowest-entry registration, `SEQUENCE_GAP`, purge keeps the tombstone | Resolved | The model checks it. The remaining residual needs a lost absence write (R2-L1). |
| R1-H2 | Incoming gate + aged observation | Resolved | As F02. |
| R1-H3 | §9.1 removal by any cause | **Partially resolved** | Immunity tags, blast resistance 1,200, `onRemove` and "outbox never drops" are sound. Still open: R2-H1 (returning destination plus redirect), R2-H2 (registered but not yet durable entries) and R2-M2 (failed settlement flush). |
| R1-M1 | Destination ageing; residuals listed | Resolved | Model includes the destination fault. |
| R1-M2 | `ManagedSavedDataType.ENDGAME`, `AtomicSavedData` widened, bad roots refuse start | Resolved | Now matches the code. Nit in R2-L7. |
| R1-M3 | Per-action overrides | Resolved | Nine new vectors match the text. |
| R1-M4 | Expiring `elevator_arrival` pre-load ticket, no synchronous load | Resolved | `TicketType.create(name, cmp, lifespan)` and `addRegionTicket` exist. Distance 0 gives level 33 (FULL, not ticking). Nit in R2-L4. |
| R1-M5 | `TELEPORT` posted at ride commit | Resolved | Nit in R2-L5. |
| R1-M6 | `ElevatorStationGuard` port, `ENDGAME_UNAVAILABLE`, independent of the switch | Resolved | Mirrors `StationRocketAuthority.FAIL_CLOSED`. |
| R1-M7 | Layer-by-layer debt, relink on `LINK_LOST`/removed/`MISSING`, audited reset | Resolved | 97,656 capped-buffer sequences settle; a 300,000 FE debt settles at 1,000 %. |
| R1-M8 | Marker at local 2..13, 3 × 3 chunks `FULL`, push skips absent neighbours, block-entity ticker | Resolved | Vectors cover the six neighbours of every cell. |
| R1-M9 | Owner plus allow list outside stations | **Not resolved** | The field's owner, not the affected player, edits the allow list (R2-M1). |
| R1-M10 | S2C-only device view, ≤ 8 KiB, generated labels | Resolved | — |
| R1-M11 | Budgets, flush gate, barrier spacing | **Partially resolved** | The root accounting cannot hold the reference load (R2-M3). P99 vs flushes is unclear (R2-L3). |
| R1-M12 | §16 IDs, recipes and progression | Resolved | All inputs exist in the registry. |
| R1-L1–L7, L9–L14 | Text changes | Resolved | L14 line numbers are now correct; `root-checks.zip` is deferred to acceptance (R2-I3). |
| R1-L8 | `endpoint forget`, owner redirect, raw outbox quarantine | **Partially resolved** | The owner redirect introduces R2-H1. |
| R1-I1 | Models extended | **Partially resolved** | Two simplifications hide R2-H1 and R2-H2 (§4). |
| R1-I2..I4 | Noted | — | — |

## 3. Findings (round 2)

### Critical

None. R2-H1 becomes a no-crash duplication on servers with a block-entity mover; see its note.

### High

**R2-H1 — ADR-054 §11 (owner and operator redirect) with §9.1/§11 "moves again" and "due move drop": a returning old destination is paid a second time.**

- *Problem.*
  - §11 lets the **owner** redirect `DESTINATION_MISSING` cargo "once the old destination's absence is established (its record was removed by §9.1, or it is `MISSING`); then the old destination cannot return with a receipt".
  - §9.1 itself says the opposite. "A crash after the barrier flush but before the endpoint's chunk saved the removal restores the endpoint with its incoming payload and receipt."
  - §9.1 also names "another mod's … block mover" as a removal cause. A mover carries the block-entity NBT, incoming payload and receipt included, and puts it back later.
  - The destination rows then pay it a second time. "An incoming payload whose record is already acknowledged or pruned … moves again" (§11), and at removal it "drops with the local buffers" (§9.1). Neither rule checks **where** the record was acknowledged.
- *Failing scenario* (`r2_redirect_return.py`, both paths end with 2 copies):
  1. D holds a persisted incoming claim.
  2. D is removed by a non-player cause. The §9.1 barrier flush returns the record to `ARRIVED`.
  3. The owner redirects the record to E, which is allowed at once. E claims.
  4. Either the server stops before D's chunk saves the removal, or a block mover later puts D back.
  5. D returns with its incoming payload and receipt. Its reconciliation keeps the receipt (`REDIRECT_DOUBLE_PAY`, paid elsewhere).
  6. E moves, acknowledges, and the record is pruned. D's incoming now matches "record … pruned" and **moves again** into D's extractable buffer.
  
  The payload now exists at both D and E. On the mover path no crash is needed. The step is player-controlled with any mover that preserves block-entity data (§9.1 lists movers; "cannot be pushed" covers only vanilla pistons). That makes it a reproducible duplication, Critical-class under docs/17, on such servers.
- *Why the model misses it.* `Delivery.REDIRECT` requires a persisted absence (`absence == "seen"`), which is stricter than the text. It also **overwrites D's durable state** with the new endpoint, so the old D can never come back. Even after `SAVE_D_LOST` it can't (`r2_delivery_model_probe.py`). And it has one destination slot, so "acknowledged elsewhere" cannot be represented.
- *Required change.*
  - Allow an owner redirect only after D's absence is persisted and aged (the tombstone rule).
  - Restrict "moves again" and "drops with the local buffers" to records acknowledged **at this endpoint**. Keep that fact past pruning for redirected records, for example with a bounded `(source, seq, voided_at)` marker kept until the old endpoint's absence is persisted, or by not pruning a redirected record until then. An incoming payload at an endpoint the record was redirected away from is quarantined for an operator, never moved or dropped.
  - Give endpoint blocks `PushReaction.BLOCK` and the common "non-movable" tags as defence in depth, without relying on them.
  - Define what §9.1 does with an incoming payload whose record is paid elsewhere.
  - Make the owner redirect a barrier flush and state its route rule.
  - Extend the model with two destinations and an "old destination returns" event.

**R2-H2 — ADR-054 §9.1: removing a source that holds a registered but not yet durable entry can lose it silently.**

- *Problem.* §9.1 says "entries with `seq ≤ dispatched_through[S]` are delivered by the ledger" and writes no `OUTBOX_LOST_ON_REMOVAL` line for them. The barrier flush is specified only for incoming payloads and receipts.
- *Failing scenario.* A registration is still only in memory (the coalesced flush runs every 100 ticks). S is removed by an operator break, `/setblock` or a mod that removes blocks without a break event. S's chunk is saved first, for example at unload, which saves at once. The server stops. After restart there is no record and no S: an unaudited cross-store loss. The crash-cut row "Endpoint removed, removal saved → registered entries delivered" says this cannot happen.
- *Evidence.* `r2_transit_traces.py` Trace A on the unmodified model: `(delivered 0, destroyed 1)`. `r2_transit_outcomes.py` finds 11 such states with 1 payload and 2 crashes.
- *Why the model misses it.* `REMOVE_S` adds every removed entry, registered or not, to the "destroyed" counter (Trace A′ shows `delivered 1, destroyed 1` for one payload). The test `buffer + destroyed >= payloads` therefore accepts this loss as an audited one. No named cut covers "forced removal before the record was durable, removal saved".
- *Reachability.* Mostly operator actions or non-event block removal, plus a stop within the ≤ 5 s flush window. docs/17 still classes cross-dimension transaction loss as High.
- *Required change.* The §9.1 barrier flush also runs when S holds any entry with `seq ≤ dispatched_through[S]` whose record is not yet durable. Fix the model's accounting (count only unregistered entries as destroyed) and add the named cut.

### Medium

**R2-M1 — ADR-058 §5: the allow list is not consent (R1-M9 not resolved).** Outside stations a field affects "its owner and the players on its allow list", and the **owner** edits that list with `/arce endgame field allow <player>`. A griefer adds the victim and places a 2.00 g field (no full-block jump) or a 0.10 g field (about 4 HP per jump) next to the victim's base. A claim mod that does not listen to the new event cannot stop it. The threat-model rows "only players who consented" and "Trapping or hurting players … controlled" are therefore false. `field_affects` and the vectors encode the owner-maintained list.

*Required:* consent must come from the affected player. For example, a player opts in with `/arce endgame field trust <owner>` (revocable at any time by that player), and only fields whose owner the player trusts affect them. Optionally keep the owner's list as a second filter.

**R2-M2 — ADR-054 §9.1 `REMOVAL_SETTLEMENT_UNKNOWN`: the failure path cannot be recovered.**
- "If the barrier flush fails, the records stay as they were": the records stay `CLAIMED`, paid to an endpoint that no longer exists, unacknowledged, and the incoming copy is gone with the block.
- The line asks an operator to "redirect or purge", but operator redirect exists only for `IN_TRANSIT`/`ARRIVED`. Only purge, which destroys the payload, remains. These records also hold the owner's 32-record capacity indefinitely.
- It is also ambiguous whether "stay as they were" means reverting the in-memory settlement or only that the file is unchanged.

*Required:* keep the settlement in memory, dirty and retried by the next coalesced flush or autosave, and audit it as pending. Alternatively, define an operator `transfer resettle` that applies §9.1 to `CLAIMED`, unacknowledged records whose paid endpoint's absence is persisted, or allow redirect of such records.

**R2-M3 — ADR-054 §7/§10: the root's growth accounting cannot hold the caps or the endgame reference load.** Admission uses worst-case per-record accounting with a 1 MiB headroom below the 4 MiB bound. The reference load (§7) then accounts for:

- 4,096 endpoints × ≤ 512 B = 2 MiB;
- 512 records × ≤ 4 KiB = 2 MiB;
- 8,192 tombstones × 64 B = 0.5 MiB.

That totals 4.5 MiB. It exceeds the hard bound, and new growth is refused at 3 MiB. On a mature server with many endpoints and tombstones, accounting could cap cargo near 128 records server-wide. C13 cannot run the stated reference load as specified.

*Required:* reconcile the bound, the worst-case record sizes, the caps and the reference load. Use tighter worst-case sizes, or lower caps, or a larger bound with its flush-time consequence. State which caps can be reached together.

### Low

- **R2-L1 — §11 tombstone residual.**
  - The text says the 6,000-tick age makes a lost absence write "unreachable in practice". But a lost write followed by a stop is permanent, so the age gives no protection after a restart.
  - *Fix:* require the absence to be re-observed by a `ChunkDataEvent.Load` after the last restart (disk state) before a tombstone may be removed under pressure.
  - A mover-carried source whose absence was observed at its old position is the same case.
- **R2-L2 — §9.1/§7: removal settlement flushes are unrate-limited.**
  - The barrier flush runs inside `onRemove`, once per removal, exempt from spacing. A `/fill` over many endpoints, or a contraption assembly of many busy endpoints, gives one flush (≤ 50 ms) each.
  - *Fix:* flush only when something must be settled, and coalesce removals in one call stack or before the next level tick.
  - Note: deferring the flush to END is unsafe for removals made in the between-tick task phase, because each level's chunk saves run early in its tick.
- **R2-L3 — §7 budgets.**
  - The table gives "all endgame work P99 ≤ 8 ms". Coalesced flushes of a multi-MiB root fall in 1 % of ticks at the reference load, bind/unbind barrier flushes add more, and a flush may take up to 50 ms.
  - *Fix:* state whether flush ticks are excluded and budgeted separately. Otherwise the P99 gate is likely unmeetable without the writer thread.
- **R2-L4 — ADR-059 §8 pre-load churn.**
  - Request then cancel (step off the platform) adds and releases an arrival ticket every intent interval, with no cooldown after a cancellation.
  - The request does not re-derive pair validity before adding a ticket.
  - *Fix:* add a per-player cancel cooldown and a validity check before the ticket.
- **R2-L5 — §5.1 `TELEPORT`.**
  - `ownerId()` is undefined for a ride (departing or arrival endpoint owner?).
  - The rider is not exposed, so a claim mod cannot decide per rider.
  - *Fix:* define `ownerId` and add an optional actor before the API freezes.
- **R2-L6 — ADR-058 inside stations.** Station-owner fields affect everyone in the region at 0.10–2.00 g, beyond ADR-041's 0–1.0 g command range. Cap them to that range or note the decision.
- **R2-L7 — §10 epoch check.** `SavedDataSchemaMigrator.migrate` validates `format_epoch` only for `schema >= CURRENT_SCHEMA_VERSION` (the global constant 2). A schema-1 `ENDGAME` root's `v1.7.0-endgame` epoch would therefore never be checked. Make that gate type-aware.
- **R2-L8 — §11 owner redirect details.** "Compatible endpoints" does not name the route rule (railgun same star system, elevator pair), and the redirect's write class (barrier flush? spacing?) is not stated.
- **R2-L9 — §5 step 5.** `MinecraftServer.getSpawnProtectionRadius()` returns 16 on non-dedicated servers. "A dedicated server's configured radius" should state the integrated or LAN behaviour explicitly (none, or the vanilla 16).
- **R2-L10 — §7 barrier spacing.** Unbind can be refused with `ROOT_BUSY`, but ADR-045 requires that unbinding is always possible. Exempt unbind (it only shrinks the root) or guarantee it eventually succeeds.

### Info

- **R2-I1 — Verified.**
  - `TicketType.create(String, Comparator, int)` (lifespan) and `ServerChunkCache.addRegionTicket` exist; distance 0 gives level 33 (`FULL`, not ticking).
  - Block-entity tickers run only in block-ticking chunks.
  - The §16 recipe inputs exist.
  - The corrected legacy line numbers are right.
  - 23 tests pass.
  - The counter model checks 97,656 sequences.
  - The authority vectors match the §3 overrides.
- **R2-I2 — Mutation claim not verifiable.** The "12 protocol mutations caught" claim in the dispositions has no harness committed at `1b3923a`.
- **R2-I3 — Stale or missing evidence.**
  - `root-checks.zip` / `upstream-audit-fetch.json` is still not committed; the audit says it comes with the acceptance.
  - `examples.json` `purpose` still says "revision 1".
- **R2-I4 — Operator file restore.** Restoring an older endgame file registers held entries with `SEQUENCE_GAP`. Payloads that were delivered after the backup and are still held by unreleased sources can then be delivered again. This is outside the guarantee, as in ADR-051; say so in the operator docs.

## 4. Model fidelity (question 3)

- **`Delivery`:**
  - `REDIRECT` needs a persisted absence; the text allows redirect right after the §9.1 index removal.
  - It replaces D's durable state, so an old destination can never return. Real crash restores, lost absence writes and block movers can bring it back.
  - There is one destination slot, so "acknowledged elsewhere" cannot be expressed.
  - `REMOVE_D` runs only with an empty receive buffer and no due move, so the §9.1 "due move drops with the local buffers" rule is never explored.
  
  Together these hide R2-H1. The removal itself (incoming → `ARRIVED`, re-claimed once after a crash) is modelled faithfully.
- **`Transit`:**
  - `REMOVE_S` counts registered entries as destroyed, which hides R2-H2 (§3).
  - Tombstone removal has no pressure condition. That is stricter (more reachable), so it is fine.
  - The registration rule uses the lowest outbox entry including stale ones. This only orders it after the stale drop and is harmless.
  - The fault-free exploration confirms exactly-once delivery except for removal losses, which are not classified (see above).
- **Counter model:** now charges toward a capped buffer and settles layer by layer, which matches ADR-055 rev. 2.

## 5. Per-ADR verdicts

| ADR | Verdict | Required changes |
|---|---|---|
| ADR-053 | **ACCEPT** | — (rev. 2 outcome list matches ADR-054 §16 and ADR-059 §8) |
| ADR-054 | **ACCEPT WITH REQUIRED CHANGES** | R2-H1, R2-H2, R2-M2, R2-M3 (Lows recommended) |
| ADR-055 | **ACCEPT** | — (R1-M7, R1-M8, S1, S3 resolved) |
| ADR-056 | **ACCEPT** | — (its destinations depend on the ADR-054 fixes above) |
| ADR-057 | **ACCEPT** | — |
| ADR-058 | **ACCEPT WITH REQUIRED CHANGES** | R2-M1 |
| ADR-059 | **ACCEPT** | — (R2-L4, R2-L5 and R2-L10 recommended; its cargo depends on ADR-054) |

**Counts:** Critical 0, High 2, Medium 3, Low 10, Info 4. "Zero Critical/High" is not yet met.

## 6. Not verified

- Third-party movers' exact rules. I believe Create and Carry On capture and restore block-entity NBT and that Create honours `PushReaction.BLOCK` and its own non-movable tags, but I did not check their code. R2-H1's crash path does not depend on them.
- The ADR-054 §7 budgets and flush times (C13, needs Gradle and a running server).
- The dispositions' mutation results (no harness committed).
- Whether a level-33 pre-load of an existing chunk ever needs neighbour generation. From the vanilla status rules, only the LIGHT step needs range 1; the 8 neighbours around a built endpoint are expected to exist already.
- No runtime behaviour of any kind; documentation review only.

## 7. Artifacts

`check_examples.log`; `r2_transit_traces.py`/`.log` (R2-H2); `r2_transit_outcomes.py`/`.log`; `r2_redirect_return.py`/`.log` (R2-H1); `r2_delivery_model_probe.py`/`.log` (model simplification); `tree/` (reviewed tree). Shared disassembly is in `../mc/`.
