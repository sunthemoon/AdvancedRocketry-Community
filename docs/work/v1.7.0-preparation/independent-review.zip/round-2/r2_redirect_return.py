"""Round 2: owner redirect (ADR-054 §11 'Operator actions') + the old destination returning with its incoming payload.

A small explicit interpreter of the revision-2 text for ONE record and TWO destinations D (old) and E (redirect
target). It is written from the ADR text, not from check_examples.Delivery, whose REDIRECT replaces D's durable
state with the new endpoint (so an old D can never come back) and requires a persisted absence ('seen').

Rules used (ADR-054 rev 2):
  claim      : record ARRIVED for X, X has no receipt -> CLAIMED paid X, X gets incoming + unpersisted receipt
  save/age   : chunk save observation of X, then the 40-tick age
  move       : X's incoming persisted and aged, and the record is CLAIMED paid X unacknowledged -> move + ack;
               "an incoming payload whose record is already acknowledged or pruned ... moves again"
  §9.1       : removal of D settles live state: incoming here -> record back to ARRIVED, paid cleared,
               barrier flush; the endpoint record is removed
  redirect   : owner may redirect DESTINATION_MISSING cargo "once ... its record was removed by §9.1"
  recon      : receipt + record paid elsewhere -> keep receipt (REDIRECT_DOUBLE_PAY); receipt dropped when the
               record is absent or its acknowledgement is durable
"""
import copy


def fresh():
    return {
        "rec": {"state": "A", "dest": "D", "paid": None, "acked": False}, "rec_dur": None,
        "D": {"present": True, "incoming": None, "receipt": None, "buffer": 0}, "D_dur": None,
        "E": {"present": True, "incoming": None, "receipt": None, "buffer": 0}, "E_dur": None,
        "captured_D": None, "d_index_removed": False, "log": [],
    }


def durable(s):
    s["rec_dur"] = copy.deepcopy(s["rec"])


def claim(s, x):
    r, ep = s["rec"], s[x]
    assert r and r["state"] == "A" and r["dest"] == x and ep["present"] and ep["receipt"] is None
    s["rec"] = {"state": "C", "dest": x, "paid": x, "acked": False}
    ep["incoming"], ep["receipt"] = "unpersisted", "unpersisted"
    s["log"].append(f"claim at {x}")


def save(s, x):
    ep = s[x]
    for k in ("incoming", "receipt"):
        if ep[k] == "unpersisted":
            ep[k] = "persisted"
    s[x + "_dur"] = copy.deepcopy(ep)
    s["log"].append(f"save {x}")


def age(s, x):
    ep = s[x]
    for k in ("incoming", "receipt"):
        if ep[k] == "persisted":
            ep[k] = "aged"
    s["log"].append(f"age {x}")


def move(s, x):
    ep, r = s[x], s["rec"]
    assert ep["present"] and ep["incoming"] == "aged"
    if r and r["state"] == "C" and r["paid"] == x and not r["acked"]:
        r["acked"] = True
        s["log"].append(f"move+ack at {x}")
    elif r is None or r["acked"]:
        s["log"].append(f"move AGAIN at {x} (record {'pruned' if r is None else 'acknowledged by ' + r['paid']})")
    else:
        raise AssertionError("no move rule applies")
    ep["incoming"], ep["buffer"] = None, ep["buffer"] + 1


def flush(s):
    durable(s)
    s["log"].append("ledger flush")


def prune(s):
    assert s["rec"]["acked"]
    s["rec"] = None
    s["log"].append("prune")


def drop_receipts(s):
    for x in ("D", "E"):
        if s[x]["receipt"] is not None and (s["rec"] is None):
            s[x]["receipt"] = None


def remove_d(s):
    """§9.1 settlement from live state, barrier flush, endpoint record removed; captures D's NBT (block mover)."""
    d, r = s["D"], s["rec"]
    s["captured_D"] = copy.deepcopy(d)
    if r and r["state"] == "C" and r["paid"] == "D" and not r["acked"] and (d["incoming"] or d["receipt"] is None):
        s["rec"] = {"state": "A", "dest": "D", "paid": None, "acked": False}
    s["D"] = {"present": False, "incoming": None, "receipt": None, "buffer": 0}
    s["d_index_removed"] = True
    durable(s)
    s["log"].append("D removed by a non-player cause (§9.1), barrier flush")


def owner_redirect(s):
    r = s["rec"]
    assert r["state"] == "A" and r["dest"] == "D" and s["d_index_removed"]
    r["dest"] = "E"
    durable(s)
    s["log"].append("owner redirect to E (barrier flush)")


def crash(s):
    s["rec"] = copy.deepcopy(s["rec_dur"])
    for x in ("D", "E"):
        dur = s[x + "_dur"]
        if dur is None:
            s[x] = {"present": x == "E", "incoming": None, "receipt": None, "buffer": 0}
        else:
            s[x] = copy.deepcopy(dur)
            for k in ("incoming", "receipt"):
                if s[x][k]:
                    s[x][k] = "persisted"  # the chunk load is an observation; ageing restarts
    s["log"].append("CRASH")


def mover_restore(s):
    d = copy.deepcopy(s["captured_D"])
    for k in ("incoming", "receipt"):
        if d[k]:
            d[k] = "unpersisted"  # BlockEntity.load from a mover starts unpersisted
    d["present"] = True
    s["D"] = d
    s["log"].append("block mover places D back with its captured NBT")


def rematerialize_if_needed(s, x):
    r = s["rec"]
    if r and r["state"] == "C" and r["paid"] == x and not r["acked"] and s[x]["receipt"] is None:
        s[x]["incoming"], s[x]["receipt"] = "unpersisted", "unpersisted"
        s["log"].append(f"rematerialize at {x}")


def copies(s):
    return s["D"]["buffer"] + s["E"]["buffer"]


def scenario(name, crash_path):
    s = fresh()
    claim(s, "D"); flush(s); save(s, "D")          # D holds a persisted incoming payload and receipt
    remove_d(s)                                      # operator break, /setblock, or a block mover
    owner_redirect(s)                                # allowed: "its record was removed by §9.1"
    claim(s, "E"); flush(s)
    if crash_path:
        crash(s)                                     # before D's chunk saved the removal
        rematerialize_if_needed(s, "E")
    else:
        pass
    save(s, "E"); age(s, "E"); move(s, "E"); flush(s); prune(s); flush(s); drop_receipts(s)
    if not crash_path:
        mover_restore(s)
    save(s, "D"); age(s, "D")
    move(s, "D")                                     # "moves again": the record is pruned
    print(f"{name}: payload copies = {copies(s)}")
    for line in s["log"]:
        print("    " + line)


scenario("R2 scenario 1 (crash before D's chunk saved its removal)", crash_path=True)
print()
scenario("R2 scenario 2 (block mover, no crash)", crash_path=False)
