"""Reviewer re-derivations against the ADR-054 section 11 reference model (check_examples.Transit).

Each scenario replays labelled events through the unmodified reference successors and, where the
ADR describes a step the model omits, applies that step by hand. It prints the delivered count.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

T = ce.Transit


def step(state, label):
    options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
    if label not in options:
        raise AssertionError(f"{label} not enabled; enabled={sorted(options)}")
    return options[label]


def replay(labels, state=None):
    state = state or T.normalize(T.initial())
    for label in labels:
        state = step(state, label)
    return state


def unpack(state):
    s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback = state
    return dict(s_live=s_live, s_dur=s_dur, l_live=l_live, l_dur=l_dur, d_live=d_live, d_dur=d_dur,
                rollback=rollback)


def pack(p):
    return T.normalize((p["s_live"], p["s_dur"], p["l_live"], p["l_dur"], p["d_live"], p["d_dur"], p["rollback"]))


def total_after_drain(state, extra=0):
    drained = T.drain(state)
    (s_input, outbox, _), _, (records, _, _), _, (buffer, receipts), _, rollback = drained
    return dict(destination_buffer=buffer, external_store=extra, source_input=s_input, outbox=len(outbox),
                records=len(records), receipts=len(receipts), rollback_audited=rollback,
                payload_copies=buffer + extra + s_input)


print("Scenario A: dispatched_through[S] removal (ADR-054 section 11 Pruning) then a crash before S's chunk save")
# Normal delivery; S is released in memory but S's chunk is not saved again afterwards.
a = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "ARRIVE", "CLAIM", "SAVE_D",
            "D_ACK", "FLUSH_L", "PRUNE", "D_DROP", "SAVE_D"])
p = unpack(a)
print("  before removal: S live outbox", p["s_live"][1], "| S durable outbox", p["s_dur"][1],
      "| ledger records", p["l_live"][0], "dispatched_through", p["l_live"][1])
# ADR text: dispatched_through[S] is removed when S's endpoint record is removed (owner breaks S, which is
# allowed because S's live outbox is empty), S holds no outbox entry, and no record has source S.
records, hw, e = p["l_live"]
assert not p["s_live"][1] and not records
p["l_live"] = (records, 0, e)          # removal (0 == absent)
a = pack(p)
a = step(a, "FLUSH_L")                 # coalesced ledger flush persists the removal
a = step(a, "CRASH")                   # crash before S's chunk (break + release) is written
print("  after restart: S outbox", unpack(a)["s_live"][1], "| ledger", unpack(a)["l_live"])
print("  ->", total_after_drain(a))

print()
print("Scenario B: destination-side lost write (ADR-051 residual not listed in ADR-054 section 11)")
# The model only offers SAVE_S_LOST. Emulate SAVE_D_LOST: the receipt is observed persisted, the file write is lost.
b = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "SAVE_S", "ARRIVE", "CLAIM"])
p = unpack(b)
buffer, receipts = p["d_live"]
p["d_live"] = (buffer, frozenset((r[0], True) for r in receipts))   # observed, d_dur unchanged
b = pack(p)
b = replay(["D_ACK", "FLUSH_L", "PRUNE", "FLUSH_L", "CRASH"], b)
print("  ->", total_after_drain(b))

print()
print("Scenario C: automation extracts the claimed payload into a store X saved independently (no fault)")
c = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "SAVE_S", "ARRIVE", "CLAIM"])
p = unpack(c)
buffer, receipts = p["d_live"]
p["d_live"] = (buffer - 1, receipts)    # hopper/pipe extracts from the receive buffer (ADR-056 section 2)
x_durable = 1                           # X's chunk (or a player file) is saved
c = pack(p)
c = replay(["FLUSH_L", "CRASH"], c)     # ledger flush persists CLAIMED; D's chunk was never saved
print("  ->", total_after_drain(c, extra=x_durable))

print()
print("Scenario C': same, but extraction is allowed only once D's receipt is persisted")
c2 = replay(["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "SAVE_S", "ARRIVE", "CLAIM",
             "SAVE_D"])
p = unpack(c2)
buffer, receipts = p["d_live"]
assert all(r[1] for r in receipts)
p["d_live"] = (buffer - 1, receipts)
c2 = pack(p)
c2 = replay(["FLUSH_L", "SAVE_D", "CRASH"], c2)
print("  ->", total_after_drain(c2, extra=1), "(only a vanilla-class rollback of D's own chunk could still duplicate)")
