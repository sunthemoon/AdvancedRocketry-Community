# v1.7.0 Endgame Systems — independent contract review, round 1

| Item | Value |
|---|---|
| Reviewed commit | `10e3d2d59225366d89d3bc07175242e198640c72` (branch `codex/v1.7.0-endgame-systems`) |
| Baseline (parent) | `ab10fb53a580e53a9a1c24097a487f2a7c54ad52` (v1.6 handoff) |
| Scope | ADR-053..059 (all `PROPOSED`, revision 1), `docs/work/v1.7.0-{legacy-audit,contract-coverage,implementation-log}.md`, `docs/PORTING_MATRIX.md` rows, `docs/work/v1.7.0-preparation/{check_examples.py,examples.json}` |
| Reviewer mode | Read-only on the repository. All work in this directory. The untracked `AdvancedRocketry-Community-v1plus-Development-Docs/` was not read. |
| Review directory | `C:/Users/Administrator/AppData/Local/Temp/arce-v170-contract-review-10bf7dbc233944db9aff249763c82d8f/` |

## 1. Commands run

| # | Command (abridged) | Exit | Output |
|---|---|---|---|
| 1 | `git -C D:/GitHub/AdvancedRocketry-Community archive 10e3d2d \| tar -x -C <dir>/tree` | 0 | `tree/` |
| 2 | `git diff --stat ab10fb5 10e3d2d` | 0 | 13 files, documentation only (+3,702/−2) |
| 3 | `git diff ab10fb5 10e3d2d -- docs/PORTING_MATRIX.md` | 0 | 17 new or changed rows |
| 4 | `git rev-parse 10e3d2d ab10fb5` | 0 | full hashes above |
| 5 | `PYTHONUTF8=1 python -B check_examples.py` (in `tree/docs/work/v1.7.0-preparation/`) | 0 | 17 tests OK in 13.7 s, `check_examples.log` |
| 6 | `python -B dump_examples.py tree/.../examples.json` | 0 | `dump_examples.log` |
| 7 | `python -B transit_extensions.py` (reviewer scenarios on the unmodified reference model) | 0 | `transit_extensions.log` |
| 8 | `python -B counter_and_gravity.py` (ADR-055 debt bound, ADR-058 jump height) | 0 | `counter_and_gravity.log` |
| 9 | `curl -sSf` × 14 files from the pinned MIT commit `c5cd5af6…` into `upstream/` | 0 each | `upstream/` |
| 10 | `python -B verify_upstream.py upstream tree/legacy-manifest/java-files.csv` | 0 | 14/14 SHA-256 match, `upstream_verify.log` |
| 11 | `javap -c -p` on the Forge 47.4.10 official-mapped jar: `MinecraftServer`, `DedicatedServer`, `BlockEvent$BreakEvent`, `ServerChunkCache`, `ChunkMap`, `ChunkStorage`, `IOWorker`, `ServerPlayer`, `Entity`, `Level`, `TeleportCommand`, `FakePlayerFactory`, `PlayerList`, `NeighborUpdater`, `ClientboundContainerSetDataPacket`, `ServerboundContainerButtonClickPacket` | 0 each | `mc/*.txt` |

No Gradle task was run and nothing in the repository was written.

## 2. Findings

Severity follows the task's guide and docs/17 §3 ("跨维度事务重复或丢失" is High).
IDs are stable for later rounds.

### Critical

None.

### High

**R1-H1 — ADR-054 §11 "Pruning": removing `dispatched_through[S]` re-enables registration of an already delivered payload.**
- *Problem.* `dispatched_through[S]` is removed when "S's endpoint record is removed, S holds no outbox entry, and no record has source S". "Holds" is S's live state, but S's chunk on disk can still contain an outbox entry that the ledger already delivered and pruned (the crash-cut table's own row "Record pruned while S still holds the entry (S unloaded, its release not yet saved …)"). The only thing that keeps that stale entry from registering again is `dispatched_through[S]`.
- *Failing scenarios.* (a) S is loaded, stale-drops its delivered entry in memory, the owner breaks S at once (allowed: no live entry), the ledger removes the endpoint and `dispatched_through[S]` and its coalesced flush (≤ 100 ticks) lands before S's chunk save (≤ ~10 s); the server is killed. After restart S is back with entry `seq = 1`, the ledger has no record and no `dispatched_through[S]`, so the "No record, seq > dispatched_through" row registers it again and D is paid twice, with no `SOURCE_ROLLBACK` audit. `transit_extensions.py` Scenario A reproduces it on the unmodified reference successors and reports `payload_copies: 2, rollback_audited: False`. (b) No crash is needed when an operator runs `endpoint purge <S>` (§13) on an unloaded S whose disk entry is stale, because the ledger cannot know S's on-disk outbox. With `seq > 1`, the same paths leave the entry permanently waiting (`seq ≠ dispatched_through + 1`) with no remedy.
- *Required change.* Never remove `dispatched_through[S]`, or keep it as a bounded tombstone until S's absence is **persisted**: a `ChunkDataEvent.Save` of S's chunk without S's ID at the recorded position, aged like registration. Refuse `endpoint purge` on an endpoint that has a `dispatched_through` entry until then. Count the tombstones in the root bound. Define the gap case (an entry with `seq > dispatched_through + 1` and no record) as an audited, operator-visible state with a purge path. Add endpoint removal and `dispatched_through` removal to the reference model.

**R1-H2 — ADR-054 §11 "Delivery", ADR-056 §2, ADR-059 §2: claimed items can leave D before D's receipt is persisted, so rematerialization duplicates them after an ordinary crash.**
- *Problem.* The receive buffer is "extractable by automation" (railgun, elevator) and can be withdrawn through the menu. The crash-cut row "Claim: ledger flushed, D not → rematerialized once" is safe only if the claimed items are still in D's unsaved chunk.
- *Failing scenario.* D claims a payload. A hopper or pipe moves it into a chest in another chunk, or a player withdraws it and logs out, which saves the player file at once. That store is saved, and the coalesced ledger flush persists `CLAIMED`. The server stops before D's chunk save. After restart D has no receipt and the ledger reconciliation adds the payload again, so it now exists twice. No write was lost. `transit_extensions.py` Scenario C shows `payload_copies: 2`. Scenario C′ shows that allowing extraction only after the receipt is persisted removes the ledger-made copy and leaves only ordinary vanilla cross-chunk rollback.
- *Required change.* Claimed items (and rematerialized ones) are not extractable by automation or the menu until their receipt is persisted (preferably also aged, see R1-M1). Add the row to the crash-cut table and an "extract" event to the model. The v1.6 terminal withdraw has the same pattern (R1-I3).

**R1-H3 — ADR-054 §2/§9: endpoint removal by any cause other than a refused player break is unspecified for outbox entries, receipts and buffers.**
- *Problem.* §2 says "breaking a device drops the plain block and its local buffers"; §9 refuses breaking "for non-operators" while an outbox entry, unacknowledged receipt or pair exists. That refusal only reaches player breaks (a cancellable `BreakEvent`). Explosions, withers and dragons, other mods' breakers and movers, `/setblock` and operator breaks still remove the block entity. The ADR does not say whether escrowed outbox payloads are "local buffers".
- *Failing scenario.* If outbox entries drop: S launches, the record is registered, and TNT destroys S before the record is durable and released (a window of up to about 5 s). The payload drops as items **and** the ledger delivers it: a duplication without any crash, reproducible in survival, which would be Critical once implemented. If outbox entries never drop: an escrowed but unregistered payload disappears with S (loss). Either way a destination destroyed with unacknowledged receipts leaves a `CLAIMED` record that nothing can settle, and the 32-per-owner limit stays occupied until an operator purges it.
- *Required change.* Define removal for **every** cause (hook `onRemove`, not only the break event). Registered entries (`seq ≤ dispatched_through`) never drop. State an explicit rule for unregistered entries and for receipts. Endpoint blocks are `#minecraft:wither_immune`/`dragon_immune` with high blast resistance. Specify what removal does to the endpoint record (see R1-H1) and add test rows (explosion, `/setblock`, FakePlayer breaker).

### Medium

**R1-M1 — ADR-054 §11 crash cuts: the destination-side lost-write residual is missing, and the 40-tick age rule applies only at S.** An acknowledgement taken right after a `ChunkDataEvent.Save` of D whose `IOWorker` write is lost lets the ledger prune the record, and the payload is lost. ADR-051 §11 lists this residual; ADR-054's table does not, and the model only offers `SAVE_S_LOST`. `transit_extensions.py` Scenario B gives `payload_copies: 0`. *Required:* list the residual, apply the same age rule before acknowledging a receipt, and add a D-side fault to the model.

**R1-M2 — ADR-054 §10: the endgame root's load-failure behaviour contradicts the managed-SavedData pipeline.** Making the root a new `ManagedSavedDataType.ENDGAME` puts it in `WorldDataMigrationService.discoverSources`. There, a future schema throws `FUTURE_SCHEMA`, and a malformed or non-operational payload throws `INVALID_SCHEMA` (`ManagedSavedDataPayloadValidator`). `BetaWorldMigrationEvents` rethrows, so **world start is refused**, not "the endgame authority blocks … the rest of the world runs". Without its own case, `currentSchemaVersion()` defaults to 2, so a schema-1 root would be "migrated" to 2 with epoch `v0.9.0-beta`. `AtomicSavedData`'s constructor also rejects every type except CELESTIAL and SATELLITE_MISSIONS. *Required:* specify the type entry (schema 1 is current, format epoch, required tags, semantic validator), state whether bad roots refuse startup or block at runtime and make §10 match, and record the `AtomicSavedData` widening.

**R1-M3 — ADR-054 §3 contradicts ADR-059 §4/§7, and the vectors encode ADR-054's side.** ADR-059 lets station members (`VISIT`) ride and ship, and lets the anchor owner ship and unbind "from either endpoint's menu". ADR-054 §3 gives station members `VIEW` only inside a region, and "anyone else" only `VIEW` outside stations. `examples.json` asserts `station_member OPERATE → false`, and §4 makes "§3 allows the action" a precondition of every intent. As written, members cannot ride, and the anchor owner cannot unbind from the terminal. Related gaps: after a station ownership transfer, the new owner's members can ride down into the old (anchor) owner's base without that owner's consent. The station owner's `CONFIGURE` of a member's railgun yields an empty list, because §9 offers only the actor's own endpoints and ADR-056 §3 requires the source's owner. *Required:* an explicit per-action override table in §3 for elevator ride, ship and unbind, matching vectors, and a rule for anchor-owner consent (for example, rides require the anchor owner to be the station owner or a station member).

**R1-M4 — ADR-059 §8 vs ADR-054 §12 and ADR-053: the ride arrival is not ticket-free and needs a synchronous load.** In 1.20.1, `ServerPlayer.teleportTo(ServerLevel, …, Set, …)` (the `/tp` path) adds a `TicketType.POST_TELEPORT` region ticket (`mc/net.minecraft.server.level.ServerPlayer.txt`). Vanilla does not load the chunk before moving the player. Steps 3–4 (arrival block entity ID and obstruction check) need the arrival chunk `FULL` in the same tick, which means a main-thread synchronous `getChunk(…, FULL, true)` with its transient ticket. §12 says v1.7 "never creates a … region ticket … never calls a synchronous chunk load", and ADR-053 lists "no chunk ticket" as an outcome. Neither a time budget nor a measurement is given. *Required:* pick one mechanism. Options: the arrival chunk must already be loaded, else `ARRIVAL_UNLOADED`; or an explicit bounded asynchronous pre-load during the countdown, with a short-lived ticket that is counted and released; or a synchronous load with an MSPT budget. Align §12, ADR-053 and the ticket-count tests with that choice.

**R1-M5 — ADR-054 §5.1 / ADR-059: the public `EndgameEffect.TELEPORT` is never posted.** The frozen API 1.8 enum includes `TELEPORT`, but ADR-059 never runs the §5 chain (zones, the API event) for a ride. Claim mods that implement the new event therefore get no veto over arrivals, while the API suggests they do. *Required:* post `EndgameEffectEvent(TELEPORT)` and check zones for the arrival box at commit (refusal changes nothing), or remove `TELEPORT` from the API before it is frozen.

**R1-M6 — ADR-059 §5: interlock and deletion guard behaviour when the endgame root is blocked, the system is disabled, or the hook is not wired.** ADR-044's precedents fail closed: `StationRocketAuthority.FAIL_CLOSED` until installed, the in-motion rule blocks while the journal is not operational, and `StationManager.delete` refuses on a non-operational journal. ADR-059 only says "refuse while a pair names the station"; with a blocked root the pair set is unknown. *Required:* warp request, confirmation and commit, and station deletion, fail closed with a distinct code while the endgame root is not operational or the elevator port is not installed. The interlock is independent of `endgame.spaceElevator.enabled`. It is reached through a port wired at startup, so the station module gets no import of the endgame module (AGENTS §3.4).

**R1-M7 — ADR-055 §3 payment counters: unpayable debt, wrong "one layer" claim, a `LINK_LOST` deadlock and forgiven debt.**
- The controller pays `(ops_done − ops_paid) × cost` all at once from a 200,000 FE buffer. The counters diverge by every layer run between the two chunks' independent saves, not "at most one". `counter_and_gravity.py`: at `energyPercent` 223 nine unsaved layers, at 500 five, at 1,000 three, already exceed the buffer, so the drill stays in `ENERGY_DEBT` forever.
- After a marker reset, or when another controller claims the marker first, the old controller sees `LINK_LOST`. It can clear its link only "after a contact with no debt and no credit, or when the marker is `MISSING`", and neither can happen, so it can never relink. An absent (removed) endpoint is not `MISSING` either.
- A marker reset with debt outstanding forgives it, contrary to "never forgiven by relinking".
- Settling credit (`CREDIT_USED`) breaks blocks, which ADR-054 §1 forbids while the system is disabled.
- The model hides the first point by adding 10⁹ FE before the final settlement.

*Required:* settle debt layer by layer (each `cost` paid raises `ops_paid` by 1). Allow clearing the link on `LINK_LOST` and on an absent marker (audited residual). Allow a reset only when settled, or audit the forgiven layers. Say that credit waits while the system is disabled. Fix the claim and the model.

**R1-M8 — ADR-055 §3 and ADR-057 §4: work at chunk edges can synchronously load a neighbouring chunk.** With marker local x/z in 1..14, footprint cells reach local 0 and 15. `removeBlock` then sends shape and neighbour updates into the adjacent chunk. `Level.getBlockState` calls `getChunk(x, z)` (FULL, loading), and `NeighborUpdater.executeUpdate` reads the neighbour's state. The step-1 check covers only the layer box, so a marker in a border (FULL, non-ticking) chunk can load or upgrade its neighbour. The same breaks attached blocks and hanging entities across a claim boundary. ADR-057 pushes energy to "adjacent receivers" with no loaded check (`Level.getBlockEntity` also loads), and the END-handler tick set may include border chunks. *Required:* restrict the footprint to local 2..13 (neighbour updates then stay in the marker chunk), or require all eight neighbour chunks `FULL`. Push only to neighbours whose chunk is present (`getChunkNow`/`hasChunkAt`), and define the device tick set.

**R1-M9 — ADR-058: area fields impose physics on non-consenting players.** Outside stations any owner may run a field over anyone; only zones, spawn protection and the new API event apply, and existing claim mods do not listen to that event (the ADR's own residual). With vanilla jump physics (`counter_and_gravity.py`, 1.00 g gives 1.25 blocks):
- at m ≥ 1.40 a player cannot jump onto a full block (2.00 g: 0.77), so players in pits or behind 1-block steps are trapped without slabs or stairs;
- at 0.10 g a jump peaks near 6.9 blocks and costs about 4 HP of fall damage.

The threat model's "players can walk out" and "bounded and harmless" are therefore false. `FIELD_DENSITY` (16 per chunk) also lets a neighbour deny someone else's fields. *Required:* on planets a field affects only its owner and an allow list. Otherwise, require an explicit consent zone, or bound the multiplier for others to a range that keeps a full-block jump and does not cause jump damage. Update the threat model and vectors.

**R1-M10 — ADR-054 §4: menu status cannot carry the details the system ADRs promise without a mechanism.** No new message is allowed, extra data is ≤ 4 KiB and sent only at open, and data slots are 16-bit (`ClientboundContainerSetDataPacket` writes shorts). ADR-055 §5, ADR-056 §6 and ADR-059 §9 show the selected target's name, body, Level and position, which change with every previous/next intent. The list of up to 64 endpoints with 128-character IDs is about 18 KiB, more than 4 KiB. v1.6 needed a dedicated S2C view message for the same problem (ADR-049 §10). Endpoints also have no `name` field in the §9 index. *Required:* specify the mechanism now, either a rate-limited menu reopen with fresh extra data or a bounded S2C status message with a protocol bump. Add or remove `name`.

**R1-M11 — Version plan §13 and ADR-054 §7/§10: no per-system MSPT/memory/ticket budgets, no flush-cost gate, and no server-wide barrier spacing.** Coverage maps §13 to "per-ADR caps", but caps are not budgets. The END handler runs after Forge records `tickTimes` (verified), so vanilla MSPT will not show endgame work. Binds, unbinds, zone changes and operator actions are synchronous barrier flushes of a root up to 4 MiB. With only the 10-tick per-player spacing, a few station owners alternating bind and unbind force a write every few ticks. ADR-041 revision 2 (B9) added server-wide spacing for exactly this, and ADR-050 §2 gated flush cost on measurement. *Required:* numeric per-system budgets measured on total tick time, a flush-cost gate at the bound, and server-wide spacing for barrier flushes or a per-station bind/unbind cooldown.

**R1-M12 — Coverage: endgame recipes and progression have no contract.** Plan §3 lists "高级多方块与终局配方" (advanced multiblocks and endgame recipes) and §14 requires complete, playable loops. ADR-054 §1 mentions recipes. No ADR fixes how the controllers, lens, marker, anchor, terminal and field controller are obtained: recipe IDs (stable public IDs from v1.0, AGENTS §8), ingredients, research or discovery gates, and the DataGen location. ADR-053's outcome list also omits it. *Required:* a recipe and progression section, or a recorded disposition.

### Low

- **R1-L1 — ADR-054 §1.** "Every intent returns `SYSTEM_DISABLED`" contradicts withdraw and unbind continuing while disabled. Say "every operation-starting intent".
- **R1-L2 — ADR-054 §5 step 5.** Vanilla spawn protection works only on a dedicated server, in the Overworld, with a non-empty ops list, and is bypassed by an op owner's profile (`PlayerList.isOp(GameProfile)`). A FakePlayer's "no permission level" is irrelevant. Evaluating "every position" of a 33³ box (35,937 calls) should be an O(1) box test.
- **R1-L3 — ADR-054 §5.1.** "Existing API classes keep their bytes" is false for `ApiVersions` (its `1.7` constant becomes `1.8`).
- **R1-L4 — ADR-054 §7 vs ADR-058 §4.** "All endgame work runs in one END handler", but the field lookup runs in the living-tick hook. State the exception.
- **R1-L5 — ADR-054 §9/§10 sizes.** "Endpoint record ≤ 256 bytes" is not met with a 128-character Level key and a full kind ID (about 260 bytes in NBT). Derive worst cases as ADR-050 §3 did. Base growth admission on per-record accounting, not by encoding the root.
- **R1-L6 — ADR-054 §13 audit volume.** One line for every ledger transition of every payload can reach hundreds of MB per hour at the caps. Aggregate, as ADR-055 does with its 1,200-tick summaries.
- **R1-L7 — ADR-054 §13.** `device inspect <pos>` and `device owner <pos> <player>` must refuse unloaded positions, because `getBlockEntity` loads chunks.
- **R1-L8 — ADR-054 §9/§11 self-service gaps.**
  - `MISSING` endpoints count toward the 64-per-owner limit with no player remedy, so explosions can exhaust a victim's capacity.
  - `DESTINATION_MISSING` cargo is operator-only.
  - Outbox gaps after a ledger loss have no remedy.
  - An undecodable outbox payload (removed mod) must stay raw in S; otherwise an AIR payload is registered.
- **R1-L9 — ADR-055 physical side effects.** "Never breaks anything outside its footprint / never damages entities" overstates:
  - the remaining half of a door is removed by shape update without its drop;
  - entities standing on the footprint fall into the shaft;
  - `BreakEvent`s are posted for cells that a later stop leaves intact, which logging and quest mods will count;
  - a waterlogged block's fluid does not stop "the next layer";
  - "typically with the owner nearby" is wrong, because both the station chunk and the planet chunk must be loaded at once.
- **R1-L10 — ADR-055 §2 vs `examples.json`.** "An ore entry of 5 items" vs a default table with `minecraft:diamond` count 1.
- **R1-L11 — ADR-056.**
  - At `energyPercent` above 400, the ORBITAL cost (up to 2,500,000 FE) exceeds the 1,000,000 FE buffer, so the railgun can never launch.
  - Travel is not stored in the outbox entry; registration recomputes it from live state, and it is undefined for `DESTINATION_MISSING`.
  - The refusal list omits route and authority codes.
- **R1-L12 — ADR-055 §4, ADR-057 §5, ADR-058 §4.** Where active counts live (devices in unloaded chunks) and which devices win when over a limit are undefined. Implementations will differ.
- **R1-L13 — ADR-059 §8.**
  - Step 5 debits before teleporting. `teleportTo` can be cancelled by `ForgeHooks.onTravelToDimension`, giving a debit without a ride; debit after a confirmed arrival.
  - How validity at use bypasses `ElevatorEndpointValidator` rule 2 (owner-only) for members and automation is unstated.
- **R1-L14 — Legacy audit accuracy.**
  - "`VoidDrill.performOperation` (lines 266–280)" is wrong; it is `VoidDrill.java` lines 99–111 (134-line file).
  - `TileOrbitalLaserDrill` is listed as 756 lines while the manifest says 757 (no trailing newline).
  - `root-checks.zip` / `upstream-audit-fetch.json` is cited but not committed at `10e3d2d`.
  - Legacy packet ID 13 (`MODE.values()[nbt.getInteger("mode")]`, unchecked index, server-side crash) is missing from §6.

### Info

- **R1-I1 — Reference model coverage.** The transit model has one S and one D. It has no endpoint removal or `dispatched_through` removal, no D-side lost write, no extraction, no redirect, purge or quarantine, and no root-full or limit waits. These omissions hide R1-H1, R1-H2 and R1-M1. The counter model's 10⁹ FE top-up hides R1-M7. The scenarios in `transit_extensions.py` and `counter_and_gravity.py` can be lifted into the checker.
- **R1-I2 — The S-side lost-write residual** (ADR-054 §11) is acceptable as documented. It could be narrowed further with an `IOWorker`/`ChunkStorage` completion signal (needs an access transformer). `ChunkStorage.flushWorker()` is the only public, blocking option.
- **R1-I3 — v1.6 precedent.** `TerminalResourceActions.withdraw` lets a player withdraw before the receipt is persisted, the same pattern as R1-H2. This is out of scope here, but should be fixed the same way.
- **R1-I4 — Claims verified correct.**
  - `UUID.compareTo` compares signed halves (Java 17), and the vector discriminates.
  - Forge records `tickTimes` before `onPostServerTick`.
  - `ChunkDataEvent.Save` is posted before `ChunkMap.write`.
  - `IOWorker.loadAsync` reads `pendingWrites` first, so a Load observation can precede the disk write; the conservative ageing handles this.
  - `getChunkNow` is main-thread and FULL-only.
  - `BreakEvent(Level, BlockPos, BlockState, Player)` works with a FakePlayer (it computes experience only).
  - `FakePlayerFactory.get(ServerLevel, GameProfile)` exists.
  - Channel versions are life support 1, celestial 3, rocket flight 8, rocket visual 1, satellite 1; the API is 1.7.
  - `BodyContextResolver.resolve(WorldLocation, catalog)` and the station-region resolver match §9.
  - `CelestialGravityController` (position override, transient `MULTIPLY_TOTAL`, `ServerPlayer` only, 0..4.0) matches ADR-058.
  - `ElevatorEndpointCode` names match the bind vectors.
  - The warp request, confirm and commit flow, the per-actor confirmations and the one-commit-per-tick rule match ADR-059 §5's assumptions.
  - Root bodies may be orbitable (`CelestialBodyDefinition`), the warp target rule uses `orbitable` plus known, and the interstellar default is 8,000,000 FE, as ADR-057 states.

## 3. Per-question assessment

1. **Scope.**
   - No v1.8 content is pulled in: line and spiral stepping, sky renderer, capsule, station gravity block and non-player fields are deferred, and strikes and coordinate linkers are rejected.
   - No permanent forcing, no client-trusted results, bounded data, and schemas everywhere.
   - Exceptions: the ride path (R1-M4) and edge effects (R1-M8) contradict "no load or ticket".
   - ADR-053 mirrors ADR-048 faithfully (same authorization basis, the prerequisites are honestly unchecked, the cursor stays at v1.0.0, same non-authorizations) and does not overstate.
2. **Coverage.** Every row in §5 and §8–14 has a contract or disposition, except: §13 numeric budgets (R1-M11), recipes and progression from §3/§14 (R1-M12), and the §12 "conservative defaults" for gravity fields (R1-M9). The TravelTarget→BodyContext disposition is reasonable.
3. **Consistency with code and APIs.** Wrong or incomplete claims:
   - the managed-SavedData blocked semantics and `AtomicSavedData` allowlist (R1-M2);
   - the vanilla teleport chunk behaviour (R1-M4);
   - spawn-protection semantics (R1-L2);
   - "API classes keep their bytes" (R1-L3).
   
   The remaining code claims check out (R1-I4).
4. **Soundness.**
   - The ledger core (escrow, persisted-and-aged in-order registration, durable release, epoch-gated claim and acknowledgement, both reconciliation tables) holds for the modelled interleavings. I re-ran the checker: 53,783 and 7,456 states.
   - It fails at the edges the model does not cover (R1-H1, R1-H2, R1-H3, R1-M1).
   - ADR-055: whole-layer atomicity is sound, the counters are not (R1-M7).
   - ADR-057's same-store generation is sound.
   - ADR-058's composition and index are sound, but its consent model is not (R1-M9).
   - ADR-059's interlock is sound when the root is operational (R1-M6). The "no passenger journal" argument holds for the player file (the player's position and inventory are saved together), with R1-M4 and R1-L13 as the gaps.
5. **Feasibility and threat models.**
   - Implementable on Forge 1.20.1 once R1-M2, R1-M4 and R1-M10 are specified.
   - Threat models are missing: non-player removal (R1-H3), edge chunk loading (R1-M8), non-consensual gravity (R1-M9), barrier-flush lag (R1-M11) and log volume (R1-L6).
6. **Legacy audit.**
   - The 14 fetched files match the manifest hashes.
   - The behaviour claims I spot-checked are accurate: laser packets 10–14, cost and cadence, jam discard, `VoidDrill`/`MiningDrill` behaviour, the force-loads, the cleanup thread, railgun ticket and energy, elevator null capsule and 50,000 cost, gravity controller ranges, black-hole fuel and location, config defaults.
   - The exceptions are in R1-L14.

## 4. Per-ADR verdicts

| ADR | Verdict | Required changes |
|---|---|---|
| ADR-053 | **ACCEPT** | None required. Optional: add recipes and progression to the outcome list once R1-M12 is decided, and keep the "no chunk ticket" outcome aligned with the R1-M4 resolution. |
| ADR-054 | **ACCEPT WITH REQUIRED CHANGES** | R1-H1, R1-H2, R1-H3, R1-M1, R1-M2, R1-M3, R1-M5, R1-M10, R1-M11 (+ R1-L1..L8) |
| ADR-055 | **ACCEPT WITH REQUIRED CHANGES** | R1-M7, R1-M8 (+ R1-L9, R1-L10, R1-L12) |
| ADR-056 | **ACCEPT WITH REQUIRED CHANGES** | R1-H2 (receive-buffer extraction rule in §2) (+ R1-L11) |
| ADR-057 | **ACCEPT WITH REQUIRED CHANGES** | R1-M8 (push targets and the tick set) (+ R1-L12) |
| ADR-058 | **ACCEPT WITH REQUIRED CHANGES** | R1-M9 (+ R1-L4, R1-L12) |
| ADR-059 | **ACCEPT WITH REQUIRED CHANGES** | R1-H2 (receive buffer), R1-M3, R1-M4, R1-M5, R1-M6 (+ R1-L13) |

R1-M12 (recipes and progression) needs a home in one of ADR-054..059 or a recorded
disposition before the fourth prerequisite is met. The version cannot meet
"zero Critical/High" until R1-H1..H3 are resolved.

## 5. Not verified

- Runtime behaviour of any kind: no implementation exists, and Gradle was not run, as instructed.
- Third-party claim mods' handling of a FakePlayer that carries the owner's real UUID, and whether they would listen to `EndgameEffectEvent`.
- `IOWorker` write ordering and latency under backlog; ChunkMap incremental-save timing (taken from ADR-051 and the field name `chunkSaveCooldowns`, not timed).
- Forge's dedicated-server behaviour for missing registry entries on downgrade (ADR-054 §14 wording).
- Door and double-plant shape-update drop behaviour (R1-L9). This and the jump-height math rely on vanilla knowledge, not disassembly; the jump formula reproduces vanilla's 1.25-block jump at 1.00 g.
- Only 14 of the 30 audited upstream files were fetched and hash-checked. The other 16 are mostly client renderers and GUI classes.
- Whether the compat test mod or API tests pin `ApiVersions` bytes (R1-L3).

## 6. Artifacts in this directory

`check_examples.log`, `dump_examples.py`/`.log`, `transit_extensions.py`/`.log`
(scenarios A, B, C, C′), `counter_and_gravity.py`/`.log`, `verify_upstream.py`,
`upstream_verify.log`, `upstream/` (14 MIT files from `c5cd5af6…`), `mc/`
(javap disassembly), `tree/` (the reviewed tree).
