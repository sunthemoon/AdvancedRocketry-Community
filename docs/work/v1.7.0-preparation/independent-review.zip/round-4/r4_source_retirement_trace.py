"""Round 4: does the Transit model apply the source-side retirement and resolve of ADR-054 rev. 4 §9?

Trace: S escrows (its registration is durable), the entry is persisted but not yet registered, S is removed by a
non-player cause (the entry is destroyed with OUTBOX_LOST_ON_REMOVAL; S's ID is retired, flush-pending), the
ledger writes the retirement, and the server stops before S's chunk saved the removal.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tree/docs/work/v1.7.0-preparation"))
import check_examples as ce  # noqa: E402

T = ce.Transit
state = T.normalize(T.initial())
for label in ["ESCROW", "SAVE_S", "REMOVE_S", "CRASH"]:
    options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
    assert label in options, (label, sorted(options))
    state = options[label]
s_live, s_dur, l_live = state[0], state[1], state[2]
print("after restart: S present =", s_live[3], "| outbox =", sorted(s_live[1]), "| ledger dispatched_through =", l_live[1])
print("enabled:", sorted({l for l, *_ in T.successors(state, 0, 0)}))
print("model outcome (delivered, destroyed, rollback):", T.delivered(T.drain(state)))
print("The model has no retirement for S: the restored S simply registers its entry and delivers it.")
print("ADR-054 rev. 4 §9: S's ID is retired, the restored S is ENDPOINT_RETIRED and frozen; resolve returns the entry")
print("to the input buffer 'only if the ID's tombstone still records dispatched_through and seq is above it'.")
print("S never registered a record, so no dispatched_through is recorded -> the entry is discarded (an audited loss),")
print("although an absent dispatched_through proves seq 1 was never registered.")
