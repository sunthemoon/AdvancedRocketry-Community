# v1.7.0 Endgame Systems: independent contract review, round 4

| Item | Value |
|---|---|
| Reviewed commit | `1e7d6c80a2a551fab14fc11ef1af82182061574a` (branch `codex/v1.7.0-endgame-systems`). ADR-054, ADR-056 and ADR-059 are at revision 4; ADR-053, ADR-055, ADR-057 and ADR-058 are unchanged at revision 3. |
| Previous rounds | `../REVIEW.md` (round 1, `10e3d2d`), `../round-2/REVIEW.md` (`1b3923a`), `../round-3/REVIEW.md` (`9b57a61`), all unchanged |
| Changes reviewed | `git log 9b57a61..1e7d6c8`, 5 commits. ADR-054/056/059 diffs, `check_examples.py`, `check_mutations.py`, `examples.json`, `review-03-dispositions.md`, implementation log. |
| Mode | Read-only on the repository: only `git archive`/`log`/`diff`/`rev-parse`. No Gradle. `AdvancedRocketry-Community-v1plus-Development-Docs/` not read. All writes are under `round-4/`. Every run had a timeout or a state cap. |

## 1. Commands run

| # | Command (abridged) | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive 1e7d6c8 \| tar -x -C round-4/tree` | 0 | `tree/` |
| 2 | `git log --oneline 9b57a61..1e7d6c8`; `git diff --stat 9b57a61 1e7d6c8`; `git rev-parse 1e7d6c8` | 0 | 5 commits, 8 files (+570/−150), documentation only |
| 3 | `git diff 9b57a61 1e7d6c8 -- docs/decisions/` and `-- …/check_examples.py` | 0 | `adr-diff.txt`, `model-diff.txt` |
| 4 | `PYTHONUTF8=1 timeout 900 python -B check_examples.py` | 0 | **27 tests OK** in 24.5 s (`check_examples.log`) |
| 5 | `timeout 1800 python -B check_mutations.py round-4/mutations-out` | 0 | Four transit controls and the full-rule redirect control clean (`[1]`); **23/23 mutations caught**, `all mutations caught`, 26 s (`check_mutations.log`) |
| 6 | `timeout 120 python -B r4_source_retirement_trace.py` (unmodified `Transit` model) | 0 | `r4_source_retirement_trace.log` |
| 7 | Arithmetic check of the §10 accounting and the pin bound (by hand, see §2) | — | 2,932,736 B; 2,816 pins |

## 2. Resolution of round-3 findings

| ID | Status | Reason |
|---|---|---|
| R3-H1 | **Resolved** | Registration now reads the persisted tag. An ID that is not registered but carries outbox entries, incoming payloads or receipts is frozen. Escrow, being selected as a destination, and claims all need a **durable** registration, so a legitimate endpoint never holds contents while unregistered. A redirect waits for the durable index removal. The `Redirect` model with an eviction adversary is exactly once in every state, with the full-rule control at `[1]`. The `without-freeze`, `register-from-unclean-tag` and `redirect-before-durable-index-removal` mutations are caught, each as a duplicate (`[2]`). |
| R3-M1 | **Resolved** | A retirement without live state (`MISSING` or `endpoint retire`) returns `CLAIMED`, unacknowledged records to `ARRIVED` in its barrier flush, and `resolve` now works item by item. `MISSING_D` and `RESOLVE_D` are modelled, and the `missing-keeps-the-claim` and `resolve-moves-any-copy` mutations are caught. The `MISSING` residual row is corrected. One source-side gap remains (R4-L2). |
| R3-M2 | **Resolved** | Tombstone growth is now bounded on every axis:<br>• pins are bounded by records and pairs: 256 × 3 + 1,024 × 2 = 2,816;<br>• young tombstones take endpoint places;<br>• settled, unpinned ones are capped at 256 per owner and 8,192 overall, with `TOMBSTONE_EVICTED` and `tombstone evict`;<br>• the freeze rule makes eviction safe.<br>Accounting checked: 786,432 + 65,536 + 655,360 + 704,512 + 524,288 + 196,608 = **2,932,736 B < 3 MiB**. The `CAP_EVICTION` adversary keeps the lost-write guarantee, and the `evict-before-saved-absence` and `evict-without-freeze` mutations are caught. Remaining: young tombstones from `endpoint retire` never settle (R4-L1). |
| R3-L1 | Resolved | A quarantined or unreadable root at the recorded position counts as present in every presence or absence observation, including tombstones and stubs. |
| R3-L2 | Resolved | Breaking a retired device first resolves it in the removal's barrier flush. Owners can resolve their own retired devices (spaced), and the menu explains the state. |
| R3-L3 | Resolved | Items frozen in a registered endpoint are resolved with the same command and make it busy until then. |
| R3-L4 | Resolved | Elevator cargo can also go to the same kind of endpoint in the station's current valid pair (ADR-054, ADR-059). ADR-056 names the owner redirect. |
| R3-L5 | Resolved | A payload stack is ≤ 512 B encoded, counting ID, count and tag (`PAYLOAD_TOO_LARGE`). `dispatched_through` uses 24 B entries. |
| R3-L6 | Resolved | The model now removes D with a receive buffer or a due move, restores one snapshot, and starts `PLACE_D` unpersisted. The revision-3 loss it exposed (resolve destroying the endpoint's own unsaved move) is fixed: `resolve` moves any frozen payload whose record is `CLAIMED` at this endpoint, and records are pruned only after the paid endpoint's chunk saved the move (payload-free stub). The `own_move_path` vector passes, and the `resolve-destroys-own-move` and `prune-before-persisted-move` mutations are caught as losses (`[0]`). |
| R3-L7 | Resolved | A control that hits `LIMIT` now fails closed, and there are retirement mutations with all rules on. Nit in R4-L5. |
| R3-I1, R3-I2 | Noted | The opt-out tags stay defence in depth only. The evidence archive is still due at acceptance. |

## 3. Findings (round 4)

### Critical

None.

### High

None.

### Medium

None.

### Low

- **R4-L1 — §11 young tombstones that never settle.**
  - A tombstone is young until its endpoint's absence is seen in a chunk-save or chunk-load tag. A young one takes a place in the owner's 64 and the server's 2,048 endpoints.
  - `endpoint retire` exists for an endpoint "in a chunk that will never load again", so that absence is never observed. The tombstone stays young indefinitely and permanently takes one of the owner's places and one of the server's.
  - `tombstone evict` only evicts settled ones. The same happens to a removal in a chunk whose save never succeeds.
  - Under the freeze rule, evicting an unpinned young tombstone is as safe as evicting a settled one: a returning copy with contents is frozen, and an empty one registers anew.
  - *Fix:* let `endpoint retire` mark its tombstone settled, or let `tombstone evict` remove unpinned young tombstones of operator-retired endpoints.
- **R4-L2 — §9 resolve at a source that never registered a record.**
  - `resolve` returns a frozen outbox entry to the input buffer "only if the ID's tombstone still records `dispatched_through` and `seq` is above it", and otherwise discards it.
  - A source that escrowed but never registered a record has no `dispatched_through`. Take this case: it is removed by a non-player cause, its retirement is flushed, and the server stops before its chunk saved the removal. The restored copy is retired, and `resolve` (or a break) discards its unregistered entry. Yet a tombstone without `dispatched_through` proves the entry was never registered, so the payload is lost unnecessarily (audited).
  - *Fix:* state that every source tombstone records `dispatched_through`, 0 when nothing was registered, and that only an **evicted** tombstone leaves entries unprovable.
  - The `Transit` model cannot show this. It models no source retirement, so a crash-restored source keeps registering as before. `r4_source_retirement_trace.py` gives `(1, 0, False)` on `ESCROW SAVE_S REMOVE_S CRASH`, where the text gives an audited discard. A retired, frozen source and its `resolve` should be added to the model.
- **R4-L3 — §9 IDs frozen for their contents.**
  - A frozen ID that is not retired ("does not register and is `ENDPOINT_RETIRED`") has two gaps. It is unstated whether it enters the tombstone table (and so its owner's caps), and whether it may register once `resolve` has emptied it. "Never registers again" is written for retired IDs.
  - `endpoint purge <id>` removes the index record of a possibly live endpoint. Its next persistence observation then freezes it whenever it holds an outbox entry or an acknowledged, not-yet-dropped receipt.
  - *Fix:* state both outcomes, and refuse `purge` while the endpoint's chunk is loaded or the endpoint holds contents.
- **R4-L4 — §11 stubs while saves are off.** A stub keeps its place among the 256 records until the paid endpoint's chunk saves the move. With `/save-off`, which is common during backups, stubs accumulate, and at 256 every escrow on the server is refused (`TRANSIT_LIMIT`) until saving resumes. The ADR says stubs live "longer only while saves are off" but not that cargo can stop. Add this to the operator guide and budget notes.
- **R4-L5 — `check_mutations.py`.** A mutation whose search hits `LIMIT` counts as "CAUGHT", because any non-empty result does. For mutations, `LIMIT` should count as inconclusive, as it already does for controls. No current mutation hits the limit.

### Info

- **R4-I1 — Verified.**
  - 27 tests pass; the harness has clean controls and catches 23/23 mutations.
  - The accounted maximum is 2,932,736 B and the pin bound 2,816.
  - The new `Redirect` model matches the revision-4 text: freeze on unregistered contents, durable registration for claims, redirect after the durable index removal, `MISSING` settlement, item-by-item resolve, stub pruning, and removal with a buffer or a due move.
  - Its stated limits are acknowledged in the text as residuals or the container class: E is never removed, two copies at once are not modelled, and a mover that bypasses `onRemove` is not modelled with a due move.
- **R4-I2 — Evidence archive.** `root-checks.zip` is still deferred to acceptance.

## 4. Per-ADR verdicts

| ADR | Revision | Verdict | Notes |
|---|---|---|---|
| ADR-053 | 3 (unchanged) | **ACCEPT** | — |
| ADR-054 | 4 | **ACCEPT** | No required change. R4-L1..L4 recommended before freezing. |
| ADR-055 | 3 (unchanged) | **ACCEPT** | — |
| ADR-056 | 4 | **ACCEPT** | Wording only (owner redirect). |
| ADR-057 | 3 (unchanged) | **ACCEPT** | — |
| ADR-058 | 3 (unchanged) | **ACCEPT** | — |
| ADR-059 | 4 | **ACCEPT** | Wording only (R3-L4 redirect route). |

**Counts:** Critical 0, High 0, Medium 0, Low 5, Info 2. No Critical or High finding remains open at the contract level.

## 5. Not verified

- How third-party block movers behave, and their opt-out tag names. The protocol no longer relies on them.
- Runtime behaviour, the flush and MSPT budgets (≤ 60 ms, ≤ 250 ms and ≤ 400 ms flush ticks) and endpoint churn rates. These need C13 on a running server.
- Whether incremental saves always settle a removal's tombstone within one autosave interval on a heavily loaded server. The text relies on vanilla autosave writing every dirty loaded chunk.
- The model checks protocols, not the Java implementation. In particular, the source-side retirement, freeze and resolve are not modelled (R4-L2).

## 6. Artifacts

`check_examples.log`, `check_mutations.log` (mutation copies in `mutations-out/`), `adr-diff.txt`, `model-diff.txt`, `r4_source_retirement_trace.py`/`.log` (R4-L2), `tree/` (reviewed tree).
