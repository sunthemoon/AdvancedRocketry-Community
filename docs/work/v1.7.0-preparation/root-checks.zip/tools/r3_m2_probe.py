import importlib.util, sys
spec = importlib.util.spec_from_file_location("c", "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
T = c.Transit
T.CAP_EVICTION = True
for faults in (0, 1):
    n, out = T.explore(crashes=2, faults=faults)
    print(faults, n, sorted(out.items()))
n, out = T.explore(crashes=2, faults=0, payloads=2)
print("two payloads", n, sorted(out.items()))
# the frozen-copy path
state = T.normalize(T.initial())
path = ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "ARRIVE", "CLAIM", "SAVE_D", "D_ACK", "FLUSH_L", "PRUNE",
        "D_DROP", "SAVE_D", "FLUSH_L", "REMOVE_S", "SAVE_S_LOST", "AGE", "EVICT_HW", "FLUSH_L", "CRASH"]
for label in path:
    options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
    assert label in options, (label, sorted(options))
    state = options[label]
print("frozen path", T.delivered(T.drain(state)), state[0], state[2])
