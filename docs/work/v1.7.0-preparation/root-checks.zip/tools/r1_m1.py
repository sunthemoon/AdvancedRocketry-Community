"""R1-M1: destination-side lost write and the age rule for the move/acknowledgement (model + ADR text)."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")
P = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
s = P.read_text(encoding="utf-8")


def sub(old, new, text=None):
    global s
    assert s.count(old) == 1, old[:110]
    s = s.replace(old, new)


# Signature: successors(state, gated, crashes_left, faults_left=0) -> (label, state, crashes_left, faults_left)
sub("    def successors(cls, state, gated, crashes_left):\n"
    "        rec, rec_dur, e, e_dur, (incoming, buffer, receipt, present, absence), d_dur, p, p_dur, vanilla = state\n",
    "    def successors(cls, state, gated, crashes_left, faults_left=0):\n"
    "        rec, rec_dur, e, e_dur, (incoming, buffer, receipt, present, absence), d_dur, p, p_dur, vanilla = state\n"
    "        c, f = crashes_left, faults_left\n")
# Every `yield "X", make(...), crashes_left` becomes a 4-tuple.
body_start = s.index("    def successors(cls, state, gated, crashes_left, faults_left=0):")
body_end = s.index("    @classmethod\n    def outcome(cls, state, gated):")
body = s[body_start:body_end]
body = body.replace("), crashes_left\n", "), c, f\n").replace("), \\\n                crashes_left\n", "), c, f\n")
body = body.replace("e_dur=e + 1), crashes_left\n", "e_dur=e + 1), c, f\n")
body = body.replace("vanilla or torn)), crashes_left - 1\n", "vanilla or torn)), c - 1, f\n")
s = s[:body_start] + body + s[body_end:]

# Ageing: incoming/receipt flags "U" (unpersisted), "P" (persisted, observed), "A" (observed >= 40 ticks ago).
sub('''        if present and gated and incoming == "P" and (claimed or rec is None or rec[1]):''',
    '''        if present and gated and incoming == "A" and (claimed or rec is None or rec[1]):''')
sub('''        due_move = incoming == "P" and (rec is None or rec[1])''',
    '''        due_move = incoming in ("P", "A") and (rec is None or rec[1])''')
sub('''        if saved != d_dur or receipt == "U" or incoming == "U" or seen != absence:
            yield "SAVE_D", make(d=d(incoming="P" if incoming else 0, receipt=None if receipt is None else "P",
                                     absence=seen), d_dur=saved), c, f''',
    '''        observe = lambda flag: flag if flag in (0, None, "A") else "P"
        if saved != d_dur or receipt == "U" or incoming == "U" or seen != absence:
            yield "SAVE_D", make(d=d(incoming=observe(incoming), receipt=observe(receipt), absence=seen),
                                 d_dur=saved), c, f
            if f:
                # R1-M1: the save is observed (ChunkDataEvent.Save) but its asynchronous file write is lost.
                yield "SAVE_D_LOST", make(d=d(incoming=observe(incoming), receipt=observe(receipt), absence=seen)), \\
                    c, f - 1
        if incoming == "P" or receipt == "P":
            age = lambda flag: "A" if flag == "P" else flag
            yield "AGE_D", make(d=d(incoming=age(incoming), receipt=age(receipt))), c, f''')
sub('''        if present and claimed and receipt == "P" and not incoming:''',
    '''        if present and claimed and receipt == "A" and not incoming:''')
s = s.replace('''        order = ["D_RECOVER", "D_ACK", "D_DROP", "D_REMAT", "PRUNE", "CLAIM", "MOVE", "FLUSH_L",
                 "SAVE_D", "SAVE_P", "REDIRECT"]''', '''        order = ["D_RECOVER", "D_ACK", "D_DROP", "D_REMAT", "PRUNE", "CLAIM", "MOVE", "AGE_D", "FLUSH_L",
                 "SAVE_D", "SAVE_P", "REDIRECT"]''')
sub("            options = {label: s for label, s, _ in cls.successors(state, gated, 0)}\n",
    "            options = {label: s for label, s, _, _ in cls.successors(state, gated, 0)}\n")
sub('''    @classmethod
    def explore(cls, gated, crashes=2):
        seen, stack, outcomes = set(), [(cls.normalize(cls.initial()), crashes)], {}
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            state, left = node
            key = cls.outcome(state, gated)
            outcomes[key] = outcomes.get(key, 0) + 1
            for _, new_state, c in cls.successors(state, gated, left):
                stack.append((new_state, c))
        return len(seen), outcomes''',
    '''    @classmethod
    def explore(cls, gated, crashes=2, faults=0):
        seen, stack, outcomes = set(), [(cls.normalize(cls.initial()), crashes, faults)], {}
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            state, left, faults_left = node
            key = cls.outcome(state, gated) + (faults_left < faults,)
            outcomes[key] = outcomes.get(key, 0) + 1
            for _, new_state, c, f in cls.successors(state, gated, left, faults_left):
                stack.append((new_state, c, f))
        return len(seen), outcomes''')
# Tests: 4-tuple successors and 3-tuple outcome keys.
s = s.replace("{l: s for l, s, _ in Delivery.successors(state, True, 1)}", "{l: s for l, s, *_ in Delivery.successors(state, True, 1)}")
s = s.replace("{l: s for l, s, _ in Delivery.successors(state, False, 1)}", "{l: s for l, s, *_ in Delivery.successors(state, False, 1)}")
s = s.replace("{l: s for l, s, _ in Delivery.successors(gated, True, 1)}", "{l: s for l, s, *_ in Delivery.successors(gated, True, 1)}")
s = s.replace('self.assertNotIn("WITHDRAW", {l for l, _, _ in Delivery.successors(gated, True, 1)})',
              'self.assertNotIn("WITHDRAW", {l for l, *_ in Delivery.successors(gated, True, 1)})')
sub('''        states, outcomes = Delivery.explore(gated=True, crashes=2)
        for (total, torn), _ in outcomes.items():
            if total != 1:
                self.assertTrue(torn, outcomes)  # no duplicate or loss without a container/player torn save
        self.assertEqual(states, EXAMPLES["delivery"]["states_gated_two_crashes"])''',
    '''        states, outcomes = Delivery.explore(gated=True, crashes=2)
        for (total, torn, _), _ in outcomes.items():
            if total != 1:
                self.assertTrue(torn, outcomes)  # no duplicate or loss without a container/player torn save
        self.assertEqual(states, EXAMPLES["delivery"]["states_gated_two_crashes"])

    def test_delivery_lost_write_residual(self):
        # R1-M1: with one lost destination write, a non-torn loss or duplicate needs that fault.
        states, outcomes = Delivery.explore(gated=True, crashes=2, faults=1)
        for (total, torn, faulted), _ in outcomes.items():
            if total != 1 and not torn:
                self.assertTrue(faulted, outcomes)
        self.assertIn((0, False, True), outcomes)  # the documented destination-side loss
        self.assertEqual(states, EXAMPLES["delivery"]["states_gated_two_crashes_one_lost_write"])''')
sub('''        _, outcomes = Delivery.explore(gated=False, crashes=2)
        self.assertIn((2, False), outcomes)''',
    '''        _, outcomes = Delivery.explore(gated=False, crashes=2)
        self.assertIn((2, False, False), outcomes)''')
P.write_text(s, encoding="utf-8", newline="\n")

# Removal cuts now need the age before a move.
g = E / "tools/generate_examples.py"
t = g.read_text(encoding="utf-8")
old = '''"events": ["CLAIM", "SAVE_D", "MOVE", "WITHDRAW", "SAVE_P", "REMOVE_D", "SAVE_D"], "expected": [1, False]},'''
assert t.count(old) == 1
t = t.replace(old, '''"events": ["CLAIM", "SAVE_D", "AGE_D", "MOVE", "WITHDRAW", "SAVE_P", "REMOVE_D", "SAVE_D"],
             "expected": [1, False]},''')
g.write_text(t, encoding="utf-8", newline="\n")

m = E / "tools/mutations.py"
t = m.read_text(encoding="utf-8")
t = t.replace('''    "move-before-persisted": ('if present and gated and incoming == "P" and (claimed or rec is None or rec[1]):',
                              'if present and gated and incoming and (claimed or rec is None or rec[1]):'),''',
              '''    "move-before-persisted": ('if present and gated and incoming == "A" and (claimed or rec is None or rec[1]):',
                              'if present and gated and incoming and (claimed or rec is None or rec[1]):'),''')
t = t.replace("        bad = sorted(k for k in outcomes if k[0] != 1 and not k[1])",
              "        bad = sorted(k for k in outcomes if k[0] != 1 and not k[1])")
m.write_text(t, encoding="utf-8", newline="\n")
print("ok")
