"""R1-H3 model: forced source removal (Transit) and destination removal with un-claim and redirect (Delivery)."""
from pathlib import Path

P = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = P.read_text(encoding="utf-8")


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:100])
    s = s.replace(old, new)


# ---- Transit: an eighth state element (destroyed_live, destroyed_dur) and forced removal of S.
sub("        return (s_live, s_dur, l_live, l_dur, d_live, d_dur, False)\n",
    "        return (s_live, s_dur, l_live, l_dur, d_live, d_dur, False, (0, 0))\n")
sub("        s_live, s_dur, (records, hw, e), (drecords, dhw, de), d_live, d_dur, rollback = state\n",
    "        s_live, s_dur, (records, hw, e), (drecords, dhw, de), d_live, d_dur, rollback, destroyed = state\n")
sub("        return (s_live, s_dur, (remap(records), hw, rank[e]), (remap(drecords), dhw, rank[de]), d_live, d_dur, rollback)\n",
    "        return (s_live, s_dur, (remap(records), hw, rank[e]), (remap(drecords), dhw, rank[de]), d_live, d_dur, rollback,\n"
    "                destroyed)\n")
sub("        s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback = state\n"
    "        s_input, outbox, next_seq, present, absence_seen = s_live\n",
    "        s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback, destroyed = state\n"
    "        s_input, outbox, next_seq, present, absence_seen = s_live\n")
sub("            parts = dict(s_live=s_live, s_dur=s_dur, l_live=l_live, l_dur=l_dur,\n"
    "                         d_live=d_live, d_dur=d_dur, rollback=rollback)\n"
    "            parts.update(changes)\n"
    "            return cls.normalize((parts[\"s_live\"], parts[\"s_dur\"], parts[\"l_live\"], parts[\"l_dur\"],\n"
    "                                  parts[\"d_live\"], parts[\"d_dur\"], parts[\"rollback\"]))\n",
    "            parts = dict(s_live=s_live, s_dur=s_dur, l_live=l_live, l_dur=l_dur,\n"
    "                         d_live=d_live, d_dur=d_dur, rollback=rollback, destroyed=destroyed)\n"
    "            parts.update(changes)\n"
    "            return cls.normalize((parts[\"s_live\"], parts[\"s_dur\"], parts[\"l_live\"], parts[\"l_dur\"],\n"
    "                                  parts[\"d_live\"], parts[\"d_dur\"], parts[\"rollback\"], parts[\"destroyed\"]))\n")
sub("        if present and s_input == 0 and not outbox:\n"
    "            # A player breaks the idle source (allowed: nothing escrowed, nothing in its input buffer).\n"
    "            yield (\"REMOVE_S\", make(s_live=(0, frozenset(), next_seq, False, False)), crashes_left, faults_left)\n",
    "        if present and s_input == 0:\n"
    "            # R1-H3: removal by any cause. Escrowed entries never drop as items: registered ones are delivered\n"
    "            # by the ledger, unregistered ones are destroyed (audited loss). The input buffer is a plain\n"
    "            # container, so the model removes S only when it is empty.\n"
    "            yield (\"REMOVE_S\", make(s_live=(0, frozenset(), next_seq, False, False),\n"
    "                                    destroyed=(destroyed[0] + len(outbox), destroyed[1])), crashes_left, faults_left)\n")
sub("            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq, present, observed), s_dur=saved),\n"
    "                   crashes_left, faults_left)\n",
    "            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq, present, observed), s_dur=saved,\n"
    "                                  destroyed=(destroyed[0], destroyed[0])), crashes_left, faults_left)\n")
sub("        if saved != s_dur or new_outbox != outbox or observed != absence_seen:\n",
    "        if saved != s_dur or new_outbox != outbox or observed != absence_seen or destroyed[0] != destroyed[1]:\n")
sub("        _, s_dur, _, l_dur, _, d_dur, rollback = state\n",
    "        _, s_dur, _, l_dur, _, d_dur, rollback, destroyed = state\n")
sub("        return cls.normalize((s_live, s_dur, l_dur, l_dur, (d_buffer, frozenset((r, True) for r in d_receipts)),\n"
    "                              d_dur, rollback))\n",
    "        return cls.normalize((s_live, s_dur, l_dur, l_dur, (d_buffer, frozenset((r, True) for r in d_receipts)),\n"
    "                              d_dur, rollback, (destroyed[1], destroyed[1])))\n")
sub("        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback = state\n"
    "        assert not outbox and not records and not receipts and s_input == 0, state\n"
    "        return buffer, rollback\n",
    "        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback, destroyed = state\n"
    "        assert not outbox and not records and not receipts and s_input == 0, state\n"
    "        return buffer, destroyed[1], rollback\n")
sub("            buffer, rollback = cls.delivered(cls.drain(state))\n"
    "            outcomes.setdefault((buffer, rollback, faults_left < faults), 0)\n"
    "            outcomes[(buffer, rollback, faults_left < faults)] += 1\n",
    "            key = cls.delivered(cls.drain(state)) + (faults_left < faults,)\n"
    "            outcomes[key] = outcomes.get(key, 0) + 1\n")

# ---- Delivery: presence, removal with un-claim, persisted absence, redirect, ack after the move.
start = s.index("class Delivery:")
end = s.index("# --- ADR-056 railgun classes")
s = s[:start] + '''class Delivery:
    """Destination half of ADR-054 section 11 with a third store: a player who withdraws the payload.

    One payload whose record is already durable and ARRIVED. `gated=True` is revision 2: a claim lands in a
    non-extractable `incoming` area and becomes withdrawable only after its receipt is persisted. `gated=False`
    is the ADR-051 shape the v1.3-v1.6 deep-test report (F02) found duplicating: the claim is extractable at once.
    The destination can be removed by any cause (R1-H3): an unacknowledged claim returns to ARRIVED, and after
    the removal is persisted an owner or operator redirects the record to a new endpoint.

    The `vanilla` flag is set at a crash that tears the ordinary container/player pair, the class every vanilla
    chest has: the player's file already holds the payload while the destination's saved, extractable buffer
    still does, or the player loses unsaved items. Protocol-created duplicates are those without the flag.
    """

    @staticmethod
    def initial():
        record = ("A", False, None)  # state, acked, ack_epoch
        # d: incoming (0, "U", "P"), buffer, receipt (None, "U", "P"), present, absence (False or "seen")
        return (record, record, 1, 1, (0, 0, None, True, False), (0, 0, False, True), 0, 0, False)

    @staticmethod
    def normalize(state):
        rec, rec_dur, e, e_dur, d, d_dur, p, p_dur, vanilla = state
        epochs = {e, e_dur} | {r[2] for r in (rec, rec_dur) if r is not None and r[2] is not None}
        rank = {value: index for index, value in enumerate(sorted(epochs))}
        fix = lambda r: None if r is None else (r[0], r[1], None if r[2] is None else rank[r[2]])
        return (fix(rec), fix(rec_dur), rank[e], rank[e_dur], d, d_dur, p, p_dur, vanilla)

    @classmethod
    def successors(cls, state, gated, crashes_left):
        rec, rec_dur, e, e_dur, (incoming, buffer, receipt, present, absence), d_dur, p, p_dur, vanilla = state

        def make(**c):
            parts = dict(rec=rec, rec_dur=rec_dur, e=e, e_dur=e_dur,
                         d=(incoming, buffer, receipt, present, absence), d_dur=d_dur, p=p, p_dur=p_dur,
                         vanilla=vanilla)
            parts.update(c)
            return cls.normalize(tuple(parts[k] for k in ("rec", "rec_dur", "e", "e_dur", "d", "d_dur", "p",
                                                          "p_dur", "vanilla")))

        def d(**c):
            parts = dict(incoming=incoming, buffer=buffer, receipt=receipt, present=present, absence=absence)
            parts.update(c)
            return tuple(parts[k] for k in ("incoming", "buffer", "receipt", "present", "absence"))

        land = (lambda: d(incoming="U", receipt="U")) if gated else (lambda: d(buffer=buffer + 1, receipt="U"))
        claimed = rec is not None and rec[0] == "C" and not rec[1]
        if present and rec is not None and rec[0] == "A" and receipt is None:
            yield "CLAIM", make(rec=("C", False, None), d=land()), crashes_left
        if present and gated and incoming == "P":
            yield "MOVE", make(d=d(incoming=0, buffer=buffer + 1)), crashes_left
        if present and buffer:
            yield "WITHDRAW", make(d=d(buffer=buffer - 1), p=p + 1), crashes_left
        saved = (1 if incoming else 0, buffer, receipt is not None, present)
        seen = absence or (False if present else "seen")
        if saved != d_dur or receipt == "U" or incoming == "U" or seen != absence:
            yield "SAVE_D", make(d=d(incoming="P" if incoming else 0, receipt=None if receipt is None else "P",
                                     absence=seen), d_dur=saved), crashes_left
        if p != p_dur:
            yield "SAVE_P", make(p_dur=p), crashes_left
        if rec != rec_dur:
            yield "FLUSH_L", make(rec_dur=rec, e=e + 1, e_dur=e + 1), crashes_left
        if present and rec is not None and rec[0] == "A" and receipt is not None:
            yield "D_RECOVER", make(rec=("C", False, None)), crashes_left
        # Acknowledging waits for the move, so incoming payloads always belong to unacknowledged claims.
        if present and claimed and receipt == "P" and not incoming:
            yield "D_ACK", make(rec=("C", True, e)), crashes_left
        if present and claimed and receipt is None:
            yield "D_REMAT", make(d=land()), crashes_left
        if receipt is not None and (rec is None or (rec[1] and e > rec[2])):
            yield "D_DROP", make(d=d(receipt=None)), crashes_left
        if rec is not None and rec[1] and e > rec[2]:
            yield "PRUNE", make(rec=None), crashes_left
        if present and buffer == 0:
            # R1-H3: removal by any cause; incoming payloads and receipts go, the claim returns to ARRIVED.
            yield "REMOVE_D", make(d=(0, 0, None, False, False), rec=("A", False, None) if claimed else rec), \\
                crashes_left
        if not present and absence == "seen" and claimed:
            yield "UNCLAIM_MISSING", make(rec=("A", False, None)), crashes_left
        if not present and absence == "seen" and rec is not None and rec[0] == "A":
            yield "REDIRECT", make(d=(0, 0, None, True, False), d_dur=(0, 0, False, True)), crashes_left
        if crashes_left:
            torn = (p_dur >= 1 and d_dur[0] + d_dur[1] >= 1) or p > p_dur
            yield "CRASH", cls.normalize((rec_dur, rec_dur, e_dur, e_dur,
                                          ("P" if d_dur[0] else 0, d_dur[1], "P" if d_dur[2] else None, d_dur[3],
                                           False if d_dur[3] else "seen"), d_dur,
                                          p_dur, p_dur, vanilla or torn)), crashes_left - 1

    @classmethod
    def outcome(cls, state, gated):
        order = ["D_RECOVER", "D_ACK", "D_DROP", "D_REMAT", "UNCLAIM_MISSING", "PRUNE", "CLAIM", "MOVE", "FLUSH_L",
                 "SAVE_D", "SAVE_P", "REDIRECT"]
        for _ in range(300):
            options = {label: s for label, s, _ in cls.successors(state, gated, 0)}
            chosen = next((label for label in order if label in options), None)
            if chosen is None:
                rec, _, _, _, (incoming, buffer, receipt, present, _), _, p, _, vanilla = state
                assert rec is None and receipt is None and not incoming and present, state
                return buffer + p, vanilla
            state = options[chosen]
        raise AssertionError("delivery drain did not terminate")

    @classmethod
    def explore(cls, gated, crashes=2):
        seen, stack, outcomes = set(), [(cls.normalize(cls.initial()), crashes)], {}
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            state, left = node
            key = cls.outcome(state, gated)
            outcomes[key] = outcomes.get(key, 0) + 1
            for _, new_state, c in cls.successors(state, gated, left):
                stack.append((new_state, c))
        return len(seen), outcomes


''' + s[end:]
P.write_text(s, encoding="utf-8", newline="\n")
print("ok")
