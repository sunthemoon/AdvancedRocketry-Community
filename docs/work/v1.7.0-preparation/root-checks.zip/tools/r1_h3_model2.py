"""R1-H3 model, corrected: removal settles each record from D's live state with a barrier flush; move acknowledges."""
from pathlib import Path

P = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = P.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub('''        if present and gated and incoming == "P":
            yield "MOVE", make(d=d(incoming=0, buffer=buffer + 1)), crashes_left
        if present and buffer:
            yield "WITHDRAW", make(d=d(buffer=buffer - 1), p=p + 1), crashes_left''',
    '''        if present and gated and incoming == "P" and claimed:
            # The move and the acknowledgement are one step (the ledger is updated in the same tick).
            yield "MOVE", make(d=d(incoming=0, buffer=buffer + 1), rec=("C", True, e)), crashes_left
        if present and buffer and p < 3:
            yield "WITHDRAW", make(d=d(buffer=buffer - 1), p=p + 1), crashes_left''')
sub('''        # Acknowledging waits for the move, so incoming payloads always belong to unacknowledged claims.
        if present and claimed and receipt == "P" and not incoming:''',
    '''        # Recovery after a crash that kept D's moved state but lost the ledger's acknowledgement.
        if present and claimed and receipt == "P" and not incoming:''')
sub('''        if present and buffer == 0:
            # R1-H3: removal by any cause; incoming payloads and receipts go, the claim returns to ARRIVED.
            yield "REMOVE_D", make(d=(0, 0, None, False, False), rec=("A", False, None) if claimed else rec), \\
                crashes_left
        if not present and absence == "seen" and claimed:
            yield "UNCLAIM_MISSING", make(rec=("A", False, None)), crashes_left
''',
    '''        if present and buffer == 0:
            # R1-H3: removal by any cause, settled from D's live state and written with a barrier flush. A payload
            # still incoming (or never materialized here) returns its record to ARRIVED; one that moved is
            # acknowledged. The model removes D only with an empty receive buffer, a plain container.
            if rec is not None and not rec[1]:
                settled = ("C", True, e) if receipt is not None and not incoming else ("A", False, None)
            else:
                settled = rec
            yield "REMOVE_D", make(d=(0, 0, None, False, False), rec=settled, rec_dur=settled, e=e + 1,
                                   e_dur=e + 1), crashes_left
''')
sub('''        order = ["D_RECOVER", "D_ACK", "D_DROP", "D_REMAT", "UNCLAIM_MISSING", "PRUNE", "CLAIM", "MOVE", "FLUSH_L",''',
    '''        order = ["D_RECOVER", "D_ACK", "D_DROP", "D_REMAT", "PRUNE", "CLAIM", "MOVE", "FLUSH_L",''')
P.write_text(s, encoding="utf-8", newline="\n")
print("ok")
