import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
D = c.Delivery
target = tuple(int(x) if x.isdigit() else x == "True" for x in sys.argv[1:3])
seen, stack, best = set(), [(D.normalize(D.initial()), 1, ())], None
while stack:
    state, left, path = stack.pop()
    if (state, left) in seen:
        continue
    seen.add((state, left))
    if D.outcome(state, True) == target and (best is None or len(path) < len(best[0])):
        best = (path, state)
    for label, s2, l2 in D.successors(state, True, left):
        stack.append((s2, l2, path + (label,)))
print(best)
