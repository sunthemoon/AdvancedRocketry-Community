"""R3-L6: named own-move path, mutations restoring the revision-3 resolve and prune rules."""
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
PREP = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (path.name, old[:100])
        s = s.replace(old, new)
    path.write_text(s, encoding="utf-8", newline="\n")


patch(PREP / "check_examples.py", [(
    """        states, outcomes = Redirect.explore((True, True, True), crashes=2)
        self.assertEqual(set(outcomes), {1}, outcomes)
        self.assertEqual(states, EXAMPLES["redirect"]["states_full_rules_two_crashes"])
""", """        states, outcomes = Redirect.explore((True, True, True), crashes=2)
        self.assertEqual(set(outcomes), {1}, outcomes)
        self.assertEqual(states, EXAMPLES["redirect"]["states_full_rules_two_crashes"])
        # R3-L6: D moved its payload, the acknowledgement is durable, D is broken and the server stops before D's
        # chunk saved the move. The retired copy that returns still finds the record, so resolve keeps the payload.
        state = Redirect.normalize(Redirect.initial())
        for label in EXAMPLES["redirect"]["own_move_path"]:
            state = {l: s for l, s, _ in Redirect.successors(state, (True, True, True), 1)}[label]
        self.assertEqual(Redirect.outcome(state, (True, True, True)), 1)
""")])

patch(TOOLS / "generate_examples.py", [(
    """                       "PLACE_D", "SAVE_D", "REREGISTER_D", "MOVE_D"],
""", """                       "PLACE_D", "SAVE_D", "REREGISTER_D", "MOVE_D"],
        "own_move_path": ["CLAIM_D", "SAVE_D", "MOVE_D", "FLUSH_L", "REMOVE_D", "CRASH"],
""")])

patch(PREP / "check_mutations.py", [
    ("""    "resolve-moves-any-copy": (
        'if d_in and rec is not None and rec[0] == "C" and rec[1] == "D" and not rec[2]:',
        'if d_in:'),
}
""", """    "resolve-moves-any-copy": (
        'if d_in and rec is not None and rec[0] == "C" and rec[1] == "D":',
        'if d_in:'),
    # Revision 3's resolve and prune rules (review R3-L6): the retired copy's own move is destroyed.
    "resolve-destroys-own-move": (
        'if d_in and rec is not None and rec[0] == "C" and rec[1] == "D":',
        'if d_in and rec is not None and rec[0] == "C" and rec[1] == "D" and not rec[2]:'),
    "prune-before-persisted-move": (
        'and e > rec[3] and not (d_dur[1] if rec[1] == "D" else ee_dur[0]):',
        'and e > rec[3]:'),
}
"""),
])
print("ok")
