"""Round 2 Lows L2, L4, L5, L7, L9, L10 and Infos I3, I4."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    # L9
    ("5. **Spawn protection.** The batch box does not intersect the vanilla spawn\n"
     "   protection square (a dedicated server's configured radius around the\n"
     "   Overworld spawn), tested once per box, else `TARGET_PROTECTED`. Unlike the\n"
     "   vanilla player check it is not bypassed when the device owner is an\n"
     "   operator, and it does not depend on the operator list being empty.\n",
     "5. **Spawn protection.** On a dedicated server the batch box does not intersect\n"
     "   the vanilla spawn protection square (the configured `spawn-protection`\n"
     "   radius around the Overworld spawn), tested once per box, else\n"
     "   `TARGET_PROTECTED`. Unlike the vanilla player check it is not bypassed when\n"
     "   the device owner is an operator, and it does not depend on the operator list\n"
     "   being empty. Integrated and LAN servers have no protected square, as in\n"
     "   vanilla, whose check always passes there (review R2-L9).\n"),
    # L5
    ("  `MinecraftForge.EVENT_BUS` on the server thread only, with `systemId()`\n"
     "  (`ResourceLocation`), `effect()`, `ownerId()` (`UUID`), `level()`\n"
     "  (`ResourceKey<Level>`), `min()` and `max()` (`BlockPos`, the batch box).\n",
     "  `MinecraftForge.EVENT_BUS` on the server thread only, with `systemId()`\n"
     "  (`ResourceLocation`), `effect()`, `ownerId()` (`UUID`: the owner of the device\n"
     "  that causes the effect; for `TELEPORT` the departing endpoint's owner),\n"
     "  `actorId()` (`Optional<UUID>`: the player whose intent caused it, such as\n"
     "  the rider of a ride, or empty for autonomous work; review R2-L5), `level()`\n"
     "  (`ResourceKey<Level>`), `min()` and `max()` (`BlockPos`, the batch box).\n"),
    # L10 + L2
    ("**Barrier spacing.** Player-triggered barrier flushes (elevator bind and\n"
     "unbind) share one server-wide spacing of 20 ticks and a per-station cooldown of\n"
     "100 ticks; a request inside either is refused with `ROOT_BUSY` before anything\n"
     "changes, as ADR-041's checked-write spacing does for stations. Barrier flushes\n"
     "that cannot wait (removal settlement, §9.1) and operator actions are exempt and\n"
     "counted in `/arce endgame status`.\n",
     "**Barrier spacing.** Player-triggered barrier flushes that grow or change\n"
     "state (elevator binds and owner redirects) share one server-wide spacing of 20\n"
     "ticks and a per-station cooldown of 100 ticks; a request inside either is\n"
     "refused with `ROOT_BUSY` before anything changes, as ADR-041's checked-write\n"
     "spacing does for stations. **Unbinding is never refused** (ADR-045 requires it\n"
     "to be always possible; it only shrinks the root): it is exempt from the\n"
     "spacing and cooldown but counts toward the spacing of the next bind (review\n"
     "R2-L10). Barrier flushes that cannot wait (removal settlement, §9.1) and\n"
     "operator actions are exempt and counted in `/arce endgame status`. A removal\n"
     "runs a barrier only when something must be settled (an incoming payload, an\n"
     "unacknowledged receipt or a registered entry whose record is not durable);\n"
     "because endpoints refuse pistons and opt out of the common movers, removals of\n"
     "busy endpoints in bulk come only from operator tools such as `/fill`, one\n"
     "flush each (review R2-L2).\n"),
    # L7
    ("  `ENDGAME`, so ordinary saves, barrier flushes and the save epoch use the same\n"
     "  replace-and-read-back path;\n",
     "  `ENDGAME`, so ordinary saves, barrier flushes and the save epoch use the same\n"
     "  replace-and-read-back path; the migrator's `format_epoch` check, which today\n"
     "  starts at the global schema 2, becomes type-aware so that the `ENDGAME` root's\n"
     "  epoch is checked at its schema 1 (review R2-L7);\n"),
])
patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    # L4
    ("  rides per endpoint and 64 on the server.\n",
     "  rides per endpoint and 64 on the server. Before adding the pre-load ticket the\n"
     "  request re-derives the pair's validity (§3); after a cancelled ride the rider\n"
     "  waits 100 ticks before the next request, so stepping on and off the platform\n"
     "  cannot churn chunk loads (review R2-L4).\n"),
])
print("ok")
