"""Deep-test finding F02 applied to ADR-054 section 11: claimed cargo stays non-extractable until persisted."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")
reps = [
    ("**Delivery.** At `arrive_at` the record becomes `ARRIVED` (due queue). D claims\n"
     "it automatically during its reconciliation pass, or on a withdraw intent, when:\n"
     "the record is durable, D's ID is persisted, D's receive buffer has room for the\n"
     "whole payload, and D has a free receipt slot (≤ 64). In one tick the record\n"
     "becomes `CLAIMED` with `paid_endpoint = D`, and D gains the payload and an\n"
     "unpersisted receipt `(source, seq)`.\n",
     "**Delivery.** At `arrive_at` the record becomes `ARRIVED` (due queue). D claims\n"
     "it automatically during its reconciliation pass, or on a withdraw intent, when:\n"
     "the record is durable, D's ID is persisted, D's receive buffer has room for the\n"
     "whole payload beyond what its incoming payloads already reserve, and D has a\n"
     "free receipt slot (≤ 64). In one tick the record becomes `CLAIMED` with\n"
     "`paid_endpoint = D`, and D gains an unpersisted receipt `(source, seq)` and the\n"
     "payload in its **incoming** area.\n\n"
     "**Incoming gate** (answers finding F02 of the external v1.3–v1.6 deep-test report\n"
     "of 2026-10-01, which reproduced a duplicate in ADR-051's terminal delivery after\n"
     "a player withdrew a reward that the terminal's chunk had not yet saved). Incoming\n"
     "payloads are not extractable by players, menus or automation, are not dropped\n"
     "when the block is broken (breaking is refused while any exist, §9), and count\n"
     "against the receive buffer's room. A payload moves from incoming into the\n"
     "extractable receive buffer, in one tick inside D, only after a\n"
     "`ChunkDataEvent.Save` or `ChunkDataEvent.Load` tag of D's chunk is observed to\n"
     "contain it (§2's persistence rule). Until then a crash can only lose D's copy\n"
     "together with its receipt, and the record rematerializes it into incoming; no\n"
     "third store (a player, a hopper, another container) can already hold it. After\n"
     "the move, the receive buffer is an ordinary container: a crash that saves a\n"
     "player's file after a withdrawal but not D's chunk duplicates the withdrawn\n"
     "items, exactly as for any vanilla chest. That container class is listed as a\n"
     "residual below; v1.7 adds no window beyond it.\n"),
    ("receipt acknowledges; missing receipt for an unacknowledged claim at D\n"
     "rematerializes once (`REMATERIALIZED`, waiting while full); a receipt is dropped\n",
     "receipt acknowledges; missing receipt for an unacknowledged claim at D\n"
     "rematerializes once into incoming (`REMATERIALIZED`, waiting while full); a\n"
     "receipt is dropped\n"),
    ("| Claim: ledger flushed, D not | `CLAIMED`, no receipt | Rematerialized once |\n",
     "| Claim: ledger flushed, D not | `CLAIMED`, no receipt | Rematerialized once into incoming; nothing was withdrawable before the lost save |\n"
     "| Claim persisted, payload moved and withdrawn, player file saved, D's chunk not saved again | D's incoming or buffer still holds the payload; the player holds it too | **Residual**, the ordinary container/player torn save of every vanilla chest; the model shows no other duplicate or loss path |\n"),
]
for old, new in reps:
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)
p.write_text(s, encoding="utf-8", newline="\n")

# Section 9 break refusal names incoming payloads explicitly.
s = p.read_text(encoding="utf-8")
old = ("non-operators while it holds an outbox entry, an unacknowledged receipt or an\n"
       "  elevator pair (`ENDPOINT_BUSY`).")
new = ("non-operators while it holds an outbox entry, an incoming payload, an\n"
       "  unacknowledged receipt or an elevator pair (`ENDPOINT_BUSY`).")
assert s.count(old) == 1, "section 9"
p.write_text(s.replace(old, new), encoding="utf-8", newline="\n")
print("ok")
