"""R1-M3: per-action authority overrides for the elevator, selection by device owner, vectors."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(path, pairs):
    p = path
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("- `VIEW` of public status never includes a target, a coordinate, an owner name or\n"
     "  another device's ID.\n\n### 4. Intents and network\n",
     "- `VIEW` of public status never includes a target, a coordinate, an owner name or\n"
     "  another device's ID.\n\n"
     "**Per-action overrides** (review R1-M3). These replace the table above for the\n"
     "named actions only; `EndgameAuthority` evaluates them first.\n\n"
     "| Action | Allowed for | Extra condition |\n"
     "|---|---|---|\n"
     "| Elevator `RIDE` and `SHIP`, at either endpoint of a pair | Station owner, station members, operators (station `VISIT`, the rocket rule) | The pair's anchor owner is the station's current owner or a current member, else `ANCHOR_OWNER_NOT_MEMBER` (operators exempt). An ownership transfer or a removed membership therefore stops traffic into the anchor owner's base without that owner's consent |\n"
     "| Elevator `BIND` | Station owner or operator, at the terminal | The anchor is the actor's own; operators may pick any (ADR-059 §3) |\n"
     "| Elevator `UNBIND` | Station owner, anchor owner, operators | From either endpoint's menu or the command, whatever the pair's validity (ADR-045) |\n"
     "| `CONFIGURE` by a station owner of a device someone else owns | Station owner | Selection lists show the **device owner's** endpoints (below), not the station owner's |\n\n"
     "### 4. Intents and network\n"),
    ("- **Selection.** A player selects only their **own** `ACTIVE` endpoints of a\n"
     "  compatible kind, from a server-side list filtered by the system's route rule\n"
     "  and sorted in ID order (§7). Operators can select any endpoint. The owner sees\n"
     "  the endpoint's Level, position and body; others see nothing.\n",
     "- **Selection.** A selection list holds only `ACTIVE` endpoints of a compatible\n"
     "  kind owned by the **device's owner**, filtered by the system's route rule and\n"
     "  sorted in ID order (§7); whoever is allowed to `CONFIGURE` the device (§3)\n"
     "  picks from it. Operators can select any endpoint. The device owner, the\n"
     "  station owner where §3 allows `CONFIGURE`, and operators see the endpoint's\n"
     "  Level, position and body; others see nothing.\n"),
])
patch(REPO / "docs/decisions/ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("Riding and shipping need the station's `VISIT` access (owner, members,\n"
     "operators), the same rule as flying a rocket to the station; configuration and\n"
     "binding need the station owner or an operator; the anchor owner may also ship\n"
     "and unbind.\n",
     "ADR-054 §3's per-action overrides apply (review R1-M3): riding and shipping\n"
     "need the station's `VISIT` access (owner, members, operators), the rocket rule,\n"
     "and the anchor owner must be the station's current owner or a member\n"
     "(`ANCHOR_OWNER_NOT_MEMBER`, operators exempt); binding needs the station owner\n"
     "or an operator; unbinding is open to the station owner, the anchor owner and\n"
     "operators.\n"),
    ("rules 1, 3, 4 and 5 (rule 2 is the actor's, checked per action), the stored\n",
     "rules 1, 3, 4 and 5 (ADR-045's owner-only rule 2 is replaced, per action, by\n"
     "ADR-054 §3's overrides, so members can ride and automation can ship), the stored\n"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ("def authority(case):\n"
     "    actor, action = case[\"actor\"], case[\"action\"]\n"
     "    if actor == \"operator\":\n"
     "        return True\n",
     "def authority(case):\n"
     "    actor, action = case[\"actor\"], case[\"action\"]\n"
     "    if actor == \"operator\":\n"
     "        return True\n"
     "    if action in (\"RIDE\", \"SHIP\"):  # ADR-054 section 3 per-action overrides (R1-M3)\n"
     "        return actor in (\"station_owner\", \"station_member\") and case[\"anchor_owner_in_station\"]\n"
     "    if action == \"BIND\":\n"
     "        return actor == \"station_owner\"\n"
     "    if action == \"UNBIND\":\n"
     "        return actor in (\"station_owner\", \"anchor_owner\")\n"),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ("        {\"actor\": \"stranger\", \"action\": \"VIEW\", \"station\": {\"owner_build_access\": True}, \"allowed\": False},\n"
     "    ],\n",
     "        {\"actor\": \"stranger\", \"action\": \"VIEW\", \"station\": {\"owner_build_access\": True}, \"allowed\": False},\n"
     "        {\"actor\": \"station_member\", \"action\": \"RIDE\", \"anchor_owner_in_station\": True, \"allowed\": True},\n"
     "        {\"actor\": \"station_member\", \"action\": \"RIDE\", \"anchor_owner_in_station\": False, \"allowed\": False},\n"
     "        {\"actor\": \"station_owner\", \"action\": \"SHIP\", \"anchor_owner_in_station\": False, \"allowed\": False},\n"
     "        {\"actor\": \"operator\", \"action\": \"RIDE\", \"anchor_owner_in_station\": False, \"allowed\": True},\n"
     "        {\"actor\": \"stranger\", \"action\": \"RIDE\", \"anchor_owner_in_station\": True, \"allowed\": False},\n"
     "        {\"actor\": \"anchor_owner\", \"action\": \"UNBIND\", \"allowed\": True},\n"
     "        {\"actor\": \"station_member\", \"action\": \"UNBIND\", \"allowed\": False},\n"
     "        {\"actor\": \"station_owner\", \"action\": \"BIND\", \"allowed\": True},\n"
     "        {\"actor\": \"anchor_owner\", \"action\": \"BIND\", \"allowed\": False},\n"
     "    ],\n"),
])
print("ok")
