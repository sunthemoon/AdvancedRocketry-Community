"""R3-M2 in the Transit model: capped tombstone eviction after a saved absence, freeze of a returning copy."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = p.read_text(encoding="utf-8")


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:100])
    s = s.replace(old, new)


sub("""    MAX_SEQ = 4
    # R1-H1: tombstone removal needs an aged absence; tests switch it off to separate the residual.
    TOMBSTONE_REMOVAL = True
""", """    MAX_SEQ = 4
    # R1-H1: tombstone removal needs an aged absence; tests switch it off to separate the residual.
    TOMBSTONE_REMOVAL = True
    # R3-M2: the tombstone caps may evict an unpinned tombstone once the source's absence was observed in a
    # chunk-save tag; a test switches this adversary on. An evicted tombstone is ("X", dispatched_through): the
    # protocol no longer knows the ID, the model keeps the value only to account a frozen copy's entries.
    CAP_EVICTION = False
""")
sub("""        d_dur = (0, frozenset())
        return (s_live, s_dur, l_live, l_dur, d_live, d_dur, False, (0, 0))
""", """        d_dur = (0, frozenset())
        return (s_live, s_dur, l_live, l_dur, d_live, d_dur, False, (0, 0), 0)
""")
sub("""        s_live, s_dur, (records, hw, e), (drecords, dhw, de), d_live, d_dur, rollback, destroyed = state
""", """        s_live, s_dur, (records, hw, e), (drecords, dhw, de), d_live, d_dur, rollback, destroyed, returned = state
""")
sub("""        return (s_live, s_dur, (remap(records), hw, rank[e]), (remap(drecords), dhw, rank[de]), d_live, d_dur, rollback,
                destroyed)
""", """        return (s_live, s_dur, (remap(records), hw, rank[e]), (remap(drecords), dhw, rank[de]), d_live, d_dur, rollback,
                destroyed, returned)
""")
sub("""        s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback, destroyed = state
        s_input, outbox, next_seq, present, absence_seen = s_live
        records, hw, e = l_live
        hw_value = 0 if hw is None else hw  # None: the tombstone was removed
""", """        s_live, s_dur, l_live, l_dur, d_live, d_dur, rollback, destroyed, returned = state
        s_input, outbox, next_seq, present, absence_seen = s_live
        records, hw, e = l_live
        hw_value = 0 if hw is None or isinstance(hw, tuple) else hw  # None: removed; a tuple: evicted (R3-M2)
""")
sub("""            parts = dict(s_live=s_live, s_dur=s_dur, l_live=l_live, l_dur=l_dur,
                         d_live=d_live, d_dur=d_dur, rollback=rollback, destroyed=destroyed)
            parts.update(changes)
            return cls.normalize((parts["s_live"], parts["s_dur"], parts["l_live"], parts["l_dur"],
                                  parts["d_live"], parts["d_dur"], parts["rollback"], parts["destroyed"]))
""", """            parts = dict(s_live=s_live, s_dur=s_dur, l_live=l_live, l_dur=l_dur,
                         d_live=d_live, d_dur=d_dur, rollback=rollback, destroyed=destroyed)
            parts.update(changes)
            return cls.normalize((parts["s_live"], parts["s_dur"], parts["l_live"], parts["l_dur"],
                                  parts["d_live"], parts["d_dur"], parts["rollback"], parts["destroyed"], returned))
""")
sub("""        if present and not rollback_pending and s_input > 0 and len(outbox) < 4 and next_seq <= cls.MAX_SEQ:
""", """        # R3-H1: escrow needs S's registration to be durable (after a re-registration the ledger file must say so).
        if present and not rollback_pending and s_input > 0 and len(outbox) < 4 and next_seq <= cls.MAX_SEQ \\
                and not isinstance(l_dur[1], tuple):
""")
sub("""        # R2-L1: only a chunk-load tag after a start (the crash below) observes an absence for tombstones.
        observed = absence_seen
""", """        # R2-L1: only a chunk-load tag after a start (the crash below) observes an absence for housekeeping. The
        # caps (R3-M2) also accept a chunk-save tag, observed even when its asynchronous write is lost.
        observed = "saved" if cls.CAP_EVICTION and not present and absence_seen is False else absence_seen
""")
sub("""        if any(o[1] and not o[2] for o in outbox) or absence_seen == "seen":
            yield ("AGE", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq,
                                       present, "aged" if absence_seen else False)), crashes_left, faults_left)
""", """        if any(o[1] and not o[2] for o in outbox) or absence_seen in ("seen", "saved"):
            aged_absence = {"seen": "aged", "saved": "saved_aged"}.get(absence_seen, absence_seen)
            yield ("AGE", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq,
                                       present, aged_absence)), crashes_left, faults_left)
""")
sub("""            yield ("DROP_HW", make(l_live=(records, None, e)), crashes_left, faults_left)
""", """            yield ("DROP_HW", make(l_live=(records, None, e)), crashes_left, faults_left)
        if cls.CAP_EVICTION and isinstance(hw, int) and not present and absence_seen in ("saved_aged", "aged") \\
                and not records:
            # R3-M2: a cap evicts an unpinned tombstone (no record names S) whose absence a save tag observed.
            yield ("EVICT_HW", make(l_live=(records, ("X", hw), e)), crashes_left, faults_left)
""")
sub("""    @classmethod
    def crash(cls, state):
        _, s_dur, _, l_dur, _, d_dur, rollback, destroyed = state
        s_input, out_seqs, next_seq, present = s_dur
        # After restart the chunk load is a persistence observation; ageing restarts.
        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, present,
                  False if present else "seen")
        d_buffer, d_receipts = d_dur
        return cls.normalize((s_live, s_dur, l_dur, l_dur, (d_buffer, frozenset((r, True) for r in d_receipts)),
                              d_dur, rollback, (destroyed[1], destroyed[1])))
""", """    @classmethod
    def crash(cls, state):
        _, s_dur, _, l_dur, _, d_dur, rollback, destroyed, returned = state
        s_input, out_seqs, next_seq, present = s_dur
        # After restart the chunk load is a persistence observation; ageing restarts.
        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, present,
                  False if present else "seen")
        l_live = l_dur
        destroyed = (destroyed[1], destroyed[1])
        records, hw, e = l_dur
        if present and isinstance(hw, tuple):
            # S returns although its tombstone was evicted (only after a lost write of the save that observed its
            # absence). Registration reads the tag (ADR-054 section 9, R3-H1): with outbox entries the ID is frozen
            # and an operator resolve discards them, because no tombstone proves them unregistered; the model
            # counts those above the evicted dispatched_through as destroyed and hands the input back to the
            # player. With no outbox entries the ID registers anew, with no dispatched_through.
            if out_seqs:
                lost = destroyed[1] + sum(1 for seq in out_seqs if seq > hw[1])
                destroyed, returned = (lost, lost), returned + s_input
                s_dur = (0, frozenset(), next_seq, False)
                s_live = (0, frozenset(), next_seq, False, "aged")
            else:
                l_live = (records, 0, e)
        d_buffer, d_receipts = d_dur
        return cls.normalize((s_live, s_dur, l_live, l_dur, (d_buffer, frozenset((r, True) for r in d_receipts)),
                              d_dur, rollback, destroyed, returned))
""")
sub("""        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback, destroyed = state
        assert not outbox and not records and not receipts and s_input == 0, state
        return buffer, destroyed[1], rollback
""", """        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback, destroyed, returned = state
        assert not outbox and not records and not receipts and s_input == 0, state
        # A payload handed back to the player by a frozen copy counts as delivered: it exists once.
        return buffer + returned, destroyed[1], rollback
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
