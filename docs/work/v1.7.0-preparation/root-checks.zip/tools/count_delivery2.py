import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for gated, crashes, faults in ((True, 2, 0), (True, 2, 1), (False, 2, 0)):
    print("gated" if gated else "ungated", crashes, faults, c.Delivery.explore(gated, crashes, faults), flush=True)
