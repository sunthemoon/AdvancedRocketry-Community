import sys, time
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for cr, f, p in ((2, 0, 1), (2, 1, 1), (2, 0, 2)):
    t = time.time()
    print(cr, f, p, c.Transit.explore(crashes=cr, faults=f, payloads=p), round(time.time() - t, 1), flush=True)
