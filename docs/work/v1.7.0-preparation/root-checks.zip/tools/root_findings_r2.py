"""Root's own findings S1-S3, applied for revision 2 (recorded in review-01-dispositions.md)."""
from pathlib import Path

ROOT = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = ROOT / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:70])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-055-ORBITAL-LASER-DRILL.md", [
    ("`ops_done += 1`, all in one tick. Each crash therefore leaves at most one\n"
     "unpaid or prepaid layer, and the next contact settles it.",
     "`ops_done += 1`, all in one tick. After a crash the gap between the two counters\n"
     "is at most the number of layers run between the two chunks' latest saves\n"
     "(normally a few seconds of cadence), and the next contact settles all of it."),
    ("   (no tool, no fortune). If the marker buffer cannot take **all** of them,",
     "   (no tool, no fortune). Harvest-tool requirements are not applied: a laser\n"
     "   cuts any breakable block, as in the legacy drill (a balance decision). If the\n"
     "   marker buffer cannot take **all** of them,"),
])
patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("  3. obtain the arrival chunk at `FULL` the way a vanilla teleport does, at the\n"
     "     **server-derived** arrival position (the centre of the other endpoint's\n"
     "     platform), never from a client value;",
     "  3. load the arrival chunk synchronously with `ServerLevel.getChunk(cx, cz)`\n"
     "     at the **server-derived** arrival position (the centre of the other\n"
     "     endpoint's platform), never from a client value. The chunk already exists\n"
     "     on disk, because the endpoint was built in it, so this reads it and\n"
     "     generates nothing; it adds no ticket of its own;"),
])
patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("no chunk. The only chunk access caused by an endgame action is the arrival of an\n",
     "no chunk. The only chunk load caused by an endgame action is the arrival check of an\n"),
])
print("ok")
