import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for retire in (True, False):
    for crashes in (0, 1, 2):
        print("retire" if retire else "no-retire", crashes, c.Redirect.explore(retire, crashes), flush=True)
