"""R2-M1 + R2-L6: player-side trust for fields outside stations; station fields capped at 1.00 g."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-058-AREA-GRAVITY-CONTROLLER.md", [
    ("  - inside a committed station region the field affects every player in its\n"
     "    clipped box, as the station's own gravity does: it is the station owner's\n"
     "    space and the field must belong to the station owner (§3);\n"
     "  - everywhere else a field affects only its owner and the players on its\n"
     "    **allow list** (at most 16 UUIDs, stored in the controller's root). The\n"
     "    owner edits it with `/arce endgame field allow <player>` and `field deny\n"
     "    <player>` from their own connected command source while looking at the\n"
     "    controller within 5 blocks (the warp-core rule, ADR-044 §4). Everyone else\n"
     "    keeps the station or Level gravity inside the box.\n",
     "  - inside a committed station region the field affects every player in its\n"
     "    clipped box, as the station's own gravity does: it is the station owner's\n"
     "    space and the field must belong to the station owner (§3). Its effective\n"
     "    value there is capped at 1.00 g, the top of ADR-041's station command range,\n"
     "    so a field can never impose more than the station owner could already set\n"
     "    for the whole station (review R2-L6);\n"
     "  - everywhere else a field affects only its owner and players who **trust**\n"
     "    that owner (review R2-M1): consent is the affected player's own choice. A\n"
     "    player manages it with `/arce endgame field trust <player>`, `field untrust\n"
     "    <player>` and `field trusted`, from their own connected command source only;\n"
     "    the list holds at most 32 owner UUIDs and is stored under\n"
     "    `Player.PERSISTED_NBT_TAG` in the player's persistent data, which Forge\n"
     "    keeps across death. Untrusting takes effect on the next tick. Everyone else\n"
     "    keeps the station or Level gravity inside the box.\n"),
    ("| Trapping or hurting players (2.00 g blocks a one-block jump, 0.10 g jumps cost fall damage) | Outside stations only the owner and an allow list are affected; inside stations only the station owner's own fields; no lateral force; box ≤ 33³ |",
     "| Trapping or hurting players (2.00 g blocks a one-block jump, 0.10 g jumps cost fall damage) | Outside stations only the owner and players who trust the owner, by their own command, are affected; inside stations only the station owner's own fields, capped at 1.00 g; no lateral force; box ≤ 33³ |"),
    ("- A1: on a planet, the owner and an allowed player get the field's value and\n"
     "  another player in the same box keeps the Level gravity; `field allow|deny`\n"
     "  edits the list only from the owner looking at the controller; on a station,\n"
     "  every player in the box gets it; a member\n",
     "- A1: on a planet, the owner and a player who trusts the owner get the field's\n"
     "  value and another player in the same box keeps the Level gravity; `field\n"
     "  trust|untrust` changes only the issuing player's own list and survives death;\n"
     "  on a station, every player in the box gets the value capped at 1.00 g; a member\n"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ('''def field_affects(case):
    """R1-M9: inside a station region everyone; elsewhere the owner and the allow list."""
    return case["in_station"] or case["player"] == case["owner"] or case["player"] in case["allow"]''',
     '''def field_affects(case):
    """R2-M1: inside a station region everyone; elsewhere the owner and players who trust the owner."""
    return case["in_station"] or case["player"] == case["owner"] or case["owner"] in case["player_trusts"]


def field_value(case):
    """R2-L6: inside a station region the value is capped at 1.00 g (100 hundredths)."""
    return min(case["m"], 100) if case["in_station"] else case["m"]'''),
    ('''        for case in data["consent"]:
            self.assertEqual(field_affects(case), case["affected"], case)''',
     '''        for case in data["consent"]:
            self.assertEqual(field_affects(case), case["affected"], case)
            self.assertEqual(field_value(case), case["value"], case)'''),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ('''        "consent": [
            {"in_station": True, "owner": "a", "player": "b", "allow": [], "affected": True},
            {"in_station": False, "owner": "a", "player": "a", "allow": [], "affected": True},
            {"in_station": False, "owner": "a", "player": "b", "allow": [], "affected": False},
            {"in_station": False, "owner": "a", "player": "b", "allow": ["b"], "affected": True},
        ],''',
     '''        "consent": [
            {"in_station": True, "owner": "a", "player": "b", "player_trusts": [], "m": 200, "affected": True, "value": 100},
            {"in_station": True, "owner": "a", "player": "b", "player_trusts": [], "m": 50, "affected": True, "value": 50},
            {"in_station": False, "owner": "a", "player": "a", "player_trusts": [], "m": 200, "affected": True, "value": 200},
            {"in_station": False, "owner": "a", "player": "b", "player_trusts": [], "m": 200, "affected": False, "value": 200},
            {"in_station": False, "owner": "a", "player": "b", "player_trusts": ["a"], "m": 10, "affected": True, "value": 10},
            {"in_station": False, "owner": "a", "player": "b", "player_trusts": ["c"], "m": 10, "affected": False, "value": 10},
        ],'''),
])
print("ok")
