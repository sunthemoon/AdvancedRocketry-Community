"""R1-M11: numeric budgets, flush-cost gate, barrier spacing."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs")


def patch(rel, pairs):
    p = D / rel
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (rel, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("chunks. C13 measures all three places against total tick time, because Forge\n"
     "records `tickTimes` before END handlers run (§7 budgets).\n",
     "chunks. C13 measures all three places against total tick time, because Forge\n"
     "records `tickTimes` before END handlers run (§7 budgets).\n\n"
     "**Budgets** (review R1-M11). Caps alone are not budgets; these are measured, not\n"
     "assumed. The **endgame reference load** is: 16 logical and 4 physical laser\n"
     "drills, 32 railguns with 16 launching every 20 ticks, 16 burning black-hole\n"
     "generators, 64 active fields with 20 players inside them, 8 elevator pairs\n"
     "with 4 rides per minute, 512 transit records, 4,096 endpoints and 8,192\n"
     "tombstones, on top of the docs/17 §4 reference load.\n\n"
     "| Budget | Limit |\n"
     "|---|---|\n"
     "| All endgame work, systems loaded and idle | mean ≤ 0.1 ms per tick |\n"
     "| All endgame work at the endgame reference load | mean ≤ 2.0 ms, P99 ≤ 8 ms per tick |\n"
     "| Share per system at that load | laser drills ≤ 0.8 ms; ledger passes (railgun and elevator cargo) ≤ 0.5 ms; black-hole generators ≤ 0.2 ms; field lookups ≤ 0.3 ms; rides ≤ 0.2 ms (means) |\n"
     "| One barrier flush of a root at the 4 MiB bound | ≤ 50 ms |\n"
     "| Memory | root ≤ 4 MiB encoded and ≤ 32 MiB of accounted heap; field index ≤ 1,024 entries; audit ring 512 lines; one device view ≤ 8 KiB per open menu |\n"
     "| Tickets | none persistent; ride-arrival tickets ≤ 64 (§12) |\n\n"
     "These totals stay inside docs/17 §4 (mean ≤ 25 ms for the whole server). A\n"
     "budget that C13 cannot meet keeps the version blocked; in particular a barrier\n"
     "flush over 50 ms at the bound requires a follow-up ADR that moves the write to\n"
     "a writer thread with separate snapshot and durable epochs, as ADR-050 §2\n"
     "requires for the satellite registry. The Windows development host gives\n"
     "provisional numbers; the reference hardware run is `[H]`.\n\n"
     "**Barrier spacing.** Player-triggered barrier flushes (elevator bind and\n"
     "unbind) share one server-wide spacing of 20 ticks and a per-station cooldown of\n"
     "100 ticks; a request inside either is refused with `ROOT_BUSY` before anything\n"
     "changes, as ADR-041's checked-write spacing does for stations. Barrier flushes\n"
     "that cannot wait (removal settlement, §9.1) and operator actions are exempt and\n"
     "counted in `/arce endgame status`.\n"),
])
patch("work/v1.7.0-contract-coverage.md", [
    ("| §13 per-system MSPT/memory/chunk-ticket budget | ADR-054 §7 (END handler measured separately), §12; per-ADR caps | A1, performance; reference hardware `[H]` | C13 |",
     "| §13 per-system MSPT/memory/chunk-ticket budget | ADR-054 §7 budget table (endgame reference load, per-system shares, flush gate, memory, tickets), §12 | A1, performance; reference hardware `[H]` | C13 |"),
])
print("ok")
