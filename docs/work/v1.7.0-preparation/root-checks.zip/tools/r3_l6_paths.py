import importlib.util
from collections import deque
spec = importlib.util.spec_from_file_location("c", "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
R = c.Redirect
rules = (True, True, True)
start = (R.normalize(R.initial()), 2)
seen = {start: None}
queue = deque([start])
found = {}
while queue and len(found) < 4:
    node = queue.popleft()
    state, left = node
    try:
        k = R.outcome(state, rules)
    except AssertionError:
        k = "stuck"
    if k != 1 and k not in found:
        path = []
        n = node
        while seen[n] is not None:
            n, label = seen[n]
            path.append(label)
        found[k] = list(reversed(path))
        print(k, found[k])
    for label, s2, c2 in R.successors(state, rules, left):
        nn = (s2, c2)
        if nn not in seen:
            seen[nn] = (node, label)
            queue.append(nn)
