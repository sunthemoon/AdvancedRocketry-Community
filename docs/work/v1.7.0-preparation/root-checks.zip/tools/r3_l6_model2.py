"""R3-L6, second step: the mover's copy is saved with D's chunk (one consistent snapshot); a mover that bypasses
onRemove carries only an empty endpoint (the stated MISSING residual stays outside the model)."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""    KEYS = ("rec", "rec_dur", "e", "e_dur", "retired", "retired_dur", "registered", "registered_dur", "d", "d_dur",
            "carried", "ee", "ee_dur")
""", """    KEYS = ("rec", "rec_dur", "e", "e_dur", "retired", "retired_dur", "registered", "registered_dur", "d", "d_dur",
            "carried", "ee", "ee_dur", "carried_dur")
""")
sub("""        return (rec, rec, 1, 1, False, False, True, True, d, d_dur, None, ee, ee_dur)
""", """        # carried: a block mover's copy of D (incoming, receipt, receive buffer); carried_dur: that copy as the
        # last save of D's chunk found it, because a crash restores the mover and the chunk from one snapshot.
        return (rec, rec, 1, 1, False, False, True, True, d, d_dur, None, ee, ee_dur, None)
""")
sub("""        (rec, rec_dur, e, e_dur, retired, retired_dur, registered, registered_dur, d, d_dur, carried, ee,
         ee_dur) = state
""", """        (rec, rec_dur, e, e_dur, retired, retired_dur, registered, registered_dur, d, d_dur, carried, ee,
         ee_dur, carried_dur) = state
""")
sub("""            if saved != d_dur or d_in == "U" or d_rc == "U":
                yield "SAVE_D", make(d=(where, observe(d_in), d_buf, observe(d_rc)), d_dur=saved), c
        elif d_dur != (False, 0, d_buf, False):
            # D's chunk saves its absence and the items a removal dropped there.
            yield "SAVE_D", make(d_dur=(False, 0, d_buf, False)), c
""", """            if saved != d_dur or d_in == "U" or d_rc == "U" or carried_dur is not None:
                yield "SAVE_D", make(d=(where, observe(d_in), d_buf, observe(d_rc)), d_dur=saved, carried_dur=None), c
        elif d_dur != (False, 0, d_buf, False) or carried != carried_dur:
            # D's chunk saves its absence and the items a removal dropped there; the mover's copy is saved with it.
            yield "SAVE_D", make(d_dur=(False, 0, d_buf, False), carried_dur=carried), c
""")
sub("""            if not due_move:
                # A block entity lost without onRemove (no settlement), later found MISSING. One that vanishes
                # loses its receive buffer with it, outside the protocol, so only an empty one vanishes; a mover
                # that bypasses onRemove carries the buffer.
                if d_buf == 0:
                    yield "VANISH_D", make(d=("gone", 0, 0, None)), c
                yield "VANISH_CARRIED_D", make(d=("carried", 0, 0, None), carried=(d_in, d_rc, d_buf)), c
""", """            if not due_move and d_buf == 0:
                # A block entity lost without onRemove (no settlement), later found MISSING, or carried away by a
                # mover that bypasses onRemove. Only an empty receive buffer goes this way: a vanished buffer is
                # lost outside the protocol, and a carried one holding a moved payload whose acknowledgement a
                # crash lost is the MISSING residual stated in ADR-054 section 9.
                yield "VANISH_D", make(d=("gone", 0, 0, None)), c
                yield "VANISH_CARRIED_D", make(d=("carried", 0, 0, None), carried=(d_in, d_rc, 0)), c
""")
sub("""        if where == "here" and not registered and not (retire and retired) and not (freeze and holds)                 and (clean_on_disk or not freeze):
""", """        if where == "here" and not registered and not (retire and retired) and not (freeze and holds) \\
                and (clean_on_disk or not freeze):
""")
sub("""            restored = ("here", "P" if inc else 0, buf, "P" if rc else None) if present else \\
                (("carried", 0, 0, None) if where == "carried" else ("gone", 0, buf, None))
            yield "CRASH", cls.normalize((rec_dur, rec_dur, e_dur, e_dur, retired_dur, retired_dur, registered_dur,
                                          registered_dur, restored, d_dur,
                                          carried if where == "carried" and not present else None,
                                          ("P" if ee_dur[0] else 0, ee_dur[1], "P" if ee_dur[2] else None),
                                          ee_dur)), c - 1
""", """            # One consistent snapshot: D's chunk and the mover's copy as D's last chunk save found them.
            restored = ("here", "P" if inc else 0, buf, "P" if rc else None) if present else \\
                (("carried", 0, 0, None) if carried_dur is not None else ("gone", 0, buf, None))
            yield "CRASH", cls.normalize((rec_dur, rec_dur, e_dur, e_dur, retired_dur, retired_dur, registered_dur,
                                          registered_dur, restored, d_dur, carried_dur,
                                          ("P" if ee_dur[0] else 0, ee_dur[1], "P" if ee_dur[2] else None),
                                          ee_dur, carried_dur)), c - 1
""")
sub("""                rec, _, _, _, _, _, _, _, (where, d_in, d_buf, d_rc), _, _, (e_in, e_buf, e_rc), _ = state
""", """                rec, _, _, _, _, _, _, _, (where, d_in, d_buf, d_rc), _, carried, (e_in, e_buf, e_rc), _, _ = state
                assert carried is None, state
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
