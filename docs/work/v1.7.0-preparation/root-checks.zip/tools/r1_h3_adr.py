"""R1-H3 text: endpoint removal by any cause; the move acknowledges; removal settles with a barrier flush."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("  root without one. It is never carried in an item: breaking a device drops the\n"
    "  plain block and its local buffers, and a new placement gets a new ID.\n",
    "  root without one. It is never carried in an item: removing a device drops the\n"
    "  plain block and its **local buffers** (input, output, receive and drop\n"
    "  buffers; energy is lost), and a new placement gets a new ID. Escrowed outbox\n"
    "  entries, incoming payloads and receipts are not local buffers; §9.1 settles them.\n")
sub("- **Removal.** Breaking an endpoint removes its record. Breaking is refused for\n"
    "  non-operators while it holds an outbox entry, an incoming payload, an\n"
    "  unacknowledged receipt or an elevator pair (`ENDPOINT_BUSY`). An endpoint whose chunk is loaded without a\n",
    "- **Removal.** Removing an endpoint removes its record (§9.1). Breaking is\n"
    "  refused for non-operators while it holds an outbox entry, an incoming payload,\n"
    "  an unacknowledged receipt or an elevator pair (`ENDPOINT_BUSY`). An endpoint\n"
    "  whose chunk is loaded without a\n")

anchor = "### 10. Endgame root\n"
sub(anchor,
    "#### 9.1 Removal by any cause\n\n"
    "Review R1-H3: a refused player break is not the only way a block entity goes.\n"
    "Every endgame endpoint block is in `#minecraft:wither_immune` and\n"
    "`#minecraft:dragon_immune`, has blast resistance 1,200 (TNT, creepers, beds\n"
    "and withers cannot remove it), and cannot be pushed (it has a block entity).\n"
    "Player breaks follow §9. Every other removal (an operator break, `/setblock`\n"
    "and `/fill`, another mod's breaker or block mover) is handled in the block's\n"
    "`onRemove` when the block changes to a different block, which chunk unloading\n"
    "never triggers:\n\n"
    "- **Local buffers** drop as items, as for any container.\n"
    "- **Outbox entries never drop.** Entries with `seq ≤ dispatched_through[S]` are\n"
    "  delivered by the ledger. Unregistered entries are destroyed with one\n"
    "  `OUTBOX_LOST_ON_REMOVAL` line naming the payload hash: an audited loss, never a\n"
    "  duplicate. Dropping them could duplicate, because dropped item entities are\n"
    "  saved in the entity storage, separately from the block entity, and a crash\n"
    "  can restore the endpoint with its entries.\n"
    "- **Incoming payloads and receipts** are settled from the endpoint's live state,\n"
    "  record by record, and the result is written with a **barrier flush** in the\n"
    "  same tick: a record whose payload is still incoming here, or was never\n"
    "  materialized here (no receipt), returns to `ARRIVED` with `paid_endpoint`\n"
    "  cleared and waits as `DESTINATION_MISSING`; a record whose payload already\n"
    "  moved to the receive buffer (receipt present, nothing incoming) becomes\n"
    "  `CLAIMED` and acknowledged. An incoming payload whose record is already\n"
    "  acknowledged or pruned is the endpoint's own content (its move was due after\n"
    "  a crash, below) and drops with the local buffers. If the barrier flush fails,\n"
    "  the records stay as they were and one `REMOVAL_SETTLEMENT_UNKNOWN` line asks\n"
    "  an operator to redirect or purge them.\n"
    "- The endpoint's index record is removed, its `dispatched_through` stays as a\n"
    "  tombstone (§11), pairs naming it become invalid (unbinding stays possible,\n"
    "  ADR-059), and a laser drill linked to it sees `LINK_LOST` (ADR-055).\n\n"
    "A crash after the barrier flush but before the endpoint's chunk saved the\n"
    "removal restores the endpoint with its incoming payload and receipt while the\n"
    "record is `ARRIVED`; the destination row \"ledger behind\" re-claims it, so it is\n"
    "paid once. The reference model checks removal at any point with up to two\n"
    "crashes.\n\n" + anchor)

sub("against the receive buffer's room. A payload moves from incoming into the\n"
    "extractable receive buffer, in one tick inside D, only after a\n",
    "against the receive buffer's room. A payload moves from incoming into the\n"
    "extractable receive buffer, in one tick inside D, and its record is\n"
    "acknowledged in the same tick, only after a\n")
sub("rematerializes once into incoming (`REMATERIALIZED`, waiting while full); a\n"
    "receipt is dropped\n",
    "rematerializes once into incoming (`REMATERIALIZED`, waiting while full); an\n"
    "incoming payload whose record is already acknowledged or pruned means D's chunk\n"
    "is behind its own move, and it moves again; a receipt is dropped\n")

sub("| Claim: ledger flushed, D not | `CLAIMED`, no receipt |",
    "| Endpoint removed by a non-player cause, removal not yet saved | Endpoint back with its entries, incoming payload and receipt | Registered entries delivered; the incoming claim, returned to `ARRIVED` by the barrier flush, is re-claimed once |\n"
    "| Endpoint removed, removal saved | No endpoint | Registered entries delivered; unregistered entries lost and audited; incoming claims redirected (`DESTINATION_MISSING`) |\n"
    "| Claim: ledger flushed, D not | `CLAIMED`, no receipt |")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
