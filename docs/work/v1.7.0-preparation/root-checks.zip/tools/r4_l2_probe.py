import importlib.util
spec = importlib.util.spec_from_file_location("c", "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
T = c.Transit
for path in (["ESCROW", "SAVE_S", "REMOVE_S", "FLUSH_L", "CRASH"],
             ["ESCROW", "SAVE_S_LOST", "AGE", "REGISTER", "FLUSH_L", "ARRIVE", "CLAIM", "SAVE_D", "D_ACK", "FLUSH_L",
              "PRUNE", "D_DROP", "SAVE_D", "STALE_DROP", "REMOVE_S", "FLUSH_L", "CRASH"],
             ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "FLUSH_L", "CRASH"]):
    state = T.normalize(T.initial())
    for label in path:
        options = {l: s for l, s, _, _ in T.successors(state, 1, 1)}
        assert label in options, (label, sorted(options))
        state = options[label]
    print(path[-4:], T.delivered(T.drain(state)))
