"""Applies one textual mutation at a time to a copy of check_examples.py and searches for a violation.

The search is the checker's own exploration (one payload, two crashes, no lost write), stopped at the
first state whose fault-free continuation does not deliver exactly once (or does not terminate).
"""
import importlib.util, shutil, sys, time
from pathlib import Path

SRC = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
OUT = Path(sys.argv[1])
MUTATIONS = {
    "none (control)": None,
    "register-unpersisted": ('elif r is None and persisted and aged and seq == lowest and seq > hw_value:',
                             'elif r is None and seq == lowest and seq > hw_value:'),
    "release-before-durable": ('elif r is not None and e > r[2]:', 'elif r is not None:'),
    "claim-before-durable": ('if st == "A" and e > de and seq not in receipt_seqs:',
                             'if st == "A" and seq not in receipt_seqs:'),
    "drop-receipt-before-durable-ack": ('if r is None or (r[1] == "C" and r[3] and e > r[4]):',
                                        'if r is None or (r[1] == "C" and r[3]):'),
    "ack-unpersisted-receipt": ('if st == "C" and not acked and (seq, True) in receipts:',
                                'if st == "C" and not acked and seq in receipt_seqs:'),
    "no-stale-drop": ('if r is None and seq <= hw_value:', 'if False:'),
    "prune-before-durable-ack": ('if st == "C" and acked and e > ae:', 'if st == "C" and acked:'),
    "no-rollback-fix": ("        if rollback_pending:\n", "        if False:\n"),
    "source-removal-without-barrier": ("barrier = dict(l_live=(records, hw, e + 1), l_dur=(records, hw, e + 1)) if pending else {}",
                                       "barrier = {}"),
    "drop-tombstone-before-persisted-absence": ('hw is not None and not present and absence_seen == "aged":',
                                                'hw is not None and not present:'),
}


def search(module, limit=300000):
    T = module.Transit
    start = T.normalize(T.initial(1))
    seen, stack = set(), [(start, 2, 0, ())]
    while stack:
        state, crashes, faults, path = stack.pop()
        key = (state, crashes, faults)
        if key in seen:
            continue
        seen.add(key)
        if len(seen) > limit:
            return "no violation within limit", len(seen), None
        try:
            outcome = T.delivered(T.drain(state))
        except AssertionError as error:
            return "violation (no quiescence: %s)" % str(error)[:60], len(seen), path
        if outcome[0] > 1 or outcome[0] + outcome[1] < 1 or outcome[2]:
            return "violation (delivered %s)" % (outcome,), len(seen), path
        for label, new_state, c, f in T.successors(state, crashes, faults):
            stack.append((new_state, c, f, path + (label,)))
    return "no violation", len(seen), None


for name, change in MUTATIONS.items():
    slug = name.split()[0]
    target = OUT / slug
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy(SRC / "examples.json", target / "examples.json")
    text = (SRC / "check_examples.py").read_text(encoding="utf-8")
    if change:
        assert text.count(change[0]) == 1, name
        text = text.replace(change[0], change[1])
    (target / "check_examples.py").write_text(text, encoding="utf-8", newline="\n")
    spec = importlib.util.spec_from_file_location("mut_" + slug.replace("-", "_"), target / "check_examples.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    began = time.time()
    verdict, states, path = search(module)
    line = "%-34s %-40s states=%-7d %.1fs path=%s" % (name, verdict, states, time.time() - began,
                                                         " ".join(path) if path else "-")
    (target / "result.txt").write_text(line + "\n", encoding="utf-8")
    print(line, flush=True)


# Delivery-side mutations (gated model, two crashes): a violation is any duplicate or loss without a torn save.
DELIVERY = {
    "removal-always-unclaims": ('settled = ("C", True, e) if receipt is not None and not incoming else ("A", False, None)',
                                'settled = ("A", False, None)'),
    "removal-without-barrier": ('yield "REMOVE_D", make(d=(0, 0, None, False, False), rec=settled, rec_dur=settled, e=e + 1,',
                                'yield "REMOVE_D", make(d=(0, 0, None, False, False), rec=settled, rec_dur=rec_dur, e=e + 1,'),
    "move-before-persisted": ('if present and gated and incoming == "A" and (claimed or rec is None or rec[1]):',
                              'if present and gated and incoming and (claimed or rec is None or rec[1]):'),
}
for name, (old, new) in DELIVERY.items():
    target = OUT / ("delivery-" + name)
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy(SRC / "examples.json", target / "examples.json")
    text = (SRC / "check_examples.py").read_text(encoding="utf-8")
    assert text.count(old) == 1, name
    (target / "check_examples.py").write_text(text.replace(old, new), encoding="utf-8", newline="\n")
    spec = importlib.util.spec_from_file_location("mutd_" + name.replace("-", "_"), target / "check_examples.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    try:
        states, outcomes = module.Delivery.explore(True, 2)
        bad = sorted(k for k in outcomes if k[0] != 1 and not k[1])
    except AssertionError as stuck:
        states, bad = 0, ["stuck: " + str(stuck)[:70]]
    line = "%-34s %-40s states=%d" % ("delivery " + name, "violation %s" % bad if bad else "no violation", states)
    (target / "result.txt").write_text(line + "\n", encoding="utf-8")
    print(line, flush=True)


# Redirect mutation: the round-2 rules (no retirement) duplicate through a returning destination.
spec = importlib.util.spec_from_file_location("mut_redirect", SRC / "check_examples.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
states, outcomes = module.Redirect.explore(False, 0)
bad = sorted(k for k in outcomes if k[0] != 1)
print("%-34s %-40s states=%d" % ("redirect without-retirement", "violation %s" % bad if bad else "no violation", states),
      flush=True)
