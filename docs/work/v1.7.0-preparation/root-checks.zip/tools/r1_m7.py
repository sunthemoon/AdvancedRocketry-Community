"""R1-M7: layer-by-layer debt settlement, relink after LINK_LOST/absence, audited reset, credit waits; model."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-055-ORBITAL-LASER-DRILL.md", [
    ("At every contact (both chunks `FULL`, before each operation):\n\n"
     "- `ops_done > ops_paid` (the marker was saved after an operation, the controller\n"
     "  was not): the controller pays the **debt** `(ops_done − ops_paid) × cost`\n"
     "  first, or waits with `ENERGY_DEBT`, then sets `ops_paid = ops_done`\n"
     "  (`DEBT_SETTLED`);\n"
     "- `ops_paid > ops_done` (the reverse): the marker performs the paid layers\n"
     "  without a new payment (`CREDIT_USED`).\n",
     "At every contact (both chunks `FULL`, before each operation):\n\n"
     "- `ops_done > ops_paid` (the marker was saved after an operation, the controller\n"
     "  was not): the controller settles the **debt layer by layer**: each time its\n"
     "  buffer holds `cost`, it pays `cost` and raises `ops_paid` by 1 (review\n"
     "  R1-M7), so a debt larger than the 200,000 FE buffer is still paid as energy\n"
     "  arrives. No new layer runs until `ops_paid = ops_done`; meanwhile the drill\n"
     "  shows `ENERGY_DEBT` with the layers still owed, and `DEBT_SETTLED` is audited\n"
     "  at the end;\n"
     "- `ops_paid > ops_done` (the reverse): the marker performs the paid layers\n"
     "  without a new payment (`CREDIT_USED`), but only while the system and physical\n"
     "  mode are enabled; while disabled the credit waits, because a disabled system\n"
     "  breaks no block (ADR-054 §1).\n"),
    ("(normally a few seconds of cadence), and the next contact settles all of it. Debt is never\n"
     "forgiven by relinking: a controller may change or clear its link only after a\n"
     "contact with no debt and no credit, or when the marker is `MISSING`\n"
     "(audited `LINK_ABANDONED`; an unsettled layer is the documented residual). A\n"
     "marker owner may reset a marker that is not active; it then accepts a new\n"
     "controller, and the old controller sees `LINK_LOST`.\n",
     "(normally a few seconds of cadence), and the next contact settles all of it.\n\n"
     "**Changing links.** A controller may change or clear its link after a contact\n"
     "with no debt and no credit. It may also clear it at any time when the link can\n"
     "no longer be contacted: the marker was removed (ADR-054 §9.1), is `MISSING`, or\n"
     "answers `LINK_LOST` because it was reset or now serves another controller. The\n"
     "unsettled difference is then abandoned with a `LINK_ABANDONED` line stating it;\n"
     "it is bounded by the crash gap above. A marker owner may reset a marker that is\n"
     "not running a layer; the marker cannot know whether its controller still owes\n"
     "layers, so the reset writes a `MARKER_RESET` line with `ops_done`, and any debt\n"
     "the old controller held is forgiven within the same bound. Both are documented\n"
     "residuals of at most a few layers' energy, never of blocks or drops.\n"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ('''def counter_model(events, cost, energy):
    """Runs controller/marker events with independent saves; returns the settled durable result.

    events: OP, SAVE_C, SAVE_M, CRASH. After the sequence a final contact settles debt and credit
    with unlimited energy added, the way a powered controller eventually would.
    """
    live_c = {"energy": energy, "paid": 0}
    live_m = {"done": 0}
    dur_c, dur_m = dict(live_c), dict(live_m)

    def contact(c, m):
        if m["done"] > c["paid"]:
            debt = (m["done"] - c["paid"]) * cost
            if c["energy"] < debt:
                return False
            c["energy"] -= debt
            c["paid"] = m["done"]
        if c["paid"] > m["done"]:
            m["done"] = c["paid"]  # credit layers performed without a new payment
        return True

    for event in events:
        if event == "OP":
            if contact(live_c, live_m) and live_c["energy"] >= cost:
                live_c["energy"] -= cost
                live_c["paid"] += 1
                live_m["done"] += 1
        elif event == "SAVE_C":
            dur_c = dict(live_c)
        elif event == "SAVE_M":
            dur_m = dict(live_m)
        elif event == "CRASH":
            live_c, live_m = dict(dur_c), dict(dur_m)
        else:
            raise ValueError(event)
    live_c["energy"] += 10 ** 9
    added = 10 ** 9
    assert contact(live_c, live_m)
    spent = energy + added - live_c["energy"]
    return {"paid": live_c["paid"], "done": live_m["done"], "spent": spent}''',
     '''BUFFER = 200_000  # ADR-055 controller buffer


def counter_model(events, cost, energy):
    """Runs controller/marker events with independent saves; returns the settled durable result.

    events: OP, CHARGE (cost FE arrives, capped at the buffer), SAVE_C, SAVE_M, CRASH. Debt is settled one
    layer at a time from the buffer (R1-M7); after the sequence the controller keeps receiving CHARGE until
    it is settled, the way a powered controller eventually would. `spent` is the controller's durable debit.
    """
    live_c = {"energy": energy, "paid": 0, "spent": 0}
    live_m = {"done": 0}
    dur_c, dur_m = dict(live_c), dict(live_m)

    def contact(c, m):
        while m["done"] > c["paid"] and c["energy"] >= cost:  # debt, layer by layer
            c["energy"] -= cost
            c["spent"] += cost
            c["paid"] += 1
        if c["paid"] > m["done"]:
            m["done"] = c["paid"]  # credit layers performed without a new payment
        return m["done"] == c["paid"]

    def charge(c):
        c["energy"] = min(BUFFER, c["energy"] + cost)

    for event in events:
        if event == "OP":
            if contact(live_c, live_m) and live_c["energy"] >= cost:
                live_c["energy"] -= cost
                live_c["spent"] += cost
                live_c["paid"] += 1
                live_m["done"] += 1
        elif event == "CHARGE":
            charge(live_c)
        elif event == "SAVE_C":
            dur_c = dict(live_c)
        elif event == "SAVE_M":
            dur_m = dict(live_m)
        elif event == "CRASH":
            live_c, live_m = dict(dur_c), dict(dur_m)
        else:
            raise ValueError(event)
    for _ in range(64):
        if contact(live_c, live_m):
            break
        charge(live_c)
    else:
        raise AssertionError("debt never settled")
    return {"paid": live_c["paid"], "done": live_m["done"], "spent": live_c["spent"]}'''),
    ('''    def test_counter_settlement_every_crash_cut(self):
        cost = 10_000
        alphabet = ["OP", "SAVE_C", "SAVE_M", "CRASH"]''',
     '''    def test_counter_settlement_every_crash_cut(self):
        cost = 10_000
        alphabet = ["OP", "CHARGE", "SAVE_C", "SAVE_M", "CRASH"]'''),
    ('''        walk([], 7)
        self.assertEqual(checked, EXAMPLES["counter_sequences_checked"])''',
     '''        walk([], 7)
        self.assertEqual(checked, EXAMPLES["counter_sequences_checked"])

    def test_counter_debt_larger_than_the_buffer_settles(self):
        # R1-M7: at 1,000 % a layer costs 100,000 FE; three unsaved controller layers owe more than the buffer.
        cost = laser_cost(1000)
        events = ["OP", "CHARGE", "OP", "CHARGE", "OP", "SAVE_M", "CRASH"]
        self.assertEqual(counter_model(events, cost, BUFFER), {"paid": 3, "done": 3, "spent": 300_000})'''),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ('    "counter_sequences_checked": sum(4 ** k for k in range(8)),',
     '    "counter_sequences_checked": sum(5 ** k for k in range(8)),'),
])
print("ok")
