"""R2-H2: removal makes registered-but-not-durable records durable; the model counts only unregistered losses."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("- **Outbox entries never drop.** Entries with `seq ≤ dispatched_through[S]` are\n"
     "  delivered by the ledger. Unregistered entries are destroyed with one\n",
     "- **Outbox entries never drop.** Entries with `seq ≤ dispatched_through[S]` are\n"
     "  delivered by the ledger; if the record of any of them is not yet durable, the\n"
     "  removal runs a **barrier flush** in the same tick, so the record reaches disk\n"
     "  before the removal can (review R2-H2). Unregistered entries are destroyed with one\n"),
    ("| Endpoint removed, removal saved | No endpoint | Registered entries delivered; unregistered entries lost and audited; incoming claims redirected (`DESTINATION_MISSING`) |",
     "| Endpoint removed, removal saved | No endpoint | Registered entries delivered (their records were made durable by the removal's barrier flush); unregistered entries lost and audited; incoming claims redirected (`DESTINATION_MISSING`) |"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ("        if present and s_input == 0:\n"
     "            # R1-H3: removal by any cause. Escrowed entries never drop as items: registered ones are delivered\n"
     "            # by the ledger, unregistered ones are destroyed (audited loss). The input buffer is a plain\n"
     "            # container, so the model removes S only when it is empty.\n"
     "            yield (\"REMOVE_S\", make(s_live=(0, frozenset(), next_seq, False, False),\n"
     "                                    destroyed=(destroyed[0] + len(outbox), destroyed[1])), crashes_left, faults_left)\n",
     "        if present and s_input == 0:\n"
     "            # R1-H3: removal by any cause. Escrowed entries never drop as items: registered ones are delivered\n"
     "            # by the ledger, unregistered ones are destroyed (audited loss). R2-H2: if a registered entry's\n"
     "            # record is not yet durable, the removal writes the ledger with a barrier flush in the same tick.\n"
     "            # The input buffer is a plain container, so the model removes S only when it is empty.\n"
     "            unregistered = sum(1 for seq in out_seqs if seq > hw_value)\n"
     "            pending = any(rec(seq) is not None and not e > rec(seq)[2] for seq in out_seqs if seq <= hw_value)\n"
     "            barrier = dict(l_live=(records, hw, e + 1), l_dur=(records, hw, e + 1)) if pending else {}\n"
     "            yield (\"REMOVE_S\", make(s_live=(0, frozenset(), next_seq, False, False),\n"
     "                                    destroyed=(destroyed[0] + unregistered, destroyed[1]), **barrier),\n"
     "                   crashes_left, faults_left)\n"),
    ("            self.assertLessEqual(buffer, 2)  # never a duplicate\n"
     "            # A loss only where a forced removal destroyed escrowed cargo (R1-H3, audited).\n"
     "            self.assertGreaterEqual(buffer + destroyed, 2)\n",
     "            self.assertLessEqual(buffer, 2)  # never a duplicate\n"
     "            # Every payload is delivered or audited as destroyed by a forced removal (R1-H3, R2-H2).\n"
     "            self.assertEqual(buffer + destroyed, 2)\n"),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ('''            {"name": "R1-H3: forced removal after the record was durable: delivered, never dropped",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "SAVE_S", "CRASH"],
             "expected": [1, 1, False]},''',
     '''            {"name": "R1-H3: forced removal after the record was durable: delivered, never dropped",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "SAVE_S", "CRASH"],
             "expected": [1, 0, False]},
            {"name": "R2-H2: forced removal before the record was durable, removal saved: delivered once",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "REMOVE_S", "SAVE_S", "CRASH"],
             "expected": [1, 0, False]},'''),
])
print("ok")
