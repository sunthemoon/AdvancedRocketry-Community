"""Fetch the v1.7 endgame legacy audit set from the pinned MIT commit and check manifest hashes.

Upstream bytes stay in the separate audit directory; only hashes/paths are recorded here.
"""
import csv, hashlib, json, pathlib, sys, time, urllib.request

REPO = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")
COMMIT = "c5cd5af62fc07cd4e0d24f06a16033f181c47c04"
BASE = f"https://raw.githubusercontent.com/Advanced-Rocketry/AdvancedRocketry/{COMMIT}/"
OUT = pathlib.Path(sys.argv[1])
RECORD = pathlib.Path(sys.argv[2])

JAVA = [
 "tile/multiblock/orbitallaserdrill/TileOrbitalLaserDrill.java", "tile/multiblock/orbitallaserdrill/AbstractDrill.java",
 "tile/multiblock/orbitallaserdrill/MiningDrill.java", "tile/multiblock/orbitallaserdrill/VoidDrill.java",
 "block/BlockOrbitalLaserDrill.java", "inventory/ContainerOrbitalLaserDrill.java", "inventory/GuiOrbitalLaserDrill.java",
 "entity/EntityLaserNode.java",
 "tile/multiblock/TileRailgun.java",
 "tile/multiblock/energy/TileBlackHoleGenerator.java",
 "tile/station/TileStationGravityController.java", "tile/multiblock/TileAreaGravityController.java",
 "api/IGravityManager.java", "util/GravityHandler.java",
 "tile/multiblock/TileSpaceElevator.java", "entity/EntityElevatorCapsule.java", "item/ItemSpaceElevatorChip.java",
 "client/render/multiblocks/RenderOrbitalLaserDrill.java", "client/render/multiblocks/RendererRailgun.java",
 "client/render/multiblocks/RenderBlackHoleGenerator.java", "client/render/multiblocks/RenderAreaGravityController.java",
 "client/render/multiblocks/RendererSpaceElevator.java", "client/render/RenderLaser.java",
 "api/ARConfiguration.java", "AdvancedRocketry.java", "dimension/DimensionProperties.java",
 "api/dimension/solar/StellarBody.java", "stations/SpaceObjectManager.java", "stations/SpaceStationObject.java",
 "tile/TileForceFieldProjector.java",
]
PREFIX = "src/main/java/zmaster587/advancedRocketry/"

manifest = {}
with open(REPO / "legacy-manifest/java-files.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        manifest[row["path"]] = row

rows = []
for rel in JAVA:
    path = PREFIX + rel
    entry = manifest.get(path)
    row = {"path": path, "in_manifest": entry is not None}
    try:
        with urllib.request.urlopen(BASE + path, timeout=30) as resp:
            data = resp.read()
        dest = OUT / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        digest = hashlib.sha256(data).hexdigest()
        row.update(bytes=len(data), sha256=digest,
                   manifest_sha256=entry["sha256"] if entry else None,
                   hash_match=(entry is not None and entry["sha256"] == digest),
                   lines=data.count(b"\n"))
    except Exception as exc:  # retained as a failed fetch, not hidden
        row.update(error=repr(exc))
    rows.append(row)
    time.sleep(0.1)

summary = {
    "upstream_commit": COMMIT,
    "requested": len(JAVA),
    "fetched": sum(1 for r in rows if "sha256" in r),
    "in_manifest": sum(1 for r in rows if r["in_manifest"]),
    "hash_matches": sum(1 for r in rows if r.get("hash_match")),
    "failures": [r["path"] for r in rows if "error" in r],
    "not_in_manifest": [r["path"] for r in rows if not r["in_manifest"]],
    "files": rows,
}
RECORD.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in summary.items() if k != "files"}, indent=2))
