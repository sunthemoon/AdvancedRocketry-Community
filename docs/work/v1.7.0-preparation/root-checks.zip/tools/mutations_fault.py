"""Re-runs two mutations with one lost source write allowed; reports outcomes beyond the documented residual."""
import importlib.util, sys
from pathlib import Path

OUT = Path(sys.argv[1])
for slug in ("none", "no-stale-drop", "no-rollback-fix"):
    spec = importlib.util.spec_from_file_location("m", OUT / slug / "check_examples.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    T = module.Transit
    seen, stack, outcomes = set(), [(T.normalize(T.initial(1)), 2, 1, ())], {}
    while stack:
        state, c, f, path = stack.pop()
        if (state, c, f) in seen:
            continue
        seen.add((state, c, f))
        try:
            o = T.delivered(T.drain(state))
        except AssertionError:
            o = ("stuck",)
        o = tuple(o)
        key = (o, f < 1)
        if key not in outcomes:
            outcomes[key] = " ".join(path)
        for label, s2, c2, f2 in T.successors(state, c, f):
            stack.append((s2, c2, f2, path + (label,)))
    print(slug, len(seen))
    for key, path in sorted(outcomes.items(), key=str):
        print("   ", key, "e.g.", path[:200])
