"""Round 3 Lows L1 (quarantine counts as present), L2 (retired devices for players), L3 (resolve for frozen items
of a registered endpoint), L4 (elevator redirect route), L5 (encoded sizes)."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    # L1
    ("""  written. Buffers of a quarantined root are not dropped on break; breaking it is
  refused for non-operators.
""", """  written. Buffers of a quarantined root are not dropped on break; breaking it is
  refused for non-operators. Quarantine never reads as absence: in every
  presence or absence observation (§9 `MISSING`, §11 tombstones and stubs), a
  block entity of an endgame block at the recorded position counts as present
  unless its root names a different, readable `device_id`, so a quarantined
  endpoint is never retired (review R3-L1).
"""),
    ("""  (`ENDPOINT_BUSY`). An endpoint whose chunk is loaded without a block entity of
  that ID at the recorded position, observed at least 40 ticks earlier in a
""", """  (`ENDPOINT_BUSY`). An endpoint whose chunk is loaded without a block entity of
  that ID at the recorded position (a quarantined or unreadable root there
  counts as present, §2), observed at least 40 ticks earlier in a
"""),
    # L2
    ("""  registers, claims, moves, acknowledges, drops or delivers them, and it never
  registers again. Breaking it drops only its local buffers. An operator resolves
  it with `/arce endgame endpoint resolve <id>` (one audited barrier flush), item
  by item (review R3-M1):
""", """  registers, claims, moves, acknowledges, drops or delivers them, and it never
  registers again. Any removal of a retired device, a player's break included,
  first resolves it as below in the removal's barrier flush and then drops its
  local buffers. A break therefore never destroys an entry that `resolve` would
  return, and a retired device is busy (§9 `ENDPOINT_BUSY`) only while a pair
  names it. Its menu shows `ENDPOINT_RETIRED`, what it holds frozen, and that
  breaking it resolves them (review R3-L2). Without breaking it, its owner (own
  endpoints, from their own connected command source, subject to the §7
  spacing) or an operator resolves it with `/arce endgame endpoint resolve <id>`
  (one audited barrier flush), item by item (review R3-M1):
"""),
    # L3
    ("""absent; a claim paid elsewhere freezes the receipt (`REDIRECT_DOUBLE_PAY`); a
quarantined record keeps it. A retired endpoint (§9) runs none of these rows.
""", """absent; a claim paid elsewhere freezes the receipt (`REDIRECT_DOUBLE_PAY`); a
quarantined record keeps it. A retired endpoint (§9) runs none of these rows.
Items frozen in a registered endpoint (`REDIRECT_CONFLICT`,
`REDIRECT_DOUBLE_PAY`), which only an operator's restore of an older file can
cause, are resolved by an operator with the same `endpoint resolve <id>`, item
by item as in §9; until then they make the endpoint busy (review R3-L3).
"""),
    # L4
    ("""railgun endpoints in the source's star system; elevator cargo goes back to its
source endpoint. An outbox payload that no longer decodes stays raw in S,
""", """railgun endpoints in the source's star system; elevator cargo goes back to its
source endpoint, or to the endpoint of the original destination's kind (anchor
or terminal) in the station's current valid pair, so a pair rebuilt after both
ends were removed can still receive it (review R3-L4). An outbox payload that
no longer decodes stays raw in S,
"""),
    # L5
    ("""most 4 stacks, each with an encoded item tag of at most 512 bytes; plain items
only otherwise.
""", """most 4 stacks, each at most 512 bytes encoded, counting the item ID, the count
and the tag together (review R3-L5); a larger stack is refused at escrow
(`PAYLOAD_TOO_LARGE`) and stays in the input buffer.
"""),
    ("""  2,048 endpoints × 384 B, 2,048 `dispatched_through` entries × 32 B, 256
""", """  2,048 endpoints × 384 B, 2,048 `dispatched_through` entries × 32 B (one long
  array holds three longs per entry, the source UUID and `seq`: 24 B; review
  R3-L5), 256
"""),
    ("""  `endpoint retire <id>` and `endpoint resolve <id>` (§9, §11); `tombstone
""", """  `endpoint retire <id>` and `endpoint resolve <id>` (§9, §11; owners may resolve
  their own retired endpoints); `tombstone
"""),
])
patch("ADR-056-RAILGUN-CARGO-AND-TARGETING.md", [
    ("""record `ARRIVED` with `DESTINATION_MISSING`; only an operator redirect (for
example back to the source) or purge resolves it.
""", """record `ARRIVED` with `DESTINATION_MISSING`; only an owner or operator redirect
under ADR-054 §11's route rule (for example back to the source) or an operator
purge resolves it.
"""),
])
patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("""must be valid at escrow. Delivery is endpoint-addressed, so it completes even if
the pair is unbound or invalid afterwards.
""", """must be valid at escrow. Delivery is endpoint-addressed, so it completes even if
the pair is unbound or invalid afterwards. Cargo whose destination endpoint was
removed waits as `DESTINATION_MISSING` and can be redirected back to its source
or to the same kind of endpoint in the station's current valid pair (ADR-054
§11, review R3-L4).
"""),
])
print("ok")
