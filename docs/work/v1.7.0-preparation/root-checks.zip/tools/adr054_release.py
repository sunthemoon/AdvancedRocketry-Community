"""Removes source_released from ADR-054 section 11 after the model showed it is redundant."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")
reps = [
    ("`acknowledged`, `ack_epoch`, `source_released`, `redirected`. Identity is\n"
     "`(source, seq)`. `dispatched_through[S]` is the highest registered `seq` of S and\n"
     "never decreases.",
     "`acknowledged`, `ack_epoch`, `redirected`. Identity is `(source, seq)`.\n"
     "`dispatched_through[S]` is the highest registered `seq` of S and never\n"
     "decreases; it is what keeps a pruned transfer from being registered again."),
    ("3. **Release.** When the record is durable, S drops the outbox entry. When a\n"
     "   chunk-save tag of S shows `seq < next_seq` and no outbox entry `seq`, the\n"
     "   ledger sets `source_released`.",
     "3. **Release.** S drops the outbox entry when its record is durable, or when\n"
     "   `seq ≤ dispatched_through[S]` and the record is gone (it was delivered,\n"
     "   acknowledged durably and pruned, or purged by an operator)."),
    ("| No record, `seq ≤ dispatched_through[S]` | present | Already completed and pruned: drop the entry, audit `OUTBOX_STALE_DROPPED` |",
     "| No record, `seq ≤ dispatched_through[S]` | present | Delivered and pruned (or purged): drop the entry, audit `OUTBOX_STALE_DROPPED` |"),
    ("| Record present, `source_released` false | absent and absence persisted | Set `source_released` |\n", ""),
    ("**Pruning.** A record is removed once its acknowledgement is durable and\n"
     "`source_released` is set. `dispatched_through[S]` is removed only when S's\n"
     "endpoint record is removed and no record has source S.",
     "**Pruning.** A record is removed once its acknowledgement is durable, whether or\n"
     "not S has already dropped its entry; the `dispatched_through` rule above makes a\n"
     "late drop safe. `dispatched_through[S]` is removed only when S's endpoint record\n"
     "is removed, S holds no outbox entry, and no record has source S. A\n"
     "`source_released` flag was considered and dropped: the reference model shows it\n"
     "changes no outcome, with or without a lost source write."),
    ("| Release saved, `source_released` not flushed | Record without the flag | Flag set at the next contact |\n", ""),
    ("| Record pruned, S rolled back past its release | Entry with `seq ≤ dispatched_through` | Dropped (`OUTBOX_STALE_DROPPED`): a loss, never a duplicate |",
     "| Record pruned while S still holds the entry (S unloaded, its release not yet saved, or that save lost) | Entry with `seq ≤ dispatched_through`, no record | Dropped (`OUTBOX_STALE_DROPPED`); the payload was already delivered once |"),
]
for old, new in reps:
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)
assert "source_released" not in s.replace("A\n`source_released` flag", "")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
