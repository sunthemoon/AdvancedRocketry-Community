import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for removal in (True, False):
    c.Transit.TOMBSTONE_REMOVAL = removal
    for cr, f, p in ((2, 0, 1), (2, 1, 1), (2, 0, 2)):
        print("removal" if removal else "kept", cr, f, p, c.Transit.explore(crashes=cr, faults=f, payloads=p), flush=True)
