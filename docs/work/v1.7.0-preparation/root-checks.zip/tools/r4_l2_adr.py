"""R4-L2: every tombstone records dispatched_through (0 when nothing was registered); resolve returns entries
above it and audits SOURCE_ROLLBACK; the models now cover a retired source."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""  - a frozen outbox entry goes back to the local input buffer only if the ID's
    tombstone still records `dispatched_through` and `seq` is above it (the
    ledger can never register it); otherwise it is discarded with an audit line,
    because it was registered and delivered, or nothing proves it was not;
""", """  - a frozen outbox entry goes back to the local input buffer if the ID's
    tombstone exists and `seq` is above its `dispatched_through`, which every
    tombstone records, 0 when nothing was registered (review R4-L2); the ledger
    can never register it. Otherwise it is discarded with an audit line: it was
    registered and delivered, or, after the tombstone was evicted, nothing
    proves it was not. When the copy's persisted `next_seq` is at or below that
    `dispatched_through`, the resolve also audits `SOURCE_ROLLBACK`, as source
    reconciliation does (§11), because the input buffer it hands back may hold a
    payload already delivered;
""")
sub("""`dispatched_through[S]` is the highest registered `seq` of S and never
decreases; it is what keeps a pruned transfer from being registered again.
""", """`dispatched_through[S]` is the highest registered `seq` of S and never
decreases; it is what keeps a pruned transfer from being registered again. It
is 0 from S's registration, so every endpoint's tombstone records it (review
R4-L2).
""")
sub("""to two crashes, and a removed destination that returns through a crash or a
block mover after its cargo was redirected and paid elsewhere. A crash restores
""", """to two crashes, a removed destination that returns through a crash or a block
mover after its cargo was redirected and paid elsewhere, and a retired source
that a crash restores, whose resolve returns exactly its unregistered entries
(review R4-L2). A crash restores
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
