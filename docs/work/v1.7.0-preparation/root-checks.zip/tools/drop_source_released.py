"""Removes source_released (and its absence observations) from the transit model and the generator."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = p.read_text(encoding="utf-8")
reps = [
    ("    Records are tuples (seq, state, dispatch_epoch, acked, ack_epoch, released); state is",
     "    Records are tuples (seq, state, dispatch_epoch, acked, ack_epoch); state is"),
    ("        # input, outbox{(seq, persisted, aged)}, next_seq, release pending, absence observed\n"
     "        s_live = (payloads, frozenset(), 1, frozenset(), frozenset())",
     "        # input, outbox{(seq, persisted, aged)}, next_seq\n"
     "        s_live = (payloads, frozenset(), 1)"),
    ("            return frozenset((r[0], r[1], rank[r[2]], r[3], None if r[4] is None else rank[r[4]], r[5]) for r in rs)",
     "            return frozenset((r[0], r[1], rank[r[2]], r[3], None if r[4] is None else rank[r[4]]) for r in rs)"),
    ("    @classmethod\n    def absent_after_save(cls, outbox_seqs, next_seq):\n"
     "        return frozenset(s for s in range(1, next_seq) if s not in outbox_seqs)\n\n", ""),
    ("        s_input, outbox, next_seq, pending, absent = s_live", "        s_input, outbox, next_seq = s_live"),
    ("            yield (\"FIX_ROLLBACK\", make(s_live=(s_input, outbox, hw + 1, pending, absent), rollback=True),",
     "            yield (\"FIX_ROLLBACK\", make(s_live=(s_input, outbox, hw + 1), rollback=True),"),
    ("            yield (\"ESCROW\", make(s_live=(s_input - 1, outbox | {(next_seq, False, False)}, next_seq + 1,\n"
     "                                          pending, absent)), crashes_left, faults_left)",
     "            yield (\"ESCROW\", make(s_live=(s_input - 1, outbox | {(next_seq, False, False)}, next_seq + 1)),\n"
     "                   crashes_left, faults_left)"),
    ("            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq, pending,\n"
     "                                          cls.absent_after_save(out_seqs, next_seq)), s_dur=saved),\n"
     "                   crashes_left, faults_left)",
     "            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq), s_dur=saved), crashes_left, faults_left)"),
    ("                yield (\"SAVE_S_LOST\", make(s_live=(s_input, new_outbox, next_seq, pending,\n"
     "                                                   cls.absent_after_save(out_seqs, next_seq))),\n"
     "                       crashes_left, faults_left - 1)",
     "                yield (\"SAVE_S_LOST\", make(s_live=(s_input, new_outbox, next_seq)), crashes_left, faults_left - 1)"),
    ("            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox),\n"
     "                                       next_seq, pending, absent)), crashes_left, faults_left)",
     "            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq)),\n"
     "                   crashes_left, faults_left)"),
    ("                yield (\"STALE_DROP\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq,\n"
     "                                                  pending, absent)), crashes_left, faults_left)",
     "                yield (\"STALE_DROP\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq)),\n"
     "                       crashes_left, faults_left)"),
    ("                yield (\"REGISTER\", make(l_live=(records | {(seq, \"T\", e, False, None, False)}, seq, e)),",
     "                yield (\"REGISTER\", make(l_live=(records | {(seq, \"T\", e, False, None)}, seq, e)),"),
    ("                yield (\"RELEASE\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq,\n"
     "                                               pending | {seq}, absent)), crashes_left, faults_left)",
     "                yield (\"RELEASE\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq)),\n"
     "                       crashes_left, faults_left)"),
    ("            seq, st, de, acked, ae, released = r\n"
     "            if not released and seq in absent:\n"
     "                yield (\"SET_RELEASED\", make(l_live=(records - {r} | {(seq, st, de, acked, ae, True)}, hw, e)),\n"
     "                       crashes_left, faults_left)\n",
     "            seq, st, de, acked, ae = r\n"),
    ("{(seq, \"A\", de, acked, ae, released)}", "{(seq, \"A\", de, acked, ae)}"),
    ("make(l_live=(records - {r} | {(seq, \"C\", de, False, None, released)}, hw, e),\n",
     "make(l_live=(records - {r} | {(seq, \"C\", de, False, None)}, hw, e),\n"),
    ("yield (\"D_RECOVER\", make(l_live=(records - {r} | {(seq, \"C\", de, False, None, released)}, hw, e)),",
     "yield (\"D_RECOVER\", make(l_live=(records - {r} | {(seq, \"C\", de, False, None)}, hw, e)),"),
    ("{(seq, \"C\", de, True, e, released)}", "{(seq, \"C\", de, True, e)}"),
    ("            if st == \"C\" and acked and e > ae and released:", "            if st == \"C\" and acked and e > ae:"),
    ("        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, frozenset(),\n"
     "                  cls.absent_after_save(out_seqs, next_seq))",
     "        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq)"),
    ("                 \"SET_RELEASED\", \"RELEASE\",", "                 \"RELEASE\","),
    ("        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback = state",
     "        (s_input, outbox, _), _, (records, _, _), _, (buffer, receipts), _, rollback = state"),
]
for old, new in reps:
    assert s.count(old) == 1, old[:90]
    s = s.replace(old, new)
leftover = [line for line in s.splitlines() if "released" in line or "absent_after" in line ]
assert not leftover, leftover
p.write_text(s, encoding="utf-8", newline="\n")

g = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb/tools/generate_examples.py")
t = g.read_text(encoding="utf-8")
old = ('            {"name": "pruned, then the source returns from a lost release write",\n'
       '             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "SAVE_S_LOST",\n'
       '                        "SET_RELEASED", "ARRIVE", "CLAIM", "SAVE_D", "D_ACK", "FLUSH_L", "PRUNE", "FLUSH_L", "CRASH"],\n'
       '             "expected": [1, False]},')
new = ('            {"name": "pruned while the source still holds its entry, then a restart",\n'
       '             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "ARRIVE", "CLAIM", "SAVE_D", "D_ACK",\n'
       '                        "FLUSH_L", "PRUNE", "FLUSH_L", "CRASH"],\n'
       '             "expected": [1, False]},\n'
       '            {"name": "pruned, then the source returns from a lost release write",\n'
       '             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "RELEASE", "SAVE_S_LOST",\n'
       '                        "ARRIVE", "CLAIM", "SAVE_D", "D_ACK", "FLUSH_L", "PRUNE", "FLUSH_L", "CRASH"],\n'
       '             "expected": [1, False]},')
assert t.count(old) == 1
g.write_text(t.replace(old, new), encoding="utf-8", newline="\n")
print("ok")
