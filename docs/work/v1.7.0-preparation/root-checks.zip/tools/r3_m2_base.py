import importlib.util
spec = importlib.util.spec_from_file_location("c", "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
n, out = c.Transit.explore(crashes=2, faults=1)
print(n, sorted(out.items()))
