import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for gated in (True, False):
    for crashes in (1, 2, 3):
        print("gated" if gated else "ungated", crashes, c.Delivery.explore(gated, crashes))
