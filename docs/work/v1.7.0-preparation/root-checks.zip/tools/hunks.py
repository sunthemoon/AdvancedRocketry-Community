"""Split the working-tree diff into hunks so separate fixes can be staged as separate commits.

Usage:
  hunks.py list <file>...              print hunk indexes with their first changed lines
  hunks.py stage <file> <i,j,...>      stage only the given hunks of one file (git apply --cached)
"""
import subprocess
import sys

ROOT = "D:/GitHub/AdvancedRocketry-Community"


def diff(path):
    out = subprocess.run(["git", "diff", "-U2", "--", path], cwd=ROOT, capture_output=True, check=True).stdout
    text = out.decode("utf-8")
    lines = text.splitlines(keepends=True)
    header, hunks, current = [], [], None
    for line in lines:
        if line.startswith("@@"):
            current = [line]
            hunks.append(current)
        elif current is None:
            header.append(line)
        else:
            current.append(line)
    return header, hunks


def main():
    action = sys.argv[1]
    if action == "list":
        for path in sys.argv[2:]:
            _, hunks = diff(path)
            print("==", path, len(hunks), "hunks")
            for index, hunk in enumerate(hunks):
                changed = [l.rstrip("\n") for l in hunk[1:] if l[:1] in "+-"][:3]
                print("  [%d] %s" % (index, hunk[0].strip()))
                for line in changed:
                    print("        " + line[:150])
    elif action == "stage":
        path, wanted = sys.argv[2], {int(x) for x in sys.argv[3].split(",") if x}
        header, hunks = diff(path)
        patch = "".join(header) + "".join("".join(h) for i, h in enumerate(hunks) if i in wanted)
        subprocess.run(["git", "apply", "--cached", "--unidiff-zero", "-"], cwd=ROOT, input=patch.encode("utf-8"),
                       check=True)
        print("staged", sorted(wanted), "of", len(hunks), "hunks in", path)


main()
