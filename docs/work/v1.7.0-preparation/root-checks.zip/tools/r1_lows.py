"""Round 1 Lows R1-L1..L14 (L4 and L13 were answered with R1-M8 and R1-M3/M4)."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(rel, pairs):
    p = REPO / rel
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (rel, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


A54 = "docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md"
patch(A54, [
    # L1
    ("- starts no new operation (every intent returns `SYSTEM_DISABLED`) and produces\n",
     "- starts no new operation (every operation-starting intent returns\n"
     "  `SYSTEM_DISABLED`; withdraw, unbind and other settlement intents still work)\n"
     "  and produces\n"),
    # L2
    ("5. **Spawn protection.** `MinecraftServer.isUnderSpawnProtection` for an\n"
     "   owner-bound FakePlayer (profile `owner_id`, name `[ARCE]`, no permission\n"
     "   level) is false for every position, else `TARGET_PROTECTED`.\n",
     "5. **Spawn protection.** The batch box does not intersect the vanilla spawn\n"
     "   protection square (a dedicated server's configured radius around the\n"
     "   Overworld spawn), tested once per box, else `TARGET_PROTECTED`. Unlike the\n"
     "   vanilla player check it is not bypassed when the device owner is an\n"
     "   operator, and it does not depend on the operator list being empty.\n"),
    # L3
    ("It exposes no internal type, no device object and no way to change the effect.\n"
     "Listeners may only cancel. Existing API classes keep their bytes; the API\n",
     "It exposes no internal type, no device object and no way to change the effect.\n"
     "Listeners may only cancel. Existing API classes keep their bytes, except\n"
     "`ApiVersions`, whose current-version constant becomes 1.8; the API\n"),
    # L5
    ("  `MISSING`), ≤ 256 bytes. At most 4,096 endpoints, 64 per owner.\n",
     "  `MISSING`), ≤ 512 bytes with a 128-character Level key and a full kind ID.\n"
     "  At most 4,096 endpoints, 64 per owner.\n"),
    ("- hard bound 4 MiB encoded; **growth admission**: endpoint registration, escrow\n"
     "  admission (§11), binds and zone additions are refused while the encoded root is\n"
     "  within 1 MiB of the bound;",
     "- hard bound 4 MiB encoded; **growth admission** is computed from per-record\n"
     "  accounting (each section's count times its worst-case record size, as ADR-050\n"
     "  §3 does), never by encoding the root: endpoint registration, escrow admission\n"
     "  (§11), binds and zone additions are refused while the accounted size is within\n"
     "  1 MiB of the bound;"),
    # L6
    ("- **Lines.** Every state-changing intent, refusal code change, effect batch\n"
     "  summary, ledger transition, reconciliation result, operator command and\n"
     "  quarantine writes one `ARCE_ENDGAME` line of at most 512 bytes:\n",
     "- **Lines.** Every state-changing intent, refusal code change, operator command,\n"
     "  quarantine and ledger anomaly (`CLAIM_RECOVERED`, `REMATERIALIZED`,\n"
     "  `REDIRECT_*`, `OUTBOX_STALE_DROPPED`, `SEQUENCE_GAP`, `SOURCE_ROLLBACK`,\n"
     "  `OUTBOX_LOST_ON_REMOVAL`, `REMOVAL_SETTLEMENT_UNKNOWN`) writes one\n"
     "  `ARCE_ENDGAME` line of at most 512 bytes. Routine ledger transitions (escrow,\n"
     "  registration, arrival, claim, acknowledgement, pruning) and effect batches are\n"
     "  aggregated into one summary line per system every 1,200 ticks (review R1-L6).\n"
     "  At most 64 lines per tick are written; the rest are counted and the count is\n"
     "  logged with the next summary. A line has the form\n"),
    ("  `system action result device owner actor` plus bounded fields. Coordinates\n",
     "  `system action result device owner actor` plus bounded fields. Coordinates\n"),
    # L7
    ("  `device inspect <pos>`; `device owner <pos> <player>`; `endpoint list\n",
     "  `device inspect <pos>` and `device owner <pos> <player>` (both refuse a\n"
     "  position whose chunk is not loaded, because reading it would load it);\n"
     "  `endpoint list\n"),
    # L8
    ("  are outside the guarantee, as in ADR-051 §7).\n",
     "  are outside the guarantee, as in ADR-051 §7). A `MISSING` endpoint still\n"
     "  counts toward its owner's limit until the owner removes it with\n"
     "  `/arce endgame endpoint forget <id>` (own `MISSING` endpoints only; the\n"
     "  tombstone of §11 stays).\n"),
    ("payload): `transfer redirect <source> <seq> <endpoint>` for an `IN_TRANSIT` or\n"
     "`ARRIVED` record to another endpoint of the same owner and system (ADR-051 §9\n"
     "residual applies); `transfer purge <source> <seq>` removes a record and destroys\n"
     "its payload.\n",
     "payload): `transfer redirect <source> <seq> <endpoint>` for an `IN_TRANSIT` or\n"
     "`ARRIVED` record to another endpoint of the same owner and system (ADR-051 §9\n"
     "residual applies); `transfer purge <source> <seq>` removes a record and destroys\n"
     "its payload. The **owner** may redirect their own `DESTINATION_MISSING` cargo to\n"
     "another of their compatible endpoints once the old destination's absence is\n"
     "established (its record was removed by §9.1, or it is `MISSING`); then the old\n"
     "destination cannot return with a receipt, so ADR-051 §9's residual does not\n"
     "apply (review R1-L8). An outbox payload that no longer decodes stays raw in S,\n"
     "is never registered, shows `OUTBOX_QUARANTINED`, and only an operator purge\n"
     "removes it.\n"),
    # L11 (outbox stores travel)
    ("most 4 entries `{seq, destination, payload, paid_fe, system}`. A payload is at\n",
     "most 4 entries `{seq, destination, payload, paid_fe, travel, system}`, with the\n"
     "travel time fixed at escrow (review R1-L11). A payload is at\n"),
    # L12
    ("- **Counts:** active devices per owner and globally, endpoints, transit records,\n"
     "  pairs and zones are capped (system ADRs and §10).\n",
     "- **Counts:** active devices per owner and globally, endpoints, transit records,\n"
     "  pairs and zones are capped (system ADRs and §10). Active-device counts are\n"
     "  kept by the runtime from loaded devices only; a device in an unloaded chunk is\n"
     "  not active (review R1-L12). A device that asks to become active is admitted\n"
     "  if its owner's and the global count allow, first come first served; devices\n"
     "  already active keep running when more load; a refused device shows\n"
     "  `ACTIVE_LIMIT` and retries every 200 ticks.\n"),
])

patch("docs/decisions/ADR-055-ORBITAL-LASER-DRILL.md", [
    # L9
    ("A stop leaves the layer untouched; nothing is half-broken. When\n"
     "`next_layer < floor` the shaft is `COMPLETE`. A shaft never breaks anything\n"
     "outside its footprint, never damages entities and never places blocks (no\n"
     "light-source blocks). Falling blocks and fluids next to the shaft follow vanilla\n"
     "physics.\n",
     "A stop leaves the layer untouched; nothing is half-broken. When\n"
     "`next_layer < floor` the shaft is `COMPLETE`. The drill itself removes only\n"
     "footprint cells, never damages entities and never places blocks (no\n"
     "light-source blocks); vanilla neighbour reactions still happen (the other half\n"
     "of a door, attached blocks, falling blocks, fluids, and entities standing on\n"
     "the footprint falling in) (review R1-L9). Break events are posted for every\n"
     "breakable cell before any cell is removed, so when a later cell's event is\n"
     "cancelled, listeners have seen events for cells that stay intact; logging or\n"
     "quest mods that count them should use the event's cancelled state.\n"),
    ("   add every drop to the marker buffer, set `next_layer −= 1`. A waterlogged\n"
     "   block leaves its fluid, which stops the next layer.\n",
     "   add every drop to the marker buffer, set `next_layer −= 1`. A waterlogged\n"
     "   block leaves its fluid, which may flow into the shaft and stop a later layer.\n"),
    ("- Physical mining runs only while the target area is loaded, typically with the\n"
     "  owner nearby.\n",
     "- Physical mining runs only while both the drill's station chunk and the target\n"
     "  area are loaded at the same time.\n"),
    # L10
    ("`default` table. The default reproduces the legacy proportion: one hit in ten is\n"
     "an ore entry of 5 items, nine in ten are 5 cobblestone.",
     "`default` table. The default reproduces the legacy proportion: one hit in ten is\n"
     "an ore entry (1 to 5 items), nine in ten are 5 cobblestone."),
])

patch("docs/decisions/ADR-056-RAILGUN-CARGO-AND-TARGETING.md", [
    ("`dz²))`, computed in 64-bit integers. Costs are multiplied by\n"
     "`endgame.railgun.energyPercent / 100` (10..1,000, default 100).",
     "`dz²))`, computed in 64-bit integers. Costs are multiplied by\n"
     "`endgame.railgun.energyPercent / 100` (10..400, default 100), so the largest\n"
     "cost, 1,000,000 FE, still fits the buffer (review R1-L11). The class, cost and\n"
     "travel are fixed at escrow and stored in the outbox entry."),
    ("before escrow change nothing: `NO_PAYLOAD`, `NO_TARGET`, `INSUFFICIENT_ENERGY`,\n"
     "`OUTBOX_FULL`, `TRANSIT_LIMIT`, `ROOT_FULL`, `SYSTEM_DISABLED`.",
     "before escrow change nothing: `SYSTEM_DISABLED`, `NOT_AUTHORIZED`, `NO_PAYLOAD`,\n"
     "`NO_TARGET`, `TARGET_FOREIGN`, `BODY_UNAVAILABLE`, `ROUTE_OUT_OF_SYSTEM`,\n"
     "`INSUFFICIENT_ENERGY`, `OUTBOX_FULL`, `TRANSIT_LIMIT`, `ROOT_FULL`."),
])

# L14 legacy audit
patch("docs/work/v1.7.0-legacy-audit.md", [
    ("| `tile/multiblock/orbitallaserdrill/TileOrbitalLaserDrill` (756 lines) |",
     "| `tile/multiblock/orbitallaserdrill/TileOrbitalLaserDrill` (757 lines) |"),
    ("| `VoidDrill.performOperation` (lines 266–280) |", "| `VoidDrill.performOperation` (lines 99–113) |"),
    ("| `MiningDrill.performOperation` (lines 45–119) |", "| `MiningDrill.performOperation` (lines 28–102) |"),
    ("| `MiningDrill.activate` (lines 121–146) |", "| `MiningDrill.activate` (lines 104–129) |"),
    ("The per-file hashes are in the preparation evidence (`upstream-audit-fetch.json`\n"
     "in `root-checks.zip`).",
     "The per-file hashes are in the preparation evidence packet\n"
     "(`upstream-audit-fetch.json` inside `root-checks.zip`, committed with the C10\n"
     "acceptance)."),
    ("1. Client packets set laser targets and the running state, and elevator buttons\n"
     "   dereference a null capsule on the server (§1, §5).",
     "1. Client packets set laser targets and the running state, packet 13 indexes\n"
     "   `MODE.values()` with an unchecked client integer (a server-side exception),\n"
     "   and elevator buttons dereference a null capsule on the server (§1, §5)."),
])

g = E / "tools/generate_examples.py"
s = g.read_text(encoding="utf-8")
old = '{"local": True, "dx": 30000000, "dz": 30000000, "percent": 1000, "expected": ["LOCAL", 2500000, 200]},'
assert s.count(old) == 1
s = s.replace(old, '{"local": True, "dx": 30000000, "dz": 30000000, "percent": 400, "expected": ["LOCAL", 1000000, 200]},\n'
                   '        {"local": False, "dx": 0, "dz": 0, "percent": 400, "expected": ["ORBITAL", 1000000, 600]},')
g.write_text(s, encoding="utf-8", newline="\n")

c = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
s = c.read_text(encoding="utf-8")
old = '''def railgun_quote(same_level_same_body, dx, dz, percent):
    if same_level_same_body:'''
assert s.count(old) == 1
s = s.replace(old, '''def railgun_quote(same_level_same_body, dx, dz, percent):
    if not 10 <= percent <= 400:  # R1-L11: the largest cost must fit the 1,000,000 FE buffer
        raise ValueError("railgun percent outside 10..400")
    if same_level_same_body:''')
old = '''        for case in EXAMPLES["railgun"]:
            self.assertEqual(railgun_quote(case["local"], case["dx"], case["dz"], case["percent"]),
                             case["expected"], case)'''
assert s.count(old) == 1
s = s.replace(old, old + '''
            self.assertLessEqual(case["expected"][1], 1_000_000)  # fits the railgun buffer''')
c.write_text(s, encoding="utf-8", newline="\n")
print("ok")
