"""R3-L6: Redirect model removes D with a receive buffer or a due move; prune waits for the persisted move;
resolve keeps a payload claimed at this endpoint (acknowledged or not)."""
import sys
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
s = p.read_text(encoding="utf-8")
STAGE = sys.argv[1] if len(sys.argv) > 1 else "all"  # "removal" applies only the wider removal (shows the loss)


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


# Removal with a receive buffer or a due move; dropped items stay in D's chunk.
sub("""        unacked_here = rec is not None and rec[1] == "D" and not rec[2]
        due_move = d_in == "P" and (rec is None or rec[2])
        if d_active and d_buf == 0 and not due_move:
            # Removal through onRemove (ADR-054 section 9.1): live settlement, retirement and index removal in one
            # barrier flush. A mover keeps D's data and may place it again later.
            if unacked_here:
                settled = ("C", "D", True, e) if d_rc is not None and not d_in else ("A", "D", False, None)
            else:
                settled = rec
            barrier = dict(rec=settled, rec_dur=settled, retired=retire, retired_dur=retire, registered=False,
                           registered_dur=False, e=e + 1, e_dur=e + 1)
            yield "REMOVE_D", make(d=("gone", 0, 0, None), **barrier), c
            yield "PICKUP_D", make(d=("carried", 0, 0, None), carried=(d_in, d_rc), **barrier), c
            # A block entity lost without onRemove (no settlement), later found MISSING.
            yield "VANISH_D", make(d=("gone", 0, 0, None)), c
            yield "VANISH_CARRIED_D", make(d=("carried", 0, 0, None), carried=(d_in, d_rc)), c
""", """        unacked_here = rec is not None and rec[1] == "D" and not rec[2]
        due_move = d_in == "P" and (rec is None or rec[2])
        if d_active:
            # Removal through onRemove (ADR-054 section 9.1): live settlement, retirement and index removal in one
            # barrier flush. The receive buffer and a due move (an incoming payload whose record is acknowledged
            # here or pruned: D's own content) drop as items into D's chunk (R3-L6); a mover keeps them instead
            # and may place D again later.
            if unacked_here:
                settled = ("C", "D", True, e) if d_rc is not None and not d_in else ("A", "D", False, None)
            else:
                settled = rec
            barrier = dict(rec=settled, rec_dur=settled, retired=retire, retired_dur=retire, registered=False,
                           registered_dur=False, e=e + 1, e_dur=e + 1)
            own = d_buf + (1 if due_move else 0)
            yield "REMOVE_D", make(d=("gone", 0, own, None), **barrier), c
            yield "PICKUP_D", make(d=("carried", 0, 0, None), carried=(0 if due_move else d_in, d_rc, own),
                                   **barrier), c
            if not due_move:
                # A block entity lost without onRemove (no settlement), later found MISSING. One that vanishes
                # loses its receive buffer with it, outside the protocol, so only an empty one vanishes; a mover
                # that bypasses onRemove carries the buffer.
                if d_buf == 0:
                    yield "VANISH_D", make(d=("gone", 0, 0, None)), c
                yield "VANISH_CARRIED_D", make(d=("carried", 0, 0, None), carried=(d_in, d_rc, d_buf)), c
""")
sub("""        elif d_dur[0]:
            yield "SAVE_D", make(d_dur=(False, 0, 0, False)), c
""", """        elif d_dur != (False, 0, d_buf, False):
            # D's chunk saves its absence and the items a removal dropped there.
            yield "SAVE_D", make(d_dur=(False, 0, d_buf, False)), c
""")
sub("""            yield "PLACE_D", make(d=("here", "U" if carried[0] else 0, 0, "U" if carried[1] else None),
                                  carried=None), c
""", """            yield "PLACE_D", make(d=("here", "U" if carried[0] else 0, carried[2], "U" if carried[1] else None),
                                  carried=None), c
""")
sub("""            restored = ("here", "P" if inc else 0, buf, "P" if rc else None) if present else \\
                (("carried", 0, 0, None) if where == "carried" else ("gone", 0, 0, None))
""", """            restored = ("here", "P" if inc else 0, buf, "P" if rc else None) if present else \\
                (("carried", 0, 0, None) if where == "carried" else ("gone", 0, buf, None))
""")
# A crash restores one consistent snapshot: when D's chunk still holds D, the mover's copy is gone with the rest of
# the unsaved world. Both together are a torn save across two stores, the container class of section 11.
sub("""                                          registered_dur, restored, d_dur, carried if where == "carried" else None,
""", """                                          registered_dur, restored, d_dur,
                                          carried if where == "carried" and not present else None,
""")

if STAGE == "all":
    sub("""        if rec is not None and rec[2] and e > rec[3]:
            yield "PRUNE", make(rec=None), c
""", """        if rec is not None and rec[2] and e > rec[3] and not (d_dur[1] if rec[1] == "D" else ee_dur[0]):
            # R3-L6: a record is pruned only once its paid endpoint's chunk no longer holds the payload as incoming
            # (the move is saved, or the endpoint is gone), so a retired copy that a crash restores still finds
            # the record saying the payload is its own.
            yield "PRUNE", make(rec=None), c
""")
    sub("""            if d_in and rec is not None and rec[0] == "C" and rec[1] == "D" and not rec[2]:
                yield "RESOLVE_D", make(d=(where, 0, d_buf + 1, None), rec=("C", "D", True, e)), c
""", """            if d_in and rec is not None and rec[0] == "C" and rec[1] == "D":
                # Claimed here: unacknowledged (a failed settlement write, R3-M1) or acknowledged (a crash undid D's
                # own move, R3-L6). Either way the payload is D's and joins its receive buffer.
                yield "RESOLVE_D", make(d=(where, 0, d_buf + 1, None), rec=rec if rec[2] else ("C", "D", True, e)), c
""")
    sub("""            # Operator resolve: move a frozen incoming payload only if its record is still claimed and
            # unacknowledged at D; otherwise destroy it. Receipts are dropped.
""", """            # Operator resolve: move a frozen incoming payload only if its record is still claimed at D;
            # otherwise destroy it. Receipts are dropped.
""")
    sub("""    payloads or receipts, so evicting its tombstone (`evict`, an adversary allowed to do so at any time) cannot
    bring it back; claims need the destination's registration to be durable; a retirement without live state
    (`MISSING`) returns D's unacknowledged claims to ARRIVED (R3-M1); an operator `resolve` moves a frozen
    incoming payload only when its record is still claimed and unacknowledged at D and destroys it otherwise.
""", """    payloads or receipts, so evicting its tombstone (`evict`, an adversary allowed to do so at any time) cannot
    bring it back; claims need the destination's registration to be durable; a retirement without live state
    (`MISSING`) returns D's unacknowledged claims to ARRIVED (R3-M1); an operator `resolve` moves a frozen
    incoming payload only when its record is still claimed at D and destroys it otherwise; a record is pruned
    only after its paid endpoint's chunk saved the move or the endpoint's absence (R3-L6). D can be removed
    with a non-empty receive buffer or a due move, which drop into its chunk or travel with a mover; a mover
    that bypasses onRemove is not modelled with a due move (the residual stated in ADR-054 section 9).
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok", STAGE)
