import importlib.util
spec = importlib.util.spec_from_file_location("c", "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation/check_examples.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
R = c.Redirect
n, out = R.explore((True, True, True), 2)
print("full rules", n, sorted(out.items(), key=str))
path = ["CLAIM_D", "SAVE_D", "MOVE_D", "FLUSH_L", "REMOVE_D", "CRASH"]
state = R.normalize(R.initial())
for label in path:
    options = {l: s for l, s, _ in R.successors(state, (True, True, True), 1)}
    assert label in options, (label, sorted(options))
    state = options[label]
print("path", path, "->", R.outcome(state, (True, True, True)))
