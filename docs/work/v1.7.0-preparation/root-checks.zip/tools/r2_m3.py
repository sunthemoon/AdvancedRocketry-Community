"""R2-M3 (size accounting and caps) and R2-L3 (P99 vs flush ticks)."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("with 4 rides per minute, 512 transit records, 4,096 endpoints and 8,192\n"
     "tombstones, on top of the docs/17 §4 reference load.\n",
     "with 4 rides per minute, 256 transit records, 1,024 endpoints and 1,024\n"
     "tombstones (a root of about 1.1 MiB), on top of the docs/17 §4 reference load.\n"),
    ("| All endgame work at the endgame reference load | mean ≤ 2.0 ms, P99 ≤ 8 ms per tick |",
     "| All endgame work at the endgame reference load | mean ≤ 2.0 ms per tick over all ticks; P99 ≤ 8 ms over the ticks without an endgame flush (review R2-L3) |"),
    ("| One barrier flush of a root at the 4 MiB bound | ≤ 50 ms |\n"
     "| Memory | root ≤ 4 MiB encoded and ≤ 32 MiB of accounted heap; field index ≤ 1,024 entries; audit ring 512 lines; one device view ≤ 8 KiB per open menu |",
     "| One coalesced or barrier flush | ≤ 60 ms at the reference root, ≤ 250 ms at the accounted maximum (§10, about 2.4 MiB); at most one coalesced flush per 100 ticks plus the spaced barriers; a flush tick is its own budget, inside docs/17 §4's 500 ms spike limit |\n"
     "| Memory | root ≤ 4 MiB encoded (accounted maximum about 2.4 MiB) and ≤ 32 MiB of accounted heap; field index ≤ 1,024 entries; audit ring 512 lines; one device view ≤ 8 KiB per open menu |"),
    ("budget that C13 cannot meet keeps the version blocked; in particular a barrier\n"
     "flush over 50 ms at the bound requires a follow-up ADR that moves the write to\n",
     "budget that C13 cannot meet keeps the version blocked; in particular a flush\n"
     "over its limit requires a follow-up ADR that moves the write to\n"),
    ("  `MISSING`), ≤ 512 bytes with a 128-character Level key and a full kind ID.\n"
     "  At most 4,096 endpoints, 64 per owner.\n",
     "  `MISSING`), ≤ 384 bytes (two UUIDs, a kind ID of at most 64 characters, a\n"
     "  Level key of at most 128 characters, a position and a state). At most 2,048\n"
     "  endpoints, 64 per owner (review R2-M3).\n"),
    ("- hard bound 4 MiB encoded; **growth admission** is computed from per-record\n"
     "  accounting (each section's count times its worst-case record size, as ADR-050\n"
     "  §3 does), never by encoding the root: endpoint registration, escrow admission\n"
     "  (§11), binds and zone additions are refused while the accounted size is within\n"
     "  1 MiB of the bound; a registration of an already escrowed payload and\n"
     "  every reconciliation step are admitted up to the bound itself, and beyond it\n"
     "  wait (never drop) with `ROOT_FULL`;\n",
     "- hard bound 4 MiB encoded; **growth admission** is computed from per-record\n"
     "  accounting (each section's count times its worst-case record size, as ADR-050\n"
     "  §3 does), never by encoding the root (review R2-M3). The worst cases are:\n"
     "  2,048 endpoints × 384 B, 2,048 `dispatched_through` entries × 32 B, 256\n"
     "  transit records × 2.5 KiB, 4,096 tombstones × 64 B, 1,024 pairs × 512 B and\n"
     "  256 zones × 768 B, about 2.4 MiB in total, so **every cap can be reached at\n"
     "  the same time**. Endpoint registration, escrow admission (§11), binds and\n"
     "  zone additions are refused only when the accounted size would pass 3 MiB;\n"
     "  tombstones beyond 4,096, a registration of an already escrowed payload and\n"
     "  every reconciliation step are admitted up to the 4 MiB bound itself, and\n"
     "  beyond it wait (never drop) with `ROOT_FULL`;\n"),
    ("**Record** (≤ 4 KiB): `source`, `seq`, `system`, `owner_id`, `destination`,",
     "**Record** (≤ 2.5 KiB: a payload of at most 2 KiB plus at most 512 bytes of\n"
     "fields): `source`, `seq`, `system`, `owner_id`, `destination`,"),
    ("**and** the table holds more than 8,192 tombstones, oldest observation first;\n"
     "otherwise tombstones are kept, admitted up to the root's hard bound. A block\n"
     "mover could still carry a retired endpoint away and place it after its\n"
     "tombstone was removed; that needs more than 8,192 later retirements in between\n"
     "and is the documented residual of the retirement rule. Residual: if the absence observation itself was a lost\n"
     "asynchronous write and the server then crashed, S could return after its\n"
     "tombstone was removed and register a delivered payload again, unaudited. The\n"
     "6,000-tick age (five minutes of uninterrupted running, far beyond any `IOWorker`\n"
     "backlog) and the pressure rule make that unreachable in practice; it is the\n"
     "same lost-write class as the escrow residual below. Limits: 512 records globally, 32 per owner, counting live\n"
     "outbox entries known to the server.",
     "**and** the table holds more than 4,096 tombstones, oldest observation first;\n"
     "otherwise tombstones are kept, admitted up to the root's hard bound. Because\n"
     "the absence must be read back from disk after a start, a lost absence write\n"
     "can no longer remove a tombstone. A block mover could still carry a retired\n"
     "endpoint away and place it after its tombstone was removed; that needs more\n"
     "than 4,096 later retirements in between and is the documented residual of the\n"
     "retirement rule. Limits: 256 records globally, 32 per owner, counting live\n"
     "outbox entries known to the server."),
])
patch("ADR-056-RAILGUN-CARGO-AND-TARGETING.md", [
    ("| Ledger growth | 512 records, 32 per owner, 4 outbox entries per railgun, root admission |",
     "| Ledger growth | 256 records, 32 per owner, 4 outbox entries per railgun, root admission (ADR-054 §10) |"),
])
print("ok")
