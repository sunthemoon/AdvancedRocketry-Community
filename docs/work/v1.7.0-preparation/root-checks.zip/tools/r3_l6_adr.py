"""R3-L6 found loss: resolve keeps a retired copy's own move; records prune after the paid endpoint saved the move."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""  - a frozen incoming payload whose record is still `CLAIMED` and unacknowledged
    at this endpoint (only after a failed settlement write, §9.1) moves to the
    local receive buffer and the record is acknowledged; every other frozen
    incoming payload (record absent, `ARRIVED`, redirected, or acknowledged
    anywhere) is destroyed with an audit line;
""", """  - a frozen incoming payload whose record is `CLAIMED` at this endpoint moves to
    the local receive buffer. The record is unacknowledged only after a failed
    settlement write (§9.1), and is then acknowledged. It is acknowledged when a
    crash undid the endpoint's own move after the acknowledgement became durable:
    the player broke the endpoint, and the server stopped before its chunk saved
    the move (review R3-L6). Every other frozen incoming payload (record absent,
    `ARRIVED`, or naming another endpoint) is destroyed with an audit line. The
    pruning rule of §11 keeps a record paid here until this endpoint's chunk has
    saved the move, so an absent record never hides the endpoint's own payload;
""")

sub("""  redirected; a returning copy is frozen and `resolve` destroys it. Residual: if
""", """  redirected; a returning copy is frozen and `resolve` destroys it. `endpoint
  retire` also prunes the stubs paid at the endpoint (§11), because its chunk
  may never load again to show the saved move. Residual: if
""")

sub("""**Pruning.** A record is removed once its acknowledgement is durable, whether or
not S has already dropped its entry; the `dispatched_through` rule above makes a
late drop safe. `dispatched_through[S]` is removed only as a tombstone whose
""", """**Pruning.** A record is removed once its acknowledgement is durable **and** a
chunk-save or chunk-load tag of its paid endpoint's chunk, observed at least 40
ticks after the acknowledgement, holds no incoming payload for it: the move is
saved, or the endpoint is gone (review R3-L6). Until then the record is a
**stub**. Its payload is dropped (≤ 128 B remain), it no longer counts toward its
owner's 32 records, and it keeps its place among the 256. The stub is the
evidence that a payload restored as incoming at a retired endpoint is that
endpoint's own (§9): without it, the reference model loses that payload when
the player breaks the endpoint after its move and the server stops before the
chunk saves. Because the incoming gate already waits for one save before a
move, a stub lives at most one more save interval. Pruning does not wait for S
to drop its entry; the `dispatched_through` rule above makes a late drop safe.
`dispatched_through[S]` is removed only as a tombstone whose
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
