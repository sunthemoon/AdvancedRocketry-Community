import sys
from pathlib import Path

sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_mutations as cm

out = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb/r3m2-mut")
COND = 'absence_seen in ("saved_aged", "aged") \\\n                and not records:'
cases = {
    "evict-before-saved-absence": (COND, 'True \\\n                and not records:'),
    "evict-without-freeze": ("            if out_seqs:\n                lost =", "            if False:\n                lost ="),
    "evict-pinned": (COND, 'absence_seen in ("saved_aged", "aged"):'),
    "escrow-before-durable-registration": ("\\\n                and not isinstance(l_dur[1], tuple):", ":"),
}
for name, (old, new) in cases.items():
    m = cm.load(out, "cap-" + name, old, new)
    m.Transit.CAP_EVICTION = True
    for faults in (0, 1):
        print(name, faults, cm.transit_violation(m, faults), flush=True)
