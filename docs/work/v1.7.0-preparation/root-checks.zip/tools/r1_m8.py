"""R1-M8: chunk-edge effects (laser footprint, neighbour chunks, black-hole push, device tick set)."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-055-ORBITAL-LASER-DRILL.md", [
    ("the shaft cursor and the link counter (below). Its footprint is the 3 × 3 column\n"
     "centred on it; the footprint must lie inside the marker's own chunk (local x and\n"
     "z in 1..14), else the marker is `FOOTPRINT_CROSSES_CHUNK` and cannot be selected.\n",
     "the shaft cursor and the link counter (below). Its footprint is the 3 × 3 column\n"
     "centred on it. The marker must sit at local x and z 2..13 of its chunk, so every\n"
     "footprint cell is at local 1..14 and every block a removal directly updates\n"
     "(the six neighbours of each cell) is still inside that chunk (review R1-M8);\n"
     "otherwise the marker is `FOOTPRINT_AT_CHUNK_EDGE` and cannot be selected.\n"),
    ("3. the drill's and the marker's chunks are `FULL` (`TARGET_UNLOADED`);\n",
     "3. the drill's chunk and the 3 × 3 chunks centred on the marker's chunk are\n"
     "   `FULL` (`TARGET_UNLOADED`), so cascading neighbour updates (falling blocks,\n"
     "   redstone, attached blocks) never load or upgrade a chunk;\n"),
    ("| Digging others' land | Physical mode off by default; marker placed by the owner through vanilla placement; ADR-054 §5 chain per layer including break events and zones; 3 × 3 footprint inside the marker's own chunk; depth cap |",
     "| Digging others' land | Physical mode off by default; marker placed by the owner through vanilla placement; ADR-054 §5 chain per layer including break events and zones; 3 × 3 footprint at least one block inside the marker's own chunk; depth cap |\n"
     "| Loading chunks through neighbour updates | Footprint at local 1..14; the 3 × 3 surrounding chunks must be `FULL` before each layer |"),
])
patch(REPO / "docs/decisions/ADR-057-BLACK-HOLE-GENERATOR.md", [
    ("3. Push up to 20,000 FE per tick in total to adjacent energy receivers, in a\n"
     "   fixed face order.\n",
     "3. Push up to 20,000 FE per tick in total to adjacent energy receivers, in a\n"
     "   fixed face order, skipping any neighbour whose chunk is not present\n"
     "   (`getChunkNow`), so a generator at a chunk edge never loads its neighbour\n"
     "   (review R1-M8).\n"),
])
patch(REPO / "docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("All endgame work runs in one `ServerTickEvent` END handler. C13 measures its time\n"
     "separately from vanilla MSPT (Forge records `tickTimes` before END handlers).\n",
     "**Where work runs** (reviews R1-M8, R1-L4). Devices act from their block-entity\n"
     "ticker, which vanilla runs only in block-ticking chunks, and draw on the\n"
     "per-tick system budgets above. Ledger, index and reconciliation passes run in\n"
     "one `ServerTickEvent` END handler. The gravity-field lookup runs in the existing\n"
     "living-tick hook (ADR-058). Any read of a position outside the device's own\n"
     "block goes through `getChunkNow` (or `hasChunkAt`) first and treats an absent\n"
     "chunk as unavailable, because `Level.getBlockState` and `getBlockEntity` load\n"
     "chunks. C13 measures all three places against total tick time, because Forge\n"
     "records `tickTimes` before END handlers run (§7 budgets).\n"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ('''def footprint_inside_chunk(mx, mz):
    """Java `x & 15` equals Python `x & 15` for negative ints (two's complement)."""
    return 1 <= (mx & 15) <= 14 and 1 <= (mz & 15) <= 14''',
     '''def footprint_inside_chunk(mx, mz):
    """R1-M8: marker at local 2..13, so cells (local 1..14) and their direct neighbours stay in the chunk.

    Java `x & 15` equals Python `x & 15` for negative ints (two's complement).
    """
    return 2 <= (mx & 15) <= 13 and 2 <= (mz & 15) <= 13


def neighbours_inside_chunk(mx, mz):
    """Every direct neighbour of every footprint cell is in the marker's chunk."""
    chunk = (mx >> 4, mz >> 4)
    for x, z in shaft_cells(mx, mz):
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if ((x + dx) >> 4, (z + dz) >> 4) != chunk:
                return False
    return True'''),
    ('''            self.assertEqual(footprint_inside_chunk(mx, mz), case["inside_chunk"], case)''',
     '''            self.assertEqual(footprint_inside_chunk(mx, mz), case["inside_chunk"], case)
            self.assertEqual(neighbours_inside_chunk(mx, mz), case["inside_chunk"], case)'''),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ('''        {"marker": [-2, 100, -15], "inside_chunk": True, "max_depth": 64, "min_build_height": -64, "floor": 36,''',
     '''        {"marker": [-2, 100, -15], "inside_chunk": False, "max_depth": 64, "min_build_height": -64, "floor": 36,'''),
    ('''        {"marker": [14, 0, 1], "inside_chunk": True, "max_depth": 64, "min_build_height": -64, "floor": -63,''',
     '''        {"marker": [14, 0, 1], "inside_chunk": False, "max_depth": 64, "min_build_height": -64, "floor": -63,'''),
    ('''        {"marker": [15, 0, 1], "inside_chunk": False, "max_depth": 64, "min_build_height": -64, "floor": -63,
         "cells": [[14, 0], [15, 0], [16, 0], [14, 1], [15, 1], [16, 1], [14, 2], [15, 2], [16, 2]]},''',
     '''        {"marker": [15, 0, 1], "inside_chunk": False, "max_depth": 64, "min_build_height": -64, "floor": -63,
         "cells": [[14, 0], [15, 0], [16, 0], [14, 1], [15, 1], [16, 1], [14, 2], [15, 2], [16, 2]]},
        {"marker": [2, 40, 13], "inside_chunk": True, "max_depth": 64, "min_build_height": -64, "floor": -24,
         "cells": [[1, 12], [2, 12], [3, 12], [1, 13], [2, 13], [3, 13], [1, 14], [2, 14], [3, 14]]},
        {"marker": [-3, 40, -14], "inside_chunk": True, "max_depth": 64, "min_build_height": -64, "floor": -24,
         "cells": [[-4, -15], [-3, -15], [-2, -15], [-4, -14], [-3, -14], [-2, -14], [-4, -13], [-3, -13], [-2, -13]]},
        {"marker": [1, 40, 8], "inside_chunk": False, "max_depth": 64, "min_build_height": -64, "floor": -24,
         "cells": [[0, 7], [1, 7], [2, 7], [0, 8], [1, 8], [2, 8], [0, 9], [1, 9], [2, 9]]},'''),
])
print("ok")
