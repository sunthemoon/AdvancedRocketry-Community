"""R3-H1 (freeze unregistered IDs carrying contents; durable registration for escrow, claim and selection;
redirect after the durable index removal) and R3-M1 (non-live retirement un-claims; resolve per item)."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""- **Registration.** An endpoint is added when its ID is persisted (§2); until
  then it is `AWAITING_WORLD_SAVE` and cannot be selected. Registration is a
  flush-pending mutation (§10). Placement beyond the limits is allowed, but the
  endpoint stays `ENDPOINT_LIMIT` and inert.
""", """- **Registration.** An endpoint is added when its ID is persisted (§2); until
  then it is `AWAITING_WORLD_SAVE` and cannot be selected. Registration is a
  flush-pending mutation (§10). Placement beyond the limits is allowed, but the
  endpoint stays `ENDPOINT_LIMIT` and inert. Registration reads the endpoint's
  entry in that persistence tag: if the ID is retired, or the entry holds any
  outbox entry, incoming payload or receipt, the endpoint does not register and
  is `ENDPOINT_RETIRED` (frozen) instead (review R3-H1). A legitimate endpoint
  never holds them unregistered, because being selected as a destination,
  escrowing at a source and claiming at a destination all require the
  endpoint's registration to be **durable** (§11). So a copy that comes back
  after its tombstone was evicted (§11) is frozen like a retired one, and the
  retirement no longer depends on keeping tombstones.
""")
sub("""  registers again. Breaking it drops only its local buffers. An operator resolves
  it with `/arce endgame endpoint resolve <id>` (one audited barrier flush):
  frozen unregistered outbox entries (`seq > dispatched_through`) go back to its
  local input buffer, because the ledger can never register them; frozen
  incoming payloads and receipts are destroyed, because their records were
  settled at removal and are delivered elsewhere. A player who finds a retired
  device places a new one, which gets a new ID.
""", """  registers again. Breaking it drops only its local buffers. An operator resolves
  it with `/arce endgame endpoint resolve <id>` (one audited barrier flush), item
  by item (review R3-M1):
  - a frozen outbox entry goes back to the local input buffer only if the ID's
    tombstone still records `dispatched_through` and `seq` is above it (the
    ledger can never register it); otherwise it is discarded with an audit line,
    because it was registered and delivered, or nothing proves it was not;
  - a frozen incoming payload whose record is still `CLAIMED` and unacknowledged
    at this endpoint (only after a failed settlement write, §9.1) moves to the
    local receive buffer and the record is acknowledged; every other frozen
    incoming payload (record absent, `ARRIVED`, redirected, or acknowledged
    anywhere) is destroyed with an audit line;
  - frozen receipts are dropped.

  A player who finds a retired device places a new one, which gets a new ID.
- **Retirement without live state** (review R3-M1). An endpoint retired as
  `MISSING`, or by an operator's `endpoint retire`, has no block entity to
  settle from. Its retirement's barrier flush therefore also returns every
  `CLAIMED`, unacknowledged record paid at it to `ARRIVED`, so the cargo can be
  redirected; a returning copy is frozen and `resolve` destroys it. Residual: if
  that endpoint had already moved the payload to its receive buffer, the
  acknowledgement was lost in a crash, and a player had taken the payload out,
  it can be delivered twice (the ADR-051 §9 class). For `MISSING` this also
  needs the block entity to vanish without `onRemove`.
""")
sub("""   buffer. Requires §3 `OPERATE` (or the system's redstone path), the system
   enabled, the root operational with admission room, a selected `ACTIVE`
   destination passing the system's route rule, a free outbox slot, the limits
   and the energy.
""", """   buffer. Requires §3 `OPERATE` (or the system's redstone path), the system
   enabled, the root operational with admission room, S's own registration and
   the selected `ACTIVE` destination's registration both durable (R3-H1), the
   destination passing the system's route rule, a free outbox slot, the limits
   and the energy.
""")
sub("""the record is durable, D's ID is persisted, D's receive buffer has room for the
""", """the record is durable, D's registration is durable (R3-H1), D's receive buffer
has room for the
""")
sub("""record to another endpoint, but only once its destination's retirement is
durable, so ADR-051 §9's double-payment residual cannot arise: a retired
destination that returns is inert (review R2-H1); `transfer purge <source>""",
    """record to another endpoint, but only once its destination's **index removal**
is durable (by removal, `MISSING` or `endpoint retire`), so ADR-051 §9's
double-payment residual cannot arise: a returning destination is retired, or
after a tombstone eviction frozen by the registration rule, and so inert
(reviews R2-H1, R3-H1); `transfer purge <source>""")
sub("""| Possible double delivery (ADR-051 §9 class), audited; a `MISSING` or removed endpoint, the only case an owner can redirect, cannot reach it, because §9.1 settles a loaded endpoint's claims from its live state |""",
    """| Possible double delivery (ADR-051 §9 class), audited. A removed endpoint cannot reach it, because §9.1 settles its claims from its live state; a `MISSING` one can only if its block entity vanished without `onRemove` after a lost acknowledgement (see "Retirement without live state", §9) |""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
