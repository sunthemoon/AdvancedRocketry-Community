"""R1-H3 checker tests, pins, named cuts and mutation harness updates."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/work/v1.7.0-preparation/check_examples.py", [
    ("        states, outcomes = Transit.explore(crashes=2, faults=0, payloads=2)\n"
     "        self.assertEqual(set(outcomes), {(2, False, False)}, outcomes)\n",
     "        states, outcomes = Transit.explore(crashes=2, faults=0, payloads=2)\n"
     "        for buffer, destroyed, rollback, faulted in outcomes:\n"
     "            self.assertFalse(rollback or faulted)\n"
     "            self.assertLessEqual(buffer, 2)  # never a duplicate\n"
     "            # A loss only where a forced removal destroyed escrowed cargo (R1-H3, audited).\n"
     "            self.assertGreaterEqual(buffer + destroyed, 2)\n"),
    ("        for (delivered, rollback, faulted), _ in outcomes.items():\n"
     "            self.assertIn(delivered, (1, 2))\n"
     "            if delivered == 2:\n"
     "                self.assertTrue(faulted and rollback, outcomes)  # only after a lost write, always audited\n"
     "            if not faulted:\n"
     "                self.assertEqual((delivered, rollback), (1, False))\n"
     "        self.assertIn((2, True, True), outcomes)  # the residual is reachable, as documented\n",
     "        for (delivered, destroyed, rollback, faulted), _ in outcomes.items():\n"
     "            self.assertGreaterEqual(delivered + destroyed, 1)\n"
     "            if delivered > 1:\n"
     "                self.assertTrue(faulted and rollback, outcomes)  # only after a lost write, always audited\n"
     "            if not faulted:\n"
     "                self.assertLessEqual(delivered, 1)\n"
     "                self.assertFalse(rollback)\n"
     "        self.assertIn((2, 0, True, True), outcomes)  # the residual is reachable, as documented\n"),
    ("        unaudited = {key for key in outcomes if key[0] == 2 and not key[1]}\n"
     "        self.assertEqual(unaudited, {(2, False, True)})  # only after a lost write, as ADR-054 section 11 states\n",
     "        unaudited = {key for key in outcomes if key[0] > 1 and not key[2]}\n"
     "        self.assertTrue(unaudited)\n"
     "        self.assertTrue(all(key[3] for key in unaudited))  # only after a lost write, as ADR-054 section 11 states\n"),
    ("    def test_delivery_without_the_gate_reproduces_f02(self):\n",
     "    def test_delivery_removal_settles_once(self):\n"
     "        for case in EXAMPLES[\"delivery\"][\"removal_cuts\"]:\n"
     "            state = Delivery.normalize(Delivery.initial())\n"
     "            for label in case[\"events\"]:\n"
     "                state = {l: s for l, s, _ in Delivery.successors(state, True, 1)}[label]\n"
     "            self.assertEqual(list(Delivery.outcome(state, True)), case[\"expected\"], case[\"name\"])\n"
     "\n"
     "    def test_delivery_without_the_gate_reproduces_f02(self):\n"),
])

g = E / "tools/generate_examples.py"
s = g.read_text(encoding="utf-8")
s = s.replace('"states_two_payloads_two_crashes": 54060', '"states_two_payloads_two_crashes": 86112')
s = s.replace('"states_one_payload_two_crashes_one_lost_write": 15467', '"states_one_payload_two_crashes_one_lost_write": 22060')
s = s.replace('"states_tombstone_removal_one_lost_write": 21668', '"states_tombstone_removal_one_lost_write": 34158')
s = s.replace('"states_gated_two_crashes": 1038', '"states_gated_two_crashes": 1314')
# Named transit cuts gain the destroyed count: [delivered, destroyed, rollback].
s = s.replace('"expected": [1, False]},', '"expected": [1, 0, False]},')
s = s.replace('"expected": [2, True]},', '"expected": [2, 0, True]},')
old = '''            {"name": "residual: escrow write lost after registration was flushed",'''
new = '''            {"name": "R1-H3: forced removal of a source with a persisted, unregistered entry",
             "events": ["ESCROW", "SAVE_S", "REMOVE_S", "SAVE_S", "CRASH"], "expected": [0, 1, False]},
            {"name": "R1-H3: forced removal after the record was durable: delivered, never dropped",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "SAVE_S", "CRASH"],
             "expected": [1, 1, False]},
            {"name": "R1-H3: forced removal, crash before the removal was saved",
             "events": ["ESCROW", "SAVE_S", "REMOVE_S", "CRASH"], "expected": [1, 0, False]},
            {"name": "residual: escrow write lost after registration was flushed",'''
assert s.count(old) == 1
s = s.replace(old, new)
old = '''        "f02_path_gated": ["CLAIM", "FLUSH_L"],'''
new = '''        "f02_path_gated": ["CLAIM", "FLUSH_L"],
        "removal_cuts": [
            {"name": "removal while the claim is incoming: back to ARRIVED, redirected, paid once",
             "events": ["CLAIM", "SAVE_D", "REMOVE_D", "SAVE_D"], "expected": [1, False]},
            {"name": "removal while incoming, crash before the removal was saved: re-claimed once",
             "events": ["CLAIM", "SAVE_D", "REMOVE_D", "CRASH"], "expected": [1, False]},
            {"name": "removal after the move and withdrawal: acknowledged, not paid again",
             "events": ["CLAIM", "SAVE_D", "MOVE", "WITHDRAW", "SAVE_P", "REMOVE_D", "SAVE_D"], "expected": [1, False]},
        ],'''
assert s.count(old) == 1
s = s.replace(old, new)
g.write_text(s, encoding="utf-8", newline="\n")

m = E / "tools/mutations.py"
patch(m, [
    ("        if outcome != (1, False):\n"
     "            return \"violation (delivered %s)\" % (outcome,), len(seen), path\n",
     "        if outcome[0] > 1 or outcome[0] + outcome[1] < 1 or outcome[2]:\n"
     "            return \"violation (delivered %s)\" % (outcome,), len(seen), path\n"),
])
mf = E / "tools/mutations_fault.py"
s = mf.read_text(encoding="utf-8")
s = s.replace('            o = ("stuck",)', '            o = ("stuck",)\n        o = tuple(o)')
mf.write_text(s, encoding="utf-8", newline="\n")
print("ok")
