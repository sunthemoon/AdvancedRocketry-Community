import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
D = c.Delivery
for gated in (True, False):
    seen, stack = set(), [(D.normalize(D.initial()), 1, ())]
    found = None
    while stack and not found:
        state, left, path = stack.pop()
        if (state, left) in seen:
            continue
        seen.add((state, left))
        if D.outcome(state, gated) == (2, False):
            found = (path, state)
            break
        for label, s2, l2 in D.successors(state, gated, left):
            stack.append((s2, l2, path + (label,)))
    print("gated" if gated else "ungated", found)
