"""R1-M10: a bounded S2C device-view message on a new S2C-only channel; endpoint labels instead of names."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("- **No new network channel and no new C2S message.** Status reaches the client\n"
     "  through menu data slots and bounded menu extra data (≤ 4 KiB per menu, tested\n"
     "  at maximum), and visuals through block-entity update tags (≤ 1 KiB, only\n"
     "  render state: active flag, beam length, field radius and value, never a target\n"
     "  coordinate of another Level). Existing channel versions (life support 1,\n"
     "  celestial 3, rocket flight 8, rocket visual 1, satellite 1) are unchanged.\n",
     "- **No new C2S message.** Menu data slots carry only 16-bit values and open\n"
     "  data is sent once, so they cannot show a selection that changes with every\n"
     "  previous/next intent (review R1-M10). As v1.6 did for the terminal (ADR-049\n"
     "  §10), one new **S2C-only** channel `advancedrocketrycommunity:endgame`,\n"
     "  protocol `1`, carries one message, the **device view**: sent when a device\n"
     "  menu opens and on change, at most once per 5 ticks per player, ≤ 8 KiB and\n"
     "  tested at that maximum. It holds the device status and codes, the current\n"
     "  selection only (never the whole list: the selected endpoint's label, its\n"
     "  position in the list and the list size), pair and transit counts, and buffer\n"
     "  summaries. Endpoints have no player-set names; a **label** is generated from\n"
     "  the kind, the first 8 hex digits of the ID and the body. Level and position\n"
     "  are included only for viewers allowed to see them (§9). Numbers that change\n"
     "  every tick (energy, progress) stay in data slots. A client without the channel\n"
     "  cannot join, as with the other channels.\n"
     "- Visuals use block-entity update tags (≤ 1 KiB, only render state: active\n"
     "  flag, beam length, field radius and value, never a target coordinate of\n"
     "  another Level). Existing channel versions (life support 1, celestial 3,\n"
     "  rocket flight 8, rocket visual 1, satellite 1) are unchanged.\n"),
])
patch("ADR-055-ORBITAL-LASER-DRILL.md", [
    ("  selected target (owner and operators only: name, body, position, depth,",
     "  selected target (ADR-054 §4 device view; owner and operators: label, body,\n"
     "  position, depth,"),
])
patch("ADR-056-RAILGUN-CARGO-AND-TARGETING.md", [
    ("- Menu: buffers, energy, destination (owner and operators: name, body, Level,",
     "- Menu (ADR-054 §4 device view): buffers, energy, destination (owner and\n"
     "  operators: label, body, Level,"),
])
print("ok")
