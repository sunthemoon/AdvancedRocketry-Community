import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
R = c.Redirect
rules = (True, True, True)
want = sys.argv[1] if sys.argv[1] == "stuck" else int(sys.argv[1])
crashes = int(sys.argv[2])
from collections import deque
start = R.normalize(R.initial())
seen = {(start, crashes)}
queue = deque([(start, crashes, ())])
while queue:
    state, left, path = queue.popleft()
    try:
        key = R.outcome(state, rules)
    except AssertionError as err:
        key = "stuck"
        detail = str(err)
    if key == want:
        print(" ".join(path)); print(state)
        if key == "stuck": print(detail[:400])
        break
    for label, s2, l2 in R.successors(state, rules, left):
        if (s2, l2) not in seen:
            seen.add((s2, l2)); queue.append((s2, l2, path + (label,)))
