"""C10 acceptance, confirmed by the maintainer on 2026-10-01: ADR-053..059 ACCEPTED with acceptance records; index,
README, version doc, status files, plan and log updated. The evidence packet is written separately."""
from pathlib import Path

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
D = ROOT / "docs/decisions"
PREP = "../work/v1.7.0-preparation/VERIFICATION.md"
BASIS = ("accepted_by: sunthemoon\naccepted_at: 2026-10-01\n"
         "acceptance_basis: maintainer confirmation on 2026-10-01 after four independent review rounds\n")


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (path.name, old[:80])
        s = s.replace(old, new)
    path.write_text(s, encoding="utf-8", newline="\n")


def wrap(text, width=80):
    lines, line = [], ""
    for word in text.split():
        if line and len(line) + len(word) + 1 > width:
            lines.append(line)
            line = word
        else:
            line = (line + " " + word).strip()
    lines.append(line)
    return "\n".join(lines)


def record(history):
    text = ("Accepted on 2026-10-01 by root after the maintainer confirmed it, following four "
            "independent contract-review rounds and a confirmation round. " + history + " Every Critical, "
            "High and Medium finding is resolved, and the final Low and Info findings are applied in this text. "
            "Reports and dispositions are in the [preparation evidence](" + PREP + ").")
    return ("## Acceptance record\n\n" + wrap(text) + "\n\n"
            "Acceptance freezes this contract for the v1.7 slices. It is not a\n"
            "runtime-completion claim, a Gate PASS or a publication decision. Later changes\n"
            "need a new revision and review.\n\n## Review history\n")


HISTORY = {
    "ADR-054": "Rounds 1 to 3 accepted it with required changes; round 4 accepted revision 4, and the confirmation "
               "round confirmed its Low answers.",
    "ADR-055": "Round 1 accepted it with required changes, and rounds 2 to 4 accepted revision 3.",
    "ADR-056": "Round 1 accepted it with required changes, and rounds 2 to 4 accepted it; revision 4 changes "
               "wording only.",
    "ADR-057": "Round 1 accepted it with required changes, and rounds 2 to 4 accepted revision 3.",
    "ADR-058": "Rounds 1 and 2 accepted it with required changes, and rounds 3 and 4 accepted revision 3.",
    "ADR-059": "Round 1 accepted it with required changes, and rounds 2 to 4 accepted it; revision 4 changes "
               "wording only.",
}

for path in sorted(D.glob("ADR-05[4-9]-*.md")):
    adr = path.name[:7]
    s = path.read_text(encoding="utf-8")
    head, rest = s.split("```yaml\n", 1)
    yaml, body = rest.split("```\n", 1)
    assert yaml.startswith("status: PROPOSED\n"), adr
    yaml = yaml.replace("status: PROPOSED\n", "status: ACCEPTED\n", 1) + BASIS
    assert body.count("## Review history\n") == 1, adr
    body = body.replace("## Review history\n", record(HISTORY[adr]), 1)
    path.write_text(head + "```yaml\n" + yaml + "```\n" + body, encoding="utf-8", newline="\n")

patch(next(D.glob("ADR-053-*.md")), [
    ("status: PROPOSED\nrevision: 3\n", "status: ACCEPTED\nrevision: 3\n"),
    ("proposed_baseline: ab10fb53a580e53a9a1c24097a487f2a7c54ad52\n",
     "accepted_baseline: ab10fb53a580e53a9a1c24097a487f2a7c54ad52\n" + BASIS),
    ("## Review history\n", "## Acceptance record\n\n" + wrap(
        "Recorded on 2026-10-01 after the maintainer confirmed the acceptance of the v1.7 contracts. Four "
        "independent contract-review rounds and a confirmation round found no required change to this ADR. "
        "ADR-054..059 are ACCEPTED in the same step, which satisfies the version's fourth prerequisite: an "
        "independent ADR and threat model for each endgame system. Reports and dispositions are in the "
        "[preparation evidence](" + PREP + "). Root records this acceptance separately from the reviews. It "
        "permits development, not runtime-completion claims, inherited Gate PASS or publication.")
     + "\n\n## Review history\n"),
])

patch(ROOT / "DOCUMENT-INDEX.md", [(
    "- [资源表、种子与版本化奖励](docs/decisions/ADR-052-RESOURCE-TABLES-AND-SEEDS.md)（第 2 版，已接受）：数据驱动的小行星类型与气体表、SplitMix64 种子派生与 v1 整数算法、可审计的奖励版本。\n",
    "- [资源表、种子与版本化奖励](docs/decisions/ADR-052-RESOURCE-TABLES-AND-SEEDS.md)（第 2 版，已接受）：数据驱动的小行星类型与气体表、SplitMix64 种子派生与 v1 整数算法、可审计的奖励版本。\n"
    "- [v1.7 实施日志](docs/work/v1.7.0-implementation-log.md)：终局系统的分块任务、契约状态与实际验证范围。\n"
    "- [v1.7 准备验证](docs/work/v1.7.0-preparation/VERIFICATION.md)：四轮独立契约审核与确认轮、处置表、参考模型与变异检查、未改动运行时的检查。\n"
    "- [v1.7 旧版终局系统审计](docs/work/v1.7.0-legacy-audit.md)：固定 MIT commit 的只读行为审计，未导入任何上游文件。\n"
    "- [v1.7 契约覆盖表](docs/work/v1.7.0-contract-coverage.md)：版本文档每一项对应的契约条款、测试等级、分块或处置。\n"
    "- [v1.7 开发基线例外](docs/decisions/ADR-053-V170-DEVELOPMENT-BASELINE-EXCEPTION.md)（第 3 版，已接受）：本版开发与继承发布验收分离。\n"
    "- [终局权限、保护、速率、能耗、运输与审计框架](docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md)（第 4 版，已接受）：系统开关、设备身份与权限、保护链、端点索引与退役、跨端点运输账本、预算与审计。\n"
    "- [轨道激光钻](docs/decisions/ADR-055-ORBITAL-LASER-DRILL.md)（第 3 版，已接受）：逻辑产出与可选的物理采矿、按层结算。\n"
    "- [轨道炮货运与目标选择](docs/decisions/ADR-056-RAILGUN-CARGO-AND-TARGETING.md)（第 4 版，已接受）：端点寻址、能耗报价与恰好一次交付。\n"
    "- [黑洞发电机](docs/decisions/ADR-057-BLACK-HOLE-GENERATOR.md)（第 3 版，已接受）：燃料表与每 tick 上限，唯一可产能的设备。\n"
    "- [区域重力控制器](docs/decisions/ADR-058-AREA-GRAVITY-CONTROLLER.md)（第 3 版，已接受）：信任名单、空间站内 1.00 g 上限与跳跃高度向量。\n"
    "- [太空电梯物流](docs/decisions/ADR-059-SPACE-ELEVATOR-LOGISTICS.md)（第 4 版，已接受）：基于 ADR-045 的配对、乘坐与到达预加载票据、站点守卫与货运。\n")])

patch(ROOT / "README.md", [(
    "registry and blocks a return to v1.5 builds; use copies of backed-up worlds. The\n"
    "[implementation log](docs/work/v1.6.0-implementation-log.md) tracks the work.\n",
    "registry and blocks a return to v1.5 builds; use copies of backed-up worlds. The\n"
    "[implementation log](docs/work/v1.6.0-implementation-log.md) tracks the work.\n\n"
    "**v1.7 Endgame Systems is in preparation.** Its contracts are accepted: an\n"
    "orbital laser drill, a railgun cargo launcher with endpoint targeting, a\n"
    "black-hole generator, an area gravity controller and space-elevator logistics,\n"
    "each with permission, protection, rate, energy and audit bounds. The\n"
    "[implementation log](docs/work/v1.7.0-implementation-log.md) tracks the work.\n"
    "None of these features is available yet; the runtime build remains\n"
    "`1.20.1-1.6.0-dev` until implementation begins.\n")])

patch(ROOT / "docs/versions/V1.7.0-ENDGAME-SYSTEMS.md", [
    ("前置版本未 `PASSED` 时，本版本只允许只读审计、测试设计和数据样例，不提前实现功能。独立 worktree 不豁免 AGENTS 的版本范围限制。\n",
     "前置版本未 `PASSED` 时，本版本只允许只读审计、测试设计和数据样例，不提前实现功能。独立 worktree 不豁免 AGENTS 的版本范围限制。\n\n"
     "已接受的开发顺序例外单独记录在 [ADR-053](../decisions/ADR-053-V170-DEVELOPMENT-BASELINE-EXCEPTION.md)，\n"
     "不勾选上述发布前置 Gate。每个终局系统的独立 ADR 与威胁模型为已接受的\n"
     "[ADR-054](../decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md)（共享框架）、\n"
     "[ADR-055](../decisions/ADR-055-ORBITAL-LASER-DRILL.md)、\n"
     "[ADR-056](../decisions/ADR-056-RAILGUN-CARGO-AND-TARGETING.md)、\n"
     "[ADR-057](../decisions/ADR-057-BLACK-HOLE-GENERATOR.md)、\n"
     "[ADR-058](../decisions/ADR-058-AREA-GRAVITY-CONTROLLER.md) 与\n"
     "[ADR-059](../decisions/ADR-059-SPACE-ELEVATOR-LOGISTICS.md)；逐项覆盖见\n"
     "[契约覆盖表](../work/v1.7.0-contract-coverage.md)，任务与实跑证据见\n"
     "[v1.7 实施日志](../work/v1.7.0-implementation-log.md)。准备阶段不代表新运行时已实现。\n"),
    ("version: v1.7.0\nstatus: PLANNED\n", "version: v1.7.0\nstatus: IN_PROGRESS\nphase: CONTRACT_FROZEN\n"),
])

patch(ROOT / "docs/status/CURRENT_VERSION.md", [
    ("""[ADR-048](../decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md), the accepted
v1.6 development baseline is the v1.5 closure commit. Inherited acceptance
remains open; accepted v1.6 contracts do not imply implemented satellite or
mission gameplay:

```yaml
active_development_version: v1.6.0
active_development_branch: codex/v1.6.0-satellite-resource-missions
phase: IMPLEMENTING
execution_state: ACTIVE
accepted_development_baseline: 940a5ed3b90a4da0ca4e43417b2bddf41ebb7307
development_log: docs/work/v1.6.0-implementation-log.md
previous_development_handoff: docs/releases/v1.5.0/RELEASE-EVIDENCE.md
runtime_build: 1.20.1-1.6.0-dev
```

v1.6 preparation (C6) is complete.""", """[ADR-053](../decisions/ADR-053-V170-DEVELOPMENT-BASELINE-EXCEPTION.md), the accepted
v1.7 development baseline is the v1.6 handoff commit. Inherited acceptance
remains open; accepted v1.7 contracts do not imply implemented endgame gameplay:

```yaml
active_development_version: v1.7.0
active_development_branch: codex/v1.7.0-endgame-systems
phase: CONTRACT_FROZEN
execution_state: ACTIVE
accepted_development_baseline: ab10fb53a580e53a9a1c24097a487f2a7c54ad52
development_log: docs/work/v1.7.0-implementation-log.md
previous_development_handoff: docs/releases/v1.6.0/RELEASE-EVIDENCE.md
runtime_build: 1.20.1-1.6.0-dev
```

v1.7 preparation (C10) is complete. [ADR-053](../decisions/ADR-053-V170-DEVELOPMENT-BASELINE-EXCEPTION.md)
accepts v1.7 development from the v1.6 handoff commit `ab10fb5`, separately from
inherited acceptance. ADR-054..059 freeze the endgame framework (authority,
protection, rate, energy, the transit ledger and audit) and the laser drill,
railgun, black-hole generator, gravity controller and space-elevator contracts
after four independent review rounds and a confirmation round
([preparation evidence](../work/v1.7.0-preparation/VERIFICATION.md)). The runtime is
unchanged: the rebuilt JARs are byte-identical to the v1.6 handoff build. The next
chunk is C11 in [COMPLETION-PLAN](COMPLETION-PLAN.md). The v1.6 facts below are unchanged.

Previous development version (v1.6, development complete, release `IN_PROGRESS`):

```yaml
previous_development_version: v1.6.0
previous_development_branch: codex/v1.6.0-satellite-resource-missions
previous_accepted_development_baseline: 940a5ed3b90a4da0ca4e43417b2bddf41ebb7307
previous_development_log: docs/work/v1.6.0-implementation-log.md
```

v1.6 preparation (C6) is complete."""),
    ("""Previous development version (v1.5, development complete, release `IN_PROGRESS`):
""", """Earlier development version (v1.5, development complete, release `IN_PROGRESS`):
"""),
])

patch(ROOT / "docs/status/COMPLETION-PLAN.md", [
    ("""### C10. v1.7 契约 `[ ]`
- 以下各项的 ADR 送审：
  - 轨道激光/采矿；
  - 轨道炮与目标系统（安全范围）；
  - 黑洞发电；
  - 重力控制器；
  - 空间电梯物流（以 ADR-045 为基础）；
  - 权限、保护区、速率、能耗与审计日志。
""", """### C10. v1.7 契约 `[x]`
- 以下各项的 ADR 送审：
  - 轨道激光/采矿；
  - 轨道炮与目标系统（安全范围）；
  - 黑洞发电；
  - 重力控制器；
  - 空间电梯物流（以 ADR-045 为基础）；
  - 权限、保护区、速率、能耗与审计日志。
- 结果（2026-10-01）：分支 `codex/v1.7.0-endgame-systems`，基线 `ab10fb5`。旧版审计只读、
  未导入。ADR-053..059 经四轮独立审核与一轮确认后由维护者确认接受：第 1 轮 0 Critical /
  3 High，第 2 轮 2 High，第 3 轮 1 High，第 4 轮无 Critical/High/Medium，5 个 Low 与确认轮的
  1 个 Info 均单独提交并写入正文。参考模型 27 项测试、26 个变异全部捕获；运行时未改动，
  重建 JAR 与 v1.6 交付构建字节一致（`docs/work/v1.7.0-preparation/`）。
"""),
    ("""**C10 v1.7 契约**（新会话：v1.6 开发交付已完成，按维护者要求大版本之间切换会话；
依据 `docs/versions/V1.7.0-ENDGAME-SYSTEMS.md`，另开 v1.7 分支，先写 ADR 并送独立审核）。
""", """**C11 采矿激光、重力控制器与权限审计框架**（同一会话继续；在 `codex/v1.7.0-endgame-systems`
上按已接受的 ADR-054/055/058 实现：终局根、权限与保护链、审计、端点索引、激光钻逻辑模式与
可选物理模式、重力控制器）。
"""),
])

patch(ROOT / "docs/work/v1.7.0-implementation-log.md", [
    ("""status: IN_PROGRESS
phase: CONTRACTS
execution_state: ACTIVE
branch: codex/v1.7.0-endgame-systems
proposed_development_baseline: ab10fb53a580e53a9a1c24097a487f2a7c54ad52
runtime_implementation_allowed: false   # until ADR-053..059 are ACCEPTED
runtime_build: 1.20.1-1.6.0-dev         # unchanged in C10
""", """status: IN_PROGRESS
phase: CONTRACT_FROZEN
execution_state: ACTIVE
branch: codex/v1.7.0-endgame-systems
accepted_development_baseline: ab10fb53a580e53a9a1c24097a487f2a7c54ad52
runtime_implementation_allowed: true    # ADR-053..059 ACCEPTED on 2026-10-01
runtime_build: 1.20.1-1.6.0-dev         # unchanged in C10
"""),
    ("## C10 — contracts (in progress)\n", "## C10 — contracts (complete)\n"),
    ("""  go to the reviewer for confirmation before the acceptance is recorded.
""", """  go to the reviewer for confirmation before the acceptance is recorded.
- Confirmation round at `30ab77b`: all five Lows resolved, every verdict ACCEPT,
  one Info (R4C-I1) answered in its own commit.
- Accepted on 2026-10-01 after the maintainer confirmed it: ADR-053..059 are
  ACCEPTED, and the [preparation evidence](v1.7.0-preparation/VERIFICATION.md)
  holds the reviews, dispositions, model runs and the unchanged-runtime checks.
"""),
    ("""1. [ ] **C10** contracts: ADR-053..059, audit, vectors, coverage, independent
""", """1. [x] **C10** contracts: ADR-053..059, audit, vectors, coverage, independent
"""),
])
print("ok")
