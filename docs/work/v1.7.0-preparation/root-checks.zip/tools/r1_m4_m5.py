"""R1-M4 (ride arrival: expiring pre-load ticket, no synchronous load) and R1-M5 (TELEPORT event posted)."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("  passengers (`DISMOUNT_FIRST`), and no other pending ride. At most 4 pending\n"
     "  rides per endpoint.\n",
     "  passengers (`DISMOUNT_FIRST`), and no other pending ride. At most 4 pending\n"
     "  rides per endpoint and 64 on the server.\n"
     "- **Arrival pre-load** (review R1-M4): the request adds one region ticket of\n"
     "  the dedicated type `advancedrocketrycommunity:elevator_arrival` at the arrival\n"
     "  chunk, at distance 0 (the chunk becomes `FULL`, nothing around it ticks), with\n"
     "  a 300-tick lifespan after which vanilla's ticket timeout removes it even if\n"
     "  nothing else does. The position is the **server-derived** arrival position\n"
     "  (the centre of the other endpoint's platform, from the pair record), never a\n"
     "  client value; the chunk already exists because the endpoint was built in it,\n"
     "  so it is read asynchronously from disk and nothing is generated. The ticket is\n"
     "  removed at commit, at cancellation and at server stop. At most one per\n"
     "  pending ride, so at most 64.\n"),
    ("  3. load the arrival chunk synchronously with `ServerLevel.getChunk(cx, cz)`\n"
     "     at the **server-derived** arrival position (the centre of the other\n"
     "     endpoint's platform), never from a client value. The chunk already exists\n"
     "     on disk, because the endpoint was built in it, so this reads it and\n"
     "     generates nothing; it adds no ticket of its own;\n"
     "  4. the arrival block entity carries the recorded endpoint ID, and the two\n"
     "     blocks above the platform centre are free of collision\n"
     "     (`ARRIVAL_OBSTRUCTED`);\n"
     "  5. then, in the same tick: debit the departing endpoint and teleport the\n"
     "     player to the arrival position (fall distance reset by the teleport).\n\n"
     "  Any failure before step 5 changes nothing and reports the code. No ticket\n"
     "  remains after the move; the player's own presence keeps the chunk loaded as for\n"
     "  any teleport. At most one arrival chunk access per tick.\n",
     "  3. the arrival chunk is `FULL` (`getChunkNow`); there is **no synchronous\n"
     "     load**. If the pre-load has not finished, the commit waits, rechecking each\n"
     "     tick, for at most 100 more ticks, then cancels with `ARRIVAL_UNLOADED`;\n"
     "  4. the arrival block entity carries the recorded endpoint ID, and the two\n"
     "     blocks above the platform centre are free of collision\n"
     "     (`ARRIVAL_OBSTRUCTED`);\n"
     "  5. ADR-054 §5 steps 2, 3 and 6 for the arrival box (the platform and the two\n"
     "     blocks above it): bounds, protected zones and the public\n"
     "     `EndgameEffectEvent` with effect `TELEPORT` (review R1-M5), else\n"
     "     `TARGET_PROTECTED`. Step 4 is replaced by the §7 access rule; spawn\n"
     "     protection does not apply because no block changes;\n"
     "  6. then, in the same tick: teleport the player to the arrival position (fall\n"
     "     distance reset by the teleport), and debit the departing endpoint only\n"
     "     once the player is in the arrival Level at the arrival position. A\n"
     "     teleport that another mod cancels (for example through Forge's dimension\n"
     "     travel event) costs nothing.\n\n"
     "  Any failure before step 6 changes nothing but releases the ticket and reports\n"
     "  the code. Vanilla's own short `POST_TELEPORT` ticket follows any teleport and\n"
     "  expires by itself; afterwards the player's presence keeps the chunk loaded.\n"),
    ("| Teleporting into protected or unsafe places | Arrival only at the other endpoint's own platform, built by its owner under vanilla placement rules; obstruction check |",
     "| Teleporting into protected or unsafe places | Arrival only at the other endpoint's own platform, built by its owner under vanilla placement rules; obstruction check; zones and the `TELEPORT` API event at commit |"),
    ("| Chunk loading from a client position | Arrival position is server-derived from the pair; one access per tick; no ticket |",
     "| Chunk loading from a client position | Arrival position is server-derived from the pair; one expiring pre-load ticket per pending ride (≤ 64, 300 ticks), released at commit or cancel; no synchronous load |"),
])
patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("v1.7 never creates a chunk ticket, forced chunk or region ticket, and never\n"
     "initialises a Level on demand. Every world effect needs its chunks already `FULL`\n"
     "(§5 step 1); ledger paths need no chunk. The single synchronous chunk load is the\n"
     "arrival check of an elevator ride (ADR-059 §8): at most one per server tick, of an\n"
     "existing chunk at a server-derived position, immediately followed by the player's\n"
     "teleport there, so it behaves like a vanilla teleport. Tests count tickets before\n"
     "and after every system.\n",
     "v1.7 never forces a chunk, never creates a persistent ticket, never loads a chunk\n"
     "synchronously, and never initialises a Level on demand. Every world effect needs\n"
     "its chunks already `FULL` (§5 step 1); ledger paths need no chunk. The only\n"
     "tickets an endgame action creates are the elevator ride-arrival tickets of\n"
     "ADR-059 §8 (review R1-M4): one per pending ride, at most 64, at a server-derived\n"
     "position, with a 300-tick lifespan and released at commit or cancellation;\n"
     "vanilla adds its own short `POST_TELEPORT` ticket to the teleport itself. Tests\n"
     "count tickets by type before and after every system and after every ride.\n"),
    ("- `EndgameEffectEvent`: a cancellable Forge `Event`, posted on\n",
     "- `EndgameEffectEvent`: a cancellable Forge `Event` (posted for `BLOCK_BREAK` by\n"
     "  ADR-055, for `ENTITY_GRAVITY` by ADR-058 and for `TELEPORT` at every elevator\n"
     "  ride commit by ADR-059 §8), posted on\n"),
])
patch("ADR-053-V170-DEVELOPMENT-BASELINE-EXCEPTION.md", [
    ("- no chunk ticket and no forced chunk loading;\n",
     "- no forced or persistent chunk loading: the only tickets are the bounded,\n"
     "  expiring elevator ride-arrival tickets (ADR-059 §8) and vanilla's own\n"
     "  teleport ticket;\n"),
])
print("ok")
