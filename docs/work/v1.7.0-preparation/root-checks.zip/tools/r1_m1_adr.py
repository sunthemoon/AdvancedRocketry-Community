"""R1-M1 ADR text and pins."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("acknowledged in the same tick, only after a\n"
    "`ChunkDataEvent.Save` or `ChunkDataEvent.Load` tag of D's chunk is observed to\n"
    "contain it (§2's persistence rule).",
    "acknowledged in the same tick, only after a\n"
    "`ChunkDataEvent.Save` or `ChunkDataEvent.Load` tag of D's chunk is observed to\n"
    "contain it (§2's persistence rule) and that observation is at least 40 ticks old,\n"
    "the same age rule as registration (review R1-M1). The reconciliation row that\n"
    "acknowledges a persisted receipt uses the same aged observation.")
sub("| **Residual**: operator redirect after a ledger rollback | ADR-051 §9 | Possible double delivery, audited |",
    "| **Residual**: operator redirect after a ledger rollback | ADR-051 §9 | Possible double delivery, audited |\n"
    "| **Residual** (R1-M1): D's save of a claim observed and aged, but its asynchronous write lost; the move, acknowledgement and flush happened; then a crash | The ledger acknowledged a payload that D's chunk never stored | The payload is lost (ADR-051 §11 lists the same class) |\n"
    "| **Residual** (R1-M1): as above, but the ledger's acknowledgement was not yet flushed and a player withdrew and saved the moved payload | The record is `CLAIMED`, D has no receipt | Rematerialized, so the payload exists twice; it needs a lost write that the 40-tick age did not outlast |")
p.write_text(s, encoding="utf-8", newline="\n")

g = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb/tools/generate_examples.py")
t = g.read_text(encoding="utf-8")
assert t.count('"states_gated_two_crashes": 1314,') == 1
t = t.replace('"states_gated_two_crashes": 1314,', '"states_gated_two_crashes": 1622,\n        "states_gated_two_crashes_one_lost_write": 4011,')
g.write_text(t, encoding="utf-8", newline="\n")
print("ok")
