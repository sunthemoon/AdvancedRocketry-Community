import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
D = c.Delivery
want = (int(sys.argv[1]), sys.argv[2] == "True")
seen, stack, best = set(), [(D.normalize(D.initial()), 2, 1, ())], None
while stack:
    state, left, faults, path = stack.pop()
    if (state, left, faults) in seen:
        continue
    seen.add((state, left, faults))
    if D.outcome(state, True) == want and faults == 0 and (best is None or len(path) < len(best)):
        best = path
    for label, s2, l2, f2 in D.successors(state, True, left, faults):
        stack.append((s2, l2, f2, path + (label,)))
print(best)
