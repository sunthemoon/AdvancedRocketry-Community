"""R3-M2: tombstones pinned, young ones counted as endpoints, settled ones capped per owner and overall."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""  Level key of at most 128 characters, a position and a state). At most 2,048
  endpoints, 64 per owner (review R2-M3).
""", """  Level key of at most 128 characters, a position and a state). At most 2,048
  endpoints, 64 per owner (review R2-M3); a young tombstone (§11) takes an
  endpoint's place in both limits until its absence is settled (review R3-M2).
""")

sub("""Tombstones are at most 64 bytes each. One is removed only when its endpoint's
absence was observed in a `ChunkDataEvent.Load` tag after the last server start
(so the absence is on disk, review R2-L1) and at least 6,000 ticks earlier,
**and** the table holds more than 4,096 tombstones, oldest observation first;
otherwise tombstones are kept, admitted up to the root's hard bound. Because
the absence must be read back from disk after a start, a lost absence write
can no longer remove a tombstone. A block mover could still carry a retired
endpoint away and place it after its tombstone was removed; that needs more
than 4,096 later retirements in between and is the documented residual of the
retirement rule. Limits: 256 records globally, 32 per owner, counting live
""", """Tombstones are at most 64 bytes each and carry their endpoint's owner. Their
growth is bounded as follows (review R3-M2):
- **Pinned.** A tombstone whose ID a transit record names (as source,
  destination or paid endpoint) or an elevator pair names is never removed. At
  most 2,816 can be pinned (256 records × 3 IDs, 1,024 pairs × 2).
- **Young.** A tombstone is young until its endpoint's absence was observed in a
  chunk-save or chunk-load tag at least 40 ticks earlier (the persistence signal
  and age rule of step 2). Autosave writes a loaded chunk that changed within
  6,000 ticks, so staying in the chunk does not keep it young. A young tombstone
  takes its endpoint's place in the owner's 64 and the server's 2,048 endpoints
  (§9), so a registration beyond them waits with `ENDPOINT_LIMIT`.
- **Housekeeping.** Once the table holds more than 4,096 tombstones, an
  unpinned one whose absence was read back in a `ChunkDataEvent.Load` tag after
  the last server start (so it is on disk, review R2-L1) at least 6,000 ticks
  earlier is removed, oldest observation first.
- **Caps.** Settled (not young), unpinned tombstones are capped at **256 per
  owner** and **8,192 on the server**. Beyond a cap the oldest such tombstone of
  that owner (or of the server) is evicted, with an audit line
  (`TOMBSTONE_EVICTED`). `/arce endgame tombstone evict <player>` evicts an
  owner's settled, unpinned tombstones (one audited barrier flush).

Evicting a settled, unpinned tombstone is safe. Registration reads the
endpoint's own persisted entry (§9, review R3-H1): a returning copy that holds
outbox entries, incoming payloads or receipts is frozen. Such a copy can
neither register a delivered payload again nor claim a record paid elsewhere.
A returning copy with no contents registers anew. A settled absence means a
crash restores the endpoint only if the save that showed its absence was lost.
A copy carried by a block mover has a current `next_seq`, so its new sequence
numbers are above the old ones. A pin keeps the ID while a live record could
still meet the copy. The reference model checks the source side with an
adversary that evicts whenever these rules allow. Without a fault it delivers
exactly once. With one lost write it adds no outcome beyond the audited
`SOURCE_ROLLBACK` residual. Evicting before a saved absence, or without the
freeze, is caught as a duplicate (`check_mutations.py`). One player's churn
evicts only that player's tombstones, or the server's oldest settled ones.
Limits: 256 records globally, 32 per owner, counting live
""")

sub("""  transit records × 2.5 KiB, 4,096 tombstones × 64 B, 1,024 pairs × 512 B and
  256 zones × 768 B, about 2.4 MiB in total, so **every cap can be reached at
  the same time**. Endpoint registration, escrow admission (§11), binds and
  zone additions are refused only when the accounted size would pass 3 MiB;
  tombstones beyond 4,096, a registration of an already escrowed payload and
  every reconciliation step are admitted up to the 4 MiB bound itself, and
  beyond it wait (never drop) with `ROOT_FULL`;
""", """  transit records × 2.5 KiB, 11,008 tombstones × 64 B (8,192 settled and
  unpinned plus 2,816 pinned; young ones take endpoint places, §11), 1,024
  pairs × 512 B and 256 zones × 768 B, 2,932,736 B or about 2.80 MiB in total,
  so **every cap can be reached at the same time** (review R3-M2). Endpoint
  registration, escrow admission (§11), binds and zone additions are refused
  only when the accounted size would pass 3 MiB. A tombstone is always
  admitted, because pins, endpoint places and caps bound the table. A
  registration of an already escrowed payload (only after a restore or a lost
  write, which escrow admission did not count) and every reconciliation step
  are admitted up to the 4 MiB bound itself, and beyond it wait (never drop)
  with `ROOT_FULL`. Only those can take the root past the accounted maximum;
""")

sub("""| One coalesced or barrier flush | ≤ 60 ms at the reference root, ≤ 250 ms at the accounted maximum (§10, about 2.4 MiB); at most one coalesced flush per 100 ticks plus the spaced barriers; a flush tick is its own budget, inside docs/17 §4's 500 ms spike limit |
| Memory | root ≤ 4 MiB encoded (accounted maximum about 2.4 MiB) and ≤ 32 MiB of accounted heap; field index ≤ 1,024 entries; audit ring 512 lines; one device view ≤ 8 KiB per open menu |""",
    """| One coalesced or barrier flush | ≤ 60 ms at the reference root, ≤ 250 ms at the accounted maximum (§10, about 2.80 MiB), ≤ 400 ms at the 4 MiB bound that only recovery registrations can reach (review R3-M2); at most one coalesced flush per 100 ticks plus the spaced barriers; a flush tick is its own budget, inside docs/17 §4's 500 ms spike limit |
| Memory | root ≤ 4 MiB encoded (accounted maximum about 2.80 MiB) and ≤ 32 MiB of accounted heap; field index ≤ 1,024 entries; audit ring 512 lines; one device view ≤ 8 KiB per open menu |""")

sub("""  while referenced; the §11 tombstone stays until the absence is persisted);
  `endpoint retire <id>` and `endpoint resolve <id>` (§9, §11); `transfer
""", """  while referenced; the §11 tombstone stays until the absence is persisted);
  `endpoint retire <id>` and `endpoint resolve <id>` (§9, §11); `tombstone
  evict <player>` (§11); `transfer
""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
