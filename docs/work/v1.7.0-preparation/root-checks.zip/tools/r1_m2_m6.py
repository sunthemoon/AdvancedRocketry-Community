"""R1-M2 (managed root semantics) and R1-M6 (warp/deletion guards fail closed)."""
from pathlib import Path

D = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("All cross-device state lives in one SavedData, `arce_endgame` in the Overworld\n"
     "data storage, written with the checked atomic file path (`AtomicSavedData`, new\n"
     "`ManagedSavedDataType.ENDGAME`):\n",
     "All cross-device state lives in one SavedData,\n"
     "`advancedrocketrycommunity_endgame.dat` in the world's `data` directory, a new\n"
     "entry of the managed-SavedData allowlist (review R1-M2):\n\n"
     "- `ManagedSavedDataType.ENDGAME`: introduced in `v1.7.0`, current schema 1 and\n"
     "  format epoch `v1.7.0-endgame` (its own `currentSchemaVersion` and `formatEpoch`\n"
     "  cases; schema 1 is the only readable schema, so there is no legacy migration),\n"
     "  required tags `endpoints`, `dispatched_through`, `transits`, `elevator_pairs`,\n"
     "  `zones` (lists) and `save_epoch` (long), the 4 MiB bound below, and a semantic\n"
     "  validator that runs the full root codec;\n"
     "- written through the checked atomic file path: `AtomicSavedData` widens its\n"
     "  constructor allowlist from the two discovery authorities to also accept\n"
     "  `ENDGAME`, so ordinary saves, barrier flushes and the save epoch use the same\n"
     "  replace-and-read-back path;\n"),
    ("- **load**: no file means a fresh root (v1.6 worlds need no migration). A root\n"
     "  with an unsupported schema, a malformed section, a duplicate key or a bound\n"
     "  violation **blocks** the endgame authority: no endgame operation and no\n"
     "  settlement, the file is kept unchanged, one `ARCE_ENDGAME_BLOCKED` line names\n"
     "  the reason, and `/arce endgame status` reports it. The rest of the world runs.\n"
     "  A blocked root is never overwritten by autosave.\n",
     "- **load**: no file means a fresh root (v1.6 worlds need no migration). The\n"
     "  pre-start validation (`WorldDataMigrationService`, ADR-050 §10) refuses to\n"
     "  start the world, as for every managed file, when the root has a future schema\n"
     "  (`FUTURE_SCHEMA`) or a malformed section, a duplicate key or a bound violation\n"
     "  (`INVALID_SCHEMA`); the message names the file and nothing is overwritten. An\n"
     "  operator who accepts losing endgame state moves the file away and restarts.\n"
     "  Records that decode but fail a semantic check later (an item of a removed mod)\n"
     "  are quarantined one by one (§11). A failed write keeps the root dirty, is\n"
     "  retried by the next save, and logs once, as `AtomicSavedData` already does.\n"
     "- **operational** means the root is loaded and the endgame service is installed\n"
     "  for this server; before that (startup) and after `ServerStoppingEvent` every\n"
     "  endgame action is refused and the station guards of ADR-059 §5 fail closed.\n"),
    ("| Blocked | any | Nothing; escrow refused |",
     "| Not operational (§10) | any | Nothing; escrow refused |"),
    ("  entries become air with Forge's usual warning) and ignores `arce_endgame`;",
     "  entries become air with Forge's usual warning) and ignores\n"
     "  `advancedrocketrycommunity_endgame.dat`;"),
    ("Disable the systems by config. Removing the code leaves `arce_endgame` unused;",
     "Disable the systems by config. Removing the code leaves\n"
     "`advancedrocketrycommunity_endgame.dat` unused;"),
])
patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("- Crash order: a bind is durable before it is reported; a warp commit is the\n",
     "- **Fail closed** (review R1-M6): the station module reaches the pair set only\n"
     "  through an `ElevatorStationGuard` port installed at startup, so it gains no\n"
     "  import of the endgame module (AGENTS §3.4). Until it is installed, and while\n"
     "  the endgame root is not operational (ADR-054 §10), warp request, confirmation\n"
     "  and commit, evacuation warps and station deletion are refused with\n"
     "  `ENDGAME_UNAVAILABLE`, as `StationRocketAuthority` fails closed for rockets\n"
     "  (ADR-044 §5). The guard does not depend on `endgame.spaceElevator.enabled`: a\n"
     "  disabled elevator still has pairs that pin the station.\n"
     "- Crash order: a bind is durable before it is reported; a warp commit is the\n"),
    ("pairs unused in `arce_endgame`; warp and deletion guards disappear with it.",
     "pairs unused in `advancedrocketrycommunity_endgame.dat`; warp and deletion\n"
     "guards disappear with it."),
])
print("ok")
