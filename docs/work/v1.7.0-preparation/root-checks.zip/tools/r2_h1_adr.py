"""R2-H1 ADR text: retired endpoint IDs, inert returning endpoints, redirect rules, frozen-content resolution."""
from pathlib import Path

p = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md")
s = p.read_text(encoding="utf-8")


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:100]
    s = s.replace(old, new)


sub("""- **Removal.** Removing an endpoint removes its record (§9.1). Breaking is
  refused for non-operators while it holds an outbox entry, an incoming payload,
  an unacknowledged receipt or an elevator pair (`ENDPOINT_BUSY`). An endpoint
  whose chunk is loaded without a
  block entity of that ID at the recorded position becomes `MISSING`; a block
  entity carrying a registered ID at another position is
  `ENDPOINT_POSITION_CONFLICT` and inert (operator copy tools such as `/clone`
  are outside the guarantee, as in ADR-051 §7). A `MISSING` endpoint still
  counts toward its owner's limit until the owner removes it with
  `/arce endgame endpoint forget <id>` (own `MISSING` endpoints only; the
  tombstone of §11 stays).
""", """- **Removal.** Removing an endpoint removes its record and **retires** its ID
  (§9.1). Breaking is refused for non-operators while it holds an outbox entry,
  an incoming payload, an unacknowledged receipt or an elevator pair
  (`ENDPOINT_BUSY`). An endpoint whose chunk is loaded without a block entity of
  that ID at the recorded position, observed at least 40 ticks earlier in a
  chunk-save or chunk-load tag, becomes `MISSING` and is retired the same way; a
  block entity carrying a registered, not retired ID at another position is
  `ENDPOINT_POSITION_CONFLICT` and inert (operator copy tools such as `/clone`
  are outside the guarantee, as in ADR-051 §7). A `MISSING` endpoint still
  counts toward its owner's limit until the owner removes it with
  `/arce endgame endpoint forget <id>` (own `MISSING` endpoints only; the
  tombstone of §11 stays).
- **Retired IDs** (review R2-H1). A removed endpoint can come back with its old
  identity: a crash after the removal's ledger write but before its chunk saved
  the removal restores it in place, and a block mover that keeps block-entity
  data (endpoints refuse vanilla pistons and opt out of the common movers below,
  but that is not relied on) may place it again anywhere. A block entity whose ID
  is retired is therefore `ENDPOINT_RETIRED`: inert at any position. Its outbox
  entries, incoming payloads and receipts are kept raw and **frozen**: it never
  registers, claims, moves, acknowledges, drops or delivers them, and it never
  registers again. Breaking it drops only its local buffers. An operator resolves
  it with `/arce endgame endpoint resolve <id>` (one audited barrier flush):
  frozen unregistered outbox entries (`seq > dispatched_through`) go back to its
  local input buffer, because the ledger can never register them; frozen
  incoming payloads and receipts are destroyed, because their records were
  settled at removal and are delivered elsewhere. A player who finds a retired
  device places a new one, which gets a new ID.
""")
sub("""Review R1-H3: a refused player break is not the only way a block entity goes.
Every endgame endpoint block is in `#minecraft:wither_immune` and
`#minecraft:dragon_immune`, has blast resistance 1,200 (TNT, creepers, beds
and withers cannot remove it), and cannot be pushed (it has a block entity).
""", """Review R1-H3: a refused player break is not the only way a block entity goes.
Every endgame endpoint block is in `#minecraft:wither_immune` and
`#minecraft:dragon_immune`, has blast resistance 1,200 (TNT, creepers, beds
and withers cannot remove it), has `PushReaction.BLOCK`, and is listed in the
non-movable tags of common block movers (`create:non_movable`,
`carryon:block_blacklist`; shipped with `replace: false`, harmless without those
mods). These are defence in depth; the retirement rule of §9 is what keeps a
returning endpoint from paying twice.
""")
sub("""  `CLAIMED` and acknowledged. An incoming payload whose record is already
  acknowledged or pruned is the endpoint's own content (its move was due after
  a crash, below) and drops with the local buffers. If the barrier flush fails,
  the records stay as they were and one `REMOVAL_SETTLEMENT_UNKNOWN` line asks
  an operator to redirect or purge them.
- The endpoint's index record is removed, its `dispatched_through` stays as a
  tombstone (§11), pairs naming it become invalid (unbinding stays possible,
  ADR-059), and a laser drill linked to it sees `LINK_LOST` (ADR-055).

A crash after the barrier flush but before the endpoint's chunk saved the
removal restores the endpoint with its incoming payload and receipt while the
record is `ARRIVED`; the destination row "ledger behind" re-claims it, so it is
paid once. The reference model checks removal at any point with up to two
crashes.
""", """  `CLAIMED` and acknowledged. An incoming payload whose record is acknowledged
  **at this endpoint**, or pruned, is the endpoint's own content (its move was
  due after a crash, below) and drops with the local buffers. An incoming
  payload whose record names another endpoint is destroyed with an
  `INCOMING_VOIDED` line, never dropped. If the barrier flush fails, the records
  stay as they were and one `REMOVAL_SETTLEMENT_UNKNOWN` line asks an operator to
  redirect or purge them.
- The endpoint's index record is removed and its ID is **retired** (§9): the
  tombstone table keeps the ID, with `dispatched_through` for a source (§11).
  The retirement is part of the barrier flush when one runs, and otherwise
  flush-pending (nothing then depends on it). Pairs naming the endpoint become
  invalid (unbinding stays possible, ADR-059), and a laser drill linked to it
  sees `LINK_LOST` (ADR-055).

A crash after the barrier flush but before the endpoint's chunk saved the
removal restores the endpoint with its incoming payload and receipt, while the
record is `ARRIVED` and the ID is retired: the restored block entity is
`ENDPOINT_RETIRED` and inert, its copy is frozen, and the record is delivered
once through a redirect (§11). The reference models check removal at any point,
with up to two crashes, and a removed destination that returns through a crash
or a block mover after its cargo was redirected and paid elsewhere.
""")
# Destination reconciliation and the "moves again" rule.
sub("""rematerializes once into incoming (`REMATERIALIZED`, waiting while full); an
incoming payload whose record is already acknowledged or pruned means D's chunk
is behind its own move, and it moves again; a receipt is dropped
""", """rematerializes once into incoming (`REMATERIALIZED`, waiting while full); an
incoming payload whose record is acknowledged **at D**, or pruned, means D's
chunk is behind its own move, and it moves again (a record can only be
redirected away from D after D's ID is retired, so a D that is not retired never
holds a payload acknowledged elsewhere; if it ever does, after an operator file
restore, the payload and receipt are frozen with `REDIRECT_CONFLICT`); a receipt
is dropped
""")
# Operator and owner redirect.
sub("""payload): `transfer redirect <source> <seq> <endpoint>` for an `IN_TRANSIT` or
`ARRIVED` record to another endpoint of the same owner and system (ADR-051 §9
residual applies); `transfer purge <source> <seq>` removes a record and destroys
its payload. The **owner** may redirect their own `DESTINATION_MISSING` cargo to
another of their compatible endpoints once the old destination's absence is
established (its record was removed by §9.1, or it is `MISSING`); then the old
destination cannot return with a receipt, so ADR-051 §9's residual does not
apply (review R1-L8).""", """payload): `endpoint retire <id>` retires an endpoint that is lost but not
`MISSING` (for example in a chunk that will never load again);
`transfer redirect <source> <seq> <endpoint>` moves an `IN_TRANSIT` or `ARRIVED`
record to another endpoint, but only once its destination's retirement is
durable, so ADR-051 §9's double-payment residual cannot arise: a retired
destination that returns is inert (review R2-H1); `transfer purge <source>
<seq>` removes a record and destroys its payload. The **owner** may redirect
their own `DESTINATION_MISSING` cargo under the same rule (review R1-L8), with
`/arce endgame transfer redirect` from their own connected command source. Both
redirects are barrier flushes subject to the §7 spacing, and both follow the
system's route rule: railgun cargo goes to another of the owner's `ACTIVE`
railgun endpoints in the source's star system; elevator cargo goes back to its
source endpoint.""")
# Tombstones hold retired IDs; R2-L1 re-observation after restart.
sub("""registering a delivered payload again (review R1-H1). Tombstones are at most
64 bytes each. One is removed only when its source's absence was observed at
least 6,000 ticks earlier **and** the table holds more than 8,192 tombstones,
oldest observation first; otherwise tombstones are kept, admitted up to the
root's hard bound.""", """registering a delivered payload again (review R1-H1). The same table holds the
ID of every retired endpoint (§9), so one tombstone serves both purposes.
Tombstones are at most 64 bytes each. One is removed only when its endpoint's
absence was observed in a `ChunkDataEvent.Load` tag after the last server start
(so the absence is on disk, review R2-L1) and at least 6,000 ticks earlier,
**and** the table holds more than 8,192 tombstones, oldest observation first;
otherwise tombstones are kept, admitted up to the root's hard bound. A block
mover could still carry a retired endpoint away and place it after its
tombstone was removed; that needs more than 8,192 later retirements in between
and is the documented residual of the retirement rule.""")
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
