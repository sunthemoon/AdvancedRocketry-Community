import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
R = c.Redirect
rules = (False, False, False)
state = R.normalize(R.initial())
for label in ["CLAIM_D", "SAVE_D", "PICKUP_D", "REDIRECT", "CLAIM_E", "SAVE_E", "MOVE_E", "FLUSH_L", "PRUNE", "PLACE_D", "SAVE_D", "REREGISTER_D", "MOVE_D"]:
    options = {l: s for l, s, _ in R.successors(state, rules, 0)}
    assert label in options, (label, sorted(options))
    state = options[label]
print(R.outcome(state, rules))
