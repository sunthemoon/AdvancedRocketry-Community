"""Root finding S4 for revision 2: endgame multiblocks are structure-only (pattern + bounded validator)."""
from pathlib import Path

ROOT = Path("D:/GitHub/AdvancedRocketry-Community/docs/decisions")


def patch(name, pairs):
    p = ROOT / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:70])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("### 3. Authority\n",
     "### 2.1 Structures\n\n"
     "The laser drill, railgun, black-hole generator and elevator anchor are\n"
     "**structure-only multiblocks**. Their shape is a `machine_patterns` file in the\n"
     "ADR-016 format, matched by the kernel's bounded `MultiblockPatternValidator`\n"
     "through a loaded-chunk world view; it never loads a chunk. Unlike the v1.2\n"
     "machines they have **no port blocks, part bindings or process journal**: every\n"
     "buffer lives in the controller block entity, and automation uses the\n"
     "controller's own capabilities. The controller re-validates when a neighbouring\n"
     "block changes inside its pattern box and every 200 ticks, at most 8 validations\n"
     "per server tick across all endgame controllers (the rest wait, ADR-054 §7). An\n"
     "unformed structure idles with `UNFORMED`, and one with an unloaded cell with\n"
     "`STRUCTURE_UNLOADED`; nothing is lost or dropped by either state.\n\n"
     "### 3. Authority\n"),
])
patch("ADR-055-ORBITAL-LASER-DRILL.md", [
    ("- A multiblock on the machine kernel (ADR-016): controller block",
     "- A structure-only multiblock (ADR-054 §2.1): controller block"),
])
patch("ADR-056-RAILGUN-CARGO-AND-TARGETING.md", [
    ("- A multiblock on the machine kernel (ADR-016): controller",
     "- A structure-only multiblock (ADR-054 §2.1): controller"),
])
patch("ADR-057-BLACK-HOLE-GENERATOR.md", [
    ("- A multiblock on the machine kernel (ADR-016): controller",
     "- A structure-only multiblock (ADR-054 §2.1): controller"),
])
patch("ADR-059-SPACE-ELEVATOR-LOGISTICS.md", [
    ("- **Anchor** (`elevator_anchor`): a multiblock on the machine kernel (ADR-016),",
     "- **Anchor** (`elevator_anchor`): a structure-only multiblock (ADR-054 §2.1),"),
])
print("ok")
