"""R1-H1 follow-up: tombstones need an aged absence and table pressure; the model can disable their removal."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")


def patch(path, pairs):
    p = REPO / path
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (path, old[:90])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("registering a delivered payload again (review R1-H1). Tombstones are at most\n"
     "64 bytes each and at most 8,192; they are admitted up to the root's hard bound\n"
     "and are never dropped any other way.",
     "registering a delivered payload again (review R1-H1). Tombstones are at most\n"
     "64 bytes each. One is removed only when its source's absence was observed at\n"
     "least 6,000 ticks earlier **and** the table holds more than 8,192 tombstones,\n"
     "oldest observation first; otherwise tombstones are kept, admitted up to the\n"
     "root's hard bound. Residual: if the absence observation itself was a lost\n"
     "asynchronous write and the server then crashed, S could return after its\n"
     "tombstone was removed and register a delivered payload again, unaudited. The\n"
     "6,000-tick age (five minutes of uninterrupted running, far beyond any `IOWorker`\n"
     "backlog) and the pressure rule make that unreachable in practice; it is the\n"
     "same lost-write class as the escrow residual below."),
    ("| No record, `seq > dispatched_through[S]` | persisted, aged, lowest entry of S |",
     "| No record, `seq > dispatched_through[S]` | persisted, aged, lowest entry of S |"),
])

check = "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ("    MAX_SEQ = 4\n",
     "    MAX_SEQ = 4\n"
     "    # R1-H1: tombstone removal needs an aged absence; tests switch it off to separate the residual.\n"
     "    TOMBSTONE_REMOVAL = True\n"),
    ("        # input, outbox{(seq, persisted, aged)}, next_seq, present, absence observed in a chunk tag\n",
     "        # input, outbox{(seq, persisted, aged)}, next_seq, present, absence (False, \"seen\" or \"aged\")\n"),
    ("        observed = not present\n",
     "        observed = absence_seen if absence_seen or present else \"seen\"\n"),
    ("        if any(o[1] and not o[2] for o in outbox):\n"
     "            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq,\n"
     "                                       present, absence_seen)), crashes_left, faults_left)\n"
     "        if hw is not None and not present and absence_seen:",
     "        if any(o[1] and not o[2] for o in outbox) or absence_seen == \"seen\":\n"
     "            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq,\n"
     "                                       present, \"aged\" if absence_seen else False)), crashes_left, faults_left)\n"
     "        if cls.TOMBSTONE_REMOVAL and hw is not None and not present and absence_seen == \"aged\":"),
    ("        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, present, not present)",
     "        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, present,\n"
     "                  False if present else \"seen\")"),
])
print("ok")
