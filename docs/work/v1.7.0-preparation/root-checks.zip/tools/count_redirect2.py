import sys
sys.path.insert(0, "D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")
import check_examples as c
for rules in ((True, True, True), (True, True, False), (True, False, True), (True, False, False), (False, False, False)):
    for crashes in (0, 1, 2):
        try:
            print(rules, crashes, c.Redirect.explore(rules, crashes), flush=True)
        except AssertionError as error:
            print(rules, crashes, "ERROR", str(error)[:120], flush=True)
