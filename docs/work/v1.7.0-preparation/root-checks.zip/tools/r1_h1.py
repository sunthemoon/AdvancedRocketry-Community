"""R1-H1: dispatched_through stays as a tombstone until the source's absence is persisted; lowest-entry registration."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")


def patch(path, pairs):
    p = REPO / path
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (path, old[:90])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch("docs/decisions/ADR-054-ENDGAME-AUTHORITY-PROTECTION-AND-AUDIT.md", [
    ("`dispatched_through[S]` is the highest registered `seq` of S and never\n"
     "decreases; it is what keeps a pruned transfer from being registered again.",
     "`dispatched_through[S]` is the highest registered `seq` of S and never\n"
     "decreases; it is what keeps a pruned transfer from being registered again.\n"
     "When S's endpoint record is removed (by any cause, §9, or by an operator purge)\n"
     "`dispatched_through[S]` stays as a **tombstone** until S's absence is persisted:\n"
     "a `ChunkDataEvent.Save` or `ChunkDataEvent.Load` tag of S's chunk whose\n"
     "block-entity list holds no entry with S's ID at the recorded position, observed\n"
     "at least 40 ticks earlier (the age rule of step 2). Until then a crash can\n"
     "restore S with a stale outbox entry, and only the tombstone keeps it from\n"
     "registering a delivered payload again (review R1-H1). Tombstones are at most\n"
     "64 bytes each and at most 8,192; they are admitted up to the root's hard bound\n"
     "and are never dropped any other way."),
    ("2. **Registration.** When the entry is persisted and the persistence\n"
     "   observation is at least 40 ticks old, and `seq = dispatched_through[S] + 1`,\n"
     "   the ledger creates the record",
     "2. **Registration.** When the entry is persisted and the persistence\n"
     "   observation is at least 40 ticks old, and the entry is S's **lowest** outbox\n"
     "   entry with `seq > dispatched_through[S]`, the ledger creates the record"),
    ("   created; it will wait as `DESTINATION_MISSING`.\n",
     "   created; it will wait as `DESTINATION_MISSING`. Normally\n"
     "   `seq = dispatched_through[S] + 1`; a larger `seq` means the ledger lost\n"
     "   registrations (an operator restored an older file), and the entry registers\n"
     "   with a `SEQUENCE_GAP` audit line instead of waiting forever.\n"),
    ("| No record, `seq > dispatched_through[S]` | persisted, aged, next in order | Register (step 2) |",
     "| No record, `seq > dispatched_through[S]` | persisted, aged, lowest entry of S | Register (step 2); `SEQUENCE_GAP` if `seq > dispatched_through[S] + 1` |"),
    ("late drop safe. `dispatched_through[S]` is removed only when S's endpoint record\n"
     "is removed, S holds no outbox entry, and no record has source S. A\n",
     "late drop safe. `dispatched_through[S]` is removed only as a tombstone whose\n"
     "source's absence is persisted (above). A\n"),
    ("| Record pruned while S still holds the entry (S unloaded, its release not yet saved, or that save lost) |",
     "| S removed (and its tombstone kept), ledger flushed, S's chunk not saved | S restored with an entry `seq ≤ dispatched_through` | Dropped (`OUTBOX_STALE_DROPPED`); delivered once |\n"
     "| Record pruned while S still holds the entry (S unloaded, its release not yet saved, or that save lost) |"),
    ("  `device inspect <pos>`; `device owner <pos> <player>`; `endpoint list\n"
     "  [<player>]`; `endpoint purge <id>` (records only, refused while referenced);",
     "  `device inspect <pos>`; `device owner <pos> <player>`; `endpoint list\n"
     "  [<player>]`; `endpoint purge <id>` (removes the index record only, refused\n"
     "  while referenced; the §11 tombstone stays until the absence is persisted);"),
])

check = "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    # Source state gains `present` and `absence_seen`; durable state gains `present`.
    ("        # input, outbox{(seq, persisted, aged)}, next_seq\n"
     "        s_live = (payloads, frozenset(), 1)\n"
     "        s_dur = (payloads, frozenset(), 1)",
     "        # input, outbox{(seq, persisted, aged)}, next_seq, present, absence observed in a chunk tag\n"
     "        s_live = (payloads, frozenset(), 1, True, False)\n"
     "        s_dur = (payloads, frozenset(), 1, True)"),
    ("        s_input, outbox, next_seq = s_live\n"
     "        records, hw, e = l_live",
     "        s_input, outbox, next_seq, present, absence_seen = s_live\n"
     "        records, hw, e = l_live\n"
     "        hw_value = 0 if hw is None else hw  # None: the tombstone was removed"),
    ("        rollback_pending = next_seq <= hw\n"
     "        if rollback_pending:\n"
     "            yield (\"FIX_ROLLBACK\", make(s_live=(s_input, outbox, hw + 1), rollback=True),",
     "        rollback_pending = present and next_seq <= hw_value\n"
     "        if rollback_pending:\n"
     "            yield (\"FIX_ROLLBACK\", make(s_live=(s_input, outbox, hw_value + 1, present, absence_seen),\n"
     "                                         rollback=True),"),
    ("        if not rollback_pending and s_input > 0 and len(outbox) < 4 and next_seq <= cls.MAX_SEQ:\n"
     "            yield (\"ESCROW\", make(s_live=(s_input - 1, outbox | {(next_seq, False, False)}, next_seq + 1)),\n"
     "                   crashes_left, faults_left)\n"
     "        new_outbox = frozenset((o[0], True, o[2]) for o in outbox)\n"
     "        saved = (s_input, frozenset(out_seqs), next_seq)\n"
     "        if saved != s_dur or new_outbox != outbox:\n"
     "            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq), s_dur=saved), crashes_left, faults_left)\n"
     "            if faults_left:\n"
     "                # The save is observed (ChunkDataEvent.Save) but its asynchronous file write is lost.\n"
     "                yield (\"SAVE_S_LOST\", make(s_live=(s_input, new_outbox, next_seq)), crashes_left, faults_left - 1)\n"
     "        if any(o[1] and not o[2] for o in outbox):\n"
     "            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq)),\n"
     "                   crashes_left, faults_left)",
     "        if present and not rollback_pending and s_input > 0 and len(outbox) < 4 and next_seq <= cls.MAX_SEQ:\n"
     "            yield (\"ESCROW\", make(s_live=(s_input - 1, outbox | {(next_seq, False, False)}, next_seq + 1,\n"
     "                                          present, absence_seen)), crashes_left, faults_left)\n"
     "        if present and s_input == 0 and not outbox:\n"
     "            # A player breaks the idle source (allowed: nothing escrowed, nothing in its input buffer).\n"
     "            yield (\"REMOVE_S\", make(s_live=(0, frozenset(), next_seq, False, False)), crashes_left, faults_left)\n"
     "        new_outbox = frozenset((o[0], True, o[2]) for o in outbox)\n"
     "        saved = (s_input, frozenset(out_seqs), next_seq, present)\n"
     "        observed = not present\n"
     "        if saved != s_dur or new_outbox != outbox or observed != absence_seen:\n"
     "            yield (\"SAVE_S\", make(s_live=(s_input, new_outbox, next_seq, present, observed), s_dur=saved),\n"
     "                   crashes_left, faults_left)\n"
     "            if faults_left:\n"
     "                # The save is observed (ChunkDataEvent.Save) but its asynchronous file write is lost.\n"
     "                yield (\"SAVE_S_LOST\", make(s_live=(s_input, new_outbox, next_seq, present, observed)),\n"
     "                       crashes_left, faults_left - 1)\n"
     "        if any(o[1] and not o[2] for o in outbox):\n"
     "            yield (\"AGE\", make(s_live=(s_input, frozenset((o[0], o[1], o[1] or o[2]) for o in outbox), next_seq,\n"
     "                                       present, absence_seen)), crashes_left, faults_left)\n"
     "        if hw is not None and not present and absence_seen:\n"
     "            # R1-H1: the tombstone goes only once the source's absence is persisted.\n"
     "            yield (\"DROP_HW\", make(l_live=(records, None, e)), crashes_left, faults_left)\n"
     "        lowest = min(out_seqs) if out_seqs else None"),
    ("            if r is None and seq <= hw:\n"
     "                yield (\"STALE_DROP\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq)),\n"
     "                       crashes_left, faults_left)\n"
     "            elif r is None and persisted and aged and seq == hw + 1:",
     "            if r is None and seq <= hw_value:\n"
     "                yield (\"STALE_DROP\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq,\n"
     "                                                  present, absence_seen)), crashes_left, faults_left)\n"
     "            elif r is None and persisted and aged and seq == lowest:"),
    ("                yield (\"RELEASE\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq)),\n"
     "                       crashes_left, faults_left)",
     "                yield (\"RELEASE\", make(s_live=(s_input, outbox - {(seq, persisted, aged)}, next_seq,\n"
     "                                               present, absence_seen)), crashes_left, faults_left)"),
    ("        s_input, out_seqs, next_seq = s_dur\n"
     "        # After restart the chunk load is a persistence observation; ageing restarts.\n"
     "        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq)",
     "        s_input, out_seqs, next_seq, present = s_dur\n"
     "        # After restart the chunk load is a persistence observation; ageing restarts.\n"
     "        s_live = (s_input, frozenset((seq, True, False) for seq in out_seqs), next_seq, present, not present)"),
    ("        order = [\"FIX_ROLLBACK\", \"STALE_DROP\", \"D_RECOVER\", \"D_ACK\", \"D_DROP\", \"D_REMAT\", \"PRUNE\",\n"
     "                 \"RELEASE\", \"REGISTER\", \"CLAIM\", \"ARRIVE\", \"ESCROW\", \"AGE\",",
     "        order = [\"FIX_ROLLBACK\", \"STALE_DROP\", \"D_RECOVER\", \"D_ACK\", \"D_DROP\", \"D_REMAT\", \"PRUNE\",\n"
     "                 \"RELEASE\", \"REGISTER\", \"CLAIM\", \"ARRIVE\", \"ESCROW\", \"AGE\", \"DROP_HW\","),
    ("        (s_input, outbox, _), _, (records, _, _), _, (buffer, receipts), _, rollback = state",
     "        (s_input, outbox, _, _, _), _, (records, _, _), _, (buffer, receipts), _, rollback = state"),
])
print("ok")
