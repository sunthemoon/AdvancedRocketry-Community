"""R1-M9: consent for gravity fields outside stations; density per owner; jump-height vectors."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:100])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/decisions/ADR-058-AREA-GRAVITY-CONTROLLER.md", [
    ("- at most 16 fields per chunk (`FIELD_DENSITY`), 8 active per owner, 256 per\n"
     "  Level and 1,024 per server (`ACTIVE_LIMIT`);\n",
     "- at most 16 fields per chunk and at most 4 of one owner per chunk\n"
     "  (`FIELD_DENSITY`, so one player cannot fill a bucket next to someone else's\n"
     "  base), 8 active per owner, 256 per Level and 1,024 per server\n"
     "  (`ACTIVE_LIMIT`);\n"),
    ("`fieldIndex.at` reads only the player's chunk bucket (≤ 16 candidates), keeps the\n"
     "fields whose box contains the player's block position, and returns `m / 100` of\n",
     "`fieldIndex.at` reads only the player's chunk bucket (≤ 16 candidates), keeps the\n"
     "fields whose box contains the player's block position **and that affect this\n"
     "player** (§5), and returns `m / 100` of\n"),
    ("- **Players only**, through the attribute. Values stay inside the existing\n"
     "  0..4.0 bound.\n",
     "- **Players only**, through the attribute. Values stay inside the existing\n"
     "  0..4.0 bound.\n"
     "- **Consent** (review R1-M9). Vanilla jump physics make the range harmful to\n"
     "  people who did not choose it: from 1.40 g a player can no longer jump onto a\n"
     "  full block (2.00 g: 0.77 blocks), so a pit or a one-block step can trap them,\n"
     "  and at 0.10 g a jump peaks near 6.9 blocks and costs about 4 HP of fall\n"
     "  damage. Therefore:\n"
     "  - inside a committed station region the field affects every player in its\n"
     "    clipped box, as the station's own gravity does: it is the station owner's\n"
     "    space and the field must belong to the station owner (§3);\n"
     "  - everywhere else a field affects only its owner and the players on its\n"
     "    **allow list** (at most 16 UUIDs, stored in the controller's root). The\n"
     "    owner edits it with `/arce endgame field allow <player>` and `field deny\n"
     "    <player>` from their own connected command source while looking at the\n"
     "    controller within 5 blocks (the warp-core rule, ADR-044 §4). Everyone else\n"
     "    keeps the station or Level gravity inside the box.\n"),
    ("| Trapping or flinging players | 0.10..2.00 g only, no lateral force, box ≤ 33³, players can walk out |",
     "| Trapping or hurting players (2.00 g blocks a one-block jump, 0.10 g jumps cost fall damage) | Outside stations only the owner and an allow list are affected; inside stations only the station owner's own fields; no lateral force; box ≤ 33³ |"),
    ("| Server load | Chunk-bucketed index, ≤ 16 candidates per lookup, active caps, no entity scans |",
     "| Server load | Chunk-bucketed index, ≤ 16 candidates per lookup, active caps, no entity scans |\n"
     "| Crowding someone else's fields out (`FIELD_DENSITY`) | At most 4 fields of one owner per chunk |"),
    ("Residual: a claim mod that listens to neither block events nor\n"
     "`EndgameEffectEvent` cannot veto a field on its land. Fields are bounded and\n"
     "harmless; zones and spawn protection still apply.\n",
     "Residual: a claim mod that listens to neither block events nor\n"
     "`EndgameEffectEvent` cannot veto a field on its land; outside stations such a\n"
     "field affects only players who consented, and zones and spawn protection\n"
     "still apply.\n"),
])

check = REPO / "docs/work/v1.7.0-preparation/check_examples.py"
patch(check, [
    ('''def upkeep(radius):
    return 5 + 2 * radius''',
     '''def upkeep(radius):
    return 5 + 2 * radius


def jump_height(multiplier, v0=0.42, drag=0.98, gravity=0.08):
    """Peak height of a vanilla player jump with the gravity attribute scaled (1.00 g gives 1.25 blocks)."""
    y, v, best = 0.0, v0, 0.0
    for _ in range(400):
        y += v
        best = max(best, y)
        v = (v - gravity * multiplier) * drag
        if v < 0 and y < best:
            break
    return best


def field_affects(case):
    """R1-M9: inside a station region everyone; elsewhere the owner and the allow list."""
    return case["in_station"] or case["player"] == case["owner"] or case["player"] in case["allow"]'''),
    ('''        worst = max(chunk_span(x - 16, x + 16) for x in range(-40, 40))
        self.assertEqual(worst, 3)''',
     '''        worst = max(chunk_span(x - 16, x + 16) for x in range(-40, 40))
        self.assertEqual(worst, 3)
        for multiplier, can_step_up in data["jump"]:
            self.assertEqual(jump_height(multiplier) >= 1.0, can_step_up, multiplier)
        for case in data["consent"]:
            self.assertEqual(field_affects(case), case["affected"], case)'''),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ('''        "upkeep": [[2, 9], [8, 21], [16, 37]],''',
     '''        "upkeep": [[2, 9], [8, 21], [16, 37]],
        "jump": [[0.10, True], [1.00, True], [1.35, True], [1.40, False], [2.00, False]],
        "consent": [
            {"in_station": True, "owner": "a", "player": "b", "allow": [], "affected": True},
            {"in_station": False, "owner": "a", "player": "a", "allow": [], "affected": True},
            {"in_station": False, "owner": "a", "player": "b", "allow": [], "affected": False},
            {"in_station": False, "owner": "a", "player": "b", "allow": ["b"], "affected": True},
        ],'''),
])
print("ok")
