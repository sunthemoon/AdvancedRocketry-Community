"""R3-M2: test, generator pins and mutations for capped tombstone eviction."""
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
PREP = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.7.0-preparation")


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (path.name, old[:100])
        s = s.replace(old, new)
    path.write_text(s, encoding="utf-8", newline="\n")


patch(PREP / "check_examples.py", [(
    """    def test_transit_named_cuts(self):
""", """    def test_transit_cap_eviction_keeps_the_lost_write_guarantee(self):
        # R3-M2: a cap evicts an unpinned tombstone once a chunk-save tag observed the source's absence. Without a
        # fault the source cannot return; after one lost write a returning copy with outbox entries is frozen and
        # resolved, an empty one registers anew, and no outcome class is added to the lost-write residual's.
        Transit.CAP_EVICTION = True
        try:
            clean_states, clean = Transit.explore(crashes=2, faults=0)
            states, outcomes = Transit.explore(crashes=2, faults=1)
            for case in EXAMPLES["transit"]["cap_eviction_cuts"]:
                state = Transit.normalize(Transit.initial())
                for label in case["events"]:
                    options = {l: s for l, s, _, _ in Transit.successors(state, 1, 1)}
                    self.assertIn(label, options, (case["name"], label, sorted(options)))
                    state = options[label]
                self.assertEqual(list(Transit.delivered(Transit.drain(state))), case["expected"], case["name"])
        finally:
            Transit.CAP_EVICTION = False
        for delivered, destroyed, rollback, faulted in clean:
            self.assertEqual((delivered + destroyed, rollback, faulted), (1, False, False))
        for (delivered, destroyed, rollback, faulted), _ in outcomes.items():
            self.assertGreaterEqual(delivered + destroyed, 1)
            if delivered > 1:
                self.assertTrue(faulted and rollback, outcomes)
        self.assertEqual([clean_states, states], EXAMPLES["transit"]["states_cap_eviction"])

    def test_transit_named_cuts(self):
""")])

patch(TOOLS / "generate_examples.py", [(
    """        "states_tombstone_removal_one_lost_write": 17897,
""", """        "states_tombstone_removal_one_lost_write": 17897,
        "states_cap_eviction": [882, 20756],
        "cap_eviction_cuts": [
            {"name": "R3-M2: absence save lost after the eviction; the copy with a delivered entry is frozen",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "ARRIVE", "CLAIM", "SAVE_D", "D_ACK",
                        "FLUSH_L", "PRUNE", "D_DROP", "SAVE_D", "FLUSH_L", "REMOVE_S", "SAVE_S_LOST", "AGE",
                        "EVICT_HW", "FLUSH_L", "CRASH"],
             "expected": [1, 0, False]},
            {"name": "R3-M2: removal and its absence saved, tombstone evicted, crash: delivered once",
             "events": ["ESCROW", "SAVE_S", "AGE", "REGISTER", "FLUSH_L", "REMOVE_S", "SAVE_S", "AGE", "ARRIVE",
                        "CLAIM", "SAVE_D", "D_ACK", "FLUSH_L", "PRUNE", "FLUSH_L", "EVICT_HW", "FLUSH_L", "CRASH"],
             "expected": [1, 0, False]},
        ],
""")])

patch(PREP / "check_mutations.py", [
    ("""DELIVERY = {
""", """# Capped tombstone eviction (review R3-M2), run with Transit.CAP_EVICTION on. Not listed: evicting a pinned
# tombstone and escrow before a durable re-registration. The model has one source life and no other ID, so it shows
# them as not load-bearing here; they guard sequence and identity reuse across lives, which it does not represent.
TRANSIT_CAP = {
    "evict-before-saved-absence": ('absence_seen in ("saved_aged", "aged") \\\\\\n                and not records:',
                                   'True \\\\\\n                and not records:', 1),
    "evict-without-freeze": ("            if out_seqs:\\n                lost =",
                             "            if False:\\n                lost =", 1),
}

DELIVERY = {
"""),
    ("""def load(out, name, old=None, new=None):
""", """def load(out, name, old=None, new=None, cap=False):
"""),
    ("""    spec.loader.exec_module(module)
    return module
""", """    spec.loader.exec_module(module)
    module.Transit.CAP_EVICTION = cap
    return module
"""),
    ("""    _, outcomes = control.Redirect.explore((True, True, True), 2)
""", """    control_cap = load(out, "control-cap", cap=True)
    for faults in (0, 1):
        found = transit_violation(control_cap, faults)
        print("control transit with cap eviction, %d lost write(s): %s" % (faults, found or "no violation"), flush=True)
        if found:
            failures.append("control cap")
    _, outcomes = control.Redirect.explore((True, True, True), 2)
"""),
    ("""    for name, (old, new) in DELIVERY.items():
""", """    for name, (old, new, faults) in TRANSIT_CAP.items():
        found = transit_violation(load(out, "transit-cap-" + name, old, new, cap=True), faults)
        found = None if found == "LIMIT" else found
        print("transit %-40s %s" % (name, ("CAUGHT: " + found[:90]) if found else "NOT CAUGHT"), flush=True)
        if not found:
            failures.append(name)
    for name, (old, new) in DELIVERY.items():
"""),
])
print("ok")
