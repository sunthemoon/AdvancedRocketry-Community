"""R1-H1 checker tests, pins, named cut and mutation."""
from pathlib import Path

REPO = Path("D:/GitHub/AdvancedRocketry-Community")
E = Path("C:/Users/Administrator/AppData/Local/Temp/arce-v170-preparation-6e0a40bb46fe4552a01f619bc25d8fcb")


def patch(p, pairs):
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (p.name, old[:90])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")


patch(REPO / "docs/work/v1.7.0-preparation/check_examples.py", [
    ("    def test_transit_lost_write_residual_is_detected(self):\n"
     "        states, outcomes = Transit.explore(crashes=2, faults=1)\n",
     "    def test_transit_lost_write_residual_is_detected(self):\n"
     "        # With tombstones kept, every duplicate needs a lost escrow write and is audited.\n"
     "        Transit.TOMBSTONE_REMOVAL = False\n"
     "        try:\n"
     "            states, outcomes = Transit.explore(crashes=2, faults=1)\n"
     "        finally:\n"
     "            Transit.TOMBSTONE_REMOVAL = True\n"),
    ("        self.assertEqual(states, EXAMPLES[\"transit\"][\"states_one_payload_two_crashes_one_lost_write\"])\n",
     "        self.assertEqual(states, EXAMPLES[\"transit\"][\"states_one_payload_two_crashes_one_lost_write\"])\n"
     "\n"
     "    def test_transit_tombstone_residual_needs_a_lost_absence_write(self):\n"
     "        states, outcomes = Transit.explore(crashes=2, faults=1)\n"
     "        unaudited = {key for key in outcomes if key[0] == 2 and not key[1]}\n"
     "        self.assertEqual(unaudited, {(2, False, True)})  # only after a lost write, as ADR-054 section 11 states\n"
     "        self.assertEqual(states, EXAMPLES[\"transit\"][\"states_tombstone_removal_one_lost_write\"])\n"),
])

g = E / "tools/generate_examples.py"
patch(g, [
    ("        \"states_two_payloads_two_crashes\": 53783,\n"
     "        \"states_one_payload_two_crashes_one_lost_write\": 7456,",
     "        \"states_two_payloads_two_crashes\": 54060,\n"
     "        \"states_one_payload_two_crashes_one_lost_write\": 15467,\n"
     "        \"states_tombstone_removal_one_lost_write\": 21668,"),
    ("            {\"name\": \"residual: escrow write lost after registration was flushed\",",
     "            {\"name\": \"R1-H1: source removed after delivery, crash before its chunk saved the removal\",\n"
     "             \"events\": [\"ESCROW\", \"SAVE_S\", \"AGE\", \"REGISTER\", \"FLUSH_L\", \"RELEASE\", \"ARRIVE\", \"CLAIM\",\n"
     "                        \"SAVE_D\", \"D_ACK\", \"FLUSH_L\", \"PRUNE\", \"D_DROP\", \"SAVE_D\", \"REMOVE_S\", \"CRASH\"],\n"
     "             \"expected\": [1, False]},\n"
     "            {\"name\": \"residual: escrow write lost after registration was flushed\","),
])

m = E / "tools/mutations.py"
patch(m, [
    ("    \"no-rollback-fix\": (\"        if rollback_pending:\\n\", \"        if False:\\n\"),",
     "    \"no-rollback-fix\": (\"        if rollback_pending:\\n\", \"        if False:\\n\"),\n"
     "    \"drop-tombstone-before-persisted-absence\": ('hw is not None and not present and absence_seen == \"aged\":',\n"
     "                                                'hw is not None and not present:'),"),
])
print("ok")
