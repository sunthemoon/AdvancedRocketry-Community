"""Archive the independent reviewer's own outputs (allow-list) into independent-review.zip plus a member index.

Excluded on purpose: tree/ (a copy of this repository), mc/ (Minecraft/Forge bytecode disassembly) and
upstream/*.java (upstream source bytes) and mutations-out/ (copies of
this repository's checker made by check_mutations.py). Only the reviewer's report, logs, scripts and hash lists are kept.
Usage: make_review_zip.py <out dir>
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

REVIEW = Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v170-contract-review-10bf7dbc233944db9aff249763c82d8f")
ALLOWED_SUFFIXES = {".md", ".log", ".py", ".java", ".txt", ".json"}
EXCLUDED_DIRS = {"tree", "mc", "upstream", "mutations-out"}


def members():
    for path in sorted(REVIEW.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(REVIEW)
        parts = relative.parts
        if parts[0] in EXCLUDED_DIRS and relative.as_posix() != "upstream/hashes.txt":
            continue
        if any(part in EXCLUDED_DIRS for part in parts[1:]) or path.suffix not in ALLOWED_SUFFIXES:
            continue
        yield relative.as_posix(), path


def main(out):
    out = Path(out)
    rows = []
    with zipfile.ZipFile(out / "independent-review.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, path in members():
            data = path.read_bytes()
            bundle.writestr(zipfile.ZipInfo(name, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    (out / "independent-review-files.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n",
                                                        encoding="utf-8", newline="\n")
    raw = (out / "independent-review.zip").read_bytes()
    print("independent-review.zip", len(rows), "members", len(raw), "bytes", hashlib.sha256(raw).hexdigest())
    for row in rows:
        print("  ", row["path"], row["bytes"])


if __name__ == "__main__":
    main(sys.argv[1])
