# V130-ENV independent final review

## Findings

No concrete unresolved correctness, contract or evidence-consistency finding in the reviewed V130-ENV slice. The scoped independent tests and bounded raw-evidence audit passed. This is **not** approval of v1.3 Required Gates, a release, client behavior or long-term stability.

The source review's two contract wording comments were corrected before implementation verification. Previously reviewed production/API/fixture source hashes did not change before the independent rerun. The runner and final evidence were reviewed separately below.

## Scope and identities

- Repository: `D:/GitHub/AdvancedRocketry-Community`.
- Baseline and HEAD at rerun: `758c7a11e430168e0f70221baace561dd41906bb`, with the reviewed working-tree implementation.
- Root subsequently committed the same bytes as contract/planning `be1453e`, production/API/fixture/tests `5b62291`, and runner/Python receipts `65bbd41c3a73b6e6fc9dd1a8f17803b46979a8ec`. These identify the reviewed source; the commits are not a claim of a subsequent rebuild.
- All **1,211 scoped source/build-definition/fixture/script files** and **8 JAR locations** (four build outputs plus four immutable evidence copies) had unchanged before/after SHA-256 values. See `before.json`, `after.json`, `hash-comparison.json`. Documentation may change concurrently under root ownership.
- Initial source report: `C:/Users/Administrator/AppData/Local/Temp/arce-v130-env-source-review-pbu5ypdv/REVIEW.md`. Its inspected implementation hashes match the rerun inputs.

## Independently executed tests

Environment: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, that JDK's `bin` prepended to PATH.

```text
.\gradlew.bat test --tests '*Environment*Test' --tests '*Api*Test' --tests '*BodyContextResolverTest' --rerun-tasks --offline --no-daemon --no-build-cache
```

Exit **0**, elapsed **46.6044395 seconds**; **15 tasks executed**, not test-cache reuse. Raw command/result/output: `gradle-command.txt`, `gradle-result.json`, `gradle.txt`. XML copies: `focused-junit/`.

| Suite | Tests |
|---|---:|
| EnvironmentSnapshotTest | 5 |
| ServerEnvironmentQueriesTest | 10 |
| BodyContextResolverTest | 8 |
| ApiArtifactTest | 14 |
| ApiVersionsTest | 9 |
| **Total** | **46** |

All five suites had zero failures, errors and skips. Actual compilation retains ResourceLocation deprecation warnings and Gradle future-version deprecation notices; these were not suppressed.

With `PYTHONUTF8=1`:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v130_environment_smoke -v
```

Exit **0**, **6 tests passed** (unittest 0.007 seconds; process 0.6490335 seconds). `python.txt`, `python-result.json` retain actual output and command.

No reviewer GameTest/server/client/remote run was performed. Root's archived full XML was independently counted: **756 tests / 141 suites**, zero failures/errors/skips. Its actual `gametest.log` states **188 required tests passed**, `BUILD SUCCESSFUL in 2m 21s`. These are inspected root executions, not independently repeated runs.

## Source and runner review

The earlier source report covers the five exports, finite record constraints, owner-thread/expired checks, binding reference release, single captured catalog, existing indexed station resolution, startup/stopping wiring and isolated consumer/classifier checks. No additional production source change was found relative to those hashes.

For `scripts/run_v130_environment_smoke.py`:

- Lines 48-58 compare exact probe identity/snapshot and boolean immediate loaded-chunk observations. Lines 74-99 bound decompression to 4 MiB, require schema/count/no reservations, match native station UUID/orbit/pad/environment and require full decoded registry equality at restart.
- Lines 115-127 validate installed artifact identities before launch and create one owned process. Lines 128-179 enforce bounded readiness/query/stop waits and capture exit, command transcript and logs; exceptions abort only the owned process. Reused `CapturedProcess` has finite stop/terminate/kill waits (`run_dedicated_server_smoke.py:674-699`). Input validation requires a disposable libraries-only server and a new disjoint evidence directory (`run_v130_adapter_recovery_smoke.py:115-135`).
- Lines 138-164 use real operator station creation/inspection and a real successful celestial reload; the orbit query remains tied to saved station identity, not changed Moon surface gravity. The runner does not simulate a native rejected reload.
- Lines 195-207 capture the actual stopped station SavedData, level.dat and datapack; lines 239-246 validate world identity across two processes and unchanged input artifacts. The runner does not claim to capture Anvil regions or a full-world checksum.
- Six Python tests exercise lifecycle receipt multiplicity/order/version, exact projection/loading flags, unresolved results, native identity/environment/schema changes, bounded station-count/schema decode, and invalid-Java failure before evidence creation. They are finite oracle checks, not comprehensive fault injection for all filesystem or process failure points.

No new source correction is requested. Existing source and native evidence support the stated configured-environment scope without changing physics, station schema or network authority.

## Independent artifact and consumer audit

Read actual immutable archives under `C:/Users/Administrator/AppData/Local/Temp/arce-v130-env-1790480192802/artifacts/`:

| Artifact | SHA-256 |
|---|---|
| Main | `048260a309a5ecb474dc69e81b3b5e403537f84dbdd156ebf534b56a4606374f` |
| API | `2ff1bc18015a897bc72cd7dbd283481f010a9b3490ec8d6c03e80d21ab4f7780` |
| Sources | `c550009cc2b16f2eba75c800b1961669577192e49705e1f2f20b3566abc4f444` |
| External fixture | `873aeda38ef4d585f4eb6e32de77c3a82aabcb3cc52575b095659b4aec3f0435` |

- API archive contains the exact **24** supported classes (including `EnvironmentSnapshot$Locus`), no extra class; each API class is byte-identical to its main-JAR entry. Existing exported classes are retained.
- Main/API/sources archives contain no fixture package/resources. The separate fixture includes `EnvironmentQueryFixture.class` and includes no host classes. No duplicate archive entry was present.
- Checked the actual files named by all **114** consumer classpath receipts and all **21** fixture source receipts. Only the remapped API dependency contains host classes, exactly the 24 allowed exports; other classpath archives contain none.
- Local publication coordinates and raw API digest match the approved lowercase artifact ID and immutable API copy. Remapped JAR digest matches the consumer report. Retained `mapped-api.input`; its `orig` SHA-1 matches the actual raw classifier. The recorded mapping digest is retained as metadata, not a new remapping execution by this audit.
- Independent consumer's negative-import report has exit **1**, actual forbidden internal class in the main archive, and `compiler.err.doesnt.exist` for `...rocket.forge`. This is deliberate isolation failure, not a failed product test. The environment-specific negative import also passed in the independent 46-test run.
- All **104** prepared library files matched the copied-library manifest's bytes and hashes.

## Independent raw native readback

Original immutable input: `C:/Users/Administrator/AppData/Local/Temp/arce-v130-env-1790480192802/runtime-evidence/`.

The helper `native_audit.py` imports only existing structural NBT and Forge ping decoders, **not** environment runner validation/expected-value functions. It reads original gzip NBT, raw logs and archive contents, then compares decoded JSON/runner receipts only as a consistency check. Derived output is `native-observations.json`.

- Verified all **31** manifest-listed files and exact manifest coverage. SHA256SUMS digest: `f8104477c6a0eeb882ddd37191fbf3625da4143c93f3a087e8f07b1f11f8f959`.
- Both phase result records show exit **0**. Each of stdout/latest/debug has exactly one API 1.6 ready receipt followed by exactly one expired receipt, then clean stop/save evidence; actual Forge startup is 47.4.10 on Minecraft 1.20.1. Both launches record only the two expected exact mod hashes. Native ping decoding confirms host, fixture, Forge and Minecraft, with zero players.
- Raw station SavedData has root schema 2 / format epoch `v0.9.0-beta`, two schema-1 committed stations and no reservations. Verified each station's owner UUID against the actual create command, name, cell, region, landing pad, orbit body, environment, members and invitations. Entire decoded root and the compressed `.dat` bytes are unchanged at restart.
- Earth station UUID: `474d8ac2-c9e7-4565-a0e1-a2a559f42abc`, cell `(0,0)`, pad `(0,128,0)`; Moon station UUID: `aeb214b9-f2b4-46db-a61a-92c8029434cb`, cell `(1,0)`, pad `(1024,128,0)`. Both retain saved gravity 0 and vacuum true; neither receives a fabricated atmosphere profile.
- Independently parsed **8 create + 6 restart probes** from all three raw log variants, matched the actual command transcript, immutable host body definitions, raw station UUIDs/pads and saved Moon datapack. All 14 observations have immediate `loaded_before=false` and `loaded_after=false`.
- The first process has Moon surface gravity **0.165**, one real `reload`, accepted celestial generation 2 and subsequent Moon surface gravity **0.4**. Moon-orbit gravity remains **0.0**. The restarted process reads Moon surface **0.4** and the same two station UUIDs without creating stations or reloading again. Unknown dimension and Space-gap probes remain unresolved.
- Raw level.dat retains Minecraft DataVersion 3465, the same WorldGenSettings and seed `-6562324498088962453`; saved game time advances **15 -> 23**. The env_query datapack is enabled and its Moon definition differs from the packaged default only by gravity 0.4. TOML bytes are exact across processes; server.properties comparison removes only the validated generated timestamp line. Loopback binding and offline smoke mode remain explicit.
- No ERROR/FATAL or linkage failure found in either phase's stdout/latest/debug. Warning counts with the terminal message included are stdout **27/11**, versus latest/debug **26/10**. The create cycle's actual **2,231 ms / 44 tick "Can't keep up"** warning is retained; no performance claim or rerun to hide it.

## Audit-helper corrections retained

The first supplemental audit stopped on the reviewer's incorrect expectation that the archived negative compiler diagnostic contained English "does not exist". The consumer uses `-XDrawDiagnostics`; its actual output is `compiler.err.doesnt.exist: ...rocket.forge`, with the expected exit 1. `native-audit-initial.txt` is retained. The corrected helper requires that exact diagnostic code/package and does not loosen the expected isolation result.

A read-only cache inspection also encountered Windows' ordinary-path length limit for `.jar.input`; the final helper uses extended-path syntax for paths at least 260 characters. No cache or source was edited. Final helper run exited **0**, recorded in `native-audit.txt`.

## Remaining limits / Gate status

- This proves configured metadata projection, successful live celestial reload, real ready/stopping notifications and same-world station identity across **two clean dedicated processes**. It does not prove crash recovery, arbitrary reload-listener atomicity or long-duration behavior.
- Rejected celestial candidates, ambiguity/blocked/missing data, no dirtying and wrong-thread/expired handles have focused test evidence; there was **no native rejected-reload process**. Real integrated-server restart was not executed.
- Immediate `getChunkNow` observations are not a general asynchronous-ticket/I/O tracer. The reviewed production query contains no chunk/ticket requests; the runner did not capture Anvil terrain or assert unchanged whole-world state. No room oxygen, effective entity gravity, travel/build permission or resource transaction behavior is inferred.
- No new client/GPU, multiplayer, remote or full original-feature campaign was performed. v1.3 Required Gate approval remains outside this report.
- Reviewer changed no tracked files or user document bundle; only generated Gradle outputs and this unique Temp evidence directory were written. Root remains the sole source/document writer. No OpenPet or child agents were launched.

The next work is root's canonical evidence/documentation completion and remaining v1.3 items, not a broader rerun prompted by this review.
