"""Read-only independent ENV audit; outputs only beside this helper.

Reuse structural NBT and Forge ping decoders, not environment runner validators.
"""
from pathlib import Path
import gzip, hashlib, io, json, re, struct, sys, uuid, zipfile
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v130-env-1790480192802')
OUT = Path(__file__).resolve().parent
EVIDENCE = BASE / 'runtime-evidence'
HOST = 'advancedrocketrycommunity'
PREFIX = 'io/github/sunthemoon/' + HOST + '/'
sys.path.insert(0, str(ROOT))
from scripts import inspect_celestial_saved_data as nbt
from scripts import run_dedicated_server_smoke as protocol

def read(p, cap=32*1024**2):
    p = Path(p)
    if len(str(p)) >= 260 and p.drive:
        p = Path('\\\\?\\' + str(p))
    assert p.is_file() and not p.is_symlink() and p.stat().st_size <= cap, str(p)
    return p.read_bytes()

def sha(raw): return hashlib.sha256(raw).hexdigest()
def js(p): return json.loads(read(p).decode('utf-8-sig'))
def uid(parts): return str(uuid.UUID(bytes=b''.join(struct.pack('>I', p & 0xffffffff) for p in parts)))
def unpack(p):
    with gzip.GzipFile(fileobj=io.BytesIO(read(p, 1024**2))) as f:
        raw = f.read(4*1024**2 + 1)
    assert len(raw) <= 4*1024**2
    old = nbt.MAX_TAGS
    try:
        nbt.MAX_TAGS = 65536
        return nbt.NbtReader(raw).read_root()
    finally: nbt.MAX_TAGS = old

def main():
    manifest = {}
    for line in read(EVIDENCE/'SHA256SUMS').decode('ascii').splitlines():
        digest, name = line.split('  ', 1)
        p = (EVIDENCE/name).resolve()
        assert EVIDENCE.resolve() in p.parents and name not in manifest
        assert sha(read(p)) == digest, name
        manifest[name] = digest
    assert set(manifest) == {p.relative_to(EVIDENCE).as_posix() for p in EVIDENCE.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}

    artifacts = {v['name']: v for v in js(BASE/'artifact-identities.json')}
    assert len(artifacts) == 4
    for name, meta in artifacts.items():
        raw=read(BASE/'artifacts'/name)
        assert len(raw)==meta['bytes'] and sha(raw)==meta['sha256']
    mainjar=BASE/'artifacts/advancedrocketry-community-1.20.1-1.3.0-dev.jar'
    apijar=BASE/'artifacts/advancedrocketry-community-1.20.1-1.3.0-dev-api.jar'
    fixturejar=BASE/'artifacts/arce-adapter-compat-test-1.0.0.jar'
    classes = {
        'version': ['ApiVersion','ApiVersions','ApiCompatibility'],
        'rocket': ['RocketBlockEntityAdapter','RocketAdapterRegistrar','RegisterRocketAdaptersEvent',
                   'RocketComponentDefinition','RocketComponentRegistrar','RegisterRocketComponentsEvent',
                   'RocketFuelDefinition','RocketFuelRegistrar','RegisterRocketFuelsEvent'],
        'atmosphere': ['AtmosphereBoundary','AtmosphereBoundaryProvider','AtmosphereBoundaryRegistrar',
                       'RegisterAtmosphereBoundariesEvent','SuitOxygenProvider','SuitEquipmentRegistrar','RegisterSuitEquipmentEvent'],
        'environment': ['AtmosphereProfile','EnvironmentQueries','EnvironmentSnapshot','EnvironmentSnapshot$Locus','ServerEnvironmentReadyEvent']}
    expected={PREFIX+'api/'+package+'/'+name+'.class' for package,names in classes.items() for name in names}
    assert len(expected)==24
    with zipfile.ZipFile(apijar) as api, zipfile.ZipFile(mainjar) as host:
        assert {n for n in api.namelist() if n.endswith('.class')}==expected
        assert {n for n in host.namelist() if n.startswith(PREFIX+'api/') and n.endswith('.class')}==expected
        assert all(api.read(n)==host.read(n) for n in expected)
        definitions={body: json.loads(host.read(f'data/{HOST}/celestial_bodies/{body}.json')) for body in ('earth','moon')}
        assert PREFIX+'compat/environment/ServerEnvironmentQueries.class' in host.namelist()
    for name in artifacts:
        with zipfile.ZipFile(BASE/'artifacts'/name) as jar:
            names=jar.namelist(); assert len(names)==len(set(names))
            if name != fixturejar.name:
                assert not any('arceadaptertest' in n or 'arce_adapter_test' in n for n in names)
            else:
                assert not any(n.startswith(PREFIX) for n in names)
                assert 'io/github/sunthemoon/arceadaptertest/EnvironmentQueryFixture.class' in names

    cp=js(BASE/'consumer-reports/classpath.json')
    assert cp['requested_api']==f'io.github.sunthemoon.{HOST}:advancedrocketry-community:1.20.1-1.3.0-dev:api'
    assert sha(read(cp['published_file']))==cp['published_sha256']==sha(read(apijar))
    assert sha(read(cp['raw_api']))==sha(read(apijar))
    assert sha(read(cp['remapped_api']))==cp['remapped_sha256']
    for entry in cp['compile_classpath']:
        p=Path(entry['file']); assert sha(read(p,128*1024**2))==entry['sha256']
        with zipfile.ZipFile(p) as jar:
            actual={n for n in jar.namelist() if n.startswith(PREFIX) and n.endswith('.class')}
        assert actual==set(entry['host_classes'])
        assert actual==(expected if p==Path(cp['remapped_api']) else set()), str(p)
    for entry in cp['fixture_sources']: assert sha(read(entry['file']))==entry['sha256']
    mapped=Path(cp['remapped_api']); inp=mapped.parent/(mapped.name+'.input')
    (OUT/'mapped-api.input').write_bytes(read(inp))
    cache=dict(line.split('=',1) for line in read(inp).decode('ascii').splitlines())
    assert cache['orig']==hashlib.sha1(read(apijar)).hexdigest()
    fixture_receipt=js(BASE/'consumer-reports/fixture-artifact.json')
    assert fixture_receipt['sha256']==sha(read(fixturejar)) and fixture_receipt['reobfuscated'] is True
    negative=js(BASE/'consumer-reports/negative-import.json')
    assert negative['exit_code']==1 and negative['inspected_host_sha256']==sha(read(mainjar))
    assert 'compiler.err.doesnt.exist: io.github.sunthemoon.advancedrocketrycommunity.rocket.forge' in str(negative['diagnostics'])
    libs=js(BASE/'library-copy-identity.json')
    for entry in libs:
        raw=read(BASE/'server/libraries'/entry['path'],128*1024**2)
        assert sha(raw)==entry['sha256'] and len(raw)==entry['bytes']

    observations={}; baseline=None; firstlevel=None
    for phase in ('create','restart'):
        d=EVIDENCE/phase; raw=unpack(d/f'world/data/{HOST}_stations.dat'); data=raw['data']
        assert data['schema_version']==2 and data['format_epoch']=='v0.9.0-beta' and data['reservations']==[]
        assert len(data['stations'])==2
        by_body={s['orbit_body'].split(':')[1]:s for s in data['stations']}
        assert set(by_body)=={'earth','moon'}
        commands=js(d/'commands.json'); assert commands[-2:]==['save-all flush','stop']
        if phase=='create':
            assert commands.count('reload')==1
            for body,index in (('earth',0),('moon',1)):
                station=by_body[body]
                matches=[c for c in commands if c.startswith('arce station admin create ') and c.endswith(f' {HOST}:{body} Env {body}')]
                assert len(matches)==1 and uid(station['owner_id'])==matches[0].split()[4]
                assert station['name']=='Env '+body and station['cell_x']==index and station['cell_z']==0
                assert station['region']==[index*1024-256,-256,index*1024+255,255]
                assert station['landing_pad']==[index*1024,128,0]
        else:
            assert not any(c.startswith('arce station admin ') or c=='reload' for c in commands)
            assert raw==baseline
        for station in by_body.values():
            assert station['schema_version']==1 and station['members']==[] and station['invitations']==[]
            assert station['environment']=={'gravity_milli':0,'vacuum':1,'solar_angle_milli_degrees':270000}
        level=unpack(d/'world/level.dat')['Data']
        assert level['DataVersion']==3465 and level['Version']['Name']=='1.20.1'
        assert 'file/env_query' in level['DataPacks']['Enabled']
        if firstlevel:
            assert firstlevel['WorldGenSettings']==level['WorldGenSettings']
            assert level['Time']>firstlevel['Time']
        else: firstlevel=level
        override=js(d/f'world/datapacks/env_query/data/{HOST}/celestial_bodies/moon.json')
        expected_override=dict(definitions['moon'],gravity_multiplier=0.4)
        assert override==expected_override
        result=js(d/'result.json'); assert result['exit_code']==0 and result['result']=='PASS'
        launch=js(d/'launch.json')
        assert launch['mods']=={p.name:sha(read(p)) for p in (mainjar,fixturejar)}
        assert '-Darce_adapter_test.environmentSmoke=true' in launch['command']
        status=js(d/'status.json'); assert status['players']['online']==0
        assert protocol.forge_mod_versions(status)=={HOST:'1.20.1-1.3.0-dev','arce_adapter_test':'1.0.0','forge':'','minecraft':'1.20.1'}
        logs={}; native_probes=None
        for log in ('stdout.txt','latest.log','debug.log'):
            lines=read(d/log).decode('utf-8').splitlines()
            severe=[l for l in lines if re.search(r'/(?:ERROR|FATAL)\]',l) or any(t in l for t in ('NoClassDefFoundError','ClassNotFoundException','NoSuchMethodError','Exception in thread'))]
            assert not severe,(phase,log,severe)
            ready=[i for i,l in enumerate(lines) if l.endswith('Environment query handle ready (API 1.6)')]
            expired=[i for i,l in enumerate(lines) if l.endswith('Environment query handle expired at server stopping')]
            assert len(ready)==len(expired)==1 and ready[0]<expired[0]
            assert any('Stopping server' in l for l in lines) and any('All dimensions are saved' in l for l in lines)
            assert any('Forge mod loading, version 47.4.10' in l for l in lines)
            probes=[json.loads(l.split('ARCE_ENV_PROBE ',1)[1]) for l in lines if 'ARCE_ENV_PROBE ' in l]
            assert len(probes)==(8 if phase=='create' else 6)
            assert len({p['label'] for p in probes})==len(probes)
            if native_probes is None: native_probes=probes
            else: assert probes==native_probes
            accepted=[l for l in lines if 'Accepted celestial catalog generation ' in l]
            assert len(accepted)==(2 if phase=='create' else 1)
            if phase=='create': assert 'generation 2 with 3 bodies' in accepted[1]
            logs[log]={'warn_lines':[l for l in lines if '/WARN]' in l or ' WARN ' in l], 'probe_count':len(probes),'ready':ready[0]+1,'expired':expired[0]+1}
        assert native_probes==result['probes']
        probe_commands=[c for c in commands if c.startswith('arce_env_probe ')]
        assert len(probe_commands)==len(native_probes)
        for command,probe in zip(probe_commands,native_probes):
            _,label,dimension,*coords=command.split()
            assert probe['label']==label and probe['dimension']==dimension
            assert probe['loaded_before'] is False and probe['loaded_after'] is False
            if label in ('space_gap','unknown'):
                assert probe['resolved'] is False and 'snapshot' not in probe
            elif 'orbit' in label:
                body='moon' if label=='reloaded_orbit' else label.split('_')[0]
                station=by_body[body]
                assert list(map(int,coords))==station['landing_pad']
                assert probe['snapshot']=={'body':station['orbit_body'],'locus':'STATION_ORBIT','instance':uid(station['station_id']),'gravity':0.0,'vacuum':True}
                assert probe['resolved'] is True
            else:
                assert list(map(int,coords))==[28000000,0,-28000000]
                body='earth' if label=='earth' else 'moon'
                definition=definitions[body] if body=='earth' or (phase=='create' and label=='moon') else override
                atmo=definition['atmosphere']
                assert probe['snapshot']=={'body':definition['id'],'locus':'SURFACE','gravity':definition['gravity_multiplier'],'vacuum':atmo['pressure']==0,
                    'atmosphere':{'pressure':atmo['pressure'],'breathable':atmo['breathable'],'temperature':atmo['temperature_kelvin'],'profile':atmo['profile']}}
                assert probe['resolved'] is True
        for rel,meta in result['disk_evidence'].items():
            payload=read(d/rel); assert sha(payload)==meta['sha256'] and len(payload)==meta['bytes']
        assert data==js(d/'native-stations.json')
        observations[phase]={'station_ids':{b:uid(s['station_id']) for b,s in by_body.items()},'game_time':level['Time'],'seed':level['WorldGenSettings']['seed'],'exit_code':result['exit_code'],'logs':logs,'probes':native_probes,'raw_stations_sha256':sha(read(d/f'world/data/{HOST}_stations.dat'))}
        baseline=raw
    for rel in ('config/advancedrocketrycommunity-common.toml','config/fml.toml'):
        assert read(EVIDENCE/'create'/rel)==read(EVIDENCE/'restart'/rel)
    def config(phase):
        lines=read(EVIDENCE/phase/'server.properties').splitlines(keepends=True)
        assert lines[0].rstrip()==b'#Minecraft server properties'
        assert re.fullmatch(rb'#[A-Z][a-z]{2} [A-Z][a-z]{2} \d{2} \d{2}:\d{2}:\d{2} \S+ \d{4}',lines[1].rstrip())
        return b''.join(lines[:1]+lines[2:])
    assert config('create')==config('restart')
    assert b'server-ip=127.0.0.1' in config('create') and b'online-mode=false' in config('create')
    suites=[ET.parse(p).getroot() for p in (BASE/'full-junit').rglob('TEST-*.xml')]
    assert len(suites)==141 and sum(int(s.attrib['tests']) for s in suites)==756
    assert all(int(s.attrib[k])==0 for s in suites for k in ('failures','errors','skipped'))
    assert 'All 188 required tests passed' in read(BASE/'gametest.log').decode('utf-8-sig')
    output={'result':'PASS','manifest_files':len(manifest),'manifest_sha256':sha(read(EVIDENCE/'SHA256SUMS')),'artifacts':artifacts,
        'api_classes':sorted(expected),'classpath_jars':len(cp['compile_classpath']),'fixture_source_files':len(cp['fixture_sources']),
        'library_files':len(libs),'observations':observations,'root_tests':{'junit':756,'suites':141,'gametests':188}}
    (OUT/'native-observations.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k not in ('observations','api_classes','artifacts')},indent=2))
    print('Native UUIDs/time:',[(p,v['station_ids'],v['game_time']) for p,v in observations.items()])

if __name__=='__main__': main()
