# V130-ENV independent source review

## Findings

No concrete unresolved correctness or contract finding in the source inspected for this slice. This is a source-review result, not a build/runtime verdict or Required Gate approval.

The two earlier contract wording recommendations are resolved in ADR-028:35 and 73-75: both resource IDs are bounded explicitly, and rejected-candidate retention is limited to the celestial catalog rather than all datapack listeners.

## Inspected implementation

Java paths in this section are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless stated otherwise.

- `api/environment/AtmosphereProfile.java:13-25` checks null/ID length, finite closed numeric ranges and positive pressure for breathable air. `EnvironmentSnapshot.java:20-38` checks the body ID, gravity, required optionals and surface/station cross-field invariants. All returned values are immutable detached records; the station branch does not fabricate atmosphere information. No client implementation types or mutable world objects are exposed in their fields.
- `compat/environment/ServerEnvironmentQueries.java:26-34,85-92` keeps all server-bearing predicates/services/resolver state in a single volatile binding and drops it on close. There is no separately retained owner predicate or station resolver after close. `at` at lines 38-56 checks the binding and owner thread before the Level predicate or catalog access; invalid input null checks happen first as documented. The production Level predicate is `server.getLevel`, not a chunk request.
- The query reads one immutable catalog at lines 51-56 and supplies it to the new `celestial/context/BodyContextResolver.java:37-61` overload. The original one-argument method delegates to that overload after its existing capture, preserving existing behavior. Identity and environment projection therefore use the same catalog rather than two independent current-catalog reads.
- Station resolution at `ServerEnvironmentQueries.java:63-82` verifies the current committed station identity/orbit body and projects the saved gravity-milli/vacuum fields. Existing fixed-size/indexed station lookup remains authoritative; reservations, unknown orbit bodies and Space gaps do not become surface results. Query code contains no save, dirtying, block access, world scan or per-position cache.
- `compat/environment/EnvironmentQueryLifecycle.java:21-41` acquires station SavedData at startup and posts the ready event after constructing the handle. Stopping and stopped cleanup both close/drop the handle. `AdvancedRocketryCommunity.java:134-140` registers startup after station startup and registers both cleanup listeners at HIGHEST priority. The lifecycle holder itself remains registered on the Forge bus but no longer retains the server through a handle after cleanup. The adapter assumes Forge's normal single logical-server lifecycle; it is not an arbitrary same-JVM event sandbox.
- `EnvironmentQueryFixture.java:29-62` registers during fixture construction, observes the real host event, refuses duplicate live handles and verifies expiration at LOWEST stopping priority. Its opt-in permission-2 command at lines 65-90 uses public API only and uses non-loading `getChunkNow` observations around the query.
- Build changes at `build.gradle:297-304,338-365` add four isolated source types and the nested enum to the exact class allowlist, compile without host output or source discovery, and extract classifier bytes from the actual reobfuscated main JAR. `compat-test-mod/build.gradle:35-37` has the corresponding five entries. The intended total is 24 exported class files. These are source-level checks; final artifact contents and classpath resolution were not inspected while the root build was active.
- `api/version/ApiVersions.java:7` advances to 1.6. The external fixture requires 1.6, and the older runner receipt strings/tests change only their expected API version. No existing runtime save or packet schema change appeared in the scoped diff.

## Tests inspected, not executed

- `src/test/java/.../api/environment/EnvironmentSnapshotTest.java`: five methods cover value identity, finite/range limits, cross-field shapes, both exact ID-length boundaries, nulls and the non-cancelable event.
- `src/test/java/.../compat/environment/ServerEnvironmentQueriesTest.java`: ten methods cover Earth/Moon, two saved stations with different environment/orbit values, exact SavedData/dirty-flag preservation, reservation/commit/delete visibility, region edge/gap, blocked/unknown body, accepted/rejected candidate freshness and detached values, missing body after reload, unavailable/unmapped/ambiguous Level, actual worker-thread rejection and expired/non-rebinding handles, and null arguments. The close test also verifies the sole retained binding field becomes null instead of relying on nondeterministic garbage collection.
- `src/adapterTest/java/.../EnvironmentQueryGameTests.java:23-68`: three real-event-handle tests cover actual Earth/Moon projection, far unloaded coordinates including Space gaps, missing dimension and actual foreign-thread refusal. They do not install internal service instances or mutate station/catalog state. No new shared-world resource fixture or persistent ticket is introduced.
- `ApiArtifactTest.java:178-195` adds positive classifier/platform-only compilation and a negative internal-environment import, first proving that the forbidden class really exists in the runtime JAR. Existing archive-set, byte-identity and classpath contamination assertions remain intact.

## Evidence limits and finite follow-up

No Gradle, Java, Python tests, GameTest, server or network command was run by this reviewer. In particular:

- The focused tests have been reviewed but not independently rerun. Suggested later focused set is `EnvironmentSnapshotTest`, `ServerEnvironmentQueriesTest`, existing `BodyContextResolverTest`, `ApiArtifactTest` and `ApiVersionsTest`.
- The GameTest and fixture checks still need actual execution evidence for startup/stopping ordering and event delivery. Direct `close()` unit coverage alone is not proof of platform lifecycle wiring. A subsequent integrated-server instance is modeled by a new unit handle, not an actually restarted integrated client.
- `getChunkNow` immediately before/after (`EnvironmentQueryGameTests.java:44-49`, fixture lines 76-80) establishes loaded-chunk state for those coordinates; it is not, by itself, an oracle for every possible asynchronous ticket request. The inspected production query code requests no tickets/chunks. Do not describe that observation as a general world-I/O tracer.
- Unit reload tests call the actual catalog manager with candidates; they are not native `/reload` evidence. Native station identity persistence, real reload and restart remain the separately planned bounded packaged verification.
- Exact final JAR exports/byte identity, consumer dependency receipts, full root test results and native archives are not established by this report. No client, multiplayer, long-load or full original-feature acceptance is inferred.

## Commands and identities

- Baseline/observed HEAD: `758c7a11e430168e0f70221baace561dd41906bb`.
- Read-only commands: `git status --short`, `git diff --stat`, scoped `git diff`, numbered PowerShell `Get-Content`, `Get-ChildItem`, `Select-String`, `rg`, and `git diff --check` (exit 0). Earlier contract review already read the required governance/version/quality documents.
- A Python `-B` inspection helper created this unique Temp directory and wrote `source-identities.json` plus `tracked-diff.patch`. The first patch-capture attempt had a mistyped Git exclusion pathspec and exited 128; the corrected command used an explicit list of tracked scope prefixes and succeeded. No repository file was written by either attempt. The failure did not execute a test or modify source.
- `source-identities.json` includes the inspected new untracked API/service/test/fixture/consumer files and current tracked changes. Root is still the sole writer and may make later scoped changes; this report applies to the captured hashes, not unspecified later revisions.
- The user-supplied untracked development-document bundle was not read or changed. No OpenPet events or child agents were started.
