# V130-ENV independent contract review

## Findings

No material contract blocker found in the reviewed boundary. Two low-priority wording recommendations remain; neither requires a new runtime mechanism.

1. **P3 - Qualify reload preservation as celestial-catalog preservation.** `docs/decisions/ADR-028-READ-ONLY-ENVIRONMENT-QUERIES.md:73-74` says successful/rejected reloads without naming the candidate. The existing `celestial/service/CelestialDefinitionReloadListener.java:32-50` applies this listener's decoded catalog directly, and `CelestialCatalogManager.java:21-44` retains the previous catalog when that candidate is rejected. This does not establish an atomic rollback transaction across all datapack reload listeners. Recommend saying an accepted celestial catalog becomes visible on the next query and a rejected celestial candidate retains the previous catalog. This avoids consumers interpreting a later unrelated listener failure as rollback of an already published catalog.
2. **P3 - Name both bounded resource IDs.** ADR-028:35 says "Snapshot IDs" after declaring `AtmosphereProfile.profile` at lines 32-33. Explicitly state the 128-character bound applies to both `EnvironmentSnapshot.bodyId` and `AtmosphereProfile.profile`. Existing `celestial/model/BoundedCelestialCodecs.java` uses this bound for both the body ID and atmosphere-profile ID. The UUID is fixed-size and is not the intended string budget. Test both public constructors independently.

References to Java files below are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` and refer to baseline `758c7a11e430168e0f70221baace561dd41906bb`, not the concurrent new implementation.

## Source-supported contract assessment

- **Precedence is compatible.** Baseline `celestial/context/BodyContextResolver.java:28-54` captures a catalog, checks instance resolvers before Level mapping, treats authoritative unresolved results as empty and accepts a surface only for exactly one Level candidate. `station/orbit/StationRegionBodyContextResolver.java:21-36` makes Space gaps/reservations unresolved rather than falling back to generic Space. The public service must additionally check Level availability without fetching chunks; the baseline resolver itself does not do that.
- **Indexed lookup already exists.** `celestial/service/CelestialCatalog.java:20-33,95-105` bounds bodies to 128 and constructs immutable Level indices. `station/model/StationRegistryModel.java:107-122` computes one grid cell with long arithmetic and uses map lookups plus an inclusive region test. Reservations are not committed stations. `station/model/StationLimits.java:7-8` bounds stations/reservations to 4096/64. No added position cache, scan queue or chunk loading is needed for the proposed query.
- **Station fields are correctly distinguished from surface values.** `station/model/StationEnvironmentProfile.java:4-21` stores gravity in milli-units (0..10000), vacuum and solar angle only; `station/persistence/StationNbtCodec.java:41-45,77-81` persists these fields. Thus station gravity needs division by 1000.0, and an absent atmosphere profile is accurate. Inventing station pressure, temperature or breathable air would not be supported by this schema.
- **Configured versus effective values is an important accurate boundary.** `celestial/service/CelestialEnvironmentService.java:16-25` and `celestial/service/CelestialGravityController.java:22-30` remain Level-based. ADR-028:79-84 correctly does not promise changed station gravity, room oxygen, permissions or player authority.
- **No-query-I/O is implementable only after acquisition.** `station/persistence/StationRegistrySavedData.java:28-34` acquires through lazy storage; loading/migration can mark data dirty at lines 65-66. By contrast, `findAt` at lines 170-171 is read-only and returns empty for blocked state. Startup acquisition and existing migration are distinct from the query guarantee. Tests should compare dirty state before/after a query after acquisition, not infer that startup can never perform I/O or migration.
- **Freshness needs no new persistent generation.** Catalog publication replaces immutable state (`CelestialCatalogManager.java:21-44`); station commit/delete update existing indices (`StationRegistryModel.java:49-76`). Detached scalar/resource-ID/UUID records can remain stable while the next query sees changed authoritative state.
- **Lifecycle promise is stronger than the old resolver and must be tested in implementation.** ADR-028:52-57 requires invalidation to clear all server-bearing state, including any captured closures. Both owner-thread and expired checks must occur before reading services or Levels; a later integrated server must get a distinct handle. Existing mod cleanup alone does not prove retained external handles are harmless.
- **API compatibility is appropriately additive.** ADR-021:56-72 requires a minor bump for the new supported types/behavior. ADR-028's API 1.6 and five new exported class files (four top-level types plus nested enum) are consistent with retaining the preceding nineteen exports. No save or network version change is implied. Classifier isolation and exact class-byte identity remain implementation checks, not facts established by this contract review.
- **Plan scope remains bounded.** `docs/work/v1.3.0-implementation-log.md:59-65,120-138` keeps ENV active and satellite/acceptance planned; neither ADR nor the entry claims full Required Gate completion.

## Finite verification recommendations

These are recommendations, not executed checks:

- Exercise all public-record null/range/finite/cross-field constraints, both resource-ID bounds and station/surface variants.
- Exercise surface, ambiguous/unknown/unavailable Level, active station, reservation/gap/deleted/blocked station, unknown orbit body, inclusive edges and negative coordinates. Verify no terrain/chunk reads and unchanged SavedData dirty state during queries.
- Capture one catalog per query for identity and values; test accepted/rejected celestial candidates and previously returned detached values, plus station create/delete visibility.
- Verify ready-event delivery once per logical server, owner-thread rejection, stopping invalidation, stopped fallback and old-handle rejection after a new server starts. Review references cleared by invalidation separately from functional expiration tests.
- Check exact 24-class classifier boundary, main/API class identity, existing consumers and isolated external consumer compilation/loading. Short dedicated restart should verify persisted station identity rather than only a synthetic in-memory station.

## Actual inspection and commands

- Read governance: AGENTS.md, PROJECT-CONFIG.md, PRODUCT.md, docs/01,04,05,06,14,16,17, the v1.3 version document, ADR-014, ADR-021, ADR-028 and the active implementation-log entry.
- Read/searched the baseline celestial/context/catalog/environment, station model/persistence/lifecycle, mod bootstrap and adjacent resolver/catalog/SavedData tests. Existing test source was inspected; no tests were executed.
- Used PowerShell `Get-Content`, numbered line output, `Select-String`, and read-only Git commands (`git rev-parse HEAD`, `git status --short`, `git show 758c7a11e430168e0f70221baace561dd41906bb:<path>`, `git diff --check`). The final whitespace check exited 0.
- Used `D:/python/pyenv/pyenv-win/shims/python.bat -B -c ...` only to create this unique Temp directory and hash the inspected documents into `identity.json`. No repository files were written. One initial read used the nonexistent lowercase version filename; the actual `docs/versions/V1.3.0-PUBLIC-API-COMPATIBILITY.md` was subsequently read.
- Observed HEAD remained the baseline. Root began adding implementation files during review; those concurrent edits were not reviewed or treated as verified by this contract report. ADR hash at final read: `83de6f9612326962bb4018dc68b71bc57aa84611cb150a101999d73289cb8de9`.

## Limits

Contract/source feasibility review only. No Gradle, Java, Python tests, server, packaged artifact, client, remote or stability run was performed. No claim of implementation correctness, absence of lifecycle leaks, native persistence verification or full v1.3 Gate approval. The user-supplied untracked development-document bundle was not inspected or changed. Root remains the sole repository writer.
