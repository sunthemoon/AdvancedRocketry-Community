# V140-MAP-01 independent source and ADR-032 draft review

Baseline: `eee45f5010e1332c69c6eb18f127fc468cfea5df`, branch `codex/v1.4.0-planetary-expansion`.
Reviewer: delegated read-only reviewer; root is the only repository writer.
This is contract preparation, not an implementation review, executed test receipt, migration certification, or Gate approval.

## Findings and final wording resolution

**No unresolved contract finding at final readback.** Root applied both clarifications below: accepted ADR-032:67-68 now explicitly checks metadata-only reloads; :76-81 explicitly aborts startup for pending staging, preserves it, distinguishes caught-operation cleanup and gives stopped-world recovery boundaries. Final contract SHA256: `a9bc30323cf0783241e19fa5fdff1ea2bf83a1047c73e700ba83d299d9b58bf7`. The original report is retained as `REVIEW-DRAFT-SNAPSHOT.md` (SHA256 `f140eba86d245214620fbc226927521acfa45f98da46ef2e4d71d0eb2ba6ef74`). Root acceptance is maintainer authority, not reviewer Gate approval.

The historical observations below retain the original draft line references. New untracked `celestial/binding/` implementation appeared during final contract readback and was deliberately not opened under this contract-only scope. No claim about that implementation follows from this report.

No blocking contradiction was found between the selected prospective-adoption policy and the inspected existing authority model. The draft explicitly limits what first adoption proves, rejects aliases as a new world-admission constraint, and does not rewrite existing saves. Two low-severity clarifications were sent to the writer:

1. **Interrupted staging policy needs an operational outcome.** ADR-032:74-76 says to diagnose and preserve interrupted staging files, without explicitly saying whether startup must abort. Specify fail-closed startup until operator recovery, or another precise bounded policy; distinguish this from cleanup of a staging file created by a caught ordinary failure in the current attempt. Never silently promote it. This matters when the authority file is absent: otherwise a leftover staging file and the first-adoption rule have ambiguous precedence.
2. **No-write reloads still require authority identity checking.** ADR-032:65-66 and :82-83 together imply that metadata-only reloads must check the opened file even though they do not rewrite it. Make this explicit so an optimization cannot publish after external deletion/replacement without detecting it. The existing manager currently accepts every otherwise valid pair at `celestial/data/PlanetaryCatalogManager.java:37-45`.

These are contract wording/verification points, not claims that new runtime defects have been reproduced. Runtime implementation has not been reviewed or executed in this task.

## Existing facts and resulting minimum requirements

Java references below are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.

| Existing evidence | Consequence for the binding contract |
| --- | --- |
| `celestial/persistence/CelestialSavedData.java:22-35,100-105,167-182` persists discovery/visit IDs and times, not a body-to-Level mapping. | A missing ledger is uninitialized history, not proof of a new world. Do not infer historical mappings from discovery. |
| `station/persistence/StationNbtCodec.java:99-108,145-160` stores orbit body, UUID, owner and region; `station/service/StationManager.java:252-269` recovers reservations and subsequently diagnoses unknown orbit bodies. | A station's Space dimension is not its orbit body's surface Level. Preserve station identity; binding startup failure must occur before this recovery callback. |
| `rocket/flight/persistence/RocketFlightNbtCodec.java:33-37,42-61,147-160` stores body, dimension and typed current/destination targets; `rocket/flight/RocketTransferRecord.java:265-275` binds snapshots to flight dimensions/origins and immutable content. | Preserve existing rocket/journal authority rather than retargeting it to a newly adopted mapping. Loaded rockets or retained journals are partial corroboration, not an inventory of all unloaded historical entities. |
| `travel/migration/LegacyFlightTargetMigrator.java:28-58,61-92` resolves legacy locations against actual dimension/current context and treats shared-Space station cases separately. | Running this resolver against a newly selected catalog does not establish that catalog's historical correctness. Prospective adoption must retain this limitation. |
| `celestial/service/CelestialCatalog.java:65-83,98-104` protects fixed Earth/Moon/Space identities and indexes Level candidates; `celestial/context/BodyContextResolver.java:38-61` gives instance context precedence and resolves only one Level candidate. | Freeze body assignment and reverse Level reservation independently; a per-body-only ledger would allow a new body ID to take an old body's Level. The selected runtime rejection of aliases is stricter than standalone ambiguity resolution and must remain disclosed. |
| `celestial/data/PlanetaryCatalogManager.java:10-16,37-49` owns only a volatile pair/generation; `PlanetaryDefinitionReloadListener.java:31-41,87-99` prepares resources then publishes that pair. | Validate the whole candidate and proposed append-only ledger delta before mutation. Commit durable authority before exposing a new accepted pair. Retain old pair, generation and route/cache owner on rejected reload. Preparation must not access world storage. |
| `AdvancedRocketryCommunity.java:108-110,137-143,172,236-240,289-308` registers reload/start/stop owners; `compat/environment/EnvironmentQueryLifecycle.java:21-27` exposes public server queries on ServerStarted. | Attach to one logical server before world-dependent startup consumers/public ready notification; clear both binding attachment and catalog lifecycle on stop, including failed-start cleanup. Do not introduce an unscoped static world map. |
| `persistence/migration/BetaWorldMigrationEvents.java:19-38` already works from the world root before managed SavedData loads; `ManagedSavedDataType.java:13-50` is a fixed historical allowlist. | The new independent schema/file should not be silently inserted into the Beta schema migration. Define ordering with the existing startup check and retain its failure behavior. |
| `rocket/transfer/RocketLandingPadSelector.java:52-63,328-329` still restricts surface admission to Earth/Moon. | A recorded mapping does not establish an actual registered/started Level, safe landing or permission to open it. MAP-02 must keep physical target and bounded landing checks. |

The draft addresses these through a schema-1 explicit JSON service, stable file identity, strict bounded input, prospective first adoption, immutable explicit unmapped entries, retained retired identities, reverse Level exclusivity and checked atomic replacement (`ADR-032:15-27,31-50,54-83`). No public API, old SavedData schema, display protocol or rocket migration change is necessary for this narrow feature.

## Platform checks and persistence implications

Inspected pinned Forge `1.20.1-47.4.10_mapped_official_1.20.1` JAR, SHA256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`. Full inspected bytecode output is retained beside this report.

- `DimensionDataStorage.readSavedData` catches load exceptions and returns null; `computeIfAbsent` then creates a replacement. Thus that convenience pattern cannot by itself distinguish an absent binding file from corrupt/unreadable authority.
- `SavedData.save(File)` catches IOException, logs, and then clears dirty; `DimensionDataStorage.save` has no success receipt. `setDirty` plus normal save is not an acknowledged binding commit.
- `DedicatedServer.initServer`: AboutToStart hook offset 467, `loadLevel` offset 491. `IntegratedServer`: offsets 38/47. `GameTestServer`: offsets 23/32. All three pinned paths support the proposed pre-Level attachment. This is bytecode inspection, not client or server runtime execution.
- Cached Forge source `ServerLifecycleHooks.java:91-98,113-117,130-135` posts AboutToStart before later Started/login admission and posts Stopped during cleanup. Existing environment-query startup exposure therefore need not occur before the new binding check.

The explicit checked service is a reasonable smaller alternative to extending generic SavedData durability. Complete all fallible candidate validation and generation calculation before the commit point; after successful replacement, publish the already prepared immutable state. Stage-force/readback plus atomic replacement supports the stated process-level ordering, not hardware power-loss durability of every world file. File-change checks protect ordinary detected edits; do not imply protection from adversarial concurrent external writers or rollback/deletion of all evidence. The complete-backup rollback restriction is appropriate.

## Policy tradeoffs and unresolved applicability

- **Selected prospective adoption:** practical first upgrade, but cannot establish pre-feature custom history. Keeping last working packs and a complete backup is essential. A safer-but-more-disruptive alternative is baseline-only automatic initialization followed by explicit operator adoption of custom entries; exhaustive old-world/entity scanning is not a bounded minimum implementation.
- **Explicit unmapped entries are permanent:** a metadata-only body cannot later acquire a surface under this contract; previously mapped bodies cannot shed the mapping. This is intentional identity stability, not merely a serialization default. Any later mapping migration needs separate authority and evidence.
- **Lifetime capacity is not active capacity:** 128 retained entries includes Earth/Moon/Space and retired entries. Repeated pack changes can exhaust it while fewer than 128 bodies are active. The 32,768-byte ceiling can bind earlier for long IDs. Reject instead of evicting; document recovery limits.
- **Reverse reservation rejects existing aliases:** appropriately explicit in ADR-032:24-27,44-45. It preserves standalone instance/ambiguous resolver behavior but makes such packs unacceptable as a runtime world catalog. No automatic choice or rename is safe.
- **No historical target certification:** station orbit identity, active journals, absent definitions and unloaded rocket entities remain separate authorities. Unknown/unavailable targets must not be deleted or rewritten. Actual newly opened Level validation belongs to MAP-02/MIG, not this ledger.

## Finite verification needed before implementation completion

1. Pure binding model: fixed baseline; same mapping; removal/re-add same or different; body rename onto retired Level; aliases; mapped/unmapped conversions; metadata-only change; 128 lifetime entries and byte-budget boundary; no partial delta on rejection.
2. Strict codec: exact keys/types/schema, null presence, duplicate body IDs/Levels, invalid/canonical IDs, malformed UTF-8/JSON/escapes, depth/bytes, future schema and empty/truncated input. Preserve rejected disk bytes.
3. Real Temp file I/O: true absence versus malformed/nonregular/symlink/unreadable file, stale stage, checked readback, atomic-move failure, changed/deleted authority including metadata-only reload, explicit retry, no overwrite/reset after failure. Inject failure deterministically where the OS cannot reliably reproduce it.
4. Pair/lifecycle tests: initial attachment failure prevents world-dependent readiness; bad reload retains generation, both catalogs and cache; successful delta commits before publication; stop/failed start releases ownership; a second logical server does not inherit the first world path or ledger.
5. One finite packaged same-world reload/restart: raw ledger receipts, removal/re-add, restart remap refusal, original failure capture, and unchanged old celestial/station/rocket authority where included. Do not substitute decoded summary for raw bytes. No full historical scan or long load campaign is required for this slice.

Suggested future executable scope: actual new binding test classes plus `PlanetaryReloadTest`, `BodyContextResolverTest`, relevant target/legacy migration and environment lifecycle tests with `--rerun-tasks --offline --no-daemon --no-build-cache`; root's standard `clean build runData runGameTestServer`; one bounded packaged restart harness. New test class names/commands must be finalized with implementation. None were run here.

## Checks actually performed and identities

- Read mandatory project/version/governance context and ADR-030/031; read the MAP-01 active leaf and full ADR-032 draft. Inspected the source files listed in `reviewed-identities.json`.
- Read-only `git rev-parse HEAD`, `git branch --show-current`, `git status --short`, `rg`/`Select-String` and numbered `Get-Content` inspections. Only root-owned work-log/draft edits were observed; the excluded user bundle was not opened.
- Used Java 17 `javap -classpath <pinned mapped Forge JAR> -c -p <class>` for DimensionDataStorage, SavedData, DedicatedServer, IntegratedServer and GameTestServer. This only inspected bytecode; no Gradle, Minecraft process or build output was started/changed.
- Used Python `-B` and `zipfile.ZipFile` to read selected cached Forge source entries (`ServerAboutToStartEvent`, `ServerStoppedEvent`, `ServerLifecycleHooks`). No network or dependency installation.
- Used PowerShell `Get-FileHash -Algorithm SHA256` for reviewed source/draft identities and pinned dependency. Only this fresh Temp directory contains reviewer writes.

The source/draft identity snapshot is retained in `reviewed-identities.json`; final accepted wording identity is separately recorded in `accepted-contract-identity.json`. Final read-only status also showed root-owned DOCUMENT-INDEX/work-log edits and new binding implementation files, which were not reviewed as production code. No implementation or runtime evidence for MAP-01 has been inferred from earlier DATA-01/02 results. Complete version acceptance, S2, V1/V2, performance and authentic old-world migration remain unverified/open.
