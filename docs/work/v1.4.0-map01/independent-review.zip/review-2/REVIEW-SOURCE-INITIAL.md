# V140-MAP-01 initial production source review

Baseline: `eee45f5010e1332c69c6eb18f127fc468cfea5df`.
Scope: four new `celestial/binding` classes, `PlanetaryCatalogManager`, central lifecycle registration, and reused strict reader, against accepted ADR-032. Root is still adding tests; this is not a final implementation verdict. Contract report is preserved separately and unchanged.

## Finding

### P2 — Indeterminate file existence is treated as first-adoption absence

`src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindingStore.java:47-50,99-104` uses `Files.exists(..., NOFOLLOW_LINKS)` to distinguish absent authority from an existing file. With this option, JDK 17's method calls `readAttributes` and catches **every IOException**, returning false; inspected bytecode is retained in `jdk17-Files-exists.txt`.

Consequently an existing file whose attributes cannot be read can be treated as uninitialized. `open` skips loading it; `verifyUnchanged` again sees false with `acceptedBytes == null`; if staging and target replacement remain permitted, `accept` can replace the old authority with the currently selected catalog. This violates ADR-032's requirement that only true absence permits initialization. The cause is not malformed JSON handling, which correctly fails closed after reading.

Minimal fix: stat using `Files.readAttributes(path, BasicFileAttributes.class, NOFOLLOW_LINKS)`, return absent only on `NoSuchFileException`, and propagate other failures. Reuse this distinction for later authority checks and preferably the pending/data-directory probes. The existing `isRegularFile`/directory predicates fail closed rather than adopting, but using checked attributes consistently provides clearer failure evidence. Add a deterministic indeterminate/unreadable-stat regression through a small internal I/O seam if native ACL behavior is unsuitable; do not loosen permission checks or modify user files to reproduce it.

This is a source/JDK-bytecode finding. No native permission failure or destructive replacement was executed.

## Other inspected behavior

- `PlanetaryBindings.java:20-40,48-65` enforces fixed identities, lifetime count, reverse-Level exclusivity, immutable mapped/unmapped identity and retained removed entries. Reconciliation constructs a candidate without mutating accepted state.
- `PlanetaryBindingsCodec.java:23-58,79-91` uses the existing bounded strict UTF-8/JSON reader, exact root/entry fields, lexical integer schema 1, canonical bounded IDs, and rejects explicit null Levels. Encoding also enforces the byte ceiling.
- `PlanetaryBindingStore.java:59-97` checks even no-write metadata reloads, stages with CREATE_NEW/NOFOLLOW, forces and validates readback, checks accepted bytes again, atomically replaces, and only then advances in-memory authority. Its normal caught-failure cleanup targets the stage it created. There is no post-commit fallible decode or validation.
- `PlanetaryCatalogManager.java:41-75` calculates generation before the checked commit, keeps the old pair/generation on declared binding rejection, and clears readiness on startup attachment failure. `clear` releases world attachment. The existing AboutToStart registration precedes ServerStarted services; earlier pinned lifecycle review established the hook precedes Level loading on dedicated, integrated and GameTest paths.
- The service does not touch previous SavedData, rocket journals, station registry, public exports, terrain or dimension registration. Prospective adoption remains explicitly weaker than historical migration certification.

No additional concrete source finding was identified in this initial scope. Filesystem races with adversarial concurrent writers, hardware power loss, entire-world transactional consistency and previously unrecorded custom history are not guarantees established by this implementation review.

## Actual checks and remaining verification

Read-only Git status/diff, numbered source reads, `rg --files` and `git diff --check` (exit 0). Inspected JDK 17 with `javap -c -p java.nio.file.Files`; source identities and the original store text are retained in this Temp folder. No repository/index edits, no Gradle, unit tests, GameTest, native server, client, remote work or excluded user-bundle access.

Tests were not complete at this checkpoint. Await root's frozen tests and exclusive Gradle slot before executable verification. Required future checks include model/codec edge cases, real Temp file roundtrip/failure tests, manager pair/cache retention, stop/rebind lifecycle, unchanged metadata disk-check behavior, and finite packaged restart/raw-ledger verification. This report does not approve any Gate.
