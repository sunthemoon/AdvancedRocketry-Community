import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(r'D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
files = {p for p in files if p and (p.startswith(('src/', 'scripts/', 'tests/', 'gradle/'))
          or p in ('build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat'))}
for directory in ('src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding',
                  'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding'):
    files.update(p.relative_to(ROOT).as_posix() for p in (ROOT / directory).rglob('*.java'))
result = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'inputs': {p: identity(ROOT / p) for p in sorted(files)},
          'artifacts': {p.name: identity(p) for p in sorted((ROOT / 'build/libs').glob('*.jar'))}}
(OUT / ('snapshot-' + sys.argv[1] + '.json')).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'inputs': len(files), 'artifacts': result['artifacts']}, indent=2))
