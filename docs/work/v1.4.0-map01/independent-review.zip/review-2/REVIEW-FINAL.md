# V140-MAP-01 independent implementation and evidence review

Baseline: `eee45f5010e1332c69c6eb18f127fc468cfea5df`, `codex/v1.4.0-planetary-expansion`.
Reviewer was read-only for repository/index; writes were limited to authorized Gradle outputs/cache and this Temp evidence directory. Root owns implementation and native executions. The prior contract report and initial source report remain unchanged.

## Findings, ordered by severity

### Resolved P2 — Indeterminate attributes cannot imply missing authority

The initial `Files.exists` finding is corrected in `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindingStore.java:39-41,109-145`: checked attributes now propagate I/O failures and only `NoSuchFileException` means absent. The initial source/JDK bytecode evidence remains in `REVIEW-SOURCE-INITIAL.md`, `PlanetaryBindingStore-initial.java.txt` and `jdk17-Files-exists.txt`.

The independently executed regression at `src/test/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindingsTest.java:196-212` injects `AccessDeniedException` at initial open and on a metadata-only reload, asserts no commit and preserves existing bytes. Model/codec/store/manager tests also passed.

### Open P3 — Reverse-Level diagnostic can name the rejected alias as the historical owner

`src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/PlanetaryBindings.java:26-34` sorts the union of retained and proposed entries, then describes the first encountered body as the Level's reserved owner. If a new alias sorts before the retained owner, the rejection message names that rejected alias. Actual native `create-reload/stdout.txt:145` says:

`Level advancedrocketrycommunity:binding_probe is reserved by advancedrocketrycommunity:binding_alias`

The retained native ledger instead correctly reserves it for `binding_probe`. Rejection, pair retention and persisted ownership all remain correct; this is an operator-diagnostic wording issue. Minimal later correction: report the two conflicting IDs without asserting historical precedence, or preflight against retained owners before rebuilding. Root explicitly chose to record this scoped P3 for remaining v1.4 work without modifying already-tested production bytes.

No additional concrete production correctness finding was identified within the reviewed slice. This is not a defect-free or Gate-approval statement.

## Source and test scope

Reviewed all four new binding production classes, manager/lifecycle registration changes, accepted ADR-032, the 17-test binding suite, affected existing pure tests, and the actual `--check-bindings` Python delta. The corrected implementation retains immutable mapped/unmapped and retired entries, enforces reverse-Level reservation and finite lifetime/byte limits, checks metadata-only reloads, validates and forces the staged file, atomically replaces it before advancing authority/publication, and aborts startup before Level loading on a binding conflict. It does not rewrite legacy celestial/station/rocket records or open additional flight destinations.

`PlanetaryBindingsTest.java:124-194` covers real file roundtrip, metadata no-rewrite, changed/deleted disk, malformed/future/nonregular/pending files, atomic-move failure and explicit retry. `:214-268` covers actual symlink refusal, pair/generation/cache retention and logical-world detach/rebind. Native ACLs/hardware fault cuts and every possible I/O/cleanup failure were not exhaustively tested; the attribute failure is deterministic injection.

## Independently executed commands and results

Java environment: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`.

```text
.\gradlew.bat test --tests *PlanetaryBindingsTest --tests *PlanetaryReloadTest --tests *BoundedDefinitionJsonTest --tests *BodyContextResolverTest --tests *LegacyFlightTargetMigratorTest --tests *RocketTargetFlightPlannerTest --tests *ServerEnvironmentQueriesTest --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

- Exit **0**, wall time **53.210216 s**; Gradle reports 52 s and **16/16 tasks executed**, not cached test XML.
- **66 tests / 7 suites**, zero failures/errors/skips: binding 17, context 8, raw JSON 8, paired reload 15, environment queries 10, target planner 3, legacy target migration 5.
- Raw command, output, receipt and copied XML: `gradle-command.txt`, `gradle-focused.log`, `gradle-result.json`, `focused-junit/`, `execution-checks.json`.
- Gradle fully exited; root was notified that its exclusive slot was released. No independent GameTest or native server was launched.

```text
PYTHONUTF8=1
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v140_celestial_schema_smoke -v
```

- Exit **0**, **10 tests**, unittest time **0.176 s**. Raw output/receipt retained as `python-focused.log` and `python-result.json`.
- Read-only `git diff --check` exit 0; generated-resource diff was empty.
- Snapshot helper hashed **1,248 source/build inputs**, including explicitly new binding files, before/after. No input changed; all three JARs stayed byte-identical. Documentation/index changes by root were outside that source-input snapshot.

Root's archived full XML independently counted **832 tests / 149 suites**, zero failures/errors/skips. Its full log contains an executed `:test`, **213 required GameTests passed**, DataGen `written: 0`, and `BUILD SUCCESSFUL in 2m 57s` (27 tasks: 18 executed, 8 cached, 1 up-to-date). These are inspected root receipts, not a second independent full-suite execution.

## Artifact identity

The frozen root copies, build/libs after the focused run, and native installed host JAR matched. Launch receipts bind both clean cycles and the rejected-startup probe to the same host bytes.

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| main | 2,412,477 | `9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf` |
| API | 48,469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| sources | 1,096,875 | `8907ccb088ef359392243209bced6e04ab7f67ea95728acb676443396f995520` |

The API JAR has **27 API class entries**, all byte-identical to corresponding main-JAR classes, contains no binding implementation, and the whole API JAR hash matches `docs/releases/v1.3.0/development-artifacts.json`. Main contains the seven expected binding/nested class entries. This does not imply a newly executed independent consumer build.

Runner SHA256: `46b3cfb059d6a7eba645e545d3bfcb1384ae3dcda4a416469b97fb673ba4328b`.
Python test SHA256: `dadf320aa5a94a4827700ad27ff47f0355d9617ae783a20d92224c98b065f388`.

## Independent native readback

Root evidence base: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-map01-1790499004940`.
Readback helper `audit_native.py` reads raw files, independently parses bounded station NBT and strict ledger JSON, checks manifests/artifacts and all three native log variants; it does not accept summary PASS as its oracle. Final helper exit **0**, output `native-audit.txt` and `native-audit.json`.

### Two clean processes: `native-evidence/`

- **33/33 manifest files** match hashes and inventory; recorded native exits are both 0, with actual ready/stop/all-dimensions-saved receipts. Binding-ready occurs before `Preparing level` in each log.
- Initial raw ledger contains exactly fixed Earth/Moon/Space entries. After additions, exactly five entries include the mapped probe and an explicitly unmapped gas body. Ledger bytes stay identical across removal, rejection of remap, rejection of reverse reuse, re-add, stop, restart-start and restart-stop. Stable SHA256: `b9fe03977bf8eaa29095bdabd64cfffd748a5f89ad0e34f817a04bc66b84970f`.
- Raw logs show accepted generations/body counts `(1,3),(2,4),(3,5),(4,4),(5,5),(6,5)`, both rejected candidates retain generation 5 and route distance 123; restart begins generation 1 with five bodies. Raw rejected candidate inputs and ledger receipts were inspected.
- Three native station files are byte-identical and independently decode identically in full, including DataVersion 3465, schema 2, no reservations, one station UUID `5f902884-429e-4bb9-a845-2f6e7f98e42a`, Moon orbit, region `[-256,-256,255,255]`, landing pad `[0,128,0]`, owner and environment. UUID agrees with actual creation and inspect commands.
- First process retains exactly **2 intentional project ERRORs**, no FATAL, **26 WARNs**, including **4,769 ms / 95 ticks behind**. Restart has **0 ERROR/FATAL and 10 WARNs**. No client-linkage failure was found. This is not performance acceptance.
- Actual fixed-Level command probes succeed and the unmapped gas Level is rejected. Raw level.dat hashes and same-world marker match the clean-cycle receipts; **whole level.dat was not decoded**.

### Separate intentional failed startup: `rejected-startup/`

- **11/11 manifest files** match. Inspected temporary helper source and exact input: only `binding_probe.level` changes to `binding_changed_at_restart`; original definition is restored afterward.
- Each log variant contains the exact binding conflict and no Level-preparation/READY receipt. Before/after ledger and station bytes match each other and the prior clean-cycle captures. This supplies native offline-remap refusal in addition to pure store reopen tests.
- Native JVM exit is **0 despite startup refusal**. The result is **OBSERVED_REJECTION**, not a third clean cycle. Preserve **4 ERRORs + 1 FATAL**, including Minecraft's pre-Level shutdown `NullPointerException` (`serverlevel2` null). Original crash report identity is recorded separately in `native-audit.json`; it was not inserted into the existing native manifest by this reviewer.
- The probe proves ledger/station conservation and pre-Level gameplay refusal, **not absence of all vanilla startup writes**. Live level.dat after the refusal differs from archived clean restart: clean SHA256 `7f814eb940e46164fd9cddc768b2739162a6773e816be6f74cc8bb0c20cb793c`; post-refusal `623a3703708d59c7f481d9b2dcff92e01613a41adf9ca6400a6d95c92fcae74b`. No whole-world byte-immutability claim or decoded explanation was inferred.

## Retained reviewer attempt and verification limits

The first supplemental audit incorrectly asserted that live level.dat must also remain byte-identical after the separate refusal. It failed at that assertion; `audit_native-first.py` and `native-audit-first.txt` are preserved unchanged. The corrected helper records both raw identities and keeps the actual ledger/station conservation assertions intact. No repository test, runtime assertion or original evidence was altered for this correction. An initial read command also looked for nonexistent per-phase `result.json`; this harness correctly stores results in `observations.json`, which was then inspected.

No new worlds/terrain or arbitrary surface flight were exercised. The clean native restart has all five identities active; retired-only cross-restart availability is not a separate native scenario. Prospective adoption cannot reconstruct pre-feature custom history. Hardware power loss, arbitrary concurrent external file writers, all failure cut points, full-world transactionality, authentic legacy-world migration, long load, clients/V1/V2 and complete acceptance remain outside this slice. No version Gate approval is given.
