import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import zipfile

OUT = Path(__file__).parent
ROOT = Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-map01-1790499004940')
EVIDENCE = ROOT / 'native-evidence'
PROBE = ROOT / 'rejected-startup'
HOST = 'advancedrocketrycommunity'
report = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def unique(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result

def json_read(path):
    return json.loads(path.read_bytes(), object_pairs_hook=unique)

def manifest(root):
    receipts = {}
    for line in (root / 'SHA256SUMS').read_text('ascii').splitlines():
        expected, relative = line.split('  ', 1)
        path = root / relative
        assert path.resolve().is_relative_to(root.resolve()) and relative not in receipts
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert digest(raw) == expected, relative
        receipts[relative] = {'sha256': expected, 'bytes': len(raw)}
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    assert actual == set(receipts), (actual-set(receipts), set(receipts)-actual)
    return receipts

class Nbt:
    def __init__(self, raw):
        self.stream = io.BytesIO(raw)
        self.nodes = 0
    def read(self, size):
        assert 0 <= size <= 4*1024*1024
        value = self.stream.read(size)
        assert len(value) == size
        return value
    def number(self, fmt):
        return struct.unpack('>' + fmt, self.read(struct.calcsize('>' + fmt)))[0]
    def string(self):
        return self.read(self.number('H')).decode('utf-8')
    def payload(self, kind, depth):
        self.nodes += 1
        assert self.nodes <= 4096 and depth <= 16
        if kind in (1, 2, 3, 4, 5, 6):
            return self.number({1:'b',2:'h',3:'i',4:'q',5:'f',6:'d'}[kind])
        if kind == 8:
            return self.string()
        if kind == 9:
            element, size = self.number('B'), self.number('i')
            assert 0 <= size <= 4096
            return [self.payload(element, depth+1) for _ in range(size)]
        if kind == 10:
            result = {}
            while True:
                element = self.number('B')
                if element == 0: return result
                key = self.string()
                assert key not in result
                result[key] = self.payload(element, depth+1)
        if kind in (7, 11, 12):
            size = self.number('i')
            assert 0 <= size <= 4096
            return [self.number({7:'b',11:'i',12:'q'}[kind]) for _ in range(size)]
        raise AssertionError(('unsupported NBT tag', kind))
    def root(self):
        assert self.number('B') == 10
        self.string()
        result = self.payload(10, 0)
        assert not self.stream.read(1)
        return result

def nbt_read(path):
    raw = path.read_bytes()
    assert len(raw) <= 4*1024*1024
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
        unpacked = stream.read(4*1024*1024+1)
    assert len(unpacked) <= 4*1024*1024
    return Nbt(unpacked).root()

def bindings(path, count):
    raw = path.read_bytes()
    assert len(raw) <= 32768
    value = json_read(path)
    assert set(value) == {'schema_version', 'bindings'} and type(value['schema_version']) is int
    assert value['schema_version'] == 1 and type(value['bindings']) is list and len(value['bindings']) == count
    records = {}
    for entry in value['bindings']:
        assert set(entry) in ({'body_id'}, {'body_id', 'level'})
        assert all(type(v) is str and len(v) <= 128 and re.fullmatch(r'[a-z0-9_.-]+:[a-z0-9/._-]+', v) for v in entry.values())
        assert entry['body_id'] not in records
        records[entry['body_id']] = entry.get('level')
    levels = [v for v in records.values() if v is not None]
    assert len(set(levels)) == len(levels)
    for name, level in [('earth', 'minecraft:overworld'), ('moon', HOST+':moon'), ('space', HOST+':space')]:
        assert records[HOST+':'+name] == level
    if count == 5:
        assert records[HOST+':schema_probe_gas'] is None
        assert records[HOST+':binding_probe'] == HOST+':binding_probe'
    return raw, records

report['native_manifest'] = manifest(EVIDENCE)
report['rejected_manifest'] = manifest(PROBE)
initial, _ = bindings(EVIDENCE / 'create-reload/bindings-at-start.json', 3)
first, records = bindings(EVIDENCE / 'create-reload/bindings-added.json', 5)
for relative in ('create-reload/bindings-removed.json', 'create-reload/bindings-readded.json',
                 'create-reload/remap-bindings.json', 'create-reload/reuse-bindings.json',
                 'create-reload/bindings-at-stop.json', 'restart/bindings-at-start.json', 'restart/bindings-at-stop.json'):
    assert bindings(EVIDENCE / relative, 5)[0] == first, relative
report['bindings'] = {'initial_sha256': digest(initial), 'stable_sha256': digest(first), 'records': records}

station_paths = [EVIDENCE / relative for relative in ('create-reload/before-reload-stations.dat',
                  'create-reload/stations.dat', 'restart/stations.dat')]
station = nbt_read(station_paths[0])
for path in station_paths:
    assert nbt_read(path) == station and path.read_bytes() == station_paths[0].read_bytes()
assert station['data']['schema_version'] == 2 and station['data']['reservations'] == []
assert len(station['data']['stations']) == 1 and station['data']['stations'][0]['orbit_body'] == HOST+':moon'
report['station'] = station
report['station_sha256'] = digest(station_paths[0].read_bytes())

logs = {}
for phase in ('create-reload', 'restart'):
    logs[phase] = {}
    for filename in ('stdout.txt', 'latest.log', 'debug.log'):
        text = (EVIDENCE / phase / filename).read_text('utf-8')
        errors = [line for line in text.splitlines() if re.search(r'\[[^\]\n]+/(?:ERROR|FATAL)\]', line)]
        expected_details = [] if phase == 'restart' else [
            'Planetary binding rejection: Body '+HOST+':binding_probe cannot change its recorded Level binding',
            'Planetary binding rejection: Level '+HOST+':binding_probe is reserved by '+HOST+':binding_alias']
        assert len(errors) == len(expected_details), (phase, filename, errors)
        assert all(detail in line for line, detail in zip(errors, expected_details))
        assert 'Planetary bindings ready: ' + ('3' if phase == 'create-reload' else '5') + ' recorded bodies' in text
        assert text.index('Planetary bindings ready:') < text.index('Preparing level "world"')
        assert 'Stopping server' in text and 'All dimensions are saved' in text
        assert not re.search(r'NoClassDefFoundError|ClassNotFoundException|InvalidDistException', text)
        logs[phase][filename] = {'errors': errors, 'warnings': len(re.findall(r'\[[^\]\n]+/WARN\]', text)),
                                'lag': [line for line in text.splitlines() if "Can't keep up!" in line]}
    obs = json_read(EVIDENCE / phase / 'observations.json')
    assert obs['exit_code'] == 0 and obs['result'] == 'PASS'
    commands = json_read(EVIDENCE / phase / 'commands.json')
    assert commands[-1] == 'stop'
    for level in ('minecraft:overworld', HOST+':moon', HOST+':space', HOST+':schema_probe_gas'):
        assert 'execute in '+level+' run time query gametime' in commands
    text = (EVIDENCE / phase / 'stdout.txt').read_text('utf-8')
    assert "Unknown dimension '"+HOST+":schema_probe_gas'" in text
    assert 'Planetary route generation='+('6' if phase == 'create-reload' else '1') in text
    assert 'distance=123 bidirectional=true' in text
    if phase == 'create-reload':
        assert re.findall(r'Accepted planetary catalog generation (\d+) with (\d+) bodies', text) == [('1','3'),('2','4'),('3','5'),('4','4'),('5','5'),('6','5')]
        assert text.count('generation 5 retained after rejected reload') == 2
    else:
        assert re.findall(r'Accepted planetary catalog generation (\d+) with (\d+) bodies', text) == [('1','5')]
report['logs'] = logs

for name, expected in [('bindings', first), ('stations', station_paths[0].read_bytes())]:
    assert (PROBE / (name+'-before.bin')).read_bytes() == expected
    assert (PROBE / (name+'-after.bin')).read_bytes() == expected
assert nbt_read(PROBE/'stations-after.bin') == station
original, changed = json_read(PROBE/'original-body.json'), json_read(PROBE/'input-body.json')
assert original['level'] == HOST+':binding_probe'
assert changed == dict(original, level=HOST+':binding_changed_at_restart')
probe_logs = {}
for filename in ('stdout.txt','latest.log','debug.log'):
    text = (PROBE/filename).read_text('utf-8')
    assert 'Body '+HOST+':binding_probe cannot change its recorded Level binding' in text
    assert 'Planetary bindings blocked startup' in text
    assert 'Preparing level ' not in text and not re.search(r'Done \([0-9.]+s\)!', text)
    assert 'NullPointerException' in text and 'serverlevel2' in text
    errors = [line for line in text.splitlines() if re.search(r'\[[^\]\n]+/ERROR\]',line)]
    fatals = [line for line in text.splitlines() if re.search(r'\[[^\]\n]+/FATAL\]',line)]
    assert len(errors) == 4 and len(fatals) == 1
    probe_logs[filename] = {'errors':errors, 'fatals':fatals}
report['rejected_startup'] = {'observations':json_read(PROBE/'observations.json'), 'logs':probe_logs,
                              'meaning':'Observed refusal before Level preparation; native exit 0 is not clean startup'}

summary = json_read(EVIDENCE/'summary.json')
server_root = Path(summary['server'])
marker = server_root/'world/.v002-smoke-world-identity.json'
assert digest(marker.read_bytes()) == summary['world']['identity_marker_sha256']
for phase, key in [('create-reload','level_dat_before_restart_sha256'),('restart','level_dat_after_restart_sha256')]:
    assert digest((EVIDENCE/phase/'level.dat').read_bytes()) == summary['world'][key]
assert digest((server_root/'world/level.dat').read_bytes()) == summary['world']['level_dat_after_restart_sha256']
assert (server_root/'world/datapacks/schema_probe/data'/HOST/'celestial_bodies/binding_probe.json').read_bytes() == (PROBE/'original-body.json').read_bytes()
report['world_identity'] = {'marker':json_read(marker), 'level_dat_decoded':False, 'live_dimension_receipts_checked':True}

artifacts = {}
for path in sorted((ROOT/'artifacts').glob('*.jar')):
    artifacts[path.name] = {'sha256':digest(path.read_bytes()), 'bytes':path.stat().st_size}
    assert path.read_bytes() == (Path(r'D:/GitHub/AdvancedRocketry-Community/build/libs')/path.name).read_bytes()
main = ROOT/'artifacts'/summary['artifact']['name']
assert digest(main.read_bytes()) == summary['artifact']['sha256']
assert (server_root/'mods'/main.name).read_bytes() == main.read_bytes()
for launch in (EVIDENCE/'create-reload/launch.json',EVIDENCE/'restart/launch.json',PROBE/'launch.json'):
    receipt=json_read(launch)
    assert receipt['artifact']['sha256']==digest(main.read_bytes())
api = next((ROOT/'artifacts').glob('*-api.jar'))
with zipfile.ZipFile(api) as a, zipfile.ZipFile(main) as m:
    classes = [name for name in a.namelist() if name.endswith('.class')]
    assert len(classes)==27 and all('/api/' in name for name in classes)
    assert all(a.read(name)==m.read(name) for name in classes)
    assert not any('celestial/binding/' in name for name in a.namelist())
    assert len([name for name in m.namelist() if name.startswith('io/github/sunthemoon/advancedrocketrycommunity/celestial/binding/') and name.endswith('.class')]) == 7
report['artifacts'] = artifacts
report['api_class_count'] = len(classes)
report['main_binding_classes'] = 7

crash = server_root/'crash-reports/crash-2026-09-27_17.07.21-server.txt'
report['crash_report'] = {'path':str(crash),'sha256':digest(crash.read_bytes()),'bytes':crash.stat().st_size}
assert 'Planetary bindings blocked startup' in crash.read_text('utf-8')
report['result'] = 'CHECKS_PASSED_WITH_RECORDED_WARNING_AND_REFUSAL_ERRORS'
(OUT/'native-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'native_manifest':len(report['native_manifest']),'rejected_manifest':len(report['rejected_manifest']),
                  'api_classes':len(classes),'records':records,'result':report['result']},indent=2))
