"""Finite same-world startup conflict probe after the two successful binding cycles."""
from pathlib import Path
import json
import re
import shutil
import sys

sys.path.insert(0, 'D:/GitHub/AdvancedRocketry-Community')
from scripts import run_v140_celestial_schema_smoke as fixture

root, artifact, output, java = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
root = fixture.support.safe_path(root)
output = fixture.support.safe_path(output)
fixture.require(not output.exists(), 'Evidence must be fresh')
fixture.require((root / 'world/.v002-smoke-world-identity.json').is_file(), 'Existing smoke world is required')
body_path = root / fixture.PACK / 'celestial_bodies/binding_probe.json'
original = fixture.support.regular(body_path, 32768)
fixture.require(json.loads(original)['level'] == fixture.BINDING_BODY, 'Probe must begin at its recorded mapping')
output.mkdir(parents=True)
identity = fixture.support.artifact(artifact, fixture.HOST, '1.20.1-1.4.0-dev')
fixture.require(fixture.server.digest_file(root / 'mods' / artifact.name) == identity['sha256'], 'Installed artifact differs')
command = fixture.support.rocket_smoke._server_command(java)
command.remove('-Dadvancedrocketrycommunity.releaseTestHooks=true')
fixture.write_json(output / 'launch.json', {'command': command, 'cwd': str(root), 'artifact': identity})
baseline = {}
for name, relative in [('bindings', fixture.BINDINGS), ('stations', fixture.STATIONS)]:
    baseline[name] = fixture.support.regular(root / relative, 4 * 1024**2)
    (output / (name + '-before.bin')).write_bytes(baseline[name])
changed = json.loads(original)
changed['level'] = fixture.HOST + ':binding_changed_at_restart'
fixture.write_json(body_path, changed)
(output / 'input-body.json').write_bytes(body_path.read_bytes())
(output / 'original-body.json').write_bytes(original)
process = None
observations = {'result': 'IN_PROGRESS', 'scope': 'Expected pre-Level startup refusal, not a clean server cycle'}
try:
    process = fixture.server.CapturedProcess(command, root, output / 'stdout.txt')
    process.wait_for(re.compile('Planetary bindings blocked startup'), 240)
    code = process.finish()
    joined = ''.join(process.lines)
    fixture.require('Body ' + fixture.BINDING_BODY + ' cannot change its recorded Level binding' in joined,
                    'The recorded body conflict was not reported')
    fixture.require(not any(fixture.server.READY_MARKER.search(line) for line in process.lines), 'Rejected server reached ready')
    fixture.require(not any('Preparing level ' in line for line in process.lines), 'World loading began despite rejected binding')
    for name, relative in [('bindings', fixture.BINDINGS), ('stations', fixture.STATIONS)]:
        after = fixture.support.regular(root / relative, 4 * 1024**2)
        (output / (name + '-after.bin')).write_bytes(after)
        fixture.require(after == baseline[name], name + ' changed during rejected startup')
    observations.update(result='OBSERVED_REJECTION', exit_code=code,
                        log_findings=fixture.server.scan_log(process.lines),
                        log_counts=fixture.server.log_audit_counts(process.lines))
    print(json.dumps(observations, indent=2))
except BaseException as error:
    observations.update(result='FAIL', error=str(error))
    if process is not None:
        process.abort()
    raise
finally:
    body_path.write_bytes(original)
    observations['body_restored_sha256'] = fixture.server.digest_file(body_path)
    observations['exit_code'] = process.process.poll() if process is not None else None
    fixture.write_json(output / 'observations.json', observations)
    for name in ('latest.log', 'debug.log'):
        source = root / 'logs' / name
        if source.is_file():
            shutil.copyfile(source, output / name)
    paths = sorted(path for path in output.rglob('*') if path.is_file())
    (output / 'SHA256SUMS').write_text(''.join(f'{fixture.server.digest_file(path)}  {path.relative_to(output).as_posix()}\n'
                                           for path in paths), encoding='ascii', newline='\n')
