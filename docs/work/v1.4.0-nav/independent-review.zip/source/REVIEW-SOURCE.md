# V140-NAV independent implementation source review

## Findings

### P2: Container click dispatch made map node selection and drag initiation unreachable — corrected during review

Initial `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/client/RocketFlightScreen.java:372–375` returned `super.mouseClicked(...) || mapMode && starMap.click(...)`. The pinned Forge 47.4.10 mapped `AbstractContainerScreen.mouseClicked` returns true even for blank non-slot container space: its terminal bytecode is `584: iconst_1; 585: ireturn`. Thus the second operand never ran. `RocketStarMap.java:148–154` is where node selection and `dragging = true` occur, so both direct mouse selection and drag-to-pan were unavailable. Previous/next buttons and wheel zoom did not compensate for the promised mouse behavior. This was independently established from actual source and pinned bytecode, not inferred from a desired test outcome.

Initial screen SHA256: `bee5173408ba066bc89622299e6641afcfdc024ff2201d4b26c258f5c172d153`.

The revised screen dispatches through `StarMapInput.click`, which offers the bounded viewport first and then falls back to the container for toolbar/other clicks. `StarMapLayoutTest.viewportReceivesClicksBeforeTheAlwaysConsumingContainerAndToolbarStillWorks` checks consumed map clicks, toolbar fallback and closed-map behavior with an always-consuming container supplier. Source inspection confirms this addresses the finding. The test has **not** been executed by this reviewer, and actual client input/visual behavior remains unverified.

Revised screen SHA256: `186cb1b8c16216d5d5c0c9786c713479ea9182f8fc49096ad900e03e5d278b97`.
New `StarMapInput.java` SHA256: `1de61f774d832d1328499a7a2a345e3cfb3a3a8682b374540e32e52205409d3a`.

No additional concrete correctness/security defect was identified in this bounded source pass. This does not imply that the changing implementation, its tests, native behavior or Required Gates have passed.

## Scope and inspected revision

- Repository: `D:/GitHub/AdvancedRocketry-Community`; branch `codex/v1.4.0-planetary-expansion`; observed HEAD/base `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`.
- Actual uncommitted runtime/client/wire changes and explicitly new files were inspected against accepted ADR-035. Required repository/version/governance rules were read in the immediately preceding NAV contract review and applied here; AGENTS and relevant quality constraints were rechecked.
- `tracked-source.diff`, `reviewed-source/` and `source-identities.json` capture 29 changed/new main/test Java files at this review checkpoint. `initial-source/` retains the earlier four files involved in the first pass, including the failing dispatch version. These are observed working-tree snapshots, not a frozen commit claim or atomic snapshot of root's ongoing work.
- `ADR-035.md` retains the accepted contract inspected. No public API export or persistent schema change was introduced by the inspected diff; protocol 7 is an intentional exact-match compatibility change, with celestial display protocol/schema 2 retained.
- Root remained sole tracked writer. No repository/index/generated/build edits, tests, Gradle or Minecraft launches were performed by this reviewer. No excluded user documentation bundle was read. Only Temp evidence was written.

## Source observations

All paths below are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` in the repository above.

- **Server authority remains separate from display.** `rocket/server/RocketFlightService.java:108–134` requires server-thread execution, calls existing live loaded same-Level/range access checks and verifies exact entity identity before supplying navigation/catalog data. Full catalog recovery additionally requires the actual open menu. `RocketNavigationService.java:43–84` captures one `PlanetaryCatalogManager.Generation`, filters station VISIT visibility and orbitability, checks rocket/source-station authorization, and invokes the existing launch planner/admission for each bounded target. Quote readiness never mutates fuel, reserves a pad or loads terrain. Existing launch-time authorization/planning was not replaced by display status.
- **Bounded refresh and lifecycle.** `rocket/menu/RocketFlightMenu.java:149–175,223–237` caches navigation for 20 ticks unless the immutable flight object changes, sends changed snapshots, accepts only refresh button 0 from the live viewer/menu on the server thread, and attempts pending catalog recovery separately from changed-only transmission. `RocketCatalogSync.java:9–20` preserves pending attempts across cooldown refusal. `RocketCatalogRefreshLimiter.java:14–30` enforces the 100-tick service-owned per-player budget, caps storage at the existing 128-player limit, prunes expired entries and exposes remove/clear. `RocketFlightService.java:489–508` clears/removes navigation state on service stop/logout. No menu-local reset bypass of the full-catalog limiter was observed.
- **Wire bounds.** `rocket/network/RocketFlightPlanPacket.java:21–25,63–116` bounds the frame before allocation, validates optional-plan flag, canonical quote/station counts, typed targets, fuel/status values, station identity/name/orbit fields, duplicate records via DTO constructors, and trailing data. The constructor's bound is 31,419 bytes. The separate full catalog remains bounded by its existing 96 KiB codec. `RocketNavigationStatus.java:7–42` implements the explicit 0–11 IDs and authorization/state/planner precedence.
- **Client coherence and targeting.** `CelestialClientCache.java:14–19` now rejects lower generations before changing last-good data/status; equal/newer data still uses existing decode/last-good behavior. `client/RocketFlightPlanHandler.java:12–17` retains open container/entity targeting. `RocketFlightMenu.java:191–196` refuses older navigation generations. `client/starmap/RocketStarMap.java:201–204` requires positive matching generations and an ACCEPTED catalog result. The console's launch send path also checks coherence, while CANCEL still uses the synchronized active plan.
- **Selection and layout.** `RocketFlightSelection.java:61–80` retains station selection by UUID across refresh/reorder and clears an unavailable editable selection, without rewriting the active plan. The screen refreshes selection from menu station summaries before updating widgets. `StarMapLayout.java:16–55` has a 128-node bound, deterministic sorted tree layout, missing-parent/duplicate/cycle rejection and bounded recursion. `StarMapViewport.java:12–41` bounds pan/zoom and ignores nonfinite motion. The renderer rebuilds layout when its snapshot reference changes, not every frame; geometric drawing is scissored and click/scroll dispatch checks the viewport. Per-frame traversal is finite, including parent lookup; this is not measured performance evidence.
- **Compatibility and reader-visible scope.** Station persistence, typed target IDs and rocket transaction code are unchanged. The new translated status/environment text is additive to the v1.4 provider. No art import, discovery authority, generic orbit arrival, terrain or environmental-rule change was found in this diff. Full real-client acceptance remains deferred under ADR-018, not claimed by the presence of UI helpers.

## Tests inspected and remaining checks

Inspected new/changed tests cover explicit status mapping, READY invariants, generation coherence, station bounds, maximum Unicode-name/ID/count encoding, late catalog rejection/reset, selected station reorder/removal, active-plan cancellation, 100/128-node deterministic layout, viewport bounds, corrected input dispatch, limiter saturation/lifecycle and quiet eventual recovery after cooldown refusal. Existing flight packet truncation/targeting tests and schema/protocol assertions were also inspected.

Tests were still being added by root. At the captured checkpoint, no new navigation GameTest file was in the 29-file snapshot. This is an incomplete verification boundary, not a claim that planned tests were omitted from a finished submission. Required later review/rerun coverage includes:

1. Actual server menu/control/source/destination permissions, permission changes while open, successful and rejected reload, same-generation station changes, live entity removal/unload and invalid menu viewers.
2. Actual catalog/plan send counts, quiet retry after refusal, reopen and shutdown cleanup, malformed extended station/status/count/flag frames, and unchanged resource totals/no forced chunk loads.
3. Real client menu opening and late entity synchronization, mouse node selection/drag/scroll, toolbar and keyboard focus, resize/GUI scales/locales, hover text, selection after asynchronous station updates, and cancellation while coherence is pending.
4. Source/artifact identity, generated resources, dedicated sidedness and packaged restart regression after the final implementation is frozen. No build artifacts were inspected while root owned the build slot.

Suggested later focused tests: `*RocketNavigationTest`, `*RocketFlightPlanPacketTest`, `*RocketFlightSelectionTest`, `*RocketCatalogRefreshLimiterTest`, `*StarMapLayoutTest`, `*CelestialSnapshot*Test`, related actual navigation/flight GameTests, and the unchanged API artifact/version boundary checks. Execution must wait for root's exclusive slot grant.

## Commands actually run

- Read-only Git: `git status --short`, `git rev-parse HEAD`, `git diff --stat bd8b9a8`, `git diff --name-only bd8b9a8`, scoped `git diff bd8b9a8 -- ...`, `git ls-files --others --exclude-standard -- src/main/java src/test/java`, and `git diff --check` (exit 0).
- PowerShell `Get-Content` with numbered ranges and scoped `rg`/`rg --files` for production/tests/limits/lifecycle. Missing guessed map-panel filename was guarded with Test-Path; actual files were then enumerated and read.
- Pinned bytecode inspection (exit 0):

```text
"C:/Program Files/Java/jdk-17.0.7/bin/javap.exe" -c -p -classpath "C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar" net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
```

Full output is retained as `AbstractContainerScreen.javap.txt`; no platform implementation was copied into the repository. The initial displayed filtered output was truncated, but the full file and the terminal return range were inspected separately.

- Temp-only `New-Item`, `Copy-Item`, report/diff/JSON writes and `Get-FileHash` capture/manifest generation.

No executable unit/GameTest/client/server/network test was run. No remote/browser/SSH/OpenPet action or subdelegation occurred. This source-stage report grants neither implementation completion nor Gate/release approval.
