# V140-NAV inherited sunlight fixture: incremental read-only review

## Findings

No new concrete defect found in the scoped synchronization correction. The original fixed-delay assumption was not a lighting-completion barrier; the revised fixture checks the same required outcome within its original timeout. This is source/platform inspection, not an independently executed GameTest result or Gate approval.

## Inspected change and evidence

- Baseline HEAD: `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`.
- `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/PlanetaryExposureGameTests.java:176-199`: unchanged 40-tick annotation, original daytime/open-column assertion and placement, initialization cleanup; fixed two-tick delay replaced by a per-tick observation.
- Same file `:202-228`: at most one scheduled successor per callback; retries only while sky remains visible and test tick is below 30. On completion or at tick 30, the assertion requires the actual STONE roof, `!canSeeSky`, and `!directSunlight`. Failure still fails the test; no condition is ignored. `pending` suppresses cleanup only after successfully scheduling the successor. The final path and assertion/ordinary callback exceptions execute cleanup. Night and unloaded-far-column assertions remain.
- `celestial/environment/PlayerEnvironmentalService.java:63-66`: the production query uses skylight dimension, daytime, loaded chunk and `canSeeSky`; no production diff exists in that directory for this correction.
- Pinned Forge 1.20.1-47.4.10 mapped jar, SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`: `BlockAndTintGetter.canSeeSky` compares actual SKY brightness with maximum light. `ThreadedLevelLightEngine.checkBlock` queues PRE_UPDATE work through the sorter mailbox; `runUpdate` executes PRE_UPDATE, superclass lighting, then POST_UPDATE. Its public `runLightUpdates` throws because the lighting runs on a different thread. Inherited `LevelLightEngine.hasLightWork` reads the two underlying engines, not all pending sorter/mailbox work. A fixed two ticks, or merely observing that inherited boolean as false, therefore does not establish that this roof update has published.
- The new condition is an eventual-result observation, **not** a claim that every queued lighting operation has completed. It does not invoke forced relighting, enlarge the test timeout or change the gameplay query.
- Independently read the retained root failure log: 232 GameTests completed, one required failure with the exact opaque-roof message, Gradle failed. Log SHA-256 `6c5de59113f6433f64b35818aa806274baf193043300fba7eed82df93ebed2a1`. This is root execution evidence, not my rerun.

## Commands actually executed

Read-only PowerShell `Get-Content`/line-numbered inspection, `git diff -- <fixture>`, `git diff --name-only -- <production environment directory>`, `git rev-parse HEAD`, `rg -n directSunlight`, and narrowed `Select-String` against the retained log. Read-only Java 17 `javap -classpath <pinned mapped Forge jar> -c -p` for `ThreadedLevelLightEngine`, `LevelLightEngine`, and `BlockAndTintGetter`. All completed successfully. Copies, hashes and this report were written only under this fresh Temp directory. No Gradle/test/server command was executed.

## Identity and remaining limits

- Reviewed corrected fixture SHA-256: `560715b89aa1bae85f999ebde51fc0adaef685bd7995d5fd4c9e9541737f83f1`.
- Reviewed production query SHA-256: `f4e275c2882ec16e045a23fcda5b710986eeaf6e5784e73b02bff1f7dec2461c`.
- Original fixed-delay source, corrected source, diff, full relevant bytecode, identities and failure excerpts are retained beside this report. Prior NAV review directories/reports are unchanged.
- Fresh-world execution of this correction remains unverified by this reviewer; root still owns the Gradle slot. This review does not establish V1/V2 UI behavior or release Gates.
- Existing night assertion is retained, not expanded: immediately restoring the roof may leave stale sheltered light, so that single step is not a separately synchronized proof of reopened-column nocturnal behavior. The earlier positive open-day assertion and the service's explicit daytime predicate are separate evidence. No new restoration-lighting or all-world stability claim is made.
