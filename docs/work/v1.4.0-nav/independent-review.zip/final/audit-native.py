import hashlib, json, re, sys
from pathlib import Path

REPO = Path(r'D:/GitHub/AdvancedRocketry-Community')
BASE = Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-nav-6fae0c34ff8247e5a5834a9520b71249')
ROOT = BASE / 'native'
OUT = Path(__file__).parent
sys.path.insert(0, str(REPO))
from scripts import run_v140_celestial_schema_smoke as schema
from scripts import run_v130_adapter_flight_smoke as decoder

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def uuid(raw): return schema.support.uuid_from_nbt(raw)

manifest = []
for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8-sig').splitlines():
    digest, name = line.split('  ', 1)
    p = ROOT / name
    assert p.resolve().is_relative_to(ROOT.resolve())
    assert p.is_file() and sha(p) == digest, name
    manifest.append(name)
assert len(manifest) == len(set(manifest))
summary = read(ROOT / 'summary.json')
assert summary['result'] == 'PASS'
for artifact in summary['artifacts']:
    p = Path(artifact['path'])
    assert sha(p) == artifact['sha256'] and p.stat().st_size == artifact['bytes']
observed = {'manifest_members': len(manifest), 'manifest_sha256': sha(ROOT / 'SHA256SUMS'), 'phases': {}}
rockets, stations, bindings, markers, configurations = {}, {}, {}, {}, {}
for phase in ('baseline', 'upgrade', 'restart'):
    d = ROOT / phase
    receipt, launch = read(d / 'observations.json'), read(d / 'launch.json')
    assert receipt['exit_code'] == 0 and receipt['result'] == 'PASS'
    expected_jar = summary['artifacts'][0 if phase == 'baseline' else 1]
    assert launch['artifact'] == expected_jar
    assert launch['command'][0].endswith('jdk-17.0.7\\bin\\java.exe')
    assert '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
    log = (d / 'stdout.txt').read_text(encoding='utf-8-sig')
    assert 'Stopping server' in log and 'Saving chunks for level' in log
    all_logs = {n: (d / n).read_text(encoding='utf-8-sig') for n in ('stdout.txt', 'latest.log', 'debug.log')}
    errors = {n: [s for s in text.splitlines() if re.search(r'/(?:ERROR|FATAL)\]', s)] for n, text in all_logs.items()}
    assert not any(errors.values()), errors
    commands = read(d / 'commands.json')
    assert 'save-all flush' in commands
    found, chunks, empty, material = [], 0, 0, 0
    for p in sorted((d / 'native').rglob('*.mca')):
        raw = p.read_bytes()
        if not raw:
            empty += 1
            continue
        material += 1
        assert len(raw) >= 8192
        match = re.fullmatch(r'r\.(-?\d+)\.(-?\d+)\.mca', p.name)
        rx, rz = map(int, match.groups())
        for index in range(1024):
            if raw[index*4:index*4+4] == bytes(4): continue
            chunks += 1
            x, z = rx*32+index%32, rz*32+index//32
            nbt = decoder.decode_entities(decoder.region_nbt._region_chunk(raw, x, z), x, z)
            found += [(p, entity) for entity in nbt['Entities'] if entity.get('id') == schema.HOST + ':rocket']
    assert len(found) == 1 and chunks <= 128 and material <= 16 and empty <= 32
    p, entity = found[0]
    data = entity['RocketEntityData']
    report = receipt['reports'][-1]
    state, snapshot = data['flight_data'], data['snapshot']
    assert data == read(d / 'native/entity-regions.json')['rocket']
    assert uuid(entity['UUID']) == report['entity']
    assert uuid(data['owner_id']) == decoder.OWNER
    assert uuid(data['assembly_transaction_id']) == uuid(state['logical_rocket_id']) == report['logical']
    assert state['current_dimension'] == report['dimension'] == snapshot['source_dimension']
    assert state['current_origin'] == report['origin'] == snapshot['source_origin']
    assert state['state'] == report['state'] and state['fuel']['amount'] == report['fuel']
    assert state['fuel']['capacity'] == 2000 and 'plan' not in state and 'active_transfer_id' not in state
    assert state['passengers'] == {'seat_capacity': 1, 'assignments': []}
    assert snapshot['content_hash'] == report['snapshot']
    cargo = [b['block_entity'] for b in snapshot['relative_blocks'] if 'block_entity' in b]
    assert len(snapshot['relative_blocks']) == 6 and len(cargo) == 1
    assert cargo[0]['data']['Items'] == [{'Slot': 0, 'id': 'minecraft:diamond', 'Count': 17}, {'Slot': 1, 'id': 'minecraft:iron_ingot', 'Count': 64}]
    assert [uuid(x['transaction_id']) for x in state['fuel']['committed_debits']] == [leg['transfer'] for leg in receipt['legs']]
    assert 2000 - sum(leg['required'] for leg in receipt['legs']) == state['fuel']['amount']
    rockets[phase] = data
    stations[phase] = schema.read_nbt(d / 'stations.dat')['data']
    native_station_ids = {(uuid(s['station_id']), uuid(s['owner_id']), s['orbit_body'], s['name']) for s in stations[phase]['stations']}
    assert native_station_ids == {(s['station_id'], s['owner_id'], s['orbit_body'], s['name']) for s in receipt['station_requests']}
    bindings[phase] = read(d / 'bindings.json')
    marker = d / 'inputs/world/.v002-smoke-world-identity.json'
    markers[phase] = sha(marker)
    configurations[phase] = decoder.configuration_identity('server.properties', (d / 'inputs/server.properties').read_bytes())
    if phase != 'baseline':
        journal = decoder.read_transfers(d / 'transfers.dat')
        assert len(journal['transfers']) == 1
        transfer = journal['transfers'][0]
        assert transfer['phase'] == 'COMMITTED' and uuid(transfer['transfer_id']) == receipt['legs'][-1]['transfer']
        assert transfer['destination_snapshot'] == snapshot
        assert transfer['source_flight']['fuel']['amount'] == 1019 and transfer['destination_flight']['fuel']['amount'] == 504
        assert transfer['required_fuel'] == 515 and transfer['source_snapshot']['source_dimension'] == schema.HOST + ':venus'
    observed['phases'][phase] = dict(exit_code=receipt['exit_code'], jar=launch['artifact']['sha256'], material_regions=material, empty_regions=empty, entity_chunks=chunks, rocket_entity=report['entity'], logical_rocket=report['logical'], fuel=state['fuel']['amount'], cargo=cargo, stations=len(stations[phase]['stations']), bindings=len(bindings[phase]['bindings']), warnings=[s for s in log.splitlines() if '/WARN]' in s], errors=errors, level_dat_sha256=sha(d/'inputs/world/level.dat'))
assert rockets['upgrade'] == rockets['restart']
assert stations['upgrade'] == stations['restart'] and bindings['upgrade'] == bindings['restart']
assert all(s in stations['upgrade']['stations'] for s in stations['baseline']['stations'])
assert [len(stations[x]['stations']) for x in stations] == [1,3,3]
assert [len(bindings[x]['bindings']) for x in bindings] == [3,6,6]
assert all(b in bindings['upgrade']['bindings'] for b in bindings['baseline']['bindings'])
assert len(set(markers.values())) == 1 and len(set(configurations.values())) == 1
log = (ROOT / 'upgrade/stdout.txt').read_text(encoding='utf-8-sig')
for report in summary['reports']:
    assert f"entity={report['entity']} logical={report['logical']} snapshot={report['snapshot']} dimension={report['dimension']} state={report['state']} fuel={report['fuel']}" in log
for leg in summary['legs']:
    assert f"request={leg['transfer']}" in log and f"required_fuel={leg['required']} fuel_before={leg['fuel_before']}" in log
assert 'code=INVALID_DESTINATION required_fuel=0 fuel_before=2000' in log
assert [x['required'] for x in summary['legs']] == [448,533,515]
assert sha(ROOT/'upgrade/transfers.dat') == sha(ROOT/'restart/transfers.dat')
assert sha(ROOT/'upgrade/stations.dat') == sha(ROOT/'restart/stations.dat')
observed['world_marker_sha256'] = next(iter(markers.values()))
observed['result'] = 'CHECKS_COMPLETED'
(OUT / 'native-audit.json').write_text(json.dumps(observed, indent=2), encoding='utf-8')
print(json.dumps({'result': observed['result'], 'manifest_members':len(manifest), 'fuel':[observed['phases'][x]['fuel'] for x in observed['phases']], 'warnings':{x:len(v['warnings']) for x,v in observed['phases'].items()}}, indent=2))
