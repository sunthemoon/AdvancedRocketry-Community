$ErrorActionPreference = 'Stop'
$env:JAVA_HOME = 'C:/Program Files/Java/jdk-17.0.7'
$env:PATH = "$env:JAVA_HOME/bin;$env:PATH"
$env:PYTHONUTF8 = '1'
Set-Location -LiteralPath 'D:/GitHub/AdvancedRocketry-Community'
$out = $PSScriptRoot
$focused = @('test', '--tests', '*RocketNavigationTest', '--tests', '*RocketFlightPlanPacketTest', '--tests', '*RocketFlightQuotesTest', '--tests', '*RocketFlightSelectionTest', '--tests', '*CelestialSnapshotTest', '--tests', '*StarMapLayoutTest', '--tests', '*RocketCatalogRefreshLimiterTest', '--tests', '*RocketMaintenanceStructureTest', '--tests', '*RocketTargetFlightPlannerTest', '--rerun-tasks', '--offline', '--no-daemon', '--no-build-cache', '--console=plain')
$start = Get-Date
('.\gradlew.bat ' + ($focused -join ' ')) | Set-Content -LiteralPath (Join-Path $out 'focused-command.txt') -Encoding utf8
& .\gradlew.bat @focused *> (Join-Path $out 'focused-gradle.log')
$code = $LASTEXITCODE
[pscustomobject]@{command=('.\gradlew.bat ' + ($focused -join ' '));java_home=$env:JAVA_HOME;start=$start.ToUniversalTime().ToString('o');end=(Get-Date).ToUniversalTime().ToString('o');seconds=((Get-Date)-$start).TotalSeconds;exit=$code} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'focused-result.json') -Encoding utf8
Copy-Item -LiteralPath 'build/test-results/test' -Destination (Join-Path $out 'focused-junit') -Recurse
if ($code -ne 0) { exit $code }
$integration = @('runData', 'runGameTestServer', '--offline', '--no-daemon', '--no-build-cache', '--console=plain')
$start = Get-Date
('.\gradlew.bat ' + ($integration -join ' ')) | Set-Content -LiteralPath (Join-Path $out 'integration-command.txt') -Encoding utf8
& .\gradlew.bat @integration *> (Join-Path $out 'integration-gradle.log')
$code = $LASTEXITCODE
[pscustomobject]@{command=('.\gradlew.bat ' + ($integration -join ' '));java_home=$env:JAVA_HOME;start=$start.ToUniversalTime().ToString('o');end=(Get-Date).ToUniversalTime().ToString('o');seconds=((Get-Date)-$start).TotalSeconds;exit=$code} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'integration-result.json') -Encoding utf8
Copy-Item -LiteralPath 'build/gametest/logs' -Destination (Join-Path $out 'gametest-logs') -Recurse
exit $code
