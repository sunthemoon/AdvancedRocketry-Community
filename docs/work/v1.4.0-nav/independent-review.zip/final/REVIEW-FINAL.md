# V140-NAV independent scoped review and verification

## Findings and dispositions

No unresolved concrete defect was identified in the final reviewed navigation diff. This is a bounded source/test/evidence conclusion, **not** a release or Required Gate approval.

1. **Resolved P2 — viewport input was unreachable.** The original `RocketFlightScreen.mouseClicked` offered the click to `AbstractContainerScreen` first, whose pinned implementation consumes blank clicks. Final `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/client/RocketFlightScreen.java:373-374` and `client/starmap/StarMapInput.java:9-10` offer the bounded map viewport first, then the container. `StarMapLayoutTest.java:15-26` actually passed in this rerun. Original source and bytecode evidence remain in the prior source review.
2. **Resolved contract gaps.** Explicit status IDs/precedence, overflow, bounded frame/name/UUID validation, and eventual pending retry following a full-catalog cooldown rejection are now specified and implemented. Focused tests below exercised these rules; this does not establish a real client packet session.
3. **Inherited fixture correction is appropriate, not a runtime relaxation.** `gametest/PlanetaryExposureGameTests.java:176-228` keeps timeout 40, observes the column until tick 30, checks actual STONE and skylight plus the gameplay query, and preserves cleanup. The fixed two-tick assumption was not a pinned lighting completion barrier. The independent run observed tick 1 / sky light 14 and passed. The original clean-world failure remains a failure; this rerun used the existing test world.

No additional source delta beyond the already-reviewed parent-map cache, typed station UUID validation, corresponding fixture changes and the sunlight synchronization correction was found. The current manual cases and verification draft distinguish V1/V2, FakePlayer/source/pure retry coverage and operator-only packaged evidence appropriately.

## Scope and identities

- Repository: `D:/GitHub/AdvancedRocketry-Community`; inspected baseline HEAD `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`, plus actual tracked diff and new source/test files. ADR-035 governs this slice.
- Reviewed navigation service/planner adaptation, menu/lifecycle/access and cooldown checks, wire bounds/exact flight protocol 7, client cache/coherence/selection/input/layout, GameTests and reader/manual documentation. Public API remains 1.7; no navigation save schema was introduced.
- `inputs-before.json` and `inputs-after.json` cover **1,180** source/generated/build input files; all paths, lengths and SHA-256 values are identical. Both inventory files hash to `75f56c05a766c6c52f8c8db20743a033e27b40b113edd5ca7c7a48251cb13aea`.
- Before/after tracked source patches are identical, SHA-256 `024b4f9fe427908e46bcf8b41e0c1bd5399d7a96c2a98f04e2807b072c204904`. The existing language changes versus HEAD remain; DataGen created no additional resource delta. Thirty-four affected tracked/new input files are copied under `input-snapshots/`.
- No tracked or index writes, excluded-user-bundle reads, remote activity, client launch, further delegation or OpenPet actions were performed. Gradle alone wrote permitted build/cache outputs. All reviewer helpers/reports are in this fresh Temp directory.

## Independently executed commands and results

Java: `C:/Program Files/Java/jdk-17.0.7`. From the shared checkout:

```text
.\gradlew.bat test --tests *RocketNavigationTest --tests *RocketFlightPlanPacketTest --tests *RocketFlightQuotesTest --tests *RocketFlightSelectionTest --tests *CelestialSnapshotTest --tests *StarMapLayoutTest --tests *RocketCatalogRefreshLimiterTest --tests *RocketMaintenanceStructureTest --tests *RocketTargetFlightPlannerTest --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
.\gradlew.bat runData runGameTestServer --offline --no-daemon --no-build-cache --console=plain
```

The exact argument arrays, start/end/exit receipts and complete redirected output are retained in `run-checks.ps1`, command text files, result JSON and logs.

- **Focused JUnit: exit 0, 49.989 s, 47 tests / 9 suites**, zero failures, errors or skips. `:test` actually executed; 16 of 16 actionable tasks executed, not cached XML. Counts: CelestialSnapshot 5, StarMapLayout 4, RocketTargetFlightPlanner 3, RocketFlightQuotes 7, RocketFlightSelection 10, RocketNavigation 4, RocketFlightPlanPacket 8, RocketCatalogRefreshLimiter 2, RocketMaintenanceStructure 4. Raw XML is in `focused-junit/`.
- **DataGen + GameTest: exit 0, 136.346 s.** DataGen reports **written 0**; all **232 Required GameTests passed**. Actual `rocket_navigation`, `rocket_navigation_refresh`, `rocket_navigation_menu` batches and the sunlight receipt are present. This was a **reused `build/gametest` world**, without clean/deletion. Eighteen actionable tasks: 4 executed, 14 up-to-date. It was not another full 866-case JUnit execution.
- Retained independent GameTest startup warning: **2164 ms / 43 ticks behind**. Intentional migration/save-failure tests emit diagnostic ERRORs; the final GameTest summary is 232/232, not a zero-ERROR-log claim. No performance acceptance is inferred.
- `focused-gradle.log`: `c09229b58587f5257de5b99e8d5463b5e3d250ce34c529e429f0dec2dfdfbd76`.
- `integration-gradle.log`: `810f8db7b8a0378df12a0984ec2670fdc5c232dfdf455ea390a20f758cc3a74e`.
- Scoped `git diff --check -- src build.gradle settings.gradle gradle.properties`: exit 0. Read-only Git/PowerShell inventories and SHA checks completed. No additional Python unittest suite was requested or executed in this final window; Python below is an evidence parser, not a runtime/test rerun.

**Both owned Gradle commands fully exited and the exclusive Gradle slot was explicitly released to root before the native report was finalized.**

## Artifact checks

All three build JARs remain byte-identical before/after, match root's frozen `artifacts/`, have unique ZIP entries and pass ZIP CRC checks. API contains exactly **27 exported classes**, all under the API package and byte-identical to the corresponding classes in main. No standalone consumer rebuild/publication was run in this review.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Main | 2546008 | `66d365ccfe8434b3e2f461b4a3f3b9663e71bd6c1571a58df44c2217089293b8` |
| API | 48469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| Sources | 1158573 | `f0ba9b84775822a095ff421d57ddcd87a95a383062a55b141b7121b13f9bb1dc` |

## Independent readback of root's packaged evidence

Source: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-nav-6fae0c34ff8247e5a5834a9520b71249/native`. This reviewer did **not** launch these three JVMs. Read-only Python command used `D:/python/pyenv/pyenv-win/shims/python.bat -B <this-directory>/audit-native-v2.py` with `PYTHONUTF8=1`; final exit 0. `audit-artifacts.py` also exited 0. Helpers, outputs and raw-decoder provenance remain available.

- Verified **147 distinct manifest members** against their actual bytes. Native manifest SHA-256 `669d4cb8940c1c343540d42ecd0a03b5ff4440a675794dcc57182c28e759150e`.
- Launch receipts bind the baseline to MAP-01 JAR `9fc582f1b83599526627b065d72b9995fbb7a69e04065a135dce7aa8697b1acf`; upgrade/restart bind the final NAV main JAR above. Actual source JAR lengths/hashes match. Commands use Java 17.0.7, Forge 47.4.10 arguments and explicit operator release-test hooks. All three phase observations record exit 0; raw stdout contains save/stop lifecycle, not merely a PASS JSON verdict.
- Independently decoded raw nonempty entity Anvil chunks using the existing bounded low-level NBT/region readers, not `entity-regions.json` alone. Each phase has exactly one saved rocket among the captured five dimension entity directories. Native entity UUID, owner/logical identity, location, fuel, passenger state, snapshot and decoder-produced receipt agree. Cargo in every phase is **17 diamonds + 64 iron ingots**, with exact slot/count metadata.
- Raw live receipts show Earth -> Mars -> Venus -> Earth, required debits **448 / 533 / 515**, fuel **2000 -> 1552 -> 1019 -> 504**, and gas-surface refusal before a successful leg. Intermediate Mars/Venus landings are live log observations, not separately stopped phase saves.
- Raw final saved rocket remains identical across restart at **504 / 2000**, with exactly the three committed debit transaction IDs. The retained final transfer is COMMITTED, source Venus fuel 1019 / destination Earth 504, required fuel 515, and destination snapshot equals the saved rocket. Final journal bytes match after restart.
- Independently decoded station SavedData: **1 -> 3 -> 3** records, preexisting record retained, exact station IDs/owners/names/orbit bodies agree with creation receipts; final bytes identical across restart. Binding JSON counts **3 -> 6 -> 6**, old reservations retained and final records unchanged. Server-properties semantic identity and final same-world marker agree.
- Actual stdout warning counts are **25 / 10 / 11**; all three raw log variants contain zero ERROR/FATAL records. Restart includes **2189 ms / 43 ticks behind**. This is not a warning-free or performance claim.
- `audit-native.py` first exited 1 because it assumed the baseline capture already contained the world marker. The runner actually creates that marker after baseline phase capture (`run_v140_planetary_worlds_smoke.py:415-417`). Original helper/output are retained unchanged. Version 2 binds baseline level.dat bytes to `baseline/world-identity.json`, then compares the later raw marker copies; it passed without modifying evidence or changing runtime assertions.

The audit does not decode whole `level.dat`, certify every block palette/item entity, independently recompute snapshot/transfer checksums, or establish full-world byte immutability. It reuses bounded low-level parsers but applies separate assertions. No client, actual menu packet/retry delivery, login, native navigation reload or environmental-player gameplay is covered by this operator travel smoke.

## Prior immutable review identities

| Report (under `C:/Users/Administrator/AppData/Local/Temp/`) | SHA-256 |
|---|---|
| `arce-v140-nav-contract-review-8f607eae14704fe997d173de32caf00d/REVIEW.md` | `30390be0fc909c790c4e82d6ff7560b5820311742c9b7d5d9f73bf8f1e980f4e` |
| `arce-v140-nav-source-review-d97fca4578ff42cab922116bd96ccc96/REVIEW-SOURCE.md` | `9dac424bec47dc7fa332c2da42f6b8ee797a4609e41d9611c1aa7e6578c971dd` |
| `arce-v140-nav-incremental-review-1612e99bad1b472c83ae2e915471ffbd/REVIEW-INCREMENTAL.md` | `cadf9402da447066f681660ea3a7246d65f250567a2280084ff61cab99c960be` |
| `arce-v140-nav-lighting-review-bf774001b33d466db048a0f1e82562ca/REVIEW-LIGHTING.md` | `ea1f24dd91d7b617630cac9965008f1cc85f8993227f9e45e781bbfe321393b3` |

## Remaining verification boundaries

The GameTests use network-free FakePlayers/private candidate publication and finite service calls; pure tests cover retry scheduling but not actual cross-menu packet delivery. Real GPU V1 and two-real-client V2 cases, GUI scale/localization visual layout, actual packet races, sustained load/performance, S2 crash cuts and complete migration/release acceptance remain unexecuted. The inherited night assertion does not separately await reopening skylight. No full Gate approval, tag, publication or user-world operation follows from this report. Further work should follow the current v1.4 remaining plan; no extra broad campaign was added here.
