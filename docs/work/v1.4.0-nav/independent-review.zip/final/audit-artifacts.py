import hashlib, json, zipfile
from pathlib import Path
OUT = Path(__file__).parent
ROOT = Path(r'C:/Users/Administrator/AppData/Local/Temp/arce-v140-nav-6fae0c34ff8247e5a5834a9520b71249/artifacts')
BUILD = Path(r'D:/GitHub/AdvancedRocketry-Community/build/libs')
result = []
for path in sorted(ROOT.glob('*.jar')):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == hashlib.sha256((BUILD/path.name).read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names))
        result.append(dict(name=path.name, bytes=path.stat().st_size, sha256=digest, entries=len(names)))
main = ROOT/'advancedrocketry-community-1.20.1-1.4.0-dev.jar'
api = ROOT/'advancedrocketry-community-1.20.1-1.4.0-dev-api.jar'
with zipfile.ZipFile(api) as a, zipfile.ZipFile(main) as m:
    exported = [n for n in a.namelist() if n.endswith('.class')]
    assert len(exported) == 27
    assert all(n.startswith('io/github/sunthemoon/advancedrocketrycommunity/api/') for n in exported)
    assert all(a.read(n) == m.read(n) for n in exported)
result = dict(artifacts=result, api_classes=exported, exact_main_api_class_identity=True)
(OUT/'artifact-audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'artifacts':len(result['artifacts']), 'api_classes':len(exported), 'main_api_byte_identity':True}))
