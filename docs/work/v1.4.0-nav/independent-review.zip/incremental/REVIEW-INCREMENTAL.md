# V140-NAV incremental source and test review

## Findings

No new concrete correctness/security defect was identified in the inspected incremental source. The earlier P2 container-click dispatch finding remains corrected by viewport-first `StarMapInput`; its original report/evidence is preserved separately. This report is read-only source inspection, not independent execution or Gate approval.

## Identity and scope

Repository: `D:/GitHub/AdvancedRocketry-Community`; baseline/observed HEAD `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`. Compared actual changes with the prior source snapshot at `arce-v140-nav-source-review-d97fca4578ff42cab922116bd96ccc96` and baseline. Root owns implementation and the active build slot. No source/index/build writes or test processes were initiated; the excluded user documentation bundle was not opened.

Of the previously captured 29 Java files, three had changed when this comparison ran: `RocketStarMap.java`, `RocketNavigation.java`, and `RocketNavigationTest.java`. Exact before/after hashes are in `delta-identities.json`. Newly reviewed files include `RocketNavigationGameTests.java`, the source-station assertion in `PlanetaryAdmissionGameTests.java`, and the manual/data/provenance documentation. The working tree is not treated as an atomic frozen commit.

## Actual review observations

Source references are beneath `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless otherwise stated.

- `rocket/menu/RocketNavigation.java:40–46` now validates station UUIDs through the existing typed `TravelTarget.Station` constructor. This consistently rejects non-RFC-4122 variants and versions outside 1–5 before a navigation station can be used as a typed target. Name and orbit-ID bounds remain unchanged. The new test uses valid UUIDs for the maximum-frame case and tests invalid UUID rejection.
- `client/starmap/RocketStarMap.java:69–84,114–120` compares decoded snapshot content before rebuilding layout and constructs an immutable ID-to-node map alongside that layout. Parent lookups are now constant-time per edge rather than a repeated linear search. `StarMapLayout.create` validates parents before publication; clearing/replacing a snapshot also clears/replaces the parent map. Same-content full snapshots preserve the viewport instead of resetting pan/zoom unnecessarily.
- `gametest/RocketNavigationGameTests.java:42–90` tests real manager quote authorization, the current body, private station filtering, gas surface exclusion, positive Mars readiness, insufficient fuel and rejected stale launch after a local catalog change. The 20 repeated quote calls are synchronous; flight data, station SavedData, transfer SavedData and loaded-chunk counts are compared during that interval.
- `RocketNavigationGameTests.java:92–132` uses the installed runtime through an actual `RocketFlightMenu`, validates button/viewer IDs, immediate refresh after immutable fuel-data replacement, revocation refresh after 21 ticks, stale station launch refusal, distant viewer refusal and closed-menu refusal. The station is owned by a random third party with explicit actor membership, avoiding an owner bypass of the revocation assertion.
- `RocketNavigationGameTests.java:134–168` checks the real service-owned catalog budget across two menu objects and a local catalog generation change. It verifies the latest generation after 101 ticks, immediate repeat refusal, logout cleanup and distance checks. The manager is local and is not installed over the global runtime.
- The additional `PlanetaryAdmissionGameTests.java:180–183` assertion checks the navigation status after source-station membership is removed, alongside existing launch/journal preservation assertions. It exercises source access separately from destination station filtering.
- The three new fixtures use separate batches and the 16-cube `rocket_test` template. Their small assembly coordinates remain inside the reserved template. Cleanup deletes/releases their own random station IDs, resets their actor's menu, clears local managers and discards their own rocket; it does not globally clear other fixtures' stations or entities.

## Evidence limits and finite follow-up

- These are network-free FakePlayers, not real client connections. The service recovery test calls `manager.navigationCatalog` directly after the delay; it does not observe `RocketFlightMenu.broadcastChanges`, packet delivery, client acceptance or rendered recovery. Actual pending retry is supported by source inspection plus the separate pure sync/limiter tests, not by this GameTest alone.
- Catalog changes use local `applyCandidate`, not Minecraft `/reload` resource listeners. They prove consumer reactions to captured generations and capability changes, not a native resource-reload cycle.
- Loaded chunk counts around synchronous quote calls do not represent real eviction/unload/reload, arbitrary concurrent chunk churn or whole-world resource conservation. Authority snapshots cover the listed flight/journal/station data; no global item-entity or block-palette conservation claim is made.
- Cleanup covers normal completion and assertion/runtime-error paths inside the fixtures' guarded regions. If a negative launch assertion unexpectedly succeeded, its newly created transfer record would not be explicitly removed by these fixtures' cleanup. Such a failed test world must not be advertised as pristine/reusable without inspection. No such failure was observed by this reviewer because tests were not executed here.
- `docs/work/v1.4.0-nav/MANUAL-CASES.md` clearly says unexecuted and distinguishes V1/V2. It records node/drag/scroll/focus, small-window/GUI-scale/language, large catalogs, gas/station navigation, changing permission/fuel, cooldown recovery and active-plan cancellation. `docs/CELESTIAL-DATA-GUIDE.md` correctly distinguishes schematic metadata from survival/oxygen/enabled damage, explicit selection from launch, and quote admission from a reserved landing pad. Native operator commands cannot substitute for those client observations.
- The provenance addition describes original geometry/text and no art import. Its generated-resource inventory link was still being assembled when reviewed; no packaged identity claim was independently checked during root's live build.

Root reported 866 JUnit/155 suites and 232 required GameTests, then a packaging clean run. Those are context only and were not independently read from mutable build output or rerun here. Independent execution/artifact/native audit remains pending an explicit exclusive slot grant.

## Commands actually performed

- `git status --short`, `git diff --stat bd8b9a8`, scoped `git diff bd8b9a8 -- ...`, `git diff --check` (exit 0).
- `rg --files docs/work` filtered to navigation, and scoped source `rg -n`/`Get-Content` with numbered lines for the new fixtures, assembly helper, station persistence, typed UUID validation, DTO/tests and documents.
- `git diff --no-index -- <prior snapshot>/client/starmap/RocketStarMap.java <repository>/client/starmap/RocketStarMap.java` identified the actual parent-cache/content-equality delta; a nonzero diff result means differences, not a failed test.
- Read-only `Get-FileHash` comparison against the prior 29-file identity inventory; Temp-only report/snapshot/hash/manifest writes.

No Gradle, unit/GameTest, client/server, remote/network, browser, process-control, OpenPet or subagent command was run. Repository files and prior reports remain unchanged by the reviewer.
