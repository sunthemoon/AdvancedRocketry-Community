# V140-NAV independent contract review

## Findings and resolution

No unresolved concrete contract finding remains in the revised ADR reviewed here. This is a contract/source inspection, not implementation verification, maintainer approval, or Gate approval.

1. **P2 — Initial wire contract did not define the promised stable status IDs or complete bounds. Resolved in revised text.** Initial ADR-035 lines 34–47 named bounded status codes and an exact-match protocol increment, but did not fix numeric values, precedence, overflow mapping, or the ordinary frame/string ceiling. The existing `rocket/flight/RocketFlightPlanCode.java` includes `ARITHMETIC_OVERFLOW`; `RocketTargetFlightPlanner.java:72–87` distinguishes formula rejection from insufficient capacity/fuel. Omitting that mapping risks an unexplainable unavailable result or later wire incompatibility. Revised ADR-035:41–62 fixes IDs 0–11, precedence, unknown-ID rejection and READY semantics; :92–99 fixes the frame and string bounds. The stated 31,419-byte ceiling is conservative and below 32 KiB; it is not a claim that every canonical combination attains that exact length. Maximum-field wire tests remain necessary.

2. **P2 — Initial recovery cadence lacked an eventual retry after a cooldown refusal. Resolved in revised text.** Initial ADR-035:38–60 combined changed-only navigation transmission, one full catalog per player per 100 ticks, and mismatch-triggered refresh, without specifying pending/retry lifetime. A request at tick 20 following a tick-0 send could be suppressed forever if neither flight nor catalog subsequently changed and the client requested only on the mismatch transition. This was a contract ambiguity, not a reproduced runtime failure. Revised :86–91 requires server retry every 20 ticks until eligible, permits client retries every 100 ticks, discards pending work on menu close, caps limiter entries at 128, and clears lifecycle state. This preserves the send budget while defining liveness.

The additional selection/cancellation clarification at revised ADR-035:25–27 is consistent with existing `RocketFlightSelection.java:97–114`: CANCEL derives from the active plan, not an editable destination. Dynamic station reorder/removal must not change the identity of a retained selection or prevent cancellation of an existing plan.

## Reviewed identity and scope

- Repository `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.4.0-planetary-expansion`, observed HEAD `bd8b9a827f3cf961ee7d658f54ac2b6547716fcc`.
- Reviewed initial PROPOSED and revised ACCEPTED ADR-035 plus the active NAV task scopes. Root recorded acceptance under standing maintainer authority; this report does not confer that authority or claim a new manual vote.
- `ADR-035-initial.md` and `ADR-035-revised.md` retain the actual observed texts; work-log snapshots/diff and `reviewed-inputs.json` retain scoped identities.
- Mandatory governance/version/quality documents were read. ADR-030 authorizes this development scope despite incomplete inherited Gates. ADR-018 postpones complete acceptance, not short authority/codec/regression checks.
- No tracked/index/build files were edited. No user documentation bundle was opened. Report and snapshots are confined to this fresh Temp directory.

## Existing mechanisms and implementation constraints

Source references below are under `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` in the repository above.

- **Authority:** `rocket/server/RocketFlightService.java:188–213,255–321,471–488` already validates intent rate, live loaded same-Level rocket, range, control, source/destination station VISIT access, current state and a new plan. Quotes at :104–174 currently do not repeat all control/source-access checks. The proposed readiness filter is real implementation work, not an existing property. Keep launch-time revalidation regardless of displayed READY.
- **Metadata-only physical admission:** `rocket/server/PlanetaryFlightAdmission.java:17–55` checks actual started Levels and saved source/body/typed target/station identity without terrain scans or chunk loads. `RocketFlightService.java:378–406` uses this before the same pure target planner. Do not call landing-pad search/reservation when rendering quotes.
- **Coherent generation:** `celestial/data/PlanetaryCatalogManager.java:15–30,41–60` publishes one body/route/generation state and exposes a matching celestial view. Capture once for a navigation operation. Rejected reload retains generation/catalog; successful route-only reload still increments generation and requires coherent refresh even if body display bytes are unchanged.
- **Existing UI limitations:** `rocket/menu/RocketFlightMenu.java:35–43,98–114,140–169,212–217` has immutable opening station data/current target and a per-broadcast quote snapshot. `client/RocketFlightScreen.java:40–47,209–216,323–333` cycles quoted bodies and uses opening station names. `RocketFlightSelection.java:14–20,66–73` copies the station list and uses an index. Dynamic metadata/selection is not supplied by the baseline.
- **Bounded private station view:** `station/service/StationAccessService.java:21–39` filters owner/operator/member VISIT access, sorts by name then UUID, and limits to 32. `station/model/StationLimits.java:7–13` caps global stations at 4096 and names at 48 Java string characters. The design retains the existing bounded subset, not a promise that every station is navigable in one frame. Add orbit body to a display DTO without altering persistent StationState schemas.
- **Network/client lifecycle:** `rocket/network/RocketFlightNetwork.java:16–37` exact-matches protocol 6, and `RocketFlightPlanPacket.java:81–87` plus `client/RocketFlightPlanHandler.java:12–17` target only an already-open matching container/entity. Preserve that check in protocol 7. `celestial/network/CelestialClientCache.java:14–44` currently accepts every valid generation; monotonic rejection is still to be implemented. Its last-good retention exists, and `client/ClientCelestialEvents.java:19–21` clears on disconnect. Generation alone must not mark a cache coherent after its last decode failed.
- **Finite data and work:** `CelestialSnapshotCodec.java:23,28–62` has the separate 96 KiB cap, and its existing maximum-count/identifier test covers 128-body encoding. `travel/route/model/RouteLimits.java:7–11` retains 512 routes, 256 anchors, 64 outgoing edges, 1024 expanded nodes and 256 cached plans. Full-catalog send limits should be checked before expensive encode/send work; navigation refresh must not bypass its cadence through client button spam. No arbitrary coordinates/collections are introduced by refresh ID 0.

## Required bounded implementation checks

1. All 12 status IDs, precedence, overflow, zero/negative/out-of-bound fuel, duplicate quote/station IDs, 48-character multibyte names, maximum ID/count frames, unknown status, strict flag/count/trailing/truncation rejection, protocol 7 exact match; separate 96 KiB catalog envelope unchanged.
2. Valid generation G, newer G+1, late G, malformed/future schema, equal-generation replay, successful route-only reload, failed reload retention, disconnect followed by a new server with smaller generation. Verify no stale packet creates/reopens a menu.
3. Cooldown boundary at ticks 99/100, denied refresh followed by quiet eventual recovery, repeated close/reopen, pending close discard, 128-player limiter saturation/expiry/logout/stop. Check encode/send counts and no resource/chunk mutation, not only returned booleans.
4. Owner/member/operator and unauthorized viewers, source access revoked after open, removed/renamed/reordered stations, absent/unstarted physical target, invalid/future runtime data, current target, insufficient fuel/capacity/thrust and stale launch intent. Keep stable editable selection separate from active-plan cancellation.
5. Deterministic 100/128-node forests/deep parent chains, bounded coordinates/pan/zoom, clipping and off-viewport hit rejection, previous/next focus bringing each body into view, no per-frame reconstruction. Localization/GUI-scale and actual client event routing remain visual/manual evidence, not pure layout proof.
6. Later short build/DataGen/GameTest, applicable independent reruns and packaged sidedness/restart regression. Pure/server checks cannot establish V1/V2, actual two-client synchronization, GPU readability/performance, or the postponed full campaign.

## Commands actually performed

Only read/inspection commands and Temp evidence writes were used:

- `git status --short`, `git branch --show-current`, `git rev-parse HEAD`, `git diff --stat`, `git diff -- docs/work/v1.4.0-implementation-log.md`, `git diff --check` (final exit 0).
- `Get-Content` of AGENTS, PROJECT-CONFIG, PRODUCT, required governance/version documents, ADR-018/030/031/035, work log, and the source/test files discussed above; numbered output using PowerShell counters.
- `rg --files src/main/java`, `rg --files src/test/java`, and bounded `rg -n` searches for NAV, flight quotes, packet/caches, station access, limits and lifecycle.
- `Copy-Item`, `Get-FileHash`, JSON/manifest/report writes only within this review Temp directory.

Inspection mistakes were corrected without hiding test failures: the guessed short version filename and three guessed Java paths did not exist; a PowerShell command containing Bash-style brace expansion had a parser error and was rerun with a valid directory search; one guessed reload-listener path in `rg` was absent. These were file-location/inspection errors, not executable verification. Large initial combined read output was truncated; relevant contract/version/source ranges were subsequently read separately.

**No Gradle, Java, Python test, client, dedicated server, remote, browser, or network commands were run.** No artifact or runtime outcome is asserted. The next review should inspect actual implementation and run the separately coordinated key checks. All Required Gates remain outside this contract-only result.
