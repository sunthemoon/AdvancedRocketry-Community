# ADR-035 — Rocket star map and navigation synchronization

```yaml
status: PROPOSED
date: 2026-09-27
owner: sunthemoon
scope: v1.4.0 navigation
authority_basis: standing maintainer authorization to use recommended implementation decisions
```

## Context

The console has typed server quotes but cycles through bodies, keeps opening-only
station names and does not explain unavailable targets. Celestial display data
already has a bounded, generation-tagged snapshot. Navigation must join these
views without treating client layout or stale quotes as launch authority.

## Decision

- Add a schematic, interactive star-map view inside the existing flight menu,
  not a second independently active container. Show parent relationships,
  body/environment details, selected surface and accessible orbit stations.
  Preserve the compact console, boarding, cancellation and typed launch flow.
  Selection is not a launch; the ordinary explicit Launch button remains.
- Body metadata is public under the existing catalog policy. Non-landable gas
  bodies remain inspectable but acquire no surface target. Discovery/research
  policy remains V140-DISC; navigation does not invent or unlock hidden routes.
  Stations remain private: only the existing VISIT policy's bounded list is
  sent, with ID, validated name and orbit body. Revoked/removed entries disappear
  on the next refresh and cannot be launched from a stale view.
- Capture one planetary generation for each quote batch. Use the same physical
  admission and route/fuel planner as launch. Check rocket control authority,
  source-station access and current state before advertising launch readiness.
  Explain ready/current/unavailable route, components, thrust, capacity, fuel,
  invalid fuel state, invalid flight state and lack of authority with bounded
  server status codes. Do not scan terrain, load chunks or reserve landing pads
  while preparing a map. A quote is not a landing guarantee.
- Keep at most 128 body nodes, 32 station summaries and 160 quotes. Retain all
  existing route-search and cache budgets. Refresh menu navigation at most once
  per 20 ticks, with immediate refresh on changed rocket flight data; state and
  active plan continue through the existing menu synchronization. Send a changed
  snapshot only; station/permission/catalog changes appear within 20 ticks.
- Extend the flight-plan S2C message with generation, stable explicit quote
  status IDs and current station summaries. Increment the exact-match
  `rocket_flight` channel from 6 to 7. This changes no public API or save schema;
  pre-NAV clients must use their matching server build. Keep the celestial
  display channel/schema at 2 and its existing 96 KiB payload limit.
- Register the existing full celestial snapshot as an additional S2C message
  on the flight channel for menu recovery. Send it on open/new generation and
  bounded refresh; cache only one encoded generation per server service.
  A player receives at most one such menu-driven full snapshot per 100 ticks
  across menu reopenings. The rate state clears on logout/server stop.
- Reuse the vanilla container-button intent for refresh, accepting only its
  fixed ID, actual viewer/open menu, live same-Level loaded rocket, distance and
  server thread. No client coordinates, fuel, target results, NBT or arbitrary
  catalog selector are accepted. Client mismatch triggers a rate-limited full
  refresh and disables selection-to-launch until generations agree; successful
  reload also uses the existing full-catalog synchronization. Late catalog
  generations cannot roll back a newer cache; malformed input retains the last
  valid data but does not become a coherent launch display.
- Layout is display-only, deterministic and bounded by the 128-node catalog.
  Rebuild it on changed data, not each frame. Clip drawing/hit testing to the
  viewport; clamp pan/zoom and provide deterministic previous/next navigation so
  every body remains inspectable. Preserve the existing teal/orange console
  style, use original code-drawn geometry and localized text, and import no art.

## Compatibility and non-goals

The existing C2S launch checks remain authoritative for owner/access/distance,
physical targets, state, current route and fuel. No client status creates a
permission or travel destination. Existing typed target IDs, station schemas,
rocket journals, terrain, API 1.7 and environmental rules are unchanged.
No warp, discovery persistence, new generic orbit arrival, world generation,
new engine tier or asset import belongs to this slice. Rollback uses matched
pre-NAV client/server artifacts; no save migration is needed for menu state.

## Verification

Check status/DTO bounds, strict wire decoding, generation retention/coherence,
dynamic station visibility and selection, deterministic 100/128-node layout and
viewport limits. GameTests exercise real server quote/control/access rejection,
reload refresh, menu validity/rate enforcement and no chunk loading or resource
mutation. Run short build/DataGen/GameTests, packaged server/restart regression
and independent review/reruns. Keep UI/manual cases explicit; do not infer V1/V2
from pure layout tests. Full client/GPU/load acceptance remains under ADR-018.

Platform references: [Forge menus](https://docs.minecraftforge.net/en/1.20.1/gui/menus/),
[screens](https://docs.minecraftforge.net/en/1.20.1/gui/screens/) and
[SimpleImpl](https://docs.minecraftforge.net/en/1.20.1/networking/simpleimpl/).
Implementation follows existing repository patterns; no platform code is copied.
