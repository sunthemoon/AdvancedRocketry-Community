"""Archive existing V150-STATION-01/02 evidence and validate exact archive members.

Reads the root and reviewer Temp directories without modifying them. Writes only
into docs/work/v1.5.0-station-schema. No build, test or server is executed.
"""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
HERE = Path(__file__).resolve().parent
TEMP = Path('C:/Users/Administrator/AppData/Local/Temp')
RUN = TEMP / 'arce-v150-station-schema-04389c908f4b406ebc03badf69358576'
REVIEW = TEMP / 'arce-v150-station-schema-review-3c51e146d3d54e2f828b5959d7f8ea66'
OUT = ROOT / 'docs/work/v1.5.0-station-schema'
BASE = 'a0e1d8fd90bc1731a3de5c34b8d3fdf20d35ab03'
HARNESS = '9c992bd8f8d9d7fa25eaf2ad27040cf6e42c51f52be7b8e8e027e11fd21590d8'
# Runtime copy (libraries, mods, disposable world copy); per-phase logs/state are under native/.
ROOT_EXCLUDED = {'station-server': 'server runtime/libraries/disposable world copy; phase logs and state retained in native/',
                 '__pycache__': 'Python bytecode cache', 'native': 'archived separately as native.zip'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def files(source, excluded=()):
    for path in sorted(source.rglob('*')):
        relative = path.relative_to(source)
        if relative.parts[0] in excluded:
            continue
        assert not path.is_symlink(), path
        if path.is_file():
            yield relative.as_posix(), path


def bundle(name, groups):
    members = [(prefix + '/' + key if prefix else key, path) for prefix, source, excluded in groups
               for key, path in files(source, excluded)]
    assert members and len(members) == len({key for key, _ in members}), name
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in sorted(members):
            data = path.read_bytes()
            archive.writestr(zipfile.ZipInfo(key, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)
    raw = (OUT / (name + '.zip')).read_bytes()
    return {'name': name + '.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
            'manifest': name + '-files.json'}


def junit(directory):
    suites = [ET.parse(path).getroot() for path in sorted(directory.glob('TEST-*.xml'))]
    return {'suites': len(suites), **{key: sum(int(s.attrib.get(key, '0')) for s in suites)
            for key in ('tests', 'failures', 'errors', 'skipped')}}


def archive():
    OUT.mkdir(exist_ok=True)
    # Tested sources must be exactly the bytes about to be committed.
    tested = json.loads((RUN / 'implementation-files.json').read_text())
    assert len(tested) == 27
    for relative, digest in tested.items():
        assert sha((ROOT / relative).read_bytes()) == digest, relative
    changed = set(git('diff', '--name-only', BASE, '--', 'src/main', 'src/test', 'gradle.properties').decode().split())
    changed |= set(git('ls-files', '--others', '--exclude-standard', '--', 'src/main', 'src/test').decode().split())
    assert changed == set(tested), sorted(changed ^ set(tested))
    artifacts = json.loads((RUN / 'artifacts.json').read_text())
    for row in artifacts['artifacts']:
        assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']

    passing, failed, focused = junit(RUN / 'full-junit-02'), junit(RUN / 'full-junit-01-failed'), junit(RUN / 'focused-junit')
    assert passing == {'suites': 170, 'tests': 943, 'failures': 0, 'errors': 0, 'skipped': 0}, passing
    assert failed['tests'] == 943 and failed['failures'] + failed['errors'] == 1, failed
    assert focused['tests'] == 76 and focused['failures'] == focused['errors'] == focused['skipped'] == 0, focused
    reviewer = junit(REVIEW / 'test-results')
    assert reviewer['tests'] == 61 and reviewer['failures'] == reviewer['errors'] == reviewer['skipped'] == 0, reviewer
    log = (RUN / 'root-gradle-02.log').read_text(encoding='utf-8', errors='replace')
    assert 'All 237 required tests passed' in log and 'BUILD SUCCESSFUL' in log, 'passing full run markers'
    assert 'BUILD FAILED' in (RUN / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace')

    summary = json.loads((RUN / 'native/summary.json').read_text())
    assert summary['result'] == 'PASS' and [c['result'] for c in summary['cycles']] == ['PASS', 'PASS']
    readback = json.loads((REVIEW / 'native-readback.json').read_text())
    assert readback['result'] == 'PASS' and readback['corrected_harness_sha256'] == HARNESS
    assert sha((RUN / 'native_station_check.py').read_bytes()) == HARNESS
    assert sha((REVIEW / 'native-harness-revised.py').read_bytes()) == HARNESS
    probes = {row['case']: row['rejected'] for row in readback['corrected_oracle_probe']}
    assert probes == {'valid': False, 'empty': True, 'missing-row': True, 'duplicate-row': True, 'wrong-size': True}

    archives = [
        bundle('root-checks', [('', RUN, set(ROOT_EXCLUDED)), ('packaging', HERE, {'__pycache__', 'out'})]),
        bundle('native', [('native', RUN / 'native', ())]),
        bundle('independent-review', [('', REVIEW, ())]),
    ]
    excluded = [{'name': name, 'reason': reason} for name, reason in sorted(ROOT_EXCLUDED.items())]
    write('evidence-archives.json', {
        'schema_version': 1, 'base_commit': BASE,
        'scope': 'V150-STATION-01/02 development evidence; archived after pause without rerunning checks',
        'source_directories': {'root': str(RUN), 'review': str(REVIEW), 'packaging': str(HERE)},
        'root_excluded_top_level': excluded, 'archives': archives})
    write('root-checks.json', {
        'base_commit': BASE, 'tested_implementation_files': tested,
        'junit_full_passing': passing, 'junit_full_first_failed': failed, 'junit_focused': focused,
        'junit_independent_targeted': reviewer, 'gametests_required_passed': 237,
        'native': {'result': summary['result'], 'phases': [{k: c[k] for k in ('phase', 'exit_code', 'result', 'station_count', 'migration_lines')} for c in summary['cycles']]},
        'independent_native_readback': {'result': readback['result'], 'kind': readback['kind'],
                                        'corrected_harness_sha256': HARNESS, 'oracle_probes': probes},
        'scope': 'Short development checks, not Required Gate approval'})
    write('development-artifacts.json', {'base_commit': BASE, 'artifacts': artifacts['artifacts'],
                                         'api_classes_unchanged_from_v140': len(artifacts['unchanged_api_classes']),
                                         'native_artifacts': summary['artifacts']})
    print('PASS: tested sources/artifacts match working tree;', ', '.join(f"{a['name']} {a['members']}" for a in archives))


def finalize():
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii')
    rows, links = [], []
    prefix = OUT.relative_to(ROOT).as_posix() + '/'
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write('source-identity.json', {'base_commit': BASE, 'files': rows})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    for path in OUT.glob('*-files.json'):
        with zipfile.ZipFile(path.with_name(path.name.replace('-files.json', '.zip'))) as archive:
            listing = json.loads(path.read_text())
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(r['path'] for r in listing)
            for row in listing:
                raw = archive.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(p for p in OUT.iterdir() if p.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                        encoding='ascii', newline='\n')
    print('PASS: staged source identities,', len(links), 'local links, complete ZIP byte readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--finalize', action='store_true')
    finalize() if parser.parse_args().finalize else archive()
