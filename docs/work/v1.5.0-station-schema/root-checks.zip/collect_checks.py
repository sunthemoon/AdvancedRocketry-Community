"""Collect exact build, resource, source and JUnit identities without writing the repository."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
OLD = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8/artifacts')
BASE = 'a0e1d8fd90bc1731a3de5c34b8d3fdf20d35ab03'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, check=True).stdout


def dump(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


artifacts = []
for file in sorted((ROOT / 'build/libs').glob('*.jar')):
    with zipfile.ZipFile(file) as z:
        assert len(z.namelist()) == len(set(z.namelist())), 'Duplicate JAR members'
    artifacts.append({'name': file.name, 'bytes': file.stat().st_size, 'sha256': digest(file.read_bytes())})
assert len(artifacts) == 3
old_api = OLD / 'advancedrocketry-community-1.20.1-1.4.0-dev-api.jar'
new_api = ROOT / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev-api.jar'
assert digest(old_api.read_bytes()) == '50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf'
def classes(path):
    with zipfile.ZipFile(path) as z:
        return {name: digest(z.read(name)) for name in z.namelist() if name.endswith('.class')}
assert classes(old_api) == classes(new_api) and len(classes(new_api)) == 27
dump('artifacts.json', {'base_commit': BASE, 'artifacts': artifacts, 'unchanged_api_classes': classes(new_api)})

scopes = ['src/main', 'src/test', 'gradle.properties']
changed = set(git('diff', '--name-only', BASE, '--', *scopes).decode().splitlines())
changed.update(git('ls-files', '--others', '--exclude-standard', '--', 'src/main', 'src/test').decode().splitlines())
dump('implementation-files.json', {path: digest((ROOT / path).read_bytes()) for path in sorted(changed)})
generated = git('ls-files', 'src/generated').decode().splitlines()
assert not git('diff', BASE, '--', 'src/generated')
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src/generated')
dump('generated-files.json', {path: digest((ROOT / path).read_bytes()) for path in generated})

suites = []
for file in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
    suite = ET.parse(file).getroot()
    suites.append({key: int(suite.attrib[key]) for key in ('tests', 'failures', 'errors', 'skipped')}
                  | {'name': suite.attrib['name'], 'sha256': digest(file.read_bytes())})
totals = {key: sum(s[key] for s in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
assert totals['tests'] == 943 and all(totals[key] == 0 for key in ('failures', 'errors', 'skipped'))
dump('junit-summary.json', {'totals': totals, 'suite_count': len(suites), 'suites': suites})
print('PASS:', totals, len(suites), 'suites;', len(artifacts), 'JARs; 27 API classes unchanged;', len(generated), 'generated files unchanged')
