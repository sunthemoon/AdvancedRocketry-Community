"""Two finite clean v1.5 starts on an unedited COPY of the retained v1.4 world.

No player expansion, new station generation, process cuts, clients or load test.
Historical source, packaged inputs, commands, logs and original backups retained.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = HISTORY / 'server-final/world'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def observe_data(world, directory):
    directory.mkdir()
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def normalize_other(name, payload):
    value = copy.deepcopy(payload)
    if name == HOST + '_satellite_missions.dat':
        clock = value.pop('clock')
        require(set(clock) == {'logical_game_time', 'last_observed_game_time'}
                and all(type(v) is int and v >= 0 for v in clock.values()), 'Invalid mission clock')
    return value


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    summary = json.loads((HISTORY / 'native-final/summary.json').read_text(encoding='utf-8'))
    require(summary['result'] == 'PASS' and summary['source_unchanged'], 'Historical receipt incomplete')
    historical_station = HISTORY / 'native-final/restored-restart/state' / STATION
    require(digest(historical_station) == digest(SOURCE / 'data' / STATION), 'Retained source station differs from native receipt')
    require(digest(HISTORY / 'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar')
            == summary['artifacts'][2]['sha256'] == '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475',
            'Historical host identity differs')
    host = support.artifact(REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar', HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(HISTORY / 'artifacts/arce-adapter-compat-test-1.0.0.jar', support.FIXTURE, '1.0.0')
    require(consumer['sha256'] == summary['artifacts'][1]['sha256'], 'Historical consumer identity differs')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    write_json(OUT / 'historical-inputs.json', {'receipt': str(HISTORY / 'native-final/summary.json'),
               'receipt_sha256': digest(HISTORY / 'native-final/summary.json'),
               'captured_station_sha256': digest(historical_station), 'old_host': summary['artifacts'][2]})
    before = observe_data(SERVER / 'world', OUT / 'before')
    old = before[STATION]
    require(old['schema_version'] == 2 and old['format_epoch'] == 'v0.9.0-beta'
            and len(old['stations']) == 2 and old['reservations'] == [], 'Unexpected historical station scope')
    require(all(s['schema_version'] == 1 for s in old['stations']), 'Historical records not schema 1')
    expected = copy.deepcopy(old)
    expected.update(schema_version=3, format_epoch='v1.5.0-orbital-station')
    for station in expected['stations']:
        station['schema_version'] = 2
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    (SERVER / 'mods').mkdir()
    for artifact in (host, consumer):
        shutil.copyfile(artifact['path'], SERVER / 'mods' / artifact['name'])
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    require((HISTORY / 'server-final/eula.txt').read_text(encoding='utf-8').find('eula=true') >= 0,
            'Disposable fixture EULA acceptance is absent')
    command = support.rocket_smoke._server_command(JAVA)
    receipts = []
    baseline_backups = fixture.inventory(SERVER / 'world' / 'advancedrocketrycommunity-backups') if (
        SERVER / 'world' / 'advancedrocketrycommunity-backups').exists() else []
    require(not baseline_backups, 'Selected native world already has migration backups')
    for phase in ('upgrade', 'restart'):
        directory = OUT / phase
        directory.mkdir()
        commands = []
        receipt = {'phase': phase, 'result': 'IN_PROGRESS'}
        write_json(directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': [host, consumer]})
        process = None
        try:
            for artifact in (host, consumer):
                require(digest(SERVER / 'mods' / artifact['name']) == artifact['sha256'], 'Installed artifact changed')
            process = server.CapturedProcess(command, SERVER, directory / 'stdout.txt')
            process.wait_for(server.READY_MARKER, 240)
            status = server.wait_for_status(port)
            support.validate_status(status, True, host['version'])
            write_json(directory / 'status.json', status)
            marker = r'\[ARCE-BETA-1002\].*migrated=1, backup=\S+-managed' if phase == 'upgrade' else r'\[ARCE-BETA-1001\].*migrated=0, backup=none'
            require(any(re.search(marker, line) for line in process.lines), 'Unexpected migration startup result')
            for station in old['stations']:
                identity = support.uuid_from_nbt(station['station_id'])
                command_text = 'arce station admin inspect ' + identity
                start = len(process.lines)
                commands.append(command_text)
                process.command(command_text)
                region = station['region']
                pad = station['landing_pad']
                expected_line = (f'region={region[0]},{region[1]}..{region[2]},{region[3]} '
                                 f'pad={pad[0]},{pad[1]},{pad[2]} orbit={station["orbit_body"]}')
                process.wait_for(re.compile(re.escape(expected_line)), 30, start_at=start)
            start = len(process.lines)
            commands.append('save-all flush')
            process.command('save-all flush')
            process.wait_for(server.SAVE_MARKER, 60, start_at=start)
            commands.append('stop')
            process.command('stop')
            require(process.finish() == 0, 'Server did not stop cleanly')
            schema.validate_log(process.lines, [])
            actual = observe_data(SERVER / 'world', directory / 'state')
            require(actual[STATION] == expected, 'Native station fields changed beyond migration versions')
            require(set(actual) == set(before), 'Native managed authority set changed')
            for name in before:
                if name != STATION:
                    require(normalize_other(name, before[name]) == normalize_other(name, actual[name]),
                            'Other authority changed beyond its mission clock: ' + name)
            backups = SERVER / 'world/advancedrocketrycommunity-backups'
            directories = list(backups.iterdir())
            require(len(directories) == 1 and directories[0].is_dir(), 'Repeated startup created another backup')
            backup = directories[0]
            manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
            require(manifest['manifestSchema'] == 2 and 'sourceSchema' not in manifest and 'targetSchema' not in manifest,
                    'Backup manifest is not per-file versioned')
            for row in manifest['files']:
                name = row['file']
                require(digest(backup / name) == row['sha256'] == digest(SOURCE / 'data' / name),
                        'Backup differs from original: ' + name)
                if row['role'] == 'authority':
                    require(row['sourceSchema'] == 2 and row['targetSchema'] == (3 if name == STATION else 2),
                            'Manifest schema differs: ' + name)
                else:
                    require(row['role'] == 'previous-copy' and name.endswith('_old')
                            and 'sourceSchema' not in row and 'targetSchema' not in row, 'Unexpected backup role')
            snapshot = fixture.inventory(backups)
            if phase == 'upgrade':
                fixture.copy_world(backups, OUT / 'migration-backups')
                baseline_backups = snapshot
            else:
                require(snapshot == baseline_backups, 'Restart modified migration backup')
            receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                           migration_lines=[line.rstrip() for line in process.lines if '[ARCE-BETA-' in line],
                           station_count=len(actual[STATION]['stations']))
        except BaseException as exc:
            receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
            if process is not None:
                process.abort()
            raise
        finally:
            receipt['exit_code'] = process.process.poll() if process is not None else None
            write_json(directory / 'receipt.json', receipt)
            write_json(directory / 'commands.json', commands)
            for name in ('latest.log', 'debug.log'):
                if (SERVER / 'logs' / name).exists():
                    shutil.copyfile(SERVER / 'logs' / name, directory / name)
            receipts.append(receipt)
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {'result': 'PASS', 'artifacts': [host, consumer], 'cycles': receipts,
               'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
               'scope': 'Two clean starts; authentic v1.4 two-station root-2 copy, no expansion/clients/process cuts/load test',
               'historical_team_coverage': 'No nonempty membership/invitations in this retained world; synthetic unit fixtures cover them'})
    print('PASS: two native starts, two station identities preserved, one byte-exact backup; original world unchanged')


if __name__ == '__main__':
    main()
