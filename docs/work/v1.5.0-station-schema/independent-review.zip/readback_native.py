"""Independent readback of completed native evidence. Does not launch a process."""
import ast
import copy
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
import uuid

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
RUN = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-station-schema-04389c908f4b406ebc03badf69358576')
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = HISTORY / 'server-final/world'
EVIDENCE = RUN / 'native'
WORLD = RUN / 'station-server/world'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MISSION = HOST + '_satellite_missions.dat'
MANAGED = {HOST + '_' + suffix + '.dat' for suffix in
           ['celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions']}
sys.path.insert(0, str(REPO / 'scripts'))
from inspect_celestial_saved_data import NbtReader

records = []


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def read(path):
    require(path.is_file() and not path.is_symlink(), 'Missing/nonregular input: ' + str(path))
    require(path.stat().st_size <= 32 * 1024**2, 'Oversized input')
    value = path.read_bytes()
    records.append({'path': str(path), 'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()})
    return value


def digest(path):
    return hashlib.sha256(read(path)).hexdigest()


def document(path):
    return json.loads(read(path))


def nbt(path):
    with gzip.GzipFile(fileobj=io.BytesIO(read(path))) as stream:
        raw = stream.read(4 * 1024**2 + 1)
    require(len(raw) <= 4 * 1024**2, 'Expanded NBT size bound')
    return NbtReader(raw).read_root()['data']


def inventory(root):
    rows = []
    for folder, children, files in os.walk(root, followlinks=False):
        for name in children + files:
            require(not (Path(folder) / name).is_symlink(), 'Linked fixture path')
        for name in files:
            path = Path(folder) / name
            raw = read(path)
            rows.append({'path': path.relative_to(root).as_posix(), 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest()})
            require(len(rows) <= 512, 'Inventory file bound')
    return sorted(rows, key=lambda row: row['path'])


def uuid_text(parts):
    require(len(parts) == 4, 'Invalid UUID input')
    value = 0
    for number in parts:
        value = (value << 32) | (number & 0xffffffff)
    return str(uuid.UUID(int=value))


summary = document(EVIDENCE / 'summary.json')
require(summary['result'] == 'PASS' and summary['source_world_unchanged'] is True, 'Root receipt is incomplete')
require([row['phase'] for row in summary['cycles']] == ['upgrade', 'restart'], 'Wrong phase membership')
original_inventory = document(EVIDENCE / 'source-world-files.json')
require(inventory(SOURCE) == original_inventory, 'Original source world changed')
names = {name for name in MANAGED if (SOURCE / 'data' / name).exists()}
require(len(names) == 4 and STATION in names, 'Authentic managed-file scope differs')
before = {name: nbt(EVIDENCE / 'before' / name) for name in names}
for name in names:
    require(read(EVIDENCE / 'before' / name) == read(SOURCE / 'data' / name), 'Before capture changed source bytes')
old_receipt = document(HISTORY / 'native-final/summary.json')
require(old_receipt['result'] == 'PASS', 'Historical receipt incomplete')
require(digest(HISTORY / 'native-final/restored-restart/state' / STATION)
        == digest(SOURCE / 'data' / STATION), 'Historical v1.4 station identity differs')
require(digest(HISTORY / 'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar')
        == old_receipt['artifacts'][2]['sha256']
        == '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475', 'Historical host mismatch')
for artifact in summary['artifacts']:
    require(digest(Path(artifact['path'])) == artifact['sha256'], 'Artifact source bytes differ')
    require(digest(RUN / 'station-server/mods' / artifact['name']) == artifact['sha256'], 'Installed artifact differs')
require(summary['artifacts'][1]['sha256'] == old_receipt['artifacts'][1]['sha256'], 'Old consumer identity changed')

old = before[STATION]
require(old['schema_version'] == 2 and old['format_epoch'] == 'v0.9.0-beta', 'Legacy root differs')
require(len(old['stations']) == 2 and not old['reservations'], 'Legacy station scope differs')
expected = copy.deepcopy(old)
expected['schema_version'] = 3
expected['format_epoch'] = 'v1.5.0-orbital-station'
for station in expected['stations']:
    require(station['schema_version'] == 1, 'Legacy record not version 1')
    require(station['members'] == station['invitations'] == [], 'Native team coverage is not empty')
    station['schema_version'] = 2
identities = [uuid_text(station['station_id']) for station in old['stations']]
expected_commands = ['arce station admin inspect ' + identity for identity in identities] + ['save-all flush', 'stop']
phase_results = []
previous_clock = before[MISSION]['clock']
for index, phase in enumerate(['upgrade', 'restart']):
    directory = EVIDENCE / phase
    receipt = document(directory / 'receipt.json')
    require(receipt == summary['cycles'][index] and receipt['exit_code'] == 0 and receipt['result'] == 'PASS',
            'Native process receipt differs')
    require(document(directory / 'commands.json') == expected_commands, 'Unexpected native action')
    launch = document(directory / 'launch.json')
    require(launch['artifacts'] == summary['artifacts'], 'Native launch artifact identity differs')
    text = read(directory / 'stdout.txt').decode('utf-8')
    require(not re.search(r'/(?:ERROR|FATAL)\]', text), 'Native log has ERROR/FATAL')
    warnings = len(re.findall(r'/WARN\]', text))
    require(warnings == receipt['log_counts']['warning_count'], 'Native warning count differs')
    marker = (r'\[ARCE-BETA-1002\].*managed=4, migrated=1, backup=\d{8}T\d{6}\.\d{3}Z-managed'
              if phase == 'upgrade' else r'\[ARCE-BETA-1001\].*managed=4, migrated=0, backup=none')
    require(re.search(marker, text) is not None, 'Native preflight marker differs')
    require('Stopping server' in text, 'Native stop marker missing')
    actual_names = {path.name for path in (directory / 'state').glob('*.dat')}
    require(actual_names == names, 'Captured authority membership differs')
    actual = {name: nbt(directory / 'state' / name) for name in names}
    require(actual[STATION] == expected, 'Station payload differs beyond schema metadata')
    for name in names - {STATION}:
        baseline = copy.deepcopy(before[name])
        observed = copy.deepcopy(actual[name])
        if name == MISSION:
            baseline.pop('clock')
            clock = observed.pop('clock')
            require(set(clock) == set(previous_clock) == {'logical_game_time', 'last_observed_game_time'}, 'Clock fields differ')
            require(all(type(clock[key]) is int and clock[key] >= previous_clock[key] >= 0 for key in clock), 'Clock moved backward')
            previous_clock = clock
        require(observed == baseline, 'Nonstation authority changed beyond mission clock')
    phase_results.append({'phase': phase, 'exit_code': receipt['exit_code'], 'stations': identities,
                          'station_sha256': digest(directory / 'state' / STATION), 'warnings': warnings})
for name in names:
    require(read(WORLD / 'data' / name) == read(EVIDENCE / 'restart/state' / name), 'Final world differs from restart capture')

backup_root = WORLD / 'advancedrocketrycommunity-backups'
directories = list(backup_root.iterdir())
require(len(directories) == 1 and directories[0].is_dir(), 'Backup count differs')
backup = directories[0]
manifest = document(backup / 'manifest.json')
require(manifest['manifestSchema'] == 2 and 'sourceSchema' not in manifest and 'targetSchema' not in manifest, 'Manifest schema differs')
expected_backup_files = names | {name + '_old' for name in names if (SOURCE / 'data' / (name + '_old')).exists()}
rows = {row['file']: row for row in manifest['files']}
require(len(rows) == len(manifest['files']) and set(rows) == expected_backup_files, 'Manifest is incomplete/duplicated')
require({path.name for path in backup.iterdir()} == expected_backup_files | {'manifest.json'}, 'Backup membership differs')
for name, row in rows.items():
    raw = read(backup / name)
    require(raw == read(SOURCE / 'data' / name), 'Backup changed source bytes')
    require(row['bytes'] == len(raw) and row['sha256'] == hashlib.sha256(raw).hexdigest(), 'Backup size/hash differs')
    if name in names:
        require(row['role'] == 'authority' and row['sourceSchema'] == before[name]['schema_version']
                and row['targetSchema'] == (3 if name == STATION else 2), 'Primary schema/role differs')
    else:
        require(row['role'] == 'previous-copy' and 'sourceSchema' not in row and 'targetSchema' not in row, 'Prior-copy role differs')
require(inventory(backup_root) == inventory(EVIDENCE / 'migration-backups'), 'Backups changed between starts')

# Independently exercise only the corrected manifest AST; never run harness main.
revised_source = read(RUN / 'native_station_check.py')
(OUT / 'native-harness-revised.py').write_bytes(revised_source)
tree = ast.parse(revised_source)
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
nodes = []
for node in ast.walk(main):
    if isinstance(node, ast.Try):
        collecting = False
        for item in node.body:
            target = item.targets[0].id if (isinstance(item, ast.Assign) and len(item.targets) == 1
                                           and isinstance(item.targets[0], ast.Name)) else None
            if target == 'manifest':
                collecting = True
            if target == 'snapshot':
                break
            if collecting:
                nodes.append(item)
require(len(nodes) == 6, 'Changed manifest AST shape; review extraction')
compiled = compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), '<revised-manifest-oracle>', 'exec')
probe = OUT / 'corrected-manifest-probe'
probe.mkdir()
for name in expected_backup_files:
    shutil.copyfile(backup / name, probe / name)
mutations = ['valid', 'empty', 'missing-row', 'duplicate-row', 'wrong-size']
probe_results = []
for label in mutations:
    candidate = copy.deepcopy(manifest)
    if label == 'empty':
        candidate['files'] = []
    elif label == 'missing-row':
        candidate['files'].pop()
    elif label == 'duplicate-row':
        candidate['files'].append(copy.deepcopy(candidate['files'][0]))
    elif label == 'wrong-size':
        candidate['files'][0]['bytes'] += 1
    (probe / 'manifest.json').write_text(json.dumps(candidate) + '\n', encoding='utf-8', newline='\n')
    scope = dict(globals(), backup=probe)
    rejected = False
    try:
        exec(compiled, scope)
    except AssertionError:
        rejected = True
    require(rejected == (label != 'valid'), 'Corrected manifest oracle result differs: ' + label)
    probe_results.append({'case': label, 'rejected': rejected})

result = {'result': 'PASS', 'kind': 'independent readback, not independent server execution',
          'source_inventory_files': len(original_inventory), 'managed_files': sorted(names),
          'backup_files': sorted(expected_backup_files), 'previous_copy_count': len(expected_backup_files - names),
          'native_phases': phase_results, 'artifacts': summary['artifacts'],
          'corrected_harness_sha256': hashlib.sha256(revised_source).hexdigest(),
          'corrected_oracle_probe': probe_results,
          'native_teams': 'empty', 'native_reservations': 'empty', 'expanded_region': 'not exercised',
          'input_hashes': records}
(OUT / 'native-readback.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: value for key, value in result.items() if key != 'input_hashes'}, indent=2))
