# Independent V150-STATION-01/02 review

Reviewer: delegated `/root/station_schema_review`; no tracked writes.
Assigned baseline/HEAD: `a0e1d8fd90bc1731a3de5c34b8d3fdf20d35ab03`.
Branch: `codex/v1.5.0-orbital-station-warp`.
Evidence timestamps use UTC; targeted execution was 2026-09-29.

## Findings first

1. **Medium — native evidence oracle accepts missing backup entries.**
   Initial Temp `native_station_check.py:145-157` iterates only the manifest rows
   present, without comparing their membership with the source managed primaries
   and `_old` companions. An empty/incomplete manifest can therefore pass the
   purported byte-exact backup check. It also omits each row's byte-count check.
   This is a validation-evidence defect, not a demonstrated production migrator
   defect. Require unique exact manifest/file membership and byte counts before
   accepting native backup evidence. The initial script is retained as
   `native-harness-initial.py`, SHA-256
   `c5919b383a9e2b1e0b81720ca9a7378baf8d9a362616924222edb15235fc5e3a`.
   `probe_initial_native_manifest.py` executes precisely the original validation
   AST at lines 145-157 against two present source authorities and zero backup
   authorities; it returned without error. `initial-manifest-probe.json` records
   that reproduction. No server, historical validator or repository file was
   modified by this probe. Root was notified before native execution.

No actionable production-code defect was found in the inspected station model,
codec, preflight migration, quarantine/build-protection or diagnostics changes.
This is scoped source review plus the independent unit rerun below, not a release
approval, native restart result, or proof that all ADR-040 obligations are done.

## Completed scope and design checks

- Inspected actual tracked diff and each explicitly named new production/test
  file, plus mandatory governance/contracts. The forbidden untracked user
  documentation bundle was neither read nor traversed.
- Registry 3 / record 2 / reservation 1 are selected independently. Other managed
  authority roots remain 2 / Beta epoch; no global format bump or API/wire change
  was introduced in this diff.
- Legacy record decoding requires original centered 512 geometry before the
  copy-and-version upgrade; current records permit only centered 512/768 squares
  and the original fixed pad. Copying preserves extra tags and byte-valued vacuum
  data during migration; ordinary known-field save behavior is unchanged.
- Negative/extreme cell arithmetic and nearest-cell lookup retain bounded,
  constant-time lookup. Full station count rejects commit before removing a
  reservation; independent restore count limits remain 4096 + 64.
- Pure payload validation avoids recursive SavedData migration calls. Runtime
  legacy load remains blocked rather than scheduling an unbacked write. Invalid,
  future or mixed registry data stays opaque and cannot expose partial authority.
- Preflight semantically validates all discovered managed sources before backup,
  stages/validates all replacements, requires atomic replacement, restores and
  verifies original bytes on ordinary commit failure, and reports incomplete
  rollback instead of success. Manifest schema 2 truthfully distinguishes each
  primary's source/target versions and prior-copy bytes. Five-backup cap remains.
- Unavailable authority now denies Space player break/place/multi-place for both
  owner/operator semantics; valid gaps and other Levels remain allowed. The
  production query introduces no chunk lookup/scan. The new GameTest was source
  reviewed, not executed by this reviewer.
- The old ordinary station flush remains unchanged. No expansion operation,
  orbit-changing mutator, or speculative warp persistence was introduced.
- Diagnostic output reports separate default and station roots. The development
  version/provenance notice retain existing licensing and unofficial branding.

## Independent commands and results

Environment: Oracle Java 17.0.7+8-LTS-224, Gradle 8.8, Windows, offline.

```text
gradlew.bat test
  --tests '*StationSchemaMigrationTest'
  --tests '*StationRegionBoundaryTest'
  --tests '*StationWorldMigrationTest'
  --tests '*WorldDataMigrationServiceTest'
  --tests '*PopulatedWorldDataPreservationTest'
  --tests '*ManagedSavedDataLoaderMigrationTest'
  --tests '*StationAccessServiceTest'
  --tests '*StationRegistrySavedDataTest'
  --tests '*StationRegistryModelTest'
  --offline --no-daemon --no-build-cache --console=plain
```

Exit **0**, BUILD SUCCESSFUL in **24 s**, 4 executed / 12 up-to-date tasks.
The `test` task executed, not UP-TO-DATE or FROM-CACHE. Its filter differs from
root's broad filter. XMLs were copied into this owned Temp directory before
releasing the exclusive JVM slot. Session 67878 is terminal; no reviewer JVM
remains running. Full stdout and command/start/end/exit are retained in
`targeted-tests.log`, `java-version.log`, `command-result.json`, and `test-results/`.

| Suite | Tests | Failures/errors/skips |
|---|---:|---:|
| ManagedSavedDataLoaderMigrationTest | 1 | 0 / 0 / 0 |
| PopulatedWorldDataPreservationTest | 18 | 0 / 0 / 0 |
| StationWorldMigrationTest | 6 | 0 / 0 / 0 |
| WorldDataMigrationServiceTest | 8 | 0 / 0 / 0 |
| StationRegionBoundaryTest | 6 | 0 / 0 / 0 |
| StationRegistryModelTest | 5 | 0 / 0 / 0 |
| StationRegistrySavedDataTest | 5 | 0 / 0 / 0 |
| StationSchemaMigrationTest | 8 | 0 / 0 / 0 |
| StationAccessServiceTest | 4 | 0 / 0 / 0 |
| **Total** | **61** | **0 / 0 / 0** |

Additional executed checks: `git diff --check` exit 0; owned
`capture_review.py` exit 0; owned `probe_initial_native_manifest.py` exit 0
(demonstrating the original oracle defect, not declaring native success).
Two exploratory searches named nonexistent `docs/adr` / `docs/operations`
directories; actual contracts were read from `docs/decisions`. These were
inventory misses, not suppressed test failures.

## Metadata follow-up boundary

After the independent 61-test run, root reported its full run had one failure:
the old v1.4 literal expectations in `ModMetadataTest`. Independently read the
actual subsequent diff: only three expected literals changed to the version and
description now in `gradle.properties`; all assertions remain. Static review
found no weakened check. `ModMetadataTest` is included in the final inspected
hash inventory but was **not** in this reviewer's executed selection. Root's
later full rerun must supply its execution result; it is not inferred here.
No additional reviewer JVM was started during root's full command.

## Inspected baseline/current identities

`inspected-file-hashes.json` records 55 explicitly inspected paths, working-byte
SHA-256/length, baseline blob SHA-256/length or absent, and normalized content
change. `baseline/` and `current/` preserve those exact bytes. The initial
54-file inventory/diff are separately retained before the metadata follow-up.
Context document snapshots are not a final review of root's concurrent later
README/changelog/status/evidence edits.

Principal production identities (baseline -> reviewed working bytes):

```text
SavedDataSchemaMigrator.java
4f3396003d6ebdcefb46f55e9ecfdf706e8fd49b9c942cca0c1e869227d431c9
e7b5e6f079144bef99bf80eb69d66c9333f5a23d213d37519bb7d61bc411cdbc

WorldDataMigrationService.java
faef8a8b398a2b3806aa5e70589a147e9e7c602bc93296670aa093fb796bb715
4dca7f9344579fc78593d7892b53f654c6f9ddd947f6210096475cb7a4efafe7

StationRegistrySavedData.java
d326d0b00163a5b693848461c9fd5c37d04727c0b97a6c43d1bbd811f1a5090c
a874ad7b644de112d8c623ebbfa507d177c2af2ea9ed00c25ee5bc12c266569b

StationRegistryPayload.java
absent
6f4a5dded3bfacf45885b19192389194a6110559895a2dc80a46b9ff55ec9f31
```

Inventory SHA-256: `1c052c17ca8cad33f729dfc424030d48cf86bcbad453c9bc408371093ab8bd34`.
JUnit summary SHA-256: `21f2604d34e9262fd81912e3eada13c60e1230e9174417577eec6b1af6a04764`.
Test stdout SHA-256: `3bb505ad0cd97cb5157b23f10d5150bebe90c914625995a2175c6ad37b7f50d9`.

## Native harness reuse assessment

The Temp harness uses copied authentic v1.4 station bytes, pinned old host and
consumer identities, and two bounded clean v1.5 starts. Inspected reused functions
provide disjoint copy/inventory bounds, strict packaged mod/status identity,
bounded NBT decoding, process ownership/stop handling, localhost configuration,
and strict log-error scanning. It does not invoke historical v090/v100 root-2
or manifest-schema-1 validators. New-schema expectations are explicit rather
than broadening historical acceptance. Installed old consumer identity is
preserved to avoid removing historical world providers.

The original source is copied without NBT patching; only the disposable copy is
started. Whole source inventory is compared afterward. Two existing station
records are compared before/after with only root/record versions and epoch
changed. No reservation or nonempty native team is exercised. Non-station managed
payloads are compared allowing only a validated mission-clock advance. This
does not inspect arbitrary rocket/chunk/player inventories or prove expansion,
team persistence, full old-world preservation, real clients or crash safety.

Fix finding 1 and review its revised oracle before citing a native PASS. This
review does not itself execute the native harness.

## Residual coverage and Required Gate status

- Required short full build/DataGen/GameTests and native save/restart are root's
  remaining execution evidence at this report boundary, not supplied by 61 unit
  cases. A copied authentic two-station world with empty teams is narrower than
  complete STATION-04 native coverage.
- Synthetic `Error` interruption tests intentionally do not prove OS process-cut,
  hardware power-loss, directory fsync, or filesystem interoperability. Atomic
  move refusal is injected; no unsupported physical filesystem was tested here.
- Full-count geometry/registry tests exercise 4096 committed + 64 reservations in
  the model, not a maximum-size native world. Composite serialized-size limits,
  production player event dispatch, and actual-client messages need their proper
  integration evidence.
- Expansion/checkpointed candidate writes, native expanded-region restart,
  orbit/warp/star content, V1/V2, and scheduled reference-load acceptance remain
  unfinished current-version work. Old ordinary flush semantics are not newly
  crash-atomic.
- **Current version does not satisfy all Required G0-G9.** No Gate status, release
  candidate, branch/tag, tracked source/test file or public documentation was
  changed by this reviewer. Recommended next work: finish the bounded schema
  evidence, resolve the harness finding, then continue V150-STATION-03/04.
