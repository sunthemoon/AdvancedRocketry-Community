"""Run only the original harness's manifest-validation AST over missing backups."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'manifest-probe-source'
backup = ROOT / 'manifest-probe-backup'
SOURCE.mkdir()
(SOURCE / 'data').mkdir()
backup.mkdir()
STATION = 'advancedrocketrycommunity_stations.dat'
names = [STATION, 'advancedrocketrycommunity_celestial.dat']
for name in names:
    (SOURCE / 'data' / name).write_bytes(('original authority ' + name).encode('ascii'))
(backup / 'manifest.json').write_text(
    json.dumps({'manifestSchema': 2, 'files': []}) + '\n', encoding='utf-8', newline='\n')

original = ROOT / 'native-harness-initial.py'
tree = ast.parse(original.read_text(encoding='utf-8'))
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
nodes = []
for node in ast.walk(main):
    if isinstance(node, ast.Try):
        for index, item in enumerate(node.body):
            if (isinstance(item, ast.Assign) and len(item.targets) == 1
                    and isinstance(item.targets[0], ast.Name) and item.targets[0].id == 'manifest'):
                nodes = node.body[index:index + 3]
                assert isinstance(nodes[1], ast.Expr) and isinstance(nodes[2], ast.For)
                break
assert len(nodes) == 3


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


selected = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
exec(compile(selected, str(original), 'exec'), globals())
result = {
    'original_harness_sha256': digest(original),
    'executed_lines': [min(node.lineno for node in nodes), max(node.end_lineno for node in nodes)],
    'present_source_authorities': names,
    'present_backup_authorities': [],
    'manifest_rows': [],
    'validation_returned_without_error': True,
    'scope': 'Extracted manifest oracle only; no native harness/server execution',
}
(ROOT / 'initial-manifest-probe.json').write_text(
    json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result, indent=2))
