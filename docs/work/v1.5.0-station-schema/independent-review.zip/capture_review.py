"""Capture explicitly reviewed files and independent JUnit evidence, read-only in repo."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = 'a0e1d8fd90bc1731a3de5c34b8d3fdf20d35ab03'
PREFIX = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
TEST = 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/'
MAIN_FILES = '''diagnostics/BetaOperationalReport.java
persistence/migration/ManagedSavedDataType.java
persistence/migration/SavedDataSchemaMigrator.java
persistence/migration/WorldDataMigrationService.java
persistence/migration/ManagedSavedDataPayloadValidator.java
persistence/migration/BoundedSavedDataIo.java
persistence/migration/BetaWorldMigrationEvents.java
station/model/StationGridCell.java
station/model/StationLimits.java
station/model/StationRegion.java
station/model/StationRegistryModel.java
station/model/StationState.java
station/model/StationReservation.java
station/model/StationEnvironmentProfile.java
station/persistence/StationNbtCodec.java
station/persistence/StationRegistryPayload.java
station/persistence/StationRegistrySavedData.java
station/service/StationAccessService.java
station/service/StationManager.java
gametest/StationProtectionGameTests.java'''.splitlines()
TEST_FILES = '''ModMetadataTest.java
diagnostics/BetaOperationalReportTest.java
persistence/migration/ManagedSavedDataLoaderMigrationTest.java
persistence/migration/PopulatedWorldDataPreservationTest.java
persistence/migration/SavedDataSchemaMigratorTest.java
persistence/migration/WorldDataMigrationServiceTest.java
persistence/migration/StationWorldMigrationTest.java
station/model/StationRegionBoundaryTest.java
station/model/StationRegistryModelTest.java
station/persistence/StationRegistrySavedDataTest.java
station/persistence/StationSchemaMigrationTest.java
station/service/StationAccessServiceTest.java'''.splitlines()
CONTEXT_FILES = '''AGENTS.md
PROJECT-CONFIG.md
PRODUCT.md
UPSTREAM.md
NOTICE.md
docs/01-PORTING-PRINCIPLES.md
docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md
docs/04-VERSION-ROADMAP.md
docs/05-MASTER-TEST-PLAN.md
docs/06-RELEASE-AND-ACCEPTANCE-GATES.md
docs/08-ASSET-LICENSE-AND-PROVENANCE.md
docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md
docs/16-POST-1.0-VERSION-ROADMAP.md
docs/17-V1PLUS-QUALITY-BUDGETS.md
docs/decisions/ADR-039-V150-DEVELOPMENT-BASELINE-EXCEPTION.md
docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md
docs/releases/v1.4.0/GATE-STATUS.md
docs/status/CURRENT_VERSION.md
docs/versions/V1.5.0-ORBITAL-STATION-WARP.md
docs/work/v1.5.0-implementation-log.md
docs/provenance/v1.5.0-development-metadata.md
gradle.properties
src/test/resources/migrations/v150/stations-v2.snbt'''.splitlines()


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, check=False)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


head = git('rev-parse', 'HEAD')
if head.returncode or head.stdout.decode().strip() != BASE:
    raise RuntimeError('HEAD changed from assigned baseline')
paths = sorted(set([PREFIX + p for p in MAIN_FILES] + [TEST + p for p in TEST_FILES] + CONTEXT_FILES))
rows = []
for relative in paths:
    if relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/'):
        raise RuntimeError('Forbidden input')
    current = (ROOT / relative).read_bytes()
    snapshot = OUT / 'current' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(current)
    base = git('show', BASE + ':' + relative)
    row = {'path': relative, 'current_bytes': len(current), 'current_sha256': sha(current)}
    if base.returncode == 0:
        snapshot = OUT / 'baseline' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(base.stdout)
        row.update(baseline_bytes=len(base.stdout), baseline_sha256=sha(base.stdout),
                   normalized_content_changed=base.stdout != current.replace(b'\r\n', b'\n'))
    else:
        row.update(baseline_bytes=None, baseline_sha256=None, normalized_content_changed=True)
    rows.append(row)

write_json('inspected-file-hashes.json', {
    'baseline': BASE,
    'head': head.stdout.decode().strip(),
    'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'files': rows,
})
diff = git('diff', '--no-ext-diff', BASE, '--', *paths)
if diff.returncode:
    raise RuntimeError(diff.stderr.decode())
(OUT / 'reviewed-tracked.diff').write_bytes(diff.stdout)
check = git('diff', '--check', '--', *paths)
(OUT / 'diff-check.log').write_bytes(check.stdout + check.stderr)
write_json('diff-check-result.json', {'exit_code': check.returncode, 'command': 'git diff --check -- <explicit reviewed paths>'})

suites = []
for file in sorted((OUT / 'test-results').glob('TEST-*.xml')):
    suite = ET.parse(file).getroot()
    suites.append({
        'name': suite.get('name'), 'tests': int(suite.get('tests')),
        'failures': int(suite.get('failures')), 'errors': int(suite.get('errors')),
        'skipped': int(suite.get('skipped')), 'time': float(suite.get('time')),
        'timestamp': suite.get('timestamp'), 'xml_sha256': sha(file.read_bytes()),
    })
summary = {key: sum(row[key] for row in suites) for key in ['tests', 'failures', 'errors', 'skipped']}
summary.update(suite_count=len(suites), suites=suites)
write_json('junit-summary.json', summary)
print(json.dumps({'reviewed_files': len(rows), 'junit': {key: summary[key] for key in ['suite_count', 'tests', 'failures', 'errors', 'skipped']}, 'diff_check_exit': check.returncode}, indent=2))
