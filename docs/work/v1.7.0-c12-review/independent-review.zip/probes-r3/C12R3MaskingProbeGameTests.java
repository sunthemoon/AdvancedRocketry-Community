package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/**
 * C12 review round 3, reviewer-only (not part of the repository): EntitySections.whenLoaded must not turn a failure
 * into a pass. Both tests are optional and are EXPECTED TO FAIL; each failure confirms that the wrapper does not mask.
 */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class C12R3MaskingProbeGameTests {
    private C12R3MaskingProbeGameTests() {
    }

    /** The entity section never loads (a chunk a million blocks away): the wait must time out as a failure. */
    @GameTest(template = "empty", batch = "c12r3_masking_probe", timeoutTicks = 40, required = false)
    public static void c12r3ProbeEntitiesThatNeverLoadFail(GameTestHelper helper) {
        EntitySections.whenLoaded(helper, () -> { }, new BlockPos(1_000_000, 2, 0));
    }

    /** The section loads, but the body fails an assertion: the test must fail, not succeed. */
    @GameTest(template = "empty", batch = "c12r3_masking_probe", timeoutTicks = 40, required = false)
    public static void c12r3ProbeAFailingBodyFails(GameTestHelper helper) {
        EntitySections.whenLoaded(helper, () -> helper.fail("C12R3 probe: body assertion failed"), BlockPos.ZERO);
    }
}
