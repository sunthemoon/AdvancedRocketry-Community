# C12 independent review — round 2 (fix commits)

Date: 2026-10-02. Reviewer: independent, read-only (same reviewer as round 1, `REVIEW.md`).
Branch `codex/v1.7.0-endgame-systems`. Reviewed range **`616b9fd0..3c681dd8`**
(19 commits, one per finding plus the review log entries). Round 1 reviewed `95e22b5`;
`616b9fd0` adds two C13 commits on top of it (`9470f27` timings, `616b9fd` release-test
hooks), which are not part of this review except where a fix touches them.

The tree was exported with `git archive 3c681dd8` into
`C:/Users/Administrator/AppData/Local/Temp/arce-v170-c12-review-k7q2/tree-r2`; every
build, test and probe ran there. Nothing in the repository was written, and the
untracked `AdvancedRocketry-Community-v1plus-Development-Docs/` folder was not opened.
No Gate, candidate or tag is claimed.

## 1. What I read

- Every commit of the range, with its diff: `ed1e453` (H1), `62ec8b6` (M1), `0541991`
  (M2), `927a0b5` (log), `e234cf5` (M3), `00a5f31` + `644c903` (I6), `55392fb` (L2),
  `68de387` (L3), `e1dba3c` (L4), `81e0c27` (I1), `8f11659` (L6), `20e3a88` (L1),
  `139e1fb` (L5), `c8483eb` (L7), `b495bcc` (I5), `c454676` (I2), `3a16fba` (I4),
  `3c681dd` (I3).
- The final state of the changed production classes: `TransitDestinationState`,
  `TransitLedger`, `TransitOperations`, `EndgameService`, `BarrierSpacing`,
  `EndpointObservations`, `EndgameRoot` (restore), `ElevatorPairs`, `ElevatorRides`,
  `ElevatorRedirectRule`, `ElevatorGuard`, `ElevatorCargo`, `EndgameDevices` (status),
  `EndgameCommands` (retire, forget, settle, evict), `TransitCommands` (resolve), the
  `endgame.elevator.model` package, `build.gradle` (`runGameTestServer`).
- The new and changed tests: `TransitLedgerTest` (H1, M1 ×3, L3, L4),
  `TransitOperationsTest` (L2, M3), `BarrierSpacingTest`, `TransitCodecTest` (H1),
  `ElevatorGameTests` (zone, spacing, redirect, automation, ticket and status checks),
  `BlackHoleGeneratorGameTests` (tickets, empty burn at a full buffer).
- The implementation log section "C12 review fixes" and the provenance record for the
  `build.gradle` change.
- Contract text re-checked: ADR-054 §5.1, §7 (barrier spacing), §9 (retired IDs, resolve,
  retirement without live state, selection), §10 (restore), §11 (registration, pruning,
  redirects, purge), §13 (status); ADR-059 §3–§7.

## 2. What I ran (exported tree at `3c681dd8`, `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, Gradle 8.8 `--offline`)

| Command | Result | Log |
|---|---|---|
| `./gradlew clean build test runData runGameTestServer --offline` | **BUILD SUCCESSFUL** in 5 min 28 s. JUnit: **1,363 tests / 251 suites, 0 failures, 0 errors, 0 skipped** (1,350 in round 1, plus 13). GameTest (fresh world, via the new `doFirst`): **All 333 required tests passed** (329 in round 1, plus 4). 18 `ERROR` lines, 0 `FATAL`, the same failure-injection set as before | `logs-r2/full-run1.log` |
| DataGen check: SHA-256 of every file under `src/generated` before and after `runData` | Every pre-existing file is byte-identical. The only additions are eight files under `src/generated/v1.7/resources/.cache/`, which `.gitignore:33` ignores | `logs-r2/generated-{before,after}.sha256` |
| `./gradlew test --offline --tests '*C12ReviewProbeTest'` (the round-1 probes, adapted to the new API, plus one new probe) | p1, p1b, p2, p3, p4, p5 now **fail at their `PROBE:` assertions**: the round-1 defects are gone. New probe p6 **passes**, confirming C12R2-I2 | `logs-r2/probe-run.log`, `logs-r2/TEST-…C12ReviewProbeTest.xml` |
| `./gradlew runGameTestServer --offline`, three more runs (each deletes the world first) | **All 333 required tests passed** in each of the three runs. Each run generated a new world (spawn preparation 11.6 s, 15.5 s and 12.5 s, against about 3 s for a kept world in round 1) | `logs-r2/gametest-run{2,3,4}.log`, `logs-r2/gametest-repeat-summary.txt` |
| Mutation check of the H1 restore rule | Removing the source and paid-endpoint rule from `finishRestore`: **all 31 endgame suites (184 tests) still pass**. The rule is untested (C12R2-I5); the original file was restored, SHA-256 `20794d75…1c24` | `logs-r2/mutation-h1.log` |

Adapting the probes (`probes-r2/C12ReviewProbeTest.java`) needed only API changes:
`EndgameService::pinned` (removed by I1) became `root::pinned`, and p5 now runs the
retire command's new operation, `TransitLedger.retire(root, id)` (L4). The scenarios and
assertions are unchanged.

| Probe | Round 1 (`95e22b5`) | Round 2 (`3c681dd8`) | Failure message in round 2 |
|---|---|---|---|
| p1 (operator eviction, then registration) | pass (defect) | **fail** | `PROBE: the root still loads` |
| p1b (per-owner cap eviction) | pass (defect) | **fail** | `PROBE: the root still loads` |
| p2 (hub with 64 records) | pass (defect) | **fail** | `PROBE: the other endpoint claimed its arrived cargo` |
| p3 (resolve of a returning `MISSING` source) | pass (defect) | **fail** | `PROBE: the entry was returned` (returned = 1) |
| p4 (same-ID copy in another chunk) | pass (defect) | **fail** | `PROBE: nothing registered although the source's own chunk was never saved` |
| p5 (refused retire of a tombstoned ID) | pass (defect) | **fail** | `PROBE: the refused retire did not prune the stub` |
| p6 (new: resolve after a purge of a claimed record) | — | **pass** (C12R2-I2) | — |

## 3. Verdicts

| Part | Round 1 | Round 2 |
|---|---|---|
| **C12a** black-hole generator | Accept | **Accept** (I3 test gaps closed) |
| **C12b** transit ledger | Accept with required changes (H1, M1) | **Accept** (new findings are Info only) |
| **C12c** railgun | Accept | **Accept** |
| **C12d** space elevator | Accept with required changes (M2, M3) | **Accept** (new findings are Info only) |

New findings: Critical 0, High 0, Medium 0, Low 1, Info 6 (§5).

## 4. Status of the round-1 findings

| ID | Sev. | Fix | Status | Evidence and notes |
|---|---|---|---|---|
| C12R-H1 | High | `ed1e453` | **Fixed** | `EndgameRoot.finishRestore` checks only the source and the paid endpoint; both are always pinned while a record names them (a source is `ACTIVE` at registration, a paid endpoint at its claim), so only the destination can be unknown, which ADR-054 §11 step 2 allows. Probes p1/p1b now fail. An unknown destination reads as `DESTINATION_MISSING`, is redirectable, and is ignored by the station guard. If an empty copy with that ID registers again later it claims the record once, which is a legitimate delivery. See C12R2-I5 on the changed codec test |
| C12R-M1 | Medium | `62ec8b6` | **Fixed** | Only a record with an applicable row costs budget; a budget-cut pass stores `resumeAt` and the next pass starts there; `cursor = id` after every served endpoint, so the next tick starts at the next one. Probe p2 now fails. I checked that the incoming gate and receipt drop, which now also run after a cut pass, never act on a record whose row was cut (an unrecovered `ARRIVED` record does not move; nothing unacknowledged drops), and that two hubs alternate without starving the others. Work stays bounded: rows are evaluated only for the records that name a loaded endpoint (at most 256 records, at their destination or paid endpoint), and the per-endpoint `forEndpoint` scan is the same as in round 1 (a C13 cost item, not a regression) |
| C12R-M2 | Medium | `0541991` | **Fixed** | The batch owner is `root.endpoint(ride.departure())`'s owner (ADR-054 §5.1); an unindexed departure fails closed with `TARGET_PROTECTED`. The new zone GameTest covers both directions of the allow list |
| C12R-M3 | Medium | `e234cf5` | **Fixed** | `BarrierSpacing` implements the 20-tick shared spacing, the 100-tick per-station cooldown (binds; owner redirects into a pair's station via `Route.station`), owner resolves, unbinds counting toward the spacing, and `exempt_barriers` in the status. Refusals happen before any change. Every existing caller is checked in §5 (C12R2-I3, C12R2-I4) |
| C12R-L1 | Low | `20e3a88` | **Fixed** | The target's pair must name the station whose region holds the record's source or destination (index or tombstone), checked through the same `ElevatorGuard.inRegion` that the deletion guard uses. GameTest with two stations. Residual edge case in C12R2-I6 |
| C12R-L2 | Low | `55392fb` | **Fixed** | `root.retired(id)` covers a `MISSING` record; probe p3 now returns the entry. An unknown, frozen ID (an evicted tombstone) still destroys, as ADR-054 §9 requires |
| C12R-L3 | Low | `68de387` | **Fixed** | Sections carry their position and apply only at the ID's recorded position (index record, `MISSING` record, young or settled tombstone) in the observed chunk. Probe p4 now fails. IDs with no record or tombstone (awaiting registration, or frozen after the registration freeze) lose their transit observations; they cannot hold contents that need them (escrow and claims need a durable registration; frozen endpoints run no rows), so nothing regresses. Stub pruning still sees a paid endpoint's own section at its recorded position |
| C12R-L4 | Low | `e1dba3c` | **Fixed** | `TransitLedger.retire` refuses an ID with no index record before it changes anything; probe p5 now keeps the stub. See C12R2-I1 (a dangling Javadoc block) |
| C12R-L5 | Low | `139e1fb` | **Fixed** | `ride_tickets=` in the device status line comes from `ElevatorRides.tickets()` (one per pending ride; a ride ends within about 263 ticks, inside the ticket's 300-tick lifespan, so the count matches the tickets held). The literal is gone |
| C12R-L6 | Low | `8f11659` | **Fixed** | `endgame.root` imports only `endgame.elevator.model` and `endgame.transit`; `endgame.elevator.model` imports only `endgame.model`. No cycle remains (`grep`) |
| C12R-L7 | Low | `c8483eb` | **Fixed** | An automatic launch never takes the operator exemption; GameTest with an online operator owner |
| C12R-I1 | Info | `81e0c27` | **Fixed** | Predicate removed; callers pass `root::pinned` |
| C12R-I2 | Info | `c454676` | **Addressed** | Class-size notes recorded (TransitLedger 554, EndgameRoot 551, EndgameService 524, BlackHoleGeneratorBlockEntity 552, laser drill 593); none over 800 lines; no `net.minecraft.client` in common code |
| C12R-I3 | Info | `3c681dd` and each fix's tests | **Addressed** | Service tests for the orchestration findings; generator ticket counts and empty burn at a full buffer; the `ELEVATOR_REFERENCES` reason; a stop releasing a pending ride's ticket (calls `ElevatorRides.clear`, which `EndgameModule` wires to `ServerStoppingEvent`). `ARRIVAL_UNLOADED` stays a unit test only, as recorded |
| C12R-I4 | Info | `3a16fba` | **Documented**, with an inaccuracy | See C12R2-I2 |
| C12R-I5 | Info | `b495bcc` | **Fixed** (no automatic test, as recorded) | The pair is removed again by a coalesced change and the bind answers `ROOT_BUSY`. If the failed write actually reached disk, a restart shows the pair, which fails safe (warps refused, unbind always possible) |
| C12R-I6 | Info | `00a5f31`, `644c903` | **Changed; diagnosis incomplete** | See C12R2-L1 |

## 5. New findings (round 2)

| ID | Sev. | Part | One line |
|---|---|---|---|
| C12R2-L1 | Low | test infrastructure (I6) | The recorded cause of the flaky rocket GameTests (a world kept between runs) does not cover the round-1 failure, which happened on a fresh world |
| C12R2-I1 | Info | C12b/C12d | Two Javadoc blocks were left dangling by the fixes (`TransitLedger.retire`, `EndgameService.barrierSpacing`), and two methods lost theirs |
| C12R2-I2 | Info | C12b (I4 note) | The I4 note says an operator resolves the endpoint to discard a purged claim's payload; at a registered endpoint a resolve does nothing to it |
| C12R2-I3 | Info | C12d/C12b (M3) | An admitted spaced request uses up its spacing and its station's cooldown even when it then changes nothing |
| C12R2-I4 | Info | tests (M3) | GameTests share the server-wide `BarrierSpacing` across batches; only the current batch order keeps spaced requests of different batches 20 ticks apart |
| C12R2-I5 | Info | C12b (H1) | The changed codec test of an unknown source passes through the `dispatched_through` check, so nothing tests the source and paid-endpoint restore rule on its own |
| C12R2-I6 | Info | C12d (L1) | Elevator cargo first redirected to its source, and then left without both ends, no longer names its terminal side: the station's rebuilt pair is refused and only a purge remains |

### C12R2-L1 (Low, test infrastructure) — the I6 diagnosis does not explain the round-1 failure

**Where.** Commits `00a5f31`/`644c903` (`build.gradle:259-265`, `doFirst { delete
file('build/gametest/world') }`) and the log entry "C12R-I6": "the cause is a GameTest
world kept between runs in `build/gametest/world`".

**Evidence.** In round 1 the reviewed tree was a fresh `git archive` export, so its first
`runGameTestServer` created a new world: `logs/gradle-gametest-baseline.log` shows 26
"Preparing spawn area" lines and "Time elapsed: 12755 ms" (world generation). That run
failed both `RocketGameTests.fuelLoaderFuelsOnlyOwnedNearbyLoadedRocketAtFixedRate` and
`RocketAdapterFailureGameTests.unavailableProviderDoesNotStarveALaterRecoverableTransaction`.
The second run, on the world the first one kept (7 lines, 3,023 ms), passed all 329. So at
least one failure of each test happened on a fresh world, which the new `doFirst` cannot
prevent:
- `unavailableProvider…` fails on `level.areEntitiesLoaded(...)` ("Fixture entity chunk is
  not ready for recovery", `RocketAdapterFailureFixture.java:119-120`). That is
  asynchronous entity-section loading, which is slower while a fresh world is still being
  generated.
- `fuelLoader…` (40-tick timeout) spawns rocket entities next to the test area. Its
  fresh-world failure means the stray rocket, if that is the cause, came from a test of
  the *same* run, which a world deletion cannot prevent (a hypothesis; I did not isolate
  the stray entity).

**Round 2.** Four `runGameTestServer` runs at `3c681dd8`, each on a newly generated world
(the full run and three repeats; spawn preparation 11.6 to 15.5 s), passed all 333. So
the failures did not recur here and are intermittent. Both round-1 failures happened in
`defaultBatch:1`, where about 100 tests run in parallel, in the same tick (08:28:41),
which points to load and cross-test timing inside one run rather than to the kept world.
I rate this Low because the log records a root cause that the evidence contradicts for at
least one occurrence, and the GameTest suite is a required Gate.

**Suggested fix.** Keep the fresh world, which removes accumulation across runs, but
record the diagnosis as partial. Make the two tests robust: wait (`thenWaitUntil`) for
`areEntitiesLoaded` instead of asserting it once, and give the fuel-loader test a
private batch or count only the rockets it spawned. Note that a fresh world adds about 10 s
of generation to every run.

### C12R2-I1 (Info) — dangling Javadoc blocks

`TransitLedger.java:503-512`: the old Javadoc of `retireWithoutLiveState` now sits
directly above the new Javadoc of `retire` (two consecutive `/** … */` blocks), so it
documents nothing and `retireWithoutLiveState` has none. `EndgameService.java:87-89`: the
Javadoc of `transitOperations()` ("Operator and owner actions on the ledger…") now sits
above the Javadoc of `barrierSpacing()`, and `transitOperations()` (line 93) has none. Move
each block back above its method.

### C12R2-I2 (Info) — the I4 note's remedy does not work

The log entry for C12R-I4 says a purge of a `CLAIMED` record leaves the payload to the paid
endpoint's incoming gate, and "to discard such a payload, an operator resolves the endpoint
instead". At a registered endpoint, `TransitOperations.resolve` handles only frozen
conflicts (`if (!frozen && !conflicts.contains(key)) continue;`), so the resolve does nothing
and the gate still delivers the payload. Breaking the endpoint does not discard it either: a
removal treats an incoming payload whose record is gone as the endpoint's own content and
drops it as items. Probe `p6_aResolveOfARegisteredEndpointLeavesAPurgedClaimsPayloadAlone`
passes (`Resolved` is all zero and the payload stays incoming). No duplication or loss;
correct the note, which the C13 operator guide will copy. There is no command that
discards such a payload; if one is needed, it needs a contract change.

### C12R2-I3 (Info) — admitted spaced requests use up their slot even when nothing changes

`BarrierSpacing.admit` records the request when it admits it, which is before the work.
The slot is spent although nothing changes in these cases:
- a bind whose barrier write fails is taken back (C12R-I5) and answers `ROOT_BUSY`, but its
  station cannot retry for 100 ticks (`ElevatorPairs.java:137-161`);
- an owner redirect whose pre-flush of a pending root fails answers `ROOT_BUSY` after
  `admit` (`TransitOperations.java:113-120`);
- an owner resolve is admitted in `TransitCommands.resolve` before the resolve finds
  anything to do, so a resolve with nothing frozen still takes the server-wide slot.

None of these lets anything through (the error is conservative), and ADR-054 §7 only
requires refusals before a change. If retries after a failed write matter, admit after the
write or release the slot on these paths. Note also, for the operator guide, that every
unbind, including an operator's, starts the shared 20-tick spacing for all players' binds,
owner redirects and owner resolves.

### C12R2-I4 (Info, unconfirmed) — GameTests couple through the server-wide spacing

`BarrierSpacing` is server-wide runtime state, and the GameTest server runs every batch in
one server. Non-operator binds (`ElevatorGameTests.java:189, 273, 397, 535`), the
cargo test's player unbind, and the railgun menu test's owner resolve each use the
20-tick slot. A batch's first bind comes about 1 to 21 ticks after the batch starts, so a
spaced request at the end of one batch can refuse the next batch's bind with `ROOT_BUSY`.
The current batch order, which vanilla derives from the batch names' hash order,
places other batches between them (for example `endgame_elevator_spacing`, then
`flight_recovery`, then `endgame_railgun_menu`), so all runs passed. Adding or renaming a
batch can change that order. Use operator binds where spacing is not under test, or clear
the spacing in a `@BeforeBatch`.

### C12R2-I5 (Info) — the source and paid-endpoint restore rule has no isolating test

`ed1e453` changed `TransitCodecTest` (lines 120-128): the "orphan" case now replaces the
record's **source** with an unknown UUID and expects `IllegalArgumentException`. The same
root then also fails the next check ("a transit record is above its source's
dispatched_through", because `dispatched_through` of the unknown source is 0), so the
assertion holds without the source rule. No test covers an unknown paid endpoint.

**Mutation check (confirms the finding).** With the source and paid-endpoint rule removed
from `EndgameRoot.finishRestore` (the loop at `EndgameRoot.java:508` iterating over an
empty array), all 31 endgame JUnit suites (184 tests) still pass (`logs-r2/mutation-h1.log`).
I restored the file byte for byte (SHA-256 `20794d75…1c24`).

Give the case a `dispatched_through` entry for the new source (or test the paid endpoint)
so only the rule under test can reject it.

### C12R2-I6 (Info) — the L1 region rule loses a twice-orphaned elevator transfer

`ElevatorRedirectRule.java` (L1): a target other than the source must be in the pair of
the station whose region holds the record's **source or destination**. A redirect
overwrites `destination`. If elevator cargo from anchor A to terminal T is first redirected
back to A (T removed) and A is then removed before it claims, the record names A twice and
neither is in the station's region. The station's rebuilt pair is then refused
(`ROUTE_REFUSED`), and so is any operator redirect, because the route rule binds operators
too; only `transfer purge`, which destroys the payload, remains. ADR-059 §6 / R3-L4 intends
that "a pair rebuilt after both ends were removed can still receive it". This needs two
removals around one redirect, so it is Info. A fix would keep the original terminal side
(or its station) on the record, or let an operator choose any station's current pair of the
original destination's kind.

## 6. Limits

- No forced-stop crash testing (C13); no client, V1 or multiplayer checks.
- I5's failed-write path and M3's interactions with failed writes were checked by
  reading, as no test can make the root write fail.
- The branch moved on during this round (at the end `HEAD` was `aab2cb85`). Every result
  here is pinned to `3c681dd8` through the exported tree.
