# C12 independent review — v1.7.0 slices C12a–C12d

Date: 2026-10-02. Reviewer: independent, read-only. Branch
`codex/v1.7.0-endgame-systems`, reviewed commit **`95e22b5`** (range
`e5d267a^..95e22b5`: C12a `e5d267a`, the C11 review fixes, C12b `f17a134`..`34ce112`,
C12c `05695e9`..`d75260c`, C12d `3e2b1d4`..`95e22b5`).

The reviewed tree was exported with `git archive 95e22b5` into
`C:/Users/Administrator/AppData/Local/Temp/arce-v170-c12-review-k7q2/tree`; every
build, test and probe ran there. Nothing in `D:/GitHub/AdvancedRocketry-Community`
was written, and the untracked `AdvancedRocketry-Community-v1plus-Development-Docs/`
directory was not opened. No Gate, candidate or tag is claimed.

## 1. What I read

- `AGENTS.md` §3 (scope, architecture, file size, dependency direction).
- Contracts: ADR-054 (whole text, with focus on §2, §3, §4, §7, §9, §9.1, §10, §11,
  §12, §13), ADR-056, ADR-057, ADR-059 (with the ADR-044/045 interlock parts).
- Packets: `docs/work/v1.7.0-c12a-black-hole/VERIFICATION.md`,
  `…-c12b-transit-ledger/VERIFICATION.md`, `…-c12c-railgun/VERIFICATION.md`,
  `…-c12d-space-elevator/VERIFICATION.md`; the implementation log sections C12a–C12d;
  the C11 review packet (format, and its accepted C11R-I1 on `hasNeighborSignal`).
- Production code, line by line: `endgame/transit/*` (rules, record, key, outbox,
  payload, codec, table, source/destination state, tags, view, endpoint, limits),
  `endgame/service/{TransitLedger, TransitOperations, EndgameService,
  EndpointObservations, EndpointRegistrations}`, `endgame/root/{EndgameRoot,
  EndgameSavedData, EndgameRootCodec (head), Tombstone}`,
  `endgame/command/{TransitCommands, ElevatorCommands, EndgameCommandSources,
  EndgameCommands (C12 diff)}`, `endgame/cargo/*`, `endgame/railgun/*` (block, block
  entity, launcher, launch, route, menu, redirect rule), `endgame/elevator/*` (all),
  `endgame/blackhole/{BlackHoleGeneratorBlockEntity, BlackHoleBurn, BlackHoleData,
  BlackHoleDataReloadListener}`, `endgame/device/{EndgameDeviceBlock,
  EndgameDeviceBlockEntity, EndgameDeviceMenu, EndgameItemSlot, RoundRobinBudget,
  EndgameDevices (tick/status), EndgameStations (C12 diff)}`, `EndgameModule`,
  `station/elevator/ElevatorStationGuard`, the guard use in
  `station/warp/StationWarpService` (quote, commit) and `station/service/StationManager`.
- Tests: `TransitLedgerTest`, `TransitOperationsTest` (harness), the model ports
  (`TransitRedirectModel`, `TransitSourceModel`, `TransitDeliveryModel`: what they call),
  `BlackHoleGeneratorGameTests`, `RailgunGameTests` (refusals, menu/resolve),
  `ElevatorGameTests` (all), `TicketCounts`, `ChunkSaveWatcher`.
- Generated tags (`wither_immune`, `dragon_immune`, `create:non_movable`,
  `carryon:block_blacklist`) and the endpoint block properties in `ModBlocks`.

## 2. What I ran (exported copy, Windows, `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, Gradle 8.8 `--offline`)

| Command | Result | Log |
|---|---|---|
| `./gradlew test --offline` | **BUILD SUCCESSFUL**, 2 min 12 s; **1,350 JUnit tests / 249 result files, 0 failures, 0 errors, 0 skipped** (matches the C12d packet's 1,350) | `logs/gradle-test-baseline.log` |
| `./gradlew runGameTestServer --offline` (run 1) | **BUILD FAILED**: 329 GameTests, **2 required tests failed**, both pre-v1.7 rocket tests: `unavailableProviderDoesNotStarveALaterRecoverableTransaction` ("Fixture entity chunk is not ready for recovery") and `fuelLoaderFuelsOnlyOwnedNearbyLoadedRocketAtFixedRate` ("Fuel Loader did not transfer exactly one cell"). All C12 GameTests passed | `logs/gradle-gametest-baseline.log` |
| `./gradlew runGameTestServer --offline` (run 2, unchanged tree) | **BUILD SUCCESSFUL**: **All 329 required tests passed**; 17 `ERROR` lines, 0 `FATAL` | `logs/gradle-gametest-baseline-run2.log` |
| `./gradlew test --offline --tests '*C12ReviewProbeTest'` | **BUILD SUCCESSFUL**, 6 probe tests, 0 failures (each asserts the suspected defect, so every pass confirms a finding) | `logs/probe-run1.log`, `logs/TEST-…C12ReviewProbeTest.xml` |

Probe source: `probes/C12ReviewProbeTest.java` (also placed in the exported tree under
`src/test/java/io/github/sunthemoon/advancedrocketrycommunity/endgame/service/`). It
uses the same harness pattern as `TransitLedgerTest` (service over a test root, a fake
`TransitEndpoint`, chunk tags posted through `EndgameService.observe`).

| Probe | Confirms |
|---|---|
| `p1_registrationAfterAnOperatorEvictionWritesARootItsOwnDecoderRefuses` | C12R-H1 (operator `tombstone evict` path) |
| `p1b_theSameHappensWithoutAnOperatorWhenThePerOwnerTombstoneCapEvictsTheDestination` | C12R-H1 (per-owner cap path) |
| `p2_aHubWithSixtyFourRecordsStarvesEveryOtherLoadedEndpoint` (with a 63-record control that does not starve) | C12R-M1 |
| `p3_aResolveOfAReturningMissingSourceDestroysAnEntryAboveDispatchedThrough` | C12R-L2 |
| `p4_aCopysChunkSaveMakesTheRegisteredSourcesUnsavedEntryRegister` | C12R-L3 |
| `p5_aRefusedRetireOfATombstonedIdStillPrunesItsStub` | C12R-L4 |

## 3. Verdicts

| Part | Verdict | Blocking items |
|---|---|---|
| **C12a** black-hole generator (ADR-057) | **Accept** | none (Info I3 on test coverage) |
| **C12b** transit ledger (ADR-054 §9, §9.1, §10, §11) | **Accept with required changes** | **H1**, **M1**; L2, L3, L4 should be fixed or recorded |
| **C12c** railgun (ADR-056) | **Accept** (railgun-specific code conforms; it inherits the C12b ledger findings, which are fixed in the ledger) | none of its own |
| **C12d** space elevator (ADR-059, ADR-044/045 interlock) | **Accept with required changes** | **M2**, **M3**; L1, L5, L6, L7 should be fixed or recorded |

Severity counts: Critical 0, High 1, Medium 3, Low 7, Info 6.

## 4. Findings (most severe first)

| ID | Sev. | Part | One line |
|---|---|---|---|
| C12R-H1 | High | C12b | A registration may name a destination whose tombstone was evicted; the root then fails its own decoder and the world refuses to start |
| C12R-M1 | Medium | C12b | One endpoint with ≥ 64 records (stubs and in-transit count) consumes the whole reconciliation budget every tick and starves every other endpoint |
| C12R-M2 | Medium | C12d | The ride `TELEPORT` event and the zone check use the arrival endpoint's owner, not the departing endpoint's owner that ADR-054 §5.1 specifies |
| C12R-M3 | Medium | C12d | Elevator binds have no server-wide 20-tick spacing and no 100-tick per-station cooldown (ADR-054 §7); the cooldown constant is unused |
| C12R-L1 | Low | C12d | The elevator redirect rule accepts an endpoint in any valid pair, not "the station's current valid pair" |
| C12R-L2 | Low | C12b | Resolve of a returning `MISSING` source destroys outbox entries that `dispatched_through` proves unregistered |
| C12R-L3 | Low | C12b | Transit observations are keyed by ID only: a same-ID copy's chunk save marks the registered endpoint's unsaved entries persisted |
| C12R-L4 | Low | C12b | `endpoint retire` of an ID without an index record reports `ENDPOINT_NOT_FOUND` but still prunes stubs and returns claims |
| C12R-L5 | Low | C12d | `/arce endgame status` prints a hard-coded `ride_tickets=0` |
| C12R-L6 | Low | C12d | Package cycle `endgame.root` ↔ `endgame.elevator` (AGENTS §3.4) |
| C12R-L7 | Low | C12d | An automatic elevator launch gets the operator exemption while its owner is an online operator |
| C12R-I1 | Info | C12b | `EndgameService.pinned` always returns false with a stale "before C12" comment |
| C12R-I2 | Info | C12b/c | Class-size notes: `TransitLedger` (534 lines) has none; the log's numbers for `EndgameRoot` and `RailgunBlockEntity` are stale |
| C12R-I3 | Info | all | Test adequacy: the model ports check `TransitRules`, not the production orchestration; some ADR A1 items are not on a running server |
| C12R-I4 | Info | C12b | Edge semantics after an operator restore or purge: a purged `CLAIMED` record's payload is still delivered; a receipt claimed elsewhere and acknowledged is dropped without `REDIRECT_DOUBLE_PAY` |
| C12R-I5 | Info | C12d | A bind whose barrier write failed answers `ROOT_BUSY`, yet the pair is live in memory (rides, cargo, warp guard) |
| C12R-I6 | Info | — | Two pre-v1.7 rocket GameTests failed in 1 of 2 runs (not attributable to C12) |

---

### C12R-H1 (High, C12b) — a registration can name an evicted destination; the written root no longer loads

**Where.** `endgame/service/TransitLedger.java:294-315` (`register`) and
`endgame/root/EndgameRoot.java:189-197` (`registerTransit`) create a record without
checking that its `destination` is an endpoint or a tombstone;
`endgame/root/EndgameRoot.java:503-509` (`finishRestore`) rejects any record whose
source, destination or paid endpoint is neither ("A transit record names no endpoint
or tombstone"). The encoder (`EndgameRootCodec.encode`) does not run that check, so the
bad root is written without error.

**Why it happens.** ADR-054 §11 step 2 deliberately registers an entry even when its
destination "has meanwhile become MISSING or was removed". Pins protect a tombstone
only while a *record* names it (`EndgameRoot.pinned`), not while an *outbox entry*
does. Between the escrow and the registration (the source's chunk must be saved and the
observation aged 40 ticks; up to an autosave interval, longer under `/save-off`), the
destination's tombstone is unpinned and may be evicted by `/arce endgame tombstone
evict <owner>` (an ADR-documented operator action declared safe), by the per-owner cap
of 256 settled tombstones, or by housekeeping.

**Failure scenario.** S escrows to D. D's owner breaks D (nothing is incoming, so it is
not busy); D's absence settles (or an operator runs `tombstone settle`); an operator
runs `tombstone evict <owner>`. S's chunk is then saved and, 40 ticks later, S's entry
registers with `destination = D`, which is now in neither the index nor the tombstone
table. The root writes normally; at the next start `EndgameSavedData.load` fails
`finishRestore`, `ManagedSavedDataPayloadValidator` (`persistence/migration/
ManagedSavedDataPayloadValidator.java:25`, `EndgameSavedData.load(payload).operational()`)
throws `INVALID_SCHEMA`, and the world refuses to start. Were the pre-start check skipped,
the root would load blocked: every endgame action refused and, through
`ElevatorStationGuard`, every station warp and deletion refused (`ENDGAME_UNAVAILABLE`). The only documented remedy (ADR-054 §10) is moving the file
away, which loses every endpoint, pair, zone and transfer.

**Reachability.** The practical trigger is the operator's `tombstone evict` (optionally
after `tombstone settle`) while any of the owner's railgun or elevator entries to a removed
endpoint is still unregistered. Without an operator it needs 256 newer settled tombstones of
the same owner inside that window (the per-owner cap), or housekeeping on a server with more
than 4,096 tombstones and a window longer than 6,000 ticks (for example under `/save-off`).

**Probe.** `p1_…` (operator path) and `p1b_…` (256 newer settled tombstones of the
same owner trigger the per-owner cap) both pass: the record is registered, the control
round trip before the registration is operational, and `EndgameSavedData.load(save())`
is not operational afterwards.

**Suggested fix.** Either (a) relax `finishRestore` for `destination` only (keep it for
source and paid endpoint), since the runtime registers to removed destinations by
design and such a record is simply `DESTINATION_MISSING` until a redirect or purge; or
(b) at registration, when the destination has neither record nor tombstone, recreate a
settled tombstone for it (pinned by the new record). Add a unit test that encodes and
decodes the root after such a registration, and one through `TransitLedger`.

### C12R-M1 (Medium, C12b) — one busy endpoint starves the whole ledger's reconciliation

**Where.** `endgame/transit/TransitDestinationState.java:119-126` takes one unit of the
shared 64-record budget for *every* record that names the endpoint, including stubs
(acknowledged, nothing to do) and `IN_TRANSIT` records; `endgame/service/
TransitLedger.java:233-236` then sets `cursor = loaded.lowerKey(id)` ("Resume at this
endpoint next tick"), so the next tick starts at the same endpoint again.

**Failure scenario.** An endpoint D with ≥ 64 records naming it spends the whole
budget each tick, and because the cursor is put back in front of D the loop returns before
reaching any other loaded endpoint, whether it sorts before or after D. Every other endpoint
on the server then gets no destination rows at all (no claims, moves, acknowledgements or
receipt drops) and no source rows except the ones a source runs right before its own launch
attempts (`reconcileSource`). While D's receive buffer is full its `ARRIVED` records never
leave, so the stall can last indefinitely. This breaks ADR-054 §7's "round-robin from the
last served device"; the reference models do not model the budget, so their ports cannot
catch it.

**Reachability.** One owner alone stays below 64 at one destination in normal play: at
most 32 live records (`endgame.transitPerOwner`) plus the stubs of one save interval, which
the receive buffer's room bounds (about 9 single-stack payloads). Two or more owners'
cargo at one endpoint reaches it: an operator pointing several owners' railguns at one hub
(`operator_target`, which then auto-launches indefinitely), or an operator consolidating
`DESTINATION_MISSING` cargo of several owners with `transfer redirect` (operators may pick a
foreign target). The impact is server-wide while it lasts, hence Medium.

**Probe.** `p2_…` passes. It builds the 64 records directly in the root (32 in transit,
32 stubs; the scheduler does not care which owner or kind they are): another loaded
endpoint's arrived, durable record is never claimed in 300 ticks; with 63 records it is
claimed (control).

**Suggested fix.** Advance the round robin past an endpoint once it has had its turn
(keep a per-endpoint resume offset for the records it did not reach), and/or do not
charge the budget for records with no applicable row (stubs, `IN_TRANSIT` without a
receipt, `QUARANTINED`). Add a service test with a 64-record hub and a second endpoint.

### C12R-M2 (Medium, C12d) — the ride `TELEPORT` event carries the wrong owner

**Where.** `endgame/elevator/ElevatorRides.java:207`:
`UUID owner = root.endpoint(ride.arrival()).map(EndpointRecord::owner).orElse(rider.getUUID());`
is the batch owner for `EndgameProtection.check`. The implementation log (C12d,
"Commit protection") records the choice, but no ADR revision does.

**Contract.** ADR-054 §5.1 (the public API extension): `ownerId()` is "the owner of the
device that causes the effect; **for `TELEPORT` the departing endpoint's owner**". §5
step 3 checks a zone's allow list against that device owner.

**Failure scenario.** An operator zone in the Overworld around A's anchor allows only A.
A station member rides *down* from the terminal owned by the station owner B. Per the
contract the event's `ownerId` is B and the zone refuses (`TARGET_PROTECTED`); the code
passes A, so the zone allows the ride, and every third-party claim-mod listener sees A
as the owner of an effect A's device did not cause. The same inversion applies to a
ride up. Only the public API's documented semantics and zone decisions are affected
(no duplication).

**Probe.** None (direct code reading; the log states the behaviour).

**Suggested fix.** Use the departing endpoint's owner
(`root.endpoint(ride.departure())`) as the batch owner, or revise ADR-054 §5.1 and the
public API guide through a new revision. Add a GameTest with a zone that allows only the
arrival owner.

### C12R-M3 (Medium, C12d) — elevator binds are not spaced or cooled down

**Where.** `endgame/elevator/ElevatorPairs.java:100-154` (`bind`) runs a barrier flush
with no spacing check. `EndgameLimits.BARRIER_STATION_COOLDOWN_TICKS` (line 60) is
referenced nowhere (`grep`); the only spacing is `TransitOperations.playerSpacing`
(`TransitOperations.java:62-75`, 20 ticks server-wide), used by owner redirects and owner
resolves, never by binds.

**Contract.** ADR-054 §7 "Barrier spacing": elevator binds and owner redirects share a
server-wide spacing of 20 ticks **and a per-station cooldown of 100 ticks**, refused with
`ROOT_BUSY` before anything changes; unbinding is exempt but "counts toward the spacing
of the next bind"; exempt barriers are "counted in `/arce endgame status`". None of
these four rules exists for binds, and owner redirects lack the per-station cooldown.

**Failure scenario.** A station owner alternates bind and unbind from the terminal menu;
only the per-player 10-tick state-intent rate (`EndgameIntentGuard.java:84`) applies, so
each player causes one full root write every 10 ticks (bind and unbind barriers
alternating). Ten players doing it, each on their own station, write the root every tick;
with the contract's rules binds would be at most one per 20 ticks server-wide and one per
100 ticks per station. ADR-054 budgets one flush at
≤ 60 ms at the reference root and ≤ 250 ms at the accounted maximum, so this is the
barrier-flush denial of service that the spacing exists to prevent.

**Probe.** None (code reading and `grep`: the constant is unused and `bind` has no
spacing call).

**Suggested fix.** In `ElevatorPairs.bind`, before any change: refuse with `ROOT_BUSY`
inside the shared 20-tick spacing or inside 100 ticks of the last bind of that station
(operators exempt); record unbinds in the shared spacing; apply the per-station cooldown
to owner redirects of elevator cargo; count exempt barriers in `status`. Unit-test the
order (spacing refusals change nothing).

### C12R-L1 (Low, C12d) — the elevator redirect rule is wider than the contract

**Where.** `endgame/elevator/ElevatorRedirectRule.java:37-53`: apart from the source
itself, any endpoint of the right kind whose pair (`root.pairs().forEndpoint(target)`)
is currently valid is accepted; the pair's station is never compared with the original
destination's station.

**Contract.** ADR-054 §11 and ADR-059 §6 (R3-L4): elevator cargo goes back to its source
"or to the endpoint of the original destination's kind in **the station's** current valid
pair".

**Failure scenario.** An owner ships from anchor A1 (Earth) toward terminal T1, breaks
T1 before the claim, and redirects the `DESTINATION_MISSING` record to their own
terminal T2 on a station paired with an anchor in another star system. The cargo is
delivered across star systems, which elevator geography otherwise excludes (a pair joins
a station to the body it orbits) and which ADR-056 defers for railgun cargo. No
duplication or loss.

**Probe.** None (code reading).

**Suggested fix.** Resolve the original station (from the source's pair if indexed, else
from the original destination's tombstone position, as `ElevatorGuard.inRegion` does) and
require `target`'s pair to name that station; or record the wider rule in an ADR revision.

### C12R-L2 (Low, C12b) — resolve of a returning `MISSING` source loses provably unregistered entries

**Where.** `endgame/service/TransitOperations.java:213-221`: `boolean tombstone =
root.tombstone(id).isPresent()`. A `MISSING` endpoint keeps its index record and its
`dispatched_through`, but `tombstone(id)` only reads the young and settled tables, so
`resolveOutboxToInput` is always false for it and every frozen outbox entry is destroyed
(`OUTBOX_DISCARDED`).

**Contract.** ADR-054 §9: a `MISSING` endpoint "is retired the same way" as a removal,
"the tombstone of §11 stays", and a resolve returns an outbox entry whose `seq` is above
the recorded `dispatched_through`.

**Failure scenario.** S (registered) escrows seq 1; S's block entity vanishes without
`onRemove`; an aged tag shows the absence and S becomes `MISSING`; the save that showed
the absence is lost (or the region is restored) and S comes back frozen. Its owner runs
`endpoint resolve`, or breaks it (`settleRemoval` uses the same resolve): seq 1 is
destroyed although `dispatched_through[S] = 0` proves it was never registered. The
workaround (`endpoint forget` first, which settles a tombstone) is undocumented.

**Probe.** `p3_…` passes: `returned = 0`, `destroyed = 1`, the input stays empty.

**Suggested fix.** Treat a `MISSING` index record as the tombstone for this rule
(`root.retired(id)` plus `dispatchedThrough(id)`). Unit test.

### C12R-L3 (Low, C12b) — a same-ID copy elsewhere feeds persistence observations to the original

**Where.** `endgame/service/EndpointObservations.java:45-61` keys the transit sections of
a chunk tag by device ID only; `endgame/service/TransitLedger.java:107-116` applies them
to `loaded.get(id)` (or keeps them pending for it) without checking that the endpoint's
recorded position lies in the observed chunk.

**Contract.** ADR-054 §2: an outbox entry or receipt counts as persisted only when it is
present "in that endpoint's entry of a … tag **for its chunk**". ADR-054 §9: a block
entity carrying a registered ID at another position is `ENDPOINT_POSITION_CONFLICT` and
**inert**.

**Failure scenario.** An operator `/clone` (or a mover that keeps block-entity data)
leaves a copy of railgun S in another chunk that holds an indexed endpoint. The copy's
chunk save shows S's outbox seq; S's own entry is marked persisted, and 40 ticks later it
registers although S's chunk never saved it. A crash then restores S's input with the
payload while the record delivers it: a duplicate outside the documented residuals. The
"inert" copy is not inert. `/clone` is outside the guarantee, hence Low.

**Probe.** `p4_…` passes: the entry registers after only the copy's chunk tag (which also
holds the indexed neighbour) was observed.

**Suggested fix.** In `observed`, apply a transit section only when the tag's block
entity stands at the ID's recorded position (index record or young tombstone), or at the
loaded endpoint's own position; key `EndpointObservations.transit` by position.

### C12R-L4 (Low, C12b) — a refused `endpoint retire` still mutates

**Where.** `endgame/command/EndgameCommands.java:262-267`: the barrier first runs
`TransitLedger.retireWithoutLiveState(root, id, true)` and then
`root.retireLost(id, …)`; for an ID without an index record (for example a removed
endpoint's young tombstone) `retireLost` returns `ENDPOINT_NOT_FOUND`, yet the stubs paid
there are already pruned and its unacknowledged claims returned.

**Failure scenario.** An operator retires the ID of an endpoint that a player just broke
(young tombstone, its chunk not yet saved). The command answers `ENDPOINT_NOT_FOUND`, but
the stub that ADR-054 §11 keeps "until this endpoint's chunk has saved the move" is gone;
a crash that restores the endpoint with its due move then makes the resolve destroy the
endpoint's own payload (the R3-L6 loss the stub prevents). Operator misuse, hence Low.

**Probe.** `p5_…` passes: `ENDPOINT_NOT_FOUND`, and the stub is gone.

**Suggested fix.** Check `root.endpoint(id)` inside the operation and return the refusal
before `retireWithoutLiveState` runs (or run it only when `retireLost` succeeds).

### C12R-L5 (Low, C12d) — status shows a hard-coded ride-ticket count

**Where.** `endgame/service/EndgameService.java:478` appends the literal `" ride_tickets=0"`.
ADR-054 §13 requires the status to show the ride-arrival tickets held (≤ 64).
`EndgameDevices.status()` prints `elevator rides=N` on the next line, so during a pending
ride the two lines disagree (`ride_tickets=0` beside `elevator rides=1`).

**Probe.** None (code reading).

**Suggested fix.** Report `devices.elevatorRides().size()` as `ride_tickets` (one ticket
per pending ride) and remove the literal.

### C12R-L6 (Low, C12d) — package cycle between the root and the elevator

**Where.** `endgame/root/EndgameRoot.java:7-8` imports `endgame.elevator.ElevatorPair` and
`ElevatorPairTable`, `endgame/root/EndgameRootCodec.java:3` imports `ElevatorPairCodec`;
seven classes of `endgame.elevator` import `endgame.root` (`ElevatorPairs`,
`ElevatorGuard`, `ElevatorRides`, `ElevatorCargo`, `ElevatorMenu`,
`ElevatorEndpointBlockEntity`, `ElevatorRedirectRule`). AGENTS §3.4 forbids two-way
module dependencies; C12b moved `EndgameNbt` to `endgame.model` precisely so that "the root
depends on the transit package and never the reverse", but the elevator pair model sits in
the same package as its Forge adapters.

**Suggested fix.** Move `ElevatorPair`, `ElevatorPairTable` and `ElevatorPairCodec` to a
model package with no Forge or root dependency (as `endgame.transit` is).

### C12R-L7 (Low, C12d) — automation inherits the owner's operator exemption while they are online

**Where.** `endgame/elevator/ElevatorCargo.java:62-65`: for an automatic launch the
shipper is the endpoint owner, and the operator exemption of `ElevatorPairs.access` is
granted when that owner is an online operator.

**Contract.** ADR-054 §3: the operator row is a connected non-fake player actor;
automation passes no intent and its path is redstone control. ADR-059 §7: ship access
needs station `VISIT` and an anchor owner who is a station member.

**Failure scenario.** An operator-owned anchor with `auto` ships to a station whose
owner the operator is not a member of while the operator is logged in, and is refused
(`UNAUTHORIZED`/`ANCHOR_OWNER_NOT_MEMBER`) once they log out: automation behaviour depends
on the owner's login and permission state. Impact is small (operators can do it by hand).

**Suggested fix.** Pass `operator = false` for automatic launches.

### C12R-I1 (Info, C12b) — dead `pinned` predicate with a stale comment

`endgame/service/EndgameService.java:413-416`: `pinned(UUID)` returns `false` with the
comment "neither exists before C12". It is still passed to `settle`, `housekeep`,
`evictOwner`, `forget` and `retireLost`; pins actually work only because
`EndgameRoot.eligible` also calls the root's own `pinned`. Remove the predicate or make it
delegate, so a later caller of the predicate alone cannot evict a pinned tombstone.

### C12R-I2 (Info, C12b/c) — class-size notes

`TransitLedger` has 534 lines (over the AGENTS §3.4 500-line check) and no
responsibility note in the log or class header. The log gives `EndgameRoot` 524 lines (it
has 548) and `RailgunBlockEntity` 510 lines (239 since `3e2b1d4` extracted
`CargoEndpointBlockEntity`). No class exceeds 800 lines. No `net.minecraft.client` import
in common code (`grep`).

### C12R-I3 (Info, all) — test adequacy

- The C12b packet's claim that the model-port tests "describe the production decisions" is
  true for `TransitRules`, but the ports re-implement the orchestration (row order, the
  64-record budget and round robin, the tag routing, settlement assembly, resolve). H1, M1,
  L2, L3 and L4 all sit in that production orchestration and none is caught by the 1,350
  tests; `TransitLedgerTest` (4) and `TransitOperationsTest` (3) are the only service-level
  tests of it.
- ADR-059 A1 lists "after … `ARRIVAL_UNLOADED` and a stop no `elevator_arrival` ticket
  remains"; the packet lists `ARRIVAL_UNLOADED` as not verified but does not mention the
  stop. ADR-057 A1 "zero tickets" is not checked by the generator GameTest.
- The generator GameTest's "a full buffer pauses without consuming" runs while
  `remaining > 0`, where nothing would be consumed anyway; the "empty burn with a full
  buffer takes nothing" branch is covered only by the unit vectors.
- `ElevatorGameTests` checks `/arce station admin delete` only by its return value 0 and
  the station still existing, not by the `ELEVATOR_REFERENCES` reason (the guard decision
  itself is asserted separately through the port).

### C12R-I4 (Info, C12b) — edge semantics after an operator restore or purge

- `TransitOperations.purge` (`:136-145`) of a `CLAIMED` record: the payload is not
  destroyed as ADR-054 §11 says; the paid endpoint's incoming gate sees an absent record
  (`TransitRules.moves(…, null)`) and moves it into the receive buffer. No duplicate or
  loss; document it or refuse a purge of `CLAIMED` records.
- `TransitDestinationState.reconcile` (`:176-184`): a receipt whose record names another
  endpoint and is acknowledged there is dropped by `dropsReceipt` without the
  `REDIRECT_DOUBLE_PAY` freeze or audit line ADR-054 §11 describes ("a claim paid
  elsewhere freezes the receipt"). Reachable only after an operator file restore.

### C12R-I5 (Info, C12d) — a bind that failed to write is live

`ElevatorPairs.java:138-151`: when the barrier write fails, the pair stays in memory
and the bind answers `ROOT_BUSY` (as the log records). Rides, cargo and the warp guard use
the pair at once, before it is durable; a crash loses it, which fails safe for the warp
interlock and leaves cargo endpoint-addressed. Consider not adding the pair to memory until
the write succeeds, or state the behaviour in ADR-059.

### C12R-I6 (Info, not C12) — flaky pre-v1.7 GameTests

Run 1 failed `RocketAdapterFailureGameTests.unavailableProviderDoesNotStarveALaterRecoverableTransaction`
and `RocketGameTests.fuelLoaderFuelsOnlyOwnedNearbyLoadedRocketAtFixedRate`; run 2 on the
same tree passed all 329. Neither file changed in C12. Worth tracking in C13, because the
C12 fixtures force chunks and leave blocks around the shared test origin.

## 5. Checked and found conforming (no finding)

- **Ledger rows** (`TransitRules`, `TransitSourceState`, `TransitDestinationState`): source
  rows (stale drop, lowest-entry registration with the aged observation, release once
  durable, `SOURCE_ROLLBACK` before escrow, `SEQUENCE_GAP`), destination rows (recover,
  claim with durable registration and whole-payload room with reservations, persisted-receipt
  acknowledgement, rematerialization once, receipt drop only after a durable acknowledgement
  or an absent record), the incoming gate (aged observation, move and acknowledgement in one
  tick), stubs and pruning after a tag ≥ 40 ticks after the acknowledgement, removal
  settlement (`MOVED`/`INCOMING`/voided/own content, barrier only when something settles,
  `REMOVAL_SETTLEMENT_PENDING`), retirement without live state, the registration freeze
  (R3-H1, R4-L3 freeze recorded in the device root), redirect only after a durable index
  removal, purge, resettle, resolve item by item. I traced every ADR-054 §11 crash cut
  through the code and found no duplicate or loss beyond the documented residuals, apart
  from the findings above.
- **Strict persistence**: device roots quarantine on any unknown key, bound or decode error
  and re-save byte-identically; quarantined endpoints count as present; the transit section,
  payloads (≤ 4 stacks × 512 B, depth and node bounds), records (≤ 2.5 KiB), receipts and
  incoming (≤ 64), outbox (≤ 4), pairs (≤ 1,024, one per station/anchor/terminal/column,
  ≤ 128-character IDs) are bounded on read and write; the root has its own schema version.
- **Authority and intents**: buttons only, no new C2S message; FakePlayers excluded from
  menus and placement ownership; command owner paths use `EndgameCommandSources.ownPlayer`
  (rejects `/execute as` another player, functions, command blocks, FakePlayers);
  per-action elevator overrides (ride/ship `VISIT` plus anchor-owner membership, bind by the
  station owner with the actor's own anchor, unbind by station owner, anchor owner or
  operator, from either menu or the command, also while disabled); railgun selection lists
  only the device owner's `ACTIVE` railguns (operators any) with the route rule; item slots
  need `WITHDRAW`/`CONFIGURE`.
- **Chunk loading**: no C12 path loads a chunk from a value a client supplied; the
  generator's push uses `getChunkNow`; ride arrival positions come from the index record;
  the `elevator_arrival` ticket (distance 0, 300-tick lifespan) is added only after the
  request checks pass and is released at commit, at every cancellation, on unbind and at
  `ServerStoppingEvent`; the commit never loads synchronously and cancels with
  `ARRIVAL_UNLOADED` after 100 more ticks; at most one commit per tick.
- **Station guard**: the port fails closed before installation and while the root is not
  operational; request, confirmation and commit all pass through `quote`, and the commit
  reads the live pair set in the tick of `checkedRelocation`; deletion is refused for pairs
  and for transit records whose source or destination (or tombstone) is in the region; the
  station module imports no endgame class.
- **C12a**: burn rule matches ADR-057 §4 (one item only while not full, rate fixed per
  item, ≤ 8,192 FE/t, pause when the whole rate does not fit), plain-item rule on insert and
  read, eligibility only on a live, orbitable, non-landable singularity body in a committed
  station, 20,000 FE/t shared push/pull output, no `receiveEnergy`, active-place release on
  ineligibility, strict all-or-nothing data reload.
- **C12c**: route rule order and classes, 64-bit integer distance, cost/travel caps,
  payload selection with minimum stack size, ADR-056 §4 refusal order with the recorded
  framework codes, 20-tick cadence and ≤ 4 launches per tick in ID order, removal and
  freeze rules, explosion resistance, push reaction and mover/immunity tags.

## 6. Limits of this review

- No forced-stop crash testing (S1/S2 belong to C13); crash windows were reasoned on the
  code and the probes.
- No client, V1 or multiplayer checks; no performance measurement.
- `ElevatorEndpointValidator` (ADR-045, v1.5) and the C11 framework classes were read
  only where C12 calls them.
- The repository moved during the review (at the end `HEAD` was `9470f27`, with a modified
  `EndgameModule.java` and an untracked `EndgameReleaseTestCommands.java` that this review
  did not create). Every result here is pinned to `95e22b5` through the exported tree.
