package io.github.sunthemoon.advancedrocketrycommunity.endgame.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.device.EndgameDeviceTags;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameCode;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSettings;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSystem;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameRoot;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.OutboxEntry;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitDestinationState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitEndpoint;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitKey;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitLimits;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitPayload;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitSourceState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitTags;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * C12 independent review probes (reviewer-only, not part of the repository). Each probe asserts the SUSPECTED
 * defective behaviour; a passing probe confirms the finding named in its method name.
 */
final class C12ReviewProbeTest {
    private static final String TYPE = "advancedrocketrycommunity:railgun";
    private static final ResourceLocation KIND = ResourceLocation.tryBuild("advancedrocketrycommunity", "railgun");
    private static final ResourceLocation LEVEL = ResourceLocation.tryBuild("minecraft", "overworld");
    private static final UUID OWNER = new UUID(1L, 1L);
    private static final UUID SOURCE = new UUID(0L, 0x10L);
    private static final UUID HUB = new UUID(0L, 0x20L);
    private static final UUID OTHER = new UUID(0L, 0x30L);
    private static final BlockPos SOURCE_POS = new BlockPos(8, 64, 8);
    private static final BlockPos HUB_POS = new BlockPos(200, 64, 200);
    private static final BlockPos OTHER_POS = new BlockPos(400, 64, 400);

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    /** A loaded endpoint with a nine-stack receive buffer (as in TransitLedgerTest). */
    private static final class Endpoint implements TransitEndpoint {
        final UUID id;
        final TransitSourceState source = new TransitSourceState();
        final TransitDestinationState destination = new TransitDestinationState();
        final List<ItemStack> received = new ArrayList<>();
        final List<ItemStack> input = new ArrayList<>();
        boolean frozen;

        Endpoint(UUID id) {
            this.id = id;
        }

        @Override
        public UUID endpointId() {
            return id;
        }

        @Override
        public Optional<UUID> endpointOwner() {
            return Optional.of(OWNER);
        }

        @Override
        public boolean transitFrozen() {
            return frozen;
        }

        @Override
        public TransitSourceState source() {
            return source;
        }

        @Override
        public TransitDestinationState destination() {
            return destination;
        }

        @Override
        public TransitDestinationState.ReceiveBuffer receiveBuffer() {
            return new TransitDestinationState.ReceiveBuffer() {
                @Override
                public boolean fits(List<List<ItemStack>> payloads) {
                    return received.size() + payloads.stream().mapToInt(List::size).sum() <= 9;
                }

                @Override
                public void insert(List<ItemStack> stacks) {
                    stacks.forEach(stack -> received.add(stack.copy()));
                }
            };
        }

        @Override
        public void transitChanged() {
        }

        @Override
        public boolean returnToInput(List<ItemStack> stacks) {
            if (input.size() + stacks.size() > 4) {
                return false;
            }
            stacks.forEach(stack -> input.add(stack.copy()));
            return true;
        }

        CompoundTag chunkTag(BlockPos pos) {
            CompoundTag section = new CompoundTag();
            source.write(section);
            destination.write(section);
            CompoundTag root = new CompoundTag();
            root.putUUID(EndgameDeviceTags.DEVICE_ID, id);
            root.put(TransitTags.SECTION, section);
            CompoundTag blockEntity = new CompoundTag();
            blockEntity.putString("id", TYPE);
            blockEntity.putInt("x", pos.getX());
            blockEntity.putInt("y", pos.getY());
            blockEntity.putInt("z", pos.getZ());
            blockEntity.put(EndgameDeviceTags.ROOT, root);
            ListTag list = new ListTag();
            list.add(blockEntity);
            CompoundTag chunk = new CompoundTag();
            chunk.put("block_entities", list);
            return chunk;
        }
    }

    private static EndgameService service(EndgameSavedData data, UUID... ids) {
        EndgameService service = new EndgameService(() -> EndgameSettings.DEFAULTS, () -> Set.of(TYPE),
                () -> TransitLimits.DEFAULTS);
        service.startForTest(data);
        for (UUID id : ids) {
            BlockPos pos = id.equals(SOURCE) ? SOURCE_POS : id.equals(HUB) ? HUB_POS : OTHER_POS;
            assertEquals(EndgameCode.OK, service.coalesced(root -> root.register(id, KIND, OWNER, LEVEL, pos.asLong(),
                    false, 2048, 64)));
        }
        persist(service);
        return service;
    }

    private static void persist(EndgameService service) {
        service.root().orElseThrow().markPersisted();
    }

    private static TransitPayload payload() {
        return TransitPayload.of(List.of(new ItemStack(Items.DIAMOND, 7))).orElseThrow();
    }

    private static TransitRecord record(long seq, UUID destination, long epoch) {
        return TransitRecord.registered(SOURCE, new OutboxEntry(seq, destination, payload(), 1, 20,
                EndgameSystem.RAILGUN), OWNER, epoch, 0L);
    }

    // ---- P1 (C12R-H1): a registration names an evicted destination; the root no longer loads ------------------

    @Test
    void p1_registrationAfterAnOperatorEvictionWritesARootItsOwnDecoderRefuses() {
        EndgameSavedData data = EndgameSavedData.create();
        EndgameService service = service(data, SOURCE, HUB);
        Endpoint source = new Endpoint(SOURCE);
        TransitLedger ledger = service.transits();
        ledger.attach(source);
        assertEquals(EndgameCode.OK, ledger.admitEscrow(SOURCE, OWNER));
        source.source.escrow(HUB, payload(), 25_000, 20, EndgameSystem.RAILGUN);
        // The destination is removed (it holds nothing, so a player may break it), its absence settles (or an
        // operator runs `tombstone settle`), and an operator runs `tombstone evict <owner>`: the tombstone is
        // unpinned because no transit RECORD names it yet, only the source's outbox entry.
        service.endpointRemoved(HUB, 5L);
        service.coalesced(root -> root.settle(HUB, EndgameService::pinned));
        List<UUID> evicted = service.barrier(root -> root.evictOwner(OWNER, EndgameService::pinned));
        assertEquals(List.of(HUB), evicted);
        // Control: the root still round-trips.
        assertTrue(EndgameSavedData.load(data.save(new CompoundTag())).operational(), "control round trip failed");
        // The source's chunk save shows the entry; 40 ticks later it registers with the evicted destination.
        service.observe(LEVEL, new ChunkPos(SOURCE_POS).toLong(), source.chunkTag(SOURCE_POS), false);
        service.tick(10L);
        service.tick(50L);
        EndgameRoot root = service.root().orElseThrow();
        TransitRecord registered = root.transits().record(new TransitKey(SOURCE, 1L)).orElseThrow();
        assertEquals(HUB, registered.destination());
        assertTrue(root.endpoint(HUB).isEmpty() && root.tombstone(HUB).isEmpty(), "the destination is unknown");
        // The written root fails its own decoder: the pre-start validation refuses the world (INVALID_SCHEMA).
        CompoundTag file = data.save(new CompoundTag());
        assertFalse(EndgameSavedData.load(file).operational(), "PROBE: the root still loads");
    }

    @Test
    void p1b_theSameHappensWithoutAnOperatorWhenThePerOwnerTombstoneCapEvictsTheDestination() {
        EndgameSavedData data = EndgameSavedData.create();
        EndgameService service = service(data, SOURCE, HUB);
        Endpoint source = new Endpoint(SOURCE);
        service.transits().attach(source);
        source.source.escrow(HUB, payload(), 25_000, 20, EndgameSystem.RAILGUN);
        service.endpointRemoved(HUB, 5L);
        service.coalesced(root -> root.settle(HUB, EndgameService::pinned));
        // The owner churns 256 more endpoints: each settles, and the per-owner cap of 256 evicts the oldest (HUB).
        for (int i = 0; i < 256; i++) {
            UUID churn = new UUID(7L, i);
            long at = new BlockPos(16 * (i + 30), 64, 0).asLong();
            service.coalesced(root -> root.register(churn, KIND, OWNER, LEVEL, at, false, 2048, 64));
            service.coalesced(root -> root.remove(churn));
            service.coalesced(root -> root.settle(churn, EndgameService::pinned));
        }
        assertTrue(service.root().orElseThrow().tombstone(HUB).isEmpty(), "the cap did not evict the destination");
        service.observe(LEVEL, new ChunkPos(SOURCE_POS).toLong(), source.chunkTag(SOURCE_POS), false);
        service.tick(10L);
        service.tick(50L);
        assertTrue(service.root().orElseThrow().transits().record(new TransitKey(SOURCE, 1L)).isPresent());
        assertFalse(EndgameSavedData.load(data.save(new CompoundTag())).operational(), "PROBE: the root still loads");
    }

    // ---- P2 (C12R-M1): one endpoint with 64 records starves every other endpoint's reconciliation -----------

    @Test
    void p2_aHubWithSixtyFourRecordsStarvesEveryOtherLoadedEndpoint() {
        assertTrue(starved(64), "PROBE: the other endpoint claimed its arrived cargo");
        assertFalse(starved(63), "control: with 63 records on the hub the other endpoint claims");
    }

    /** 32 live in-transit records and {@code total - 32} stubs at the hub, one arrived record for OTHER. */
    private static boolean starved(int total) {
        EndgameService service = service(EndgameSavedData.create(), SOURCE, HUB, OTHER);
        long seq = 0;
        for (int i = 0; i < total; i++) {
            long next = ++seq;
            boolean stub = i >= 32;
            service.coalesced(root -> {
                TransitRecord base = record(next, HUB, root.saveEpoch());
                root.registerTransit(stub ? base.arrived().claimed(HUB).acknowledged(root.saveEpoch()).asStub()
                        : new TransitRecord(base.key(), base.system(), base.owner(), base.destination(), base.payload(),
                        base.paidFe(), base.dispatchEpoch(), 1_000_000L, TransitRecord.State.IN_TRANSIT, null, false,
                        0L, false));
                return null;
            });
        }
        long last = ++seq;
        service.coalesced(root -> {
            root.registerTransit(record(last, OTHER, root.saveEpoch()).arrived());
            return null;
        });
        persist(service);
        persist(service);
        Endpoint hub = new Endpoint(HUB);
        Endpoint other = new Endpoint(OTHER);
        service.transits().attach(hub);
        service.transits().attach(other);
        for (long tick = 100L; tick < 400L; tick++) {
            service.tick(tick);
        }
        return other.destination.incoming().isEmpty();
    }

    // ---- P3 (C12R-L2): a returning MISSING source loses provably unregistered entries on resolve ------------

    @Test
    void p3_aResolveOfAReturningMissingSourceDestroysAnEntryAboveDispatchedThrough() {
        EndgameService service = service(EndgameSavedData.create(), SOURCE, HUB);
        Endpoint copy = new Endpoint(SOURCE);
        copy.source.escrow(HUB, payload(), 25_000, 20, EndgameSystem.RAILGUN);
        copy.frozen = true;
        service.coalesced(root -> root.markMissing(SOURCE));
        persist(service);
        EndgameRoot root = service.root().orElseThrow();
        assertEquals(0L, root.dispatchedThrough(SOURCE), "seq 1 is provably unregistered");
        assertTrue(root.retired(SOURCE));
        TransitOperations.Resolved resolved = service.transitOperations().resolve(copy, OWNER, 100L, null);
        assertEquals(0, resolved.returned(), "PROBE: the entry was returned");
        assertEquals(1, resolved.destroyed(), "PROBE: the entry was not destroyed");
        assertTrue(copy.input.isEmpty());
    }

    // ---- P4 (C12R-L3): a same-ID copy elsewhere feeds persistence observations to the registered endpoint ----

    @Test
    void p4_aCopysChunkSaveMakesTheRegisteredSourcesUnsavedEntryRegister() {
        EndgameService service = service(EndgameSavedData.create(), SOURCE, HUB, OTHER);
        Endpoint source = new Endpoint(SOURCE);
        service.transits().attach(source);
        source.source.escrow(HUB, payload(), 25_000, 20, EndgameSystem.RAILGUN);
        // An operator copy (or a mover that kept the data) of the source stands in OTHER's (indexed) chunk.
        BlockPos copyAt = OTHER_POS.east();
        CompoundTag chunk = new Endpoint(OTHER).chunkTag(OTHER_POS);
        chunk.getList("block_entities", 10).add(source.chunkTag(copyAt).getList("block_entities", 10).get(0));
        service.observe(LEVEL, new ChunkPos(copyAt).toLong(), chunk, false);
        service.tick(10L);
        service.tick(50L);
        assertTrue(service.root().orElseThrow().transits().record(new TransitKey(SOURCE, 1L)).isPresent(),
                "PROBE: nothing registered although the source's own chunk was never saved");
    }

    // ---- P5 (C12R-L4): `endpoint retire` of a tombstoned ID is refused but prunes the stubs paid there -------

    @Test
    void p5_aRefusedRetireOfATombstonedIdStillPrunesItsStub() {
        EndgameService service = service(EndgameSavedData.create(), SOURCE, HUB);
        TransitKey key = new TransitKey(SOURCE, 1L);
        service.coalesced(root -> {
            root.registerTransit(record(1L, HUB, root.saveEpoch()).arrived().claimed(HUB)
                    .acknowledged(root.saveEpoch()).asStub());
            return null;
        });
        persist(service);
        service.endpointRemoved(HUB, 5L);
        // The command's own operation (EndgameCommands.retire), run as its barrier.
        EndgameRoot.Change change = service.barrier(root -> {
            TransitLedger.retireWithoutLiveState(root, HUB, true);
            return root.retireLost(HUB, EndgameService::pinned);
        });
        assertEquals(EndgameCode.ENDPOINT_NOT_FOUND, change.code(), "the command reports a refusal");
        assertTrue(service.root().orElseThrow().transits().record(key).isEmpty(),
                "PROBE: the refused retire did not prune the stub");
    }
}
