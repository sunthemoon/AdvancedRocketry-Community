| ID | Sev. | Part | One line |
|---|---|---|---|
| C12R2-L1 | Low | test infrastructure (I6) | The recorded cause of the flaky rocket GameTests (a world kept between runs) does not cover the round-1 failure, which happened on a fresh world |
| C12R2-I1 | Info | C12b/C12d | Two Javadoc blocks were left dangling by the fixes (`TransitLedger.retire`, `EndgameService.barrierSpacing`), and two methods lost theirs |
| C12R2-I2 | Info | C12b (I4 note) | The I4 note says an operator resolves the endpoint to discard a purged claim's payload; at a registered endpoint a resolve does nothing to it |
| C12R2-I3 | Info | C12d/C12b (M3) | An admitted spaced request uses up its spacing and its station's cooldown even when it then changes nothing |
| C12R2-I4 | Info | tests (M3) | GameTests share the server-wide `BarrierSpacing` across batches; only the current batch order keeps spaced requests of different batches 20 ticks apart |
| C12R2-I5 | Info | C12b (H1) | The changed codec test of an unknown source passes through the `dispatched_through` check, so nothing tests the source and paid-endpoint restore rule on its own |
| C12R2-I6 | Info | C12d (L1) | Elevator cargo first redirected to its source, and then left without both ends, no longer names its terminal side: the station's rebuilt pair is refused and only a purge remains |

### C12R2-L1 (Low, test infrastructure) — the I6 diagnosis does not explain the round-1 failure

**Where.** Commits `00a5f31`/`644c903` (`build.gradle:259-265`, `doFirst { delete
file('build/gametest/world') }`) and the log entry "C12R-I6": "the cause is a GameTest
world kept between runs in `build/gametest/world`".

**Evidence.** In round 1 the reviewed tree was a fresh `git archive` export, so its first
`runGameTestServer` created a new world: `logs/gradle-gametest-baseline.log` shows 26
"Preparing spawn area" lines and "Time elapsed: 12755 ms" (world generation). That run
failed both `RocketGameTests.fuelLoaderFuelsOnlyOwnedNearbyLoadedRocketAtFixedRate` and
`RocketAdapterFailureGameTests.unavailableProviderDoesNotStarveALaterRecoverableTransaction`.
The second run, on the world the first one kept (7 lines, 3,023 ms), passed all 329. So at
least one failure of each test happened on a fresh world, which the new `doFirst` cannot
prevent:
- `unavailableProvider…` fails on `level.areEntitiesLoaded(...)` ("Fixture entity chunk is
  not ready for recovery", `RocketAdapterFailureFixture.java:119-120`). That is
  asynchronous entity-section loading, which is slower while a fresh world is still being
  generated.
- `fuelLoader…` (40-tick timeout) spawns rocket entities next to the test area. Rockets
  from other tests of the *same* run can stand near it on a fresh world too, so cross-test
  contamination is not limited to earlier runs.

FRESHRUNS-PLACEHOLDER

**Suggested fix.** Keep the fresh world, which removes accumulation across runs, but
record the diagnosis as partial. Make the two tests robust: wait (`thenWaitUntil`) for
`areEntitiesLoaded` instead of asserting it once, and give the fuel-loader test a
private batch or count only the rockets it spawned. Note that a fresh world adds about 10 s
of generation to every run.

### C12R2-I1 (Info) — dangling Javadoc blocks

`TransitLedger.java:503-512`: the old Javadoc of `retireWithoutLiveState` now sits
directly above the new Javadoc of `retire` (two consecutive `/** … */` blocks), so it
documents nothing and `retireWithoutLiveState` has none. `EndgameService.java:87-89`: the
Javadoc of `transitOperations()` ("Operator and owner actions on the ledger…") now sits
above the Javadoc of `barrierSpacing()`, and `transitOperations()` (line 93) has none. Move
each block back above its method.

### C12R2-I2 (Info) — the I4 note's remedy does not work

The log entry for C12R-I4 says a purge of a `CLAIMED` record leaves the payload to the paid
endpoint's incoming gate, and "to discard such a payload, an operator resolves the endpoint
instead". At a registered endpoint, `TransitOperations.resolve` handles only frozen
conflicts (`if (!frozen && !conflicts.contains(key)) continue;`), so the resolve does nothing
and the gate still delivers the payload. Breaking the endpoint does not discard it either: a
removal treats an incoming payload whose record is gone as the endpoint's own content and
drops it as items. Probe `p6_aResolveOfARegisteredEndpointLeavesAPurgedClaimsPayloadAlone`
passes (`Resolved` is all zero and the payload stays incoming). No duplication or loss;
correct the note, which the C13 operator guide will copy. There is no command that
discards such a payload; if one is needed, it needs a contract change.

### C12R2-I3 (Info) — admitted spaced requests use up their slot even when nothing changes

`BarrierSpacing.admit` records the request when it admits it, which is before the work.
The slot is spent although nothing changes in these cases:
- a bind whose barrier write fails is taken back (C12R-I5) and answers `ROOT_BUSY`, but its
  station cannot retry for 100 ticks (`ElevatorPairs.java:137-161`);
- an owner redirect whose pre-flush of a pending root fails answers `ROOT_BUSY` after
  `admit` (`TransitOperations.java:113-120`);
- an owner resolve is admitted in `TransitCommands.resolve` before the resolve finds
  anything to do, so a resolve with nothing frozen still takes the server-wide slot.

None of these lets anything through (the error is conservative), and ADR-054 §7 only
requires refusals before a change. If retries after a failed write matter, admit after the
write or release the slot on these paths. Note also, for the operator guide, that every
unbind, including an operator's, starts the shared 20-tick spacing for all players' binds,
owner redirects and owner resolves.

### C12R2-I4 (Info, unconfirmed) — GameTests couple through the server-wide spacing

`BarrierSpacing` is server-wide runtime state, and the GameTest server runs every batch in
one server. Non-operator binds (`ElevatorGameTests.java:189, 273, 397, 535`), the
cargo test's player unbind, and the railgun menu test's owner resolve each use the
20-tick slot. A batch's first bind comes about 1 to 21 ticks after the batch starts, so a
spaced request at the end of one batch can refuse the next batch's bind with `ROOT_BUSY`.
The current batch order, which vanilla derives from the batch names' hash order,
places other batches between them (for example `endgame_elevator_spacing`, then
`flight_recovery`, then `endgame_railgun_menu`), so all runs passed. Adding or renaming a
batch can change that order. Use operator binds where spacing is not under test, or clear
the spacing in a `@BeforeBatch`.

### C12R2-I5 (Info) — the source and paid-endpoint restore rule has no isolating test

`ed1e453` changed `TransitCodecTest` (lines 120-128): the "orphan" case now replaces the
record's **source** with an unknown UUID and expects `IllegalArgumentException`. The same
root then also fails the next check ("a transit record is above its source's
dispatched_through", because `dispatched_through` of the unknown source is 0), so the
assertion holds without the source rule. No test covers an unknown paid endpoint.

MUTATION-RESULT-PLACEHOLDER

Give the case a `dispatched_through` entry for the new source (or test the paid endpoint)
so only the rule under test can reject it.

### C12R2-I6 (Info) — the L1 region rule loses a twice-orphaned elevator transfer

`ElevatorRedirectRule.java` (L1): a target other than the source must be in the pair of
the station whose region holds the record's **source or destination**. A redirect
overwrites `destination`. If elevator cargo from anchor A to terminal T is first redirected
back to A (T removed) and A is then removed before it claims, the record names A twice and
neither is in the station's region. The station's rebuilt pair is then refused
(`ROUTE_REFUSED`), and so is any operator redirect, because the route rule binds operators
too; only `transfer purge`, which destroys the payload, remains. ADR-059 §6 / R3-L4 intends
that "a pair rebuilt after both ends were removed can still receive it". This needs two
removals around one redirect, so it is Info. A fix would keep the original terminal side
(or its station) on the record, or let an operator choose any station's current pair of the
original destination's kind.
