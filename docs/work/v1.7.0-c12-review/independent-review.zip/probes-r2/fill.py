import sys

report = sys.argv[1]
key = sys.argv[2]
source = sys.argv[3]
with open(report, encoding='utf-8') as handle:
    text = handle.read()
with open(source, encoding='utf-8') as handle:
    value = handle.read().rstrip() + '\n'
if key not in text:
    raise SystemExit('missing key ' + key)
text = text.replace(key, value.rstrip('\n') if not value.endswith('\n\n') else value)
with open(report, 'w', encoding='utf-8') as handle:
    handle.write(text)
print('filled', key)
