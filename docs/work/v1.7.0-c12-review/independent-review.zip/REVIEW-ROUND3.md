# C12 independent review — round 3 (confirmation of the round-2 dispositions)

Date: 2026-10-02. Reviewer: independent, read-only (rounds 1 and 2: `REVIEW.md`,
`REVIEW-ROUND2.md`). Branch `codex/v1.7.0-endgame-systems`, range
**`3c681dd8..10d9b12f`**. The C12 round-2 fix commits are `16a71bab` (C12R2-L1),
`e8a5c12c` (C12R2-I1), `8a68b15b` (C12R2-I5), `83f1b9c4` (C12R2-I2) and `10d9b12f`
(C12R2-I3, I4, I6 recorded as accepted). `ccc861c0`, `d8a916d4`, `23acc49f` and
`aab2cb85` are C13 work: I glanced at them, and no verdict is given.

The tree was exported with `git archive 10d9b12f` into
`C:/Users/Administrator/AppData/Local/Temp/arce-v170-c12-review-k7q2/tree-r3`. Nothing in
the repository was written, and `AdvancedRocketry-Community-v1plus-Development-Docs/` was
not opened. No Gate, candidate or tag is claimed.

## 1. What I ran (`JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, Gradle 8.8 `--offline`)

| Command | Result | Log (under `logs-r3/`) |
|---|---|---|
| `./gradlew clean build test runData runGameTestServer --offline` on the fresh export | **BUILD SUCCESSFUL** in 7 min 18 s. JUnit: **1,364 tests / 251 suites, 0 failures, 0 errors, 0 skipped** (1,363 in round 2, plus the new restore-rule test). GameTest on a newly generated world (18.1 s spawn preparation): **All 335 required tests passed** (333 in round 2, plus the 2 C13 destruction tests). 18 `ERROR` lines (the failure-injection set), 0 `FATAL` | `full-run1.log` |
| DataGen: SHA-256 of `src/generated` before and after | All 395 tracked files are byte-identical. The only additions are 8 files under `src/generated/v1.7/resources/.cache/`, which `.gitignore` ignores | `generated-{before,after}.sha256` |
| `./gradlew runGameTestServer --offline` twice more, each on a new world (20.8 s and 14.4 s spawn preparation) | **All 335 required tests passed** both times | `gametest-run2.log`, `gametest-run3.log`, `summary.txt` |
| `./gradlew test --offline --tests '*C12ReviewProbeTest'` (the round-1 and round-2 probes) | p1, p1b, p2, p3, p4, p5 **fail at their `PROBE:` assertions**, as in round 2: the round-1 defects stay fixed. p6 **passes**: a resolve at a registered endpoint still leaves a purged claim's payload alone, which the corrected I2 note now states | `probe-run.log`, `TEST-…C12ReviewProbeTest.xml` |
| Mutation checks of the restore rule in `EndgameRoot.finishRestore` (endgame JUnit suites each time; original restored, SHA-256 `20794d75…1c24`) | Rule removed: the new test **fails**. Paid-endpoint half removed: the new test **fails**. Source half removed: **all pass** (see C12R3-I1) | `mutation-{A,B,C}.log` |
| Masking probe: two optional GameTests through `EntitySections.whenLoaded` (`probes-r3/C12R3MaskingProbeGameTests.java`, added to the export only for this run and then removed) | Both **fail**, as they must: a chunk whose entities never load fails with "The test chunk's entities have not loaded yet", and a body assertion failure fails the test ("C12R3 probe: body assertion failed"). All required tests still passed (vanilla's summary line counts all 337 tests) | `masking-probe-run.log` |

## 2. Verdict

**C12a, C12b, C12c and C12d: accept** (unchanged from round 2). Every round-2 finding is
fixed, or recorded as accepted with a reason that I agree with. Across rounds 2 and 3
there were eight GameTest runs, all on newly generated worlds, and every required test
passed in each. One new
Info finding: a Javadoc wording nit, no code change needed.

## 3. Confirmation of the round-2 findings

| ID | Sev. | Disposition | Confirmed | Evidence |
|---|---|---|---|---|
| C12R2-L1 | Low | Fixed in `16a71bab`: `EntitySections.whenLoaded` waits (`thenWaitUntil`) until `areEntitiesLoaded` holds at the test chunk(s), then runs the unchanged body and succeeds; applied to every `RocketAdapterFailureFixture` test (`RocketAdapterFailureGameTests`, including the two delegating helpers, and all of `RocketDisassemblyGameTests`) and to the fuel-loader test. The I6 log entry names both causes | **Yes** | `git diff -w` shows that only the wrapper, the removed trailing `helper.succeed()` and some line wraps changed. No body has an early `return` or its own sequence, and the fixture still asserts `areEntitiesLoaded` itself. **No masking:** the probe shows that a section that never loads fails by timeout, and that a failing body fails. A plain `RuntimeException` in a body now propagates out of a sequence event instead of out of the test method, but it still fails loudly and never reads as a pass. Timeouts are unchanged (40 ticks), so a slow section is a failure, not a hidden wait. The four fresh-world GameTest runs of this round all passed |
| C12R2-I1 | Info | Fixed in `e8a5c12c` | **Yes** | `TransitLedger.retireWithoutLiveState` and `EndgameService.transitOperations` have their Javadoc again; no dangling blocks remain |
| C12R2-I2 | Info | Fixed in `83f1b9c4` (log and `docs/ENDGAME-OPERATOR-GUIDE.md`) | **Yes** | Both now say that a purge of a `CLAIMED` record leaves delivery to the paid endpoint and that `endpoint resolve` at a registered endpoint acts only on frozen conflicts; probe p6 agrees |
| C12R2-I3 | Info | Accepted (`10d9b12f`): the spacing counts admitted requests, which errs toward fewer root writes | **Agree** | Nothing gets through; at worst a player retries after the wait |
| C12R2-I4 | Info | Accepted (`10d9b12f`): batches run one after another, and binds that must follow an unbind inside a test are an operator's | **Agree** | The log's statement that each player bind is at least 20 ticks after any other batch's spaced request holds in practice (8 of 8 runs passed) but nothing enforces it; the note tells later test authors to wait as players do, which is enough |
| C12R2-I5 | Info | Fixed in `8a68b15b`: `TransitCodecTest.theRestoreRuleRefusesAnUnknownSourceOrPaidEndpoint` | **Yes**, with a wording nit (C12R3-I1) | Removing the rule, or only its paid-endpoint half, fails the new test. The source half cannot be isolated: see C12R3-I1 |
| C12R2-I6 | Info | Accepted (`10d9b12f`): a redirect back to an anchor source that is later removed leaves only a purge; recording the original destination would change the record format | **Agree** | The residual is documented, and the operator guide's purge rules apply |

## 4. Round-1 findings, re-checked

Nothing in this range touches the production code of the round-1 fixes, apart from the two
moved Javadoc blocks (C12R2-I1). The round-1 probes still fail their `PROBE:` assertions
(H1 via p1/p1b, M1 via p2, L2 via p3, L3 via p4, L4 via p5). The suites stay green, so the
round-2 status table in `REVIEW-ROUND2.md` §4 stands unchanged.

## 5. New finding (round 3)

### C12R3-I1 (Info) — the new restore test's Javadoc overstates what it isolates

`TransitCodecTest.theRestoreRuleRefusesAnUnknownSourceOrPaidEndpoint` says that "the
refused roots differ from a valid one only in that, so no other check refuses them
first". For the unknown-**source** root that is not so. The copied `dispatched_through`
section still names the source, so `finishRestore`'s first check ("A dispatched_through
entry names no endpoint or tombstone") refuses it before the record rule runs.
Mutation B confirms it: with the source half of the rule removed (the paid half kept),
every endgame test passes. The commit message says this correctly. The source half is in
fact implied by two other restore checks (a record's `seq` must be at or below its source's
`dispatched_through`, and every `dispatched_through` entry must name an endpoint or
tombstone), so no test can isolate it, and none needs to. The fix is to word the Javadoc as
the commit message does. No code change is needed.

## 6. Limits

- No forced-stop crash testing (C13), no client or multiplayer checks.
- The C13 commits in the range were only glanced at. `ElevatorReleaseTestCommands` and
  `EndgameReleaseTestCommands` register nothing unless the JVM flag
  `advancedrocketrycommunity.releaseTestHooks` is set, and are operator-only when it is.
  `EndgameDestructionGameTests` passed in all runs.
- At the end of this round the repository's `HEAD` was `10d9b12f`, with an untracked
  `docs/work/v1.7.0-c12-review/` that this review did not create.
