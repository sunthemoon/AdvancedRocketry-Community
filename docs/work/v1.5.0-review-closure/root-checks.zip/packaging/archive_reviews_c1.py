"""Archive the two independent reviews handled by C1 into the review-closure packet."""
import hashlib
import json
import zipfile
from pathlib import Path

OUT = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-review-closure')
TEMP = Path('C:/Users/Administrator/AppData/Local/Temp')
REVIEWS = [
    ('independent-review-warp', TEMP / 'arce-v150-warp-review-b42c92ae0c3f8a585f4f4b526c215583',
     ('tree-', 'prev-review/', 'packets/', '__pycache__/'), ['0416455', '615a5f1', '1a5763a']),
    ('independent-review-contracts', TEMP / 'arce-v150-elevator-ui-review-bb661d39bfc2c602c71f3cbf41fb7981',
     ('prev-review/',), ['2900e66']),
]
sha = lambda b: hashlib.sha256(b).hexdigest()
ev = json.loads((OUT / 'evidence-archives.json').read_text())
for name, src, excluded, commits in REVIEWS:
    rows = []
    with zipfile.ZipFile(OUT / f'{name}.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(src.rglob('*')):
            rel = p.relative_to(src).as_posix()
            if p.is_file() and not any(rel.startswith(prefix) or ('/' + prefix) in rel for prefix in excluded):
                data = p.read_bytes()
                z.writestr(zipfile.ZipInfo(rel, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
    (OUT / f'{name}-files.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n',
                                           encoding='utf-8', newline='\n')
    raw = (OUT / f'{name}.zip').read_bytes()
    ev['archives'] = [a for a in ev['archives'] if a['name'] != f'{name}.zip']
    ev['archives'].append({'name': f'{name}.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
                           'manifest': f'{name}-files.json', 'source_directory': str(src),
                           'excluded': list(excluded), 'reviewed_commits': commits})
    print('PASS', name, len(rows), len(raw), sha(raw))
(OUT / 'evidence-archives.json').write_text(json.dumps(ev, indent=2, sort_keys=True) + '\n', encoding='utf-8',
                                            newline='\n')
