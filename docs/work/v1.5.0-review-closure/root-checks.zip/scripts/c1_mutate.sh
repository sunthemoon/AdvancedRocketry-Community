#!/bin/sh
# Usage: c1_mutate.sh <evidence dir>. Applies each mutation alone, runs the focused tests, restores.
E="$1"
cd /d/GitHub/AdvancedRocketry-Community || exit 2
export JAVA_HOME="/c/Program Files/Java/jdk-17.0.7"
REG=src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/persistence/StationRegistrySavedData.java
BUD=src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/persistence/StationStorageBudget.java
mkdir -p "$E/mutations"
: > "$E/mutations/mutation-results.tsv"
run() {
  id="$1"; file="$2"; old="$3"; new="$4"; tests="$5"
  cp "$file" "$E/mutations/backup.java"
  python - "$file" "$old" "$new" <<'EOF'
import sys
p, old, new = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(p, encoding='utf-8').read()
assert s.count(old) == 1, ('mutation anchor', old)
open(p, 'w', encoding='utf-8', newline='\n').write(s.replace(old, new))
EOF
  ./gradlew test $tests > "$E/mutations/$id.log" 2>&1
  code=$?
  cp "$E/mutations/backup.java" "$file"
  if [ $code -ne 0 ]; then verdict=KILLED; else verdict=SURVIVED; fi
  printf '%s\t%s\texit=%s\n' "$id" "$verdict" "$code" | tee -a "$E/mutations/mutation-results.tsv"
}
run M20-transfer-unchecked "$REG" \
  "        requireStorageRoom(StationLimits.MAX_TEAM_ENTRY_GROWTH_NBT_BYTES);
        StationState result = registry.transferOwnership(stationId, ownerId);" \
  "        StationState result = registry.transferOwnership(stationId, ownerId);" \
  "--tests *StationRegistryStorageBoundTest"
run M18-relocation-unchecked "$REG" \
  "            requireStorageRoom(growth);" "" "--tests *StationRegistryStorageBoundTest"
run M22-quarantine-accepted "$REG" \
  "return operational() && !updatesQuarantined;" "return operational();" "--tests *StationCheckedUpdateTest"
run R4-entry-at-growth-limit "$BUD" \
  "        return fits(records, balances, encodedBytes, StationLimits.MAX_WARP_ENERGY_ENTRY_NBT_BYTES,
                StationLimits.MAX_REGISTRY_NBT_BYTES);" \
  "        return fits(records, balances, encodedBytes, StationLimits.MAX_WARP_ENERGY_ENTRY_NBT_BYTES,
                GROWTH_LIMIT);" "--tests *StationStorageBudgetTest --tests *StationRegistryStorageBoundTest"
run R13-check-inflates "$BUD" \
  "        return fits(records, balances, encodedBytes, growthBytes, GROWTH_LIMIT);" \
  "        boolean fits = fits(records, balances, encodedBytes, growthBytes, GROWTH_LIMIT);
        grew(growthBytes);
        return fits;" "--tests *StationStorageBudgetTest"
rm -f "$E/mutations/backup.java"
git diff --stat -- "$REG" "$BUD"
