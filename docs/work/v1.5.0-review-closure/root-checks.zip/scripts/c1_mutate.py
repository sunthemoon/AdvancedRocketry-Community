"""Applies each mutation alone, runs the focused tests, and restores the file. Usage: c1_mutate.py <E>."""
import os
import subprocess
import sys
from pathlib import Path

E = Path(sys.argv[1]) / 'mutations'
E.mkdir(parents=True, exist_ok=True)
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
PKG = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station/persistence'
REG = PKG / 'StationRegistrySavedData.java'
BUD = PKG / 'StationStorageBudget.java'
env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

MUTATIONS = [
    ('M20-transfer-unchecked', REG,
     """        requireStorageRoom(StationLimits.MAX_TEAM_ENTRY_GROWTH_NBT_BYTES);
        StationState result = registry.transferOwnership(stationId, ownerId);""",
     """        StationState result = registry.transferOwnership(stationId, ownerId);""",
     ['--tests', '*StationRegistryStorageBoundTest']),
    ('M18-relocation-unchecked', REG, """            requireStorageRoom(growth);""", "",
     ['--tests', '*StationRegistryStorageBoundTest']),
    ('M06-invite-unchecked', REG,
     """        requireStorageRoom(StationLimits.MAX_TEAM_ENTRY_GROWTH_NBT_BYTES);
        StationState result = registry.invite(stationId, playerId);""",
     """        StationState result = registry.invite(stationId, playerId);""",
     ['--tests', '*StationRegistryStorageBoundTest']),
    ('M22-quarantine-accepted', REG, "return operational() && !updatesQuarantined;", "return operational();",
     ['--tests', '*StationCheckedUpdateTest']),
    ('R4-entry-at-growth-limit', BUD,
     """        return fits(records, balances, encodedBytes, StationLimits.MAX_WARP_ENERGY_ENTRY_NBT_BYTES,
                StationLimits.MAX_REGISTRY_NBT_BYTES);""",
     """        return fits(records, balances, encodedBytes, StationLimits.MAX_WARP_ENERGY_ENTRY_NBT_BYTES,
                GROWTH_LIMIT);""",
     ['--tests', '*StationStorageBudgetTest', '--tests', '*StationRegistryStorageBoundTest']),
    ('R13-check-inflates', BUD,
     """        return fits(records, balances, encodedBytes, growthBytes, GROWTH_LIMIT);""",
     """        boolean fits = fits(records, balances, encodedBytes, growthBytes, GROWTH_LIMIT);
        grew(growthBytes);
        return fits;""",
     ['--tests', '*StationStorageBudgetTest']),
]

results = []
for name, path, old, new, tests in MUTATIONS:
    original = path.read_bytes()
    text = original.decode('utf-8')
    assert text.count(old) == 1, (name, 'anchor')
    path.write_bytes(text.replace(old, new).encode('utf-8'))
    try:
        with open(E / f'{name}.log', 'wb') as log:
            code = subprocess.call(['sh', './gradlew', 'test', *tests], cwd=ROOT, env=env,
                                   stdout=log, stderr=subprocess.STDOUT)
    finally:
        path.write_bytes(original)
    verdict = 'KILLED' if code != 0 else 'SURVIVED'
    results.append(f'{name}\t{verdict}\texit={code}')
    print(results[-1], flush=True)
(E / 'mutation-results.tsv').write_text('\n'.join(results) + '\n', encoding='utf-8', newline='\n')
