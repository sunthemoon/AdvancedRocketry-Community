"""Combined GameTest mutation runs: each mutation targets a different test. Usage: c1_gt_mutate.py <E>."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

E = Path(sys.argv[1]) / 'gametest-mutations'
E.mkdir(parents=True, exist_ok=True)
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
S = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'
WARP = S / 'station/warp/StationWarpService.java'
ROCKET = S / 'rocket/entity/RocketEntity.java'
env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

M = {
    'M02-actor-recheck-removed': (WARP, """        if (!station.ownerId().equals(confirmed.actorId())
                && server.getProfilePermissions(confirmed.actor()) < 2) {""", """        if (false) {"""),
    'M10-kill-switch-at-commit-removed': (WARP, """        if (!settings.get().enabled()) {
            return StationWarpResult.of(StationManagementCode.WARP_DISABLED, confirmed.observed());""",
                                          """        if (false) {
            return StationWarpResult.of(StationManagementCode.WARP_DISABLED, confirmed.observed());"""),
    'M03-all-due-commit-together': (WARP, """        countdowns.nextDue(now).ifPresent(countdown -> {
            countdowns.cancel(countdown.quote().stationId());
            commit(server, countdown.quote());
        });""", """        for (StationWarpCountdowns.Countdown countdown : countdowns.all()) {
            if (countdown.dueTick() <= now) {
                countdowns.cancel(countdown.quote().stationId());
                commit(server, countdown.quote());
            }
        }"""),
    'M11-local-check-before-take-removed': (WARP, """        if (!StationLocalActor.localPlayer(server, player, issuedByPlayer)) {
            // Rejected before take(): another source cannot consume the player's confirmation.
            return audit("confirm", player, StationWarpResult.of(StationManagementCode.NOT_LOCAL_PLAYER, null));
        }
""", ""),
    'M12-station-built-records-space-body': (ROCKET,
                                             """? stationOrbit(serverLevel, station.instanceId(), dimension) : bodyForDimension(dimension),""",
                                             """? bodyForDimension(dimension) : bodyForDimension(dimension),"""),
    'M27-level-check-removed': (WARP, """        if (maxReceive <= 0 || !server.isSameThread() || !level.dimension().equals(CelestialIds.SPACE_LEVEL)
                || server.getLevel(CelestialIds.SPACE_LEVEL) != level) {""",
                                """        if (maxReceive <= 0 || !server.isSameThread()) {"""),
    'M16-thread-check-removed': (WARP, """        if (maxReceive <= 0 || !server.isSameThread() || !level.dimension().equals(CelestialIds.SPACE_LEVEL)""",
                                 """        if (maxReceive <= 0 || !level.dimension().equals(CelestialIds.SPACE_LEVEL)"""),
}
RUNS = {
    'set-a': ['M02-actor-recheck-removed', 'M10-kill-switch-at-commit-removed', 'M03-all-due-commit-together',
              'M11-local-check-before-take-removed', 'M12-station-built-records-space-body', 'M27-level-check-removed'],
    'set-b': ['M16-thread-check-removed'],
}

for run, names in RUNS.items():
    originals = {}
    try:
        for name in names:
            path, old, new = M[name]
            originals.setdefault(path, path.read_bytes())
            text = path.read_text(encoding='utf-8')
            assert text.count(old) == 1, (name, 'anchor')
            path.write_bytes(text.replace(old, new).encode('utf-8'))
        (E / f'{run}-mutations.txt').write_text('\n'.join(names) + '\n', encoding='utf-8', newline='\n')
        with open(E / f'{run}-gradle.log', 'wb') as log:
            code = subprocess.call(['sh', './gradlew', 'runGameTestServer'], cwd=ROOT, env=env,
                                   stdout=log, stderr=subprocess.STDOUT)
    finally:
        for path, data in originals.items():
            path.write_bytes(data)
    shutil.copy(ROOT / 'build/gametest/logs/latest.log', E / f'{run}-gametest-latest.log')
    print(run, 'exit', code, flush=True)
