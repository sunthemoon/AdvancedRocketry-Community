# Independent contract review: ADR-045 (space elevator endpoint) and ADR-046 (v1.5 station controls are commands)

```yaml
reviewed_commit: 2900e66c9776b68a3fd4eeeabf3ec5073820416a
branch: codex/v1.5.0-orbital-station-warp
review_type: independent contract review (pre-implementation), read-only
reviewer_role: independent reviewer, not the author, no maintainer authority
date: 2026-09-30
verdict_ADR-045: ACCEPT WITH CHANGES
verdict_ADR-046: ACCEPT WITH CHANGES
critical: 0
high: 2 (both ADR-046)
medium: 9 (ADR-045: F45-1..F45-4; ADR-046: F46-3..F46-7)
low: 7 (ADR-045: F45-5..F45-8; ADR-046: F46-8..F46-10)
info: 2 (F45-9, F46-11)
gate_approval: NONE
```

## 1. Inputs and method

All repository content was read from the commit with `git show 2900e66:<path>`. Nothing in the
repository was written, and no git state was changed. The untracked documentation bundle was not
read. Gradle was not run, so none of the claims below comes from test execution; they come from
reading the committed source and documents.

Documents:
- `docs/decisions/ADR-045-SPACE-ELEVATOR-ENDPOINT-CONTRACT.md` and
  `docs/decisions/ADR-046-V150-STATION-CONTROLS-ARE-COMMANDS.md` (the reviewed drafts).
- `docs/versions/V1.5.0-ORBITAL-STATION-WARP.md` (§1-§19), `docs/versions/V1.7.0-ENDGAME-SYSTEMS.md`,
  `docs/04-VERSION-ROADMAP.md` (line 63), `docs/16-POST-1.0-VERSION-ROADMAP.md`,
  `docs/17-V1PLUS-QUALITY-BUDGETS.md` (§2, §3, §5, §6, §8), `docs/05-MASTER-TEST-PLAN.md` (§9),
  `docs/06-RELEASE-AND-ACCEPTANCE-GATES.md` (G6, G8), `docs/PORTING_MATRIX.md`,
  `docs/status/CURRENT_VERSION.md`, `AGENTS.md`.
- ADR-039, ADR-040, ADR-041, ADR-043, ADR-044 (rev. 3). Only ADR-039/040/041/043/044 are accepted.
- `docs/work/v1.5.0-implementation-log.md` (feature map, UI and ELEVATOR leaves, decision log).

Code, all at `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`:
- `station/command/StationCommands.java`, `station/command/StationWarpCommands.java`
- `station/service/StationLocalActor.java`, `StationAccessService.java`, `StationAccessAction.java`,
  `StationManager.java`, `StationManagementCode.java`
- `station/warp/StationWarpService.java`, `StationWarpCountdowns.java`
- `station/forge/StationPlatformGenerator.java`, `station/persistence/StationRegistrySavedData.java`
- `celestial/service/PlanetarySurfaceResolver.java`, `celestial/model/CelestialBodyDefinition.java`,
  `travel/model/TravelTarget.java`, `rocket/server/RocketFlightService.java`
- The four `*Network.java` protocol constants and the tests that pin them.
- `gametest/StationExpansionGameTests.java`, `StationWarpGameTests.java`, `StationGameTests.java`,
  `StationOrbitGameTests.java`, `StationProtectionGameTests.java`

`git diff --name-only 6f530ac 2900e66` (274 files) contains no path under `network/` or `client/`.

## 2. Scope answers

**ADR-045 is in scope for v1.5 and does not over-deliver.** Plan §3 item 8 asks for a "basic space
elevator connection contract, which may be incomplete". §6.10 asks for an "endpoint contract and
placeholder validation" without widening scope, and §4 excludes full elevator logistics. ADR-039
lists "a bounded elevator endpoint contract" as a required v1.5 outcome. The player-facing elevator
is v1.7 work: V1.7 §3 lists "space elevator basic logistics loop", `04-VERSION-ROADMAP.md:63` puts
the space elevator in v1.7, and V1.7 §2 requires an independent ADR and threat model for each
endgame system. No blocks, persistence, transport, packet or API method are proposed, so nothing
here is premature v1.7 implementation.

The ADR's "Rules fixed now for a later implementation" section does reach into v1.7 decisions. Its
invariants (lifecycle, warp interlock, journaled transport, fail closed) are appropriate. Freezing
the storage location ("owned by the station record") is not; see F45-3 and F45-8.

**An operator-only, read-only check command is an appropriate placeholder validation**, on four
conditions. The permission requirement sits on the leaf itself (F45-4). The arguments are bounded
at parse. The command loads no chunk in any Level and leaves every SavedData clean. It is declared
a diagnostic surface with no stability promise. Together with the pure validator and its tests, it
meets §6.10 and gives §12.5 ("no dangerous elevator write interface") concrete evidence.

**ADR-046's core decision, commands with no screen and no packet, is defensible.** The plan never
requires a screen. ADR-044 §7 already chose commands for warp and deferred any screen. AGENTS §3.1
forbids frameworks that the current version does not use. The draft still needs changes before
acceptance. It closes UI-01/UI-02 "by this record", which conflicts with accepted ADR-039 and with
`CURRENT_VERSION.md` (F46-1). It defines the §15 report as log lines with no oracle and at the wrong
evidence level (F46-2). Its protocol claim covers the whole version, which pre-empts ORBIT-03
(F46-3).

## 3. ADR-045 findings

### F45-1 (Medium): the authority rule is ordered last and leaks state to unauthorized requesters

Rule 5 (owner or operator) is evaluated after rules 2-4. A future player path would therefore tell
a non-owner the station's current orbit body (rule 2 passes or fails), catalog and Level status
(rule 3), and border position (rule 4) before it says "unauthorized". The existing code checks in
the safe order: `StationWarpService.status` checks VISIT before disclosing anything, and
`StationManager.requireAllowed` runs before any mutation. In v1.5, rule 5 also cannot be reached
through the command, because the command is operator-only.

Proposed wording: "1. the station registry is operational and the station exists; 2. the requester
is the station's owner or a permission-level-2 operator; 3. the body is the station's current orbit
body; 4. … (catalog/Level); 5. … (column bounds). Rule 2 is exercised on the pure validator in v1.5,
because the command admits only operators."

### F45-2 (Medium): the future warp interlock conflicts with ADR-044 evacuation and has no unbind path

The fixed rules say that a station with a bound pair may not warp, and that a pair on a missing,
unmapped or absent Level is "reported invalid and nothing is deleted". ADR-044 §4 (Evacuation) lets
a station whose orbit body is unavailable warp to any valid target. Together these rules would
strand a bound station in an unavailable orbit forever, because nothing defines unbinding.

The interlock's check points are also not stated. ADR-044 checks the in-motion rule at request, at
confirm and at commit.

Proposed wording:
- "The owner or an operator can always unbind a pair, whatever its validity. Unbinding is a
  server-side station write that never loads the far end's chunks."
- "Warp, including evacuation, is refused while a pair is bound. It is checked at request, at
  confirmation and against the live state inside the checked relocation. If the pair is part of the
  observed station state, a bind after confirmation makes the commit STALE."
- "Station deletion fails closed while an elevator transport record references the station, as the
  rocket guard does (ADR-044 §5)."
- "The implementing ADR adds named transitions 'bind pair' and 'unbind pair' to ADR-041's checked
  update list, and extends ADR-044 §3's relocation predicate."

### F45-3 (Medium): no reconciliation with ADR-039, and v1.7 decisions are frozen too early

ADR-039 (accepted) says: "Metadata, a diagnostic command or passing unit tests alone cannot
substitute for these outcomes." One of those outcomes is the elevator endpoint contract. ADR-045
delivers a model, a diagnostic command and tests. An auditor who applies ADR-039 literally will
reject this unless the ADR explains why the validator is the outcome itself.

The section title "Rules fixed now for a later implementation" also binds v1.7. V1.7 §2 requires
v1.7's own ADR and threat model. V1.7 §5 requires cross-dimension targets to use
TravelTarget/BodyContext, and V1.7 §8 requires each system to introduce its own schema.

Proposed wording:
- Add a "Relation to ADR-039 and v1.7" paragraph: "Plan §3/§6.10 defines this outcome as a contract
  plus placeholder validation that may be incomplete. The validator and its tests are that outcome,
  not a stand-in for a player feature. The player-visible elevator (structure, climber, transport,
  logistics) is v1.7 scope (V1.7 §3; roadmap v1.7)."
- Rename the section to "Constraints handed to the v1.7 elevator ADR": "v1.7 must satisfy these
  constraints or supersede them explicitly in its own ADR and threat model."

### F45-4 (Medium): the command could strip the permission check from every admin command

Brigadier merges literal nodes of the same name. `CommandNode.addChild` keeps the requirement of
the node registered first and discards the requirement of a later duplicate. Today
`StationCommands` and `StationWarpCommands` both register `station → admin` with
`.requires(hasPermission(2))`, so the result is safe. A third `admin` registration without
`.requires` that registers first would remove the permission check from `inspect`, `delete`,
`transfer` and every other admin leaf.

Proposed wording: "The `elevator` literal carries `.requires(source -> source.hasPermission(2))`
itself, independent of the shared `admin` node. Arguments are `UuidArgument`, `ResourceLocationArgument`
and `IntegerArgumentType.integer(-30_000_000, 30_000_000)` for x and z. The ADR-046 matrix asserts
that a non-operator cannot run any admin leaf." The same leaf-level guard is recommended for the
existing admin leaves.

### F45-5 (Low): rule 3 is imprecise

The phrase "mapped to a loaded server Level (CelestialCatalog / PlanetarySurfaceResolver rules)"
mixes several things:
- `PlanetarySurfaceResolver.find` resolves a Level to a body, not a body to a Level. It returns
  empty unless exactly one catalog body maps to that Level.
- The existing predicate is `CelestialBodyDefinition.supportsSurfaceArrival()`: landable, mapped,
  and not the Space Level.
- Levels in this rewrite are fixed (ADR-031). "Unloaded Level" can only mean
  `server.getLevel(key) == null`.

Proposed wording: "3. in the catalog captured once for this check (rules 2 and 3 read the same
capture), the body satisfies `supportsSurfaceArrival()`; `server.getLevel(levelKey)` is present;
and `PlanetarySurfaceResolver.find(catalog, levelKey, true)` returns this body. A Level shared by
several bodies is rejected." In the missing-body sentence, replace "unloaded Level" with "a Level
absent from this server".

### F45-6 (Low): the station end is well defined but cites no source and overlaps rocket landing

ADR-040 fixes the pad at `(cx,128,cz)` for both 512 and 768 widths: "The pad stays (cx,128,cz)".
Expansion never moves it, and migration validates legacy pads at the cell center. So "the station's
landing-pad column" is well defined for expanded regions, but the ADR should cite ADR-040 for it.
That column is also where rockets land.

Proposed wording: "The station end is derived from the committed record (the ADR-040 pad column,
invariant under expansion). v1.7 may choose a physical attachment point inside the committed region
that does not obstruct rocket landing."

### F45-7 (Low): the verification list is incomplete and "pure" is undefined

Add these checks:
- The loaded-chunk count is unchanged in every ServerLevel (Space, the target body's Level and the
  Overworld), not only one.
- No SavedData becomes dirty; the station registry in particular stays clean.
- Unknown station UUID; blocked or quarantined registry.
- A catalog reload that removes the body or remaps its Level.
- A world-border shrink that excludes a previously valid column.
- Rule 2 (authority, after reordering) tested on the pure validator.
- Output is one bounded line, and one `ARCE_STATION_ELEVATOR_CHECK` audit log line is written.
- The required short commands run; API class bytes and generated files are unchanged.

Define "pure": "The validator is a function over a snapshot (station view, captured catalog,
Level-presence predicate, border predicate). A thin Forge adapter builds the snapshot." Add a
one-paragraph threat note: operator-only, O(1), no chunk access, no writes.

### F45-8 (Low): decisions the v1.7 ADR should inherit to avoid later migration surprises

v1.5 persists nothing, so this ADR creates no migration. Committing now to storage "owned by the
station record" would force the following in v1.7:
- a record schema 3 and root migration;
- a share of the 4 MiB registry bound, which interacts with ADR-044's 256 KiB growth admission;
- a new ADR-041 transition.

V1.7 §8 instead expects each system to introduce its own schema. Record the following as open v1.7
decisions, and fix only the invariant "validity is always re-derived from live state, so any
cross-store save-order crash fails closed":
- the storage location;
- storing the Level key observed at bind time, with a changed mapping treated as invalid (ADR-043
  re-parenting and data-pack remaps);
- a never-reused pair UUID for transport journals;
- cardinality: at most one pair per station, and column uniqueness across stations.

### F45-9 (Info): other verified points

- The station-end derivation, no client coordinates for the station side, and no chunk loading are
  consistent with ADR-040 and ADR-044.
- Rule 2 correctly makes a warp invalidate a pair.
- ADR-044 §8's traceability row for §12.5 ("Not applicable (none exposed)") should link ADR-045
  once ADR-045 is accepted.
- Recommended: say that the command path is a diagnostic surface with no stability promise and may
  be removed or renamed in v1.7. It is not persisted, so the v1.0+ stable-ID rule does not bind it.

## 4. ADR-046 findings

### F46-1 (High): UI-01/UI-02 are closed "by this record", contradicting ADR-039 and CURRENT_VERSION

The draft's Consequences section says: "UI-01 and UI-02 are satisfied by existing behaviour plus
this record."

- ADR-039 (accepted): "UI/security … Metadata, a diagnostic command or passing unit tests alone
  cannot substitute for these outcomes."
- `docs/status/CURRENT_VERSION.md`: "The per-station sky, UI screens, the elevator endpoint, … remain
  unimplemented current-version work, not metadata-only substitutes."
- The plan points toward client UI work: §7 gives the Permissions/UI workstream the `client` write
  scope, and §11.5 asks for GUI scale checks.

The decision to use commands is sound. The defect is that a proposed ADR silently changes an
accepted outcome and closes leaves by documentation.

Proposed wording:
- Add `amends: ADR-039 (v1.5 UI outcome is the server command interface; no screen)` to the YAML
  header, plus a "Relation to ADR-039" section that says why commands meet the "UI/security"
  outcome.
- Record the no-screen decision as a maintainer-accepted scope disposition. It needs:
  - an owner;
  - a reason;
  - the version at which a station/warp control screen is reconsidered (for example "no later than
    v1.8.0 classic content, with a PORTING_MATRIX row as PASSED_REDESIGNED or DEFERRED");
  - a recovery condition (a screen brings its own ADR and bounded, versioned payload, as the draft
    already says).
- Replace the Consequences line with: "UI-01 is verified by the protocol check (F46-3). UI-02 is
  verified by GameTests that capture the actual replies for every StationManagementCode and warp
  message. This record defines the target and closes nothing."
- The integrator updates the "UI screens" wording in `CURRENT_VERSION.md` after acceptance.

### F46-2 (High): the "multiplayer permission report" has no oracle and is at the wrong evidence level

The draft says the matrix "logs one `ARCE_STATION_PERMISSION_MATRIX` line per cell". It defines no
expected outcomes and no assertion. A log-only matrix records whatever the code does, and plan §9
says test code existing is not a passed test.

Several cells are undecided policy:
- Team commands (invite, remove, accept, decline) do not use the local-actor rule. They call
  `getPlayerOrException()` and use `source.hasPermission(2)` as the operator bypass. So `/execute as`,
  a silent own source, a FakePlayer (which is a `ServerPlayer`) and a remote owner or operator are
  presumably allowed, but no document says so.
- The console is refused player-only commands at the Brigadier level (`ERROR_NOT_PLAYER`), but that
  expectation is not stated.

Evidence level is also wrong. `docs/17 §2` assigns "multiplayer, passengers, permissions, sync" to
`V2` (two real clients) for G6/G8, and packaged dedicated-server behaviour to `S1`. A GameTest with
mock connections is `A1`, which can only support G3.

Proposed wording:
- Add a normative expected-outcome table: rows are actions, columns are actors, and each cell holds
  the expected `StationManagementCode`, exception text or Brigadier error.
- The GameTest asserts every cell against that table and fails on any difference. The log line is
  written after the assertion and carries both the expected and the actual value.
- The report has three levels:
  - A1: the full matrix;
  - S1: a named subset on the packaged candidate JAR, using the STATION-04 native harness with mock
    connections;
  - V2: a named subset with two real clients (outsider and member rejections visible,
    countdown/commit received), which stays open for ACC-02.

Section 6 gives the required report content.

### F46-3 (Medium): the protocol claim pre-empts ORBIT-03, and the proposed check is weak

The draft says "No v1.5 feature adds a C2S or S2C packet" and "No network protocol version
changes". ORBIT-03 is a planned v1.5 leaf ("Per-station sky/UI synchronization"). ADR-041 says
per-station sky "needs a synchronized context and a bounded protocol decision (ORBIT-03, separate
ADR)". Plan §11.1 and §13.5 assume per-station client sky.

On the check itself: only celestial "2" (`CelestialSnapshotV2Test`) and flight "8"
(`RocketFlightPlanPacketTest`, `RocketMaintenanceStructureTest`) are pinned. Life-support "1" and
visual "1" are not pinned. Pinning version strings also does not detect a new message type added
without a version bump.

Proposed wording:
- "The station, team and warp controls add no packet. This does not decide ORBIT-03, which may add
  a bounded S2C context under its own ADR and protocol bump."
- Check: "A test pins all four channel versions and each channel's registered message list against
  a committed table, which changes only with an ADR."
- Record `network_protocol: life 1 / celestial 2 / flight 8 / visual 1` in the plan YAML at ACC.

### F46-4 (Medium): the matrix is missing actions, actors and cases

Missing actions:
- `admin create`, `dump`, `recover-reservations`, `admin warp [station]` (WARP-05 diagnostics) and
  ADR-045's `admin elevator check`.
- BUILD: place and break inside a station region. `StationProtectionGameTests` covers only the
  unavailable-registry case.
- VISIT through the existing rocket flight C2S path. `RocketFlightService` checks
  `TravelTarget.Station` source and destination for VISIT. This is the only client packet that
  carries station IDs, so it is central to §12.1. Cases: a private station, a deleted station, a
  station-sourced launch after a warp.
- Station creation with the deployment kit (the one-owned-station cap).
- Warp-core placement, which is BUILD-gated.

The draft's premise "Every v1.5 station action is already a Brigadier command" is therefore
inaccurate.

Missing actors:
- the owner of another station (cross-station authority, the most realistic attacker);
- a removed member;
- the previous owner after a transfer;
- a de-opped operator;
- a command block;
- `/function`;
- an operator standing outside the station;
- a stale (logged-out) player object.

Missing cases:
- Same-station contention:
  - owner and operator both requesting;
  - an expansion confirmation against a warp commit;
  - a gravity or membership change during a countdown;
  - a transfer, de-op or admin delete during a countdown.
- Caps: 128 confirmations, 64 countdowns, 32 members or invitations.
- Replay: confirm after the confirmation was consumed.
- Inviting yourself, the owner or an existing member.
- High-frequency requests (test plan §9, G6).

Define "independent" as follows: different stations never interfere; same-station contention
resolves deterministically, with the first commit winning and the others getting
`STATION_CHANGED` or `WARP_COUNTDOWN_ACTIVE`.

### F46-5 (Medium): the no-chunk-loading invariant is false for admin create and delete

`StationPlatformGenerator.generate` and `removeTemplate` call `level.getChunk` over the platform
chunks. `StationManager.delete` logs `chunks=` accordingly. A matrix that asserts "loaded-chunk
count unchanged" for every action will either fail or be weakened.

Proposed wording: "No player-issued action and no read-only admin action loads or generates a
chunk; the loaded-chunk count is unchanged in every Level. Operator `create` and `delete` load
exactly the platform chunks of the named cell (existing behaviour, bounded by the 289-block
template), and the matrix asserts that exact count."

### F46-6 (Medium): rate and abuse bounds are unspecified (G6, test plan §9)

G6 requires "reasonable rate limiting or natural idempotence". Test plan §9 lists "high-frequency
requests" and asks for "limited, non-spamming diagnostics".

What the code does:
- `invite`, `remove`, `accept`, `decline`, `transfer` and `delete` each call `flush`, which runs
  `DimensionDataStorage.save()` on the server thread. That writes every dirty managed SavedData, not
  only the station file.
- There is no per-station cooldown for these commands. Gravity and warp have 100-tick cooldowns
  (ADR-041, ADR-044).
- Every warp request or rejection and every access rejection writes an INFO audit line.
- The vanilla command spam limiter applies only to non-operators. If the ADR relies on it, it must
  verify and cite it.

Proposed wording: add a "Rate bounds" subsection. For each mutating command it names the bound
(vanilla limiter for non-operators, confirmation and countdown caps, per-station cooldowns). It
then either adds a per-station team-mutation cooldown or cites a measured flush cost at 4,096
stations showing that the sustained worst-case rate stays inside the tick budget. It also states the
audit log volume per player.

### F46-7 (Medium): an offline member cannot be removed

`/arce station remove <station_id> <player>` uses `EntityArgument.player()`, which resolves only
online players, and there is no admin removal command. An owner therefore cannot revoke BUILD from
an offline member, and an operator can do so only by transferring or deleting the station. This is
a real team-permission gap (plan §3 "ownership/team permissions", §12.2).

Proposed wording: either "UI-03 changes `remove` to accept a member UUID (bounded; no packet)", or
record a known issue with an owner and a target version.

### F46-8 (Low): the localization deferral lacks waiver fields

AGENTS §5 requires owner, reason, expiry version and recovery condition for any deferral. Many
GameTests assert English literals, for example `"(in-system warp costs 2000000 FE; warp energy 0 FE)"`.

Proposed wording: "Known issue: station and warp messages are literal English. Owner: sunthemoon.
Expires no later than v1.8.0. Recovery: translatable keys in the `advancedrocketrycommunity_v150`
namespace, with tests asserting `StationManagementCode` tokens instead of prose." Recommended now:
include the code token in rejection replies so that automation does not depend on English text.

### F46-9 (Low): presentation accuracy and gaps (UI-02)

- The claim that "`status` and `environment` are read-only" is inaccurate: `warp status` folds
  pending credits, which ADR-044 defines as an ordinary mutation. Suggested wording: "change no
  station state".
- Countdown and commit/abort messages ("Station warp to X in N s", "Station warped: …") do not name
  the station, which is ambiguous for players who are members of several stations.
- Visitors standing in the region are not notified, although their orbit context changes.
- Offline members get no notice at their next login.
- The countdown appears only on the action bar, which is transient and hidden behind screens or with
  F1.

Required: state as a rule that start, commit and abort always go to chat.

Recommended:
- name the station in member notices;
- add `ClickEvent.SUGGEST_COMMAND` on the confirm hint, which needs no packet and removes the need
  to type a UUID;
- record the visitor and offline-notice gaps.

### F46-10 (Low): the no-screen disposition has no PORTING_MATRIX trace

`docs/PORTING_MATRIX.md` has no row for classic station or warp control GUIs. Row 40 lumps the
space elevator with "black hole/space elevator/orbital laser … DEFERRED". At ACC-01, add or split
rows:
- station/warp controls: commands, PASSED_REDESIGNED candidate;
- GUI: DEFERRED with a target version;
- elevator: v1.5 contract, v1.7 logistics.

### F46-11 (Info): verified facts that support the draft

- There are no network or client file changes since `6f530ac`.
- Expansion, gravity, and warp request, confirm and cancel all require `issuedBy` (own, non-silent
  source) and `localPlayer` (the connected player-list entity), per `StationLocalActor`.
- `warp status` requires VISIT inside the region.
- Admin nodes require permission 2.
- Inputs are bounded:
  - UUID and ResourceLocation arguments;
  - gravity 0..100;
  - station names of at most 48 characters, validated in the model;
  - the delete token is the literal "confirm";
  - the vanilla 256-character command packet limit bounds every input.
- Quotes show station, bodies, class, cost, balance and route warning. Countdowns are announced at
  10, 5, 3, 2 and 1 seconds to owner, members and actor (`StationWarpCountdowns.ANNOUNCED_SECONDS`).
- Existing GameTests already cover much of UI-03 for expansion and warp: `/execute as`, silent
  source, FakePlayer, stale object, confirmation mismatch, consumed confirmation and member or
  outsider rejection.

## 5. Traceability (§9-§15)

No ADR checks a box by itself. Plan §9 requires executed commands, exit codes, logs and a commit.
"Contributes" below means the ADR defines evidence that, once run, supports the item.

| Plan item | ADR-045 / ADR-046 contribution | Remains open for |
|---|---|---|
| §9.2 permission matrix | ADR-046 UI-03 A1 matrix, with oracle (F46-2, F46-4) | UI-03 run; ACC-02 candidate rerun |
| §9.6 resources/energy charged once | matrix asserts no charge on rejected actions | WARP-02/03 (existing); MIG-01 |
| §9.1, 9.3, 9.4, 9.7, 9.8 | none | STATION/ORBIT/WARP/STAR (existing), MIG-01 |
| §9.5 crash recovery per journal stage | none | MIG-01 |
| §10.3 owner disconnect, passengers | matrix logout and stale-object cells | WARP-04; MIG-02 native; ACC-02 |
| §10.5 catalog reload/removal aborts | ADR-045 rule-3 reload test | WARP-03 (existing); MIG-02 |
| §10.6 non-member unauthorized requests | A1 matrix plus S1 subset (F46-2) | S1 on candidate: ACC-02 |
| §10.1, 10.2, 10.4 | none | ORBIT-04/WARP-04/05; MIG-01/02 |
| §11.2 countdown, status, failure feedback | UI-02 message table (F46-1) | V1/V2 legibility: ACC-02 |
| §11.5 GUI scale / multiplayer sync | GUI scale N/A once the disposition is accepted (F46-1) | V2 sync: ACC-02 |
| §11.1, 11.3, 11.4 | none | ORBIT-03; V1/V2 in ACC-02 |
| §12.1 forged station/target IDs | matrix incl. flight C2S (F46-4); ADR-045 unknown UUID | UI-03 run |
| §12.2 non-owner cannot warp/delete/change permissions | matrix | UI-03 run |
| §12.3 no client energy/cost | commands carry no cost (verified) | WARP-03 (existing) |
| §12.4 coordinates never load chunks | scoped invariant (F46-5); ADR-045 all-Level count | UI-03 and ELEVATOR runs |
| §12.5 no dangerous weapon/elevator writes | ADR-045 read-only operator check, registry-clean assertion | ELEVATOR run |
| §13.3 no full dirty every tick | F46-6 team flush rate bound | WARP-05 (existing); UI-03 |
| §13.1, 13.2, 13.4, 13.5 | none | ORBIT-02/04, WARP-03/05, ORBIT-03, ACC-02 |
| §14.4 permission and energy conservation | permissions half | UI-03; energy via WARP |
| §14.1-14.3, 14.5, 14.6 | none | WARP, MIG-01/02, ACC-03 |
| §15 station/warp ADR | ADR-045/046 once accepted | none |
| §15 multiplayer permission report | ADR-046 as redefined: A1 + S1 + V2 | V2 and candidate binding: ACC-02 |
| §15 recovery matrix, performance, video, migration report | none | MIG-01/02, ACC-02 |

## 6. What the §15 "multiplayer permission report" must contain

1. Identity:
   - commit SHA and branch;
   - exact commands with exit codes;
   - the JAR SHA-256 (development), and for release the candidate JAR SHA-256;
   - Minecraft, Forge and Java versions;
   - the evidence level of each part (A1, S1, V2).
2. The version or hash of the normative expected-outcome table (ADR-046 revision).
3. How each actor is constructed: mock connection, op level, FakePlayer profile, console,
   `/execute as`, command block, `/function`, silent own source, stale object, cross-station owner,
   removed member, previous owner, de-opped operator.
4. One row per cell with:
   - action and actor;
   - the precondition state;
   - expected and actual outcome;
   - PASS or FAIL;
   - whether the station registry, balances and orbit are unchanged or dirty;
   - the loaded-chunk delta per Level;
   - a log-line reference.
5. Separate tables for:
   - forged or stale identifiers, including the rocket flight C2S station target;
   - same-station contention and cross-station independence;
   - caps and replay;
   - high-frequency requests and log volume.
6. Totals (cells, pass, fail). Failed runs are retained. Log paths and `SHA256SUMS.txt` are
   included.
7. The S1 subset result on the packaged JAR and the native dedicated server.
8. V2 status (two real clients) and its subset. This stays open until ACC-02 and is not claimed
   earlier.
9. Known gaps: localization, offline removal if not fixed, no screen, visitor notices.
10. A statement that the report is not a Gate approval.

Archive the development packet under `docs/work/v1.5.0-<ui-slice>/VERIFICATION.md`. The
candidate-bound copy belongs in `docs/releases/v1.5.0/`, for example as a section of
`SECURITY-REVIEW.md` or as a dedicated report. The draft's "archived with the slice" covers only the
development copy.

## 7. Required changes

ADR-045:
1. Move authority to rule 2, directly after station existence, and test it on the pure validator
   (F45-1).
2. Add the unbind path; make warp, including evacuation, refused while bound. Check the interlock at
   request, confirm and inside the checked relocation. Add the deletion guard for transport records.
   Name the ADR-041 transitions and the ADR-044 §3 predicate extension the implementation must add
   (F45-2).
3. Add "Relation to ADR-039 and v1.7". Reframe the fixed rules as constraints handed to the v1.7
   ADR. Do not fix the storage location; keep only the invariant that validity is re-derived from
   live state and fails closed (F45-3, F45-8).
4. Put `.requires(hasPermission(2))` on the `elevator` leaf itself, bound x and z at parse to
   ±30,000,000, add one audit log line, and declare the command an unstable diagnostic surface
   (F45-4).
5. Restate rule 3 precisely (`supportsSurfaceArrival`, Level present, unique reverse mapping via
   `PlanetarySurfaceResolver`, one captured catalog) (F45-5).
6. Cite the ADR-040 pad invariant and disclose the overlap with rocket landing (F45-6).
7. Extend the tests as listed in F45-7: all-Level chunk counts, no dirty SavedData, unknown UUID,
   blocked registry, reload or remap, border shrink, the standard short commands, and API and
   generated-file bytes unchanged.

ADR-046:
8. Declare the amendment of ADR-039's UI outcome. Record the no-screen disposition with owner,
   reason, reconsideration version and recovery condition. Replace "satisfied by … this record" with
   behavioural verification. Update CURRENT_VERSION and PORTING_MATRIX at acceptance (F46-1, F46-10).
9. Add the normative expected-outcome table and asserting GameTest. Define the report as A1 (full)
   plus S1 (packaged subset) plus V2 (open for ACC-02), with the content in section 6 (F46-2).
10. Scope the no-packet claim to these controls and carve out ORBIT-03. Pin all four channel
    versions and message lists. Record `network_protocol` (F46-3).
11. Complete the matrix with the missing actions, actors and cases listed in F46-4, including the
    rocket flight C2S station target and BUILD/VISIT.
12. Scope the chunk invariant: no loads for player and read-only actions, and exact platform chunks
    for admin create and delete (F46-5).
13. Add rate bounds per mutating command, including the team-command flush cost or a cooldown, and
    the log volume bound (F46-6).
14. Fix offline member removal (UUID argument) or record it as a known issue with an owner and a
    target version (F46-7).
15. Record the localization gap with owner, expiry version and recovery (F46-8).
16. Correct "read-only" to "changes no station state" and require start, commit and abort to go to
    chat (F46-9).

Recommended, not blocking: name the station in member notices, add a click-to-suggest confirm hint,
include code tokens in rejection replies, add leaf-level `.requires` to the existing admin leaves,
and link ADR-045 from ADR-044 §8's §12.5 row.

## 8. Statement

This is an independent contract review of two PROPOSED records at commit `2900e66`. It is not a
Gate approval. It does not accept either ADR on anyone's behalf and does not mark any plan checkbox,
leaf or version status. Acceptance remains the maintainer's decision after the required changes are
applied. No test was executed for this review.
