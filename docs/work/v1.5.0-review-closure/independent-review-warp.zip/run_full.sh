#!/usr/bin/env bash
# Full required run for one exported commit; logs under evidence/.
D="C:/Users/Administrator/AppData/Local/Temp/arce-v150-warp-review-b42c92ae0c3f8a585f4f4b526c215583"
c="$1"
export JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"
cd "$D/tree-$c" || exit 2
start=$(date +%s)
./gradlew clean build test runData runGameTestServer --offline --no-daemon > "$D/evidence/full-$c.log" 2>&1
rc=$?
end=$(date +%s)
echo "exit=$rc seconds=$((end-start))" >> "$D/evidence/full-$c.log"
echo "$c exit=$rc seconds=$((end-start))" >> "$D/evidence/full-runs-summary.txt"
