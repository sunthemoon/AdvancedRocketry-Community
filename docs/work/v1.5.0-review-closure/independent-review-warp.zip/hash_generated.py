import hashlib, os, sys, json
root = sys.argv[1]
out = {}
for base, dirs, files in os.walk(root):
    for f in files:
        p = os.path.join(base, f)
        rel = os.path.relpath(p, root).replace(os.sep, "/")
        if "/.cache/" in "/" + rel or rel.startswith(".cache"):
            continue
        out[rel] = hashlib.sha256(open(p, "rb").read()).hexdigest()
json.dump(out, open(sys.argv[2], "w"), indent=1, sort_keys=True)
print(len(out))
