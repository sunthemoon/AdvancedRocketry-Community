import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mutate
lane = sys.argv[1]
for k, (d, rel, old, new, mode) in mutate.MUTATIONS.items():
    t = open(os.path.join(lane, rel), encoding="utf-8").read()
    print(k, t.count(old), d)
