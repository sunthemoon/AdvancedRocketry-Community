"""Single-change mutation runner for the v1.5 warp review (exports only, never the repository).

Usage: python mutate.py <lane-dir> <evidence-dir> <id> [<id> ...]
Each mutation is applied alone, the tests run, the file is restored and byte-compared.
"""
import os
import shutil
import subprocess
import sys
import time

P = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"
WARP = P + "station/warp/StationWarpService.java"
CREDITS = P + "station/warp/StationWarpCredits.java"
RULE = P + "rocket/server/RocketStationMotionRule.java"
TRANSFER = P + "rocket/server/RocketTransferService.java"
REG = P + "station/persistence/StationRegistrySavedData.java"
BIO = P + "persistence/migration/BoundedSavedDataIo.java"
MTYPE = P + "persistence/migration/ManagedSavedDataType.java"
ENTITY = P + "rocket/entity/RocketEntity.java"
MANAGER = P + "station/service/StationManager.java"
ADMIT = P + "rocket/server/PlanetaryFlightAdmission.java"

# id: (description, file, old, new, mode)  mode: "junit" or "both" (JUnit + GameTests)
MUTATIONS = {
    "M01": ("Credits: no per-tick allowance", CREDITS,
            "long allowance = StationLimits.WARP_CREDIT_PER_TICK - acceptedThisTick.getOrDefault(stationId, 0);",
            "long allowance = Long.MAX_VALUE;", "both"),
    "M02": ("Commit: actor recheck removed", WARP,
            "        if (!station.ownerId().equals(confirmed.actorId())\n"
            "                && server.getProfilePermissions(confirmed.actor()) < 2) {",
            "        if (false) {", "both"),
    "M03": ("Tick: every due countdown commits in the same tick", WARP,
            "        countdowns.nextDue(now).ifPresent(countdown -> {\n"
            "            countdowns.cancel(countdown.quote().stationId());\n"
            "            commit(server, countdown.quote());\n"
            "        });",
            "        for (var due = countdowns.nextDue(now); due.isPresent(); due = countdowns.nextDue(now)) {\n"
            "            countdowns.cancel(due.get().quote().stationId());\n"
            "            commit(server, due.get().quote());\n"
            "        }", "both"),
    "M04": ("Rule: PREPARED always blocks", RULE,
            "case PREPARED -> live.test(record.transferId());", "case PREPARED -> true;", "junit"),
    "M05": ("Rule: PREPARED never blocks", RULE,
            "case PREPARED -> live.test(record.transferId());", "case PREPARED -> false;", "junit"),
    "M06": ("Growth: invite not checked", REG,
            "        requireStorageRoom(StationLimits.MAX_TEAM_ENTRY_GROWTH_NBT_BYTES);\n"
            "        StationState result = registry.invite(stationId, playerId);",
            "        StationState result = registry.invite(stationId, playerId);", "both"),
    "M07": ("Reader: declaration guard removed", BIO,
            "            if (bytes > backed) {", "            if (false && bytes > backed) {", "junit"),
    "M08": ("Wiring: every record counts as classified", TRANSFER,
            "transferId -> liveTransfers.contains(transferId) || settledTransfers.contains(transferId),",
            "transferId -> true,", "both"),
    "M09": ("Wiring: live set replaced by the settled set", TRANSFER,
            "                liveTransfers::contains,", "                settledTransfers::contains,", "both"),
    "M10": ("Commit: kill switch not rechecked", WARP,
            "    private StationWarpResult commitChecked(MinecraftServer server, StationRegistrySavedData data, WarpQuote confirmed) {\n"
            "        if (!settings.get().enabled()) {",
            "    private StationWarpResult commitChecked(MinecraftServer server, StationRegistrySavedData data, WarpQuote confirmed) {\n"
            "        if (false) {", "both"),
    "M11": ("Confirm: local-player check after take (consumable by another source)", WARP,
            "        if (!StationLocalActor.localPlayer(server, player, issuedByPlayer)) {\n"
            "            // Rejected before take()",
            "        if (false) {\n"
            "            // Rejected before take()", "both"),
    "M12": ("Entity: station-built rocket records the Space body", ENTITY,
            "? stationOrbit(serverLevel, station.instanceId(), dimension) : bodyForDimension(dimension),",
            "? bodyForDimension(dimension) : bodyForDimension(dimension),", "both"),
    "M13": ("Deletion: blocked journal no longer fails closed", MANAGER,
            "        if (!journal.operational()) {\n"
            "            // ADR-044 §5: a blocked journal hides its records, so deletion fails closed.",
            "        if (false) {\n"
            "            // ADR-044 §5: a blocked journal hides its records, so deletion fails closed.", "both"),
    "M14": ("Admission: current_body comparison restored", ADMIT,
            "                    .filter(state -> catalog.get(state.orbitBody()).isPresent());",
            "                    .filter(state -> catalog.get(state.orbitBody()).isPresent())\n"
            "                    .filter(state -> flight.currentBody().equals(state.orbitBody())\n"
            "                            || flight.currentBody().equals(CelestialIds.SPACE_ID));", "both"),
    "M15": ("Credits: simulate records the credit", CREDITS,
            "if (accepted > 0 && !simulate) {", "if (accepted > 0) {", "junit"),
    "M16": ("Core: off-thread calls accepted", WARP,
            "if (maxReceive <= 0 || !server.isSameThread() || ", "if (maxReceive <= 0 || ", "both"),
    "M17": ("Fold: entry headroom ignored", REG,
            "                if (!entryHeadroom) {", "                if (false) {", "junit"),
    "M18": ("Growth: relocation to a longer orbit id not checked", REG,
            "        if (relocation) {\n            requireStorageRoom(",
            "        if (false) {\n            requireStorageRoom(", "both"),
    "M19": ("Commit: no cooldown after a committed warp", WARP,
            "        if (code == StationManagementCode.WARP_COMMITTED || code == StationManagementCode.WRITE_FAILED",
            "        if (code == StationManagementCode.WRITE_FAILED", "both"),
    "M20": ("Growth: ownership transfer not checked", REG,
            "        requireStorageRoom(StationLimits.MAX_TEAM_ENTRY_GROWTH_NBT_BYTES);\n"
            "        StationState result = registry.transferOwnership(stationId, ownerId);",
            "        StationState result = registry.transferOwnership(stationId, ownerId);", "both"),
    "M21": ("Commit: confirmed cost/class not compared", WARP,
            "        if (current.quote().costClass() != confirmed.costClass() || current.quote().cost() != confirmed.cost()) {\n"
            "            return StationWarpResult.quoted(",
            "        if (false) {\n"
            "            return StationWarpResult.quoted(", "both"),
    "M22": ("Core: quarantined registry still charged", WARP,
            "        if (!data.operational() || data.updatesQuarantined()) {\n            return 0;",
            "        if (!data.operational()) {\n            return 0;", "both"),
    "M25": ("Confirm: observed state not compared", WARP,
            "if (located.authority() != data || !confirmed.observed().equals(located.station())) {",
            "if (located.authority() != data) {", "both"),
    "M26": ("Request: core ray pick always succeeds", WARP,
            "        HitResult hit = player.pick(StationLimits.WARP_CORE_REACH, 1.0F, false);",
            "        if (true) {\n            return true;\n        }\n"
            "        HitResult hit = player.pick(StationLimits.WARP_CORE_REACH, 1.0F, false);", "both"),
    "M27": ("Core: accepted outside the Space Level", WARP,
            " || !level.dimension().equals(CelestialIds.SPACE_LEVEL)\n"
            "                || server.getLevel(CelestialIds.SPACE_LEVEL) != level) {",
            ") {", "both"),
    "M28": ("Reader: 8x heap factor for every type (pre-fix F1)", MTYPE,
            "return this == STATIONS ? 8L : 1L;", "return 8L;", "junit"),
    "M29": ("Rule: unclassified records ignored (rule 2 removed)", RULE,
            "            if (!classified.test(record.transferId())) {",
            "            if (false && !classified.test(record.transferId())) {", "junit"),
    "M30": ("Rule: committed arrivals never block (rule 4 removed)", RULE,
            "                case COMMITTED -> gameTime < record.destinationFlightData().stateStartedGameTime()",
            "                case COMMITTED -> false && gameTime < record.destinationFlightData().stateStartedGameTime()",
            "junit"),
}


def run(lane, log, args):
    env = dict(os.environ)
    env["JAVA_HOME"] = "C:/Program Files/Java/jdk-17.0.7"
    with open(log, "w", encoding="utf-8", errors="replace") as out:
        proc = subprocess.run(["bash", "./gradlew"] + args, cwd=lane, env=env, stdout=out,
                              stderr=subprocess.STDOUT)
    return proc.returncode


def gametest_summary(log):
    text = open(log, encoding="utf-8", errors="replace").read()
    lines = [l for l in text.splitlines() if "GameTestServer" in l and ("required tests" in l or "failed" in l)]
    failed = sorted({l.split("] ")[-1][:200] for l in text.splitlines()
                     if "::" in l and ("failed!" in l or "failed" in l and "GameTest" in l)})
    return lines[-3:], failed[:15]


def main():
    lane, evidence = sys.argv[1], sys.argv[2]
    tally = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tally.py")
    results = os.path.join(evidence, "mutation-results.tsv")
    for mid in sys.argv[3:]:
        desc, rel, old, new, mode = MUTATIONS[mid] if mid != "BASE" else ("baseline", None, None, None, "both")
        path = os.path.join(lane, rel) if rel else None
        original = open(path, "rb").read() if path else None
        if path:
            text = original.decode("utf-8")
            if text.count(old) != 1:
                with open(results, "a", encoding="utf-8") as r:
                    r.write(f"{mid}\t{desc}\tANCHOR_NOT_UNIQUE({text.count(old)})\n")
                continue
            open(path, "wb").write(text.replace(old, new).encode("utf-8"))
        shutil.rmtree(os.path.join(lane, "build", "gametest"), ignore_errors=True)
        tasks = ["cleanTest", "test"] + (["runGameTestServer"] if mode == "both" else [])
        log = os.path.join(evidence, f"mut-{mid}.log")
        start = time.time()
        rc = run(lane, log, tasks + ["--offline", "--no-daemon", "--continue"])
        seconds = int(time.time() - start)
        junit = subprocess.run([sys.executable, tally, lane], capture_output=True, text=True).stdout.strip()
        gt_lines, gt_failed = gametest_summary(log) if mode == "both" else ([], [])
        compile_failed = "Compilation failed" in open(log, encoding="utf-8", errors="replace").read()
        if path:
            open(path, "wb").write(original)
            restored = open(path, "rb").read() == original
        else:
            restored = True
        with open(os.path.join(evidence, f"mut-{mid}-summary.txt"), "w", encoding="utf-8") as s:
            s.write(f"{mid} {desc}\nexit={rc} seconds={seconds} compile_failed={compile_failed} restored={restored}\n")
            s.write(junit + "\n")
            for line in gt_lines:
                s.write("GT " + line + "\n")
            for line in gt_failed:
                s.write("GTFAIL " + line + "\n")
        first = junit.splitlines()[0] if junit else ""
        failed_tests = [l[7:] for l in junit.splitlines()[1:]]
        with open(results, "a", encoding="utf-8") as r:
            r.write(f"{mid}\t{desc}\texit={rc}\t{first}\tjunit_failed={';'.join(failed_tests)[:600]}\t"
                    f"gametest={' | '.join(gt_lines)[:300]}\trestored={restored}\n")


if __name__ == "__main__":
    main()
