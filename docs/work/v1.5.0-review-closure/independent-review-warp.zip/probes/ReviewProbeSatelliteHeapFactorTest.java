package io.github.sunthemoon.advancedrocketrycommunity.persistence.migration;

import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.celestial.content.StarSystemContent;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.persistence.SatelliteMissionSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.satellite.model.SatelliteLimits;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Review probe (not part of the repository): a satellite registry grown only through its public API
 * (launch, complete, claim; completed missions are retained up to MAX_MISSIONS) is read back through
 * the bounded pre-start reader, whose heap quota for this type is again 1x the raw bound after 1a5763a.
 */
final class ReviewProbeSatelliteHeapFactorTest {
    @TempDir Path root;

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    @Test
    void satelliteRegistryAtReachableSizesThroughTheBoundedReader() throws Exception {
        var definition = StarSystemContent.surveySatellite();
        var target = StarSystemContent.TAU_CETI_E;
        long duration = definition.missionDurationTicks();
        SatelliteMissionSavedData data = SatelliteMissionSavedData.create(0);
        List<UUID> satellites = new ArrayList<>();
        long time = 0;
        int missions = 0;
        int[] checkpoints = {512, 1024, 2048, 4096, 6144, SatelliteLimits.MAX_MISSIONS};
        int next = 0;
        while (missions < SatelliteLimits.MAX_MISSIONS && next < checkpoints.length) {
            List<UUID> started = new ArrayList<>();
            List<UUID> owners = new ArrayList<>();
            for (int batch = 0; batch < 32 && missions < SatelliteLimits.MAX_MISSIONS; batch++) {
                UUID mission = new UUID(77, missions);
                UUID owner = new UUID(78, missions % 4_000);
                boolean ok;
                if (satellites.size() < SatelliteLimits.MAX_SATELLITES - 1) {
                    UUID satellite = new UUID(79, satellites.size());
                    ok = data.launch(satellite, mission, owner, definition, target, time, false).success();
                    if (ok) {
                        satellites.add(satellite);
                    }
                } else {
                    UUID satellite = satellites.get(missions % satellites.size());
                    owner = new UUID(78, satellites.indexOf(satellite) % 4_000);
                    ok = data.startMission(satellite, mission, owner, definition, target, time, false).success();
                }
                if (!ok) {
                    break;
                }
                started.add(mission);
                owners.add(owner);
                missions++;
            }
            time += duration + 1;
            for (int pass = 0; pass < 4; pass++) {
                data.completeDue(time);
            }
            for (int index = 0; index < started.size(); index++) {
                data.claim(started.get(index), owners.get(index), time);
            }
            if (started.isEmpty()) {
                break;
            }
            if (missions >= checkpoints[next]) {
                measure(data, missions, satellites.size());
                next++;
            }
        }
        assertTrue(missions > 0);
    }

    private void measure(SatelliteMissionSavedData data, int missions, int satellites) throws Exception {
        CompoundTag payload = data.save(new CompoundTag());
        CompoundTag outer = new CompoundTag();
        outer.put("data", payload);
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (DataOutputStream output = new DataOutputStream(raw)) {
            NbtIo.write(outer, output);
        }
        NbtAccounter heap = new NbtAccounter(Long.MAX_VALUE);
        NbtIo.read(new DataInputStream(new ByteArrayInputStream(raw.toByteArray())), heap);
        ManagedSavedDataType type = ManagedSavedDataType.SATELLITE_MISSIONS;
        long quota = type.maxCompressedBytes() * type.heapAccountingFactor();
        Path dir = Files.createDirectories(root.resolve("m" + missions));
        Path file = dir.resolve(type.fileName());
        CheckedSavedDataFile.replace(file, type, () -> payload);
        String outcome;
        try {
            BoundedSavedDataIo.read(file, type);
            outcome = "READ_OK";
        } catch (SavedDataMigrationException refused) {
            outcome = "REFUSED_" + refused.diagnosticId();
        }
        System.out.printf("ARCE_REVIEW_PROBE_SATELLITE missions=%d satellites=%d raw_bytes=%d raw_bound=%d"
                        + " heap_accounted=%d ratio=%.3f heap_quota=%d outcome=%s%n",
                missions, satellites, raw.size(), type.maxCompressedBytes(), heap.getUsage(),
                heap.getUsage() / (double) raw.size(), quota, outcome);
    }
}
