package io.github.sunthemoon.advancedrocketrycommunity.persistence.migration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.ModIdentity;
import io.github.sunthemoon.advancedrocketrycommunity.station.model.StationLimits;
import io.github.sunthemoon.advancedrocketrycommunity.station.persistence.StationRegistrySavedData;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Review probe (not part of the repository): the largest registry that growth admission now allows
 * (fully populated records until refusal, plus a balance for every station) must still pass the
 * bounded pre-start reader with the 8x heap factor and the declaration guard.
 */
final class ReviewProbeFullRegistryReadTest {
    @TempDir Path root;

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    @Test
    void longNames() throws Exception {
        probe("S".repeat(StationLimits.MAX_NAME_LENGTH), "long");
    }

    @Test
    void shortNames() throws Exception {
        probe("S", "short");
    }

    private void probe(String name, String label) throws Exception {
        StationRegistrySavedData full = new StationRegistrySavedData();
        List<UUID> stations = new ArrayList<>();
        int index = 0;
        boolean refused = false;
        while (!refused && index < StationLimits.MAX_STATIONS) {
            UUID stationId = new UUID(44, index);
            try {
                full.reserve(stationId, UUID.randomUUID(), name, ModIdentity.id("earth"), 0);
                full.commit(stationId);
                stations.add(stationId);
                for (int member = 0; member < StationLimits.MAX_MEMBERS; member++) {
                    UUID joining = new UUID(45, index * 64L + member);
                    full.invite(stationId, joining);
                    full.acceptInvitation(stationId, joining);
                    full.invite(stationId, new UUID(46, index * 64L + member));
                }
            } catch (IllegalStateException growthRefused) {
                refused = true;
            }
            index++;
        }
        Map<UUID, Integer> credits = new LinkedHashMap<>();
        stations.forEach(stationId -> credits.put(stationId, StationLimits.MAX_WARP_ENERGY));
        var fold = full.foldWarpCredits(credits);
        CompoundTag payload = full.save(new CompoundTag());
        CompoundTag outer = new CompoundTag();
        outer.put("data", payload);
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (DataOutputStream output = new DataOutputStream(raw)) {
            NbtIo.write(outer, output);
        }
        NbtAccounter heap = new NbtAccounter(Long.MAX_VALUE);
        NbtIo.read(new DataInputStream(new ByteArrayInputStream(raw.toByteArray())), heap);
        long quota = ManagedSavedDataType.STATIONS.maxCompressedBytes()
                * ManagedSavedDataType.STATIONS.heapAccountingFactor();
        System.out.printf("ARCE_REVIEW_PROBE_FULL_REGISTRY variant=%s stations=%d refused=%s balances_credited=%d"
                        + " balances_refused=%d raw_bytes=%d heap_accounted=%d ratio=%.3f heap_quota=%d raw_quota=%d%n",
                label, stations.size(), refused, fold.credited(), fold.refused(), raw.size(), heap.getUsage(),
                heap.getUsage() / (double) raw.size(), quota, ManagedSavedDataType.STATIONS.maxCompressedBytes());
        Path file = java.nio.file.Files.createDirectories(root.resolve(label)).resolve(ManagedSavedDataType.STATIONS.fileName());
        CheckedSavedDataFile.replace(file, ManagedSavedDataType.STATIONS, () -> payload);
        CompoundTag read = BoundedSavedDataIo.read(file, ManagedSavedDataType.STATIONS);
        assertEquals(payload, read.getCompound("data"));
        StationRegistrySavedData reloaded = StationRegistrySavedData.load(read.getCompound("data"));
        assertTrue(reloaded.operational());
        assertEquals(stations.size(), reloaded.stations().size());
        assertEquals(full.warpEnergyBalances(), reloaded.warpEnergyBalances());
    }
}
