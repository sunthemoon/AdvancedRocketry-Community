"""Evidence-integrity check of committed packets, read through `git show` only (never the working tree)."""
import hashlib
import io
import json
import subprocess
import sys
import zipfile

REPO = "D:/GitHub/AdvancedRocketry-Community"
PACKETS = [
    ("0416455", "docs/work/v1.5.0-warp-core"),
    ("615a5f1", "docs/work/v1.5.0-warp-rockets"),
    ("1a5763a", "docs/work/v1.5.0-slices-review"),
]


def blob(commit, path):
    return subprocess.run(["git", "-C", REPO, "show", f"{commit}:{path}"], capture_output=True, check=True).stdout


def sha(data):
    return hashlib.sha256(data).hexdigest()


def changed_files(commit):
    out = subprocess.run(["git", "-C", REPO, "diff", "--name-only", f"{commit}~1", commit],
                         capture_output=True, text=True, check=True).stdout
    return [line for line in out.splitlines() if line]


def link_exists(commit, document, target):
    import posixpath
    target = target.split("#", 1)[0]
    if not target:
        return True
    base = posixpath.dirname(document)
    target = posixpath.normpath(posixpath.join(base, target)).rstrip("/")
    proc = subprocess.run(["git", "-C", REPO, "cat-file", "-e", f"{commit}:{target}"], capture_output=True)
    return proc.returncode == 0


def main():
    problems = 0
    for commit, packet in PACKETS:
        print(f"== {commit} {packet}")
        sums = blob(commit, f"{packet}/SHA256SUMS.txt").decode()
        for line in sums.splitlines():
            digest, name = line.split(None, 1)
            name = name.strip().lstrip("*")
            actual = sha(blob(commit, f"{packet}/{name}"))
            ok = actual == digest
            problems += not ok
            print(f"  SHA256SUMS {name}: {'OK' if ok else 'MISMATCH ' + actual}")
        archives = json.loads(blob(commit, f"{packet}/evidence-archives.json"))
        for archive in archives["archives"]:
            data = blob(commit, f"{packet}/{archive['name']}")
            zf = zipfile.ZipFile(io.BytesIO(data))
            members = [i for i in zf.infolist() if not i.is_dir()]
            ok = (len(data) == archive["bytes"] and sha(data) == archive["sha256"]
                  and len(members) == archive["members"])
            problems += not ok
            print(f"  archive {archive['name']}: bytes={len(data)} members={len(members)} "
                  f"{'OK' if ok else 'MISMATCH vs ' + json.dumps(archive)}")
            manifest = json.loads(blob(commit, f"{packet}/{archive['manifest']}"))
            listed = {entry["path"]: entry for entry in manifest}
            actual = {i.filename: i for i in members}
            missing = sorted(set(listed) - set(actual))
            extra = sorted(set(actual) - set(listed))
            bad = []
            for path, entry in listed.items():
                if path in actual:
                    content = zf.read(actual[path])
                    if len(content) != entry["bytes"] or sha(content) != entry["sha256"]:
                        bad.append(path)
            problems += len(missing) + len(extra) + len(bad)
            print(f"  manifest {archive['manifest']}: listed={len(listed)} missing={missing[:5]} "
                  f"extra={extra[:5]} bad={bad[:5]}")
        identity = json.loads(blob(commit, f"{packet}/source-identity.json"))
        ident_bad = []
        for entry in identity["files"]:
            content = blob(commit, entry["path"])
            if len(content) != entry["bytes"] or sha(content) != entry["sha256"]:
                ident_bad.append(entry["path"])
            if entry.get("working_sha256") and entry["working_sha256"] != entry["sha256"]:
                ident_bad.append(entry["path"] + " (working differs)")
        covered = {entry["path"] for entry in identity["files"]}
        changed = [path for path in changed_files(commit) if not path.startswith(packet + "/")]
        uncovered = sorted(set(changed) - covered)
        not_changed = sorted(covered - set(changed))
        problems += len(ident_bad) + len(uncovered)
        print(f"  source-identity: entries={len(covered)} bad={ident_bad[:5]} changed_outside_packet={len(changed)} "
              f"uncovered={uncovered[:8]} listed_but_unchanged={len(not_changed)} base={identity.get('base_commit')}")
        links = json.loads(blob(commit, f"{packet}/links.json"))
        dead = [link for link in links["links"] if not link_exists(commit, link["document"], link["target"])]
        problems += len(dead)
        print(f"  links: {len(links['links'])} checked, dead={dead[:5]}")
    print(f"TOTAL PROBLEMS {problems}")


if __name__ == "__main__":
    main()
