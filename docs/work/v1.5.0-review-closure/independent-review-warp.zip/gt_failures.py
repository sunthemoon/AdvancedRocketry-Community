import os, re, sys
# Prints, per mutation log, the GameTest summary and the names of failed GameTests.
for path in sys.argv[1:]:
    text = open(path, encoding="utf-8", errors="replace").read()
    summary = [l.split("]: ")[-1] for l in text.splitlines() if "GameTestServer]:" in l and "required tests" in l]
    failed = sorted({m.group(1) for m in re.finditer(r"LogTestReporter\]: (\S+) failed!", text)})
    compile_failed = "Compilation failed" in text or "compileJava FAILED" in text
    print(f"{os.path.basename(path)}\tsummary={summary[-1] if summary else 'none'}\tfailed={','.join(failed)}\tcompile_failed={compile_failed}")
