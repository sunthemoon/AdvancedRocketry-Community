import os, sys, xml.etree.ElementTree as ET
root = os.path.abspath(sys.argv[1]) + r"\build\test-results\test"
lp = chr(92) * 2 + "?" + chr(92) + root
tests = fails = errors = skipped = suites = 0
failed = []
if os.path.isdir(lp):
    for name in os.listdir(lp):
        if not name.endswith(".xml"):
            continue
        with open(lp + "\\" + name, "rb") as fh:
            t = ET.parse(fh).getroot()
        suites += 1
        tests += int(t.get("tests", 0)); fails += int(t.get("failures", 0)); errors += int(t.get("errors", 0)); skipped += int(t.get("skipped", 0))
        for tc in t.iter("testcase"):
            if tc.find("failure") is not None or tc.find("error") is not None:
                failed.append(tc.get("classname") + "." + tc.get("name"))
print(f"suites={suites} tests={tests} failures={fails} errors={errors} skipped={skipped}")
for x in sorted(failed):
    print("FAILED " + x)
