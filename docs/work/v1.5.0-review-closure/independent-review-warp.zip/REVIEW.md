# Independent review: V150-WARP-03 (`0416455`), V150-WARP-04 (`615a5f1`) and the review fixes (`1a5763a`)

Reviewer: independent reviewer (not the author). Date: 2026-09-30.
Repository: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.5.0-orbital-station-warp`.

| Slice | Commit | Base | Contract |
|---|---|---|---|
| WARP-03: warp core, credits, config, commands, countdown, commit | `0416455a83631bbc74d3cf7212bc1947e326f327` | `9969550` | ADR-044 rev. 3 §2, §4, §7 |
| WARP-04: in-motion rule, docked-rocket admission, deletion guard | `615a5f190b30b260c41e5a2b6b8f1c0aa8df6628` | `0416455` | ADR-044 rev. 3 §5 |
| Fixes for the WARP-02/STAR/capacity review (F1-F12) | `1a5763a8c3e4d9da6fe253f17db1ae5bcc0dfffb` | `615a5f1` | previous report in `docs/work/v1.5.0-slices-review/` |

**This is not a Gate approval.** It does not verify, accept or reject any leaf, ADR, version or
release on anyone's behalf, and it changes no status. It is evidence for the maintainer.

## Method

**Scope and access.**
- Read-only on the repository. Only `git show`, `git diff`, `git log`, `git grep`, `git ls-tree`,
  `git cat-file` and `git archive` were used.
- The working tree (concurrent WARP-05 edits) and the untracked private directory were never read.
  Every statement below refers to the committed trees.

**Material read.**
- `AGENTS.md`; ADR-040, ADR-041 and ADR-043; ADR-044 rev. 3 as committed at `1a5763a`.
- `docs/work/v1.5.0-implementation-log.md` and the three `VERIFICATION.md` packets.
- The archived previous review, extracted to `prev-review/` in this directory.
- The full diff of all three commits: source, tests, GameTests, build, generated data and docs.

**Builds.**
- Each commit was exported with `git archive <commit> | tar -x` into `tree-<commit>/`.
- Two mutation lanes, `tree-mutA` and `tree-mutB`, were exported from `1a5763a`.
- Gradle ran with `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, `--offline --no-daemon`.

**Vanilla and Forge behaviour** was checked with `javap -c` on
`forge-1.20.1-47.4.10_mapped_official_1.20.1.jar` (output in `evidence/javap-*.txt`):
- every NBT type's `NbtAccounter` charges, and when arrays and lists are allocated;
- that `ServerLifecycleHooks.handleServerStopping` runs after the tick loop and before `stopServer`;
- that `Entity.pick` carries no `@OnlyIn`.

**Probes.** Scratch tests (`probes/`) were copied into an export for a single run and deleted afterwards.
The flaky-test check at `9969550` ran GameTests only.

### Commands actually run

| Command (in the export) | Result | Log |
|---|---|---|
| `1a5763a`: `gradlew clean build test runData runGameTestServer` | Exit 0, 208 s. `:test` executed: 1,020 JUnit / 184 suites, 0 failures. "All 248 required tests passed". `src/generated`: 266 files, 0 differences after runData. Main JAR `f4411b03…` and API JAR `97d1aaad…` are byte-identical to the packet | `evidence/full-1a5763a.log`, `…-junit-tally.txt`, `…-generated-diff.txt` |
| `615a5f1`: the same full run | Exit 1, 203 s. 1,013 JUnit / 182 suites, 0 failures; generated files unchanged; main JAR `d1b021f7…` equals the packet. **One GameTest failed**: the pre-existing flaky rocket test (R9) | `evidence/full-615a5f1.log` |
| `615a5f1`: `runGameTestServer` rerun with a fresh `build/gametest` | Exit 0, "All 248 required tests passed" | `evidence/rerun-615a5f1-gametest.log` |
| `0416455`: the same full run | Exit 0, 238 s. 1,008 JUnit / 181 suites, 0 failures. "All 245 required tests passed". Generated files unchanged; main JAR `10a21dad…` equals the packet | `evidence/full-0416455.log` |
| `9969550`: `runGameTestServer`, twice, under the same load | Both exit 0, 240 passed (flaky-test check, R9) | `evidence/flake-9969550-gametest-*.log` |
| Probe at `1a5763a`: the largest station registry that growth admission allows, read through `BoundedSavedDataIo` | Pass, 2 variants: 1,887 / 1,930 fully populated stations with every balance folded. Raw 4.01 MB; heap accounted 25.5 / 26.0 MB (ratio 6.36 / 6.49), under the 34.1 MB quota | `evidence/probes-1a5763a.log`, `evidence/probe-results.txt` |
| Probe at `1a5763a` and at `615a5f1`: satellite registry grown through its public API, written by `CheckedSavedDataFile.replace` | `1a5763a`: **2,048 missions refused `OVERSIZED_DATA`** (R1). `615a5f1`: 512-6,144 missions read; 8,192 exceeds the registry's own bound (R3) | same, plus `evidence/probes-615a5f1.log` |
| Evidence integrity of the three packets | 0 problems | `evidence/evidence-integrity.log` (`verify_evidence.py`) |
| 28 single-change mutations | 13 killed, 15 survived (see "Mutation results") | `evidence/mutations-lane*/`, `evidence/mutation-summary.tsv` |

**Mutation runs.**
- Every mutation ran `cleanTest test`: all 1,020 JUnit tests.
- 20 of them also ran `runGameTestServer` (all 248 GameTests) with a fresh GameTest world.
- Each mutated file was restored and byte-compared after its run. Afterwards both lanes' `src/` trees
  were diffed against the `1a5763a` export and are identical.

The full runs overlapped with the mutation lanes; up to four Gradle or GameTest JVMs ran at once.

## Verdicts

| Commit | Verdict | Why |
|---|---|---|
| `0416455` WARP-03 | **ACCEPT WITH CHANGES** | The core, credits, commands, confirmation, countdown and commit implement ADR-044 §2 and §4 as written. Authority, energy bounds and every §4 commit recheck are present and, by inspection, correct. Changes are needed because 8 of 13 WARP-03 mutations survive the whole suite, including the actor recheck, the kill switch at commit, confirmation consumption and one commit per tick (R2). Two Low issues (R4, R6) also need fixing. |
| `615a5f1` WARP-04 | **ACCEPT WITH CHANGES** | `RocketStationMotionRule` matches §5 rules 1-4, fails closed and is wired at common setup, before any server exists. The admission change keeps every other check. Changes: the wiring into the journal sets and the station-built orbit are untested (R2), the §5 `current_body` sentence is only half implemented (R5), and rule 2 has no operator path (R7). |
| `1a5763a` review fixes | **REJECT as committed** | F1-F12 are addressed as claimed, and the new declaration guard is sound. But the per-type heap factor introduces a High regression (R1): at 1,190 missions or more (measured: fails at 2,048, passes at 1,024), a satellite registry can no longer be saved or read at start. Everything else in the commit is acceptable. Restoring a measured factor for every managed type (the guard makes 8x safe for satellites), plus capacity round-trip tests, would make this an ACCEPT. |

One High finding (R1), two Medium (R2; R3, pre-existing and outside these commits), no Critical.

## Findings

Line numbers are at the commit named in each finding. `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`
is abbreviated to `…/`.

### R1 — High — `1a5763a`: heap factor 1 for non-station types makes satellite registries above about 1,190 missions unwritable and unreadable

**Where.**
- `…/persistence/migration/ManagedSavedDataType.java:109-115`: `heapAccountingFactor()` is 1 for every
  type except `STATIONS`.
- `…/persistence/migration/BoundedSavedDataIo.java:46-55`: heap quota = raw bound × factor.
- `…/persistence/migration/AtomicSavedData.java:41-52`: every satellite and celestial save, ordinary or
  flush, goes through `CheckedSavedDataFile.replace`.
- `…/persistence/migration/CheckedSavedDataFile.java:61`: the staged file is read back through
  `BoundedSavedDataIo.read`.
- The pre-start migration reads every managed file through the same reader.

**Mechanism.** `NbtAccounter` charges about 5× the raw size for this registry (measured 5.02-5.05 from 512
to 6,144 missions). With factor 1 the heap quota equals the raw bound (4,259,840 bytes). Any satellite
payload above about 844 KB raw therefore exceeds the quota and is classified `OVERSIZED_DATA`. That is about
1,190 launched missions, 20 % of the registry's own raw bound.

**Reproduction** (`probes/ReviewProbeSatelliteHeapFactorTest.java`, `evidence/probe-results.txt`). The probe
grows the registry only through `launch`, `startMission`, `completeDue` and `claim`. Completed missions are
kept (none are pruned) up to `MAX_MISSIONS` = 8,192. Each checkpoint is written with
`CheckedSavedDataFile.replace`, exactly as `AtomicSavedData.flush` does.
- `1a5763a`: 512 and 1,024 missions are written (heap 3.66 MB). 2,048 missions fail with
  `SavedDataMigrationException: advancedrocketrycommunity_satellite_missions expanded NBT exceeds the fixed
  byte limit`. At that point the heap charge is 7.33 MB against a 4.26 MB quota, while raw is only 1.45 MB.
- `615a5f1` (factor 8): 2,048, 4,096 and 6,144 missions are written and read back.

**Failure scenario.** A long-running server passes about 1,190 satellite missions. From then on:
- Every ordinary save of the satellite registry fails. `AtomicSavedData.save` logs "Atomic SavedData save
  failed … retained dirty state" once and carries on.
- Every `SatelliteManager` operation that flushes (launch, start, claim, the 20-tick scheduler) has already
  changed the in-memory registry. It then throws inside its `try` and reports `UNSUPPORTED_DATA` or
  "Satellite scheduler pass failed".
- On restart, the world silently reverts to the last satellite file written below the threshold.
- A world whose satellite file was written above the threshold by `615a5f1` is refused at start by the
  pre-start migration (`OVERSIZED_DATA`).

The rocket journals are also back to factor 1, with quotas of about 64 MiB and 138 MB. With large
block-entity payloads they carry the same class of risk; this was not measured.

**Status.** Before `30b9b11` every type used factor 1. So this is a latent v1.4 defect that `30b9b11` masked
and `1a5763a` re-exposes; relative to its parent `615a5f1` it is a regression. The previous review's primary
suggestion (a single-charge guard while keeping 8× cumulative) avoids it. Its "1 or a measured value"
alternative was taken without measuring.

**Suggested fix.**
- Set each type's cumulative factor from a measured ratio. 8 is safe for `SATELLITE_MISSIONS` and
  `CELESTIAL`: their raw bounds are small, and the new guard still limits one declaration to 4× the backed
  raw bytes (at most about 17 MB for satellites).
- For the rocket journals, measure at capacity. If their factor is raised, also tighten the guard for arrays
  (an array needs one raw byte per accounted byte; only list headers need the 4× allowance), or cap a single
  declaration absolutely.
- Add a capacity test per managed type: grow it through its public API to the largest encodable size and
  round-trip it through `CheckedSavedDataFile.replace` and `BoundedSavedDataIo.read`. Mutation M28 (8× for
  every type) survives today because nothing pins these factors.

### R2 — Medium — `0416455`, `615a5f1`: several ADR-044 §4/§5 safety rules are pinned by no test

Each mutation below was applied alone. All 1,020 JUnit tests and all 248 GameTests still passed.

**WARP-03** (`…/station/warp/StationWarpService.java`):

| Mutation | Code changed |
|---|---|
| M02: commit no longer rechecks the actor (owner, or `getProfilePermissions >= 2`) | `:325-328` |
| M10: commit no longer rechecks the kill switch | `:314` |
| M03: every due countdown commits in the same tick | `:265-268` |
| M11: confirm checks the local player after `take()`, so another source can consume the confirmation | `:154-157` |
| M25: confirm no longer compares the observed state; the commit still aborts on a stale state, so defense in depth only | `:174` |
| M22: `receiveEnergy` charges a quarantined registry | `:91` |
| M16: `receiveEnergy` accepts off-thread calls | `:86` |
| M27: `receiveEnergy` accepts cores outside the Space Level | `:86-87` |

The GameTest assertions for M16 and M27 (`StationWarpGameTests.java:79-82` at `0416455`) are vacuous. The off-thread
call runs after both cores have already used the station's 200,000 FE for that tick, so it returns 0 with
or without the thread check. The Overworld core returns 0 because either the allowance is used or no station
region contains its x/z.

**WARP-04:**

| Mutation | Code changed |
|---|---|
| M08: every journal record counts as classified | `…/rocket/server/RocketTransferService.java:253` |
| M09: the live set is replaced by the settled set | `…/rocket/server/RocketTransferService.java:254` |
| M12: a rocket built on a station records the Space body again | `…/rocket/entity/RocketEntity.java:95-98` |

Only the pure rule is unit-tested. The GameTest checks just that the installed port is not `FAIL_CLOSED`.

**ADR-044 §8 traceability rows not delivered by WARP-03:**
- "a cost-class change and target removal both cancel": only a config price change is tested.
- The packet says a GameTest cannot swap data packs. But a GameTest can build its own `StationWarpService`
  on a private `CelestialCatalogManager`, as `PlanetaryAdmissionGameTests` already does for `RocketManager`,
  and apply a candidate catalog without the target.

**Failure scenario.** A later refactor (WARP-05, UI-01) could delete or invert any of these rules and every
check would still pass. For example:
- M11: a command block running `/execute as <player> run arce station warp confirm <id>` would burn the
  player's confirmation.
- M02 / M10: a countdown confirmed by an operator who has since been de-opped, or started before the kill
  switch was thrown, would still commit.
- M08: a restart with unrecovered journal records would allow warps while rockets are in flight.

**Suggested fix.** See "Required changes" item 2.

### R3 — Medium (pre-existing, outside these commits) — the satellite registry outgrows its own 4 MiB bound before its record limits

- Where: `…/satellite/persistence/SatelliteMissionSavedData.java:249-250`.
- The `615a5f1` probe reached 3.71 MB raw at 6,144 missions and 4,095 satellites. Before reaching 8,192
  missions (`MAX_MISSIONS`), `save` threw "Encoded satellite registry exceeds its fixed NBT bound".
- `AtomicSavedData.save` logs this once, and every later save fails. This is the satellite twin of the
  previous review's F2 (stations).
- The reviewed commits did not cause it; it is recorded so it is tracked.
- Suggested fix: an admission check like the one F2 added for stations, or bounds re-derived so the record
  limits fit the byte bound.

### R4 — Low — `0416455` + `1a5763a`: energy is destroyed when a fold refuses a new balance entry

**Where.**
- `0416455` `…/station/warp/StationWarpService.java:84-106`: `receiveEnergy` accepts energy for any station
  with room; `fold` drains every pending credit before folding.
- `1a5763a` `…/station/persistence/StationRegistrySavedData.java:223-265`: a credit that needs a new entry is
  refused while the encoded registry is above 4 MiB − 256 KiB, and returned as `refused`. The caller discards
  it.

**Contract gap.** ADR-044 §3 discloses only crash losses. §2 says such a credit "is refused", but by then the
core has already taken the energy from its source.

**Scenario.**
- The registry reaches the growth-admission limit. This is reachable by design after F2:
  `StationRegistryStorageBoundTest` itself ends above that limit after a fold.
- A station that spends its balance to exactly 0 (its entry is removed by `putBalance`), or one that never
  had a balance, keeps accepting up to 200,000 FE per tick.
- Every 200 ticks the fold refuses the new entry and the energy disappears, with one
  `ARCE_STATION_WARP_CREDIT_REFUSED` warning. That station can never recharge.

**Suggested fix.**
- Decide entry admission when energy is accepted: `receiveEnergy` returns 0 for a station without an entry
  while the headroom check fails (cache the decision per fold).
- Or admit a new entry whenever `encoded + 64 <= 4 MiB`. Every non-balance growth now stops at
  4 MiB − 256 KiB, so the 256 KiB headroom already belongs to balances.
- If the refusal stays, add it to the §3 disclosure.

### R5 — Low — `615a5f1`: ADR-044 §5 "new flight and transfer records store the station's current orbit body" is only half implemented

**Where.**
- `…/rocket/server/RocketFlightService.java:276-277`: `flight.withPlan(...).startCountdown(...)` keeps the
  docked rocket's saved `current_body`.
- `RocketTransferService.prepareLaunch` stores that value in the record's source flight data.
- `…/rocket/server/RocketTransferEntities.java:230-233` (`stationarySource`) restores it after a failed
  departure.

**What is implemented.** Only rockets assembled on a station (`RocketEntity.java:95-114`) and arrivals (the
plan's destination body) record the current orbit. A rocket that docked before a warp and then departs writes
a transfer record whose source `current_body` is the pre-warp orbit, and keeps that value after a fail-back.

**Impact.** None found today:
- admission ignores the field for station sources;
- the planner reads the station record;
- only the checksum and the schema-1 migration read the field.

It is still a contract mismatch, and a trap for any future reader of `current_body`.

**Suggested fix.** Refresh `current_body` from the station record when a station-sourced countdown starts,
or amend the §5 sentence to "rockets built on a station, and arrivals".

### R6 — Low — `0416455`: `/arce station warp status` folds credits and is not bound to the local-actor rule

**Where.**
- `…/station/command/StationWarpCommands.java:92-109`: no `issuedBy` check.
- `…/station/warp/StationWarpService.java:224-250`: `fold(server)` at line 246.

**Problem.**
- ADR-044 §2 fixes the fold triggers: every 200 ticks, before request and commit checks, and at stop. The
  stated goal is that a charging station "dirties the registry at most once per 10 s".
- `status` adds an unrestricted trigger: `/execute as <member>`, command blocks and functions can all run it.
- A repeating command block running `execute as @a run arce station warp status` therefore dirties the
  registry every tick while any core charges.
- Every ARCE flush (`DimensionDataStorage.save()` writes all dirty overworld data) then rewrites the station
  file, which can be up to 4 MiB.

**Suggested fix.** Make `status` read-only (show the folded balance plus `pendingCredit` without folding), or
apply the local-actor rule to it.

### R7 — Low — `615a5f1`: rule 2 can block every warp permanently, and operators have no way out

**Where.**
- `…/rocket/server/RocketStationMotionRule.java:36-40`.
- `…/rocket/server/RocketTransferRecoveryService.java:69-82`: `recoverNext` always retries the first
  unclassified record.
- `…/rocket/server/RocketTransferEntities.java:324-336`: `entityChunkLoaded` stays false forever when the
  record's Level is missing.

**Problem.** Rule 2 is global by design (ADR-044 §5). But a journal record whose Level no longer exists, for
example after a dimension or data pack is removed, stays `RETRY_LATER` forever. It then:
- blocks every warp on the server;
- starves recovery of the records queued behind it.

The packet's remedy, `/arce rocket recover <transfer_id>`, also returns `RETRY_LATER`, for the same reason.
`WARP_ROCKETS_IN_MOTION` does not name the blocking record.

**Suggested fix** (WARP-05 diagnostics, as the packet plans):
- name the unclassified or blocking transfer in the refusal and in `status`;
- let recovery move past a record it cannot classify;
- give operators an audited way to abandon a record whose Level is gone.

### R8 — Low — `1a5763a`: F2's growth admission is proven only for reserve, commit and invite-then-accept

- M06 (no check on `invite`), M20 (none on `transferOwnership`) and M18 (none on relocation to a longer orbit
  ID) all survive.
- `StationRegistryStorageBoundTest` only drives reserve, commit and invite-plus-accept. The `acceptInvitation`
  check and the running bound's 8 KiB-per-record over-estimate hide a missing `invite` check.
- The code is correct by inspection (see "Checked and found correct").
- Suggested fix: near the limit, assert that each growth path is refused on its own: `invite`, `addMember`,
  `acceptInvitation`, `transferOwnership`, `reserve`/`commit`, and `checkedRelocation` to a longer ID.

### R9 — Info — a pre-existing rocket GameTest is flaky

- The test is `…/gametest/RocketFlightGameTests.java:389`
  (`earthmoonroundtripconservesfuelandblockedpadreturnssource`, "Blocked-pad source cleanup failed").
- It failed in 2 of about 33 GameTest runs: the `615a5f1` full run and mutation M01. M01 is a credit
  mutation that cannot affect rockets.
- Both failing runs placed the Earth return fixture at y=63 (the world seed is random). One other y=63 run
  passed, and a clean rerun at `615a5f1` passed.
- The test has been unchanged since `660cfc9` (v1.1.1). Two runs at `9969550` under the same load passed.
- The failure is not attributable to these commits, but it can mask or fake a regression in any full run.
  It is worth hardening separately.

### R10 — Info — `1a5763a`: the CHANGELOG overstates F1

- The CHANGELOG says a declared array or list is "refused as oversized before any memory is reserved for it".
- That holds only for declarations the file cannot back. A declaration the file can back is still allocated
  before EOF: up to about 4.5 MB for a tiny file, or up to the type's quota for a large compressible file.
- The packet's residual-risk wording is correct.

### R11 — Info — `0416455`: ADR-044 §7 says the model uses the machine-casing textures

- The model's top face references `minecraft:block/crying_obsidian`. The packet discloses this.
- It is a reference, not a copied asset, so there is no licensing issue.
- Either amend §7 or use a project texture.

### R12 — Info — only the main and API JARs are reproducible from the committed trees

- Built from `git archive`, the main and API JARs match the packets byte-for-byte at all three commits.
- The sources JARs are 94 bytes smaller than the packets' in every case (for example, 1,272,058 against
  1,272,152 bytes at `1a5763a`).
- The compiled JAR matches, so this is most likely working-tree line endings in `.java` files. The author's
  logs show the checks ran in the repository working tree.
- The packets' sources-JAR hashes cannot be reproduced from the commits.

### R13 — Info — `1a5763a`: refused mutations inflate the growth bound

- `requireStorageRoom` (`StationRegistrySavedData.java:271-276`) grows `encodedUpperBound` before the model
  mutation runs.
- A rejected mutation therefore still adds 64 B or 8 KiB to the bound: an invite to a full list, a duplicate
  reservation or a missing invitation.
- Near the limit, each such command triggers a full encode of the registry (up to 4 MiB) on the server
  thread. This is only a command-rate risk; vanilla chat-spam limits apply.
- Suggested fix: grow the bound only after the mutation succeeds.

### R14 — Info — ADR-044 was edited in place while ACCEPTED (rev. 3)

- The §2 growth-admission paragraph adds a behavioural rule (creation and team growth are refused near the
  bound). The ADR calls this a text correction.
- ADR-040 still says "Counts remain 4,096 stations … 4 MiB registry". That now holds only for small records.
- The review-history entry makes the change traceable. Whether it needs a revision bump or an ADR-040
  cross-reference is the maintainer's call.

### R15 — Info — class size and dependency direction

- `StationRegistrySavedData` grew from 534 to 599 lines, and `RocketEntity` from 493 to 504. Both are over
  AGENTS.md's 500-line review threshold and well under 800.
- Suggestions:
  - move growth admission into a small storage-budget helper;
  - resolve the station orbit in `RocketTargetContextService`, which already resolves the station.
- The station → rocket dependency already existed (deletion guard). WARP-04 adds no new module edge.

### R16 — Info — `1a5763a`: the packet does not retain its failed focused runs

- The fix packet reports "exit 1 twice, then exit 0" for its focused runs, but archives only the full run.
- This is the same class as the previous F9. The WARP-03 packet does retain its failed full run.

## Previous findings F1-F12 (from `docs/work/v1.5.0-slices-review/`)

| ID | Claimed handling | Checked | Status |
|---|---|---|---|
| F1 | Per-type heap factor, plus a guard that refuses a single declaration the remaining raw bytes cannot back; tiny-file test for every type | See the guard analysis below. The guard is sound, and M07 (guard removed) is caught by the new test. But the per-type factor of 1 is R1 | **Resolved, with a new High regression (R1)** |
| F2 | Growth admission on creation, commit, member, invitation, transfer and longer-ID relocation; running upper bound; ADR text | Every growth path is admitted conservatively (below). The probe fills 1,887-1,930 full stations, folds every balance and stays under 4 MiB. Tests prove only part of it (R8) | Resolved (test gap R8) |
| F3 | Fold validated as a whole | Null key or value, negative, above the cap and more than 4,096 entries are refused before any credit; tested; M17 caught | Resolved |
| F4 | Javadoc and ADR §3 split of checks | Present. WARP-03's commit step folds and checks target, class and cost (`StationWarpService.java:329-336`, `363-400`) | Resolved (target-removal test missing, R2) |
| F5 | Candidate seam; five corruptions; root-shape message | Present, on both the relocation and growth paths; the message "schema 3 cannot carry warp_energy" is asserted | Resolved |
| F6 | Planner, survey, 16-system and reload tests | Planner cannot reach Tau Ceti e or a station there (`UNSUPPORTED_ROUTE`, with a Mars control); survey mission ends in `PENDING_DISCOVERY`; exactly 16 accepted, 17th refused. The reload stays in `PlanetaryReloadTest` | Resolved |
| F7 | Assert `OVERSIZED_DATA`; comment fixed | Present | Resolved |
| F8 | `startsCooldown` rule pinned for every code | Present, and the behaviour is equivalent to before. The call site is not tested, which is acceptable | Resolved |
| F9 | Acknowledged | The WARP-03 packet keeps its failed full run 01. The fix packet's failed focused runs are not kept (R16) | Partly |
| F10 | Thread confinement documented | In the `StationRegistrySavedData` class Javadoc | Resolved |
| F11 | `WARP_REGISTRY_SCHEMA_VERSION = 4` | Used by `formatEpoch`, `validateRootShape` and `StationRegistryPayload.upgrade`. The remaining `REGISTRY_SCHEMA_VERSION` use is `currentSchemaVersion()`, which is correct | Resolved |
| F12 | Recorded | Recorded in the packet | Resolved (Info) |

## Checked and found correct

### Authority (WARP-03)

**Request, confirm and cancel** go through `StationLocalActor.locate`, which requires all of:
- the player's own, non-silent source (`source.source == player && withSuppressedOutput() != source`);
- the same `ServerPlayer` instance present in the player list. This excludes the console, `/execute as`
  run by another source, command blocks, functions, FakePlayers and silent sources;
- the owner, or `hasPermissions(2)` (which is `getProfilePermissions`);
- the Space Level, checked by both key and identity;
- the actor's chunk already loaded (`hasChunkAt` never loads);
- a committed region, found with `findAt`.

**Request** additionally requires:
- a server ray pick within 5 blocks (`Entity.pick` is common code with no `@OnlyIn`);
- the hit block is `WARP_CORE`, in a loaded chunk;
- the hit block lies in the actor's own station.

**Confirm:**
- Non-local sources are refused before `take()`. `take()` is keyed by the caller's own UUID and bound to the
  station ID and the registry instance.
- The confirm then compares the full observed state and recomputes the quote: enabled, cooldown, countdown,
  catalog, target, knowledge, fold, balance, in motion, class and cost.

**Commit** checks, in order:
- enabled;
- operational and not quarantined;
- live state equals observed (an ownership transfer changes the state, so it aborts as `STATION_CHANGED`);
- actor is the owner, or `getProfilePermissions(actor) >= 2`. The ops list is keyed by UUID and works while
  the actor is offline; a de-op cancels;
- the recomputed quote (present, orbitable, known, not the current orbit; same class and cost);
- fold, then balance;
- in motion.

Then `checkedRelocation`; a runtime failure becomes `WRITE_FAILED`. Cooldown is recorded on
`COMMITTED`, `WRITE_FAILED` and `OUTCOME_UNKNOWN`. At most one commit runs per tick, and the countdown is
removed before its commit, so a failing commit is never retried.

**During a countdown:**
- a catalog reload, config change, target removal, deletion or quarantine each yields a named abort that is
  sent to online members;
- nothing persists before the commit;
- at stop, `ServerStoppingEvent` runs after the tick loop and before the stop save (`javap`), so the final
  fold is saved. Countdowns and confirmations are cleared; `clear()` at stopped resets credits, cooldown and
  the tick marker.

### Energy (WARP-03)

**`receiveEnergy`**, checked in this order:
- `maxReceive > 0`;
- `isSameThread()` first;
- Space Level by key and identity;
- operational and not quarantined;
- one `findAt`, which only finds committed stations;
- room = cap − balance − pending;
- a per-station, per-tick allowance;
- a pending map of at most 4,096 entries.

**Simulation and the energy view.**
- `simulate` records nothing. Its only effect is to reset the per-tick map at a tick boundary, which the next
  real call would do anyway.
- `getEnergyStored` returns 0, `extractEnergy` 0, `canExtract` false. A removed block entity returns 0, and
  its capabilities are invalidated.
- The only information exposed: `receiveEnergy(n, true)` reveals `cap − balance − pending` when that is below
  the allowance. Only someone who can place a core in the region (a member) can see it, and members can
  already read the balance with `status`.

**Credits** are drained, then folded, so they are never duplicated. They are lost only:
- in the ADR §3 crash cases;
- when the station was deleted before the fold;
- in the R4 case.

### In-motion rule (WARP-04)

**The rules.**
- Rule 1: the journal must be operational.
- Rule 2: every record must be in live ∪ settled.
- Rule 3: listed phases block; `PREPARED` blocks only while live.
- Rule 4: a committed arrival blocks until `stateStarted` (the scheduled arrival) + `DESCENT_TICKS` + 20,
  measured in overworld game time. Every Level shares that time through `DerivedLevelData`.

**Classification paths.**
- Every path that drops a record from the live set without settling it leaves it unclassified, so rule 2
  blocks until recovery reclassifies it. Those paths are: source missing, source no longer flying,
  destination missing, and a tick exception.
- `failBackToSource` removes the record.
- A recovery result of `RETRY_LATER` leaves the record unclassified (R7).
- `prepareLaunch` adds the record to the live set, synchronously on the server thread after the journal
  flush.
- A settled `PREPARED` record cannot relaunch (`REQUEST_REPLAYED`) until its settlement completes.

**Region overlap** is inclusive, covers both source and destination snapshots, and is limited to the Space
Level.

**Wiring and sessions.**
- The rule is wired in common setup (`enqueueWork`), before any server exists.
- In an integrated server, both services live on across sessions. `rocketManager.clear()` empties both sets at
  stop, so every new session starts unclassified (fail closed) until recovery runs.

### Admission (WARP-04)

For a station source, admission still requires every one of:
- the Space Level, and the live Level's identity;
- current dimension equal to the live Level;
- the snapshot's dimension;
- current target equal to the source;
- the station at the rocket's block position has that ID, so another station's region or a gap is refused;
- the orbit body is in the catalog;
- VISIT on the source station.

The planner takes the source body from the station record, and no quote comes from the client. No bypass
was found. The deletion guard fails closed on a blocked journal (M13 caught).

### F1 guard (1a5763a), checked against the 1.20.1 bytecode

**Charges per type:**
- End 8, Byte 9, Short 10, Int 12, Long 16, Float 12, Double 16.
- String: 36, then `readUTF` 2 + UTF length, charged after the read.
- Byte, Int and Long arrays: 24, then `len×1`, `len×4` or `len×8` respectively, charged before `newarray`.
- List: 37, then `4×len` before `newArrayListWithCapacity`. A list of `End` with length > 0 is rejected, and
  every other element needs at least one raw byte.
- Compound: 48, then per entry 2 + (2 + UTF length after the read) + (28 + 2×length) + 4 + 36.

**Soundness.**
- Only arrays and lists allocate by a declared count, and both are charged before the allocation, so the
  guard sees them.
- An array's charge equals its raw bytes; a list's charge is at most 4× its raw bytes.
- Post-read charges are at most 131,098 bytes.
- For valid data within its payload bound, the remaining raw quota is at least the 64 KiB file overhead.
  The compressed estimate is at least 1,024 × 1,032 + 64 KiB (deflate's 1,032:1 maximum; the gzip read-ahead
  buffer is 512 B). So the guard never refuses valid data.
- Negative lengths fail in the JVM and are refused as invalid (fail closed).
- The station probe confirms the largest registry admission allows is read back.

### F2 admission (1a5763a)

**Bounds charged per growth path:**
- reserve and commit: 8 KiB each; a record is at most 8 KiB standalone;
- invite, `addMember`, `acceptInvitation` and transfer: 64 B each. The actual growth is at most 26 B per team
  entry; a transfer adds at most the old owner;
- relocation: +Δ in orbit-ID length (ASCII);
- a new fold entry: 64 B (actual 47 B).

**Paths that do not grow:** release, delete, member removal, decline, expansion (region ints), gravity (int)
and debit.

**The bound stays safe.**
- Shrinking is ignored, so the bound stays conservative. A load starts unmeasured.
- The cheap bound (1,024 + (stations + reservations) × 8,192 + entries × 64) is a true upper bound.
- No path grows without accounting.

### Tests

No existing assertion was weakened or removed:
- `aNewBalanceEntryIsRefusedWhenTheRegistryIsNearItsBound` was rewritten with the same assertions (an
  existing entry is credited, a new one refused) in `StationRegistryStorageBoundTest`;
- `CommonConfigTest`'s change from 2 to 5 values is exact;
- the raw-bound test was strengthened;
- `PlanetaryAdmissionGameTests.catalogs` was refactored and keeps the same routes;
- `ConnectedTestPlayers` only adds action-bar capture.

## Mutation results

**Setup.**
- Each mutation was applied alone to an export of `1a5763a`, which contains all three slices.
- JUnit: `cleanTest test`, all 1,020 tests.
- GameTests: all 248, where the mutated code is reachable from a GameTest.
- Files were restored and byte-compared after every run.
- Scripts: `mutate.py`, `gt_failures.py`, `tally.py`. Logs: `evidence/mutations-lane*/`.
- The R9 flake appeared once, in M01's run, and was ignored when judging.

| ID | Commit | Mutation | Result | Caught by |
|---|---|---|---|---|
| M01 | WARP-03 | No per-tick allowance | Killed | `StationWarpStateTest.creditsRespect…`; GameTest `coresChargeOnlyTheStationTheyStandIn…` |
| M02 | WARP-03 | Commit skips the actor recheck | **Survived** | — (R2) |
| M03 | WARP-03 | Every due countdown commits in the same tick | **Survived** | — (R2) |
| M10 | WARP-03 | Commit skips the kill switch | **Survived** | — (R2) |
| M11 | WARP-03 | Confirm checks the local player after `take()` | **Survived** | — (R2) |
| M15 | WARP-03 | `simulate` records the credit | Killed | `StationWarpStateTest` |
| M16 | WARP-03 | Off-thread calls accepted | **Survived** | — (vacuous assertion, R2) |
| M19 | WARP-03 | No cooldown after a commit | Killed | GameTest `ownerWarpsInSystemAfterConfirmationAndCountdown` |
| M21 | WARP-03 | Commit skips the cost/class comparison | Killed | GameTest `cancelledChangedOrRepricedCountdownsNeverWarpOrCharge` |
| M22 | WARP-03 | Quarantined registry still charged | **Survived** | — (R2) |
| M25 | WARP-03 | Confirm skips the observed-state comparison | **Survived** | — (the commit still aborts; defense in depth) |
| M26 | WARP-03 | Core ray pick always succeeds | Killed | GameTest `requestsWithoutAuthorityCore…` |
| M27 | WARP-03 | Cores outside the Space Level accepted | **Survived** | — (vacuous assertion, R2) |
| M04 | WARP-04 | `PREPARED` always blocks | Killed | `RocketStationMotionRuleTest.preparedRecordsBlockOnlyWhileLive` |
| M05 | WARP-04 | `PREPARED` never blocks | Killed | same |
| M29 | WARP-04 | Rule 2 removed | Killed | `RocketStationMotionRuleTest.anUnavailableJournalOrAnUnclassifiedRecord…` |
| M30 | WARP-04 | Rule 4 removed | Killed | `RocketStationMotionRuleTest.aCommittedArrivalBlocks…` |
| M08 | WARP-04 | Wiring: every record counts as classified | **Survived** | — (R2) |
| M09 | WARP-04 | Wiring: the live set is replaced by the settled set | **Survived** | — (R2) |
| M12 | WARP-04 | A station-built rocket records the Space body | **Survived** | — (R2) |
| M13 | WARP-04 | Deletion allowed while the journal is blocked | Killed | GameTest `stationDeletionFailsClosedWhileTheTransferJournalIsBlocked` |
| M14 | WARP-04 | `current_body` comparison restored | Killed | GameTest `dockedRocketDepartsFromTheStationsNewOrbitAfterRelocation` |
| M06 | fixes | `invite` growth unchecked | **Survived** | — (R8) |
| M18 | fixes | Longer orbit-ID relocation unchecked | **Survived** | — (R8) |
| M20 | fixes | `transferOwnership` growth unchecked | **Survived** | — (R8) |
| M07 | fixes | Declaration guard removed | Killed | `BoundedSavedDataIoCapacityTest.aTinyFileDeclaringAHugeElement…` |
| M17 | fixes | Fold ignores the entry headroom | Killed | `StationRegistryStorageBoundTest.growthStops…` |
| M28 | fixes | 8× heap factor for every type | **Survived** | — (this is the R1 fix direction; nothing pins the per-type factor, which is also why R1 went unnoticed) |

**Summary:** 13 of 28 killed.
- WARP-03: 5 of 13 killed.
- WARP-04: 6 of 9 killed.
- Fixes: 2 of 6 killed.

The pure pieces are well tested: credits, rule 1-4 logic, the declaration guard and fold headroom. The
safety rechecks, the port wiring and the non-station growth paths are not.

## Evidence integrity

For `v1.5.0-warp-core`, `v1.5.0-warp-rockets` and `v1.5.0-slices-review`:
- every `SHA256SUMS.txt` line matches its committed blob;
- `evidence-archives.json` bytes, SHA-256 and member counts match the archives (198, 191, 193 and 65
  members);
- every ZIP member's size and SHA-256 matches its `*-files.json`, with none missing or extra;
- every `source-identity.json` entry matches the blob at its commit, and the entries cover exactly the files
  that commit changed outside the packet (45, 15 and 16);
- every relative link in `links.json` resolves.

0 problems (`evidence/evidence-integrity.log`). The main and API JARs are reproduced exactly; the sources JARs
are not (R12).

## Required changes

1. **R1 (`1a5763a`, blocking).**
   - Give every managed type a cumulative heap factor that covers its measured ratio: 8 for satellites and
     celestial; measure the rocket journals, and tighten the array allowance if their factor is raised.
   - Add per-type capacity round-trip tests through `CheckedSavedDataFile.replace` and
     `BoundedSavedDataIo.read`.
2. **R2 (`0416455`, `615a5f1`).** Add tests that fail under M02, M03, M08, M09, M10, M11, M12, M16, M22 and
   M27:
   - an operator actor de-opped mid-countdown → `WARP_ACTOR_CHANGED`;
   - the kill switch thrown mid-countdown → abort;
   - `/execute as <player> … confirm` leaves the player's confirmation usable;
   - two countdowns due in the same tick commit in consecutive ticks;
   - off-thread and Overworld calls made while the station still has allowance;
   - a quarantined registry refuses energy;
   - `RocketTransferService.stationRegionInMotion` with one live and one settled record (a package-level
     unit test, or a GameTest with an isolated journal);
   - a station-built rocket's `current_body`;
   - a target removed from a private `CelestialCatalogManager` during a countdown.
3. **R8 (`1a5763a`).** Refusal tests for each growth path near the limit.
4. **R4-R7 (WARP-05 at the latest):**
   - R4: stop destroying energy on entry refusal, or disclose it;
   - R5: refresh `current_body` for station departures, or amend §5;
   - R6: make `status` read-only;
   - R7: rule-2 diagnostics and an operator path for records that cannot be classified.

R3 is pre-existing and should be tracked separately. R9-R16 are recommendations.

## Residual risks

- **Untested end to end.** The real in-motion rule never runs in a warp GameTest; the wiring is untested
  (R2). WARP-05's native evidence has not been reviewed here.
- **Accepted, not solved.** ADR-044 §3's Forge Energy loss and duplication around crashes is disclosed and
  accepted, not solved.
- **Server-thread spikes.**
  - Growth admission and full-registry candidates encode up to 4 MiB on the server thread.
  - Probe registries ran at a heap-accounting ratio of 6.4. Time was not measured here.
- **Method limits.**
  - Mutations were judged on a single run each, on a loaded machine.
  - Probes are scratch tests, not native evidence.
  - The rocket-journal capacity under factor 1 was not measured.
- **Still open.** V1/V2 client evidence, native multiplayer and restart evidence, and performance acceptance
  remain open, as the packets state.

## Statement

This review is independent evidence for the maintainer. It is **not** a Gate approval. It does not mark any
leaf verified or accepted, and it does not change any version, leaf or release status.
