"""Collect the C14 preparation run: JUnit XML and summary, GameTest logs, hashes of every non-documentation file
changed since the v1.8 development baseline, artifact hashes, and a byte comparison of the three JARs with the
v1.7 development handoff build."""
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
sha = lambda b: hashlib.sha256(b).hexdigest()

base = (E / 'base-commit.txt').read_text().strip()
junit = E / 'full-junit'
junit.mkdir()
tests = failures = errors = skipped = suites = 0
for f in sorted((ROOT / 'build/test-results/test').glob('*.xml')):
    shutil.copyfile(f, junit / f.name)
    r = ET.parse(f).getroot()
    suites += 1
    tests += int(r.get('tests')); failures += int(r.get('failures')); errors += int(r.get('errors'))
    skipped += int(r.get('skipped'))
summary = {'suites': suites, 'tests': tests, 'failures': failures, 'errors': errors, 'skipped': skipped}
(E / 'junit-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')

changed = subprocess.check_output(['git', 'diff', '--name-only', base, 'HEAD'], cwd=ROOT).decode().splitlines()
files = {}
for path in changed:
    if path.startswith('docs/') or path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/'):
        continue
    if (ROOT / path).is_file():
        files[path] = sha((ROOT / path).read_bytes())
(E / 'implementation-files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8',
                                            newline='\n')
(E / 'post-run-changes.json').write_text('{"files": []}\n', encoding='utf-8', newline='\n')

artifacts = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append({'name': jar.name, 'bytes': jar.stat().st_size, 'sha256': sha(jar.read_bytes())})
(E / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}, indent=2) + '\n', encoding='utf-8',
                                  newline='\n')

for name in ('latest.log', 'debug.log'):
    log = ROOT / 'build/gametest/logs' / name
    if log.exists():
        shutil.copyfile(log, E / ('gametest-' + name))

HANDOFF = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v170-c13-close2-d5991756c4e14bd0ace46b7af9dd39ee/artifacts.json')
previous = {a['name']: a for a in json.loads(HANDOFF.read_text())['artifacts']}
rows = []
for artifact in artifacts:
    before = previous.get(artifact['name'])
    rows.append({'name': artifact['name'], 'handoff_sha256': before and before['sha256'],
                 'current_sha256': artifact['sha256'], 'identical': bool(before) and before['sha256'] == artifact['sha256']})
result = {'comparison': 'all JARs against the v1.7 development handoff build (C13 closure run, 55da6a5)',
          'artifacts': rows, 'all_identical': all(row['identical'] for row in rows) and len(rows) == len(previous)}
(E / 'artifact-comparison.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(summary, len(files), 'non-documentation files changed since the baseline', [a['name'] for a in artifacts])
print('all JARs identical to the v1.7 handoff build:', result['all_identical'])
