#!/usr/bin/env bash
# C14 Python checks after the acceptance edits (documentation only); each log and exit code is kept.
C=/c/Users/Administrator/AppData/Local/Temp/arce-v180-preparation-7ab047faa03449238fbf4da5149d956b
EV=/c/Users/Administrator/AppData/Local/Temp/arce-v180-c14-189c61a748584cab97c5881f8bdc1251
cd /d/GitHub/AdvancedRocketry-Community || exit 1
mkdir -p $C/python
git rev-parse HEAD > $C/python/head.txt
git status --porcelain > $C/python/status.txt
run() { name=$1; shift; "$@" > $C/python/$name.log 2>&1; echo $? > $C/python/$name.exit; }
run py-01-ledger python -B scripts/validate_v180_content_ledger.py
run py-02-ledger-accepted python -B scripts/validate_v180_content_ledger.py --require-accepted
run py-03-ledger-closure python -B scripts/validate_v180_content_ledger.py --closure
run py-04-inventory python -B tools/audit/inventory_v180_content.py --upstream $EV/upstream/ar --check
run py-05-derivation python -B tools/audit/vanilla_derivation.py --upstream $EV/upstream/ar --vanilla 1.12.2=$EV/vanilla/client-1.12.2.jar --vanilla 1.20.1=$EV/vanilla/client-1.20.1.jar --check --report-memory
run py-06-unittest python -B -m unittest -v tests.test_validate_v180_content_ledger tests.test_vanilla_derivation
run py-07-bootstrap python -B scripts/validate_bootstrap_provenance.py
run py-08-fetch-clients python -B tools/audit/fetch_vanilla_clients.py --output $EV/vanilla
echo DONE > $C/python/status.done
