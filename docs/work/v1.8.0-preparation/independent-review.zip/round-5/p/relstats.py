"""Relation statistics of the committed results, and IMPORT files related (either side) to flagged files."""
import csv
import fnmatch
import json
import sys
from collections import Counter

d = json.load(open(sys.argv[1], encoding="utf-8"))
rules = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))
findings = {f["asset"]: f for f in json.load(open(sys.argv[3], encoding="utf-8"))["findings"]}


def rule(asset):
    for r in rules:
        if fnmatch.fnmatchcase(asset, r["pattern"]):
            return r


verdict = {e["asset"]: e["verdict"] for e in d["assets"]}
handling = {a: rule(a)["handling"] for a in verdict}
listed = {e["asset"]: {r["asset"]: r["level"] for r in e.get("related", [])} for e in d["assets"]}
total = sum(len(v) for v in listed.values())
one_sided = [(a, b) for a, r in listed.items() for b in r if a not in listed.get(b, {})]
print("counts", d["counts"], "| relations recorded", total, "| one-sided", len(one_sided),
      "| max per file", max(len(v) for v in listed.values()))
print("thresholds keys with 'related':", [k for k in d["thresholds"] if "related" in k])
sym = {}
for a, r in listed.items():
    for b, lv in r.items():
        for x, y in ((a, b), (b, a)):
            if sym.setdefault(x, {}).get(y) != "HIT":
                sym[x][y] = lv


def flag(asset):
    f = findings.get(asset, {}).get("decision")
    if f == "CLEARED":
        return None
    if verdict.get(asset) in ("HIT", "SUSPECT", "UNSUPPORTED"):
        return "verdict " + verdict[asset]
    if handling.get(asset) == "REVIEW":
        return "REVIEW"
    if f == "EXCLUDED":
        return "EXCLUDED finding"
    return None


bad = []
for a, h in sorted(handling.items()):
    if h == "IMPORT" and findings.get(a, {}).get("decision") != "CLEARED":
        for b, lv in sorted(sym.get(a, {}).items()):
            if flag(b):
                bad.append((a, b, lv, flag(b)))
print("IMPORT files related (either side) to a flagged file:", len(bad))
for row in bad:
    print("  ", row)
print("handling counts", Counter(handling.values()))
excl = [(a, b, lv, rule(b)["reason"][:70]) for a, h in sorted(handling.items()) if h == "IMPORT"
        for b, lv in sorted(sym.get(a, {}).items()) if handling.get(b) == "EXCLUDE" and not flag(b)]
print("IMPORT files related to EXCLUDE-by-rule files (not inherited by ADR):", len(excl))
for row in excl:
    print("  ", row)
