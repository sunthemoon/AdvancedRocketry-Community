"""Round-4 mutations of copies of the v1.8 inputs through the round-4 validator (helpers from round 3)."""
import json
import sys

import mutate3lib as m
from mutate3lib import (ADR061, M, edit_entry, edit_ledger, edit_plan, evidence_folder, mut, repin_results,  # noqa: F401
                        rows, set_allow, set_findings)

FINDINGS = "docs/provenance/v1.8.0-origin-findings.json"
TAB = "textures/gui/buttons/tabtemplate.png"
TABWARP = "textures/gui/buttons/tabwarp.png"
EXCLUDED_TAB = json.loads((m.TREE / FINDINGS).read_text(encoding="utf-8"))["findings"]

# Keep only the round-3 cases whose behaviour round 4 changed or that stay relevant.
KEEP = ("R3-a", "R3-b", "R3-c", "R3-e", "R3-f", "R3-g")
M[:] = [(n, f) for n, f in M if n.startswith(KEEP)]


def results():
    return json.loads((m.TREE / m.DERIV).read_text(encoding="utf-8"))


def hit_relative():
    """A CLEAR file, allowlisted REVIEW, related at HIT level to a file whose own verdict is HIT."""
    d = results()
    verdict = {e["asset"]: e["verdict"] for e in d["assets"]}
    allow = dict(l.split("\t") for l in (m.TREE / m.ALLOW).read_text(encoding="utf-8").splitlines() if "\t" in l)
    for e in d["assets"]:
        if e["verdict"] != "CLEAR" or allow.get(e["asset"]) != "REVIEW":
            continue
        for r in e.get("related", []):
            if r["level"] == "HIT" and verdict.get(r["asset"]) == "HIT" and r.get("method") != "hash":
                return e["asset"], r["asset"], r
    raise AssertionError("no CLEAR file related at HIT level to a HIT file")


def plan_pattern(asset):
    import fnmatch
    for r in rows(m.TREE, m.PLAN):
        if fnmatch.fnmatchcase(asset, r["pattern"]):
            return r["pattern"]


def owner_cleared(asset, **extra):
    f = {"asset": asset, "decision": "CLEARED", "reviewer": "sunthemoon", "reviewed_at": "2026-10-03",
         "basis": "compared; differs"}
    f.update(extra)
    return f


@mut("R4-a evidence file names the unit but not the delivered modern ID")
def r4a(r):
    folder = r / "docs/work/v1.8.0-c16b-machines"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "VERIFICATION.md").write_text("delivered: block:lathe\n", encoding="utf-8")
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062",
                evidence="docs/work/v1.8.0-c16b-machines/VERIFICATION.md")


@mut("R4-b evidence file names the unit and the modern ID only inside longer tokens (block:lathe_2, ..._casing2)")
def r4b(r):
    folder = r / "docs/work/v1.8.0-c16b-machines"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "VERIFICATION.md").write_text(
        "delivered: block:lathe_2 as advancedrocketrycommunity:machine_casing2\n", encoding="utf-8")
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062",
                evidence="docs/work/v1.8.0-c16b-machines/VERIFICATION.md")


@mut("R4-c evidence file names both only with a '/' or '.' suffix (block:lathe/old, ...machine_casing.json)")
def r4c(r):
    folder = r / "docs/work/v1.8.0-c16b-machines"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "VERIFICATION.md").write_text(
        "not delivered: block:lathe/old; see advancedrocketrycommunity:machine_casing.json\n", encoding="utf-8")
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062",
                evidence="docs/work/v1.8.0-c16b-machines/VERIFICATION.md")


@mut("R4-d HIT override with a confirmation_record file that names the asset and the confirmer")
def r4d(r):
    rec = r / "docs/work/v1.8.0-preparation/confirm-earth.md"
    rec.parent.mkdir(parents=True, exist_ok=True)
    rec.write_text("textures/env/earth_phases.png confirmed by x\n", encoding="utf-8")
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/env/earth_phases.png", overrides="HIT", confirmed_by="x",
                                                  confirmation_record="docs/work/v1.8.0-preparation/confirm-earth.md")])
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "REVIEW")


@mut("R4-e HIT override whose confirmation_record is the findings file itself")
def r4e(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/env/earth_phases.png", overrides="HIT", confirmed_by="x",
                                                  confirmation_record=FINDINGS)])
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "REVIEW")


@mut("R4-f independent-reviewer CLEARED finding whose review_record is the findings file itself")
def r4f(r):
    set_findings(r, EXCLUDED_TAB + [{"asset": "textures/items/space_boots.png", "decision": "CLEARED",
                                     "reviewer": "someone", "role": "independent reviewer", "review_record": FINDINGS,
                                     "reviewed_at": "2026-10-03", "basis": "looks fine"}])
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R4-g tab button IMPORT with allowlist IMPORT + ADR-062 re-pin (inheritance)")
def r4g(r):
    edit_plan(r, TABWARP, handling="IMPORT")
    set_allow(r, TABWARP, "IMPORT")


@mut("R4-h as R4-g, and the tab button's related entries stripped + ADR-061 re-pin (validator only; CI --check)")
def r4h(r):
    edit_plan(r, TABWARP, handling="IMPORT")
    set_allow(r, TABWARP, "IMPORT")
    edit_entry(r, TABWARP, related=None)
    repin_results(r)


@mut("R4-i related entry level changed HIT -> SUSPECT keeping its measures + re-pin")
def r4i(r):
    d = results()
    entry = next(e for e in d["assets"] if e["asset"] == TABWARP)
    rel = [dict(x, level="SUSPECT") if x["asset"] == TAB else x for x in entry["related"]]
    edit_entry(r, TABWARP, related=rel)
    repin_results(r)


@mut("R4-j related entry naming an asset that is not a legacy asset + re-pin")
def r4j(r):
    d = results()
    entry = next(e for e in d["assets"] if e["asset"] == TABWARP)
    rel = entry["related"] + [dict(entry["related"][0], asset="textures/gui/buttons/nonexistent.png")]
    edit_entry(r, TABWARP, related=rel)
    repin_results(r)


@mut("R4-k EXCLUDED tab-template finding removed; tab template IMPORT, allowlist IMPORT + re-pin")
def r4k(r):
    set_findings(r, [])
    edit_plan(r, TAB, handling="IMPORT", plan="C16a", units="-")
    set_allow(r, TAB, "IMPORT")


@mut("R4-l EXCLUDED tab-template finding removed only (plan and allowlist unchanged)")
def r4l(r):
    set_findings(r, [])


@mut("R4-m owner's plain CLEARED finding on a CLEAR file related at HIT level to a HIT file; IMPORT under REVIEW ceiling")
def r4m(r):
    asset, other, rel = hit_relative()
    print(f"      (R4-m uses {asset}, related {rel['level']} to {other}, overlap {rel.get('overlap')}, "
          f"exact {rel.get('exact')})", file=sys.stderr)
    set_findings(r, EXCLUDED_TAB + [owner_cleared(asset)])
    edit_plan(r, plan_pattern(asset), handling="IMPORT")


@mut("R4-n owner's plain CLEARED finding on SUSPECT buttonautoeject releases tab buttons? (tabwarp IMPORT + allowlist)")
def r4n(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/gui/buttons/buttonautoeject.png")])
    edit_plan(r, TABWARP, handling="IMPORT")
    set_allow(r, TABWARP, "IMPORT")


def main():
    import shutil
    out = []
    base = m.OUT / "mut"
    for name, fn in M:
        m.fresh(base)
        try:
            fn(base)
        except AssertionError as ex:
            out.append((name + f" [setup failed: {ex}]", None, []))
            continue
        rc, err = m.run(base)
        out.append((name, rc, err[:3]))
    shutil.rmtree(base)
    for name, rc, err in out:
        status = "n/a" if rc is None else ("CAUGHT" if rc != 0 else "SURVIVED")
        print(f"[{status}] {name}")
        for e in err:
            print(f"      {e[:240]}")


