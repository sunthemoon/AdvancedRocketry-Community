"""Posting cap and legacy relations: N legacy 16x16 files share a casing tile (each with its own 4x4 face
painted in the middle); a 128x64 model sheet embeds the bare tile. Is the sheet related to the tile file?"""
import sys

sys.path.insert(0, sys.argv[1])
from tools.audit.vanilla_derivation import LEGACY, Image, match_images  # noqa: E402


def noise(width, height, seed, colours=24):
    state, palette, out = seed, [], []
    for _ in range(colours):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        palette.append((state & 0xFF, (state >> 8) & 0xFF, (state >> 16) & 0xFF, 255))
    for _ in range(width * height):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        out.append(palette[state % colours])
    return out


tile = noise(16, 16, 601)
for n in (8, 16, 24, 40, 80):
    legacy = [("casing.png", Image(16, 16, tile))]
    for i in range(n):
        face = list(tile)
        own = noise(4, 4, 1000 + i)
        for y in range(4):
            for x in range(4):
                face[(y + 6) * 16 + x + 6] = own[y * 4 + x]
        legacy.append((f"machine_{i:02d}.png", Image(16, 16, face)))
    sheet = noise(128, 64, 613, colours=8)
    for y in range(16):
        for x in range(16):
            sheet[(y + 20) * 128 + 40 + x] = tile[y * 16 + x]
    legacy.append(("model.png", Image(128, 64, sheet)))
    matcher = match_images(legacy, [(LEGACY, name, image) for name, image in legacy])
    model = matcher.related.get("model.png", {})
    back = [name for name, table in matcher.related.items() if "model.png" in table]
    print(f"N={n:3d}: model.png lists casing.png: {'casing.png' in model} ({len(model)} relations); "
          f"files listing model.png: {len(back)}; casing.png relations: {len(matcher.related.get('casing.png', {}))}",
          flush=True)
