"""Round-5 mutations: the round-3/4 cases plus new ones, through the round-5 validator."""
import json

import mutate3lib as m
import mutate4lib as m4
from mutate3lib import M, edit_entry, edit_plan, mut, repin_results, rows, set_allow, set_findings, write

FINDINGS = m4.FINDINGS
EXCLUDED_TAB = m4.EXCLUDED_TAB
owner_cleared = m4.owner_cleared


@mut("R5-a plain CLEARED warning.png with releases naming progressbars.png (IMPORT under REVIEW ceiling)")
def r5a(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/gui/warning.png",
                                                  releases=["textures/gui/progressbars/progressbars.png"])])
    edit_plan(r, m4.plan_pattern("textures/gui/warning.png"), handling="IMPORT")


@mut("R5-b plain CLEARED warning.png whose releases names some other file")
def r5b(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/gui/warning.png", releases=["textures/env/sun.png"])])
    edit_plan(r, m4.plan_pattern("textures/gui/warning.png"), handling="IMPORT")


@mut("R5-c HIT override whose confirmation_record aliases the findings file (docs/../docs/provenance/...)")
def r5c(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared(
        "textures/env/earth_phases.png", overrides="HIT", confirmed_by="x",
        confirmation_record="docs/../docs/provenance/v1.8.0-origin-findings.json")])
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "REVIEW")


@mut("R5-d independent-reviewer CLEARED finding whose review_record is docs/provenance/./v1.8.0-origin-findings.json")
def r5d(r):
    set_findings(r, EXCLUDED_TAB + [{"asset": "textures/items/space_boots.png", "decision": "CLEARED",
                                     "reviewer": "someone", "role": "independent reviewer",
                                     "review_record": "docs/provenance/./v1.8.0-origin-findings.json",
                                     "reviewed_at": "2026-10-03", "basis": "looks fine"}])
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R5-e monitorrear IMPORT + allowlist IMPORT + re-pin (relation listed only by crystallizer_active)")
def r5e(r):
    edit_plan(r, "textures/blocks/monitorrear.png", handling="IMPORT")
    set_allow(r, "textures/blocks/monitorrear.png", "IMPORT")


@mut("R5-f as R5-e and the relation removed from crystallizer_active's list + ADR-061 re-pin (validator only)")
def r5f(r):
    edit_plan(r, "textures/blocks/monitorrear.png", handling="IMPORT")
    set_allow(r, "textures/blocks/monitorrear.png", "IMPORT")
    d = m4.results()
    entry = next(e for e in d["assets"] if e["asset"] == "textures/blocks/crystallizer_active.png")
    edit_entry(r, "textures/blocks/crystallizer_active.png",
               related=[x for x in entry["related"] if x["asset"] != "textures/blocks/monitorrear.png"])
    repin_results(r)


@mut("R5-g areagravitycontroller model texture IMPORT + allowlist IMPORT + re-pin")
def r5g(r):
    edit_plan(r, "textures/models/areagravitycontroller.png", handling="IMPORT")
    set_allow(r, "textures/models/areagravitycontroller.png", "IMPORT")


@mut("R5-h tab-template plan row widened to a glob citing the finding, finding removed")
def r5h(r):
    set_findings(r, [])
    rs = rows(r, m.PLAN)
    for row in rs:
        if row["pattern"] == "textures/gui/buttons/tabtemplate.png":
            row["pattern"] = "textures/gui/buttons/tabtemplat?.png"
    write(r, m.PLAN, rs)


@mut("R5-i EXCLUDED tab-template finding with review_record = the findings file")
def r5i(r):
    set_findings(r, [dict(EXCLUDED_TAB[0], review_record=FINDINGS)])


@mut("R5-j tab-template finding keeps EXCLUDED but its review_record points at a file not naming it")
def r5j(r):
    set_findings(r, [dict(EXCLUDED_TAB[0], review_record="docs/work/v1.8.0-preparation/reviews/REVIEW-01.md")])


@mut("R5-k plain CLEARED finding with releases given as a string")
def r5k(r):
    set_findings(r, EXCLUDED_TAB + [owner_cleared("textures/gui/warning.png",
                                                  releases="textures/gui/progressbars/progressbars.png")])


def main():
    import shutil
    out = []
    base = m.OUT / "mut"
    for name, fn in M:
        m.fresh(base)
        try:
            fn(base)
        except AssertionError as ex:
            out.append((name + f" [setup failed: {ex}]", None, []))
            continue
        rc, err = m.run(base)
        out.append((name, rc, err[:3]))
    shutil.rmtree(base)
    for name, rc, err in out:
        status = "n/a" if rc is None else ("CAUGHT" if rc != 0 else "SURVIVED")
        print(f"[{status}] {name}")
        for e in err:
            print(f"      {e[:240]}")


main()
