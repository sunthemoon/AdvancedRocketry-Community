"""Round-2 mutations of copies of the v1.8 inputs through the revised validator."""
import csv
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

TREE = Path(sys.argv[1])
OUT = Path(sys.argv[2])
VALIDATOR = TREE / "scripts/validate_v180_content_ledger.py"
COPY = ["legacy-manifest", "docs/decisions", "docs/versions", "docs/provenance", "src/generated", "docs/work/v1.8.0-preparation",
        "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry"]
FILES = ["docs/work/v1.8.0-legacy-inventory.json", "docs/work/v1.8.0-content-ledger.csv",
         "docs/work/v1.8.0-asset-plan.csv", "docs/work/v1.8.0-asset-import-allowlist.txt",
         "docs/work/v1.8.0-vanilla-derivation.json", "docs/work/v1.8.0-content-audit.md"]
INV, LEDGER, PLAN, ALLOW, DERIV = FILES[0], FILES[1], FILES[2], FILES[3], FILES[4]
ADR062 = "docs/decisions/ADR-062-CLASSIC-CONTENT-DISPOSITIONS-AND-BATCHES.md"
EVID = "docs/work/v1.8.0-content-audit.md"


def fresh(root):
    if root.exists():
        shutil.rmtree(root)
    for c in COPY:
        src = TREE / c
        if src.exists():
            shutil.copytree(src, root / c)
    if (TREE / "src/main/resources").exists():
        shutil.copytree(TREE / "src/main/resources", root / "src/main/resources")
    for f in FILES:
        (root / f).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(TREE / f, root / f)


def rows(root, rel):
    with (root / rel).open(encoding="utf-8", newline="") as h:
        return list(csv.DictReader(h))


def write(root, rel, rs):
    b = io.StringIO()
    w = csv.DictWriter(b, fieldnames=list(rs[0].keys()), lineterminator="\n")
    w.writeheader()
    w.writerows(rs)
    (root / rel).write_text(b.getvalue(), encoding="utf-8", newline="")


def edit_ledger(root, uid, **ch):
    rs = rows(root, LEDGER)
    hit = False
    for r in rs:
        if r["unit_id"] == uid:
            r.update(ch)
            hit = True
    assert hit, uid
    write(root, LEDGER, rs)


def edit_plan(root, pattern, **ch):
    rs = rows(root, PLAN)
    hit = False
    for r in rs:
        if r["pattern"] == pattern:
            r.update(ch)
            hit = True
    assert hit, pattern
    write(root, PLAN, rs)


def set_allow(root, asset, ceiling, repin=True):
    p = root / ALLOW
    lines = [l for l in p.read_text(encoding="utf-8").splitlines() if l.split("\t")[0] != asset]
    lines.append(f"{asset}\t{ceiling}")
    lines.sort()
    data = ("\n".join(lines) + "\n").encode("utf-8")
    p.write_bytes(data)
    if repin:
        a = root / ADR062
        t = a.read_text(encoding="utf-8")
        t = re.sub(r"^import_allowlist_sha256:.*$", "import_allowlist_sha256: " + hashlib.sha256(data).hexdigest(),
                   t, flags=re.M)
        a.write_text(t, encoding="utf-8")


def set_verdict(root, asset, verdict):
    p = root / DERIV
    d = json.loads(p.read_text(encoding="utf-8"))
    for e in d["assets"]:
        if e["asset"] == asset:
            e["verdict"] = verdict
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def set_findings(root, findings):
    p = root / "docs/provenance/v1.8.0-origin-findings.json"
    p.write_text(json.dumps({"schema_version": 1, "findings": findings}), encoding="utf-8")


def run(root, *extra):
    p = subprocess.run([sys.executable, str(VALIDATOR), "--root", str(root), *extra],
                       capture_output=True, text=True, timeout=600)
    return p.returncode, p.stderr.strip().splitlines()



# ---- round-3 cases (appended to the round-2 helpers in mutate3_head.py) ----
ADR061 = "docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md"


def repin_results(root):
    data = (root / DERIV).read_bytes()
    a = root / ADR061
    t = a.read_text(encoding="utf-8")
    t = re.sub(r"^derivation_results_sha256:.*$", "derivation_results_sha256: " + hashlib.sha256(data).hexdigest(),
               t, flags=re.M)
    a.write_text(t, encoding="utf-8")


def edit_entry(root, asset, **ch):
    p = root / DERIV
    d = json.loads(p.read_text(encoding="utf-8"))
    for e in d["assets"]:
        if e["asset"] == asset:
            for k, v in ch.items():
                if v is None:
                    e.pop(k, None)
                else:
                    e[k] = v
    counts = {}
    for e in d["assets"]:
        counts[e["verdict"]] = counts.get(e["verdict"], 0) + 1
    d["counts"] = dict(sorted(counts.items()))
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def evidence_folder(root, unit):
    folder = root / "docs/work/v1.8.0-c16b-machines"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "VERIFICATION.md").write_text(f"delivered: {unit}\n", encoding="utf-8")
    return "docs/work/v1.8.0-c16b-machines/VERIFICATION.md"


M = []


def mut(name):
    def deco(fn):
        M.append((name, fn))
        return fn
    return deco


@mut("R2 R1-2 IMPLEMENTED lathe -> unrelated registered block, evidence = the audit file")
def r01(r):
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062", evidence=EVID)


@mut("R3-a IMPLEMENTED lathe -> unrelated registered block, evidence = a batch folder file that names the unit")
def r02(r):
    ev = evidence_folder(r, "block:lathe")
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062", evidence=ev)


@mut("R3-b evidence file lists only a longer unit id that contains the unit id as a substring")
def r03(r):
    folder = r / "docs/work/v1.8.0-c16b-machines"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "VERIFICATION.md").write_text("delivered: block:latheX\n", encoding="utf-8")
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062",
                evidence="docs/work/v1.8.0-c16b-machines/VERIFICATION.md")


@mut("R2-a flip HIT earth_phases to CLEAR, IMPORT, allowlist + ADR-062 re-pin (no ADR-061 re-pin)")
def r04(r):
    set_verdict(r, "textures/env/earth_phases.png", "CLEAR")
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "IMPORT")


@mut("R3-c flip HIT earth_phases to CLEAR, drop its measures, re-pin ADR-061 and ADR-062 (validator only; CI --check would catch)")
def r05(r):
    edit_entry(r, "textures/env/earth_phases.png", verdict="CLEAR", best=None)
    repin_results(r)
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "IMPORT")


@mut("R3-d flip HIT earth_phases to CLEAR keeping its measures, re-pin both ADRs")
def r06(r):
    edit_entry(r, "textures/env/earth_phases.png", verdict="CLEAR")
    repin_results(r)
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "IMPORT")


@mut("R2-f CLEARED finding for SUSPECT space_boots by 'anyone'")
def r07(r):
    set_findings(r, [{"asset": "textures/items/space_boots.png", "decision": "CLEARED", "reviewer": "anyone",
                      "reviewed_at": "2026-10-02", "basis": "looks fine"}])
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R3-e CLEARED finding for SUSPECT space_boots written in the owner's name")
def r08(r):
    set_findings(r, [{"asset": "textures/items/space_boots.png", "decision": "CLEARED", "reviewer": "sunthemoon",
                      "reviewed_at": "2026-10-02", "basis": "looks fine"}])
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R3-f HIT override in the owner's name with any confirmed_by string, REVIEW ceiling + re-pin")
def r09(r):
    set_findings(r, [{"asset": "textures/env/earth_phases.png", "decision": "CLEARED", "reviewer": "sunthemoon",
                      "reviewed_at": "2026-10-02", "basis": "differs", "overrides": "HIT", "confirmed_by": "x"}])
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "REVIEW")


@mut("R2-g model texture moved after its model (cuttingmachine2 C16b -> C18d)")
def r10(r):
    edit_plan(r, "textures/models/cuttingmachine2.png", plan="C18d")


@mut("R2-h IMPORT rule owner replaced by an unrelated unit of an earlier batch")
def r11(r):
    edit_plan(r, "textures/blocks/moonturf_placeholder_none", units="x") if False else None
    rs = rows(r, PLAN)
    for row in rs:
        if row["handling"] == "IMPORT" and row["plan"] == "C18d":
            row["units"] = "block:platepress"
            break
    write(r, PLAN, rs)


@mut("R2-j IMPLEMENTED sound_event:lathe with the existing ui_select sound and a batch evidence file")
def r12(r):
    ev = evidence_folder(r, "sound_event:lathe")
    edit_ledger(r, "sound_event:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:ui_select", decision="ADR-062", evidence=ev)


@mut("R2-k derivation JSON: drop the vanilla jar hashes and thresholds (no re-pin)")
def r13(r):
    p = r / DERIV
    d = json.loads(p.read_text(encoding="utf-8"))
    d["vanilla"] = {}
    d["thresholds"] = {}
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


@mut("R2-m PLANNED asm_rule GravityHandler(living) moved to REJECTED citing ADR-062")
def r14(r):
    edit_ledger(r, "asm_rule:GravityHandler.applyGravity(living)", disposition="REJECTED", plan="-", target="-",
                decision="ADR-062")


@mut("R3-g tabwarp.png (contains the excluded vanilla tab) stays IMPORT -- baseline state")
def r15(r):
    pass


def main():
    results = []
    base = OUT / "mut"
    for name, fn in M:
        fresh(base)
        try:
            fn(base)
        except AssertionError as ex:
            results.append((name + f" [setup failed: {ex}]", None, []))
            continue
        rc, err = run(base)
        results.append((name, rc, err[:3]))
    shutil.rmtree(base)
    for name, rc, err in results:
        status = "n/a" if rc is None else ("CAUGHT" if rc != 0 else "SURVIVED")
        print(f"[{status}] {name}")
        for e in err:
            print(f"      {e[:220]}")


