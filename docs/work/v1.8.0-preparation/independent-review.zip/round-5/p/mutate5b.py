"""Round-5 extra: a plain CLEARED finding on a HIT-level copy of the EXCLUDED tab template."""
import mutate3lib as m
import mutate5lib as m5
from mutate3lib import M, edit_plan, mut, set_allow, set_findings

M.clear()


@mut("R5-l plain CLEARED finding on tabwarp (HIT-level copy of the EXCLUDED tab template), no releases; IMPORT + allowlist IMPORT")
def r5l(r):
    set_findings(r, m5.EXCLUDED_TAB + [m5.owner_cleared("textures/gui/buttons/tabwarp.png")])
    edit_plan(r, "textures/gui/buttons/tabwarp.png", handling="IMPORT")
    set_allow(r, "textures/gui/buttons/tabwarp.png", "IMPORT")


m5.main()
