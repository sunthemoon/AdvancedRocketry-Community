import hashlib, sys
for p in sys.argv[2:]:
    data = open(sys.argv[1] + "/" + p, "rb").read()
    print(p, hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest())
