import json,sys
inv=json.load(open(sys.argv[1],encoding='utf-8'))
for u in inv['units']:
    if u['kind'] in ('material','asm_rule','config_file','packet_unregistered') or u['id'] in ('libvulpes:curated/coalGenerator',) or 'coal' in u['id'].lower(): print(u['id'], u.get('products',''), u.get('registered_by',''), u.get('source','').split('/')[-1], u.get('line'))
