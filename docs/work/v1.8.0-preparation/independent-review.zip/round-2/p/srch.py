import json, sys
for f in sys.argv[1:]:
    d = json.load(open(f, encoding="utf-8"))
    print(f, "total", d.get("total_count"), d.get("message", ""))
    for it in d.get("items", [])[:10]:
        print("  ", it["number"], it["state"], it.get("pull_request") is not None, it["created_at"][:10], repr(it["title"][:90]), it["html_url"])
