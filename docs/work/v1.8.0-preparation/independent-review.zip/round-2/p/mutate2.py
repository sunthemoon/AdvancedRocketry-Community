"""Round-2 mutations of copies of the v1.8 inputs through the revised validator."""
import csv
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

TREE = Path(sys.argv[1])
OUT = Path(sys.argv[2])
VALIDATOR = TREE / "scripts/validate_v180_content_ledger.py"
COPY = ["legacy-manifest", "docs/decisions", "docs/versions", "docs/provenance", "src/generated",
        "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry"]
FILES = ["docs/work/v1.8.0-legacy-inventory.json", "docs/work/v1.8.0-content-ledger.csv",
         "docs/work/v1.8.0-asset-plan.csv", "docs/work/v1.8.0-asset-import-allowlist.txt",
         "docs/work/v1.8.0-vanilla-derivation.json", "docs/work/v1.8.0-content-audit.md"]
INV, LEDGER, PLAN, ALLOW, DERIV = FILES[0], FILES[1], FILES[2], FILES[3], FILES[4]
ADR062 = "docs/decisions/ADR-062-CLASSIC-CONTENT-DISPOSITIONS-AND-BATCHES.md"
EVID = "docs/work/v1.8.0-content-audit.md"


def fresh(root):
    if root.exists():
        shutil.rmtree(root)
    for c in COPY:
        src = TREE / c
        if src.exists():
            shutil.copytree(src, root / c)
    if (TREE / "src/main/resources").exists():
        shutil.copytree(TREE / "src/main/resources", root / "src/main/resources")
    for f in FILES:
        (root / f).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(TREE / f, root / f)


def rows(root, rel):
    with (root / rel).open(encoding="utf-8", newline="") as h:
        return list(csv.DictReader(h))


def write(root, rel, rs):
    b = io.StringIO()
    w = csv.DictWriter(b, fieldnames=list(rs[0].keys()), lineterminator="\n")
    w.writeheader()
    w.writerows(rs)
    (root / rel).write_text(b.getvalue(), encoding="utf-8", newline="")


def edit_ledger(root, uid, **ch):
    rs = rows(root, LEDGER)
    hit = False
    for r in rs:
        if r["unit_id"] == uid:
            r.update(ch)
            hit = True
    assert hit, uid
    write(root, LEDGER, rs)


def edit_plan(root, pattern, **ch):
    rs = rows(root, PLAN)
    hit = False
    for r in rs:
        if r["pattern"] == pattern:
            r.update(ch)
            hit = True
    assert hit, pattern
    write(root, PLAN, rs)


def set_allow(root, asset, ceiling, repin=True):
    p = root / ALLOW
    lines = [l for l in p.read_text(encoding="utf-8").splitlines() if l.split("\t")[0] != asset]
    lines.append(f"{asset}\t{ceiling}")
    lines.sort()
    data = ("\n".join(lines) + "\n").encode("utf-8")
    p.write_bytes(data)
    if repin:
        a = root / ADR062
        t = a.read_text(encoding="utf-8")
        t = re.sub(r"^import_allowlist_sha256:.*$", "import_allowlist_sha256: " + hashlib.sha256(data).hexdigest(),
                   t, flags=re.M)
        a.write_text(t, encoding="utf-8")


def set_verdict(root, asset, verdict):
    p = root / DERIV
    d = json.loads(p.read_text(encoding="utf-8"))
    for e in d["assets"]:
        if e["asset"] == asset:
            e["verdict"] = verdict
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def set_findings(root, findings):
    p = root / "docs/provenance/v1.8.0-origin-findings.json"
    p.write_text(json.dumps({"schema_version": 1, "findings": findings}), encoding="utf-8")


def run(root, *extra):
    p = subprocess.run([sys.executable, str(VALIDATOR), "--root", str(root), *extra],
                       capture_output=True, text=True, timeout=600)
    return p.returncode, p.stderr.strip().splitlines()


M = []


def mut(name):
    def deco(fn):
        M.append((name, fn))
        return fn
    return deco


@mut("R1-1 IMPLEMENTED lathe -> tag literal machine_casings")
def m01(r):
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casings", decision="ADR-062", evidence=EVID)


@mut("R1-2 IMPLEMENTED lathe -> unrelated registered block machine_casing, evidence = the audit file")
def m02(r):
    edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:machine_casing", decision="ADR-062", evidence=EVID)


@mut("R1-3 PLANNED centrifuge -> REDESIGNED v1.8.0 free text, no evidence")
def m03(r):
    edit_ledger(r, "block:centrifuge", disposition="REDESIGNED", plan="v1.8.0", target="something later",
                decision="ADR-016 ADR-062")


@mut("R2-3b PLANNED centrifuge -> REDESIGNED v1.8.0 free text, evidence = any v1.8 work file")
def m04(r):
    edit_ledger(r, "block:centrifuge", disposition="REDESIGNED", plan="v1.8.0", target="something later",
                decision="ADR-016 ADR-062", evidence=EVID)


@mut("R1-4 REJECTED lathe citing only ADR-016")
def m05(r):
    edit_ledger(r, "block:lathe", disposition="REJECTED", plan="-", target="-", decision="ADR-016")


@mut("R2-4b REJECTED lathe citing ADR-062 although ADR-062 section 4 never mentions it")
def m06(r):
    edit_ledger(r, "block:lathe", disposition="REJECTED", plan="-", target="-", decision="ADR-062")


@mut("R1-6 EXCLUDE font.png -> IMPORT (no allowlist entry)")
def m07(r):
    edit_plan(r, "textures/font.png", handling="IMPORT", plan="C18d")


@mut("R1-7 REVIEW *leo.jpg -> IMPORT")
def m08(r):
    edit_plan(r, "textures/planets/*leo.jpg", handling="IMPORT", plan="C18d")


@mut("R1-10 IMPORT rule for the rejected transceiver")
def m09(r):
    edit_plan(r, "textures/blocks/wirelesstransciever_*", handling="IMPORT", plan="C16a")


@mut("R2-a HIT earth_phases: flip committed verdict to CLEAR, IMPORT it, add to allowlist, re-pin the digest")
def m10(r):
    set_verdict(r, "textures/env/earth_phases.png", "CLEAR")
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d", units="-")
    set_allow(r, "textures/env/earth_phases.png", "IMPORT")


@mut("R2-b SUSPECT space_boots: flip committed verdict to CLEAR and IMPORT (allowlist ceiling REVIEW)")
def m11(r):
    set_verdict(r, "textures/items/space_boots.png", "CLEAR")
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R2-c SUSPECT space_boots: flip verdict, raise allowlist to IMPORT and re-pin digest")
def m12(r):
    set_verdict(r, "textures/items/space_boots.png", "CLEAR")
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")
    set_allow(r, "textures/items/space_boots.png", "IMPORT")


@mut("R2-d raise an allowlist ceiling without re-pinning the digest")
def m13(r):
    set_allow(r, "textures/items/space_boots.png", "IMPORT", repin=False)


@mut("R2-e CLEARED origin finding for a HIT asset (earth_phases) and IMPORT")
def m14(r):
    set_findings(r, [{"asset": "textures/env/earth_phases.png", "decision": "CLEARED", "reviewer": "x",
                      "reviewed_at": "2026-10-02", "basis": "y"}])
    edit_plan(r, "textures/env/earth_phases.png", handling="IMPORT", plan="C18d")


@mut("R2-f CLEARED origin finding for SUSPECT space_boots by any reviewer string, then IMPORT")
def m15(r):
    set_findings(r, [{"asset": "textures/items/space_boots.png", "decision": "CLEARED", "reviewer": "anyone",
                      "reviewed_at": "2026-10-02", "basis": "looks fine"}])
    edit_plan(r, "textures/items/space_boots.png", handling="IMPORT")


@mut("R2-g model texture moved to a later batch than its model (cuttingmachine2 C16b -> C18d)")
def m16(r):
    edit_plan(r, "textures/models/cuttingmachine2.png", plan="C18d")


@mut("R2-h IMPORT rule owner unit replaced by an unrelated PLANNED unit")
def m17(r):
    edit_plan(r, "textures/blocks/plank_blue.png", units="block:lathe")


@mut("R2-i IMPLEMENTED fluid:oxygen with an item ID (oxygen_canister)")
def m18(r):
    edit_ledger(r, "fluid:oxygen", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:oxygen_canister", decision="ADR-062", evidence=EVID)


@mut("R2-j IMPLEMENTED sound_event:lathe with the existing ui_select sound")
def m19(r):
    edit_ledger(r, "sound_event:lathe", disposition="IMPLEMENTED", plan="v1.8.0",
                target="advancedrocketrycommunity:ui_select", decision="ADR-062", evidence=EVID)


@mut("R2-k derivation JSON: drop the vanilla jar hashes and thresholds")
def m20(r):
    p = r / DERIV
    d = json.loads(p.read_text(encoding="utf-8"))
    d["vanilla"] = {}
    d["thresholds"] = {}
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


@mut("R2-l evidence on a PLANNED row")
def m21(r):
    edit_ledger(r, "block:lathe", evidence=EVID)


@mut("R2-m PLANNED asm_rule GravityHandler moved wholesale to REJECTED citing ADR-062")
def m22(r):
    edit_ledger(r, "asm_rule:GravityHandler.applyGravity", disposition="REJECTED", plan="-", target="-",
                decision="ADR-062")


def main():
    results = []
    base = OUT / "mut"
    fresh(base)
    rc, err = run(base)
    results.append(("baseline", rc, err[:3]))
    for name, fn in M:
        fresh(base)
        try:
            fn(base)
        except AssertionError as ex:
            results.append((name + f" [setup failed: {ex}]", None, []))
            continue
        rc, err = run(base)
        results.append((name, rc, err[:3]))
    fresh(base)
    rc, err = run(base, "--closure")
    results.append(("closure on the committed tree", rc, err[:3]))
    shutil.rmtree(base)
    for name, rc, err in results:
        status = "n/a" if rc is None else ("CAUGHT" if rc != 0 else "SURVIVED")
        print(f"[{status}] {name}")
        for e in err:
            print(f"      {e[:220]}")


main()
