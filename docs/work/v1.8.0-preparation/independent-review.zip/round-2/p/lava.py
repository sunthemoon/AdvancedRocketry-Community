import sys, zipfile
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
root = sys.argv[2]; jars = sys.argv[3:]
def frames(img):
    w = img.width
    return [vd.Image(w, w, img.pixels[i*w*w:(i+1)*w*w]) for i in range(img.height // w)]
for leg in ("textures/blocks/fluid/lava_still.png", "textures/blocks/fluid/lava_flow.png"):
    c = vd.Image(*vd.decode_png(open(root + "/" + leg, "rb").read()))
    cf = frames(c)
    best = None
    for jar in jars:
        z = zipfile.ZipFile(jar)
        for n in z.namelist():
            if n.endswith(("lava_still.png", "lava_flow.png")) and "textures" in n:
                v = vd.Image(*vd.decode_png(z.read(n)))
                if v.width != c.width: continue
                for i, a in enumerate(cf[:8]):
                    for j, b in enumerate(frames(v)):
                        both = [(x, y) for x, y, o1, o2 in zip(a.luminance, b.luminance, a.opaque, b.opaque) if o1 and o2]
                        rk = vd._pearson(vd._ranks([p[0] for p in both]), vd._ranks([p[1] for p in both]))
                        eq = sum(1 for p, q in zip(a.pixels, b.pixels) if p == q) / len(a.pixels)
                        if best is None or rk > best[0]: best = (rk, eq, n, i, j)
    print(leg, c.width, "x", c.height, "frames", len(cf), "best frame match: rank=%.3f exact=%.3f" % best[:2], best[2:], "committed:", end=" ")
    print([e for e in __import__("json").load(open(sys.argv[1] + "/docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))["assets"] if e["asset"] == leg[len(""):].replace("textures/", "textures/", 1)][0].get("verdict"))
