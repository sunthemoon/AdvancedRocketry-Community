"""Frame-level comparison: legacy frames vs vanilla frames for animated strips (sizes the tool never pairs)."""
import sys, zipfile, csv, fnmatch
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
tree = Path(sys.argv[1]); up = Path(sys.argv[2]); jars = {"1.12.2": sys.argv[3], "1.20.1": sys.argv[4]}
def first_frame(img):
    w = img.width
    return vd.Image(w, w, img.pixels[:w * w])
van = {}
for label, jar in jars.items():
    z = zipfile.ZipFile(jar)
    for n in z.namelist():
        if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
            w, h, px = vd.decode_png(z.read(n))
            img = vd.Image(w, h, px)
            if h > w and h % w == 0:
                van.setdefault(w, []).append((label, n, first_frame(img), True))
            elif h == w:
                van.setdefault(w, []).append((label, n, img, False))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def rule(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r
root = up / "src/main/resources/assets/advancedrocketry"
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\", "/"); r = rule(a)
    if r["handling"] not in ("IMPORT", "REVIEW"): continue
    w, h, px = vd.decode_png(f.read_bytes()); img = vd.Image(w, h, px)
    strip = h > w and h % w == 0
    if not (strip or h == w): continue
    cand = first_frame(img) if strip else img
    for label, n, v, vstrip in van.get(w, []):
        if not strip and not vstrip: continue  # same-size squares are already compared by the tool
        xs = [l for l, o in zip(cand.luminance, cand.opaque) if o]
        both = [(la, lb) for la, lb, oa, ob in zip(cand.luminance, v.luminance, cand.opaque, v.opaque) if oa and ob]
        if len(both) < 32: continue
        rk = vd._pearson(vd._ranks([p[0] for p in both]), vd._ranks([p[1] for p in both]))
        m = vd.compare(cand, v)
        if rk >= 0.75 or m["overlap"] >= 0.10:
            print(f"{r['handling']}#{r['order']:>4s} {a:45s} frame0 ~ {label}:{n} {'(strip)' if vstrip else ''} rank_ungated={rk:.3f} tool={ {k: round(x,3) for k,x in m.items()} }")
