import json, sys
for f in sys.argv[1:]:
    d = json.load(open(f, encoding="utf-8"))
    print(f, d.get("number"), d.get("user", {}).get("login"), d.get("merged_at"), repr((d.get("title") or "")[:100]))
    print("   body:", repr((d.get("body") or "")[:900]))
