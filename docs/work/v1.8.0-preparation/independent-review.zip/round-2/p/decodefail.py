import sys, zipfile, zlib, struct
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
for label, jar in (("1.12.2", sys.argv[2]), ("1.20.1", sys.argv[3])):
    z = zipfile.ZipFile(jar); tot = fail = 0; reasons = {}
    for n in z.namelist():
        if n.startswith("assets/minecraft/") and n.endswith(".png"):
            tot += 1
            try: vd.decode_png(z.read(n))
            except (vd.DecodeError, zlib.error, struct.error, IndexError) as e:
                fail += 1; reasons.setdefault(str(e)[:40], []).append(n)
    print(label, "png", tot, "undecodable (silently skipped)", fail)
    for r, ns in reasons.items(): print("   ", r, len(ns), ns[:4])
