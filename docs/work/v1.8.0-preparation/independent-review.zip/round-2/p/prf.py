import json, sys, glob, csv, fnmatch
tree = sys.argv[1]
rules = list(csv.DictReader(open(tree + "/docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def rule(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"] + "#" + r["order"]
root = "src/main/resources/assets/advancedrocketry/"
for n in ("1809", "1811", "1889"):
    files = []
    for f in sorted(glob.glob(f"f{n}_*.json")):
        d = json.load(open(f, encoding="utf-8"))
        if isinstance(d, list): files += [x["filename"] for x in d if x["status"] != "removed"]
    assets = [x[len(root):] for x in files if x.startswith(root) and x.endswith(".png")]
    hs = {}
    for a in assets:
        h = rule(a) or "none"
        hs.setdefault(h.split("#")[0], []).append(a)
    print(n, "png files", len(assets), {k: len(v) for k, v in hs.items()})
    print("   IMPORT:", " ".join(sorted(hs.get("IMPORT", [])))[:1500])
