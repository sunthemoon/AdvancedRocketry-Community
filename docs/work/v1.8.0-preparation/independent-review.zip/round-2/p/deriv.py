import json, sys, csv, fnmatch
d = json.load(open(sys.argv[1], encoding="utf-8"))
print("counts", d["counts"], "vanilla", d["vanilla"])
rules = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"]+"#"+r["order"]
for e in d["assets"]:
    if e["verdict"] in ("HIT", "SUSPECT", "UNSUPPORTED"):
        b = e.get("best", {})
        print(f'{e["verdict"]:11s} {handling(e["asset"]):14s} {e["asset"]:55s} {b.get("vanilla","")[:70]:70s} s={b.get("scale","")} ov={b.get("overlap","")} iou={b.get("iou","")} rk={b.get("rank","")} {",".join(e.get("hash_match",[]))[:60]}')
