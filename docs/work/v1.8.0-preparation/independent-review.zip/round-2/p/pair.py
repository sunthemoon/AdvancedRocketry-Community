import sys, zipfile, math
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
root = sys.argv[2]; z = zipfile.ZipFile(sys.argv[3])
for spec in sys.argv[4:]:
    a, v = spec.split("=")
    c = vd.Image(*vd.decode_png(open(root + "/" + a, "rb").read()))
    van = vd.Image(*vd.decode_png(z.read(v)))
    if (c.width, c.height) != (van.width, van.height):
        # compare first frame for strips
        fw = min(c.width, van.width); fh = fw
        c = vd.Image(fw, fh, c.pixels[:fw*fh]); van = vd.Image(fw, fh, van.pixels[:fw*fh])
    xs = [l for l, o in zip(c.luminance, c.opaque) if o]; ys = [l for l, o in zip(van.luminance, van.opaque) if o]
    pear = vd._pearson(xs, ys) if len(xs) == len(ys) else float('nan')
    print(f"{a} vs {v}: size={c.width}x{c.height} cand_levels={c.levels} van_levels={van.levels} tool={vd.compare(c, van)} pearson_lum={pear:.4f} spearman={vd._pearson(vd._ranks(xs), vd._ranks(ys)):.4f}")
