"""Search for legacy textures that are crops (sub-images) of larger vanilla images, and for rotated/mirrored copies."""
import sys, zipfile, csv, fnmatch
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
tree = Path(sys.argv[1]); up = Path(sys.argv[2]); jars = {"1.12.2": sys.argv[3], "1.20.1": sys.argv[4]}
van = []
for label, jar in jars.items():
    z = zipfile.ZipFile(jar)
    for n in z.namelist():
        if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
            try: w, h, px = vd.decode_png(z.read(n))
            except Exception: continue
            if w * h > 512 * 512: continue
            rows = [b"".join(bytes(p) for p in px[y*w:(y+1)*w]) for y in range(h)]
            van.append((label, n, w, h, px, rows))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def rule(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r
root = up / "src/main/resources/assets/advancedrocketry"
def transforms(w, h, px):
    get = lambda x, y: px[y*w + x]
    yield "id", w, h, px
    yield "flipx", w, h, [get(w-1-x, y) for y in range(h) for x in range(w)]
    yield "flipy", w, h, [get(x, h-1-y) for y in range(h) for x in range(w)]
    yield "rot180", w, h, [get(w-1-x, h-1-y) for y in range(h) for x in range(w)]
    if w == h:
        yield "rot90", w, h, [get(y, w-1-x) for x in range(w) for y in range(h)][:0] or [get(x2, y2) for y2, x2 in [(w-1-x, y) for y in range(h) for x in range(w)]]
        yield "transpose", w, h, [get(y, x) for y in range(h) for x in range(w)]
hits = []
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\", "/")
    r = rule(a)
    if r["handling"] not in ("IMPORT", "REVIEW"): continue
    try: w, h, px = vd.decode_png(f.read_bytes())
    except Exception: continue
    if w > 64 or h > 64: continue
    for tname, tw, th, tpx in transforms(w, h, px):
        opaque = [i for i, p in enumerate(tpx) if p[3] > 0]
        if len(opaque) < 24: break
        # most distinctive fully-opaque row
        best_row, best_score = None, -1
        for y in range(th):
            row = tpx[y*tw:(y+1)*tw]
            if all(p[3] == 255 for p in row):
                s = len(set(row))
                if s > best_score: best_row, best_score = y, s
        if best_row is None or best_score < 3: continue
        needle = b"".join(bytes(p) for p in tpx[best_row*tw:(best_row+1)*tw])
        for label, n, vw, vh, vpx, rows in van:
            if (vw, vh) == (tw, th) and tname == "id": continue  # same-size identity handled by the tool
            if vw < tw or vh < th: continue
            for y, rb in enumerate(rows):
                start = rb.find(needle)
                while start != -1:
                    if start % 4 == 0:
                        x0 = start // 4; y0 = y - best_row
                        if 0 <= y0 and y0 + th <= vh and x0 + tw <= vw:
                            eq = sum(1 for i in opaque if tpx[i] == vpx[(y0 + i // tw) * vw + x0 + i % tw])
                            if eq / len(opaque) >= 0.6:
                                hits.append((eq / len(opaque), r["handling"] + "#" + r["order"], a, tname, f"{label}:{n}", x0, y0))
                    start = rb.find(needle, start + 1)
seen = set()
for frac, hd, a, tname, n, x0, y0 in sorted(hits, reverse=True):
    if (a, n) in seen: continue
    seen.add((a, n))
    print(f"{frac:.2f} {hd:12s} {a:50s} [{tname}] in {n} at ({x0},{y0})")
print("matches:", len(seen))
