"""Re-score IMPORT/REVIEW legacy PNGs with the tool's own measures but without the luminance-level gates."""
import sys, zipfile, csv, fnmatch, json
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
tree = Path(sys.argv[1]); up = Path(sys.argv[2]); jars = {"1.12.2": sys.argv[3], "1.20.1": sys.argv[4]}
images = {}
for label, jar in jars.items():
    z = zipfile.ZipFile(jar)
    for n in z.namelist():
        if n.startswith("assets/minecraft/") and n.endswith(".png"):
            try: w, h, px = vd.decode_png(z.read(n))
            except Exception: continue
            images.setdefault((w, h), []).append((label, n, vd.Image(w, h, px)))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def rule(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r
committed = {e["asset"]: e for e in json.load(open(tree/"docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))["assets"]}
def compare_ungated(c, v):
    union = equal = both = informative = 0; sa = []; sb = []
    for pa, pb, oa, ob, la, lb in zip(c.pixels, v.pixels, c.opaque, v.opaque, c.luminance, v.luminance):
        if oa or ob:
            union += 1
            if pb != v.dominant:
                informative += 1
                if pa == pb: equal += 1
            if oa and ob:
                both += 1; sa.append(la); sb.append(lb)
    if union == 0: return None
    overlap = equal / informative if informative else 0.0
    rank = vd._pearson(vd._ranks(sa), vd._ranks(sb)) if both >= vd.MIN_SHARED_PIXELS else 0.0
    return {"overlap": overlap, "iou": both / union, "rank": rank}
root = up / "src/main/resources/assets/advancedrocketry"
out = []
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\", "/")
    r = rule(a)
    if r["handling"] not in ("IMPORT", "REVIEW"): continue
    try: w, h, px = vd.decode_png(f.read_bytes())
    except Exception: continue
    cand = vd.Image(w, h, px); best = None
    for factor in vd.SCALES:
        if factor > 1 and (w % factor or h % factor): pass
        targets = []
        if factor == 1: targets.append((cand, (w, h), False))
        elif not (w % factor or h % factor): targets.append((cand.downscaled(factor), (w // factor, h // factor), False))
        for c, size, _ in targets:
            for label, n, v in images.get(size, []):
                m = compare_ungated(c, v)
                if m is None: continue
                lv = vd.verdict(m); key = (vd.SEVERITY[lv], m["overlap"], m["rank"])
                if best is None or key > best[0]: best = (key, lv, f"{label}:{n}", factor, m)
        if factor > 1:
            for label, n, v in images.get((w * factor, h * factor), []):
                m = compare_ungated(cand, v.downscaled(factor))
                if m is None: continue
                lv = vd.verdict(m); key = (vd.SEVERITY[lv], m["overlap"], m["rank"])
                if best is None or key > best[0]: best = (key, lv, f"{label}:{n}", -factor, m)
    if best:
        _, lv, name, factor, m = best
        old = committed[a]["verdict"]
        if vd.SEVERITY[lv] > vd.SEVERITY.get(old, 0):
            out.append((lv, old, r["handling"] + "#" + r["order"], a, name, factor, m))
for lv, old, hd, a, name, factor, m in sorted(out):
    print(f"{lv:8s} (committed {old:8s}) {hd:12s} {a:50s} ~ {name} s={factor} ov={m['overlap']:.3f} iou={m['iou']:.3f} rk={m['rank']:.3f}")
print("upgraded verdicts:", len(out))
