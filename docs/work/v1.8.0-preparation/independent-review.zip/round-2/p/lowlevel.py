"""How many vanilla PNGs fall below the tool's luminance-level gates, and does a pixel-exact copy of one score CLEAR?"""
import sys, zipfile
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
jars = {"1.12.2": sys.argv[2], "1.20.1": sys.argv[3]}
total = low = 0
examples = []
for label, jar in jars.items():
    z = zipfile.ZipFile(jar)
    for n in z.namelist():
        if not (n.startswith("assets/minecraft/textures/") and n.endswith(".png")): continue
        try: w, h, px = vd.decode_png(z.read(n))
        except Exception: continue
        img = vd.Image(w, h, px)
        total += 1
        if img.levels < vd.MIN_LUMINANCE_LEVELS:
            low += 1
            if sum(img.opaque) >= 32 and len(examples) < 4000:
                examples.append((label, n, img))
print("vanilla PNGs decoded", total, "below 8 luminance levels", low)
# Self-comparison: a pixel-identical copy (different file bytes) of each low-level vanilla image vs itself
clear = suspect = hit = 0
names = []
for label, n, img in examples:
    m = vd.compare(img, img)
    v = vd.verdict(m)
    if v == "CLEAR":
        clear += 1
        if len(names) < 25: names.append(f"{label}:{n} {img.width}x{img.height} levels={img.levels} opaque={sum(img.opaque)} {m}")
    elif v == "SUSPECT": suspect += 1
    else: hit += 1
print("pixel-identical copies of low-level vanilla images (>=32 opaque px):", len(examples), "-> CLEAR", clear, "SUSPECT", suspect, "HIT", hit)
for s in names: print("  ", s)
