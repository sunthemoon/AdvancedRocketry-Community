"""Unit IDs that the validator's whole-token rule still finds inside another unit ID."""
import csv
import sys

sys.path.insert(0, sys.argv[1])
sys.path.insert(0, sys.argv[1] + "/scripts")
import validate_v180_content_ledger as v  # noqa: E402

ids = [r["unit_id"] for r in csv.DictReader(open(sys.argv[1] + "/docs/work/v1.8.0-content-ledger.csv", encoding="utf-8"))]
pairs = []
for a in ids:
    pattern = v._token(a)
    for b in ids:
        if a != b and pattern.search(b):
            pairs.append((a, b))
print(len(ids), "unit ids;", len(pairs), "pairs where one id's token is found inside another id")
for a, b in pairs[:40]:
    print(f"  {a!r} found in {b!r}")
