"""CLEAR assets whose recorded best whole-image match has iou >= 0.85 and rank in [0.60, 0.75)."""
import csv
import fnmatch
import json
import sys

d = json.load(open(sys.argv[1], encoding="utf-8"))
rules = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))


def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]):
            return r["handling"] + "#" + r["order"]


for a in d["assets"]:
    b = a.get("best", {})
    if a["verdict"] == "CLEAR" and b.get("iou", 0) >= 0.85 and 0.60 <= b.get("rank", 0) < 0.75:
        print(f'{b["rank"]:.3f} {handling(a["asset"]):12s} {a["asset"]:52s} {b.get("method")} {b.get("reference")}'
              f' o={b.get("orientation")} ov={b.get("overlap")} c={b.get("colours")}')
