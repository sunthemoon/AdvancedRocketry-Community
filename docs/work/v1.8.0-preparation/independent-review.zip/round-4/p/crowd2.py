"""Does pooling legacy references with vanilla ones crowd a vanilla sprite out of a large legacy sheet?
Embeds vanilla 1.12.2 block textures into real legacy model textures and scores them against vanilla only
and against vanilla plus all legacy references (as the committed run does)."""
import csv
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

tree, up, jar112, jar120 = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], sys.argv[4]
_, _, vanilla = vd.load_vanilla([f"1.12.2={jar112}", f"1.20.1={jar120}"])
legacy = []
for row in csv.DictReader(open(tree / "legacy-manifest/assets.csv", encoding="utf-8")):
    rel = row["source_path"][len(vd.ASSET_ROOT):]
    if rel.endswith(".png"):
        try:
            legacy.append((rel, vd.Image(*vd.decode_rgba((up / row["source_path"]).read_bytes()))))
        except Exception:
            pass
by = dict(legacy)
z = zipfile.ZipFile(jar112)


def sprite(name):
    w, h, rgba = vd.decode_rgba(z.read("assets/minecraft/textures/blocks/" + name))
    return w, min(h, w), rgba[:4 * w * min(h, w)]


def embed(sheet, name, x0, y0):
    w, h, rgba = sprite(name)
    out = bytearray(sheet.rgba)
    for y in range(h):
        i = 4 * ((y0 + y) * sheet.width + x0)
        out[i:i + 4 * w] = rgba[4 * y * w:4 * (y + 1) * w]
    return vd.Image(sheet.width, sheet.height, bytes(out))


cases = []
for sheet_name, positions in (("textures/models/areagravitycontroller.png", [(5, 3), (61, 37)]),
                              ("textures/models/warpcore.png", [(1, 2), (33, 18)]),
                              ("textures/models/railgun.png", [(7, 9)])):
    sheet = by.get(sheet_name)
    if sheet is None:
        continue
    for tex in ("piston_side.png", "furnace_front_off.png", "iron_block.png"):
        for x0, y0 in positions:
            if x0 + 16 <= sheet.width and y0 + 16 <= sheet.height:
                cases.append((f"{sheet_name.split('/')[-1]} {sheet.width}x{sheet.height} + {tex} at ({x0},{y0})",
                              embed(sheet, tex, x0, y0)))
only = vd.analyse_images(cases, vanilla)
pooled = vd.match_images(cases, vanilla + [(vd.LEGACY, n, i) for n, i in legacy]).best
for name, _ in cases:
    a = only.get(name, (None, "CLEAR", {}))
    b = pooled.get(name, (None, "CLEAR", {}))
    print(f"vanilla-only {a[1]:8s} pooled {b[1]:8s} {name}  [{b[2].get('reference', '')}]", flush=True)
