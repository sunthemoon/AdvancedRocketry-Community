"""Round-4 sibling probe (ADR-061 section 4.8 inheritance), independent of the recorded `related` lists.

1. From the committed results: assets whose related list is at the cap, and relations recorded in one
   direction only.
2. Fresh run: every IMPORT PNG scored by the tool against the flagged legacy PNGs (verdict HIT/SUSPECT/
   UNSUPPORTED, handling REVIEW, an EXCLUDED finding, or EXCLUDE handling), in both directions, without the
   cap. Flags each IMPORT file that reaches SUSPECT or HIT against a flagged file."""
import csv
import fnmatch
import json
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

tree, root = Path(sys.argv[1]), Path(sys.argv[2])
d = json.load(open(tree / "docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))
rules = list(csv.DictReader(open(tree / "docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
findings = {f["asset"]: f["decision"] for f in json.load(open(tree / "docs/provenance/v1.8.0-origin-findings.json",
                                                                encoding="utf-8"))["findings"]}


def rule(asset):
    for r in rules:
        if fnmatch.fnmatchcase(asset, r["pattern"]):
            return r


verdict = {e["asset"]: e["verdict"] for e in d["assets"]}
related = {e["asset"]: {r["asset"]: r["level"] for r in e.get("related", [])} for e in d["assets"]}
handling = {a: rule(a)["handling"] for a in verdict}
cap = d["thresholds"]["max_related"]
print("assets at the related cap:", sorted(a for a, r in related.items() if len(r) >= cap))
one_way = sorted((a, b) for a, r in related.items() for b in r if a not in related.get(b, {}))
print("one-way relations:", len(one_way), "of", sum(len(r) for r in related.values()))


def flag(asset):
    if findings.get(asset) == "CLEARED":
        return None
    if verdict.get(asset) in ("HIT", "SUSPECT", "UNSUPPORTED"):
        return "verdict " + verdict[asset]
    if handling.get(asset) == "REVIEW":
        return "REVIEW"
    if findings.get(asset) == "EXCLUDED":
        return "EXCLUDED finding"
    if handling.get(asset) == "EXCLUDE":
        return "EXCLUDE handling (" + rule(asset)["reason"][:60] + ")"
    return None


imports = [a for a in verdict if handling[a] == "IMPORT" and a.endswith(".png")]
for a in imports:
    for b, level in related[a].items():
        if flag(b):
            print("RECORDED", a, "->", b, level, flag(b))
    for b, r in related.items():
        if a in r and b not in related[a] and flag(b):
            print("ONE-WAY ", a, "<-", b, r[a], flag(b))


def load(asset):
    return vd.Image(*vd.decode_rgba((root / asset).read_bytes()))


flagged = [b for b in verdict if b.endswith(".png") and flag(b) and verdict[b] != "UNSUPPORTED"]
print("IMPORT pngs", len(imports), "flagged pngs", len(flagged))
print("IMPORT pngs", len(imports), "flagged pngs", len(flagged), flush=True)
images = {}
for a in set(imports) | set(flagged):
    images[a] = load(a)
LEG = vd.LEGACY
# forward: IMPORT files as candidates, flagged files as (legacy-labelled) references: every SUSPECT+ relation, no cap
fwd = vd.match_images([(a, images[a]) for a in imports], [(LEG, b, images[b]) for b in flagged]).related
print("forward done", flush=True)
bwd = vd.match_images([(b, images[b]) for b in flagged], [(LEG, a, images[a]) for a in imports]).related
print("backward done", flush=True)
for a in sorted(imports):
    hits = {}
    for b, (_, level, record) in fwd.get(a, {}).items():
        hits.setdefault(b, []).append(("fwd", level))
    for b, table in bwd.items():
        if a in table:
            hits.setdefault(b, []).append(("bwd", table[a][1]))
    for b, how in sorted(hits.items()):
        recorded = related[a].get(b)
        print(f"IMPORT#{rule(a)['order']:>4s} {a:48s} ~ {b:48s} {how} recorded={recorded} flag={flag(b)}", flush=True)
