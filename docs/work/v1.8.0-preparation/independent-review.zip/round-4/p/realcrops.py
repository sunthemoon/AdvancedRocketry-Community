"""Exact and lightly edited crops of real vanilla GUI elements, scored by the schema-3 tool against
all vanilla images of both clients (the same reference set and posting caps as the real run)."""
import sys
import zipfile

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

jar112, jar120, legacy_root = sys.argv[2], sys.argv[3], sys.argv[4]
_, _, vanilla = vd.load_vanilla([f"1.12.2={jar112}", f"1.20.1={jar120}"])
z = zipfile.ZipFile(jar112)


def crop(name, x0, y0, w, h):
    width, height, rgba = vd.decode_rgba(z.read(name))
    rows = [rgba[(y0 + y) * 4 * width + 4 * x0:(y0 + y) * 4 * width + 4 * (x0 + w)] for y in range(h)]
    return vd.Image(w, h, b"".join(rows))


def edited(image, x, y, colour=(1, 2, 3, 255)):
    rgba = bytearray(image.rgba)
    i = 4 * (y * image.width + x)
    rgba[i:i + 4] = bytes(colour)
    return vd.Image(image.width, image.height, bytes(rgba))


def recolour_fill(image, old, new):
    cells = image.cells()
    return vd.Image(image.width, image.height, b"".join(bytes(new) if c == bytes(old) else c for c in cells))


tab = crop("assets/minecraft/textures/gui/container/creative_inventory/tabs.png", 0, 0, 28, 32)
slot = crop("assets/minecraft/textures/gui/container/generic_54.png", 7, 17, 18, 18)
button = crop("assets/minecraft/textures/gui/widgets.png", 0, 66, 64, 20)
arrow = crop("assets/minecraft/textures/gui/container/furnace.png", 176, 14, 24, 17)
flame = crop("assets/minecraft/textures/gui/container/furnace.png", 176, 0, 14, 14)
fill = tab.cells()[16 * 28 + 14]
cases = {
    "exact creative tab crop (1.12.2 tabs.png 0,0 28x32)": tab,
    "creative tab crop, one pixel recoloured": edited(tab, 14, 2),
    "creative tab crop, fill recoloured yellow": recolour_fill(tab, tuple(fill), (223, 223, 45, 255)),
    "exact inventory slot crop (generic_54 7,17 18x18)": slot,
    "exact button crop (widgets 0,66 64x20)": button,
    "exact furnace progress arrow (furnace 176,14 24x17)": arrow,
    "exact furnace flame (furnace 176,0 14x14)": flame,
}
legacy = {}
for rel in ("textures/gui/buttons/tabtemplate.png", "textures/gui/buttons/buttonautoeject_hover.png"):
    legacy["legacy " + rel] = vd.Image(*vd.decode_rgba(open(legacy_root + "/" + rel, "rb").read()))
cases.update(legacy)
best = vd.analyse_images(list(cases.items()), vanilla)
for name in cases:
    level, record = best.get(name, (None, "CLEAR", {}))[1:]
    keys = ("method", "reference", "exact", "near", "mapped", "classes", "colours", "overlap", "rank", "votes")
    print(f"{level:8s} {name:55s} {dict((k, record[k]) for k in keys if k in record)}")
