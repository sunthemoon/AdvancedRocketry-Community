"""Results file structure and the distribution of whole-image measures among CLEAR assets."""
import collections
import json
import sys

d = json.load(open(sys.argv[1], encoding="utf-8"))
print({k: v for k, v in d.items() if k != "assets"})
clear = [a for a in d["assets"] if a["verdict"] == "CLEAR"]
print(json.dumps(clear[0])[:1200])
buckets = collections.Counter()
for a in clear:
    b = a.get("best", {})
    if "rank" in b and b.get("iou", 0) >= 0.85:
        r = b["rank"]
        buckets["0.70-0.75" if r >= 0.70 else "0.60-0.70" if r >= 0.60 else "0.50-0.60" if r >= 0.5 else "<0.50"] += 1
print("CLEAR best records with iou>=0.85 by rank:", dict(buckets))
methods = collections.Counter(a.get("best", {}).get("method") for a in clear)
print("CLEAR best methods:", dict(methods))
