"""Share of tabtemplate's opaque pixels equal to 1.20.1 creative_inventory/tabs.png at given offsets,
and which colours the equal and differing pixels have."""
import sys
import zipfile
from collections import Counter

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

jar120, legacy = sys.argv[2], sys.argv[3]
tw, th, trgba = vd.decode_rgba(open(legacy, "rb").read())
vw, vh, vrgba = vd.decode_rgba(zipfile.ZipFile(jar120).read(
    "assets/minecraft/textures/gui/container/creative_inventory/tabs.png"))


def px(rgba, w, x, y):
    i = 4 * (y * w + x)
    return tuple(rgba[i:i + 4])


print("tabtemplate", tw, th, "colours", Counter(px(trgba, tw, x, y) for y in range(th) for x in range(tw)).most_common(8))
for ox, oy in ((1, 34), (157, 34), (0, 32), (28, 32)):
    equal = differ = 0
    eq_c, diff_c = Counter(), Counter()
    for y in range(th):
        for x in range(tw):
            a = px(trgba, tw, x, y)
            if a[3] == 0 or ox + x >= vw or oy + y >= vh:
                continue
            b = px(vrgba, vw, ox + x, oy + y)
            if a == b:
                equal += 1
                eq_c[a] += 1
            else:
                differ += 1
                diff_c[(a, b)] += 1
    total = equal + differ
    print(f"offset ({ox},{oy}): equal {equal}/{total} = {equal / max(1, total):.3f}; equal colours {eq_c.most_common(4)};"
          f" differing pairs {diff_c.most_common(4)}")
