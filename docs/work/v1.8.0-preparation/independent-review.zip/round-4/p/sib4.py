"""Round-4 sibling probe (ADR-061 section 4.8 inheritance), independent of the recorded `related` lists.

1. From the committed results: assets whose related list is at the cap, and relations recorded in one
   direction only.
2. Fresh run: every IMPORT PNG scored by the tool against the flagged legacy PNGs (verdict HIT/SUSPECT/
   UNSUPPORTED, handling REVIEW, an EXCLUDED finding, or EXCLUDE handling), in both directions, without the
   cap. Flags each IMPORT file that reaches SUSPECT or HIT against a flagged file."""
import csv
import fnmatch
import json
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

tree, root = Path(sys.argv[1]), Path(sys.argv[2])
d = json.load(open(tree / "docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))
rules = list(csv.DictReader(open(tree / "docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
findings = {f["asset"]: f["decision"] for f in json.load(open(tree / "docs/provenance/v1.8.0-origin-findings.json",
                                                                encoding="utf-8"))["findings"]}


def rule(asset):
    for r in rules:
        if fnmatch.fnmatchcase(asset, r["pattern"]):
            return r


verdict = {e["asset"]: e["verdict"] for e in d["assets"]}
related = {e["asset"]: {r["asset"]: r["level"] for r in e.get("related", [])} for e in d["assets"]}
handling = {a: rule(a)["handling"] for a in verdict}
cap = d["thresholds"]["max_related"]
print("assets at the related cap:", sorted(a for a, r in related.items() if len(r) >= cap))
one_way = sorted((a, b) for a, r in related.items() for b in r if a not in related.get(b, {}))
print("one-way relations:", len(one_way), "of", sum(len(r) for r in related.values()))


def flag(asset):
    if findings.get(asset) == "CLEARED":
        return None
    if verdict.get(asset) in ("HIT", "SUSPECT", "UNSUPPORTED"):
        return "verdict " + verdict[asset]
    if handling.get(asset) == "REVIEW":
        return "REVIEW"
    if findings.get(asset) == "EXCLUDED":
        return "EXCLUDED finding"
    if handling.get(asset) == "EXCLUDE":
        return "EXCLUDE handling (" + rule(asset)["reason"][:60] + ")"
    return None


imports = [a for a in verdict if handling[a] == "IMPORT" and a.endswith(".png")]
for a in imports:
    for b, level in related[a].items():
        if flag(b):
            print("RECORDED", a, "->", b, level, flag(b))
    for b, r in related.items():
        if a in r and b not in related[a] and flag(b):
            print("ONE-WAY ", a, "<-", b, r[a], flag(b))


def load(asset):
    return vd.Image(*vd.decode_rgba((root / asset).read_bytes()))


flagged = [b for b in verdict if b.endswith(".png") and flag(b) and verdict[b] != "UNSUPPORTED"]
print("IMPORT pngs", len(imports), "flagged pngs", len(flagged))
cands = [(a, load(a)) for a in imports]
refs = [("legacy-flagged", b, load(b)) for b in flagged]
forward = vd.analyse_images(cands, refs)
cands2 = [(b, load(b)) for b in flagged]
backward = {}
# match_images keeps only the best reference per candidate; re-run per IMPORT file for the reverse direction
for a, image in cands:
    best = vd.analyse_images(cands2, [("legacy-import", a, image)])
    for b, (_, level, record) in best.items():
        if level != "CLEAR":
            backward.setdefault(a, []).append((level, b, record))
keys = ("method", "reference", "exact", "near", "mapped", "classes", "colours", "overlap", "iou", "rank")
for a in imports:
    hit = forward.get(a)
    if hit and hit[1] != "CLEAR":
        rec = {k: hit[2][k] for k in keys if k in hit[2]}
        ref = rec.get("reference", "")
        print(f"FORWARD  {hit[1]:8s} IMPORT#{rule(a)['order']:>4s} {a:50s} ~ {ref} ({flag(ref.split(':', 1)[-1])}) {rec}")
    for level, b, record in backward.get(a, []):
        rec = {k: record[k] for k in keys if k in record and k != "reference"}
        print(f"BACKWARD {level:8s} IMPORT#{rule(a)['order']:>4s} {a:50s} inside {b} ({flag(b)}) {rec}")
