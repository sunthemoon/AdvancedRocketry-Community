"""Machine faces built on filtered vanilla casings: a 16x16 face whose part is a filtered vanilla texture."""
import random
import sys

sys.path.insert(0, sys.argv[0].rsplit("/", 1)[0] if "/" in sys.argv[0] else ".")
import realfilt as rf  # noqa: E402  (loads vanilla once; argv as for realfilt.py)

vd, rng = rf.vd, random.Random(9)
cases = {}
other = rf.load("stonebrick.png")[2]
for name in ("piston_side.png", "furnace_front_off.png", "iron_block.png", "dispenser_front_horizontal.png"):
    w, h, px = rf.load(name)
    stem = name[:-4]
    n6 = rf.noisy(px, 6)
    cases[f"{stem}: +-6 noise, 8x8 centre replaced"] = rf.image(w, h, rf.overlay(w, h, n6, 8, 3))
    top = [n6[i] if i < w * h // 2 else other[i] for i in range(w * h)]
    cases[f"{stem}: top half +-6 noise, bottom other art"] = rf.image(w, h, top)
    top_exact = [px[i] if i < w * h // 2 else other[i] for i in range(w * h)]
    cases[f"{stem}: top half exact, bottom other art"] = rf.image(w, h, top_exact)
    bl = rf.blur(w, h, px)
    cases[f"{stem}: blur, 6x6 centre replaced"] = rf.image(w, h, rf.overlay(w, h, bl, 6, 3))
best = vd.analyse_images(list(cases.items()), rf.vanilla)
keys = ("method", "reference", "exact", "near", "mapped", "classes", "colours", "overlap", "iou", "rank")
for name in cases:
    level, record = best.get(name, (None, "CLEAR", {}))[1:]
    rec = dict((k, record[k]) for k in keys if k in record)
    if "reference" in rec:
        rec["reference"] = rec["reference"].split("/")[-1]
    print(f"{level:8s} {name:55s} {rec}")
