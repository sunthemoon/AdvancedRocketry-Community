import json, sys, csv, fnmatch
d = json.load(open(sys.argv[1], encoding="utf-8"))
rules = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"] + "#" + r["order"]
print("counts", d["counts"], "schema", d["schema"])
for e in d["assets"]:
    a = e["asset"]
    if any(fnmatch.fnmatchcase(a, n) for n in sys.argv[3:]):
        b = e.get("best", {})
        rel = [(r["asset"].split("/")[-1], r["level"]) for r in e.get("related", [])]
        print(f'{e["verdict"]:8s} {handling(a):14s} {a:48s} best={b.get("method","")}:{b.get("reference","")[:55]} ex={b.get("exact","")} ov={b.get("overlap","")} c={b.get("colours","")} | related={rel}')
