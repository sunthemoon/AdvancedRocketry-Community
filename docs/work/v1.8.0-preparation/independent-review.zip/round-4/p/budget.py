"""Why the model texture's own list misses warpcore.png: the pair alone vs the full reference set,
with the tool's caps as committed and with the posting cap and offset budgets lifted."""
import csv
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

tree, up, jar112, jar120 = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], sys.argv[4]
_, _, vanilla = vd.load_vanilla([f"1.12.2={jar112}", f"1.20.1={jar120}"])
legacy = []
for row in csv.DictReader(open(tree / "legacy-manifest/assets.csv", encoding="utf-8")):
    rel = row["source_path"][len(vd.ASSET_ROOT):]
    if rel.endswith(".png"):
        try:
            legacy.append((rel, vd.Image(*vd.decode_rgba((up / row["source_path"]).read_bytes()))))
        except Exception:
            pass
target = "textures/models/areagravitycontroller.png"
cand = [(n, i) for n, i in legacy if n == target]
refs = vanilla + [(vd.LEGACY, n, i) for n, i in legacy]


def run(label):
    m = vd.match_images(cand, refs)
    table = m.related.get(target, {})
    print(label, "related of", target, ":", sorted((k.split("/")[-1], v[1]) for k, v in table.items()), flush=True)


run("committed caps:")
for name in ("POSTING_CAP", "OFFSETS_PER_VARIANT", "OFFSETS_PER_REFERENCE"):
    print(name, getattr(vd, name, None))
vd.POSTING_CAP = 10 ** 6
run("posting cap lifted:")
vd.OFFSETS_PER_VARIANT = 10 ** 6
run("posting cap and offsets per variant lifted:")
