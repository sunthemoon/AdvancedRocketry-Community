"""Round-4 adversarial cases for the schema-3 derivation check (beyond the ten round-3 cases)."""
import random
import sys

sys.path.insert(0, sys.argv[1])
from tools.audit.vanilla_derivation import Image, analyse_images  # noqa: E402


def noise(width, height, seed, colours=24):
    state = seed
    palette = []
    for _ in range(colours):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        palette.append((state & 0xFF, (state >> 8) & 0xFF, (state >> 16) & 0xFF, 255))
    pixels = []
    for _ in range(width * height):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        pixels.append(palette[state % colours])
    return pixels


def crop(pixels, width, x0, y0, w, h):
    return [pixels[(y0 + y) * width + x0 + x] for y in range(h) for x in range(w)]


def gui_button(w, h, fill=(198, 198, 198, 255)):
    """A vanilla-style button: black outline, white top-left bevel, dark bottom-right bevel, flat fill."""
    black, white, dark = (0, 0, 0, 255), (255, 255, 255, 255), (85, 85, 85, 255)
    out = []
    for y in range(h):
        for x in range(w):
            if x == 0 or y == 0 or x == w - 1 or y == h - 1:
                out.append(black)
            elif x == 1 or y == 1:
                out.append(white)
            elif x == w - 2 or y == h - 2:
                out.append(dark)
            else:
                out.append(fill)
    return out


rng = random.Random(5)
sheet_px = noise(128, 128, seed=11)
# A vanilla GUI sheet: grey background with two buttons and some textured icons.
gui = [(139, 139, 139, 255)] * (256 * 256)
button = gui_button(24, 24)
for y in range(24):
    for x in range(24):
        gui[(y + 40) * 256 + x + 40] = button[y * 24 + x]
icon = noise(16, 16, seed=77, colours=12)
for y in range(16):
    for x in range(16):
        gui[(y + 100) * 256 + x + 100] = icon[y * 16 + x]
vanilla = [("v", "sheet.png", Image(128, 128, sheet_px)), ("v", "gui.png", Image(256, 256, gui))]

base = crop(sheet_px, 128, 40, 30, 24, 24)
cases = {}
cases["exact GUI button crop (flat fill + bevel)"] = Image(24, 24, list(button))
redrawn = [(20, 20, 20, 255) if p == (0, 0, 0, 255) else p for p in button]
cases["GUI button crop, outline recoloured"] = Image(24, 24, redrawn)
cases["GUI button crop, fill recoloured"] = Image(24, 24, [(150, 160, 170, 255) if p == (198, 198, 198, 255) else p
                                                            for p in button])
noisy = [(min(255, max(0, r + rng.randint(-6, 6))), min(255, max(0, g + rng.randint(-6, 6))),
          min(255, max(0, b + rng.randint(-6, 6))), a) for r, g, b, a in base]
cases["crop with +-6 noise (a filter)"] = Image(24, 24, noisy)
blur = []
for y in range(24):
    for x in range(24):
        acc = [0, 0, 0]
        n = 0
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if 0 <= x + dx < 24 and 0 <= y + dy < 24:
                    p = base[(y + dy) * 24 + x + dx]
                    acc = [acc[i] + p[i] for i in range(3)]
                    n += 1
        blur.append((acc[0] // n, acc[1] // n, acc[2] // n, 255))
cases["crop blurred 3x3"] = Image(24, 24, blur)
cases["icon with alpha 255 -> 200"] = Image(16, 16, [(r, g, b, 200) for r, g, b, a in icon])
big = noise(128, 128, seed=999, colours=10)
recol = [(int((0.299 * r + 0.587 * g + 0.114 * b) * 0.5) + 20, 30, 40, a) for r, g, b, a in base]
for y in range(24):
    for x in range(24):
        big[(y + 50) * 128 + x + 60] = recol[y * 24 + x]
cases["recoloured crop inside a 128x128 sheet (documented limit)"] = Image(128, 128, big)
big2 = noise(128, 128, seed=998, colours=10)
for y in range(24):
    for x in range(24):
        big2[(y + 50) * 128 + x + 60] = noisy[y * 24 + x]
cases["noisy crop inside a 128x128 sheet"] = Image(128, 128, big2)
palette4 = [(64 * ((r + g + b) // 192), 64 * ((r + g + b) // 192), 0, a) for r, g, b, a in base]
cases["crop reduced to 4 grey levels (merging colours)"] = Image(24, 24, palette4)
# A legacy texture that is the vanilla icon at x2 with every second row shifted (a stylised edit)
cases["icon x2 nearest"] = Image(32, 32, [icon[(y // 2) * 16 + x // 2] for y in range(32) for x in range(32)])
cases["unrelated noise (negative)"] = Image(24, 24, noise(24, 24, seed=4242))
cases["unrelated flat button of another size (negative)"] = Image(20, 12, gui_button(20, 12, fill=(120, 120, 120, 255)))

results = analyse_images(list(cases.items()), vanilla)
for name in cases:
    level = results.get(name, (None, "CLEAR", {}))[1]
    record = results.get(name, (None, "CLEAR", {}))[2]
    keys = ("method", "exact", "near", "mapped", "classes", "colours", "overlap", "rank")
    print(f"{level:8s} {name:58s} {dict((k, record[k]) for k in keys if k in record)}")
