"""Recorded and fresh measures for the two IMPORT files that escape inheritance."""
import json
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

tree, root = Path(sys.argv[1]), Path(sys.argv[2])
d = json.load(open(tree / "docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))
by = {e["asset"]: e for e in d["assets"]}
for src, other in (("textures/blocks/warpcore.png", "textures/models/areagravitycontroller.png"),
                   ("textures/blocks/crystallizer_active.png", "textures/blocks/monitorrear.png")):
    rec = [r for r in by[src].get("related", []) if r["asset"] == other]
    print("recorded on", src, "->", other, ":", rec)
    print("  sizes", by[src].get("size"), by[other].get("size"), "| related count of", src, len(by[src].get("related", [])),
          "| of", other, len(by[other].get("related", [])))
    a = vd.Image(*vd.decode_rgba((root / src).read_bytes()))
    b = vd.Image(*vd.decode_rgba((root / other).read_bytes()))
    for cand, ref, cn, rn in ((a, b, src, other), (b, a, other, src)):
        m = vd.match_images([(cn, cand)], [(vd.LEGACY, rn, ref)])
        print("  fresh", cn.split("/")[-1], "as candidate vs", rn.split("/")[-1], ":",
              {k: v for k, v in m.related.get(cn, {}).get(rn, (None, "CLEAR", {}))[2].items()
               if k in ("method", "exact", "near", "mapped", "colours", "classes", "overlap", "iou", "rank", "offset",
                        "scale", "reference_scale", "candidate_scale", "pixels")},
              m.related.get(cn, {}).get(rn, (None, "CLEAR"))[1])
