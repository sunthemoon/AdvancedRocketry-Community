"""Filtered, partial and overlaid derivatives of real vanilla 1.12.2 block textures, scored by the
schema-3 tool against all vanilla images of both clients."""
import random
import sys
import zipfile

sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd  # noqa: E402

jar112, jar120 = sys.argv[2], sys.argv[3]
_, _, vanilla = vd.load_vanilla([f"1.12.2={jar112}", f"1.20.1={jar120}"])
z = zipfile.ZipFile(jar112)
rng = random.Random(7)


def load(name):
    w, h, rgba = vd.decode_rgba(z.read("assets/minecraft/textures/blocks/" + name))
    h = min(h, w)
    return w, h, [tuple(rgba[i:i + 4]) for i in range(0, 4 * w * h, 4)]


def image(w, h, px):
    return vd.Image(w, h, b"".join(bytes(p) for p in px))


def clamp(v):
    return min(255, max(0, int(v)))


def noisy(px, amp):
    return [(clamp(r + rng.randint(-amp, amp)), clamp(g + rng.randint(-amp, amp)), clamp(b + rng.randint(-amp, amp)), a)
            for r, g, b, a in px]


def blur(w, h, px):
    out = []
    for y in range(h):
        for x in range(w):
            acc, n = [0, 0, 0], 0
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if 0 <= x + dx < w and 0 <= y + dy < h:
                        p = px[(y + dy) * w + x + dx]
                        acc = [acc[i] + p[i] for i in range(3)]
                        n += 1
            out.append((acc[0] // n, acc[1] // n, acc[2] // n, px[y * w + x][3]))
    return out


def crop(w, px, x0, y0, cw, ch):
    return [px[(y0 + y) * w + x0 + x] for y in range(ch) for x in range(cw)]


def overlay(w, h, px, size, colour_seed):
    out = list(px)
    r2 = random.Random(colour_seed)
    x0, y0 = (w - size) // 2, (h - size) // 2
    for y in range(size):
        for x in range(size):
            out[(y0 + y) * w + x0 + x] = (r2.randint(0, 255), r2.randint(0, 255), r2.randint(0, 255), 255)
    return out


if __name__ == "__main__":
    cases = {}
    for name in ("piston_side.png", "furnace_front_off.png", "iron_block.png", "cobblestone.png", "dispenser_front_horizontal.png"):
        w, h, px = load(name)
        stem = name[:-4]
        cases[f"{stem}: +-6 noise"] = image(w, h, noisy(px, 6))
        cases[f"{stem}: +-12 noise"] = image(w, h, noisy(px, 12))
        cases[f"{stem}: 3x3 blur"] = image(w, h, blur(w, h, px))
        cases[f"{stem}: darkened x0.8"] = image(w, h, [(clamp(r * .8), clamp(g * .8), clamp(b * .8), a) for r, g, b, a in px])
        cases[f"{stem}: channels swapped"] = image(w, h, [(b, g, r, a) for r, g, b, a in px])
        cases[f"{stem}: 8x8 centre replaced"] = image(w, h, overlay(w, h, px, 8, 3))
        cases[f"{stem}: 10x10 centre replaced"] = image(w, h, overlay(w, h, px, 10, 3))
        cases[f"{stem}: 12x12 crop +-6 noise"] = image(12, 12, noisy(crop(w, px, 2, 2, 12, 12), 6))
        cases[f"{stem}: x2 then +-6 noise"] = image(2 * w, 2 * h, noisy(
            [px[(y // 2) * w + x // 2] for y in range(2 * h) for x in range(2 * w)], 6))
        cases[f"{stem}: x2 then blur"] = image(2 * w, 2 * h, blur(2 * w, 2 * h,
            [px[(y // 2) * w + x // 2] for y in range(2 * h) for x in range(2 * w)]))
    best = vd.analyse_images(list(cases.items()), vanilla)
    keys = ("method", "reference", "exact", "near", "mapped", "classes", "colours", "overlap", "iou", "rank")
    for name in cases:
        level, record = best.get(name, (None, "CLEAR", {}))[1:]
        rec = dict((k, record[k]) for k in keys if k in record)
        if "reference" in rec:
            rec["reference"] = rec["reference"].split("/")[-1]
        print(f"{level:8s} {name:45s} {rec}")
