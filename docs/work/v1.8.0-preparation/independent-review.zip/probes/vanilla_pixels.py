import zipfile, sys, csv, fnmatch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode, PngError
jar, tree, up = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
z = zipfile.ZipFile(jar)
def sig(w,h,px):
    # 8x8 mean colour grid + alpha mask
    g=[]
    for gy in range(8):
        for gx in range(8):
            x0=gx*w//8; x1=max(x0+1,(gx+1)*w//8); y0=gy*h//8; y1=max(y0+1,(gy+1)*h//8)
            rs=gs=bs=as_=n=0
            for y in range(y0,y1):
                for x in range(x0,x1):
                    r,gg,b,a=px[y*w+x]; rs+=r*a//255; gs+=gg*a//255; bs+=b*a//255; as_+=a; n+=1
            g.append((rs/n,gs/n,bs/n,as_/n))
    return g
def dist(s1,s2):
    return sum(abs(a-b) for p,q in zip(s1,s2) for a,b in zip(p,q))/(len(s1)*4)
van = {}
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
        try:
            w,h,px = decode(z.read(n), 128*128)
        except Exception: continue
        if h > w: h2 = w  # animated strips: take first frame
        else: h2 = h
        van.setdefault((w,h2), []).append((n, sig(w,h2,px[:w*h2]), px[:w*h2]))
print("vanilla decoded", sum(len(v) for v in van.values()), file=sys.stderr)
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"]+"#"+r["order"]
root = up/"src/main/resources/assets/advancedrocketry"
results=[]
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\","/")
    try: w,h,px = decode(f.read_bytes(), 128*128)
    except Exception as e: continue
    h2 = w if h > w else h
    s = sig(w,h2,px[:w*h2])
    best=None
    for n, vs, vpx in van.get((w,h2), []):
        d = dist(s, vs)
        if best is None or d < best[0]:
            exact = sum(1 for p,q in zip(px[:w*h2], vpx) if p==q)/(w*h2)
            best=(d,n,exact)
    if best and (best[0] < 12 or best[2] > 0.5):
        results.append((best[0], a, best[1], best[2], handling(a)))
for d,a,n,ex,hd in sorted(results):
    print(f"{d:6.2f} exact={ex:.2f} {hd:16s} {a}  ~  {n}")
