import zipfile, sys, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
z = zipfile.ZipFile(sys.argv[1]); root = Path(sys.argv[2])
def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
for spec in sys.argv[3:]:
    a, v = spec.split("=")
    w1,h1,p1 = decode((root/a).read_bytes(), 4096*4096); w2,h2,p2 = decode(z.read(v), 4096*4096)
    if (w1,h1)!=(w2,h2): print(a, "size differs", (w1,h1),(w2,h2)); continue
    idx=[i for i in range(len(p1)) if p1[i][3]>0 and p2[i][3]>0]
    xs=[lum(p2[i]) for i in idx]; ys=[lum(p1[i]) for i in idx]
    mx=sum(xs)/len(xs); my=sum(ys)/len(ys); vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
    cov=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); r=cov/math.sqrt(vx*vy); b=cov/vx; a0=my-b*mx
    resid=sum(abs(y-(a0+b*x)) for x,y in zip(xs,ys))/len(xs)
    # rank agreement: fraction of pixel pairs ordered the same
    import random; random.seed(1); agree=tot=0
    for _ in range(20000):
        i,j=random.sample(range(len(xs)),2)
        if xs[i]!=xs[j] and ys[i]!=ys[j]:
            tot+=1; agree += (xs[i]<xs[j])==(ys[i]<ys[j])
    distinct=len(set(round(x,1) for x in xs))
    print(f"{a} vs {v}: pixels={len(idx)} r={r:.4f} slope={b:.3f} mean_abs_resid={resid:.2f} pair_order_agree={agree/max(1,tot):.3f} vanilla_distinct_lum={distinct}")
