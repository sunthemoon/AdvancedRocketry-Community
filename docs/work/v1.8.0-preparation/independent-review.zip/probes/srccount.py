import json, sys, csv, collections
inv = json.load(open(sys.argv[1], encoding="utf-8"))
print("sources", len(inv["sources"]))
rows = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))
c = collections.Counter(r["disposition"] for r in rows); print(c)
# DEFERRED/REJECTED rows not citing ADR-062
for r in rows:
    if r["disposition"] in ("DEFERRED","REJECTED") and "ADR-062" not in r["decision"].split():
        print("no ADR-062:", r["unit_id"], r["decision"])
