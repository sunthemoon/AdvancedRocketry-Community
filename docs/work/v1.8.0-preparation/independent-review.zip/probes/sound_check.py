import json, hashlib, sys
from pathlib import Path
idx = json.load(open(sys.argv[1]))["objects"]
by = {v["hash"]: k for k, v in idx.items()}
root = Path(sys.argv[2])
for f in sorted(root.glob("*.ogg")):
    data = f.read_bytes()
    s1 = hashlib.sha1(data).hexdigest()
    # vorbis comment packet: find 0x03 'vorbis'
    i = data.find(b"\x03vorbis")
    vendor = comments = None
    if i >= 0:
        j = i + 7
        vl = int.from_bytes(data[j:j+4], "little"); vendor = data[j+4:j+4+vl].decode("utf-8","replace"); j += 4+vl
        n = int.from_bytes(data[j:j+4], "little"); j += 4; comments=[]
        for _ in range(min(n,50)):
            cl = int.from_bytes(data[j:j+4], "little"); comments.append(data[j+4:j+4+cl].decode("utf-8","replace")); j += 4+cl
    # last granule position for duration
    k = data.rfind(b"OggS"); gran = int.from_bytes(data[k+6:k+14], "little")
    ih = data.find(b"\x01vorbis"); rate = int.from_bytes(data[ih+12:ih+16], "little"); ch = data[ih+11]
    print(f"{f.name:28s} vanilla={by.get(s1,'-')} vendor={vendor!r} comments={comments} duration={gran/rate:.2f}s ch={ch} rate={rate}")
