import json,sys
inv=json.load(open(sys.argv[1],encoding='utf-8'))
kind=sys.argv[2]
for u in inv['units']:
    if u['kind']==kind: print(u['legacy_name'], u['source'].split('/')[-1], u['line'], u.get('display',''), u.get('java_class',''), u.get('conditional',''))
print(inv['counts'])
