import zipfile, sys
from collections import Counter
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
jar = zipfile.ZipFile(sys.argv[1]); root = Path(sys.argv[2])
for spec in sys.argv[3:]:
    a, v = spec.split("=")
    w1,h1,p1 = decode((root/a).read_bytes(), 4096*4096)
    w2,h2,p2 = decode(jar.read(v), 4096*4096)
    op = [i for i,p in enumerate(p1) if p[3]>0]
    common = Counter(p1[i] for i in op).most_common(3)
    excl = set(c for c,_ in common[:1])
    rest = [i for i in op if p1[i] not in excl]
    eq = sum(1 for i in rest if p1[i]==p2[i])
    # distinct colours among equal pixels
    eqcols = Counter(p1[i] for i in rest if p1[i]==p2[i])
    print(f"{a} vs {v}: opaque={len(op)} top={common[0]} non-dominant={len(rest)} equal_non_dominant={eq} ({eq/max(1,len(rest)):.2f}) distinct_equal_colours={len(eqcols)} top_equal={eqcols.most_common(4)}")
