import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
print(d["sha"], d["commit"]["author"], repr(d["commit"]["message"][:600]))
print(len(d.get("files",[])), "files;", [f["filename"].split("/")[-1] for f in d.get("files",[])][:40])
