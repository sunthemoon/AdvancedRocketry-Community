import json, sys
from pathlib import Path
R = Path(sys.argv[1])
seen=set()
for name in sys.argv[2:]:
    for f in sorted(R.glob(name)):
        if f in seen: continue
        seen.add(f)
        d = json.loads(f.read_text(encoding="utf-8"))
        ing = []
        def walk(x):
            if isinstance(x, dict):
                if "item" in x: ing.append(x["item"] + (f"@{x['data']}" if "data" in x else ""))
                if "ore" in x: ing.append("ore:" + x["ore"])
                for k, v in x.items(): walk(v)
            elif isinstance(x, list):
                for v in x: walk(v)
        walk(d.get("key", d.get("ingredients", {})))
        res = d.get("result", {})
        print(f"{f.name:32s} -> {res.get('item')}@{res.get('data','')} : {sorted(set(ing))}")
