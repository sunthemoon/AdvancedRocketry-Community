import re, json, sys
from pathlib import Path
up = Path(sys.argv[1]); inv = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
J = up/"src/main/java/zmaster587/advancedRocketry"
listed = {u["legacy_name"] for u in inv["units"] if u["kind"]=="config"}
listed_names = {n.split(".",1)[1] for n in listed}
found = {}
for f in sorted(J.rglob("*.java")):
    t = f.read_text(encoding="utf-8", errors="replace")
    for m in re.finditer(r'\b(\w+)\.get(Boolean|Int|Float|String|StringList|Double)?\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*,', t, re.S):
        obj = m.group(1)
        if obj not in ("config","configuration","cfg"): continue
        a, b = m.group(3).strip(), m.group(4).strip()
        if m.group(2) is None:
            cat, name = a, b
        else:
            name, cat = a, b
        name = name.strip('"'); cat = cat.strip('"').split(".")[-1]
        line = t.count("\n",0,m.start())+1
        found.setdefault(name, []).append((str(f.relative_to(J)).replace("\\","/"), line, cat))
missing = {k:v for k,v in found.items() if k not in listed_names}
print("distinct config names found:", len(found), "listed:", len(listed))
for k,v in sorted(missing.items()): print("MISSING", k, v[0])
extra = listed_names - set(found)
print("listed but not found by probe:", sorted(extra))
