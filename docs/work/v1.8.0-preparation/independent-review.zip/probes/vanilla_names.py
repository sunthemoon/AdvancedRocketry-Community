import zipfile, hashlib, csv, sys
from pathlib import Path
jar = sys.argv[1]; tree = Path(sys.argv[2]); up = Path(sys.argv[3])
z = zipfile.ZipFile(jar)
van = {}
vhash = {}
for n in z.namelist():
    if n.startswith("assets/minecraft/") and not n.endswith("/"):
        base = n.rsplit("/",1)[-1].lower()
        van.setdefault(base, []).append(n)
        if n.endswith((".png",".json",".ogg",".mcmeta")):
            vhash.setdefault(hashlib.sha256(z.read(n)).hexdigest(), []).append(n)
print("vanilla assets", sum(len(v) for v in van.values()))
root = "src/main/resources/assets/advancedrocketry/"
rows = list(csv.DictReader(open(tree/"legacy-manifest/assets.csv", encoding="utf-8")))
# asset plan handling
import fnmatch
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"], r["order"]
    return None, None
for r in rows:
    p = r["source_path"]
    if not p.startswith(root): continue
    a = p[len(root):]
    base = a.rsplit("/",1)[-1].lower()
    h = r["sha256"]
    hd, order = handling(a)
    tags = []
    if base in van and (base.endswith(".png") or base.endswith(".ogg") or base.endswith(".json") or base.endswith(".mcmeta")):
        tags.append("NAME=" + ";".join(van[base][:3]))
    if h in vhash:
        tags.append("BYTES=" + ";".join(vhash[h][:3]))
    if tags:
        print(f"{hd:10s} rule{order:>4s} {a}  " + " | ".join(tags))
