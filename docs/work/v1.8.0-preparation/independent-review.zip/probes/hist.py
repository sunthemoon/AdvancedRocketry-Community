import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
print(sys.argv[2], [(c["sha"][:8], c["commit"]["author"]["name"], c["commit"]["author"]["date"][:10]) for c in d])
