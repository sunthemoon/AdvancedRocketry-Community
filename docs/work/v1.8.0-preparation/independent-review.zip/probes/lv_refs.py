import re, sys
from pathlib import Path
up = Path(sys.argv[1]); lv = Path(sys.argv[2])
refs = {}
for f in up.rglob("*"):
    if f.is_file() and f.suffix in (".json", ".java", ".obj", ".mtl", ".lang"):
        t = f.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r'libvulpes:([A-Za-z0-9_/.\-]+)', t, re.I):
            refs.setdefault(m.group(1), set()).add(str(f.relative_to(up)).replace("\\","/"))
print("distinct libvulpes refs", len(refs))
for k in sorted(refs): print(f"  {k:45s} {len(refs[k]):4d} files")
blobs = [l.split("\t")[0] for l in lv.read_text(encoding="utf-8").splitlines()]
tex = [b for b in blobs if "/textures/" in b]
print("lv textures", len(tex))
for t in tex: print("  ", t)
