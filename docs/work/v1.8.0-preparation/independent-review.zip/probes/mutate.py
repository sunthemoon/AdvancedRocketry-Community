"""Targeted mutations of copies of the v1.8 ledger inputs; reports which the validator catches."""
import csv, io, json, shutil, subprocess, sys, tempfile
from pathlib import Path
TREE = Path(sys.argv[1]); OUT = Path(sys.argv[2])
VALIDATOR = TREE / "scripts/validate_v180_content_ledger.py"
COPY = ["legacy-manifest", "docs/decisions", "docs/versions", "docs/provenance",
        "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry"]
FILES = ["docs/work/v1.8.0-legacy-inventory.json", "docs/work/v1.8.0-content-ledger.csv", "docs/work/v1.8.0-asset-plan.csv"]
LEDGER, PLAN, INV = FILES[1], FILES[2], FILES[0]
def fresh(root):
    if root.exists(): shutil.rmtree(root)
    for c in COPY: shutil.copytree(TREE / c, root / c)
    for f in FILES:
        (root / f).parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(TREE / f, root / f)
def rows(root, rel):
    with (root/rel).open(encoding="utf-8", newline="") as h: return list(csv.DictReader(h))
def write(root, rel, rs):
    b = io.StringIO(); w = csv.DictWriter(b, fieldnames=list(rs[0].keys()), lineterminator="\n"); w.writeheader(); w.writerows(rs)
    (root/rel).write_text(b.getvalue(), encoding="utf-8", newline="")
def edit_ledger(root, uid, **ch):
    rs = rows(root, LEDGER); hit = False
    for r in rs:
        if r["unit_id"] == uid: r.update(ch); hit = True
    assert hit, uid
    write(root, LEDGER, rs)
def edit_plan(root, pattern, **ch):
    rs = rows(root, PLAN); hit=False
    for r in rs:
        if r["pattern"] == pattern: r.update(ch); hit=True
    assert hit, pattern
    write(root, PLAN, rs)
def drop_plan(root, pattern):
    rs = [r for r in rows(root, PLAN) if r["pattern"] != pattern]
    for i, r in enumerate(rs, 1): r["order"] = str(i)
    write(root, PLAN, rs)
def run(root, *extra):
    p = subprocess.run([sys.executable, str(VALIDATOR), "--root", str(root), *extra], capture_output=True, text=True, timeout=300)
    return p.returncode, p.stderr.strip().splitlines()
M = []
def mut(name, gap):
    def deco(fn): M.append((name, gap, fn)); return fn
    return deco
@mut("IMPLEMENTED lathe pointing at a tag-only literal 'machine_casings'", True)
def m1(r): edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0", target="advancedrocketrycommunity:machine_casings", decision="ADR-062")
@mut("IMPLEMENTED lathe pointing at an unrelated registered ID (machine_casing)", True)
def m2(r): edit_ledger(r, "block:lathe", disposition="IMPLEMENTED", plan="v1.8.0", target="advancedrocketrycommunity:machine_casing", decision="ADR-062")
@mut("PLANNED unit moved to REDESIGNED v1.8.0 with free text (escapes the zero-PLANNED closure)", True)
def m3(r): edit_ledger(r, "block:centrifuge", disposition="REDESIGNED", plan="v1.8.0", target="something else later", decision="ADR-062")
@mut("REJECTED row citing an unrelated accepted ADR (no player impact anywhere)", True)
def m4(r): edit_ledger(r, "block:lathe", disposition="REJECTED", plan="-", target="-", decision="ADR-016")
@mut("DEFERRED row citing only ADR-001", True)
def m5(r): edit_ledger(r, "block:centrifuge", disposition="DEFERRED", plan="post-2.0", target="-", decision="ADR-001")
@mut("Asset plan: loosen EXCLUDE textures/env/sun.png to IMPORT", True)
def m6(r): edit_plan(r, "textures/env/sun.png", handling="IMPORT", plan="C18d")
@mut("Asset plan: loosen REVIEW textures/planets/*leo.jpg to IMPORT", True)
def m7(r): edit_plan(r, "textures/planets/*leo.jpg", handling="IMPORT", plan="C18d")
@mut("Asset plan: drop deferred hovercraft OBJ exclusion (falls through to models/*.obj IMPORT)", True)
def m8(r): drop_plan(r, "models/hovercraft.obj")
@mut("Asset plan: drop silent placeholder dummy.ogg exclusion (falls to sounds/*.ogg REVIEW)", True)
def m9(r): drop_plan(r, "sounds/dummy.ogg")
@mut("Asset plan: IMPORT for asset whose unit is REJECTED (wirelesstransciever)", True)
def m10(r): edit_plan(r, "textures/blocks/wirelesstransciever_*", handling="IMPORT", plan="C16a")
@mut("Inventory: delete a config unit and its ledger row, fix counts", True)
def m11(r):
    p = r/INV; inv = json.loads(p.read_text(encoding="utf-8"))
    inv["units"] = [u for u in inv["units"] if u["id"] != "config:ROCKET.experimentalSpaceFlight"]; inv["counts"]["config"] -= 1
    p.write_text(json.dumps(inv, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    write(r, LEDGER, [x for x in rows(r, LEDGER) if x["unit_id"] != "config:ROCKET.experimentalSpaceFlight"])
@mut("Inventory: change a unit line number / display", True)
def m12(r):
    p = r/INV; inv = json.loads(p.read_text(encoding="utf-8"))
    for u in inv["units"]:
        if u["id"] == "block:lathe": u["line"] = 1; u["display"] = "Not a Lathe"
    p.write_text(json.dumps(inv, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
@mut("Inventory: add a fabricated unit plus ledger row", True)
def m13(r):
    p = r/INV; inv = json.loads(p.read_text(encoding="utf-8"))
    inv["units"].append({"id": "config:FAKE.key", "kind": "config", "legacy_name": "FAKE.key", "source": inv["units"][0]["source"], "line": 1}); inv["counts"]["config"] += 1
    p.write_text(json.dumps(inv, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    rs = rows(r, LEDGER); rs.append(dict(rs[0], unit_id="config:FAKE.key")); write(r, LEDGER, rs)
@mut("PLANNED row assigned to a batch that ADR-062 does not plan for that system (block:lathe -> C18d)", False)
def m14(r): edit_ledger(r, "block:lathe", plan="C18d")
@mut("REDESIGNED with plan v0.0.1 (before the mechanism existed)", True)
def m15(r): edit_ledger(r, "block:launchpad", plan="v0.0.1")
@mut("IMPLEMENTED config row with target '-'", False)
def m16(r): edit_ledger(r, "config:STATION.warpTravelTime", target="-")
@mut("Ledger decision token lower-case 'adr-062'", False)
def m17(r): edit_ledger(r, "block:lathe", decision="adr-062")
@mut("MERGED row targeting a REJECTED unit (block entity follows a rejected block)", False)
def m18(r): edit_ledger(r, "block_entity:ARTileLathe", target="block:wirelesstransciever")
@mut("Ledger row with notes field > 512 chars", False)
def m19(r): edit_ledger(r, "block:lathe", notes="x"*600)
@mut("Asset plan IMPORTED handling for a file recorded only under a different source repo string", False)
def m20(r): pass
@mut("--require-accepted with all ADRs flipped to ACCEPTED but ledger still has PLANNED rows", True)
def m21(r):
    for f in (r/"docs/decisions").glob("ADR-06[0-2]*.md"):
        t = f.read_text(encoding="utf-8").replace("status: PROPOSED", "status: ACCEPTED", 1); f.write_text(t, encoding="utf-8")
results = []
base = OUT / "mut"
fresh(base); rc, err = run(base); results.append(("baseline (unmodified copy)", None, rc, err[:3]))
for name, gap, fn in M:
    if fn is m20: continue
    fresh(base); fn(base)
    extra = ("--require-accepted",) if fn is m21 else ()
    rc, err = run(base, *extra)
    results.append((name, gap, rc, err[:3]))
shutil.rmtree(base)
for name, gap, rc, err in results:
    status = "CAUGHT" if rc != 0 else "SURVIVED"
    print(f"[{status}] {name}")
    for e in err: print(f"      {e[:200]}")
