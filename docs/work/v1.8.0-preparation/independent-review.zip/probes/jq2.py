import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
print(d["sha"], d["commit"]["author"], d["commit"]["message"])
print("parents", [p["sha"] for p in d["parents"]])
for f in d.get("files", []):
    print(f["status"], f["filename"], f.get("additions"), f.get("deletions"))
    if "icen" in f["filename"].lower():
        print(f.get("patch","")[:3000])
