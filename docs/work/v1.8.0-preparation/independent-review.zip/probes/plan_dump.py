import csv, fnmatch, sys
from pathlib import Path
tree = Path(sys.argv[1])
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
root = "src/main/resources/assets/advancedrocketry/"
assets = sorted(r["source_path"][len(root):] for r in csv.DictReader(open(tree/"legacy-manifest/assets.csv", encoding="utf-8")) if r["source_path"].startswith(root))
want = sys.argv[2:]
for a in assets:
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]):
            if any(fnmatch.fnmatchcase(a, w) for w in want):
                print(f"{r['handling']:10s} #{r['order']:>3s} {r['plan']:24s} {a}")
            break
