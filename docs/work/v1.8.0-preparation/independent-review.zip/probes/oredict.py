import re, json, sys, collections
from pathlib import Path
up = Path(sys.argv[1]); inv = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
names = collections.Counter()
for f in (up/"src/main/resources/assets/advancedrocketry/recipes").glob("*.json"):
    for m in re.finditer(r'"ore"\s*:\s*"(\w+)"', f.read_text(encoding="utf-8")): names[m.group(1)] += 1
for f in (up/"src/main/java").rglob("*.java"):
    t = f.read_text(encoding="utf-8", errors="replace")
    for m in re.finditer(r'"((?:ingot|plate|dust|stick|gear|sheet|coil|block|nugget|ore|boule|crystal|gem|fan|rod|wire|item|lens|casing|turf|log|plank|tree|slab|concrete|waferSilicon|dye)[A-Z]\w*)"', t): names[m.group(1)] += 1
print(sorted(names.items()))
mats = {u["legacy_name"]: u.get("products") for u in inv["units"] if u["kind"]=="material"}
print(json.dumps(mats, indent=0))
