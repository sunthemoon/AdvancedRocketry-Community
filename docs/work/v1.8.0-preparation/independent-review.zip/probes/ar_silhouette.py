import zipfile, sys, math, csv, fnmatch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
z = zipfile.ZipFile(sys.argv[1]); tree = Path(sys.argv[2]); root = Path(sys.argv[3])
van = []
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
        try: w,h,px = decode(z.read(n), 32*32)
        except Exception: continue
        if (w,h)==(16,16): van.append((n, px, set(i for i,p in enumerate(px) if p[3]>0)))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"]+"#"+r["order"]
def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
out=[]
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\","/")
    try: w,h,px = decode(f.read_bytes(), 32*32)
    except Exception: continue
    if (w,h)!=(16,16): continue
    op = [i for i,p in enumerate(px) if p[3]>0]
    full = len(op) >= 250
    best=None
    for n, vpx, vop in van:
        if not vop: continue
        iou = sum(1 for i in op if i in vop)/len(set(op)|vop)
        sh = [i for i in op if i in vop]
        if len(sh)<8: continue
        xs=[lum(px[i]) for i in sh]; ys=[lum(vpx[i]) for i in sh]
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys); vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
        corr = sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(vx*vy) if vx>0 and vy>0 else 0
        s = (iou if not full else 1)*corr
        if best is None or s > best[0]: best=(s,iou,corr,n)
    if best and ((not full and best[1]>0.85 and best[2]>0.7) or (full and best[2]>0.8)):
        out.append((best[0], a, best, handling(a), full))
for s,a,b,hd,full in sorted(out, reverse=True):
    print(f"{s:.2f} {'FULL' if full else 'SHAPE'} {hd:14s} {a} ~ {b[3]} IoU={b[1]:.2f} r={b[2]:.2f}")
