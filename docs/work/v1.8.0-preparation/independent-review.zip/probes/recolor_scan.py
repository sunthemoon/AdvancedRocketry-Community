import zipfile, sys, math, csv, fnmatch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
z = zipfile.ZipFile(sys.argv[1]); tree = Path(sys.argv[2]); root = Path(sys.argv[3]); label = sys.argv[4] if len(sys.argv) > 4 else "AR"
def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
van = {}
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
        try: w,h,px = decode(z.read(n), 128*128)
        except Exception: continue
        mask = [p[3]>0 for p in px]; L=[lum(p) for p in px]
        van.setdefault((w,h), []).append((n, mask, L))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"]+"#"+r["order"]
    return "-"
res=[]
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\","/")
    try: w,h,px = decode(f.read_bytes(), 128*128)
    except Exception: continue
    m1=[p[3]>0 for p in px]; L1=[lum(p) for p in px]
    for n, m2, L2 in van.get((w,h), []):
        idx=[i for i in range(len(px)) if m1[i] and m2[i]]
        un=sum(1 for i in range(len(px)) if m1[i] or m2[i])
        if len(idx) < 32 or len(idx)/un < 0.9: continue
        xs=[L2[i] for i in idx]; ys=[L1[i] for i in idx]
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys); vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
        if vx < 1 or vy < 1: continue
        r=sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(vx*vy)
        if r >= 0.93:
            res.append((r, a, n, len(idx), handling(a)))
best={}
for r,a,n,k,hd in res:
    if a not in best or r > best[a][0]: best[a]=(r,n,k,hd)
for a,(r,n,k,hd) in sorted(best.items(), key=lambda x:-x[1][0]):
    print(f"{r:.3f} {hd:14s} {label}:{a} ~ {n} ({k} px)")
