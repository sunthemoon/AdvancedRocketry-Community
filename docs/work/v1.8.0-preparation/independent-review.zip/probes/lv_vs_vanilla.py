import zipfile, sys, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
z = zipfile.ZipFile(sys.argv[1]); d = Path(sys.argv[2])
van = {}
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
        try: w,h,px = decode(z.read(n), 64*64)
        except Exception: continue
        van.setdefault((w,h), []).append((n, px))
def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
for f in sorted(d.glob("*.png")):
    try: w,h,px = decode(f.read_bytes(), 64*64)
    except Exception as e: print(f.name, "skip", e); continue
    op = [i for i,p in enumerate(px) if p[3]>0]
    if not op: continue
    best=None
    for n, vpx in van.get((w,h), []):
        vop = set(i for i,p in enumerate(vpx) if p[3]>0)
        if not vop: continue
        inter = sum(1 for i in op if i in vop); union = len(set(op)|vop)
        iou = inter/union
        sh = [i for i in op if i in vop]
        if len(sh) < 8: continue
        xs=[lum(px[i]) for i in sh]; ys=[lum(vpx[i]) for i in sh]
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys)
        vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
        corr = sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(vx*vy) if vx>0 and vy>0 else 0
        score = iou*max(corr,0)
        if best is None or score > best[0]: best=(score, iou, corr, n)
    if best and best[1] > 0.85 and best[2] > 0.6:
        print(f"{f.name:40s} mask_IoU={best[1]:.2f} lum_corr={best[2]:.2f} ~ {best[3]}")
