import re, sys, collections
from pathlib import Path
up = Path(sys.argv[1]) / "src/main/resources/assets/advancedrocketry"
occ = collections.Counter(); occ_ci = collections.Counter()
for f in up.rglob("*"):
    if f.is_file():
        t = f.read_bytes().decode("utf-8", "replace")
        for m in re.finditer(r'libvulpes:([A-Za-z0-9_/.\-]+)', t, re.I):
            occ[m.group(1)] += 1; occ_ci[m.group(1).lower()] += 1
print("asset-only distinct", len(occ), "case-insensitive", len(occ_ci))
for k,v in occ_ci.most_common(8): print(" ", k, v)
J = Path(sys.argv[1]) / "src/main/java"
occj = collections.Counter()
for f in J.rglob("*.java"):
    t = f.read_text(encoding="utf-8", errors="replace")
    for m in re.finditer(r'libvulpes:([A-Za-z0-9_/.\-]+)', t, re.I): occj[m.group(1)] += 1
print("java distinct", len(occj), sorted(occj))
allk = set(occ) | set(occj)
print("union distinct", len(allk), "ci", len({k.lower() for k in allk}))
jref = collections.Counter()
for f in J.rglob("*.java"):
    t = f.read_text(encoding="utf-8", errors="replace")
    for m in re.finditer(r'LibVulpesBlocks\.(blockStructureBlock|blockAdvStructureBlock)\b', t): jref[m.group(1)] += 1
print("java refs", jref)
