import zipfile, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
jar = zipfile.ZipFile(sys.argv[1]); root = Path(sys.argv[2])
pairs = [l.split() for l in sys.argv[3:]]
for spec in sys.argv[3:]:
    a, v = spec.split("=")
    w1,h1,p1 = decode((root/a).read_bytes(), 4096*4096)
    w2,h2,p2 = decode(jar.read(v), 4096*4096)
    if (w1,h1)!=(w2,h2):
        print(a, v, "size", (w1,h1),(w2,h2)); continue
    op1 = [i for i,p in enumerate(p1) if p[3]>0]; op2=set(i for i,p in enumerate(p2) if p[3]>0)
    same_mask = sum(1 for i in range(len(p1)) if (p1[i][3]>0)==(p2[i][3]>0))/len(p1)
    eq_opaque = sum(1 for i in op1 if p1[i]==p2[i])
    near = sum(1 for i in op1 if p2[i][3]>0 and sum(abs(x-y) for x,y in zip(p1[i][:3],p2[i][:3]))<=24)
    # luminance correlation over shared opaque
    sh=[i for i in op1 if i in op2]
    def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
    import math
    if sh:
        xs=[lum(p1[i]) for i in sh]; ys=[lum(p2[i]) for i in sh]
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys)
        cov=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
        corr = cov/math.sqrt(vx*vy) if vx>0 and vy>0 else float('nan')
    else: corr=float('nan')
    print(f"{a} vs {v}: size={w1}x{h1} opaque_legacy={len(op1)} opaque_vanilla={len(op2)} alpha_mask_agree={same_mask:.3f} exact_rgba_on_opaque={eq_opaque}/{len(op1)} near_rgb={near}/{len(op1)} lum_corr={corr:.3f}")
