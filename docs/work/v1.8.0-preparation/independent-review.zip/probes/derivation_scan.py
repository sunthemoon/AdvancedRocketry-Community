import zipfile, sys, csv, fnmatch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
jar, tree, up = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
z = zipfile.ZipFile(jar)
van = {}
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/") and n.endswith(".png"):
        try: w,h,px = decode(z.read(n), 256*256)
        except Exception: continue
        van.setdefault((w,h), []).append((n, px))
rules = list(csv.DictReader(open(tree/"docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"]+"#"+r["order"]
root = up/"src/main/resources/assets/advancedrocketry"
out=[]
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\","/")
    try: w,h,px = decode(f.read_bytes(), 256*256)
    except Exception: continue
    op = [i for i,p in enumerate(px) if p[3]>0]
    if len(op) < 16: continue
    best=None
    for n, vpx in van.get((w,h), []):
        eq = sum(1 for i in op if px[i]==vpx[i])
        if best is None or eq > best[0]:
            best=(eq,n)
    if best and best[0]/len(op) >= 0.15:
        out.append((best[0]/len(op), a, best[1], best[0], len(op), handling(a)))
for r,a,n,eq,tot,hd in sorted(out, reverse=True):
    print(f"{r:5.2f} {eq:5d}/{tot:<5d} {hd:14s} {a}  ==  {n}")
