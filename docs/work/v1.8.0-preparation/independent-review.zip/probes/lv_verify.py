import hashlib, sys
from pathlib import Path
tsv = Path(sys.argv[1]); d = Path(sys.argv[2])
ok=bad=0
for line in tsv.read_text(encoding="utf-8").splitlines():
    p, sha = line.split("\t")
    if "/textures/" not in p: continue
    name = p.replace("src/main/resources/assets/libvulpes/textures/","").replace("/","__")
    data = (d/name).read_bytes()
    g = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
    if g == sha: ok+=1
    else: bad+=1; print("BAD", p)
print("git blob verified", ok, "bad", bad)
