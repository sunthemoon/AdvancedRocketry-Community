import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
mode = sys.argv[2]
if mode == "commit":
    print(d.get("sha"), d["commit"]["author"], repr(d["commit"]["message"][:300]), [p["sha"] for p in d["parents"]])
elif mode == "commits":
    for c in d:
        print(c["sha"], c["commit"]["author"]["date"], repr(c["commit"]["message"][:120]))
elif mode == "branch":
    print(d.get("name"), d["commit"]["sha"], d["commit"]["commit"]["author"]["date"])
elif mode == "repo":
    print(d.get("full_name"), d.get("license"), d.get("default_branch"), d.get("fork"), d.get("parent", {}).get("full_name") if d.get("parent") else None)
elif mode == "tree":
    print(len(d.get("tree", [])), d.get("truncated"))
