import csv, hashlib, sys
from pathlib import Path
tree = Path(sys.argv[1]); up = Path(sys.argv[2])
hashes = {}
for name, col in (("java-files.csv","path"),("assets.csv","source_path")):
    with (tree/"legacy-manifest"/name).open(encoding="utf-8", newline="") as h:
        for row in csv.DictReader(h):
            hashes[row[col]] = row["sha256"]
ok = bad = missing = 0
for p, d in hashes.items():
    f = up / p
    if not f.exists():
        missing += 1; print("MISSING", p); continue
    if hashlib.sha256(f.read_bytes()).hexdigest() == d: ok += 1
    else: bad += 1; print("DIFF", p)
print("manifest entries", len(hashes), "ok", ok, "bad", bad, "missing", missing)
allfiles = [str(x.relative_to(up)).replace("\\","/") for x in up.rglob("*") if x.is_file()]
extra = [x for x in allfiles if x not in hashes]
print("files in tree", len(allfiles), "not in manifest", len(extra))
for x in sorted(extra): print("  EXTRA", x)
