import re, json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[3])
from tools.audit.inventory_v180_content import strip_java_comments
up = Path(sys.argv[1]); inv = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
J = up/"src/main/java/zmaster587/advancedRocketry"
ev = [u for u in inv["units"] if u["kind"]=="event"]
by = {}
for u in ev: by.setdefault(u["source"].rsplit("/",1)[-1][:-5], []).append(u["legacy_name"])
for f in sorted(J.rglob("*.java")):
    t = strip_java_comments(f.read_text(encoding="utf-8", errors="replace"))
    n = len(re.findall(r"@SubscribeEvent", t))
    if n:
        stem = f.stem
        print(f"{str(f.relative_to(J)):60s} subscribe={n:3d} inventoried={len(by.get(stem,[]))}")
