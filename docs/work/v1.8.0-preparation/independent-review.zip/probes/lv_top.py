import zipfile, sys, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
z = zipfile.ZipFile(sys.argv[1]); d = Path(sys.argv[2])
van = []
for n in z.namelist():
    if n.startswith("assets/minecraft/textures/item/") and n.endswith(".png"):
        try: w,h,px = decode(z.read(n), 16*16)
        except Exception: continue
        if (w,h)==(16,16): van.append((n, px))
def lum(p): return 0.299*p[0]+0.587*p[1]+0.114*p[2]
for name in sys.argv[3:]:
    w,h,px = decode((d/name).read_bytes())
    op = [i for i,p in enumerate(px) if p[3]>0]
    res=[]
    for n, vpx in van:
        vop = set(i for i,p in enumerate(vpx) if p[3]>0)
        if not vop: continue
        inter = sum(1 for i in op if i in vop); iou = inter/len(set(op)|vop)
        sh = [i for i in op if i in vop]
        if len(sh)<8: continue
        xs=[lum(px[i]) for i in sh]; ys=[lum(vpx[i]) for i in sh]
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys); vx=sum((x-mx)**2 for x in xs); vy=sum((y-my)**2 for y in ys)
        corr = sum((x-mx)*(y-my) for x,y in zip(xs,ys))/math.sqrt(vx*vy) if vx>0 and vy>0 else 0
        res.append((iou*max(corr,0), iou, corr, n))
    res.sort(reverse=True)
    print(name, "opaque", len(op), " | ".join(f"{n.split('/')[-1]} IoU={i:.2f} r={c:.2f}" for s,i,c,n in res[:3]))
