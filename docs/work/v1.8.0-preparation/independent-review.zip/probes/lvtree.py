import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
print("entries", len(d["tree"]), "truncated", d.get("truncated"))
blobs = [t for t in d["tree"] if t["type"]=="blob"]
import collections
for t in blobs:
    p = t["path"]
    if not p.startswith("src/main/resources/assets/") and not p.startswith("src/main/java"):
        print("ROOT", p)
assets = [t["path"] for t in blobs if t["path"].startswith("src/main/resources/assets/")]
print("asset files", len(assets))
c = collections.Counter("/".join(p.split("/")[4:7]) for p in assets)
for k,v in sorted(c.items()): print(f"  {v:4d} {k}")
open(sys.argv[2],"w",encoding="utf-8").write("\n".join(t["path"]+"\t"+t["sha"] for t in blobs))
