import zlib, struct
class PngError(Exception): pass
def decode(data, max_pixels=512*512):
    if data[:8] != b"\x89PNG\r\n\x1a\n": raise PngError("sig")
    pos = 8; idat = []; plte = None; trns = None
    while pos < len(data):
        ln, typ = struct.unpack(">I4s", data[pos:pos+8]); body = data[pos+8:pos+8+ln]; pos += 12+ln
        if typ == b"IHDR":
            w,h,bd,ct,cm,fm,il = struct.unpack(">IIBBBBB", body)
        elif typ == b"PLTE": plte = body
        elif typ == b"tRNS": trns = body
        elif typ == b"IDAT": idat.append(body)
        elif typ == b"IEND": break
    if il != 0: raise PngError("interlaced")
    if w*h > max_pixels: raise PngError("large")
    raw = zlib.decompress(b"".join(idat))
    ch = {0:1,2:3,3:1,4:2,6:4}[ct]
    if bd not in (1,2,4,8,16): raise PngError("bd")
    bpp_bits = ch*bd
    stride = (w*bpp_bits+7)//8
    bpp = max(1, bpp_bits//8)
    out = bytearray(); prev = bytearray(stride); i = 0
    for y in range(h):
        f = raw[i]; line = bytearray(raw[i+1:i+1+stride]); i += 1+stride
        if f == 1:
            for x in range(bpp, stride): line[x] = (line[x]+line[x-bpp]) & 255
        elif f == 2:
            for x in range(stride): line[x] = (line[x]+prev[x]) & 255
        elif f == 3:
            for x in range(stride):
                a = line[x-bpp] if x>=bpp else 0
                line[x] = (line[x] + ((a+prev[x])>>1)) & 255
        elif f == 4:
            for x in range(stride):
                a = line[x-bpp] if x>=bpp else 0; b = prev[x]; c = prev[x-bpp] if x>=bpp else 0
                p = a+b-c; pa=abs(p-a); pb=abs(p-b); pc=abs(p-c)
                pr = a if (pa<=pb and pa<=pc) else (b if pb<=pc else c)
                line[x] = (line[x]+pr) & 255
        out += line; prev = line
    # to RGBA list
    px = []
    def samples(row):
        if bd == 8: return list(row)
        if bd == 16: return [row[k] for k in range(0,len(row),2)]
        vals=[]; per=8//bd; mask=(1<<bd)-1
        for byte in row:
            for s in range(per): vals.append((byte >> (8-bd*(s+1))) & mask)
        return vals
    for y in range(h):
        row = out[y*stride:(y+1)*stride]; s = samples(row)
        for x in range(w):
            if ct == 6: r,g,b,a = s[4*x:4*x+4]
            elif ct == 2:
                r,g,b = s[3*x:3*x+3]; a=255
            elif ct == 0:
                v = s[x]; v = v*255//((1<<bd)-1) if bd<8 else v; r=g=b=v; a=255
            elif ct == 4:
                v,a = s[2*x:2*x+2]; r=g=b=v
            elif ct == 3:
                idx = s[x]; r,g,b = plte[3*idx:3*idx+3]; a = trns[idx] if trns and idx < len(trns) else 255
            px.append((r,g,b,a))
    return w, h, px
