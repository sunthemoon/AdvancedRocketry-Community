import sys, zlib, struct
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pngdecode import decode
def encode(w, h, px, path):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w): raw += bytes(px[y*w+x])
    def chunk(t, b): return struct.pack(">I", len(b)) + t + b + struct.pack(">I", zlib.crc32(t+b) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
    Path(path).write_bytes(data)
out = sys.argv[1]; scale = int(sys.argv[2]); files = sys.argv[3:]
imgs = [decode(Path(f).read_bytes(), 4096*4096) for f in files]
H = max(h for w,h,_ in imgs)*scale; Wd = sum(w for w,_,_ in imgs)*scale + 8*(len(imgs)-1)
canvas = [(255,0,255,255)]*(Wd*H)
ox = 0
for w,h,px in imgs:
    for y in range(h*scale):
        for x in range(w*scale):
            p = px[(y//scale)*w + x//scale]
            # composite on dark grey
            a = p[3]/255; bg = 60
            canvas[y*Wd + ox + x] = (int(p[0]*a+bg*(1-a)), int(p[1]*a+bg*(1-a)), int(p[2]*a+bg*(1-a)), 255)
    ox += w*scale + 8
encode(Wd, H, canvas, out)
