import sys, zipfile
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
root = sys.argv[2]; z = zipfile.ZipFile(sys.argv[3])
sheets = [(lab, n, vd.Image(*vd.decode_png(z.read(n)))) for lab, n in [("1.12.2", "assets/minecraft/textures/gui/advancements/tabs.png"), ("1.12.2", "assets/minecraft/textures/gui/container/creative_inventory/tabs.png")]]
for a in ("textures/gui/buttons/tabtemplate.png", "textures/gui/buttons/tabwarp.png", "textures/gui/buttons/tabplanet_hover.png", "textures/gui/buttons/tabguidance.png", "textures/gui/buttons/buttonautoeject_hover.png"):
    im = vd.Image(*vd.decode_png(open(root + "/" + a, "rb").read()))
    res = vd.analyse_images([(a, im)], sheets)
    p = vd.SubImageProbe(im.transformed(5))
    print(a, im.width, "x", im.height, "colours", im.colours, "->", res.get(a, (None, "CLEAR", {}))[1], {k: v for k, v in res.get(a, (None, "CLEAR", {}))[2].items() if k in ("method", "sub", "colours", "orientation")}, "| anchors(o=5):", [x[2] for x in p.anchors])
