import json, sys, csv, fnmatch
d = json.load(open(sys.argv[1], encoding="utf-8"))
rules = list(csv.DictReader(open(sys.argv[2], encoding="utf-8")))
def handling(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r["handling"] + "#" + r["order"]
names = sys.argv[3:]
print("counts", d["counts"], "schema", d["schema"])
for e in d["assets"]:
    a = e["asset"]
    if (names and any(fnmatch.fnmatchcase(a, n) for n in names)) or (not names and e["verdict"] != "CLEAR"):
        b = e.get("best", {})
        print(f'{e["verdict"]:11s} {handling(a):14s} {a:52s} {b.get("method","")}:{b.get("vanilla","")[:62]} o={b.get("orientation","")} s={b.get("scale","")} ov={b.get("overlap","")} c={b.get("colours","")} sub={b.get("sub","")} iou={b.get("iou","")} rk={b.get("rank","")}')
