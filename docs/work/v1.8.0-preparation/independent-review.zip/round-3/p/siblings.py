"""IMPORT legacy PNGs that are recolours/copies of legacy PNGs whose derivation verdict is HIT or SUSPECT (ADR-061 §4.8 inheritance)."""
import sys, json, csv, fnmatch
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from tools.audit import vanilla_derivation as vd
tree = Path(sys.argv[1]); root = Path(sys.argv[2])
d = json.load(open(tree / "docs/work/v1.8.0-vanilla-derivation.json", encoding="utf-8"))
verdict = {e["asset"]: e["verdict"] for e in d["assets"]}
rules = list(csv.DictReader(open(tree / "docs/work/v1.8.0-asset-plan.csv", encoding="utf-8")))
def rule(a):
    for r in rules:
        if fnmatch.fnmatchcase(a, r["pattern"]): return r
imgs = {}
for f in sorted(root.rglob("*.png")):
    a = str(f.relative_to(root)).replace("\\", "/")
    try: imgs[a] = vd.Image(*vd.decode_png(f.read_bytes()))
    except Exception: pass
flagged = {a: im for a, im in imgs.items() if verdict.get(a) in ("HIT", "SUSPECT")}
out = []
for a, im in imgs.items():
    r = rule(a)
    if r["handling"] != "IMPORT": continue
    best = None
    for b, other in flagged.items():
        if (other.width, other.height) != (im.width, im.height): continue
        for o in range(8):
            v = im.transformed(o) if o else im
            if (v.width, v.height) != (other.width, other.height): continue
            m = vd.compare(v, other)
            if not m: continue
            lv = vd.verdict({k: round(x, 4) for k, x in m.items()})
            key = (vd.SEVERITY[lv], m["rank"], m["overlap"])
            if best is None or key > best[0]: best = (key, lv, b, o, m)
    if best and best[1] != "CLEAR":
        _, lv, b, o, m = best
        out.append(f"{lv:8s} IMPORT#{r['order']:>4s} {a:50s} ~ legacy {b} ({verdict[b]}, {rule(b)['handling']}) o={o} ov={m['overlap']:.3f} c={m['colours']} iou={m['iou']:.3f} rk={m['rank']:.3f}")
print("\n".join(sorted(out)) or "none"); print("count", len(out))
