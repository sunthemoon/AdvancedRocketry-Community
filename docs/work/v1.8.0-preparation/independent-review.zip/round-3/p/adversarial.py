"""Adversarial calibration cases for tools/audit/vanilla_derivation.py (round 3).

Each case is a plausible way legacy art is derived from a vanilla sheet. The script runs the
tool's own analyse_images() and prints the verdict per case; a derivation that is not HIT or
SUSPECT is a false negative.
"""
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
from tools.audit.vanilla_derivation import Image, analyse_images  # noqa: E402


def noise(width, height, seed, colours=24):
    state = seed
    palette = []
    for _ in range(colours):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        palette.append((state & 0xFF, (state >> 8) & 0xFF, (state >> 16) & 0xFF, 255))
    pixels = []
    for _ in range(width * height):
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        pixels.append(palette[state % colours])
    return pixels


def crop(pixels, width, x0, y0, w, h):
    return [pixels[(y0 + y) * width + x0 + x] for y in range(h) for x in range(w)]


sheet_px = noise(128, 128, seed=11)
texture_px = noise(16, 16, seed=7)
vanilla = [("v", "sheet.png", Image(128, 128, sheet_px)), ("v", "texture.png", Image(16, 16, texture_px))]

base = crop(sheet_px, 128, 40, 30, 24, 24)
cases = {}

# 1. crop with one pixel repainted in a colour that does not occur in the sheet
one_new = list(base)
one_new[5 * 24 + 5] = (1, 2, 3, 255)
cases["crop + 1 new-colour pixel"] = Image(24, 24, one_new)

# 2. crop with a small icon painted on top (16 pixels of 4 new colours), like tabwarp over tabtemplate
icon = list(base)
for i, (x, y) in enumerate([(x, y) for y in range(10, 14) for x in range(10, 14)]):
    icon[y * 24 + x] = ((i * 40) % 250 + 3, 7, 9, 255)
cases["crop + 4x4 new-colour icon"] = Image(24, 24, icon)

# 3. crop upscaled x2
up = [base[(y // 2) * 24 + x // 2] for y in range(48) for x in range(48)]
cases["crop upscaled x2"] = Image(48, 48, up)

# 4. vanilla 16x16 texture embedded in a larger legacy sheet (64x64) at an offset
big = noise(64, 64, seed=999, colours=10)
for y in range(16):
    for x in range(16):
        big[(y + 20) * 64 + x + 24] = texture_px[y * 16 + x]
cases["vanilla texture inside a 64x64 legacy sheet"] = Image(64, 64, big)

# 5. vanilla 16x16 texture inside a 256x256 legacy GUI sheet
gui = [(198, 198, 198, 255)] * (256 * 256)
for y in range(16):
    for x in range(16):
        gui[(y + 100) * 256 + x + 60] = texture_px[y * 16 + x]
cases["vanilla texture inside a 256x256 legacy sheet"] = Image(256, 256, gui)

# 6. crop with every channel shifted by +1 (a re-save with a colour profile)
cases["crop, every channel +1"] = Image(24, 24, [(min(r + 1, 255), min(g + 1, 255), min(b + 1, 255), a)
                                                  for r, g, b, a in base])

# 7. whole texture shifted by one pixel (wrap-around)
cases["texture shifted by 1 px"] = Image(16, 16, [texture_px[y * 16 + (x + 1) % 16] for y in range(16) for x in range(16)])

# 8. 40% of a texture copied, rest repainted with new colours
partial = [p if (i % 5) < 2 else (i % 7 + 1, 0, 200, 255) for i, p in enumerate(texture_px)]
cases["40% of the texture copied"] = Image(16, 16, partial)

# 9. recoloured crop (documented limit)
cases["recoloured crop"] = Image(24, 24, [(int((0.299 * r + 0.587 * g + 0.114 * b) * 0.5) + 20, 30, 40, a)
                                            for r, g, b, a in base])

# 10. crop of 70 x 70 (above the 64 px sub-image limit)
cases["70x70 crop (over the sub-image size limit)"] = Image(70, 70, crop(sheet_px, 128, 10, 10, 70, 70))

results = analyse_images(list(cases.items()), vanilla)
missed = 0
for name in cases:
    level = results.get(name, (None, "CLEAR", {}))[1]
    record = results.get(name, (None, "CLEAR", {}))[2]
    flag = "" if level in ("HIT", "SUSPECT") else "   <-- missed"
    missed += level == "CLEAR"
    print(f"{level:8s} {name:48s} {dict((k, record[k]) for k in ('method', 'sub', 'overlap', 'colours', 'rank') if k in record)}{flag}")
print(f"missed {missed} of {len(cases)}")
