# C7 independent review, round 2: the fixes in 2e0dbb7 and the revision-4 amendments

Reviewer: the same independent, read-only reviewer as round 1
(`../REVIEW.md`). Date: 2026-10-01.

## 1. Scope and method

- **Reviewed:** commit `2e0dbb7` ("answer the first C7 independent review"),
  diffed against `d15dfcc`. The tree was extracted with `git archive 2e0dbb7` into
  `round-2/tree/`, and file:line references below are relative to
  `round-2/tree/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.
- **C8a-2 (`d15dfcc`):** checked only where it touches C7 files. The
  `AdvancedRocketryCommunity` wiring adds the resource tables manager and its
  reload listener. `SatelliteCommands` gains `mission verify <id>`, which is
  read-only, returns "not found" on a blocked registry, and has no grammar
  conflict with `mission <mission_id>`. I found nothing affecting C7.
- **Read:**
  - the full main-source diff;
  - `SatelliteRegistryFixture`, all seven new GameTests in
    `SatelliteReviewGameTests`, and the new `SurveyScanJobTest` case;
  - the adapter-test orphan component;
  - the dispositions in `docs/work/v1.6.0-c7-review/VERIFICATION.md`;
  - the rewritten ADR-049 "Proposed amendment — revision 4 (C7)" (items 1–11)
    and the new ADR-050 "Proposed amendment — revision 4 (C7)" (items 1–5).
- **Checked to confirm specific findings:**
  - the terminal assembly path, the payload runtime and default payload mapping,
    and the adapter payload fixture and GameTests;
  - that `CheckedSavedDataFile` uses the `.arce-pending` sibling the flush-failure
    test blocks (line 36).
- **Ran in `round-2/tree`** (JDK 17.0.7; log `round-2/gradle-test.log`):
  `./gradlew test --tests '*Satellite*' --tests '*SurveyScan*' --tests '*NetworkProtocolPin*' --tests '*Resource*' --offline --no-daemon`.
  Result: BUILD SUCCESSFUL, 43 suites / 118 tests, 0 failures, 0 errors.
- **Not run:** GameTests. The coordinator reports 278 passing, including the
  two fixture batches.
- Nothing in the repository was modified.

## 2. Round-1 findings: status

| ID | Status | Evidence |
|---|---|---|
| C7-H1 replay without the barrier flush | **Resolved** | `satellite/service/SatelliteKindLifecycle.java:55-68`: a matching replay flushes a dirty registry before `IDEMPOTENT`. A failed flush throws, is caught (`:109-112`) and answers `UNSUPPORTED_DATA`, so the package stays. "Not dirty" implies durable, because `AtomicSavedData` clears the dirty flag only after a successful replace. `aFailedLaunchFlushKeepsThePackageUntilTheReplayIsDurable` presses Launch twice while the pending file is blocked (package kept both times), then shows that the durable replay consumes the package and that the satellite is on disk. That also tests the barrier-before-extraction order |
| C7-M1 receiver crash on a blocked registry | **Resolved** | `SolarLinks.check` returns "unavailable, output 0" and `release` logs and returns when `!operational()` (`satellite/service/SolarLinks.java:53-55,123-127`). The manager wraps check and release (`SatelliteManager.java:464-485`). The scheduler returns early on a blocked registry. The blocked batch covers a receiver check, breaking a receiver (block entity gone, chip dropped), a scan, `blank-chip` and a launch |
| C7-M2 view pacing counted broadcasts | **Resolved** | `satellite/terminal/SatelliteTerminalViews.java:48-63` paces on `server.getTickCount()`, at most one compose per 5 ticks whatever the clicks. It still composes on the first tick after opening and picks up a pending change at the next allowed tick. The GameTest checks 50 calls in one tick twice, then exactly one more send after 5 ticks |
| C7-M3 scan tick crash and long biome IDs | **Resolved** | Each job has its own try/catch (`satellite/scan/SurveyScanService.java:137-152`), and the manager guards the scan tick (`SatelliteManager.java:85-90`). IDs longer than 128 characters become `OTHER` (`satellite/scan/SurveyScanJob.java:153`), with a unit test |
| C7-M4 untested behaviour | **Resolved** | Tests now cover: failed-flush replay; blocked registry; view pacing; unloaded-chunk scan (all `UNKNOWN`, `hasChunk` false before and after); chip `use()` driven by the production tick; builder `DEFINITION_NOT_FOUND` via the orphan primary and `OUTPUT_BLOCKED`; a stale builder menu refused by generation. Residual gaps, not blocking: the terminal's `clickMenuButton`/`stillValid` path is still exercised only through `handleButton`, and "no chunk tickets" is inferred from `hasChunk`, which is adequate because the reader is `getChunkNow`-only |
| C7-M5 deviations only in verification notes | **Resolved** | The deviations are now written into ADR-049 revision-4 items 8–11 and ADR-050 revision-4 items 1–5. The verdicts on that text are in §4 |
| C7-L1 `blank-chip` guards | **Resolved** | The command refuses while the registry is blocked, reads the raw `satellite_id` of an undecodable chip, and refuses if that satellite is registered (`satellite/command/SatelliteCommands.java:205-217`). GameTests cover both cases |
| C7-L2 component catalog not cleared | **Resolved** | `AdvancedRocketryCommunity.java:365-366` |
| C7-L3 builder data stat truncated | **Resolved** | The stat is split into two halves and the menu data count is now 12. Both sides use the same count, and the screen reads only accessors |
| C7-L4 launch did not re-check the primary's definition | **Resolved** | `SatelliteKindLifecycle.java:75-82`, recorded in item 9 |
| C7-L5 refused decommission flushed | **Resolved** | Only a removal flushes (`SatelliteKindLifecycle.java:152-155`). The UI confirmation is deferred to the v1.8 UI batch, which I accept |
| C7-L6 target selection carried over | **Resolved, with a regression** | See R2-L1 |
| C7-L7 ambiguous codes | **Resolved (documented)** | ADR-049 revision-4 item 7 |
| C7-L8 class sizes and layering | **Not resolved; deferral accepted** | Scheduled for C8a-1 per the implementation-log plan |
| C7-L9 roots skip slot checks | **Partially resolved** | The receiver root now requires the control-chip *item* only. Item 7's text says "only bound chips of `solar` satellites … (also when a root loads)"; see R2-L2. I accept the rationale for leaving the builder unchanged: a data-pack change must not quarantine the root, and assembly re-checks every slot |
| C7-L10 scan duration vs Level height | **Resolved (documented)** | Item 6 |
| C7-L11 automation inserted chips into the builder | **Resolved** | The automation handler refuses slot 8 (`satellite/builder/SatelliteBuilderBlockEntity.java:424,440`), with a GameTest |
| C7-L12 operator unlink and receiver access | **Resolved (documented)** | Item 7 |

## 3. Regressions and new problems

No Critical, High or Medium problems. I found four Lows and one note.

### R2-L1 — Terminal assembly with an ADR-029 payload loses the chosen target

- **Where:** `satellite/terminal/SatelliteTerminalBlockEntity.java:338-348` (the
  new `inventoryChanged` reset) together with `assemble()` (`:202-206`).
- **Scenario:**
  1. The player inserts a third-party ADR-029 payload item P, which maps to
     definition X, and a blank chip. They select X's third target (index 2), then
     press Assemble.
  2. `assemble()` extracts the last P before it writes the bound chip. For that
     moment `selectedDefinition()` sees a blank chip and an empty payload slot, so
     it returns the default `data_satellite`, which is not X. The reset sets the
     index to 0.
  3. `setStackInSlot(chip bound to X)` then changes the definition back to X, and
     the index is reset to 0 again.
- **Effect:** before and after the intent the definition is X, yet the selection
  is lost. Launch then starts the first data mission at X's first target unless
  the player notices and re-selects.
- **Scope:** the built-in data-storage unit maps to `data_satellite`, so it is not
  affected. No test covers selection before a payload assembly; the adapter
  payload GameTests never press the target buttons.
- **Fix:** write the bound chip before extracting the payload, so the chip keeps
  selecting X throughout. Alternatively, suspend the reset during `assemble()`
  and compare the definition once afterwards. Add an adapter-test GameTest:
  select index 2, assemble, and assert the index is still 2.

### R2-L2 — Item 7's load rule is stronger than the code

- ADR-049 revision-4 item 7 says only bound chips of `solar` satellites fit "also
  when a root loads".
- `satellite/receiver/MicrowaveReceiverInventory.java:98-99` checks only
  `stack.is(SATELLITE_CONTROL_CHIP)`. A root holding a blank or non-solar chip
  therefore loads; the chip then shows as `UNAVAILABLE`, which is benign.
- **Fix:** use `validChip(stack)` in `loadValidated`, or reword the item to
  "only control chips load; others show as unavailable".

### R2-L3 — Item 9 lists refusals as if exhaustive

- A launch can also answer:
  - `IDENTITY_CONFLICT` (the package can then never be consumed);
  - `UNSUPPORTED_DATA` (flush failure or blocked registry);
  - `CATALOG_UNAVAILABLE`;
  - `UNAUTHORIZED`.
- **Fix:** say "every answer other than `SUCCESS`/`IDEMPOTENT` keeps the package",
  and name `IDENTITY_CONFLICT` explicitly.

### R2-L4 — A receiver broken while the registry is blocked is not fully documented

- `SolarLinks.release` removes the receiver-directory entry before it checks
  `operational()`.
- After the registry is repaired, the links of a receiver broken during the
  blocked period point to a receiver that can never be confirmed missing, so only
  `/arce satellite admin unlink` clears them.
- The behaviour is acceptable, and the `ARCE_SATELLITE_RECEIVER_RELEASE_SKIPPED`
  warning identifies the case. Item 7 (or ADR-050 item 4) should say it.

### Note — builder menu data layout changed without a version marker

- The builder menu data grew from 11 to 12 slots, but the menu open-data format
  version (1) and the channel protocol are unchanged.
- A client built from an older dev build against a newer server would fail on
  data index 11.
- This is harmless before release. Mention it if dev builds are distributed.

### Checked and found sound

- **Replay flush:** it cannot consume a package early, and it adds a flush only
  to replays, which are rare.
- **Target reset during `load()`:** `resetLoadedState()` and `loadValidated()`
  trigger resets, but `load()` then sets `targetDefinition` and restores the
  persisted index. The carry path goes through the same `load()`.
- **Registry fixture:**
  - It is batch-scoped and serial.
  - It restores the original object after the batch and saves it back over the
    file the flush-failure batch overwrote.
  - The blocked fixture is never dirtied, so autosave cannot write the future
    payload.
  - The obstacle directory is removed in a `finally`.
  - During those batches, receivers left from earlier batches degrade to
    `UNAVAILABLE` and recover afterwards.
- **View pacer:** there is no integer-overflow issue in practice, and the pacer
  still sends on open.
- **Scan catch:** a dropped job is not refunded, as item 5 now states.
- **Manager catch around the receiver check:** partial link claims made before
  an exception stay consistent and are re-read at the next check.

## 4. Verdicts on the revision-4 amendments

### ADR-049 revision 4

| # | Item | Verdict | Reason or change needed |
|---|---|---|---|
| 1 | Builder charge slot and automation rules (never slot 8) | **Accept** | Implemented and tested |
| 2 | View contents; kind from the chip (`data` if empty); 8,405 B worst case; pace of 5 **server ticks** | **Accept** | Implemented and tested |
| 3 | `blank-chip`: raw ID read, refused when the satellite is registered, refused while the registry is blocked | **Accept** | Implemented and tested |
| 4 | `DEFINITION_NOT_FOUND` for a data start with a non-`data` chip | **Accept** | — |
| 5 | Scan request codes and order; no refund for a cancelled or failed job | **Accept** | Matches the code, including the new catch |
| 6 | Scan reading; long IDs become `OTHER`; COMMON config; duration scales with Level height | **Accept** | — |
| 7 | Receiver links, missing/unknown rules, operator unlink, code reuse, blocked-registry behaviour, no access control | **Accept with changes** | Align the "also when a root loads" rule with the code (R2-L2). Add that a receiver broken while the registry is blocked leaves links only an operator can clear (R2-L4) |
| 8 | Operator decommission | **Accept** | Behaves like the owner path, and the audit line records `by=`. An operator still cannot use another owner's terminal (only the cancel button is exempt), which is consistent with "at a terminal with its chip" |
| 9 | Launch refusals; the package is kept | **Accept with changes** | Editorial: make the list non-exhaustive and name `IDENTITY_CONFLICT` and `UNSUPPORTED_DATA` (R2-L3) |
| 10 | Replay durability | **Accept** | Implemented and tested |
| 11 | Target selection restarts when the chip or payload selects another definition | **Accept with changes** | Define the comparison over a whole intent: an assembly that ends on the same definition keeps the selection. Fix the transient reset (R2-L1) |

### ADR-050 revision 4

| # | Item | Verdict | Reason or change needed |
|---|---|---|---|
| 1 | The save epoch advances only after a changed write | **Accept** | I re-verified it against ADR-051 §6–§7: `save_epoch > start_epoch` and `ack_epoch < E` still mean "durable". The invariant depends on every registry mutation calling `changed()`. Keep that as a review rule for C8, or add a unit test that each new mutating registry API advances the epoch on the next write |
| 2 | Counters, link index and queues derived on load, not persisted | **Accept** | — |
| 3 | `target_body` required (data target; system root for survey/asteroid; the gas giant for gas missions) | **Accept** | Consistent with §11 ("a craft's system is recomputed at each start") and with the discovery-evidence exemption, which applies only to `data` missions. C8b must supply the field for every kind |
| 4 | Blocked registry: the scheduler does nothing; launches and scans are refused without consuming anything; receivers produce nothing | **Accept** | Implemented and tested. The list is illustrative: decommission, unlink, `blank-chip` and `verify` are also refused or read-only |
| 5 | Per-player intent rate limits delivered with the C8a limits | **Accept** | This defers a v1.6 obligation within the version, not beyond it. It must be closed in C8a before any v1.6 Gate evidence is produced |

## 5. Overall verdict for closing C7

**Accept. C7 may close.** Every round-1 Critical, High and Medium finding is
resolved and tested. Of the Lows, one is partial (L9) and one is scheduled (L8);
both dispositions are acceptable. The fixes introduce only Low issues.

Before, or in, the commit that marks ADR-049 and ADR-050 revision 4 accepted:

1. Apply the editorial changes to ADR-049 items 7, 9 and 11 (R2-L2, R2-L3, R2-L4
   and the item-11 wording).
2. Fix R2-L1: set the bound chip before extracting the payload, and add its
   GameTest. This is cheap and restores behaviour the L6 fix broke. If it is not
   done in C7, record it as a tracked C8a-1 item.

This review is not a Gate, candidate or release decision.
