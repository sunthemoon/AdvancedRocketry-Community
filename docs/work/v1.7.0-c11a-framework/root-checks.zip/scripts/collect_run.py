"""Collect a slice run: JUnit XML and summary, GameTest log, hashes of every implementation file changed since the
slice base (the slice spans several commits), artifact hashes, and a class-by-class API classifier comparison with
the baseline's classifier."""
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
BASELINE_API = Path('D:/GitHub/arce-v170-apibase/build/libs/advancedrocketry-community-1.20.1-1.6.0-dev-api.jar')
sha = lambda b: hashlib.sha256(b).hexdigest()

base = (E / 'base-commit.txt').read_text().strip()
junit = E / 'full-junit'
junit.mkdir()
tests = failures = errors = skipped = suites = 0
for f in sorted((ROOT / 'build/test-results/test').glob('*.xml')):
    shutil.copyfile(f, junit / f.name)
    r = ET.parse(f).getroot()
    suites += 1
    tests += int(r.get('tests')); failures += int(r.get('failures')); errors += int(r.get('errors'))
    skipped += int(r.get('skipped'))
summary = {'suites': suites, 'tests': tests, 'failures': failures, 'errors': errors, 'skipped': skipped}
(E / 'junit-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

changed = subprocess.check_output(['git', 'diff', '--name-only', base, 'HEAD'], cwd=ROOT).decode().splitlines()
files = {}
for path in changed:
    if path.startswith('docs/') or path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/'):
        continue
    if (ROOT / path).is_file():
        files[path] = sha((ROOT / path).read_bytes())
(E / 'implementation-files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
(E / 'post-run-changes.json').write_text('{"files": []}\n', encoding='utf-8')

artifacts = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append({'name': jar.name, 'bytes': jar.stat().st_size, 'sha256': sha(jar.read_bytes())})
(E / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}, indent=2) + '\n', encoding='utf-8')

for name in ('latest.log', 'debug.log'):
    log = ROOT / 'run/gametest/logs' / name
    if log.exists():
        shutil.copyfile(log, E / ('gametest-' + name))


def classes(jar):
    with zipfile.ZipFile(jar) as archive:
        return {n: sha(archive.read(n)) for n in archive.namelist() if n.endswith('.class')}


current = classes(next((ROOT / 'build/libs').glob('*-api.jar')))
baseline = classes(BASELINE_API)
rows = []
for name in sorted(set(current) | set(baseline)):
    a, b = current.get(name), baseline.get(name)
    rows.append({'class': name, 'baseline_sha256': b, 'current_sha256': a,
                 'status': 'added' if b is None else 'removed' if a is None else 'identical' if a == b else 'changed'})
result = {'baseline': str(BASELINE_API), 'baseline_sha256': sha(BASELINE_API.read_bytes()), 'classes': rows,
          'changed': [r['class'] for r in rows if r['status'] == 'changed'],
          'added': [r['class'] for r in rows if r['status'] == 'added'],
          'removed': [r['class'] for r in rows if r['status'] == 'removed']}
(E / 'api-class-comparison.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(summary, len(files), 'implementation files', [a['name'] for a in artifacts])
print('api changed', result['changed'], 'added', result['added'], 'removed', result['removed'])
