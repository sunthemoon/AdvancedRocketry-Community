import sys,struct,collections
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2]); planet = sys.argv[3]
d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
grid = {}
for region in sorted(d.glob('r.*.mca')):
    rx, rz = map(int, region.name.split('.')[1:3])
    data = region.read_bytes()
    for i in range(1024):
        if struct.unpack('>I', data[i*4:i*4+4])[0] == 0: continue
        cx, cz = rx*32 + (i % 32), rz*32 + (i // 32)
        if not (-20 <= cx <= 20 and -20 <= cz <= 20): continue
        st = regions._decode_chunk(regions._region_chunk(data, cx & 31, cz & 31), cx, cz).get('Status').split(':')[-1]
        grid[(cx,cz)] = st
code = {'full':'F','structure_starts':'s','structure_references':'r','biomes':'b','noise':'n','surface':'u','carvers':'c','liquid_carvers':'l','features':'f','initialize_light':'i','light':'L','spawn':'S','empty':'e'}
for cz in range(-20, 21):
    print('%4d '%cz + ''.join(code.get(grid.get((cx,cz)),'.') for cx in range(-20,21)))
