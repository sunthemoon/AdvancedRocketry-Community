import json,sys,hashlib,subprocess,os
ident=json.load(open(sys.argv[1]))
repo=sys.argv[2]; commit=sys.argv[3]
files=ident['files']
bad=[];missing=[]
for f in files:
    try:
        data=subprocess.run(['git','-C',repo,'show',f'{commit}:{f["path"]}'],capture_output=True,check=True).stdout
    except subprocess.CalledProcessError:
        missing.append(f['path']); continue
    h=hashlib.sha256(data).hexdigest()
    if h!=f['sha256']: bad.append((f['path'],h[:12],f['sha256'][:12]))
print('entries',len(files),'mismatch',len(bad),'missing',len(missing))
for b in bad[:20]: print(' MISMATCH',b)
for m in missing[:10]: print(' MISSING',m)
# files changed since base not listed
changed=subprocess.run(['git','-C',repo,'diff','--name-only',ident['base_commit'],commit],capture_output=True,text=True).stdout.split()
listed={f['path'] for f in files}
print('changed since base',len(changed),'not listed',[c for c in changed if c not in listed][:20])
