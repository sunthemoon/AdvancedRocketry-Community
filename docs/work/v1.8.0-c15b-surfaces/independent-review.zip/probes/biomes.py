import json,glob,sys
root=sys.argv[1]
for f in sorted(glob.glob(root+'/src/generated/v1.4/resources/data/advancedrocketrycommunity/worldgen/biome/*.json')+glob.glob(root+'/src/generated/v1.8/resources/data/advancedrocketrycommunity/worldgen/biome/*.json')):
    d=json.load(open(f))
    print('==',f.split('generated/')[1])
    print({k:d[k] for k in d if k not in ('features',)})
    print(' features', d.get('features'))
