import json,os,sys
gen=os.path.join(sys.argv[1],'src','generated')
for p in ['data/minecraft/tags/blocks/mineable/pickaxe.json','data/minecraft/tags/blocks/needs_iron_tool.json']:
    union=set(); v18=None
    for v in sorted(os.listdir(gen)):
        f=os.path.join(gen,v,'resources',p) if v!='resources' else os.path.join(gen,'resources',p)
        if os.path.isfile(f):
            vals=set(json.load(open(f))['values'])
            if v=='v1.8': v18=vals
            else: union|=vals
    print(p,'v1.8',len(v18),'earlier union',len(union),'missing in v1.8',sorted(union-v18),'new',sorted(v18-union))
