import gzip,struct,sys
raw=gzip.decompress(open(sys.argv[1],'rb').read())
i=raw.find(b'\x04\x00\x04seed')
print('seed', struct.unpack('>q', raw[i+7:i+15])[0] if i>=0 else None)
