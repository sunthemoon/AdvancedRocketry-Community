import sys,json
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2]); planet=sys.argv[3]; cx=int(sys.argv[4]); cz=int(sys.argv[5])
region = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region' / f'r.{cx >> 5}.{cz >> 5}.mca'
chunk = regions._decode_chunk(regions._region_chunk(region.read_bytes(), cx & 31, cz & 31), cx, cz)
print('keys', sorted(chunk.keys()))
print('Status', chunk.get('Status'), 'DataVersion', chunk.get('DataVersion'))
for s in chunk.get('sections', []):
    bp=[e.get('Name').split(':')[1] for e in (s.get('block_states') or {}).get('palette', [])]
    bio=(s.get('biomes') or {}).get('palette', [])
    if bp!=['air'] or True: print(' Y',s.get('Y'),'blocks',bp[:8],'biomes',bio)
print('structures', json.dumps(chunk.get('structures'), default=str)[:300])
