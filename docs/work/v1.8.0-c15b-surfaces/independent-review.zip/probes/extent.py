import sys,struct,collections
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2])
for planet in ('moon', 'mars', 'venus'):
    d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
    full=[]; other=collections.Counter()
    for region in sorted(d.glob('r.*.mca')):
        rx, rz = map(int, region.name.split('.')[1:3])
        data = region.read_bytes()
        for i in range(1024):
            off = struct.unpack('>I', data[i*4:i*4+4])[0]
            if off == 0: continue
            cx, cz = rx*32 + (i % 32), rz*32 + (i // 32)
            try:
                chunk = regions._decode_chunk(regions._region_chunk(data, cx & 31, cz & 31), cx, cz)
            except Exception as e:
                other['err']+=1; continue
            st = chunk.get('Status')
            if st in ('minecraft:full','full'): full.append((cx,cz))
            else: other[st]+=1
    xs=[c[0] for c in full]; zs=[c[1] for c in full]
    print(planet, 'full', len(full), 'x', (min(xs),max(xs)) if xs else None, 'z', (min(zs),max(zs)) if zs else None, dict(other))
