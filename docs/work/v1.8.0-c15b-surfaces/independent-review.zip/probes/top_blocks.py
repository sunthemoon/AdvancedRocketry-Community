import sys,collections,struct
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
sys.path.insert(0, sys.argv[1] + '/../s1/scripts')
world = Path(sys.argv[2]); planet=sys.argv[3]
def section_blocks(states):
    palette=[e.get('Name','?').split(':')[1] for e in states.get('palette',[])]
    if len(palette)==1 or 'data' not in states: return [palette[0]]*4096 if palette else ['air']*4096
    bits=max(4,(len(palette)-1).bit_length()); per=64//bits; mask=(1<<bits)-1
    data=[v & 0xFFFFFFFFFFFFFFFF for v in states['data']]
    return [palette[(data[i//per]>>((i%per)*bits))&mask] for i in range(4096)]
d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
summary=collections.Counter()
rows=[]
for region in sorted(d.glob('r.*.mca')):
    rx, rz = map(int, region.name.split('.')[1:3]); data=region.read_bytes()
    for i in range(1024):
        if struct.unpack('>I', data[i*4:i*4+4])[0] == 0: continue
        cx, cz = rx*32 + (i % 32), rz*32 + (i // 32)
        if not (-14 <= cx <= 14 and -14 <= cz <= 14): continue
        chunk = regions._decode_chunk(regions._region_chunk(data, cx & 31, cz & 31), cx, cz)
        st=chunk.get('Status').split(':')[-1]
        if st not in ('initialize_light','spawn','full','light'): continue
        secs={int(s['Y']):section_blocks(s['block_states']) for s in chunk.get('sections',[]) if s.get('block_states')}
        tops=collections.Counter()
        for x in range(16):
            for z in range(16):
                top='air'
                for Y in sorted(secs, reverse=True):
                    b=secs[Y]
                    found=None
                    for y in range(15,-1,-1):
                        name=b[(y<<8)|(z<<4)|x]
                        if name not in ('air','cave_air'): found=name; break
                    if found: top=found; break
                tops[top]+=1
        biomes=sorted({str(b).split(':')[1] for s in chunk.get('sections',[]) for b in (s.get('biomes') or {}).get('palette',[])})
        key=(st,tuple(biomes),tuple(sorted(tops)))
        summary[key]+=1
        if 'stone' in tops and len(rows)<6: rows.append((cx,cz,st,biomes,dict(tops)))
for k,v in summary.most_common(): print(v,k)
for r in rows: print(r)
