package io.github.sunthemoon.advancedrocketrycommunity.gametest;

import io.github.sunthemoon.advancedrocketrycommunity.AdvancedRocketryCommunity;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.CelestialIds;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.content.PlanetaryContent;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.surface.SurfaceContent;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.surface.worldgen.CraterPiece;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.surface.worldgen.GeodePiece;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.surface.worldgen.VolcanoPiece;
import io.github.sunthemoon.advancedrocketrycommunity.datagen.V180PlanetWorldgen;
import io.github.sunthemoon.advancedrocketrycommunity.material.MaterialContent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** C15bR1 reviewer probes (not part of the reviewed commit): measurements logged as ARCE_REVIEW_PROBE lines. */
@GameTestHolder(AdvancedRocketryCommunity.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ReviewProbeGameTests {
    private static final TicketType<ChunkPos> PROBE = TicketType.create("arce_review_probe",
            Comparator.comparingLong(ChunkPos::toLong));

    private ReviewProbeGameTests() {
    }

    private static void log(String line) {
        AdvancedRocketryCommunity.LOGGER.info("ARCE_REVIEW_PROBE " + line);
    }

    private static Structure.GenerationContext context(ServerLevel level, Structure structure, ChunkPos chunk) {
        ChunkGenerator generator = level.getChunkSource().getGenerator();
        return new Structure.GenerationContext(level.registryAccess(), generator, generator.getBiomeSource(),
                level.getChunkSource().randomState(), level.getServer().getStructureManager(), level.getSeed(), chunk,
                level, structure.biomes()::contains);
    }

    private static List<StructurePiece> pieces(ServerLevel level, ResourceKey<Structure> key, ChunkPos chunk) {
        Structure structure = level.registryAccess().registryOrThrow(Registries.STRUCTURE).getOrThrow(key);
        Optional<Structure.GenerationStub> stub = structure.findValidGenerationPoint(context(level, structure, chunk));
        return stub.map(found -> found.getPiecesBuilder().build().pieces()).orElse(List.of());
    }

    /** P1: real geode generation points on Venus against the noise surface of every lens column. */
    @GameTest(template = "empty", batch = "review_probe_geode", timeoutTicks = 400)
    public static void probeGeodeCover(GameTestHelper helper) {
        ServerLevel venus = helper.getLevel().getServer().getLevel(PlanetaryContent.level(PlanetaryContent.VENUS));
        ChunkGenerator generator = venus.getChunkSource().getGenerator();
        int geodes = 0;
        int breached = 0;
        int thin = 0;
        int minCover = Integer.MAX_VALUE;
        long breachedColumns = 0;
        long columns = 0;
        for (int i = 0; i < 40; i++) {
            for (int j = 0; j < 40; j++) {
                ChunkPos chunk = new ChunkPos(-3_000 + i * 7, 2_000 + j * 7);
                for (StructurePiece piece : pieces(venus, V180PlanetWorldgen.GEODE, chunk)) {
                    GeodePiece geode = (GeodePiece) piece;
                    BoundingBox box = geode.getBoundingBox();
                    int cx = (box.minX() + box.maxX()) / 2;
                    int cy = (box.minY() + box.maxY()) / 2;
                    int cz = (box.minZ() + box.maxZ()) / 2;
                    int r = geode.shape().radius();
                    geodes++;
                    int geodeMin = Integer.MAX_VALUE;
                    for (int dx = -r; dx <= r; dx++) {
                        for (int dz = -r; dz <= r; dz++) {
                            int half = geode.shape().halfHeight(dx, dz);
                            if (half < 0) {
                                continue;
                            }
                            columns++;
                            int surface = generator.getBaseHeight(cx + dx, cz + dz, Heightmap.Types.WORLD_SURFACE_WG,
                                    venus, venus.getChunkSource().randomState()) - 1;
                            int cover = surface - (cy + half);
                            geodeMin = Math.min(geodeMin, cover);
                            if (cover <= 0) {
                                breachedColumns++;
                            }
                        }
                    }
                    minCover = Math.min(minCover, geodeMin);
                    if (geodeMin <= 0) {
                        breached++;
                    } else if (geodeMin < 4) {
                        thin++;
                    }
                }
            }
        }
        log("geode starts=" + geodes + " breaching_surface=" + breached + " cover_1_to_3=" + thin + " min_cover="
                + minCover + " breached_columns=" + breachedColumns + "/" + columns);
        helper.succeed();
    }

    /** P4: real volcano generation points on Venus: cone columns whose ground lies below the box (floating skirt). */
    @GameTest(template = "empty", batch = "review_probe_volcano", timeoutTicks = 400)
    public static void probeVolcanoSkirt(GameTestHelper helper) {
        ServerLevel venus = helper.getLevel().getServer().getLevel(PlanetaryContent.level(PlanetaryContent.VENUS));
        ChunkGenerator generator = venus.getChunkSource().getGenerator();
        int volcanoes = 0;
        int floating = 0;
        long floatingColumns = 0;
        long columns = 0;
        int worstGap = 0;
        for (int i = 0; i < 30; i++) {
            for (int j = 0; j < 30; j++) {
                ChunkPos chunk = new ChunkPos(-3_000 + i * 9, 2_000 + j * 9);
                for (StructurePiece piece : pieces(venus, V180PlanetWorldgen.VOLCANO, chunk)) {
                    VolcanoPiece volcano = (VolcanoPiece) piece;
                    BoundingBox box = volcano.getBoundingBox();
                    int bx = (box.minX() + box.maxX()) / 2;
                    int bz = (box.minZ() + box.maxZ()) / 2;
                    int baseY = box.minY() + 32;
                    int r = volcano.shape().radius();
                    volcanoes++;
                    boolean any = false;
                    for (int dx = -r; dx <= r; dx++) {
                        for (int dz = -r; dz <= r; dz++) {
                            double distance = Math.sqrt(dx * dx + dz * dz);
                            if (volcano.shape().coneRise(distance) <= 0) {
                                continue;
                            }
                            columns++;
                            int ground = generator.getBaseHeight(bx + dx, bz + dz, Heightmap.Types.WORLD_SURFACE_WG,
                                    venus, venus.getChunkSource().randomState()) - 1;
                            if (ground < box.minY() - 1) {
                                floatingColumns++;
                                any = true;
                                worstGap = Math.max(worstGap, box.minY() - 1 - ground);
                            }
                        }
                    }
                    floating += any ? 1 : 0;
                }
            }
        }
        log("volcano starts=" + volcanoes + " with_floating_skirt=" + floating + " floating_columns=" + floatingColumns
                + "/" + columns + " worst_gap=" + worstGap);
        helper.succeed();
    }

    /** P2: real crater generation points on the Moon and Mars: base heights and radii. */
    @GameTest(template = "empty", batch = "review_probe_crater", timeoutTicks = 400)
    public static void probeCraterStarts(GameTestHelper helper) {
        for (ResourceKey<Level> key : List.of(CelestialIds.MOON_LEVEL, PlanetaryContent.level(PlanetaryContent.MARS))) {
            ServerLevel level = helper.getLevel().getServer().getLevel(key);
            ResourceKey<Structure> structure = key == CelestialIds.MOON_LEVEL ? V180PlanetWorldgen.MOON_CRATER
                    : V180PlanetWorldgen.MARS_CRATER;
            Map<Integer, Integer> radii = new TreeMap<>();
            int craters = 0;
            int floorClamped = 0;
            int maxTop = 0;
            for (int i = 0; i < 30; i++) {
                for (int j = 0; j < 30; j++) {
                    for (StructurePiece piece : pieces(level, structure, new ChunkPos(1_000 + i * 5, -1_000 - j * 5))) {
                        CraterPiece crater = (CraterPiece) piece;
                        craters++;
                        int bucket = crater.shape().radius() / 8 * 8;
                        radii.merge(bucket, 1, Integer::sum);
                        BoundingBox box = crater.getBoundingBox();
                        if (box.minY() == V180PlanetWorldgen.CRATER_FLOOR_MIN) {
                            floorClamped++;
                        }
                        maxTop = Math.max(maxTop, box.maxY());
                    }
                }
            }
            log("crater level=" + key.location() + " starts=" + craters + " radius_buckets=" + radii
                    + " floor_clamped=" + floorClamped + " box_max_y=" + maxTop);
        }
        helper.succeed();
    }

    /** P3: real chunk generation on the Moon, Mars and Venus: ore blocks per chunk, highest block, geode exposure. */
    @GameTest(template = "empty", batch = "review_probe_generate", timeoutTicks = 6_000)
    public static void probeGeneratedChunks(GameTestHelper helper) {
        int side = 12;
        Map<ResourceKey<Level>, ChunkPos> origins = Map.of(
                CelestialIds.MOON_LEVEL, new ChunkPos(2_400, 2_400),
                PlanetaryContent.level(PlanetaryContent.MARS), new ChunkPos(2_400, 2_400),
                PlanetaryContent.level(PlanetaryContent.VENUS), new ChunkPos(2_400, 2_400));
        List<Runnable> release = new ArrayList<>();
        List<ChunkPos[]> all = new ArrayList<>();
        for (Map.Entry<ResourceKey<Level>, ChunkPos> entry : origins.entrySet()) {
            ServerLevel level = helper.getLevel().getServer().getLevel(entry.getKey());
            for (int i = 0; i < side; i++) {
                for (int j = 0; j < side; j++) {
                    ChunkPos chunk = new ChunkPos(entry.getValue().x + i, entry.getValue().z + j);
                    level.getChunkSource().addRegionTicket(PROBE, chunk, 0, chunk);
                    release.add(() -> level.getChunkSource().removeRegionTicket(PROBE, chunk, 0, chunk));
                }
            }
        }
        helper.startSequence().thenWaitUntil(() -> {
            for (Map.Entry<ResourceKey<Level>, ChunkPos> entry : origins.entrySet()) {
                ServerLevel level = helper.getLevel().getServer().getLevel(entry.getKey());
                for (int i = 0; i < side; i++) {
                    for (int j = 0; j < side; j++) {
                        helper.assertTrue(level.getChunkSource().hasChunk(entry.getValue().x + i, entry.getValue().z + j),
                                "loading");
                    }
                }
            }
        }).thenExecute(() -> {
            Map<String, Block> ores = new TreeMap<>();
            ores.put("copper", Blocks.COPPER_ORE);
            for (String ore : List.of("tin", "rutile", "aluminum", "iridium", "dilithium")) {
                ores.put(ore, MaterialContent.block(ore + "_ore"));
            }
            for (Map.Entry<ResourceKey<Level>, ChunkPos> entry : origins.entrySet()) {
                ServerLevel level = helper.getLevel().getServer().getLevel(entry.getKey());
                Map<String, Integer> counts = new TreeMap<>();
                Map<String, Integer> chunksWith = new TreeMap<>();
                int highest = 0;
                int stone = 0;
                int geodeTops = 0;
                int geodeShell = 0;
                int caveAirOpen = 0;
                int lavaTop = 0;
                int craterStarts = 0;
                int minTop = 999;
                for (int i = 0; i < side; i++) {
                    for (int j = 0; j < side; j++) {
                        ChunkAccess chunk = level.getChunk(entry.getValue().x + i, entry.getValue().z + j);
                        craterStarts += chunk.getAllStarts().size();
                        Map<String, Integer> here = new TreeMap<>();
                        BlockPos.MutableBlockPos position = new BlockPos.MutableBlockPos();
                        int bx = chunk.getPos().getMinBlockX();
                        int bz = chunk.getPos().getMinBlockZ();
                        for (int x = 0; x < 16; x++) {
                            for (int z = 0; z < 16; z++) {
                                int top = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, bx + x, bz + z);
                                highest = Math.max(highest, top);
                                minTop = Math.min(minTop, top);
                                BlockState topState = chunk.getBlockState(position.set(bx + x, top, bz + z));
                                if (topState.is(SurfaceContent.GEODE_SHELL.get())) {
                                    geodeTops++;
                                }
                                if (topState.is(Blocks.LAVA)) {
                                    lavaTop++;
                                }
                                for (int y = 0; y <= top; y++) {
                                    BlockState state = chunk.getBlockState(position.set(bx + x, y, bz + z));
                                    if (state.is(Blocks.STONE)) {
                                        stone++;
                                    }
                                    if (state.is(SurfaceContent.GEODE_SHELL.get())) {
                                        geodeShell++;
                                    }
                                    for (Map.Entry<String, Block> ore : ores.entrySet()) {
                                        if (state.is(ore.getValue())) {
                                            counts.merge(ore.getKey(), 1, Integer::sum);
                                            here.merge(ore.getKey(), 1, Integer::sum);
                                        }
                                    }
                                }
                                // A geode hollow open to the sky: cave air with sky directly above the column top.
                                BlockState below = chunk.getBlockState(position.set(bx + x, top - 1, bz + z));
                                if (below.is(Blocks.CAVE_AIR)) {
                                    caveAirOpen++;
                                }
                            }
                        }
                        here.keySet().forEach(name -> chunksWith.merge(name, 1, Integer::sum));
                    }
                }
                log("generated level=" + entry.getKey().location() + " chunks=" + side * side + " highest_world_surface="
                        + highest + " lowest_world_surface=" + minTop + " ore_blocks=" + counts
                        + " chunks_with_ore=" + chunksWith + " stone_blocks=" + stone + " starts=" + craterStarts
                        + " geode_shell_blocks=" + geodeShell + " geode_shell_tops=" + geodeTops + " lava_tops=" + lavaTop
                        + " cave_air_under_top=" + caveAirOpen);
            }
            release.forEach(Runnable::run);
        }).thenSucceed();
    }
}
