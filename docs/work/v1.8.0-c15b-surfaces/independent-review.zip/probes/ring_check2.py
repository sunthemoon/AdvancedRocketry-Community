import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2])
for planet in ('moon', 'mars', 'venus'):
    d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
    out = []
    for cx, cz in ((-6, -6), (-6, 0), (5, 0), (0, 5), (-5, -5), (4, 4)):
        region = d / f'r.{cx >> 5}.{cz >> 5}.mca'
        chunk = regions._decode_chunk(regions._region_chunk(region.read_bytes(), cx & 31, cz & 31), cx, cz)
        palettes = set()
        for section in chunk.get('sections', []):
            for entry in (section.get('block_states') or {}).get('palette', []):
                palettes.add(entry.get('Name').split(':')[1])
        keep = sorted(p for p in palettes if any(k in p for k in ('turf', 'ferric', 'end_stone', 'basalt', 'terracotta', 'red_sand', '_ore', 'geode', 'charcoal', 'lava')))
        out.append((cx, cz, chunk.get('Status').split(':')[-1], keep))
    print(planet, out)
