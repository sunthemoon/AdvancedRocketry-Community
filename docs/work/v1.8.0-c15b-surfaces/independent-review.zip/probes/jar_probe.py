import zipfile,hashlib,sys,os,collections
root=sys.argv[1]
jars={'main':'build/libs/advancedrocketry-community-1.20.1-1.8.0-dev.jar','sources':'build/libs/advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar'}
paths=['data/advancedrocketrycommunity/dimension/moon.json','data/advancedrocketrycommunity/dimension/mars.json','data/advancedrocketrycommunity/dimension/venus.json',
'data/advancedrocketrycommunity/worldgen/noise_settings/mars.json','data/advancedrocketrycommunity/worldgen/noise_settings/venus.json','data/advancedrocketrycommunity/worldgen/noise_settings/moon.json',
'data/minecraft/tags/blocks/mineable/pickaxe.json','data/minecraft/tags/blocks/mineable/shovel.json','data/minecraft/tags/blocks/mineable/axe.json','data/minecraft/tags/blocks/needs_iron_tool.json','data/minecraft/tags/blocks/needs_stone_tool.json',
'data/advancedrocketrycommunity/satellite_definitions/data_satellite.json','data/advancedrocketrycommunity/dimension_type/moon.json']
def h(b): return hashlib.sha256(b).hexdigest()[:12]
# all generated roots that have each path
gen=os.path.join(root,'src','generated')
for name,j in jars.items():
    z=zipfile.ZipFile(os.path.join(root,j))
    names=z.namelist()
    c=collections.Counter(names)
    dups=[n for n,k in c.items() if k>1]
    print(name,'entries',len(names),'duplicates',len(dups),dups[:5])
    for p in paths:
        hits=[n for n in names if n.endswith(p) and (n==p or n.endswith('/'+p))]
        if not hits: print('  MISSING',p); continue
        for n in hits:
            jb=h(z.read(n))
            srcs=[]
            for v in sorted(os.listdir(gen)):
                f=os.path.join(gen,v,'resources',p) if v!='resources' else os.path.join(gen,'resources',p)
                if os.path.isfile(f): srcs.append((v,h(open(f,'rb').read())))
            match=[v for v,hh in srcs if hh==jb]
            print('  %-75s %s from %s (roots with copy: %s)'%(n,jb,match,[v for v,_ in srcs]))
