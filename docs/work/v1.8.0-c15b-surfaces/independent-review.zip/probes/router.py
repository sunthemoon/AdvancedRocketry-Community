import json,sys
for b in ['mars','venus']:
    d=json.load(open(sys.argv[1]+'/src/generated/v1.4/resources/data/advancedrocketrycommunity/worldgen/noise_settings/%s.json'%b))
    print(b, json.dumps(d['noise_router']['final_density'])[:2500])
