import sys,struct,collections
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2])
for planet in ('moon', 'mars', 'venus'):
    d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
    kinds = collections.Counter(); examples = collections.defaultdict(list)
    for region in sorted(d.glob('r.*.mca')):
        rx, rz = map(int, region.name.split('.')[1:3])
        data = region.read_bytes()
        for i in range(1024):
            if struct.unpack('>I', data[i*4:i*4+4])[0] == 0: continue
            cx, cz = rx*32 + (i % 32), rz*32 + (i // 32)
            if cx > 30 or cz > 30: continue   # skip the far area
            chunk = regions._decode_chunk(regions._region_chunk(data, cx & 31, cz & 31), cx, cz)
            if chunk.get('Status') not in ('minecraft:full', 'full'): continue
            blocks=set(); biomes=set()
            for s in chunk.get('sections', []):
                for e in (s.get('block_states') or {}).get('palette', []): blocks.add(e.get('Name').split(':')[1])
                for b in (s.get('biomes') or {}).get('palette', []): biomes.add(b if isinstance(b,str) else str(b))
            terrain = 'old' if (blocks & {'end_stone','red_sand','yellow_terracotta'}) else 'new'
            surface = sorted(blocks & {'moon_turf','dark_moon_turf','ferric_sand','end_stone','red_sand','yellow_terracotta','basalt','stone','red_sandstone'})
            key = (terrain, tuple(sorted(b.split(':')[1] for b in biomes)), tuple(surface))
            kinds[key]+=1
            if len(examples[key])<3: examples[key].append((cx,cz))
    print('==', planet)
    for k,v in kinds.most_common(): print('  ', v, k, examples[k])
