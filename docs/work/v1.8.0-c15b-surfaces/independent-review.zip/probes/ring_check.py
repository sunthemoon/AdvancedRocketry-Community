import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1] + '/scripts')
import v120_precision_world_fixture as regions
world = Path(sys.argv[2])
for planet in ('moon', 'mars', 'venus'):
    d = world / 'dimensions' / 'advancedrocketrycommunity' / planet / 'region'
    out = []
    for cx, cz in ((-4, -4), (3, 0), (0, 3), (-3, -3)):
        region = d / f'r.{cx >> 5}.{cz >> 5}.mca'
        chunk = regions._decode_chunk(regions._region_chunk(region.read_bytes(), cx & 31, cz & 31), cx, cz)
        palettes = set()
        for section in chunk.get('sections', []):
            for entry in (section.get('block_states') or {}).get('palette', []):
                palettes.add(entry.get('Name'))
        interesting = sorted(p for p in palettes if 'turf' in p or 'ferric' in p or 'end_stone' in p or 'basalt' in p
                             or 'terracotta' in p or 'red_sand' in p or '_ore' in p)
        out.append(((cx, cz), chunk.get('Status'), interesting))
    print(planet, out)
