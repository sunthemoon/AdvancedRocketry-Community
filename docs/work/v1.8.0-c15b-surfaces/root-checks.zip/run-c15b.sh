#!/usr/bin/env bash
# C15b evidence run: Gradle full run, test rerun, JAR check, collection. Sequential, alone on the host.
C=C:/Users/ADMINI~1/AppData/Local/Temp/arce-v180-c15b-cfeae6545c8142278a9cc4f933b665ec
cd /d/GitHub/AdvancedRocketry-Community || exit 1
export JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"
git rev-parse HEAD > $C/run-commit.txt
git status --porcelain > $C/pre-run-status.txt
./gradlew --offline clean build test runData runGameTestServer > $C/root-gradle-01.log 2>&1
echo $? > $C/root-gradle-01.exit
git status --porcelain -- src/generated > $C/generated-status.txt
git diff --stat > $C/post-gradle-diff.txt
python -B $C/scripts/jar_check.py > $C/jar-resource-check.txt 2>&1
echo $? > $C/jar-resource-check.exit
./gradlew --offline test --rerun > $C/root-gradle-02.log 2>&1
echo $? > $C/root-gradle-02.exit
if [ "$(cat $C/root-gradle-01.exit)" != "0" ] || [ "$(cat $C/root-gradle-02.exit)" != "0" ]; then echo GRADLE_FAILED > $C/run.status; exit 1; fi
python $C/scripts/collect_run.py > $C/collect.log 2>&1 || { echo COLLECT_FAILED > $C/run.status; exit 1; }
echo DONE > $C/run.status
