"""Write docs/work/v1.8.0-c15b-surfaces/VERIFICATION.md from the run's facts (Python results from python/*.exit,
native results from native/summary.json)."""
import json
import re
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
OUT = ROOT / 'docs/work/v1.8.0-c15b-surfaces'
NS = 'advancedrocketrycommunity'
lang = json.loads((ROOT / 'src/generated/v1.8/resources/assets/advancedrocketrycommunity_v180/lang/en_us.json')
                  .read_text(encoding='utf-8'))
BLOCKS = ['moon_turf', 'dark_moon_turf', 'ferric_sand', 'charcoal_log', 'geode_shell']
for block in BLOCKS:
    assert f'block.{NS}.{block}' in lang, block
registered = ', '.join(f'`{NS}:{block}`' for block in BLOCKS)

COMMITS = [
    ('9a8b0e0', 'ADR-063 revision 5 (proposed): the C15b decisions of §5'),
    ('495d758', 'Asset plan: the geode shell texture is drawn new instead of imported (ADR-061 §4.2)'),
    ('361c02b', 'The v1.7 black-hole idle GameTest waits for the generator\'s first real evaluation before timing '
                'its re-check; the 21-tick bound is unchanged'),
    ('7d5d60c', 'ADR-063 revision 5 additions: drops and tools, saved pieces'),
    ('3d4cae8', 'Two v1.7 GameTests name what blocks an elevator arrival or lies near a laser marker in their '
                'failure messages; assertions unchanged'),
    ('d682e72', 'The surfaces, biomes, structures, charred trees, Moon and Mars ores, switches, release-test '
                'hooks and tests'),
    ('0744fba', 'The release-test hook `sample` loads the column it reports (found by the third S1 attempt)'),
    ('3e24ddf', 'A GameTest checks that each body\'s generator tries its own structure sets (the S1 world had '
                'structures off, and no GameTest showed that worldgen tries the sets)'),
    ('2a74f90', 'The v1.7 elevator anchor fixture lays a roof against gravel falling from the rock above the '
                'test space (named by the `3d4cae8` diagnostics); assertions unchanged'),
    ('ef4bb85', 'The C15a press switch GameTest names what it saw when it fails; assertions unchanged'),
    ('this commit', 'The evidence packet, the ledger delivery and the status documents'),
]

PYTHON = [
    ('py-01-ledger', '`python -B scripts/validate_v180_content_ledger.py`'),
    ('py-02-ledger-accepted', '`… --require-accepted`'),
    ('py-03-ledger-closure', '`… --closure` (expected to fail until C19)'),
    ('py-04-inventory', '`python -B tools/audit/inventory_v180_content.py --upstream <Temp> --check`'),
    ('py-05-derivation', '`python -B tools/audit/vanilla_derivation.py --upstream <Temp> --vanilla … --check`'),
    ('py-06-art-screen', '`python -B tools/audit/screen_generated_art.py --root src/generated/v1.8/resources '
                         '--vanilla 1.12.2=… --vanilla 1.20.1=…`'),
    ('py-07-unittest', '`python -B -m unittest tests.test_validate_v180_content_ledger '
                       'tests.test_vanilla_derivation tests.test_screen_generated_art`'),
    ('py-08-machine-resources', '`python -B scripts/validate_v120_machine_resources.py`'),
    ('py-09-beta-resources', '`python -B scripts/validate_v090_resources.py`'),
    ('py-10-client-imports', '`python -B scripts/check_client_imports.py`'),
]

FIXED = """- The Moon surface was one block low: the density is zero at S, so the top block lies at
  S − 1; S is now 21 + 12n + 4|n|.
- The volcano's skirt wrote below its box on sloped ground; the box now reaches the skirt
  depth and every write of every piece is clamped to its own box and the chunk.
- The geode's half height truncated towards zero and reached past the radius; it uses
  floor division.
- GameTests read the worldgen heightmap, which is stale on loaded chunks; they read
  `WORLD_SURFACE`.
- Moon tests shared the fixed pad area; `MoonPadArea` gives it a known shape first.
- The v1.3 atmosphere rooms on the Moon were buried by the new terrain; they moved to
  y 64.
- Heavy structure tests loaded chunks synchronously and stalled the tests running beside
  them; they now load through region tickets and wait.
- The surface test's rock check assumed a fixed filler depth; it now walks down the
  filler, which the vanilla surface depth and a crater rim can make up to about 18 blocks
  deep.
- A v1.7 GameTest timed the black-hole generator's idle re-check from a status that a new
  generator reads before it ever ticks (`361c02b`).
- GameTests stand in natural terrain below the surface (the GameTest Overworld is a
  normal world, seed 0; tests start at y -60), and which earlier test or rock surrounds
  a test depends on the layout of the batches, which C15b's new batches shift. Two v1.7
  GameTests failed once each in pre-commit runs and passed in the next: an elevator ride
  down cancelled as `ARRIVAL_OBSTRUCTED` (the rides test, then the zone test) and two
  items near a laser marker. `3d4cae8` made both failure messages name what was there.
  The Gradle evidence run on `3e24ddf` (`failed-run-3e24ddf/`) then failed three tests:
  the elevator zone test, whose message named gravel filling the arrival platform;
  `theServerSwitchTurnsThePressOff` (C15a), whose block was gone five ticks after the
  rising edge of a disabled press, with no plates saved near it (cause unknown); and the
  v1.5 sky-context test, which counted the zone test's rider, left online because the
  zone test failed before its clean-up. `2a74f90` roofs the elevator anchor fixture;
  `ef4bb85` makes the press test name what it saw. The pre-commit GameTest logs are in
  `prechecks/`; the laser test did not fail again.
- The S1 harness needed six attempts before the final run, each kept in `root-checks.zip`:
  1. `attempt-01-failed`: the console `fill` that explores the planets needs loaded
     chunks; the harness now force-loads the square, retries the fill and releases it.
  2. `attempt-02-failed`: the release reply reads "for force loading"; the v1.6 world
     also holds blocks of the adapter compat fixture mod, which both phases now install,
     as the v1.7 harness did.
  3. `attempt-03-failed`: a defect in the release-test hook `sample`: it read an unloaded
     column's height as the minimum build height (void air at y -1) and its biome from
     the biome source. `0744fba` loads the column first.
  4. `attempt-04-failed`: each hook line is logged and also echoed as console feedback, so
     a query matched the previous body's line; queries now match the dimension and
     position.
  5. `attempt-05-failed`: one explored Moon chunk was reported changed by a comparison of
     raw section data (palette and packed longs, light-only sections included); its
     content was the same flat Moon. The harness now compares decoded block states and
     writes any difference with its position (`native/explored-differences.json`).
  6. `attempt-06-structures-off`: passed, but no body showed a structure start: the
     retained v1.6 world was created with structures off (`generate_features` 0), so
     vanilla never tried a structure set. The harness now turns structures on in the
     copied `level.dat` (the source world stays unchanged and is verified) and requires
     crater starts on the Moon and Mars and a geode start on Venus; `3e24ddf` adds the
     GameTest that each body's generator tries its own sets.
- The Gradle evidence runs on `d682e72` and `0744fba` (369 GameTests and 1,419 JUnit tests
  each, all passing) are kept as `superseded-run-d682e72/` and `superseded-run-0744fba/`;
  this packet's run, and S1's seventh attempt, are on the commit named above."""


def python_rows():
    rows = []
    for name, command in PYTHON:
        exit_file = E / 'python' / (name + '.exit')
        log_file = E / 'python' / (name + '.log')
        if not exit_file.exists():
            rows.append('| %s | not run |' % command)
            continue
        code = exit_file.read_text().strip()
        lines = [line.strip() for line in log_file.read_text(encoding='utf-8', errors='replace').splitlines()
                 if line.strip()]
        last = lines[-1] if lines else ''
        if 'ledger' in name:
            result = next((line for line in lines if '"result"' in line), last)
            last = result.strip(',')
        if name.startswith('py-07'):
            verdict = next((line for line in reversed(lines) if line.startswith(('OK', 'FAILED'))), '')
            last = next((line for line in reversed(lines) if line.startswith('Ran ')), '') + '; ' + verdict
        rows.append('| %s | Exit %s; `%s` |' % (command, code, last.replace('|', '/')[:160]))
    return '\n'.join(rows)


def native():
    summary_file = E / 'native' / 'summary.json'
    if not summary_file.exists():
        return 'Not run yet.'
    summary = json.loads(summary_file.read_text(encoding='utf-8'))
    summary_inputs = json.loads((E / 'native' / 'inputs.json').read_text(encoding='utf-8'))
    upgrade = summary['upgrade']
    timings = upgrade['timings']
    per_chunk = upgrade['ms_per_chunk']
    explore = summary['explore']
    lines = [
        'A copy of the retained v1.6 world (`arce-v160-c9-…/attempt-04/native-server/world`) was opened by the',
        'v1.7 handoff build (main JAR `4326d3d6…`, rebuilt from `55da6a5`, equal to the handoff hash), which',
        'generated and saved a 6 × 6 chunk square around the origin of the Moon, Mars and Venus (the "explored"',
        'chunks). The v1.8 build of the tested commit then opened the same world on a packaged dedicated server',
        '(`native_c15b_check.py`, release-test hooks on, no clients). The copy\'s `level.dat` has structures turned',
        f'on (the source world has `generate_features` {summary_inputs["generate_features_in_source"]}):',
        '',
        '| Check | Result |',
        '|---|---|',
    ]
    for planet in ('moon', 'mars', 'venus'):
        sample = upgrade['samples'][planet + ':explored']
        lines.append(f'| {planet.capitalize()} explored column (-40, -40) keeps its old top | `{sample["block"]}` at '
                     f'y {sample["top"]}, biome `{sample["biome"]}` |')
    for planet in ('moon', 'mars', 'venus'):
        tops = sorted({value['block'] for key, value in upgrade['samples'].items()
                       if key.startswith(planet + ':new:')})
        biomes = sorted({value['biome'] for key, value in upgrade['samples'].items()
                         if key.startswith(planet + ':new:')})
        lines.append(f'| {planet.capitalize()} new chunks (9 × 9 around chunk 64, 64) | tops '
                     + ', '.join(f'`{top}`' for top in tops) + '; biomes ' + ', '.join(f'`{b}`' for b in biomes)
                     + f'; highest surface y {int(timings[planet]["highest"]) - 1}; starts {timings[planet]["starts"]} |')
    reference = timings['overworld']
    lines.append(f'| Generation time (81 chunks each, synchronous) | Overworld reference '
                 f'{per_chunk["overworld"]:.1f} ms/chunk; ' + '; '.join(
                     f'{planet} {per_chunk[planet]:.1f} ms/chunk' for planet in ('moon', 'mars', 'venus'))
                 + f' (budget {1.5:.1f} × reference); slowest single chunk: '
                 + ', '.join(f'{name} {timings[name]["slowest_ms"]} ms' for name in ('overworld', 'moon', 'mars', 'venus'))
                 + ' |')
    lines.append(f'| Explored chunks after the upgrade | {summary["explored_chunks_unchanged"]} chunks (6 × 6 per body): '
                 f'every block section equal before and after |')
    lines.append('| Logs | Both phases start and stop cleanly (exit 0); the log scan finds no unexpected error or '
                 'warning; the source world is unchanged |')
    lines += ['', 'Explore replies: ' + '; '.join(f'{k}: {v}' for k, v in explore.items()) + '.',
              '', 'The phases\' logs, commands, receipts and the summary are in `root-checks.zip` (`native/`).']
    return '\n'.join(lines)


def facts():
    log1 = (E / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace')
    log2 = (E / 'root-gradle-02.log').read_text(encoding='utf-8', errors='replace')
    junit = json.loads((E / 'junit-summary.json').read_text())
    games = json.loads((E / 'gametest-summary.json').read_text())
    jars = {a['name']: a['sha256'][:8] for a in json.loads((E / 'artifacts.json').read_text())['artifacts']}
    pick = lambda suffix: next(v for k, v in jars.items() if k.endswith(suffix))
    jar_check = (E / 'jar-resource-check.txt').read_text(encoding='utf-8')
    jar_line = ('No duplicate entries; the v1.8 Moon, Mars and Venus dimension and noise-settings files, '
                '`needs_iron_tool`, `needs_stone_tool` and `mineable/pickaxe` appear once each in the main and '
                'sources JARs, with the v1.8 bytes; no empty directories (`RESULT PASS`)'
                if 'RESULT PASS' in jar_check else 'FAILED: ' + jar_check.strip().splitlines()[-1])
    return {
        '{RUN}': (E / 'run-commit.txt').read_text().strip()[:7],
        '{T1}': re.findall(r'BUILD SUCCESSFUL in (.*)', log1)[-1].strip(),
        '{T2}': re.findall(r'BUILD SUCCESSFUL in (.*)', log2)[-1].strip(),
        '{GT}': str(games['required_passed']),
        '{JUNIT}': '{:,}'.format(junit['tests']),
        '{SUITES}': str(junit['suites']),
        '{MAIN}': pick('-dev.jar'), '{API}': pick('-api.jar'), '{SRC}': pick('-sources.jar'),
        '{ERRORS}': str(log1.count('ERROR]')),
        '{JARCHECK}': jar_line,
    }


text = (E / 'scripts' / 'verification-template.md').read_text(encoding='utf-8')
for key, value in facts().items():
    text = text.replace(key, value)
text = text.replace('{COMMITS}', '\n'.join(f'| `{c}` | {d} |' if c != 'this commit' else f'| {c} | {d} |'
                                           for c, d in COMMITS))
text = text.replace('{COUNT}', 'five blocks with their block items')
text = text.replace('{REGISTERED}', registered).replace('{PY_RESULTS}', python_rows())
text = text.replace('{NATIVE}', native()).replace('{FIXED}', FIXED)
final = E / 'packaging' / 'out' / 'validation-final.summary'
text = text.replace('{FINAL}', final.read_text(encoding='utf-8').strip() if final.exists()
                    else 'They need the finished packet and run after packaging.')
assert not re.findall(r'\{[A-Z_]+\}', text), re.findall(r'\{[A-Z_]+\}', text)
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'VERIFICATION.md').write_text(text, encoding='utf-8', newline='\n')
print('written')
