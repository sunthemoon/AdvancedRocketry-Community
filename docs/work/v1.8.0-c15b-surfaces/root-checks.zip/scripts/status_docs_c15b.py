"""Record the C15b delivery in the status documents (documentation only). Facts come from facts.json."""
import json
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
facts = json.loads((E / 'scripts' / 'facts.json').read_text(encoding='utf-8'))


def edit(relative, old, new):
    path = ROOT / relative
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (relative, old[:80])
    path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')


LOG = 'docs/work/v1.8.0-implementation-log.md'
edit(LOG, '| C15 | C15b | Moon/Mars/Venus surfaces, biomes and features | not started |',
     '| C15 | C15b | Moon/Mars/Venus surfaces, biomes and features | delivered; implementation review pending |')
edit(LOG, """- Owner decisions open: ADR-063 revision 4 and ADR-061 revision 7, including the
  iron-plate route (the press, or re-keying `rolling_iron_bars`).
""", """- Owner decisions open: ADR-063 revision 4 and ADR-061 revision 7, including the
  iron-plate route (the press, or re-keying `rolling_iron_bars`).

## C15b — the Moon, Mars and Venus surfaces

Planned outputs (ADR-063 §4 for the Moon and Mars ores, §5, §8, §9):

- Five surface blocks with drawn art; five biomes; the Moon as a noise Level of
  low relief (surface y 12–36) and Mars and Venus with their v1.4 routers and new
  surfaces; the crater, volcano and geode structures and the charred-tree
  feature; the Moon and Mars ore sets; five server switches; the 50 ledger rows
  moved to C15b, including the 13 `config:WORLDGEN.*` rows from C15a.
- A0/A1 tests of §9 for C15b, the S1 packaged-server check on an upgraded world,
  the evidence packet, an independent implementation review.

Explicit C15b non-goals: the Tau Ceti worlds and the crystal blocks (C15c); a
landing rule that puts Moon rockets on the ground (a later ADR); carvers on the
three bodies; restoring the legacy volcanic biome's creepers; world migration of
explored chunks; imported assets; candidate, tag or Gate changes.

Progress:

- Settled while implementing: ADR-063 revision 5, **proposed** (`9a8b0e0`,
  `7d5d60c`): two crater structures of one type, the Venus `patches` biome
  source (the copied v1.4 router has no climate to split the Venus biomes), no
  carvers on the three bodies (the legacy defaults had none), no spawns, the
  geode and charred-tree numbers, the five switches, the surfaces, the drops and
  tools (the charcoal log drops charcoal as the legacy log did; the geode shell
  needs an iron pickaxe until the C18b jackhammer) and a schema version on saved
  pieces. The geode shell texture is drawn new instead of imported
  (`495d758`, ADR-061 §4.2).
- A v1.7 GameTest timed the black-hole generator's idle re-check from a status
  that a new generator reads before it ever ticks; the C15b batches delayed the
  first tick and exposed it. `361c02b` waits for the first real evaluation; the
  21-tick bound is unchanged.
- Fixed before the implementation commit, from GameTest runs: the Moon surface
  was one block low (the density's zero lies at S, the top block at S − 1); the
  volcano's skirt wrote below its box (the box now reaches the skirt and every
  write is clamped to it); the geode's half height truncated towards zero and
  reached past the radius (floor division); stale worldgen heightmaps on loaded
  chunks (tests read `WORLD_SURFACE`); Moon tests shared the fixed pad area
  (`MoonPadArea` gives it a known shape); the v1.3 atmosphere rooms on the Moon
  were buried by the new terrain (moved to y 64); heavy structure tests stalled
  the concurrent batches with synchronous chunk loads (they now load through
  tickets); and the surface test's rock check assumed a fixed filler depth (it
  now walks down the filler, which the vanilla surface depth and a crater rim
  can make up to about 18 blocks deep).
- GameTests stand in natural rock below the surface (the GameTest Overworld is a
  normal world, seed 0), and the new batches shift which test stands where. Two
  v1.7 GameTests failed once each before the implementation commit (an elevator
  ride cancelled as `ARRIVAL_OBSTRUCTED`, two items near a laser marker);
  `3d4cae8` made their messages name what was there. The evidence run on
  `3e24ddf` then failed three tests: the elevator zone test (gravel from the rock
  above filled the arrival platform; `2a74f90` roofs the anchor fixture), the C15a
  press switch test (its block was gone five ticks after a disabled press's rising
  edge, with no plates near it; cause unknown, `ef4bb85` makes it name what it
  saw), and the v1.5 sky-context test (the failed zone test's rider was still
  online). Logs: `failed-run-3e24ddf/` and `prechecks/` in the C15b packet.
- Implementation `d682e72`. S1 needed six harness attempts (all kept): the third found
  that the release-test hook `sample` read unloaded columns as empty (`0744fba` loads
  them); the sixth passed but showed no structure start, because the retained v1.6
  world has structures off. The harness now turns them on in its copy and requires
  starts, and `3e24ddf` adds a GameTest that each body's generator tries its own
  structure sets. Evidence run on `{RUN}`: {GT} GameTests, {JUNIT}
  JUnit tests, clean DataGen diff; S1 on a copy of the retained v1.6 world
  upgraded by the v1.7 handoff build ([C15b
  evidence](v1.8.0-c15b-surfaces/VERIFICATION.md)).
- 50 ledger rows delivered: 11 IMPLEMENTED, 39 REDESIGNED.
""".replace('{RUN}', facts['run']).replace('{GT}', facts['gt']).replace('{JUNIT}', facts['junit']))

PLAN = 'docs/status/COMPLETION-PLAN.md'
edit(PLAN, """    待维护者决定是否接受 ADR-063 第 4 版与 ADR-061 第 7 版；证据 `docs/work/v1.8.0-c15a-materials/`）；C15b 月球、火星、金星地表与地物；C15c 经典系外行星世界
    （ADR-063 已接受）；""", """    待维护者决定是否接受 ADR-063 第 4 版与 ADR-061 第 7 版；证据 `docs/work/v1.8.0-c15a-materials/`）；
    C15b 月球、火星、金星地表与地物 `[x]`（开发完成，待独立实现审核与 ADR-063 第 5 版的接受；证据
    `docs/work/v1.8.0-c15b-surfaces/`）；C15c 经典系外行星世界（ADR-063 已接受）；""")
edit(PLAN, """**C15a 收尾**：维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机或改键 `rolling_iron_bars`、
金红石不压制、轧制配方用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）与 ADR-061 第 7 版
（内核机器配方在 C16a 前只用物品原料）。随后 **C15b 月球、火星、金星地表与地物**
（同一会话继续；ADR-063 §5，含月球与火星矿石及从 C15a 移来的 `config:WORLDGEN.*` 行）。""",
     """**C15b 收尾**：独立实现审核与修复。维护者决定是否接受 ADR-063 第 4 版（铁板来自压板机或改键
`rolling_iron_bars`、金红石不压制、轧制配方用物品原料、压板机在动作时解析标签并拒绝歧义、两个开关）、
第 5 版（陨石坑结构、金星斑块生物群系源、三颗天体无洞穴雕刻、掉落与工具、结构件 schema 等）与
ADR-061 第 7 版（内核机器配方在 C16a 前只用物品原料）。随后 **C15c 经典系外行星世界**
（同一会话继续；ADR-063 §6）。""")

CURRENT = 'docs/status/CURRENT_VERSION.md'
edit(CURRENT, """hovercraft past v2.0. C15a (the material set, ores and the small plate press) is delivered
and changes the runtime identity to `1.20.1-1.8.0-dev`
([C15a evidence](../work/v1.8.0-c15a-materials/VERIFICATION.md)); its independent review
and the owner's decision on ADR-063 revision 4 are pending. The next chunk is in
[COMPLETION-PLAN](COMPLETION-PLAN.md). No Gate is claimed.""",
     """hovercraft past v2.0. C15a (the material set, ores and the small plate press) is delivered
and changes the runtime identity to `1.20.1-1.8.0-dev`
([C15a evidence](../work/v1.8.0-c15a-materials/VERIFICATION.md)); its independent review
accepted it. C15b (the Moon, Mars and Venus surfaces, structures and planet ores) is
delivered ([C15b evidence](../work/v1.8.0-c15b-surfaces/VERIFICATION.md)); its
independent review is pending. The owner's decision on ADR-063 revisions 4 and 5 and
ADR-061 revision 7 is open. The next chunk is in [COMPLETION-PLAN](COMPLETION-PLAN.md).
No Gate is claimed.""")

MATRIX = 'docs/PORTING_MATRIX.md'
edit(MATRIX, "钛/铝/钢/锡/硅/铱/二锂/钛铝/钛铱材料组、Forge 通用标签、矿石与小型压板机（ADR-061 §2）；C15a 已交付 Overworld 部分，月球与火星矿石在 C15b | `v1.8.0` | C15a 批次 ADR + A0/A1 | IN_PROGRESS |",
     "钛/铝/钢/锡/硅/铱/二锂/钛铝/钛铱材料组、Forge 通用标签、矿石与小型压板机（ADR-061 §2）；C15a 交付 Overworld 部分，C15b 交付月球与火星矿石（开发完成，待版本 Gate） | `v1.8.0` | C15a/C15b 批次 ADR + A0/A1 | IN_PROGRESS |")
edit(MATRIX, "月球/火星/金星地表方块与生物群系、陨石坑/火山/晶洞/水晶（C15b）；外星森林等六种生物群系落在固定的数据驱动世界（C15c） | `v1.8.0` | C15b/C15c 批次 ADR + A1/S1 | PLANNED |",
     "月球/火星/金星地表方块与生物群系、陨石坑/火山/晶洞与焦木（C15b 已交付）；水晶与外星森林等六种生物群系落在固定的数据驱动世界（C15c） | `v1.8.0` | C15b/C15c 批次 ADR + A1/S1 | IN_PROGRESS |")
print('status documents updated')
