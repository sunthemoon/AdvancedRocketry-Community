You are the independent implementation reviewer for slice C15b of v1.8.0 in the repository
D:/GitHub/AdvancedRocketry-Community (Minecraft 1.20.1 Forge 47.4.10, Java 17). Review round 1 (C15bR1).

Read-only rules (strict):
- Do not modify the repository or its working copy in any way: no git writes (no commit, checkout, stash,
  reset, worktree, add), no file edits, no builds inside the repository directory.
- Read the committed tree only through git (`git show`, `git diff`, `git log`, `git ls-tree`, `git archive`).
  Export the reviewed commit with `git archive <commit> | tar -x -C <your dir>/tree` and build/run there.
- Work only in your own directory: C:/Users/Administrator/AppData/Local/Temp/arce-v180-c15b-review-<random hex>.
  Create it first.
- Never read or copy the untracked folder `AdvancedRocketry-Community-v1plus-Development-Docs/`.
- Java: `C:/Program Files/Java/jdk-17.0.7` (set JAVA_HOME; the shell default is invalid). Gradle with `--offline`.
  Run Gradle builds one at a time; a full `clean build runData runGameTestServer` takes about 6 minutes.
  The C: drive has limited space: do not keep more than one exported tree plus its build at a time.
- If you need Minecraft/Forge behaviour, use `javap -c` on the mapped Forge jar in
  C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/
  1.20.1-47.4.10_mapped_official_1.20.1/.

Reviewed commit: {REVIEWED} on branch `codex/v1.8.0-classic-content`. Base of v1.8: `39fc16c` (C14
acceptance). C15a is complete and was accepted by its own review. C15b commits: `9a8b0e0` (ADR-063 revision
5 proposed), `495d758` (geode shell asset rule), `361c02b` (a v1.7 idle-test fix), `7d5d60c` (revision 5
additions), `3d4cae8` (diagnostics in two v1.7 GameTests), `d682e72` (the implementation), `{PACKET}` (the
evidence packet and ledger delivery).

Read first: AGENTS.md; docs/decisions/ADR-061 (identity, import, validation), ADR-062 §1/§6/§7, ADR-063 in
full (especially §4, §5 with revision 5, §8, §9); docs/work/v1.8.0-c15b-surfaces/VERIFICATION.md; the C15b
section of docs/work/v1.8.0-implementation-log.md; the full non-generated diff `0a99d17..{REVIEWED}`; spot-check
the generated JSON under src/generated/v1.8.

Review for:
1. Correctness against ADR-063 §4/§5/§9 and revision 5: terrain bounds (Moon surface y 12–36, nothing above
   y 63, crater floors ≥ 5 and rims ≤ 44 on the Moon), every structure piece writing only inside the chunk being
   generated and its box, the Moon/Mars ore sets and numbers, switches, drops and tools, the saved piece schema,
   the Venus patch biome source, superseded dimension/noise files excluded from the JARs, seams for existing
   worlds (explored chunks keep their surfaces).
2. AGENTS.md constraints: server authority, bounded algorithms and per-tick budgets, size limits on variable
   data (codecs, NBT), no client imports in common code, persistence schema versions, file sizes.
3. Test quality: do the GameTests and JUnit tests actually prove the contract? Run mutations (change a bound,
   a switch, a number, a write clamp) and report which survive. Check for tests that pass vacuously.
4. Evidence: rebuild the export, compare GameTest/JUnit counts, JAR hashes and entries, DataGen determinism,
   the art screen, the ledger validator, and the S1 native results in the packet with what you measure.
5. The two v1.7 test changes (`361c02b`, `3d4cae8`): do they keep the original intent without weakening?
6. The ledger rows (50 delivered: 11 IMPLEMENTED, 39 REDESIGNED): are dispositions and targets honest?
7. ADR-063 revision 5 (proposed): recommend accept / accept with changes / reject, with reasons.

Write your report as REVIEW.md in your directory, in the format of
docs/work/v1.8.0-c15a-materials/reviews/REVIEW-01.md: header (reviewed commit, scope, method, isolation),
"1. Commands run and results" (table), "2. Findings" (each with an ID C15bR1-<severity letter><n>, severity
Critical/High/Medium/Low/Info, evidence with file:line, impact, and a concrete required change), "3. Verdicts"
(C15b: accept / accept with required changes / reject; ADR-063 revision 5). Keep all your scripts, logs and
probes in your directory (not the exported tree or Minecraft disassembly, which may be large). Reply with a
short summary: counts by severity, verdicts, and the path of REVIEW.md.
