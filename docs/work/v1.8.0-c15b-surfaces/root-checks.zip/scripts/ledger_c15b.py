"""Mark the 50 C15b ledger rows delivered (ADR-062 section 1) with the C15b evidence (ADR-063 section 5, rev. 5)."""
import csv
import io
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEDGER = ROOT / 'docs/work/v1.8.0-content-ledger.csv'
EVIDENCE = 'docs/work/v1.8.0-c15b-surfaces/VERIFICATION.md'
NS = 'advancedrocketrycommunity:'
I, R = 'IMPLEMENTED', 'REDESIGNED'

ORES_ALL = 'Overworld, Moon and Mars %s ore placed features'
NO_CARVERS = ('the Moon, Mars and Venus have no carvers, as the legacy defaults; data-pack planet biomes may add '
              'vanilla carvers (ADR-063 revision 5)')

# unit -> (disposition, target, notes or None to keep)
DELIVERED = {
    'biome:hotdryrock': (I, NS + 'ferric_regolith biome', None),
    'biome:moon': (I, NS + 'regolith_highlands biome', None),
    'biome:moondark': (I, NS + 'regolith_lowlands biome', None),
    'biome:volcanic': (I, NS + 'volcanic biome', None),
    'biome:volcanicbarren': (I, NS + 'volcanic_lowlands biome', None),
    'block:basalt': (R, 'vanilla basalt in the Venus surface', None),
    'block:charcoalLog': (I, NS + 'charcoal_log', 'volcanic flora; not flammable, as legacy'),
    'block:geode': (I, NS + 'geode_shell', None),
    'block:hotTurf': (I, NS + 'ferric_sand', None),
    'block:moonTurf': (I, NS + 'moon_turf', None),
    'block:moonTurf_dark': (I, NS + 'dark_moon_turf', None),
    'config:WORLDGEN.AluminumPerChunk': (R, ORES_ALL % 'aluminum', None),
    'config:WORLDGEN.AluminumPerClump': (R, ORES_ALL % 'aluminum', None),
    'config:WORLDGEN.CopperPerChunk': (R, 'Moon and Mars copper ore placed features', None),
    'config:WORLDGEN.CopperPerClump': (R, 'Moon and Mars copper ore placed features', None),
    'config:WORLDGEN.DilithiumPerChunk': (R, ORES_ALL % 'dilithium', None),
    'config:WORLDGEN.DilithiumPerChunkLuna': (R, 'Moon dilithium ore placed feature', None),
    'config:WORLDGEN.DilithiumPerClump': (R, ORES_ALL % 'dilithium', None),
    'config:WORLDGEN.EnableOreGen': (R, 'overworld_ores and planet_ores server switches', None),
    'config:WORLDGEN.generateAluminum': (R, ORES_ALL % 'aluminum', None),
    'config:WORLDGEN.GenerateCopper': (R, 'Moon and Mars copper ore placed features', None),
    'config:WORLDGEN.generateCraters': (R, 'craters server switch and the crater structures', None),
    'config:WORLDGEN.generateDilithium': (R, ORES_ALL % 'dilithium', None),
    'config:WORLDGEN.generateGeodes': (R, 'geodes server switch and the geode structure', None),
    'config:WORLDGEN.generateIridium': (R, 'Moon and Mars iridium ore placed features', None),
    'config:WORLDGEN.GenerateRutile': (R, ORES_ALL % 'rutile', None),
    'config:WORLDGEN.GenerateTin': (R, ORES_ALL % 'tin', None),
    'config:WORLDGEN.generateVolcanos': (R, 'volcanoes server switch and the volcano structure', None),
    'config:WORLDGEN.geodeBaseSize': (R, 'geode structure radius 16-24', None),
    'config:WORLDGEN.geodeOres': (R, 'geode_ores block tag', 'data packs choose the ores; at most 32 kinds'),
    'config:WORLDGEN.geodeOres_blacklist': (R, 'geode_ores block tag', 'data packs replace the tag to leave ores out'),
    'config:WORLDGEN.geodeVariation': (R, 'geode structure radius 16-24', None),
    'config:WORLDGEN.IridiumPerChunk': (R, 'Moon and Mars iridium ore placed features', None),
    'config:WORLDGEN.IridiumPerClump': (R, 'Moon and Mars iridium ore placed features', None),
    'config:WORLDGEN.RutilePerChunk': (R, ORES_ALL % 'rutile', None),
    'config:WORLDGEN.RutilePerClump': (R, ORES_ALL % 'rutile', None),
    'config:WORLDGEN.TinPerChunk': (R, ORES_ALL % 'tin', None),
    'config:WORLDGEN.TinPerClump': (R, ORES_ALL % 'tin', None),
    'config_file:oreConfig.xml': (R, 'Moon and Mars ore placed features in data packs', None),
    'worldgen:CustomizableOreGen': (R, 'configured ore features with the planet_ores server switch', None),
    'worldgen:MapGenCaveExt': (R, 'vanilla cave carvers in planet biome data', NO_CARVERS),
    'worldgen:MapGenCrater': (R, 'crater structures moon_crater and mars_crater', None),
    'worldgen:MapGenCraterHuge': (R, 'crater structures (radius capped at 48)', None),
    'worldgen:MapGenCraterSmall': (R, 'crater structures (small radii)', None),
    'worldgen:MapGenGeode': (R, 'geode structure', None),
    'worldgen:MapGenHighCaves': (R, 'vanilla cave carvers in planet biome data', NO_CARVERS),
    'worldgen:MapGenMassiveRavine': (R, 'vanilla canyon carvers in planet biome data', NO_CARVERS),
    'worldgen:MapGenRavineExt': (R, 'vanilla canyon carvers in planet biome data', NO_CARVERS),
    'worldgen:MapGenVolcano': (R, 'volcano structure', None),
    'worldgen:WorldGenCharredTree': (I, 'charred_tree feature in the volcanic biome', None),
}

raw = LEDGER.read_text(encoding='utf-8')
rows = list(csv.reader(io.StringIO(raw)))
seen = set()
for row in rows[1:]:
    if row[0] in DELIVERED:
        assert row[1] == 'PLANNED' and row[2] == 'C15b', row
        disposition, target, notes = DELIVERED[row[0]]
        row[1], row[2], row[3], row[4], row[6] = disposition, 'v1.8.0', target, 'ADR-063', EVIDENCE
        if notes is not None:
            row[5] = notes
        seen.add(row[0])
assert seen == set(DELIVERED), set(DELIVERED) - seen
left = [row[0] for row in rows[1:] if row[2] == 'C15b']
assert not left, left
out = io.StringIO()
csv.writer(out, lineterminator='\n').writerows(rows)
LEDGER.write_text(out.getvalue(), encoding='utf-8', newline='')
counts = {}
for unit, (disposition, _, _) in DELIVERED.items():
    counts[disposition] = counts.get(disposition, 0) + 1
print('delivered', len(seen), counts)
