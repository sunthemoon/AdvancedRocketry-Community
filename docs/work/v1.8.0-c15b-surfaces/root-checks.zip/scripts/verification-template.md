# V180 C15b — the Moon, Mars and Venus surfaces: verification

Date: 2026-10-03. Scope: slice C15b of ADR-062 §6 under
[ADR-061](../../decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md),
[ADR-062](../../decisions/ADR-062-CLASSIC-CONTENT-DISPOSITIONS-AND-BATCHES.md) and
[ADR-063](../../decisions/ADR-063-MATERIALS-ORES-AND-PLANETARY-SURFACES.md) §4 (the Moon
and Mars ores), §5, §8 and §9. ADR-063 revision 3 is accepted; revisions 4 (C15a) and 5
(this slice) are **proposed** and wait for the owner. Branch
`codex/v1.8.0-classic-content`; base `39fc16c` (the C14 acceptance); tested commit
`{RUN}`. Development evidence only: **no Required Gate, candidate or release
decision**. No saved-data schema changes; the three planet Levels get a new generator
for chunks generated after the upgrade.

## Commits

| Commit | Content |
|---|---|
{COMMITS}

## Delivered ledger units

| Unit | Disposition | Delivery |
|---|---|---|
| `biome:moon` | IMPLEMENTED | `advancedrocketrycommunity:regolith_highlands` (moon turf over stone) |
| `biome:moondark` | IMPLEMENTED | `advancedrocketrycommunity:regolith_lowlands` (dark moon turf over stone) |
| `biome:hotdryrock` | IMPLEMENTED | `advancedrocketrycommunity:ferric_regolith` (Mars, ferric sand over red sandstone) |
| `biome:volcanic` | IMPLEMENTED | `advancedrocketrycommunity:volcanic` (Venus, basalt; charred trees) |
| `biome:volcanicbarren` | IMPLEMENTED | `advancedrocketrycommunity:volcanic_lowlands` (Venus, basalt) |
| `block:moonTurf` | IMPLEMENTED | `advancedrocketrycommunity:moon_turf` |
| `block:moonTurf_dark` | IMPLEMENTED | `advancedrocketrycommunity:dark_moon_turf` |
| `block:hotTurf` | IMPLEMENTED | `advancedrocketrycommunity:ferric_sand` |
| `block:charcoalLog` | IMPLEMENTED | `advancedrocketrycommunity:charcoal_log` (does not burn; drops one charcoal, itself with Silk Touch) |
| `block:geode` | IMPLEMENTED | `advancedrocketrycommunity:geode_shell` (iron pickaxe until the C18b jackhammer) |
| `block:basalt` | REDESIGNED | vanilla basalt in the Venus surface |
| `worldgen:WorldGenCharredTree` | IMPLEMENTED | the `charred_tree` feature in the volcanic biome |
| `worldgen:MapGenCrater` | REDESIGNED | crater structures `moon_crater` and `mars_crater` |
| `worldgen:MapGenCraterHuge` | REDESIGNED | crater structures (radius capped at 48) |
| `worldgen:MapGenCraterSmall` | REDESIGNED | crater structures (small radii, weighted as legacy) |
| `worldgen:MapGenVolcano` | REDESIGNED | the `volcano` structure (cone radius at most 32) |
| `worldgen:MapGenGeode` | REDESIGNED | the `geode` structure (radius 16–24) |
| `worldgen:MapGenCaveExt` | REDESIGNED | no carvers on the three bodies, as the legacy defaults; vanilla cave carvers stay available to data-pack planet biomes |
| `worldgen:MapGenHighCaves` | REDESIGNED | as `worldgen:MapGenCaveExt` |
| `worldgen:MapGenMassiveRavine` | REDESIGNED | as `worldgen:MapGenCaveExt`, with vanilla canyon carvers |
| `worldgen:MapGenRavineExt` | REDESIGNED | as `worldgen:MapGenMassiveRavine` |
| `worldgen:CustomizableOreGen` | REDESIGNED | configured ore features with the `planet_ores` server switch |
| `config_file:oreConfig.xml` | REDESIGNED | Moon and Mars ore placed features in data packs |
| `config:WORLDGEN.EnableOreGen` | REDESIGNED | the `overworld_ores` and `planet_ores` server switches |
| `config:WORLDGEN.generateCraters` | REDESIGNED | the `craters` switch and the crater structures |
| `config:WORLDGEN.generateVolcanos` | REDESIGNED | the `volcanoes` switch and the volcano structure |
| `config:WORLDGEN.generateGeodes` | REDESIGNED | the `geodes` switch and the geode structure |
| `config:WORLDGEN.geodeBaseSize` | REDESIGNED | the geode structure's radius 16–24 |
| `config:WORLDGEN.geodeVariation` | REDESIGNED | as `config:WORLDGEN.geodeBaseSize` |
| `config:WORLDGEN.geodeOres` | REDESIGNED | the `geode_ores` block tag (at most 32 kinds) |
| `config:WORLDGEN.geodeOres_blacklist` | REDESIGNED | data packs replace the `geode_ores` tag |
| `config:WORLDGEN.GenerateCopper` | REDESIGNED | Moon and Mars copper ore placed features |
| `config:WORLDGEN.CopperPerChunk` | REDESIGNED | as `config:WORLDGEN.GenerateCopper` (10 veins of 6) |
| `config:WORLDGEN.CopperPerClump` | REDESIGNED | as `config:WORLDGEN.GenerateCopper` |
| `config:WORLDGEN.GenerateTin` | REDESIGNED | Overworld, Moon and Mars tin ore placed features |
| `config:WORLDGEN.TinPerChunk` | REDESIGNED | as `config:WORLDGEN.GenerateTin` (Moon and Mars: 10 veins of 6) |
| `config:WORLDGEN.TinPerClump` | REDESIGNED | as `config:WORLDGEN.GenerateTin` |
| `config:WORLDGEN.GenerateRutile` | REDESIGNED | Overworld, Moon and Mars rutile ore placed features |
| `config:WORLDGEN.RutilePerChunk` | REDESIGNED | as `config:WORLDGEN.GenerateRutile` (Moon and Mars: 6 veins of 6) |
| `config:WORLDGEN.RutilePerClump` | REDESIGNED | as `config:WORLDGEN.GenerateRutile` |
| `config:WORLDGEN.generateAluminum` | REDESIGNED | Overworld, Moon and Mars aluminum ore placed features |
| `config:WORLDGEN.AluminumPerChunk` | REDESIGNED | as `config:WORLDGEN.generateAluminum` (Moon and Mars: 1 vein of 16) |
| `config:WORLDGEN.AluminumPerClump` | REDESIGNED | as `config:WORLDGEN.generateAluminum` |
| `config:WORLDGEN.generateIridium` | REDESIGNED | Moon and Mars iridium ore placed features (none in the Overworld) |
| `config:WORLDGEN.IridiumPerChunk` | REDESIGNED | as `config:WORLDGEN.generateIridium` (1 vein of 16) |
| `config:WORLDGEN.IridiumPerClump` | REDESIGNED | as `config:WORLDGEN.generateIridium` |
| `config:WORLDGEN.generateDilithium` | REDESIGNED | Overworld, Moon and Mars dilithium ore placed features |
| `config:WORLDGEN.DilithiumPerChunk` | REDESIGNED | as `config:WORLDGEN.generateDilithium` (Mars: 1 vein of 16) |
| `config:WORLDGEN.DilithiumPerChunkLuna` | REDESIGNED | the Moon dilithium ore placed feature (10 veins of 16, the airless count) |
| `config:WORLDGEN.DilithiumPerClump` | REDESIGNED | as `config:WORLDGEN.generateDilithium` |

Fifty rows: 11 IMPLEMENTED, 39 REDESIGNED. The Moon and Mars ores sit between
y 4 and 40; the Moon's target the vanilla stone replaceables, Mars red sandstone.

Registered by C15b ({COUNT}, named in both languages):
{REGISTERED}.

Also, all in this mod's namespace: the biomes `regolith_highlands`,
`regolith_lowlands`, `ferric_regolith`, `volcanic` and `volcanic_lowlands`; the
structure types and piece types `crater`, `volcano` and `geode`; the feature
`charred_tree`; the biome source `patches`; the noise `moon_terrain`; the noise
settings `moon`, `mars` and `venus`; the structures `moon_crater`, `mars_crater`,
`volcano` and `geode` with their sets; twelve configured and placed ore features
(`moon_*_ore`, `mars_*_ore`); the block tag `geode_ores`; four
`has_structure/*` biome tags; and the COMMON values `worldgen.planetOres`,
`worldgen.craters`, `worldgen.volcanoes`, `worldgen.geodes` and
`worldgen.charredTrees` (default on). The release-test commands
`/arce surface release-test generate|sample` exist only with the release-test hook
property.

The v1.8 dimension files for the Moon, Mars and Venus supersede the v0.3 Moon and
the v1.4 Mars and Venus copies, and the v1.8 Mars and Venus noise settings supersede
the v1.4 ones (their routers are copied unchanged; only the surface rules change).
`build.gradle` excludes the superseded copies from the main and sources JARs.

## Contract tests (ADR-063 §9 for C15b)

| Requirement | Test |
|---|---|
| A0 worldgen and tag JSON audit | `V180PlanetResourcesTest`: the Moon Level, router, noise and biome source; Mars and Venus keep the v1.4 router and change only surfaces and biomes; biomes spawn nothing and carve nothing; the Moon and Mars veins against the contract; structures and sets; blocks with loot, models, tools and names; the charcoal log and other drops |
| A0 structure and feature bounds | `SurfaceShapesTest`: craters within radius, rim and reach; crater ranges validated; volcanoes within radius 32 and height 48 with a contained lava pool; geodes within radius 24 with an open middle; the Venus patches use every biome and are stable |
| A0 DataGen determinism | `runData`, then `git status -- src/generated` clean; `V180SurfaceArtTest` re-encodes the six textures and compares them with the committed bytes |
| A0 asset derivation | No file is imported. The six drawn textures pass `tools/audit/screen_generated_art.py` with the 19 C15a textures (25 `CLEAR`) |
| A1 ore placement | `eachBodyCarriesItsOreSetWithIridium` (the Moon and Mars biomes carry their six veins each, iridium on both, Moon dilithium 10 of 16; Venus none), `eachPlanetVeinReplacesOnlyItsBodysRockNearItsOrigin` (each vein replaces only its body's rock, within 5 blocks), `planetVeinsStayInTheirChunkAndFollowTheServerSwitch` (each vein's count of positions inside the origin chunk at y 4–40 on the Moon and Mars; none with the switch off) |
| A1 structure bounds | `aMoonCraterWritesOnlyItsChunkWithinItsBounds`, `aVolcanoWritesOnlyItsChunkWithinRadius32AndHeight48`, `aGeodeWritesOnlyItsChunkWithinRadius24BelowTheSurface`: each piece is placed chunk by chunk through a recording level; every write lies inside the chunk being generated and the piece's box, and every block outside the piece is unchanged; `eachBodysGeneratorTriesItsOwnStructureSets` (worldgen tries each body's own structure sets and no other) |
| A1 feature bounds | `aCharredTreeStaysWithinItsReach` (twelve seeds: a trunk of six to eight logs, nothing beyond one block sideways) |
| A1 Moon height bound | `moonSurfaceStaysBetweenY12And36ForTwoSeeds` (a 64 × 64 grid, 4,096 columns, for the world seed and a second seed; both biomes on their own height bands); crater rims are capped at y 44 by the crater test and `SurfaceShapesTest` |
| A1 Moon landing | `aMoonRocketArrivesAtY80OverTheHighestHighlands`, `aMoonRocketArrivesAtY80OverACrater` |
| A1 developer platform | `theDeveloperPlatformStaysInOpenSkyOverTheHighestHighlands` |
| A1 each server switch | `planetVeinsStayInTheirChunkAndFollowTheServerSwitch` (`planet_ores`), `eachStructureSwitchStopsItsStarts` (`craters` on the Moon and Mars, `volcanoes`, `geodes`), `theCharredTreeFollowsItsServerSwitch` (`charred_trees`), `CommonConfigTest` (61 values) |
| New surfaces in new chunks | `newChunksUseTheNewSurfacesAndBiomes` (top, filler, rock and biome on the three bodies), the updated v1.4 `PlanetaryWorldGameTests` |
| Saved pieces (revision 5) | `savedPiecesLoadBackAndRefuseAnotherSchema` |
| Drops and tools (revision 5) | `theCharcoalLogDropsCharcoalAndTheGeodeShellNeedsAnIronPickaxe`, `theCharcoalLogDropsCharcoalAndTheOtherSurfaceBlocksThemselves` |
| S1 packaged server | `native_c15b_check.py` (below): crater starts on the Moon and Mars and a geode start on Venus in new chunks, generation within 1.5 × the Overworld's time per chunk, explored chunks unchanged |

The two Tau Ceti Levels of the S1 sentence come with C15c.

## Native check (S1)

{NATIVE}

## Generated art

The six textures (moon turf, dark moon turf, ferric sand, the charcoal log side and
top, the geode shell) are 16 × 16 palette grids in `V180SurfaceArt`, written by
DataGen (`NEW`). The legacy turf and log textures were excluded as vanilla-derived
(ADR-061 §4.8), and the geode shell rule became `REGENERATE` (`495d758`). The screen
reports all 25 v1.8 textures `CLEAR` against both vanilla clients
(`python/art-screen.json` in `root-checks.zip`). The screen is a measured check, not
proof of originality; the ADR-061 §4.5 human visual review is open.

## Commands actually executed

Windows host, Java `C:/Program Files/Java/jdk-17.0.7`, Gradle 8.8, Python 3.13.

| Command | Result |
|---|---|
| `gradlew --offline clean build test runData runGameTestServer` on `{RUN}` | Exit 0, {T1}. **{GT} required GameTests** passed. `git status -- src/generated` after DataGen: clean |
| `gradlew --offline test --rerun` | Exit 0, {T2}. **{JUNIT} JUnit tests / {SUITES} suites**, 0 failures, errors or skips |
| JAR resource check (`jar-resource-check.txt`) | {JARCHECK} |
{PY_RESULTS}

Final validators: {FINAL}

The three JARs (`artifacts.json`, with every entry in `artifact-entries.json`): main
`{MAIN}…`, API `{API}…`, sources `{SRC}…`. The full build log has {ERRORS} ERROR lines and
0 FATAL, from intentional failure-injection GameTests and the missing
`server.properties`. This is not a clean-log claim.

## Fixed during the slice, before the first commit

{FIXED}

## Not verified

- Any client: the new blocks' models and textures, the biome colours and fog, and the
  Moon's black sky (V0/V1); the ADR-061 §4.5 human visual review of the six textures.
- A long exploration: the S1 run generates 9 × 9 chunks per body; the GameTests sample
  4,096 Moon columns for two seeds.
- `/reload` with changed worldgen data (worldgen registries load at start only).
- The CI workflow on GitHub (this branch has no pull request).
- ADR-063 revisions 4 and 5 and ADR-061 revision 7 are proposed, not accepted.

Next: the C15b implementation review, then the owner's decision on ADR-063 revisions
4 and 5 and ADR-061 revision 7, then C15c in
[COMPLETION-PLAN](../../status/COMPLETION-PLAN.md).
