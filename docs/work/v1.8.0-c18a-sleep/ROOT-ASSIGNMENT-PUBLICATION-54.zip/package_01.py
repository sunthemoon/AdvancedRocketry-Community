"""Actual two Root seals and one counter seal; no universal-schema assumption."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
specs = json.loads((OUT / 'INPUT-SEALS-01.json').read_text(encoding='utf-8'))
assert [s['profile'] for s in specs] == ['root', 'root', 'counter']
for spec in specs:
    leaf = OUT.parent / spec['leaf']
    raw = (leaf / 'SEAL-RESULT.json').read_bytes()
    assert sha(raw) == spec['seal_sha256']
    result = json.loads(raw)
    assert result['report_sha256'] == spec['report_sha256']
    assert result['manifest_sha256'] == spec['manifest_sha256']
    if spec['profile'] == 'root':
        assert result['exit_code'] == 0 and result['gate_approval'] is False
        assert set(result['excluded']) == set(spec['exclusions'])
    else:
        assert result['outcome'] == 'SEALED_CUSTODY_ONLY'
        assert set(result['exact_exclusions']) == set(spec['exclusions'])
        command = json.loads((leaf / 'custody-seal-28.command.json').read_bytes())
        assert command['exit_code'] == 0 and command['timeout'] is False
        assert command['ceiling_seconds'] == 180
        for stream in ('stdout', 'stderr'):
            data = (leaf / ('custody-seal-28.' + stream + '.txt')).read_bytes()
            meta = command[stream]
            assert meta['overflow'] is False
            assert len(data) == meta['raw_bytes'] == meta['retained_bytes'] <= 262144
            assert sha(data) == meta['raw_sha256'] == meta['retained_sha256']

original = OUT.parent / 'sleep-native-log-disposition-20261009-39/package_01.py'
raw = original.read_bytes()
assert sha(raw) == '7e177d58e499f9b938cf0814d357a492c409a2bef6b7b68cc148a880e4515e35'
source = raw.decode('utf-8').replace('assert len(SPECS) == 2', 'assert len(SPECS) == 3')
source = source.replace("{'SHA256SUMS.txt', 'SEAL-RESULT.json'}", "set(spec['exclusions'])")
source = source.replace("'excluded_entries': ['SHA256SUMS.txt', 'SEAL-RESULT.json']", "'excluded_entries': spec['exclusions']")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
