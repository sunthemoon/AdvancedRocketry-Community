# Root54 assignment and terminal-evidence publication

Date: 2026-10-09 UTC. Root sole integration; version/active objective remain open.

## Completed scope and decisions

Exact8 Main files (5 Markdown /3 ZIPs) are normally committed/pushed at
0dcfaf980e4a4236ff5e3c8630286b40b34eebb1, parent e21fdbd7. CURRENT_VERSION,
COMPLETION-PLAN and implementation log record active isolated functional53,
independent55 and M1 feasibility56. New FUNCTIONAL-SOURCE-ASSIGNMENT-54.md and
OWNER-QUESTION-04.md preserve declared writes and the exact pending Space question.
No recommended/default selection is treated as an owner submission or approval.

Root publishes only assignment/custody facts and actual sealed50 probe results;
no source integration, decoder/resource qualification, platform helper/lifetime
narrowing, M1 mechanism, production sleep or Gate is adopted. Normative37+43,
D1 outcomes and log refusal requirements remain separately scoped and unchanged.
Provider/door source research is not a runtime observation or production grant.

Complete stable Root52/Root-assignment53 reports/audits and report50 are read
before relevant exact-hash acknowledgments and actual custody seals. Task55's
stable420-line/29984-byte report is separately completely read after Main54
publication; SHA25610202fdfa46a7f01519dd91083a445587b95f3a2b61effbf49bc391d17fe193b
matches. Its two independent finite cohorts and R55-01/02 remain separately
disposed; this packet does not rehost55 or infer global R49/R55/U01/U02 closure.

## Actual commands, files and evidence

INPUT-SEALS-01.json pins manifests/reports/actual-result hashes for Root52,
Root53 and Task50. package-01 verifies exact declared flat Root/counter schemas,
Task50 excluded actual command/stream hashes, all manifest members/exclusions,
safe contained case-unique names, ZIP CRC and byte-exact payloads. No prior seal
changes, universal assumed schema or duplicate source-tree export.

ROOT-NORMATIVE-FREEZE-52.zip is41381 compressed /118840 expanded bytes,
SHA2569813b9f3faeff4ba4ebbd01ef1f66735f39ef667a82952567d697da9e9d82c64.
SOURCE-ASSIGNMENT-53.zip is21850 /47551,
SHA2564055fe032f3c780a3f997ee5dbc944471e8c9436186763cbda4e00340a8dc155.
TERMINAL-COUNTER-50.zip is135607 /284173,
SHA2562f3eb7f6d766038fb72de1745ed118efb0098a3649e0964da0e806a6cd906f28.
Root52/53 exclude only manifest self/result;50 also excludes the three
custody-seal-28 receipt/stream files, separately verified and included in ZIP.

PACKAGING-01 records actual43 sleep ZIPs13795443 compressed /67879839 expanded
bytes; unchanged65011712 reserve gives132891551 conservative expanded-plus FAIL
before loose/later sets (compressed-plus78807155 is a different measure).
This is not an atomic launch inventory. Individual file/slice publication limits
pass; no deletion/relabeling/cap/quota/waiver or native launch.

All16 retained static/package/Git receipts exit0/no timeout; actual argv/cwd/UTCs,
raw split lengths/hashes and protected before/after snapshots are retained.
No uncaptured command is relabeled as successful receipt. Key actual intervals:

- package-01:10:32:01.341926-10:32:02.054149 UTC.
- links-02:10:34:52.700567-53.306564; whitespace-03:53.986197-54.127324.
- stage/stat/diff/check04-07:10:36:10.113038-10:36:12.388043. Separately named
  spacing-stage/check08-09:10:37:03.329405-10:37:04.145362; terminology-stage10
  and final stat/full diff/check11-13:10:40:20.362467-10:40:22.749944. The exact
  final cached stat and complete raw UTF-8 diff are read before commit;8 files,
  160 insertions /3 deletions. Thin console CP936 is lossy, raw UTF-8 intact.
- commit-14:10:41:25.769453-26.017609; normal push15:10:41:26.691068-30.220959.
  All three workers confirm fixed/disjoint inputs before Main HEAD move.
- source-candidate-16:10:45:10.284525-10:45:10.332191, actual fixed source
  fa83657f89095a78bfb97ac39918ee1b74139d5b shows only two additions,397/426 lines.
  It is an isolated candidate, not Main integration or independently verified
  functional acceptance here. Author's test claims are not Root rerun results.

Initial combined tool exploration returns exit1 on missing src/main/java/org and
truncates aggregate worktree/source display. Later narrow exact D1/sleep/source
path/document reads preserve this preparation gap; no historical raw receipt is
reconstructed. Pinned own runner uses finite post-capture fixed180-second static
commands, not streaming allocator/OS preemption; final own audit checks caps.
Worker static/schema/fixture/transport failures stay in their own evidence.

## Tests, uncompleted scope, risks and Gates

Root54 adds/modifies/runs no tests. Gradle clean build/test/runData/generated-diff/
runGameTestServer, resource/native/dedicated/restart/real-client/Unicode checks
NOT_EXECUTED, not PASS or inapplicable. No d57 historical regression is rebound.
Actual20 observations/thirteen D1 rows remain unexecuted. Isolated source53 and
fresh actual-code reviewer57 are separate tasks; no test/runtime authority inferred.

Uncompleted: independent actual-source/functional and finite resource qualification;
platform/native/traced lifetime and unavailable-counter handling; M1/B1/R1/M2/D1
implementation/runtime; Space policy; source-schema/Gson/framing/NBT/provenance,
whole driver/helper/quota/capture/I/O/Unicode; log/recipe/R-021 save/log/recovery,
old-world/client/item/asset/hatch and inherited full-version acceptance. No smaller
end state substitutes for the active original v1.8 objective.

Protected Main src tree85f53265bf4ee59b65c4a88664cb2e5e208c583e, no source/scripts/
build/API/schema/ADR/risk/ledger/Gate change. User AGENTS SHA256
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09 is untouched/
unstaged; expected tracked state only M AGENTS.md, index empty, HEAD/upstream0dc.
No peer/untracked/world/process takeover, cleanup, install or force push.
Ledger186 PLANNED /154 REVIEW, ADR-068 PROPOSED/R-021 OPEN unchanged.
**All current-version Required Gates G0-G9 satisfied: NO.** No release/tag/waiver.
Evidence is this exclusive sleep-source-and-air-assignment-publication-20261009-54
leaf and committed checkpoint54/three ZIPs. Later own audit/full read/ack/seal
are not preclaimed. Next v1.8 work is actual code57, complete source53/55/56
evidence and scoped dispositions, then unchanged downstream qualification.
