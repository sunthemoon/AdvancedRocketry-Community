# Proposed finite packaged observation driver and parser

**Design only; no executable/parser/source freeze or launch authorization.**
Task 05's exact twenty cases are the scope. Native Spawn, pose, occupancy, chat
and frame outputs are recorded, not populated by this document. Source
`0c05cc27` is provisional and requires Task 08/Addendum 10 source corrections
and independent review. Sealing this design record does not freeze its schema
or authorize execution. Root's final pre-seal instruction fixes the total cell
inventory and the pre-executable-freeze wrapper provenance requirement below.

## 1. Input identity and preflight contract

Before a later authorized launch, freeze one committed task input manifest
with the following identities and verify them again after collection:

| Input | Required evidence/check |
|---|---|
| Governance/task/source | Fixed governance SHA, Task 05/08 and runtime-task hashes; final two-class candidate and actual host/fixture source commits; review disposition. A moving Main branch is not the source identity. |
| Driver/parser/tests/helpers | Published fixed commit/archive and individual SHA-256/length; exact bytes equal to their Git blobs, including staged/unstaged drift checks. No ambient import, stale bytecode, unverified plugin/helper or mutable cache module. Any helper must be separately reviewed before execution. |
| Host/API/fixture JARs | Fresh build/publication receipts on the named source cohort; SHA-256/length, CRC and duplicate-name/entry checks; mods.toml identity/version; API-only consumer dependency receipt and reobfuscation receipt. Both sleep classes/nested classes appear in the separate `arce_adapter_test` JAR, never the shipping host. No historical jackhammer hash is an allowed sleep input. |
| JDK | Exact Java 17 executable path/SHA-256, JDK release identity, full `-version` stdout/stderr/exit, OS/architecture. The historical recipe used JDK 17.0.7; that is a reference, not a substitute for measured launch identity. Reject JAVA_TOOL_OPTIONS/JDK_JAVA_OPTIONS/_JAVA_OPTIONS or other ambient injection unless explicitly frozen. |
| Libraries | Source template absolute identity; exact manifest of all used relative library files, lengths and SHA-256; hashes of win_args.txt and every recursively referenced argument file; copied bytes rechecked. Forge `1.20.1-47.4.10`, no install/download. The historical 104-file count is not an acceptance rule. |
| cwd/argv/environment | Absolute fresh runtime cwd, complete expanded argument identity, command argv, child-only TEMP/TMP/java.io.tmpdir, UTC and monotonic boundaries, owned PID/start time. Pin native launch target, module/class paths and all configuration; disallow arce.gameTestHooks and unassigned fixture opt-ins. |
| Fresh world/actors | Absent owned runtime/world path and both UUID playerdata files before creation; no imported world/playerdata or ordinary players. Generate a fresh local ownership marker bound to task/source/artifacts/config, hash it before/after. |
| Containment/space | Every input/output/ancestor has no symlink/junction/reparse point; output neither contains nor is inside inputs. C: and D: each have >=10 GiB before each launch. No input template mods/config/world tree is copied. |

Use the established copied-libraries/native Java launch recipe, not Gradle
runServer or a development runtime. Install exactly the frozen host and separate
fixture JARs in a new mods directory; reject unexpected mods/datapacks/config.
Start from absent world and config, record generated COMMON/server config hashes
and values when available, and inspect them again after stopping. No later
dimension replacement, air/sleep/spawn policy or configuration bypass is added.

Proposed native argv, with all placeholders filled and frozen before launch:

`<verified-java> -Xms512M -Xmx2G -Djava.net.preferIPv4Stack=true -Djava.io.tmpdir=<owned-temp> -Darce.sleepBoundaryObservation=true @libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt nogui`

Use the native console command `arce_sleep_boundary_observe` only. Require
permission 4, exact native server console, owning thread, no ordinary players,
absent owned UUIDs and no reentrancy, as reviewed in final source. Player/RCON/
NULL sources are not admitted. Default-disabled/source authority tests belong to
the separate authorized test assignment; this opt-in launch cannot prove the
disabled launch by itself.

Freeze server.properties as the established recipe: `127.0.0.1`, newly allocated
loopback port, offline mode, secure profile enforcement false, peaceful,
survival/force-gamemode false, max-players 2, view/simulation distance 2,
spawn-protection 0, sync-chunk-writes true, command blocks/query/RCON false,
normal world, seed 0, generate-structures false, level-name world. Use a
sleep-specific MOTD/ownership marker. Record exact sorted bytes/hash and native
readback, plus eula and generated configuration. Native peaceful behavior is an
input, not monster qualification. A later task may authorize the established
bounded loopback **status** query for identity; it is TCP status only, not a
connected gameplay actor or client login/input/ack.

## 2. Finite schedule and evidence retention

Use one fresh native process. No restart, warm-up loop, changed timeout, retry
or replacement world is part of this design.

| Step | Ceiling and evidence |
|---|---|
| Java version preflight | Established 30 s; retained full version output/exit. |
| Native startup | Established 300 s to trusted native Done marker; UTC/PID/cwd/argv/raw stdout. |
| Optional authorized loopback status identity | Established 60 s, with established per-request 5 s bound; retain actual response and host/fixture versions. Never gameplay proof. |
| Invocation 1 | Exactly one console command; 60 s to one trusted structured response after its recorded stdout byte/line cursor. All twenty synchronous cases share this ceiling, not twenty separate 60 s extensions. |
| Native save 1 | `save-all flush`, 60 s to a new native Saved-the-game marker after its command cursor. Copy/hash the two owned, already logged-out playerdata files to compact phase evidence. |
| Invocation 2 | Only after invocation 1 has a parseable bounded result, no unresolved unexpected setup/native/capture/cleanup failure, and owned teardown is supported by final source/records. Exactly one command with the same 60 s ceiling. Case 19's reached/attributed intentional failure alone is not a retry or a stop condition. |
| Native save 2 | Same new `save-all flush` and 60 s ceiling; retain actual saved playerdata/hash/projection separately. |
| Stop and exit | `stop`; established 90 s exit ceiling, exit code, native Stopping-server then all-dimensions-saved order, reader completion. Retain stdout.txt, actual runtime logs/latest.log and logs/debug.log before disposable cleanup. |

If startup/action/parser/preconditions fail, do not launch a second invocation
or silently retry. Retain any actual response and partial effects. If native
stdin remains usable, attempt normal save/stop within the same 60/90 s bounds;
otherwise the later authorized driver may terminate only its exact owned
process, using the baseline 15 s terminate /15 s kill /5 s reader bounds. Forced
termination is a failed normal-save/exit observation, never crash-recovery proof.
Record each failure and cleanup attempt independently; do not raise before
persisting the receipt/raw logs. No signal is sent to an unrelated process.

At most one startup, two actions, two saves and one stop: the successful-path
native deadline is <=690 s excluding finite preflight/copy/parser work; optional
forced-exit waits add at most 35 s. Proposed separate non-native limits are 180 s
for manifest/JDK preflight and library/JAR/config copying (Java's own 30 s is
inside it), 60 s per post-save phase for bounded copy/NBT/response inspection,
60 s for final raw-log retention/hash checks, 60 s for offline reparse and 60 s
for own cleanup. Thus the complete proposed task budget is <=1205 s, including
optional forced-exit waits. Reject oversized input manifests/logs before these
operations; freeze their exact finite file/entry counts. Deadline failure retains
an incomplete receipt, not a larger limit or unbounded work between stages.

Preserve merged stdout/stderr **raw bytes** by streaming, not lossy decoding or
only a tail. Index command send times and marker byte/line spans in separate
receipts; never inject fabricated native marker lines. A bounded in-memory
scanner may retain only one candidate line and fixed marker state while spooling
raw logs. Do not inherit the historical helper's unbounded `self.lines` list
without a reviewed bound. Missing latest/debug logs, invalid marker encoding,
read/copy failure and forced termination remain explicit evidence gaps.

Retain compact INPUTS/COMMANDS/RESULT, raw stdout/latest/debug, two exact
structured response extracts with raw offsets/hashes, typed Spawn projections,
the bounded actual native playerdata files, parser findings, process/containment
and cleanup receipts. No source/world/runtime archive. Respect <=50 MB per
repository evidence file and <=100 MB per slice; an oversize raw log is a
retention issue requiring explicitly located external storage plus hash or a
new assignment, never permission to truncate away a failure. Offline parser
rejects files outside its frozen size budget.

## 3. Frozen fixture inventory and exactly twenty rows

Evidence class is **native-Java simulated transport**: native PlayerList actors
on own open EmbeddedChannels and public native packet/accept handlers. It is
not decoder/scheduling, TCP gameplay, real-client acknowledgement or multiplayer.

- SleepObsA: `3ec99863-f1a1-4ba6-8aaa-390209dbe2d0`; SleepObsB:
  `c5c1adf3-c2b4-4f57-8c98-576bfe5bbcf5`. Native placeNewPlayer/removal owns load,
  registration and logout save. Record original loaded Spawn before any reset.
- Overworld chunk (0,0), valid build bounds/world border. WHITE_BED, EAST,
  MAIN_HAND, empty both hands. Head (12,180,12), foot (11,180,12).
- Root's final design instruction freezes **12 total touched cells**, including
  bed halves and support/clearance: head/foot, their below/above cells,
  (11,179,11)/(11,180,11)/(11,181,11), and
  (10,179,12)/(10,180,12)/(10,181,12). Verify the final reviewed source matches
  this exact inventory; any expansion requires a new explicit assignment.
  Capture/restore exact states; initial cells are BE-free. No search. The prior
  two-halves-plus-16 wording is superseded, not an 18-cell allowance.
- Home A (8,180,8), angle 23.75f, forced true; B (8,180,10), angle -17.5f,
  forced false, native Overworld. Day/night preparation 6000/18000 and temporary
  doDaylightCycle/doMobSpawning false. These are inputs only.
- Freeze declared actor teleports/hit vector/face, normal native permissions,
  loaded-bed and actual native reach/day checks from final source. The
  provisional A range-control x is 2.5 instead of 11.5; B x is 10.5, y 180.
  Normal wake applies only to actual sleepers; no pose setter/direct sleeping.
- Record fixture getChunkAt, native login/teleport preparation and real owned
  outbound position packet ID/public simulated accept separately. No forged
  acknowledgement ID, private field or no-ticket guarantee. Handler refusal
  cannot be replaced by a direct game-mode/sleep call.

The parser checks this exact number/name sequence, not a count alone:

| # | Row name | Required executed route/control attribution, not a native verdict |
|---:|---|---|
| 1 | day_head_observer_off | Ordinary public handleUseItemOn; observer off. |
| 2 | day_head_observer_on | Equivalent declared day/head inputs; observer on. |
| 3 | day_foot_observer_off | Ordinary handler day/foot; observer off. |
| 4 | day_foot_observer_on | Equivalent declared day/foot inputs; observer on. |
| 5 | night_head_observer_off | Ordinary handler night/head; observer off. |
| 6 | night_head_observer_on | Equivalent declared night/head inputs; observer on. |
| 7 | night_foot_observer_off | Ordinary handler night/foot; observer off. |
| 8 | night_foot_observer_on | Equivalent declared night/foot inputs; observer on. |
| 9 | packet_range_refusal | Ordinary handler with verified native out-of-range setup. |
| 10 | occupied_bed_refusal | Ordinary handler with declared occupied bed state, not posed sleeper. |
| 11 | native_admin_forced | Public native administrative forced setter. |
| 12 | native_same_bed_tuple_unforced | Separately labeled same-tuple forced seed, then native forced=false setter. |
| 13 | native_null_reset | Public native null reset. |
| 14 | nested_native_admin_same_actor | Guarded same-actor setter inside genuine handler-caused spawn dispatch. |
| 15 | nested_native_admin_other_actor | Guarded other-actor setter inside genuine dispatch. |
| 16 | nested_synthetic_bus_same_actor | Guarded same-actor synthetic bus post inside genuine dispatch. |
| 17 | nested_synthetic_bus_other_actor | Guarded other-actor synthetic bus post inside genuine dispatch. |
| 18 | direct_and_forwarded_callbacks | Same-actor direct callback and other-actor forwarded callback, labeled not bus posts, inside genuine dispatch. |
| 19 | one_shot_observer_failure | Declared reached one-shot observer-failure intervention; preserve actual native return/throw/partial effects. |
| 20 | independent_admin_after_failure_teardown | Separate public native administrative observation after row 19's owned teardown. |

Do not count rows initialized UNEXECUTED as execution. A handler returning early
can be a completed native attempt without having reached a setter; record
coverage separately. For 14-18 require actual control-fired/outer-event/context
evidence, not merely a planned label. If genuine dispatch or case 19's
intervention is not reached, preserve the missing observation. Never manufacture
an event/frame to complete the row.

## 4. Response/schema and bounded parser contract

Freeze a source-schema document and golden **structural synthetic** parser
fixtures only after final corrected source is reviewed. Synthetic data must be
marked non-native and must not contain purported successful bed/frame results.
The current prefix is `ARCE_SLEEP_BOUNDARY_OBSERVATION `; provisional root format
is `ARCE_SLEEP_BOUNDARY_OBSERVATION_1`, evidenceClass is the exact simulation
label, cases and lifecycle are arrays, and each row has number/name/status plus
preparation/actions/events/outputs/cleanup. Outcome, traceStopped/incomplete,
capture-attempt and persisted-event totals exist provisionally. Final spelling,
required/optional/null fields and failure/measurement shape await source freeze.

Required final contract, independent of field spelling:

- <=512 KiB UTF-8 JSON per invocation including lifecycle, rows, finish fields
  and explicit incompleteness; <=128 KiB per row; <=128 attempted events per
  invocation and <=32 per row; <=64 real frames and at most one overflow sentinel
  per event; <=512 invocation-owned identity tokens. Freeze delimiter/wrapper
  accounting separately (proposed line bound: payload cap +4096 bytes).
- Size checks precede allocation proportional to untrusted string/chat/frame
  input. Oversized/unavailable metadata/chat/snapshot/accounting is explicitly
  incomplete, not a valid silently shortened observation. Preserve incomplete
  final output and reserve its bounded overhead; parser rejection cannot fix
  source allocation. Measurement labels describe actual measured scope;
  allocation is null/unmeasured unless public measurement was already enabled.
- Scoped positive integer tokens (0/null only where defined) bind owned actor,
  event, Level, connection/listener, observer and declared callback identities.
  A maps to its exact UUID and B to its exact UUID, never borrowed objects.
  Reused event tokens are allowed for the same explicitly forwarded object;
  do not globally assume all events are unique or compare token integers across
  invocations. Tokens/identityHashCode are not external authentication.
- Record actual event actor/Level/Spawn tuple/forced/cancellation-at-observer,
  current route/control/context/depth and frame declaring class/descriptor/member.
  Nested callback arguments and outer event references have separate attribution.
  LOWEST receiveCanceled is not final authority: retain post-action getter/native
  snapshots as well. No desired stack sequence, cause verdict or receiver proof.
- Record native before/after getter dimension/position/null/angle raw float bits/
  forced, actual player pose/sleeping/eye/position, both loaded bed states, hands,
  permission/reach, native list/connection identity and owned outbound replies.
  Preparation resets, actual actions, interventions and cleanup have distinct
  arrays/phases. Missing snapshots are incomplete evidence, not empty success.
- Freeze per-string, nesting and per-collection bounds from actual corrected
  source in addition to total bytes. Proposed parser depth cap is 32, with no
  repair/default-filling of a deeper malformed result. Numeric fields use exact
  types (bool is not int), finite numbers, signed raw-float-bit domain and valid
  bounded coordinates. JSON duplicate keys, non-finite literals, malformed UTF-8,
  trailing data and unknown schema/version are rejected.

Parser acceptance sequence:

1. Verify persisted input/artifact/argv/config hashes and marker ownership. Read
   raw log streaming with finite byte/line buffers; count the marker anywhere.
   Accept exactly one complete trusted fixture stdout record within each
   command's nonoverlapping cursor window and exactly two overall for a completed
   two-invocation run. Reject wrong logger/thread/fixture class, console echo,
   nested quoted marker, oversized/malformed marker, duplicates and stale rows.
   Before executable freeze, establish the wrapper using fixed primary native
   logging/STDOUT provenance and the already inspected immutable recipe,
   bound to the final packaged source identity. Retain exact supporting paths,
   commits/hashes and offsets. Do not first run an unassigned server to discover
   or relax an accepted wrapper. If primary/recipe support is insufficient,
   wrapper acceptance remains unfrozen. A raw-prefix allowance is not inherited
   automatically from the old driver.
2. Enforce payload/row/event/frame/token/collection/depth/type limits before
   building an unbounded object tree. Verify exact twenty-row sequence, off/on
   flags (off only 1/3/5/7), source route mapping, terminal or explicit unexecuted
   statuses, control reachability and event totals. Root summary is cross-checked
   against rows, never treated as a parser PASS command.
3. Validate declared setup and identity at the primary action, not just command
   entry. Equivalent off/on prepared inputs are compared; compare actual native
   output projections without diagnostic tokens/timing. Record equality,
   differences and insufficient reachability as observations. No spawn/pose/frame
   outcome is prefilled, and matching early refusals cannot prove setter passivity.
4. Separate five results: execution completeness, trace completeness, native
   observations/comparisons, intentional intervention reached/attributed status,
   and setup/native/capture/cleanup failures. Recognized case 19 failure remains
   in the native result; an unexpected failure, missing intervention or later
   row-20 failure is not forgiven. Cleanup has an independent status and receipt.
5. Audit complete stdout/latest/debug for all WARN/ERROR/FATAL/client-linkage/
   player-save warnings and unexplained exceptions, preserving source line spans.
   If case 19 causes native eventbus exception logging, correlate it to that
   invocation/window and exact declared exception using reviewed schema; record
   it as intentional diagnostic, not a blanket waiver or clean-log Gate. Never
   suppress a whole logger/message pattern or unrelated project errors.
6. Verify each save marker is new and native, stop precedes completed native
   all-dimensions save, and process/reader exit is measured. Retain raw files/hashes.
   Independently rerun only this frozen **offline parser**, without native launch
   or source helper import, against the retained evidence before deletion.

Parser mutation tests to implement later: missing/duplicate/reordered/wrong-name
rows; bool-as-int, NaN and duplicate keys; wrong actor/UUID/connection references;
off-row events; stale/wrong-logger markers; every byte/event/frame/sentinel/token
cap at limit and one over; unavailable/incomplete fields; missing outer/control
reach; intentional versus unrelated exceptions; row-20/cleanup failure retained;
save/stop order and nonzero exit; changed staged/helper/JAR/config bytes;
linked/overlapping inputs; malformed/oversized/wrong-type saved NBT. These tests
validate the parser only and must not be copied into native evidence.

## 5. Native saved Spawn and cleanup attribution

Read only the two exact UUID native playerdata files after actors are removed
and after each native flush; copy/hash their bytes before second invocation can
replace them. Bounded reader: compressed <=1 MiB, expanded <=4 MiB, plus frozen
NBT depth/collection/string/duplicate-field limits. Retain root compound, UUID
typed int-array and DataVersion typed int, then exact present/absent wire types
and raw float bits for SpawnDimension, SpawnX/Y/Z, SpawnAngle and SpawnForced.
Pin actual native serializer/default behavior before defining a getter-to-disk
projection; unexpected partial/mistyped fields are findings, not coerced values.
No full-player JSON clone, native NBT edit, manual load or extra persistence root.

Compare actual disk Spawn to the preceding native logout/save-input getter
projection and to the loaded-field restoration evidence, using only the pinned
native absence/default rules. Invocation 2 records its actual native loaded
Spawn before resets; compare that projection to save 1 where supported. This is
same-process native logout/reacquisition, not server restart or per-action
persisted Spawn, and it cannot establish online-first-save-at-stop durability.

Fixture cleanup is synchronous, exact and independent even after partial
acquisition/failure. Addendum 10 requires marker ownership to begin inside its
responsible release scope: every failure after INVOKING acquisition, including
trace/fixture initialization, must release that exact marker and preserve
bounded actual failure/partial-acquisition evidence. That correction is still
in progress; no failure injection or corrected source is executed here.
After initialization, unregister owned control/observer registrations; clear
trace/reentrancy context; normal wake only actual owned sleepers; explicitly
restore loaded Spawn with the normal public setter; native remove/logout save
only owned actors; drain/release/close only owned channels/outbound packets;
restore each captured cell/time/gamerule and verify. Log every attempt/result
even if another failed. No global bus clearing, reflection, pose reset policy,
unowned UUID removal, or second-persistence truth store. Do not label a Spawn
restoration as passive observation; it is teardown preparation before native save.

Invocation 2 may narrowly show that the same command can reacquire the same
owned UUIDs and execute after first teardown, and that case 20 is not swallowed
by case 19's one-shot intervention. It cannot prove exhaustive listener/heap
release, absence of invisible global interference, production cold/warm/JIT
behavior, concurrency, network scheduling, transport, restart, death, old-world
migration or an enforceable classifier. Retained source finally review and
reported cleanup remain necessary; successful repetition is not a replacement.

After Root/independent readers release interests and offline reparse finishes,
delete only the future driver's absent-then-created `_tmp` runtime/world/library
copies and parser-test scratch explicitly listed in its ownership manifest.
Do not delete source worktrees/build/cache/input worlds or sealed evidence under
this design. Use one native PowerShell cleanup attempt: check exact absolute
resolved targets lie within that task's explicit temporary root, reject all
reparse points/linked ancestors, count bytes/files, confirm own PID exited and no
active reader/process references, then Remove-Item -LiteralPath. Record checks,
deletion outcome and remaining paths. Failure/policy denial retains targets and
is not retried through another shell. Keep raw logs/results/compact native data;
seal only after Root review. Task 09 itself creates no cleanup target.

## 6. Assertions that can be frozen now versus later

**Source/recipe-independent:** exact Task 05 case/actor/world inventory; no
ordinary clients; command ownership; finite attempts; copied-input containment;
exact input receipts and raw retention; row identity and caps; no hidden bypass;
failure/intervention/cleanup separation;
typed-not-coerced NBT; explicit exclusion and no Gate/product authority.

**Recipe-derived and already inspectable, but not native sleep evidence:**
copied-libraries launch pattern, 300/60/60/90 s native ceilings, optional 60 s
loopback status and 30/15/15/5 s JDK/forced-exit/reader limits; console/save/stop
marker provenance; fresh configuration pattern and checked PowerShell cleanup.
The additional non-native bounds above are proposed driver limits requiring
review, not historical measured outcomes or a relaxation of native ceilings.

**Await final source/schema/artifact:** complete output byte accounting and
pre-allocation bounds; final field/enum/exception/measurement scope; exact
lifecycle/teardown stage names and setup-marker release correction; control-fired
evidence mapping; final source compliance with the fixed 12-cell inventory;
pre-freeze primary/recipe-supported stdout wrapper; reobfuscated class/descriptor spelling; which native
actions actually reach events; actual native before/after outcomes; serialized
Spawn presence/default mapping; actual normal saved disk data; all commands,
tests and launch results. Baseline receipt numbers prove none of these.

## 7. Explicitly open/non-authorized

B1 cause/indeterminate/coexistence strategy; R1 callback-argument and inherited
receiver authentication; M1 registered-bed/occupancy-air neutral transition; M2
supplied-gap versus station-only branch freeze and installed host/live access;
D1 unanswered natural=true compass/clock/portal ancillary choice. No owner
answer or production policy is supplied by this design.

Also unexecuted: full Q01-Q18 and S01-S21/R01-R02, inherited/custom beds/cached
receiver changes, monster/item-first/secondary and hostile late-writer mod
interaction, interpreted/JIT/development qualification, connected TCP gameplay/
decoder/scheduling/real client login/input/ack, real GPU/multiplayer, six actual
off-world hosts/Space air/access, prior worlds/restart/death, crash recovery,
reference workload/soak, provenance/item delivery and all Required G0-G9.

A later explicit source/artifact freeze, driver/parser implementation and
independent review plus finite runtime assignment are required. This document
creates none of those approvals and grants no new launch or cleanup permission.
