# Passive sleep observation driver design 09

Date: 2026-10-09. Delegated read-only test-design worker. Status: **PROPOSED,
UNEXECUTED, SEALED RECORD**. The record seal is not a driver/parser/source freeze.
Root owns OpenPet and all integration/runtime decisions.

## Findings and unknowns first

1. **Source and parser freeze are prerequisites, not completed work.** The two
   classes were read only from Git at
   `0c05cc27112f5f4a71faa66bc16b5f7f4390f345`. Task 08 confirms that its accepted-byte
   caps check after allocating serialization/frame/chat data, and that its
   measurement fields describe only a prefix of capture. The bounded-output
   correction and independent source review are in progress. This design does
   not endorse that candidate, prescribe the final corrected field names, or
   inspect the source worker's moving checkout. Addendum 10 separately records
   an actual setup-ownership finding in e72b41/0c05: INVOKING is acquired before
   trace/fixture construction, but their responsible try/finally starts only
   afterward. A failure in that interval can retain the reentrancy marker.
   Its source correction is still in progress; no such failure was executed
   and no corrected revision is adopted by this report.
2. **A returned command is not twenty completed observations or successful
   sleeping.** The provisional fixture intentionally fails the observer in case
   19, retains the row's actual failure, then attempts case 20 after teardown.
   Its root failure summary and Brigadier return can therefore indicate a
   failure even when all prescribed interventions executed. A parser must keep
   fixture completeness, actual native effects, deliberate interventions,
   unexpected failures, trace completeness and cleanup separate. It must not
   require an all-success root verdict or convert the intentional failure into
   a successful-sleep result.
3. **Current snapshots are getters, not per-case serialized Spawn evidence.**
   The provisional `spawnGetterProjection` explicitly says this. Teardown
   restores loaded Spawn fields before native PlayerList removal/logout saving.
   A later external parser can inspect those native disk files after each
   invocation, but they will describe the teardown/save phase, not every bed or
   nested-setter action. There is no authorized per-case save hook. Exact
   native NBT presence/default semantics must be pinned before comparison; no
   guessed tags or manually generated player NBT may fill that gap.
4. **The established launch environment is a reusable recipe, not sleep
   evidence.** Its frozen driver uses two native processes for jackhammer
   continuation. The proposed sleep driver instead uses one fresh process and
   two sequential invocations to probe synchronous release and reacquisition.
   No old world, playerdata, host/fixture result, successful parser verdict or
   artifact hash is promoted to a sleep result. Actual sleep artifacts, JDK,
   libraries, configuration and logs must be newly bound.
5. **Observed identities do not close provenance gaps.** Task 05 excludes
   inherited/custom and stale cached receivers. Its callback controls and
   identity tokens label owned objects; StackWalker declaring classes and
   descriptors do not authenticate callback arguments or a BedBlock receiver.
   Neither two runs nor off/on agreement proves B1/R1, coexistence, an
   INDETERMINATE policy, listener exclusivity, comprehensive absence of retained
   objects, or real transport.

## Fixed input references

- Governance Main: `8b3a6329a34b728029ecb71db111c74ee7bf5c9a`, read with `git show`,
  not moving HEAD. Required PROJECT-CONFIG, PRODUCT, porting principles,
  roadmap, master test plan, release gates, parallel coordination, post-1.0
  roadmap, quality budgets, v1.8 version file and ADR-060 were read. The actual
  version filename is `docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`; an
  initial `docs/versions/v1.8.0.md` read failed and was corrected. Earliest
  incomplete acceptance remains v1.0; its version file and fixed status/Gate
  files were also read. ADR-060 permits v1.8 development, not Gate approval.
- Complete `docs/work/v1.8.0-c18a-sleep/PROPOSED-OBSERVATION-01.md` at that Main,
  Git blob `c37b2c3de014ee89415cda226fe780c917736ff1`; assignment 05 blob
  `927bf3d3c512f7b794c364bbe67cf12e77088311`.
- External `SLEEP-OBSERVATION-DRIVER-DESIGN-TASK-09.md`, SHA-256
  `ff83fa693a4469dd7540cd074d1284b876d6f07d29f06c52065f3a225928435f`, verified.
  External source Task 05 SHA-256
  `a793aa4c994537401b0b728af3254e4e6815474fe5d149a6095e53b65550eb65`;
  correction Task 08 SHA-256
  `7ae9af7b58679cd66101066bcb7b13848011bb9e8e453c9354b6e6afde8f66de`.
- Final follow-up input `SLEEP-OBSERVATION-SOURCE-CORRECTION-ADDENDUM-10.md`,
  SHA-256 `bb9f1e7ed50275e1f408ccf969814a144b1b1b0cdf3e09e39905d6b3016f6f74`,
  read and hashed before seal. Its actual-source setup-ownership correction
  remains attributed to the source worker and additive review, not this design.
- Provisional source: both new classes at `0c05cc27112f5f4a71faa66bc16b5f7f4390f345`,
  complete text inspected through fixed Git object reads only. Fixture Git blob:
  `3fd23820b5307ea34b2fc0e01bf01e3e2aeebaf3`; trace Git blob:
  `ca0a466e3ef03ab0cf7dc9dfcd314e2b707a9d5b`.
- Supporting fixed sleep inputs: PROPOSED-CONTRACT-01, SPAWN-RESEARCH-STATUS-02,
  AIR-RESEARCH-STATUS-02, OWNER-QUESTION-02 and OBSERVATION-REVIEW-STATUS-04.
- Established recipe leaf:
  `D:/GitHub/ARCE-Task-Evidence/v1.8.0/jackhammer-root-20261009-01`.
  Actual child paths were listed before opening. Text-only inspection covered
  REPORT, packaged-launch-02 COMMAND/RESULT/classpath/fixture-artifact receipts,
  packaged-02 inputs/RESULT and seed/continue launch/commands/receipt records,
  launch_packaged.py, driver-frozen-02 packaged_driver.py and its tests/manifest,
  DRIVER-PACKAGE-02, cleanup_owned.ps1 and CLEANUP-RESULT. The driver SHA-256 is
  `63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e`;
  launcher SHA-256 is
  `b9bfc5483705c2e90bbbd309d09cfb6f6dabcae4ef9c8c26307b2ea7098e23a4`.
  They were not executed or copied into this leaf.
- Existing helper's relevant public launch/log/process portions were read as
  text with `git show 3b18a6bc8b58424d647053d6c6f1833ba14d9dc7:scripts/run_dedicated_server_smoke.py`.
  No helper was imported, compiled or executed.

## Deliverable and decisive acceptance checks

[PROPOSED-DRIVER.md](PROPOSED-DRIVER.md) supplies an actionable finite launch,
twenty-row inventory, provisional schema boundary, parser and cleanup design.
Its principal checks are: verified committed inputs and artifacts; one fresh
owned Overworld process; at most two console commands of exactly twenty rows;
unchanged established 300/60/60/90-second startup/action/save/stop ceilings;
complete raw logs and exact native saves; fail-closed parser bounds and row
identity; explicitly retained intervention/unexpected-failure distinctions; and
independent attempts to restore/remove/release every owned fixture resource.

Source/recipe-independent assertions can already be specified: containment,
actor/cell inventory, size/event/frame limits, exact row names, finite attempts,
failure attribution and exclusion reporting. The baseline-derived native launch
and deadline recipe is separately identified, not a new source observation.
Final schema keys, failure-chain mapping, measurement scope, bounds accounting,
native save/default projection and actual packaged class presence remain subject
to final source/artifact review. No runnable driver or parser is provided here.

## Actual read commands and no-execution state

Exploration commands were read-only PowerShell/Git. `apply_patch` created and
corrected the two design files, then generated the two-document checksum
manifest inside the exclusive leaf. Actual command families:

- `Get-Content -LiteralPath <Task 09/Task 05/Task 08/Addendum 10 or discovered baseline text> -Raw`.
- `Get-FileHash -LiteralPath <tasks, named baseline text or final own documents/manifest> -Algorithm SHA256`.
- `git status --short`, `git branch --show-current`, `git worktree list`.
- `git ls-tree -r --name-only <fixed Main> -- <named governance/docs scopes>`;
  discovery filters used PowerShell `Select-String`.
- `git show <fixed Main>:<named required/supporting document>`;
  `git show <fixed source>:<each of the two new classes>`;
  `git diff-tree --no-commit-id --name-only -r <fixed source>`.
- `git show <fixed historical source>:scripts/run_dedicated_server_smoke.py`,
  with `Select-String -Context` for relevant recipe/process portions.
- `git rev-parse <fixed Main>:<named input document>` for blob identities.
- `Get-ChildItem -LiteralPath <external root/discovered baseline child>`, and
  `Get-Content ... | ConvertFrom-Json | Select-Object ... | ConvertTo-Json`
  for compact historical identity inspection.
- `Test-Path -LiteralPath <exclusive output leaf>` returned false before edits;
  final reads/listing verify only the two proposed files were created.
- Final own-leaf PowerShell inspection enumerated the two expected files and
  checked for trailing whitespace: zero offending lines in both documents and
  neither a reparse point. This is document hygiene, not parser/native/test
  execution.
- Final seal checks read the manifest and rehashed its two exact relative
  document names, rejected unexpected coverage/duplicates/path escapes/reparse
  points, and measured all three retained files. REPORT and manifest hashes,
  exact coverage and byte totals are returned separately to Root; the manifest
  does not list itself or any external/mutable build input.

The initial status/tree listings and a combined baseline receipt listing
exceeded the display budget. Required proposal/source and relevant recipe
sections were subsequently read in smaller complete/focused displays. No
exploratory display is presented as an independently timestamped test receipt.
The missing version filename was a failed read, not a passed check. Other read
commands completed; a multi-command cell can have final exit 0 despite that
earlier `git show` failure.

No Python, Java, Gradle, compiler, tests, networking, installation, driver,
Minecraft server/client, world access/mutation, reflection, other process,
cleanup, delegation or Claude was run. No raw input helper was executed.
Repository/peer/sealed-evidence files, index and HEAD were not modified. Existing
user-owned AGENTS changes/untracked files were observed and left untouched.
Main/source/HEAD interests were released to Root at task start; they remain
released. No runtime or temporary tree exists for this task to clean.

## Completion, remaining work and Gate state

Completed scope: read-only design for a later finite packaged-driver/parser;
two design documents and their SHA256SUMS.txt seal; no tests added or run.
No source, save schema, API, protocol, resources, provenance or policy changed.
Root reported complete reading of both documents in its delegated follow-up
message on 2026-10-09 and adopted them only as unfrozen design input, not runtime
permission or a parser verdict. That message authorized final correction and
sealing of these two documents only. Sealed files are not modified afterward.

## Explicit final pre-seal corrections

- The earlier inventory wording allowed two halves plus <=16 support/clearance
  cells. Root's follow-up freezes the **existing 12 total cells** listed in the
  design; that wider wording is superseded, not an 18-cell allowance.
- The stdout-wrapper contract now requires fixed primary/recipe provenance
  before a future executable freeze. It cannot depend on a preliminary,
  unassigned runtime launch to discover an acceptable prefix.
- Addendum 10's setup-ownership finding is recorded as an in-progress source
  correction. The future reviewed cleanup contract covers trace/fixture
  initialization failure after marker acquisition; the old 0c05 schema/source
  is still provisional and cannot be used as final authority.

Uncompleted: Task 08/Addendum 10 corrected/final source review; exact artifacts and helpers;
executable/parser implementation, freeze and independent review; explicitly
assigned runtime checks; all native observations; full qualification. B1/R1,
M1 neutral transition, M2 branch freeze and installed live access/air, D1 owner
ancillary choice, six actual hosts/Space, TCP gameplay/client, prior worlds,
restart/death, JIT/interpreted/dev qualification, hostile late writers and
inherited receiver coverage remain open. No full Q01-Q18 or S01-S21/R01-R02
completion is claimed.

All required v1.8 G0-G9 and inherited acceptance remain open; this design
provides no PASS, enforcement, owner choice, source/runtime permission, candidate
selection, delivery/ledger/status change or Gate approval. Next action is only
to finish the current passive fixture's bounded-source review, then have Root
issue a separate finite driver implementation/review assignment if supported.
