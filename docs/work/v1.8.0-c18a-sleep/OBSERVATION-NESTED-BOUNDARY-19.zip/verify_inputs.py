"""Read-only verification of immutable Task 19 source and sealed input leaves."""
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
BASE = LEAF.parent
INPUTS = ["sleep-observation-wire-qualification-20261009-17", "sleep-observation-source-independent-20261009-06",
          "sleep-observation-root-qualification-20261009-11", "sleep-observation-qualification-independent-20261009-12"]
results = []
for name in INPUTS:
    root = BASE / name
    manifest = root / "SHA256SUMS.txt"
    lines = manifest.read_text(encoding="utf-8-sig").splitlines()
    count = 0
    for line in lines:
        if not line.strip():
            continue
        digest, relative = line.split("  ", 1)
        target = (root / relative).resolve()
        if not target.is_relative_to(root.resolve()) or target == manifest:
            raise RuntimeError("Unsafe or cyclic input manifest member " + relative)
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != digest:
            raise RuntimeError("Input hash mismatch: " + str(target))
        count += 1
    results.append({"leaf": str(root), "covered_files": count,
                    "report_sha256": hashlib.sha256((root / "REPORT.md").read_bytes()).hexdigest(),
                    "manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest()})
result = {"sealed_inputs": results, "task_sha256": hashlib.sha256((BASE / "SLEEP-OBSERVATION-NESTED-BOUNDARY-TASK-19.md").read_bytes()).hexdigest()}
(LEAF / "INPUT-VERIFICATION.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
