"""Compact source/tool/compiled-class hashes; no binary or source-tree export."""
import hashlib
import json
from pathlib import Path
from capture import CWD, JDK, LEAF, run

FILES = [
    CWD / "src/adapterTest/java/io/github/sunthemoon/arceadaptertest" / name
    for name in ("SleepBoundaryTrace.java", "SleepBoundaryChatBounds.java", "SleepBoundaryObservationFixture.java")
]
FILES += [CWD / name for name in ("build.gradle", "gradle.properties", "gradlew.bat", "gradle/wrapper/gradle-wrapper.properties", "gradle/wrapper/gradle-wrapper.jar")]
FILES += [JDK / "bin" / name for name in ("java.exe", "javac.exe", "javap.exe")]
FILES += [Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")]
FILES += sorted((CWD / "build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest").glob("SleepBoundary*.class"))
inventory = []
for path in FILES:
    data = path.read_bytes()
    item = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if path.suffix == ".java":
        item["lines"] = len(data.splitlines())
    inventory.append(item)
(LEAF / "SOURCE-AND-TOOL-IDENTITIES.json").write_text(json.dumps(inventory, indent=2) + "\n", encoding="utf-8")
print(json.dumps(inventory, indent=2))
GOVERNANCE = ["PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md", "docs/04-VERSION-ROADMAP.md",
              "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md", "docs/05-MASTER-TEST-PLAN.md",
              "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md", "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
              "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md"]
for index, path in enumerate(GOVERNANCE):
    run("governance-%02d" % index, ["git", "show", "30944465a6e07215990182fb0dd935e65303e27a:" + path])
