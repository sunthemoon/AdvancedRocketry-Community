"""Separately authorized Addendum 23 compile cohort; no tests/runtime."""
import hashlib
import json
import os
from capture import CWD, LEAF, run, utc

addendum = LEAF.parent / "SLEEP-OBSERVATION-NESTED-BOUNDARY-ADDENDUM-23.md"
digest = hashlib.sha256(addendum.read_bytes()).hexdigest()
if digest != "c54cdea7bc53eb0dccdca1a3dc6e99c9cde81cc27a3ddef612e56194cdefa4c7":
    raise RuntimeError("Addendum identity mismatch")
print(addendum.read_text(encoding="utf-8"))
print("Addendum SHA256 " + digest)
files = [CWD / "src/adapterTest/java/io/github/sunthemoon/arceadaptertest" / name
         for name in ("SleepBoundaryTrace.java", "SleepBoundaryChatBounds.java", "SleepBoundaryObservationFixture.java")]
before = [{"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}
          for path in files]
receipt = {"recorded_utc": utc(), "addendum_sha256": digest, "sources": before}
(LEAF / "COMPILE-03-SOURCE-INPUTS.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
run("compile-03", [os.environ["COMSPEC"], "/d", "/c", "gradlew.bat", "compileJava", "compileTestJava",
                   "compileAdapterTestJava", "--no-daemon", "--no-build-cache", "--rerun-tasks"], compile_command=True)
for path, item in zip(files, before):
    if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        raise RuntimeError("Source changed during compile: " + str(path))
print("Source unchanged through compile-03")
