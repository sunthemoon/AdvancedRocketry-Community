$ErrorActionPreference = 'Stop'
$source = (Resolve-Path -LiteralPath 'D:\GitHub\arce-v180-sleep-chat-boundary-20261009').ProviderPath
$leaf = (Resolve-Path -LiteralPath 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-observation-nested-boundary-20261009-19').ProviderPath
$targets = @(
    @{ Path = 'D:\GitHub\arce-v180-sleep-chat-boundary-20261009\build'; Root = $source },
    @{ Path = 'D:\GitHub\arce-v180-sleep-chat-boundary-20261009\.gradle'; Root = $source },
    @{ Path = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-observation-nested-boundary-20261009-19\_tmp'; Root = $leaf }
)
$live = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'java.exe' -and ($_.CommandLine -like '*arce-v180-sleep-chat-boundary-20261009*' -or
        $_.CommandLine -like '*sleep-observation-nested-boundary-20261009-19*')
})
if ($live.Count -ne 0) { throw 'Live owned Java process overlaps disposable output.' }
$checked = @()
foreach ($entry in $targets) {
    $target = [System.IO.Path]::GetFullPath($entry.Path)
    $prefix = $entry.Root.TrimEnd('\') + '\'
    if (-not $target.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Target is outside its owned root.' }
    $exists = Test-Path -LiteralPath $target
    $count = 0
    $bytes = 0
    if ($exists) {
        $cursor = Get-Item -LiteralPath $target -Force
        while ($null -ne $cursor) {
            if (($cursor.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Ancestor reparse point.' }
            $cursor = $cursor.Parent
        }
        $children = @(Get-ChildItem -LiteralPath $target -Force -Recurse)
        if (@($children | Where-Object { ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -ne 0) {
            throw 'Descendant reparse point.'
        }
        $files = @($children | Where-Object { -not $_.PSIsContainer })
        $count = $files.Count
        $bytes = ($files | Measure-Object -Property Length -Sum).Sum
        if ($null -eq $bytes) { $bytes = 0 }
    }
    $checked += [pscustomobject]@{ target = $target; contained = $true; existed = $exists; files = $count; bytes = $bytes }
}
foreach ($entry in $checked) {
    if ($entry.existed) { Remove-Item -LiteralPath $entry.target -Recurse -Force -ErrorAction Stop }
    if (Test-Path -LiteralPath $entry.target) { throw 'Owned target remains after one cleanup attempt.' }
}
[pscustomobject]@{ startCheckUtc = [DateTime]::UtcNow.ToString('o'); liveOwnedJavaCount = $live.Count;
    checkedTargets = $checked; result = 'REMOVED'; sourceRetained = (Test-Path -LiteralPath $source) } | ConvertTo-Json -Depth 5
