"""One-time leaf-relative sealing, only after Root has read the complete report."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
from capture import LEAF, utc

started = utc()
if LEAF.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
    raise RuntimeError("Evidence leaf is a reparse point")
expected = sys.argv[1]
if not re.fullmatch(r"[0-9a-f]{64}", expected):
    raise RuntimeError("An exact Root-read report SHA256 is required")
report = LEAF / "REPORT.md"
if hashlib.sha256(report.read_bytes()).hexdigest() != expected:
    raise RuntimeError("Report differs from the Root-read bytes")
if not (LEAF / "ROOT-READ-ACKNOWLEDGEMENT.md").is_file():
    raise RuntimeError("Missing actual Root read/seal acknowledgement")
manifest = LEAF / "SHA256SUMS.txt"
if manifest.exists() or (LEAF / "_tmp").exists():
    raise RuntimeError("Already sealed or owned disposable outputs remain")
covered = []
for path in sorted(LEAF.rglob("*")):
    if path.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError("Reparse point in evidence leaf")
    if not path.is_file():
        continue
    relative = path.relative_to(LEAF).as_posix()
    if relative in ("SHA256SUMS.txt", "SEAL-RESULT.json") or relative.startswith("seal-01."):
        continue
    if not path.resolve().is_relative_to(LEAF.resolve()) or "\n" in relative or "\r" in relative:
        raise RuntimeError("Unsafe evidence member")
    if path.stat().st_size > 50 * 1024 ** 2:
        raise RuntimeError("Evidence file exceeds 50 MiB")
    covered.append((path, relative, hashlib.sha256(path.read_bytes()).hexdigest()))
if sum(path.stat().st_size for path, _, _ in covered) > 100 * 1024 ** 2:
    raise RuntimeError("Evidence leaf exceeds 100 MiB")
with manifest.open("x", encoding="utf-8", newline="\n") as out:
    out.writelines(digest + "  " + relative + "\n" for _, relative, digest in covered)
for path, _, digest in covered:
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise RuntimeError("Post-seal covered-file verification failed")
result = {"argv": sys.argv, "cwd": os.getcwd(), "pre_start_utc": started, "end_utc": utc(), "exit_code": 0,
          "report_sha256": expected, "manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
          "covered_files": len(covered), "covered_bytes": sum(path.stat().st_size for path, _, _ in covered),
          "excluded_post_seal_receipts": ["SEAL-RESULT.json", "seal-01.*"], "verification": "ALL_HASHES_MATCH"}
(LEAF / "SEAL-RESULT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
