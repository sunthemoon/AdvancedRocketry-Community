"""Addendum 23 final source/compiled-class identities; no prior cohort overwrite."""
import hashlib
import json
from capture import CWD, LEAF

files = [CWD / "src/adapterTest/java/io/github/sunthemoon/arceadaptertest" / name
         for name in ("SleepBoundaryTrace.java", "SleepBoundaryChatBounds.java", "SleepBoundaryObservationFixture.java")]
files += sorted((CWD / "build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest").glob("SleepBoundary*.class"))
items = []
for path in files:
    data = path.read_bytes()
    item = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if path.suffix == ".java":
        item["lines"] = len(data.splitlines())
    items.append(item)
result = json.dumps(items, indent=2) + "\n"
(LEAF / "SOURCE-AND-CLASS-IDENTITIES-03.json").write_text(result, encoding="utf-8")
print(result)
