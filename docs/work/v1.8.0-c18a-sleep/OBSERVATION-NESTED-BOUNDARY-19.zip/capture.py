"""Task 19 scoped command receipts; not a runtime or test driver."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

LEAF = Path(__file__).resolve().parent
CWD = Path("D:/GitHub/arce-v180-sleep-chat-boundary-20261009")
JDK = Path("C:/Program Files/Java/jdk-17.0.7")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, argv, cwd=CWD, compile_command=False):
    stdout = LEAF / (name + ".stdout.txt")
    stderr = LEAF / (name + ".stderr.txt")
    receipt = LEAF / (name + ".command.json")
    if any(p.exists() for p in (stdout, stderr, receipt)):
        raise RuntimeError("Refusing to overwrite command evidence: " + name)
    env = os.environ.copy()
    record = {"argv": argv, "cwd": str(cwd), "pre_start_utc": utc()}
    if compile_command:
        record["disk_free_bytes"] = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
        if min(record["disk_free_bytes"].values()) < 10 * 1024 ** 3:
            raise RuntimeError("Less than 10 GiB free")
        tmp = LEAF / "_tmp" / name
        tmp.mkdir(parents=True, exist_ok=False)
        env.update(JAVA_HOME=str(JDK), PATH=str(JDK / "bin") + os.pathsep + env["PATH"], TEMP=str(tmp), TMP=str(tmp))
        for key in ("_JAVA_OPTIONS", "JDK_JAVA_OPTIONS"):
            if env.get(key):
                raise RuntimeError("Unexpected JVM override: " + key)
        record["parent_JAVA_TOOL_OPTIONS"] = env.get("JAVA_TOOL_OPTIONS")
        env["JAVA_TOOL_OPTIONS"] = "-Djava.io.tmpdir=" + str(tmp)
        record["child_environment"] = {key: env.get(key) for key in ("JAVA_HOME", "JAVA_TOOL_OPTIONS", "TEMP", "TMP")}
        record["timeout_seconds"] = 1800
    start = utc()
    with stdout.open("wb") as out, stderr.open("wb") as err:
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=out, stderr=err)
        record.update(start_utc=start, pid=process.pid)
        try:
            record["exit_code"] = process.wait(timeout=1800 if compile_command else 180)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            record.update(exit_code=process.returncode, result="TIMEOUT", stopped_owned_child=True)
    record.update(end_utc=utc(), stdout_bytes=stdout.stat().st_size, stderr_bytes=stderr.stat().st_size,
                  stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record))
    return record


if __name__ == "__main__":
    if sys.argv[1] == "compile":
        run("compile-01", [os.environ["COMSPEC"], "/d", "/c", "gradlew.bat", "compileJava", "compileTestJava",
                           "compileAdapterTestJava", "--no-daemon", "--no-build-cache", "--rerun-tasks"],
            compile_command=True)
    else:
        run(sys.argv[1], sys.argv[2:])
