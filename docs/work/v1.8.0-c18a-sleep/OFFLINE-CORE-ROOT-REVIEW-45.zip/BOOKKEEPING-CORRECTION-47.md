# Root45 prospective bookkeeping correction 47

Actual package-01 exits 1 before archive creation because it assumes Task40's
seal result uses Root's flat exit_code schema. Task40 actually has exit and a
nested verification object plus embedded raw streams. Original command/helper/
stderr/receipt remain unchanged. A bounded direct tool read confirms both
destination ZIPs are still absent; its transport is not a reconstructed child
receipt. This is a bookkeeping schema failure, not a policy-denied command.

Task45's no-failed-command-retry boundary prohibits repeating that unchanged
helper. Root permits one separately named package_corrected_02.py execution,
package-corrected-02, using the actual two explicitly identified seal schemas and
actual Task40 embedded-stream hashes. All scope/caps and original receipts stay
unchanged. No generic unknown-schema acceptance, cleanup, policy bypass, archive
overwrite, native/runtime retry, source change or diagnostic/Gate authority.
