# Task44: independent prospective Windows peak-process counter qualification

You are a fresh delegated independent worker/subagent, not Root or author37/43.
Do not use Root persona and do not delegate. Root is sole Main integrator.
Fixed governance b0b818261621d6c607386925535a62f027dfbf8b; observation source
d57ecda1f11dab76d882f945b0de606534ef4fb9. No HEAD/index/source manipulation.

Exclusive absent new external write_scope:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-platform-counter-20261009-44.
Before creating leaf/helpers, check status/worktrees, applicable AGENTS and live
agents. Preserve every user/peer/sealed/world/cache/source file. No cleanup.

Read all mandatory fixed governance documents, actual
docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md, fixed sleep checkpoint42,
and the complete actual author37 proposal and independent40 report:
- sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md:
  SHA256 f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0,
  19096 bytes /271 lines.
- sleep-offline-json-core-independent-20261009-40/REPORT.md:
  SHA256 aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60,
  18632 bytes /280 lines.
Leaves are under D:/GitHub/ARCE-Task-Evidence/v1.8.0. Proposal37 and diagnostic
addendum43 remain PROPOSED. No decoder or synthetic payload test is assigned.

Outcome: independently assess and qualify, if evidence permits, a standard-
library Windows binding for this Python interpreter's own process-lifetime peak
working-set counter, for later separately assigned structural resource tests.
Verify primary official API meaning/units, declaration layout/width/return/error
handling, process-handle ownership, actual availability and limits. Distinguish
peak working set, current working set, traced Python allocations, commit/pagefile
usage and hard allocator/quota enforcement. Unsupported/ambiguous measurements
must remain UNQUALIFIED. Provide evidence, not an anticipated value or verdict.

Allowed official network reads: Microsoft Learn Windows API docs and official
Python 3.13 docs only; cite precise supporting pages. Root inspected
https://learn.microsoft.com/windows/win32/api/psapi/ns-psapi-process_memory_counters
and https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getprocessmemoryinfo
as prospective references, not a counter selection or actual measurement.
Inspect actual installed Python identity/platform and run at most three fresh
own Python -B counter-probe children using standard-library ctypes/tracemalloc.
Query only the child's own process, never other PIDs. If needed, a clearly labeled
counter probe may allocate/touch/release at most 16 MiB of bytearray; it is not a
decoder payload or simulated native trace. Report actual values and measurement
intervals without imposing a predicted memory delta. Retain at most one such
buffer at a time, no repeated tree/cache/stress loop or unbounded sample list.
Do not change process working-set limits, job quotas, affinities, privileges,
environment, services or any system configuration. No install/download/Gradle/
JVM/Minecraft/Claude/process termination/cleanup/delegation. No project edits.

Own helpers/REPORT and bounded raw receipts are allowed only in the new leaf.
Every child has a fixed enforced 180-second ceiling, split streams <=256 KiB;
leaf <=4 MiB. Capture true argv/cwd/UTC/exit/raw lengths/hashes and preserve all
failures. Use nontruncated required reads; no fake historical receipt. The
unchanged prospective traced and lifetime-peak ceilings are 256 MiB each; actual
counter work cannot increase them or qualify the unimplemented decoder.

Deliver findings-first REPORT.md with actual sources/declarations/invocations,
identity/measurement/capture boundaries, completed/uncompleted scope, own changed
files, actual commands/results, tests/probes distinguished, evidence path, risks,
Required Gate status and next v1.8-only work. Explain a bounded prospective test-
file binding without assigning or copying production/test code. Send stable
lines/bytes/SHA256 and await Root's complete exact-hash read before one-time seal.
No generic decoder, full-driver runtime, OS hard resource enforcement, native
behavior, R-021/diagnostic waiver or Gate permission follows from this task.
