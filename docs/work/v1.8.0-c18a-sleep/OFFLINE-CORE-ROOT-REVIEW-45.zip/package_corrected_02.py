"""Inspect actual declared seal schemas, then rehost unchanged leaves."""
import base64
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
specs = json.loads((out / 'INPUT-SEALS-01.json').read_text(encoding='utf-8'))
facts = []
for spec in specs:
    result_raw = (out.parent / spec['leaf'] / 'SEAL-RESULT.json').read_bytes()
    result = json.loads(result_raw)
    if spec['leaf'] == 'sleep-offline-json-core-independent-20261009-40':
        assert hashlib.sha256(result_raw).hexdigest() == 'df4fefb4d7ee3dde29ea75af63dc83439dd489a35854ab7fef27f4db9040a209'
        assert result['kind'] == 'actual-one-time-custody-seal-not-adoption-or-qualification'
        assert result['exit'] == 0 and result['timeout_seconds'] == 180
        assert result['excluded_from_manifest'] is True
        for channel in ('stdout', 'stderr'):
            stream = base64.b64decode(result[channel + '_base64'], validate=True)
            assert len(stream) == result[channel + '_bytes'] <= 262144
            assert hashlib.sha256(stream).hexdigest() == result[channel + '_sha256']
        assert result['stderr_bytes'] == 0
        verification = result['verification']
        assert json.loads(base64.b64decode(result['stdout_base64'], validate=True)) == verification
        assert verification['all_covered_match'] is True
    elif spec['leaf'] == 'sleep-offline-core-and-diagnostics-publication-20261009-42':
        assert result['exit_code'] == 0 and result['gate_approval'] is False
        verification = result
    else:
        raise AssertionError('UNDECLARED_SEAL_SCHEMA')
    assert verification['manifest_sha256'] == spec['manifest_sha256']
    assert verification['report_sha256'] == spec['report_sha256']
    assert set(verification['excluded']) == {'SHA256SUMS.txt', 'SEAL-RESULT.json'}
    facts.append(verification)
original = out.parent / 'sleep-native-log-disposition-20261009-39/package_01.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '7e177d58e499f9b938cf0814d357a492c409a2bef6b7b68cc148a880e4515e35'
scope = {'__file__': str(Path(__file__)), '__name__': '__main__'}
exec(compile(raw, str(Path(__file__)), 'exec'), scope)
for row, fact in zip(scope['rows'], facts):
    assert row['covered_files'] == fact['covered_files'] and row['covered_bytes'] == fact['covered_bytes']
