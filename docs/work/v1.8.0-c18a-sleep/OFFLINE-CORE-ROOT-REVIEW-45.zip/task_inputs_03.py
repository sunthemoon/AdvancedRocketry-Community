"""Retain bounded exact Root-owned prospective assignments without editing originals."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
names = {
    'SLEEP-OFFLINE-DIAGNOSTIC-CONVENTION-TASK-43.md': '902451dfb311325248045b3bee4861b9d97ecac23632ce5ee3532a52a902ee6c',
    'SLEEP-JSON-PLATFORM-COUNTER-TASK-44.md': 'adaae9e1865680d35fe02302b4932f44092f7c39b8eaef9efc560e177b6012e8',
    'SLEEP-JSON-COUNTER-TIMEOUT-CLARIFICATION-46.md': '7e8aaa1a251b71654d479c1d97cfa00580c114d2860d87678358e36aca6da23c',
}
rows = []
for name, expected in names.items():
    source = out.parent / name
    assert source.stat().st_size < 16384 and not source.is_symlink()
    assert not (getattr(source.lstat(), 'st_file_attributes', 0) & 0x400)
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected
    with (out / name).open('xb') as target:
        target.write(raw)
    rows.append({'name': name, 'bytes': len(raw), 'sha256': expected})
with (out / 'TASK-INPUTS-03.json').open('x', encoding='utf-8') as target:
    target.write(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows), flush=True)
