"""Reuse verified archive algorithm for two actual sealed inputs only."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
specs = json.loads((out / 'INPUT-SEALS-01.json').read_text(encoding='utf-8'))
for spec in specs:
    result = json.loads((out.parent / spec['leaf'] / 'SEAL-RESULT.json').read_text(encoding='utf-8'))
    assert result['exit_code'] == 0 and not result['gate_approval']
    assert result['manifest_sha256'] == spec['manifest_sha256']
    assert result['report_sha256'] == spec['report_sha256']
    assert result['excluded'] == ['SHA256SUMS.txt', 'SEAL-RESULT.json']
original = out.parent / 'sleep-native-log-disposition-20261009-39/package_01.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '7e177d58e499f9b938cf0814d357a492c409a2bef6b7b68cc148a880e4515e35'
scope = {'__file__': str(Path(__file__)), '__name__': '__main__'}
exec(compile(raw, str(Path(__file__)), 'exec'), scope)
for row, spec in zip(scope['rows'], specs):
    result = json.loads((out.parent / spec['leaf'] / 'SEAL-RESULT.json').read_text(encoding='utf-8'))
    assert row['covered_files'] == result['covered_files'] and row['covered_bytes'] == result['covered_bytes']
