# Root45 offline-core independent-review publication report

## Completed scope and exact commit

Root completely reads the stable final independent40 REPORT, 280 lines /18632
bytes, SHA256 aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60,
before exact-hash custody acknowledgment and actual worker seal. Actual seals40
and Root42 are verified/rehosted without predecessor alteration. Seven record/
archive files are committed and normally pushed as
b80fb950b3965956ff6a75f8f86b9aff32aa196d, parent
b0b818261621d6c607386925535a62f027dfbf8b, branch codex/v1.8.0-classic-content.
Workers43/44 confirm no mutable-HEAD dependency before movement; their fixed
b0b/d57 inputs remain unchanged and they are notified of the actual new commit.

## Uncompleted scope and design disposition

Independent40 reports Low R01: non-bytes preflight and partial-token reservation/
maxima/consumption diagnostics need a fixed convention. No Critical/High/Medium
contract contradiction is identified in the narrowed static candidate. Root
does not infer executable safety or adopt candidate37. Its bytes/object-only/
iterative/inert-number/bounded error/resource profile remains PROPOSED. No decoder
or structural payload/test assignment. Source-schema/Gson/conversion/provenance,
framing/capture/NBT/log/native behavior remain downstream and unqualified.

Task43 separately proposes only an additive diagnostic convention. Task44
independently checks prospective Windows own-process counter availability/ABI/
units/meaning with at most three bounded children, not the unimplemented decoder.
Clarification46 permits timeout handling only for a known just-launched direct
own child; no descendants or foreign PID management. Clarification48 permits
prospective bounded static43 continuation, preserving its over-cap unretained
nested discovery and bootstrap/quoting gaps. Prior narrow correction is not
retrospectively authorized as a full-compliance fix. No expected outcome, cap
increase, resource qualification, hard OS enforcement, native-driver/helper/quota
assignment, production sleep/natural/air/spawn/time or cleanup follows.

Independent38 diagnostic provenance/findings remain open, including three recipe
attribution gaps and existing High R-021/log policy/evidence admission obligations.
Five injected native saves remain distinct from 26 synthetic direct event refusals.
D1/narrow-log requirements are separately frozen, not implemented. Twenty rows,
thirteen D1 rows, B1/R1/M1/M2, old worlds/clients/items/assets/hatch decisions,
strict timeout/native errors/retention/incidents/links stay open. Ledger remains
186 PLANNED /154 REVIEW; all Required Gates open, active goal not complete.

## Files and tests

Actual staged stat: seven files, 135 insertions /four deletions. Scope:
CURRENT_VERSION.md, COMPLETION-PLAN.md, v1.8 implementation log, additive note in
OFFLINE-CORE-AND-DIAGNOSTICS-STATUS-42.md, new OFFLINE-CORE-INDEPENDENT-STATUS-45.md
and OFFLINE-JSON-CORE-INDEPENDENT-40.zip /OFFLINE-CORE-ROOT-PUBLICATION-42.zip.
Only independent static review40 is marked verified, not the parent decoder task.
Own external leaf retains exact43/44/46 assignment snapshots and clarification48.
No source/test/build/API/schema/asset/provenance/owner/risk/ADR/ledger/Gate edit.
Source remains 85f53265bf4ee59b65c4a88664cb2e5e208c583e, equivalent to actually
tested d57ecda1f11dab76d882f945b0de606534ef4fb9. User AGENTS.md is untouched/
unstaged, SHA256 c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
Tests added/modified/executed by Root45: NONE. Historical2192 build/test JUnit and
594 required native passes are not rerun/rebound to this record-only commit.

## Actual commands, original failure and evidence

Pinned sealed Root33 runner is reused only with this new own __file__ context;
actual argv/cwd/UTC/exit, fixed180, split raw hashes and protected pre/post state
are retained. Root39 algorithms are read-only, hash-verified reuse in this leaf.

| Receipt | Actual 2026-10-09 UTC interval | Exit / result |
|---|---|---|
| package-01 | 09:30:47.922466-09:30:47.982214 | 1; KeyError exit_code before archive creation |
| package-corrected-02 | 09:31:49.902704-09:31:50.651449 | 0; actual declared schemas/seals/payload/CRC |
| task-inputs-03 | 09:32:30.000686-09:32:30.062824 | 0; three exact Root-owned task snapshots |
| check-02 | 09:33:47.338412-09:33:48.028898 | 0; exact protected scope/added links |
| check-final-04 | 09:35:43.236280-09:35:43.903966 | 0; final clarification note included |
| whitespace-01 | 09:35:44.614459-09:35:44.737870 | 0; git diff --check |
| stage-01 | 09:35:45.411540-09:35:45.511500 | 0; exact seven own files |
| cached-stat-01 | 09:35:46.224324-09:35:46.282642 | 0; seven files135 /4 |
| cached-diff-01 | 09:35:46.974857-09:35:47.035138 | 0; complete cached Markdown |
| cached-check-01 | 09:35:47.710504-09:35:47.769808 | 0; cached whitespace |
| commit-01 | 09:36:13.248926-09:36:13.527724 | 0; actual b80fb950 commit |
| push-01 | 09:36:14.206561-09:36:18.214863 | 0; normal non-forced push |

The first helper assumes a flat seal schema and fails before writes. Root reads
actual Task40 nested verification/embedded streams and Root42 flat result, then
persists prospective bookkeeping correction47. The unchanged failed helper is
not retried; separate corrected02 checks only actual declared schemas, preserves
the original failure and verifies embedded stream hashes before archive creation.
No policy-denied command/cleanup is retried or Gate failure hidden. Final audit
must verify this exact original exit1, not assert every command passed.

Runner Chinese presentation is lossy; stored raw Git stdout is correct UTF-8.
Root reads the whole raw cached Markdown diff and stat before commit. Direct
read/editor/message transports have tool results, not invented child receipts.
Added-link checks are not historical whole-log portability. Prior worker40 and
current43/44 preparation gaps are retained, not normalized away. Final audit/seal
follow this report with separate actual output. No runtime/build/temp cleanup.

## Actual custody, volume and remaining v1.8 work

Archive40: 309361 compressed /705832 expanded bytes, SHA256
acef5e54b133b8f94c2fabd4ec49faa0d6a6f300ae37c9cf007e025b3d8f2230;
140 covered /691694 bytes, manifest
56151ac5caf85fd27df961844c9debffbe85c23c5d97147a82398b121308a3e5.
Archive42: 38172 /109609 bytes, SHA256
0115114443f048277816403439a0dfde5119639f1e2f8a75505114092ba63762;
42 covered /105230 bytes, manifest
ffe56db5f61cc72a9b3507089051c8f4751a74accd1bb7ad75b407a50fa0cb23.
Both exclude only self manifest and sole later SEAL-RESULT.json; archives hash
those too. Actual covered files/hashes, safe case-unique contained names/reparse,
exact exclusions, declared result counts, CRC and payload equality pass.

Actual36 sleep ZIPs:12993198 compressed /66163264 expanded bytes. Unchanged reserve
65011712 yields78004910 /131174976; conservative admission still fails before
unmapped loose/later sets. No atomic launch inventory, deletion, relabeling or
budget/category waiver. Individual-file/slice publication limits pass; source/
library/world/build trees are not exported. Evidence is this exclusive leaf's
actual raw receipts, task snapshots, hashes/seal/link/volume/final-audit records,
complete-reading acknowledgment and one-time custody manifest.

Next current-version work: finish actual43/44, independently review the proposed
diagnostic convention, disposition supported scope before separately assigning
bounded decoder/tests. Keep all source/runtime/diagnostic/R-021/acceptance obligations
separate. All current-version Required Gates satisfied: NO. No tag, release,
feature delivery, version PASS or active-goal completion.
