"""Repeat protected exact scope/added-link check after final clarification note."""
from pathlib import Path

source = (Path(__file__).resolve().parent / 'check_02.py').read_text(encoding='utf-8')
source = source.replace("exec(compile(source, str(Path(__file__)), 'exec')",
                        "source = source.replace('CHECK-02.json', 'CHECK-04.json')\nexec(compile(source, str(Path(__file__)), 'exec')")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
