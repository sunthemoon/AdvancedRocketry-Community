"""Reuse protected added-link audit for exact Root45 record-only scope."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/check_02.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'a06e96477358766a5a73740905fb6955e47e8428f2c24bb9bd16d9446eecad35'
source = raw.decode('utf-8').replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                                   'b0b818261621d6c607386925535a62f027dfbf8b')
source = source.replace('NATIVE-LOG-DISPOSITION-39.md', 'OFFLINE-CORE-INDEPENDENT-STATUS-45.md')
source = source.replace('NATIVE-LOG-REVISION-STATUS-36.md', 'OFFLINE-CORE-AND-DIAGNOSTICS-STATUS-42.md')
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
