"""Audit pushed Root45 state and all original actual receipt outcomes."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/final_audit_03.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '67be47ed4742907d12ed07e25cedca59e11b93a884f99ab88588cd64907cabe3'
source = raw.decode('utf-8')
source = source.replace("head = 'cd9b54a23b5bf92760b05655a427344d6b620984'",
                        "head = 'b80fb950b3965956ff6a75f8f86b9aff32aa196d'")
source = source.replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                        'b0b818261621d6c607386925535a62f027dfbf8b')
old = "assert receipt['exit_code'] == 0 and not receipt['timed_out']"
assert source.count(old) == 1
source = source.replace(old, "assert receipt['exit_code'] == (1 if receipt['name'] == 'package-01' else 0) and not receipt['timed_out']")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
