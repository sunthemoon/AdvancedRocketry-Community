# Task43: offline core diagnostic convention addendum

You are a delegated author/subagent, not Root or the independent reviewer.
Use neutral engineering style and do not delegate. Root is sole Main integrator.
Fixed governance is b0b818261621d6c607386925535a62f027dfbf8b; observation source
remains d57ecda1f11dab76d882f945b0de606534ef4fb9. Historical inputs keep their
own commit identities. Do not substitute mutable Main or move HEAD/index.

Exclusive new external write_scope:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-diagnostic-convention-20261009-43.
Check Git status/worktrees, applicable working AGENTS and live agents before
creating this absent leaf or helpers. Preserve user/peer/sealed/source/runtime
files. No cleanup, repository/worktree creation or source write permission.

Read all mandatory fixed project/product/principles/roadmap/version/master-test/
release-Gate/post-1.0/quality/parallel documents. The actual version filename is
docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md. Read fixed sleep checkpoints
33/39/42 and owner decisions, complete Task37 proposal/report and Task40 report.
Read Task43 itself and actual supplied input seals before a final custody result.
Do not use stored bytes as a substitute for complete nontruncated required reads.

Inputs:
- sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md:
  19096 bytes /271 lines, SHA256
  f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0.
- The same leaf's REPORT.md: 16797 bytes /225 lines, SHA256
  1f775414b3937a5d1813b57b511c616c0003bc09c7cadba07bf7424844b9bbb2.
- sleep-offline-json-core-independent-20261009-40/REPORT.md:
  18632 bytes /280 lines, SHA256
  aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60.
All named leaves are under D:/GitHub/ARCE-Task-Evidence/v1.8.0. Actual Task40
seal is pending at assignment; final custody must inspect its supplied result,
not infer creation from Root's permission. Author37 seal is already complete.

Outcome: propose an additive precise diagnostic-accounting convention for the
actual candidate37 API in response to independent40 R01. Choose and explain a
single deterministic convention for input-type preflight metrics/error locations,
reservation versus token-completion counters, partial-token maxima and scan versus
lookahead consumption. Specify preflight precedence, bound failure accounting,
error-span/location effects and the evidence needed to verify these conventions.
Report any dependency or unresolved ambiguity rather than silently selecting a
broader admission/resource/schema behavior. The accepted input profile, existing
inclusive caps, inert numbers, API shapes and cooperative/external deadlines are
not reopened by this assignment. No fixed remedy or independent verdict is given.

Write PROPOSED-DIAGNOSTIC-CONVENTION-01.md and REPORT.md, plus only necessary own
static receipt/custody/sealing helpers and metadata. This addendum is PROPOSED;
Root and a separate independent review must disposition it before implementation.
Do not overwrite candidate37, report40, old evidence or repository records.
No decoder/prototype/source, generated synthetic payload/test execution, source
schema/conversion/framing/capture/helper/NBT/log/runtime/world/native gameplay,
platform measurement/allocation/quota/process management or production sleep/
air/natural/spawn/time changes are assigned. No implementation or test authority.

Allowed commands: read-only bounded Git/rg and file/hash/manifest/ZIP inspection;
Python -B or PowerShell static receipt/arithmetic/inspection only. Every child has
an enforced 180-second ceiling, split streams <=256 KiB and actual argv/cwd/UTC/
exit/raw hashes. Own evidence leaf <=4 MiB; input displays can use contiguous
ranges without increasing raw-stream caps. Preserve failed operations and stop/
report unmet limits; no unbounded retry, historical receipt fabrication, network,
install/download/Gradle/JVM/Minecraft/Claude/cleanup/delegation or source exports.

Deliver stable proposal and REPORT paths, lines/bytes/SHA256. REPORT includes
completed/uncompleted scope, decisions, changed files, tests NOT_EXECUTED, actual
commands/errors/custody, evidence location, risks, Required Gate status and next
v1.8-only work. Await Root's complete exact-hash reading of both final files
before one-time own custody seal; then deliver actual coverage/exclusions.
No contract adoption, executable assignment, resource qualification, native
observation, R-021 acceptance, diagnostic waiver or Gate authority is inferred.
