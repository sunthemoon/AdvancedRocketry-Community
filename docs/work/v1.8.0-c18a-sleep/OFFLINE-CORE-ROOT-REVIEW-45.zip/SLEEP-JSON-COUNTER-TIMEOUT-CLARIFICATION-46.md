# Task44 prospective timeout clarification 46

Scope: Task44 only, task SHA256
adaae9e1865680d35fe02302b4932f44092f7c39b8eaef9efc560e177b6012e8.

The no-process-termination restriction protects foreign, game, service and system
processes. To enforce the already fixed 180-second child ceiling, the assigned
own receipt parent may stop only its own immediate child that it just launched,
on that actual timeout, retaining its known PID, raw streams, actual exit and
timeout receipt. This permission is prospective and not a failed-command retry.
The measurement/inspection child must not create subprocess descendants.
Python standard-library subprocess timeout handling for that own direct child
is permitted. A self-exit watchdog may be used only for the same bounded child,
but must not be described as independent external enforcement or OS preemption.
Record the actual mechanism and its limitations. No other PID enumeration,
termination, process tree action, runtime allocation or configuration is granted.

The initial overbroad/truncated listing and missing py executable remain failed
or incomplete preparation records; no raw-cap compliance or complete read is
inferred. Do not rerun that broad listing. Required governance/content reads must
be complete, through separately named bounded reads if needed. Do not fabricate
preparation raw streams or times. All caps, scope and other Task44 restrictions
remain unchanged.
