$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath('D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009').TrimEnd('\')
$targets = @('build', '.gradle', '_review-temp-21') | ForEach-Object { Join-Path $root $_ }
if (Get-Process -Id 15100 -ErrorAction SilentlyContinue) { throw 'Owned final compile launcher is still live.' }
$live = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^(java|javaw|gradle)(\.exe)?$' -and $_.CommandLine -and
    ($_.CommandLine.Contains($root) -or $_.CommandLine.Contains($root.Replace('\', '/')))
})
if ($live.Count) { throw 'Live owned final execution.' }
$cursor = $root
while ($cursor) {
    $item = Get-Item -LiteralPath $cursor -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Reparse ancestor: ' + $cursor) }
    $cursor = Split-Path -Parent $cursor
}
foreach ($target in $targets) {
    $absolute = [IO.Path]::GetFullPath($target)
    if (-not $absolute.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw ('Outside owned final root: ' + $absolute) }
    if (-not (Test-Path -LiteralPath $absolute)) { throw ('Missing final output: ' + $absolute) }
    $items = @((Get-Item -LiteralPath $absolute -Force)) + @(Get-ChildItem -LiteralPath $absolute -Force -Recurse)
    if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse final output.' }
}
[pscustomobject]@{ pre_delete_utc = (Get-Date).ToUniversalTime().ToString('o'); outputs = $targets; live_own_execution = 0 } | ConvertTo-Json
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target -Recurse -Force
    if (Test-Path -LiteralPath $target) { throw ('Retained final output: ' + $target) }
}
[pscustomobject]@{ end_utc = (Get-Date).ToUniversalTime().ToString('o'); result = 'own final outputs absent' } | ConvertTo-Json
