# Independent fixed 7a nested-chat review

Date: 2026-10-09 UTC. This is an immutable-cohort preliminary review, not the
final Task 21 REPORT or a seal. Successor source has not yet been supplied.

## Findings first

### R01 - Medium: ResourceLocation receiver admission remains incomplete

At fixed candidate 7a36169083f26a7c78dca6db0f53de7235e7a03f,
[ChatBounds:62](D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L62)
invokes the style font's namespace/path getters without checking its exact native
receiver class. The pinned ResourceLocation is non-final; getNamespace, getPath
and toString are overridable. Style.Serializer later invokes font.toString.
A derived font can therefore perform receiver behavior during preflight, or
return a serializer string unrelated to the bounded getters before the
post-allocation byte check. The same unguarded returned-identifier route exists
at ChatBounds:77-79 for the SHOW_ENTITY registry key. Pinned Forge registration
and ResourceKey storage retain the supplied identifier rather than establishing
an exact-class normalization guarantee.

Evidence: receiver-primary.stdout.txt lines 727, 902-914, 966-974 and the
Style.Serializer font branch; registry-key-primary.stdout.txt lines 53-64,
180-191, 1834-1843 and 2537-2552; wrapper-primary.stdout.txt lines 208-216.
The font issue was disclosed by the author and independently verified here.
This is static evidence, not an executed custom font/key or native fixture
failure. Root's Addendum 22 assigns a correction; it does not close this finding.

### R02 - Medium: EntityType behavior can run before the registry-key check

[ChatBounds:77](D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L77)
passes entity.type to ENTITY_TYPE.getKey after checking only the enclosing
EntityTooltipInfo class. EntityType is non-final with public constructors.
NamespacedWrapper delegates to ForgeRegistry.getKey/getResourceKey; the latter
looks up the value in an inverse HashBiMap. That lookup calls smearedHash(value),
which virtually invokes Object.hashCode. A derived EntityType can therefore run
an overridden hashCode during preflight, even without a matching registration.
Checking the returned ResourceLocation afterward would not prevent this call.

Evidence: entitytype-signatures.stdout.txt class/public constructor declarations;
wrapper-primary.stdout.txt lines 208-216; registry-key-primary.stdout.txt
lines 1679-1717 and 1960-1989; bimap-primary.stdout.txt lines 48-58 and 1239-1250.
The ordinary native type is not rejected by the proposed exact-value admission.
No derived EntityType was instantiated, registered, invoked or tested here.
Root's Addendum 23 assigns this independently reported correction, without a
prefilled successor result.

No Critical/High production or gameplay defect is established by these static
checks. Both findings limit broader finite receiver/pre-allocation claims;
the originally named ClickEvent/EntityTooltipInfo checks are source-addressed.

## Supported fixed-source result

Complete parent-to-candidate diff and complete candidate helper/Trace/unchanged
497-line Fixture were read. Only two adapterTest source files differ:
167 insertions, 54 deletions. Production, API, src/test, generated resources,
Gradle/build inputs, provenance and central files have empty fixed-object diffs.
Trace delegates boundedChat preflight, retains allocation reservation and its
post-serialization check, and remains 445 lines. ChatBounds is 166 lines and
contains only chat traversal/admission and focused tests. The extraction is a
reasonable single-responsibility split; no >500/>800-line class is introduced.

ClickEvent exact-class rejection precedes getValue and native getAction/getValue.
EntityTooltipInfo null/exact-class rejection precedes metadata processing and
its virtual serialize. Unsupported receivers raise IllegalStateException into
the existing capture-failure machinery. Schema, intervention, incompleteness,
observer, cleanup, fixture and native action semantics are unchanged.
All budgets are unchanged: chat depth 8, 32 visits/siblings, four arguments,
1024-character individual text, 8192 escaped-text estimate, 4096 reservation plus
1024 per visit; trace 64 frames plus sentinel, 32/128 events, 128/512 KiB, 512 tokens.

Three new GameTest methods compile but are UNEXECUTED. The ordinary-receiver test
covers all six click actions and absent/present native SHOW_ENTITY names with a
nested click. Two recording-subtype tests cover direct, sibling, translation,
SHOW_TEXT and SHOW_ENTITY-name routes, assert the exact refusal reason and zero
overridden getter/serializer counters. Existing five Trace and four Fixture
GameTests are unchanged, for twelve source-declared sleep GameTests at 7a.
No runtime discovery or result follows from those declarations.

## Actual independent compile and integrity

Source parent: 5b45132000ade1e3c8d130a6b8ccb29f07535124.
Candidate/detached HEAD: 7a36169083f26a7c78dca6db0f53de7235e7a03f.
Governance: fixed Main 6d1b796e0e93b9953af505dd3fd9b25d47b91d97, including
mandatory documents, active uppercase v1.8, post-v1.0/parallel rules, ADR-060
and complete Main disposition 18. Earliest acceptance remains v1.0.

Independent command:

```text
./gradlew.bat compileJava compileTestJava compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks
```

compile-01.command.json retains exact cmd.exe argv, cwd, environment and UTC.
Pre-start 2026-10-09T06:37:18.415060+00:00; start/end 06:37:18.417316 to
06:38:00.896258 UTC; exit 0; BUILD SUCCESSFUL in 42s; ten tasks executed.
JDK is installed Oracle 17.0.7+8-LTS-224; ceiling 1800 s. C/D free before
compile were 30518239232/292606390272 bytes, both >=10 GiB. Preflight records
available physical memory 21469820 KiB, no overlapping Java/Gradle execution,
no existing assigned outputs and a non-reparse owned worktree. Child temp is
the initially absent owned worktree _review-temp-21, not a peer/evidence temp.
All raw streams are retained, including 29/69 compiler-warning cohorts.
No JUnit, GameTest, build/package, DataGen, server, driver/parser or runtime ran.

Fixed Git and actual working source bytes match:

| File | Bytes /lines | SHA256 |
|---|---:|---|
| Trace | 27593 /445 | 20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f |
| ChatBounds | 10985 /166 | 639ddfe5d01fddd39b37a6dedf7c3bcda4a28493ee9d1da4c2faa13d17cd4058 |
| Unchanged Fixture | 33987 /497 | 1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |

INPUT-AND-SOURCE-IDENTITIES.json includes task/tool/primary entry hashes and
exact source bytes. Task 16 and 17 complete reports were read; every covered
seal member independently verifies (157 and 251). Task 16 report/manifest hashes
are 7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3 /
2aa9ee0dad7fce9a509b9c7b70ae3021f5f4e898138e42c8fee3de099d45b105.
Task 17 report/manifest are fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108 /
430acfcab917021c5fb1de7b44ae3a13306db723af13df631573bc0e95316d16.
Author's complete first-cohort unsealed report was read at SHA256
a8a2cea30caaa5fbce3df8102d6c573717e620fbc0d06e659c3f6273b9a00def.
It is not substituted for any future final author report or source successor.

## Ownership, preparation failures and remaining boundaries

The original worktree is still detached at 7a; index and tracked/source diffs
remain empty. Only this Task 21 evidence leaf and originally absent assigned
generated outputs were written. No Main/author/peer source/index/HEAD/process
interest, source edit, staging, commit, push, nested delegation or pet emission.
No platform/upstream code/art is imported; installed primary JARs are hashed/
inspected only and not bundled. Fixed input reads are not a production G0 audit.

The single native cleanup attempt was denied by Windows execution policy:
cleanup-01 exit 1, UnauthorizedAccess, 425-byte raw stderr. The script body,
its guarded pre-delete checks and Remove-Item calls did not execute. No deletion,
retry, bypass, alternate shell, peer takeover or process termination followed.
Retained owned build: 3912 files /20836588 bytes; .gradle: 16 /2936678;
_review-temp-21: empty. Later read-only audit finds no live owned Java/Gradle
process and the original HEAD/index/source unchanged. These outputs remain
Task 21's retained generation, not permission for another agent to clean them.

Early exploratory task/worktree/tool reads and the absent javap/Adoptium probes
were transcript-only, without invented UTC/raw receipts. A guessed pwsh path
failed before child creation; preflight.command.json retains FileNotFoundError
and zero streams. A separately named installed-Windows-PowerShell preflight
succeeded before compile. Some broad displays truncated; complete retained
inputs and focused source/report/governance reads followed. Capture is not
claimed to be a fully instrumented transcript of every preparation command.

Remaining: the source successor/delta and final author-report review; all new
tests and standard regression; current packaged/API/artifact qualification;
driver/parser encoding, spool, NBT and whole-trace token freeze; twenty native
rows/two invocations, typed disk/save/flush/reacquisition/restart, broader sleep
B1/R1/M1/M2/D1, production dimension/spawn/time policy, real clients, prior
world/coexistence and acceptance. Task 16's two Medium/one Low, Task 17's token
and encoding limits, and historical strict TIMEOUT/native ERROR/retention remain
open. No native outcome is prefilled or borrowed as a rerun.

All current/inherited Required Gates satisfied: **no**. Compile is not G1 full
clean-build, G3 executed behavior, G4-G8 runtime/player proof or G9 approval.
Within v1.8, review the additive committed correction against these exact
findings, then seek a separately authorized finite test/regression assignment.
This preliminary file and all 7a receipts stay distinct from a future successor.
