"""One-time, Root-read-gated, safe leaf-only evidence seal and read-only verification."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys

LEAF = Path(__file__).resolve().parent
EXCLUDED = {
    'SHA256SUMS.txt', 'SEAL-RESULT.json',
    'seal-01.command.json', 'seal-01.stdout.txt', 'seal-01.stderr.txt',
    'seal-verify-01.command.json', 'seal-verify-01.stdout.txt', 'seal-verify-01.stderr.txt',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def no_reparse(path):
    if path.is_symlink() or path.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError('Reparse member: ' + str(path))


def members():
    for ancestor in (LEAF, *LEAF.parents):
        no_reparse(ancestor)
    result = []
    seen = set()
    for path in sorted(LEAF.rglob('*')):
        no_reparse(path)
        if not path.is_file():
            continue
        relative = path.relative_to(LEAF).as_posix()
        if relative in EXCLUDED:
            continue
        parsed = PurePosixPath(relative)
        if parsed.is_absolute() or '..' in parsed.parts or ':' in relative or '\\' in relative:
            raise RuntimeError('Unsafe member: ' + relative)
        if relative.casefold() in seen or not path.resolve().is_relative_to(LEAF.resolve()):
            raise RuntimeError('Duplicate or outside member: ' + relative)
        seen.add(relative.casefold())
        if path.stat().st_size > 50 * 1024 * 1024:
            raise RuntimeError('Member larger than 50 MiB')
        result.append((relative, path))
    if sum(p.stat().st_size for _, p in result) > 100 * 1024 * 1024:
        raise RuntimeError('Evidence larger than 100 MiB')
    return result


manifest = LEAF / 'SHA256SUMS.txt'
if sys.argv[1] == 'seal':
    if manifest.exists() or (LEAF / 'SEAL-RESULT.json').exists():
        raise RuntimeError('Already sealed; no overwrite/retry')
    ack = json.loads((LEAF / 'ROOT-READ-ACK.json').read_text(encoding='utf-8'))
    if not ack['acknowledgement'] or ack['report_sha256'] != digest(LEAF / 'REPORT.md'):
        raise RuntimeError('Missing Root full-read acknowledgement or changed report')
    covered = members()
    lines = [digest(path) + '  ' + relative + '\n' for relative, path in covered]
    with manifest.open('x', encoding='utf-8', newline='\n') as out:
        out.writelines(lines)
    result = {'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'members': len(covered), 'covered_bytes': sum(p.stat().st_size for _, p in covered),
              'manifest_sha256': digest(manifest), 'report_sha256': digest(LEAF / 'REPORT.md'),
              'excluded': sorted(EXCLUDED)}
    with (LEAF / 'SEAL-RESULT.json').open('x', encoding='utf-8') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps(result, indent=2))
elif sys.argv[1] == 'verify':
    seen = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        expected, relative = line.split('  ', 1)
        parsed = PurePosixPath(relative)
        if not re.fullmatch('[0-9a-f]{64}', expected) or parsed.is_absolute() or '..' in parsed.parts or ':' in relative or '\\' in relative:
            raise RuntimeError('Unsafe seal line')
        if relative in EXCLUDED or relative.casefold() in seen:
            raise RuntimeError('Excluded/duplicate seal member')
        path = LEAF.joinpath(*parsed.parts)
        if not path.resolve().is_relative_to(LEAF.resolve()):
            raise RuntimeError('Seal member outside leaf')
        no_reparse(path)
        if digest(path) != expected:
            raise RuntimeError('Seal mismatch: ' + relative)
        seen.add(relative.casefold())
    if seen != {relative.casefold() for relative, _ in members()}:
        raise RuntimeError('Seal coverage mismatch')
    result = json.loads((LEAF / 'SEAL-RESULT.json').read_text(encoding='utf-8'))
    if result['manifest_sha256'] != digest(manifest) or result['report_sha256'] != digest(LEAF / 'REPORT.md'):
        raise RuntimeError('Post-seal identity mismatch')
    print(json.dumps({'verified_members': len(seen), 'manifest_sha256': digest(manifest),
                      'report_sha256': digest(LEAF / 'REPORT.md')}, indent=2))
else:
    raise RuntimeError('Unknown mode')
