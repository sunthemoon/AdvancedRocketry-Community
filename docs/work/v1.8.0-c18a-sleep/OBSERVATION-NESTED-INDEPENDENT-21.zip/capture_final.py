"""Task 25 receipts for the separate fixed-successor review generation."""
from pathlib import Path
import os
import sys
import capture

capture.CWD = Path('D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009')

if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        capture.run('final-compile-02', [os.environ['COMSPEC'], '/d', '/c', 'gradlew.bat', 'compileJava', 'compileTestJava',
                    'compileAdapterTestJava', '--no-daemon', '--no-build-cache', '--rerun-tasks'], True)
    else:
        capture.run(sys.argv[1], sys.argv[2:])
