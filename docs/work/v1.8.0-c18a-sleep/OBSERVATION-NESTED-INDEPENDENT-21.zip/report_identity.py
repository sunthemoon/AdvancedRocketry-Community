"""Read-only final report identity and evidence-helper syntax preparation."""
import ast
import hashlib
import json
from pathlib import Path

leaf = Path(__file__).resolve().parent
for name in ('seal.py', 'audit_evidence.py', 'final_inventory.py'):
    ast.parse((leaf / name).read_text(encoding='utf-8'), filename=name)
raw = (leaf / 'REPORT.md').read_bytes()
print(json.dumps({'path': str(leaf / 'REPORT.md'), 'bytes': len(raw),
                  'lines': len(raw.splitlines()), 'sha256': hashlib.sha256(raw).hexdigest(),
                  'evidence_helper_syntax': 'valid', 'sealed': (leaf / 'SHA256SUMS.txt').exists()}, indent=2))
