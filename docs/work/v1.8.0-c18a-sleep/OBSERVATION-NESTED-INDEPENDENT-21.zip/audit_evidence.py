"""Verify existing independent receipts and the final author seal, without runtime."""
import hashlib
import json
from pathlib import Path
from inspect import peer_seal

leaf = Path(__file__).resolve().parent
records = []
for path in sorted(leaf.glob('*.command.json')):
    if path.name == 'receipt-and-author-seal-audit.command.json':
        continue
    record = json.loads(path.read_text(encoding='utf-8'))
    name = path.name.removesuffix('.command.json')
    for stream in ('stdout', 'stderr'):
        raw = (leaf / (name + '.' + stream + '.txt')).read_bytes()
        if len(raw) != record[stream + '_bytes'] or hashlib.sha256(raw).hexdigest() != record[stream + '_sha256']:
            raise RuntimeError('Receipt stream mismatch: ' + name)
    records.append({'receipt': path.name, **record})
author = peer_seal('sleep-observation-nested-boundary-20261009-19')
expected = '982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e'
if author['report_sha256'] != expected:
    raise RuntimeError('Author final report changed')
result = {'verified_receipts': len(records), 'author_final_seal': author, 'commands': records}
destination = leaf / 'COMMAND-INDEX-AND-AUTHOR-SEAL.json'
with destination.open('x', encoding='utf-8') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps({'verified_receipts': len(records), 'author_final_seal': author,
                  'nonzero_or_preparation_error': [r for r in records if r.get('exit_code', 0) or r.get('preparation_or_execution_error')],
                  'evidence_bytes_before_report_and_seal': sum(p.stat().st_size for p in leaf.iterdir() if p.is_file())}, indent=2))
