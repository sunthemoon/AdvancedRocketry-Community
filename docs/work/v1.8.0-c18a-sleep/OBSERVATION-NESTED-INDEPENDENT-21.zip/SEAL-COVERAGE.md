# Task 21 one-time evidence sealing boundary

Only this evidence leaf's safe ordinary files are covered. No external source,
build, .gradle, Temp, cache, peer leaf or platform JAR is a manifest member.
Root must completely read the final REPORT.md and acknowledge the one-time seal
before ROOT-READ-ACK.json is written and seal.py is invoked. The acknowledgement
identifies the fully read REPORT by SHA256. No acknowledgement is inferred.

The following names are deliberately excluded because they are the manifest
itself or post-seal receipts/results; all other leaf files must be covered:

- SHA256SUMS.txt
- SEAL-RESULT.json
- seal-01.command.json
- seal-01.stdout.txt
- seal-01.stderr.txt
- seal-verify-01.command.json
- seal-verify-01.stdout.txt
- seal-verify-01.stderr.txt

The seal helper rejects existing seals, unsafe/outside/case-duplicate members,
reparse points, files over 50 MiB or covered total over 100 MiB. It writes the
manifest once with leaf-relative forward-slash paths, then performs a separately
captured read-only hash/coverage verification. No covered file changes after
sealing; corrections require a separately authorized additive record.
