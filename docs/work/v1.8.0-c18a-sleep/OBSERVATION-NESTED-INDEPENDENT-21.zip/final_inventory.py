"""Read-only final source, retention and author-report identities for Task21."""
import hashlib
import json
from pathlib import Path
import subprocess

result = {'owned_outputs': [], 'sources': {}, 'git': {}}
roots = (
    Path('D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009'),
    Path('D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009'),
)
for root in roots:
    result['git'][str(root)] = {}
    for args in (['rev-parse', 'HEAD'], ['status', '--porcelain=v1'], ['diff', '--check']):
        p = subprocess.run(['git', '-C', str(root)] + args, capture_output=True, timeout=180)
        result['git'][str(root)][' '.join(args)] = {
            'exit_code': p.returncode, 'stdout': p.stdout.decode('utf-8'),
            'stderr': p.stderr.decode('utf-8'),
        }
        if p.returncode:
            raise RuntimeError('Git read failed')
    for name in ('build', '.gradle', '_review-temp-21'):
        path = root / name
        files = [p for p in path.rglob('*') if p.is_file()] if path.exists() else []
        result['owned_outputs'].append({
            'path': str(path), 'exists': path.exists(), 'files': len(files),
            'bytes': sum(p.stat().st_size for p in files),
        })
    result['sources'][str(root)] = {}
    for name in ('SleepBoundaryTrace', 'SleepBoundaryChatBounds', 'SleepBoundaryObservationFixture'):
        path = root / ('src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name + '.java')
        raw = path.read_bytes()
        result['sources'][str(root)][name] = {
            'bytes': len(raw), 'lines': len(raw.splitlines()),
            'sha256': hashlib.sha256(raw).hexdigest(),
        }
author = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-20261009-19/REPORT.md')
raw = author.read_bytes()
result['author_report'] = {'path': str(author), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
expected = '982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e'
if result['author_report']['sha256'] != expected:
    raise RuntimeError('Root-ready author report identity changed')
print(json.dumps(result, indent=2))
