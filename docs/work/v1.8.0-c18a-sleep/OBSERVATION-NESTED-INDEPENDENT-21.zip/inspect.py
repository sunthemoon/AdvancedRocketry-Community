"""Compact fixed review input/hash audit, without executable game behavior."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile
import capture

sys.stdout.reconfigure(encoding='utf-8')
BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
PARENT = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
CANDIDATE = '7a36169083f26a7c78dca6db0f53de7235e7a03f'
GIT = 'C:/Program Files/Git/cmd/git.exe'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def peer_seal(name):
    leaf = BASE / name
    manifest = leaf / 'SHA256SUMS.txt'
    result = {'leaf': str(leaf), 'report_sha256': digest(leaf / 'REPORT.md'), 'manifest_sha256': digest(manifest)}
    seen = set()
    count = 0
    for line in manifest.read_text(encoding='utf-8-sig').splitlines():
        expected, relative = line.split('  ', 1)
        path = PurePosixPath(relative)
        if path.is_absolute() or '..' in path.parts or '\\' in relative or ':' in relative or relative.casefold() in seen:
            raise RuntimeError('Unsafe/duplicate peer seal member: ' + relative)
        seen.add(relative.casefold())
        target = leaf.joinpath(*path.parts)
        if not target.resolve().is_relative_to(leaf.resolve()) or target.is_symlink():
            raise RuntimeError('Outside peer seal member: ' + relative)
        if digest(target) != expected:
            raise RuntimeError('Peer seal mismatch: ' + relative)
        count += 1
    result['verified_members'] = count
    return result


if __name__ == '__main__':
    result = {'task21_sha256': digest(BASE / 'SLEEP-OBSERVATION-NESTED-BOUNDARY-REVIEW-TASK-21.md'),
              'task19_sha256': digest(BASE / 'SLEEP-OBSERVATION-NESTED-BOUNDARY-TASK-19.md'),
              'peer_seals': [peer_seal('sleep-observation-driver-contract-independent-20261009-16'),
                             peer_seal('sleep-observation-wire-qualification-20261009-17')]}
    for suffix, argv in [('head', ['rev-parse', 'HEAD']), ('index', ['ls-files', '--stage']),
                         ('status', ['status', '--short', '--untracked-files=all']),
                         ('diffcheck', ['diff', '--check', PARENT, CANDIDATE]),
                         ('changes', ['diff', '--name-status', PARENT, CANDIDATE]),
                         ('production-build-scope', ['diff', '--exit-code', PARENT, CANDIDATE, '--',
                          'src/main', 'src/test', 'src/generated', 'build.gradle', 'settings.gradle',
                          'gradle.properties', 'gradle', 'gradlew', 'gradlew.bat', 'docs/provenance'])]:
        capture.run('identity-' + suffix, [GIT] + argv)
        result[suffix] = {'stdout_sha256': digest(capture.LEAF / ('identity-' + suffix + '.stdout.txt')),
                          'receipt': 'identity-' + suffix + '.command.json'}
    files = ['SleepBoundaryTrace.java', 'SleepBoundaryChatBounds.java', 'SleepBoundaryObservationFixture.java']
    result['source'] = []
    for name in files:
        relative = 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name
        capture.run('source-' + name[:-5], [GIT, 'show', CANDIDATE + ':' + relative])
        raw = capture.LEAF / ('source-' + name[:-5] + '.stdout.txt')
        result['source'].append({'path': relative, 'fixed_git_bytes': raw.stat().st_size,
                                'fixed_git_sha256': digest(raw), 'working_bytes': (capture.CWD / relative).stat().st_size,
                                'working_sha256': digest(capture.CWD / relative), 'lines': len(raw.read_bytes().splitlines())})
    primary = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
    result['primary_jar'] = {'path': str(primary), 'bytes': primary.stat().st_size, 'sha256': digest(primary)}
    with zipfile.ZipFile(primary) as archive:
        result['primary_entries'] = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in [
            'net/minecraft/network/chat/ClickEvent.class', 'net/minecraft/network/chat/HoverEvent$EntityTooltipInfo.class',
            'net/minecraft/network/chat/Style$Serializer.class', 'net/minecraft/resources/ResourceLocation.class',
            'net/minecraft/network/chat/TextColor.class']}
    result['tools'] = [{'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)} for path in [
        Path('D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe'), capture.JDK / 'bin/java.exe', capture.JDK / 'bin/javap.exe']]
    (capture.LEAF / 'INPUT-AND-SOURCE-IDENTITIES.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
