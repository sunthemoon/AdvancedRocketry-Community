$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath('D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009').TrimEnd('\')
$targets = @('build', '.gradle', '_review-temp-21') | ForEach-Object { Join-Path $root $_ }
$started = (Get-Date).ToUniversalTime().ToString('o')
$own = @(Get-CimInstance Win32_Process | Where-Object {
    ($_.Name -match '^(java|javaw|gradle)(\.exe)?$') -and $_.CommandLine -and
    ($_.CommandLine.Contains($root) -or $_.CommandLine.Contains($root.Replace('\', '/')))
} | Select-Object ProcessId, ParentProcessId, Name)
if ($own.Count -ne 0) { throw ('Live owned execution: ' + ($own | ConvertTo-Json -Compress)) }
if (Get-Process -Id 16992 -ErrorAction SilentlyContinue) { throw 'Owned compile launcher PID is still live.' }
$cursor = $root
while ($cursor) {
    $item = Get-Item -LiteralPath $cursor -Force
    if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { throw ('Reparse ancestor: ' + $cursor) }
    $cursor = Split-Path -Parent $cursor
}
$inventory = @()
foreach ($target in $targets) {
    $absolute = [System.IO.Path]::GetFullPath($target)
    if (-not $absolute.StartsWith($root + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw ('Outside owned root: ' + $absolute) }
    if (-not (Test-Path -LiteralPath $absolute)) { throw ('Missing expected owned output: ' + $absolute) }
    $items = @((Get-Item -LiteralPath $absolute -Force)) + @(Get-ChildItem -LiteralPath $absolute -Force -Recurse)
    if (@($items | Where-Object { $_.Attributes -band [System.IO.FileAttributes]::ReparsePoint }).Count -ne 0) {
        throw ('Reparse output: ' + $absolute)
    }
    $files = @($items | Where-Object { -not $_.PSIsContainer })
    $inventory += [pscustomobject]@{ path = $absolute; files = $files.Count; bytes = ($files | Measure-Object -Property Length -Sum).Sum }
}
[pscustomobject]@{ pre_delete_utc = $started; owned_compile_pid_absent = 16992; live_own_execution = $own; outputs = $inventory } | ConvertTo-Json -Depth 5
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target -Recurse -Force
    if (Test-Path -LiteralPath $target) { throw ('Retained after single native deletion: ' + $target) }
}
[pscustomobject]@{ end_utc = (Get-Date).ToUniversalTime().ToString('o'); removed = $targets; result = 'all owned outputs absent' } | ConvertTo-Json -Depth 4
