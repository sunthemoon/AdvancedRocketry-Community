"""Fixed successor scope/source audit for Task 25, no game invocation."""
import hashlib
import json
from pathlib import Path
import capture

capture.CWD = Path('D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009')
PARENT = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
ORIGINAL = '7a36169083f26a7c78dca6db0f53de7235e7a03f'
FINAL = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
GIT = 'C:/Program Files/Git/cmd/git.exe'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


if __name__ == '__main__':
    result = {'final': FINAL, 'source': []}
    for suffix, args in [('head', ['rev-parse', 'HEAD']), ('index', ['ls-files', '--stage']),
                         ('status', ['status', '--short', '--untracked-files=all']),
                         ('parents', ['log', '-3', '--format=%H %P %s', FINAL]),
                         ('changes', ['diff', '--name-status', PARENT, FINAL]),
                         ('stat', ['diff', '--stat', PARENT, FINAL]),
                         ('diffcheck', ['diff', '--check', PARENT, FINAL]),
                         ('unchanged-trace-fixture', ['diff', '--exit-code', ORIGINAL, FINAL, '--',
                          'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java',
                          'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java']),
                         ('production-build-scope', ['diff', '--exit-code', PARENT, FINAL, '--',
                          'src/main', 'src/test', 'src/generated', 'build.gradle', 'settings.gradle',
                          'gradle.properties', 'gradle', 'gradlew', 'gradlew.bat', 'docs/provenance'])]:
        capture.run('final-identity-' + suffix, [GIT] + args)
        result[suffix] = {'stdout_sha256': sha(capture.LEAF / ('final-identity-' + suffix + '.stdout.txt')),
                          'receipt': 'final-identity-' + suffix + '.command.json'}
    for name in ['SleepBoundaryTrace.java', 'SleepBoundaryChatBounds.java', 'SleepBoundaryObservationFixture.java']:
        relative = 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name
        capture.run('final-source-' + name[:-5], [GIT, 'show', FINAL + ':' + relative])
        raw = capture.LEAF / ('final-source-' + name[:-5] + '.stdout.txt')
        working = capture.CWD / relative
        if raw.read_bytes() != working.read_bytes():
            raise RuntimeError('Working/fixed source mismatch: ' + relative)
        result['source'].append({'path': relative, 'bytes': raw.stat().st_size, 'sha256': sha(raw),
                                'lines': len(raw.read_bytes().splitlines())})
    result['source_declared_sleep_tests'] = {
        name: (capture.CWD / ('src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name)).read_text().count('@GameTest(')
        for name in ['SleepBoundaryTrace.java', 'SleepBoundaryChatBounds.java', 'SleepBoundaryObservationFixture.java']}
    (capture.LEAF / 'FINAL-SOURCE-IDENTITIES.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
