"""Independent static-review command receipts; does not run tests or a driver."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

LEAF = Path(__file__).resolve().parent
CWD = Path('D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009')
JDK = Path('C:/Program Files/Java/jdk-17.0.7')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, argv, compile_command=False):
    stdout = LEAF / (name + '.stdout.txt')
    stderr = LEAF / (name + '.stderr.txt')
    receipt = LEAF / (name + '.command.json')
    if any(p.exists() for p in (stdout, stderr, receipt)):
        raise RuntimeError('Existing evidence: ' + name)
    env = os.environ.copy()
    record = {'argv': argv, 'cwd': str(CWD), 'pre_start_utc': utc(), 'timeout_seconds': 1800 if compile_command else 180}
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    try:
        if compile_command:
            record['disk_free_bytes'] = {drive: shutil.disk_usage(drive).free for drive in ('C:/', 'D:/')}
            if min(record['disk_free_bytes'].values()) < 10 * 1024 ** 3:
                raise RuntimeError('Less than 10 GiB free')
            temp = CWD / '_review-temp-21'
            temp.mkdir(exist_ok=False)
            if any(env.get(key) for key in ('_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'JAVA_TOOL_OPTIONS')):
                raise RuntimeError('Unexpected JVM override')
            env.update(JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + env['PATH'], TEMP=str(temp), TMP=str(temp), JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + str(temp))
            record['child_environment'] = {key: env[key] for key in ('JAVA_HOME', 'JAVA_TOOL_OPTIONS', 'TEMP', 'TMP')}
        with stdout.open('wb') as out, stderr.open('wb') as err:
            record['start_utc'] = utc()
            process = subprocess.Popen(argv, cwd=CWD, env=env, stdout=out, stderr=err)
            record['pid'] = process.pid
            receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
            try:
                record['exit_code'] = process.wait(timeout=record['timeout_seconds'])
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                record.update(exit_code=process.returncode, result='TIMEOUT', stopped_owned_child=True)
    except Exception as error:
        record['preparation_or_execution_error'] = repr(error)
        if not stderr.exists():
            stderr.write_text(repr(error) + '\n', encoding='utf-8')
        if not stdout.exists():
            stdout.write_bytes(b'')
    record.update(end_utc=utc(), stdout_bytes=stdout.stat().st_size, stderr_bytes=stderr.stat().st_size,
                  stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        run('compile-01', [os.environ['COMSPEC'], '/d', '/c', 'gradlew.bat', 'compileJava', 'compileTestJava',
                           'compileAdapterTestJava', '--no-daemon', '--no-build-cache', '--rerun-tasks'], True)
    else:
        run(sys.argv[1], sys.argv[2:])
