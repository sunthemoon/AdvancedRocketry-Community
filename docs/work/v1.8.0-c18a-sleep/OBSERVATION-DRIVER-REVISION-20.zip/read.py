"""Print complete or numbered focused static inputs without changing them."""
import pathlib
import sys

for argument in sys.argv[1:]:
    pieces = argument.rsplit("::", 1)
    path = pathlib.Path(pieces[0])
    print("=== " + str(path) + " ===", flush=True)
    if path.is_dir():
        for child in sorted(path.iterdir()):
            print(child.name + ("/" if child.is_dir() else " " + str(child.stat().st_size)))
    elif len(pieces) == 1:
        sys.stdout.buffer.write(path.read_bytes())
        sys.stdout.buffer.write(b"\n")
    else:
        start, end = map(int, pieces[1].split(":"))
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if start <= number <= end:
                sys.stdout.buffer.write((str(number) + ": " + line + "\n").encode("utf-8"))
