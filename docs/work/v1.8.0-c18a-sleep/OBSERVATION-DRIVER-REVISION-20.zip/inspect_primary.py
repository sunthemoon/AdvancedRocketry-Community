"""Hash installed read-only primary containers and selected ZIP entries."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
jar = Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
with jar.open("rb") as stream:
    digest = hashlib.file_digest(stream, "sha256").hexdigest()
result = {"kind": "static-installed-primary-not-runtime-qualification", "container": {"path": str(jar), "bytes": jar.stat().st_size, "sha256": digest}, "entries": []}
with zipfile.ZipFile(jar) as archive:
    names = archive.namelist()
    for name in ["net/minecraft/nbt/NbtIo.class", "net/minecraft/world/level/storage/PlayerDataStorage.class"]:
        if names.count(name) != 1:
            raise ValueError("Missing/nonunique entry: " + name)
        info = archive.getinfo(name)
        data = archive.read(info)
        result["entries"].append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "crc32": f"{info.CRC:08x}", "read_crc_validated": True})
target = root / "PRIMARY-IDENTITIES.json"
if target.exists():
    raise FileExistsError(str(target))
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
