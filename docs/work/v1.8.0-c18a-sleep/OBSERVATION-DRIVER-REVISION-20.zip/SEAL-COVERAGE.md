# One-time static record seal coverage

Root's Task20 coordination message confirms complete reading of REPORT.md
(245 lines, SHA25606943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6)
and PROPOSED-DRIVER-03.md (991 lines,
SHA256c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680).
Root authorizes one-time safe leaf-relative sealing only. The message does not
grant proposal acceptance, executable/runtime permissions, or any Gate conclusion.

The manifest covers every regular file already in this exclusive leaf, including
helpers, actual raw command receipts, incident-original copy and Correction24
permission. All existing ancestors and members are checked for reparse/symlink
identity before hashing; no external or unsafe member is admitted.

The complete exclusions are:
1. SHA256SUMS.txt itself: no self-reference.
2. SEAL-RESULT.json: an explicitly post-seal receipt containing actual child
   pre-start/end UTC, argv/cwd/exit, unchanged raw stdout/stderr as base64 and
   decoded ASCII diagnostics, final manifest verification and file/byte counts.

The mutable out-of-scope37-byte original remains outside the leaf after the one
policy-denied corrective attempt. It is not a covered file. Only its exact
preserved37-byte INCIDENT-ORIGINAL.txt and the failure/permission evidence are
covered. Nothing is removed, retried, overwritten or declared accepted here.
No prior sealed input is edited. No hash line points outside this leaf.
