# Later Root coordination inputs

Received in the Task20 coordination session on 2026-10-09. These inputs are
separate from fixed governance309 and source5b; no per-message submission UTC is
available here and none is invented. They are not executions by this worker.

1. Root moves Main only for Tasks16/17 disposition documents and sealed archives.
   Task20 continues to read fixed309 governance and5b source, holding no Main or
   process interest and making no historical seal/source modifications.
2. Root reports the first Task19 source revision7a and separately assigns
   Addendum22 for font/corresponding ResourceLocation receivers. Task20 does not
   inspect, test or qualify7a or an unproduced successor. The complete addendum
   permission text was read under commands/36.
3. Root reports Task21 primary static evidence that Forge's inverse registry
   value lookup can invoke EntityType.hashCode before returned-key checks, and
   EntityType is publicly constructible/subclassable. Root's Addendum23 extends
   Task19's source boundary work. Its complete permission text was read under
   commands/36. No final source, compile or independent review is assumed here.
4. Root reports17 sleep ZIPs at Main6d totaling5,677,163 compressed bytes and
   32,447,830 expanded bytes, from disposition18/PACKAGING-01. These are later
   supplied planning constraints, not archive inspections performed by Task20.
   Successor source/review/regression volumes remain unknown. Actual slice-wide
   inventory is required before a later launch; the proposed limits cannot be
   justified by assuming future compression or by counting time as volume.
5. Root expressly states proposed OS hard allocation/new capture budgets still
   await independent review and are not executable approval. Proposal03 retains
   those limits as unassigned, qualification-dependent specifications.
6. Root's Correction24 supplied one literal-file correction permission for the
   mistakenly created37-byte external placeholder, requiring identity checks and
   denial-stop. Exact bytes/permission were preserved; command39 was rejected by
   PowerShell execution policy before the script ran. Root then explicitly required
   no retry/bypass/alternate/Root removal. The original remains outside the leaf,
   scope incident unresolved. Only the preserved leaf copy is manifest-covered.

The precise permission files are external read-only inputs. Their hashes and
the final governed/static input identities will be included in the pre-seal
audit; they are not added to or substituted into any earlier sealed package.
