"""Preserve the exact single-file incident and Root's correction permission."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
items = [
    (root.parent / "LATER-INPUTS-INVALID-PLACEHOLDER.md", "INCIDENT-ORIGINAL.txt", 37, "87491e3764bcb18ecbf1845ad6e50942911383694c33dd40a18a24c707d8698a"),
    (root.parent / "SLEEP-OBSERVATION-DRIVER-REVISION-CORRECTION-24.md", "CORRECTION-PERMISSION-24.md", None, "c06411ac4bb7c0e701ff1371308b6b2c9434037c1d8535063857a7fdec2f34e6"),
]
result = []
for source, name, expected_size, expected_hash in items:
    data = source.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != expected_hash or (expected_size is not None and len(data) != expected_size):
        raise ValueError("Identity changed: " + str(source))
    target = root / name
    if target.exists():
        raise FileExistsError(str(target))
    target.write_bytes(data)
    result.append({"source": str(source), "preserved": name, "bytes": len(data), "sha256": digest})
print(json.dumps({"kind": "authorized-incident-preservation-not-runtime", "files": result}, indent=2))
