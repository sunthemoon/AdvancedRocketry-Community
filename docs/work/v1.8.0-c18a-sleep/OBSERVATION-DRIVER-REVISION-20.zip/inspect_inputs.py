"""Read-only static input/seal identities; writes only this evidence leaf."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent

def identity(path):
    digest = hashlib.sha256()
    length = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
            length += len(chunk)
    return {"path": str(path), "bytes": length, "sha256": digest.hexdigest()}

leaves = [
    "sleep-observation-driver-contract-20261009-15",
    "sleep-observation-driver-contract-independent-20261009-16",
    "sleep-observation-wire-qualification-20261009-17",
]
result = {"kind": "static-inputs-not-runtime-qualification", "source": "5b45132000ade1e3c8d130a6b8ccb29f07535124", "governance": "30944465a6e07215990182fb0dd935e65303e27a", "seals": [], "inputs": []}
for name in leaves:
    leaf = BASE / name
    manifest = leaf / "SHA256SUMS.txt"
    checked = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
        if match is None:
            raise ValueError("Unsupported manifest entry: " + line)
        expected, relative = match.groups()
        candidate = leaf / relative
        if Path(relative).is_absolute() or candidate.resolve().is_relative_to(leaf.resolve()) is False:
            raise ValueError("External manifest entry: " + relative)
        actual = identity(candidate)
        if actual["sha256"] != expected.lower():
            raise ValueError("Hash mismatch: " + str(candidate))
        checked.append({"relative": relative, "bytes": actual["bytes"], "sha256": actual["sha256"]})
    result["seals"].append({"leaf": str(leaf), "manifest": identity(manifest), "report": identity(leaf / "REPORT.md"), "covered_count": len(checked), "covered_bytes": sum(item["bytes"] for item in checked), "all_match": True})

for name in ["SLEEP-OBSERVATION-DRIVER-CONTRACT-TASK-15.md", "SLEEP-OBSERVATION-DRIVER-CONTRACT-REVIEW-TASK-16.md", "SLEEP-OBSERVATION-WIRE-QUALIFICATION-TASK-17.md", "SLEEP-OBSERVATION-NESTED-BOUNDARY-TASK-19.md", "SLEEP-OBSERVATION-DRIVER-REVISION-TASK-20.md"]:
    result["inputs"].append(identity(BASE / name))
result["inputs"].append(identity(BASE / leaves[0] / "PROPOSED-DRIVER-02.md"))
result["inputs"].append(identity(Path("D:/GitHub/AdvancedRocketry-Community/AGENTS.md")))
for name in ["06-fixed-source-fixture", "07-fixed-source-trace"]:
    result["inputs"].append(identity(ROOT / "commands" / (name + ".stdout.txt")))
for path in [Path("C:/Program Files/Java/jdk-17.0.7/bin/java.exe"), Path("C:/Program Files/Java/jdk-17.0.7/bin/javap.exe"), Path("C:/Program Files/Java/jdk-17.0.7/release"), Path("C:/Program Files/Java/jdk-17.0.7/lib/modules")]:
    result["inputs"].append(identity(path))
for path in sorted((ROOT / "commands").glob("governance-*.stdout.txt")):
    result["inputs"].append(identity(path))
target = ROOT / "INPUTS.json"
if target.exists():
    raise FileExistsError(str(target))
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
