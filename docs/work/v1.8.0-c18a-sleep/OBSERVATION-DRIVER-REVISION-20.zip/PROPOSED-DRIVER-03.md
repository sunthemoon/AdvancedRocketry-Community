# Packaged sleep observation driver/parser contract revision 03

Date: 2026-10-09. Status: **PROPOSED / STATIC ONLY / NOT AN EXECUTABLE FREEZE**.
This contract describes a possible later explicitly assigned driver and offline
parser. It supplies no runtime permission, executed result, acceptance verdict,
artifact identity, gameplay policy or owner authorization beyond its quoted
source. No driver, parser or tests are supplied by TASK-20. This is a self-contained
revision of proposal 02, not an amendment of its sealed historical bytes.

## 1. Authority, immutable inputs and separate result domains

Source base is `b9bec789978de0df67c93e976239d6d36e41532b`; corrected fixture source
is `5b45132000ade1e3c8d130a6b8ccb29f07535124`. Governance/owner-record checkpoint
is `30944465a6e07215990182fb0dd935e65303e27a`. The two complete Java files were
read using fixed Git objects, not the author checkout. Within this document,
**Fixture** and **Trace** mean SleepBoundaryObservationFixture.java and
SleepBoundaryTrace.java at that corrected source. Raw inputs and hashes are in
INPUTS.json and commands/06-fixed-source-fixture.stdout.txt and
commands/07-fixed-source-trace.stdout.txt. The old proposal is design input, not a
runtime result or authority for the corrected schema. Sealed Tasks 16/17 supply
independent review and primary wire facts. Task 19 is a separate, unresolved
nested-receiver source dependency: no result, new source identity, compilation
or tests from it are assumed here. Root's later Addendum22 also requires font/
corresponding ResourceLocation receiver review. Root's later Addendum23 also
requires EntityType value-receiver review before registry inverse-map hashCode.
These are unresolved dependencies, not qualification of any Task19 revision or
successor. At fixed 5b, universal bounded chat admission
is not established; this proposal does not make that source launch-ready.

The exact owner reply in OWNER-DECISION-03 is: "接受原生维度行为，按上述范围冻结并审核。"
It conditionally accepts the question's native ancillary dimension behavior
while preserving no Earth-night skip and no existing-spawn change. It still
requires exact behavior freeze/review. It does not authorize this driver, new
dimension resources, production sleep/enforcement, a respawn policy, migration,
air-gap/station choice or Gate/item closure. D1's ancillary *choice* is answered;
D1's separate dimension/spawn/time contract and qualification are unfinished.

The possible future observation scope is exactly **one fresh packaged native
process with two sequential console invocations of the same twenty-row native-
Java fixture**, not a restart or retry. Evidence class is exactly
`native-Java simulated transport`. There is no TCP status query, gameplay TCP,
client, prior world, death, restart, inherited/custom bed, monster/item/mod
qualification, off-world natural/spawn/time/air implementation, production cause
decision, global night skip, migration or acceptance campaign in this scope.

Results must remain independently inspectable:

1. Input/artifact/helper integrity and launch identity.
2. Process/command execution and actually attempted native actions.
3. Capture completeness, structural parser findings and retained frame data.
4. Declared interventions and their actually reached attribution.
5. Actual native getters/pose/bed/chat/effects and off/on comparisons.
6. Fixture teardown and external disposable-output cleanup.
7. Native save, typed disk Spawn, logout/reacquisition and process exit evidence.
8. Review/acceptance status; no domain above makes a Required Gate PASS.

No native spawn, sleep, bed, frame, chat or equality result is specified here.
Any later driver RESULT document starts with actual unexecuted/unknown state and
is populated from retained bytes/receipts, not from this inventory.

## 2. Future qualification manifest: actual inputs, not inherited hashes

Before implementation freeze or launch, a later assignment must identify actual
committed driver/parser/tests/helpers, source cohort, published API, host/fixture
JARs, JDK, libraries, argument files and configuration. Reject absent qualification
inputs; do not insert historical values or a provisional source hash in their
place. Static planning INPUTS.json is expressly not that manifest.

| Boundary | Required later qualification |
|---|---|
| Source | Exact tested host and fixture commits; the two corrected source blob identities or independently reviewed subsequent equivalents; fixed governance/task/review hashes; clean assigned source-input diff. A moving Main or unrelated HEAD is insufficient. |
| Executables | Each driver/parser/test/helper byte length and SHA-256, publication commit/archive/manifest identity, exact Git-blob equality and staged/unstaged drift checks. No ambient source import, stale pyc, plugin, dynamic download or unreviewed helper. |
| Host/fixture/API | Actual build/publication/consumer/reobfuscation receipts for the tested source; all JAR lengths/hashes and safe unique ZIP entries/CRC; actual mods.toml IDs/versions and dependency metadata. No assumed jackhammer or compile-only class hashes. |
| Boundary proof | Host lacks adapter-test classes; fixture contains both corrected top-level classes and actual nested classes, under `io/github/sunthemoon/arceadaptertest/`, with no bundled host/API/platform classes or jarjar payload. Actual independent consumer classpath resolves only the published API classifier plus platform; preserve negative internal-import proof. |
| Packaging metadata | The inspected consumer recipe defaults arceVersion to an older value and its exported API list is finite. A later packaging task must select the actual current publication and successfully qualify that unchanged/independently reviewed recipe. No success is inferred from reading build.gradle. |
| Native libraries | Exact source-template identity and finite relative library inventory, lengths/hashes, Forge 1.20.1-47.4.10, win_args.txt and recursively referenced argument files; all referenced paths contained and copied bytes equal. Historical library counts are not acceptance rules. |
| Java/environment | Exact Java 17 executable hash, release/version output/exit, OS/architecture, actual expanded argv/module/classpath, child-only TEMP/TMP/java.io.tmpdir, relevant environment. Reject JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, _JAVA_OPTIONS and ambient argument/agent injection unless explicitly frozen. |
| Containment | All inputs, outputs and existing ancestors have no reparse/junction/symlink; output is absent before creation and neither contains nor is inside input/source/library roots. Input templates contribute libraries only, never world/mods/config. |
| Freshness/space | Both UUID playerdata paths and world absent before launch; no ordinary player or imported world; absent owned temporary root. Check both C: and D: >=10 GiB immediately before launch. Ownership marker binds task/source/artifacts/config and is hashed before/after. |

Input manifests and ZIP inventories must themselves have fixed maximum bytes,
entries, path/string lengths and recursion depths before execution. Proposed
manifest limit is 4 MiB, 4096 file entries, 4096 characters per path and 16 levels
of argument-file recursion with cycle rejection; final reviewed manifests must
fit those bounds. Arguments may not reference arbitrary external files. These
are proposed driver limits, not observed library counts or source caps.

## 3. Native launch and configuration contract

Use the already inspected copied-libraries packaged Forge recipe; never Gradle
runServer, a development launch or arce.gameTestHooks. Exactly the later qualified
host and independent `arce_adapter_test` fixture JARs are installed. Reject
unexpected mods, datapacks, custom dimension definitions and inherited config.

The argv *shape*, with actual verified paths filled before launch, is:

`<qualified-Windows-Java17> -Xms512M -Xmx2G -Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -Djava.net.preferIPv4Stack=true -Djava.io.tmpdir=<owned-temp> -Darce.sleepBoundaryObservation=true @libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt nogui`

The three encoding properties are an explicit proposed recipe change, requiring
independent executable/recipe review; they were not part of the historical run.
No other fixture opt-in or JVM behavior-changing flag is inherited. The final
manifest must capture actual argv, cwd, environment, start UTC/monotonic time,
PID/process creation identity and spawned-child ownership before waiting.
The primary candidate is the installed Windows JDK 17.0.7 whose java.exe,
release and lib/modules identities are recorded in INPUTS.json; no java.exe
invocation or native fixture runtime was run here. Installed javap was used only
as a static inspection tool. A later assignment must bind actual bytes/version output.
These sun.* properties are pinned-JDK mechanisms, not a portable Java guarantee.

The pinned SystemProps uses command properties and putIfAbsent for stdout/stderr
encoding; System.initPhase1 passes those values to newPrintStream. PrintStream
constructs an OutputStreamWriter. Thus these explicit UTF-8 properties supply a
primary-supported recipe, not evidence of a future transformed process. The
Windows default line.separator is required to be CRLF, with no property override;
its actual preflight settings must agree before launch. Parsing supports only the
explicit LF/CRLF grammar in section 7; a different separator is a recipe failure.
Reject duplicate encoding properties, charset providers, agents, stream replacement,
logger override properties and injection via all recursively expanded argfiles
or JAVA_TOOL_OPTIONS/JDK_JAVA_OPTIONS/_JAVA_OPTIONS. Record child locale/code page,
but do not use a console code page as stdout-encoding proof. Keep the exact pinned
fmlloader log4j2.xml routing bytes/configuration, with no silent logging changes.
The only trusted observation route is raw println: the patched Forge Bootstrap
boot method does not call its retained private wrapStreams method (Task 17).
Logged/wrapped/ANSI-adjusted fallbacks are unsupported.

Strict capture means original process bytes are retained without decoding,
replacement or newline normalization. Valid Java Unicode scalars become UTF-8;
paired surrogates encode as four bytes. Pinned StreamEncoder uses REPLACE and
CharsetEncoder's default replacement is ASCII '?' (0x3F), so an isolated Java
surrogate is replaced by the producer, not recoverable from stdout. This matches
the source BudgetWriter's one-byte isolated-surrogate/four-byte-pair accounting.
No parser can distinguish a legitimate '?' from that producer replacement;
original Java UTF-16 text fidelity is therefore not claimed. The later offline
qualification must check exact Gson escaping/stream encoding, including split
pairs, isolated surrogates, U+0000/U+2028, non-ASCII and supplementary characters.
No lossy decoder repair is allowed. JSON escaped lone surrogates are unsupported
and separately refused; this is not proof that the native Java producer rejected
all such input.

Freeze exact ASCII sorted server.properties bytes and eula bytes. The historical
recipe supplies loopback `127.0.0.1`, a newly allocated local port, offline mode,
secure-profile enforcement false, peaceful difficulty, survival, force-gamemode
false, max-players 2, view/simulation distance 2, spawn-protection 0,
sync-chunk-writes true, query/RCON/command-blocks false, normal world, seed 0,
generate-structures false and level-name world. Use a task-specific MOTD and
ownership marker. Record generated COMMON/server config values/hashes and final
properties readback; no silent extra bypass. Loopback binding is not permission
for a status/client connection in this observation-only contract.

Fixture registration is `@Mod.EventBusSubscriber(modid=AdapterTestMod.MOD_ID)`
and RegisterCommandsEvent registration is gated by
`Boolean.getBoolean("arce.sleepBoundaryObservation")`. The exact command is
`arce_sleep_boundary_observe`, with no arguments. Its source predicate requires
permission 4, null entity and `source.withSource(source.getServer()) == source`;
run additionally requires owning server thread, no INVOKING marker, empty
ordinary PlayerList and both absent UUIDs. NULL/RCON/entity sources do not qualify.
INVOKING.set is literally before withInvocation's try; Trace/Fixture creation
and action initialization are covered by that try, and its finally removes the
marker. Do not restate marker.set as physically inside the try. This opt-in launch
does not execute or prove default-disabled registration; separate standard tests
retain their original budgets.

## 4. Finite phases, storage reservation and failure states

Native ceilings remain 300/60/60/90 seconds; no standard test timeout, source
cap, reference-load budget or accepted failure assertion is changed. Task 20's
static commands separately have a 180-second ceiling.

| Future phase | Ceiling / maximum actions |
|---|---|
| Qualification/copy/reservation | 180 s total, including one <=30 s Java-version/settings check; finite hashing/copy/config/ownership/capacity receipts, no downloads. |
| Startup | 300 s to new trusted native Done marker in owned raw stdout; no retry. |
| Invocation 1 | One exact command; 60 s for the complete twenty synchronous rows and one bounded response. |
| Save 1 | One save-all flush; 60 s for new Saved-the-game marker after its cursor. |
| Post-save 1 | 60 s for bounded response inspection, two-file native save copies/projection/hashes and invocation-2 admission. |
| Invocation 2 | One identical command if admission succeeds; 60 s, never replacement evidence. |
| Save 2 | One new save-all flush; 60 s and independent copies. |
| Post-save 2 | 60 s for response/disk checks and comparisons. |
| Normal stop | One stop; 90 s for stopping/all-dimensions-saved ordering and actual native exit. |
| Reader completion | 5 s after exit, with actual EOF/write/flush status. |
| Retain/audit | 60 s for bounded final raw/config/hash/log findings. |
| Offline reparse | 60 s for independent frozen parser replay on retained bytes only. |
| External cleanup | 60 s; one separately authorized own-target attempt after all interests release. |

Native waits <=630 s =300+2*60+2*60+90. Complete success <=1115 s =
630+180+120+5+3*60. If a later assignment explicitly authorizes owned-process
forced exit, terminate <=15 s then kill <=15 s and reader <=5 s replace the
normal reader 5 s, so conservative failure <=1145 s. All waits use both phase
and one global monotonic deadline; no retry or deadline reset. UTF-8 qualification,
reservation, native-file monitoring and failure receipts consume these existing
phases, not new waits. No TCP/status/client phase exists. A timeout/failed normal
stop is not permission granted by this document to signal a process.

Invocation 2 requires complete first capture/schema, twenty actual primary
attempts, correlated control reachability, no unexpected setup/native/capture/
teardown failure and actual typed save 1. The exact reached row-19 intervention
is preserved rather than waived or automatically stopping the run; the root
HAS_FAILURE_OR_INCOMPLETE_CASE cannot decide admission by itself.

### Finite retained storage (bytes, not an unlimited external spool)

The former external-overflow promise is removed. These are proposed additional
driver limits, not native producer/source caps:

| Category | Admission threshold / immutable hard storage maximum |
|---|---|
| Merged stdout/stderr raw stream | 16 MiB accepted; 17 MiB retained prefix, including the 1 MiB shutdown reserve. |
| Native latest-log family | 16 MiB accepted; 17 MiB retained segments in native byte order. |
| Native debug-log family | 16 MiB accepted; 17 MiB retained segments in native byte order. |
| Compact inputs/helpers/config/receipts/results | 4 MiB combined; individual metadata receipt <=64 KiB; manifest <=4 MiB remains subordinate to this aggregate. |
| Four native compressed playerdata copies | <=1 MiB each, <=4 MiB total; no expanded NBT stored. |
| Two isolated response byte copies | <=512 KiB each, <=1 MiB total, with offset/hash backreferences into raw stdout. |
| Typed projections/segment indices/other compact evidence | <=1 MiB combined; no full-player JSON clone. |
| Reserved failure receipts | 1 MiB, separate from all preceding categories. |

Maximum new retained evidence =51+4+4+1+1+1 =62 MiB =65,011,712 bytes,
below both 100 MiB and a conservative decimal 100,000,000-byte slice maximum. Every file is below
50,000,000 bytes (largest 17 MiB). No overflow path, secondary volume, automatic
rotation/deletion or additional raw-file allocation may extend these budgets.
Hashes name actual retained extents, never falsely hash an absent complete file.
Copies that duplicate raw responses count twice; allocation counts all categories.

This lowers the previous proposed 24 MiB admission threshold to 16 MiB rather
than raising a source/runtime cap. It is a deliberate defensive capture-contract
change for independent review, not a native-log volume prediction.

Root's later coordination input reports 17 existing sleep ZIPs at Main6d totaling
5,677,163 compressed and 32,447,830 expanded bytes. This worker did not produce or
verify those later archives and does not substitute them for fixed309 governance.
Using expanded bytes conservatively, those inputs plus this 62 MiB future maximum
total 97,459,542 bytes, under 100 MiB and 100,000,000 bytes. Using compressed repository
files instead totals 70,688,875 bytes; never mix the two measures or double-count
an archive's logical expanded contents as another independent delivered set.
Task19 successors/reviews/regressions and later Task20 packaging are unproduced/
unqualified here. Before launch an actual slice-wide inventory must include their
real sizes plus every existing distinct retained evidence/helper/config set and
the proposed maximum, below 100 MiB (and this proposal's stricter 100,000,000 cap).
If that aggregate does not fit, block launch and request pre-run disposition;
do not assume future compression, raise caps, split one slice to evade the budget,
delete sealed inputs or move an unlimited spool outside the named evidence root.

Before launch physically allocate and verify the three 17 MiB sinks and the
1 MiB emergency area, plus available reserved capacity for the remaining 10 MiB.
Use no sparse-size-only reservation, symlink, compression assumption or a free-
space measurement as proof of reserved writable bytes. Verify positioned writes,
flush/readback and no overlapping roots/handles under the qualified filesystem
helper. Reservation failure is PRELAUNCH_CAPACITY_FAILURE; no server is launched.
Emergency area holds four fixed 64 KiB receipt slots, a <=512 KiB journal and
<=256 KiB header/index slack. It cannot be used for verbose logs. Pre-store source/
task/input hashes, budgets, process-not-started state and receipt format before
launch; bounded writes replace only an unsealed task-owned slot with sequence,
length and checksum. Never seek beyond allocated ranges. First-failure details
use one slot; save/stop/reader/final dispositions use the other three, with finite
status fields, not unbounded exception strings. Later sealed evidence remains
immutable; this slot protocol applies only to the live disposable assignment.

For a *total owned runtime storage* guarantee, independently qualify a separate
OS-enforced <=4 GiB writable runtime allocation containing copied libraries/mods,
native logs/world/config/temp, with no reparse ancestors and no access to source
or other tasks. Libraries/mods must occupy <=2 GiB and leave >=2 GiB available
at launch. The 62 MiB evidence/emergency reservation is outside that allocation.
Size polling alone is not a hard storage limit. The platform allocation/helper/
authorization is UNASSIGNED and must be reviewed before executable/runtime freeze;
Task 20 neither creates nor selects quota/mount infrastructure. If unavailable,
launch is blocked rather than claiming bounded total disk use. This proposed
limit constrains disposable output, not a native-world size or performance Gate.
Recheck C: and D: >=10 GiB after all allocation/copy and immediately before launch.

### Capture and I/O transitions

A later reviewed reader consumes merged raw pipe bytes in <=64 KiB chunks,
stores only acknowledged positioned-write bytes, and hashes each retained extent.
Only one current line buffer <=512 KiB+4096 bytes and finite prefix automata exist;
no self.lines list, decoded log clone, deferred unbounded queue or tail-only proof.
A bounded queue, if used, is <=4 chunks; queue overflow is CAPTURE_IO_FAILURE,
not dropping oldest/newest silently. Reader/write/flush failures immediately notify
the controller independently of marker waits, with <=250 ms controller polling;
this is an implementation responsiveness target needing actual qualification,
not a measured scheduling guarantee. A stuck reader or filesystem call fails at
the existing phase/global deadline; do not restart its deadline.

For native latest/debug families, retain every segment required by the unchanged
qualified logger profile, with file identity, sequence, original size and retained
offsets. At most 32 segments per family, aggregate 17 MiB each. A lost/replaced/
unaccounted rotation is CAPTURE_GAP even if the last filename is small. Monitor
finite size/identity changes during native phases; eventual copies are bounded.
Do not hash/copy an arbitrarily large native file after failure. The <=4 GiB
runtime allocation prevents unbounded temporary storage but does not promise
complete retained logs inside the smaller evidence allowance.

Crossing 16 MiB, candidate-line size, segment-count or any metadata admission
limit causes CAPTURE_BUDGET_FAILURE: no further fixture invocation, and no native
success/gameplay failure is inferred. Continue retaining shutdown bytes only up
to the fixed 17 MiB family maximum. At hard maximum stop writes to that sink;
explicitly record first unretained offset, successfully retained length/hash,
bytes obtained-but-unretained, and whether future length/EOF is unknown.
Continue pipe draining without retaining bytes only while total pipe bytes read
(including retained bytes) <=1 GiB and within the already running deadlines.
Reads use <=64 KiB; exceeding that fixed read-volume budget or failing a read is
CAPTURE_IO_FAILURE with incomplete/unknown tail. No discarded bytes become a
successful response, and discarded-tail counters/digests are not durable raw data.

ENOSPC, short write, flush/readback failure, access denial and handle/reader error
are CAPTURE_IO_FAILURE; preserve actual obtained/acknowledged/durable extents and
OS error separately. A flush failure makes durability unknown even if a write
returned. Reserved failure writes are attempted and independently flushed; if
they also fail, report EMERGENCY_RECEIPT_UNAVAILABLE through the coordination
channel if reachable, retain its session receipt and all still-readable evidence.
Reservation cannot guarantee continued storage through hardware/filesystem loss;
never fabricate a final on-disk receipt or claim complete bytes in that situation.

Any unexpected failure aborts future fixture commands without retry. The controller
attempts remaining already budgeted normal saves/stopping if owned stdin is usable:
at most two save commands total and one stop. A stdin write has actual cursor/time/
partial-write result; an incomplete write is not a successfully issued command.
For stdout/retention failure a save marker cannot be trusted from unretained bytes.
Normal actions may have happened, but save/exit qualification is INCOMPLETE.

Only a separate explicit runtime assignment can permit the 15/15/5 forced-stop
sequence for the exact started PID plus creation identity/owned descendants.
Forced exit is PROCESS_FORCED_STOP, never normal-save/durability/S2 or gameplay
evidence. Without that permission, failure to exit leaves OWNED_PROCESS_STILL_LIVE,
records the live ownership interest and forbids cleanup; the controller may finish
its bounded evidence/report work but must not claim the server stopped. This
proposal grants no process termination or cleanup permission.

## 5. Exact fixture inventory, preparation and twenty primary actions

Actors are SleepObsA (`3ec99863-f1a1-4ba6-8aaa-390209dbe2d0`) and SleepObsB
(`c5c1adf3-c2b4-4f57-8c98-576bfe5bbcf5`). Native PlayerList.placeNewPlayer owns
registration/playerdata loading; native remove owns logout save. Each actor owns
a Connection(SERVERBOUND) and open EmbeddedChannel; exact actor/Level/connection/
listener/UUID/native list identities are checked, not borrowed from clients.
Loaded Spawn is captured before resets. Actors must be new disposable Overworld
actors with empty inventory and not sleeping at acquisition.

Overworld chunk (0,0), WHITE_BED/EAST, MAIN_HAND, empty both hands. Head
(12,180,12), foot (11,180,12). **Exactly 12 captured/touched cells**:
head/foot, their below/above cells, (11,179,11)/(11,180,11)/(11,181,11), and
(10,179,12)/(10,180,12)/(10,181,12). Initial cells are loaded, BE-free, in bounds
and world border. Fixture getChunkAt is explicit preparation; native login/
teleport may load. This is not no-ticket/no-load proof. No region search.

Homes A (8,180,8), 23.75f/forced true and B (8,180,10), -17.5f/forced false are
declared reset inputs. Day/night uses 6000/18000, temporary doDaylightCycle and
doMobSpawning false. Each row normally wakes only actual sleepers, resets homes
with the public native setter, empties hands/sets survival, installs supports at
Y=179 and air clearance, places exact bed halves and sets time. Row 12 separately
seeds HEAD/6.25f/forced=true before its unforced primary setter.

A teleports to (11.5,180,11.5), except row 9 to (2.5,180,11.5); B to
(10.5,180,12.5), respective home yaws and pitch 0. Each preparation drain uses
the actual owned ClientboundPlayerPositionPacket ID with the public native
accept-teleport handler. This is explicitly simulated, not forged/wire/client
acknowledgement. Native alive, survival, empty hands, day/night, bed halves/
occupancy, mayInteract and canReach(target,1.5) are checked. Ordinary use hit is
Vec3.atCenterOf(target)+(0,-0.25,-0.5), face NORTH, inside false, MAIN_HAND,
sequence 1. Missing preconditions remain setup failure, never a direct-sleep
replacement.

| # | Exact name | Primary route / declared intervention (not native result) |
|---:|---|---|
| 1 | day_head_observer_off | Public handleUseItemOn, HEAD/day, observer off. |
| 2 | day_head_observer_on | Same declared HEAD/day inputs, observer on. |
| 3 | day_foot_observer_off | Public handler, FOOT/day, observer off. |
| 4 | day_foot_observer_on | Same declared FOOT/day inputs, observer on. |
| 5 | night_head_observer_off | Public handler, HEAD/night, observer off. |
| 6 | night_head_observer_on | Same declared HEAD/night inputs, observer on. |
| 7 | night_foot_observer_off | Public handler, FOOT/night, observer off. |
| 8 | night_foot_observer_on | Same declared FOOT/night inputs, observer on. |
| 9 | packet_range_refusal | Public handler HEAD/night; declared native out-of-range setup. |
| 10 | occupied_bed_refusal | Public handler HEAD/night; bed-state occupied=true, not a posed sleeper. |
| 11 | native_admin_forced | Public setRespawnPosition(OVERWORLD,HEAD,6.25f,true,false). |
| 12 | native_same_bed_tuple_unforced | Public same HEAD/6.25f forced=false setter after separately labeled forced seed. |
| 13 | native_null_reset | Public setter(OVERWORLD,null,0,false,false). |
| 14 | nested_native_admin_same_actor | Genuine handler-caused A spawn dispatch; one guarded nested A HEAD/41.5f/forced setter. |
| 15 | nested_native_admin_other_actor | Same outer route; guarded nested B setter. |
| 16 | nested_synthetic_bus_same_actor | Same genuine outer route; guarded synthetic A OVERWORLD/FOOT/forced event bus post, no native setter substitution. |
| 17 | nested_synthetic_bus_other_actor | Same outer route; guarded synthetic B event bus post. |
| 18 | direct_and_forwarded_callbacks | Same genuine outer route; direct callback with synthetic A FOOT/forced=true argument and Consumer-forwarded callback with B FOOT/forced=false argument; not bus posts. |
| 19 | one_shot_observer_failure | Ordinary public handler, separately armed one-shot observer exception; preserve reached/return/throw/partial effects. |
| 20 | independent_admin_after_failure_teardown | Separately registered observer and public forced administrative setter after row 19 teardown. |

ObserverEnabled is false only for rows 1/3/5/7, true for other *begun* rows.
DeclaredRoute is `public native setRespawnPosition` for 11/12/13/20, otherwise
`public native handleUseItemOn`. DeclaredControl is `observer off/on pair` for
1-8 and the exact row name for 9-20. Row 14-18 controls are registered only after
preparation; the source guard fires at most once when the outer event actor is A,
with nestedDepth=1 and an explicit outerEvent/controlReceiver/controlIndex record.
Control precedence/order is not inferred from a desired stack sequence.

Primary labels are `public_native_handleUseItemOn`,
`native_administrative_forced_setter`,
`native_forced_false_same_bed_tuple_setter`, or `native_null_reset` as mapped
above. Nested labels/contexts are `declared_nested_native_administrative_setter`,
`declared_synthetic_bus_post`, `declared_direct_callback_not_bus` and
`declared_forwarded_callback_not_bus`. Actual arrays preserve nested ordering:
an outer action appends in finally and can follow its nested action records.

## 6. Corrected source schema: exact keys, types and failure unions

This is a source schema proposal, not sample native output. The future parser
must make an explicit schema inventory from these exact fixed files; reject
unknown keys/format outside the bounded supported chat JSON union rather than
invent defaults. Incomplete/failure outputs are still retained and analyzed.

Primitive definitions: `token` is integer 1..512 for non-null identities;
source token(null)=0 is allowed only where a field actually denotes nullable
identity. Do not permit arbitrary zero for required owned actor/receiver/class.
`pos` is null or exactly three signed int32 coordinates; `vec` is exactly three
finite JSON numbers; angleBits/yawBits are signed int32 raw Float bits, not
floating conversion. JSON booleans are not integers. Time/counters use actual
integer fields, never numeric strings; timing uses nonnegative signed-int64
unless an actual unsupported measurement is null.

### Root and row

| Object | Required fields | Conditional fields / meaning |
|---|---|---|
| Root | format=`ARCE_SLEEP_BOUNDARY_OBSERVATION_1`; evidenceClass=`native-Java simulated transport`; traceStopped:boolean; cases:20-row array; lifecycle:array; outcome:string; eventCaptureAttempts:int 0..128; persistedEventRecords:int 0..128 | incomplete:string, present when incomplete(reason) first fires. No invocation ID or command return value exists in source output. |
| Row | number:1..20; name:exact table; status:string; preparation/actions/events/outputs/cleanup:arrays | observerEnabled:boolean and observerReceiver:token set by begin(); declaredRoute/declaredControl set by route(); incomplete:true set when the current row becomes incomplete. Unbegun rows do not get those fields. A begun row can still remain UNEXECUTED if failure occurs before the row try block. |

Status values actually assigned are UNEXECUTED, ACTION_RETURNED,
INTERVENTION_NOT_REACHED_OR_NATIVE_RETURNED, OBSERVER_INTERVENTION_FAILED and
SETUP_OR_NATIVE_ACTION_FAILED. UNEXECUTED initialization is not an attempt.
ACTION_RETURNED means the source action returned, not successful sleeping or
reached spawn setter. For 14-18, a returned primary action with no fired control
uses INTERVENTION_NOT_REACHED_OR_NATIVE_RETURNED. Row 19 returning rather than
throwing also uses that status. The OBSERVER_INTERVENTION_FAILED classifier
searches at most eight Throwable causes for the actual exception type, not just
message text.

Root outcome is exactly NATIVE_ACTIONS_RETURNED_NOT_A_GATE or
HAS_FAILURE_OR_INCOMPLETE_CASE. The latter includes the intended row-19 failure,
unexpected row failures, cleanup failure or trace incompleteness. Do not turn the
former into a Gate verdict or demand it when accepting retained intentional
intervention evidence. Count retained events by summing rows; it must equal
persistedEventRecords. eventCaptureAttempts counts successful reserveEvent()
reservations, including failed capture/unattached records; it can exceed retained
records and need not equal them. There is no emitted per-row attempt counter.

### Event, frames and native snapshot

An event record has exactly: event, eventClass, actor, level, spawnLevel,
newSpawn, forced, canceledAtObserver, declaredRoute, declaredControl,
declaredContext, nestedDepth, receiver, nativeAtCallback, frames,
capturePrefixDurationNanos, capturePrefixAllocatedBytes and measurementScope.
Identity fields are scoped tokens; eventClass/spawnLevel/route/control/context/
scope are strings; newSpawn is pos; forced/canceledAtObserver are booleans;
nestedDepth is 0 or 1. Do not infer event authority/cause from declared labels.

Frame union is either `{class:string,classToken:token,descriptor:string,member:string}`
or exactly `{overflow:true}`. At most 64 real frames and one sentinel, only last.
Retained class/descriptor/member are actual metadata, not a required bed stack
sequence or authenticated receiver. Frame descriptors/member spellings must be
bound to actual later reobfuscated artifacts, never copied as expected outcomes.

Normal snapshot has actors:array of owned actor entries. An entry has actor and
spawnGetterProjection; full snapshots additionally have native. Small snapshots
omit native and world. Full world (when level exists) has gameTime, dayTime,
isDay, head and foot. The native player object has exactly uuid, level, levelId,
connection, listener, connected, playerListIdentity, levelListIdentity,
listenerActorIdentity, pose, sleeping, sleepingPos, position, eye, yawBits,
mainEmpty, offEmpty, gameMode, mayInteractHead and reachHead. All identity/reach/
permission booleans are observations, not new privileges. Snapshot only emits
head reach/mayInteract, even for a FOOT-target row; separate source preconditions
validate actual target. Do not invent missing foot permission/packet-ID fields.

Bed snapshot has pos, state, loadedBlockToken, ordinaryWhiteBedIdentity and
receiverQualification=`loaded block identity is not a callback receiver proof`.
Spawn getter projection has dimension:string, position:pos, angleBits:int32,
forced:boolean, source=`native getters, not serialized player NBT`.
The safeSnapshot failure union is the Error object below, not an empty actors
snapshot; any such union is incomplete evidence. Acquisition can have fewer
bound actors and partial lifecycle, and must not be repaired to two.

### Actions, outputs and Error

Action record keys: label:string, declaredContext:string, nestedDepth:0|1,
before:Snapshot|Error, after:Snapshot|Error, outcome:`RETURNED`|`THREW`, plus
failure:Error only for THREW. Preparation=true actions go to preparation;
ordinary/nested actions go to actions. Actions with current=null go to lifecycle.
Do not require a stage key for those lifecycle action records.

System-chat output has actor:token, systemChat:native admitted component JSON,
overlay:boolean and phase=`fixture_preparation_before_public_ack` or
`post_action_case_teardown`. It does not represent a real client's received chat.
Unsupported/oversized native chat capture sets incompleteness; never replace it
with an empty successful response. Exact supported component structural union
must be pinned to the later qualified native serializer before parser freeze.

Error has type:string, message:string, causes:array and suppressed:array.
Each cause has type/message; suppressed entries are strings. Causes/suppressed
are at most eight each; messages/suppressed/first-incomplete reason are clipped
to 256 Java UTF-16 units. No stack trace field is emitted in this object. Native
eventbus raw-log stack traces remain separate evidence. The intentional type is
`io.github.sunthemoon.arceadaptertest.SleepBoundaryTrace$ObserverInterventionFailure`
and message is `declared one-shot observer failure intervention`; classification
requires the actual reached row/action/cause correlation, not message matching
alone. No successful native value is specified by this exception identity.

### Preparation/control, row cleanup and lifecycle record variants

Preparation includes fixture input declaration (kind, bed, facing, head, foot,
dayTime, initialHomeA/B, angleABits/angleBBits, forcedA/B, fixtureBlockFlags,
supportsAndClearanceCount), action records, ordinary packet declaration (route,
hand, target, hit, face, sequence), simulated-ack declaration (kind, actor,
actualOwnedOutboundId), control declaration (kind, outerEvent, controlReceiver,
controlIndex), synthetic completion (syntheticEvent, postReturnedCanceled),
forwarder declaration (forwarderIdentity, callbackReceiver), or caseFailure:Error.
`fixtureBlockFlags` is the actual integer UPDATE_CLIENTS|UPDATE_KNOWN_SHAPE;
supportsAndClearanceCount is the fixed ten non-bed cells. No field is a native
verdict just because it resides in preparation.

Row cleanup variant stage=unregister has kind=`control`|`observer` and either
ownedIdentity/outcome=`RETURNED`, or failure:Error. stage=outbound_drain has
failure:Error. stage=case_listener_and_trace_context_teardown has
observerRegistered/controlRegistered booleans and depthBeforeClear integer.
These booleans are local source ownership flags set before registration attempts,
not independently verified live eventbus membership. trace.end clears callback
state after the cleanup record. Failed unregister sets cleanupBlocked and leaves
later rows UNEXECUTED while final teardown still attempts retained listeners.

Lifecycle variants from acquire/close:

- qualification_limits: unexecuted/scope strings.
- declared_fixture_chunk_preparation: chunkX/chunkZ ints, beforeLoaded boolean,
  ticketQualification string.
- captured_initial_cell: pos/state; exactly twelve for complete acquisition.
- captured_world_preparation: gameTime/dayTime int64, doDaylightCycle/
  doMobSpawning booleans.
- native_placeNewPlayer: actor/connection/channel tokens and loading string.
- native_loaded_spawn and native_logout_save_input: actor token, uuid string,
  spawnGetterProjection; loaded entries occur before resets, logout input before
  native remove.
- fixture_acquisition_or_invocation_failed: failure:Error.
- Cleanup stage plus outcome=`RETURNED` or failure:Error: final_exact_owned_listener_unregister;
  owned_native_wake_<uuid>; owned_native_spawn_restore_<uuid>;
  native_remove_logout_save_<uuid>; own_channel_close_release_<uuid>;
  restore_cell_<BlockPos.toShortString()>; restore_owned_world_time;
  restore_doDaylightCycle; restore_doMobSpawning; verify_owned_world_time_and_rules.
- Current=null action records for teardown_native_owned_wake and
  teardown_fixture_restore_loaded_spawn use the Action union above, not stage.

Do not demand cleanup stages for an actor/cell/world never acquired. Complete
acquisition establishes the exact required teardown inventory; partial ownership
has a separately derived required inventory. Missing lifecycle entries after a
cap/failure are incomplete evidence, not implied completion.

## 7. Source caps, exact wire union and bounded offline parsing

### Unchanged source limits and source limitation

Case: 32 reserved events/128 KiB JSON. Invocation: 128 reserved events/512 KiB
JSON including lifecycle/final fields; 64 real frames plus one last sentinel;
512 identity tokens. Counter-only JsonWriter/BudgetWriter checks append bytes
before attachment, reserves 4096 invocation/512 case bytes, and preflights frame
metadata/descriptor <=1024 Java UTF-16 units before descriptor allocation.
Stopped gates reserveEvent, not every later append: later preparation/cleanup
can still exist. eventCaptureAttempts may exceed persisted records; persisted
count equals the sum of row events.

Source chat requires exact MutableComponent and Style, literal/translatable/EMPTY
contents, exact HoverEvent, component depth<=8 (root depth0), <=32 component
visits including repeated references, <=32 siblings/component, <=4 args,
per admitted text<=1024 UTF-16 units, escaped-text estimate<=8192. Chat reservation
is 4096+1024*visits+textEstimate before native JSON allocation, followed by actual
post-serialization byte checking. ResourceLocation namespace/path are checked
separately, so emitted combined font/type IDs may reach 2049 units. Drain
iterations<=512, packets<512, chats<=16/drain; four A/B drains allow <=64 output
records/row.

At fixed 5b the source does NOT require exact nested ClickEvent or
HoverEvent.EntityTooltipInfo before overridable access/serialization.
Task 17 establishes both subclassability and virtual EntityTooltipInfo.serialize.
Offline shape refusal cannot prevent that earlier serializer/getter allocation.
Task 19, including Root's later Addenda22/23, must independently qualify the missing
pre-call exact-receiver boundaries, including style font/corresponding resource
identifiers before their overridable getters/toString, and EntityType value
receivers before inverse-registry hashCode/equals dispatch. Root reports the
latter static finding from Task21; this worker has not executed that inspection
or a revised source. Identify actual new commit/artifacts/tests; no Task19
revision or successor outcome is assumed.
Universal pre-allocation/closed-union proof and executable launch remain blocked
on this dependency. Ordinary-native compatibility below is explicitly conditional.

Prefix duration/allocation includes verification, StackWalker, metadata/frame
work and measurement queries, but excludes native snapshot, event object,
append accounting and final output. Allocation is null if unsupported/not already
enabled; no measurement capability is globally enabled. These are not whole-
observer/MSPT/reference-load/production measurements.

### Primary-supported ordinary native chat JSON union

A systemChat root is a JSON object, never a primitive/array/null. Exactly one
content form: text:string (including EMPTY text:""), or translate:string with
optional fallback:string and optional nonempty with:array. with elements are
ComponentObject or string. Every admitted non-Component Java argument uses
String.valueOf and a String JsonPrimitive: null/Boolean/numbers are strings,
including "null", "true", "NaN"/"Infinity" where the native argument supplies them;
JSON null/boolean/number with entries are unsupported. This specifies type mapping,
not any actual chat text/result to be required.

Optional nonempty extra is an array of ComponentObject siblings. Style keys are
flattened: bold/italic/underlined/strikethrough/obfuscated:boolean and
color/insertion/font:string. clickEvent is exactly {action:string,value:string};
actions are open_url/open_file/run_command/suggest_command/change_page/
copy_to_clipboard, without importing the deserializer's allowed-server filter.
hoverEvent is exactly {action:"show_text",contents:ComponentObject} or
{action:"show_entity",contents:{type:string,id:string,name?:ComponentObject}}.
id uses canonical UUID spelling; type/font are combined ResourceLocations.
No hover legacy value, nested style, SHOW_ITEM/score/selector/keybind/NBT/custom
content or unknown/null style members are supported. Omitted fields are not
synthesized as null. Native color is a name or # plus uppercase hexadecimal;
fromRgb accepts signed int and does not prove an exact six-digit hex width.

Component object <=14 members; click/hover <=2 and entity contents <=3.
Source with<=4; component sibling visits under the global visit budget imply
extra<=31 for an ordinary component. Recount source component visits across
with/extra/hover recursion, not unique identities; depth0..8. Wire string bounds:
content/key/fallback/insertion/click value<=1024, combined font/type<=2049,
other native primitive argument strings<=4096 plus their supported mapping.
Do not apply the 1024 cap to a combined namespace:path.

Depth proof for ordinary receivers: trace/cases/row/outputs/output/component
container depth6. extra/with/show_text component edges add2; show_entity name
adds3. Eight edges place the deepest component at<=30, with final hover/entity
containers<=32 (scalar depth33). Global container depth64 therefore accommodates
this ordinary union, NOT arbitrary admitted subclasses at 5b. Task 17's <=25
value/container nodes per component visit gives <=800 per chat; that is a local
conservative bound, not proof of the whole-trace 65536 bound. Twenty rows*64
chats*800 =1,024,000 before trace byte admission; byte caps alone do not establish
a 65536-node limit. No unsupported subtype was exercised here.

### Precise additional parser limits and refusal semantics

Keep the proposed 65536 node and depth64 limits; do not enlarge them to fit an
observation. Define a JSON node as each object, array, or scalar VALUE, including
each null/boolean/string/number. Root is one; object member values and array
elements each count recursively. Member-name strings are NOT nodes: count them
separately, globally<=65536 names and <=64 names/object. Closing/opening punctuation
and whitespace are not nodes. Duplicate names compare decoded UTF-16 units,
before insertion, including escaped-name aliases; duplicates are refused.

Container depth counts root object as1 and each entered object/array adds1;
scalars do not add container depth, but their node count applies. Maximum generic
string/name <=4096 decoded UTF-16 units; source-specific 1024/256/2049 limits
override it at their exact fields. Count supplementary scalars as two units.
Reject malformed UTF-8, BOM at marker payload, unsupported escaped lone
surrogates, raw control characters, malformed escapes and trailing JSON data.
No Unicode normalization, errors=replace, re-encoding of retained original bytes
or key coercion. Separate source-size accounting may serialize a parsed row under
the exact qualified Gson policy without replacing its retained wire bytes. Require
strict JSON numbers with integer fields in their source ranges (booleans are
not ints), finite float-valued fields, and numeric lexemes<=64 ASCII bytes.
Angle/yaw bits remain signed int32, never float conversion. "NaN"/"Infinity"
are permitted only as native argument STRINGS, not nonfinite JSON numbers.

Other additional limits: lifecycle<=64; per-row preparation<=64/actions<=8/
cleanup<=16/outputs<=64; frames<=64 plus last-only singleton sentinel; row
events<=32 and invocation persisted/reserved counts<=128; exactly20 case slots.
Unknown keys/variants/types/format and wrong/missing/duplicate/reordered row
number/name are schema refusals. Nullable identity0 is only allowed where the
actual field denotes null; otherwise token1..512, scoped per invocation.
Response payload<=524288 original UTF-8 bytes excluding prefix/terminator.
Re-encoded row JSON <=131072 bytes under the pinned source Gson escaping policy;
do not equate an arbitrary pretty-print size to source accounting. The later
parser must qualify this exact accounting offline; inability to establish it is
a contract qualification failure, not a relaxed cap.

Check bytes/lexeme/string/depth/nodes/keys/collections during bounded tokenization
before allocating a general-purpose tree. No unchecked json.load-style eager
tree, recursive decompression, plugin or ambient mutable helper. One response
at a time; its parser allocation/RSS ceiling is 256 MiB, separate from Java Xmx2G
and needing independent worst-boundary offline qualification. No expanded log
tree or retained repeated AST is allowed. A violated resource/shape bound is
CAPTURE_STRUCTURAL_REFUSAL with exact field/offset/bound, retained original bytes
and separate execution/native state UNKNOWN or observed-before-refusal.

The 65536 whole-trace node cap, generic/string/collection limits and NBT stricter
wire policies are deliberately ADDITIONAL defensive admission limits. Full source-
valid compatibility is not claimed. A valid source-admitted ordinary trace may
be refused by the node cap; this is capture-contract failure, never native gameplay
failure, successful observation, or proof that source serialization was unsafe.
Before launch, independent review must accept this stated refusal scope or request
a new contract with pre-run evidence; no post-rejection budget/grammar widening.

### Raw framing, command correlation and offline analysis order

Byte grammar: ASCII ARCE_SLEEP_BOUNDARY_OBSERVATION, exactly one ASCII space,
one compact bounded JSON object, followed by LF or CRLF. Prefix must start at
byte-line offset0. The proposed Windows recipe emits CRLF; LF is an explicitly
supported structural terminator, not an alternative unreviewed launcher.
The compact payload admits no insignificant whitespace outside quoted strings,
including before/after the root object; no pretty-print normalization is applied.
No leading whitespace/logger/thread wrapper/ANSI strip, quoted/echoed marker,
bare CR, multiline reconstruction, second object or unterminated EOF candidate.
Gson escapes newline/control content; process interleaving or a torn print is a
capture failure rather than an invitation to repair/join bytes. Full raw bytes
are retained even when the one bounded candidate buffer refuses a line.

Scanner prefix automata check the observation and setup-failure spellings
anywhere in each byte stream, including non-start/quoted/oversized lines, without
retaining unlimited lines. Non-start/wrapped/stray/duplicate occurrences are
findings, not trusted responses. Only raw stdout of the exact owned process
and a recorded nonoverlapping command window can supply the one trusted object.
The window begins at the acknowledged raw byte cursor before the actual stdin
write and ends after the complete response; pre/post UTC/monotonic/write/line
cursors are recorded. Failed/partial write or preceding unread bytes prevents
trusted correlation. Final replay scans the entire retained stdout for strays,
not just accepted windows. Exactly one result/invocation and two overall are
required only for a complete two-invocation run; do not invent missing results.

ARCE_SLEEP_BOUNDARY_SETUP_FAILURE type= is unstructured failure evidence, not a
twenty-row substitute. The source clips message to256 UTF-16 units but it may
contain LF, and the prefix can also describe later serialization/finalization
failure. Preserve its raw extent and fail further invocation admission; neither
absence of acquisition nor successful teardown follows from this text.

After input/artifact/helper/config/ownership checks, apply framing and section6
schema. Verify event totals, scoped token roles/A-B UUID maps and identity
observations. Observer-off rows have no observed events, not proof of absent
native events. Require actual primary action/before/after/outcome for attempt
completeness; UNEXECUTED/setup failure is not counted. For rows14-18 analyze
actual guarded control declaration, outerEvent/controlReceiver/index and native/
synthetic/direct/forwarded action records; missing reachability stays a finding.
Do not require a predicted frame fingerprint or event/record order: outer
actions append in finally after nested records.

Row19 attribution requires actual reached intervention, exact exception class
SleepBoundaryTrace$ObserverInterventionFailure in its source-declared package,
eight-link classifier semantics and actual row/action/cause/window correlation;
message-only matching is insufficient. Raw eventbus diagnostics and partial
native effects remain visible. Root HAS_FAILURE_OR_INCOMPLETE_CASE and Brigadier
zero are not blanket failure or success. Row20 is analyzed independently; its
failure or missing attempt is never waived by row19. Unexpected native/setup/
snapshot/capture/cleanup errors remain separate findings.

For off/on pairs first compare declared prepared inputs, then actual native
projections, excluding tokens/timing/diagnostic sequence only. Preserve native
differences/equality/indeterminate reachability; equal early refusals do not prove
setter observation passivity. No sleeping/spawn/chat/pose/frame native result
is prefilled. Correlate all raw WARN/ERROR/FATAL, linkage/save warnings and
exceptions across complete stdout/latest/debug families. Narrow row19 attribution
does not suppress diagnostics or make a clean-log/Gate waiver.

Analyze fixture teardown, new flush markers/typed copies, stop/save/exit/reader
order separately. Replay only the frozen parser independently on retained bytes,
not a fixture import/native re-launch. Refused/incomplete outputs are still
reported without manufacturing schema objects, accepted rows or disk values.

Later offline qualification uses clearly labeled STRUCTURAL SYNTHETIC inputs,
not purported native success samples. Required mutations cover schema/count/
byte/type/event/frame/sentinel/token/depth/node/key/lexeme/UTF16 boundaries,
native string-valued primitive args and chat style/hover union, escaped-name
duplicates, malformed Unicode/line framing/torn/stray/stale/duplicate markers,
wrong wrappers, unexecuted/misnamed rows, missing/alias controls, row19 causes,
row20/cleanup/save/stop/exit failures, queue/IO/reservation/hard-prefix/reader
failure, drifted JAR/helper/config/path ownership and NBT cases below.
At-limit and one-over checks precede any native assignment; no test is run here.

## 8. Native save, typed NBT, modified UTF-8 and gzip

Snapshots are native getters, not NBT serialization. Close restores loaded
Spawn via the public native setter before native remove/logout save. Disk describes
teardown/logout state, NOT per-row bed behavior. Restoration itself is an
attributed fixture mutation. After each completed invocation and a new native
save-all flush marker, copy/hash only the two exact UUID playerdata files into
separate invocation evidence before invocation2 can replace them. Record copy
start/end, source identity/size and equality of bounded read/copy hashes; instability
or missing copy is incomplete. Never rewrite, coerce, manually load or synthesize NBT.

Limits retained from proposal02: compressed<=1 MiB/file; expanded<=4 MiB/file;
NBT container depth<=32; total tags/collection elements<=65536; each name/string
wire length<=65535 bytes. Retain compressed files and compact typed Spawn/UUID/
DataVersion projections only; expanded unrelated player fields are validated/
bounded-skipped without a full-player tree/JSON clone.

### Exact compressed-input policy

Supported native compressed input is exactly ONE gzip member, with the pinned
JDK GZIPOutputStream ten-byte header 1f 8b 08 00 00 00 00 00 00 ff. Task20's
installed static writeHeader bytecode establishes that header. Its separately
hashed mapped Forge NbtIo.writeCompressed constructs the ordinary GZIPOutputStream,
and PlayerDataStorage.save calls writeCompressed before safeReplaceFile and the
saving event; writeUnnamedTag emits the empty root name. This is static route
evidence, not a saved file/flush result. The actual future runtime SRG/transformed
save path and JDK/library identities must still bind this writer.
Other legal gzip header profiles (optional fields/FHCRC/FTEXT/mtime/OS variants),
concatenated members, padding or trailing bytes are UNSUPPORTED_COMPRESSED_WIRE
capture refusals, not a claim that gzip/native readers reject them.

Incremental raw-DEFLATE decoding uses <=64 KiB input/output chunks, no output
allocation beyond the 4 MiB expanded limit, and checks end-of-deflate.
Consume exactly the following 8-byte little-endian trailer: CRC32 equals all
actual expanded bytes; ISIZE equals actual expanded count (<=4 MiB, no wrap).
Require compressed EOF immediately after that trailer, and expanded EOF exactly
after one NBT root. Check unused/unconsumed input explicitly; never use a gzip
convenience reader that silently accepts subsequent members. Truncation, inflate
error/dictionary request, bad checksum/size, stalled no-progress decoder, byte/
deadline limit or missing full-consumption proof is a separate capture refusal.
No retry with another decoder/header profile or repaired file is allowed.

### Typed NBT grammar and counting

Root must be TAG_Compound (10), with its empty native name fully consumed. Tag IDs1..12
have standard bounded native payloads; TAG_End0 only terminates a compound or
declares an empty list element type. Nonempty list type must be1..12 and each
element's actual grammar is consumed without a repeated name/type header.
Lengths are signed int32 and must be nonnegative; reject an unknown type,
negative count, count*width arithmetic overflow, bytes beyond remaining expanded
input, or declared count beyond budget before allocation. Compound names are
decoded modified-UTF8 code units and duplicate names at any compound depth are
refused, including non-Spawn names. No native coercions or name normalization.

Counting: root is one tag; each named tag and each list element is one tag,
including nested lists/compounds. Every byte/int/long-array element additionally
counts one collection element; a list element is counted once as its tag, not
again solely because it is in a list. Every TAG_End terminator counts one unit
toward the same <=65536 total to bound empty-compound streams. Named field strings
and names do not add tag units but all their bytes count toward4 MiB. Root
compound has container depth1; each nested compound/list adds1, with depth<=32.
All scalar/list/array payloads, including unrelated skipped ones, are consumed.
Float/Double payloads must be finite; preserve raw Float SpawnAngle bits, including
signed zero. No reinterpretation of Byte/Int/Float tag type as another type.

Mandatory compact projection: native root UUID is Int_Array type11 with exactly
four signed int32 words matching each actual fixed actor UUID; DataVersion is
positive Int type3. SpawnX/Y/Z are exact Int type3; SpawnForced exact Byte type1
with value0/1; SpawnAngle exact Float type5 with retained raw bits;
SpawnDimension exact String type8 and a valid qualified dimension ResourceLocation.
Record every tag's actual presence/type/value; no assumed DataVersion value,
getter equality, absence, flush, save or durable exit is prefilled.

### Canonical Java modified UTF-8 (not stdout UTF-8)

DataOutput.writeUTF writes an unsigned big-endian16-bit byte length and encoded
Java UTF-16 units. The same policy applies to EVERY tag name and StringTag,
including skipped unrelated strings; declared byte lengths are checked before
decoding/allocation. Decode exactly that many bytes, preserving code units:
- U+0001..U+007F use one byte01..7f.
- U+0000 is exactly c0 80, not raw00.
- U+0080..U+07FF use canonical two-byte encodings.
- U+0800..U+FFFF use canonical three-byte encodings, INCLUDING surrogate units.
- A supplementary character is a high/low surrogate pair encoded as SIX bytes.
  Isolated surrogate units are legal Java writeUTF output; preserve/skip them as
  UTF-16 units without replacing or applying a scalar-only UTF-8 decoder.

Refuse invalid continuation/truncation, raw00, overlong encodings other than
c0 80 for NUL, four-byte standard-UTF8 forms and bytes outside these canonical
forms. DataInput.readUTF may accept some noncanonical forms; this stricter offline
policy is explicitly an additional capture refusal, NOT native-load rejection.
Duplicate compound names compare the preserved UTF-16 sequence. Projected UUID/
Spawn names and ResourceLocation dimension are ASCII-valid native spellings;
unpaired units cannot become a fabricated dimension string. Unrelated canonical
strings may contain NUL/surrogates and are bounded-skipped, never re-encoded as
ordinary UTF-8 to decide their validity or length.

Pinned DataOutputStream.writeUTF bytecode and native StringTag.write (Task17)
establish the encoding/65535 form. The Forge StringTag writer catches an overlong
UTFDataFormatException and writes an empty string with a log finding; a successfully
decoded empty string does not prove preservation of an oversized original value.

### Native save/load/default comparison boundary

Task17's qualified native codec chain establishes SpawnDimension StringTag8:
ResourceLocation.CODEC = Codec.STRING with read/toString; Codec.STRING calls
DynamicOps.createString; NbtOps creates StringTag. The same Level resource-key
codec is used on load. Actual disk presence/codec result is still unexecuted.
Non-null respawnPosition saves all six Spawn tags in that branch; null position
skips them. Native codec failure or incomplete tag set is not reconstructed.

Native load accepts coordinate numeric tags using contains(name,99), then getter
coercions for int/boolean/float and optional dimension decode/fallback. This exact-
type offline parser is stricter and does NOT assert native load rejects everything
it refuses. Partial/mistyped/coerced Spawn sets remain findings outside fresh-scope
typed-save success. For the fresh constructor only, a completely absent Spawn set
maps to minecraft:overworld/null/raw angle0/forcedfalse. Present valid six-tag sets
preserve actual values/types/raw angle. A null-position getter with nondefault
dimension/angle/forced loses those ancillary values on save: report non-equivalence,
not successful preservation or a migration policy.

Compare actual disk projection to preceding native_logout_save_input and actual
loaded-restoration getter evidence. Invocation2 native_loaded_spawn precedes resets
and may be compared with save1. This is same-process logout/UUID reacquisition,
not restart/death/per-case persistence or online-first-save-at-stop durability.
Even on refusal/comparison failure retain bounded actual files/hashes/projections.

Future structural offline NBT qualification covers canonical NUL/ASCII/BMP/
supplementary/isolated-surrogate strings, exact65535 and one-over/truncated length,
all name/skipped-string rules, malformed/noncanonical/four-byte UTF8,
gzip header/member/trailer/CRC/ISIZE/full-consumption/decompression limits,
typed UUID/DataVersion/Spawn/raw angle/default/partial/coercion/duplicate/list/
array/depth/tag-unit/negative-length/overflow cases. No NBT parser/test or native
playerdata operation is executed in Task20.

## 9. Synchronous fixture teardown and external cleanup

Source-owned listener unregister attempts use exact object identity, not global
bus clearing. Every row tries control then observer unregister, attempts each
actor drain and records context teardown before trace.end. Failed unregister
blocks later rows; close still attempts every retained listener independently.
Flags/receipts show attempted operations, not exhaustive heap/listener proof.

Close independently attempts: exact retained listeners; trace.end; actual-owned
sleepers' native wake; public native loaded-Spawn restoration and getter checks;
owned native remove/logout save with no removal of an unowned UUID occupant;
owned channel finishAndReleaseAll plus not-open/disconnected check; each captured
cell restore with state-identity/BE-free check; day time/brightness and both
gamerules restoration; final dayTime/gameTime/rule check. Boolean `&=` keeps later
attempts running despite another cleanup failure. Partial acquisition including
native Level registration retains actor/channel ownership. Marker release covers
Trace/Fixture construction failure; trace.clear ends per-invocation retained
tokens/metadata/references after output attempt.

The second invocation can narrowly test reacquisition/command continuation after
the first's synchronous cleanup, and row 20 can observe later administrative use
after row 19's one-shot teardown. Neither repetition nor source finally review
proves exhaustive listener/heap release, concurrency, invisible global effects,
receiver authenticity, transport, JIT/warm/cold coverage or production safety.

External cleanup is separately authorized, not this planning worker's action.
Only a later driver's absent-then-created `_tmp` runtime/world/copied-library
and owned parser-test scratch paths listed in its manifest may be targets. No
source worktrees/build/cache/input worlds/other agents' outputs or sealed evidence
are transferred as deletion targets. Root/independent readers must release their
interests and offline replay finish first.

Use one native PowerShell attempt: resolve exact absolute literal targets under
that task's explicit temporary root; check all existing target/ancestor members
for reparse points; count files/bytes; verify exact owned process exit and no live
reader/process/reference interests; emit pre-delete receipts; Remove-Item with
LiteralPath; record remaining paths/result independently. A policy denial or
failed check retains targets and is never retried through another shell or new
computed target. Preserve compact raw logs/results/native two-file copies before
deletion. TASK-20 creates no temporary runtime cleanup target.

## 10. Remaining prerequisites and acceptance boundary

This static revision incorporates primary-supported raw routing, ordinary chat
union/depth/string-valued primitive args and SpawnDimension type. It proposes a
new explicit UTF-8 recipe, finite reservation/storage/failure policy, defined
node/key accounting and native modifiedUTF8/single-member gzip policies.
These are specifications for independent review, not implemented/qualified closure.

Before executable/parser/runtime freeze, independently resolve:
- Task19/Addenda22/23's pre-call nested/resource-identifier/EntityType registry-value
  receiver boundaries, actual new source identity,
  compilation/boundary tests and coherent build/API/consumer/reobfuscation/artifact
  qualification. Fixed5b remains the historical inspected source; no retrofit.
- The actual committed driver/parser/helpers/offline tests and publication;
  independent mutation/resource/IO/reservation/Unicode/argv/logger/ownership reruns.
  Source method existence, source-review hashes and Tasks11/12 regressions do not
  qualify this implementation.
- Actual pinned JDK/Forge/Gson/logger/library bytes, expanded arguments/configuration,
  process UTF-8 route and CRLF settings, native NbtIo/GZIPOutputStream writer path,
  and exact source accounting. The historical lossy ASCII marker is not Unicode
  proof. Pinned sun.* behavior is not assumed portable or effective after an
  unreviewed transformation.
- Independent disposition of deliberately stricter parser/refusal scope, finite
  retained-prefix policy, platform-enforced <=4 GiB disposable-storage allocation,
  emergency-slot/reservation and bounded stuck-I/O handling. No platform helper,
  administrative quota/mount authority or future forced-stop/cleanup permission
  is assigned here. Failure of a prerequisite blocks launch.
- A separate explicit bounded native assignment after those qualifications,
  including process/cleanup permissions and actual input manifest. No discovery
  launch, scope expansion or automatic retry follows from this document.

Unsupported inputs remain raw logger/wrapper/ANSI/echo/unterminated/multiline
response variants; malformed Unicode/JSON/unknown schema; non-ordinary/custom
chat receivers/content, JSON primitive with args, legacy hover/style/item/NBT;
extra strict node/collection/string/resource refusals; noncanonical modifiedUTF8,
unqualified gzip header profiles/multiple members/trailing data, partial/coerced
typed Spawn, prior-world/default/restart/death migrations. These are capture/
qualification exclusions, not invented native gameplay defects or success.

All normal/current-version test budgets and assertions remain unchanged:
clean build, test, runData plus empty generated diff, and unfiltered GameTest are
separate work. Task20 runs none. All native twenty-row/two-invocation/effect/
teardown/save/exit/actual byte outcomes are UNEXECUTED/UNKNOWN here.

B1 cause/indeterminate/coexistence; R1 argument/receiver authenticity; M1 neutral
occupancy/air transition; M2 gap/station-only/live-access policy; D1 separate exact
dimension/spawn/time contract/qualification; production failure ADR/risk; real
clients/TCP/GPU/multiplayer/performance/mod/monster/item/host/provenance and full
Q01-Q18/S01-S21/R01-R02/item/ledger/asset acceptance remain open. The owner's
conditional ancillary choice remains accurately scoped, not production authority.
Current v1.8 G0-G9 and inherited Required Gates are NOT all satisfied.
Root can request independent review/disposition within current v1.8; a proposal
seal/full read is not executable acceptance, runtime permission or a Gate PASS.

