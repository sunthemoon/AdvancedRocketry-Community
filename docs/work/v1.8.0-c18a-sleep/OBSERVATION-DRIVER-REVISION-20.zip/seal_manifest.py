"""One-time safe leaf-relative static evidence manifest; no runtime work."""
from pathlib import Path
import hashlib
import json
import stat

root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
result_path = root / "SEAL-RESULT.json"
if manifest.exists() or result_path.exists():
    raise FileExistsError("One-time seal already exists")

def safe(path):
    info = path.stat(follow_symlinks=False)
    if path.is_symlink() or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise ValueError("Unsafe reparse/symlink: " + str(path))
    return info

for ancestor in [root, *root.parents]:
    safe(ancestor)
members = []
for path in sorted(root.rglob("*")):
    info = safe(path)
    if path.is_dir():
        continue
    if not stat.S_ISREG(info.st_mode) or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Unsafe/nonregular evidence: " + str(path))
    data = path.read_bytes()
    members.append({"relative": path.relative_to(root).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

required = {
    "REPORT.md": "06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6",
    "PROPOSED-DRIVER-03.md": "c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680",
}
indexed = {item["relative"]: item for item in members}
for name, digest in required.items():
    if indexed[name]["sha256"] != digest:
        raise ValueError("Root-read document drift: " + name)
text = "".join(item["sha256"] + "  " + item["relative"] + "\n" for item in members)
with manifest.open("xb") as stream:
    stream.write(text.encode("utf-8"))

for item in members:
    data = (root / item["relative"]).read_bytes()
    if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise ValueError("Post-seal member drift: " + item["relative"])
data = manifest.read_bytes()
print(json.dumps({"covered_count": len(members), "covered_bytes": sum(item["bytes"] for item in members), "all_covered_match": True, "manifest_bytes": len(data), "manifest_sha256": hashlib.sha256(data).hexdigest(), "documents": [indexed[name] for name in required], "excluded": ["SHA256SUMS.txt", "SEAL-RESULT.json"]}, indent=2))
