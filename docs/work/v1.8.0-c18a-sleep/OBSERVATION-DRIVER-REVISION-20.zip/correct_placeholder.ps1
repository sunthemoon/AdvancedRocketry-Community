$ErrorActionPreference = 'Stop'
$target = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\LATER-INPUTS-INVALID-PLACEHOLDER.md'
$expected = '87491e3764bcb18ecbf1845ad6e50942911383694c33dd40a18a24c707d8698a'
$resolved = (Resolve-Path -LiteralPath $target -ErrorAction Stop).ProviderPath
if (-not [string]::Equals($resolved, $target, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Resolved target identity changed; no removal attempted.'
}
$item = Get-Item -LiteralPath $target -Force -ErrorAction Stop
if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) -or $item.Length -ne 37) {
    throw 'Target is not the authorized regular non-reparse 37-byte file.'
}
$actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'Target hash changed; no removal attempted.' }
[pscustomobject]@{ phase = 'pre-remove'; literal = $target; resolved = $resolved; bytes = $item.Length; sha256 = $actual; regularNonReparse = $true } | ConvertTo-Json -Compress
Remove-Item -LiteralPath $target -ErrorAction Stop
$remaining = Test-Path -LiteralPath $target
[pscustomobject]@{ phase = 'post-remove'; literal = $target; remains = $remaining; outcome = 'single-authorized-literal-file-correction' } | ConvertTo-Json -Compress
if ($remaining) { throw 'Authorized removal did not produce absence; no retry permitted.' }
