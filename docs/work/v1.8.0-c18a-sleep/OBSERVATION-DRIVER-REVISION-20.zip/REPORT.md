# Sleep observation driver/parser contract revision 20

Date: 2026-10-09. Delegated static contract worker, not Root. Status:
**PROPOSED / STATIC ONLY / NOT EXECUTABLE-FROZEN OR ACCEPTED**.

## Findings and proposed dispositions

1. **Task16-R01 receives an explicit proposed encoding/framing recipe, not an
   executed qualification.** Proposal03 adds file.encoding/sun.stdout.encoding/
   sun.stderr.encoding=UTF-8 to the future pinned Windows Java17 argv; prohibits
   duplicate/injected properties, agents/providers/stream replacement and logger
   overrides; requires Windows CRLF settings and accepts only the stated raw
   LF/CRLF byte grammar. Task17's patched Forge Bootstrap does not call its retained
   wrapper. Additional installed SystemProps/System/PrintStream/StreamEncoder/
   CharsetEncoder/UTF8 bytecode supports property precedence and native encoding.
   Isolated UTF16 surrogate replacement by the producer is explicitly ASCII '?',
   distinct from forbidden decoder repair. Original Java text fidelity is not
   inferred from retained UTF8; historical lossy ASCII output is not Unicode proof.
   Actual coherent artifacts, argv/encoder/Gson/logger offline qualification and
   future owned-process byte/routing evidence remain prerequisites. R01 is not
   independently closed by this document.
2. **Task16-R02 receives finite hard limits and explicit incomplete-capture
   outcomes.** The former unlimited external spool is removed. Three raw families
   each have 16 MiB admission/17 MiB hard retention, including 1 MiB shutdown reserve;
   compact evidence 10 MiB plus reserved failure receipts 1 MiB give 62 MiB maximum.
   Emergency slots are physically reserved/verified before launch. Queue/read/
   write/flush/ENOSPC/rotation/hard-prefix failures retain actual extents and separate
   durability/unknown-tail states. Pipe read volume<=1 GiB and existing deadlines
   bound discard draining; no discarded bytes count as a successful response.
   A separately qualified OS-enforced<=4 GiB runtime allocation would bound native
   temporary world/logs/libraries, while the smaller retained-evidence cap remains
   independent. Size polling is not that hard proof. The allocation/helper/platform
   authority and stuck-I/O qualification are unassigned and block launch if absent.
   Neither this task nor Root's coordination update approves quota infrastructure,
   process termination or runtime. R02 is a proposed disposition awaiting review.
3. **The entire slice budget is explicit, without future volume guesses.** Root's
   later supplied 17-archive totals are 5,677,163 compressed/32,447,830 expanded bytes.
   Conservatively combining expanded bytes with 62 MiB gives 97,459,542 bytes, below
   100 MiB and the proposed stricter decimal 100,000,000 cap. Compressed repository
   measure instead gives 70,688,875 bytes. This worker did not create/verify those
   later archives. Future Task19/review/regression/Task20 packaging volumes remain
   unknown, and the actual distinct slice-wide inventory must fit before launch.
   The new16 MiB threshold is explicitly lower than proposal02's24 MiB; no source
   cap or standard timeout is raised. Temporary allocation is not evidence-budget
   approval or a promise that every native temporary byte can be archived.
4. **Task17's ordinary chat union/depth is used precisely; global node closure
   is not invented.** Native non-Component translation args are JSON strings,
   including Java null/numbers/booleans. Style is flattened; click and SHOW_TEXT/
   SHOW_ENTITY have exact ordinary wire unions. Combined font/type IDs may reach
   2049 UTF16 units and color need not be six hex digits. Ordinary container depth
   <=32 fits64. JSON nodes now explicitly count values/containers, excluding member
   names, which receive separate global/per-object bounds; strings count UTF16 units.
   The65536 whole-trace cap is preserved as deliberately stricter defensive refusal,
   NOT claimed compatible with every source-valid trace. Local800-node/chat and
   analytical1,024,000 pre-byte-bound whole-trace envelope are distinguished.
   Refusal is CAPTURE_STRUCTURAL_REFUSAL, not native gameplay failure/success.
5. **Nested receiver/source qualification remains unresolved.** Fixed5b lacks
   exact nested ClickEvent/EntityTooltipInfo pre-call checks. Root separately
   assigns Task19/Addenda22/23 for those receivers, font/corresponding resource
   identifiers and EntityType values before inverse-registry hashCode/equals.
   Later supplied Task21 facts and addendum permissions are recorded as later
   coordination inputs, not inspections/tests executed by Task20. No first revision,
   successor commit, compile/test or independent review result is assumed. An
   offline parser cannot protect an earlier native getter/serializer allocation;
   fixed5b is not made launch-ready by accepting ordinary JSON shapes.
6. **Task16-R03 receives canonical native-string and complete gzip/NBT policies.**
   Tag names and all StringTags, including bounded-skipped fields, use Java modified
   UTF8: NUL=c080, supplementary characters=six encoded surrogate bytes, isolated
   surrogate units are preserved rather than treated as scalar UTF8. Noncanonical
   forms are additional parser refusals, not native-load rejection claims. One
   member with the pinned JDK header, raw-deflate completion, CRC32/ISIZE, exact
   trailer/compressed EOF and exact expanded NBT consumption are specified. Native
   typed Spawn/default semantics follow Task17. Additional public mapped NbtIo/
   PlayerDataStorage bytecode binds ordinary GZIPOutputStream/save/empty-root-name
   routes statically, not disk/flush behavior. Actual runtime route/helper mutation
   tests and saved inputs remain unexecuted. R03 is not independently closed.
7. **Intervention, native effects and persistence remain separate.** Exact reached
   row19 cause/action/window correlation is required; root failure/Brigadier zero
   is not a broad waiver or success. Row20, raw errors, teardown and capture failures
   remain independent. Getter snapshots are not serialized NBT; restored loaded
   Spawn before native logout save is compared to actual disk copies, not per-row
   home/spawn assumptions. Same-process second UUID acquisition is not restart,
   death, per-action durability or production receiver/cause proof.

No finding here is asserted to be an observed native gameplay defect. No native
sleep/spawn/pose/frame/chat/equality/control or save verdict is prefilled.

## Complete proposal, scope and unchanged limits

[PROPOSED-DRIVER-03.md](PROPOSED-DRIVER-03.md) is self-contained: exact source
authority/non-goals, actual future input/packaging ownership requirements, launch/
charset recipe, deadlines/capacity/failure states, twenty named routes and two-
actor/twelve-cell preparation, full source schema/status/error/lifecycle unions,
source caps/measurement exclusions, ordinary chat union, bounded structural
counting/refusals/raw framing/offline correlation, typed modifiedUTF8/gzip/NBT,
getter/logout/disk/reacquisition boundaries, fixture/external cleanup and remaining
prerequisites. It is documentation, not driver/parser/test implementation.

Fixed source remains5b45132000ade1e3c8d130a6b8ccb29f07535124, base
b9bec789978de0df67c93e976239d6d36e41532b. Fixed governance is
30944465a6e07215990182fb0dd935e65303e27a. Tasks15/16/17 sealed histories remain
unchanged; later Root inputs are distinguished in CONSTRAINT-UPDATES.md. The task
uses no moving Main as a source/governance qualification and holds no HEAD/process
interest. Source events 32/case and 128/invocation, bytes 128 KiB/case and 512 KiB/invocation,
frames 64+sentinel and identities 512 remain unchanged. Native waits 630 s, proposed
whole success 1115 s/conservative forced failure 1145 s are preserved. Added
qualification/reservation/refusal work consumes existing phases. Time is not
volume/performance evidence.

Mandatory supplied AGENTS and fixed governance were read: PROJECT-CONFIG,
PRODUCT, porting principles, roadmap, active uppercase v1.8 version, master tests,
release gates, post-v1.0 roadmap/budgets/parallel rules, ADR060, status/owner03 and
the earliest incomplete v1.0 version. ADR060 permits v1.8 development separately
from inherited acceptance; neither it nor the owner's conditional native ancillary
choice expands this one-fresh-process/two-console-invocation observation-only scope.
No TCP/client/restart/death/prior-world/custom-bed/mod/monster/item/off-world
dimension/spawn/time/air/enforcement/migration/global-night-skip work is assigned.

## Actual fixed input integrity

commands/24 and INPUTS.json record actual leaf-relative verification:

| Input | REPORT SHA256 | Manifest SHA256 | Covered files matched |
|---|---|---|---:|
| Task15 | d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277 | 6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760 |148|
| Task16 | 7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3 | 2aa9ee0dad7fce9a509b9c7b70ae3021f5f4e898138e42c8fee3de099d45b105 |157|
| Task17 | fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108 | 430acfcab917021c5fb1de7b44ae3a13306db723af13df631573bc0e95316d16 |251|

All 556 covered files match. Complete sealed proposal15 is 46009 bytes/SHA256
628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec.
Complete15 proposal/report,16 REPORT,17 REPORT and their task permissions were
read; focused primary findings followed. No original record was edited.

Task20 permission text is 2571 bytes/SHA256
b9bdf35ed22e96e00c7facd7b0835e39cd8f8f0d9d307d7d63ea7c39e5636157.
Raw fixed Git source identities are Fixture33987 bytes/
1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 and
Trace31470 bytes/39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0.
They agree with the sealed input cohort; no subsequent Task19 source is substituted.
Actual installed JDK java.exe54416 bytes/
308e8c921fd9d152ad526e5f0988682e8f96792a6313f185fa6b20db671a791f,
javap23696 bytes/69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d,
lib/modules125493164 bytes/
1fa387443737a2b511de1a7f76a50a16404be4a8947ab5d40e5861a4bad89d72 were
hashed, not copied or executed as a Java runtime. Installed mapped Forge19355242
bytes/95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e
was independently rehashed. PRIMARY-IDENTITIES.json records unique CRC-validated
NbtIo/PlayerDataStorage selected entry hashes; no whole primary library is retained.

These are static inspection identities, not a later artifact/runtime manifest.
Inherited Tasks11/12 regression counts/build/API/artifact results, strict180 s
TIMEOUT, unwaived native errors and independent retention limits remain as their
historical reports describe. This task does not rerun or rebind them.

## Commands actually run and preparation failures

Each captured inspection has commands/<name>.json with actual pre-start UTC,
argv/cwd/end/exit/duration/180 s ceiling and unmodified separate stdout/stderr.
Only Python -B compact evidence/read/hash/ZIP operations, read-only Git/rg and
installed javap static inspection were run. Complete raw source/proposal/reports,
permissions/governance, manifest/hash and primary-bytecode reads are retained.
The final PRESEAL-VERIFICATION.json provides the definitive actual command index;
its own later receipt/streams are sealed but are not falsely self-indexed.

Static inspections completed without subprocess failure or timeout. The separate
authorized correction attempt 39 failed exit 1 before its script could execute.
Successful inspection exits do not erase these preparation/transport problems:
- Command21 intended UTF_8$Encoder but double-quoted PowerShell expanded $Encoder;
  actual argv inspected UTF_8. Its StreamEncoder output remains valid static input.
  Command22 single-quoted the exact nested class and succeeded. Command21 is not
  represented as the intended nested-class inspection.
- Three apply_patch attempts failed context verification before editing; their raw
  tool errors are session-only and not reconstructed as subprocess receipts.
- One mistaken apply_patch created an out-of-scope one-sentence placeholder at
  D:/GitHub/ARCE-Task-Evidence/v1.8.0/LATER-INPUTS-INVALID-PLACEHOLDER.md. Root was
  immediately notified. Root's Correction24 authorized one exact native nonrecursive
  literal-file removal after preserving bytes/permission and rechecking identity.
  Those exact bytes/hash and permission are retained as INCIDENT-ORIGINAL.txt and
  CORRECTION-PERMISSION-24.md; command38 verifies both supplied identities. The one
  command39 PowerShell -File attempt failed exit1/UnauthorizedAccess because script
  execution is disabled, before its identity checks or Remove-Item ran. No retry,
  bypass, alternate invocation or transfer to Root cleanup occurred. Per Root's
  subsequent explicit stop instruction the 37-byte original remains at that external
  location; this scope incident is UNRESOLVED/NOT CLEANED. It is not a source/runtime
  change or sealed-input mutation. The mutable external file is NOT a manifest
  covered item; its exact preserved leaf copy and actual failure receipts are.
- Initial task reading preceded the capture helper and is transcript-only; the
  full task was subsequently reread/hash-recorded. Broad displayed reads sometimes
  exceeded tool display limits; complete raw streams were captured and relied-on
  sections reread in focused complete displays. Display truncation is not passed
  off as complete inspection or an executed observation.
- All original Tasks15/16/17 preparation failures and their evidence gaps remain
  in their immutable REPORTs. No old failure was overwritten or reclassified.

No Java execution/discovery, compilation, tests/GameTest/Gradle, parser/driver,
server/world/playerdata runtime, network/download/install/library copy, process
termination, runtime cleanup, worktree/HEAD/index change, commit/push or delegation was
performed by this task. Current-version Gradle/test commands are UNEXECUTED here
under explicit static-task permissions, not PASS or NOT_APPLICABLE. The sole
additional Correction24 literal-file cleanup was attempted but did not execute;
it is not represented as an allowed static inspection or completed cleanup despite
the capture helper's generic static-inspection-not-runtime label.

## Completion, modifications, risks and Gate boundary

Completed scope: fixed governance/source/complete contract-review-primary reads;
actual 556-file seal/input hashes; extra installed JDK/native-save route primary
inspection; proposed complete revised driver/parser/encoding/count/storage/failure/
NBT contract; compact raw evidence and this report. Intended modifications are
exclusively this evidence leaf's Markdown/helpers/JSON/command streams, followed
only after Root full read by one-time leaf-relative sealing. The explicitly
reported placeholder incident is the sole known exception: Root disposition keeps
the original 37-byte external file after the policy-denied corrective attempt.

Uncompleted: independent proposal disposition, source19/Addenda22/23 qualification,
actual coherent artifacts, committed driver/parser/tests/helpers and independent
offline mutation/resource/I/O/Unicode/ownership reruns, platform storage allocation/
reservation/termination/cleanup authority, any native twenty-row/two-invocation/
teardown/save/exit/typed-disk/reacquisition outcome, and broader item/acceptance work.
No tests are added, modified or executed. No production/API/save/network/assets/
provenance policy or ledger/Gate conclusion is changed.

Key design decisions: original source/runtime ceilings retained; explicit encoding
properties for review; ordinary wire facts separated from universal admission;
defined unchanged node cap with honest source-valid defensive refusal; bounded
retained prefixes/emergency receipts plus distinct temporary-output hard allocation;
canonical native modifiedUTF8 and exact single-member/header/trailer consumption;
actual later input/volume qualification rather than historical/future hashes.

Known risks include unqualified source receiver/registry dispatch, additional
defensive refusal of otherwise native-valid data, producer surrogate replacement,
limited shutdown retention, OS allocation/helper/authority feasibility and residual
hardware/filesystem loss, unknown successor evidence volume and all runtime/native
behavior/persistence boundaries. The write-scope incident is separately visible.
None is cured by a static seal or a finite time budget.

**Current v1.8 G0-G9 and inherited Required Gates are not all satisfied.** No
executable/source integration/runtime/owner-scope/Gate/item/ledger acceptance is
claimed. Next work remains within current v1.8: independent review/disposition of
the complete revision and source dependencies, then only a separately assigned
bounded implementation/qualification, with explicit runtime permission later.

Root must read this complete REPORT and proposal before one-time sealing. Current
proposal/report hashes and final actual manifest/count/byte results are reported
through coordination, not inserted as self-referential or unexecuted seal claims.
