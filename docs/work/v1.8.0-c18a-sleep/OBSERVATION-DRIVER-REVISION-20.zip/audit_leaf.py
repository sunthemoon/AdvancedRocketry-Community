"""Compact pre-seal document/input/receipt audit; no driver/parser/test runtime."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
inputs = json.loads((root / "INPUTS.json").read_text(encoding="utf-8"))
checks = []
for item in inputs["inputs"]:
    path = Path(item["path"])
    with path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if path.stat().st_size != item["bytes"] or actual != item["sha256"]:
        raise ValueError("Static input drift: " + str(path))
    checks.append({"path": str(path), "bytes": item["bytes"], "sha256": actual})
for path in [root.parent / "SLEEP-OBSERVATION-NESTED-BOUNDARY-ADDENDUM-22.md", root.parent / "SLEEP-OBSERVATION-NESTED-BOUNDARY-ADDENDUM-23.md", root.parent / "SLEEP-OBSERVATION-DRIVER-REVISION-CORRECTION-24.md", root / "commands/governance-13.stdout.txt"]:
    data = path.read_bytes()
    checks.append({"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

receipts = []
for path in sorted((root / "commands").glob("*.json")):
    receipt = json.loads(path.read_text(encoding="utf-8"))
    for key in ["pre_start_utc", "argv", "cwd", "end_utc", "exit_code", "timeout_seconds", "stdout", "stderr"]:
        if key not in receipt:
            raise ValueError("Missing receipt field: " + str(path) + " / " + key)
    if receipt["timeout_seconds"] != 180:
        raise ValueError("Wrong command ceiling: " + str(path))
    receipts.append({"name": path.name, "exit_code": receipt["exit_code"], "timed_out": receipt["timed_out"], "duration_seconds": receipt["duration_seconds"], "stdout_bytes": (path.parent / receipt["stdout"]).stat().st_size, "stderr_bytes": (path.parent / receipt["stderr"]).stat().st_size})

inventory = []
for path in sorted(root.rglob("*")):
    if path.is_file():
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError("Unsafe own evidence path: " + str(path))
        data = path.read_bytes()
        inventory.append({"relative": path.relative_to(root).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
documents = []
for name in ["PROPOSED-DRIVER-03.md", "REPORT.md"]:
    data = (root / name).read_bytes()
    documents.append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "lines": len(data.decode("utf-8").splitlines())})

result = {"kind": "static-preseal-audit-not-native-or-parser-test", "source": inputs["source"], "governance": inputs["governance"], "historical_seals_verified_in_command24": inputs["seals"], "inputs_rechecked": checks, "documents": documents, "commands": receipts, "command_count_before_this_receipt": len(receipts), "nonzero_commands": [r for r in receipts if r["exit_code"] != 0], "own_inventory_before_this_receipt": inventory, "own_bytes_before_this_receipt": sum(r["bytes"] for r in inventory), "scope_incident": {"external_path": str(root.parent / "LATER-INPUTS-INVALID-PLACEHOLDER.md"), "still_exists": (root.parent / "LATER-INPUTS-INVALID-PLACEHOLDER.md").exists(), "covered_external_item": False, "original_preserved": "INCIDENT-ORIGINAL.txt", "disposition": "POLICY_DENIED_BEFORE_SCRIPT_NO_RETRY_OR_ROOT_REMOVAL"}, "proposed_budget_arithmetic": {"raw_hard_bytes": 3 * 17 * 1024 * 1024, "other_and_failure_bytes": 11 * 1024 * 1024, "new_hard_total": 62 * 1024 * 1024, "root_supplied_existing_expanded": 32447830, "expanded_conservative_total": 32447830 + 62 * 1024 * 1024, "success_seconds": 300 + 2 * 60 + 2 * 60 + 90 + 180 + 2 * 60 + 5 + 3 * 60, "conservative_failure_seconds": 1145}}
target = root / "PRESEAL-VERIFICATION.json"
if target.exists():
    raise FileExistsError(str(target))
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"documents": documents, "input_rechecks": len(checks), "command_count_before_this_receipt": len(receipts), "nonzero_commands": result["nonzero_commands"], "own_inventory_files": len(inventory), "own_bytes_before_this_receipt": result["own_bytes_before_this_receipt"], "scope_incident": result["scope_incident"], "proposed_budget_arithmetic": result["proposed_budget_arithmetic"]}, indent=2))
