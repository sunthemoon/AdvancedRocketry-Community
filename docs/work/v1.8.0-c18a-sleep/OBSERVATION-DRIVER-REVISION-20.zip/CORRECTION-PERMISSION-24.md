# Task20 single-file scope correction permission

Date: 2026-10-09. Root verifies the author-reported accidental regular file
D:/GitHub/ARCE-Task-Evidence/v1.8.0/LATER-INPUTS-INVALID-PLACEHOLDER.md:
37 bytes, SHA256 87491e3764bcb18ecbf1845ad6e50942911383694c33dd40a18a24c707d8698a.
The author created it outside its Task20 leaf by a mistaken patch. No sealed
input, repository source or peer output is changed.

Authorize only that author to preserve the exact bytes/hash and incident in its
own unsealed Task20 leaf, then remove this one verified literal file using native
PowerShell Remove-Item -LiteralPath (no recursion). Verify resolved absolute name,
regular non-reparse identity and exact hash immediately before removal. Capture
actual pre-start/end UTC, argv/cwd/exit/raw streams and final absence. If identity
changes or removal is denied, stop and report; do not retry or use another route.
No other cleanup, deletion, source/HEAD, Main or runtime authority is granted.
Retain the original mistaken-patch preparation gap and this corrective permission
in final REPORT. This does not approve the proposed driver contract or a Gate.
