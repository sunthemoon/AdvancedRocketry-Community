"""Retain actual read-only static inspection command receipts for TASK-20."""
import datetime
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
name, cwd, *argv = sys.argv[1:]
if not argv or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for char in name):
    raise SystemExit("usage: capture.py name cwd argv...")
directory = root / "commands"
directory.mkdir(exist_ok=True)
prefix = directory / name
if prefix.with_suffix(".json").exists():
    raise SystemExit("duplicate receipt name")
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
started = utc()
clock = time.monotonic()
timed_out = False
try:
    result = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=180)
    stdout, stderr, exit_code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, exit_code = error.stdout or b"", error.stderr or b"", None
    timed_out = True
ended = utc()
duration = time.monotonic() - clock
prefix.with_suffix(".stdout.txt").write_bytes(stdout)
prefix.with_suffix(".stderr.txt").write_bytes(stderr)
receipt = {"argv": argv, "cwd": cwd, "pre_start_utc": started, "end_utc": ended,
           "duration_seconds": duration, "exit_code": exit_code, "timed_out": timed_out,
           "timeout_seconds": 180, "stdout": prefix.with_suffix(".stdout.txt").name,
           "stderr": prefix.with_suffix(".stderr.txt").name,
           "kind": "static-inspection-not-runtime"}
prefix.with_suffix(".json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
sys.stdout.buffer.write(stdout)
sys.stderr.buffer.write(stderr)
print("\nCAPTURE_RECEIPT=" + json.dumps(receipt), flush=True)
raise SystemExit(exit_code if exit_code is not None else 124)
