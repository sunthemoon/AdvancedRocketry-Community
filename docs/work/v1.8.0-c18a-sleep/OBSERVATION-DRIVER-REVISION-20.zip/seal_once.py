"""Capture the actual seal subprocess once; explicit post-seal receipt only."""
from pathlib import Path
from datetime import datetime, timezone
import base64
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
target = root / "SEAL-RESULT.json"
if target.exists() or (root / "SHA256SUMS.txt").exists():
    raise FileExistsError("One-time seal/receipt already exists")
argv = [sys.executable, "-B", str(root / "seal_manifest.py")]
cwd = "D:/GitHub/AdvancedRocketry-Community"
pre = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
completed = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=180)
end = datetime.now(timezone.utc).isoformat()
receipt = {"kind": "actual-one-time-static-record-seal-not-acceptance", "pre_start_utc": pre, "end_utc": end, "duration_seconds": time.monotonic() - start, "argv": argv, "cwd": cwd, "exit_code": completed.returncode, "timeout_seconds": 180, "stdout_base64": base64.b64encode(completed.stdout).decode("ascii"), "stderr_base64": base64.b64encode(completed.stderr).decode("ascii"), "stdout_text": completed.stdout.decode("ascii", errors="strict"), "stderr_text": completed.stderr.decode("ascii", errors="strict"), "excluded_from_manifest": True}
if completed.returncode == 0:
    receipt["verification"] = json.loads(completed.stdout)
with target.open("x", encoding="utf-8") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt, indent=2))
raise SystemExit(completed.returncode)
