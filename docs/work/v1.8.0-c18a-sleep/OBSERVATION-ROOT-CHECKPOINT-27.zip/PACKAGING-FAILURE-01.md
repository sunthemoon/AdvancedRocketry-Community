# Packaging preparation failure 01

Root invoked Python3.13.15 -B package_inputs_01.py through exec_command. It
returned exit1 at line50, `assert covered['REPORT.md'] == report_sha`, after
creating Root18 and Task19 ZIPs. The manually copied Task20 REPORT digest omitted
one `5`; the sealed input manifest and file agree on the complete correct hash
06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6.
No Task20 ZIP or PACKAGING-01.json was produced. The tool output preserves the
traceback; precise subprocess start/end UTC was not instrumented for this first
invocation and is not reconstructed. The original helper remains unchanged.

A separate package_inputs_02.py validates the unchanged helper's SHA, corrects
only the copied digest in memory and verifies existing Root18/19 ZIP payloads
without overwriting them. This is a corrected preparation cohort, not a test
rerun or evidence-source alteration. Remaining ZIPs are exclusive-create.
