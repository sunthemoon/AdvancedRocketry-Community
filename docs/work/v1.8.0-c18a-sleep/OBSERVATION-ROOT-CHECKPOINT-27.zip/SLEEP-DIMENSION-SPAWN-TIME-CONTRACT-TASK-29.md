# Dimension, spawn and time contract preparation 29

Date: 2026-10-09 UTC. You are a delegated contract worker, not Root. Do not
delegate or call Claude. This is static contract preparation for the current
v1.8 C18a-SLEEP-01 slice, not implementation or acceptance.

## Inputs and observable output

Fixed governance Main: 6d1b796e0e93b9953af505dd3fd9b25d47b91d97.
Fixed isolated source: d57ecda1f11dab76d882f945b0de606534ef4fb9, readable in
D:/GitHub/arce-v180-sleep-chat-boundary-20261009. Do not move its HEAD or use its
retained outputs as your own generation. Its production src/main is unchanged
by the observation-only corrections.

Read mandatory governance/version/quality/parallel documents and the exact
OWNER-DECISION-01.md, OWNER-QUESTION-02.md and OWNER-DECISION-03.md under
Main docs/work/v1.8.0-c18a-sleep. The actual submitted owner answer is the
authority for its explicitly stated scope; do not broaden it. Read original
PROPOSED-CONTRACT-01.md and RESEARCH/CONTRACT-REVIEW/SPAWN/AIR/BOUNDARY status
records and their sealed research inputs as needed. Inspect actual generated
dimension resources/providers, packaging exclusions, time/spawn services and
pinned native/Forge primary inputs before describing behavior.

Prepare a self-contained PROPOSED dimension/spawn/time sub-contract suitable
for a separate fresh independent review. Separate owner-selected product scope,
source-established facts, implementation requirements, still-unresolved inputs
and runtime acceptance obligations. Identify exact stable dimension identities,
resource/generation/startup/upgrade boundaries, native ancillary implications,
spawn-record operations and time/quorum ownership. Define bounded verification
criteria and compatibility/recovery boundaries without claiming unexecuted
results. Distinguish this D1 proposal from B1/R1/M1/M2 and the full sleep/API/
respawn item. Do not adopt a technical solution for those other prerequisites
or infer that this sub-contract authorizes production source.

## Ownership and commands

Exclusive write_scope:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29/**.
Only this leaf may hold TASK, proposal, REPORT, input hashes, small excerpts,
read-command receipts and scratch. Main/source/central registry/build/config/
state/Gate/ledger files, other worktrees and sealed evidence are read-only.
No commit/push/checkout/worktree mutation, Gradle/build/test/Java execution,
server/world/client/driver/parser, install/network, quota/mount or cleanup.
Read-only git/rg/file/hash/ZIP inspection, Python -B bounded helpers and pinned
javap inspection are allowed with 180-second ceilings. Do not copy complete
Minecraft/upstream libraries, source trees, resources or runtime outputs; retain
only audit-relevant tiny excerpts and identities. No upstream asset/code import.
Record actual read inputs/commands/UTC/exit, and preserve failures/capture gaps.

## Delivery

Keep the sub-contract concise, avoiding repetition of the existing full-sleep
proposal. Final REPORT: findings/uncertainties first, owner/source/gov identity,
actual inspected files and command results, explicit authority limits, output
paths/hashes, unexecuted tests and proposed independent-review scope. No fixed
verdict, policy acceptance, Gate closure or implementation-readiness claim.
Send complete proposal/report paths, line counts, sizes and SHA to Root. Wait
for Root's full reading before any one-time manifest seal, and disclose excluded
seal receipts. Root alone will decide publication and review assignments.
