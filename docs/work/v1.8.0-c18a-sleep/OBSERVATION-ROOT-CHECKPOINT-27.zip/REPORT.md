# Root observation evidence checkpoint 27

Date: 2026-10-09 UTC. Executor: Root, sole Main record integrator.

## Completed scope and publication

Root completely reads final d57 Trace/helper and all Task19/21/20/26 reports;
proposal20 is completely read at 991 lines. The new Main checkpoint records final
isolated source, scoped independent patch disposition, static contract findings,
retention/incident state and separate still-pending qualification/D1 assignments.
Five immutable archives rehost Root18/19/20/21/26 after safe path/hash/CRC/full
payload verification. Prior sealed inputs and archives are unchanged.

Main commit/push: 7cf661e7861971a61ac26d786ae0ae1e33ff2af6, from fixed6d.
Actual captured commit UTC 07:31:55.266655--07:31:55.527740, exit 0; normal push
UTC 07:31:55.572109--07:32:00.499289, exit 0. Before commit Root reads cached stat
and complete cached Markdown diff. Staged 11 files are six Markdown records and
five new ZIPs, 215 insertions/8 deletions; user AGENTS is never staged.

## Source, tests and findings

Isolated normally pushed d57ecda1f11dab76d882f945b0de606534ef4fb9/src tree
85f53265bf4ee59b65c4a88664cb2e5e208c583e remains unmerged. Author19's three and
independent21's two compile cohorts return 0; they execute no tests. Six new
GameTests are compiled, and final scoped source review identifies no remaining
material patch finding. Historical ResourceLocation/EntityType findings are
source-addressed, not universal native/capture proof. The Object guard probe is
not an instantiated/injected EntityType subclass. Original cohorts remain.

Task26's complete 332-line review adds a Medium compressed-native-log interpretation
gap and Low reachable-ID wording. Current Main27 clarifies 2049 is an independent
field envelope, not reachable source maximum; shared budget yields at most a
loose 1366 including colon, with other text lowering it. Original17/20 seals stay.
Earlier encoding/storage/NBT recipes are stated, not executed/accepted. OS hard
runtime allocation, capture/reservation/I/O/helper/parser qualification and
permissions remain open. Separately scoped offline structural work is possible,
not assigned or approved by this publication.

Twenty-two actual sleep ZIPs total 8491365 compressed/44048970 expanded bytes.
Proposal03 reserves 65011712 new bytes; conservative expanded sum 109060682 fails
its pre-run construction. No waiver, relabeled pass, source-cap increase,
evidence deletion or native launch approval occurs. Later28/29 evidence is not
part of this checkpoint inventory.

Task28 is a separate fixed-d57 standard development qualification in its own
fresh detached checkout. Task29 statically prepares the dimension/spawn/time
sub-contract under the owner's exact conditional ancillary scope. Their final
reports/results are pending at this publication and are not inputs to this seal.
No observation command/driver/parser/production source is assigned here.

Root27 executes no Gradle/test/GameTest/native observation. Main's complete src
tree remains 368c91b05ecf98c1b817ec6e499708ff47c8399b, with integrated behavioral
regression at 3b18 unchanged. Historical5b results stay separate, not rebound.

## Actual validation and captured limits

check_records_01 captures whitespace, accepted-ledger, approved-bootstrap and
tracked-state commands: all exit 0, exact argv/cwd/UTC/log SHA/owner digest retained.
Publication preparation repeats those validations, stages exact scope and captures
cached stat/diff/check; all exit 0. Only changed/new links are checked; historical
whole-log portability is not approved. Accepted ledger remains 186 PLANNED/
154 REVIEW; no ledger or Gate file is edited. FINAL-AUDIT-01 records final Main/
upstream/source/index/owner identities and exact copied Task28/29/30 permissions.

First packaging helper has a copied Task20 REPORT digest missing one character;
it exits 1 at the report assertion after creating the first two ZIPs. A separate
helper pins the unchanged failed script, corrects only that digest in memory,
verifies existing ZIPs without overwrite and creates the remaining two. Actual
sealed input hash was correct. PACKAGING-FAILURE-01 preserves available failure
details; the traceback remains a session tool receipt, not a separately persisted
raw child log. Precise first process UTC is unavailable and is not fabricated.
Successful packaging02/03 operation start/end UTC is sampled inside Python,
not an external launcher timestamp. Original helper and failed cohort remain.

Direct exploratory displays include a guessed missing Task11 filename, guessed
main resource directory and PowerShell wildcard rg path errors; correct discovered
files and focused reads follow. Initial combined governance/tool output truncates;
needed version/test/Gate/quality/parallel/source/report text is separately read or
was fully read earlier in the continuing Root session. These are session tool
receipts, not separately captured child logs. First fresh worktree creation and
permission-file hash displays are likewise not reconstructed UTC/stream receipts.
Own publication/check receipts are fully instrumented; final auxiliary identity
git reads are audit values rather than individually captured raw child streams.
OpenPet remains unreachable with Win10061; task proceeds without app-data edits.

## Cleanup, custody, risks and unfinished scope

Root27 creates no runtime/build/world output or cleanup target. Only compact
evidence/records are written. Author19's three own output generations are cleaned;
independent21's two policy-denied generations retain 47584321 bytes plus empty
scratch directories. Older independent retention stays unchanged. Task20's
out-of-scope 37-byte external file remains after its one-time correction is denied
before the script body. No retry/bypass/alternate shell/Root takeover occurs.
Manifest coverage never includes that external mutable file.

User AGENTS SHA remains c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09;
only its existing tracked modification remains after push; inherited untracked
files are untouched, index empty. New qualification checkout is detached d57;
other agents retain their fixed source/governance identities. No Claude is called.

Unfinished: final28 qualification,29 proposal/review, compressed-log contract,
driver/parser/capture storage/runtime, all twenty console rows/disk/cause proof,
B1/R1/M1/M2/D1 runtime and production sleep, exact dimension/spawn/time freezing,
Space choice, clients/restart/prior worlds/air/access/performance/full items/assets,
hatch choices, strict timeout/log/link/cleanup gaps and all Required Gates.
Current-version all Required Gates satisfied: no. No source merge, contract/Gate/
ledger/version/release approval or tag occurs. Next work remains within v1.8:
complete separate qualification/D1 review and resolve capture-contract prerequisites.

All own persisted report/audit/receipt bytes must be read and audited before
one-time leaf-relative sealing. Later corrections or outcomes use a separate
record, never edits to this seal or older inputs.
