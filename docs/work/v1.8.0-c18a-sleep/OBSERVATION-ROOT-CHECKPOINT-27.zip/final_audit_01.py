"""Audit own publication receipts and preserve permission copies, not outputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

start = datetime.now(timezone.utc).isoformat()
copies = []
for name, expected in (
    ('SLEEP-NESTED-BOUNDARY-QUALIFICATION-TASK-28.md', '757c5753e9f591ed0ef6ed7b4a884dac7d7d7c546c78cc743d17dc89aa4ede46'),
    ('SLEEP-DIMENSION-SPAWN-TIME-CONTRACT-TASK-29.md', '9aae475f9cde781c65e4b076fe7e6fe476fe87deae24f0393c4f860d130e38bf'),
    ('SLEEP-NESTED-QUALIFICATION-CLEANUP-CLARIFICATION-30.md', 'b95f5b69e3aedff292a743101fad4a9893d2794e92ee3c73814bdf453bdc6ee1')):
    raw = (BASE / name).read_bytes()
    assert sha(raw) == expected
    target = OUT / name
    with target.open('xb') as stream:
        stream.write(raw)
    copies.append({'path': name, 'bytes': len(raw), 'sha256': expected})
receipts = []
for path in sorted(OUT.glob('*-01-*.json')):
    if not path.name.startswith(('publication-01-', 'check-01-')):
        continue
    record = json.loads(path.read_text(encoding='utf-8'))
    log = path.with_suffix('.log')
    assert record['log_bytes'] == log.stat().st_size and record['log_sha256'] == sha(log.read_bytes())
    assert record['owner_agents_sha256'] == 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
    assert record['exit'] == 0
    receipts.append({'path': path.name, 'sha256': sha(path.read_bytes()), 'log': log.name})
argv = ['git', 'status', '--short', '--untracked-files=no']
log = OUT / 'final-01-state.log'
command_start = datetime.now(timezone.utc).isoformat()
with log.open('xb') as stream:
    result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=180, check=False)
command_end = datetime.now(timezone.utc).isoformat()
assert result.returncode == 0 and log.read_text(encoding='utf-8').strip() == 'M AGENTS.md'
identities = {}
for label, args in (
    ('head', ['rev-parse', 'HEAD']), ('upstream', ['rev-parse', '@{u}']),
    ('src_tree', ['rev-parse', 'HEAD:src']), ('index', ['diff', '--cached', '--name-only']),
    ('candidate_head', ['-C', 'D:/GitHub/arce-v180-sleep-chat-boundary-20261009', 'rev-parse', 'HEAD']),
    ('candidate_tree', ['-C', 'D:/GitHub/arce-v180-sleep-chat-boundary-20261009', 'rev-parse', 'HEAD:src'])):
    identities[label] = subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()
assert identities['head'] == identities['upstream'] == '7cf661e7861971a61ac26d786ae0ae1e33ff2af6'
assert identities['src_tree'] == '368c91b05ecf98c1b817ec6e499708ff47c8399b' and not identities['index']
assert identities['candidate_head'] == 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
assert identities['candidate_tree'] == '85f53265bf4ee59b65c4a88664cb2e5e208c583e'
owner = sha((ROOT / 'AGENTS.md').read_bytes())
assert owner == 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
record = {'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
          'state_command': {'argv': argv, 'cwd': str(ROOT), 'start_utc': command_start,
                            'end_utc': command_end, 'exit': result.returncode,
                            'log_bytes': log.stat().st_size, 'log_sha256': sha(log.read_bytes())},
          'permission_copies': copies, 'verified_command_receipts': receipts,
          'identities': identities, 'owner_agents_sha256': owner,
          'auxiliary_check_output_note': 'Identity git reads are audit values, not separately raw-stream-captured child receipts.'}
with (OUT / 'FINAL-AUDIT-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
