"""Capture scoped record validation without moving HEAD or staging."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = '6d1b796e0e93b9953af505dd3fd9b25d47b91d97'
OWNER = 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
DOCS = ['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
        'docs/work/v1.8.0-implementation-log.md',
        'docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-08.md',
        'docs/work/v1.8.0-c18a-sleep/DRIVER-REVIEW-STATUS-18.md',
        'docs/work/v1.8.0-c18a-sleep/NESTED-BOUNDARY-STATUS-27.md']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()

def run(name, argv):
    log = OUT / ('check-01-' + name + '.log')
    receipt = log.with_suffix('.json')
    assert not log.exists() and not receipt.exists()
    record = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 180,
              'start_utc': datetime.now(timezone.utc).isoformat()}
    with log.open('xb') as stream:
        try:
            result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=180, check=False)
            record['exit'] = result.returncode
        except subprocess.TimeoutExpired:
            record['exit'] = 'TIMEOUT'
    record.update(end_utc=datetime.now(timezone.utc).isoformat(), log_bytes=log.stat().st_size,
                  log_sha256=sha(log), owner_agents_sha256=sha(ROOT / 'AGENTS.md'))
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    assert record['exit'] == 0

assert git('rev-parse', 'HEAD') == BASE and git('rev-parse', '@{u}') == BASE
assert git('rev-parse', 'HEAD:src') == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
assert sha(ROOT / 'AGENTS.md') == OWNER and not git('diff', '--cached', '--name-only')
assert sorted(git('diff', '--name-only').splitlines()) == sorted(['AGENTS.md', *DOCS[:-1]])
links = []
for name in DOCS:
    # Only new implementation-log links belong to this checkpoint; inherited
    # link gaps remain open rather than implicitly adopted as portable inputs.
    text = (ROOT / name).read_text(encoding='utf-8')
    if name.endswith('v1.8.0-implementation-log.md'):
        text = text.split('## 2026-10-09 complete sleep driver', 1)[0]
    for target in re.findall(r'\]\(([^)]+)\)', text):
        if '://' in target or target.startswith('#'):
            continue
        path = (ROOT / name).parent / target.split('#', 1)[0]
        assert path.exists(), (name, target)
        links.append({'file': name, 'target': target})
with (OUT / 'CHANGED-LINKS-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps({'checked': links, 'whole_log_portability': False}, indent=2) + '\n')
run('whitespace', ['git', 'diff', '--check'])
run('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
run('bootstrap', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py', '--require-approved-review'])
run('final-state', ['git', 'status', '--short', '--untracked-files=no'])
