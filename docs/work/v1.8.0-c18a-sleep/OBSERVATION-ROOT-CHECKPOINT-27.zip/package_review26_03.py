"""Verify and rehost the fully read, one-time sealed review26."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
OUT = Path(__file__).resolve().parent
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
LEAF = BASE / 'sleep-observation-driver-revision-independent-20261009-26'
TARGET = DEST / 'OBSERVATION-DRIVER-REVISION-INDEPENDENT-26.zip'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

started = datetime.now(timezone.utc).isoformat()
manifest = (LEAF / 'SHA256SUMS.txt').read_bytes()
assert sha(manifest) == '9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d'
covered = {}
for line in manifest.decode('utf-8-sig').splitlines():
    match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
    assert match
    expected, name = match.groups()
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and ':' not in name and '\\' not in name
    assert name.casefold() not in {key.casefold() for key in covered}
    assert sha((LEAF / name).read_bytes()) == expected.lower(), name
    covered[name] = expected.lower()
assert covered['REPORT.md'] == 'e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc'
paths = {}
for path in LEAF.rglob('*'):
    assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
    if path.is_file():
        assert path.stat().st_size < 50 * 1024 ** 2
        paths[path.relative_to(LEAF).as_posix()] = path
assert set(paths) == set(covered) | {'SHA256SUMS.txt', 'SEAL-RESULT.json'}
assert len(paths) == len({name.casefold() for name in paths})
assert sha(paths['SEAL-RESULT.json'].read_bytes()) == 'c1bfce2d1f534ade7fc1be0bb7f0b636fcdffdc92e7474b16ec668c14440bd36'
assert not TARGET.exists()
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(paths.items()):
        archive.write(path, name)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(paths)
    for name, path in paths.items():
        assert archive.read(name) == path.read_bytes()
    expanded = sum(info.file_size for info in archive.infolist())
archives, compressed_total, expanded_total = [], 0, 0
for path in sorted(DEST.glob('*.zip')):
    assert path.stat().st_size < 50 * 1024 ** 2
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        size = sum(info.file_size for info in archive.infolist())
    compressed_total += path.stat().st_size
    expanded_total += size
    archives.append({'path': path.name, 'bytes': path.stat().st_size, 'expanded_bytes': size,
                     'sha256': sha(path.read_bytes())})
assert max(compressed_total, expanded_total) < 100 * 1024 ** 2
record = {'start_utc': started, 'end_utc': datetime.now(timezone.utc).isoformat(),
          'archive': TARGET.name, 'bytes': TARGET.stat().st_size, 'expanded_bytes': expanded,
          'archive_sha256': sha(TARGET.read_bytes()), 'entries': len(paths),
          'covered_entries': len(covered), 'covered_bytes': sum(paths[x].stat().st_size for x in covered),
          'noncovered_postseal_entries': ['SEAL-RESULT.json'],
          'manifest_sha256': sha(manifest), 'report_sha256': covered['REPORT.md'],
          'crc_payloads_verified': True, 'all_sleep_archives': archives,
          'all_sleep_compressed_bytes': compressed_total, 'all_sleep_expanded_bytes': expanded_total,
          'runtime_or_executable_approval': False}
with (OUT / 'PACKAGING-03.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
