"""Correct only a copied REPORT digest; verify, never overwrite, prior ZIPs."""
import hashlib
from pathlib import Path

original = Path(__file__).with_name('package_inputs_01.py')
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'cb359e2e52e23a9d84b0495edcb0766c31c1f5c75912552e2288ebe627251d15'
source = raw.decode('utf-8')
wrong = '06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b615a1b5a61b6'
correct = '06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6'
assert source.count(wrong) == 1
source = source.replace(wrong, correct)
old = "    assert not target.exists()\n    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:\n        for name, path in sorted(paths.items()):\n            archive.write(path, name)\n"
new = "    already_exists = target.exists()\n    if not already_exists:\n        with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:\n            for name, path in sorted(paths.items()):\n                archive.write(path, name)\n"
assert source.count(old) == 1
source = source.replace(old, new).replace("'archive': zip_name, 'bytes':", "'archive': zip_name, 'already_existed_and_verified': already_exists, 'bytes':")
source = source.replace("OUT / 'PACKAGING-01.json'", "OUT / 'PACKAGING-02.json'")
exec(compile(source, str(original) + ':corrected02', 'exec'))
