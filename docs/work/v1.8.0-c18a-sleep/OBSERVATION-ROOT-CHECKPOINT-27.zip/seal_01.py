"""Seal this completely read Root checkpoint once; no external manifest inputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

start = datetime.now(timezone.utc).isoformat()
assert not (OUT / 'SHA256SUMS.txt').exists()
paths = {}
for path in OUT.rglob('*'):
    assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
    if path.is_file():
        name = path.relative_to(OUT).as_posix()
        assert ':' not in name and '..' not in Path(name).parts
        assert path.stat().st_size < 50 * 1024 ** 2
        paths[name] = path
assert len(paths) == len({name.casefold() for name in paths})
assert sum(path.stat().st_size for path in paths.values()) < 100 * 1024 ** 2
for receipt in [p for p in paths.values() if p.name.startswith(('publication-01-', 'check-01-')) and p.suffix == '.json']:
    record = json.loads(receipt.read_text(encoding='utf-8'))
    log = receipt.with_suffix('.log')
    assert record['exit'] == 0 and record['log_bytes'] == log.stat().st_size
    assert record['log_sha256'] == sha(log.read_bytes())
manifest = ''.join(sha(path.read_bytes()) + '  ' + name + '\n' for name, path in sorted(paths.items()))
with (OUT / 'SHA256SUMS.txt').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(manifest)
for line in manifest.splitlines():
    expected, name = line.split('  ', 1)
    assert sha((OUT / name).read_bytes()) == expected
print(json.dumps({'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
                  'covered_files': len(paths), 'covered_bytes': sum(path.stat().st_size for path in paths.values()),
                  'manifest_sha256': sha((OUT / 'SHA256SUMS.txt').read_bytes()),
                  'report_sha256': sha((OUT / 'REPORT.md').read_bytes()),
                  'excluded_files': ['SHA256SUMS.txt'], 'own_runtime_outputs': False}), flush=True)
