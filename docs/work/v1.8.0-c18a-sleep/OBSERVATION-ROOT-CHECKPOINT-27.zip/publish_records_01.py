"""Stage scoped evidence records; publish only after Root inspects cached diff."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = '6d1b796e0e93b9953af505dd3fd9b25d47b91d97'
OWNER = 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
DOCS = sorted(['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',
    'docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-08.md',
    'docs/work/v1.8.0-c18a-sleep/DRIVER-REVIEW-STATUS-18.md',
    'docs/work/v1.8.0-c18a-sleep/NESTED-BOUNDARY-STATUS-27.md'])
ZIPS = sorted(['docs/work/v1.8.0-c18a-sleep/' + name for name in (
    'OBSERVATION-ROOT-DISPOSITION-18.zip', 'OBSERVATION-NESTED-BOUNDARY-19.zip',
    'OBSERVATION-DRIVER-REVISION-20.zip', 'OBSERVATION-NESTED-INDEPENDENT-21.zip',
    'OBSERVATION-DRIVER-REVISION-INDEPENDENT-26.zip')])
EXPECTED = sorted(DOCS + ZIPS)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()

def run(name, argv):
    log = OUT / ('publication-01-' + name + '.log')
    receipt = log.with_suffix('.json')
    assert not log.exists() and not receipt.exists()
    record = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 180,
              'start_utc': datetime.now(timezone.utc).isoformat()}
    with log.open('xb') as stream:
        try:
            result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=180, check=False)
            record['exit'] = result.returncode
        except subprocess.TimeoutExpired:
            record['exit'] = 'TIMEOUT'
    record.update(end_utc=datetime.now(timezone.utc).isoformat(), log_bytes=log.stat().st_size,
                  log_sha256=sha(log), head=git('rev-parse', 'HEAD'),
                  owner_agents_sha256=sha(ROOT / 'AGENTS.md'))
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    assert record['exit'] == 0

assert git('rev-parse', 'HEAD') == BASE and git('rev-parse', '@{u}') == BASE
assert git('branch', '--show-current') == 'codex/v1.8.0-classic-content'
assert sha(ROOT / 'AGENTS.md') == OWNER
assert git('rev-parse', 'HEAD:src') == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
if sys.argv[1] == 'prepare':
    assert not git('diff', '--cached', '--name-only')
    assert sorted(git('diff', '--name-only').splitlines()) == sorted(['AGENTS.md', *[p for p in DOCS if not p.endswith('NESTED-BOUNDARY-STATUS-27.md')]])
    links = []
    for name in DOCS:
        text = (ROOT / name).read_text(encoding='utf-8')
        if name.endswith('v1.8.0-implementation-log.md'):
            text = text.split('## 2026-10-09 complete sleep driver', 1)[0]
        for target in re.findall(r'\]\(([^)]+)\)', text):
            if '://' not in target and not target.startswith('#'):
                assert ((ROOT / name).parent / target.split('#', 1)[0]).exists(), (name, target)
                links.append({'file': name, 'target': target})
    (OUT / 'CHANGED-LINKS-02.json').write_text(json.dumps({'links': links, 'whole_log_portability': False}, indent=2) + '\n', encoding='utf-8')
    rows = json.loads((OUT / 'PACKAGING-02.json').read_text(encoding='utf-8'))['archives']
    rows += [json.loads((OUT / 'PACKAGING-03.json').read_text(encoding='utf-8'))]
    for row in rows:
        assert sha(ROOT / 'docs/work/v1.8.0-c18a-sleep' / row['archive']) == row['archive_sha256']
    compressed = expanded = 0
    for path in (ROOT / 'docs/work/v1.8.0-c18a-sleep').glob('*.zip'):
        assert path.stat().st_size < 50 * 1024 ** 2
        compressed += path.stat().st_size
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            expanded += sum(info.file_size for info in archive.infolist())
    assert max(compressed, expanded) < 100 * 1024 ** 2
    for name, argv in (
        ('whitespace', ['git', 'diff', '--check']),
        ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
        ('bootstrap', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py', '--require-approved-review']),
        ('stage', ['git', 'add', '--', *EXPECTED]),
        ('cached-stat', ['git', 'diff', '--cached', '--stat']),
        ('cached-diff', ['git', 'diff', '--cached', '--', *DOCS]),
        ('cached-check', ['git', 'diff', '--cached', '--check']),
    ):
        run(name, argv)
    assert sorted(git('diff', '--cached', '--name-only').splitlines()) == EXPECTED
    with (OUT / 'PREPARED-INPUTS-01.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps({'base': BASE, 'paths': [{'path': name, 'sha256': sha(ROOT / name)} for name in EXPECTED]}, indent=2) + '\n')
elif sys.argv[1] == 'commit':
    assert sorted(git('diff', '--cached', '--name-only').splitlines()) == EXPECTED
    for row in json.loads((OUT / 'PREPARED-INPUTS-01.json').read_text(encoding='utf-8'))['paths']:
        assert sha(ROOT / row['path']) == row['sha256']
    run('commit', ['git', 'commit', '-m', 'docs(sleep): preserve final receiver and driver review evidence'])
    run('push', ['git', 'push', 'origin', 'HEAD:codex/v1.8.0-classic-content'])
    assert git('rev-parse', 'HEAD') == git('rev-parse', '@{u}')
    assert git('rev-parse', 'HEAD:src') == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
    assert git('status', '--short', '--untracked-files=no') == 'M AGENTS.md'
    assert not git('diff', '--cached', '--name-only')
else:
    raise SystemExit('Unknown publication phase')
