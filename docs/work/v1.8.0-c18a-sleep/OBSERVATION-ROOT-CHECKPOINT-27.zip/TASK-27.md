# Root observation checkpoint 27

Date: 2026-10-09 UTC. Root is the sole Main record integrator. Fixed Main base
6d1b796e0e93b9953af505dd3fd9b25d47b91d97. Scope: rehost completely read sealed
Root18/Task19/Task20/Task21 and completed Task26 evidence; record actual current
source/review/proposal/qualification state. No production or fixture source
merge, native observation run, policy change or Gate/ledger approval.

Exclusive scratch/evidence is this leaf. Main write_scope is a new checkpoint
Markdown and compact immutable ZIPs in docs/work/v1.8.0-c18a-sleep, additive
supersession notes in SOURCE-REVIEW-STATUS-08.md and DRIVER-REVIEW-STATUS-18.md,
docs/status/CURRENT_VERSION.md, docs/status/COMPLETION-PLAN.md and
docs/work/v1.8.0-implementation-log.md. Root may create a fresh detached d57
qualification checkout under Task28; worker28 owns its outputs/evidence.
Do not edit user AGENTS, ledger/Gates, source, old sealed files or untracked
historical evidence. Task26/28 readers remain fixed to their specified inputs.

Verify manifests, archive safe/case-unique paths, CRC/payload hashes, individual
files below 50 MB and slice evidence volume below 100 MB. Disclose explicit
post-seal exclusions and actual cumulative retained evidence. Do not delete or
split evidence to bypass limits. Validate record whitespace, accepted ledger,
approved bootstrap and only changed links. Full repository strict results stay
distinct. Stage exact task files, inspect cached stat/diff/check and owner hash,
then normal commit/push; no force/amend or foreign index takeover. Capture raw
command receipts/UTC/exit and publication identities. Final report must be
completely read before sealing; source/gameplay and all Gates remain separate.
