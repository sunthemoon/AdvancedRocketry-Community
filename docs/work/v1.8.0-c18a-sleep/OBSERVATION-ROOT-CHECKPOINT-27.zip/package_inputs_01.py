"""Rehost four fully read sealed inputs without editing their contents."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
OUT = Path(__file__).resolve().parent
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
SPECS = [
    ('sleep-observation-disposition-20261009-18', 'OBSERVATION-ROOT-DISPOSITION-18.zip',
     'fb8082599dfcd7c418461ba3496ee5f7678d35792d8240a72797c63474ccc444',
     '09884712fa7f23c30fce40b2f2bc4b79578f160fdd8bd73e4e59d458bbee1936', []),
    ('sleep-observation-nested-boundary-20261009-19', 'OBSERVATION-NESTED-BOUNDARY-19.zip',
     'df8c9dd1dbc7d487663474c3326ba302178ca4348923539c5bbbf91a7ffbbe3a',
     '982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e',
     ['SEAL-RESULT.json', 'seal-01.command.json', 'seal-01.stdout.txt', 'seal-01.stderr.txt']),
    ('sleep-observation-driver-revision-20261009-20', 'OBSERVATION-DRIVER-REVISION-20.zip',
     'b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0',
     '06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b615a1b5a61b6',
     ['SEAL-RESULT.json']),
    ('sleep-observation-nested-boundary-independent-20261009-21', 'OBSERVATION-NESTED-INDEPENDENT-21.zip',
     '9c4131dbdbfcf34e53583639172e65bd945b17f462fca808dd7acd469ef8d00d',
     'a7b68817e1b0167536d5681069d450724a624e5ea0ecb258a71fc1eb2cc2353a',
     ['SEAL-RESULT.json', 'seal-01.command.json', 'seal-01.stdout.txt', 'seal-01.stderr.txt',
      'seal-verify-01.command.json', 'seal-verify-01.stdout.txt', 'seal-verify-01.stderr.txt'])]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

start = datetime.now(timezone.utc).isoformat()
results = []
for leaf_name, zip_name, manifest_sha, report_sha, extras in SPECS:
    leaf = BASE / leaf_name
    raw_manifest = (leaf / 'SHA256SUMS.txt').read_bytes()
    assert sha(raw_manifest) == manifest_sha
    covered, folded = {}, set()
    for line in raw_manifest.decode('utf-8-sig').splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
        assert match
        expected, name = match.groups()
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
        assert name.casefold() not in folded
        folded.add(name.casefold())
        assert sha((leaf / name).read_bytes()) == expected.lower(), name
        covered[name] = expected.lower()
    assert covered['REPORT.md'] == report_sha
    paths = {}
    for path in leaf.rglob('*'):
        assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
        if path.is_file():
            assert path.stat().st_size < 50 * 1024 ** 2
            paths[path.relative_to(leaf).as_posix()] = path
    assert set(paths) == set(covered) | {'SHA256SUMS.txt', *extras}, sorted(set(paths) - set(covered))
    assert len(paths) == len({name.casefold() for name in paths})
    target = DEST / zip_name
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.write(path, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes()
        expanded = sum(info.file_size for info in archive.infolist())
    results.append({'archive': zip_name, 'bytes': target.stat().st_size,
                    'expanded_bytes': expanded, 'archive_sha256': sha(target.read_bytes()),
                    'entries': len(paths), 'covered_entries': len(covered),
                    'covered_bytes': sum(paths[name].stat().st_size for name in covered),
                    'report_sha256': report_sha, 'manifest_sha256': manifest_sha,
                    'noncovered_postseal_entries': extras, 'crc_payloads_verified': True})
archives, total_compressed, total_expanded = [], 0, 0
for path in sorted(DEST.glob('*.zip')):
    assert path.stat().st_size < 50 * 1024 ** 2
    total_compressed += path.stat().st_size
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        expanded = sum(info.file_size for info in archive.infolist())
        total_expanded += expanded
    archives.append({'path': path.name, 'bytes': path.stat().st_size,
                     'expanded_bytes': expanded, 'sha256': sha(path.read_bytes())})
assert total_compressed < 100 * 1024 ** 2 and total_expanded < 100 * 1024 ** 2
record = {'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
          'archives': results, 'all_sleep_archives': archives,
          'all_sleep_compressed_bytes': total_compressed,
          'all_sleep_expanded_bytes': total_expanded,
          'runtime_or_executable_approval': False}
with (OUT / 'PACKAGING-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
