"""Audit exact Root58 committed records and raw receipts, without code acceptance."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/final_audit_03.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '67be47ed4742907d12ed07e25cedca59e11b93a884f99ab88588cd64907cabe3'
source = raw.decode('utf-8').replace('cd9b54a23b5bf92760b05655a427344d6b620984',
                                   'fdaa015e37a45364b5d2be9d1a3984892d644073')
source = source.replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                        '0dcfaf980e4a4236ff5e3c8630286b40b34eebb1')
source = source.replace("'src', 'build.gradle'", "'src', 'scripts', 'build.gradle'")
source = source.replace(",\n               'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md'", '')
source = source.replace("assert len(raw) == identity['bytes']", "assert len(raw) <= 262144\n        assert len(raw) == identity['bytes']")
scope = """
assert set(git('diff', '--name-only', '0dcfaf980e4a4236ff5e3c8630286b40b34eebb1', head).decode().splitlines()) == {
 'docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
 'docs/work/v1.8.0-implementation-log.md',
 *('docs/work/v1.8.0-c18a-sleep/' + name for name in (
   'OWNER-DECISION-05.md', 'OWNER-QUESTION-04.md', 'OWNER-DECISION-03.md',
   'AIR-RESEARCH-STATUS-02.md', 'BOUNDARY-REVIEW-STATUS-03.md',
   'FUNCTIONAL-SOURCE-ASSIGNMENT-54.md'))}
"""
source = source.replace('rows = []', scope + '\nrows = []')
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
