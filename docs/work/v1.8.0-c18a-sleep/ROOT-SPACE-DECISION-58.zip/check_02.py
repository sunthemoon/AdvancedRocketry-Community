"""Check only Root58 record scope, local references and protected state."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = Path(__file__).resolve().parent
SCOPE = [
    'docs/status/CURRENT_VERSION.md',
    'docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',
    'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-05.md',
    'docs/work/v1.8.0-c18a-sleep/OWNER-QUESTION-04.md',
    'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md',
    'docs/work/v1.8.0-c18a-sleep/AIR-RESEARCH-STATUS-02.md',
    'docs/work/v1.8.0-c18a-sleep/BOUNDARY-REVIEW-STATUS-03.md',
    'docs/work/v1.8.0-c18a-sleep/FUNCTIONAL-SOURCE-ASSIGNMENT-54.md',
]


def git(*args):
    p = subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True,
                       timeout=180, check=True)
    assert len(p.stdout) <= 262144 and len(p.stderr) <= 262144
    return p.stdout.decode('utf-8')


def check():
    assert git('rev-parse', 'HEAD').strip() == '0dcfaf980e4a4236ff5e3c8630286b40b34eebb1'
    assert git('rev-parse', 'HEAD:src').strip() == '85f53265bf4ee59b65c4a88664cb2e5e208c583e'
    assert not git('diff', '--cached', '--name-only')
    assert hashlib.sha256((ROOT / 'AGENTS.md').read_bytes()).hexdigest() == \
        'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
    modified = set(git('diff', '--name-only').splitlines())
    assert modified == (set(SCOPE) - {'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-05.md'}) | {'AGENTS.md'}
    links = []
    for name in SCOPE:
        p = ROOT / name
        assert p.is_file() and p.stat().st_size < 50 * 1024 * 1024
        body = p.read_text(encoding='utf-8')
        for target in re.findall(r'\]\(([^)]+)\)', body):
            if '://' in target or target.startswith('#'):
                continue
            dest = p.parent / target.split('#')[0]
            assert dest.exists(), (name, target)
            links.append([name, target])
    decision = (ROOT / SCOPE[3]).read_text(encoding='utf-8')
    question = (ROOT / SCOPE[4]).read_text(encoding='utf-8')
    assert 'call_5a2196f7697a41f7bc84b01cce27db08' in decision
    presented = question.split('## Exact submitted question\n\n')[1].split('\n\n')[0]
    assert '> ' + presented in decision
    answer = '\u5141\u8bb8\u4f9b\u6c27\u7684\u7ad9\u5916\u623f\u95f4\uff08\u63a8\u8350\uff09'
    assert '\n> ' + answer + '\n' in decision
    assert 'ANSWERED_BY_OWNER_DECISION_05' in question
    result = {'scope': SCOPE, 'local_links_checked': len(links),
              'exact_question_and_answer': True, 'production_unchanged': True,
              'gate_approval': False}
    (LEAF / 'CHECK-02.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    check()
