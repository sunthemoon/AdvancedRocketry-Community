"""Task57 separately named finite structural/diagnostic contract cases.

Expected tuples are written from the fixed contract and original byte recipes,
not obtained from decoder output. These are not resource or native traces.
"""
import dataclasses
import inspect
import time
import unittest
from unittest.mock import patch

import sleep_observation_json_core as core


class IndependentContractCases(unittest.TestCase):
    def decode(self, raw):
        with patch.object(core, '_monotonic_ns', return_value=100):
            return core.decode_payload(raw, deadline_ns=1000000000)

    def refusal(self, raw, error, metrics):
        result = self.decode(raw)
        self.assertIs(type(result), core.Refused)
        self.assertEqual(dataclasses.astuple(result.error), error)
        self.assertEqual(dataclasses.astuple(result.metrics), metrics)
        self.assertEqual(result.kind, 'JSON_CORE_REFUSED')
        self.assertFalse(hasattr(result, 'value'))
        return result

    def accepted(self, raw, value, metrics):
        result = self.decode(raw)
        self.assertIs(type(result), core.Decoded)
        self.assertEqual(result.value, value)
        self.assertEqual(dataclasses.astuple(result.metrics), metrics)
        self.assertEqual(result.kind, 'JSON_CORE_DECODED')
        return result

    def test_01_rejected_input_hooks_not_invoked(self):
        class Trap:
            def hook(self, *args):
                raise AssertionError('Rejected-input hook invoked')
            __len__ = __bytes__ = __iter__ = __repr__ = __getitem__ = __eq__ = hook
        result = self.decode(Trap())
        self.assertEqual(dataclasses.astuple(result.error), ('INPUT_TYPE', 0, (), None, None, None, None))
        self.assertEqual(dataclasses.astuple(result.metrics), (0, 0, 0, 0, 0, 0, 0))

    def test_02_rejected_deadline_hooks_not_invoked(self):
        class Trap:
            def hook(self, *args):
                raise AssertionError('Rejected-deadline hook invoked')
            __int__ = __repr__ = __gt__ = __le__ = __add__ = hook
        with patch.object(core, '_monotonic_ns', return_value=100):
            result = core.decode_payload(b'{}', deadline_ns=Trap())
        self.assertEqual(dataclasses.astuple(result.error), ('DEADLINE_ARGUMENT', 0, (), None, None, None, None))
        self.assertEqual(dataclasses.astuple(result.metrics), (2, 0, 0, 0, 0, 0, 0))

    def test_03_live_monotonic_explicit_deadline(self):
        result = core.decode_payload(b'{"n":0}', deadline_ns=time.monotonic_ns() + 5000000000)
        self.assertIs(type(result), core.Decoded)
        self.assertEqual(result.value, {'n': core.JsonNumber('0', 5, 6)})
        self.assertEqual(dataclasses.astuple(result.metrics), (7, 7, 2, 1, 1, 1, 1))

    def test_04_exact_public_dataclass_shapes(self):
        shapes = {core.JsonNumber: ('lexeme', 'start', 'end'),
                  core.DecodeMetrics: ('input_bytes', 'consumed_bytes', 'nodes', 'names', 'max_container_depth', 'max_string_utf16_units', 'max_number_bytes'),
                  core.DecodeError: ('code', 'byte_offset', 'location', 'name_span', 'limit_name', 'limit', 'observed'),
                  core.Decoded: ('value', 'metrics', 'kind'),
                  core.Refused: ('error', 'metrics', 'kind')}
        for cls, names in shapes.items():
            self.assertEqual(tuple(field.name for field in dataclasses.fields(cls)), names)
            self.assertTrue(cls.__dataclass_params__.frozen)
            self.assertEqual(cls.__slots__, names)
        self.assertEqual(core.decode_payload.__annotations__, {'payload': bytes, 'deadline_ns': int, 'return': core.DecodeResult})
        self.assertEqual(inspect.signature(core.decode_payload).parameters['deadline_ns'].default, inspect.Parameter.empty)

    def test_05_number_spans_follow_original_unicode_bytes(self):
        raw = b'{"\xc3\xa9":-0.50E-2}'
        self.accepted(raw, {'\u00e9': core.JsonNumber('-0.50E-2', 6, 14)}, (15, 15, 2, 1, 1, 1, 8))

    def test_06_literal_types_not_number_records(self):
        self.accepted(b'{"a":[false,null,true]}', {'a': [False, None, True]}, (23, 23, 5, 1, 2, 1, 0))

    def test_07_empty_name_duplicate_and_no_value_admission(self):
        self.refusal(b'{"":0,"":1}', ('DUPLICATE_NAME', 6, (1,), (6, 8), None, None, None), (11, 8, 2, 2, 1, 0, 1))

    def test_08_sibling_nested_ordinals_and_span_owner(self):
        raw = b'{"a":0,"b":[[],{"x":0,"y":} ]}'
        self.refusal(raw, ('SYNTAX', 26, (1, 1, 1), (22, 25), None, None, None), (30, 26, 6, 4, 3, 1, 1))

    def test_09_false_malformed_prefix_reservation(self):
        self.refusal(b'{"k":fAlse}', ('SYNTAX', 6, (0,), (1, 4), None, None, None), (11, 6, 2, 1, 1, 1, 0))

    def test_10_null_malformed_prefix_reservation(self):
        self.refusal(b'{"k":nulX}', ('SYNTAX', 8, (0,), (1, 4), None, None, None), (10, 8, 2, 1, 1, 1, 0))

    def test_11_completed_literal_missing_container_close(self):
        self.refusal(b'{"k":true', ('SYNTAX', 9, (), None, None, None, None), (9, 9, 2, 1, 1, 1, 0))

    def test_12_comma_opened_name_whitespace_slot(self):
        self.refusal(b'{"a":0, "b":1}', ('WHITESPACE', 7, (1,), None, None, None, None), (14, 7, 2, 1, 1, 1, 1))

    def test_13_array_unrecognized_value_no_node_reservation(self):
        self.refusal(b'{"a":[0,X]}', ('SYNTAX', 8, (0, 1), None, None, None, None), (11, 8, 3, 1, 2, 1, 1))

    def test_14_escaped_slash_name_alias_duplicate(self):
        self.refusal(b'{"/":0,"\\/":1}', ('DUPLICATE_NAME', 7, (1,), (7, 11), None, None, None), (14, 11, 2, 2, 1, 1, 1))

    def test_15_bom_scalar_inside_string_not_payload_bom(self):
        self.accepted(b'{"x":"\xef\xbb\xbf"}', {'x': '\ufeff'}, (11, 11, 2, 1, 1, 1, 0))

    def test_16_del_scalar_allowed(self):
        self.accepted(b'{"x":"\x7f"}', {'x': '\x7f'}, (9, 9, 2, 1, 1, 1, 0))

    def test_17_noncharacter_scalar_allowed(self):
        self.accepted(b'{"x":"\xef\xbf\xbf"}', {'x': '\uffff'}, (11, 11, 2, 1, 1, 1, 0))

    def test_18_reversed_surrogate_pair_no_atom_commit(self):
        raw = b'{"x":"a\\uDC00\\uD800"}'
        self.refusal(raw, ('SURROGATE', 7, (0,), (1, 4), None, None, None), (21, 7, 2, 1, 1, 1, 0))

    def test_19_split_surrogate_pair_no_atom_commit(self):
        raw = b'{"x":"a\\uD800\\n\\uDC00"}'
        self.refusal(raw, ('SURROGATE', 7, (0,), (1, 4), None, None, None), (23, 7, 2, 1, 1, 1, 0))

    def test_20_invalid_second_unicode_escape_byte_owner(self):
        raw = b'{"x":"a\\uD800\\uDC0Z"}'
        self.refusal(raw, ('STRING_ESCAPE', 13, (0,), (1, 4), None, None, None), (21, 7, 2, 1, 1, 1, 0))

    def test_21_invalid_third_utf8_byte_lead_offset(self):
        raw = b'{"x":"a\xe2\x82Z"}'
        self.refusal(raw, ('UTF8', 7, (0,), (1, 4), None, None, None), (12, 7, 2, 1, 1, 1, 0))

    def test_22_prior_completed_string_maximum_survives_refusal(self):
        raw = b'{"abcd":"123456","z":"q\\q"}'
        self.refusal(raw, ('STRING_ESCAPE', 23, (1,), (17, 20), None, None, None), (27, 23, 3, 2, 1, 6, 0))

    def test_23_unclosed_partial_key_span_and_maximum(self):
        self.refusal(b'{"abcd', ('SYNTAX', 6, (0,), (1, 6), None, None, None), (6, 6, 1, 1, 1, 4, 0))

    def test_24_64_byte_huge_exponent_remains_inert(self):
        token = b'1e' + b'9' * 62
        raw = b'{"x":' + token + b'}'
        self.assertEqual(len(token), 64)
        self.accepted(raw, {'x': core.JsonNumber(token.decode('ascii'), 5, 69)}, (70, 70, 2, 1, 1, 1, 64))

    def test_25_incomplete_64_byte_exponent_sign(self):
        token = b'9' * 62 + b'e+'
        raw = b'{"x":' + token + b'}'
        self.refusal(raw, ('NUMBER_GRAMMAR', 69, (0,), (1, 4), None, None, None), (70, 69, 2, 1, 1, 1, 64))

    def test_26_65th_legal_exponent_digit_bound(self):
        token = b'9' * 62 + b'e+0'
        raw = b'{"x":' + token + b'}'
        self.refusal(raw, ('NUMBER_BYTES', 5, (0,), (1, 4), 'number_bytes', 64, 65), (71, 69, 2, 1, 1, 1, 64))

    def test_27_negative_leading_zero_number_prefix(self):
        self.refusal(b'{"x":-01}', ('NUMBER_GRAMMAR', 7, (0,), (1, 4), None, None, None), (9, 7, 2, 1, 1, 1, 2))

    def test_28_incomplete_number_at_eof(self):
        self.refusal(b'{"x":1e-', ('NUMBER_GRAMMAR', 8, (0,), (1, 4), None, None, None), (8, 8, 2, 1, 1, 1, 3))

    def test_29_completed_number_at_eof_is_separator_failure(self):
        self.refusal(b'{"x":1e-0', ('SYNTAX', 9, (), None, None, None, None), (9, 9, 2, 1, 1, 1, 4))

    def test_30_depth64_pending_key_trail_is64_segments(self):
        raw = b'{"a":' * 64
        self.assertEqual(len(raw), 320)
        self.refusal(raw, ('SYNTAX', 320, (0,) * 64, (316, 319), None, None, None), (320, 320, 64, 64, 64, 1, 0))

    def test_31_depth65_container_atomic_refusal_direct_key(self):
        raw = b'{"a":' * 64 + b'{}' + b'}' * 64
        self.refusal(raw, ('DEPTH', 320, (0,) * 64, (316, 319), 'container_depth', 64, 65), (386, 320, 64, 64, 64, 1, 0))

    def test_32_private_depth_refusal_does_not_increment_node(self):
        scanner = core._Scanner(b'[', 1000000000)
        scanner.nodes = 64
        scanner.depth = 64
        scanner.stack = [core._Frame([], ()) for _ in range(64)]
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_value(True)
        self.assertEqual(dataclasses.astuple(stop.exception.error), ('DEPTH', 0, (), None, 'container_depth', 64, 65))
        self.assertEqual(dataclasses.astuple(scanner.metrics()), (1, 0, 64, 0, 64, 0, 0))

    def test_33_private_local_name_refusal_preserves_global_counter(self):
        scanner = core._Scanner(b'"x"', 1000000000)
        scanner.names = 100
        frame = core._Frame({}, (), ordinal=64)
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_name(frame)
        self.assertEqual(dataclasses.astuple(stop.exception.error), ('OBJECT_NAMES', 0, (), None, 'object_names', 64, 65))
        self.assertEqual((scanner.names, frame.ordinal), (100, 64))

    def test_34_private_global_name_refusal_preserves_local_counter(self):
        scanner = core._Scanner(b'"x"', 1000000000)
        scanner.names = 65536
        frame = core._Frame({}, (), ordinal=3)
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_name(frame)
        self.assertEqual(dataclasses.astuple(stop.exception.error), ('NAMES', 0, (), None, 'names', 65536, 65537))
        self.assertEqual((scanner.names, frame.ordinal), (65536, 3))

    def test_35_deadline_wins_over_private_bound_attempt(self):
        scanner = core._Scanner(b'[', 100)
        scanner.nodes = 65536
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_value(True)
        self.assertEqual(dataclasses.astuple(stop.exception.error), ('DEADLINE', 0, (), None, None, None, None))
        self.assertEqual(scanner.nodes, 65536)

    def test_36_partial_key_deadline_span(self):
        raw = b'{"' + b'a' * 4096 + b'":0}'
        with patch.object(core, '_monotonic_ns', side_effect=(100, 100, 100, 200)):
            result = core.decode_payload(raw, deadline_ns=200)
        self.assertEqual(dataclasses.astuple(result.error), ('DEADLINE', 4096, (0,), (1, 4096), None, None, None))
        self.assertEqual(dataclasses.astuple(result.metrics), (4102, 4096, 1, 1, 1, 4094, 0))

    def test_37_incomplete_nested_key_owns_its_span(self):
        raw = b'{"a":[{"bc\\'
        self.refusal(raw, ('STRING_ESCAPE', 10, (0, 0, 0), (7, 10), None, None, None), (11, 10, 3, 2, 3, 2, 0))

    def test_38_missing_array_separator_after_complete_container(self):
        self.refusal(b'{"a":[{}{}]}', ('SYNTAX', 8, (0,), None, None, None, None), (12, 8, 3, 1, 3, 1, 0))

    def test_39_trailing_newline_no_new_reservation(self):
        self.refusal(b'{"a":[]}\r\n', ('WHITESPACE', 8, (), None, None, None, None), (10, 8, 2, 1, 2, 1, 0))

    def test_40_unrecognized_value_precedes_resource_reservation(self):
        raw = b'{"a":[' + b','.join([b'0'] * 65534) + b',X]}'
        self.assertEqual(len(raw), 131077)
        self.refusal(raw, ('SYNTAX', 131074, (0, 65534), None, None, None, None), (131077, 131074, 65536, 1, 2, 1, 1))


if __name__ == '__main__':
    unittest.main(verbosity=2)
