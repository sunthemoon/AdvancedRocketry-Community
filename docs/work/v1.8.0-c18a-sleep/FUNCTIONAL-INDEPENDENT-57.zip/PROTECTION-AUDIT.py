"""Read-only final Task57 protected-state observation."""
import hashlib
import json
from pathlib import Path
import subprocess

MAIN = 'D:/GitHub/AdvancedRocketry-Community'
SOURCE = 'D:/GitHub/arce-v180-sleep-json-core-20261009-53'
commands = [(['git', '-C', MAIN, 'status', '--porcelain=v1'], MAIN),
            (['git', '-C', MAIN, 'branch', '--show-current'], MAIN),
            (['git', '-C', MAIN, 'rev-parse', 'HEAD'], MAIN),
            (['git', '-C', SOURCE, 'status', '--porcelain=v1'], SOURCE),
            (['git', '-C', SOURCE, 'rev-parse', 'HEAD'], SOURCE),
            (['git', '-C', MAIN, 'diff-tree', '--check',
              'e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1',
              'fa83657f89095a78bfb97ac39918ee1b74139d5b'], MAIN)]
rows = []
for argv, cwd in commands:
    result = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=30)
    assert len(result.stdout) <= 262144 and len(result.stderr) <= 262144
    rows.append({'argv': argv, 'cwd': cwd, 'exit_code': result.returncode,
                 'stdout': result.stdout.decode('utf-8'),
                 'stderr': result.stderr.decode('utf-8'),
                 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
    assert result.returncode == 0
own_temp = Path(__file__).resolve().parent
leaf = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57')
assert not (own_temp / '__pycache__').exists()
assert not (leaf / '__pycache__').exists()
print(json.dumps({'commands': rows, 'no_pycache': True,
                  'own_leaf_bytes_before_receipt': sum(p.stat().st_size for p in leaf.iterdir() if p.is_file()),
                  'peer_or_project_writes': 'NONE_PERFORMED_BY_TASK57'}, indent=2))
