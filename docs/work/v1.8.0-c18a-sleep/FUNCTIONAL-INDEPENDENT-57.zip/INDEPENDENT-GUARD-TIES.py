"""Task57 cases41/42: private tie-guard full diagnostic snapshots only."""
import dataclasses
import unittest
from unittest.mock import patch

import sleep_observation_json_core as core


class IndependentGuardTieCases(unittest.TestCase):
    def test_41_private_object_global_names_tie_complete_snapshot(self):
        scanner = core._Scanner(b'"x"', 1000000000)
        scanner.names = 65536
        frame = core._Frame({}, (), ordinal=64)
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_name(frame)
        self.assertEqual(dataclasses.astuple(stop.exception.error),
                         ('OBJECT_NAMES', 0, (), None, 'object_names', 64, 65))
        self.assertEqual(dataclasses.astuple(scanner.metrics()), (3, 0, 0, 65536, 0, 0, 0))
        self.assertEqual(frame.ordinal, 64)

    def test_42_private_nodes_depth_tie_complete_snapshot(self):
        scanner = core._Scanner(b'[', 1000000000)
        scanner.nodes = 65536
        scanner.names = 65536
        scanner.depth = 64
        scanner.stack = [core._Frame([], ()) for _ in range(64)]
        with patch.object(core, '_monotonic_ns', return_value=100), self.assertRaises(core._Stop) as stop:
            scanner.reserve_value(True)
        self.assertEqual(dataclasses.astuple(stop.exception.error),
                         ('NODES', 0, (), None, 'nodes', 65536, 65537))
        self.assertEqual(dataclasses.astuple(scanner.metrics()), (1, 0, 65536, 65536, 64, 0, 0))
        self.assertEqual(len(scanner.stack), 64)


if __name__ == '__main__':
    unittest.main(verbosity=2)
