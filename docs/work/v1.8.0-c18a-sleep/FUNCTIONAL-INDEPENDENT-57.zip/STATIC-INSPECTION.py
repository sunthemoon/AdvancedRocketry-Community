"""Task57 bounded in-memory compile and AST/source inventory; no runtime resource probe."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = []
for name in ('sleep_observation_json_core.py', 'test_sleep_observation_json_core.py', 'independent_cases.py'):
    raw = (ROOT / name).read_bytes()
    tree = ast.parse(raw, filename=name)
    compile(tree, name, 'exec')
    methods = [node.name for node in ast.walk(tree)
               if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    row = {'file': name, 'bytes': len(raw), 'lines': len(raw.splitlines()),
           'sha256': hashlib.sha256(raw).hexdigest(), 'test_methods': methods,
           'test_method_count': len(methods), 'compile': 'PASS'}
    if name == 'sleep_observation_json_core.py':
        imports = [ast.unparse(node) for node in ast.walk(tree)
                   if isinstance(node, (ast.Import, ast.ImportFrom))]
        calls = sorted({ast.unparse(node.func) for node in ast.walk(tree)
                        if isinstance(node, ast.Call)})
        row['imports'] = imports
        row['call_targets'] = calls
        row['parser_value_call_sites'] = [node.lineno for node in ast.walk(tree)
                                         if isinstance(node, ast.Call) and ast.unparse(node.func) == 'self.value']
        row['prohibited_eager_conversion_calls_present'] = any(
            target in ('int', 'float', 'Decimal', 'json.loads', 'json.load') for target in calls)
        assert imports == ['from dataclasses import dataclass, field',
                           'from time import monotonic_ns as _monotonic_ns']
        assert not row['prohibited_eager_conversion_calls_present']
        assert row['parser_value_call_sites'] == [328, 372]
    rows.append(row)
assert rows[1]['test_method_count'] == 32
assert rows[2]['test_method_count'] == 40
assert not (ROOT / '__pycache__').exists()
print(json.dumps({'rows': rows, 'no_pycache': True, 'resource_measurement': 'NOT_EXECUTED'}, indent=2))
