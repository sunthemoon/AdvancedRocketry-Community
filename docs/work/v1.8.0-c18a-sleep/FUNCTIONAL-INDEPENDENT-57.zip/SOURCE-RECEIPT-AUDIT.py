"""Task57 bounded read-only audit of source53's actual sealed packet."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-source-20261009-53')
REPO = 'D:/GitHub/AdvancedRocketry-Community'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    assert path.parent == LEAF
    assert path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(), 'st_file_attributes', 0) & 1024)
    assert path.stat().st_size <= 262144
    return path.read_bytes()


files = sorted(LEAF.iterdir())
assert len(files) <= 512
assert len({p.name.casefold() for p in files}) == len(files)
assert sum(p.stat().st_size for p in files) <= 4194304
for ancestor in (LEAF, LEAF.parent, LEAF.parent.parent, LEAF.parent.parent.parent):
    assert not ancestor.is_symlink()
    assert not (getattr(ancestor.stat(), 'st_file_attributes', 0) & 1024)

report = read(LEAF / 'REPORT.md')
assert sha(report) == '619bd07be187c02fee5d003fd71a161aa1be7070aaaa75385430a27c28d62e4e'
assert (len(report), len(report.splitlines())) == (21017, 119)
correction = read(LEAF / 'DEVELOPMENT-CORRECTIONS.md')
assert sha(correction) == '18e3b019d5d8cc8794c0228d767c1f005e73da951a0798820dd3891a972aec28'
manifest = read(LEAF / 'SHA256SUMS.txt')
seal = json.loads(read(LEAF / 'SEAL-RESULT.json'))
expected_exclusions = ['SEAL-RESULT.json', 'SHA256SUMS.txt']
assert seal['exact_exclusions'] == expected_exclusions
assert seal['exit_code'] == 0 and seal['timed_out'] is False
assert seal['output_limit_exceeded'] is False and seal['drain_complete'] is True
assert seal['timeout_seconds'] == 180 and seal['stream_limit_bytes'] == 262144
rows = []
for line in manifest.decode('utf-8').splitlines():
    digest, name = line.split('  ', 1)
    assert len(digest) == 64 and all(char in '0123456789abcdef' for char in digest)
    assert name == Path(name).name and name not in expected_exclusions
    raw = read(LEAF / name)
    assert sha(raw) == digest
    rows.append({'name': name, 'bytes': len(raw), 'sha256': digest})
assert len({row['name'].casefold() for row in rows}) == len(rows)
assert {p.name for p in files} == {row['name'] for row in rows} | set(expected_exclusions)
verification = seal['verification']
assert verification['all_covered_match'] is True
assert verification['covered_files'] == len(rows)
assert verification['covered_bytes'] == sum(row['bytes'] for row in rows)
assert verification['manifest_bytes'] == len(manifest)
assert verification['manifest_sha256'] == sha(manifest)
assert verification['exact_exclusions'] == expected_exclusions
assert verification['report_sha256'] == sha(report)
assert verification['report_bytes'] == len(report)
assert verification['report_lines'] == len(report.splitlines())
for label in ('stdout', 'stderr'):
    raw = base64.b64decode(seal[label + '_base64'], validate=True)
    assert len(raw) == seal[label + '_bytes'] == seal[label + '_observed_bytes']
    assert sha(raw) == seal[label + '_sha256']
assert json.loads(base64.b64decode(seal['stdout_base64'])) == verification
assert base64.b64decode(seal['stderr_base64']) == b''
ack = json.loads(read(LEAF / 'ROOT-ACK.json'))
assert ack['sender'] == '/root' and ack['complete_exact_report_read'] is True
assert ack['report_sha256'] == sha(report)
assert (ack['report_bytes'], ack['report_lines']) == (len(report), len(report.splitlines()))

receipts = []
nonzero = []
maximum_stream = 0
for path in files:
    if not path.name.endswith('.command.json'):
        continue
    receipt = json.loads(read(path))
    assert receipt['timeout_seconds'] == 180
    assert receipt['timed_out'] is False and receipt['output_limit_exceeded'] is False
    assert receipt['stream_limit_bytes'] == 262144
    assert receipt['aggregate_limit_bytes'] == 4194304
    assert receipt.get('drain_complete', True) is True
    for stream in receipt['streams']:
        target = Path(stream['path'])
        assert target.parent == LEAF
        raw = read(target)
        assert len(raw) == stream['bytes'] == stream['observed_bytes']
        assert stream['complete'] is True and sha(raw) == stream['sha256']
        maximum_stream = max(maximum_stream, len(raw))
    receipts.append(path.name)
    if receipt['exit_code'] != 0:
        nonzero.append({'receipt': path.name, 'exit_code': receipt['exit_code']})
assert nonzero == [{'receipt': '16-functional-development-01.command.json', 'exit_code': 1}]
assert len(receipts) == 46
patch = read(LEAF / 'SOURCE.patch')
git_patch = subprocess.check_output(['git', '-C', REPO, 'diff', '--binary',
                                    'e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1',
                                    'fa83657f89095a78bfb97ac39918ee1b74139d5b'])
assert patch == git_patch
assert sha(patch) == 'bc4cf724f5dfd19f4cff19c69c91390a0a2e3d73df2d4043cc800e116ef1aa83'
print(json.dumps({'report': {'bytes': len(report), 'lines': len(report.splitlines()), 'sha256': sha(report)},
                  'correction_sha256': sha(correction),
                  'receipt_count': len(receipts), 'preserved_nonzero': nonzero,
                  'maximum_raw_stream_bytes': maximum_stream,
                  'actual_custody': verification,
                  'full_files': len(files), 'full_bytes': sum(p.stat().st_size for p in files),
                  'seal_result_bytes': (LEAF / 'SEAL-RESULT.json').stat().st_size,
                  'seal_result_sha256': sha(read(LEAF / 'SEAL-RESULT.json')),
                  'fixed_git_patch_bytes': len(patch), 'fixed_git_patch_sha256': sha(patch),
                  'no_resource_native_or_code_acceptance_inferred': True}, indent=2))
