"""Task57 own final evidence/compile/receipt audit, not custody or qualification."""
import ast
import hashlib
import json
from pathlib import Path

LEAF = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57')
TEMP = Path(__file__).resolve().parent
names = sorted(LEAF.iterdir())
assert len(names) <= 512 and len({p.name.casefold() for p in names}) == len(names)
assert all(p.is_file() and not p.is_symlink() for p in names)
assert not any(getattr(p.stat(), 'st_file_attributes', 0) & 1024 for p in names)
assert not (LEAF / '__pycache__').exists() and not (TEMP / '__pycache__').exists()
assert sum(p.stat().st_size for p in names) + 2 * 262144 + 8192 <= 4194304
receipts = []
nonzero = []
maximum = 0
for path in names:
    if not path.name.endswith('.command.json'):
        continue
    value = json.loads(path.read_text(encoding='utf-8'))
    assert value['external_timeout_seconds'] == 180 and value['timed_out'] is False
    for label, stream in value['streams'].items():
        target = LEAF / path.name.replace('.command.json', '.' + label + '.txt')
        raw = target.read_bytes()
        assert len(raw) == stream['bytes_retained'] == stream['bytes_total']
        assert stream['overflow'] is False
        assert hashlib.sha256(raw).hexdigest() == stream['sha256_retained'] == stream['sha256_total']
        maximum = max(maximum, len(raw))
    assert value['source_hashes_before'] == value['source_hashes_after']
    receipts.append(path.name)
    if value['exit_code'] != 0:
        nonzero.append({'receipt': path.name, 'exit_code': value['exit_code']})
assert len(receipts) == 7
assert nonzero == [{'receipt': 'functional-source-audit.command.json', 'exit_code': 1}]
for path in names:
    if path.suffix == '.py':
        compile(path.read_bytes(), str(path), 'exec')
method_counts = {}
for name, count in (('test_sleep_observation_json_core.py', 32),
                    ('independent_cases.py', 40), ('independent_guard_ties.py', 2)):
    tree = ast.parse((TEMP / name).read_bytes())
    actual = sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_') for node in ast.walk(tree))
    assert actual == count
    method_counts[name] = actual
report = (LEAF / 'REPORT.md').read_bytes()
assert not (LEAF / 'SHA256SUMS.txt').exists() and not (LEAF / 'SEAL-RESULT.json').exists()
print(json.dumps({'report_bytes': len(report), 'report_lines': len(report.splitlines()),
                  'report_sha256': hashlib.sha256(report).hexdigest(),
                  'earlier_receipts': receipts, 'preserved_nonzero': nonzero,
                  'maximum_raw_stream_bytes': maximum,
                  'own_files_before_this_receipt': len(names),
                  'own_bytes_before_this_receipt': sum(p.stat().st_size for p in names),
                  'all_own_python_helpers_compile_in_memory': True,
                  'test_method_counts': method_counts, 'no_pycache': True,
                  'custody_seal_executed': False, 'resource_native_gate_acceptance': False}, indent=2))
