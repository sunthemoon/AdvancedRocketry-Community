# Task57 independent actual offline JSON functional-core review

## Findings and recommendation

**R57-01 - Low: the committed paired test suite omits the explicit 64-byte huge-exponent inertness boundary.**
At [test_sleep_observation_json_core.py:298-305](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/test_sleep_observation_json_core.py#L298), the committed fixtures test short huge exponents and a 64-digit integer, but not the frozen37 Numbers family's explicit "64-byte huge exponent" case. An integer token at the byte limit does not exercise exponent-state continuation at that same limit. Add an independently asserted 64-byte exponent lexeme to the paired suite; retain all existing assertions and limits.

Bounded reproduction/verification: Task57 independent case 24 constructs `b'{"x":' + b'1e' + b'9' * 62 + b'}'`, independently asserts token length 64, and expects `JsonNumber('1e' + '9'*62, 5, 69)` with metrics `(70,70,2,1,1,1,64)`. The unchanged decoder passes this case. Cases 25/26 additionally check incomplete exponent-sign grammar versus a legal 65th exponent digit. This is a repository regression-coverage gap, not a demonstrated decoder defect or numeric-expansion failure. No correction was made by Task57, and the fixed reviewed commit is not rebound to a future correction.

**R57-02 - Low: the simultaneous-bound regression assertions do not check the complete diagnostics required by43.**
At [test_sleep_observation_json_core.py:393-405](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/test_sleep_observation_json_core.py#L393), the local/global-name tie and node/depth tie assert only `.error.code` plus selected counters, not the complete DecodeError and DecodeMetrics snapshots. Addendum43's Verification dependency explicitly requires all diagnostic fields, including bound name/limit/observed, admitted-work metrics and precedence. Retain the private nature of these checks and strengthen their oracle rather than changing bounds.

Bounded verification: independent private cases 41/42 require full tuples `('OBJECT_NAMES',0,(),None,'object_names',64,65)` and `('NODES',0,(),None,'nodes',65536,65537)`, complete metrics `(3,0,0,65536,0,0,0)` and `(1,0,65536,65536,64,0,0)`, and unchanged local ordinal/stack respectively. Both pass unchanged code. They do not fabricate a reachable accepted document or establish a code failure; this is a committed test-oracle gap.

No material decoder code defect was identified by the complete two-file inspection, independent paired rerun, 42 separately named contract cases, and bounded evidence audit described below. This statement is limited to that evidence; it does not prove absence of defects or qualify memory, lifetime native peaks, latency, source compatibility, native execution, or any release Gate.

The existing resource/platform dependency, including R49-01 and the unchanged finite resource contract, remains open. It is not a new Task57 code finding. Recommendation: retain both Low findings, add their paired regressions in a separately assigned source correction, and separately complete the unchanged qualification prerequisites before claiming full decoder qualification or integrating a runtime caller.

## Exact reviewed scope and immutable identities

Task57 is a fresh delegated independent reviewer, not Root or source53's author. No further delegation or persona was used. Root coordinates OpenPet. Read-only scope is the actual fixed Git diff, complete frozen contract, source53's actual final report/correction/receipts/custody, narrow adjacent conventions, and finite functional verification. No acceptance authority, source correction, project edit, or Main integration is exercised.

- Task: [SLEEP-JSON-CORE-INDEPENDENT-TASK-57.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-CORE-INDEPENDENT-TASK-57.md), 5504 bytes /81 lines, SHA256 `5c8bac4a38836d433a83a2cc7ab87f95c7c902f2f7e111e27a99bf92479cc6aa`.
- Actual Git commit: `fa83657f89095a78bfb97ac39918ee1b74139d5b`, verified type `commit`, message `feat(sleep): add bounded offline JSON core`, sole parent `e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1`.
- Actual branch/worktree: `codex/v1.8.0-sleep-json-core`, `D:/GitHub/arce-v180-sleep-json-core-20261009-53`.
- Actual fixed diff: precisely the two added files below, 823 insertions. Fixed `git diff-tree --check` exits 0. No production/native/Forge source or central file is changed by that commit.

| Exact postimage | Git blob | Bytes / lines | SHA256 |
| --- | --- | --- | --- |
| scripts/sleep_observation_json_core.py | a94355efcaca7ae7da628c3f9e4dd379859493aa | 14387 /397 | cdf4b6fa93900f41f2ba9e524bc16dbbaec47f739efd9c943fac6864005711d0 |
| scripts/test_sleep_observation_json_core.py | 249e3b30800e654da3db85858bd4d2514cae11c1 | 23605 /426 | ac44ffdadc879f68b56a8fe8c243c9a418d7d5c6071ce37744b68fd22d3257d1 |

Only these exact Git blob bytes were copied to the new own Temp directory. Every command receipt checks their SHA256 before and after execution; all match. Production source is not duplicated in this evidence leaf. Main's possible docs-only movement does not change the fixed source/contract identities.

| Completely read normative input | Bytes / lines | Independently checked SHA256 |
| --- | --- | --- |
| OFFLINE-CORE-CONTRACT-FREEZE-52.md at fixed e21 parent | 7949 /120 | 445be05d7e086b0d2d346f239f6ae71c896941f77fe7475eb51e9666974826ae |
| external 37 PROPOSED-OFFLINE-JSON-CORE-01.md | 19096 /271 | f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0 |
| external 43 PROPOSED-DIAGNOSTIC-CONVENTION-01.md | 15960 /244 | 69f6d6b85379b23d67566ead27db5d75e6ef039066e28614f7767ebf29298048 |

Their complete documents, not summaries or author conclusions, govern review. Historical PROPOSED wording in the immutable packets is not edited. Actual metadata is retained in [NORMATIVE-IDENTITIES.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57/NORMATIVE-IDENTITIES.json).

## Complete preparation and protected state

Before any own helper/snapshot write, Task57 completely read working Main AGENTS.md and every mandated config/product/principles/roadmap/exact-v1.8/test-plan/Gates/post-1.0/quality/parallel-governance file, actual CURRENT_VERSION/GATE_STATUS, previous v1.7 Gate record, actual status/branch/HEAD/worktrees, and live collaboration agents. These were narrow complete UTF-8 reads. The early read outputs remain transcript-only; they are not represented as captured historical disk receipts.

The actual Main AGENTS.md is 15797 bytes /327 lines, SHA256 `c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`. Main was observed on codex/v1.8.0-classic-content at `0dcfaf980e4a4236ff5e3c8630286b40b34eebb1`, with pre-existing modified AGENTS.md and many untracked documentation/archive entries. The separately captured protected-state audit observed the same HEAD/branch and retained those entries. Source53's own worktree is clean at fixed fa83657. No unrelated file, index, branch, HEAD, world, process, or sealed packet was modified or cleaned by Task57.

The release acceptance cursor remains v1.0.0 IN_PROGRESS; active development is separately v1.8.0. v1.7 and all inherited/current Required Gates remain open. The development exception is not release approval.

[PREPARATION.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57/PREPARATION.md) preserves failed guessed version/test paths, unavailable `py` launcher, non-evidence display/command preparation limitations, successful discovery of actual files/executable, and two pre-execution independent-fixture arithmetic corrections. No failed functional test was retried, removed, relaxed, or relabeled passing.

## Code reasoning against complete 37/43

The following is source reasoning supported by the cited executions, not a claim of exhaustive test coverage:

- [Records/API and preflight](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L10): exact public signature, frozen slotted dataclass fields, fixed result kinds, and inert JsonNumber records match the contract. Lines 380-391 sample entry time and enforce exact bytes, byte-size, exact-int deadline type/ceiling, and expiry precedence. Rejected-object hooks are not invoked; oversized input keeps its actual length and otherwise zero preflight metrics.
- [Atomic reservations](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L127): deadline precedes node/depth or local/global-name guards. Both guards pass before counters commit. Nodes precede depth; object names precede global names. Invalid initials do not reserve a token, whereas malformed recognized prefixes retain successful reservations. Inclusive constants remain 524288/65536/65536/64/64/4096/64 with no public override.
- [Strings and canonical UTF-8](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L151): bounded lookahead rejects invalid lead/continuation, overlong, truncated, surrogate, and above-U+10FFFF encodings. Simple escapes/four-hex escapes/high-low pairs form indivisible admission atoms. A low surrogate alone or missing/wrong immediate partner refuses. Admitted supplementary scalars add two UTF-16 units; a rejected atom adds no cursor or maximum units. Scratch is bounded before append, rather than decoding an unchecked full token.
- [Numbers](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L238): finite grammar states preserve sign/fraction/exponent spelling and original byte spans. Legal-prefix byte 65 refuses before commitment; illegal suffix adds no prospective byte. Only the bounded ASCII lexeme is decoded, with no int/float/Decimal expansion or projection. The discovered paired-test gap is R57-01 above, not a code-path failure.
- [Stack/tree ownership](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L297): run's explicit stack, not recursive value descent, bounds container depth. Scalar admission does not add depth. The admitted mutable dict/list tree is exclusively returned on success; refusal exposes no partial tree. Duplicate decoded names are compared before associated value admission/insertion, including escaped/raw aliases. Existing dict contents supply the bounded per-object duplicate set without a retained duplicate AST.
- [Diagnostics and deadline state](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L98): c is a contiguous committed prefix; maxima describe admitted partial tokens. Error offsets may differ from c. run assigns pending member/array ordinals, clears outer spans on nested entry/separator, and preserves current complete/partial key spans. At depth 64 a pending slot has at most 64 ordinal segments. Fixed diagnostics do not echo names/payloads. Checks precede allocation, before advances reach 4096 new bytes, and before success; complete UTF-8/pair atoms are not split. This is cooperative, not scheduling/preemption proof.
- [Exception and dependency boundaries](D:/GitHub/arce-v180-sleep-json-core-20261009-53/scripts/sleep_observation_json_core.py#L392): only deliberate _Stop is caught; unexpected implementation/MemoryError propagates. The sole imports are dataclasses and monotonic_ns. There is no file/process/network I/O, schema/framing/source policy, callback/plugin, cache, or runtime driver. Each class remains below 500 lines.

Adjacent existing classic_inventory_fixture_json.py and its paired test were read completely for conventions. Their eager text decode, recursive role/schema parser, whitespace admission, immutable tree and float projection are materially different contracts; no requirement to reuse those behaviors was inferred.

## Actual independently executed commands, counts, and receipts

Exact executable is `D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe`, Python 3.13.15 64-bit AMD64, executable SHA256 `85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd`. No installation or platform-binding/resource probe was performed.

For each row the parent command was that executable with `-B` and this leaf's receipt_runner.py plus the row's case argument. The actual immediate child argv is `[exact executable, '-B', absolute Temp/<file>]`; cwd is `C:/Users/Administrator/AppData/Local/Temp/arce-sleep-json-functional-review-20261009-57`. Parent ceilings are fixed 180 seconds; split streams retain at most 262144 bytes with actual argv/cwd/UTC/exit/length/hash/overflow/timeout. No child was terminated. All supplied decoder calls have explicit absolute deadlines; the one live-clock check uses 5 seconds, and controlled-clock checks remain private test scaffolding.

| Parent case / actual child file | UTC start  ->  end on 2026-10-09 | Exit /result | stdout /stderr bytes |
| --- | --- | --- | --- |
| paired /test_sleep_observation_json_core.py | 10:48:35.692055  -> 10:48:37.215961 | 0 /32 original unittest methods, OK | 0 /136 |
| independent /independent_cases.py | 10:51:24.712054  -> 10:51:25.409404 | 0 /40 separately named methods, OK | 0 /5544 |
| static /static_inspection.py | 10:51:44.192981  -> 10:51:44.281428 | 0 /in-memory compile and bounded AST inventory | 6437 /0 |
| protected /protection_audit.py | 10:53:20.213994  -> 10:53:20.681936 | 0 /read-only Git/protected-state observation | 14107 /0 |
| source-audit /source_receipt_audit.py | 10:56:29.614393  -> 10:56:29.739796 | 1 /reviewer assumed 46 receipts; actual 47 | 0 /260 |
| source-audit-47 /source_receipt_audit_47.py | 10:57:42.631625  -> 10:57:42.796102 | 0 /additive exact 47-receipt/custody/Git-patch audit | 1263 /0 |
| guard-ties /independent_guard_ties.py | 11:02:29.989923  -> 11:02:30.114772 | 0 /2 additional private full-snapshot methods, OK | 0 /407 |
| final-audit /final_audit.py | 11:04:43.070242  -> 11:04:43.165879 | 0 /seven earlier receipt/hash checks, helper compile, method inventory; packet unsealed | 1027 /0 |

Raw/command files are named functional-<case>.command.json, .stdout.txt and .stderr.txt under this leaf. No stream overflow or timeout occurred. For empty streams SHA256 is `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| Nonempty raw stream | SHA256 |
| --- | --- |
| functional-paired.stderr.txt | 94ae279d9f824a90ee08763b86e553b58955d6d4a85daed39df82d9e0e1f2641 |
| functional-independent.stderr.txt | 508eb13ae1851a250fbfe40006220b2294cfdfcd2a96dd78a6d81f5f1f788e92 |
| functional-static.stdout.txt | 581132566caa7852515e64e1727543465229ea3e96e07d519467aa676c110c14 |
| functional-protected.stdout.txt | 871935da8d82eeb4bc094df93076eaa30be555ea07ff8fe7a0c1704d1751c5db |
| functional-source-audit.stderr.txt | 09d5623cc7572f15824821a8222befde21216709099c9a73519d4d35c92e2872 |
| functional-source-audit-47.stdout.txt | edcf773b66e1acdb6f9b958a4a26eef202bc792217498aa9f200a67c62def3cc |
| functional-guard-ties.stderr.txt | 4cc705309087317950b6c90a031c5cfcc448a937c2ca2498a6c4a889990e7d9b |
| functional-final-audit.stdout.txt | 104a1fbd396c4e13d200ff21f93cd9da163a93a37d3ec7060c05e6c0b73acb5d |

The original audit failure and helper are preserved unchanged. [AUDIT-CORRECTION.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57/AUDIT-CORRECTION.md) records that the actual sealed author packet includes newly recorded receipt 47 after the reviewer's earlier 46-file observation. The additive helper retains all original checks, binds 47, additionally requires exact prefixes 01..47 and final exact receipt name, and reaches the fixed Git-patch check. This is not an unchanged failed-cohort retry or relaxed functional assertion.

Test-method counts are not multiplied by subtests, source53's author runs, or repeated paired coverage. Task57 independently executed 32 original and 42 additional methods. The first 40 case names, fixture recipes and contract-derived expected full metrics/errors are retained in [INDEPENDENT-CASES.py](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57/INDEPENDENT-CASES.py), 12407 bytes /233 lines, SHA256 `521e8346f77dcd020a0f1fce06fcb95718358f003abd94eb1b117caea53f7d4c`. The additional two cases are [INDEPENDENT-GUARD-TIES.py](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-independent-20261009-57/INDEPENDENT-GUARD-TIES.py), SHA256 `0d48b1bbcbfbd163e1fc4f72eaf23be778e9c1dd27547756b2a84ab280c17472`. These are test evidence, not a third production module or native payload corpus.

Additional cases cover rejected-object/deadline hooks; real monotonic explicit deadline; exact API/record fields; Unicode original-byte numeric spans; literal/empty-name accounting; nested sibling ordinals/spans; malformed literal prefixes; completed token EOF versus pending-slot failures; comma-opened slots; escaped-slash duplicates; BOM/DEL/noncharacter in-string values; reversed/split/bad-second-escape atoms; UTF-8 lead offsets; prior/partial maxima; 64-byte huge-exponent/incomplete/65th-byte precedence; negative-zero grammar; 64/65-depth object slots; private atomic guards; partial-key deadline state; nested incomplete-key ownership; completed-container separators; trailing CRLF; and invalid lookahead at the actual node limit.

Cases 32-35 and 41/42 are explicitly seeded private guard checks, not accepted end-to-end payloads or native traces. The whole-name ceiling 65536 is dominated by the successful-tree node relationship and is not fabricated as an accepted document. In-memory AST checks confirm 32 paired/40 first independent methods, production imports/call inventory, no eager numeric conversion call, and run-only self.value call sites 328/372; the separate guard-ties receipt executes the two final methods. No __pycache__ was created.

## Source53 actual evidence attribution and custody

Task57 completely read the actual stable author [REPORT.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-source-20261009-53/REPORT.md), 21017 bytes /119 lines, SHA256 `619bd07be187c02fee5d003fd71a161aa1be7070aaaa75385430a27c28d62e4e`, plus the full DEVELOPMENT-CORRECTIONS.md, all four author functional receipts/raw stderr streams, relevant compile/push attribution, current capture/seal helper and actual Root acknowledgment/seal. Author conclusions were not used as the review oracle.

The author preserves development cohort 16 exit 1,26 tests/3 failed assertions; subsequent distinct cohorts 17/18/31 report 27/32/32 passing. Initial compile receipt 15 already identifies the final core SHA256, while its intermediate paired test SHA differs. The three correction explanations independently match byte arithmetic and 43: the original 4090-unit interval fixture could not reach the intended check; malformed key input length is 9; nested inner colon commits before the unexpected byte 19. Task57 did not relabel that failed cohort or infer an uncommitted intermediate tree as delivered source.

The read-only corrected audit independently verifies all 47 numbered source53 command receipts and split raw identities. Only cohort 16 has nonzero exit. All author receipts have actual 180-second ceiling, no timeout/overflow, complete retained streams, maximum raw 38394 bytes. The original helper's historical broader timeout permission and transcript-only/truncated-presentation limitations remain explicit in the author report; current custody does not repair their history. No timeout branch was exercised. The author push is recorded as normal non-force branch push, not a Main merge; Task57 did not perform a remote push.

The fixed committed patch is 39262 bytes /835 lines, SHA256 `bc4cf724f5dfd19f4cff19c69c91390a0a2e3d73df2d4043cc800e116ef1aa83`, independently equal to the fixed e21 -> fa83657 actual Git diff.

Actual source53 seal at 10:54:51.367460 -> 10:54:51.471954 UTC exited0. The audit verifies 150 covered files /450444 bytes and exact full 152 files /466848 bytes; manifest 14373 bytes, SHA256 `71e2b21e0c726174e2562f8e5ee3f257a307620016dfb4505317fa01677f7619`; sole seal-result 2031 bytes, SHA256 `acf320239f6a8411b9a022f0024e78908d70cf94dae655eacc3befdd1769fadc`. Exact exclusions are only SHA256SUMS.txt and SEAL-RESULT.json. All covered hashes, exact file-set coverage, regular contained files, bounded sizes, and no reparse ancestors/members match. Embedded stdout 377 bytes SHA256 `db3275170d673f1a1cd4080b2d1612756f624632e2cb9e39ae6004bcd0e8cf41` decodes to its stored verification object; stderr is empty. Actual exit/timeout/overflow/drain flags are checked, not inferred from permission or Root's relay. This is custody evidence only, not code/resource/native/Gate acceptance.

## Test/oracle/resource/recovery limitations and remaining qualifications

Finite tests and source reasoning do not enumerate every possible bounded document or every possible scheduling instant. Most deadlines are private controlled clocks; one short live-clock call proves ordinary API execution, not worst-case 60-second latency or interruption responsiveness. The checked iterative allocation bounds are design evidence, not measured native/traced 256-MiB guarantee, OS quota, preemption, or host-OOM recovery proof. Unexpected exceptions are deliberately not fabricated as successful refusal.

All decoder resource cases remain NOT_EXECUTED by Task57. The unchanged contract still requires at most 12 fresh finite cases, both traced peak and actual native process-lifetime peak <=268435456 bytes, decoder 60 seconds/external 180 seconds, capped split streams and 4-MiB case evidence. Platform-counter terminal coverage and its independent disposition remain separate prerequisites; no platform helper/counter was selected or bound here. Functional tests do not substitute sampled/current or self-query metrics for a lifetime peak.

Source-aware root/row/event/status/type/range/Gson 131072-byte accounting, source/native Unicode compatibility, framing/cursors/capture/log/NBT/provenance, saved-spawn/durability comparison, 20 observations, 13 D1 rows, production sleep/air/dimension/spawn/time, dedicated/restart/crash/client/visual, cumulative admission/quota and R-021 save/log/recovery policy remain untested/open. No acceptance or recovery mechanism is added by this decoder review.

All v1.8 Required Gates satisfied: **NO**. Gradle clean build/test, runData/generated diff, GameTest, dedicated/restart/native, real V1/V2, full resource/performance, license/package/progression/release evidence are NOT_EXECUTED/open here, not PASS and not NOT_APPLICABLE. No ledger delivery, version state, ADR/risk acceptance, waiver, release or tag is granted.

## Own evidence, stable report and custody boundary

Own writes are only this new external leaf and the explicitly named new Temp directory; no repository file was modified. The leaf contains identities, own finite test/audit/capture/seal helpers, actual raw receipts and preparation/correction/report records. It contains no duplicate production source, whole source export, world, archive, stored synthetic payload corpus or compiler cache. Raw maximum retained stream is 14107 bytes before own custody; actual leaf remains well below 4 MiB. No cleanup of own/peer evidence or foreign process was performed.

This is the stable report for Root's complete exact-hash read and acknowledgment. It is not sealed at report creation. Only after that acknowledgment may the one-time own-leaf helper create SHA256SUMS.txt and SEAL-RESULT.json. Actual seal coverage/bytes/hash/raw receipt/result/exclusions will be separately returned after execution, without modifying this stable report. Planned exclusions are not reported as completed seal facts.

Completed: fixed two-file independent source/contract review, independent 32+42 functional methods, compile/AST/protection checks, author failed-cohort/oracle attribution, actual bounded source53 custody audit, and two Low committed-test findings. Uncompleted: R57-01/R57-02 source correction and every separately mandatory resource/native/full-driver/full-version qualification above. Key decisions: unchanged compact bytes/iterative reservations/inert numbers/diagnostics/deadlines; no new policy or source contract. Modified project files: none. Added project tests: none; own 42 finite cases are evidence only.

Next v1.8-only work: separately add R57-01/R57-02's paired regressions without rebinding this review; disposition terminal-counter prerequisites and explicitly assign unchanged decoder resource qualification; then, only under later scoped authority/evidence, consider source-aware/framing/runtime observation integration and remaining C18-A/full-v1.8 acceptance. No later-version feature or framework is proposed.
