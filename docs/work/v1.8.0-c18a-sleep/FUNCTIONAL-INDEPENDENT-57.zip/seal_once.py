"""Task57 one-time own custody after Root's exact stable-report acknowledgment."""
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

LEAF = Path(__file__).resolve().parent
MANIFEST = LEAF / 'SHA256SUMS.txt'
RESULT = LEAF / 'SEAL-RESULT.json'
EXCLUSIONS = ['SHA256SUMS.txt', 'SEAL-RESULT.json']
CAP = 262144


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def regular(path):
    assert path.parent == LEAF and path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(), 'st_file_attributes', 0) & 1024)
    assert path.stat().st_size <= CAP
    return path.read_bytes()


def child():
    assert not MANIFEST.exists() and not RESULT.exists()
    for ancestor in (LEAF, LEAF.parent, LEAF.parent.parent, LEAF.parent.parent.parent):
        assert not ancestor.is_symlink()
        assert not (getattr(ancestor.stat(), 'st_file_attributes', 0) & 1024)
    report = regular(LEAF / 'REPORT.md')
    ack = json.loads(regular(LEAF / 'ROOT-ACK.json'))
    assert ack['sender'] == '/root' and ack['complete_exact_report_read'] is True
    assert ack['report_sha256'] == sha(report)
    assert (ack['report_bytes'], ack['report_lines']) == (len(report), len(report.splitlines()))
    files = sorted(LEAF.iterdir())
    assert len(files) <= 512 and len({p.name.casefold() for p in files}) == len(files)
    rows = [(path.name, regular(path)) for path in files]
    content = ''.join(sha(raw) + '  ' + name + '\n' for name, raw in rows).encode('utf-8')
    covered_bytes = sum(len(raw) for _, raw in rows)
    assert covered_bytes + len(content) + 8192 <= 4194304
    with MANIFEST.open('xb') as out:
        out.write(content)
    for name, raw in rows:
        assert sha(regular(LEAF / name)) == sha(raw)
    assert {p.name for p in LEAF.iterdir()} == {name for name, _ in rows} | {'SHA256SUMS.txt'}
    print(json.dumps({'all_covered_match': True, 'covered_files': len(rows),
                      'covered_bytes': covered_bytes, 'manifest_bytes': len(content),
                      'manifest_sha256': sha(content), 'exact_exclusions': EXCLUSIONS,
                      'report_bytes': len(report), 'report_lines': len(report.splitlines()),
                      'report_sha256': sha(report)}))


def parent():
    assert not MANIFEST.exists() and not RESULT.exists()
    argv = [sys.executable, '-B', str(Path(__file__).resolve()), '--child']
    cwd = str(LEAF)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic_ns()
    proc = subprocess.Popen(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    buffers = [bytearray(), bytearray()]
    lengths = [0, 0]

    def drain(stream, index):
        while chunk := stream.read(8192):
            lengths[index] += len(chunk)
            if len(buffers[index]) < CAP:
                buffers[index].extend(chunk[:CAP - len(buffers[index])])

    threads = [threading.Thread(target=drain, args=(proc.stdout, 0)),
               threading.Thread(target=drain, args=(proc.stderr, 1))]
    for thread in threads:
        thread.start()
    timed_out = False
    try:
        exit_code = proc.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()  # Only the parent's just-launched immediate Python child.
        exit_code = proc.wait()
    for thread in threads:
        thread.join()
    raw = [bytes(value) for value in buffers]
    overflow = any(length > CAP for length in lengths)
    passed = exit_code == 0 and not timed_out and not overflow
    result = {'kind': 'ONE_TIME_INDEPENDENT_EVIDENCE_CUSTODY_NOT_CODE_RESOURCE_OR_GATE_ACCEPTANCE',
              'argv': argv, 'cwd': cwd, 'started_utc': started,
              'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsed_ns': time.monotonic_ns() - begin, 'exit_code': exit_code,
              'timeout_seconds': 180, 'timed_out': timed_out,
              'stream_limit_bytes': CAP, 'output_limit_exceeded': overflow,
              'drain_complete': True, 'exact_exclusions': EXCLUSIONS,
              'verification': json.loads(raw[0]) if passed else None}
    for label, value, length in zip(('stdout', 'stderr'), raw, lengths):
        result[label + '_bytes'] = len(value)
        result[label + '_observed_bytes'] = length
        result[label + '_sha256'] = sha(value)
        result[label + '_base64'] = base64.b64encode(value).decode('ascii')
    encoded = (json.dumps(result, indent=2) + '\n').encode('utf-8')
    assert len(encoded) <= 8192
    with RESULT.open('xb') as out:
        out.write(encoded)
    print(json.dumps({'verification': result['verification'], 'result_bytes': len(encoded),
                      'result_sha256': sha(encoded), 'exit_code': exit_code,
                      'timed_out': timed_out, 'output_limit_exceeded': overflow}))
    return 0 if passed else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['--child']:
        child()
    else:
        assert len(sys.argv) == 1
        raise SystemExit(parent())
