"""Task57 finite functional receipt parent; no resource qualification."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

LEAF = Path(__file__).resolve().parent
TEMP = Path('C:/Users/Administrator/AppData/Local/Temp/arce-sleep-json-functional-review-20261009-57')
CAP = 262144
TIMEOUT = 180
ALLOWED = {'paired': 'test_sleep_observation_json_core.py',
           'independent': 'independent_cases.py',
           'static': 'static_inspection.py',
           'protected': 'protection_audit.py',
           'source-audit': 'source_receipt_audit.py',
           'source-audit-47': 'source_receipt_audit_47.py',
           'guard-ties': 'independent_guard_ties.py',
           'final-audit': 'final_audit.py'}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def hashes():
    rows = json.loads((LEAF / 'INPUTS.json').read_text(encoding='utf-8'))['rows']
    actual = {}
    for row in rows:
        data = (TEMP / Path(row['file']).name).read_bytes()
        value = hashlib.sha256(data).hexdigest()
        if value != row['sha256']:
            raise AssertionError('Immutable source changed')
        actual[row['file']] = {'sha256': value, 'bytes': len(data)}
    return actual


def main():
    case = sys.argv[1]
    filename = ALLOWED[case]
    prefix = LEAF / ('functional-' + case)
    if any(Path(str(prefix) + ext).exists() for ext in ('.command.json', '.stdout.txt', '.stderr.txt')):
        raise RuntimeError('Receipt already exists; retry is not authorized')
    before = hashes()
    argv = [sys.executable, '-B', str(TEMP / filename)]
    started = utc()
    start = time.monotonic_ns()
    child = subprocess.Popen(argv, cwd=TEMP, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    streams = {}

    def drain(stream, label):
        kept = bytearray()
        length = 0
        total_digest = hashlib.sha256()
        while chunk := stream.read(8192):
            length += len(chunk)
            total_digest.update(chunk)
            if len(kept) < CAP:
                kept.extend(chunk[:CAP - len(kept)])
        data = bytes(kept)
        Path(str(prefix) + '.' + label + '.txt').write_bytes(data)
        streams[label] = {'bytes_total': length, 'bytes_retained': len(data),
                          'overflow': length > CAP,
                          'sha256_retained': hashlib.sha256(data).hexdigest(),
                          'sha256_total': total_digest.hexdigest()}

    threads = [threading.Thread(target=drain, args=(child.stdout, 'stdout')),
               threading.Thread(target=drain, args=(child.stderr, 'stderr'))]
    for thread in threads:
        thread.start()
    timed_out = False
    try:
        exit_code = child.wait(timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        timed_out = True
        # Only this parent's just-launched immediate child is stopped.
        child.kill()
        exit_code = child.wait()
    for thread in threads:
        thread.join()
    result = {'case': case, 'argv': argv, 'cwd': str(TEMP),
              'started_utc': started, 'ended_utc': utc(),
              'elapsed_ns': time.monotonic_ns() - start,
              'external_timeout_seconds': TIMEOUT,
              'immediate_child_pid': child.pid, 'timed_out': timed_out,
              'exit_code': exit_code, 'streams': streams,
              'source_hashes_before': before, 'source_hashes_after': hashes(),
              'resource_measurement': 'NOT_EXECUTED',
              'parent_preemption_or_memory_quota_claim': False}
    Path(str(prefix) + '.command.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    for label in ('stdout', 'stderr'):
        print(label + ':')
        print(Path(str(prefix) + '.' + label + '.txt').read_text(encoding='utf-8'))
    return 1 if timed_out or any(row['overflow'] for row in streams.values()) else exit_code


if __name__ == '__main__':
    raise SystemExit(main())
