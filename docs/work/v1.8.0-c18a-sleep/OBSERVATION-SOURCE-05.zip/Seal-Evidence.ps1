$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-20261009-05')
$prefix = $leaf.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$manifestPath = Join-Path $leaf 'SHA256SUMS.txt'
$preflightPath = Join-Path $leaf 'seal-preflight.json'
if ((Test-Path -LiteralPath $manifestPath) -or (Test-Path -LiteralPath $preflightPath)) { throw 'Seal output already exists; never overwrite sealed evidence' }
for ($item=Get-Item -LiteralPath $leaf -Force; $null -ne $item; $item=$item.Parent) {
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Evidence root or ancestor is a reparse point' }
}
$directories = [Collections.Generic.Stack[string]]::new()
$directories.Push($leaf)
$files = [Collections.Generic.List[object]]::new()
while ($directories.Count -gt 0) {
    foreach ($item in Get-ChildItem -LiteralPath $directories.Pop() -Force) {
        if (!$item.FullName.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or
                ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Evidence child containment/reparse check failed' }
        if ($item.PSIsContainer) {
            if ($item.Name -in @('temp','build','.gradle')) { throw 'Scratch/build directory retained in the evidence inventory' }
            $directories.Push($item.FullName)
        } else { $files.Add($item) }
    }
}
$total=[long](($files | Measure-Object -Property Length -Sum).Sum)
$largest=($files | Sort-Object Length -Descending | Select-Object -First 1)
if ($total -gt 100MB -or $largest.Length -gt 50MB) { throw 'Evidence volume limit exceeded' }
$audit=Get-Content -LiteralPath (Join-Path $leaf 'identity-audit.json') -Raw | ConvertFrom-Json
if ($audit.head -ne '5b45132000ade1e3c8d130a6b8ccb29f07535124' -or
        $audit.author_compile_count -ne 3 -or $audit.author_executed_test_count -ne 0 -or $audit.unexecuted_source_test_count -ne 9) { throw 'Source-only identity/count receipt differs' }
$preflight=[ordered]@{
    seal_started_utc=[DateTime]::UtcNow.ToString('o');leaf=$leaf;source_sha=$audit.head
    authorization='Root completion instruction: author-owned cleanup and source-only evidence seal; no runtime or integration'
    independent_report_last_received='Root reports additive actual-diff review/compile completed, final report preparing; final verdict not received by author'
    author_compile_count=3;author_executed_test_count=0;unexecuted_source_test_count=9
    containment='Exact exclusive source-evidence leaf';reparse_points=0;scratch_directories=0
    evidence_files_before_preflight=$files.Count;bytes_before_preflight_and_manifest=$total
    largest_existing_file=$largest.FullName.Substring($prefix.Length).Replace('\','/');largest_existing_file_bytes=$largest.Length
    expected_manifest_entries=($files.Count+1);manifest_excludes_only_itself=$true
    max_package_bytes=100MB;max_single_file_bytes=50MB
    final_check='Verify-Seal.ps1 returns hashes, full coverage, REPORT membership, manifest identity and actual sealed volume without writing'
}
$preflight | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $preflightPath -Encoding utf8
$files.Add((Get-Item -LiteralPath $preflightPath))
$lines=@($files | Sort-Object FullName -CaseSensitive | ForEach-Object {
    $relative=$_.FullName.Substring($prefix.Length).Replace('\','/')
    (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + $relative
})
# The manifest is written once. No retained file is modified after this operation.
$lines | Set-Content -LiteralPath $manifestPath -Encoding ascii
& (Join-Path $leaf 'Verify-Seal.ps1')
