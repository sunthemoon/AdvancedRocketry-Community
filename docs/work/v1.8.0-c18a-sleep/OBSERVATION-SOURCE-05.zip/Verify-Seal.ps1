$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-20261009-05')
$prefix = $leaf.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$manifestPath = Join-Path $leaf 'SHA256SUMS.txt'
for ($item=Get-Item -LiteralPath $leaf -Force; $null -ne $item; $item=$item.Parent) {
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Evidence root or ancestor is a reparse point' }
}
$directories = [Collections.Generic.Stack[string]]::new()
$directories.Push($leaf)
$files = [Collections.Generic.List[object]]::new()
while ($directories.Count -gt 0) {
    foreach ($item in Get-ChildItem -LiteralPath $directories.Pop() -Force) {
        if (!$item.FullName.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or
                ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Evidence child containment/reparse check failed' }
        if ($item.PSIsContainer) { $directories.Push($item.FullName) } else { $files.Add($item) }
    }
}
$entries = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
foreach ($line in Get-Content -LiteralPath $manifestPath) {
    if ($line -notmatch '^([a-f0-9]{64})  (.+)$') { throw 'Malformed manifest entry' }
    $sha=$Matches[1]; $relative=$Matches[2]
    if ($relative -eq 'SHA256SUMS.txt' -or $relative.Contains('\') -or [IO.Path]::IsPathRooted($relative)) { throw 'Invalid manifest path' }
    $path = [IO.Path]::GetFullPath((Join-Path $leaf $relative))
    if (!$path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or
            $path.Substring($prefix.Length).Replace('\','/') -cne $relative) { throw 'Manifest path is not canonical and contained' }
    $entries.Add($relative,$sha)
    $actual=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $sha) { throw ('Evidence hash differs: ' + $relative) }
}
$retained=@($files | Where-Object { $_.Name -ne 'SHA256SUMS.txt' } | ForEach-Object { $_.FullName.Substring($prefix.Length).Replace('\','/') } | Sort-Object -CaseSensitive)
$covered=@($entries.Keys | Sort-Object -CaseSensitive)
if (($retained -join "`n") -cne ($covered -join "`n")) { throw 'Manifest does not cover the exact retained evidence inventory' }
if (!$entries.ContainsKey('REPORT.md')) { throw 'REPORT is not covered by the manifest' }
$total=[long](($files | Measure-Object -Property Length -Sum).Sum)
$largest=($files | Sort-Object Length -Descending | Select-Object -First 1)
if ($total -gt 100MB -or $largest.Length -gt 50MB) { throw 'Evidence volume limit exceeded' }
[ordered]@{
    verified_utc=[DateTime]::UtcNow.ToString('o');leaf=$leaf;hashes_verified=$entries.Count
    full_file_coverage=$true;report_covered=$true;external_or_scratch_manifest_entries=0
    reparse_points=0;file_count_including_manifest=$files.Count;total_bytes_including_manifest=$total
    largest_file=$largest.FullName.Substring($prefix.Length).Replace('\','/');largest_file_bytes=$largest.Length
    manifest_sha256=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    report_sha256=$entries['REPORT.md'];verification_writes=0
} | ConvertTo-Json -Depth 5
