$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-sleep-observation-20261009')
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-20261009-05')
$targets = @(
    @{root=$workspace; path=(Join-Path $workspace 'build')},
    @{root=$workspace; path=(Join-Path $workspace '.gradle')},
    @{root=$leaf; path=(Join-Path $leaf 'compile-01/temp')},
    @{root=$leaf; path=(Join-Path $leaf 'compile-02/temp')},
    @{root=$leaf; path=(Join-Path $leaf 'compile-03/temp')}
)
$result = [ordered]@{start_utc=[DateTime]::UtcNow.ToString('o');shell='native PowerShell';own_pid=$PID;workspace=$workspace;leaf=$leaf;targets=@()}
$failed = $false
foreach ($target in $targets) {
    $path = [IO.Path]::GetFullPath($target.path)
    $audit = [ordered]@{target=$path;owner='source worker compile output';outcome='NOT_ATTEMPTED'}
    try {
        $prefix = $target.root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if (!$path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target is outside its intended owned root' }
        if (!(Test-Path -LiteralPath $path)) { $audit.outcome='NOT_PRESENT'; $result.targets += $audit; continue }
        $item = Get-Item -LiteralPath $path -Force
        if (!$item.PSIsContainer -or ![string]::Equals($item.FullName,$path,[StringComparison]::OrdinalIgnoreCase)) { throw 'Resolved absolute target differs' }
        for ($ancestor = $item; $null -ne $ancestor; $ancestor = $ancestor.Parent) {
            if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Target or ancestor is a reparse point' }
        }
        $childPrefix = $path.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        $directories = [Collections.Generic.Stack[string]]::new()
        $directories.Push($path)
        $files = 0; $bytes = [long]0; $entries = 0
        while ($directories.Count -gt 0) {
            foreach ($child in Get-ChildItem -LiteralPath $directories.Pop() -Force) {
                if (!$child.FullName.StartsWith($childPrefix,[StringComparison]::OrdinalIgnoreCase) -or
                        ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Child containment or reparse check failed' }
                $entries++
                if ($child.PSIsContainer) { $directories.Push($child.FullName) } else { $files++; $bytes += $child.Length }
            }
        }
        $audit.containment='PASS'; $audit.reparse_points=0
        $audit.files=$files; $audit.bytes=$bytes; $audit.entries=$entries
        $owners = @(Get-CimInstance Win32_Process | Where-Object {
            $_.ProcessId -ne $PID -and $_.CommandLine -and $_.Name -match '^(javaw?|gradle|python|pwsh|powershell).*' -and
            ($_.CommandLine.Replace('/','\').IndexOf($path.Replace('/','\'),[StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                $_.CommandLine.Replace('/','\').IndexOf($workspace.Replace('/','\'),[StringComparison]::OrdinalIgnoreCase) -ge 0)
        } | Select-Object ProcessId,Name,CommandLine)
        $audit.overlapping_processes=$owners
        if ($owners.Count -gt 0) { throw 'A process may still own the target; no process termination or deletion attempted' }
        $audit.delete_start_utc=[DateTime]::UtcNow.ToString('o')
        Remove-Item -LiteralPath $path -Recurse -Force
        if (Test-Path -LiteralPath $path) { throw 'Target remains after the one native deletion attempt' }
        $audit.outcome='DELETED'; $audit.delete_end_utc=[DateTime]::UtcNow.ToString('o')
    } catch {
        $failed = $true; $audit.outcome='REFUSED_OR_RETAINED'; $audit.failure=$_.Exception.Message
        # Preserve any remainder. Never retry in another shell or delete peers/processes.
    }
    $result.targets += $audit
}
$result.end_utc=[DateTime]::UtcNow.ToString('o')
$result.disks_after=@(Get-Volume -DriveLetter C,D | Select-Object DriveLetter,Size,SizeRemaining)
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-audit.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8
if ($failed) { exit 1 }
