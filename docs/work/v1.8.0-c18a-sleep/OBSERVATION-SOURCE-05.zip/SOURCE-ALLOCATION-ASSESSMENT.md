# Actual old-candidate allocation and pending refinement assessment

Reviewed source: 0c05cc27112f5f4a71faa66bc16b5f7f4390f345. The same candidate
compiled in compile-02 and was normally pushed before Root requested a freeze.
No evidence is sealed yet.

The old append implementation first adds the newly constructed JsonObject to
the tree, serializes the whole candidate root to a String and UTF-8 array, then
checks the accepted structured byte limit. If the root fits, it also serializes
the current case before checking that case limit. Accepted evidence is bounded;
these checks are not a pre-allocation memory/serialization guarantee. Frame and
event counts alone do not bound every transient metadata String. The old public
allocation reading excludes native snapshot construction and append serialization;
the duration reading excludes append. No end-to-end or reference-load performance
result follows from those fields, and no runtime measurement was executed.

Root has assigned correction task 08 to replace this post-serialization check
with bounded size accounting/serialization and precise measurement attribution,
without changing caps or native event decisions. The original commits and both
successful compile cohorts remain separate, unchanged records.

Before Root's freeze message, this worker began the unpublished twelve-line
refinement retained as pending-owned-refinement.patch. It adds an alive/survival/
empty-hand check, includes Level-list-only partial login in native removal, and
checks the owned channel/connection is closed after release. It has not been
committed, compiled or pushed. The draft placed the first check at acquisition;
its intended check point is after declared fixture preparation. Any adopted
refinement will be attributed separately from the accounting correction.
