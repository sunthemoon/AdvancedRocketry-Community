$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-sleep-observation-20261009')
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-20261009-05')
$base = 'b9bec789978de0df67c93e976239d6d36e41532b'
$head = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
$branch = 'codex/v1.8.0-sleep-boundary-observation'
$sources = @(
    'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java',
    'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java'
)
function Read-Git([string[]]$Arguments) {
    $output = @(& git -C $workspace @Arguments)
    if ($LASTEXITCODE -ne 0) { throw ('Git read failed: ' + ($Arguments -join ' ')) }
    return $output
}
function Require([bool]$condition, [string]$message) { if (!$condition) { throw $message } }
Require ((Read-Git @('rev-parse','HEAD')) -eq $head) 'Unexpected source HEAD'
Require ((Read-Git @('branch','--show-current')) -eq $branch) 'Unexpected source branch'
$status = @(Read-Git @('status','--porcelain=v1','--untracked-files=all'))
Require ($status.Count -eq 0) 'Source worktree is not clean'
[void](Read-Git @('diff','--check'))
[void](Read-Git @('diff','--exit-code'))
[void](Read-Git @('merge-base','--is-ancestor',$base,$head))
$changed = @(Read-Git @('diff','--name-only',$base,$head))
Require ((($changed | Sort-Object) -join "`n") -eq (($sources | Sort-Object) -join "`n")) 'Source diff exceeds the two-file scope'
$published = [string](Read-Git @('rev-parse',('refs/remotes/origin/' + $branch)))
Require ($published -eq $head) 'Local origin tracking ref does not match the pushed source'
$result = [ordered]@{
    audited_utc=[DateTime]::UtcNow.ToString('o');cwd=$workspace;base=$base;head=$head;branch=$branch
    status=$status;changed_files=$changed;base_ancestor=$true;diff_whitespace_exit=0;diff_exit=0
    origin_tracking_ref=$published;remote_network_recheck_executed=$false
    publication_evidence='push.json and push-correction.json/raw logs; no new push or network command during this audit'
    upstream_probe='Earlier read-only rev-parse @{upstream} reported no upstream configured. Explicit normal pushes used HEAD:branch; no Git configuration was changed.'
    assignment_commit=[string](Read-Git @('show','--no-patch','--format=%H %s','73981dba655d3cb86bae34fadd0023aa83e8efdc'))
    tasks=@();sources=@();compiles=@();patches=@();scratch=@()
}
$tasks = @(
    @{name='SLEEP-OBSERVATION-SOURCE-TASK-05.md';sha='a793aa4c994537401b0b728af3254e4e6815474fe5d149a6095e53b65550eb65'},
    @{name='SLEEP-OBSERVATION-SOURCE-CORRECTION-TASK-08.md';sha='7ae9af7b58679cd66101066bcb7b13848011bb9e8e453c9354b6e6afde8f66de'},
    @{name='SLEEP-OBSERVATION-SOURCE-CORRECTION-ADDENDUM-10.md';sha='bb9f1e7ed50275e1f408ccf969814a144b1b1b0cdf3e09e39905d6b3016f6f74'}
)
foreach ($task in $tasks) {
    $path = Join-Path 'D:/GitHub/ARCE-Task-Evidence/v1.8.0' $task.name
    $sha = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    Require ($sha -eq $task.sha) ('Task hash changed: ' + $task.name)
    $result.tasks += [ordered]@{path=$path;sha256=$sha;matches_assignment=$true}
}
foreach ($source in $sources) {
    $path = Join-Path $workspace $source
    $blob = [string](Read-Git @('rev-parse',($head + ':' + $source)))
    $workingBlob = [string](Read-Git @('hash-object','--',$source))
    Require ($blob -eq $workingBlob) 'Source file differs from committed blob'
    $text = Get-Content -LiteralPath $path -Raw
    $lines = @(Get-Content -LiteralPath $path).Count
    Require ($lines -le 500) 'Source class exceeds assignment line boundary'
    $tests = @([regex]::Matches($text,'(?m)public static void (\w+)\(GameTestHelper helper\)') | ForEach-Object { $_.Groups[1].Value })
    $result.sources += [ordered]@{path=$source;bytes=(Get-Item -LiteralPath $path).Length;lines=$lines;git_blob=$blob;working_git_blob=$workingBlob;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();game_tests=$tests;test_execution='UNEXECUTED'}
}
Require ((($result.sources | ForEach-Object { $_.game_tests.Count } | Measure-Object -Sum).Sum) -eq 9) 'Expected source test inventory count differs'
$expectedCandidates = @('e72b41dea67404b5abba48bb499a1b4d5d743389','0c05cc27112f5f4a71faa66bc16b5f7f4390f345',$head)
$expectedArgv = './gradlew.bat compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks'
for ($i=1; $i -le 3; $i++) {
    $cohort = 'compile-{0:d2}' -f $i
    $receipt = Get-Content -LiteralPath (Join-Path $leaf ($cohort + '/command.json')) -Raw | ConvertFrom-Json
    $logPath = Join-Path $leaf ($cohort + '/command.log')
    $log = Get-Content -LiteralPath $logPath -Raw
    Require (($receipt.argv -join ' ') -eq $expectedArgv) 'Compile argv differs'
    Require ($receipt.cwd -eq $workspace) 'Compile cwd differs'
    Require ($receipt.source_sha -eq $expectedCandidates[$i-1] -and $receipt.source_sha_after -eq $expectedCandidates[$i-1]) 'Compile source attribution differs'
    Require ($receipt.exit_code -eq 0 -and @($receipt.git_status_before).Count -eq 0 -and @($receipt.git_status_after).Count -eq 0) 'Compile receipt is not a clean successful candidate'
    Require ($log -match 'BUILD SUCCESSFUL' -and $log -match '7 actionable tasks: 7 executed') 'Raw compile log result differs'
    foreach ($disk in $receipt.disks_before) { Require ($disk.SizeRemaining -ge 10GB) 'Compile disk preflight below boundary' }
    $temp = [IO.Path]::GetFullPath((Join-Path $leaf ($cohort + '/temp')))
    Require ($receipt.child_temp -eq $temp -and $receipt.child_tmp -eq $temp) 'Compile scratch attribution differs'
    $result.compiles += [ordered]@{cohort=$cohort;source_sha=$receipt.source_sha;argv=$receipt.argv;start_utc=$receipt.start_utc;end_utc=$receipt.end_utc;exit_code=$receipt.exit_code;receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $leaf ($cohort + '/command.json')) -Algorithm SHA256).Hash.ToLowerInvariant();log_sha256=(Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash.ToLowerInvariant();runtime_and_tests_executed=$false}
}
$patchPairs = @(
    @{file='source-candidate-01.patch';from=$base;to=$expectedCandidates[0]},
    @{file='source-attribution-02.patch';from=$expectedCandidates[0];to=$expectedCandidates[1]},
    @{file='source-final.patch';from=$base;to=$expectedCandidates[1]},
    @{file='adopted-owned-refinement.patch';from=$expectedCandidates[1];to='9f21a3daab7e6f3b38029742979a328306146fcf'},
    @{file='bounded-accounting-and-setup-guard.patch';from='9f21a3daab7e6f3b38029742979a328306146fcf';to=$head},
    @{file='source-corrected-5b451320.patch';from=$base;to=$head}
)
foreach ($pair in $patchPairs) {
    $actual = ((Get-Content -LiteralPath (Join-Path $leaf $pair.file) -Raw).Replace("`r`n","`n")).TrimEnd("`n")
    $expected = ((Read-Git @('diff','--binary',$pair.from,$pair.to,'--') ) -join "`n").TrimEnd("`n")
    Require ($actual -eq $expected) ('Persisted patch differs from committed source: ' + $pair.file)
    $result.patches += [ordered]@{file=$pair.file;from=$pair.from;to=$pair.to;committed_diff_matches_after_line_ending_normalization=$true;sha256=(Get-FileHash -LiteralPath (Join-Path $leaf $pair.file) -Algorithm SHA256).Hash.ToLowerInvariant()}
}
$result.pending_refinement=[ordered]@{file='pending-owned-refinement.patch';status='Preserved original uncommitted refinement, distinct from the adopted committed diff';sha256=(Get-FileHash -LiteralPath (Join-Path $leaf 'pending-owned-refinement.patch') -Algorithm SHA256).Hash.ToLowerInvariant()}
foreach ($path in @((Join-Path $workspace 'build'),(Join-Path $workspace '.gradle'),(Join-Path $leaf 'compile-01/temp'),(Join-Path $leaf 'compile-02/temp'),(Join-Path $leaf 'compile-03/temp'))) {
    $present = Test-Path -LiteralPath $path
    Require (!$present) 'Owned cleanup target still present'
    $result.scratch += [ordered]@{path=$path;present=$present}
}
$result.author_compile_count=3; $result.author_executed_test_count=0; $result.unexecuted_source_test_count=9
$result.toolchain=@()
foreach ($tool in @(
    @{name='Oracle Java 17.0.7 java.exe';path='C:/Program Files/Java/jdk-17.0.7/bin/java.exe';sha='308e8c921fd9d152ad526e5f0988682e8f96792a6313f185fa6b20db671a791f'},
    @{name='Gradle wrapper JAR';path=(Join-Path $workspace 'gradle/wrapper/gradle-wrapper.jar');sha='ed2c26eba7cfb93cc2b7785d05e534f07b5b48b5e7fc941921cd098628abca58'},
    @{name='Forge 47.4.10 mapped official primary JAR';path='C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar';sha='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'}
)) {
    $hash = (Get-FileHash -LiteralPath $tool.path -Algorithm SHA256).Hash.ToLowerInvariant()
    Require ($hash -eq $tool.sha) ('Toolchain identity changed: ' + $tool.name)
    $result.toolchain += [ordered]@{name=$tool.name;path=$tool.path;sha256=$hash;matches_recorded_identity=$true}
}
$wrapperProperties = Get-Content -LiteralPath (Join-Path $workspace 'gradle/wrapper/gradle-wrapper.properties') -Raw
Require ($wrapperProperties.Contains('gradle-8.8-bin.zip') -and $wrapperProperties.Contains('a4b4158601f8636cdeeab09bd76afb640030bb5b144aafe261a5e8af027dc612')) 'Gradle distribution identity differs'
$result.gradle_distribution=[ordered]@{version='8.8';declared_sha256='a4b4158601f8636cdeeab09bd76afb640030bb5b144aafe261a5e8af027dc612';wrapper_properties_sha256=(Get-FileHash -LiteralPath (Join-Path $workspace 'gradle/wrapper/gradle-wrapper.properties') -Algorithm SHA256).Hash.ToLowerInvariant()}
$result.upstream_imports='No upstream code or asset was imported. Only original test-only public platform adapter source was added.'
$result | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath (Join-Path $leaf 'identity-audit.json') -Encoding utf8
$result | ConvertTo-Json -Depth 9
