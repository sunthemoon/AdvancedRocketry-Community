# Source correction receipt and author source-only closure

Task 08 SHA-256 is
7ae9af7b58679cd66101066bcb7b13848011bb9e8e453c9354b6e6afde8f66de.
Addendum 10 SHA-256 is
bb9f1e7ed50275e1f408ccf969814a144b1b1b0cdf3e09e39905d6b3016f6f74.
Both were read and verified before their scoped corrections. Original task 05,
source commits, patches, compile-01/02 and original publication are retained.

The previously unpublished preparation/cleanup refinement is preserved as
pending-owned-refinement.patch and adopted separately as 9f21a3daab7e6f3b38029742979a328306146fcf.
Its intended check is after declared preparation, not before the initial native
login. It verifies alive/survival/empty hands, includes Level-list-only partial
acquisition in native removal, and checks own channel/connection closure. That
intermediate commit was not compiled by itself.

The accounting/setup correction is 5b45132000ade1e3c8d130a6b8ccb29f07535124.
The fixture is 497 lines and the trace is 498 lines. The byte budget is counted
through capped, non-retaining public JsonWriter output before attaching a record.
No whole-root String or UTF-8 array is allocated for cap rejection. Final output
is pre-counted and emitted through a capped writer with pre-sized storage. UTF-8
escapes and split surrogate handling have source boundary tests.

Frame class/member text and public MethodType descriptor length are preflighted
before descriptor construction. A conservative frame-record budget is checked
before building frame JSON. Oversized metadata yields incomplete evidence, not
a valid truncated observation. MethodType/Class references and diagnostic names
remain evidence only; no native decision predicate was introduced.

Native chat uses a finite public Component preflight before native toJsonTree:
32 nodes, depth 8, at most 4 translation arguments, at most 1024 characters per
string and a cumulative escaped-text upper bound of 8192 bytes. Native literal/
translation/empty content, bounded siblings, style and text/entity hover values
are supported. Other content/hover/item-NBT or unavailable metadata is explicitly
incomplete. A conservative JSON allocation allowance is checked against the case/
invocation budget before calling the native serializer. The post-check validates
the already bounded preflight, rather than being its only size protection.

Public time/allocation fields now name the capture prefix: ownership validation,
StackWalker, metadata preflight/accounting and frame JSON, including measurement
queries. They explicitly exclude native snapshot/event-record construction,
append accounting and final output serialization. No global JVM measurement is
enabled. Unavailable allocation stays unmeasured; no performance claim is made.

The invocation guard owns all initialization and execution in its own finally.
An outer setup failure returns a failure marker and releases the exact marker;
it is not native success. A source unit intervention checks later independent
invocation is not blocked. No setup failure or test intervention was executed.

compile-03 executed the exact permitted compile command at the committed correction
SHA. UTC: 2026-10-09T05:14:49.5220440Z to 2026-10-09T05:15:05.4305790Z.
Exit 0; BUILD SUCCESSFUL in 15 seconds, seven tasks executed. The same existing
jackhammer deprecation warning and Gradle deprecation notice remain. No test,
GameTest, build, DataGen, driver, server/client/world, runtime or failure injection
was executed. Source and branch status were clean before/after compilation.

The branch is normally published. Root subsequently instructed the author to keep
5b451320 unchanged, finish own scratch/identity checks and seal this source-only
leaf. The final REPORT and cleanup/identity audits record that closure. Last
received independent status was additive actual-diff review/compilation complete,
with its final report being prepared; the author has not received its final
verdict and does not count independent runs as author evidence. SHA256SUMS.txt
seals the retained compact evidence. No Gate, item/ledger, integration,
B1/R1/M1/M2/D1 or v1.8 completion is claimed.
