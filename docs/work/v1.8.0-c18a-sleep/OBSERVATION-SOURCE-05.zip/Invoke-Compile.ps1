$ErrorActionPreference = 'Stop'
$workspace = 'D:/GitHub/arce-v180-sleep-observation-20261009'
$leaf = 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-20261009-05'
$attempt = Join-Path $leaf 'compile-01'
if (Test-Path -LiteralPath $attempt) { throw 'Attempt must not overwrite prior evidence' }
New-Item -ItemType Directory -Path $attempt | Out-Null
$temp = Join-Path $attempt 'temp'
New-Item -ItemType Directory -Path $temp | Out-Null
Set-Location -LiteralPath $workspace
$env:JAVA_HOME = 'C:/Program Files/Java/jdk-17.0.7'
$env:TEMP = $temp
$env:TMP = $temp
$disks = @(Get-Volume -DriveLetter C,D | Select-Object DriveLetter,Size,SizeRemaining)
foreach ($disk in $disks) { if ($disk.SizeRemaining -lt 10GB) { throw 'Less than 10 GiB free; compilation not started' } }
$metadata = [ordered]@{
    cwd = (Get-Location).Path
    argv = @('./gradlew.bat','compileAdapterTestJava','--no-daemon','--no-build-cache','--rerun-tasks')
    source_sha = (& git rev-parse HEAD).Trim()
    branch = (& git branch --show-current).Trim()
    git_status_before = @(& git status --short)
    start_utc = [DateTime]::UtcNow.ToString('o')
    java_home = $env:JAVA_HOME
    java_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath "$env:JAVA_HOME/bin/java.exe").Hash.ToLowerInvariant()
    jdk_release = @(Get-Content -LiteralPath "$env:JAVA_HOME/release")
    wrapper_properties = @(Get-Content -LiteralPath 'gradle/wrapper/gradle-wrapper.properties')
    wrapper_jar_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath 'gradle/wrapper/gradle-wrapper.jar').Hash.ToLowerInvariant()
    child_temp = $env:TEMP
    child_tmp = $env:TMP
    disks_before = $disks
}
$metadata | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $attempt 'command.json') -Encoding utf8
& "$env:JAVA_HOME/bin/java.exe" -version 2>&1 | Out-File -LiteralPath (Join-Path $attempt 'java-version.txt') -Encoding utf8
& './gradlew.bat' compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks 2>&1 |
    Tee-Object -FilePath (Join-Path $attempt 'command.log')
$code = $LASTEXITCODE
$metadata.end_utc = [DateTime]::UtcNow.ToString('o')
$metadata.exit_code = $code
$metadata.source_sha_after = (& git rev-parse HEAD).Trim()
$metadata.git_status_after = @(& git status --short)
$metadata.disks_after = @(Get-Volume -DriveLetter C,D | Select-Object DriveLetter,Size,SizeRemaining)
$metadata | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $attempt 'command.json') -Encoding utf8
exit $code
