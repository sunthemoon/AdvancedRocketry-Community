"""Bounded read-only inspection of named public platform methods; no game launch."""
import subprocess

JAVAP = r"C:/Program Files/Java/jdk-17.0.7/bin/javap.exe"
JAR = r"C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar"
INSPECTIONS = {
    "net.minecraft.server.network.ServerGamePacketListenerImpl": ["handleUseItemOn(", "handleAcceptTeleportPacket("],
    "net.minecraft.server.level.ServerPlayer": ["teleportTo(net.minecraft.server.level.ServerLevel, double, double, double, float, float)", "setRespawnPosition("],
    "net.minecraft.world.level.block.BedBlock": ["use("],
    "net.minecraft.world.level.Level": ["isDay(", "updateSkyBrightness("],
}
for owner, members in INSPECTIONS.items():
    result = subprocess.run([JAVAP, "-classpath", JAR, "-c", owner], capture_output=True, text=True, check=True)
    print("CLASS", owner)
    lines = result.stdout.splitlines()
    for member in members:
        starts = [i for i, line in enumerate(lines) if line.startswith("  public ") and member in line]
        if len(starts) != 1:
            raise ValueError((owner, member, starts))
        start = starts[0]
        stop = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("  public ") or lines[i].startswith("  protected ")), len(lines))
        if stop - start > 350:
            raise ValueError("Named method exceeds bounded inspection limit")
        print("\n".join(lines[start:stop]))
