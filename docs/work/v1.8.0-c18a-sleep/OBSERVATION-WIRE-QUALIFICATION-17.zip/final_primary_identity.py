import pathlib,hashlib,json,zipfile
p=pathlib.Path(__file__).parent;rows=[]
for s in [r'C:\Program Files\Java\jdk-17.0.7\bin\java.exe',r'C:\Program Files\Java\jdk-17.0.7\lib\modules',r'D:\python\pyenv\pyenv-win\versions\3.13.15\python.exe']:
 f=pathlib.Path(s);h=hashlib.sha256()
 with f.open('rb') as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
 d={'path':s,'bytes':f.stat().st_size,'sha256':h.hexdigest()};rows.append(d);print(d)
f=p.parent/'jackhammer-root-20261009-01/packaged-02/seed/stdout.txt';b=f.read_bytes();needle=b'ARCE_JACKHAMMER_CONTINUATION';start=b.index(needle);end=b.index(b'\n',start)+1;print('HISTORICAL EXACT MARKER BYTES',repr(b[start:end]))
for n in ['30-hover-dispatch','31-tags-primary','jdk-printstream']:
 print('\n====',n)
 for i,l in enumerate((p/(n+'.stdout.txt')).read_text().splitlines()):
  if any(s in l for s in ['EntityTooltipInfo.serialize','REF_invoke','getId();','writeUTF','writeByte','writeFloat','writeInt','newLine','defaultCharset']):print(i+1,l)
(p/'FINAL-PRIMARY-INPUTS.json').write_text(json.dumps(rows,indent=2)+'\n')
