import pathlib,hashlib,json
p=pathlib.Path(__file__).parent;e=p.parent; checks=[]
leaves=[('sleep-observation-driver-contract-20261009-15','d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277','6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760'),('sleep-observation-root-qualification-20261009-11','0c82a4097db51bb98e1f45d819126ba87f1d7946c7b0d15157136f50fa19eebb','8f6a602a85fb91ab194068ee119ac3e72b170d95c06701aba38da56b1dd175f1'),('sleep-observation-qualification-independent-20261009-12','dadc06c556466d0f353fe96db68327208da5e40b89de883fb1eb6faa08d5cb31','542d90ea3197a1a3615ebf5b1a16048fea0a0c14dcdcdc6704904756c307c0f6')]
for leaf,report,manifest in leaves:
 r=e/leaf
 for n,want in [('REPORT.md',report),('SHA256SUMS.txt',manifest)]:
  b=(r/n).read_bytes();d={'path':str(r/n),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches':hashlib.sha256(b).hexdigest()==want};checks.append(d);print(d)
 good=0;bad=[]
 for line in (r/'SHA256SUMS.txt').read_text().splitlines():
  h,n=line.split('  ',1);f=r/n
  if pathlib.Path(n).is_absolute() or '..' in pathlib.Path(n).parts:raise ValueError('unsafe manifest path')
  if f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==h:good+=1
  else:bad.append(n)
 print('SEAL CONTENTS',leaf,'matches',good,'bad',bad);checks.append({'leaf':leaf,'sealed_files_matched':good,'bad':bad})
q=e/'sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md';b=q.read_bytes();checks.append({'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches':hashlib.sha256(b).hexdigest()=='628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec'})
for n,old in [('11-trace-fixed','39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0'),('12-fixture-fixed','1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820')]:
 b=(p/(n+'.stdout.txt')).read_bytes();d={'fixed_git_show':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches':hashlib.sha256(b).hexdigest()==old};checks.append(d);print(d)
q=e/'jackhammer-root-20261009-01/packaged-02/seed/stdout.txt';b=q.read_bytes();d={'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches':hashlib.sha256(b).hexdigest()=='7acaab4ff7eacf3c0f8c203d8b0b0f1a9932d8682e1905fbcf05e9608900d294'};checks.append(d);print(d)
for i,line in enumerate(b.splitlines(),1):
 if b'ARCE_JACKHAMMER_CONTINUATION' in line:print('HISTORICAL RAW LINE',i,repr(line))
q=e/'jackhammer-root-20261009-01/packaged-02/inputs.json';data=json.loads(q.read_text());print('HISTORICAL INPUTS',hashlib.sha256(q.read_bytes()).hexdigest(),'keys',list(data))
print(json.dumps(data,indent=2)[:4000])
(p/'INPUT-VERIFICATION.json').write_text(json.dumps(checks,indent=2)+'\n')
