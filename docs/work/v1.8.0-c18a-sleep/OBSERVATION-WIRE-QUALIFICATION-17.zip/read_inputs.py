import pathlib,hashlib
r=pathlib.Path(r'D:\GitHub\AdvancedRocketry-Community'); e=pathlib.Path(r'D:\GitHub\ARCE-Task-Evidence\v1.8.0')
files=['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md','docs/versions/v1.8.0.md','docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
for f in files:
 p=r/f
 if not p.exists():
  print('MISSING',p);continue
 print('\n====',p); print(p.read_text(encoding='utf-8'))
for p in e.glob('*TASK-16*'): print('\n====',p);print(p.read_text(encoding='utf-8'))
p=e/'sleep-observation-driver-contract-20261009-15'
for q in p.iterdir():
 if q.is_file():
  b=q.read_bytes();print('\n====',q,'SHA256',hashlib.sha256(b).hexdigest())
  if q.suffix.lower() in ['.md','.txt']: print(b.decode('utf-8',errors='replace'))
