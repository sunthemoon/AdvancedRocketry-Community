import datetime,pathlib,hashlib,json,subprocess,zipfile,sys
sys.stdout.reconfigure(encoding='utf-8');p=pathlib.Path(__file__).parent;e=p.parent;t=pathlib.Path(r'D:\GitHub\AdvancedRocketry-Community\.gradle\v120-jei-session\server');j=r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe';mapped=r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
def run(n,a):
 r={'pre_start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':a,'cwd':str(pathlib.Path.cwd())};x=subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);r.update(exit_code=x.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(p/(n+'.stdout.txt')).write_bytes(x.stdout);(p/(n+'.stderr.txt')).write_bytes(x.stderr);(p/(n+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');print(n,x.returncode,len(x.stdout));return x.stdout
files=['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md','docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
for i,f in enumerate(files):run('governance-'+str(i).zfill(2),['git','show','48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514:'+f])
for i,c in enumerate(['net.minecraft.network.chat.ClickEvent$Action','net.minecraft.network.chat.HoverEvent$EntityTooltipInfo']):run('extra-'+str(i),[j,'-p','-c','-s','-classpath',mapped,c])
run('resource-verbose',[j,'-p','-v','-classpath',mapped,'net.minecraft.resources.ResourceLocation'])
run('resourcekey-verbose',[j,'-p','-v','-classpath',mapped,'net.minecraft.resources.ResourceKey'])
run('routing-complete',[j,'-p','-c','-s','-classpath',str(t/'libraries/net/minecraftforge/fmlloader/1.20.1-47.4.10/fmlloader-1.20.1-47.4.10.jar'),'net.minecraftforge.fml.loading.targets.CommonLaunchHandler'])
run('jdk-system',[j,'-p','-c','-s','java.lang.System','java.nio.charset.Charset'])
old=json.loads((e/'jackhammer-root-20261009-01/packaged-02/inputs.json').read_text());matches=[]
for x in old['libraries']:
 f=t/'libraries'/x['path'];ok=f.is_file() and f.stat().st_size==x['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'];matches.append({'relative':x['path'],'matches_historical':ok})
(p/'RECIPE-LIBRARY-COMPARISON.json').write_text(json.dumps(matches,indent=2)+'\n');print('Historical library comparisons',len(matches),'all equal',all(x['matches_historical'] for x in matches))
for n in ['11-trace-fixed','12-fixture-fixed','primary-06','28-extra-primary','routing-complete','resource-verbose','resourcekey-verbose','jdk-system']:
 lines=(p/(n+'.stdout.txt')).read_text(encoding='utf-8').splitlines();print('\nFOCUSED',n)
 terms={'11-trace-fixed':['chatPreflight','chatText','boundedChat'],'12-fixture-fixed':['System.out','loadedSpawn','loadedDimension'],'primary-06':['public class','EntityTooltipInfo(','serialize('],'28-extra-primary':['ClickEvent(','TextColor(','RESOURCE_KEY_CODEC','ResourceKey.codec'],'routing-complete':['log4j','setOut'],'resource-verbose':['REF_invokeStatic net/minecraft/resources/ResourceLocation.read','REF_invokeVirtual net/minecraft/resources/ResourceLocation.toString'],'resourcekey-verbose':['codec(','ResourceLocation.CODEC','REF_invoke'],'jdk-system':['newPrintStream','sun.stdout.encoding','file.encoding','defaultCharset','Charset.forName']}.get(n,[])
 for i,l in enumerate(lines):
  if any(s in l for s in terms):print(i+1,l)
