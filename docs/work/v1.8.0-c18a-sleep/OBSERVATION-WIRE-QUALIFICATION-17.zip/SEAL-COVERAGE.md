# One-time static leaf seal coverage

Root's coordination message on 2026-10-09 confirms complete reading of all
382 lines of REPORT.md, SHA256
fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108,
and instructs a one-time leaf-relative seal. This is a full-read/seal instruction,
not executable freeze, process/cleanup permission, gameplay or Gate approval.

SHA256SUMS.txt covers every existing safe regular file in this exclusive leaf at
sealing, including this coverage note, the unchanged report, all compact raw
static-inspection command streams/receipts and evidence helpers, and the actual
pre-start SEAL-COMMAND.json receipt. It never lists external source/JAR/build/Temp
locations as covered files. The selected primary archives are only hashed.

Excluded files are exactly SHA256SUMS.txt itself and the three post-seal command
outputs SEAL-RESULT.json, SEAL-STDOUT.txt and SEAL-STDERR.txt. The post-seal result
retains actual command argv/cwd/pre-start/end UTC, actual exit and raw-stream
lengths/hashes; streams are unchanged. Exclusion avoids self-referential hashes.
No covered file is changed after sealing. Preparation transcript-only evidence
limitations remain as explicitly disclosed in REPORT.md; no missing UTC/raw
record is reconstructed by this seal.
