# Packaged sleep observation primary wire qualification 17

Date: 2026-10-09 UTC. Delegated read-only primary-inspection worker, not Root.
Status: static contracts established with explicit remaining boundaries; no
executable freeze, packaged launch, twenty-case observation or Gate approval.

## Findings first

1. **Raw println routing is supported by the pinned Forge recipe.** The actual
   Forge 47.4.10 server Bootstrap boot method no longer calls its retained private
   stream-wrapper method. The mapped Forge Bootstrap has the same removal.
   Historical retained jackhammer output has an unprefixed ASCII marker at line
   188. This is not evidence that the corrected sleep fixture has run, nor proof
   of its later JVM stdout charset or original line-ending bytes.
2. **Native translation argument wire values are strings, not their Java
   primitive types.** All admitted non-Component arguments, including null,
   Boolean and numeric wrappers, go through String.valueOf(Object) and the String
   JsonPrimitive constructor. Thus null becomes the string "null", true becomes
   "true", and Float/Double special values can be string "NaN"/"Infinity".
   A native-output parser must not admit JSON null/number/boolean argument values
   merely because the source preflight permits their Java counterparts.
3. **The claimed finite chat union needs a nested receiver boundary.** Exact
   MutableComponent/Style/HoverEvent checks do not check exact ClickEvent or
   HoverEvent.EntityTooltipInfo classes. Both are non-final with public
   constructors and overridable methods; SHOW_ENTITY serialization dispatches
   virtually to EntityTooltipInfo.serialize. Its subtype can supply a JsonElement
   outside the ordinary native shape while passing this preflight. This is a
   static admission gap, not an observed custom receiver in the fixed fixture.
   A universal closed-union/depth proof therefore remains unfinished. No source
   edit or policy decision is made here.
4. **For ordinary pinned nested receivers, JSON depth 64 is sufficient for the
   source chat depth 8; global node 65536 is not derived from the source caps.**
   SHOW_ENTITY contributes three container levels per component edge. The
   complete ordinary chat can reach at most container depth 32 from the trace
   root (scalar depth 33). Component objects have at most 14 members; arrays
   with/extra are bounded independently. A per-chat conservative value/container
   node bound is 800, but 20 rows x 64 chats x 800 is 1024000 before byte limits.
   The byte cap alone does not prove the proposed 65536 token/node bound.
   Its counting definition and an evidence-based whole-trace compatibility
   argument remain necessary; do not enlarge it after an observed rejection.
5. **SpawnDimension's ordinary native wire type is statically proved StringTag
   (NBT type 8), not assumed.** ResourceLocation.CODEC is Codec.STRING with
   decode ResourceLocation.read and encode ResourceLocation.toString;
   Codec.STRING writes DynamicOps.createString, and NbtOps.createString creates
   StringTag. Load uses Level.RESOURCE_KEY_CODEC via ResourceKey.codec and the
   same ResourceLocation codec. Disk presence, actual save, reacquisition and
   restart remain unexecuted in this task.
6. **Strict UTF-8 capture is not established by the unchanged Java 17 recipe.**
   JDK System initializes stdout from sun.stdout.encoding when supplied, otherwise
   the PrintStream default charset; Charset.defaultCharset resolves file.encoding.
   Neither the stated argv nor static library equality proves their future
   process values. The old retained stdout was decoded/re-encoded by a lossy
   historical helper, so its ASCII line cannot qualify arbitrary Unicode bytes.

## Authority, fixed inputs and integrity

Exclusive write scope is this report's leaf:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-wire-qualification-20261009-17/.
No source/worktree/HEAD/index/process interest was acquired; no worktree, runtime,
world, network, Gradle, GameTest, driver/parser/test or cleanup was created/run.
Read-only Git commands name fixed objects, not a moving HEAD. Root coordinates
OpenPet; this worker sends no pet events and delegates no work.

Fixed corrected source: 5b45132000ade1e3c8d130a6b8ccb29f07535124.
Fixed governance/owner record: 48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514.
Mandatory fixed governance files, active uppercase v1.8 document, post-v1.0 and
parallel rules are captured under governance-00 through governance-10.
Working AGENTS was read as supplied; it is not substituted for the fixed source.
Source-only adapters and pinned installed platform/library bytecode are inspected;
no upstream code/assets, complete primary JAR or source tree are bundled.

Actual verification (27-input-verification.*, INPUT-VERIFICATION.json):

| Leaf/input | REPORT SHA256 | Manifest SHA256 | Covered files checked |
|---|---|---|---:|
| Task 15 | d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277 | 6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760 | 148 |
| Root Task 11 | 0c82a4097db51bb98e1f45d819126ba87f1d7946c7b0d15157136f50fa19eebb | 8f6a602a85fb91ab194068ee119ac3e72b170d95c06701aba38da56b1dd175f1 | 835 |
| Independent Task 12 | dadc06c556466d0f353fe96db68327208da5e40b89de883fb1eb6faa08d5cb31 | 542d90ea3197a1a3615ebf5b1a16048fea0a0c14dcdcdc6704904756c307c0f6 | 895 |

All named hashes and every checked leaf-relative covered file match; no original
seal was changed. PROPOSED-DRIVER-02.md is 46009 bytes, SHA256
628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec.
Source fixed Git output identities match the independent corrected review:
Fixture 33987 bytes /1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820;
Trace 31470 /39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0.
The full proposal and sibling REPORT/seal bytes were captured; focused contract
sections were reread. Task 11/12 complete reports were read as regression inputs,
not credited as this worker's reruns. Their strict TIMEOUT/log/retention limits
and unexecuted packaged/twenty-case/disk boundaries are retained.

## Primary tool, archive and entry identities

PRIMARY-INPUTS.json, RUNTIME-PRIMARY-INPUTS.json and FINAL-PRIMARY-INPUTS.json
record selected entry/container lengths and hashes. Representative whole inputs:

| Input | Bytes | SHA256 |
|---|---:|---|
| Installed mapped Forge 1.20.1-47.4.10 JAR | 19355242 | 95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e |
| Recipe Forge server JAR | 4848366 | 1dcf74ad4961877f5c79d29b361596fd4222c8849f6db31fbcf663d1ba5ff072 |
| Recipe server SRG JAR | 14086905 | cba463381db0c98d6da71ab879c8eee4e66146cb1af5449cf1525f159f56bba2 |
| Recipe fmlloader JAR | 267079 | 12d27a5d59286ab5fa8cc90cb2c73eb21f4624b765ce2e6408d5e397a6a6699b |
| Recipe win_args.txt | 5172 | be6edc64448d827ce12cd64a6781c908761381b377c4b666e480f2d8ac90134f |
| Installed javap.exe | 23696 | 69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d |
| Installed java.exe | 54416 | 308e8c921fd9d152ad526e5f0988682e8f96792a6313f185fa6b20db671a791f |
| Installed JDK lib/modules | 125493164 | 1fa387443737a2b511de1a7f76a50a16404be4a8947ab5d40e5861a4bad89d72 |

JDK modules are hashed only, not copied. Recipe template is the existing
D:/GitHub/AdvancedRocketry-Community/.gradle/v120-jei-session/server libraries.
All 104 historical manifest library entries have identical current installed
bytes/lengths (RECIPE-LIBRARY-COMPARISON.json). This is read-only input equality,
not copied-library/containment/current-launch qualification. The historical
packaged inputs.json hash is 0b8794b1f5a1a9efa29153cf0c1c517e3b2dcce386f970eee90d6326af22a701.
The current Task 11/12 fixture artifact is 191702 bytes,
93194a0bb197b5051174d66f2f4ddcd58649fc0764d83b5da3ac0ab7aca600aa;
it is not the historical jackhammer fixture and was not launched here.

## 1. System.out, bootstrap and framing

Fixture lines 105 and 122 invoke System.out.println(String), respectively for
setup-failure text and the structured marker plus trace.json(). No source logger
call or wrapper is added. Exact fixed-source println uses the runtime System.out,
not Bootstrap's saved stream. Later actual fixture class/reobfuscation/launch
identity still needs the executable qualification manifest.

09-forge-bootstrap.stdout.txt shows actual patched Bootstrap.m_135870_ bytecode
0..105: registries/bootstrap work plus Forge GameData.vanillaSnapshot and
NetworkHooks.init, but no call to m_135890_. The retained private m_135890_
bytecode still contains System.setErr/setOut of LoggedPrintStream or
DebugLoggedPrintStream depending on LOGGER.isDebugEnabled. Its mere existence
is not an active stdout route. primary-00 supplies the readable mapped names
bootStrap/wrapStreams. This distinction resolves the prior public-API ambiguity
without invoking a private method or modifying access.

CommonLaunchHandler.preLaunch reads log4j2.xml from the fmlloader module and
reconfigures Log4j (routing-complete lines 40..97; bytecode 0..111). The selected
fmlloader XML hash is b51029523df8874beca56c09ce4310bdae7f0885dc1412f8830f62f04c19db83.
It defines TerminalConsole and file/GUI patterns, default INFO Mojang/Minecraft
and console, DEBUG debug-file threshold, and relevant property overrides.
These patterns format logger events, not the ordinary System.out println that
Forge Bootstrap leaves unwrapped. Early modlauncher/Mojang resources were also
inspected and identified; they are not silently selected as final Forge config.
No current logger-property/profile value or transformed runtime route is observed.

If vanilla wrapStreams were active in a separately qualified recipe, the pinned
LoggedPrintStream.logLine template is "[{}]: {}" and DebugLoggedPrintStream's is
"[{}]@.({}:{}): {}" with file name/line number from a stack frame. Neither is a
class/method wrapper contract, and logger layout adds another outer prefix.
primary-01/02 establish those possibilities only. This task qualifies no wrapper
fallback, permissive logger/thread prefix or ANSI stripping for the proposed recipe.

Historical retained stdout.txt is 30909 bytes,
7acaab4ff7eacf3c0f8c203d8b0b0f1a9932d8682e1905fbcf05e9608900d294.
Line 188 begins exactly ARCE_JACKHAMMER_CONTINUATION followed by an ASCII space;
the retained line ends LF (35-final-primary-identity). The old driver uses decoded
text/errors=replace and retained lines, so this is a historical retained marker
spelling/position, not lossless original process-byte or line-ending proof.

Supported proposed grammar remains only a marker at byte-line start,
ARCE_SLEEP_BOUNDARY_OBSERVATION plus one ASCII space and one bounded JSON object,
with LF/CRLF terminator, bound to the owned process and nonoverlapping command
cursors. No leading whitespace, echo/quoted marker, logger wrapper or setup-failure
substitute is supported. Native println string output is charset-dependent;
JDK System.newPrintStream, initPhase1, Charset.defaultCharset and PrintStream
println/newLine bytecode are captured in jdk-system/jdk-printstream.
Actual stdout encoding and line separators must be frozen before executable
review. A later assignment can resolve them with qualified recipe/input evidence;
this static task neither adds an encoding JVM flag nor launches discovery.

## 2. Ordinary native component serializer union and accounting

The following is the ordinary pinned class-method union, qualified to unmodified
nested native receivers, not arbitrary admitted subclasses. primary-03 serialize
(Component,Type,Context) starts at line 417; runtime-0 confirms the SRG recipe
implementation and branch structure. Native component output is always an object;
primitive/root-array inputs accepted by native deserialization are not emitted
by this serialization route.

Content is exactly one of:
- text:string for LiteralContents; text:"" for ComponentContents.EMPTY.
- translate:string, optional fallback:string, optional nonempty with:array.
  with entries are recursively serialized Component objects or JSON strings from
  String.valueOf of admitted String/null/Boolean/Integer/Long/Short/Byte/Float/Double.
Optional nonempty extra:array contains recursively serialized sibling objects.
The source excludes score/selector/keybind/NBT/custom content and SHOW_ITEM.
The native serializer supports more branches, but they are not this capture union.

Style is flattened into the component object, not nested under a style key.
Optional bold/italic/underlined/strikethrough/obfuscated values are JSON booleans;
color/insertion/font are strings; clickEvent is {action:string,value:string};
hoverEvent is {action:"show_text",contents:ComponentObject} or
{action:"show_entity",contents:{type:string,id:string,name?:ComponentObject}}.
No hover legacy value property is emitted. SHOW_ENTITY id is UUID.toString;
type is the registry ResourceLocation.toString. Empty Style serializes null and
Component skips it; optional fields are omitted rather than emitted as null.
Click serialization does not perform the server-allowed-action filter used by
deserialization. The enum includes open_url/open_file/run_command/suggest_command/
change_page/copy_to_clipboard. Color uses a known native name or # plus formatted
uppercase hex; fromRgb(int) does not enforce 24-bit input, so hex need not be
exactly six digits. Font/type are combined ResourceLocation strings: separate
source namespace/path caps 1024 allow combined length up to 2049, not 1024.

Evidence: primary-04 Style.serialize bytecode 0..253; primary-05 HoverEvent.serialize
0..39; primary-06 EntityTooltipInfo.serialize 0..63; runtime-1/2; extra-0,
28-extra-primary and 30-hover-dispatch. 30-hover-dispatch line 213 and its bootstrap
method handle explicitly show REF_invokeVirtual EntityTooltipInfo.serialize.
Trace lines 240..293 show the preflight's actual checks, including missing exact
ClickEvent/EntityTooltipInfo checks. This prevents claiming universal custom
receiver rejection, maximum nesting or pre-allocation safety from that source.
No subtype was instantiated, reflected into, invoked, tested or injected here.

For the ordinary union, depth accounting counts root JSON object as depth 1:
trace root/cases/row/outputs/output/component = depth 6. Sibling/with component
edges add two containers; SHOW_TEXT adds two; SHOW_ENTITY name adds three.
With at most eight source component edges, deepest component is depth 30.
A leaf SHOW_ENTITY with no name adds hover/contents objects at depth 31/32
without another component edge (33 if scalar values count). This proves
ordinary chat structural compatibility with parser nesting 64, not arbitrary
nested subtype output. Depth checks must still happen before tree allocation.

Source component budget counts visits (including shared references repeatedly),
not unique identities: at most 32 visits, depths 0..8, <=32 siblings per component
(with global count usually tighter), <=4 args. An object has <=14 keys, with/extra
arrays <=4/31 under the global visit cap, hover entity contents <=3 keys and
click/hover objects <=2. Conservative JSON value/container count is <=25 per
component visit, hence <=800 per chat; counting keys as tokens adds another
explicit dimension. The source's 8192 estimate counts escaped admitted text,
not all emitted primitive-argument strings; per-component 1024 overhead plus
actual post-serialization byte check supplies a separate byte boundary.

The proposal's generic 4096 string and 64 object-key limits accommodate this
ordinary union when source-specific caps are applied to the correct fields.
Its whole-trace 65536 token/node cap needs a precise definition and derivation.
For example, a source-admitted ordinary component with 31 translatable siblings,
each with four empty-string args, has many small JSON nodes without consuming
source text budget. This is an analytic permitted shape, not generated/native
fixture evidence. It illustrates why UTF-8 byte and component-visit budgets are
not interchangeable with whole-trace token counts. An additional defensive
parser refusal remains possible; it must be explicitly accounted as capture
failure, not silently treated as source closure or native success.

## 3. Typed Spawn serialization and fresh-only default mapping

Native save: primary-11 addAdditionalSaveData line 607, bytecode 246..360,
and runtime-5 corresponding SRG method. A non-null respawnPosition writes:
SpawnX/Y/Z = IntTag type 3 (signed int32); SpawnForced = ByteTag type 1 from
putBoolean (0/1); SpawnAngle = FloatTag type 5 (IEEE754 binary32); SpawnDimension
= StringTag type 8 with ResourceLocation.toString, via codec resultOrPartial
and ifPresent. The codec can report an error; a full present set is not assumed
merely because the method exists. Null position skips all six Spawn writes.
The actor getter projection remains dimension/position/raw-angle-bits/forced,
not an NBT writer or a serialized snapshot.

ResourceLocation static codec bytecode and resource-verbose bootstrap handles
bind Codec.STRING to read/toString, rather than inferring invokedynamic targets.
Codec$16.write calls DynamicOps.createString (codec-0); Encoder.encodeStart
passes ops.empty (codec-2); PrimitiveCodec.encode merges the primitive with that
empty value (dfu-1); NbtOps creates StringTag and accepts StringTag on read
(primary-10 lines 212/229). ResourceKey.codec maps that same ResourceLocation
codec to/from the registry key (resourcekey-verbose); Level initializes its
RESOURCE_KEY_CODEC with Registries.DIMENSION (28-extra-primary lines 2530..2534).
31-tags-primary establishes typed IDs and DataOutput.writeInt/writeByte/
writeFloat/writeUTF payload methods. NBT StringTag uses Java modified UTF-8,
not ordinary UTF-8. A future bounded reader must implement that wire encoding
or explicitly constrain supported strings; default minecraft:overworld is ASCII.
The proposed string-byte ceiling 65535 matches writeUTF's unsigned length form.
The pinned Forge StringTag writer catches UTFDataFormatException, logs failure
and writes an empty string; this is not successful preservation of an oversized
source string, and no disk/log equivalence is inferred from the cap.

Native load: primary-11 readAdditionalSaveData line 469, bytecode 174..321.
It checks all coordinates with contains(name,99), accepting any native numeric
tag before getInt coercion; forced/angle likewise use native getters. It reads
SpawnDimension only inside that coordinate branch, parses with Level's codec,
and falls back to OVERWORLD on unsuccessful parse after logging. The offline
parser's exact IntTag/ByteTag/FloatTag/StringTag validation is intentionally
stricter; it must not claim native load rejects every type it rejects.
Partial/mistyped/coerced data remain findings outside fresh-scope success.

Fresh ServerPlayer constructor initializes respawnDimension=OVERWORLD; Java
initial defaults leave position null, angle +0.0f (raw bits 0), forced false.
For either newly acquired owned actor, a completely absent serialized Spawn set
maps, under this fresh-object rule only, to minecraft:overworld/null/0/false.
For a present valid six-tag set, preserve each wire type/value and Float raw bits
and map the decoded dimension key without converting omission to an emitted tag.
A present coordinate set without angle/forced/dimension uses native defaults/
retained constructor values on fresh load, but is not the fully typed native
saved-set result this parser should accept. Invalid dimension fallback is not
an equivalence success. Null-position getters with nondefault ancillary fields
lose those fields on save; report non-equivalence, never synthesize preservation.

Both actors are fixed UUIDs 3ec99863-f1a1-4ba6-8aaa-390209dbe2d0 and
c5c1adf3-c2b4-4f57-8c98-576bfe5bbcf5. Fixture lines 178..179 capture loaded Spawn
and dimension before resets; lines 325..343 restore them via the public setter,
check getters, record native_logout_save_input and call native PlayerList.remove.
Hence retained playerdata would describe teardown/logout-save, not per-case
bed outcomes. Declared home resets are not predicted saved values. Invocation 2
would be same-process UUID reacquisition; no restart/death proof follows.
This task writes/reads no native playerdata, invokes no setter and makes no
claim about successful restoration, codec execution, disk flush or restart.

## Proposed parser compatibility and unfinished freeze

| Boundary | Evidence-supported result | Still required |
|---|---|---|
| Raw marker start | Supported for pinned patched Forge recipe and historical retained ASCII line | Actual corrected fixture bytecode/owned launch identity; stdout charset/line terminator |
| Logged wrapper fallback | Not qualified; ordinary recipe does not call vanilla wrapper | Separate exact recipe/outer logger/receiver proof before any wrapper admission |
| Ordinary component content/style/hover | Exact union above; non-Component args are strings | Account missing nested exact-receiver checks; do not infer custom-shape closure |
| Depth 64 /object keys 64 /string 4096 | Compatible with ordinary bounded union and correct combined-ID handling | Universal subclass boundary; precise token/node definition and whole-trace bound |
| SpawnDimension StringTag | Codec chain and read/write type statically established | Later actual typed two-file save copies, codec/log/presence evidence |
| Fresh absent Spawn mapping | Overworld/null/+0.0/false for fresh constructor only | Actual loaded/restored getters and disk comparison; no prior-world/restart inference |
| Bounded NBT parser | Types, presence and modified-UTF-8 requirement identified | Committed reviewed implementation/mutation tests and actual retained disk input |

Task 11/12 supply actual source/build/API/artifact regression identities, not this
worker's executions and not packaged observation evidence. Their matching host,
API, source and corrected consumer hashes do not resolve stdout Unicode, native
chat output, disk fields, control reachability or two-invocation teardown outcomes.
No assumed successful gameplay output was inserted into a prompt, parser or test.

## Commands actually run, failures and evidence limitations

Material captured reads/hash/ZIP/Git/javap checks have .command.json receipts
(pre-start UTC, actual argv/cwd, finish UTC and exit) and unmodified separate raw
stdout/stderr. inspect_primary/inspect_recipe/finish_inspection capture each
nested javap/Git command separately with a 180-second subprocess timeout.
All actual completed inspection commands finish well below 180 seconds.
No runtime command, library download, native server, test, parser implementation,
Gradle, network, cleanup, process termination, commit or push was run.

Successful cohorts: 03-inputs, 05-paths, 06-boundaries, 07-recipe, 08-primary,
09-forge-bootstrap, 10-focused, 11/12 fixed adapters, 13/14 serializer sections,
19..35 focused/hash/static checks, all primary-00..12, runtime-0..5, dfu/codec/
extra/routing/JDK/governance nested javap/Git commands. Seals/library comparison
and fixed adapter hash checks succeed. Some broad tool displays were truncated;
raw evidence is complete and focused reads followed. No truncated display is
credited as a native outcome or test result.

Preserved failing captured cohorts: 01-governance PowerShell quoting parse error;
02-inputs guessed lowercase version path absent; 04-contract guessed Task 16
filename absent (PowerShell continued subsequent reads and exited 0, so its
nonempty stderr is retained as a failure despite that exit). Correct uppercase
version and actual Task 16 filename were subsequently read.

Preparation/transport limitations exist outside archived receipts: initial Python
helper creation failed with a SyntaxError before it could exist; exploratory
Python-shim commands with parentheses produced no intended receipts, and a
pipe-containing rg argument through the shim failed before capture began.
A subsequent attempted receipt read confirmed the missing files. These failures
are visible in the coordination/tool transcript; original UTC/raw files were not
available and are not reconstructed. Later checks use the absolute installed
Python executable and succeed with proper receipts. Consequently this package
must not be described as a fully instrumented transcript of every preparation
command. All relied-on wire findings have separate successful primary receipts.

## Completion, files, risks and acceptance

Completed: fixed input/hash/seal verification; corrected source/governance and
regression-boundary reading; installed/native recipe primary inspection; raw vs
wrapper route distinction; ordinary native serializer union/depth/primitive
analysis; dimension codec/typed Spawn/default projection analysis; this report
and compact raw command/identity evidence. Modified files are exclusively this
leaf's evidence/docs/helpers; no code/assets/provenance/save/network/API changed.
No tests were added, modified or run by this task.

Uncompleted: exact future process stdout encoding; universal nested-receiver/chat
union closure; defined/derived global token budget; committed driver/parser/test
qualification; actual packaged source/artifact/config/copy containment; twenty
native rows/two-invocation/control/effect/teardown outcomes; typed playerdata,
flush/reacquisition/exit/restart proof; broader B1/R1/M1/M2/D1, gameplay, real
client/TCP/mod/host/GPU/multiplayer/performance/provenance/item/ledger acceptance.
Known risks are the six findings and preparation evidence gaps above. They are
not cured by sealed historical regression receipts or method existence.

Current and inherited v1.8 Required Gates G0-G9 are **not all satisfied**. This
worker makes no cause/enforcement/gameplay decision, authority expansion, waiver,
Gate PASS, release or item-delivery claim. Next work within v1.8 is a separate
contract disposition/freeze resolving these boundaries, followed only by a
separately assigned implementation/independent review and later bounded runtime.

Root must read this complete REPORT before one-time leaf-relative SHA256SUMS
sealing. No current seal/read acknowledgement is inferred. Final actual seal
identities will be reported after that coordination instruction; no manifest
will cite external mutable build/Temp paths as its covered files.
