import datetime,hashlib,json,pathlib,subprocess,sys
p=pathlib.Path(__file__).parent
argv=[sys.executable,'-B',str(p/'seal.py')]
r={'pre_start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(pathlib.Path.cwd()),'ceiling_seconds':180,'excluded_from_manifest':['SEAL-RESULT.json','SEAL-STDOUT.txt','SEAL-STDERR.txt']}
(p/'SEAL-COMMAND.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
x=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
(p/'SEAL-STDOUT.txt').write_bytes(x.stdout);(p/'SEAL-STDERR.txt').write_bytes(x.stderr)
r.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=x.returncode,stdout={'bytes':len(x.stdout),'sha256':hashlib.sha256(x.stdout).hexdigest()},stderr={'bytes':len(x.stderr),'sha256':hashlib.sha256(x.stderr).hexdigest()})
if x.returncode==0:r['actual_seal_result']=json.loads(x.stdout)
(p/'SEAL-RESULT.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
sys.stdout.buffer.write(x.stdout);sys.stderr.buffer.write(x.stderr);sys.exit(x.returncode)
