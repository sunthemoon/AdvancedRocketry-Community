import hashlib,json,pathlib,stat
p=pathlib.Path(__file__).parent
excluded={'SHA256SUMS.txt','SEAL-RESULT.json','SEAL-STDOUT.txt','SEAL-STDERR.txt'}
assert not (p/'SHA256SUMS.txt').exists(), 'one-time seal already exists'
rows=[];total=0
for f in sorted(p.rglob('*')):
 assert not f.is_symlink() and not f.is_junction() and not (getattr(f.lstat(),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT),str(f)
 if not f.is_file():continue
 n=f.relative_to(p).as_posix()
 assert not n.startswith('/') and '..' not in pathlib.PurePosixPath(n).parts
 if n in excluded:continue
 b=f.read_bytes();rows.append((hashlib.sha256(b).hexdigest(),n));total+=len(b)
manifest=''.join(h+'  '+n+'\n' for h,n in rows)
(p/'SHA256SUMS.txt').write_text(manifest,encoding='utf-8',newline='\n')
assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h for h,n in rows)
result={'report_sha256':hashlib.sha256((p/'REPORT.md').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((p/'SHA256SUMS.txt').read_bytes()).hexdigest(),'covered_files':len(rows),'covered_bytes':total,'manifest_bytes':(p/'SHA256SUMS.txt').stat().st_size,'excluded_files':sorted(excluded)}
print(json.dumps(result,indent=2))
