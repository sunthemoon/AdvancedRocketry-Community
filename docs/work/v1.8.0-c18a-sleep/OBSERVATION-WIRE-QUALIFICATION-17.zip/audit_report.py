import pathlib,json,hashlib
p=pathlib.Path(__file__).parent
q=p.parent/'sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md';print('PROPOSAL',len(q.read_bytes()),hashlib.sha256(q.read_bytes()).hexdigest())
for n in ['primary-06','primary-11','primary-12','31-tags-primary','runtime-0','runtime-1','runtime-2','runtime-3','runtime-4','runtime-5','30-hover-dispatch']:
 lines=(p/(n+'.stdout.txt')).read_text().splitlines();print('\nVERIFY',n)
 terms=['getId();','write(','respawnDimension','public class net.minecraft.network.chat.ClickEvent','public net.minecraft.network.chat.ClickEvent','getValue();','m_135890_','RESOURCE_KEY_CODEC']
 for i,l in enumerate(lines):
  if any(t in l for t in terms):print(i+1,'\n'.join(lines[max(0,i-2):i+11]))
for n in ['35-final-primary-identity','29-final-inspection','27-input-verification']:
 r=json.loads((p/(n+'.command.json')).read_text()); print(n,r['exit_code'],r['pre_start_utc'],r['finished_utc'])
