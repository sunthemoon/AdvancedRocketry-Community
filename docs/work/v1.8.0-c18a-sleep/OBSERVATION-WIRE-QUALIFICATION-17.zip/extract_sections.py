import pathlib,re,sys
p=pathlib.Path(__file__).parent
for name,patterns in [('primary-03',['serialize(net.minecraft.network.chat.Component','serializeStyle','lambda']),('primary-04',['serialize(net.minecraft.network.chat.Style']),('primary-05',['serialize()']),('primary-06',['serialize()']),('primary-08',['static {}','read(java.lang.String)']),('primary-10',['createString','getStringValue']),('primary-11',['readAdditionalSaveData','addAdditionalSaveData','ServerPlayer(net.minecraft.server.MinecraftServer']),('dfu-0',['static {}']),('dfu-1',['encode','decode'])]:
 lines=(p/(name+'.stdout.txt')).read_text().splitlines()
 chunks=[];start=0
 for i,l in enumerate(lines):
  if l.startswith('  ') and not l.startswith('    ') and (';' in l or l.strip()=='static {};'):
   if i>start:chunks.append((start,lines[start:i]))
   start=i
 chunks.append((start,lines[start:]))
 for n,ls in chunks:
  if any(x in ls[0] for x in patterns):
   print('\n====',name,'line',n+1);print('\n'.join(ls))
