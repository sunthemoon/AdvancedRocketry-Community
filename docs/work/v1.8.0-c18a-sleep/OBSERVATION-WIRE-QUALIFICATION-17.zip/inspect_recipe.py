import pathlib,hashlib,json,subprocess,datetime,zipfile
p=pathlib.Path(__file__).parent; t=pathlib.Path(r'D:\GitHub\AdvancedRocketry-Community\.gradle\v120-jei-session\server/libraries'); javap=r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe'; server=t/'net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-server.jar';srg=t/'net/minecraft/server/1.20.1-20230612.114412/server-1.20.1-20230612.114412-srg.jar'
def run(n,a):
 r={'pre_start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':a,'cwd':str(pathlib.Path.cwd())};x=subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);r.update(exit_code=x.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(p/(n+'.stdout.txt')).write_bytes(x.stdout);(p/(n+'.stderr.txt')).write_bytes(x.stderr);(p/(n+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');print(n,x.returncode,len(x.stdout))
classes=['net.minecraft.network.chat.Component$Serializer','net.minecraft.network.chat.Style$Serializer','net.minecraft.network.chat.HoverEvent$Action','net.minecraft.resources.ResourceLocation','net.minecraft.nbt.NbtOps','net.minecraft.server.level.ServerPlayer']
entries=[]
for i,c in enumerate(classes):
 n=c.replace('.','/')+'.class'
 for f in [server,srg]:
  with zipfile.ZipFile(f) as z:
   if n in z.namelist():
    b=z.read(n);entries.append({'entry':n,'container':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});run('runtime-'+str(i),[javap,'-p','-c','-s','-classpath',str(f)+';'+str(srg),c]);break
for f in [t/'net/minecraftforge/fmlloader/1.20.1-47.4.10/fmlloader-1.20.1-47.4.10.jar',t/'cpw/mods/modlauncher/10.0.9/modlauncher-10.0.9.jar',t/'net/minecrell/terminalconsoleappender/1.2.0/terminalconsoleappender-1.2.0.jar']:
 with zipfile.ZipFile(f) as z:
  for n in z.namelist():
   if n.endswith('.class'):
    b=z.read(n)
    if b'setOut' in b or b'log4j.configuration' in b or b'log4j2.xml' in b:
     entries.append({'entry':n,'container':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});print('ROUTING',f,n);run('routing-'+str(len(entries)),[javap,'-p','-c','-s','-classpath',str(f),n[:-6].replace('/','.')])
dfu=t/'com/mojang/datafixerupper/6.0.8/datafixerupper-6.0.8.jar'
for i,c in enumerate(['com.mojang.serialization.Codec$16','com.mojang.serialization.Codec$2','com.mojang.serialization.Encoder']):run('codec-'+str(i),[javap,'-p','-c','-s','-classpath',str(dfu),c])
run('jdk-printstream',[javap,'-p','-c','-s','java.io.PrintStream'])
(p/'RUNTIME-PRIMARY-INPUTS.json').write_text(json.dumps(entries,indent=2)+'\n')
