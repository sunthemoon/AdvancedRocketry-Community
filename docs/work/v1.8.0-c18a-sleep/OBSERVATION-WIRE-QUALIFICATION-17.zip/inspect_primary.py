import datetime,hashlib,json,pathlib,subprocess,zipfile
p=pathlib.Path(__file__).parent; root=pathlib.Path(r'D:\GitHub\AdvancedRocketry-Community'); t=root/'.gradle/v120-jei-session/server'; mapped=pathlib.Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'); javap=pathlib.Path(r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe')
inputs=[]
def identify(f):
 b=f.read_bytes();d={'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};inputs.append(d);return d
for f in [mapped,javap,pathlib.Path(r'C:\Program Files\Java\jdk-17.0.7\release'),t/'libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt']: print(identify(f))
classes=['net.minecraft.server.Bootstrap','net.minecraft.server.LoggedPrintStream','net.minecraft.server.DebugLoggedPrintStream','net.minecraft.network.chat.Component$Serializer','net.minecraft.network.chat.Style$Serializer','net.minecraft.network.chat.HoverEvent','net.minecraft.network.chat.HoverEvent$EntityTooltipInfo','net.minecraft.network.chat.HoverEvent$ItemStackInfo','net.minecraft.resources.ResourceLocation','net.minecraft.resources.ResourceKey','net.minecraft.nbt.NbtOps','net.minecraft.server.level.ServerPlayer','net.minecraft.nbt.CompoundTag']
def run(name,argv):
 r={'pre_start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(pathlib.Path.cwd())};x=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);r.update(exit_code=x.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(p/(name+'.stdout.txt')).write_bytes(x.stdout);(p/(name+'.stderr.txt')).write_bytes(x.stderr);(p/(name+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,x.returncode,len(x.stdout));return x.stdout
for i,c in enumerate(classes):run('primary-'+str(i).zfill(2),[str(javap),'-p','-c','-s','-classpath',str(mapped),c])
for f in sorted((t/'libraries').rglob('*.jar')):
 with zipfile.ZipFile(f) as z:
  selected=[n for n in z.namelist() if n.endswith('/Bootstrap.class') or n.endswith('/ConsoleHandling.class') or n.endswith('/LogUtils.class') or n in ['log4j2.xml','log4j2_server.xml']]
  if selected:
   print('RECIPE PRIMARY',identify(f))
   for n in selected:
    b=z.read(n);d={'container':str(f),'entry':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};inputs.append(d);print(d)
    if n.endswith('.xml'): print(b.decode('utf-8'))
  if f.name=='datafixerupper-6.0.8.jar':
   identify(f)
   for j,c in enumerate(['com.mojang.serialization.Codec','com.mojang.serialization.codecs.PrimitiveCodec','com.mojang.serialization.DynamicOps','com.mojang.serialization.DataResult']):run('dfu-'+str(j),[str(javap),'-p','-c','-s','-classpath',str(f),c])
with zipfile.ZipFile(mapped) as z:
 for c in classes:
  n=c.replace('.','/')+'.class';b=z.read(n);inputs.append({'container':str(mapped),'entry':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(p/'PRIMARY-INPUTS.json').write_text(json.dumps(inputs,indent=2)+'\n')
