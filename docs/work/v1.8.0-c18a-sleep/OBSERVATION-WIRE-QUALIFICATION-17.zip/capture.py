import datetime,json,pathlib,subprocess,sys
p=pathlib.Path(__file__).parent
name=sys.argv[1]; argv=sys.argv[2:]
r={'pre_start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(pathlib.Path.cwd())}
x=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(p/(name+'.stdout.txt')).write_bytes(x.stdout); (p/(name+'.stderr.txt')).write_bytes(x.stderr)
r['exit_code']=x.returncode;r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/(name+'.command.json')).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
sys.stdout.buffer.write(x.stdout);sys.stderr.buffer.write(x.stderr);sys.exit(x.returncode)
