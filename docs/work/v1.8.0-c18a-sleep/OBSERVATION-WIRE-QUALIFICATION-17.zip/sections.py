import pathlib,sys
p=pathlib.Path(__file__).parent
lines=(p/(sys.argv[1]+'.stdout.txt')).read_text().splitlines();starts=[i for i,l in enumerate(lines) if l.startswith('  ') and not l.startswith('    ') and (';' in l or l.strip()=='static {};')]+[len(lines)]
for start,end in zip(starts,starts[1:]):
 if any(s in lines[start] for s in sys.argv[2:]):print('====',sys.argv[1],'line',start+1);print('\n'.join(lines[start:end]))
