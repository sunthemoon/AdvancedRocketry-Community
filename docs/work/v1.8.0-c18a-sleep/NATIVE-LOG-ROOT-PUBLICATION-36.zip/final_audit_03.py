"""Audit actual Root36 receipts and protected committed state."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    result = subprocess.run(['git', *args], cwd=MAIN, capture_output=True, timeout=180)
    assert result.returncode == 0 and not result.stderr
    return result.stdout


head = '9edbcab9ba53f2aaf4861867a916fbe424972c07'
assert git('rev-parse', 'HEAD').decode().strip() == head
assert git('rev-parse', '@{upstream}').decode().strip() == head
assert git('rev-parse', 'HEAD:src').decode().strip() == '85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert git('status', '--porcelain=v1', '--untracked-files=no') == b' M AGENTS.md\n'
assert not git('diff', '--cached', '--name-only')
assert not git('diff', '55cf9bd802be2614fc27d56479684f58caceda60', 'HEAD', '--',
               'src', 'build.gradle', 'compat-test-mod', 'docs/provenance',
               'docs/status/GATE_STATUS.md', 'docs/decisions', 'docs/11-RISK-REGISTER.md',
               'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md')
assert sha((MAIN / 'AGENTS.md').read_bytes()) == 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
rows = []
for path in sorted(LEAF.glob('*.command.json')):
    receipt = json.loads(path.read_text())
    for suffix, identity in receipt['streams'].items():
        raw = (LEAF / (receipt['name'] + '.' + suffix + '.txt')).read_bytes()
        assert len(raw) == identity['bytes'] and sha(raw) == identity['sha256']
    assert receipt['exit_code'] == 0 and not receipt['timed_out']
    rows.append({key: receipt[key] for key in ['name', 'argv', 'start_utc', 'end_utc', 'exit_code']})
record = {'utc': datetime.now(timezone.utc).isoformat(), 'main': head,
          'commands': rows, 'report_sha256': sha((LEAF / 'REPORT.md').read_bytes()),
          'production_unchanged': True, 'gate_approval': False}
with (LEAF / 'FINAL-AUDIT-03.json').open('x', encoding='utf-8') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'commands'}), flush=True)
