"""Rehost fully read Root33 and author34 seals, preserving all older bytes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT=Path(__file__).resolve().parent
DEST=Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
SPECS=[('sleep-d1-outcome-disposition-20261009-33','D1-ROOT-OUTCOME-33.zip',
        '2ad2a21f81ec390c97e1ca3d815f17b2e3c5ccedf13cb289fce64e5138a0ec9f',
        '3cb18850c2ac176744f30a20e653783e99573cfea5a6514a024699a041fdb7d3'),
       ('sleep-compressed-log-contract-revision-20261009-34','NATIVE-LOG-REVISION-34.zip',
        '531ae2fb8fe0619d52c83745fbccfd80594cd8cfdfb42f8dff61f2591b20d88c',
        '7561ac38212b0d003f2698244d567cf4746f8d870ce87176542b9ae2f5558ac5')]
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def safe(path,leaf):
    assert path.resolve().is_relative_to(leaf.resolve())
    current=path
    while current!=leaf.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(),'st_file_attributes',0)&0x400)
        current=current.parent
rows=[]
for leaf_name,archive_name,manifest_sha,report_sha in SPECS:
    leaf=OUT.parent/leaf_name
    manifest=(leaf/'SHA256SUMS.txt').read_bytes()
    assert sha(manifest)==manifest_sha
    covered={}
    for line in manifest.decode('utf-8-sig').splitlines():
        m=re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
        assert m
        expected,name=m.groups()
        pure=PurePosixPath(name)
        assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
        safe(leaf/name,leaf)
        assert sha((leaf/name).read_bytes())==expected
        covered[name]=expected
    assert covered['REPORT.md']==report_sha
    paths={p.relative_to(leaf).as_posix():p for p in leaf.rglob('*') if p.is_file()}
    assert set(paths)-set(covered)=={'SHA256SUMS.txt','SEAL-RESULT.json'}
    assert len(paths)==len({n.casefold() for n in paths})
    target=DEST/archive_name
    assert not target.exists()
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(paths.items()):
            safe(path,leaf)
            assert path.stat().st_size<50*1024**2
            z.write(path,name)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and set(z.namelist())==set(paths)
        for name,path in paths.items():
            assert z.read(name)==path.read_bytes()
        expanded=sum(i.file_size for i in z.infolist())
    rows.append({'archive':archive_name,'bytes':target.stat().st_size,'expanded_bytes':expanded,
                 'sha256':sha(target.read_bytes()),'manifest_sha256':manifest_sha,
                 'covered_files':len(covered),'covered_bytes':sum(paths[n].stat().st_size for n in covered),
                 'excluded_entries':['SHA256SUMS.txt','SEAL-RESULT.json']})
archives=[]
for path in sorted(DEST.glob('*.zip')):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        size=sum(i.file_size for i in z.infolist())
    assert path.stat().st_size<50*1024**2
    archives.append({'path':path.name,'bytes':path.stat().st_size,'expanded_bytes':size,'sha256':sha(path.read_bytes())})
compressed=sum(x['bytes'] for x in archives)
expanded_all=sum(x['expanded_bytes'] for x in archives)
assert max(compressed,expanded_all)<100*1024**2
r={'utc':datetime.now(timezone.utc).isoformat(),'archives':rows,'all_sleep_archives':archives,
   'all_sleep_compressed_bytes':compressed,'all_sleep_expanded_bytes':expanded_all,'approval':False}
with (OUT/'PACKAGING-01.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='all_sleep_archives'}),flush=True)
