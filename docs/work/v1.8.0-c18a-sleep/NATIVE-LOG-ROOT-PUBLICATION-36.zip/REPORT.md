# Root36 static native-log publication report

## Completed scope

Root completely read author34's 262-line proposal and 270-line report before
its seal, and Root33's final report before its separate seal. This checkpoint
verifies and rehosts those two actual immutable evidence sets and publishes
their bounded, still-PROPOSED revision and fresh independent35 assignment.
No independent35 outcome is inferred. Main record commit is
9edbcab9ba53f2aaf4861867a916fbe424972c07, normally pushed on
codex/v1.8.0-classic-content. Parent is 55cf9bd802be2614fc27d56479684f58caceda60.

## Uncompleted scope and design boundaries

Native-log proposal04 explicitly refuses complete capture when compressed or
ambiguous rotation exists. It does not decode gzip, waive diagnostics, change
logging or prove runtime identity/EOF/durability/Unicode/I/O behavior. Proposal03
and this additive candidate remain unadopted and not executable-frozen. Root
does not assign a parser, driver, helper, runtime allocation, quota or invocation.
The twenty observation rows, thirteen D1 rows, B1/R1/M1/M2, prior-world and
client checks remain open. D1's independently reviewed intended outcomes stay
separately frozen; production natural/sleep/spawn/time/air is unchanged.

Stored physical copies and conservative expanded inventory remain distinct.
The unchanged 65011712-byte reserve does not fit the conservative cumulative
measure. No budget change, evidence deletion, cleanup or relabeling is approved.
Task28's .log/.xml-only collector did not retain .gz, so those standard tests do
not establish original rotation completeness or a capture/log Gate pass.

## Modified files and tests

The exact staged and committed scope is seven files:

- docs/status/CURRENT_VERSION.md
- docs/status/COMPLETION-PLAN.md
- docs/work/v1.8.0-implementation-log.md
- docs/work/v1.8.0-c18a-sleep/D1-OUTCOME-FREEZE-33.md (additive note only)
- docs/work/v1.8.0-c18a-sleep/NATIVE-LOG-REVISION-STATUS-36.md
- docs/work/v1.8.0-c18a-sleep/D1-ROOT-OUTCOME-33.zip
- docs/work/v1.8.0-c18a-sleep/NATIVE-LOG-REVISION-34.zip

Actual cached stat: seven files, 134 insertions and two deletions. No code,
build, resources, public API, persistence/schema, provenance, owner decision,
ledger, risk register, ADR or Gate file changes. No tests added or executed.
Complete src tree remains 85f53265bf4ee59b65c4a88664cb2e5e208c583e, equivalent
to the actually qualified d57ecda1f11dab76d882f945b0de606534ef4fb9. No test
receipt is rebound to this documentation commit. Task28 actual build and
separate test each have 2192 tests; native has 594 required passes, with the
documented 62 ERROR /zero FATAL and fixed 180-second strict TIMEOUT still open.

## Actual commands and results

Each captured command has its actual argv/cwd, UTC interval, exit, fixed
180-second ceiling, raw stdout/stderr hash and before/after Git/owner identity
in its own *.command.json and streams. run_36.py reuses only verified, pinned
algorithm bytes from sealed Root33 under this new leaf's __file__ context.
No sealed predecessor is written. Root36 wrapper SHA256 is
cb8e309261fe1f3f5bc7baa7751db6f78f95983de7fd90be1c5bf60acfae513e.

| Receipt | UTC interval on 2026-10-09 | Exit / result |
|---|---|---|
| package-01 | 08:29:01.116464-08:29:01.670910 | 0; actual seals, payloads, CRC, volumes |
| check-02 | 08:31:37.769827-08:31:38.443925 | 0; protected identities and added links |
| whitespace-01 | 08:31:39.123259-08:31:39.251478 | 0; git diff --check |
| stage-01 | 08:31:39.946910-08:31:40.069418 | 0; exact seven task files |
| cached-stat-01 | 08:36:39.365696-08:36:39.440860 | 0; seven files, 134 /2 |
| cached-diff-01 | 08:36:40.132539-08:36:40.191961 | 0; full staged Markdown |
| cached-check-01 | 08:36:40.889772-08:36:40.948549 | 0; cached whitespace |
| commit-01 | 08:37:09.701001-08:37:09.946333 | 0; actual 9edbcab9 commit |
| push-01 | 08:37:10.656955-08:37:14.732311 | 0; normal non-forced push |

The runner's presentation channel displayed Chinese with replacement
characters; raw Git stdout retains correct UTF-8. Root explicitly read the
entire cached-diff-01.stdout.txt as UTF-8 before commit; no source corruption
is inferred, and no raw receipt was rewritten. Historical whole-plan missing
links remain outside this added-link check. Final audit and one-time seal have
their own subsequent actual receipts, not retrospectively invented times.

## Custody and inventory

D1-ROOT-OUTCOME-33.zip: 44305 compressed /131954 expanded bytes, SHA256
ddb08915b590236c548f867462f4a926ee3cf1bf20f6646f2c91d3c23936604f.
Its manifest 2ad2a21f81ec390c97e1ca3d815f17b2e3c5ccedf13cb289fce64e5138a0ec9f
covers 50 files /126826 bytes. NATIVE-LOG-REVISION-34.zip: 340714 compressed
/907168 expanded bytes, SHA256
a394890b605308546e98099843ed8a6dbb1b230cb1a5fdfc5e8efaa026f42745.
Its manifest 531ae2fb8fe0619d52c83745fbccfd80594cd8cfdfb42f8dff61f2591b20d88c
covers 44 files /890872 bytes. Each has only manifest self and later
SEAL-RESULT.json excluded; archive hashes cover those too. Unique safe names,
reparse checks, CRC and actual payload hashes match. Original sets unchanged.

The actual 29 sleep ZIPs total 11599312 compressed /61828259 expanded bytes.
Adding the unchanged reserve gives 76611024 compressed-plus versus 126839971
conservative expanded-plus bytes. The latter exceeds admission before any
unmapped loose/later sets. It is not launch approval. Individual files and
published slice remain below repository limits. No full source, library, world
or build tree is archived. No old denied cleanup or incident is retried.

## Verification status, risks and next current-version work

Independent35 remains in progress at this checkpoint with fixed55cf/d57 inputs;
its findings require complete reading and a separate later disposition. Its
actual audit of later inventory is not adoption of this revision. Preserve
fixed strict timeout, native errors, identity/capture/resource gaps, historical
links, retained denied outputs and external mistaken file. User-owned AGENTS.md
remains untouched/unstaged, SHA256
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
Ledger remains 186 PLANNED /154 REVIEW; all Required Gates G0-G9 remain open.
No release, tag, feature delivery or version PASS is claimed. Next: complete
independent35 disposition, then separately define any still-needed bounded
offline or runtime work from evidence and current-version prerequisites.

Evidence: this exclusive leaf's actual command receipts, PACKAGING-01.json,
CHECK-02.json, final audit, full-read acknowledgment and one-time manifest.
