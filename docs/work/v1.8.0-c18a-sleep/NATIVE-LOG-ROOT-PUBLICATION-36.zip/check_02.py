"""Validate Root36 added links and exact protected record-only scope."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
OUT=Path(__file__).resolve().parent
BASE='55cf9bd802be2614fc27d56479684f58caceda60'
DOCS=['docs/status/CURRENT_VERSION.md','docs/status/COMPLETION-PLAN.md',
      'docs/work/v1.8.0-implementation-log.md','docs/work/v1.8.0-c18a-sleep/D1-OUTCOME-FREEZE-33.md',
      'docs/work/v1.8.0-c18a-sleep/NATIVE-LOG-REVISION-STATUS-36.md']
def git(*args):
    p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True,timeout=180)
    assert p.returncode==0 and not p.stderr
    return p.stdout
assert git('rev-parse','HEAD').decode().strip()==BASE
assert git('rev-parse','@{upstream}').decode().strip()==BASE
assert git('rev-parse','HEAD:src').decode().strip()=='85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').decode().splitlines())=={'AGENTS.md',*DOCS[:-1]}
assert hashlib.sha256((ROOT/'AGENTS.md').read_bytes()).hexdigest()=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
assert not git('diff','--','src','build.gradle','compat-test-mod','docs/provenance',
               'docs/status/GATE_STATUS.md','docs/decisions','docs/11-RISK-REGISTER.md',
               'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md')
links=[]
for name in DOCS:
    if name==DOCS[-1]:
        text=(ROOT/name).read_text(encoding='utf-8')
    else:
        diff=git('diff','--unified=0','--',name).decode('utf-8')
        text='\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' in target or target.startswith('#'):
            continue
        path=((ROOT/name).parent/target.split('#',1)[0]).resolve()
        assert path.is_relative_to(ROOT.resolve()) and path.exists(),(name,target)
        links.append({'file':name,'target':target})
r={'utc':datetime.now(timezone.utc).isoformat(),'main':BASE,'checked_links':links,
   'protected_source_owner_and_gates':True,'whole_historical_portability':False,'approval':False}
with (OUT/'CHECK-02.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='checked_links'}),flush=True)
