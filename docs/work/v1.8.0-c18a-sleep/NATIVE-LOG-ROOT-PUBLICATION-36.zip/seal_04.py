"""Reuse pinned one-time seal with Root36-exclusive output context."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-observation-integration-20261009-32/seal_07.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '36aef0f7873f5673703942ab2f0fe7b3719085a708b16e82e93e785289c86c0f'
source = raw.decode('utf-8').replace('FINAL-AUDIT-06.json', 'FINAL-AUDIT-03.json')
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
