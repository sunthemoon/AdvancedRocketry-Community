# Task53 pure functional offline JSON core author report

## Findings and status

Status: committed and normally pushed **two-file source candidate with 32 passing author functional tests**. Fresh independent actual-code review, decoder resource qualification, Main integration and every applicable v1.8.0 Gate remain open. This report does not establish absence of defects, resource acceptance or delivery/ledger acceptance.

1. Resource qualification is **NOT_EXECUTED**. No process memory, traced peak, lifetime RSS, platform helper, fresh resource case or native/world operation was run. The unchanged later contract requires at most 12 fresh cases, both peaks <=268435456 bytes, decode 60 seconds / external 180 seconds, split streams <=262144 bytes and evidence <=4 MiB. The independent49 terminal lifetime-counter coverage finding R49-01 is not closed by these functional tests or by this author.
2. Development cohort16 failed three test fixture/oracle assertions. The original receipt and raw failure streams remain. Contract-derived byte arithmetic and the exact corrections are recorded in `DEVELOPMENT-CORRECTIONS.md`; no decoder implementation, bound, timeout or assertion type was changed for those failures. Corrected cohort17 passed 27 tests, expanded cohort18 passed 32, and distinct committed cohort31 passed 32.
3. Preparation/capture limitations remain explicit: bootstrap checks and complete mandatory governance/Main AGENTS reads were transcript-only, not saved as split leaf receipts. They must not be represented as newly captured historical raw evidence. Adjacent combined read08 retained its complete bounded raw stream but its tool presentation truncated part of the test file; separate narrow reads09/10 completely displayed that file before implementation writes. No aggregate truncated display is claimed as a complete read.
4. Own capture-helper review found a latent permission mismatch: its original timeout branch could terminate any immediately launched command, rather than only Python. All receipts01–33 completed without timeout or termination. Before normal push34, the branch was limited to the immediately launched Python child; locked stream snapshots and explicit drain completeness were added. This prospective correction does not retrospectively change the old helper or receipt semantics. No process was terminated during this task.

## Completed and excluded scope

Completed: new standard-library-only generic byte decoder, frozen result/metric/error/number records, iterative structural parsing, checked lexical admission, and finite functional tests in the exclusive assigned worktree. Exactly two repository files were added. Helpers, raw command streams, receipts, correction note, committed patch and this report reside only in the new own evidence leaf.

Not completed or authorized: third production module; framing or sleep-chat marker/cursor processing; source-aware schema, Gson row-byte accounting or numeric projection; integer/float range conversion; NBT/log/provenance integration; runtime driver/platform counter binding; memory/resource cohorts; stress/fuzz/random workloads; OS quotas; world, native, Forge, Gradle, dedicated server, restart or client/visual tests; Main merge/push; version, risk, ADR, status, plan or ledger changes. No upstream/Mojang/Forge code or asset was copied, no package installed, and no other agent was delegated.

## Exact source and task identities

- Assignment: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-CORE-FUNCTIONAL-TASK-53.md`, 5793 bytes /85 lines, SHA256 `945ba46e4feaa0e0c3f1d8e907ffef45b466ce47a3e0600a780edbe4c7a4f63d` (complete reread28; the initial bootstrap read preceded own writes).
- Worktree: `D:/GitHub/arce-v180-sleep-json-core-20261009-53`.
- Branch: `codex/v1.8.0-sleep-json-core`.
- Frozen baseline and parent: `e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1`.
- Historical observation source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`, not retested here.
- Source candidate commit: `fa83657f89095a78bfb97ac39918ee1b74139d5b`, message `feat(sleep): add bounded offline JSON core`.
- Normal non-force branch push34 exited 0; local HEAD and upstream both identify `fa83657f89095a78bfb97ac39918ee1b74139d5b` in receipt37. No Main HEAD was moved by this worker.

| Repository file | Lines | Bytes | SHA256 |
| --- | ---: | ---: | --- |
| `scripts/sleep_observation_json_core.py` | 397 | 14387 | `cdf4b6fa93900f41f2ba9e524bc16dbbaec47f739efd9c943fac6864005711d0` |
| `scripts/test_sleep_observation_json_core.py` | 426 | 23605 | `ac44ffdadc879f68b56a8fe8c243c9a418d7d5c6071ce37744b68fd22d3257d1` |

`SOURCE.patch` is the actual fixed baseline-to-candidate two-file Git diff: 39262 bytes /835 lines, SHA256 `bc4cf724f5dfd19f4cff19c69c91390a0a2e3d73df2d4043cc800e116ef1aa83`. Audit42 confirms byte-for-byte equality with the two completely read cached diffs26/27. Cached stat23 was exactly 397+426=823 insertions in two files; cached names25 and committed names33 are exactly these two additions. Cached check24 and fixed committed diff check41 exited 0. Worktree status32/40 is empty.

The decoder class occupies lines 84–377 (294 lines); the complete production module is below the 500-line review threshold. The test class is also below 500 lines. Source comments/docstrings use the adjacent modules' English convention; Unicode test literals are intentional scalar/normalization fixtures.

## Normative inputs and actual custody

The complete proposals37/43, not their summaries, govern implementation. Their historical PROPOSED text was not edited. Committed disposition52 freezes their stated internal contract only, and does not grant resource/native/Gate acceptance.

| Fully read input | Bytes / lines | SHA256 |
| --- | --- | --- |
| Fixed `docs/work/v1.8.0-c18a-sleep/OFFLINE-CORE-CONTRACT-FREEZE-52.md` at e21 | 7949 /120 | `445be05d7e086b0d2d346f239f6ae71c896941f77fe7475eb51e9666974826ae` |
| 37 `PROPOSED-OFFLINE-JSON-CORE-01.md` | 19096 /271 | `f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0` |
| 43 `PROPOSED-DIAGNOSTIC-CONVENTION-01.md` | 15960 /244 | `69f6d6b85379b23d67566ead27db5d75e6ef039066e28614f7767ebf29298048` |
| Independent40 final `REPORT.md` | 18632 /280 | `aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60` |
| Independent49 final `REPORT.md` | 24827 /316 | `81ed06d8e26a0999d2f2da5b7254d93c8b01da3bc10e52f33dd8bbd367f7228f` |

Complete input displays are receipts01/02/03/04/06. Seal results were completely displayed in11. Read-only audit12 verified each manifest member's actual SHA256, manifest identity, exact file-set coverage, case uniqueness, contained regular files/no reparse ancestors or members, bounded file/leaf sizes, actual exit/timeout/overflow flags and embedded raw seal stream lengths/hashes. Each embedded stdout JSON equals its stored verification object. Permission messages alone were not treated as seal evidence.

| Input leaf suffix | Covered files / bytes | Full files / bytes | Manifest bytes / SHA256 | Seal-result bytes / SHA256 |
| --- | --- | --- | --- | --- |
| `sleep-offline-json-core-contract-20261009-37` | 90 /649019 | 92 /659856 | 8615 / `1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763` | 2222 / `719d27a044cc4b6e964245e6451cc09bb7d452ddd01c5a207f068cb3ebe3d38f` |
| `sleep-offline-json-core-independent-20261009-40` | 140 /691694 | 142 /705832 | 12457 / `56151ac5caf85fd27df961844c9debffbe85c23c5d97147a82398b121308a3e5` | 1681 / `df4fefb4d7ee3dde29ea75af63dc83439dd489a35854ab7fef27f4db9040a209` |
| `sleep-offline-diagnostic-convention-20261009-43` | 75 /307482 | 77 /317032 | 7205 / `8764692b5fe5b3dc34dfde4c4a39b05786530890174485b472f47a1a5dd19bd9` | 2345 / `a289cfc81540757f252f68f0b88072b1f0f3f53ff2b7c9574f6dc7266e759a83` |
| `sleep-offline-convention-independent-20261009-49` | 173 /514813 | 175 /533339 | 16405 / `008f32c53416765d83360d55344db299329dfa8615b1918e9498673c6e4192a4` | 2121 / `20722c2ef94ff713c567fcf6abb48fb55a656d2c0a0b85965df1fbb4bfc7b2b3` |

Every input packet's exact exclusions are only manifest self `SHA256SUMS.txt` and sole `SEAL-RESULT.json`. No input or peer packet was modified. Historical input failures, cap/ordering/bootstrap/quoting and inner-receipt limitations remain in their sealed records; this current custody check does not repair or reauthorize their historical execution.

## Preparation and adjacent context

Before the first own helper/source write, direct live-agent listing and bounded bootstrap commands checked clean worktree status, exact branch/HEAD and worktree list. Complete fixed e21 governance was read in separate narrow UTF-8 displays: PROJECT-CONFIG.md; PRODUCT.md; docs/01-PORTING-PRINCIPLES.md; docs/04-VERSION-ROADMAP.md; docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md; docs/05-MASTER-TEST-PLAN.md; docs/06-RELEASE-AND-ACCEPTANCE-GATES.md; docs/16-POST-1.0-VERSION-ROADMAP.md; docs/17-V1PLUS-QUALITY-BUDGETS.md; docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md. These child commands used actual 180-second subprocess watchdogs and bounded captured streams, but their complete outputs/hashes are transcript-only, not newly saved raw leaf receipts.

The actual working Main AGENTS.md was completely read before own writes, not replaced by the branch's tracked copy. Its actual identity before and after source work is 15797 bytes /327 lines, SHA256 `c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`. No AGENTS file was written or copied over. Worktree creation receipt supplied by Root was completely displayed in read08; creation was at exact e21, not inferred from permission alone.

Adjacent file discovery07 was limited to sleep/JSON names under scripts. The existing `classic_inventory_fixture_json.py` (10844 bytes /322 lines, SHA256 `fa947139e9f6d759911cd3adc40aef254974c1cbde88603c2ccaa1ad4cec5472`) and its tests (20918 /430, SHA256 `05a336800ab14719ec4a9be7e71e848383df67c0713894cba4ec0dcd60e97c96`) were read. The combined read08 presentation truncation is preserved; complete test ranges1–215 and216–430 were then read in09/10. Its eager full-text decode, recursion, role/schema policy, whitespace and float projection do not match this contract; none was reused as core behavior. Only ordinary English dataclass/unittest conventions were followed.

## Design and frozen functional behavior

- The exact built-in bytes type and actual byte-size preflight precede exact built-in integer deadline checks. Type refusal invokes no arbitrary input len/repr hooks. The deadline is caller-owned absolute monotonic nanoseconds, <=60 seconds after entry, and cannot reset between calls.
- Iterative object/array frames replace recursive parsing. A single admitted mutable tree is built; success returns exclusive ownership, while refusal returns no partial tree. Frozen outer records do not pretend the tree is immutable evidence.
- Values, names and active depth are atomically reserved at recognized legal slot introducers. Node-before-depth and object-name-before-global-name guard ordering, nonrollback failure snapshots and member/array ordinal locations follow43. The global-name guard is checked privately because a successful tree cannot contain 65536 names under the unchanged node cap.
- Consumed bytes are the contiguous committed original prefix. Whole canonical UTF-8 scalars, simple escapes, four-hex non-surrogate escapes and complete twelve-byte surrogate pairs are validated and UTF-16 bounded before commitment. Rejected atoms are not partially consumed. Decoded key aliases are checked before insertion or associated value admission.
- Number scanning is a finite lexical state machine. Every admitted prefix byte is checked against 64; the original bounded ASCII lexeme and original span become JsonNumber. No int/float/Decimal numeric conversion, exponent expansion or Gson/schema projection is performed. `1e999999` remains inert.
- The unchanged caps are input 524288, value nodes 65536, global names 65536, names/object 64, active container depth 64, individual decoded string/name UTF-16 units 4096 and numeric lexeme bytes 64. No public limit override or callback is exposed.
- Deadline checks occur at entry, before every value/key/container reservation, before an advance would reach the 4096-new-byte interval, and before success. Indivisible string atoms are not split. This remains cooperative checking, not OS preemption.
- Error code, byte offset, bounded ordinal tuple, partial/completed original name span, fixed bound name/limit/first attempted observed quantity and admitted-prefix maxima are returned without payload/key text, traceback or arbitrary messages. Only the deliberate private refusal signal is caught; MemoryError or other unexpected implementation exceptions propagate instead of fabricated Refused.

## Actual functional commands and results

Runtime executable observed by audit42: `D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe`, Python 3.13.15, 64-bit AMD64. All four functional cohorts used exact child argv `["python","-B","scripts/test_sleep_observation_json_core.py","-v"]`, cwd `D:/GitHub/arce-v180-sleep-json-core-20261009-53`, external timeout 180 seconds, retained split stream cap 262144 bytes and own leaf cap 4194304 bytes. No timeout, overflow or process termination occurred. Each stdout is empty (SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`). Counts are unittest test methods; finite subtests are not inflated into additional test counts.

| Cohort / source state | UTC start → end on 2026-10-09 | Actual result | Stderr bytes / SHA256 |
| --- | --- | --- | --- |
| 16 development01, uncommitted intermediate | 10:34:47.716602 →10:34:49.235236 | exit1, 26 tests, 3 failed assertions | 6709 / `fc7ee2fbca7e5ea6216c145a8db5bd9ba8bbce8631d1ccd91d044d5cd0456c35` |
| 17 corrected development02, intermediate | 10:35:32.918683 →10:35:34.384087 | exit0, 27 tests, OK | 3885 / `f3e186d4387d19cbd7cd721bbb2ba86d9e2d7142db681b27fc335c910f65e210` |
| 18 expanded development03, intermediate | 10:36:57.329655 →10:36:58.843657 | exit0, 32 tests, OK | 4668 / `392a06c1fe51ec7495ae08ce19444bc6361348457f696e073fb4caa6f0a4d9fb` |
| 31 committed functional at fa83657 | 10:39:17.163183 →10:39:18.677631 | exit0, 32 tests, OK | 4668 / `69ee2d9c274726322ea676992e6cbb65b1888a5dae1833acdc928f69e2e41731` |

These are finite functional boundary checks, not resource measurements: exact supported value/result ownership and order; number lexeme spans; type/preflight precedence including an explicitly permitted unscanned 1 MiB input; independent fake-clock entry/allocation/interval/atomic-atom/final-return checks; literal absolute-deadline reuse; compact object-root syntax and whitespace; malformed UTF-8/escapes/surrogates/control bytes; decoded aliases and normalization-distinct names; 4096/4097 UTF-16 strings/names, supplementary widths and invalid-atom precedence; numeric 64/65 and malformed lexical-prefix precedence; legal 524288-byte payload versus 524289; actual 65536-node accepted tree versus first rejected 65537th node; active depth 64/65; 64/65 names per object and per-object reset; bounded private global name 65536/65537 and tie guards; incomplete token reservations, admitted maxima, nested ordinal/span ownership, no I/O/echo and unexpected exception propagation. No successful 65536-name document is fabricated.

Raw receipts are `<cohort>.command.json`, `<cohort>.stdout.txt`, `<cohort>.stderr.txt` under this leaf. Receipt15 retains the initial intermediate source hashes; `DEVELOPMENT-CORRECTIONS.md` independently explains every failed oracle. No failed file was deleted, retried unchanged or relabeled passing.

Other saved actual commands/results:

- 01: fixed Git freeze read; 02–04/06: complete input document reads; 05: narrow independent49 leaf discovery; 07: narrow adjacent filename discovery; 08: bounded adjacent/creation receipt raw read with presentation limitation; 09/10: complete narrow adjacent test ranges; 11: complete four seal-result reads; 12: bounded read-only four-packet custody audit; 13: focused API reread. All exit 0.
- 14/15: compile source/tests in memory with no pycache, exit 0; no generated compiler files. The known-invalid conditional expression noticed during authoring was corrected before the first compile command, not presented as a failed executed test.
- 19–21: pre-stage status/HEAD/branch; 22: `git add --` only two owned files; 23–27: exact cached stat/check/name-status and separate complete UTF-8 diffs. All exit 0.
- 28: complete task reread/identity; 29: isolated commit (2026-10-09T10:39:16.202716+00:00 →10:39:16.397377+00:00), exit 0; 30: exact committed HEAD; 32/33: clean status and exact committed two-file scope, exit 0.
- 34: authorized normal `git push -u origin codex/v1.8.0-sleep-json-core`, UTC 10:40:25.728824→10:40:29.050584, exit 0; stdout 93 bytes SHA256 `e705042227cade4aadf6ae1a020b1b7aca22f588a1f572b2b0cfaf5ce7285a00`, stderr 378 bytes SHA256 `8d179f5b90ede71a8585c9b2b1d9a08c4d179bca7746b96ac215880a50161170`.
- 35: fixed committed patch generation to own leaf, exit 0; 36/42: bounded own receipt/source/patch/protected-file audit, exit 0; 37–41: exact branch/upstream/src identity, protected Main HEAD/status, clean own status and fixed committed diff check, exit 0; 43: one-time seal helper compile in memory only, exit 0, not a seal run.

Each command receipt retains true argv/cwd/UTC/external limit/exit and independent raw stream paths, lengths and SHA256. Audit42 verified all 41 earlier saved receipts and raw stream identities, retained the sole nonzero cohort16, and found maximum own raw stream 38394 bytes. At the audit's entry the leaf had 130 files /353952 bytes; this is a historical pre-report checkpoint, not final seal coverage. The audit's own later receipt, helper compile, report and Root acknowledgement are not included in that checkpoint count.

Original capture helper identity before prospective correction: 3080 bytes, SHA256 `b585104404543f20e74d5b89f5e73c0cff6abc6ca89d6237ac2d8828a8b796b4`. Corrected helper: 3457 bytes /87 lines, SHA256 `3e6d1f8f3c8c821d06f6ba6274b653db69381dde682a499e152a25699079b6c7`. No timeout branch was exercised under either version. Git/non-Python children are not terminated by the corrected helper; a timeout would be explicitly failed and require reporting any remaining own process rather than descendant management.

## Protected state, custody and acceptance boundary

Root explicitly confirmed no other agent depends on this isolated worktree HEAD before commit, and authorized a normal branch push only after the committed functional cohort passed and scope stayed exactly two files. Root did not authorize Main merge, third module, resource/native tests or Gate acceptance. Root54's separate record-only Main move to `0dcfaf980e4a4236ff5e3c8630286b40b34eebb1` did not rebase this worktree or change its fixed e21 input.

Protected Main status39 retains modified AGENTS.md and existing untracked documentation/archive entries; none was modified, staged, committed, removed or taken over by this worker. Main HEAD38 is 0dcfaf98. Its `src` tree, candidate `src` tree and fixed baseline `src` tree are all `85f53265bf4ee59b65c4a88664cb2e5e208c583e`. Main AGENTS actual hash remains unchanged. Existing worlds, upstream source, credentials, build/registration/state files, sealed37/43 and all peer evidence are outside write scope and untouched.

The own packet is not sealed as of this stable report. A one-time own-leaf custody seal is permitted only after Root completely reads this exact stable report and acknowledges its SHA256/bytes/lines. The prewritten helper has been compiled, not executed. The actual acknowledgement will be separately recorded; actual manifest/result identities, file/byte coverage and every exclusion will be reported after the one-time operation. Report or source changes after acknowledgement would require a new exact reading, not reuse of old permission. No prior37/43 acknowledgement authorizes this53 seal.

No current-version Required Gate is marked satisfied. `./gradlew clean build`, `./gradlew runData`, generated-cleanliness `git diff --exit-code`, `./gradlew runGameTestServer`, applicable dedicated/restart/native and V1/V2 visual requirements are **NOT_EXECUTED/open here**, not PASS and not NOT_APPLICABLE. This narrowly authorized pure-functional slice does not change v1.8.0 IN_PROGRESS or open C18-A sleep acceptance work.

## v1.8.0-only next work

Root can assign a fresh independent review of the actual fa83657 two-file diff and rerun the frozen functional checks. Separately resolve actual terminal process-lifetime counter coverage under its scoped review, then explicitly assign unchanged finite decoder resource qualification if its prerequisites hold. Only after separate evidence/acceptance may Root consider source-aware schema/framing and authorized sleep observation integration. No later-version feature or broad framework is proposed here.
