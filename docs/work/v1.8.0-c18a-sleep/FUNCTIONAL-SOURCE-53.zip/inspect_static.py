"""Bounded Task53 file reads, identities and in-memory source compilation."""
import hashlib
import pathlib
import sys

sys.stdout.reconfigure(encoding="utf-8")
mode = sys.argv[1]
if mode == "files":
    for value in sys.argv[2:]:
        p = pathlib.Path(value)
        if p.stat().st_size > 180000:
            raise SystemExit("static file read bound")
        raw = p.read_bytes()
        print("FILE", str(p), "BYTES", len(raw), "LINES", len(raw.decode().splitlines()),
              "SHA256", hashlib.sha256(raw).hexdigest())
        print(raw.decode("utf-8"))
elif mode == "lines":
    p = pathlib.Path(sys.argv[2])
    raw = p.read_bytes()
    if len(raw) > 180000:
        raise SystemExit("static range read bound")
    lines = raw.decode().splitlines()
    start, end = map(int, sys.argv[3:5])
    print("FILE", str(p), "BYTES", len(raw), "LINES", len(lines), "SHA256", hashlib.sha256(raw).hexdigest())
    for i in range(start - 1, min(end, len(lines))):
        print(str(i + 1) + ": " + lines[i])
elif mode == "compile":
    for value in sys.argv[2:]:
        p = pathlib.Path(value)
        raw = p.read_bytes()
        compile(raw, str(p), "exec")
        print("COMPILED_IN_MEMORY", str(p), len(raw), len(raw.decode().splitlines()), hashlib.sha256(raw).hexdigest())
else:
    raise SystemExit("invalid mode")
