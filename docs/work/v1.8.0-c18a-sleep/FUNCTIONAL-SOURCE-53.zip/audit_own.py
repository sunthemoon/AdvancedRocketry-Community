"""Bounded evidence identity/capture audit, not decoder resource measurement."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

LEAF = Path(__file__).resolve().parent
WORKTREE = Path("D:/GitHub/arce-v180-sleep-json-core-20261009-53")

def identity(path):
    assert path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(), "st_file_attributes", 0) & 1024)
    assert path.stat().st_size <= 262144
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "lines": len(raw.splitlines()),
            "sha256": hashlib.sha256(raw).hexdigest()}

receipts = sorted(LEAF.glob("*.command.json"))
assert len(receipts) <= 100
failed = []
maximum = 0
for path in receipts:
    receipt = json.loads(path.read_bytes())
    assert receipt["argv"] and receipt["cwd"] == str(WORKTREE).replace("\\", "/")
    assert receipt["timeout_seconds"] == 180
    assert receipt["stream_limit_bytes"] == 262144
    assert receipt["aggregate_limit_bytes"] == 4194304
    assert not receipt["timed_out"] and not receipt["output_limit_exceeded"]
    assert receipt.get("drain_complete", True)
    start = datetime.datetime.fromisoformat(receipt["start_utc"])
    end = datetime.datetime.fromisoformat(receipt["end_utc"])
    assert start.utcoffset() == end.utcoffset() == datetime.timedelta(0) and end >= start
    assert 0 <= receipt["elapsed_seconds"] < 180
    if receipt["exit_code"]:
        failed.append({"path": path.name, "exit_code": receipt["exit_code"]})
    assert len(receipt["streams"]) == 2
    for stream in receipt["streams"]:
        target = Path(stream["path"])
        assert target.parent.resolve() == LEAF.resolve()
        actual = identity(target)
        assert actual["bytes"] == stream["bytes"] == stream["observed_bytes"]
        assert actual["sha256"] == stream["sha256"] and stream["complete"]
        maximum = max(maximum, actual["bytes"])
assert failed == [{"path": "16-functional-development-01.command.json", "exit_code": 1}]
files = list(LEAF.iterdir())
assert len(files) <= 512 and all(p.is_file() for p in files)
assert len(files) == len({p.name.casefold() for p in files})
total = sum(p.stat().st_size for p in files)
assert total <= 4194304
assert (LEAF / "SOURCE.patch").read_bytes() == (
    (LEAF / "26-cached-core.stdout.txt").read_bytes()
    + (LEAF / "27-cached-tests.stdout.txt").read_bytes())
print(json.dumps({"verified_receipts_before_this_audit": len(receipts),
                  "preserved_nonzero_cohorts": failed, "maximum_raw_stream_bytes": maximum,
                  "leaf_files_before_this_audit": len(files), "leaf_bytes_before_this_audit": total,
                  "committed_patch_equals_complete_cached_diffs": True,
                  "python_executable": sys.executable, "python_version": sys.version}))
for path in (WORKTREE / "scripts/sleep_observation_json_core.py",
             WORKTREE / "scripts/test_sleep_observation_json_core.py",
             LEAF / "SOURCE.patch", LEAF / "capture_command.py",
             Path("D:/GitHub/AdvancedRocketry-Community/AGENTS.md")):
    print(json.dumps(identity(path)))
