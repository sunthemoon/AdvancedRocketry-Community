"""Read-only, bounded verification of the four fixed input custody packets."""
import base64
import hashlib
import json
from pathlib import Path

ROOT = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
LEAVES = (
    ("sleep-offline-json-core-contract-20261009-37", 90, 649019, "1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763"),
    ("sleep-offline-json-core-independent-20261009-40", 140, 691694, "56151ac5caf85fd27df961844c9debffbe85c23c5d97147a82398b121308a3e5"),
    ("sleep-offline-diagnostic-convention-20261009-43", 75, 307482, "8764692b5fe5b3dc34dfde4c4a39b05786530890174485b472f47a1a5dd19bd9"),
    ("sleep-offline-convention-independent-20261009-49", 173, 514813, "008f32c53416765d83360d55344db299329dfa8615b1918e9498673c6e4192a4"),
)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def safe_read(path):
    assert path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(), "st_file_attributes", 0) & 1024)
    assert path.stat().st_size <= 4194304
    return path.read_bytes()

for leaf_name, count, size, expected_manifest in LEAVES:
    leaf = ROOT / leaf_name
    for ancestor in (leaf, ROOT, ROOT.parent, ROOT.parent.parent):
        assert not ancestor.is_symlink()
        assert not (getattr(ancestor.stat(), "st_file_attributes", 0) & 1024)
    manifest = safe_read(leaf / "SHA256SUMS.txt")
    assert digest(manifest) == expected_manifest
    covered = {}
    for line in manifest.decode("utf-8").splitlines():
        sha, relative = line.split("  ", 1)
        path = Path(relative)
        assert len(sha) == 64 and all(c in "0123456789abcdef" for c in sha)
        assert not path.is_absolute() and ".." not in path.parts and ":" not in relative
        assert relative.casefold() not in covered
        target = leaf / path
        assert target.resolve().is_relative_to(leaf.resolve())
        for parent in target.parents:
            if parent == leaf:
                break
            assert not parent.is_symlink()
            assert not (getattr(parent.stat(), "st_file_attributes", 0) & 1024)
        raw = safe_read(target)
        assert digest(raw) == sha
        covered[relative.casefold()] = len(raw)
    actual = list(leaf.rglob("*"))
    assert len(actual) <= 512
    files = [p for p in actual if p.is_file()]
    assert len(files) == len({p.relative_to(leaf).as_posix().casefold() for p in files})
    exclusions = sorted(p.relative_to(leaf).as_posix() for p in files
                        if p.relative_to(leaf).as_posix().casefold() not in covered)
    assert exclusions == ["SEAL-RESULT.json", "SHA256SUMS.txt"]
    assert len(covered) == count and sum(covered.values()) == size
    result_raw = safe_read(leaf / "SEAL-RESULT.json")
    result = json.loads(result_raw)
    assert result.get("exit_code", result.get("exit")) == 0
    assert not result.get("timed_out", False)
    assert not result.get("output_limit_exceeded", result.get("stream_limit_exceeded", False))
    for stream in ("stdout", "stderr"):
        raw = base64.b64decode(result[stream + "_base64"], validate=True)
        assert len(raw) == result[stream + "_bytes"] <= 262144
        assert digest(raw) == result[stream + "_sha256"]
    inner = json.loads(base64.b64decode(result["stdout_base64"]))
    assert inner == result["verification"]
    assert inner["covered_files"] == count and inner["covered_bytes"] == size
    assert inner["manifest_sha256"] == expected_manifest
    total = sum(p.stat().st_size for p in files)
    assert total <= 4194304
    print(json.dumps({"leaf": leaf_name, "covered_files": count,
                      "covered_bytes": size, "full_files": len(files),
                      "full_bytes": total, "exact_exclusions": exclusions,
                      "manifest_bytes": len(manifest), "manifest_sha256": digest(manifest),
                      "result_bytes": len(result_raw), "result_sha256": digest(result_raw),
                      "all_covered_match": True, "inner_receipt_matches": True}))
