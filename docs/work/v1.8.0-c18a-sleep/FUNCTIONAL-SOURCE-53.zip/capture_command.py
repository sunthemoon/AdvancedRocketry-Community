"""Task53 bounded functional/static command custody, not resource qualification."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import threading
import time

ROOT = pathlib.Path(__file__).resolve().parent
CWD = "D:/GitHub/arce-v180-sleep-json-core-20261009-53"
LIMIT = 262144
AGGREGATE = 4194304
sys.stdout.reconfigure(encoding="utf-8")
label, *argv = sys.argv[1:]
if not label or not argv or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in label):
    raise SystemExit("invalid label/argv")
paths = [ROOT / (label + suffix) for suffix in (".stdout.txt", ".stderr.txt", ".command.json")]
if any(p.exists() for p in paths):
    raise SystemExit("existing receipt")
if sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file()) + 2 * LIMIT + 8192 > AGGREGATE:
    raise SystemExit("insufficient aggregate headroom")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic()
proc = subprocess.Popen(argv, cwd=CWD, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
buffers = [bytearray(), bytearray()]
overflow = threading.Event()
lengths = [0, 0]
lock = threading.Lock()


def drain(stream, index):
    while True:
        chunk = stream.read(4096)
        if not chunk:
            break
        with lock:
            lengths[index] += len(chunk)
            room = LIMIT - len(buffers[index])
            buffers[index].extend(chunk[:room])
            if len(chunk) > room:
                overflow.set()


threads = [threading.Thread(target=drain, args=(stream, i), daemon=True)
           for i, stream in enumerate((proc.stdout, proc.stderr))]
for thread in threads:
    thread.start()
timed_out = False
try:
    proc.wait(timeout=180)
except subprocess.TimeoutExpired:
    timed_out = True
    # Task53 permits terminating only the immediately launched Python child.
    if pathlib.Path(argv[0]).name.casefold() in ("python", "python.exe"):
        proc.kill()
        proc.wait()
for thread in threads:
    thread.join(timeout=5)
drain_complete = not any(thread.is_alive() for thread in threads)
with lock:
    buffers = [bytes(raw) for raw in buffers]
    lengths = list(lengths)
receipt = {"argv": argv, "cwd": CWD, "start_utc": started,
           "end_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "elapsed_seconds": time.monotonic() - begin, "exit_code": proc.returncode,
           "timeout_seconds": 180, "timed_out": timed_out,
           "output_limit_exceeded": overflow.is_set(), "stream_limit_bytes": LIMIT,
           "aggregate_limit_bytes": AGGREGATE, "streams": []}
receipt["drain_complete"] = drain_complete
for i, (path, raw) in enumerate(zip(paths, buffers)):
    with path.open("xb") as out:
        out.write(raw)
    receipt["streams"].append({"path": str(path), "bytes": len(raw),
                               "observed_bytes": lengths[i], "complete": drain_complete and lengths[i] == len(raw),
                               "sha256": hashlib.sha256(raw).hexdigest()})
with paths[2].open("x", encoding="utf-8", newline="\n") as out:
    json.dump(receipt, out, indent=2)
    out.write("\n")
print(json.dumps(receipt))
for name, raw in zip(("stdout", "stderr"), buffers):
    print("=== " + name + " ===")
    print(raw.decode("utf-8", "replace"))
if timed_out or overflow.is_set() or not drain_complete:
    raise SystemExit("actual child timeout/stream limit failure")
raise SystemExit(proc.returncode)
