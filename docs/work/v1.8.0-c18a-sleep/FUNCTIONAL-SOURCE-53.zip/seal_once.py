"""One-time own-leaf custody seal after Root's complete exact report reading."""
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

LEAF = Path(__file__).resolve().parent
MANIFEST = LEAF / "SHA256SUMS.txt"
RESULT = LEAF / "SEAL-RESULT.json"
EXCLUSIONS = ["SEAL-RESULT.json", "SHA256SUMS.txt"]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def regular(path):
    assert path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(), "st_file_attributes", 0) & 1024)
    assert path.stat().st_size <= 262144
    return path.read_bytes()

def child():
    assert not MANIFEST.exists() and not RESULT.exists()
    for parent in (LEAF, LEAF.parent, LEAF.parent.parent, LEAF.parent.parent.parent):
        assert not parent.is_symlink()
        assert not (getattr(parent.stat(), "st_file_attributes", 0) & 1024)
    ack = json.loads(regular(LEAF / "ROOT-ACK.json"))
    report = regular(LEAF / "REPORT.md")
    assert ack["sender"] == "/root" and ack["complete_exact_report_read"] is True
    assert ack["report_sha256"] == digest(report)
    assert ack["report_bytes"] == len(report) and ack["report_lines"] == len(report.splitlines())
    files = sorted(LEAF.iterdir(), key=lambda p: p.name)
    assert len(files) <= 512 and len(files) == len({p.name.casefold() for p in files})
    rows = []
    covered_bytes = 0
    for path in files:
        raw = regular(path)
        covered_bytes += len(raw)
        rows.append(digest(raw) + "  " + path.name + "\n")
    manifest = "".join(rows).encode("utf-8")
    assert covered_bytes + len(manifest) + 8192 <= 4194304
    with MANIFEST.open("xb") as out:
        out.write(manifest)
    for line in manifest.decode("utf-8").splitlines():
        sha, name = line.split("  ", 1)
        assert digest(regular(LEAF / name)) == sha
    actual = list(LEAF.iterdir())
    assert {p.name for p in actual} == {p.name for p in files} | {"SHA256SUMS.txt"}
    print(json.dumps({"all_covered_match": True, "covered_files": len(files),
                      "covered_bytes": covered_bytes, "manifest_bytes": len(manifest),
                      "manifest_sha256": digest(manifest), "exact_exclusions": EXCLUSIONS,
                      "report_bytes": len(report), "report_lines": len(report.splitlines()),
                      "report_sha256": digest(report)}))

if sys.argv[1:] == ["--child"]:
    child()
else:
    assert len(sys.argv) == 1 and not MANIFEST.exists() and not RESULT.exists()
    argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--child"]
    cwd = "D:/GitHub/arce-v180-sleep-json-core-20261009-53"
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    proc = subprocess.Popen(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    buffers = [bytearray(), bytearray()]
    observed = [0, 0]
    lock = threading.Lock()
    overflow = threading.Event()

    def drain(stream, index):
        while True:
            chunk = stream.read(4096)
            if not chunk:
                return
            with lock:
                observed[index] += len(chunk)
                room = 262144 - len(buffers[index])
                buffers[index].extend(chunk[:room])
                if len(chunk) > room:
                    overflow.set()

    threads = [threading.Thread(target=drain, args=(stream, i), daemon=True)
               for i, stream in enumerate((proc.stdout, proc.stderr))]
    for thread in threads:
        thread.start()
    timed_out = False
    try:
        proc.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()  # This parent's own immediately launched Python child only.
        proc.wait()
    for thread in threads:
        thread.join(timeout=5)
    complete = not any(thread.is_alive() for thread in threads)
    with lock:
        raw = [bytes(value) for value in buffers]
        lengths = list(observed)
    result = {"kind": "ONE_TIME_SOURCE_EVIDENCE_CUSTODY_NOT_REVIEW_OR_RESOURCE_GATE",
              "argv": argv, "cwd": cwd, "start_utc": started,
              "end_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "elapsed_seconds": time.monotonic() - begin, "exit_code": proc.returncode,
              "timeout_seconds": 180, "timed_out": timed_out,
              "stream_limit_bytes": 262144, "output_limit_exceeded": overflow.is_set(),
              "drain_complete": complete, "excluded_from_manifest": True,
              "exact_exclusions": EXCLUSIONS}
    for name, value, length in zip(("stdout", "stderr"), raw, lengths):
        result[name + "_bytes"] = len(value)
        result[name + "_observed_bytes"] = length
        result[name + "_sha256"] = digest(value)
        result[name + "_base64"] = base64.b64encode(value).decode("ascii")
    passed = proc.returncode == 0 and not timed_out and not overflow.is_set() and complete
    result["verification"] = json.loads(raw[0]) if passed else None
    encoded = (json.dumps(result, indent=2) + "\n").encode("utf-8")
    assert len(encoded) <= 8192
    with RESULT.open("xb") as out:
        out.write(encoded)
    print(json.dumps({"manifest_bytes": MANIFEST.stat().st_size if MANIFEST.exists() else None,
                      "manifest_sha256": digest(regular(MANIFEST)) if MANIFEST.exists() else None,
                      "result_bytes": len(encoded), "result_sha256": digest(encoded),
                      "verification": result["verification"], "exit_code": proc.returncode}))
    raise SystemExit(0 if passed else 1)
