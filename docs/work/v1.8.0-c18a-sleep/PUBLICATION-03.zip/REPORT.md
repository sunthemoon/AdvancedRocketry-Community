# Root publication checkpoint: sleep research and isolated observation assignment

Date: 2026-10-09 UTC. This compact record concerns documentation/evidence
publication and assignment, not new off-world gameplay qualification.

## Completed scope

Root reads the complete sealed air, tool integration-record, boundary research
and observation-proposal independent reports and relevant proposed corrections.
Each new archive is built only from an unchanged input manifest and covered
files, with safe relative/case-unique names, persisted hash verification and CRC.
Source/evidence archives and their original manifests are not edited.

Main commits normally published during this checkpoint:
- 98304a1d192ed071d6d76fdfc508b39c2e4c5ad6: air research and tool record review.
- ff1e60c6d527825e2c68b5675d18a568cda791ed: unassigned observation proposal.
- b9bec789978de0df67c93e976239d6d36e41532b: complete boundary review and R1 gap.
- 73981dba655d3cb86bae34fadd0023aa83e8efdc: narrowed source-only assignment.

No new gameplay source is merged in these commits. Main src remains the qualified
368c91b05ecf98c1b817ec6e499708ff47c8399b tree. Actual previous behavior qualification
stays tied to 3b18a6bc; no Main metadata-SHA Gradle/native rerun is claimed.

Root creates the clean isolated sleep-observation worktree at fixed b9bec789,
then delegates only two new adapterTest source classes and an exact compile
command to /root/sleep_observation_source. Source task SHA-256:
a793aa4c994537401b0b728af3254e4e6815474fe5d149a6095e53b65550eb65.
That worker owns its code/compile/output interests. Its later source/results are
not this checkpoint's verified output, and no runtime launch is authorized.

## Design, unfinished scope and risk

Actual off-world sleep remains the owner's conditional target, not a refusal-only
or pose-only substitute. No ancillary natural/compass/clock/portal decision is
received; no spawn/time/gap policy is silently chosen. Native dimension resources
and production listeners remain unchanged.

M1 has no qualified neutral-transition mechanism; registered-bed pre-interaction
and occupancy/adjacent-door invalidation are distinct. M2's private bounded host/
live-access correction has no adopted product branch. B1 lacks production cause/
indeterminate/coexistence proof. R1 requires explicit callback-argument/inherited
receiver controls or exclusions. D1 and pre-normalization loaded-half obligations
remain open. Static revocation ordering does not prove universal immediate wake.

The proposed first observation stage is passive simulated native-Java transport
in an owned Overworld, not real TCP/client/Q01/Q18 or off-world air proof. Twenty
bounded cases and two actors are assigned for source only; parser/runtime,
packaging, actual-diff review, full regression and source/driver/runtime evidence
remain separate work. The prior strict 180-second TIMEOUT and unwaived native
ERROR headers are not resolved here. All required release/visual/persistence/
performance/license Gates and ledger/item acceptance remain open.

## Commands actually executed and evidence limits

check_publication.py executes six actual read/check commands at the recorded
2ad2ea94 pre-publication HEAD: head, src tree, empty index, git diff --check,
accepted v1.8 ledger and approved bootstrap provenance. All exit 0; material argv,
cwd/UTC/exits and separate raw stdout/stderr hashes/files are in COMMANDS.json.
It also verifies newly referenced paths, archive CRC/volume and unchanged owner
AGENTS.md. PUBLICATION-CHECKS.json binds the actual document/archive candidate
bytes, not later modified metadata. It performs no Gradle or strict rerun.

commit_publication.py and commit_boundary_review.py preserve their exact scoped
staging/stat/whitespace/commit/normal-push/HEAD/index/status argv/UTC/exits and raw
streams in the corresponding JSON/logs. Proposal commit uses rendered PowerShell
Tee logs, explicitly not original raw streams. The last assignment/worktree
creation/commit/push is retained in the tool transcript rather than duplicated
as independently captured raw terminal files. Final Git checks are captured by
final_records.py. No invented earlier UTC or lost raw proof is supplied.

Own exploratory reads guessed missing repository/evidence paths, including the
work completion-plan filename, short ledger validator name, compat-test-mod/src,
spawn PRIMARY-AUDIT.json, native-launch-02.command.json and a v170 helper filename.
Discovery/correct existing reads follow; their original error/rendered streams
remain in the tool transcript, not independent raw archives. Some combined
PowerShell exploration exits are zero despite earlier nonterminating read errors;
those are not all-subcommand PASS. Truncated displays are not negative evidence.
The initial final-record checker also stops at its fourth command because its
output prefix collides with an earlier owned index receipt. Its original helper
bytes and first three raw outputs are retained; unpublished in-memory timestamps
are not reconstructed. A distinct output prefix is used for the corrected full
capture. This is a checker preparation failure, not a failed target behavior.
Four failed patch-context attempts affect only the new external source-task draft;
the final valid edits/input hash are verified before dispatch. No failed gameplay
test is hidden or changed to success by these preparation corrections.

No new source tests are run by Root at this checkpoint. Source test plans are
unexecuted, not waived or NOT_APPLICABLE. No world/client/server/driver, compiler,
install, reflection/private invocation, AT/coremod or Claude is executed by Root.
OpenPet attempts fail safely; no runtime/config/app-data change follows.

## Files, custody and acceptance

Only scoped documentation/plan/status/log and new compact archives are committed
on Main. User-owned AGENTS.md retains the previously recorded c2448e93... hash,
unstaged; inherited untracked/peer files are neither acquired nor cleaned. Main
HEAD movement occurs after independent reviewers release all mutable interests;
the source worker later uses a separate fixed worktree/branch.

This leaf contains owned short scripts/raw Git checks/receipts/report, not an
exported source/build/world/runtime copy. No own disposable process or scratch
tree is created here and no cleanup is attempted. Input seals and peer-denied
temporary retention stay untouched. The ordinary source worktree is assigned
and retained, not packaged in evidence or deleted during implementation.

Final persisted bytes are sealed and reverified separately. This report intentionally
contains no self-referential report/manifest hash. Current-version Required Gates
are not satisfied; v1.8 remains IN_PROGRESS under ADR-060, with inherited v1.0
acceptance unchanged. Next within v1.8: finish and independently review the
bounded fixture candidate, then freeze a separate driver/runtime task; disposition
M1/M2/B1/R1/D1 before any enforcing off-world sleep implementation.
