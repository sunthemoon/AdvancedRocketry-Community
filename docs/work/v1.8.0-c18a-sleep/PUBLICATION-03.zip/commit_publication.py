"""Commit only the verified documentation/evidence publication, then push normally."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

MAIN = Path("D:/GitHub/AdvancedRocketry-Community")
OUT = Path(__file__).resolve().parent
HEAD = "2ad2ea944d87176f6b4171c2c13c69502c106db5"
FILES = [
    "docs/status/CURRENT_VERSION.md", "docs/status/COMPLETION-PLAN.md",
    "docs/work/v1.8.0-implementation-log.md",
    "docs/work/v1.8.0-c18a-sleep/AIR-RESEARCH-STATUS-02.md",
    "docs/work/v1.8.0-c18a-sleep/AIR-FEASIBILITY-02.zip",
    "docs/work/v1.8.0-c18a-sleep/RESEARCH-STATUS-01.md",
    "docs/work/v1.8.0-c18a-sleep/CONTRACT-REVIEW-STATUS-01.md",
    "docs/work/v1.8.0-c18b-jackhammer/SOURCE-INTEGRATION-01.md",
    "docs/work/v1.8.0-c18b-jackhammer/INTEGRATION-REVIEW-STATUS-01.md",
    "docs/work/v1.8.0-c18b-jackhammer/INTEGRATION-INDEPENDENT-01.zip",
]
rows = []
def git(name, *args):
    argv = ["git", *args]
    start = datetime.now(timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=MAIN, capture_output=True, timeout=180)
    streams = {}
    for suffix, raw in [("stdout", p.stdout), ("stderr", p.stderr)]:
        path = OUT / (name + "." + suffix + ".log")
        assert not path.exists()
        path.write_bytes(raw)
        streams[suffix] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    rows.append(dict(argv=argv, cwd=str(MAIN), start_utc=start,
                     end_utc=datetime.now(timezone.utc).isoformat(),
                     exit=p.returncode, streams=streams))
    (OUT / "COMMIT-COMMANDS.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    assert p.returncode == 0, (name, p.stdout, p.stderr)
    print(p.stdout.decode("utf-8"), end="")
    return p.stdout.decode("utf-8").strip()

assert git("before-head", "rev-parse", "HEAD") == HEAD
assert not git("before-index", "diff", "--cached", "--name-only")
assert hashlib.sha256((MAIN / "AGENTS.md").read_bytes()).hexdigest() == \
    "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
checks = json.loads((OUT / "PUBLICATION-CHECKS.json").read_text("utf-8"))
for f in checks["files"]:
    assert hashlib.sha256((MAIN / f["path"]).read_bytes()).hexdigest() == f["sha256"]
git("stage", "add", "--", *FILES)
assert set(git("staged-names", "diff", "--cached", "--name-only").splitlines()) == set(FILES)
git("staged-stat", "diff", "--cached", "--stat")
git("staged-whitespace", "diff", "--cached", "--check")
git("commit", "commit", "-m", "docs(v1.8): publish sleep prerequisites and integration audit")
committed = git("committed-head", "rev-parse", "HEAD")
git("push", "push", "origin", "codex/v1.8.0-classic-content")
assert git("upstream", "rev-parse", "@{upstream}") == committed
assert not git("final-index", "diff", "--cached", "--name-only")
assert git("final-tracked-status", "status", "--short", "--untracked-files=no").strip() == "M AGENTS.md"
assert hashlib.sha256((MAIN / "AGENTS.md").read_bytes()).hexdigest() == \
    "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
(OUT / "COMMIT-RESULT.json").write_text(json.dumps(dict(
    commit=committed, parent=HEAD, normal_push=True, owner_agents_unchanged=True,
    staged_files=FILES, verified_utc=datetime.now(timezone.utc).isoformat()), indent=2) + "\n", encoding="utf-8")
