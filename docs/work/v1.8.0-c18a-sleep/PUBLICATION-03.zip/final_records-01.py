"""Capture final fixed Main metadata checks and seal only owned compact receipts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parent
main = Path("D:/GitHub/AdvancedRocketry-Community")
expected = "73981dba655d3cb86bae34fadd0023aa83e8efdc"
assert not (root / "SHA256SUMS.txt").exists()
rows = []
for name, argv in [
    ("head", ["git", "rev-parse", "HEAD"]),
    ("upstream", ["git", "rev-parse", "@{upstream}"]),
    ("src", ["git", "rev-parse", "HEAD:src"]),
    ("index", ["git", "diff", "--cached", "--name-only"]),
    ("status", ["git", "status", "--short", "--untracked-files=no"]),
    ("whitespace", ["git", "diff", "--check", "2ad2ea944d87176f6b4171c2c13c69502c106db5", expected]),
]:
    start = datetime.now(timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=main, capture_output=True, timeout=30)
    raw = {}
    for suffix, data in [("stdout", p.stdout), ("stderr", p.stderr)]:
        path = root / ("final-" + name + "." + suffix + ".log")
        assert not path.exists()
        path.write_bytes(data)
        raw[suffix] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    rows.append(dict(argv=argv, cwd=str(main), started_utc=start,
                     ended_utc=datetime.now(timezone.utc).isoformat(), exit=p.returncode, raw=raw))
    assert p.returncode == 0
    actual = p.stdout.decode().strip()
    if name in ("head", "upstream"):
        assert actual == expected
    if name == "src":
        assert actual == "368c91b05ecf98c1b817ec6e499708ff47c8399b"
    if name == "index":
        assert not actual
    if name == "status":
        assert actual == "M AGENTS.md"
assert hashlib.sha256((main / "AGENTS.md").read_bytes()).hexdigest() == \
    "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
archives = []
for group in ("v1.8.0-c18a-sleep", "v1.8.0-c18b-jackhammer"):
    expanded_total = 0
    for path in sorted((main / "docs/work" / group).glob("*.zip")):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            expanded = sum(i.file_size for i in z.infolist())
            expanded_total += expanded
        archives.append(dict(path=path.relative_to(main).as_posix(), expanded_bytes=expanded,
                             bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert expanded_total < 100 * 1024**2
(root / "FINAL-RECORDS.json").write_text(json.dumps(dict(
    checked_utc=datetime.now(timezone.utc).isoformat(), head=expected,
    commands=rows, archives=archives, source_unchanged=True, runtime_rerun=False), indent=2) + "\n", encoding="utf-8")
files = sorted(p for p in root.rglob("*") if p.is_file())
assert all(not p.is_symlink() and not p.is_junction() for p in files)
for p in files:
    assert p.stat().st_size < 50 * 1024**2
manifest = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " +
                   p.relative_to(root).as_posix() + "\n" for p in files)
(root / "SHA256SUMS.txt").write_bytes(manifest.encode("utf-8"))
for line in (root / "SHA256SUMS.txt").read_text("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
print(json.dumps(dict(covered_files=len(files), covered_bytes=sum(p.stat().st_size for p in files),
    report_sha256=hashlib.sha256((root / "REPORT.md").read_bytes()).hexdigest(),
    manifest_sha256=hashlib.sha256((root / "SHA256SUMS.txt").read_bytes()).hexdigest(),
    source_unchanged=True, runtime_rerun=False), indent=2))
