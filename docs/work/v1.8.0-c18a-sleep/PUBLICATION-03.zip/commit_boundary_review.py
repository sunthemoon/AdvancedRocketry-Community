"""Publish only fixed boundary review records; no source or runtime claims."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

main = Path("D:/GitHub/AdvancedRocketry-Community")
out = Path(__file__).resolve().parent
expected = "ff1e60c6d527825e2c68b5675d18a568cda791ed"
files = ["docs/status/COMPLETION-PLAN.md", "docs/status/CURRENT_VERSION.md",
         "docs/work/v1.8.0-implementation-log.md",
         "docs/work/v1.8.0-c18a-sleep/AIR-RESEARCH-STATUS-02.md",
         "docs/work/v1.8.0-c18a-sleep/SPAWN-RESEARCH-STATUS-02.md",
         "docs/work/v1.8.0-c18a-sleep/BOUNDARY-REVIEW-STATUS-03.md",
         "docs/work/v1.8.0-c18a-sleep/BOUNDARY-INDEPENDENT-03.zip"]
rows = []
def git(name, *args):
    start = datetime.now(timezone.utc).isoformat()
    p = subprocess.run(["git", *args], cwd=main, capture_output=True, timeout=180)
    raw = {}
    for suffix, data in [("stdout", p.stdout), ("stderr", p.stderr)]:
        path = out / ("boundary-" + name + "." + suffix + ".log")
        assert not path.exists()
        path.write_bytes(data)
        raw[suffix] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    rows.append(dict(argv=["git", *args], cwd=str(main), started_utc=start,
                     ended_utc=datetime.now(timezone.utc).isoformat(), exit=p.returncode, raw=raw))
    (out / "BOUNDARY-COMMIT-COMMANDS.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    assert p.returncode == 0, (name, p.stderr)
    print(p.stdout.decode("utf-8"), end="")
    return p.stdout.decode("utf-8").strip()
assert git("head", "rev-parse", "HEAD") == expected
assert not git("index", "diff", "--cached", "--name-only")
assert hashlib.sha256((main / "AGENTS.md").read_bytes()).hexdigest() == \
    "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
git("check", "diff", "--check")
git("stage", "add", "--", *files)
assert set(git("names", "diff", "--cached", "--name-only").splitlines()) == set(files)
git("stat", "diff", "--cached", "--stat")
git("cached-check", "diff", "--cached", "--check")
git("commit", "commit", "-m", "docs(sleep): record independent boundary qualification findings")
committed = git("committed", "rev-parse", "HEAD")
git("push", "push", "origin", "codex/v1.8.0-classic-content")
assert git("upstream", "rev-parse", "@{upstream}") == committed
assert git("status", "status", "--short", "--untracked-files=no").strip() == "M AGENTS.md"
assert not git("final-index", "diff", "--cached", "--name-only")
(out / "BOUNDARY-COMMIT-RESULT.json").write_text(json.dumps(dict(parent=expected,
    commit=committed, normal_push=True, source_changed=False, runtime_rerun=False,
    final_utc=datetime.now(timezone.utc).isoformat()), indent=2) + "\n", encoding="utf-8")
