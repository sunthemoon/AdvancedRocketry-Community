"""Verify bounded research publication without claiming new runtime qualification."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile

MAIN = Path("D:/GitHub/AdvancedRocketry-Community")
OUT = Path(__file__).resolve().parent
PYTHON = "D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe"
EXPECTED_HEAD = "2ad2ea944d87176f6b4171c2c13c69502c106db5"
FILES = [
    "docs/status/CURRENT_VERSION.md", "docs/status/COMPLETION-PLAN.md",
    "docs/work/v1.8.0-implementation-log.md",
    "docs/work/v1.8.0-c18a-sleep/AIR-RESEARCH-STATUS-02.md",
    "docs/work/v1.8.0-c18a-sleep/RESEARCH-STATUS-01.md",
    "docs/work/v1.8.0-c18a-sleep/CONTRACT-REVIEW-STATUS-01.md",
    "docs/work/v1.8.0-c18b-jackhammer/SOURCE-INTEGRATION-01.md",
    "docs/work/v1.8.0-c18b-jackhammer/INTEGRATION-REVIEW-STATUS-01.md",
]
COMMANDS = [
    ("head", ["git", "rev-parse", "HEAD"]),
    ("source-tree", ["git", "rev-parse", "HEAD:src"]),
    ("index", ["git", "diff", "--cached", "--name-only"]),
    ("whitespace", ["git", "diff", "--check"]),
    ("ledger", [PYTHON, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("bootstrap", [PYTHON, "-B", "scripts/validate_bootstrap_provenance.py", "--require-approved-review"]),
]
rows = []
for name, argv in COMMANDS:
    start = datetime.now(timezone.utc).isoformat()
    proc = subprocess.run(argv, cwd=MAIN, capture_output=True, timeout=180)
    streams = {}
    for suffix, raw in [("stdout", proc.stdout), ("stderr", proc.stderr)]:
        path = OUT / (name + "." + suffix + ".log")
        assert not path.exists()
        path.write_bytes(raw)
        streams[suffix] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    rows.append(dict(name=name, argv=argv, cwd=str(MAIN), started_utc=start,
                     ended_utc=datetime.now(timezone.utc).isoformat(),
                     exit=proc.returncode, streams=streams))
    assert proc.returncode == 0, (name, proc.stderr)
    if name == "head":
        assert proc.stdout.decode().strip() == EXPECTED_HEAD
    if name == "source-tree":
        assert proc.stdout.decode().strip() == "368c91b05ecf98c1b817ec6e499708ff47c8399b"
    if name == "index":
        assert not proc.stdout.strip()
(OUT / "COMMANDS.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
assert hashlib.sha256((MAIN / "AGENTS.md").read_bytes()).hexdigest() == \
    "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"

archives = []
for group in ["v1.8.0-c18a-sleep", "v1.8.0-c18b-jackhammer"]:
    total = 0
    for path in sorted((MAIN / "docs/work" / group).glob("*.zip")):
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            infos = archive.infolist()
            names = set()
            for info in infos:
                pure = PurePosixPath(info.filename)
                assert not pure.is_absolute() and ".." not in pure.parts
                assert ":" not in info.filename and "\\" not in info.filename
                assert info.filename.casefold() not in names and info.file_size < 50 * 1024**2
                names.add(info.filename.casefold())
            expanded = sum(info.file_size for info in infos)
            total += expanded
        archives.append(dict(path=path.relative_to(MAIN).as_posix(), bytes=path.stat().st_size,
                             expanded_bytes=expanded, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert total < 100 * 1024**2

files = []
for name in FILES:
    path = MAIN / name
    raw = path.read_bytes()
    if name != "docs/work/v1.8.0-implementation-log.md":
        for target in re.findall(r"\]\(([^)]+)\)", raw.decode("utf-8")):
            if "://" not in target and not target.startswith("#"):
                assert (path.parent / target.split("#", 1)[0]).exists(), (name, target)
    files.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
(OUT / "PUBLICATION-CHECKS.json").write_text(json.dumps(dict(
    checked_utc=datetime.now(timezone.utc).isoformat(), candidate_head=EXPECTED_HEAD,
    files=files, archives=archives, source_unchanged=True, owner_agents_unchanged=True,
    runtime_rerun=False, strict_rerun=False), indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(commands=len(rows), changed_documents=len(files),
    archives=len(archives), source_unchanged=True, runtime_rerun=False), indent=2))
