import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import io
import zipfile
import struct

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

LEAF = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = '2ad2ea944d87176f6b4171c2c13c69502c106db5'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def emit_record(argv, started, code, out, err, detail=None):
    record = dict(argv=argv, cwd=str(REPO), started_utc=started, ended_utc=utc(),
                  exit_code=code, stdout_bytes=len(out), stdout_sha256=hashlib.sha256(out).hexdigest(),
                  stderr_bytes=len(err), stderr_sha256=hashlib.sha256(err).hexdigest())
    if detail:
        record.update(detail)
    with (LEAF / 'COMMANDS.jsonl').open('a', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(record, ensure_ascii=True, sort_keys=True) + '\n')
    if err:
        sys.stderr.write(err.decode('utf-8', errors='replace'))

def method_descriptors(data):
    if len(data) > 2097152 or data[:4] != b'\xca\xfe\xba\xbe':
        raise ValueError('Invalid/bounded class input')
    pos = 8
    def u2():
        nonlocal pos
        v = struct.unpack_from('>H', data, pos)[0]
        pos += 2
        return v
    def u4():
        nonlocal pos
        v = struct.unpack_from('>I', data, pos)[0]
        pos += 4
        return v
    cp = [None] * u2()
    i = 1
    while i < len(cp):
        tag = data[pos]
        pos += 1
        if tag == 1:
            n = u2()
            cp[i] = data[pos:pos+n].decode('utf-8', errors='replace')
            pos += n
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18):
            pos += 4
        elif tag in (5, 6):
            pos += 8
            i += 1
        elif tag in (7, 8, 16, 19, 20):
            pos += 2
        elif tag == 15:
            pos += 3
        else:
            raise ValueError('Unknown constant-pool tag')
        i += 1
    pos += 6
    interfaces = u2()
    pos += 2 * interfaces
    def member():
        nonlocal pos
        access, name, descriptor, attributes = u2(), u2(), u2(), u2()
        for _ in range(attributes):
            u2()
            n = u4()
            pos += n
        return dict(access=access, name=cp[name], descriptor=cp[descriptor])
    for _ in range(u2()):
        member()
    return [member() for _ in range(u2())]

mode = sys.argv[1]
started = utc()
if mode == 'git':
    argv = ['git', *sys.argv[2:]]
    p = subprocess.run(argv, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    emit_record(argv, started, p.returncode, p.stdout, p.stderr)
    sys.stdout.write(p.stdout.decode('utf-8', errors='replace'))
    sys.exit(p.returncode)
elif mode in ('doc', 'file', 'find'):
    target = sys.argv[2]
    if mode == 'doc':
        argv = ['git', 'show', COMMIT + ':' + target]
        p = subprocess.run(argv, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err, code = p.stdout, p.stderr, p.returncode
    else:
        argv = [sys.executable, '-B', str(LEAF / 'audit_capture.py'), 'file', target, *sys.argv[3:]]
        try:
            out, err, code = pathlib.Path(target).read_bytes(), b'', 0
        except Exception as e:
            out, err, code = b'', str(e).encode(), 1
    emit_record(argv, started, code, out, err,
                {'capture_note': 'stdout hash covers unmodified git bytes or inspected file bytes; console display is numbered/subset below'})
    lines = out.decode('utf-8', errors='replace').splitlines()
    if mode == 'find':
        pattern = re.compile(sys.argv[3])
        for i, line in enumerate(lines, 1):
            if pattern.search(line):
                print(f'{i:5}: {line}')
        sys.exit(code)
    start = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    end = int(sys.argv[4]) if len(sys.argv) > 4 else len(lines)
    for i in range(start, min(end, len(lines)) + 1):
        print(f'{i:5}: {lines[i-1]}')
    print(f'-- {target}: total_lines={len(lines)} bytes={len(out)} sha256={hashlib.sha256(out).hexdigest()} exit={code}')
    sys.exit(code)
elif mode == 'inventory':
    target = pathlib.Path(sys.argv[2])
    result = [{'path': str(p.relative_to(target)).replace('\\', '/'), 'bytes': p.stat().st_size,
               'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(target.rglob('*')) if p.is_file()]
    out = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), *sys.argv[1:]], started, 0, out, b'')
    (LEAF / sys.argv[3]).write_bytes(out)
    print(out.decode())
elif mode == 'verify':
    target = pathlib.Path(sys.argv[2]).resolve()
    manifest = target / 'SHA256SUMS.txt'
    rows = []
    for line in manifest.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():
            continue
        m = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
        if not m:
            rows.append({'line': line, 'status': 'invalid-format'})
            continue
        expected, name = m.groups()
        p = (target / name).resolve()
        if target not in p.parents:
            rows.append({'path': name, 'status': 'outside-leaf'})
            continue
        data = p.read_bytes() if p.is_file() else None
        actual = hashlib.sha256(data).hexdigest() if data is not None else None
        rows.append({'path': name, 'bytes': len(data) if data is not None else None,
                     'expected_sha256': expected.lower(), 'actual_sha256': actual,
                     'status': 'match' if actual == expected.lower() else 'mismatch-or-missing'})
    all_files = [str(p.relative_to(target)).replace('\\', '/') for p in sorted(target.rglob('*')) if p.is_file()]
    covered = {r.get('path') for r in rows}
    result = dict(input_leaf=str(target), manifest_bytes=manifest.stat().st_size,
                  manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), entries=rows,
                  entries_count=len(rows), matches=sum(r['status']=='match' for r in rows),
                  unlisted=[p for p in all_files if p not in covered and p != 'SHA256SUMS.txt'])
    out = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    code = 0 if result['matches'] == len(rows) else 1
    emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), *sys.argv[1:]], started, code, out, b'')
    (LEAF / sys.argv[3]).write_bytes(out)
    print(out.decode())
    sys.exit(code)
elif mode == 'zipgit':
    target = sys.argv[2]
    argv = ['git', 'show', COMMIT + ':' + target]
    p = subprocess.run(argv, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    emit_record(argv, started, p.returncode, p.stdout, p.stderr)
    if p.returncode:
        sys.exit(p.returncode)
    with zipfile.ZipFile(io.BytesIO(p.stdout)) as z:
        infos = z.infolist()
        if len(infos) > 100 or sum(i.file_size for i in infos) > 2000000:
            raise SystemExit('Archive exceeds fixed audit bound')
        if len(sys.argv) == 3:
            rows = [dict(path=i.filename, bytes=i.file_size, sha256=hashlib.sha256(z.read(i)).hexdigest()) for i in infos]
            manifests = [i for i in infos if pathlib.PurePosixPath(i.filename).name in ('SHA256SUMS.txt', 'checksums.txt')]
            checks = []
            for manifest in manifests:
                parent = pathlib.PurePosixPath(manifest.filename).parent
                for line in z.read(manifest).decode('utf-8-sig').splitlines():
                    if not line.strip():
                        continue
                    m = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
                    if not m:
                        checks.append(dict(line=line, status='invalid-format'))
                        continue
                    expected, name = m.groups()
                    full = str(parent / name)
                    if name.startswith('/') or '..' in pathlib.PurePosixPath(name).parts:
                        checks.append(dict(path=name, status='unsafe-name'))
                        continue
                    data = z.read(full)
                    actual = hashlib.sha256(data).hexdigest()
                    checks.append(dict(path=name, bytes=len(data), expected_sha256=expected.lower(), actual_sha256=actual,
                                       status='match' if actual == expected.lower() else 'mismatch'))
            result = dict(commit=COMMIT, archive=target, archive_bytes=len(p.stdout), archive_sha256=hashlib.sha256(p.stdout).hexdigest(),
                          crc_failure=z.testzip(), entries=rows, covered_entries=checks)
            out = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
            emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), *sys.argv[1:]], started, 0, out, b'')
            (LEAF / 'ORIGINAL-INDEPENDENT-ARCHIVE-AUDIT.json').write_bytes(out)
            print(out.decode())
        else:
            name = sys.argv[3]
            out = z.read(name)
            emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), *sys.argv[1:]], started, 0, out, b'',
                        dict(capture_note='stdout hash covers inspected ZIP entry bytes; console is numbered/subset'))
            lines = out.decode('utf-8', errors='replace').splitlines()
            start = int(sys.argv[4]) if len(sys.argv) > 4 else 1
            end = int(sys.argv[5]) if len(sys.argv) > 5 else len(lines)
            for i in range(start, min(end, len(lines)) + 1):
                print(f'{i:5}: {lines[i-1]}')
            print(f'-- {target}!{name}: total_lines={len(lines)} bytes={len(out)} sha256={hashlib.sha256(out).hexdigest()}')
elif mode == 'metadata':
    base = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
    spawn = base / 'sleep-spawn-feasibility-20261009-02'
    air = base / 'sleep-air-feasibility-20261009-02'
    audits = {
        'spawn-fixed': json.loads((spawn / 'INPUTS.json').read_bytes()),
        'spawn-native': json.loads((spawn / 'NATIVE-INPUTS.json').read_bytes()),
        'spawn-signatures': json.loads((spawn / 'SIGNATURE-INPUTS.json').read_bytes()),
        'air-fixed': json.loads((air / 'INPUT-AUDIT.json').read_bytes()),
        'air-primary': json.loads((air / 'PRIMARY-AUDIT.json').read_bytes())}
    blob_rows, primary_rows, entry_rows = [], [], []
    primary_paths = {}
    for label, audit in audits.items():
        commit = audit.get('commit', audit.get('fixed_commit'))
        for row in audit.get('fixed_blobs', []):
            path = row.get('path') or row['argv'][-1].split(':', 1)[1]
            argv = ['git', 'show', commit + ':' + path]
            row_started = utc()
            p = subprocess.run(argv, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            emit_record(argv, row_started, p.returncode, p.stdout, p.stderr)
            actual = hashlib.sha256(p.stdout).hexdigest()
            row_started = utc()
            current = subprocess.run(['git', 'show', COMMIT + ':' + path], cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            emit_record(['git', 'show', COMMIT + ':' + path], row_started, current.returncode, current.stdout, current.stderr)
            blob_rows.append(dict(audit=label, path=path, recorded_commit=commit, expected_sha256=row['sha256'],
                                  actual_sha256=actual, matches=(p.returncode == 0 and actual == row['sha256']),
                                  current_fixed_matches=(current.returncode == 0 and hashlib.sha256(current.stdout).hexdigest() == actual)))
        for row in audit.get('primary_files', []):
            path = pathlib.Path(row['path'])
            data = path.read_bytes()
            actual = hashlib.sha256(data).hexdigest()
            primary_paths[str(path)] = path
            primary_rows.append(dict(audit=label, path=str(path), bytes=len(data), expected_sha256=row['sha256'],
                                     actual_sha256=actual, matches=(actual == row['sha256'])))
    air_files = audits['air-primary']['primary_files']
    jar_map = {'mapped': pathlib.Path(air_files[0]['path']), 'sources': pathlib.Path(air_files[1]['path'])}
    with zipfile.ZipFile(jar_map['mapped']) as mapped, zipfile.ZipFile(jar_map['sources']) as sources:
        for row in audits['air-primary']['primary_entries']:
            z = mapped if row['jar'] == 'mapped' else sources
            info = z.getinfo(row['entry'])
            if info.file_size > 2097152:
                raise SystemExit('Primary entry exceeds 2 MiB cap')
            data = z.read(info)
            actual = hashlib.sha256(data).hexdigest()
            entry_rows.append(dict(entry=row['entry'], bytes=len(data), expected_sha256=row['sha256'],
                                   actual_sha256=actual, matches=(actual == row['sha256'])))
        for row in audits['spawn-native']['classes']:
            data = mapped.read(row['entry'])
            if len(data) > 2097152:
                raise SystemExit('Primary entry exceeds 2 MiB cap')
            actual = hashlib.sha256(data).hexdigest()
            entry_rows.append(dict(entry=row['entry'], bytes=len(data), expected_sha256=row['sha256'],
                                   actual_sha256=actual, matches=(actual == row['sha256'])))
        for row in audits['spawn-native']['events']:
            data = sources.read(row['entry'])
            actual = hashlib.sha256(data).hexdigest()
            entry_rows.append(dict(entry=row['entry'], bytes=len(data), expected_sha256=row['sha256'],
                                   actual_sha256=actual, matches=(actual == row['sha256'])))
    row = audits['spawn-signatures']['primary_eventbus']
    data = pathlib.Path(row['path']).read_bytes()
    primary_rows.append(dict(audit='spawn-signatures-eventbus', path=row['path'], bytes=len(data), expected_sha256=row['sha256'],
                            actual_sha256=hashlib.sha256(data).hexdigest(), matches=(hashlib.sha256(data).hexdigest() == row['sha256'])))
    for row in audits['spawn-signatures']['classes']:
        with zipfile.ZipFile(row['jar']) as z:
            data = z.read(row['entry'])
        actual = hashlib.sha256(data).hexdigest()
        entry_rows.append(dict(entry=row['entry'], bytes=len(data), expected_sha256=row['sha256'],
                               actual_sha256=actual, matches=(actual == row['sha256'])))
    result = dict(fixed_commit=COMMIT, fixed_blob_checks=blob_rows, primary_file_checks=primary_rows,
                  primary_entry_checks=entry_rows, audit_shapes={k: list(v) for k, v in audits.items()})
    out = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    (LEAF / 'PERSISTED-INPUT-IDENTITY-AUDIT.json').write_bytes(out)
    code = 0 if all(r['matches'] for r in [*blob_rows, *primary_rows, *entry_rows]) else 1
    emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), mode], started, code, out, b'')
    print(json.dumps(dict(blob_checks=len(blob_rows), blob_matches=sum(r['matches'] for r in blob_rows),
                          current_fixed_blob_matches=sum(r['current_fixed_matches'] for r in blob_rows),
                          primary_file_checks=len(primary_rows), primary_file_matches=sum(r['matches'] for r in primary_rows),
                          primary_entries=len(entry_rows), primary_entry_matches=sum(r['matches'] for r in entry_rows),
                          differing_current_fixed_paths=[r['path'] for r in blob_rows if not r['current_fixed_matches']],
                          audit_shapes=result['audit_shapes']), indent=2))
    sys.exit(code)
elif mode == 'signatures':
    audit = json.loads(pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/SIGNATURE-INPUTS.json').read_bytes())
    rows = []
    for row in audit['classes']:
        with zipfile.ZipFile(row['jar']) as z:
            methods = method_descriptors(z.read(row['entry']))
        for selected in row['selected']:
            actual = sum(m['descriptor'] == selected['descriptor'] for m in methods)
            rows.append(dict(entry=row['entry'], descriptor=selected['descriptor'],
                             recorded_count=selected['same_descriptor_count_in_declared_class'], actual_count=actual,
                             matches=actual == selected['same_descriptor_count_in_declared_class']))
    result = dict(methods=rows, class_count=len(audit['classes']), selected_count=len(rows),
                  matches=sum(r['matches'] for r in rows), parser='Bounded classfile method_info descriptor inventory; no class loading/reflection/invocation')
    out = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    (LEAF / 'SIGNATURE-RECHECK.json').write_bytes(out)
    code = 0 if result['matches'] == len(rows) else 1
    emit_record([sys.executable, '-B', str(LEAF / 'audit_capture.py'), mode], started, code, out, b'')
    print(json.dumps({k: v for k, v in result.items() if k != 'methods'}, indent=2))
    sys.exit(code)
else:
    raise SystemExit('Unsupported mode')
