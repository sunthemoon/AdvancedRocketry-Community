import hashlib
import json
import pathlib
import sys

sys.stdout.reconfigure(encoding='utf-8')
LEAF = pathlib.Path(__file__).resolve().parent
MANIFEST = LEAF / 'SHA256SUMS.txt'

def files():
    return sorted(p for p in LEAF.rglob('*') if p.is_file() and p != MANIFEST)

def expected_manifest():
    return ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
                   str(p.relative_to(LEAF)).replace('\\', '/') + '\n' for p in files()).encode('utf-8')

mode = sys.argv[1]
if mode == 'seal':
    if MANIFEST.exists():
        raise SystemExit('A seal already exists; refusing overwrite')
    MANIFEST.write_bytes(expected_manifest())
elif mode != 'verify':
    raise SystemExit('Use seal or verify')

actual = MANIFEST.read_bytes()
expected = expected_manifest()
if actual != expected:
    raise SystemExit('Manifest verification failed')
names = [str(p.relative_to(LEAF)).replace('\\', '/') for p in files()]
if len(set(n.casefold() for n in names)) != len(names):
    raise SystemExit('Case-insensitive name collision')
if any('..' in pathlib.PurePosixPath(n).parts or pathlib.PurePosixPath(n).is_absolute() for n in names):
    raise SystemExit('Manifest contains unsafe names')
report = (LEAF / 'REPORT.md').read_bytes()
print(json.dumps(dict(mode=mode, covered_files=len(names), matched_files=len(names), unlisted_files=0,
                      covered_bytes=sum(p.stat().st_size for p in files()),
                      manifest_bytes=len(actual), manifest_sha256=hashlib.sha256(actual).hexdigest(),
                      report_bytes=len(report), report_sha256=hashlib.sha256(report).hexdigest(),
                      actual_files_including_manifest=len(names)+1,
                      crc_archives_created=0, source_exports=0, native_processes=0,
                      cleanup_attempts=0, python_cache_files=sum(p.suffix == '.pyc' for p in files())),
                 indent=2, sort_keys=True))
