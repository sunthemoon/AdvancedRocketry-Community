import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
leaf = pathlib.Path(__file__).resolve().parent
cwd = 'D:/GitHub/AdvancedRocketry-Community'
for mode in ('seal', 'verify'):
    argv = [sys.executable, '-B', str(leaf / 'seal.py'), mode]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(json.dumps(dict(argv=argv, cwd=cwd, started_utc=started, ended_utc=ended,
                          exit_code=p.returncode, stdout_bytes=len(p.stdout),
                          stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),
                          stderr_bytes=len(p.stderr), stderr_sha256=hashlib.sha256(p.stderr).hexdigest(),
                          raw_stdout=p.stdout.decode('utf-8'), raw_stderr=p.stderr.decode('utf-8'),
                          capture_location='Tool transcript only; no sealed leaf bytes changed by this outer capture'),
                     indent=2, sort_keys=True))
    if p.returncode:
        sys.exit(p.returncode)
