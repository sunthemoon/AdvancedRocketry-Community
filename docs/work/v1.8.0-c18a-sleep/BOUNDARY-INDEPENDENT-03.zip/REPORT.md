# Independent review 03: native sleep boundary research

Date: 2026-10-09 UTC. Delegated independent worker:
`/root/sleep_boundary_research_review`. Fixed project commit:
`2ad2ea944d87176f6b4171c2c13c69502c106db5`. This is a research/qualification-scope
review, not a source review, implementation assignment, architecture adoption or
acceptance. No proposed runtime case was executed.

## Findings first

Reference abbreviations: **S** is the fixed external
`sleep-spawn-feasibility-20261009-02` leaf, **A** is the fixed external
`sleep-air-feasibility-20261009-02` leaf, **P** is the fixed project
`docs/work/v1.8.0-c18a-sleep/PROPOSED-CONTRACT-01.md`, and **I** is
`CONTRACT-INDEPENDENT-01.zip!REPORT.md` at the fixed project commit. Native numbers
are method bytecode offsets in the sealed primary extracts, not source lines.

### R1 — Medium: qualification needs an explicit callback/receiver trust boundary

**New concrete qualification-detail gap within the already-open B1 identity
prerequisite; static inference, not a reproduced false positive.** S:REPORT.md:41-63
uses the nearest contiguous dispatch/factory/setter/bed/packet chain and explicitly
disregards callback frames above that dispatch. S:REPORT.md:85-91 acknowledges
missing receiver identity. S:QUALIFICATION-PLAN.md:64-70 tests nested setters,
synthetic events posted to the bus/factory, overriding beds and cancellation
writers, but does not explicitly distinguish direct/forwarded callback arguments
or a different receiver inheriting the selected declaring-class method.

The inspected EventBus passes its actual event object to its dispatcher at
EventBus.post(Event,dispatcher):101-107 and returns that object's cancellation at
:142-161 (S:signature-and-dispatch.txt:108-137). The proposed frame data do not
expose those arguments. A listener directly invoking an observer/adapter with a
different synthetic event while the genuine outer dispatch is still active does
not create a nearer EventBus frame. Its below-dispatch chain can therefore look
genuine while its callback argument is not the posted event. Similarly,
BedBlock's declaring method does not identify the actual registered block/receiver;
an inherited method can have the same declaring class and MethodType.

This does not demonstrate that an ordinary unmodified native setter changes the
wrong player. On the primary chain, ServerPlayer.startSleepInBed:107-122 loads its
own receiver for the setter, the setter:0-15 passes that receiver to the factory,
and the factory:3-14 creates/posts the event from those arguments
(S:native-methods.txt:192-201,523-531,1991-1998). It supports a **conditional native
argument-propagation inference**, not universal callback or transformer immunity.

Before an enforcing assignment, freeze the exact allowed callback route and
bed/player/connection/Level identities. Add finite controls for direct/forwarded
callback invocation with the same and another actor/event, an inherited rather
than overridden bed method, and nested native operations for both actors; or
explicitly exclude those routes with the corresponding compatibility limitation.
Do not reinterpret a stack declaring class as object authentication. A shadow
observer may characterize these cases without choosing a veto mechanism.

### Already-open prerequisites, not newly discovered implementation defects

- **B1, blocking technical input:** S:REPORT.md:93-107 and
  S:QUALIFICATION-PLAN.md:11-16 leave the exact INDETERMINATE admission/setter
  behavior, supported baseline/mod/JVM boundary and cancellation coexistence
  unspecified. An unknown ordinary stack cannot safely be treated as unrelated;
  a blanket unknown-off-world veto can suppress administrative/restore operations.
  LOWEST is not an exclusive final writer. These are honestly disclosed, not
  resolved by descriptor uniqueness or by this review. An enforcing task is not
  ready; an observational task can record indeterminate outcomes without effects.
- **Loaded-half before-read boundary, already disclosed:** BedBlock.use:24-50 reads
  a normalized head before the sleep event (S:REPORT.md:128;
  S:native-methods.txt:1018-1033). A later sleep-event loaded-cell check is too late
  to qualify prevention of that read. An early RightClickBlock check must also
  account for item-first/secondary selection, cached state and intervening
  listeners rather than broadening a bed-only action into all clicks. The initial
  observational fixture should use fully loaded halves; it earns no unloaded-half
  or no-ticket boundary proof.
- **M1, Medium feasibility prerequisite:** A:PROPOSED-CORRECTIONS-02.md:104-159
  specifies the necessary old/new-state and neighbor-reaction proof, but supplies
  no qualifying public recognizer. Native occupancy can synchronously revoke
  authority; universal immediate waking has not been measured. Current-state-only
  exemptions, ignoring PENDING/VACUUM, grace periods, restoring old authority,
  physics cancellation and larger budgets remain disallowed. Any correction of
  registered interaction/neighbor invalidation also needs disposition of the
  accepted ADR-024 semantics, not merely unchanged public class bytes.
- **M2, Medium product/freezing prerequisite:** A:PROPOSED-CORRECTIONS-02.md:16-102
  provides a coherent, bounded correction for the proposed gap-allowing branch.
  It separates required actual Space host and operational registry from optional
  orbit description, checks live VISIT independently at both admission samples,
  and reuses the same rule at the current sleeping eye. It does not choose the
  gap/station-only branch or the whole-bed-footprint permission alternative.
  Define the scope/lifetime of its proposed non-reentrancy check (:16-20); do not
  turn a projection guard into an unpaired bed-action flag.
- **D1, owner choice:** fixed OWNER-DECISION-01.md:13-20 selects actual sleep
  conditional on dimension/spawn/time freezing and review. OWNER-QUESTION-02.md:
  10-21 records an unanswered ancillary question, not approval. No natural=true,
  compass/clock/portal, shared-time, respawn or migration policy is selected here.

No Critical/High runtime defect is asserted from this planning-only inspection.
The absence of a runtime finding is not evidence that any mechanism works.

## Complete-plan audit and evidence classification

The entire P:1-346, I:1-332, S:REPORT.md:1-250 and QUALIFICATION-PLAN.md:1-130,
and A:REPORT.md:1-472 and PROPOSED-CORRECTIONS-02.md:1-181 were read. The plan's
Q01-Q18 and original S01-S21/R01-R02 remain unexecuted requirements, not passed
tests. Its early/late refusal, item-first/secondary use, admin/null/restore,
exception, packaged/remapped/JIT, saved-field, lifecycle and reference-load cases
are materially useful. They are a broad later qualification matrix, not a finite
launch-ready observation task: S:QUALIFICATION-PLAN.md:117-120 expressly defers
launcher, transport and stop conditions.

Static ordering is corroborated: useItemOn caches state at :7-13, posts
RightClickBlock at :41, returns on a consuming item-first result at :133-143,
then calls the cached state's use at :251-259. Native sleep sets spawn at :122
before time/monster refusal. Cancellation precedes field/message mutation.
The nearest dispatch and nearest setter are necessary to distinguish nested
events/setters; neither tuple equality nor an enclosing sleep frame suffices.

For M1, the fixed AtmosphereServerEvents.java:58-72 dirties exactly registered
clicked states/doors before admission; :75-89 separately dirties changed cells
for a nonempty catalog and adjacent doors. AtmosphereLevelService.java:132-159
revokes authority and cancels affected work synchronously. The primary
ServerLevel.updateNeighborsAt:14 precedes neighborUpdater:31
(A:native-methods.txt:1314-1334); DoorBlock.neighborChanged:125-157 changes OPEN/
POWERED with flag 2 afterward (A:door-methods.txt:246-261). A current bed state or
closed neighboring door therefore cannot authenticate a neutral previous state
or exclude a later consequential change. Small empty-catalog service fixtures
cannot characterize the installed nonempty-catalog/multipass case.

For M2, fixed station/persistence/StationRegistrySavedData.java:82-83 defines
operational reads separately from updatesAvailable:118-120. Its :204-209 returns
empty while blocked. Fixed station/service/StationAccessService.java:21-34
requires operator/owner/member authority; invitations do not grant VISIT.
The proposed constant-size per-cell projection fits these static interfaces.
Actual loaded-full-cell, host/catalog generation, negative/region-edge identity,
eye-height extensions, optional-orbit removal and lifecycle behavior remain
runtime or separately frozen semantic inputs, not successful measured behavior.

**Policy choice** is the recorded actual-sleep target plus still-pending ancillary
and gap/footprint dispositions. **Architecture adoption** would choose/freeze a
baseline-sensitive classifier or another mechanism. **Static facts** are the
verified bytes/interfaces/order above. **Inference** includes receiver propagation
under that exact native chain and possible self-invalidation. **Measured behavior
in this task is limited to input/hash/descriptor checks**; no sleep, frame walk,
air timing, save, packet, production compatibility or performance was measured.

## Finite observation-only Overworld stage

There is enough static context to prepare a **separate, explicitly authorized
test-only observation assignment**, without first implementing an enforcing
classifier or changing off-world dimension data. This is a supported planning
scope, not permission to build/run it and not a selected mechanism/verdict.

The task's actual-connected-client proposal and Root's later narrower proposal
must remain different evidence cohorts:

1. A genuine connected-client Overworld attempt can observe the native ordinary
   packet/interaction/event chain on that build. It still cannot demonstrate
   off-world host gating, spawn veto correctness, M1/M2 or ancillary policy.
2. Root's supplemental **PlayerList-registered ServerPlayer with EmbeddedChannel,
   public same-thread handleUseItemOn entry** can characterize the packaged native
   Java frames, actor/Level/event identities and early/late native branches.
   An open simulated Connection and native registry membership do not prove real
   TCP transport, decoder/packet scheduling, a genuine client intent or client
   acknowledgement/receipt. Outbound channel capture is not client acceptance.
   This is not the real connected positive in Q01/Q18 and cannot close B1/Q01-Q18.
   Public construction/registration must be demonstrated without private access,
   reflection, AT, substituted native checks or world/player-map surgery; inability
   to do so is a setup limitation, not authority to change those boundaries.

Minimum assignment controls, with no result prefilled:

- Freeze committed source/JAR/JDK/Forge/EventBus/fixture identities, a disjoint
  test-only write_scope and exact public entry route. Inspect the actual started
  Overworld and its native dimension/time/gamerules; use a disposable owned world,
  two named owned actors, known real bed IDs, loaded halves and fixed positions.
  Declare whether those actors are TCP clients or EmbeddedChannel fixtures.
- Observers only read public data and record bounded primitives. They never set
  cancellation/results, call a spawn/sleep setter as a policy, restore fields,
  redirect time, suppress atmosphere events or register shipped listeners.
  Driver-issued native administrative/setter actions are isolated test controls,
  not a preservation policy. Any test-only refusal/exception listener is declared
  separately, finite and removed by its own public registration identity.
- Declare event priority/receiveCanceled and StackWalker options, callback entry,
  frame cap and all observer-added frames. Record truncation/metadata exceptions
  explicitly rather than deducing NON_MATCH. The proposed 64-frame value may be
  an observation cap only if chosen in that task; it is not an approved budget.
  Do not infer adjacency across hidden/omitted frames without stating the policy.
- Each attempt needs a sequence, route, actor/connection/Level identity, clicked
  and normalized cells, loaded/current bed states, item-first/block decisions,
  event object identities, nested depth, frame class/MethodType and examined count,
  native outcome/occupancy, and pre/post public Spawn values. Use bounded
  identity-based tokens, not identityHashCode alone as an equality proof.
  Save/read exact Spawn field types/presence/float bits only on owned fixtures.
- Include native night head/foot use, daytime/monster late refusal, obstructed/
  packet-range early refusal, item-first PASS/consume and secondary-use selection;
  native admin forced and forced=false same-tuple setter, null reset and restore;
  nearer nested setter and synthetic bus/factory event for both actors; R1's
  forwarded/direct-callback and inherited-method identity controls. Include stale
  cached-state/receiver changes as a declared control or explicit exclusion.
- Compare observer-disabled and observer-enabled copies/cohorts for the same
  native branch/field/item/event effects. A LOWEST observation is not inherently
  the final result; compare final event/native outcomes after the public driver
  returns. Record exceptions and native partial effects, then another independent
  operation. No rollback, swallowing or successful-sleep result is predeclared.
- Separate initial and repeated packaged observations; name a cohort warmed/JIT
  only with compilation evidence, not elapsed time alone. Development versus
  reobfuscated packaged evidence and any interpreted cohort are distinct. This
  cannot qualify Forge 47.4.23 or other JVM/mod transformations without those runs.
- Freeze exact case count/repetition ceiling, launch count, per-case tick/time
  limits, global deadline, per-attempt/event/frame/output-byte caps and overflow
  stop behavior before dispatch. No unbounded retry/warm-up, tick logging, silent
  truncation, background server or fixture growth. Check >=10 GB free before any
  authorized full build/native launch; clean only declared owned processes/copies.
- Observe native leave-bed/logout/replacement/stop and one finite restart if that
  assignment claims persistence/isolation. An observer's lifecycle cleanup and
  shadow outputs do not prove an eventual production adapter's cleanup, failure
  handling or saved spawn preservation. Short observer timing/allocation and
  buffer bounds are not installed-reference-load G7 proof or V1/V2 acceptance.

If resources require a smaller first stage, enumerate its actual rows and mark
the others unexecuted; do not silently call a representative bed/caller cohort
the entire matrix. M1 supplied-room/catalog/neighbor/scan cases and M2 actual
Space/access cases require their own later authorized environment and cannot be
credited to ambient Overworld breathability. Enforcing fallback/coexistence,
off-world registry upgrade/time, old native off-world spawn migration, real
clients, full lifecycle and reference-load coverage all remain separate.

## Input identities and actual checks

- Task bytes: 3,600; SHA-256
  `915a1f8138e89baf2f4ef060fd0dcb820cc8fd4d7ef562254d506647783603ce`.
- S report: 20,460 bytes, `e138312695cadeca45870f9b1bbf3241a940e563a5f72026039f1c6994a3c9a8`.
  S manifest: 7,735 bytes, `a80fcee411f747ec29eefba2c25c01dfe4e4562d832336c04853e5eaeaa2ed67`.
  All 83 covered files match; no unlisted files.
- A report: 33,387 bytes, `ee1a0a45fc98537feb3e8a59cdc28c75087350d8742236bea2c15955a1eaf80f`.
  A manifest: 1,250 bytes, `dd452a8c958809c8509a4eb7815d04ca0d8ee8c05f75b84a99f742cf6cc1135a`.
  All 15 covered files match; no unlisted files.
- Original independent archive: 258,624 bytes,
  `24df674e72e53187ed2c7b12651986d61151535beee070463e84f8ac5fe1d164`;
  14 entries, CRC checked, all 13 manifest entries match. I report:
  `e0466f41886a38971f51a3f5132356ccb8fcf86b68bcdeccef05bdc17ec1fc56`.
- P bytes match `55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21`.
  Owner decision matches `1dd0928208ffba6cda4636a632d06fe00ebbef650e6f4d9d4d2b1ed66fdf0af6`;
  pending question matches `f3c5c669d34c25b2defec256c857d7fe62dc19c8975e81a7ae57b6aa54cf5cb0`.
- Persisted input metadata independently rechecked 92 recorded Git blob hashes,
  all matching their recorded 46c566dd commit, and compared them with the fixed
  2ad2ea94 objects. 91 compare identically; only CURRENT_VERSION.md differs. No
  mutable checkout was adopted. Seven primary-file hash checks and 41 bounded ZIP
  class/source-entry checks all match (counts include repeated inputs). No class
  was loaded or invoked. A bounded classfile descriptor inventory independently
  confirms all 11 selected method-descriptor counts across eight actual classes.

Actual operations are read-only fixed `git show`/`ls-tree`, Python -B file/ZIP/
hash/classfile reads and owned evidence creation. COMMANDS.jsonl records material
argv/cwd/UTC/exit and original Git-byte or inspected-input hashes. Persisted audit
JSONs contain exact per-input results. No input script was executed. No compiler,
javap process, Gradle/test/DataGen/GameTest, Minecraft/server/client/world,
runtime stack walk, network, install, reflection/private invocation, AT/coremod,
source export, subprocess daemon or further delegation was run. Required version
commands remain required for implementation, not waived or NOT_APPLICABLE here.

## Failures, command-capture limits and custody

The initial task/leaf setup and broad read-only tree display predated the harness;
their rendered tool streams have no separately captured UTC/raw hash. The broad
display was truncated; it was not negative source evidence. Initial Python
console encoding rendered Chinese poorly; explicit UTF-8 and bounded rereads
recovered the necessary full governance/proposal/report content. A guessed
docs/versions/v1.8.0.md read exited 128; discovery found the actual version file.
Two guessed station source reads exited 128; fixed metadata identified the actual
station/persistence file, which was read. One combined ad-hoc regex display
emitted a shell command-not-found error; the corrected individual searches used
simple patterns. These are exploration errors, not gameplay failures or waivers.

The first metadata batch's 184 inner Git records were timestamped after each
subprocess, not before it. Their hashes/argv/exits remain accurate, but their
started_utc values are **not valid execution-start measurements**. The outer
batch envelope is valid. The capture was corrected and the complete metadata
batch rerun with real pre-execution timestamps; final persisted identity audit
comes from that rerun. No historical start time or lost stream was invented.
Hashing unmodified inspected input bytes does not hash the numbered/subset console
display; this distinction is recorded in each read. Raw bytes are not duplicated
as a source export. Sealing/independent verification metadata and the actual
manifest bytes/hash are returned separately, outside this covered report.

## Scope, policies, ownership and disposal

Completed: complete independent planning review, seal/input/descriptor checks,
finite observation-stage boundaries and this external evidence leaf. Uncompleted:
R1 qualification additions, enforcing B1 mechanism/failure/coexistence acceptance,
M1 recognizer/runtime timing, M2 product freeze, D1 answer, any source fixture/
production implementation and runtime/save/client/performance/release tests.

Changed files are only new owned report/script/audit/log/seal files in this leaf.
No repository, input/peer/original seal, source test, status, ledger, asset, schema,
API/protocol, ADR/risk or owner-response file changed. Known risks remain exactly
the baseline-sensitive identity/coexistence/failure, occupancy/air, loaded-half,
host/access, old-record, lifecycle and unexecuted acceptance obligations above.

Mutable repository/HEAD/branch/source/native-runtime/peer evidence interests were
released at task start and remain released. Root alone coordinates OpenPet. Owned
server/world/export/build copies=0, temporary archives=0, native/game/background
processes=0, cleanup attempts=0, denied/retried/bypassed cleanup=0, peer cleanup=0,
Python bytecode caches=0. The small audit/seal scripts are retained reproducibility
evidence, not disposable runtime copies. No cleanup was necessary or performed.

No current-version Required Gate is satisfied by this review. The fixed inherited
acceptance cursor remains v1.0 IN_PROGRESS; v1.8 development under ADR-060 and all
G0-G9 obligations remain unchanged. No unrelated hatch/tool finding is reviewed
or closed. No owner choice, architecture, risk/ADR, ledger, delivery, tag/release
or source assignment is approved. Next within v1.8: translate the bounded
observation scope into an explicitly assigned task with finite controls, record
its actual evidence, then independently disposition B1/M1/M2/D1 before any
enforcing off-world default sleep slice. No later-version work is recommended.
