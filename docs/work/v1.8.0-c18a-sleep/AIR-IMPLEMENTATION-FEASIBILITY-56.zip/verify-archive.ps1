param([Parameter(Mandatory)][string]$Archive)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::OpenRead($Archive)
try {
    $manifest = $zip.GetEntry('SHA256SUMS.txt')
    if ($null -eq $manifest -or $manifest.Length -gt 262144) { throw 'Missing or oversized manifest' }
    $reader = [IO.StreamReader]::new($manifest.Open(), [Text.Encoding]::UTF8)
    try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
    $names = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $coveredBytes = [long]0
    foreach ($line in ($text -split "`n")) {
        if (-not $line.Trim()) { continue }
        if ($line.TrimEnd("`r") -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Malformed manifest line: $line" }
        $expected = $Matches[1]; $name = $Matches[2]
        if (-not $names.Add($name)) { throw "Duplicate manifest member: $name" }
        $entry = $zip.GetEntry($name)
        if ($null -eq $entry) { throw "Manifest member absent: $name" }
        $stream = $entry.Open(); $hash = [Security.Cryptography.SHA256]::Create()
        try { $actual = [Convert]::ToHexString($hash.ComputeHash($stream)).ToLowerInvariant() }
        finally { $stream.Dispose(); $hash.Dispose() }
        if ($actual -ne $expected) { throw "Manifest mismatch: $name" }
        $coveredBytes += $entry.Length
    }
    $excluded = @($zip.Entries | Where-Object { -not $names.Contains($_.FullName) } | ForEach-Object { $_.FullName })
    [ordered]@{ archive=$Archive; covered_members=$names.Count; covered_bytes=$coveredBytes;
        actual_exclusions=$excluded; all_manifest_digests_match=$true;
        crc_independently_verified=$false; no_extraction_or_execution=$true } | ConvertTo-Json -Depth 4
} finally { $zip.Dispose() }
