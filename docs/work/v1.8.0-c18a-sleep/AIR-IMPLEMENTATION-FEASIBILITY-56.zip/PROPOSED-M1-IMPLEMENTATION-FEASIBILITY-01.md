# Supplied-air sleep M1 implementation feasibility, proposal 01

Status: PROPOSED; source feasibility only, not an accepted contract or production assignment.
Author: delegated engineering worker `/root/sleep_json_platform_counter`, Task56, 2026-10-09.
Fixed source/governance: `e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1`.
Historical observation source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`; not relabeled as current execution.

## 1. Findings and implementation status

**No complete, supportable minimal production delta has been established for M1.**
The current public event payloads and installed atmosphere API do not authenticate
an old/new native-bed state transition or provide a paired completion boundary for
its neighbor effects. A sleep-only exemption cannot therefore be justified from
the inspected inputs. This is a scoped evidence limitation, not a proof that every
possible public integration is impossible.

The current services already implement synchronous revocation and bounded repair.
They can support read-only admission/wake consumers once their other prerequisites
are satisfied. What remains missing is evidence sufficient to distinguish a
completed atmosphere-neutral native bed operation from genuine or unknown loss,
without suppressing the latter. No new PENDING grace, blanket bed exemption,
restoration of invalidated air, synchronous room rescan, or weaker provider contract
is proposed.

Key source evidence below refers to fixed captures, whose exact Git object and
command are retained in the adjacent receipt. Native bytecode offsets refer to
historical selected-method extracts; fresh installed jar/member identities match
those extracts' recorded primary inputs. These are static observations, not tests.

## 2. Existing authority and ownership

| Boundary | Current behavior and evidence |
| --- | --- |
| Registration | [Registry:48-67,75-122](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/registry-22.stdout.txt#L48) validates owner/window/conflicts/bounds, compiles every possible state, then freezes an immutable table. Providers may claim another namespace's block. |
| Registered DEFAULT | [Catalog:20-33](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/catalog-21.stdout.txt#L20) separates registration membership from the enum DEFAULT; DEFAULT is not equivalent to unregistered. |
| Runtime classification | [World view:41-85](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/world-view-18.stdout.txt#L41) applies build-height/loading guards, paired owned airlock, sealing tag, native door OPEN, permeable tag, compiled non-DEFAULT rule, then fluid/air/sky/collision fallback. Enum equality alone is not effective observation equality. |
| Immediate revocation | [Level service:132-160](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/level-service-17.stdout.txt#L132) cancels affected scans/completed results, removes indexed/provider authority, resets affected vents, then enqueues repair. Dirty overflow clears/resets, not delayed grace. |
| Live supplied-air query | [Level service:223-248](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/level-service-17.stdout.txt#L223) requires a loaded cell, indexed volume, loaded ACTIVE elected vent and current ability to supply. Ambient BREATHABLE can short-circuit this loaded-cell query. |
| Lifecycle | [Manager:98-141](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/manager-16.stdout.txt#L98) owns per-Level services and removes absent Levels; [central wiring:368-395,427-447](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/central-wiring-37.stdout.txt#L368) installs the exact manager, disconnects it at stopping, clears services at stopped, and reinstalls on a later start. |

The provider callback is a pure loading-time function of BlockState, not a runtime
world callback. It can legitimately depend on OCCUPIED. There is no registration
rule requiring occupancy neutrality. [Provider:6-16](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/provider-23.stdout.txt#L6)
and [accepted ADR-024:34-65,75-92](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/adr024-44.stdout.txt#L34)
remain unchanged. Their after-return callback timing checks are not arbitrary-code
preemption.

## 3. Event and native-operation order

### 3.1 Registered-bed pre-admission

[Atmosphere events:58-72](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L58)
reads the loaded current clicked state and marks it dirty if it is door-like or
exactly registered, including registered DEFAULT. An unrelated nonempty catalog
alone does not dirty an unregistered bed at this particular interaction handler.
The existing non-mutating detector/useBlock-DENY exception is not a sleep exception.

Installed `ServerPlayerGameMode.useItemOn` obtains the cached state, posts the
RightClick event at bytecode offsets 34-44, checks cancellation, invokes item-first
behavior at 125-131, and only later invokes block use. See
[interaction extract:3-188](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/interaction-historical-53.stdout.txt#L3).
Thus a registered neutral bed can revoke supplied authority before the later sleep
admission query. This is a source-supported risk, not a measured claim that every
such attempt fails: room membership and actual service/native timing matter.

Skipping this handler for every BedBlock would also skip genuine mutations from
item-first/block/provider behavior. A pre-interaction state and a later tick
comparison are not authenticated successful native bed-operation evidence.

### 3.2 Occupancy and wake

`LivingEntity.startSleeping` invokes `setBedOccupied(true)` at offsets 33-41
before assigning sleeping pose at 44-48. The installed public default
`IForgeBlock.setBedOccupied` calls `Level.setBlock` with OCCUPIED and flag 3.
Bed counterpart `updateShape` copies occupancy for a matching opposite half and
can return AIR for an invalid pair. See
[native extract:3-44,586-630,1384-1397](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/native-historical-51.stdout.txt#L3)
and [installed Forge declaration:250-261](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/forge-block-58.stdout.txt#L250).

Native normal wake calls the Forge wake notification and then native stopSleeping;
that notification is not a mutable operation-completion acknowledgment.
[Wake declaration:10-38](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/wake-event-57.stdout.txt#L10)
and [native stopSleepInBed:451-476](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/native-historical-51.stdout.txt#L451)
show this boundary. Native teardown can itself generate occupancy notifications.

With any registered providers installed, [Neighbor handler:75-89](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L75)
conservatively dirties the changed position even if its new state is unregistered.
That is necessary to cover replacement of an old registered state. An occupancy
toggle can consequently revoke otherwise neutral supplied air. It does not follow
that every sleeper immediately wakes: the first actual native wake check must be
observed separately, without treating a later rebuild as loss grace.

### 3.3 Why current state is insufficient

[BlockEvent:38-64 and NeighborNotify:188-223](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/block-event-54.stdout.txt#L188)
contains Level, position, one state, notified directions and a force-redstone flag;
it has no authenticated prior BlockState, native sleeper identity, operation token,
or paired final neighbor closure. Placement snapshots and fluid-specific old/new
fields exist for their own operations, not arbitrary bed occupancy writes.

`ServerLevel.updateNeighborsAt` reads the new current state, posts the event at
offset 14, then calls the neighbor updater at 31.
[Native extract:1314-1334](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/native-historical-51.stdout.txt#L1314).
The `Level.markAndNotifyBlock` old/new locals are not forwarded to that event.
Its later `onBlockStateChange` hooks at 189-202 are methods on existing Level/block
instances, not an established global event hook that this mod owns.
[Native extract:779-890](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/native-historical-51.stdout.txt#L779).
No custom Level replacement, vanilla block replacement, private-field accessor,
Access Transformer, or ASM authority is inferred.

### 3.4 Adjacent doors are a separate loss source

The current neighbor handler dirties loaded notified door-like neighbors even
with an empty provider catalog. Their current closed state at the event is not a
completion guarantee: native `DoorBlock.neighborChanged` subsequently computes
signal and writes POWERED/OPEN using flag 2 at offsets 125-157.
[Door extract:189-262](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/doors-historical-52.stdout.txt#L189).
Skipping neighbors because the originating bed classification is neutral would
lose this protection. No guaranteed secondary notification for that flag-2 write
has been established.

The mod-owned [AirlockDoorBlock:55-89](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/airlock-28.stdout.txt#L55)
already invalidates before superclass setOpen/neighbor/place/remove/destroy actions.
[Runtime:28-48](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/runtime-15.stdout.txt#L28)
guards the exact installed Level/server thread and dirties both loaded halves.
This owned bridge is useful existing infrastructure but does not authenticate or
wrap vanilla beds/doors. Do not weaken or duplicate it as a blanket sleep bypass.

## 4. Scan and volume evidence is not a transition journal

[VolumeScanTask:65-105,136-145](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/scan-task-29.stdout.txt#L65)
retains traversable cells and bounds; SEALED observations are not retained as
authenticated BlockStates. [AtmosphereVolume:7-35](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/volume-model-32.stdout.txt#L7)
and [scan result:8-15](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/scan-result-33.stdout.txt#L8)
have no prior boundary-state witness or classification generation.
[VolumeIndex:19-21,80-92](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/volume-index-31.stdout.txt#L19)
indexes cells, not every historical sealing frontier. The coordinator already
removes affected unconsumed completed scans in
[cancelAround:167-189](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/scan-coordinator-30.stdout.txt#L167).

A new journal would need authenticated change capture, frontier coverage,
in-flight/completed/indexed consistency, reload/lifecycle invalidation and a
bounded cost within existing budgets. Remembering last scan states alone cannot
establish those requirements. Such a journal is a larger atmosphere integration
proposal requiring separate review of ADR-024 implications; it is not authorized
or made feasible merely by naming an epoch or token.

## 5. Genuine loss, reload and removal

- Genuine changed effective classification, replacement, malformed bed/airlock,
  uncertain prior state, unloaded cells, or unclosed neighbor effects retain
  ordinary immediate `markDirty` revocation. Unknown means fail closed.
- Vent removal, loss of current energy/oxygen, unsupported data and chunk unload
  retain current query/lifecycle behavior. Queries do not charge resources;
  [vent:75-98,298-303](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/vent-actual-47.stdout.txt#L75)
  and [supply engine:11-59](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/vent-supply-48.stdout.txt#L11)
  remain the single supply debit authority.
- Reload-wide datapack sync (`player == null`) schedules service invalidation on
  the owning server; individual login sync is not reload.
  [Events:101-104](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L101).
  [Service:287-291,439-445](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/level-service-17.stdout.txt#L287)
  resets cached/in-flight/completed authority. The immutable compiled provider
  table is reused; runtime tag precedence is evaluated again. Provider callbacks
  are not rerun by `/reload`.
- Provider removal is a next mod-loading startup table rebuild/fallback contract,
  not a supported live unregister operation. A later world/server start in the
  same loaded process reinstalls the same cleared manager/catalog. Test provider
  removal with a separate provider-free process startup, not datapack reload.

## 6. Smallest conditional candidate and exact missing prerequisite

The smallest separable work is a pure, internal transition decision plus tests;
it is **not a complete M1 fix**, and by itself must grant no preservation of air.
It consumes an authenticated receipt, never manufactures one from a marker,
current-state sample, stack descriptor, or event-supplied claim.

Before any neutral decision can influence installed invalidation, evidence must
establish all of the following for the actual public native operation:

1. Exact installed server/Level identity, owning thread, loaded cells, bed receiver,
   normalized matching head/foot, and previous/current immutable states.
2. Only the intended occupancy change, stable bed identity/geometry and equal
   **effective** observations under unchanged compiled catalog and live tag/profile
   semantics for every affected cell. OCCUPIED-sensitive rules can invalidate this.
3. A paired operation boundary covering item-first/callback changes, counterpart
   repair and notified adjacent doors before neutral authority is relied upon.
4. No intervening genuine or unknown dirty event, lifecycle replacement, unload,
   reload or resource loss. Unknown/reentrant/exceptional cases use existing dirty
   behavior, not delayed acceptance or resurrection of a revoked volume.
5. Valid current provider authority at admission and the first native wake check;
   no saved whitelist/cached protection decision substitutes for live air.

The inspected public surfaces do not presently establish items 1-3 as a complete
receipt producer. A timestamp, owner flag, catalog version or retained stack frame
does not fill that gap. Therefore no event-handler edit is currently ready for
assignment based on this proposal.

The closure must also be finite and charged within existing observation/work
budgets. Arbitrary same-JVM callbacks can change more cells than a bed's two halves;
unknown or unbounded effects cannot be called neutral. No new observer cap or
unbudgeted frontier sweep is silently added by this conditional proposal.

### Candidate write boundaries, only after separate assignment

| Proposed bounded scope | Dependency and constraint |
| --- | --- |
| New internal `BedBoundaryTransitionPolicy.java` under atmosphere/server, and matching unit test | Pure bounded input decision; absent/unqualified witness returns ordinary invalidation. Not a public provider API and not a gameplay exception. |
| Existing AtmosphereServerEvents only at registered interaction/neighbor routing | Requires independently established receipt producer/closure. Native door-neighbor loss handling and all unknown cases remain active. Changing ADR-024 invalidation semantics requires explicit disposition. |
| Existing ServerLevelVolumeWorldView, only if an effective-classification factoring is needed | Preserve exact current priority/loaded guards; no callback during scans. An old-state classifier cannot silently query current-world geometry as its historical witness. |
| New installed native-operation tests under gametest and pure-policy tests | Must observe exact installed services/native operations; no substituted markDirty call as proof of event routing. A test-only public/internal witness seam needs explicit review; existing reflection utilities are not a new permission. |

No manager/coordinator/index/journal redesign is included in that smallest
conditional scope. If the missing receipt cannot be obtained without such changes,
the write boundary must be reconsidered in a new task instead of quietly expanded.
Central lifecycle/registration wiring remains integrator-owned. JSON core files,
resources, NBT/network/schema, station authorization, global BodyContext and
dimension profiles are excluded from this M1 candidate.

### Read-only admission/wake consumer invariants

Subject to B1/R1/M2 and D1 prerequisite work, reuse the existing manager rather
than introducing another oxygen authority. Entry validates actual current eye and
normalized native sleeping-eye cells, deduplicated to at most two manager lookups;
perform loaded-cell preflight even on ambient-breathable hosts. Awake air failure
must be refused before native completion; suit oxygen does not make a cell
BREATHABLE. The first native sleeping-time check after genuine/unknown loss uses
the actual current eye, at most one manager lookup, and native `stopSleepInBed(false,
true)` behavior, not a pose-only edit.

[SleepingTimeCheck declaration:15-42](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/sleep-time-55.stdout.txt#L15)
and [Player.tick native offsets 83-97](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/native-historical-51.stdout.txt#L241)
support that normal wake mechanism. Actual callback authentication, final event
result/coexistence and paired bed-operation scope are not solved by event priority.
The existing [life-support tick:63-114](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/player-life-support-43.stdout.txt#L63)
has its own debit/damage authority and occurs through LivingTick; it is not evidence
of the earlier native sleep-time check. Do not double charge, heal or add immunity.

## 7. Unchanged budgets and lifecycle invariants

Retain 4096 cells/volume, 256 task observations/tick, 1024 Level observations/tick,
64 active jobs, 128 indexed volumes, 65536 indexed cells, 8192 dirty positions,
256 dirty processing positions/tick and 1024 tracked vents.
[Limits:5-15](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/limits-27.stdout.txt#L5).
Keep registration bounds/timing unchanged. No synchronous extra room scan, new
chunk ticket/forced loading, cap change, larger timeout, or deferred-loss grace.

No new persistent/NBT data or packet/protocol/channel; native bed-use/leave-bed
traffic remains transport. No new per-tick log or repetitive message. Preserve the
contract's localized state-change or per-attempt bounded presentation and existing quality,
NBT, network, logging and per-tick budgets; measure O(connected sleepers) under the
existing reference workload before acceptance. No unbounded transition history.
Any eventual operation-local state is cleared on exception, wake, bed removal,
death/logout/replacement, Level change, unload/reload and stop/restart; saving does
not resume a sleep session or authorize retained air.

## 8. Evidence-based tests to define in a later authorized task

Every row below is NOT_EXECUTED. Record actual native call order, loaded cells,
catalog/installed manager identity, pre/post service metrics and resources, native
pose/sleeping location/occupancy, first native wake check and actual result. Setup
must first establish a real nonambient supplied volume; assertion text is not proof.

| Case | Native operation and evidence needed |
| --- | --- |
| Registered DEFAULT and occupancy-neutral bed | Connected player's ordinary head/foot use with empty hand and item-first controls; inspect pre-admission authority and both native occupancy transitions. No manual dirty substitute, exemption or PENDING grace. |
| Unrelated nonempty catalog | Ordinary unregistered-bed use; distinguish RightClick membership behavior from later coarse neighbor invalidation. |
| OCCUPIED-sensitive registered rule | Compile valid native-bed states with unoccupied PERMEABLE and occupied SEALED, plus reverse-state controls; capture actual effective loss/admission outcome rather than label the change neutral. A SEALED sleeping-eye setup cannot be predeclared breathable. |
| Adjacent native door/trapdoor/gate and owned airlock | Native use/redstone/support/removal operations; observe notification order and both halves. If a bed-caused late door mutation is alleged, supply a real reproducible native sequence, not fabricated event fields. |
| Cached/in-flight/completed scan and dirty backlog | Real changed wall/door operation, including provider replacement by unregistered block; verify immediate authority revocation and no stale republish before repair. |
| Genuine/unknown loss while sleeping | Exhaust supply, remove vent/boundary, malformed pair, unavailable cell, reload and live access change; observe the first actual native wake check and ordinary native wake cleanup. |
| Reload versus provider removal | Actual reload-wide sync preserves frozen rule table but revokes service authority; separate provider-free restart verifies legacy fallback and no retained sleep/air witness. |
| Lifecycle and budgets | Native manual wake, break, death/logout/clone, authorized teleport, unload/stop/restart; deduplicated lookup counts, no new forced loads, one ordinary supply debit and existing reference-load counters/MSPT. |

Existing [AtmosphereGameTests:115-166,333-344](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/atmosphere-tests-38.stdout.txt#L115)
construct standalone services and explicitly mark dirty. They remain useful service
regressions, not installed bed-event proof. Existing
[boundary tests:80-159](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/boundary-tests-39.stdout.txt#L80)
cover backlog/reload on constructed instances. The more recent
[AirlockDoorGameTests:265-329,501-513](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/airlock-tests-40.stdout.txt#L265)
exercise installed native revocation and use private read-only test witnesses;
do not claim that infrastructure is absent, that these are sleep tests, or that its
reflection is permission for new production/test access in Task56.

## 9. Other prerequisites and unresolved decisions

- B1/R1: native bed-caused spawn setter and actual callback/receiver authentication
  remain separate. ServerPlayer writes spawn at offsets 107-122, before later time
  and monster failures at 125-258; M1 air checks do not resolve that ordering.
- M2: actual loaded host/profile and operational live Space station/authorization
  checks for both cells remain separate. At fixed e21, the Space policy answer was
  still pending. During Task56, Root relayed the actual root-session owner answer
  "允许供氧的站外房间（推荐）" to question04: supplied/sealed rooms outside committed
  station regions, with in-region per-point VISIT, unavailable registry rejection
  and unchanged drift/safety-return/spawn constraints. This is explicitly a Root
  session-message attribution; the new owner-decision publication was not yet
  committed/read here. This worker does not select policy or infer an M1/M2 source
  assignment from the relay; implementation and exact both-cell behavior remain open.
- D1: outcome freeze33 does not implement natural profiles, native Level quorum,
  shared-primary time or compass/clock behavior and does not grant M1 a mechanism.
- Offline core contract52 and peers53/55 concern different files/evidence and
  confer no sleep/air or runtime-resource authority here.

Next permitted v1.8 work is independent review of this feasibility/missing-mechanism
record and a separately scoped source-evidence task for an authentic public receipt
producer/closure, if warranted. Implementation/native runtime validation require
their own assignment after the unresolved dependencies and canonical owner-decision record are
handled. No Required Gate or current status is changed.
