$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$target = Join-Path $leaf 'COMMAND-AUDIT.json'
if (Test-Path -LiteralPath $target) { throw 'Refusing audit overwrite' }
$items = @()
foreach ($file in (Get-ChildItem -LiteralPath $leaf -File -Filter '*.command.json' | Sort-Object Name)) {
    $receipt = Get-Content -LiteralPath $file.FullName -Raw -Encoding utf8 | ConvertFrom-Json
    $stem = $file.Name.Substring(0, $file.Name.Length - '.command.json'.Length)
    foreach ($name in @('stdout','stderr')) {
        $path = Join-Path $leaf "$stem.$name.txt"
        $info = $receipt.$name
        if ((Get-Item -LiteralPath $path).Length -ne $info.retained_bytes) { throw "Length mismatch: $path" }
        $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $info.retained_sha256) { throw "Retained digest mismatch: $path" }
        if (-not $info.overflow -and ($hash -ne $info.raw_sha256 -or $info.raw_bytes -ne $info.retained_bytes)) {
            throw "Complete raw identity mismatch: $path"
        }
    }
    if ($receipt.ceiling_seconds -ne 180 -or $receipt.stream_cap_bytes -ne 262144) { throw "Unexpected caps: $stem" }
    $items += [ordered]@{ name=$stem; receipt_sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant(); receipt=$receipt }
}
$note = 'Snapshot of already-finished captured static commands only. This audit child and subsequent custody/seal receipts are not recursively included. Direct preparation/tool-facing displays lack this receipt coverage; no historical reconstruction.'
$audit = [ordered]@{ note=$note; captured_commands=$items.Count; commands=$items }
[IO.File]::WriteAllText($target, ($audit | ConvertTo-Json -Depth 12) + "`n", [Text.UTF8Encoding]::new($false))
$failed = @($items | Where-Object { $_.receipt.exit_code -ne 0 } | ForEach-Object { $_.name })
$timeouts = @($items | Where-Object { $_.receipt.timeout } | ForEach-Object { $_.name })
$overflows = @($items | Where-Object { $_.receipt.stdout.overflow -or $_.receipt.stderr.overflow } | ForEach-Object { $_.name })
$files = @(Get-ChildItem -LiteralPath $leaf -File)
[ordered]@{ audited_commands=$items.Count; nonzero_exits=$failed; timeouts=$timeouts; raw_stream_overflows=$overflows;
    audit_bytes=(Get-Item -LiteralPath $target).Length; audit_sha256=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant();
    leaf_files_at_audit=$files.Count; leaf_bytes_at_audit=($files | Measure-Object -Property Length -Sum).Sum;
    task_sha256=(Get-FileHash -LiteralPath 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-AIR-IMPLEMENTATION-FEASIBILITY-TASK-56.md' -Algorithm SHA256).Hash.ToLowerInvariant()
} | ConvertTo-Json -Depth 4
