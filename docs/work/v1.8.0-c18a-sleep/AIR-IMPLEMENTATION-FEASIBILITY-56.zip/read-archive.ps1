param([Parameter(Mandatory)][string]$Archive, [string]$Member)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead($Archive)
try {
    if ($Member) {
        $entry=$zip.GetEntry($Member)
        if ($null -eq $entry) { throw "Exact member absent: $Member" }
        if ($entry.Length -gt 262144) { throw 'Member exceeds retained stream cap' }
        $stream=$entry.Open()
        try { $stream.CopyTo([Console]::OpenStandardOutput()) } finally { $stream.Dispose() }
    } else {
        [ordered]@{archive=$Archive; bytes=(Get-Item -LiteralPath $Archive).Length;
            sha256=(Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json
        foreach($entry in $zip.Entries) {
            $stream=$entry.Open(); $hash=[Security.Cryptography.SHA256]::Create()
            try { $digest=[Convert]::ToHexString($hash.ComputeHash($stream)).ToLowerInvariant() }
            finally { $stream.Dispose(); $hash.Dispose() }
            [ordered]@{member=$entry.FullName; bytes=$entry.Length; compressed_bytes=$entry.CompressedLength;
                sha256=$digest} | ConvertTo-Json -Compress
        }
    }
} finally { $zip.Dispose() }
