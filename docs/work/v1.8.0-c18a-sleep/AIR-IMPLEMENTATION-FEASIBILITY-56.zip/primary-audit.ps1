$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$mapped = 'C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
$sources = 'C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar'
$files = @($mapped, $sources, 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
foreach ($path in $files) {
    [ordered]@{ kind='file'; path=$path; bytes=(Get-Item -LiteralPath $path).Length;
        sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() } | ConvertTo-Json -Compress
}
$entries = @{
    mapped=@('net/minecraft/world/entity/LivingEntity.class', 'net/minecraft/world/entity/player/Player.class',
        'net/minecraft/world/level/block/BedBlock.class', 'net/minecraft/world/level/Level.class',
        'net/minecraft/server/level/ServerLevel.class', 'net/minecraft/world/level/block/DoorBlock.class',
        'net/minecraft/server/level/ServerPlayerGameMode.class', 'net/minecraft/server/level/ServerPlayer.class',
        'net/minecraftforge/common/extensions/IForgeBlock.class');
    sources=@('net/minecraftforge/event/level/BlockEvent.java',
        'net/minecraftforge/event/entity/player/SleepingTimeCheckEvent.java',
        'net/minecraftforge/event/entity/player/PlayerSleepInBedEvent.java',
        'net/minecraftforge/event/entity/player/PlayerWakeUpEvent.java',
        'net/minecraftforge/common/extensions/IForgeBlock.java')
}
foreach ($name in @('mapped','sources')) {
    $path = if ($name -eq 'mapped') { $mapped } else { $sources }
    $zip = [IO.Compression.ZipFile]::OpenRead($path)
    try {
        foreach ($member in $entries[$name]) {
            $entry = $zip.GetEntry($member)
            if ($null -eq $entry) { throw "Missing exact primary member: $member" }
            if ($entry.Length -gt 262144) { throw "Exact primary member exceeds cap: $member" }
            $stream = $entry.Open(); $hash = [Security.Cryptography.SHA256]::Create()
            try { $digest = [Convert]::ToHexString($hash.ComputeHash($stream)).ToLowerInvariant() }
            finally { $stream.Dispose(); $hash.Dispose() }
            [ordered]@{ kind='member'; archive=$name; member=$member; bytes=$entry.Length; sha256=$digest } | ConvertTo-Json -Compress
        }
    } finally { $zip.Dispose() }
}
