$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot)
$expectedLeaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56')
if (-not $leaf.Equals($expectedLeaf, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected custody leaf' }
$manifestPath = Join-Path $leaf 'SHA256SUMS.txt'
$resultPath = Join-Path $leaf 'SEAL-RESULT.json'
foreach ($path in @($manifestPath,$resultPath)) {
    if (Test-Path -LiteralPath $path) { throw "One-time seal already has output: $path" }
}
$inputs = @(
    @{ name='PROPOSED-M1-IMPLEMENTATION-FEASIBILITY-01.md'; bytes=24964; lines=307; sha256='deea111caf71311c151385ad2ab9c6838d87e8f1611e7c17e484c6bee018c2c6' },
    @{ name='REPORT.md'; bytes=23404; lines=318; sha256='6599ada57402229cf31ac21a5d8980dd48b3f21e6f1524aef0b0ebef39382a55' }
)
foreach ($input in $inputs) {
    $path = Join-Path $leaf $input.name
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $input.sha256 -or (Get-Item -LiteralPath $path).Length -ne $input.bytes -or (@(Get-Content -LiteralPath $path -Encoding utf8)).Count -ne $input.lines) { throw "Stable input changed: $path" }
}
$ackPath = Join-Path $leaf 'CUSTODY-ACK.md'
$ack = Get-Content -LiteralPath $ackPath -Raw -Encoding utf8
foreach ($input in $inputs) {
    if (-not $ack.Contains($input.sha256)) { throw 'Custody acknowledgment does not bind both stable hashes' }
}
$excluded = @('SHA256SUMS.txt','SEAL-RESULT.json','custody-seal-70.stdout.txt','custody-seal-70.stderr.txt','custody-seal-70.command.json')
$allFiles = @(Get-ChildItem -LiteralPath $leaf -File)
if (@(Get-ChildItem -LiteralPath $leaf -Directory).Count -ne 0) { throw 'Unexpected nested custody directory' }
$covered = @($allFiles | Where-Object { $_.Name -notin $excluded } | Sort-Object Name)
$lines = @()
foreach ($file in $covered) {
    $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    $lines += "$hash  $($file.Name)"
}
$manifestText = ($lines -join "`n") + "`n"
if (($allFiles | Measure-Object -Property Length -Sum).Sum + [Text.Encoding]::UTF8.GetByteCount($manifestText) + 524288 + 32768 -gt 4194304) { throw 'Custody leaf would exceed assigned cap with late receipt allowance' }
[IO.File]::WriteAllText($manifestPath, $manifestText, [Text.UTF8Encoding]::new($false))
for ($index=0; $index -lt $covered.Count; $index++) {
    $expectedHash = $lines[$index].Substring(0,64)
    if ((Get-FileHash -LiteralPath $covered[$index].FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) {
        throw "Covered file changed during custody seal: $($covered[$index].Name)"
    }
}
$manifestHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
$result = [ordered]@{
    schema='arce.task56.custody-seal.v1'; task='Task56'; sealed_utc=[DateTime]::UtcNow.ToString('o')
    leaf=$leaf; leaf_cap_bytes=4194304; source_commit='e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1'
    historical_observation_commit='d57ecda1f11dab76d882f945b0de606534ef4fb9'
    stable_inputs=$inputs; custody_ack_file='CUSTODY-ACK.md'
    custody_ack_sha256=(Get-FileHash -LiteralPath $ackPath -Algorithm SHA256).Hash.ToLowerInvariant()
    manifest_file='SHA256SUMS.txt'; manifest_bytes=(Get-Item -LiteralPath $manifestPath).Length
    manifest_sha256=$manifestHash; covered_files=$covered.Count
    covered_bytes=($covered | Measure-Object -Property Length -Sum).Sum; covered_digests_reverified=$true
    excluded_protocol_names=$excluded
    exclusion_reason='Manifest self-reference, result self-reference, and three outer capture receipts created only after this child completes. Final caller must verify actual physical exclusions.'
    seal_scope='Exact-hash full-read custody only; not implementation/contract/ADR/risk/policy/Gate/resource acceptance.'
    gaps_preserved='Original direct preparation/renderer instrumentation gap, source rendering truncation, vent-path exit128, grep no-match1 and two failed manual-context patches remain in stable REPORT.'
}
[IO.File]::WriteAllText($resultPath, ($result | ConvertTo-Json -Depth 6) + "`n", [Text.UTF8Encoding]::new($false))
[Console]::OpenStandardOutput().Write([IO.File]::ReadAllBytes($resultPath))
