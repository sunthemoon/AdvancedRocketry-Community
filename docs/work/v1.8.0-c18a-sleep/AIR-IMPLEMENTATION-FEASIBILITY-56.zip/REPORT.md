# Task56 supplied-air sleep source-feasibility report

## Findings and status

Status: evidence-only feasibility proposal delivered; M1 implementation readiness
is **not established**. No production code, test, world or Gate change was made.
Author: delegated engineering worker `/root/sleep_json_platform_counter`.
Date: 2026-10-09. This is worker research, not independent review or owner adoption.

1. **Registered-bed pre-admission can revoke supplied authority.** Current
   [AtmosphereServerEvents:58-72](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L58)
   marks exactly registered clicked states dirty, including DEFAULT. Native
   RightClick precedes item-first/block use and later admission. This is a static
   ordering risk, not measured universal refusal or immediate wake.
2. **OCCUPIED neutrality cannot be assumed.**
   [Registry:96-115](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/registry-22.stdout.txt#L96)
   compiles all possible immutable states; providers may validly classify bed
   occupancy differently. Native occupancy calls flag-3 setBlock before sleeping
   pose. Coarse neighbor invalidation also applies with an unrelated nonempty
   catalog, even when RightClick registration membership did not match.
3. **The inspected event API lacks authenticated old/new operation evidence.**
   [Installed BlockEvent:38-64,188-223](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/block-event-54.stdout.txt#L188)
   has one current state and notification directions, not a native sleeper/receiver,
   paired previous/current state or completed neighbor-effect receipt. The native
   old/new locals are not a new mod-owned global hook.
4. **Adjacent-door handling cannot safely be skipped with a bed exemption.**
   [Events:75-89](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L75)
   revokes loaded adjacent door authority before native neighbor reactions.
   Native DoorBlock can subsequently change POWERED/OPEN with flag 2. The existing
   [owned airlock:55-89](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/airlock-28.stdout.txt#L55)
   and [runtime:28-48](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/runtime-15.stdout.txt#L28)
   already supply a guarded both-half pre-mutation revocation bridge; do not
   misreport that infrastructure as absent or infer it wraps vanilla beds.
5. **Existing volume models are not an old-state/frontier journal.**
   [Scan task:65-105](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/scan-task-29.stdout.txt#L65),
   [volume:7-35](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/volume-model-32.stdout.txt#L7)
   and [index:19-21](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/volume-index-31.stdout.txt#L19)
   retain traversable cells/bounds, not authenticated previous sealing states.
6. **Reload and provider removal are different lifecycle operations.**
   [Events:101-104](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/events-14.stdout.txt#L101)
   plus [service:287-291,439-445](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/level-service-17.stdout.txt#L287)
   revoke service authority on reload-wide sync while reusing the compiled table.
   Provider removal changes that table on a new mod-loading startup, not `/reload`
   or a later world start within the same loaded process.

The additive [proposal](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/PROPOSED-M1-IMPLEMENTATION-FEASIBILITY-01.md)
identifies the smallest separable conditional pure-policy/test scope and the
missing authentic public receipt/neighbor-closure producer. It explicitly does
not assign an event exemption or claim a complete M1 fix. Genuine/unknown loss,
zero new forced loading and all existing budgets remain requirements.

## Fixed inputs and identities

- Assignment: [Task56](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-AIR-IMPLEMENTATION-FEASIBILITY-TASK-56.md),
  SHA256 `e80c1796ec1352c8c1bd8ec5b257a52be70c5e38875cec7a86c3de323ffa02e8`.
- Current source/governance is exclusively Git commit
  `e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1`.
- Historical reports/observations remain attributed to
  `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
- Proposal stable identity: 307 lines / 24964 bytes,
  SHA256 `deea111caf71311c151385ad2ab9c6838d87e8f1611e7c17e484c6bee018c2c6`.
- Exact fixed Git blob inputs are bound by the true `git show <fixed>:<path>` argv
  in each adjacent command receipt, not mutable working Main HEAD.

All six required fixed sleep documents were captured and read completely:

| Fixed document / evidence capture | Bytes | SHA256 |
| --- | ---: | --- |
| [PROPOSED-CONTRACT-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/sleep-contract-01.stdout.txt) | 24707 | `55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21` |
| [CONTRACT-REVIEW-STATUS-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/contract-status-02.stdout.txt) | 3329 | `b2a71f827cc949ff24e3dfce2a8cbfd26dcbc91e1edaaca30425bf330f97afa6` |
| [AIR-RESEARCH-STATUS-02](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/air-status-03.stdout.txt) | 3608 | `4887fa54a0d64764a95a4330ec238666d6722b939436880ad57683aaf4b11489` |
| [BOUNDARY-REVIEW-STATUS-03](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/boundary-status-04.stdout.txt) | 3428 | `4ef862672772ed4ff34a4e7eeb931d2275f0af5c3f25364274ea52609bb638ce` |
| [D1-OUTCOME-FREEZE-33](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/d1-freeze-05.stdout.txt) | 7681 | `b8c4145c33a5322a75ed449d3a5de5317f3c04d4ac31096fde67b927c0c5db18` |
| [OFFLINE-CORE-CONTRACT-FREEZE-52](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/offline-freeze-06.stdout.txt) | 7949 | `445be05d7e086b0d2d346f239f6ae71c896941f77fe7475eb51e9666974826ae` |

The exact boundary checkpoint linked the existing archive, so no guessed archive
name or broad retry was needed:

| Working archive, independently hashed read-only | Bytes | SHA256 |
| --- | ---: | --- |
| [AIR-FEASIBILITY-02.zip](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep/AIR-FEASIBILITY-02.zip) | 146434 | `d272e2a94129279416b01c5b489c788acbd6c2d117d62715f1b3ff7323b6c39d` |
| [BOUNDARY-INDEPENDENT-03.zip](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep/BOUNDARY-INDEPENDENT-03.zip) | 54282 | `78896073d96d27e85168aa62fb9e32a99ef01685f1f5760fd72e05a595a64664` |

Inventories07/08 hashed all 16/11 actual members without extraction. Separate
[manifest verification60](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/air-manifest-60.stdout.txt)
matched 15 members / 693057 bytes and
[verification61](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/boundary-manifest-61.stdout.txt)
matched 10 / 391381. Each actual manifest excludes only itself. CRC was not
independently verified; hashes and successful bounded member reads are the checks
actually performed. No archive script was executed and no source tree was exported.

Required historical texts were read in full from exact members:

| Member capture | Bytes | SHA256 |
| --- | ---: | --- |
| [AIR proposal09](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/air-proposal-09.stdout.txt) | 14031 | `365951558aa660bbc947d428e9e82127029b17b210d933e6c6fe7d0da893e391` |
| [AIR report10](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/air-report-10.stdout.txt) | 33387 | `ee1a0a45fc98537feb3e8a59cdc28c75087350d8742236bea2c15955a1eaf80f` |
| [Boundary report11](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/boundary-report-11.stdout.txt) | 21172 | `7273034e676bb038f5e95d8f49a7a68fcb3107a57b9042965058a250fd1bf9c7` |

Historical selected native methods and primary metadata were read separately;
they are not relabeled as new runtime traces. The fresh
[installed primary audit50](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/primary-current-50.stdout.txt)
confirmed the exact mapped jar (19355242 bytes,
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`),
Forge sources jar (1621504,
`918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`),
and javap executable (23696,
`69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`).
Their paths are explicitly retained in that audit and receipt. Nine exact mapped
class entries needed for bed/neighbor/wake order and five exact Forge declarations
were hashed, not a broad native class inventory. All previously recorded matching
identities remain byte-identical; whole mapped-jar identity also binds the selected
historical factory methods.

New public-only javap59 inspected LivingEntity, Player, ServerPlayer and IForgeBlock
declarations; exit0, stdout45066 bytes, stderr0, SHA256
`1d2656e98ac5fb35b1782962bf05c7d3a0d54d546332ed130c573c2a2152d17d`.
It did not execute Minecraft or grant access to private fields.

## Preparation, actual reads and protected state

Before any own leaf/helper write, the actual working Main
[AGENTS.md](D:/GitHub/AdvancedRocketry-Community/AGENTS.md) was read completely in
an explicit UTF-8 display. It was owner-modified and was not changed by this worker.
Git status, branch, HEAD, full worktree list and live collaboration agents were
checked. At preparation Main was `codex/v1.8.0-classic-content` at fixed e21; only
AGENTS was tracked-dirty and the index was empty. Existing untracked artifacts
were left alone. The exclusive Task56 leaf was verified absent before creation.

Complete mandatory fixed governance reads occurred before own writes:
[PROJECT-CONFIG](D:/GitHub/AdvancedRocketry-Community/PROJECT-CONFIG.md),
[PRODUCT](D:/GitHub/AdvancedRocketry-Community/PRODUCT.md),
[porting principles](D:/GitHub/AdvancedRocketry-Community/docs/01-PORTING-PRINCIPLES.md),
[roadmap](D:/GitHub/AdvancedRocketry-Community/docs/04-VERSION-ROADMAP.md),
[v1.8 version](D:/GitHub/AdvancedRocketry-Community/docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md),
[master tests](D:/GitHub/AdvancedRocketry-Community/docs/05-MASTER-TEST-PLAN.md),
[release Gates](D:/GitHub/AdvancedRocketry-Community/docs/06-RELEASE-AND-ACCEPTANCE-GATES.md),
[v1plus roadmap](D:/GitHub/AdvancedRocketry-Community/docs/16-POST-1.0-VERSION-ROADMAP.md),
[quality budgets](D:/GitHub/AdvancedRocketry-Community/docs/17-V1PLUS-QUALITY-BUDGETS.md),
and [parallel coordination](D:/GitHub/AdvancedRocketry-Community/docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md).
Actual working version and fixed Gate status were also fully read. No upstream
source/art import was involved.

**Preparation instrumentation gap:** those initial direct tool preparation/Git
displays have conversation tool outputs/exit records, but no original own fixed180
watchdog, raw split-stream hash/length or UTC receipt. This was reported to Root
before continuing. It remains a gap; later receipts are not reconstructed historical
preparation records. Direct tool-facing rendering/manual patch calls similarly are
not claimed to be in the captured-child command audit. No complete every-command
instrumentation or OS hard-preemption claim is made.

All required current core interfaces/models were read completely from fixed Git
captures: events14, runtime15, manager16, level-service17, world-view18, catalog21,
registry22, provider23, classification24, registrar25, register-event26, limits27,
airlock28, scan-task29, scan-coordinator30, volume-index31, volume-model32,
scan-result33 and cell-observation34. Registry tests41, life-support43, ADR-02444,
supply48 and runtime lifecycle test49 were read fully. Central wiring37 was read at
368-395 and 427-447 with nearby lifecycle context, not claimed as a full-file read.
Atmosphere tests38 and boundary tests39 were read completely across displays.
Airlock tests40 were inspected at native pair guards/redstone, installed
revocation265-329 and exact witness helpers501-513; unrelated loot/placement content
was not claimed fully reviewed. Actual vent47 was inspected at tick/supply/current
resource guards and capability seams; unrelated persistence/inventory content was
not claimed fully read.

Root54 announced a docs/archive-only checkpoint and requested HEAD-dependency
confirmation. This worker confirmed all remaining source/governance reads were
fixed e21, historical attribution d57, and own writes confined to the new leaf.
Root subsequently reported commit/push
`0dcfaf980e4a4236ff5e3c8630286b40b34eebb1`; the
[identity63](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/protected-identity-63.stdout.txt)
independently observed that HEAD. This did not rebind Task56 inputs.
[Status62](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/protected-status-62.stdout.txt)
still showed only tracked AGENTS modification and existing untracked artifacts;
[index64](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/protected-index-64.stdout.txt)
was empty and [fixed-to-HEAD source diff65](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/protected-source-65.stdout.txt)
was empty. No worker commit, staging, checkout, push, deletion or cleanup occurred.
Peer53/55 files and sealed Task44/50 leaves were not edited or reopened for writes.

At fixed e21 the Space question04 was unanswered. Before stable Task56 delivery,
Root relayed the actual owner answer in the root session, exactly
"允许供氧的站外房间（推荐）". Root specified supplied/sealed rooms outside committed
station regions, in-region per-point VISIT, unavailable registry rejection and
unchanged drift/safety-return/spawn constraints, and said a new owner-decision
publication would follow. This report attributes that new information to the
actual Root session message, not to the fixed source or a read/committed owner
record. This worker makes no policy choice or implementation grant from the relay.

## Actual commands, results, limits and preserved gaps

Captures01-67 are 67 separately named static child commands. Every captured child
uses the unchanged own [capture helper](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/capture.ps1):
fixed180 seconds, <=262144 retained bytes per split raw stream, actual executable/
argument vector/cwd/start-end UTC/PID/exit, raw and retained byte lengths/SHA256.
Only its known immediate child is eligible for actual timeout handling; no child
tree/foreign process management. No timeout was reached, no stream overflow occurred.
The helper is not an allocator/OS hard-resource enforcement claim.

| Commands | Actual scope/result |
| --- | --- |
| 01-06 | Six fixed sleep document `git show` reads; all exit0. |
| 07-12 | Exact archive/member/primary-metadata reads; all exit0, no extraction. |
| 13-34 | Narrow fixed paths and atmosphere/provider/scan sources; all exit0. |
| 35-41 | Exact central symbols/ADR filename, wiring and relevant tests; all exit0. |
| 42 | Wrong presumed vent `atmosphere/content` path: git show exit128, stdout0, stderr182. Preserved, not converted into success. |
| 43-44 | Life-support and discovered ADR-024 source; exit0. |
| 45 | Narrow sleep-hook symbol grep: exit1 with both streams0, meaning no matches in the stated source/test scope, not runtime proof or a test failure. |
| 46-49 | Exact lifecycle path, independently discovered `atmosphere/vent` source, supply and lifecycle test; all exit0. Corrected path47 is a distinct supporting read, not an unchanged retry. |
| 50-58 | Exact installed primary identities, three historical native excerpts and five primary Forge source declarations; all exit0. |
| 59 | Public-only static javap four exact classes; exit0. |
| 60-61 | Distinct archive manifest-verification checks; all listed member hashes match, exit0. |
| 62-65 | Protected current status/identity/index and fixed-to-HEAD src diff; all exit0. |
| 66 | Verified existing raw/retained hashes and caps for the prior 65 captured receipts; exit0. |
| 67 | Separately named supporting fixed version/Gate read, not original preparation reconstruction; exit0. |

[COMMAND-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/COMMAND-AUDIT.json)
contains the exact argv, UTCs, exits, raw/retained digests and receipt hashes for
01-65; 112630 bytes, SHA256
`55b425139bad15242d5160386da28bbb5b55f103edaaff7748a2733d080aa535`.
It intentionally predates audit66 and supporting read67, whose own separate
receipts are retained. In that 65-command snapshot the largest raw stdout was
80520 bytes and largest stderr182; nonzero exits were only42 and45, no overflow
or timeout. Audit66 stdout423 bytes and stderr0; read67 stdout8905 and stderr0.
Audit's physical snapshot was 201 files / 877995 bytes before its own three late
receipt files, read67, proposal/report and later custody files. It is not a final
sealed-package count.

Preserved tool/display issues, separate from raw child stream caps:

- A grouped source display returned tool truncation (tool chunk `be5a96`). The
  underlying complete source captures were not truncated or replaced. Missing
  atmosphere-test ranges were later read in distinct smaller displays, including
  170-350 and 333-393. This does not erase the initial rendering truncation.
- A one-line filename display indexed a PowerShell scalar string as a character
  and showed `A`; the actual receipt retained all46 bytes, and a separate raw UTF-8
  display read the complete ADR filename. No filesystem search retry was needed.
- Two manual proposal wording patches failed to match expected context. No file
  was changed by either failed patch; separate bounded context reads and exact
  patches corrected the prose before stable delivery. These failures are tool-history
  records, not fabricated child command receipts.

No test/world/Gradle/native/game launch, decoder/resource cohort, install,
environment/quota/service/privilege change or process enumeration/termination was
performed. `javap` is the only JVM-based static tool launched; it ran no game/test.
No delegation occurred. Root coordinated OpenPet; this worker did not spam it.

## Completion scope, design decisions and modified files

Completed: current M1 source/event/lifecycle mapping, exact primary identity
checks, bounded historical archive/member verification, additive feasibility and
candidate native-operation test design, protected-state checks, stable proposal.

Not completed: authentic public paired native-bed receipt/closure, implementation,
independent proposal review, runtime proof, B1/R1/M2/D1 integration, canonical
publication/read of the newly relayed Space owner decision, decoder/resource
qualification and release acceptance.

Design decisions: preserve existing dirty fallback and owned airlock bridge; reuse
manager read-only air rather than another debit authority; compiled enum equality
alone is insufficient; no journal without bounded authenticated capture; no new
Gameplay/NBT/network/log/scan budget change. Same-JVM arbitrary callback effects
and absent witnesses remain unknown and fail closed.

Only the [exclusive evidence leaf](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56)
was written: proposal, this report, five own static capture/read/audit helpers,
67 command receipt/stream triples and the generated command audit. Helpers neither
change project files nor execute historical archive scripts. Subsequent own
custody/seal records, if authorized by actual Root full read, remain additive here.

## Tests, acceptance evidence and known risks

New/modified executable tests: none. Proposal's native-operation matrix is design,
not test execution or an assigned expected outcome. Existing service tests were
inspected, not rerun. Some current installed-airlock tests use private read-only
reflection; this observation is not a new private-field/AT/ASM grant. A later
installed sleep witness seam must be separately reviewed/assigned.

`clean build`, `runData`, `git diff --exit-code`, `runGameTestServer`, packaged native
startup/restart, real-GPU V1/V2, two connected clients, true-sleep loss/wake and
reference-workload/MSPT checks: **NOT_EXECUTED by Task56**, not PASS or NOT_APPLICABLE.
The readonly name-status source/index checks are not relabeled as those gates.

Current v1.8 remains IN_PROGRESS with Required Gates **G0, G1, G2, G3, G4, G5, G6,
G7, G8 and G9 all unresolved by this task**, including inherited v1.0 acceptance.
The [supporting version read67](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56/gate-supporting-read-67.stdout.txt)
binds the fixed current version/Gate requirements. Does Task56 satisfy all current
Required Gates? **No.** No status, ledger, risk, ADR, product policy or Gate authority
is exercised here.

Open M1 requirements (these IDs are local, not historical counter U01/U02):

- M1-01: authentic old/new native operation receipt and bounded neighbor closure
  are not established by inspected public APIs; neutral preservation is unassigned.
- M1-02: current adapter/provider classification precedence and genuine/unknown
  loss must survive any proposed selective invalidation refinement; no weakening
  of accepted ADR-024 or budgets is implied.
- M1-03: installed native admission/occupancy/wake, adjacent-door transitions,
  resource/queued-scan/reload/removal/lifecycle proof is absent.
- M1-04: B1/R1, actual-host/live-access M2 and D1 mechanisms remain independent
  prerequisites. The actual Space answer was relayed by Root before delivery,
  but its canonical decision publication/read is outside this fixed-source
  evidence. No M1/M2 source assignment or policy adoption is performed here.
- M1-05: original direct preparation/renderer instrumentation coverage gap remains
  disclosed; a later receipt/seal cannot retroactively qualify it.

Only v1.8 next work is recommended: independent read-only review of this proposal
and a new bounded source-evidence task for a public authentic receipt/closure
mechanism if warranted. Do not issue production/native work merely because a
conditional predicate or proposed journal has been named.

## Stable delivery and custody

This report and proposal are to remain unchanged after stable identity delivery.
At this report's preparation, Root exact-hash complete-read acknowledgment and
the own one-time seal have **not yet occurred**. No final manifest coverage,
exclusions, seal success or Root adoption is preclaimed here. Actual acknowledgment,
manifest/exclusions/result must be recorded in subsequent additive custody files
and returned separately, without changing these stable texts or sealed44/50.
