import hashlib
import json
import pathlib
import zipfile

leaf = pathlib.Path(__file__).resolve().parent
checkout = pathlib.Path('D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009')
paths = [
    checkout / 'build/libs/advancedrocketry-community-1.20.1-1.8.0-dev.jar',
    checkout / 'build/libs/advancedrocketry-community-1.20.1-1.8.0-dev-api.jar',
    checkout / 'build/libs/advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar',
    checkout / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar',
]
result = []
for path in paths:
    if not path.is_file() or path.stat().st_size > 50 * 1024 * 1024:
        raise ValueError('Absent or oversized assigned artifact: ' + str(path))
    row = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) > 65536:
            raise ValueError('Oversized static ZIP inventory')
        names = [entry.filename for entry in entries]
        row['entries'] = len(names)
        row['unique_names'] = len(set(names)) == len(names)
        row['crc_error'] = archive.testzip()
        row['sleep_classes'] = [n for n in names if '/SleepBoundary' in n and n.endswith('.class')]
        row['adapter_classes'] = sum(n.startswith('io/github/sunthemoon/arceadaptertest/') and n.endswith('.class') for n in names)
        row['fixture_foreign_classes'] = [n for n in names if path == paths[-1] and n.endswith('.class') and not n.startswith('io/github/sunthemoon/arceadaptertest/')]
        row['jarjar'] = [n for n in names if n.startswith('META-INF/jarjar/')]
    result.append(row)
data = json.dumps(result, indent=2) + '\n'
(leaf / 'ARTIFACT-STATIC-AUDIT.json').write_text(data, encoding='utf-8')
print(data)
