# Independent corrected observation driver contract review 16

Date: 2026-10-09 UTC. Delegated read-only reviewer, not Root. This is a static
contract review, not executable freeze, runtime permission or acceptance.

## Findings first

### R01 — Medium: freeze the actual stdout character encoding, not only its prefix

The proposal requires strict UTF-8 decoding and measures logical UTF-8 payload
bytes, but its native argv and stdout qualification name routing/wrapper behavior
without pinning the encoding of the final byte stream. See the fixed proposal
[lines 86-93, 167-180, 443-474](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md).
Fixed Trace line 44 disables HTML escaping; its component/error strings can
contain non-ASCII UTF-16 units. Fixed Fixture line 122 writes through
System.out.println, not an explicitly selected Charset. The installed public
PrintStream constructor bytecode accepts a Charset and forwards it to
OutputStreamWriter, while the no-charset constructors use a different path;
see [39-printstream-primary.stdout.txt:3-58](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/commands/39-printstream-primary.stdout.txt).

An ASCII historical prefix cannot establish preservation of non-ASCII payloads,
or equality between the Trace counter and native wire size. This does **not**
demonstrate a charset failure in an executed sleep run: no such run exists here.
Before executable freeze, include the exact final PrintStream/logger encoding
and malformed/unpaired-surrogate conversion in the static stdout qualification.
Bind that proof to the actual JDK, launch arguments, argument files and routing.
Any needed JVM-argument change must be explicit and independently reviewed;
do not silently add flags or accept lossy decoder replacement after a failure.
Add corresponding structural offline encoding tests in the later test assignment.

### R02 — Medium: overflow retention and writer failure still need a finite policy

The proposal gives stdout/latest/debug a 24 MiB acceptance threshold each, then
requires complete raw bytes to remain at an external owned location. It also
requires persistence of all receipts/bytes before raising. See
[lines 157-184](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md).
The in-memory scanner and deadlines are finite, but the external spool has no
specified maximum bytes/reserved capacity or explicit ENOSPC/write/flush failure
transition. A finite wall-clock deadline is not a finite output-volume budget.
The initial 10 GiB check does not guarantee later spool writes can complete.

Before executable freeze, distinguish the evidence acceptance threshold from a
hard owned-storage budget. Define pre-reserved/qualified overflow capacity and
the actual reader/writer failure receipt, retained-byte cursor/hash and bounded
save/stop/exit behavior when complete capture becomes physically impossible.
Such a failure must remain capture-incomplete; it cannot be relabeled complete,
silently truncated, retried through another destination or made an acceptance
success. Preserve all bytes actually obtained and any failure receipt that can
be written. This is an implementability gap in the failure contract, not a
demonstrated disk failure or permission to weaken the repository evidence budget.

### R03 — Low: explicitly qualify NBT string encoding and gzip member policy

The typed-NBT proposal correctly keeps wire types, caps and absent defaults
separate, but does not yet name the exact native string decoder or whether one
gzip member is required. See
[lines 528-551](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md).
The actual installed StringTag public write path calls DataOutput.writeUTF;
see [40-nbt-primary.stdout.txt:30-44](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/commands/40-nbt-primary.stdout.txt).
This uses Java modified UTF-8, not the stdout JSON UTF-8 domain. The distinction
matters even for bounded-skipped/validated unrelated string tags. A generic
UTF-8 decoder must not be inherited from the historical ambient NBT helper.

The later typed parser freeze should pin modified-UTF-8 rules, gzip member/trailer
and exact-consumed-input rules, including NUL/supplementary characters and
malformed cases in offline tests. The proposal already lists parser/default
qualification as open; this finding specifies that prerequisite rather than
claiming native Spawn parsing was executed or that an ASCII SpawnDimension
would presently fail.

No Critical/High runtime defect is established by these static checks. R01/R02
must be dispositioned before an executable/runtime contract freeze; R03 belongs
in that parser qualification. This report does not modify or close any issue.

## Source fidelity and checks that are supported

The complete 497-line Fixture and 498-line Trace at fixed source
5b45132000ade1e3c8d130a6b8ccb29f07535124 were read, not a moving author checkout.
The base-to-source stat contains only those two adapterTest files, 995 additions.
Their blob IDs are 8e02816298e750a0b80f5b164ee2b87871028112 and
561d169f5005639d814d6ca15d7d2f9a0fc4a77c. Raw fixed inputs are
[21-fixture.stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/commands/21-fixture.stdout.txt) and
[22-trace.stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/commands/22-trace.stdout.txt).

- The exact twenty names/routes, twelve-cell inventory, A/B UUIDs, homes,
  observer-off/on rows, genuine-event control guard and direct/forwarded callback
  distinction match the fixed source. No desired native bed/spawn/frame outcome
  is prescribed. FOOT-target preparation is checked by source even though native
  snapshots expose only HEAD reach/mayInteract.
- Root, row, action, event/frame, snapshot/Error, preparation/control, cleanup
  and lifecycle variants are faithful. UNEXECUTED is not an attempt; source
  status/outcome is not the parser's sole verdict. Event reservations and retained
  events are distinct, and current=null teardown actions do not have a stage key.
  The eight-cause intentional-failure classifier and row-20 independence are
  retained rather than changed into a blanket failure waiver.
- Exact caps remain 32 events/128 KiB per row, 128 events/512 KiB per invocation,
  64 frames plus sentinel and 512 identity tokens. Counter-only admission and
  metadata/chat preflight are reflected accurately. Global stopped state gates
  event reservation, not every later append. Allocation/time fields describe
  only the source's measured prefix, not whole observer cost or MSPT.
- JSON depth64, nodes65536 and collection/string defensive limits are proposed
  driver limits, not observed counts or expanded source budgets. Their complete
  serializer-domain derivation and mutation reruns remain open as the proposal
  states. Ordinary preparation/actions/teardown are finite in source; no current
  evidence justifies widening a failed bound.
- Console identity, permission, owning thread, player absence, exact actor/list/
  connection validation, partial-acquisition ownership and finally release are
  represented correctly. The marker protects Trace/Fixture construction through
  the withInvocation action; the source's marker set itself precedes its try.
  It should not be described as literally set inside the try body.
- The proposed one-process/two-invocation scope is not restart or retry. The
  630 s native waits, 1115 s success total and 1145 s conservative forced-stop
  total add correctly. Stage/global deadlines, no TCP status phase, no invocation
  retry, at most two flushes/one stop and exact process ownership are preserved.
  Current scope provides no forced-exit permission; that remains later assignment.
- Loaded Spawn restoration occurs before native remove/logout. Typed saved
  playerdata therefore describes restored teardown state, not each row's bed
  effects. Fresh absent Spawn defaults, possible null/non-default loss,
  invocation-2 reacquisition and no manual NBT loading remain separately labeled.
- Listener/actor/channel/cell/world cleanup attempts remain independent despite
  another failure. Cleanup flags/getters and a second invocation are not exhaustive
  heap/listener/receiver-release proof. External cleanup is a different authority
  domain, with one native literal-path attempt, reparse/containment checks and
  no peer/source/cache/world/sealed-evidence deletion authority.

## Fixed input and seal identities

Task16 is 3239 bytes, SHA-256
b937f2feea9d1d19efb8b616232f265f8eafbcb2c7cebbd0c126e07b1656169f.
Source base is b9bec789978de0df67c93e976239d6d36e41532b; governance/owner record
is 48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514.

All assigned final identities were verified against actual leaves. No draft
REPORT or mutable build path was substituted for a sealed input.

| Final input | Actual SHA-256 | Manifest entries verified |
|---|---|---:|
| Task15 REPORT | d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277 | |
| Task15 PROPOSED-DRIVER-02 | 628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec | |
| Task15 SHA256SUMS | 6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760 | 148 |
| Task11 REPORT | 0c82a4097db51bb98e1f45d819126ba87f1d7946c7b0d15157136f50fa19eebb | |
| Task11 SHA256SUMS | 8f6a602a85fb91ab194068ee119ac3e72b170d95c06701aba38da56b1dd175f1 | 835 |
| Task12 REPORT | dadc06c556466d0f353fe96db68327208da5e40b89de883fb1eb6faa08d5cb31 | |
| Task12 SHA256SUMS | 542d90ea3197a1a3615ebf5b1a16048fea0a0c14dcdcdc6704904756c307c0f6 | 895 |

Receipt [20-seals.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/commands/20-seals.json)
and its raw stdout retain actual manifest hashes and every-entry verification
counts. Source SHA-256 values are
1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 (Fixture) and
39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0 (Trace).

Installed javap is 23696 bytes, SHA-256
69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d.
The mapped primary Forge JAR is 19355242 bytes, SHA-256
95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e.
These are static-inspection identities, not a new packaged launch qualification.
[INPUTS.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/INPUTS.json)
records actual lengths/hashes. No large JAR/source/world/export is copied here.

## Later qualification inputs: useful evidence, not this reviewer's reruns

The complete final Task11 and Task12 reports were read through their final
sections. Both independently executed short fixed-source regressions, reporting
2192 JUnit cases in each build/explicit-test cohort and 588 required standard
GameTests. Those nine sleep guard/bound GameTests do not execute the twenty-row
observation command. Both strict validators reached their unchanged 180 s
TIMEOUT; native logs retain 62 ERROR headers/zero FATAL. Task12 additionally
retains a policy-denied cleanup attempt. These limits remain open, not waived.

Task15's original artifact qualification prerequisite is now partially supported
by these actual later inputs: published/API-only independent consumer and
reobfuscation receipts exist for the exact corrected source. This reviewer also
rehashes the four actual retained Task12 JARs and statically checks ZIP CRC,
unique entry names and class placement. Results match both reports:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Runtime | 6073913 | 0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011 |
| API | 51052 | aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b |
| Sources | 2892005 | 7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a |
| Reobfuscated fixture | 191702 | 93194a0bb197b5051174d66f2f4ddcd58649fc0764d83b5da3ac0ab7aca600aa |

The host/API/sources have no adapter classes. The fixture has all ten actual
SleepBoundary class files among 55 adapter classes, no foreign class payload or
jarjar. All four ZIP CRC checks have no bad entry and names are unique. See
[ARTIFACT-STATIC-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/ARTIFACT-STATIC-AUDIT.json).
The already sealed consumer classpath/negative-import/fixture receipts and
original build/consumer recipe were read. No consumer check or test is rerun here.

This does not make those build paths the future runtime's frozen inputs. A later
manifest must bind chosen artifact bytes, actual native libraries/arg files/JDK,
configuration and driver/parser/helper publication, with no drift. Neither
qualification executed a packaged twenty-case observation, native Spawn parsing,
driver/parser or mutation tests. Task12 retention does not confer deletion or
process ownership on Task16 or Root.

## Actual checks, failure preservation and capture limits

Only read-only Git/file/hash/ZIP/JSON inspection, installed public javap static
text inspection and Python -B compact evidence helpers were executed. All
captured subprocesses have actual immediate pre-start UTC, argv/cwd, exit code,
duration, 180 s ceiling and separate raw stdout/stderr bytes/hashes under
commands/. The inventory before its own receipt counts 42 completed captured
commands, all child exits 0, longest 1.332 s; subsequent own final inspections
are separately retained. This is a command count, not a tested-case count.
See [COMMAND-SUMMARY.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-independent-20261009-16/COMMAND-SUMMARY.json).

Material check families: fixed governance/status/ADR-060; complete fixed Fixture/
Trace/build/AdapterTestMod/consumer recipe; original source assignment and actual
owner record; complete sealed proposal/reports; all-entry seals; historical
packaged launcher/driver/cleanup and current primary CapturedProcess source as
text; actual artifact CRC/hash/class placement; public PrintStream and native
StringTag/CompoundTag/NbtIo bytecode; own input/raw-stream inventories.

Preparation/capture failures are preserved without invented receipts:

- Initial Task16/mandatory-document/discovery reads preceded the capture helper.
  They are transcript-only. The guessed lowercase docs/versions/v1.8.0.md was
  absent; the actual uppercase v1.8 version and complete fixed governance were
  read subsequently. No missing UTC or raw stream is reconstructed.
- Initial helper attempts 01-state, 03-diff and 04-proposal-seals were rejected by
  its argparse handling of dashed child options before capture. No corresponding
  child receipt exists; actual tool errors remain transcript-only. The evidence
  helper was corrected and distinct later commands 18/19/20 completed.
- The outer helper printing command25 encountered a UnicodeEncodeError after it
  had already retained its child's actual exit-0 receipt and raw streams. Earlier
  nested inspection displays used ambient encoding; their raw bytes remain.
  After explicitly setting only the evidence helper's stdout/stderr to UTF-8,
  complete reports were reread in command26 and task/proposal/report in command42.
  This is an inspection-helper failure, not evidence of the future Java charset.
- Some combined tool displays exceeded their display budget. Complete captured
  raw bytes remain, and focused source/schema/report/governance reads followed.
  Direct viewing and apply_patch/collaboration records are session records,
  not fabricated subprocess receipts.

No command exceeded 180 s. No Gradle, javac/compile, unit/GameTest, executable
driver/parser/test, native server/client/world/network, installation, cleanup,
process termination, commit/push or source mutation ran under Task16. Current
version general regression commands are **UNEXECUTED BY TASK16**, not PASS or
NOT_APPLICABLE. The installed javap inspected bytecode as text only; no game
method, reflection entry point or historical helper was invoked/imported.

## Ownership, authority and remaining work

Exclusive writes are only this Task16 external leaf: REPORT.md, compact evidence
helpers, raw-command receipts, input/command/artifact inventories and the later
explicitly acknowledged one-time leaf-relative seal. No worktree was created or
moved; no Main/source/build/status/ledger/index/HEAD/peer/original seal was edited,
staged, committed, deleted or taken over. Existing user-owned AGENTS modification
and untracked archives/docs were observed and left alone. No delegation or
OpenPet emission was performed; Root owns progress coordination. No Main/source/
peer HEAD/index/process interest is retained.

Mandatory AGENTS/governance, active v1.8/post-v1.0/parallel rules, earliest
incomplete v1.0/status/Gates and ADR-060 were read. Active v1.8 development remains
distinct from inherited release acceptance. The fixed actual owner reply is
"接受原生维度行为，按上述范围冻结并审核。" Its conditions and no-Earth-night-skip/
no-existing-spawn-change scope match the proposal. It does not authorize this
driver or resolve M1/M2/B1/R1/D1 qualification, production sleep/enforcement,
respawn/migration, asset/item/ledger acceptance or G0-G9.

Completed scope: independent fixed-source/proposal review; actual input seals;
static artifact byte/class checks; primary public-bytecode inspection; findings,
raw receipts and this report. Key design decisions remain separated execution,
capture, intervention, native effects, cleanup, save and acceptance domains,
without native result prefill or borrowing tests as reruns. No tests were added
or changed. Save/network/schema/API/provenance policy is unchanged.

Uncompleted scope: R01/R02 disposition and R03 typed-wire freeze; exact component
JSON union/depth/node bound proof; actual stdout route/encoding/wrapper and
SpawnDimension/default codec proof for chosen libraries; committed driver/parser/
helpers/tests and independent offline mutation reruns; a separate finite runtime/
forced-exit/cleanup assignment; any actual twenty-case/two-invocation/typed-save
observation; broader sleep/player/client/receiver/cause/air/station/dimension/
restart/death/previous-world/coexistence/JIT/GPU/multiplayer/performance acceptance.
Strict/log/retention limits in the earlier qualification reports remain open.

**All current/inherited Required Gates satisfied: no.** This static review is not
approval, executable freeze or issue closure. Within v1.8, resolve/freeze the named
wire/resource/serializer prerequisites, then separately assign implementation,
independent executable/offline review and only later bounded runtime execution.
No native outcome or wider sleep-policy verdict is implied.

Root must read this complete persisted report before the one-time seal. Final
actual REPORT/manifest hashes are communicated only after that acknowledgement;
the manifest covers own leaf-relative evidence, never itself or mutable external
build/Temp paths.
