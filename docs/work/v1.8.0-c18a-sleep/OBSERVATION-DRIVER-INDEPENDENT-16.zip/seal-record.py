import datetime
import hashlib
import json
import os
import pathlib
import sys
import time

root = pathlib.Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS.txt'
result_path = root / 'SEAL-RESULT.json'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic()
if manifest.exists() or result_path.exists():
    raise ValueError('One-time seal already exists')
excluded = {'SHA256SUMS.txt', 'SEAL-RESULT.json'}
lines = []
total = 0
for p in sorted(root.rglob('*')):
    if p.is_symlink() or p.is_junction():
        raise ValueError('Linked evidence member')
    if p.is_file() and p.name not in excluded and not p.name.startswith('52-seal.'):
        relative = p.relative_to(root).as_posix()
        raw = p.read_bytes()
        if len(raw) > 50 * 1024 * 1024:
            raise ValueError('Oversized evidence file')
        total += len(raw)
        lines.append(hashlib.sha256(raw).hexdigest() + '  ' + relative)
if total > 100 * 1024 * 1024:
    raise ValueError('Oversized evidence leaf')
with manifest.open('x', encoding='utf-8', newline='\n') as output:
    output.write('\n'.join(lines) + '\n')
record = {'started_utc': started, 'argv': sys.orig_argv, 'cwd': os.getcwd(), 'exit_code': 0, 'duration_seconds': time.monotonic() - begin, 'report_path': str(root / 'REPORT.md'), 'report_sha256': hashlib.sha256((root / 'REPORT.md').read_bytes()).hexdigest(), 'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'covered_files': len(lines), 'covered_bytes': total, 'postseal_result_outside_manifest': True, 'postseal_52_capture_outside_manifest': True}
result_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
