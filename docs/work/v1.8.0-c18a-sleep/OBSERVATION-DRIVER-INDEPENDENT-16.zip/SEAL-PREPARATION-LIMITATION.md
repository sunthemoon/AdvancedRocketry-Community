# Seal preparation limitation

After Root's complete read, one apply_patch request updating seal coverage/helper
was rejected as an invalid multi-file hunk. No file changed and no seal command
executed from that rejected request. The actual tool error is transcript-only;
no subprocess receipt or missing UTC is reconstructed. A separate valid patch
then added the explicit post-seal 52-seal capture exclusions. REPORT.md remains
byte-identical to Root's complete-read identity.
