import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')

def capture(name, argv):
    pre = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    record = {'argv': argv, 'cwd': str(REPO), 'pre_start_utc': pre, 'timeout_seconds': 180}
    try:
        result = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=180)
        stdout, stderr = result.stdout, result.stderr
        record['exit_code'] = result.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr = exc.stdout or b'', exc.stderr or b''
        record['exit_code'] = None
        record['failure'] = 'TimeoutExpired'
    record['duration_seconds'] = time.monotonic() - start
    directory = ROOT / 'commands'
    directory.mkdir(exist_ok=True)
    for suffix, data in [('stdout', stdout), ('stderr', stderr)]:
        output = directory / (name + '.' + suffix + '.txt')
        output.write_bytes(data)
        record[suffix] = {'file': output.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    (directory / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(stdout.decode('utf-8', errors='replace'), end='')
    print(stderr.decode('utf-8', errors='replace'), end='')

def inspect(paths):
    for path in paths:
        p = pathlib.Path(path)
        data = p.read_bytes()
        print('###', str(p), 'bytes', len(data), 'sha256', hashlib.sha256(data).hexdigest())
        for index, line in enumerate(data.decode('utf-8-sig').splitlines(), 1):
            print(str(index) + ': ' + line)

def seals(leaves):
    for leaf in leaves:
        directory = pathlib.Path(leaf)
        manifest = directory / 'SHA256SUMS.txt'
        print('MANIFEST', str(manifest), hashlib.sha256(manifest.read_bytes()).hexdigest())
        count = 0
        for line in manifest.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip():
                continue
            digest, relative = line.split(None, 1)
            relative = relative.lstrip('* ')
            target = (directory / relative).resolve()
            if not target.is_relative_to(directory.resolve()):
                raise ValueError('Manifest escapes leaf: ' + relative)
            actual = hashlib.sha256(target.read_bytes()).hexdigest()
            if actual != digest.lower():
                raise ValueError('Mismatch: ' + relative)
            count += 1
        print('VERIFIED', count, 'entries')
        for name in ['REPORT.md', 'PROPOSED-DRIVER-02.md']:
            p = directory / name
            if p.exists():
                print(name, len(p.read_bytes()), hashlib.sha256(p.read_bytes()).hexdigest())

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=['capture', 'inspect', 'seals'])
    p.add_argument('args', nargs=argparse.REMAINDER)
    a = p.parse_args()
    if a.action == 'capture':
        capture(a.args[0], a.args[1:])
    elif a.action == 'inspect':
        inspect(a.args)
    else:
        seals(a.args)
