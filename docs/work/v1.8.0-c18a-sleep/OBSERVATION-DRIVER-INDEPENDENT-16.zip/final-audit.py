import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
if (root / 'SHA256SUMS.txt').exists():
    raise ValueError('Final audit must precede one-time seal')
expected_report = '7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3'
if hashlib.sha256((root / 'REPORT.md').read_bytes()).hexdigest() != expected_report:
    raise ValueError('Report differs from Root complete-read identity')
commands = []
for path in sorted((root / 'commands').glob('*.json')):
    record = json.loads(path.read_text(encoding='utf-8'))
    if not record['pre_start_utc'] or not record['argv'] or not record['cwd'] or record['duration_seconds'] > 180:
        raise ValueError('Invalid execution receipt')
    for stream in ['stdout', 'stderr']:
        info = record[stream]
        data = (path.parent / info['file']).read_bytes()
        if len(data) != info['bytes'] or hashlib.sha256(data).hexdigest() != info['sha256']:
            raise ValueError('Raw stream drift: ' + str(path))
    commands.append({'receipt': path.name, 'exit_code': record['exit_code'], 'duration_seconds': record['duration_seconds']})
files = []
for path in sorted(root.rglob('*')):
    if path.is_symlink() or path.is_junction():
        raise ValueError('Linked evidence member')
    if path.is_file():
        raw = path.read_bytes()
        files.append({'path': path.relative_to(root).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
result = {'report_sha256': expected_report, 'command_count_before_own_receipt': len(commands), 'commands': commands, 'files_before_own_output': files, 'bytes_before_own_output': sum(f['bytes'] for f in files), 'maximum_file_bytes': max(f['bytes'] for f in files), 'all_captured_child_exits_zero': all(c['exit_code'] == 0 for c in commands), 'capture_limitations_preserved_in_report': True, 'source_runtime_permission': False}
(root / 'FINAL-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k not in ['commands', 'files_before_own_output']}, indent=2))
