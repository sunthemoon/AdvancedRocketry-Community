# One-time seal coverage

After Root reads REPORT.md completely and acknowledges sealing, SHA256SUMS.txt
will cover regular own-leaf evidence files by safe relative name. It will not
cover itself, post-seal SEAL-RESULT.json or commands/52-seal.*. No mutable external artifact/build/
Temp path is a manifest entry. Input identities are static records, not copies
of the artifacts or permission to remove them.

seal-record.py refuses an existing manifest and records its actual execution
UTC, argv, cwd, report digest, manifest digest, count and bytes. The separate
52-seal capture receipt records actual pre-start UTC/argv/cwd/exit/raw streams;
it necessarily completes after the manifest and stays outside that manifest.
The coordinating acknowledgement remains a session source recorded faithfully
in ROOT-PRESEAL-ACKNOWLEDGEMENT.md. SEAL-RESULT.json is outside manifest coverage
to avoid a cyclic hash. Any correction requires a separate
new record; sealed covered bytes are not changed.
