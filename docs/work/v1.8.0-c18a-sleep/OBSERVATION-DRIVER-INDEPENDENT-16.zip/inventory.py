import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
paths = [
    pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OBSERVATION-DRIVER-CONTRACT-REVIEW-TASK-16.md'),
    root / 'commands/21-fixture.stdout.txt',
    root / 'commands/22-trace.stdout.txt',
    pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'),
    pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'),
]
files = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
inputs = {'source': '5b45132000ade1e3c8d130a6b8ccb29f07535124', 'base': 'b9bec789978de0df67c93e976239d6d36e41532b', 'governance': '48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514', 'scope': 'static independent review; no runtime or tests', 'files': files}
(root / 'INPUTS.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8')
commands = []
for path in sorted((root / 'commands').glob('*.json')):
    record = json.loads(path.read_text(encoding='utf-8'))
    for stream in ['stdout', 'stderr']:
        info = record[stream]
        raw = (path.parent / info['file']).read_bytes()
        if len(raw) != info['bytes'] or hashlib.sha256(raw).hexdigest() != info['sha256']:
            raise ValueError('Raw stream drift: ' + str(path))
    commands.append({'receipt': str(path.relative_to(root)), 'argv': record['argv'], 'pre_start_utc': record['pre_start_utc'], 'exit_code': record['exit_code'], 'duration_seconds': record['duration_seconds']})
(root / 'COMMAND-SUMMARY.json').write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'inputs': inputs, 'completed_command_count': len(commands), 'max_duration_seconds': max(c['duration_seconds'] for c in commands), 'nonzero_commands': [c for c in commands if c['exit_code'] != 0]}, indent=2))
