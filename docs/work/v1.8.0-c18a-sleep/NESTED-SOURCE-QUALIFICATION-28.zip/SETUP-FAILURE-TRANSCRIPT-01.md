# Transcript-only preparation failure 01

The exploratory PowerShell environment/global-input read in exec chunk
`dee410` exited 1 before its body executed. It attempted to pipe a `foreach`
statement into `ConvertTo-Json`. Raw tool output:

```text
ParserError:
Line |
   2 |  ... {name=$n;value=[Environment]::GetEnvironmentVariable($n)} } | Convert ...
     |                                                                ~
     | An empty pipe element is not allowed.
```

No source, process or cleanup operation ran. This read was transcript-only;
no missing absolute UTC or separate stdout/stderr receipt is reconstructed.
The separately instrumented `environment-global-01` command obtains environment
controls but exits 1 on assigning the read-only PowerShell HOME variable.
`environment-global-corrected-02` independently reads absent global Gradle
configuration/init inputs. Both captured records remain unchanged.

Some initial exploratory displays were truncated; focused reads and retained
fixed governance/source/report inputs followed. Preparation is not claimed to
be a fully instrumented transcript of every exploratory read. Sustained task
commands have separate complete command receipts.
