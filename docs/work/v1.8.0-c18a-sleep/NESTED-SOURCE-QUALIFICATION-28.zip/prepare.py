"""Fixed Task28 source/governance/sealed-input inventory, no observation execution."""
import hashlib
import json
from pathlib import Path
import subprocess
from capture import LEAF, SOURCE, HEAD, TREE, JDK, sha, state, utc

GOV = '6d1b796e0e93b9953af505dd3fd9b25d47b91d97'
def output(name, argv):
    p = subprocess.run(argv, capture_output=True, cwd=SOURCE)
    (LEAF/name).write_bytes(p.stdout)
    if p.returncode or p.stderr:
        (LEAF/(name+'.stderr.txt')).write_bytes(p.stderr)
    if p.returncode:
        raise RuntimeError((argv, p.returncode))
    return {'argv': argv, 'exit': p.returncode, 'bytes': len(p.stdout), 'sha256': sha(LEAF/name)}

records = {'utc': utc(), 'source': HEAD, 'src_tree': TREE, 'governance': GOV, 'read_inputs': [], 'governance_inputs': []}
docs = ['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md',
        'docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
        'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
        'docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
        'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md','docs/status/CURRENT_VERSION.md',
        'docs/status/GATE_STATUS.md','docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
        'docs/releases/v1.7.0/RELEASE-EVIDENCE.md']
for i, doc in enumerate(docs):
    record = output('governance-%02d.txt'%i, ['git','show',GOV+':'+doc])
    record['path'] = doc
    records['governance_inputs'].append(record)
for leaf in ['sleep-observation-nested-boundary-20261009-19','sleep-observation-nested-boundary-independent-20261009-21']:
    root = LEAF.parent/leaf
    manifest = root/'SHA256SUMS.txt'
    members = []
    for line in manifest.read_text(encoding='utf-8-sig').splitlines():
        digest, rel = line.split(None,1)
        rel = rel.lstrip('*')
        file = (root/rel).resolve()
        if not file.is_relative_to(root.resolve()) or sha(file) != digest:
            raise RuntimeError('Input seal failed: '+str(file))
        members.append({'path':rel, 'bytes':file.stat().st_size, 'sha256':digest})
    records['read_inputs'].append({'leaf':str(root), 'report_bytes':(root/'REPORT.md').stat().st_size,
        'report_sha256':sha(root/'REPORT.md'), 'manifest_sha256':sha(manifest), 'verified_members':len(members)})
    (LEAF/(leaf+'-manifest.txt')).write_bytes(manifest.read_bytes())
    (LEAF/(leaf+'-REPORT.md')).write_bytes((root/'REPORT.md').read_bytes())
    if leaf.endswith('-21'):
        assert sha(root/'REPORT.md') == 'a7b68817e1b0167536d5681069d450724a624e5ea0ecb258a71fc1eb2cc2353a'
        assert sha(manifest) == '9c4131dbdbfcf34e53583639172e65bd945b17f462fca808dd7acd469ef8d00d'
records['diff'] = output('source-base-to-final.diff', ['git','diff','5b45132000ade1e3c8d130a6b8ccb29f07535124',HEAD,'--','src'])
records['scope'] = output('source-scope.txt', ['git','diff','--stat','5b45132000ade1e3c8d130a6b8ccb29f07535124',HEAD])
records['identity'] = state()
for name in ['SleepBoundaryTrace','SleepBoundaryChatBounds','SleepBoundaryObservationFixture']:
    output(name+'.source.txt', ['git','show',HEAD+':src/adapterTest/java/io/github/sunthemoon/arceadaptertest/'+name+'.java'])
records['java'] = output('java-version.txt', [str(JDK/'bin/java.exe'),'-XshowSettings:properties','-version'])
records['tool_hashes'] = {str(JDK/'bin'/n):sha(JDK/'bin'/n) for n in ['java.exe','javac.exe','javap.exe']}
assert records['identity']['head']['stdout'].strip() == HEAD
assert records['identity']['src_tree']['stdout'].strip() == TREE
assert not records['identity']['status']['stdout']
(LEAF/'FIXED-INPUT-IDENTITIES.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(json.dumps(records['read_inputs'],indent=2))
print(json.dumps(records['identity']['disk_free']))
