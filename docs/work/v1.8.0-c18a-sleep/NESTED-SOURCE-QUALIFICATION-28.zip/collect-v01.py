"""Compact standard Gradle/JUnit/native-log identities for Task28 commands."""
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET
from capture import LEAF, SOURCE, sha, utc

cohort = sys.argv[1]
dest = LEAF/(cohort+'-results')
dest.mkdir()
result = {'utc':utc(), 'cohort':cohort, 'junit':None, 'copied':[], 'artifacts':[], 'native_log_inventory':[]}
def copy(file, root):
    rel = file.relative_to(root)
    target = dest/rel
    if file.stat().st_size > 50*1024**2:
        raise RuntimeError('Oversized evidence '+str(file))
    total = sum(x.stat().st_size for x in LEAF.rglob('*') if x.is_file())
    if total + file.stat().st_size > 100*1024**2:
        raise RuntimeError('Evidence total above 100 MiB')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(file, target)
    result['copied'].append({'source':str(file), 'evidence':str(target.relative_to(LEAF)),
                             'bytes':file.stat().st_size,'sha256':sha(file)})
if cohort in ['build-01','test-01']:
    junit = SOURCE/'build/test-results/test'
    counts = {'xml_files':0, 'tests':0,'failures':0,'errors':0,'skipped':0,'actual_testcases':0}
    suites = []
    for file in sorted(junit.glob('TEST-*.xml')):
        root = ET.parse(file).getroot()
        counts['xml_files'] += 1
        for field in ['tests','failures','errors','skipped']:
            counts[field] += int(root.attrib.get(field,'0'))
        cases = root.findall('testcase')
        counts['actual_testcases'] += len(cases)
        suites.append({'file':file.name,'name':root.attrib.get('name'), 'counts':root.attrib,
                       'cases':[{'name':c.attrib.get('name'), 'classname':c.attrib.get('classname'),
                                 'failure':c.find('failure') is not None, 'error':c.find('error') is not None,
                                 'skipped':c.find('skipped') is not None} for c in cases]})
        copy(file, SOURCE)
    result['junit'] = {'counts':counts,'suites':suites}
if cohort == 'native-01':
    native = SOURCE/'build/gametest'
    for file in sorted(native.rglob('*')):
        if file.is_file() and (file.suffix in ['.log','.xml'] or file.name in ['latest.log','debug.log']):
            copy(file,SOURCE)
            if file.suffix == '.log':
                lines = file.read_text(encoding='utf-8',errors='replace').splitlines()
                errors = [dict(line=i+1,text=x) for i,x in enumerate(lines) if '/ERROR]' in x or '/FATAL]' in x]
                result['native_log_inventory'].append({'file':str(file),'error_headers':sum('/ERROR]' in x for x in lines),
                    'fatal_headers':sum('/FATAL]' in x for x in lines),'headers':errors})
if cohort == 'compat-01':
    for file in sorted((SOURCE/'compat-test-mod/build/reports/consumer').glob('*.json')):
        copy(file,SOURCE)
    for file in sorted((SOURCE/'compat-test-mod/build/test-results').rglob('*.xml')):
        copy(file,SOURCE)
for parent in [SOURCE/'build/libs', SOURCE/'build/repo', SOURCE/'compat-test-mod/build/libs']:
    for file in sorted(parent.rglob('*')):
        if file.is_file():
            result['artifacts'].append({'path':str(file),'bytes':file.stat().st_size,'sha256':sha(file)})
for parent in [SOURCE/'build/classes/api',SOURCE/'build/classes/adapterTest']:
    for file in sorted(parent.rglob('*.class')):
        if 'adapterTest' not in str(parent) or file.name.startswith('SleepBoundary'):
            result['artifacts'].append({'path':str(file),'bytes':file.stat().st_size,'sha256':sha(file)})
out = LEAF/(cohort+'-COLLECTION.json')
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cohort':cohort,'junit':result['junit']['counts'] if result['junit'] else None,
                  'copied_files':len(result['copied']),'artifact_identities':len(result['artifacts']),
                  'native_logs':[{k:v for k,v in x.items() if k!='headers'} for x in result['native_log_inventory']]}))
