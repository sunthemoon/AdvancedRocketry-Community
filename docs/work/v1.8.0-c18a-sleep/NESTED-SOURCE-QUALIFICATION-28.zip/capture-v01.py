"""Task28 finite command receipts; not an observation/runtime driver."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

LEAF = Path(__file__).resolve().parent
SOURCE = Path(r'D:\GitHub\arce-v180-sleep-nested-qualification-20261009-28')
HEAD = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
TREE = '85f53265bf4ee59b65c4a88664cb2e5e208c583e'
JDK = Path(r'C:\Program Files\Java\jdk-17.0.7')
PWSH = r'C:\Program Files\WindowsApps\Microsoft.PowerShell_7.6.6.0_x64__8wekyb3d8bbwe\pwsh.exe'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest()

def git(*args):
    p = subprocess.run(['git', '-C', str(SOURCE), *args], capture_output=True)
    return {'argv': ['git', '-C', str(SOURCE), *args], 'exit': p.returncode,
            'stdout': p.stdout.decode('utf-8', 'replace'), 'stderr': p.stderr.decode('utf-8', 'replace')}

def state():
    files = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
             'gradle/wrapper/gradle-wrapper.properties', 'gradle/wrapper/gradle-wrapper.jar',
             'compat-test-mod/build.gradle', 'compat-test-mod/settings.gradle', 'compat-test-mod/gradle.properties']
    files += ['src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + n + '.java'
              for n in ['SleepBoundaryTrace', 'SleepBoundaryChatBounds', 'SleepBoundaryObservationFixture']]
    ps = '$ErrorActionPreference="Stop"; [pscustomobject]@{memory=(Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory); processes=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -match "java|gradle|minecraft"} | Select-Object ProcessId,ParentProcessId,Name,CommandLine)} | ConvertTo-Json -Depth 5'
    inv = subprocess.run([PWSH, '-NoProfile', '-Command', ps], capture_output=True)
    index = git('ls-files', '--stage')
    return {'utc': utc(), 'head': git('rev-parse', 'HEAD'), 'src_tree': git('rev-parse', 'HEAD:src'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all'),
            'tracked_diff': git('diff', '--exit-code'), 'index_diff': git('diff', '--cached', '--exit-code'),
            'src_diff': git('diff', '--exit-code', '--', 'src'),
            'index_sha256': hashlib.sha256(index['stdout'].encode()).hexdigest(),
            'inputs': {f: {'bytes': (SOURCE/f).stat().st_size, 'sha256': sha(SOURCE/f)} for f in files},
            'disk_free': {d: shutil.disk_usage(d).free for d in ['C:\\', 'D:\\']},
            'native_inventory_exit': inv.returncode, 'native_inventory_stdout': inv.stdout.decode('utf-8', 'replace'),
            'native_inventory_stderr': inv.stderr.decode('utf-8', 'replace')}

def run(name, timeout, cwd, argv):
    receipt = LEAF / (name + '.command.json')
    if receipt.exists():
        raise RuntimeError('No receipt overwrite or silent retry: ' + name)
    before = state()
    if before['head']['stdout'].strip() != HEAD or before['src_tree']['stdout'].strip() != TREE:
        raise RuntimeError('Fixed source mismatch')
    if any(before[k]['exit'] or before[k]['stdout'] for k in ['tracked_diff', 'index_diff', 'src_diff']):
        raise RuntimeError('Tracked/index/source state is not clean')
    if any(n < 10*1024**3 for n in before['disk_free'].values()):
        raise RuntimeError('Disk below 10 GiB')
    env = os.environ.copy()
    controls = ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'GRADLE_OPTS', 'CLASSPATH']
    inherited = {k: env.get(k) for k in controls}
    if any(inherited.values()):
        raise RuntimeError('Unexpected inherited JVM injection: ' + repr(inherited))
    scratch = LEAF/'scratch'/name
    scratch.mkdir()
    env['JAVA_HOME'] = str(JDK)
    env['PATH'] = str(JDK/'bin') + os.pathsep + env['PATH']
    env['TEMP'] = env['TMP'] = str(scratch)
    env['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir="' + str(scratch) + '"'
    record = {'name': name, 'fixed_source': HEAD, 'fixed_src_tree': TREE, 'prestart_utc': utc(),
              'argv': argv, 'cwd': cwd, 'timeout_seconds': timeout, 'inherited_jvm_controls': inherited,
              'child_environment': {k: env.get(k) for k in ['JAVA_HOME','PATH','TEMP','TMP', *controls, 'GRADLE_USER_HOME']},
              'helper_sha256': sha(__file__), 'task_sha256': sha(LEAF/'TASK-28.md'), 'before': before}
    started = time.monotonic()
    record['start_utc'] = utc()
    timed_out = False
    with open(LEAF/(name+'.stdout.txt'), 'xb') as out, open(LEAF/(name+'.stderr.txt'), 'xb') as err:
        try:
            proc = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
            record['pid'] = proc.pid
            receipt.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
            try:
                code = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                kill = subprocess.run([r'C:\Windows\System32\taskkill.exe','/PID',str(proc.pid),'/T','/F'], capture_output=True)
                record['owned_timeout_termination'] = {'argv': kill.args, 'exit': kill.returncode,
                                                      'stdout': kill.stdout.decode('utf-8','replace'),
                                                      'stderr': kill.stderr.decode('utf-8','replace')}
                code = proc.wait(timeout=60)
        except Exception as exc:
            record['launch_error'] = repr(exc)
            code = None
    record.update({'end_utc': utc(), 'elapsed_seconds': time.monotonic()-started,
                   'exit_code': code, 'timed_out': timed_out, 'after': state()})
    record['streams'] = {suffix: {'bytes': (LEAF/(name+'.'+suffix+'.txt')).stat().st_size,
                                  'sha256': sha(LEAF/(name+'.'+suffix+'.txt'))} for suffix in ['stdout','stderr']}
    receipt.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'name': name,'exit_code':code,'timed_out':timed_out,'elapsed_seconds':record['elapsed_seconds'],
                      'receipt':str(receipt)}), flush=True)
    return code if code is not None and not timed_out else 124

if __name__ == '__main__':
    sys.exit(run(sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4:]))
