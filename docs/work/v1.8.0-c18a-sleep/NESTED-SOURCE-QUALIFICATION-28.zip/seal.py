"""One-time leaf-relative Task28 seal after Root's full-report read acknowledgement."""
import json
from pathlib import Path
import sys
from capture import LEAF, sha, utc

EXCLUDED = {
    'SHA256SUMS.txt','SEAL-RESULT.json','SEAL-VERIFY-RESULT.json',
    'seal-01.command.json','seal-01.stdout.txt','seal-01.stderr.txt',
    'seal-verify-01.command.json','seal-verify-01.stdout.txt','seal-verify-01.stderr.txt'
}
def members():
    found = []
    seen = set()
    for file in sorted(LEAF.rglob('*')):
        stat = file.lstat()
        if file.is_symlink() or getattr(stat,'st_file_attributes',0) & 1024:
            raise RuntimeError('Reparse member: '+str(file))
        if not file.is_file():
            continue
        rel = file.relative_to(LEAF).as_posix()
        if rel in EXCLUDED or rel.startswith('scratch/'):
            continue
        if not file.resolve().is_relative_to(LEAF.resolve()) or rel.casefold() in seen:
            raise RuntimeError('Unsafe/case-duplicate seal member: '+rel)
        seen.add(rel.casefold())
        if stat.st_size > 50*1024**2:
            raise RuntimeError('Single evidence file above 50 MiB')
        found.append((rel,stat.st_size,sha(file)))
    if sum(n for _,n,_ in found) > 100*1024**2:
        raise RuntimeError('Evidence above 100 MiB')
    return found

manifest = LEAF/'SHA256SUMS.txt'
if sys.argv[1] == 'seal':
    if manifest.exists():
        raise RuntimeError('One-time seal already exists')
    ack = json.loads((LEAF/'ROOT-READ-ACK.json').read_text(encoding='utf-8'))
    if not ack.get('complete_report_read') or ack['report_sha256'] != sha(LEAF/'REPORT.md'):
        raise RuntimeError('Root complete-read/report-identity acknowledgement missing')
    files = members()
    with manifest.open('x',encoding='utf-8',newline='\n') as stream:
        for rel,_,digest in files:
            stream.write(digest+'  '+rel+'\n')
    result = {'utc':utc(),'covered_files':len(files),'covered_bytes':sum(n for _,n,_ in files),
              'manifest_sha256':sha(manifest),'report_sha256':sha(LEAF/'REPORT.md'),
              'excluded':sorted(EXCLUDED),'excluded_prefixes':['scratch/']}
    (LEAF/'SEAL-RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
elif sys.argv[1] == 'verify':
    files = members()
    parsed = []
    for line in manifest.read_text(encoding='utf-8').splitlines():
        digest,rel = line.split('  ',1)
        file = LEAF/rel
        if not file.resolve().is_relative_to(LEAF.resolve()) or sha(file) != digest:
            raise RuntimeError('Seal mismatch: '+rel)
        parsed.append((rel,file.stat().st_size,digest))
    if parsed != files:
        raise RuntimeError('Seal coverage differs from retained members')
    result = {'utc':utc(),'verified_files':len(parsed),'verified_bytes':sum(n for _,n,_ in parsed),
              'manifest_sha256':sha(manifest),'report_sha256':sha(LEAF/'REPORT.md')}
    (LEAF/'SEAL-VERIFY-RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
else:
    raise RuntimeError('Expected seal or verify')
print(json.dumps(result,indent=2))
