# Final sleep nested-source qualification, Task28

Date: 2026-10-09 UTC. Delegated worker/tester, not Root. Fixed actual source:
`d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Disposition: finite development command cohort completed, with strict TIMEOUT,
unwaived native ERROR logs and preparation/observability limits retained.
No source integration, observation-driver execution or Required Gate approval.

## Findings first

1. **Strict validation remains failed/incomplete.** The assigned Python command
   reaches its unchanged 180-second ceiling. The owned Python target is terminated
   through its recorded PID/tree, yielding target exit 1 and `timed_out: true`;
   elapsed time including termination is 180.487 seconds. Raw stdout/stderr are
   empty. No link-report PASS or completed repository-validation result is inferred.
2. **Native log acceptance remains open.** The unfiltered GameTest command exits 0
   and reports all 594 required tests passed. Its stdout, latest.log and debug.log
   each have 62 ERROR headers and zero FATAL. These are duplicate views of one run,
   not 186 distinct errors. The inventory includes intentional fault-injection,
   failed chunk-save and project validation/operation diagnostics. They are retained
   individually and are not collectively called harmless, waived or accepted.
3. **Native per-test observability is limited.** Actual runtime discovery shows
   151 batches totaling 594 tests, including sleep_trace=11 and sleep_console=4.
   The fixed source/compiled inventory correlates the six new helper methods plus
   five unchanged Trace methods with the observed 11-test batch. The default run
   emits no native test XML or individual named PASS records. The complete suite
   result supports that batch result; a separate direct per-method result receipt
   is not fabricated. The registry-value case remains an owned Object probe at
   the shared admission helper, not a constructed EntityType subtype or injected
   registry value/key. Broader arbitrary-custom-state closure is unproved.
4. **Preparation timing and failures are explicit.** Initial preparation includes
   transcript-only/truncated reads. The first capture helper rejects the recorded
   JVM controls but omits JAVA_OPTS from that field; the broad prelaunch environment
   display contains no such variable. An instrumented supplementary JAVA_OPTS read
   confirms null, and global Gradle properties/init files are found absent, only
   after the first build has launched. This supplemental capture is not backdated
   as prelaunch proof. Later command cohorts include JAVA_OPTS in their rejection
   checks. A malformed publication property argument causes a separately preserved
   failed setup cohort; its quoted correction succeeds. Other preparation failures
   and their corrections are listed below. None changes source, assertions, caps,
   timeouts or cleanup policy.

No new material source/test defect was established in the scoped final correction.
The narrow executed suite result does not close the historical wire, driver,
gameplay, release or log-acceptance obligations.

## Fixed authority, source and read inputs

| Input | Fixed identity |
|---|---|
| Task28 | SHA256 `757c5753e9f591ed0ef6ed7b4a884dac7d7d7c546c78cc743d17dc89aa4ede46` |
| Source commit | `d57ecda1f11dab76d882f945b0de606534ef4fb9` |
| src tree | `85f53265bf4ee59b65c4a88664cb2e5e208c583e` |
| Governance checkpoint | Main `6d1b796e0e93b9953af505dd3fd9b25d47b91d97` |
| Cleanup clarification30 | SHA256 `b95f5b69e3aedff292a743101fad4a9893d2794e92ee3c73814bdf453bdc6ee1` |
| Author Task19 REPORT / manifest | `982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e` / `df8c9dd1dbc7d487663474c3326ba302178ca4348923539c5bbbf91a7ffbbe3a` |
| Independent Task21 REPORT / manifest | `a7b68817e1b0167536d5681069d450724a624e5ea0ecb258a71fc1eb2cc2353a` / `9c4131dbdbfcf34e53583639172e65bd945b17f462fca808dd7acd469ef8d00d` |

Both complete reports were read and all seal members actually verified: Task19
314 members, Task21 248 members. Task21's required report/manifest identities
match exactly. Task, clarification, report and manifest copies plus fixed read-input
hashes are kept in this leaf. No sealed input is edited or used as this run's result.

Mandatory project/product/principles/roadmap/active uppercase v1.8/test/release/
parallel/post-v1.0/quality documents were read. Their fixed governance objects,
AGENTS, CURRENT_VERSION, GATE_STATUS, ADR-060 and previous v1.7 release handoff
are retained as separate fixed-input captures. The earliest unfinished acceptance
cursor remains v1.0; ADR-060 permits scoped v1.8 development, not inherited or
current release acceptance. Root owns repository status/ledger/implementation
records; this external task report makes no central-record change.

## Ownership and completed scope

Fresh detached checkout:
`D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28`.
Exclusive evidence/scratch scope is this leaf. Initial exploration and Root's
assignment confirm the clean detached fixed HEAD and fresh generated-output
absence. Every instrumented command checks fixed HEAD/src tree, index/tracked/
source diffs, ten wrapper/build/consumer inputs, all three observation source
hashes, disk and native process/memory inventory before and after execution.
No tracked/index/source diff appears in those records. Separate DataGen and
post-cleanup Git commands are empty. Source checkout and fixed source remain.

Completed: actual-source change/test-inventory inspection; fixed governance and
sealed-input verification; clean build, separate forced JUnit test, twice forced
DataGen and independent source checks, unfiltered GameTest, corrected offline
local publication, offline independent compat build, strict timeout attempt,
diff check, compact result/artifact audits and one owned cleanup generation.

No tracked source/config/test/doc is modified. No Main index/HEAD operation,
commit, push, branch move, peer output adoption/deletion or delegation occurs.
Claude is not called. Root alone coordinates OpenPet. New files are compact task
evidence/capture/result/seal helpers in this external leaf; existing commands
write only their assigned/generated outputs. There is no new observation
driver/parser, packaged native launcher, real TCP/client, long-load/GPU/remote,
prior-world/restart/death or production dimension/spawn/time/air/policy/API/schema
operation. The twenty-row console command/property is never invoked/enabled.

## Actual source review and design assessment

The complete base-to-final source patch is two adapterTest files, 239 insertions
and 54 deletions. Production/API, ordinary unit tests, generated data, build,
central registration, provenance and status files have no source-change scope.
The new helper performs finite chat receiver admission; Trace delegates only
that preflight and retains byte reservation/native JSON/post-allocation bounds.
Fixture is unchanged. Exact ClickEvent, EntityTooltipInfo, ResourceLocation and
EntityType checks precede the inspected overridable getter/serializer/inverse-map
behavior. Limits and existing five Trace/four Fixture tests remain unchanged.
Historical 7a/0552 findings are not retroactively credited as final-source results.

| Source | Bytes / lines | SHA256 |
|---|---:|---|
| [SleepBoundaryTrace](D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java) | 27593 /445 | `20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f` |
| [SleepBoundaryChatBounds](D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java) | 15889 /238 | `16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0` |
| [SleepBoundaryObservationFixture](D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java) | 33987 /497 | `1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820` |

No new public/persistent ID, save/network schema, API surface or gameplay policy
is introduced. Project-original adapter admission/test code is inspected;
no upstream/fork code/art or official assets are imported and no license/provenance
record is removed. This is not a complete G0 license/provenance acceptance audit.

## Frozen execution environment and receipts

Child JAVA_HOME/PATH selects installed Oracle JDK 17.0.7+8-LTS-224, amd64,
`C:/Program Files/Java/jdk-17.0.7`, without changing the parent installation or
environment. The parent JAVA_HOME was a different JRE and is disclosed by the
initial read. Actual wrapper --version confirms Gradle 8.8; wrapper distribution
URL/checksum and build Forge input remain 1.20.1-47.4.10. Native logs/process
inventory confirm that mapped Forge/runtime identity. Installed java/javac/javap,
wrapper/build and source hashes are retained. No installation/version change.

Each child TEMP/TMP and java.io.tmpdir uses its own leaf scratch/cohort directory.
Only the disclosed JAVA_TOOL_OPTIONS temp property is injected. Other recorded
JVM controls are rejected if unexpectedly present. Global Gradle properties,
init.gradle/init.gradle.kts/init.d are absent in the supplementary timed read;
the timing limit in finding 4 is preserved. The native live-process snapshot
retains actual wrapper/daemon/server command lines, not a packaged/custom launcher.

All C/D pre/post free-space checks exceed 10 GiB. Across the completed pre-report
command catalog, minimum free bytes are C=30,489,055,232 and D=290,947,158,016.
Initial free physical memory is 21,215,384 KiB; per-command memory/native process
inventories are preserved. No pre-existing native Java process was found in the
initial preparation. No foreign process is terminated; only strict-01's owned
timed-out Python PID/tree is stopped.

Each command receipt preserves raw argv/cwd, prestart/start/end UTC, child PID,
exit/timeout, frozen child environment, fixed input hashes, pre/post source/index/
resource state and separate complete stdout/stderr sizes/hashes. The command
index catalogs 28 completed commands before its own preparation audit; that
audit and subsequent report/seal receipts are separately named. Initial
transcript-only failures/reads are not falsely added to this complete-receipt set.

## Commands actually executed

All successful Gradle cohorts use unchanged `--no-daemon --no-build-cache
--rerun-tasks`, with no filter, run-config change or opt-in observation property.
Their ceiling is 2400 seconds. UTC times below are on 2026-10-09; full fractions,
argv and state are in the linked command records.

| Cohort | Actual task / command | Start / end UTC | Result |
|---|---|---|---|
| [build-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/build-01.command.json) | gradlew.bat clean build | 07:16:09.979 /07:19:13.369 | Exit 0; 183.390 s |
| [test-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/test-01.command.json) | gradlew.bat test | 07:19:50.626 /07:22:55.516 | Exit 0; 184.890 s |
| [data-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/data-01.command.json) | gradlew.bat runData | 07:23:21.074 /07:24:07.327 | Exit 0; 46.253 s |
| [data-02](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/data-02.command.json) | second forced runData | 07:24:49.290 /07:25:33.636 | Exit 0; 44.347 s |
| [native-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/native-01.command.json) | unfiltered runGameTestServer | 07:25:53.995 /07:30:06.548 | Exit 0; 252.553 s; 594 required pass |
| [publish-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/publish-01.command.json) | publication setup with split property argv | 07:30:33.161 /07:30:42.492 | Exit 1; 9.331 s; unknown task; no publish task executes |
| [publish-corrected-02](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/publish-corrected-02.command.json) | publishMavenJavaPublicationToLocalProjectRepository -ParceVersion=1.20.1-1.8.0-dev --offline | 07:32:25.473 /07:33:06.291 | Exit 0; 40.818 s |
| [compat-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/compat-01.command.json) | compat-test-mod ../gradlew.bat clean build -ParceVersion=1.20.1-1.8.0-dev --offline | 07:33:35.180 /07:33:55.580 | Exit 0; 20.400 s; test NO-SOURCE |
| [strict-01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/strict-01.command.json) | Python -B scripts/validate_repository.py --require-approved-identity | 07:35:18.302 /07:38:18.789 | TIMEOUT at unchanged 180 s; target exit 1 after owned termination |

Separate `git diff --exit-code` and `git status --short` commands after **each**
DataGen run exit 0 with empty output. Separate `git diff --check` exits 0. Post-
cleanup corrected independent diff/status commands likewise exit 0, empty.
Native launch occurs only after preceding build/test/DataGen and source/disk/
memory checks permit it. No runtime result is substituted from Task19/21/11/12.
The setup correction changes quoting only; it is a new named cohort, not a silent
repeat or increased timeout. All Gradle/JVM/deprecation warnings remain raw.

## Actual tests and artifacts

| Executed JUnit command | XML files | Actual cases / tests | Failures / errors / skips |
|---|---:|---:|---:|
| clean build | 381 | 2192 /2192 | 0 /0 /0 |
| separate forced test | 381 | 2192 /2192 | 0 /0 /0 |

Each command's actual JUnit XML is copied separately before later reruns overwrite
the checkout result directory. No compile-only or optional Gradle task skip is
counted as a passed/omitted JUnit test. Publication/DataGen have no new JUnit
execution; compat's test task is NO-SOURCE. Native emits no XML; its actual
151 batch counts sum to 594 and its terminal required-test result is retained.

New helper method inventory correlated with the observed sleep_trace batch:

- `ordinaryNestedNativeReceiversRemainSerializable`: native click actions and
  entity hover metadata/nested name serialization.
- `unsupportedClickReceiversAreRefusedBeforeGetters`: counting/throwing getters
  across direct/sibling/translation/SHOW_TEXT/SHOW_ENTITY-name routes.
- `unsupportedEntityTooltipReceiversAreRefusedBeforeSerialization`: same routes,
  exact refusal and zero serializer/tooltip behavior counters.
- `ordinaryNativeResourceIdentifiersRemainSerializable`: native fonts and PIG key.
- `unsupportedFontReceiversAreRefusedBeforeIdentifierMethods`: same five routes
  plus shared identifier admission, with zero getter/string counters.
- `unsupportedRegistryValuesAreRefusedBeforeReceiverBehavior`: native PIG and
  owned Object hash/equals/toString probe at the shared exact-type helper; no
  EntityType subtype construction or native registry injection.

The five unchanged Trace and four unchanged Fixture guard methods remain in the
fixed inventory. sleep_trace=11 and sleep_console=4 are actual runtime discovery,
not counts inferred from compilation alone. There is no twenty-row console
observation, off-world sleep or actual connected-client result in this run.

Current artifact identities, retained as metadata rather than binary archives:

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Host JAR | 6073913 | `0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011` |
| Sources JAR | 2892005 | `7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a` |
| API JAR | 51052 | `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b` |
| Compat fixture JAR | 200725 | `d8bd853dd704069160c2124199b2482519adcbe2b16d94e821c50204177ee4b6` |
| Actual Forge-remapped consumer API | recorded in consumer classpath | `a04dbac3aa097869f9f47eb57c619acdc1d62925f6d8e489820c68796e7aee6e` |

Host/API/sources hashes match across build/test/native/publication inventories.
The host/API/sources JARs contain no SleepBoundary classes. The independent
fixture JAR contains the three observation classes and nested probes, confined
to its adapter namespace; no API/host/platform class shading or duplicate entry
is credited. API source/class/entry and actual consumer dependency/fixture source
hashes are preserved in collection/result JSON. The consumer resolves its raw
API from this task's own local publication, verifies its mapped classifier and
real platform-only classpath, and rejects the existing internal implementation
import. That negative compiler's exit 1 and two expected package/symbol errors
are retained; the surrounding boundary check and build exit 0. It is not an
additional JUnit or native runtime result.

## Retained failures and scope deviations

- A transcript-only exploratory PowerShell foreach-pipe parser error executes
  no body. Its raw error excerpt and missing-receipt/UTC limit are retained.
- The captured supplementary environment/global-input command exits 1 assigning
  PowerShell's read-only HOME variable. It first prints null JAVA_OPTS and the
  disclosed own temp property. A separately named global-input correction exits 0
  and reports absent Gradle properties/init files. This occurs after build launch.
- First publication argv contains `-ParceVersion=1` and separate
  `.20.1-1.8.0-dev`; Gradle exits 1 before publication on an unknown task. Corrected
  quoting produces the exact single intended property argument, preserved in a
  different command receipt. No source/config fix or tool change occurs.
- Strict TIMEOUT and the native 62 ERROR/zero FATAL inventories are retained,
  with no retry, timeout increase or acceptance waiver.
- After successful cleanup, two prospective post-cleanup capture preparations
  raise FileNotFoundError because their scratch parent was removed. No Git child
  launches and no `.command.json` is created for those failed preparations.
  The surrounding display/read command returns 0; it is not a passed Git check.
  The evidence-only empty scratch parent is recreated, and separately named
  corrected diff/status receipts are empty, exit 0. This is not a cleanup retry
  or recreation of checkout build/world output. The original exceptions and
  absent instrumented UTC limits are retained in a separate transcript record.

Capture helper revisions are preserved as original version snapshots and later
hash-bound receipts. No sustained test/source failure is concealed by those
preparation corrections. No assertion/filter/cap/log/time waiver, unsupported
installation, source change, forbidden runtime or extra cleanup attempt occurs.

## Cleanup and retained output

Clarification30 was completely read, copied and hash-checked before cleanup.
It expressly includes this fresh task's newly generated build/gametest world
as disposable output; prior/source/player worlds, source/fixtures, peers and
sealed inputs stay protected. No older denied cleanup is retried or taken over.

After all assigned processes and result readers finish, one inline native
PowerShell literal-path cleanup generation succeeds: command start/end UTC
07:40:06.075 /07:40:11.794, exit 0, 5.719 seconds. Before any removal it verifies
each exact resolved absolute target, ancestor/descendant reparse absence,
containment and no live overlapping owned Java/native process; per-file paths,
bytes and SHA256 are inventoried. All targets are checked before the first delete.

| Own disposable target | Files / bytes removed |
|---|---:|
| checkout build, including new GameTest world and local publication | 5719 /273990126 |
| checkout .gradle | 17 /6287951 |
| checkout run-data | 5 /128482 |
| compat-test-mod build | 81 /25783761 |
| compat-test-mod .gradle | 16 /266145 |
| own initial scratch generation | 6 /705024 |

All post-delete target-absence checks pass. Source checkout and evidence leaf
remain; fixed HEAD/src tree and empty tracked/index/source state remain verified.
Only empty evidence scratch directories are later recreated for read/report/seal
bookkeeping; they do not contain build/world/library outputs. Shared dependency
caches and source/generated fixtures remain outside cleanup. No cleanup denial,
retry, execution-policy bypass, alternate shell or foreign process termination.

Retained evidence is about 14 MB before this report/final seal additions; no
single evidence file exceeds 50 MB and the leaf stays well below 100 MB. Only
compact raw logs/receipts/results/XML, fixed-input/diff/source identities, artifact
hashes, cleanup inventory and small helpers are kept. There is no complete
source/library/build/world/server archive, source checkout deletion or temporary
compression. Artifact paths in identity JSON describe removed generated files;
the later seal covers the leaf records, not those external mutable paths.

## Unfinished obligations, risks and Required Gates

Unfinished: native per-method standalone receipts; constructed EntityType-subtype/
registry injection and universal receiver/union/pre-allocation qualification;
driver/parser/token/encoding/storage freeze and independent review; packaged
current-artifact observation, twenty native rows/two invocations, typed Spawn
disk/flush/reacquisition/exit/restart; real TCP/client/decoder, prior-world/death,
coexistence/custom bed/all-host/Space checks; sleep B1/R1/M1/M2/D1 and separate
production dimension/spawn/time/air/failure-policy freezing; full assets/item/
ledger/progression/performance/GPU/multiplayer and release acceptance.

Historical source findings and Task11/12 strict/log/peer-retention limits remain
their own evidence. This independent actual d57 run does not rebind those
receipts, retry peer cleanup or authorize broader work. Our own strict TIMEOUT,
native log acceptance and preparation-timing limits also remain open.

**All current/inherited Required Gates G0-G9 satisfied: no.** Scoped build/test/
DataGen/native/consumer results are development evidence, not complete release
Gates. G0 strict validation is incomplete; G4/G5/G6/G7/G8/G9 full dedicated/
restart/security/performance/real-client/release obligations are unexecuted or
incomplete. No Gate PASS, item/ledger delivery, version status update, source
integration, tag, release or production/observation runtime authority is made.

Next suggestion within v1.8 only: Root independently dispositions this exact
source's finite evidence and retained metadata/log/strict limits, then separately
freezes/reviews any remaining observation contract before assigning its runtime.
That suggestion is not permission to launch a driver or implement off-world sleep.

## Evidence and Root-read-before-seal boundary

Evidence leaf:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/`.
Key records are the
[fixed input identities](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/FIXED-INPUT-IDENTITIES.json),
[command index](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/COMMAND-INDEX.json),
[actual result audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/FINAL-RESULT-AUDIT.json),
[cleanup inventory](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/CLEANUP-OUTPUT-INVENTORY.json)
and per-command raw streams plus separate cohort result directories.

Root must completely read this persisted REPORT before its exact-hash full-read
acknowledgement and the one-time seal. At report preparation no acknowledgement
or seal is inferred. The
[seal coverage](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/SEAL-COVERAGE.md)
defines safe leaf-relative regular-file coverage and the precise excluded
manifest/result/seal/verification receipts plus evidence scratch prefix. No
external mutable build/cache/Temp path is a seal member. Covered files, including
this report and original failed receipts, are never edited after sealing.
