"""Task28 receipt, standard result and artifact audit; no observation driver."""
import hashlib
import json
from pathlib import Path
import re
import zipfile
from capture import LEAF, SOURCE, sha, state, utc

records = []
for file in sorted(LEAF.glob('*.command.json')):
    r = json.loads(file.read_text(encoding='utf-8'))
    if 'end_utc' not in r:
        continue
    for suffix, identity in r['streams'].items():
        stream = LEAF/(r['name']+'.'+suffix+'.txt')
        assert stream.stat().st_size == identity['bytes'] and sha(stream) == identity['sha256']
    records.append({'name':r['name'],'start_utc':r['start_utc'],'end_utc':r['end_utc'],
        'argv':r['argv'],'cwd':r['cwd'],'exit_code':r['exit_code'],'timed_out':r['timed_out'],
        'elapsed_seconds':r['elapsed_seconds'],'ceiling_seconds':r['timeout_seconds'],
        'helper_sha256':r['helper_sha256'], 'before_source_clean':all(r['before'][k]['exit']==0 and not r['before'][k]['stdout']
          for k in ['tracked_diff','index_diff','src_diff']),
        'after_source_clean':all(r['after'][k]['exit']==0 and not r['after'][k]['stdout']
          for k in ['tracked_diff','index_diff','src_diff']),
        'disk_before':r['before']['disk_free'],'disk_after':r['after']['disk_free']})
records.sort(key=lambda r:r['start_utc'])
assert sha(LEAF/'CLEANUP-CLARIFICATION-30.md') == 'b95f5b69e3aedff292a743101fad4a9893d2794e92ee3c73814bdf453bdc6ee1'
stdout = (LEAF/'native-01.stdout.txt').read_text(encoding='utf-8',errors='replace')
required = re.findall(r'All (\d+) required tests passed',stdout)
batches = re.findall(r"Running test batch '([^']+)' \((\d+) tests\)",stdout)
native = json.loads((LEAF/'native-01-COLLECTION.json').read_text(encoding='utf-8'))
sources = {}
for name in ['SleepBoundaryChatBounds','SleepBoundaryTrace','SleepBoundaryObservationFixture']:
    file = SOURCE/'src/adapterTest/java/io/github/sunthemoon/arceadaptertest'/(name+'.java')
    text = file.read_text(encoding='utf-8')
    sources[name] = {'bytes':file.stat().st_size,'sha256':sha(file),
       'declared_gametest_methods':re.findall(r'@GameTest\([^\n]+\)\s+public static void (\w+)\(',text)}
artifacts = []
for file in sorted((SOURCE/'build/libs').glob('*.jar')) + sorted((SOURCE/'compat-test-mod/build/libs').glob('*.jar')):
    with zipfile.ZipFile(file) as archive:
        names = archive.namelist()
        selected = [n for n in names if '/api/' in n and n.endswith('.class')]
        artifacts.append({'path':str(file),'bytes':file.stat().st_size,'sha256':sha(file),
            'zip_entries':len(names),'duplicate_entries':len(names)-len(set(names)),
            'api_class_entries':{n:hashlib.sha256(archive.read(n)).hexdigest() for n in selected},
            'observation_class_entries':[n for n in names if 'SleepBoundary' in n]})
consumer = {}
for name in ['classpath.json','negative-import.json','fixture-artifact.json']:
    path = SOURCE/'compat-test-mod/build/reports/consumer'/name
    if path.exists():
        consumer[name] = json.loads(path.read_text(encoding='utf-8'))
result = {'utc':utc(),'commands':records,'sources':sources,'artifacts':artifacts,'consumer':consumer,
          'native':{'terminal_required_pass_counts':required,'batches':[{'name':n,'discovered_tests':int(c)} for n,c in batches],
                    'batch_total':sum(int(c) for n,c in batches), 'native_xml_retained':sum(x['evidence'].endswith('.xml') for x in native['copied']),
                    'logs':native['native_log_inventory'],
                    'stdout_error_headers':stdout.count('/ERROR]'),'stdout_fatal_headers':stdout.count('/FATAL]')},
          'final_source_state':state(),'evidence_before_cleanup':{'files':sum(p.is_file() for p in LEAF.rglob('*')),
              'bytes':sum(p.stat().st_size for p in LEAF.rglob('*') if p.is_file())}}
(LEAF/'FINAL-RESULT-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'native_required':required,'batches':len(batches),'batch_total':result['native']['batch_total'],
     'sleep_batches':[x for x in result['native']['batches'] if x['name'].startswith('sleep_')],
     'artifacts':[{k:v for k,v in x.items() if k in ['path','bytes','sha256','observation_class_entries']} for x in artifacts],
     'commands_failed':[x['name'] for x in records if x['exit_code'] or x['timed_out']],
     'native_xml':result['native']['native_xml_retained'], 'stdout_error_headers':result['native']['stdout_error_headers'],
     'stdout_fatal_headers':result['native']['stdout_fatal_headers']} ,indent=2))
