# Independent sleep observation nested receiver review, Task 21

Date: 2026-10-09 UTC. Fresh delegated independent read-only reviewer, not Root.
Fixed governance: Main `6d1b796e0e93b9953af505dd3fd9b25d47b91d97`.
Final reviewed source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.

## Findings first, ordered by severity

### R01 - Medium, historical 7a: identifier receiver behavior was not admitted safely

At original fixed candidate `7a36169083f26a7c78dca6db0f53de7235e7a03f`,
[ChatBounds:62](D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L62)
calls the font identifier's namespace/path getters without an exact receiver
class check. The pinned ResourceLocation is non-final with overridable getters
and toString; Style.Serializer subsequently calls font.toString. A derived
font could execute receiver behavior during preflight, or serialize a different
string before the existing post-allocation bound is checked. The same missing
returned-identifier admission exists at original ChatBounds:77-79 for the
SHOW_ENTITY registry key. Native ResourceKey storage and Forge registration do
not establish exact ResourceLocation normalization.

Independent static evidence: receiver-primary.stdout.txt lines 727, 902-914,
966-974 and its Style.Serializer font branch; registry-key-primary.stdout.txt
lines 53-64, 180-191, 1834-1843 and 2537-2552; wrapper-primary.stdout.txt
lines 208-216. The author disclosed the font boundary; this reviewer verified
the primary route independently. No custom font/key was executed or injected.

**Final-source disposition:** the additive identifier correction at 0552eb65 is
retained in final d57ecda1. Final
[ChatBounds:40-44](D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L40)
checks null/exact ResourceLocation before getters; the font at line 75 and
registry-returned key at line 92 use this helper. This addresses the inspected
source boundary. Its new GameTests compile but are unexecuted; no runtime closure
or universal arbitrary-custom-state conclusion follows. Original 7a is not
retroactively credited with the successor correction.

### R02 - Medium, historical 7a and 0552: registry lookup could invoke type behavior first

Original
[ChatBounds:77](D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L77)
passes entity.type to ENTITY_TYPE.getKey after admitting only the enclosing
EntityTooltipInfo. EntityType is public/non-final with public constructors.
NamespacedWrapper delegates getKey to ForgeRegistry; getResourceKey performs
owners.inverse().get(value). The pinned inverse HashBiMap calls
Hashing.smearedHash(value), which virtually invokes Object.hashCode. A derived
EntityType could therefore execute receiver behavior before any returned-key
admission, even without a matching registration. The 0552 identifier correction
alone does not address this earlier value lookup.

Independent static evidence: entitytype-signatures.stdout.txt; wrapper-primary
lines 208-216; registry-key-primary lines 1679-1717 and 1960-1989;
bimap-primary.stdout.txt lines 48-58 and 1239-1250. This reviewer identified and
reported this additional value boundary before Addendum 23 was issued. No
EntityType subclass was constructed, registered, invoked or tested here.

**Final-source disposition:** final
[ChatBounds:46-50](D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009/src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java#L46)
checks null/exact EntityType with final Object.getClass; line 90 evaluates that
admission before ENTITY_TYPE.getKey. The exact 0552-to-d57 delta and independently
compiled bytecode both confirm the order: final-compiled-admission.stdout.txt
places chatEntityType at bytecode 513 and registry getKey at 516. This addresses
the inspected source boundary, not an executed native subtype/registry result.
The new test uses a local Object behavior probe at the shared admission helper,
not an instantiated EntityType subtype or component-level registry injection.

No Critical/High production or gameplay defect was established. No remaining
material defect was identified in the scoped final patch after these source
corrections. This is a narrow static-review result with the test and broader
qualification limits below, not Gate approval or exhaustive receiver proof.

## Authority, fixed inputs and completed review

Task authority is
[Task 21](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OBSERVATION-NESTED-BOUNDARY-REVIEW-TASK-21.md),
SHA256 `c231ba9c590d873d17d83924bbaeb2037d6e019a54c58904b0f7e4f566eb2739`.
[Addendum 25](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OBSERVATION-NESTED-BOUNDARY-REVIEW-ADDENDUM-25.md),
SHA256 `a4eb92222e99576db151999b8dc9cf7e01918279fe0887ea294ebf11ec19082f`,
authorizes the separate fixed final worktree/delta and one new compile generation.
Task 19 and Addenda 22/23 were completely read and hash-checked:

| Authority | SHA256 |
|---|---|
| Task 19 | c0aa3f2de10388f15d5cb899af9e3dcd57450fa4831f533452262bcd2e43f1b4 |
| Addendum 22 | 5ef9ad65df1540076fe63417becf2ddc7b328de2cb69a0cb5d129d29ba3969ed |
| Addendum 23 | c54cdea7bc53eb0dccdca1a3dc6e99c9cde81cc27a3ddef612e56194cdefa4c7 |

All applicable mandatory governance was read at fixed Main 6d: project/product,
porting principles, roadmap, active uppercase v1.8 version document, master test
plan, release gates, post-v1.0 roadmap, quality budgets and parallel rules.
AGENTS, CURRENT_VERSION, GATE_STATUS, ADR-060 and complete Main disposition 18
were also read. Earliest incomplete acceptance remains v1.0 IN PROGRESS; scoped
v1.8 development under ADR-060 is not inherited acceptance or release approval.
The author's different assigned governance baseline is recorded in its report;
this independent review does not follow a moving Main/author HEAD.

Root supplied two separate detached source trees:

- Original: `D:/GitHub/arce-v180-sleep-chat-boundary-review-20261009`, fixed at
  `7a36169083f26a7c78dca6db0f53de7235e7a03f`.
- Final: `D:/GitHub/arce-v180-sleep-chat-boundary-review-final-20261009`, fixed at
  `d57ecda1f11dab76d882f945b0de606534ef4fb9`.

The complete original parent-to-7a diff, complete final helper/Trace/unchanged
Fixture and exact 7a-to-final and 0552-to-final deltas were read. The final helper
is only 238 lines; the complete files and raw fixed-object diffs are retained.
The additive ancestry is independently checked:

```text
5b45132000ade1e3c8d130a6b8ccb29f07535124  corrected source base
7a36169083f26a7c78dca6db0f53de7235e7a03f  named nested receiver checks/extraction
0552eb65bbf2ca8c55af1a50821c3345c4a2747f  identifier receiver correction
d57ecda1f11dab76d882f945b0de606534ef4fb9  pre-lookup EntityType value correction
```

This reviewer made no commit, amend, push, checkout or HEAD/index/source change.
The author's normal pushes are author receipts, not operations rerun here.
The original fixed review is preserved in FIXED-7A-REVIEW.md with its original
receipts; its then-pending successor statements remain historical, not edited.

Complete Task 16/17 reports and every covered seal member were independently
verified, followed by the complete final author Task 19 report and its seal:

| Input | Verified members | REPORT SHA256 | Manifest SHA256 |
|---|---:|---|---|
| Task 16 contract review | 157 | 7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3 | 2aa9ee0dad7fce9a509b9c7b70ae3021f5f4e898138e42c8fee3de099d45b105 |
| Task 17 primary wire review | 251 | fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108 | 430acfcab917021c5fb1de7b44ae3a13306db723af13df631573bc0e95316d16 |
| Final author Task 19 | 314 | 982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e | df8c9dd1dbc7d487663474c3326ba302178ca4348923539c5bbbf91a7ffbbe3a |

The final author report is 24,557 bytes and was completely read in
author-report-root-ready-corrected.stdout.txt, with its identity independently
confirmed by final_inventory.py and receipt-and-author-seal-audit. Earlier
unsealed author snapshots were read/captured at SHA256
a8a2cea30caaa5fbce3df8102d6c573717e620fbc0d06e659c3f6273b9a00def
and e552f604871b056d30e7c56367e8709b2ba3810f311dd47103ffbbb117281fe9
under separate cohort names. They are not substituted for the final report.
Author compile stream hashes were actually checked against all three author
receipts by author-compile-receipt-audit. They are input evidence, not this
reviewer's independent tests/reruns. Author successful cleanup likewise does not
change this reviewer's separate cleanup denials.

## Exact scope, source identities and design assessment

Base-to-final scope is exactly two adapterTest source files, 239 insertions and
54 deletions. Original base-to-7a is two files, 167 insertions and 54 deletions.
Fixed-object production/API, src/test, generated resources, build inputs,
provenance and central/status scope checks are empty. Final Trace and Fixture
are byte-identical to their original reviewed cohort; Fixture is also unchanged
from the corrected source base. Working bytes match their fixed committed
objects before and after compilation. Both detached HEADs remain unchanged and
both final status/index/tracked diffs are empty.

| Source file | Reviewed state | Bytes /lines | SHA256 |
|---|---|---:|---|
| SleepBoundaryTrace.java | Modified from base; identical at 7a/final | 27593 /445 | 20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f |
| SleepBoundaryChatBounds.java | Added; original 7a | 10985 /166 | 639ddfe5d01fddd39b37a6dedf7c3bcda4a28493ee9d1da4c2faa13d17cd4058 |
| SleepBoundaryChatBounds.java | Final d57 | 15889 /238 | 16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0 |
| SleepBoundaryObservationFixture.java | Unchanged reference | 33987 /497 | 1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |

INPUT-AND-SOURCE-IDENTITIES.json, FINAL-SOURCE-IDENTITIES.json, source-blob-ids
and final-status-and-retention-corrected retain exact Git/working byte identities.
The author records the intermediate helper as 14,094 bytes /212 lines, SHA256
d7c0c3fa4546b1b468eff1624d16ece8c62ff6b82f2156d8e6d4de478dd23b56;
this reviewer reads its immutable 0552-to-final delta, not a moving checkout or
an independently compiled intermediate generation.

The extraction is a reasonable focused split: Trace retains invocation-owned
event/frame/identity evidence, accounting, byte reservation and failure handling;
ChatBounds contains finite chat traversal/admission plus focused tests. Trace
stays 445 lines, helper 238, unchanged Fixture 497. No >500/>800-line class is
introduced. Existing five Trace tests are retained without weakened assertions.

Inspected ordering at final source:

- Exact native component/content/style/hover admission is retained. ClickEvent
  exact-class rejection precedes getValue and subsequent native getAction/getValue.
- EntityTooltipInfo null/exact-class rejection precedes metadata and its native
  virtual serialize. The nested entity name recursively uses the same admission.
- Final identifier/value admission addresses R01/R02 before their inspected
  overridable behavior. Ordinary exact native identifiers/types remain source
  admissible. Null/non-exact EntityType now refuses capture rather than relying
  on the default-registry fallback; this is a declared malformed-observation
  boundary, not a gameplay decision or preserved null metadata behavior.
- Trace still checks the conservative preflight bound against available bytes
  before Component.Serializer.toJsonTree and validates the resulting tree. An
  unsupported receiver still raises IllegalStateException into existing capture
  failure handling. No save-control exception mechanism is introduced.

Unchanged budgets: depth 8; 32 visited components and 32 siblings; four translated
arguments; 1024 characters per string; 8192 conservative escaped-text bytes;
4096 reservation plus 1024 per component. Trace retains 64 frames plus overflow
sentinel, 32/128 event caps, 128/512 KiB case/invocation bytes and 512 identity
tokens. No evidence schema, incompleteness/intervention/observer/lifecycle,
twenty-case native Fixture action, persistent ID, network/API/save, registration
or production dimension/spawn/time behavior changes. Item/NBT/custom contents
remain unsupported. This patch does not prove every broader wire union bound.

Installed read-only primary evidence was independently inspected, not copied
into project source or bundled as JARs. The exact mapped Forge 1.20.1-47.4.10
JAR is 19,355,242 bytes, SHA256
95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e.
Pinned Guava 31.1-jre is 2,959,479 bytes, SHA256
a42edc9cab792e39fe39bb94f3fca655ed157ff87a8af78e1d6ba5b07c4a00ab.
Primary class entry hashes, paths and javap streams are in the identity JSON and
receiver/registry/wrapper/entitytype/bimap receipts. The Forge inverse-map route
is checked directly rather than assuming the vanilla default registry applies.

## Added tests versus actually executed verification

Final helper adds six adapter GameTest methods, all compiled, **all UNEXECUTED**:

| New method | Source-declared coverage and limit |
|---|---|
| ordinaryNestedNativeReceiversRemainSerializable | All six pinned ClickEvent actions; SHOW_ENTITY absent/present name; ordinary click in entity name; native JSON field assertions |
| unsupportedClickReceiversAreRefusedBeforeGetters | Counting/throwing subclass getters; exact refusal and zero counters through direct/sibling/translation/SHOW_TEXT/SHOW_ENTITY-name routes |
| unsupportedEntityTooltipReceiversAreRefusedBeforeSerialization | Counting/throwing serialize/tooltip subclass behavior; same five component routes and zero counters |
| ordinaryNativeResourceIdentifiersRemainSerializable | Exact default/uniform font identifiers and PIG registry key; no font loading or visual assertion |
| unsupportedFontReceiversAreRefusedBeforeIdentifierMethods | Counting/throwing ResourceLocation getters/toString; five component routes plus shared identifier helper; no registry-key injection |
| unsupportedRegistryValuesAreRefusedBeforeReceiverBehavior | Native PIG admission and an owned Object hash/equals/toString-counting probe at the exact shared value helper; no EntityType subtype, native registry mutation or component-level injected value |

Original 7a declared three new helper tests, five unchanged Trace tests and four
unchanged Fixture tests (12 total). Final declares six plus those unchanged nine
(15 total). These are source declarations, not executed discovery or PASS counts.
Actual subtype construction would involve native global intrusive-holder
allocation; avoiding it keeps the new value probe mutation-free but narrows its
qualification. Static source/compiled ordering supports the value-before-lookup
claim; the probe must not be described as an executed EntityType subtype test.

This reviewer independently ran exactly two authorized three-task compiles:

```text
./gradlew.bat compileJava compileTestJava compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks
```

Actual argv begins installed cmd.exe /d /c gradlew.bat and those exact tasks/options.
Cwd is the corresponding separate fixed worktree. Each ceiling remains 1800
seconds, with no timeout extension. Oracle JDK 17.0.7+8-LTS-224 is selected via
JAVA_HOME/PATH; Gradle is 8.8, unchanged Forge input is 47.4.10. Child TEMP/TMP and
java.io.tmpdir use the initially absent owned worktree `_review-temp-21`.
Unexpected JVM overrides are rejected. Source/index/HEAD remain read-only.

| Independent cohort | Actual pre-start; start/end UTC, 2026-10-09 | Result | C:/D: free before, bytes |
|---|---|---|---|
| compile-01, fixed 7a | 06:37:18.415060; 06:37:18.417316 /06:38:00.896258 | Exit 0; BUILD SUCCESSFUL 42s; 10 tasks executed | 30518239232 /292606390272 |
| final-compile-02, fixed d57 | 06:50:32.697544; 06:50:32.699782 /06:51:17.123520 | Exit 0; BUILD SUCCESSFUL 44s; 10 tasks executed | 30512308224 /291956850688 |

Both drives exceed 10 GiB. Preflight free physical memory was 21,469,820 KiB
original /21,300,272 KiB final. Owned-output absence, ancestor/reparse checks,
no overlapping Java/Gradle execution and JDK identity are retained before each
compile. The final compile never reuses the original denied output generation.

| Independent raw stream | Bytes | SHA256 |
|---|---:|---|
| compile-01 stdout | 1145 | 648f754f3446fe85d588e4927283e8dda1899f91fc4390e77233f38f5d6705ec |
| compile-01 stderr | 42910 | f67b6d4a4519abe77bb56ee0ee552d60697faa51b5dfe223e5b55184079286b4 |
| final-compile-02 stdout | 1145 | 366fd56c9c1c7e9d7965eb19b02e013705d332efda186a3cff6544f7ad225a93 |
| final-compile-02 stderr | 43908 | 265118480cca7e11f86a57b887a976010a379255bef7e2a9adb9f2e8f9b73dc7 |

All warnings remain in raw stderr, including 29/69 existing cohorts and the
final helper's deprecated ResourceLocation constructor warning. No warning/log
waiver is claimed. No test method, JUnit, GameTest, native server, discovery,
driver/parser, gameplay, package/build, DataGen or network/install command ran.
No third compile or intermediate-cohort independent compile is implied.

Other actually executed read-only checks include fixed git show/diff/check,
HEAD/index/status/worktree reads, source/tool/JAR hashes and ZIP-entry hashes,
primary javap and final compiled-helper javap, full reports/governance reads,
peer seal verification, author raw-compile receipt audit and retained-output
inventory. COMMAND-INDEX-AND-AUTHOR-SEAL.json catalogs 75 pre-audit command
receipts with exact argv/cwd/pre-start/start/end/exit/streams; all their stream
sizes and hashes were verified. The audit's own receipt and later seal receipts
are separately named. Early transcript-only preparation is not fabricated into
this catalog. Receipt data, not a summarized command title, is the execution
record.

## Cleanup, preserved failures and ownership

Only the exclusive Task 21 evidence leaf and the separately assigned, initially
absent generated build/.gradle/temp outputs were written. No Main, author or
peer source/index/branch/output was edited, staged, deleted or adopted. No
process was terminated, no nested delegation occurred, and Root owns pet/state
records. This reviewer did not perform an OpenPet emission.

**Each generation made one native cleanup attempt and stopped on denial.**

| Attempt | Actual pre-start; start/end UTC | Result |
|---|---|---|
| cleanup-01, original tree | 06:43:30.362251; 06:43:30.363795 /06:43:30.584970 | Exit 1; policy UnauthorizedAccess; 425-byte stderr |
| final-cleanup-02, separate final tree | 06:52:59.139393; 06:52:59.141068 /06:52:59.371294 | Exit 1; policy UnauthorizedAccess; 431-byte stderr |

Windows refused loading the .ps1 files. Neither script body, its guarded checks
nor any Remove-Item call executed. No deletion, execution-policy bypass, alternate
cleanup command, retry, peer takeover or process termination followed. The
original script's guarded pre-delete checks are therefore not credited as having
run. The final generation additionally has an independently executed pre-delete
read-only preflight (exit 0), confirming containment, no reparse targets/ancestors
and no live owned compile/Java process before that denied attempt. Later owned
process/status reads confirm neither compile child remains live.

Read-only inventory after both denials retains:

| Owned worktree generation | build files /bytes | .gradle files /bytes | owned temp |
|---|---:|---:|---|
| Original 7a | 3912 /20836588 | 16 /2936678 | empty, retained |
| Final d57 | 3914 /20842985 | 16 /2968070 | empty, retained |

These external generated directories are not manifest members or permission for
another agent to delete them. Shared caches, fixed source trees and any native
world were not cleaned. Both fixed HEADs and source/index cleanliness remain
verified at final-status-and-retention-corrected. The original denied tree was
neither reused nor retried under Addendum 25.

Preserved preparation/evidence failures, none hidden or converted to PASS:

- Initial javap/Adoptium path probes failed in transcript-only exploration. A
  guessed pwsh path failed before child creation; preflight.command.json retains
  FileNotFoundError and zero streams. A separately named installed PowerShell
  preflight succeeded before the first compile. No missing UTC/raw receipt is
  reconstructed.
- final-status-and-retention failed with ModuleNotFoundError importing capture
  from a -c command's working tree (exit 1, 334-byte stderr). A separately named
  read-only final_inventory.py audit succeeds; the failed receipt is unchanged.
- author-report-root-ready failed because outer-shell variable interpolation
  removed the variable/arguments (exit 1, 2278-byte stderr). Its separately named
  correction completely prints the final report but retains a non-terminating
  missing Get-FileHash error (562-byte stderr) despite exit 0. That PowerShell hash
  operation is not credited. Absolute Python independently obtains the expected
  final report hash and verifies every author seal member. No tool install or
  policy change was made.
- Both native cleanup policy denials above remain failures, not cleanup success
  or a Required Gate waiver.

Some broad tool displays truncated; complete retained files and focused/full
source/report/governance reads followed. The package is not represented as a
fully instrumented transcript of every exploratory read.

## Provenance, unfinished scope, risks and Required Gates

Project source changes are original admission/test code and extraction from
the existing project Trace. No upstream/fork code/art or official Minecraft/
Forge artwork is imported, no platform JAR is bundled, no license declaration
is removed and no provenance-ledger edit occurs. Existing English/ASCII code
and comment conventions are retained. Read-only primary bytecode evidence is
not a source/asset import or a complete production license Gate audit.

Completed scope: independent original/final fixed source and exact-delta review,
source-addressed disposition of the two historical findings, full required input
report/seal checks, two independent compiles, raw receipts and explicit failed
cleanup retention. Modified project files by this reviewer: **none**. Only this
external evidence leaf/helpers and assigned disposable generation outputs are
written. New/modified tests by this reviewer: **none**; the six author's tests
are reviewed/compiled, not run.

Unfinished and known risks:

- All final new/current tests, runtime discovery, ordinary native serialization
  and before-behavior receiver assertions remain unexecuted. EntityType-subtype/
  registry injection and broader arbitrary custom-state behavior are not proven.
- Task 16's Medium encoding-policy and finite-overflow storage issues and Low
  modified-UTF8/gzip/NBT limit remain; Task 17 whole-trace token budget 65536 is
  not derived/frozen, and union/encoding/pre-allocation qualifications remain.
- Historical Tasks 11/12 strict 180-second TIMEOUT, 62 ERROR/0 FATAL native-log
  accounting and peer denied-retention limits remain input facts, not reruns,
  waivers or newly closed regressions. This Task 21 additionally retains its own
  two cleanup-denied generations.
- Current packaged/API/artifact identity, driver/parser/token/encoding freeze,
  twenty native rows/two invocations, typed Spawn disk/flush/reacquisition/exit/
  restart, real TCP/client/decoder, prior-world/death/coexistence/custom-bed/
  all-host/Space and production cause/enforcement/failure policy are unverified.
- Sleep B1/R1/M1/M2/D1, dimension/spawn/time policy freeze, assets/item/ledger,
  performance, real GPU/multiplayer and release acceptance remain outside this
  read-only compile assignment. No native outcome or row result is prefilled.

**Current/inherited Required Gates G0-G9 all satisfied: no.** Compile does not
replace clean build/runData/standard GameTest, dedicated-server/restart, visual,
player or release evidence. No assertion, cap, timeout, failure handling or Gate
requirement was relaxed. No Gate PASS, version approval, ledger/item closure,
source integration, release or tag is made by this reviewer.

Within v1.8, the supported next work is a separately authorized finite executed
regression/qualification assignment on the exact final committed source, with
the mutation-free value-probe limit and open wire/runtime boundaries stated.
This report grants no runtime launch or cleanup-retry permission.

## Evidence and Root-read-before-seal boundary

Evidence leaf:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-independent-20261009-21/`.
It contains original/final fixed source/diffs, compact helpers, primary javap,
input/source/tool hashes, full report/governance receipts, both compiles, all
captured failures, cleanup denials and retained-output inventories. At the
pre-report audit it is approximately 6.90 MB; no single file exceeds 50 MB and
the leaf stays below 100 MB. No whole source/build/world archive is duplicated.

Root must completely read this persisted final REPORT before acknowledging
one-time sealing. At report preparation that acknowledgement and seal are not
inferred. SEAL-COVERAGE.md and seal.py specify safe case-unique leaf-relative
coverage, Root-read/report-hash gate, no reparse/external members, one-time write
and separate verification. The manifest itself and precisely named post-seal
receipts/results are excluded; external mutable build/.gradle/temp/cache paths
are never covered. ROOT-READ-ACK.json may be added only after actual Root
acknowledgement. Covered files, including this report and all original receipts,
remain unchanged after sealing.

D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-independent-20261009-21/REPORT.md
