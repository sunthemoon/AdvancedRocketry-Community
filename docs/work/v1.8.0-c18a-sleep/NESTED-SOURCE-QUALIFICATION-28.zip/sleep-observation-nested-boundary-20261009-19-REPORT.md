# Sleep observation nested receiver source task 19

Date: 2026-10-09 UTC. Delegated implementation worker, not Root.
Disposition: Task 19 and Addenda 22/23 receiver checks implemented,
separately compiled, additively committed and normally pushed; independent final
review and executed tests
remain outstanding. No native gameplay result or Gate approval is claimed.

## Findings and limits first

1. The named Task 17 admission gap is source-addressed: exact ClickEvent and
   HoverEvent.EntityTooltipInfo identities are checked before their overridable
   getters or native virtual serializer can run. Ordinary native nested receivers
   remain admitted by the inspected source. Six focused GameTest methods are
   added and compile successfully, but **were not executed** by this worker.
2. **Historical intermediate boundaries are retained, not credited as closed at
   earlier cohorts.** The first pushed 7a361690 cohort still admits font identifier
   subclasses. The pinned public
   ResourceLocation class is non-final and has public constructors and overridable
   getNamespace/getPath/toString methods. Addendum 22 authorizes the additive
   ResourceLocation checks at 0552eb65 for both font and registry-returned keys.
   That intermediate cohort still admits arbitrary EntityType value receivers to
   Forge inverse registry lookup. Root's independent Task 21 identifies that
   boundary and Addendum 23 authorizes the final d57ecda1 exact EntityType check
   before lookup. Original/intermediate source hashes and compile/diff receipts
   remain unchanged; neither receives a retroactive final-cohort verdict.
3. **Value-probe qualification is narrower than a constructed native subtype.**
   EntityType constructors eagerly allocate intrusive holders through the global
   native registry. The added value-admission test uses an owned hash/equals/
   string-counting Object probe at the actual shared exact-type admission method,
   and native EntityType.PIG for the admitted case. No EntityType subtype is
   constructed or globally registered. Static ordering is inspected, not an
   executed subtype/registry injection result. Universal arbitrary-custom-state
   closure is not assumed from these compiles.
4. The only authorized sustained validations are three successful three-task compiles.
   No tests, standard GameTest, packaged server, driver/parser, twenty native rows,
   encoding-policy change, network download, install or gameplay implementation
   was performed. Historical Tasks 11/12 are verified inputs, not this worker's
   executed tests; their strict TIMEOUT/log/retention limits remain unchanged.

## Authority, preparation and ownership

Task: D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OBSERVATION-NESTED-BOUNDARY-TASK-19.md.
Task SHA256: c0aa3f2de10388f15d5cb899af9e3dcd57450fa4831f533452262bcd2e43f1b4.
Addendum 22 SHA256: 5ef9ad65df1540076fe63417becf2ddc7b328de2cb69a0cb5d129d29ba3969ed.
Addendum 23 SHA256: c54cdea7bc53eb0dccdca1a3dc6e99c9cde81cc27a3ddef612e56194cdefa4c7.
Both complete external addenda are read and hash-checked before their source edits.
Fixed governance: 30944465a6e07215990182fb0dd935e65303e27a.
Fixed corrected source base: 5b45132000ade1e3c8d130a6b8ccb29f07535124.
Exclusive worktree: D:/GitHub/arce-v180-sleep-chat-boundary-20261009.
Exclusive branch: codex/v1.8.0-sleep-chat-boundary.
Exclusive evidence: this REPORT's external leaf directory.

Initial status is clean at the assigned base; source-status-00/source-head-00 and
worktrees-00 retain the actual checks. Main's pre-existing AGENTS/untracked peer
outputs were observed in the initial transcript only and not touched, staged,
committed, deleted or adopted. Root later announced a separate Main central-doc
publication; all governance reads here keep their explicit fixed SHA.
Source ownership is limited to the two files below. No other agent was delegated
to a moving source HEAD. Root was notified before each independent branch commit;
Task 21 uses separately assigned fixed objects, not this moving checkout.
Root owns central records and OpenPet; this worker sends no pet events and
delegates no work.

All ten mandatory project/product/principles/roadmap/active uppercase v1.8/test/
release/parallel/v1+/quality documents were read before editing. They are also
captured separately in governance-00 through governance-09 command receipts.
The fixed GATE_STATUS and ADR-060 were additionally read and retained: earliest
incomplete acceptance remains v1.0; scoped v1.8 development is not inherited or
current Gate approval. Root owns repository implementation/status/ledger records;
this external report supplies only this assigned task's record.

Complete Task 17 and corrected Tasks 06/11/12 reports were read. Their original
leaf-relative manifests and all covered hashes were actually verified by
input-verification; no sealed input was edited. INPUT-VERIFICATION.json records:

| Input | Covered files | REPORT SHA256 |
|---|---:|---|
| Primary wire Task 17 | 251 | fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108 |
| Corrected source review Task 06 | 125 | 3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0 |
| Root qualification Task 11 | 835 | 0c82a4097db51bb98e1f45d819126ba87f1d7946c7b0d15157136f50fa19eebb |
| Independent qualification Task 12 | 895 | dadc06c556466d0f353fe96db68327208da5e40b89de883fb1eb6faa08d5cb31 |

The primary wire report is read as evidence of pinned native serialization and
remaining boundaries, not as permission for runtime or any assumed outcome.
Its original nested EntityTooltipInfo/ClickEvent bytecode was read; this worker
also captures the installed public ClickEvent and ResourceLocation javap output.

## Completed scope and design decisions

SleepBoundaryTrace.boundedChat still performs admission before native
Component.Serializer.toJsonTree, reserves against available trace/case bytes,
and checks the resulting tree against the same conservative upper bound.
Its native-chat traversal is extracted verbatim apart from the named receiver
checks and equivalent imported class names into SleepBoundaryChatBounds.

- A ClickEvent local is obtained from the already exact native Style. The final
  Object.getClass comparison rejects subclasses before any getValue call, and
  therefore before the later native Style serializer can call getAction/getValue.
- A SHOW_ENTITY value is obtained only through the already exact native
  HoverEvent receiver. Null or non-exact EntityTooltipInfo is refused before
  metadata processing and before native virtual EntityTooltipInfo.serialize.
- Both font and SHOW_ENTITY registry-returned ResourceLocation values are checked
  for exact identity before getNamespace/getPath, and thus before later native
  toString conversion. Their ordinary namespace/path budget accounting is unchanged.
- The EntityTooltipInfo.type value is checked with final Object.getClass before
  BuiltInRegistries.ENTITY_TYPE.getKey can perform inverse-map value hashing.
  Null/non-exact EntityType values now refuse capture; ordinary exact native types
  stay admitted. Null type metadata's prior default-registry fallback is not
  credited as preserved malformed-data capture. No gameplay decision is changed.
- Unsupported nested receivers propagate IllegalStateException through the
  existing capture-failure handling. No catch/intervention/observer/lifecycle,
  incompleteness or twenty-case Fixture behavior is changed.
- Existing limits remain identical: chat depth 8, 32 component visits,
  32 siblings, four translation arguments, 1024 characters per admitted text,
  8192 conservative escaped-text bytes, 4096 reservation plus 1024 per component;
  trace frame/event/identity/case/invocation budgets are unchanged.
- No evidence schema, public or persistent ID, native gameplay state, save schema,
  network protocol, API, central registration, build input, resource or asset is
  changed. Unsupported item/NBT/custom component routes remain unsupported.

Responsibility review: Trace was 498 lines; adding focused receiver tests directly
would exceed 500 and mix native-chat admission with event/frame/state capture.
The permitted focused split leaves Trace at 445 lines and final ChatBounds at 238.
ChatBounds contains only the finite chat traversal and its admission tests.
Trace retains byte-reservation/accounting and all invocation-owned evidence.
The five existing Trace tests remain in place without weakened assertions,
timeouts or budgets. Fixture remains byte-identical to the corrected base.

### Actual pinned registry identifier/value route

Read-only primary inspection does not assume that Forge uses the vanilla
DefaultedMappedRegistry for ENTITY_TYPE. Installed BuiltInRegistries static
bytecode initializes that field with forge(..., "pig", ...), whose selected
overload calls GameData.getWrapper. NamespacedDefaultedWrapper inherits the
NamespacedWrapper getKey route; that method directly delegates to ForgeRegistry.
ForgeRegistry.getResourceKey performs owners.inverse().get(value), and getKey
maps the result through a verbose method handle bound to ResourceKey.location,
otherwise returning defaultKey. These return paths do not prove exact
ResourceLocation implementation identity. ResourceKey's private native
constructor stores the supplied location object; its location getter returns
that field, not a newly normalized identifier. The vanilla MappedRegistry/
DefaultedMappedRegistry route likewise returns holder.key().location or its
default key. Final admission therefore checks the returned identifier, instead
of treating a registry lookup as sufficient receiver qualification.

Separately, EntityType is public/non-final with public constructors, and the
Forge inverse map can invoke value hashing. The final exact-type gate precedes
that lookup. EntityType's constructor invokes the global registry's
createIntrusiveHolder at bytecode 5..14; NamespacedWrapper's implementation calls
validateWrite before native holder creation. A late probe constructor would
therefore mutate native registry state or fail its lifecycle check. This is why
the new test uses a local Object behavior probe at the same gate rather than
constructing/disposing a fake EntityType. No map/holder/class field is reflected
into, private method invoked, registry mutated or subtype execution claimed.

Supporting raw evidence is primary-builtin-registries, primary-registry-wrapper,
primary-defaulted-wrapper, primary-forge-registry and its verbose cohort,
primary-resource-key, primary-mapped/defaulted-registry, primary-entity-type and
primary-entity-type-code. This worker independently inspects them; Task 21's
finding supplies scope motivation through Addendum 23, not a borrowed runtime
result or final independent-review verdict.

## Modified files, commit and exact identities

Final assigned source commit: **d57ecda1f11dab76d882f945b0de606534ef4fb9**.
Additive chain, all normally pushed to origin refs/heads/codex/v1.8.0-sleep-chat-boundary, exit 0:

- 7a36169083f26a7c78dca6db0f53de7235e7a03f, parent 5b451320: named nested receiver fix and split.
- 0552eb65bbf2ca8c55af1a50821c3345c4a2747f, parent 7a361690: Addendum 22 identifier fix.
- d57ecda1f11dab76d882f945b0de606534ef4fb9, parent 0552eb65: Addendum 23 pre-lookup value fix.

No commit is amended or squashed. Original and intermediate development cohorts
remain distinct; neither is described as an independently verified successor.
No other HEAD or Main index/branch was moved by this worker.

| Source | Change | Bytes /lines | SHA256 |
|---|---|---:|---|
| src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java | Modified; delegates preflight | 27593 /445 | 20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f |
| src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryChatBounds.java | Added; final admission and six tests | 15889 /238 | 16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0 |
| SleepBoundaryObservationFixture.java | Unchanged reference | 33987 /497 | 1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |

The original two-file base-to-7a diff is fixed-source-diff.stdout.txt:
17136 bytes, SHA256 2b7f0476288011c21c68988ba6e21b86df1e9ff335f49d36b24125d943325b9f.
Original stat: two files, 167 insertions and 54 deletions. First ChatBounds is
10985 bytes /166 lines, SHA256 639ddfe5d01fddd39b37a6dedf7c3bcda4a28493ee9d1da4c2faa13d17cd4058.
Intermediate ChatBounds is 14094 /212, SHA256
d7c0c3fa4546b1b468eff1624d16ece8c62ff6b82f2156d8e6d4de478dd23b56.
Addendum 22 changes only the helper (48 insertions/2 deletions); Addendum 23 only
the helper (27 insertions/1 deletion). Trace and Fixture do not change in those deltas.

| Fixed raw diff | Bytes | SHA256 |
|---|---:|---|
| 7a to 0552, successor-diff.stdout.txt | 6530 | 8a75ff3b68be42661e8b588882ee0fbb886773499cba1d87481cf8ecda1897b1 |
| 0552 to final, successor-diff-03.stdout.txt | 4177 | d49cadd1587ee7c834ced09328f236f37222ad5d74e6229d387592cc5e881a07 |
| 7a to final, original-to-final-diff.stdout.txt | 8649 | 7009bc6d6af462914aeceab749b49b1040fe1e07e1f61230214016c46c31693f |
| base to 0552, fixed-source-diff-02.stdout.txt | 20291 | 8d64b20e2998ba90b6282422776c22d42b5c990306de2478b2127346a98992d0 |
| base to final, fixed-source-diff-03.stdout.txt | 22112 | c5a3922d14cbdeb3fc3a081c7d46748ad0c6915f61db8076de44707c19b92832 |

Working source blob IDs match committed blob IDs for each cohort. Separate
SOURCE-AND-TOOL-IDENTITIES.json /SOURCE-AND-CLASS-IDENTITIES-02.json /-03.json
preserve source/tool/compiled-class hashes. Compiles occur before their additive
commits on unchanged bytes; COMPILE-02/03-SOURCE-INPUTS.json additionally records
pre-start source hashes and checks unchanged bytes through compilation. None is
presented as executed-test evidence or delivered/accepted source qualification.

## Added tests versus actually executed checks

The following six adapter GameTest methods are added, compiled, **UNEXECUTED**:

1. ordinaryNestedNativeReceiversRemainSerializable: every pinned native click
   Action; native SHOW_ENTITY with absent/present name; ordinary click nested in
   the entity name. Checks actual native serialized fields when eventually run.
2. unsupportedClickReceiversAreRefusedBeforeGetters: subclass action/value getters
   count calls and throw AssertionError if invoked. Exact refusal reason and both
   zero counters are asserted across direct, sibling, translation argument,
   SHOW_TEXT and SHOW_ENTITY-name component routes.
3. unsupportedEntityTooltipReceiversAreRefusedBeforeSerialization: subclass
   serialize/tooltip getters likewise count and throw if invoked. The same five
   routes assert the named admission refusal and zero receiver-behavior counters.
4. ordinaryNativeResourceIdentifiersRemainSerializable: native default/uniform
   fonts and the ordinary PIG registry identifier; no visual/font loading assertion.
5. unsupportedFontReceiversAreRefusedBeforeIdentifierMethods: ResourceLocation
   subclass with counting/throwing namespace/path/string methods, the same five
   component routes and direct shared identifier admission; no registry mutation.
6. unsupportedRegistryValuesAreRefusedBeforeReceiverBehavior: ordinary native
   PIG identity admitted; an owned Object probe with counting/throwing hashCode,
   equals and toString refused by the shared exact-type admission. This is not a
   constructed EntityType subtype inside a component, nor a live registry-key
   replacement. Constructor/global intrusive-holder mutation is deliberately
   avoided; the actual component-to-guard-before-lookup order is static source proof.

These assertions are source evidence and compile evidence only. Their runtime
discovery and results, admitted native serialization and actual before-behavior
refusal evidence still require a separately authorized independent test run.
No native observer command, custom receiver behavior or test method is executed
by the compilation.

Each of the three separately authorized compiles uses:

```text
./gradlew.bat compileJava compileTestJava compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks
```

Actual child argv starts C:/WINDOWS/system32/cmd.exe /d /c gradlew.bat followed by
those exact task/options. Cwd is the exclusive source worktree. Installed
JAVA_HOME/PATH select C:/Program Files/Java/jdk-17.0.7; output confirms Oracle
Java 17.0.7+8-LTS-224, amd64, Gradle 8.8 and unchanged Forge 47.4.10 inputs.
Child TEMP/TMP/java.io.tmpdir are the owned per-cohort leaf _tmp/compile-N; unexpected
_JAVA_OPTIONS/JDK_JAVA_OPTIONS are rejected and parent JAVA_TOOL_OPTIONS is null.

| Compile cohort /source | Actual start/end UTC on 2026-10-09 | Result | C:/D: free before, bytes |
|---|---|---|---|
| compile-01 /7a361690 | 06:28:44.014651 /06:29:28.488853 | Exit 0; 44s; ten executed tasks | 30527553536 /293229953024 |
| compile-02 /0552eb65 | 06:39:52.166321 /06:41:03.544760 | Exit 0; 1m 11s; ten executed tasks | 30516670464 /292576079872 |
| compile-03 /final d57ecda1 | 06:47:13.272277 /06:47:55.491097 | Exit 0; 42s; ten executed tasks | 30512734208 /292565618688 |

Each .command.json retains pre-start UTC, exact argv/cwd, child PID and end UTC.
Every inner Gradle ceiling remains 1800 seconds, with no timeout reached or
enlarged. The separate Python receipt wrappers for cohorts 02/03 have a shorter
180-second helper ceiling, also not reached. All disk counters are >=10 GiB.
Each cohort records absent disposable outputs and no overlapping Java worker,
and uses its own _tmp/compile-01, -02 or -03 generation. Prior receipt files are
never overwritten. All tests remain unexecuted on every cohort.

Raw stdout: 1145 bytes /SHA256
366fd56c9c1c7e9d7965eb19b02e013705d332efda186a3cff6544f7ad225a93.
Raw stderr: 42243 bytes /SHA256
c1ff66ce5e1a4fc75e26f04b94acf39e01957c899eb6da299b3557b1795d2c4d.
Second stdout/stderr are 1148/42628 bytes, SHA256
c1144f1495ef14f64bd196df71c0d7d9752cc7778386c93106242915ed01a598 /
4ec8e8d457a6794611995929457b5bd0188beec897697fc19780a5b9f1022d45.
Final stdout/stderr are 1145/42628 bytes, SHA256
648f754f3446fe85d588e4927283e8dda1899f91fc4390e77233f38f5d6705ec /
c4623753c9db16836016739c0cc40e02fb9521f1681e556232de2a3485dc61ac.
Existing ResourceLocation/deprecation warnings, including adjacent
JackhammerContinuationFixture:78, are retained without suppression or log waiver.
The identifier subtype test necessarily uses the pinned public deprecated
ResourceLocation constructor; its additional warning is retained in cohorts 02/03.

Other actual successful captured commands: sealed-input hashes, fixed governance
Git reads, worktree/status/HEAD checks, installed read-only javap inspection, source/tool/class
hash inventory, git diff --check, assigned-only staging, cached stat/files/check,
commit, normal push, immutable base-to-commit diff/check, source blob comparison,
final empty working/index diffs/status and one native cleanup per separately
authorized compilation generation.
Each has .command.json exact argv/cwd/pre-start/start/end UTC/exit and separate
unmodified stdout/stderr. No test/build/runData/GameTest/runtime command is hidden
inside the helpers.

Preserved failure: preflight-outputs is a native PowerShell parser error, exit 1,
zero stdout and 347-byte stderr (an empty pipeline after foreach). It performed
no cleanup or validation. The separately named preflight-outputs-corrected read
succeeds before compile; the failed receipt remains unchanged.
The later addendum-read capture fully prints Addendum 22 but exits 1 because
Windows PowerShell 5 has no Get-FileHash cmdlet here (562-byte stderr). The
original pwsh transcript hash succeeds; compile_02.py then independently checks
the expected addendum SHA256 and captures the complete text. No tool is installed
or policy changed to resolve this evidence-helper failure.
Early preparation reads/broad listings were transcript-only and some displays
were truncated. Focused full reports/source/governance reads followed. No missing
raw receipt/UTC is reconstructed, and this package is not claimed as a complete
instrumented transcript of every exploratory read.

## Provenance, cleanup and retention

The new source is project-original admission/test code plus extraction from the
existing project corrected Trace. No upstream/fork/Minecraft/Forge code or art
asset is copied into source; no asset import or provenance-ledger change occurs.
Installed platform bytecode is read-only evidence, not a bundled platform JAR.
Existing license declarations remain untouched. All new source/comments are
ASCII and follow the existing English comment conventions.

Each separately authorized generation has one successful native cleanup, exit 0:
cohort 01 at 06:32:41.366172 to 06:32:43.641617 UTC, cohort 02 at
06:42:50.580416 to 06:42:52.882534, and cohort 03 at 06:49:09.635417 to
06:49:11.948914. These are not retries of the previous cleanup: each new compile
records targets absent before recreating its owned output generation. Each
validates resolved absolute containment, ancestor/descendant
reparse absence and zero live overlapping Java processes before deletion. Only
initially absent and subsequently exclusively owned source build (3912 files /
20836588 bytes), source .gradle (16 files /2900360 bytes) and own leaf _tmp
(empty) are removed for cohort 01. Cohort 02 removes build 3913 /20840652 and
.gradle 16 /2900494; cohort 03 removes build 3914 /20842985 and .gradle 16 /
2900624; each own _tmp is empty. All post-delete checks pass and source remains.
No process is terminated, source/world/peer/sealed evidence is deleted, or cleanup
retry/alternate shell is used. Raw cleanup JSON's startCheckUtc is emitted after
removal; real pre-start/start/end times are in cleanup-01/02/03.command.json, not
inferred from that misleading field label.

Retained: assigned source checkout/branch, compact raw command evidence,
fixed diff, hashes, this report and own small evidence helpers. No complete
source/build/world/server export, binary archive or temporary compression is
retained. Shared dependency caches are neither deleted nor treated as this
worker's disposable output. Peer Tasks 06/12 retained-policy-cleanup failures
remain their own records and are not taken over or retried.

## Unfinished scope, risks and Required Gates

Unfinished: independent final actual-diff review and all added/current tests on
d57ecda1; constructed EntityType-subclass/registry injection qualification;
universal chat union/pre-allocation qualification; driver/parser/global token/
encoding freeze;
packaged/current-artifact identity and twenty-row/two-invocation observations;
typed Spawn disk, flush/reacquisition/exit/restart; real TCP/client/decoder,
prior-world/death/coexistence/custom bed/all-host/Space checks; B1/R1/M1/M2/D1,
production cause/enforcement/failure strategy, assets/item/ledger/performance/
GPU/multiplayer acceptance. No gameplay scope or existing native row result is
assumed. Static admission and compile do not authorize runtime launch.

Known risks include unexecuted new tests and their value-probe scope limit, original
strict-validation TIMEOUT and native-log ERROR acceptance gaps retained from
Tasks 11/12, and broader wire/runtime/production boundaries above. No assertion,
budget, timeout, failure semantics or Gate requirement is relaxed.

**Current and inherited Required Gates G0-G9 all satisfied: no.** No Gate PASS,
item/ledger closure, version approval, release, tag or source integration is made.
Next suggestion within v1.8 only: independently review the exact final immutable
patch with retained original/intermediate findings, then issue only separately
authorized finite regression/driver preparation tasks. Existing source and
evidence can be reviewed/reverted by the three additive assigned source commits;
Main is not changed by this worker.

## Evidence and sealing boundary

This external leaf contains the full fixed-source diff, input seals/hashes,
compile stdout/stderr/command, source/tool/class hashes, captured governance,
staged review/commit/push/final Git receipts, the original failed preflight and
successful correction, public receiver inspection and successful native cleanup.
Root must fully read this complete persisted REPORT before any seal. At report
preparation no read acknowledgement or seal is inferred. A later one-time safe
leaf-relative seal must exclude itself/post-seal verification and must not cover
external mutable build/Temp files. This report does not embed its own hash.
