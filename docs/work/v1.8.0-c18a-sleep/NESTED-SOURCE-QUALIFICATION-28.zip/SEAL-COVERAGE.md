# Task28 one-time seal coverage

Root must completely read the persisted final REPORT and acknowledge its exact
SHA256 before `ROOT-READ-ACK.json` is created and the one-time seal runs.
No read acknowledgement or seal is inferred from report preparation.

The manifest covers every safe, case-unique leaf-relative regular evidence file,
including the final report, task/clarification copies, fixed-input/source records,
raw command receipts and streams, retained result XML/logs, original failures,
cleanup inventory/results, compact helpers and Root's read acknowledgement.
It covers no external build/cache/Temp/source path. Evidence is bounded to
50 MiB per file and 100 MiB total. All reparse members are refused.

Exact excluded files:

```text
SHA256SUMS.txt
SEAL-RESULT.json
SEAL-VERIFY-RESULT.json
seal-01.command.json
seal-01.stdout.txt
seal-01.stderr.txt
seal-verify-01.command.json
seal-verify-01.stdout.txt
seal-verify-01.stderr.txt
```

The evidence-only `scratch/` prefix is excluded. Its post-cleanup bookkeeping
directories are empty; no build/world/library archive is placed there.
Excluded seal/verification receipts are separately reported after sealing.
Every covered file remains unchanged once sealed.
