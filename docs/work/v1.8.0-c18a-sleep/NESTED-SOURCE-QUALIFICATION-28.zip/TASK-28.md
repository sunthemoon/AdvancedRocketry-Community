# Final isolated observation source qualification 28

Date: 2026-10-09 UTC. You are a delegated worker/tester, not Root. Do not
delegate or use Claude. Root remains the sole Main integrator and progress
coordinator. Task type: independent finite development qualification.

## Fixed inputs and purpose

Qualify actual source `d57ecda1f11dab76d882f945b0de606534ef4fb9`, src tree
`85f53265bf4ee59b65c4a88664cb2e5e208c583e`. Do not substitute prior source
results. Governance checkpoint is Main `6d1b796e0e93b9953af505dd3fd9b25d47b91d97`.
Read repository mandatory governance/version/test/Gate/parallel documents.
Read the final author Task19 and independent Task21 reports and manifests at:

- D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-20261009-19/
- D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-independent-20261009-21/

Task21 REPORT SHA is
`a7b68817e1b0167536d5681069d450724a624e5ea0ecb258a71fc1eb2cc2353a`;
manifest is `9c4131dbdbfcf34e53583639172e65bd945b17f462fca808dd7acd469ef8d00d`.
Root has completely read this review before this separate runtime assignment.
Review actual source changes and test inventory without presupposing outcomes.

## Ownership

Root will create the fresh detached checkout:
D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28.
Exclusive evidence/scratch write_scope:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/**.
Additionally, only this fresh checkout's disposable build/.gradle/run-data and
compat-test-mod build/.gradle/local-publication outputs may be written by
existing commands. No tracked source/config/test/doc modifications, Main
index/HEAD operations, commit/push, peer/sealed evidence writes or deletions.
Do not use retained Task19/21/11/12 outputs or clean them. No foreign process
termination. Keep task copy and fixed read-input hashes inside your leaf.

## Finite commands

Before sustained commands verify HEAD, source tree, clean index/tracked/source
state, installed JDK17.0.7, Gradle8.8/Forge47.4.10 identities, wrapper/build
inputs and all three observation Java file hashes. Record disk C/D free >=10
GiB, memory and owned/native Java process inventory. Pin child TEMP/TMP and
java.io.tmpdir to your own leaf scratch, disclose frozen environment and reject
unexpected JVM injections. No installations or tool/version changes.

Run each once with the unchanged 2400-second ceiling and existing Gradle tasks:

1. ./gradlew.bat clean build --no-daemon --no-build-cache --rerun-tasks
2. ./gradlew.bat test --no-daemon --no-build-cache --rerun-tasks
3. ./gradlew.bat runData --no-daemon --no-build-cache --rerun-tasks
4. Separate git diff --exit-code and git status, then a second forced runData
   followed by the same independent source-state checks.
5. Existing unfiltered ./gradlew.bat runGameTestServer --no-daemon
   --no-build-cache --rerun-tasks, only after preceding build/test/DataGen and
   source/disk/memory checks permit launch. Do not invoke the twenty-row console
   command, enable its opt-in property, add test filters, or change run configs.
6. Existing offline local publish task and compat-test-mod clean build at
   -ParceVersion=1.20.1-1.8.0-dev --offline, same uncached flags and ceiling.
7. Python -B scripts/validate_repository.py --require-approved-identity with
   unchanged 180-second ceiling; git diff --check.

Trusted existing Gradle dependency resolution is permitted. Helpers in the old
sealed Root11 leaf may be read as command/capture references only; new helpers
must be scoped to this task and bound to actual d57 source, not reused receipts.
No novel observation driver/parser/helper, packaged native launcher, real TCP
or clients, long-load/GPU/remote, prior worlds/restart/death, OS quota/mount,
production dimension/spawn/time/air/policy/API/schema changes are authorized.

Capture complete raw argv/cwd/start/end UTC/exit/timeout/environment/input
hashes and before/after state for commands. Preserve setup and command failures
with separate corrected-cohort records where appropriate; no silent retries,
timeout increases, assertions/filter/cap/log waivers or source fixes. Record
actual JUnit XML test/failure/error/skip counts separately per command; retain
native logs/results and actual discovered test counts, including new test
identities/results when observable. Never infer execution from compile alone.
Collect artifact/API/source/consumer hashes and native ERROR/FATAL inventory
without treating existing errors as accepted. On a source/test failure, report
and do not alter implementation or continue dependent runtime checks blindly.

## Cleanup, evidence and report

Keep only compact logs/receipts/results/XML/input/diff/artifact identity; no
source/library/build/world archive. Check evidence/file sizes before collection.
After own processes/readers finish, inventory your own created disposable
outputs, resolve absolute paths and reject reparses/paths outside the explicit
checkout outputs and own scratch. One native PowerShell -LiteralPath cleanup
attempt per output generation is allowed. Use inline native PowerShell for this
new task if chosen, not any older denied script. Any denial/failure stops cleanup
with retained identities/bytes/paths; no retry, execution-policy bypass,
alternate shell, Root/peer takeover or deletion of source checkout/worlds.

Final REPORT: findings first, fixed source/governance/review hashes, actual
command results and timeouts, tests/artifacts, retained failures, output cleanup,
scope deviations, evidence paths, unfinished obligations and Required Gates.
Do not mark item/ledger/version delivered or authorize integration/observation
runtime. Send Root complete report path/size/hash. Wait for Root's full-read
acknowledgment before one-time sealing, then report covered files/bytes,
manifest hash and all excluded seal receipts. Never edit a sealed input.
