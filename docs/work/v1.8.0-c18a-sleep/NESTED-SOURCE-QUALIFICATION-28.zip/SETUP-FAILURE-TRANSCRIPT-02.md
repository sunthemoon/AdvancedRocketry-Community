# Post-cleanup capture preparation failures

In exec chunk `bdd272`, the attempted capture wrappers named
`post-cleanup-diff` and `post-cleanup-status` both raised before launching
their Git child commands. The successful cleanup had removed the owned
scratch parent. The capture helper attempted `scratch.mkdir()` on a child
without recreating that parent.

Raw exception tails, respectively:

```text
  File "D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-nested-source-qualification-20261009-28\capture.py", line 66, in run
    scratch.mkdir()
FileNotFoundError: [WinError 3] The system cannot find the path specified: 'D:\\GitHub\\ARCE-Task-Evidence\\v1.8.0\\sleep-nested-source-qualification-20261009-28\\scratch\\post-cleanup-diff'

  File "D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-nested-source-qualification-20261009-28\capture.py", line 66, in run
    scratch.mkdir()
FileNotFoundError: [WinError 3] The system cannot find the path specified: 'D:\\GitHub\\ARCE-Task-Evidence\\v1.8.0\\sleep-nested-source-qualification-20261009-28\\scratch\\post-cleanup-status'
```

The surrounding PowerShell read/display command returned 0 because its later
read-only inventories succeeded. Neither Git child ran; no `.command.json`
was created for these failed wrapper preparations. No missing UTC/raw receipt
is reconstructed. The evidence-only scratch parent is recreated for separately
named corrected read-only checks and later sealing metadata. This does not
retry cleanup or recreate checkout build/world outputs. No cleanup retry,
bypass or alternative deletion occurs.
