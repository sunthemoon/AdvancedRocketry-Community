# Task28 owned build-output cleanup clarification 30

Date: 2026-10-09 UTC. Root clarifies Task28's prospective cleanup boundary in
response to the worker's question before any cleanup. Original Task28 remains
unchanged; its one-attempt/containment/reparse/process/receipt/denial-stop rules
still apply. This does not authorize retry of any older denied cleanup.

The fresh detached Task28 checkout's own `build/**` is disposable generated
output, including the newly generated `build/gametest` test world. Once its
command has finished, all required evidence is collected and there are no own
or peer readers/processes using it, this output may be included in the one
native PowerShell literal-path cleanup generation. Likewise only other exact
Task28-owned disposable directories already assigned may be included, with
resolved absolute inventory and containment checks before deletion.

The prohibition protects the source checkout itself, tracked source/fixtures,
all prior/source/player worlds, peers' worlds/outputs and sealed evidence. No
such input may be deleted or transferred. If provenance/ownership of any path
is uncertain, exclude it and report retention. A denial or failure stops this
generation without retry/bypass/alternate shell/Root takeover.
