"""Print complete static documentation/source inputs, without changing them."""
import pathlib
import sys

for supplied in sys.argv[1:]:
    pieces = supplied.rsplit("::", 1)
    path = pathlib.Path(pieces[0])
    print("=== " + str(path) + " ===", flush=True)
    if len(pieces) == 1:
        sys.stdout.buffer.write(path.read_bytes())
    else:
        start, end = (int(value) for value in pieces[1].split(":"))
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if start <= number <= end:
                sys.stdout.buffer.write((str(number) + ": " + line + "\n").encode("utf-8"))
    sys.stdout.buffer.write(b"\n")
