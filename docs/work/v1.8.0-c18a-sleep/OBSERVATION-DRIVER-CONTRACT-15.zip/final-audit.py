"""Audit own static evidence and unchanged named inputs before the one-time seal."""
import datetime
import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
inputs = json.loads((root / "INPUTS.json").read_text(encoding="utf-8"))
checked = []
for row in inputs["files"]:
    path = pathlib.Path(row["path"])
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
    actual = digest.hexdigest()
    checked.append({"path": row["path"], "matches": actual == row["sha256"], "bytes": path.stat().st_size, "sha256": actual})
    if actual != row["sha256"] or path.stat().st_size != row["bytes"]:
        raise SystemExit("named static input changed: " + str(path))
commands = []
for path in sorted((root / "commands").glob("*.json")):
    receipt = json.loads(path.read_text(encoding="utf-8"))
    for key in ("stdout", "stderr"):
        if not (path.parent / receipt[key]).is_file():
            raise SystemExit("missing raw stream: " + str(path))
    if receipt["timed_out"] or receipt["timeout_seconds"] != 180:
        raise SystemExit("inspection command limit issue")
    commands.append({"name": path.name, "exit_code": receipt["exit_code"], "duration_seconds": receipt["duration_seconds"]})
files = []
for path in sorted(root.rglob("*")):
    if path.is_symlink() or path.is_junction():
        raise SystemExit("linked owned evidence")
    if path.is_file():
        if path.suffix in (".jar", ".class", ".zip", ".dat"):
            raise SystemExit("unexpected runtime/source archive")
        files.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size})
if any(row["bytes"] > 50 * 1024**2 for row in files) or sum(row["bytes"] for row in files) > 100 * 1024**2:
    raise SystemExit("evidence size budget")
for name in ("REPORT.md", "PROPOSED-DRIVER-02.md"):
    lines = (root / name).read_text(encoding="utf-8").splitlines()
    if any(line.rstrip() != line for line in lines):
        raise SystemExit("documentation trailing whitespace")
result = {
    "kind": "final-static-audit-not-runtime-tests", "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "static_inputs": checked, "commands_completed_before_this_audit": commands,
    "owned_files_before_this_audit_receipt": files,
    "file_count_before_this_audit_receipt": len(files),
    "bytes_before_this_audit_receipt": sum(row["bytes"] for row in files),
    "root_full_read_and_seal_authorization": "Root coordination message on 2026-10-09: full read of updated REPORT and all 645 proposal lines; one-time seal instruction only, not executable/runtime/Gate approval",
    "unresolved_runtime_qualifications_preserved": ["actual coherent packaged artifacts/consumer", "stdout routing grammar", "supported native component JSON union/depth", "SpawnDimension wire/default projection"],
}
(root / "FINAL-AUDIT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"static_input_count": len(checked), "all_static_inputs_match": True,
                  "completed_command_receipts": len(commands), "nonzero_preparation_receipts": [row for row in commands if row["exit_code"] != 0],
                  "file_count_before_audit_receipt": len(files), "bytes_before_audit_receipt": result["bytes_before_this_audit_receipt"],
                  "documentation_hygiene": "PASS", "runtime_execution": "UNEXECUTED"}, indent=2))
