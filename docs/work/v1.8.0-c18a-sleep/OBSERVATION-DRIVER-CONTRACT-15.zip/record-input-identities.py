"""Record actual static planning inputs, not future runtime artifact identities."""
import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
external = root.parent
repo = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
primary = pathlib.Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
paths = [
    external / "SLEEP-OBSERVATION-DRIVER-CONTRACT-TASK-15.md",
    external / "sleep-observation-driver-design-20261009-09/REPORT.md",
    external / "sleep-observation-driver-design-20261009-09/PROPOSED-DRIVER.md",
    external / "sleep-observation-driver-design-20261009-09/SHA256SUMS.txt",
    external / "sleep-observation-source-independent-20261009-06/REPORT.md",
    external / "sleep-observation-source-independent-20261009-06/SHA256SUMS.txt",
    external / "jackhammer-root-20261009-01/launch_packaged.py",
    external / "jackhammer-root-20261009-01/driver-frozen-02/packaged_driver.py",
    external / "jackhammer-root-20261009-01/packaged-02/seed/stdout.txt",
    external / "jackhammer-root-20261009-01/cleanup_owned.ps1",
    root / "commands/16-source-fixture.stdout.txt",
    root / "commands/17-source-trace.stdout.txt",
    root / "commands/19-fixed-owner.stdout.txt",
    primary,
    pathlib.Path("C:/Program Files/Java/jdk-17.0.7/bin/javap.exe"),
]
for relative in (
    "AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md",
    "docs/04-VERSION-ROADMAP.md", "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md",
    "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
    "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
    "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
    "docs/work/v1.8.0-c18a-sleep/OBSERVATION-ASSIGNMENT-05.md",
    "docs/work/v1.8.0-c18a-sleep/PROPOSED-OBSERVATION-01.md",
):
    paths.append(repo / relative)
rows = []
for path in paths:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
    rows.append({"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()})
result = {
    "kind": "static-planning-inputs-not-runtime-qualification",
    "source_base": "b9bec789978de0df67c93e976239d6d36e41532b",
    "corrected_source": "5b45132000ade1e3c8d130a6b8ccb29f07535124",
    "governance_checkpoint": "48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514",
    "working_AGENTS_is_user_modified": True,
    "future_host_fixture_driver_parser_library_config_identities": "UNASSIGNED / NOT QUALIFIED",
    "files": rows,
}
(root / "INPUTS.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
