# Corrected-source sleep observation driver contract proposal 15

Date: 2026-10-09. Delegated planning worker; status **PROPOSED / STATIC ONLY**.
Root owns integration, OpenPet, source/runtime assignment and acceptance. This
report and PROPOSED-DRIVER-02.md must be read in full by Root before a one-time
SHA256SUMS.txt record seal. A seal is not executable/parser/runtime/Gate approval.

## Findings and implementation questions

1. **The corrected source now supplies an exact inspectable schema, not native
   execution evidence.** Both full immutable classes at
   `5b45132000ade1e3c8d130a6b8ccb29f07535124` were read. The old design's pending
   byte-allocation/setup-marker wording is superseded for this new proposal by
   actual counter-only JsonWriter admission, metadata/chat preflight and
   withInvocation finally coverage. The independent source review's historical
   findings remain preserved; this worker ran no compile/test/observer/injection.
   No prior sealed file was modified.
2. **Root/Brigadier failure cannot be the parser's whole verdict.** A reached
   case-19 observer failure is retained as OBSERVER_INTERVENTION_FAILED and
   HAS_FAILURE_OR_INCOMPLETE_CASE; the command can return zero even if every
   prescribed action/intervention ran. The revised contract separates integrity,
   execution, trace, intervention, native effects, teardown, save and acceptance.
   Missing reachability, unexpected causes and row-20 failure are not waived.
3. **Historical stdout supports raw-prefix output, not an assumed wrapper.**
   The inspected historical packaged stdout line 188 is a raw fixture prefix;
   its fixed fixture and corrected Fixture both use System.out.println. The old
   driver allowed a class/method STDOUT wrapper but that was not the observed
   packaged line. Public LoggedPrintStream/DebugLoggedPrintStream inspection
   supports possible redirection, not all wrapped spellings. Raw-prefix grammar
   is proposed conditional on actual future launcher/library/fixture stdout
   qualification; no logged fallback is inherited and no unassigned discovery
   launch is permitted. Exact pre-executable wrapper qualification remains open.
4. **Saved Spawn describes restored logout state, not each native row.**
   The source restores loaded Spawn through the native public setter before
   remove/logout save. Public installed ServerPlayer bytecode writes coordinate,
   forced and angle tags only with non-null respawnPosition; CompoundTag public
   bytecode identifies int/byte/float tag paths. Exact SpawnDimension codec/wire
   representation and supported component-chat JSON union still need static
   qualification against actual later runtime inputs. Nothing here parses native
   playerdata or generates supposed successful Spawn values.
5. **No later artifact/helper identities are borrowed.** The corrected review's
   compiled-class hashes and jackhammer host/fixture/JDK/library receipts are
   historical/static inputs only. The consumer recipe defaults to an older
   arceVersion and retains a finite exported API list: the later current-source
   publication/consumer/negative-import/reobfuscation checks must actually pass
   with qualified artifacts. TASK-15 creates no artifact qualification manifest.
6. **Defensive driver limits are proposals, not raised source budgets.** The
   unchanged source 64-frame-plus-sentinel, 32-event/128-KiB case,
   128-event/512-KiB invocation and 512-token caps remain exact. Prefix allocation
   excludes snapshot/event/append/output cost. Proposed JSON depth64 does not
   raise source component depth8 and avoids silently inheriting the old generic
   depth32 without serializer-tree proof. Proposed node/collection/raw-log limits
   and the fully summed <=1115 s success /<=1145 s conservative failure ceiling
   need independent review. There is no optional TCP/status phase in this scope.
7. **The owner ancillary answer is accurately scoped.** Exact committed
   OWNER-DECISION-03 conditionally accepts native ancillary dimension behavior
   only with freeze/review, preserves no Earth-night skip/no existing-spawn
   change and does not answer M2 gap/station or hatch writer choices. D1 ancillary
   choice is answered; its actual dimension/spawn/time contract and qualification
   remain open. The twenty-case Overworld observation is not expanded.

These are contract qualifications/questions, not claims of a demonstrated native
gameplay defect. No native outcome, successful-sleep/frame sequence or tested
case count is prefilled in the proposal.

## Complete proposal and inspected scope

[PROPOSED-DRIVER-02.md](PROPOSED-DRIVER-02.md) is the complete new proposal. It
contains actual source keys/types/status/failure unions, all twenty exact names
and source route/control attribution, exact two-actor/twelve-cell fixture inputs,
preparation versus actual actions, corrected caps/measurement scope, finite
launch/phase/failure policy, bounded raw retention/offline parsing, typed native
save/default boundaries, independent fixture/external cleanup and acceptance
exclusions. It intentionally contains no executable driver/parser/tests.

The raw corrected files are 497 and 498 lines. Fixed base-to-source diff changes
only those two new adapterTest files, 995 additions; actual Git stat and blobs
are recorded in commands/35 and commands/36. Both complete adapters, adjacent
AdapterTestMod, fixed root build.gradle and consumer build.gradle were read.
Standard-test source budgets/assertions and production classes were not edited.

Mandatory governance was read: supplied/working AGENTS, PROJECT-CONFIG, PRODUCT,
porting principles, main roadmap, master tests/release gates, active v1.8 version,
ADR-060, post-v1.0 roadmap, quality budgets and parallel coordination. Earliest
incomplete acceptance remains v1.0; its version and fixed status/Gate records
were read. Active development is v1.8 under accepted ADR-060, not inherited Gate
completion. The fixed owner record is read directly from Git checkpoint
`48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514`. Working AGENTS is user-modified and
was left untouched; it is distinguished from committed governance in INPUTS.json.

The complete primary design REPORT/PROPOSED-DRIVER and independent source-review
REPORT were read. Installed public javap was used only for stdout stream public
API and CompoundTag/ResourceLocation public surface; no private member was
invoked/reflected into. Sealed primary ServerPlayer bytecode was inspected for
save/load/default semantics. Historical packaged launch/driver/helper/cleanup
files were read as text only; none were imported or executed.

## Fixed inputs and actually verified hashes

TASK-15 is 3664 bytes, SHA-256
`5e2ce67b85856c32b2abbe162b1b7b3940d93b68d31b6e68ecf88180383a4a56`.

| Read-only input | Actual SHA-256 |
|---|---|
| Prior design REPORT | 83e255f95ddf4a0cd77c8b983093f50c16370cf84d482d8d3a22dc7d6f5857fe |
| Prior design PROPOSED-DRIVER | db8cb7cce70114c6ef16ac9d877f2660334ef2ca60de9c8f1073b0c8e45441ab |
| Prior design manifest | b7e7be0bebd828922a27832475e4ceb6a7e5d33d2f00c9b4b8e16f2cb5f1043a |
| Independent corrected-source REPORT | 3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0 |
| Independent source manifest | 8a15258723e165c3a0e128278134af5ae6c74f2967cf457548ea0ccf9b155de0 |
| Corrected Fixture raw Git source | 1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |
| Corrected Trace raw Git source | 39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0 |
| Owner decision03 raw fixed Git source | a07290d5d9c6b721419ddcc245da2dac5082ad0f0f1958b974928ccd336d795e |

All four assigned REPORT/manifest hashes match. Actual manifests also verified
both design-covered files and all 125 source-review-covered files. Original
seals/bytes remain unchanged. Fixed Fixture Git blob is
`8e02816298e750a0b80f5b164ee2b87871028112`; Trace blob is
`561d169f5005639d814d6ca15d7d2f9a0fc4a77c`. Corrected-source base and governance
SHA remain as assigned. Full static path/length/hash identity inventory is in
[INPUTS.json](INPUTS.json); it labels future artifacts/helpers/config explicitly
unassigned/unqualified, not zero-filled or historical identities.

Historical recipe driver is 16905 bytes, SHA-256
`63b241bc9dad45aac7c723fe3a5d117dbd453ef61365c674852909f70ca67f5e`;
launcher SHA-256
`b9bfc5483705c2e90bbbd309d09cfb6f6dabcae4ef9c8c26307b2ea7098e23a4`.
Historical packaged stdout is 30909 bytes, SHA-256
`7acaab4ff7eacf3c0f8c203d8b0b0f1a9932d8682e1905fbcf05e9608900d294`.
Installed primary mapped Forge JAR was actually rehashed: 19355242 bytes,
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`;
public javap executable is 23696 bytes,
`69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`.
Those are static-inspection inputs, not a later packaged runtime qualification.
No full primary JAR, world, source export, build or server archive is retained.

## Actual commands, failures and capture limits

Material inspection commands are captured under commands/<name>.json with
actual argv, cwd, immediate pre-start UTC, monotonic duration, exit code,
180-second timeout and stdout/stderr raw-file names. Corresponding raw streams
are retained unchanged. The documentation/evidence helpers are capture-command,
read-material, inspect-inputs and record-input-identities; Python ran with -B.
None is a runtime driver/parser/test. The definitive command index/result/size
inventory is PRESEAL-VERIFICATION.json, generated before sealing; the final
inspection's own raw streams are also sealed but are not self-indexed.

Actual material families:

- git status/log/worktree list, fixed ls-tree/show/diff --stat and blob identities.
- Read complete governance/assignment/proposal/reports/source/build/recipe text,
  plus focused previously retained public-bytecode/process/save portions.
- rg file/path discovery and marker/primary-bytecode lookups.
- Verify immutable input manifests/files, hash named static inputs, inspect own
  documentation/evidence inventory and hygiene.
- Installed `javap.exe -public -c -s -classpath <mapped-Forge-JAR>` for only
  DebugLoggedPrintStream/LoggedPrintStream and CompoundTag/ResourceLocation.

Preparation failures are preserved, not reclassified as test failures/success:

- commands/01-governance failed exit 1 because the outer PowerShell expanded
  variables in the intended nested command. Its actual received argv and raw
  parser errors are retained. No intended inner Git/read action executed.
- commands/05-governance failed exit 1 after reading initial documents because
  guessed lowercase docs/versions/v1.8.0.md does not exist. The actual uppercase
  V1.8.0-CLASSIC-CONTENT-COMPLETION.md and remaining governance were read in later
  successful captured commands. The failed receipt remains intact.
- The attempted inspection named 25-wrapper-save-primary was rejected by the
  shell before Python capture began: `'SpawnForced' is not recognized as an
  internal or external command`. No 25 metadata/raw files were created. The
  actual session tool output/attempted command is transcript-only; no pre-start
  UTC/argv/raw reconstruction is invented. A separate captured multi -e rg
  command (28-save-primary) then read the intended material successfully.
- Initial Task-15 Get-Content/tool-metadata discovery preceded the capture helper;
  these initial session tool records are transcript-only, not falsely described
  as pre-start-timestamped raw receipts. Task-15 was subsequently reread and
  hashed in captured commands. apply_patch file-edit receipts and collaboration
  status/messages remain session records, not subprocess command results.
- Broad discovery/combined tool displays sometimes exceeded display budgets;
  complete raw subprocess streams were retained by the helper and source/
  proposal/key schema/save/recipe sections read in complete/focused displays.
  Display truncation is not a claimed truncated raw evidence capture.

No command exceeded its 180-second ceiling. No Gradle, compile, unit tests,
GameTest, native server/client/world, driver, parser/mutation tests, network,
installation, process termination, cleanup, commit or push ran for TASK-15.
The general/current-version Gradle commands remain UNEXECUTED here because the
explicit planning task forbids them; they are not PASS or NOT_APPLICABLE and
their budgets remain unchanged. No tested native count or artifact result exists.

## Ownership, modifications and completion status

Write scope is exclusively
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/**`.
No source/production/test/build/status/ledger/Main/index/HEAD/original seal/peer
file was edited, staged, switched, committed, removed or taken over. Existing
user-owned AGENTS modification and untracked evidence/archive/docs were observed
and left alone. Main/source/peer HEAD/process interests remain released. No
worktree was created or moved, no subordinate agent delegated and no competing
OpenPet event sent. Collaboration status showed Root and two other distinct
workers active; no process/reference ownership was inferred from that listing.

Completed scope: fixed-input integrity, complete static corrected-source/schema/
registration/native-row/teardown reading, historical packaged recipe and public
primary inspection, new full corrected-source proposal/report and raw command
evidence. New/modified files are only this leaf's two Markdown documents,
documentation/evidence helpers, INPUTS.json, command receipts/raw streams and
pre-seal inventory, followed by the explicitly authorized one-time seal.

Uncompleted scope: committed qualified driver/parser/helpers/tests, current
artifact/publication/consumer qualification, exact stdout/component/dimension
wire contracts, independent proposal/executable review, any native twenty-row
run/two-invocation/save evidence, and the broader qualification/acceptance matrix.
No production/save/network/API/provenance policy changed; no tests were added.

Key design decisions: fixed corrected source rather than moving author input;
eight independent result domains; intentional failure preserved without broad
waiver; getter/disk/native-save evidence separated; actual later artifacts required;
raw bounded logging instead of old lossy/unbounded helper; no TCP/status phase;
original native/source/standard-test budgets preserved; exact conditional owner
choice recorded without observation-scope expansion.

Known risks/uncertainties: all seven findings above, native handler/event/control
reachability unobserved, no authenticated receiver/cause proof, cleanup getters
and repetition not exhaustive release proof, unresolved actual artifact/parser/
stdout/component/NBT qualification and no native save/exit/log evidence. B1/R1,
M1/M2 and D1's contract/qualification, prior-world/death/restart/TCP/client/JIT/
custom/mod/monster/item/real-host/air/GPU/multiplayer, production ADR/risk strategy
and item/ledger/asset acceptance remain open.

**Current v1.8 G0-G9 and inherited Required Gates are not all satisfied.** This
planning record makes no PASSED/RELEASED/Gate/item/ledger claim. Within current
v1.8, Root can have an independent reader review this complete static contract,
resolve/freeze the named implementation inputs and issue a separate finite
driver/parser implementation/review assignment. Runtime still requires its own
explicit bounded assignment after executable/artifact qualification.

Root's pre-seal full-read acknowledgement and any seal authorization must come
from the coordination session; neither is inferred by this report. Final actual
sealed hashes are reported separately only after that authorization; the manifest
will not hash itself or cite mutable external build/temp paths as coverage.
