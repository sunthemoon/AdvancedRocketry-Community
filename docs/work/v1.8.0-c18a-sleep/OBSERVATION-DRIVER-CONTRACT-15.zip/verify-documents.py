"""Validate own documentation hygiene and index captured static commands."""
import datetime
import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
documents = []
for name in ("PROPOSED-DRIVER-02.md", "REPORT.md"):
    path = root / name
    data = path.read_bytes()
    lines = data.decode("utf-8").splitlines()
    trailing = [number for number, line in enumerate(lines, 1) if line.rstrip() != line]
    documents.append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                      "lines": len(lines), "trailing_whitespace_lines": trailing})
commands = []
for path in sorted((root / "commands").glob("*.json")):
    record = json.loads(path.read_text(encoding="utf-8"))
    streams = {}
    for key in ("stdout", "stderr"):
        data = (path.parent / record[key]).read_bytes()
        streams[key] = {"name": record[key], "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    commands.append({"receipt": path.name, **record, "streams": streams})
files = []
for path in sorted(root.rglob("*")):
    if path.is_file():
        if path.is_symlink() or path.is_junction():
            raise SystemExit("linked evidence member")
        files.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size})
result = {
    "kind": "pre-seal-static-document-inspection-not-tests",
    "checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "documents": documents, "command_receipts_completed_before_this_check": commands,
    "files_before_this_check_receipt": files, "bytes_before_this_check_receipt": sum(row["bytes"] for row in files),
    "unexpected_native_runtime_artifacts": [row["path"] for row in files if pathlib.Path(row["path"]).suffix in (".jar", ".class", ".zip", ".dat")],
    "initial_uncaptured_command_records": "Task read/tool discovery and shell-rejected attempt 25 are transcript-only; no UTC/streams reconstructed",
}
(root / "PRESEAL-VERIFICATION.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"documents": documents, "command_receipt_count": len(commands),
                  "commands_nonzero_exit": [row["receipt"] for row in commands if row["exit_code"] != 0],
                  "timed_out": [row["receipt"] for row in commands if row["timed_out"]],
                  "file_count_before_check_receipt": len(files), "bytes_before_check_receipt": result["bytes_before_this_check_receipt"],
                  "unexpected_native_runtime_artifacts": result["unexpected_native_runtime_artifacts"]}, indent=2))
if any(row["trailing_whitespace_lines"] for row in documents) or result["unexpected_native_runtime_artifacts"]:
    raise SystemExit("documentation/evidence hygiene issue")
