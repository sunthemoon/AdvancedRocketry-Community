"""Capture a read-only material inspection command for TASK-15 evidence."""
import datetime
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
name, cwd, *argv = sys.argv[1:]
if not argv or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for ch in name):
    raise SystemExit("usage: capture-command.py safe-name cwd argv...")
prefix = root / "commands" / name
prefix.parent.mkdir(exist_ok=True)
if prefix.with_suffix(".json").exists():
    raise SystemExit("capture name already exists")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
monotonic = time.monotonic()
timeout = False
try:
    result = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=180)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, code = error.stdout or b"", error.stderr or b"", None
    timeout = True
prefix.with_suffix(".stdout.txt").write_bytes(stdout)
prefix.with_suffix(".stderr.txt").write_bytes(stderr)
metadata = {
    "argv": argv, "cwd": cwd, "pre_start_utc": started,
    "duration_seconds": time.monotonic() - monotonic,
    "exit_code": code, "timed_out": timeout, "timeout_seconds": 180,
    "stdout": prefix.with_suffix(".stdout.txt").name,
    "stderr": prefix.with_suffix(".stderr.txt").name,
    "purpose": "read-only static inspection; no driver/runtime invocation",
}
prefix.with_suffix(".json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
sys.stdout.buffer.write(stdout)
sys.stderr.buffer.write(stderr)
print("\nCAPTURE_METADATA=" + json.dumps(metadata), flush=True)
raise SystemExit(code if code is not None else 124)
