# Corrected-source packaged sleep observation driver contract 02

Date: 2026-10-09. Status: **PROPOSED / STATIC ONLY / NOT AN EXECUTABLE FREEZE**.
This contract describes a possible later explicitly assigned driver and offline
parser. It supplies no runtime permission, executed result, acceptance verdict,
artifact identity, gameplay policy or owner authorization beyond its quoted
source. No driver, parser or tests are supplied by TASK-15.

## 1. Authority, immutable inputs and separate result domains

Source base is `b9bec789978de0df67c93e976239d6d36e41532b`; corrected fixture source
is `5b45132000ade1e3c8d130a6b8ccb29f07535124`. Governance/owner-record checkpoint
is `48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514`. The two complete Java files were
read using fixed Git objects, not the author checkout. Within this document,
**Fixture** and **Trace** mean SleepBoundaryObservationFixture.java and
SleepBoundaryTrace.java at that corrected source. Raw inputs and hashes are in
INPUTS.json and commands/16-source-fixture.stdout.txt and
commands/17-source-trace.stdout.txt. The old proposal is design input, not a
runtime result or authority for the corrected schema.

The exact owner reply in OWNER-DECISION-03 is: "接受原生维度行为，按上述范围冻结并审核。"
It conditionally accepts the question's native ancillary dimension behavior
while preserving no Earth-night skip and no existing-spawn change. It still
requires exact behavior freeze/review. It does not authorize this driver, new
dimension resources, production sleep/enforcement, a respawn policy, migration,
air-gap/station choice or Gate/item closure. D1's ancillary *choice* is answered;
D1's separate dimension/spawn/time contract and qualification are unfinished.

The possible future observation scope is exactly **one fresh packaged native
process with two sequential console invocations of the same twenty-row native-
Java fixture**, not a restart or retry. Evidence class is exactly
`native-Java simulated transport`. There is no TCP status query, gameplay TCP,
client, prior world, death, restart, inherited/custom bed, monster/item/mod
qualification, off-world natural/spawn/time/air implementation, production cause
decision, global night skip, migration or acceptance campaign in this scope.

Results must remain independently inspectable:

1. Input/artifact/helper integrity and launch identity.
2. Process/command execution and actually attempted native actions.
3. Capture completeness, structural parser findings and retained frame data.
4. Declared interventions and their actually reached attribution.
5. Actual native getters/pose/bed/chat/effects and off/on comparisons.
6. Fixture teardown and external disposable-output cleanup.
7. Native save, typed disk Spawn, logout/reacquisition and process exit evidence.
8. Review/acceptance status; no domain above makes a Required Gate PASS.

No native spawn, sleep, bed, frame, chat or equality result is specified here.
Any later driver RESULT document starts with actual unexecuted/unknown state and
is populated from retained bytes/receipts, not from this inventory.

## 2. Future qualification manifest: actual inputs, not inherited hashes

Before implementation freeze or launch, a later assignment must identify actual
committed driver/parser/tests/helpers, source cohort, published API, host/fixture
JARs, JDK, libraries, argument files and configuration. Reject absent qualification
inputs; do not insert historical values or a provisional source hash in their
place. Static planning INPUTS.json is expressly not that manifest.

| Boundary | Required later qualification |
|---|---|
| Source | Exact tested host and fixture commits; the two corrected source blob identities or independently reviewed subsequent equivalents; fixed governance/task/review hashes; clean assigned source-input diff. A moving Main or unrelated HEAD is insufficient. |
| Executables | Each driver/parser/test/helper byte length and SHA-256, publication commit/archive/manifest identity, exact Git-blob equality and staged/unstaged drift checks. No ambient source import, stale pyc, plugin, dynamic download or unreviewed helper. |
| Host/fixture/API | Actual build/publication/consumer/reobfuscation receipts for the tested source; all JAR lengths/hashes and safe unique ZIP entries/CRC; actual mods.toml IDs/versions and dependency metadata. No assumed jackhammer or compile-only class hashes. |
| Boundary proof | Host lacks adapter-test classes; fixture contains both corrected top-level classes and actual nested classes, under `io/github/sunthemoon/arceadaptertest/`, with no bundled host/API/platform classes or jarjar payload. Actual independent consumer classpath resolves only the published API classifier plus platform; preserve negative internal-import proof. |
| Packaging metadata | The inspected consumer recipe defaults arceVersion to an older value and its exported API list is finite. A later packaging task must select the actual current publication and successfully qualify that unchanged/independently reviewed recipe. No success is inferred from reading build.gradle. |
| Native libraries | Exact source-template identity and finite relative library inventory, lengths/hashes, Forge 1.20.1-47.4.10, win_args.txt and recursively referenced argument files; all referenced paths contained and copied bytes equal. Historical library counts are not acceptance rules. |
| Java/environment | Exact Java 17 executable hash, release/version output/exit, OS/architecture, actual expanded argv/module/classpath, child-only TEMP/TMP/java.io.tmpdir, relevant environment. Reject JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, _JAVA_OPTIONS and ambient argument/agent injection unless explicitly frozen. |
| Containment | All inputs, outputs and existing ancestors have no reparse/junction/symlink; output is absent before creation and neither contains nor is inside input/source/library roots. Input templates contribute libraries only, never world/mods/config. |
| Freshness/space | Both UUID playerdata paths and world absent before launch; no ordinary player or imported world; absent owned temporary root. Check both C: and D: >=10 GiB immediately before launch. Ownership marker binds task/source/artifacts/config and is hashed before/after. |

Input manifests and ZIP inventories must themselves have fixed maximum bytes,
entries, path/string lengths and recursion depths before execution. Proposed
manifest limit is 4 MiB, 4096 file entries, 4096 characters per path and 16 levels
of argument-file recursion with cycle rejection; final reviewed manifests must
fit those bounds. Arguments may not reference arbitrary external files. These
are proposed driver limits, not observed library counts or source caps.

## 3. Native launch and configuration contract

Use the already inspected copied-libraries packaged Forge recipe; never Gradle
runServer, a development launch or arce.gameTestHooks. Exactly the later qualified
host and independent `arce_adapter_test` fixture JARs are installed. Reject
unexpected mods, datapacks, custom dimension definitions and inherited config.

The argv *shape*, with actual verified paths filled before launch, is:

`<Java17> -Xms512M -Xmx2G -Djava.net.preferIPv4Stack=true -Djava.io.tmpdir=<owned-temp> -Darce.sleepBoundaryObservation=true @libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt nogui`

No other fixture opt-in or JVM behavior-changing flag is inherited. The final
manifest must capture actual argv, cwd, environment, start UTC/monotonic time,
PID/process creation identity and spawned-child ownership before waiting.
JDK 17.0.7 in the historical recipe is reference identity only.

Freeze exact ASCII sorted server.properties bytes and eula bytes. The historical
recipe supplies loopback `127.0.0.1`, a newly allocated local port, offline mode,
secure-profile enforcement false, peaceful difficulty, survival, force-gamemode
false, max-players 2, view/simulation distance 2, spawn-protection 0,
sync-chunk-writes true, query/RCON/command-blocks false, normal world, seed 0,
generate-structures false and level-name world. Use a task-specific MOTD and
ownership marker. Record generated COMMON/server config values/hashes and final
properties readback; no silent extra bypass. Loopback binding is not permission
for a status/client connection in this observation-only contract.

Fixture registration is `@Mod.EventBusSubscriber(modid=AdapterTestMod.MOD_ID)`
and RegisterCommandsEvent registration is gated by
`Boolean.getBoolean("arce.sleepBoundaryObservation")`. The exact command is
`arce_sleep_boundary_observe`, with no arguments. Its source predicate requires
permission 4, null entity and `source.withSource(source.getServer()) == source`;
run additionally requires owning server thread, no INVOKING marker, empty
ordinary PlayerList and both absent UUIDs. NULL/RCON/entity sources do not qualify.
The setup ownership marker begins inside `withInvocation`'s try/finally coverage,
including Trace initialization, and is removed by its finally. This opt-in launch
does not execute or prove default-disabled registration; separate standard tests
retain their original budgets.

## 4. Finite phases, failure stop policy and raw retention

The native ceilings remain the established recipe's 300/60/60/90 seconds. A
ceiling is not a measured timing or permission to change GameTest/reference-load
budgets. TASK-15's own inspection commands have a distinct 180-second ceiling.

| Future phase | Ceiling / exact action and evidence |
|---|---|
| Qualification/copy | Proposed 180 s total, including existing 30 s Java-version check. Finite manifest/hash/copy/config/ownership receipts; no install/download. |
| Startup | 300 s to new trusted native Done marker in owned stdout; no startup retry/replacement world. |
| Invocation 1 | One `arce_sleep_boundary_observe`; 60 s total to one trusted bounded structured response. All twenty synchronous rows share that ceiling. |
| Save 1 | One `save-all flush`; 60 s to new native Saved-the-game marker after recorded command cursor. |
| Post-save 1 | Proposed 60 s for bounded response inspection, typed two-file playerdata copy/projection, hash checks and invocation-2 admission. Copy before another invocation can replace files. |
| Invocation 2 | One identical command, only if admission below succeeds; same 60 s. This is a distinct invocation, never replacement evidence for invocation 1. |
| Save 2 | One new `save-all flush`; same 60 s and independent saved-file copies. |
| Post-save 2 | Proposed 60 s for bounded response/disk inspection and comparison. |
| Normal stop | One `stop`; 90 s for native process exit; retain native Stopping-server then new all-dimensions-saved order and actual exit code. |
| Reader completion | Existing 5 s after exit. Reader failure/non-completion is explicit evidence failure. |
| Retain/audit | Proposed 60 s for final raw stdout/latest/debug retention, hashes/config checks and log findings. |
| Offline reparse | Proposed 60 s for independent frozen-parser replay against retained bytes only. |
| External cleanup | Proposed 60 s; one separately authorized own-temporary-target cleanup attempt after readers release interests. |

Successful native waits total <=630 s: 300 + two 60 s actions + two 60 s saves +
90 s stop. With qualification 180, two post-save phases 120, reader 5 and three
60 s final phases, proposed complete success ceiling is <=1115 s. A failed stop
may add existing 15 s terminate +15 s kill +5 s reader waits instead of the
normal reader 5 s; proposed conservative complete ceiling is <=1145 s. There is
no TCP/status phase. The older design's 690/1205 figures are not inherited task
budgets. Stage deadlines and a global monotonic deadline both apply; waiting
cannot restart a deadline or accumulate retries.

Invocation 2 admission requires actual first response integrity/schema, all
twenty primary actions attempted, all prescribed control reachability attributed,
no unresolved unexpected setup/native/capture/teardown failure, complete retained
trace and actual typed save 1. Case 19's reached and exactly correlated declared
observer failure is retained, not a blanket stop or success. A root
HAS_FAILURE_OR_INCOMPLETE_CASE alone does not forbid invocation 2, because that
summary cannot distinguish this intervention from other failures. The parser's
separate attribution, not a relaxed root-outcome assertion, decides admission.

Any unexpected failure/deadline/malformed response/missing attribution stops
further fixture invocations without retry. Persist all receipts and bytes before
raising. If owned stdin remains usable, attempt the remaining already bounded
normal save/stop; total save/stop commands remain at most two/one, not additional
retries. If explicit later authorization permits forced exit, signal only the
exact started process after PID/creation-identity checks, within 15/15/5 bounds.
Forced termination makes normal-save/exit evidence failed/incomplete; it does not
become S2/crash-recovery qualification. Retention/cleanup attempts remain separate
even if process/parse/save failed. No unrelated process is terminated.

The historical CapturedProcess helper decodes text with errors=replace and
retains an unbounded self.lines list. **Neither behavior is inherited.** A later
reviewed driver streams merged stdout/stderr raw bytes with bounded 64 KiB reads,
one bounded candidate-line buffer and fixed marker state. Store command-write
UTC/monotonic times and stdout byte/line cursors separately. Do not inject marker
lines or use only a tail. An oversized line is spooled unchanged while the scanner
discards its in-memory remainder and flags it. At most one current candidate line
of payload cap +4096 bytes is retained in memory.

Proposed retained raw-file ceiling is 24 MiB each for stdout/latest/debug; their
aggregate is <=72 MiB. On crossing a threshold, no parse/runtime success is
claimed; normal save/stop is attempted within existing ceilings and complete raw
bytes remain at an explicitly located owned external retention path with hash.
No silent truncation/rotation removes failure data. Offline parser refuses inputs
outside its frozen size budget. Such a retention breach needs Root disposition,
not permission to claim the <=100 MiB slice budget was met. Compact metadata/
response/typed data are limited to the remaining evidence budget; no file committed
to the repository exceeds 50 MB and total repository slice evidence <=100 MB.

## 5. Exact fixture inventory, preparation and twenty primary actions

Actors are SleepObsA (`3ec99863-f1a1-4ba6-8aaa-390209dbe2d0`) and SleepObsB
(`c5c1adf3-c2b4-4f57-8c98-576bfe5bbcf5`). Native PlayerList.placeNewPlayer owns
registration/playerdata loading; native remove owns logout save. Each actor owns
a Connection(SERVERBOUND) and open EmbeddedChannel; exact actor/Level/connection/
listener/UUID/native list identities are checked, not borrowed from clients.
Loaded Spawn is captured before resets. Actors must be new disposable Overworld
actors with empty inventory and not sleeping at acquisition.

Overworld chunk (0,0), WHITE_BED/EAST, MAIN_HAND, empty both hands. Head
(12,180,12), foot (11,180,12). **Exactly 12 captured/touched cells**:
head/foot, their below/above cells, (11,179,11)/(11,180,11)/(11,181,11), and
(10,179,12)/(10,180,12)/(10,181,12). Initial cells are loaded, BE-free, in bounds
and world border. Fixture getChunkAt is explicit preparation; native login/
teleport may load. This is not no-ticket/no-load proof. No region search.

Homes A (8,180,8), 23.75f/forced true and B (8,180,10), -17.5f/forced false are
declared reset inputs. Day/night uses 6000/18000, temporary doDaylightCycle and
doMobSpawning false. Each row normally wakes only actual sleepers, resets homes
with the public native setter, empties hands/sets survival, installs supports at
Y=179 and air clearance, places exact bed halves and sets time. Row 12 separately
seeds HEAD/6.25f/forced=true before its unforced primary setter.

A teleports to (11.5,180,11.5), except row 9 to (2.5,180,11.5); B to
(10.5,180,12.5), respective home yaws and pitch 0. Each preparation drain uses
the actual owned ClientboundPlayerPositionPacket ID with the public native
accept-teleport handler. This is explicitly simulated, not forged/wire/client
acknowledgement. Native alive, survival, empty hands, day/night, bed halves/
occupancy, mayInteract and canReach(target,1.5) are checked. Ordinary use hit is
Vec3.atCenterOf(target)+(0,-0.25,-0.5), face NORTH, inside false, MAIN_HAND,
sequence 1. Missing preconditions remain setup failure, never a direct-sleep
replacement.

| # | Exact name | Primary route / declared intervention (not native result) |
|---:|---|---|
| 1 | day_head_observer_off | Public handleUseItemOn, HEAD/day, observer off. |
| 2 | day_head_observer_on | Same declared HEAD/day inputs, observer on. |
| 3 | day_foot_observer_off | Public handler, FOOT/day, observer off. |
| 4 | day_foot_observer_on | Same declared FOOT/day inputs, observer on. |
| 5 | night_head_observer_off | Public handler, HEAD/night, observer off. |
| 6 | night_head_observer_on | Same declared HEAD/night inputs, observer on. |
| 7 | night_foot_observer_off | Public handler, FOOT/night, observer off. |
| 8 | night_foot_observer_on | Same declared FOOT/night inputs, observer on. |
| 9 | packet_range_refusal | Public handler HEAD/night; declared native out-of-range setup. |
| 10 | occupied_bed_refusal | Public handler HEAD/night; bed-state occupied=true, not a posed sleeper. |
| 11 | native_admin_forced | Public setRespawnPosition(OVERWORLD,HEAD,6.25f,true,false). |
| 12 | native_same_bed_tuple_unforced | Public same HEAD/6.25f forced=false setter after separately labeled forced seed. |
| 13 | native_null_reset | Public setter(OVERWORLD,null,0,false,false). |
| 14 | nested_native_admin_same_actor | Genuine handler-caused A spawn dispatch; one guarded nested A HEAD/41.5f/forced setter. |
| 15 | nested_native_admin_other_actor | Same outer route; guarded nested B setter. |
| 16 | nested_synthetic_bus_same_actor | Same genuine outer route; guarded synthetic A OVERWORLD/FOOT/forced event bus post, no native setter substitution. |
| 17 | nested_synthetic_bus_other_actor | Same outer route; guarded synthetic B event bus post. |
| 18 | direct_and_forwarded_callbacks | Same genuine outer route; direct callback with synthetic A FOOT/forced=true argument and Consumer-forwarded callback with B FOOT/forced=false argument; not bus posts. |
| 19 | one_shot_observer_failure | Ordinary public handler, separately armed one-shot observer exception; preserve reached/return/throw/partial effects. |
| 20 | independent_admin_after_failure_teardown | Separately registered observer and public forced administrative setter after row 19 teardown. |

ObserverEnabled is false only for rows 1/3/5/7, true for other *begun* rows.
DeclaredRoute is `public native setRespawnPosition` for 11/12/13/20, otherwise
`public native handleUseItemOn`. DeclaredControl is `observer off/on pair` for
1-8 and the exact row name for 9-20. Row 14-18 controls are registered only after
preparation; the source guard fires at most once when the outer event actor is A,
with nestedDepth=1 and an explicit outerEvent/controlReceiver/controlIndex record.
Control precedence/order is not inferred from a desired stack sequence.

Primary labels are `public_native_handleUseItemOn`,
`native_administrative_forced_setter`,
`native_forced_false_same_bed_tuple_setter`, or `native_null_reset` as mapped
above. Nested labels/contexts are `declared_nested_native_administrative_setter`,
`declared_synthetic_bus_post`, `declared_direct_callback_not_bus` and
`declared_forwarded_callback_not_bus`. Actual arrays preserve nested ordering:
an outer action appends in finally and can follow its nested action records.

## 6. Corrected source schema: exact keys, types and failure unions

This is a source schema proposal, not sample native output. The future parser
must make an explicit schema inventory from these exact fixed files; reject
unknown keys/format outside the bounded supported chat JSON union rather than
invent defaults. Incomplete/failure outputs are still retained and analyzed.

Primitive definitions: `token` is integer 1..512 for non-null identities;
source token(null)=0 is allowed only where a field actually denotes nullable
identity. Do not permit arbitrary zero for required owned actor/receiver/class.
`pos` is null or exactly three signed int32 coordinates; `vec` is exactly three
finite JSON numbers; angleBits/yawBits are signed int32 raw Float bits, not
floating conversion. JSON booleans are not integers. Time/counters use actual
integer fields, never numeric strings; timing uses nonnegative signed-int64
unless an actual unsupported measurement is null.

### Root and row

| Object | Required fields | Conditional fields / meaning |
|---|---|---|
| Root | format=`ARCE_SLEEP_BOUNDARY_OBSERVATION_1`; evidenceClass=`native-Java simulated transport`; traceStopped:boolean; cases:20-row array; lifecycle:array; outcome:string; eventCaptureAttempts:int 0..128; persistedEventRecords:int 0..128 | incomplete:string, present when incomplete(reason) first fires. No invocation ID or command return value exists in source output. |
| Row | number:1..20; name:exact table; status:string; preparation/actions/events/outputs/cleanup:arrays | observerEnabled:boolean and observerReceiver:token set by begin(); declaredRoute/declaredControl set by route(); incomplete:true set when the current row becomes incomplete. Unbegun rows do not get those fields. A begun row can still remain UNEXECUTED if failure occurs before the row try block. |

Status values actually assigned are UNEXECUTED, ACTION_RETURNED,
INTERVENTION_NOT_REACHED_OR_NATIVE_RETURNED, OBSERVER_INTERVENTION_FAILED and
SETUP_OR_NATIVE_ACTION_FAILED. UNEXECUTED initialization is not an attempt.
ACTION_RETURNED means the source action returned, not successful sleeping or
reached spawn setter. For 14-18, a returned primary action with no fired control
uses INTERVENTION_NOT_REACHED_OR_NATIVE_RETURNED. Row 19 returning rather than
throwing also uses that status. The OBSERVER_INTERVENTION_FAILED classifier
searches at most eight Throwable causes for the actual exception type, not just
message text.

Root outcome is exactly NATIVE_ACTIONS_RETURNED_NOT_A_GATE or
HAS_FAILURE_OR_INCOMPLETE_CASE. The latter includes the intended row-19 failure,
unexpected row failures, cleanup failure or trace incompleteness. Do not turn the
former into a Gate verdict or demand it when accepting retained intentional
intervention evidence. Count retained events by summing rows; it must equal
persistedEventRecords. eventCaptureAttempts counts successful reserveEvent()
reservations, including failed capture/unattached records; it can exceed retained
records and need not equal them. There is no emitted per-row attempt counter.

### Event, frames and native snapshot

An event record has exactly: event, eventClass, actor, level, spawnLevel,
newSpawn, forced, canceledAtObserver, declaredRoute, declaredControl,
declaredContext, nestedDepth, receiver, nativeAtCallback, frames,
capturePrefixDurationNanos, capturePrefixAllocatedBytes and measurementScope.
Identity fields are scoped tokens; eventClass/spawnLevel/route/control/context/
scope are strings; newSpawn is pos; forced/canceledAtObserver are booleans;
nestedDepth is 0 or 1. Do not infer event authority/cause from declared labels.

Frame union is either `{class:string,classToken:token,descriptor:string,member:string}`
or exactly `{overflow:true}`. At most 64 real frames and one sentinel, only last.
Retained class/descriptor/member are actual metadata, not a required bed stack
sequence or authenticated receiver. Frame descriptors/member spellings must be
bound to actual later reobfuscated artifacts, never copied as expected outcomes.

Normal snapshot has actors:array of owned actor entries. An entry has actor and
spawnGetterProjection; full snapshots additionally have native. Small snapshots
omit native and world. Full world (when level exists) has gameTime, dayTime,
isDay, head and foot. The native player object has exactly uuid, level, levelId,
connection, listener, connected, playerListIdentity, levelListIdentity,
listenerActorIdentity, pose, sleeping, sleepingPos, position, eye, yawBits,
mainEmpty, offEmpty, gameMode, mayInteractHead and reachHead. All identity/reach/
permission booleans are observations, not new privileges. Snapshot only emits
head reach/mayInteract, even for a FOOT-target row; separate source preconditions
validate actual target. Do not invent missing foot permission/packet-ID fields.

Bed snapshot has pos, state, loadedBlockToken, ordinaryWhiteBedIdentity and
receiverQualification=`loaded block identity is not a callback receiver proof`.
Spawn getter projection has dimension:string, position:pos, angleBits:int32,
forced:boolean, source=`native getters, not serialized player NBT`.
The safeSnapshot failure union is the Error object below, not an empty actors
snapshot; any such union is incomplete evidence. Acquisition can have fewer
bound actors and partial lifecycle, and must not be repaired to two.

### Actions, outputs and Error

Action record keys: label:string, declaredContext:string, nestedDepth:0|1,
before:Snapshot|Error, after:Snapshot|Error, outcome:`RETURNED`|`THREW`, plus
failure:Error only for THREW. Preparation=true actions go to preparation;
ordinary/nested actions go to actions. Actions with current=null go to lifecycle.
Do not require a stage key for those lifecycle action records.

System-chat output has actor:token, systemChat:native admitted component JSON,
overlay:boolean and phase=`fixture_preparation_before_public_ack` or
`post_action_case_teardown`. It does not represent a real client's received chat.
Unsupported/oversized native chat capture sets incompleteness; never replace it
with an empty successful response. Exact supported component structural union
must be pinned to the later qualified native serializer before parser freeze.

Error has type:string, message:string, causes:array and suppressed:array.
Each cause has type/message; suppressed entries are strings. Causes/suppressed
are at most eight each; messages/suppressed/first-incomplete reason are clipped
to 256 Java UTF-16 units. No stack trace field is emitted in this object. Native
eventbus raw-log stack traces remain separate evidence. The intentional type is
`io.github.sunthemoon.arceadaptertest.SleepBoundaryTrace$ObserverInterventionFailure`
and message is `declared one-shot observer failure intervention`; classification
requires the actual reached row/action/cause correlation, not message matching
alone. No successful native value is specified by this exception identity.

### Preparation/control, row cleanup and lifecycle record variants

Preparation includes fixture input declaration (kind, bed, facing, head, foot,
dayTime, initialHomeA/B, angleABits/angleBBits, forcedA/B, fixtureBlockFlags,
supportsAndClearanceCount), action records, ordinary packet declaration (route,
hand, target, hit, face, sequence), simulated-ack declaration (kind, actor,
actualOwnedOutboundId), control declaration (kind, outerEvent, controlReceiver,
controlIndex), synthetic completion (syntheticEvent, postReturnedCanceled),
forwarder declaration (forwarderIdentity, callbackReceiver), or caseFailure:Error.
`fixtureBlockFlags` is the actual integer UPDATE_CLIENTS|UPDATE_KNOWN_SHAPE;
supportsAndClearanceCount is the fixed ten non-bed cells. No field is a native
verdict just because it resides in preparation.

Row cleanup variant stage=unregister has kind=`control`|`observer` and either
ownedIdentity/outcome=`RETURNED`, or failure:Error. stage=outbound_drain has
failure:Error. stage=case_listener_and_trace_context_teardown has
observerRegistered/controlRegistered booleans and depthBeforeClear integer.
These booleans are local source ownership flags set before registration attempts,
not independently verified live eventbus membership. trace.end clears callback
state after the cleanup record. Failed unregister sets cleanupBlocked and leaves
later rows UNEXECUTED while final teardown still attempts retained listeners.

Lifecycle variants from acquire/close:

- qualification_limits: unexecuted/scope strings.
- declared_fixture_chunk_preparation: chunkX/chunkZ ints, beforeLoaded boolean,
  ticketQualification string.
- captured_initial_cell: pos/state; exactly twelve for complete acquisition.
- captured_world_preparation: gameTime/dayTime int64, doDaylightCycle/
  doMobSpawning booleans.
- native_placeNewPlayer: actor/connection/channel tokens and loading string.
- native_loaded_spawn and native_logout_save_input: actor token, uuid string,
  spawnGetterProjection; loaded entries occur before resets, logout input before
  native remove.
- fixture_acquisition_or_invocation_failed: failure:Error.
- Cleanup stage plus outcome=`RETURNED` or failure:Error: final_exact_owned_listener_unregister;
  owned_native_wake_<uuid>; owned_native_spawn_restore_<uuid>;
  native_remove_logout_save_<uuid>; own_channel_close_release_<uuid>;
  restore_cell_<BlockPos.toShortString()>; restore_owned_world_time;
  restore_doDaylightCycle; restore_doMobSpawning; verify_owned_world_time_and_rules.
- Current=null action records for teardown_native_owned_wake and
  teardown_fixture_restore_loaded_spawn use the Action union above, not stage.

Do not demand cleanup stages for an actor/cell/world never acquired. Complete
acquisition establishes the exact required teardown inventory; partial ownership
has a separately derived required inventory. Missing lifecycle entries after a
cap/failure are incomplete evidence, not implied completion.

## 7. Bounds and offline parser sequence

Actual unchanged source caps: per case 32 reserved events/128 KiB JSON; per
invocation 128 reserved events/512 KiB JSON including lifecycle/final fields;
64 frames plus one overflow sentinel; 512 invocation identity tokens. Append
checks bytes before attachment using a counter-only JsonWriter/BudgetWriter,
reserving 4096 invocation and 512 case bytes. Frames preflight metadata/descriptor
<=1024 UTF-16 units before descriptor allocation. Chat preflight accepts exact
MutableComponent, supported literal/translatable/empty contents and exact Style;
depth<=8, nodes<=32, siblings<=32 per component, args<=4, per text<=1024 UTF-16
units, total escaped-text estimate<=8192, bounded click/font/insertion and
SHOW_TEXT/SHOW_ENTITY recursion; SHOW_ITEM/NBT/custom content is refused as
incomplete. Drain reads at most 512 iterations and requires packets<512 and
replies<=16 per drain; only first sixteen chats are captured. Four actor drains
per ordinary complete row allow at most 64 chat records, not unlimited output.

The allocation/timing prefix includes ownership validation, StackWalker,
metadata preflight/accounting and frame JSON plus measurement queries. It
**excludes** native snapshot, event-record creation, append accounting and final
serialization. capturePrefixAllocatedBytes is null when public allocation
measurement is unsupported/not already enabled; no global JVM measurement is
enabled. Neither value proves complete observer cost, MSPT or production budget.

Proposed parser defensive bounds, additional to actual caps: JSON nesting 64,
total token/node count 65536, generic object keys<=64, lifecycle<=64,
preparation<=64/actions<=8/cleanup<=16/outputs<=64 per row, generic strings<=4096
UTF-16 units, exact source-specific 1024/256-unit bounds where specified. These
are conservative fixed-source parser limits, not additional source behavior or
measured counts. The earlier proposal's generic depth 32 is not adopted silently:
supported nested component style/hover structures need source-serializer depth
qualification. A proposed 64 global JSON depth does not raise source chat depth8.
If a future actual fixed-source serializer exceeds a proposed defensive bound,
record a contract finding before launch; never increase bounds from a failed run.

Reject malformed UTF-8, duplicate keys, nonfinite numbers, trailing JSON data,
wrong wire/schema/version/types, oversized payload/row/frame/events/tokens,
reordered/duplicate/missing/wrong-name rows and unknown variants. Size/depth/node/
collection checks occur during bounded tokenization before constructing a large
tree. Error/incomplete variants remain distinct from structural malformedness;
the raw result is retained even if the parser rejects it. A globally stopped
trace can still append later preparation/cleanup records: source stopped gates
reserveEvent, not every append. Do not require all later arrays to be empty.

Offline acceptance sequence:

1. Verify actual persisted input/JAR/helper/config/output hashes and ownership.
   Scan all raw stdout for both observation and setup-failure prefixes anywhere,
   with finite memory. Command windows are nonoverlapping byte cursors written
   before sending commands; no stale marker may be reused. Later final replay
   checks full raw stdout, not just windows, for duplicates/strays.
2. The inspected historical packaged stdout emits a **raw line beginning exactly**
   `ARCE_JACKHAMMER_CONTINUATION ` (line 188), and the fixed historical fixture
   uses System.out.println as corrected Fixture.observe does. The baseline
   parser *allowed* a logged STDOUT class/method wrapper but that wrapper was
   not the observed packaged result. Therefore proposed default grammar is
   raw `ARCE_SLEEP_BOUNDARY_OBSERVATION ` + one bounded JSON object + LF/CRLF,
   bound to the exact owned process and command window. No leading whitespace,
   echo, nested quoted marker or unrelated logger is accepted.
3. Raw-prefix acceptance is conditional on later static qualification of the
   actual launcher/library/fixture println bytecode and stdout routing as the
   frozen recipe. The available public LoggedPrintStream API confirms possible
   redirection but does not establish every wrapper; no logged wrapper is
   automatically admitted. If qualification instead requires a wrapped form,
   freeze its exact primary-supported logger/thread/class/method/line grammar
   before executable review; if insufficient, wrapper acceptance remains open.
   Never run an unassigned server or widen grammar after observing a failure.
4. Exactly one trusted structured response is required per completed command,
   exactly two overall for a completed two-invocation run. A setup-failure line
   is failure evidence, not a replacement structured result. Actual pre-Trace
   failure text begins `ARCE_SLEEP_BOUNDARY_SETUP_FAILURE type=` and clips the
   message to 256 UTF-16 units, but is not structured JSON and can contain line
   breaks; retain raw bytes, fail admission and do not manufacture a twenty-row
   object. `withInvocation` can also report later serialization/finalization
   failures, so the prefix is not proof that no acquisition occurred.
5. Apply exact schema/inventory/type/cap checks; verify event totals, token roles,
   A/B UUID mappings and actual identity booleans, route/context/control mapping.
   Off rows have no observed events. Tokens are invocation-scoped diagnostics,
   not authentication or comparable across invocations. Forwarded/synthetic
   event identity may repeat references to the same explicitly declared object.
6. For execution completeness, require one actual primary action per row with
   before/after and RETURNED/THREW outcome; explicit UNEXECUTED or failed setup
   is never counted as completed native attempt. For controls 14-18 require
   actual guarded intervention/outerEvent/controlReceiver/index and expected
   declared nested route records; record missing reachability without fabricating
   an event. Row 19 requires exact reached/attributed intervention evidence;
   row 20 must be analyzed independently rather than waived by row 19.
7. Compare equivalent declared prepared inputs for off/on pairs, then their
   actual primary native output projections. Exclude tokens/timing/diagnostic
   sequence from cross-row native comparisons, not native state fields. Preserve
   equality/differences/insufficient reachability as observations. Equal early
   refusals do not establish setter observation passivity. No stack fingerprint,
   pose/spawn result or successful sleep is prescribed.
8. Analyze fixture teardown independently. Missing/suppressed/capped cleanup or
   nonzero native exit remains failure/incomplete. Correlate raw WARN/ERROR/FATAL,
   client linkage, player-save warnings and exceptions across stdout/latest/debug.
   Any row-19 eventbus diagnostic is only narrowly attributed to actual invocation,
   exact intervention type/cause/window; it is not suppressed or a clean-log Gate
   waiver. Unrelated exceptions/errors remain findings.
9. Verify new native flush markers, retained typed playerdata and actual stop/save/
   exit/reader ordering. Independently rerun only the frozen offline parser on
   retained evidence before external temporary cleanup. No fixture/source helper
   import or native re-launch is involved in offline replay.

Later parser tests must use clearly marked structural synthetic data, not
purported native success outcomes. Mutation coverage includes all schema/type/
byte/event/frame/sentinel/token/depth limits; at-limit and one-over; stale/wrong-
wrapper/duplicate/quoted prefixes; reordered/wrong-name/unexecuted rows; absent
control firing, forwarding aliases and failure unions; intentional versus
unrelated causes; row-20/cleanup/save/stop/exit failures; drifted helper/JAR/config
bytes, linked/overlapping paths and malformed/oversized/partial/mistyped NBT.
Test counts/results are populated only from actual later execution.

## 8. Native save and typed Spawn evidence

Fixture snapshots are explicitly native getters, not player NBT. Close restores
the actors' loaded Spawn through the public native setter before native remove.
Thus disk copies describe teardown/logout-save, **not per-case bed outcomes**.
Restoration is an attributed fixture mutation, not passive observer behavior.

After each completed invocation and new `save-all flush`, copy/hash only the two
exact UUID playerdata files into separate invocation evidence before the next
command. No full world/server/source archive. Proposed retained parser limits:
compressed<=1 MiB/file, expanded<=4 MiB/file, NBT depth<=32, <=65536 total tags/
collection elements, string byte length<=65535, duplicate compound names rejected,
finite numeric payloads and no trailing compressed/NBT data. Use bounded
decompression and typed reading; do not subclass an unreviewed mutable ambient
NBT helper. Exact parser/default mapping must be reviewed before launch.

Preserve native root compound, exact UUID int-array with four signed int32 words,
positive DataVersion int, and for each Spawn tag exact present/absent wire type,
value and Float raw bits. Do not coerce an int to byte/float, accept a boolean as
int, synthesize absent tags, or retain a full-player JSON clone. Unrelated native
player fields are bounded-skipped/validated, not rewritten.

The fixed installed public ServerPlayer save bytecode (sealed primary input and
commands/28,34) writes SpawnX/Y/Z with putInt, SpawnForced with putBoolean and
SpawnAngle with putFloat **only if respawnPosition is non-null**. CompoundTag's
public bytecode in commands/41,42 identifies IntTag, ByteTag and FloatTag. It
encodes SpawnDimension through ResourceLocation.CODEC/NbtOps within that same
non-null branch. Exact dimension wire representation/codec path must additionally
be statically pinned from the later actual runtime before treating an assumed
StringTag as evidence; this task did not execute serialization or saved-data
parsing. Partial or mistyped Spawn sets are findings, never native coercion.

Native load bytecode reads coordinates only if all three numeric tags exist,
then forced/angle and optional decoded dimension; the constructor initializes
respawnDimension=OVERWORLD, with absent position/angle/forced receiving normal
Java defaults. For this fresh-only fixture, a fully absent serialized Spawn set
can be compared to the loaded/restored getter projection by that qualified
absence rule; it is not an old-world migration rule. If a getter has null position
with non-default angle/dimension/forced, omission loses those wire fields: report
non-equivalence rather than pretending serialization preserves them. Unexpected
partial/default/coercion scenarios remain outside native success acceptance.

Compare actual disk Spawn to the preceding native_logout_save_input projection
and loaded-field-restoration evidence, using only statically qualified native
presence/default mapping. Invocation 2's native_loaded_spawn is captured before
resets and can be compared with save 1. This is same-process native logout and
reacquisition of the same UUIDs, not restart/death/per-action persistence or proof
of online-first-save-at-stop durability. Keep files/projections/hashes even on
comparison failure; never modify native NBT or load it manually.

## 9. Synchronous fixture teardown and external cleanup

Source-owned listener unregister attempts use exact object identity, not global
bus clearing. Every row tries control then observer unregister, attempts each
actor drain and records context teardown before trace.end. Failed unregister
blocks later rows; close still attempts every retained listener independently.
Flags/receipts show attempted operations, not exhaustive heap/listener proof.

Close independently attempts: exact retained listeners; trace.end; actual-owned
sleepers' native wake; public native loaded-Spawn restoration and getter checks;
owned native remove/logout save with no removal of an unowned UUID occupant;
owned channel finishAndReleaseAll plus not-open/disconnected check; each captured
cell restore with state-identity/BE-free check; day time/brightness and both
gamerules restoration; final dayTime/gameTime/rule check. Boolean `&=` keeps later
attempts running despite another cleanup failure. Partial acquisition including
native Level registration retains actor/channel ownership. Marker release covers
Trace/Fixture construction failure; trace.clear ends per-invocation retained
tokens/metadata/references after output attempt.

The second invocation can narrowly test reacquisition/command continuation after
the first's synchronous cleanup, and row 20 can observe later administrative use
after row 19's one-shot teardown. Neither repetition nor source finally review
proves exhaustive listener/heap release, concurrency, invisible global effects,
receiver authenticity, transport, JIT/warm/cold coverage or production safety.

External cleanup is separately authorized, not this planning worker's action.
Only a later driver's absent-then-created `_tmp` runtime/world/copied-library
and owned parser-test scratch paths listed in its manifest may be targets. No
source worktrees/build/cache/input worlds/other agents' outputs or sealed evidence
are transferred as deletion targets. Root/independent readers must release their
interests and offline replay finish first.

Use one native PowerShell attempt: resolve exact absolute literal targets under
that task's explicit temporary root; check all existing target/ancestor members
for reparse points; count files/bytes; verify exact owned process exit and no live
reader/process/reference interests; emit pre-delete receipts; Remove-Item with
LiteralPath; record remaining paths/result independently. A policy denial or
failed check retains targets and is never retried through another shell or new
computed target. Preserve compact raw logs/results/native two-file copies before
deletion. TASK-15 creates no temporary runtime cleanup target.

## 10. Remaining prerequisites and review/acceptance boundary

Static source reading resolves the corrected field names, actual twenty routes,
unchanged caps, scope of measured prefix and marker/teardown finally ownership.
It does not produce native observations or packaged artifact qualification.

Unresolved before executable/parser freeze:

- Actual later tested coherent host/fixture/API artifacts and independent consumer
  packaging/reobfuscation/negative-import receipts, not source-review class hashes.
- Exact native serializer component JSON union and its maximum structural nesting;
  proposed defensive parser collection/node/string limits need independent review.
- Complete fixed primary stdout-routing/wrapper qualification for the actual
  libraries/fixture launch; raw-prefix default is recipe-supported, not yet a
  qualified sleep runtime result. No fallback wrapper is implicitly authorized.
- Exact SpawnDimension codec/wire representation and bounded typed-NBT default
  projection proof from the qualified actual runtime.
- Committed driver/parser/helpers/tests, their independent offline mutation-test
  rerun and later explicit bounded process/cleanup assignment.

No standard test budget, assertion or source cap is weakened. clean build, test,
runData plus empty generated diff and unfiltered runGameTestServer remain separate
mandatory regression work; this task executes none. No simulated result replaces
connected-client/native-log/client/visual/provenance/persistence/restart/performance
qualification or current/inherited G0-G9.

B1 cause/indeterminate/coexistence, R1 argument/receiver authenticity, M1 neutral
bed/occupancy-air transition, M2 supplied gap versus station-only/live-access,
D1 exact dimension/spawn/time qualification, production failure strategy/ADR/risk,
item/ledger/asset delivery and full Q01-Q18/S01-S21/R01-R02 remain open. The
conditionally accepted ancillary owner choice is recorded accurately but changes
none of these permissions. Root may submit this static proposal to an independent
reviewer and assign a bounded implementation only after resolving/freezing its
prerequisites; no runtime approval follows from proposal sealing.
