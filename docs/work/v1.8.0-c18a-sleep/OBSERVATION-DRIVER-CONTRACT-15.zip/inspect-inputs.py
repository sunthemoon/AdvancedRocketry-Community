"""Inspect fixed proposal seals and list historical recipe text inputs only."""
import hashlib
import json
import pathlib

base = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
checks = {
    "sleep-observation-driver-design-20261009-09/REPORT.md": "83e255f95ddf4a0cd77c8b983093f50c16370cf84d482d8d3a22dc7d6f5857fe",
    "sleep-observation-driver-design-20261009-09/SHA256SUMS.txt": "b7e7be0bebd828922a27832475e4ceb6a7e5d33d2f00c9b4b8e16f2cb5f1043a",
    "sleep-observation-source-independent-20261009-06/REPORT.md": "3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0",
    "sleep-observation-source-independent-20261009-06/SHA256SUMS.txt": "8a15258723e165c3a0e128278134af5ae6c74f2967cf457548ea0ccf9b155de0",
}
records = []
for relative, expected in checks.items():
    path = base / relative
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    records.append({"path": str(path), "bytes": len(data), "sha256": actual, "expected": expected, "matches": actual == expected})
print(json.dumps(records, indent=2))
for name in ("sleep-observation-driver-design-20261009-09", "sleep-observation-source-independent-20261009-06"):
    leaf = base / name
    manifest = leaf / "SHA256SUMS.txt"
    print("=== manifest " + str(manifest) + " ===")
    print(manifest.read_text(encoding="utf-8"))
    verified = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(None, 1)
        relative = relative.lstrip("*")
        path = leaf / relative
        if not path.resolve().is_relative_to(leaf.resolve()):
            raise SystemExit("manifest escapes leaf")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise SystemExit("manifest mismatch: " + str(path))
        verified += 1
    print("MANIFEST_VERIFIED_FILES=" + str(verified))
leaf = base / "jackhammer-root-20261009-01"
print("=== historical recipe text/receipt listing ===")
for path in sorted(leaf.rglob("*")):
    if path.is_file() and path.suffix in (".py", ".ps1", ".md", ".json"):
        print(str(path.relative_to(leaf)) + " " + str(path.stat().st_size))
if not all(record["matches"] for record in records):
    raise SystemExit("fixed input mismatch")
