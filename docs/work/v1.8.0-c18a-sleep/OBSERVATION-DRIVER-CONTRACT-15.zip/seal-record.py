"""Create the authorized one-time static-record manifest; no runtime action."""
import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
if manifest.exists():
    raise SystemExit("one-time manifest already exists")
files = sorted(path for path in root.rglob("*") if path.is_file())
if any(path.is_symlink() or path.is_junction() for path in root.rglob("*")):
    raise SystemExit("linked evidence member")
if any(path.name == "SEAL-RESULT.json" for path in files):
    raise SystemExit("post-seal receipt exists before seal")
rows = []
for path in files:
    data = path.read_bytes()
    rows.append((path.relative_to(root).as_posix(), len(data), hashlib.sha256(data).hexdigest()))
if sum(row[1] for row in rows) > 100 * 1024**2 or any(row[1] > 50 * 1024**2 for row in rows):
    raise SystemExit("evidence size budget")
payload = "".join(digest + "  " + name + "\n" for name, size, digest in rows).encode("ascii")
with manifest.open("xb") as stream:
    stream.write(payload)
for name, size, digest in rows:
    path = root / name
    if path.stat().st_size != size or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit("post-seal mismatch: " + name)
result = {
    "kind": "one-time-static-record-seal-not-runtime-approval", "verified_manifest_files": len(rows),
    "covered_bytes": sum(row[1] for row in rows), "manifest_bytes": len(payload),
    "manifest_sha256": hashlib.sha256(payload).hexdigest(),
    "report_sha256": hashlib.sha256((root / "REPORT.md").read_bytes()).hexdigest(),
    "proposal_sha256": hashlib.sha256((root / "PROPOSED-DRIVER-02.md").read_bytes()).hexdigest(),
    "coverage_exceptions": ["SHA256SUMS.txt itself", "SEAL-RESULT.json post-seal execution receipt"],
    "all_manifest_entries_verified": True,
}
print(json.dumps(result, indent=2), flush=True)
