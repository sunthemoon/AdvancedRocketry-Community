# One-time seal coverage

This Task26 leaf is new compact independent review evidence. Root must read the
complete final REPORT.md and acknowledge its exact byte count and SHA-256 before
SHA256SUMS.txt is created. ROOT-READ-ACK.json will record the actual coordination
acknowledgement, not a prefilled outcome or newly granted execution authority.

The manifest covers every regular file under this leaf except SHA256SUMS.txt
itself and the exact post-seal SEAL-RESULT.json receipt. The result is excluded
because its actual command exit, streams, end time and manifest hash cannot be
available until the seal operation ends. No wildcard command/receipt exclusion
is used. No pre-existing input package or external runtime/build file is covered.

Before creating the manifest, the one-time operation rejects a pre-existing seal,
absolute or unsafe member names, case collisions, symlinks/reparse points in any
ancestor, out-of-leaf resolution and nonregular members. It hashes retained bytes
with safe forward-slash leaf-relative names, checks every written entry, and
records covered-file/byte totals. Individual files must remain below 50,000,000
bytes and the complete leaf below 100,000,000 bytes. This is this leaf's hygiene
check, not complete slice-wide budget or native capture approval.

COMMAND-INDEX.json indexes receipts existing when it was generated. The later
final-audit receipt and exact post-seal result identify their own actual argv,
cwd, process pre-start/end UTC, exit, stdout/stderr and 180-second child ceiling;
they are not backfilled into the command index. Direct exploratory tool displays
remain the REPORT's disclosed session-only capture limitations.

Covered bytes are immutable after sealing. A subsequent correction requires a
new additive record/package, never editing this report, manifest or old seals.
