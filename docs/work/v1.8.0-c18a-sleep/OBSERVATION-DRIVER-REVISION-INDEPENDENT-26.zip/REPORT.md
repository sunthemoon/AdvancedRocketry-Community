# Independent sleep observation driver contract revision review 26

Date: 2026-10-09 UTC. Fresh delegated independent read-only reviewer, not Root.
Fixed governance: Main `6d1b796e0e93b9953af505dd3fd9b25d47b91d97`.
Final source reference: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Task20's historical schema/source input remains `5b45132000ade1e3c8d130a6b8ccb29f07535124`.

## Findings first, ordered by severity

### R01 - Medium: compressed native-log rotations lack a bounded interpretation policy

Proposal03 keeps the unchanged logger profile, promises all native latest/debug
segments, assigns each family a 16 MiB admission/17 MiB retained maximum, and
requires complete raw diagnostic correlation. See
[proposal03:121, 205-219, 282-289, 702-705, 743-750](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-20261009-20/PROPOSED-DRIVER-03.md#L205).
The actual pinned fmlloader profile has `.log.gz` rotation destinations, including
latest.log's time-based policy, not just ordinary uncompressed byte segments.
See independently extracted
[log-profile.stdout.bin:40-55](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/commands/log-profile.stdout.bin#L40).
The pinned Log4j FileExtension GZ branch constructs GzCompressAction; its execute
method reads the old file into a GZIPOutputStream, and can delete the source.
See
[extension branch:14-28](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/commands/log-gzip-extension-primary.stdout.bin#L14)
and
[compression:90-125, 269-285](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/commands/log-gzip-primary.stdout.bin#L90).

The contract does not say whether the family threshold counts stored compressed
bytes, original uncompressed extents, or both; how a compressed successor maps
to an already retained prefix without omission/double counting; or what bounded
decoded-byte/member/CRC/EOF policy makes its diagnostics inspectable. Scanning
the `.gz` bytes for ASCII diagnostics is not scanning the log payload. The
section 8 single-member policy is explicitly a playerdata/NBT policy with a 4 MiB
expanded-file bound, not a native-log decoding contract. The pipe's 1 GiB read
limit also does not define log-family expansion. A short fresh run is not a
contractual exclusion of crossing a logger time boundary.

Before capture/executable freeze, either define the compressed-log retention,
ordering, expansion and diagnostic-scanning/refusal policy within the existing
budgets, or explicitly refuse every such rotation as incomplete capture while
retaining its bounded actual extents. Do not change the pinned logger, assume a
small compression ratio, or treat absent decoded diagnostics as a clean log.
No rotation, native failure or decompression failure was executed here. This is
an implementability gap in the proposed capture contract, not a gameplay defect.

### R02 - Low: 2049 is a loose identifier envelope, not a reachable source maximum

[Proposal03:568-569](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-20261009-20/PROPOSED-DRIVER-03.md#L568)
says emitted combined font/type IDs may reach 2049 UTF-16 units. Independent
per-field caps alone give that envelope, but the same traversal accumulates both
namespace and path lengths into one `6 * length` budget capped at 8192. See
historical
[Trace:248-251, 277, 287](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/commands/historical-trace.stdout.bin#L248)
and final
[fixed-d57 ChatBounds:34-44](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/commands/source-bounds.stdout.bin#L34).
An identifier whose namespace and path are each 1024 units requires 12288
estimated bytes before its colon or any other admitted text. It cannot pass
this source admission. The global estimate gives the tighter loose ceiling
`floor(8192 / 6) + 1 = 1366` for a combined identifier, potentially lower when
other text consumes the budget. This is analytical source accounting, not an
executed maximum-length native example.

Correct the reachable-maximum wording in a new additive disposition/revision;
old sealed Task17/20 records must remain unchanged. Keeping a separately declared
2049 defensive parser envelope is not itself unsafe, and a blanket combined-ID
1024 limit would still be wrong. Do not describe that looser envelope as an
attainable source boundary or use it as a native at-limit test expectation.

No Critical/High native or production defect is established. R01 remains a
capture-contract prerequisite. R02 is a factual boundary-description correction;
neither finding permits source, logger, parser, test, runtime or cleanup changes.

## Evidence-backed disposition of the revision

The complete 991-line proposal03 and 245-line Task20 report were read, along with
complete proposal15 and sealed Task16/17/19/21 reports. This review does not
accept the entire proposal or grant an executable freeze.

| Boundary | Supported disposition | Remaining qualification |
|---|---|---|
| Task16-R01 encoding/framing | The three explicit UTF-8 properties, pinned-JDK precedence, raw println route, CRLF recipe and exact LF/CRLF structural grammar are now stated. Producer ASCII `?` replacement of isolated surrogates is distinguished from forbidden decoder repair. | Actual coherent JDK/argv/Gson/logger/fixture artifacts and offline Unicode/accounting tests; later owned-process byte route. A static recipe is not observed Unicode output. |
| Task16-R02 storage/failure | Unlimited overflow spool is removed. Three 17 MiB families plus compact 10 MiB and emergency 1 MiB give 62 MiB; admitted families stop at 16 MiB. Obtained/acknowledged/durable bytes, unknown tail, reserve failure, short write/flush/ENOSPC and live-process states are separated. | R01 compressed-log policy; actual reservation/positioned-write/emergency helper, platform hard allocation and stuck-I/O/resource qualification; explicit runtime/process/cleanup authority. |
| Structural JSON | Nodes are values/containers, names are separately counted, duplicates compare decoded UTF-16, container depth starts at1, scalar depth is excluded, lexemes/strings/collections are bounded before tree construction. | Qualified source-Gson row-byte accounting and measured worst-boundary parser RSS; exact implementation/mutations. The 65536 whole-trace cap intentionally may refuse source-valid ordinary traces. |
| Ordinary native chat | Native non-Component args are wire strings, style is flattened, click/SHOW_TEXT/SHOW_ENTITY unions are enumerated, depth64 accommodates the stated ordinary union. | R02 distinction between independent-field envelope and reachable source limit; all global text/visit constraints remain applicable. No universal arbitrary-custom-state or prior5b receiver closure follows. |
| Task16-R03 NBT/gzip | Canonical Java modified UTF-8 applies to all names and strings, including skipped fields. Single pinned-header member, raw-deflate EOF, trailer CRC/ISIZE, exact compressed and expanded consumption, typed UUID/DataVersion/Spawn and counting are specified. | Committed bounded implementation and synthetic boundary/mutation/resource checks; actual transformed native save/writer identities and saved files. This stricter wire admission is not native-load rejection policy. |
| Interventions/correlation | Twenty actual primary attempts, reached controls, row19 exact class/action/cause/window, independent row20, incomplete/error unions and raw diagnostics remain separate. | Actual command cursors/partial writes, native effects, capture and complete diagnostic evidence. No predicted frame fingerprint or native equality/sleep result is inserted. |
| Getter/logout/disk | Loaded Spawn is restored before native remove; getter projections are not NBT. Actual copies and save1-to-second-acquisition comparisons describe teardown/logout state. | Actual stable two-file copies, codec/log/save/flush/exit evidence. No per-row persistence, online-first-save-at-stop, restart or death proof. |

The arithmetic is internally consistent: retained maximum 62 MiB is 65,011,712
bytes; native waits 630 s, whole success 1115 s and conservative authorized forced
failure 1145 s remain unchanged. The lowered 16 MiB threshold is explicitly a new
defensive capture limit, not a larger source cap. Queues contain at most four
64 KiB chunks; the candidate buffer is at most 512 KiB + 4096 bytes. Finite
segment counts and bounded read-volume are
specified. The controller responsiveness and filesystem reservation are targets
awaiting qualification, not guarantees measured by Task20 or this review.

The <=4 GiB OS-enforced runtime allocation is explicitly unassigned. It cannot
be implemented or claimed through size polling or this review. Without a
qualified allocation/reservation/I/O mechanism, native launch remains blocked.
The same is true of process signals and cleanup: a timeout grants no such
authority, and retained live ownership must prevent cleanup.

The reported 17-archive totals and conservative sum in proposal03 add correctly,
but are an earlier checkpoint, not future slice-volume approval. A later Root27
PACKAGING-02 input is independently read/hash-recorded and all 21 actual ZIP
hashes, safe case-unique names, expanded sizes and complete CRC reads are checked
in PACKAGING27-VERIFICATION.json. Current archive totals are 8,075,223 compressed /
42,133,730 expanded bytes. Adding the future 62 MiB reserve gives 73,086,935 bytes
under the compressed repository measure, or 107,145,442 bytes under the conservative
expanded measure. The latter exceeds both 100,000,000 and 100 MiB; the former does
not. Neither subtotal includes this review or the separately assigned final-d57
standard qualification28 evidence. No future sizes, compression or results are
assumed. The future distinct inventory must explicitly use one consistent measure,
account all actual sets/receipts/reserves and block launch if it does not fit.
Proposal03's earlier 97,459,542-byte subtotal cannot be reused as approval. This
review produces no ZIP and claims no complete final slice-volume approval.

The proposed merged stdout/stderr capture also needs precise later executable
terminology: after redirecting both handles into one pipe, bytes have a merged
cursor, not independently recorded stdout origin or cross-stream original order.
The trusted producer route can be pinned statically, but that is different from
per-byte stream provenance. No stream-separated retention or larger budget is
silently added by this report.

## Fixed-source fidelity and successor evidence limits

The final complete Fixture (497 lines), Trace (445 lines), ChatBounds (238 lines)
and full 5b-to-d57
delta were independently read through fixed Git objects. Their captured hashes
match sealed Task19/21; no moving author/source checkout was substituted.

- Fixture bytes are unchanged. Command registration/console/permission/thread/
  non-reentrancy guards, both UUIDs, twelve cells, twenty names/routes, preparation,
  direct/forwarded/synthetic distinctions and independent teardown match the
  proposal. INVOKING.set precedes its try, as proposal03 now correctly says.
- Trace retains the same root/row/event/action/snapshot/error/status unions,
  source caps and prefix-measurement exclusions. Reservations may exceed retained
  events; stopped state does not prevent every later append. Current=null
  teardown actions have no stage. No schema retrofit into Task20 is made.
- Final ChatBounds checks exact ClickEvent and EntityTooltipInfo before their
  inspected receiver behavior, exact identifiers before getters/toString, and
  exact EntityType before registry lookup. This is later source-addressed evidence,
  not a retroactive qualification of5b or intermediate7a/0552.
- Task21 independently reports successful original/final compiles and no remaining
  material defect in its scoped final static patch. Its six new helper tests are
  compiled but UNEXECUTED. The value probe is a local Object at the shared gate,
  not an instantiated/injected EntityType subtype. This reviewer executes no
  compilation or test and does not broaden that conclusion.
- For precise later row19 analysis, final Trace344-348 checks at most eight
  Throwable nodes including the root: root plus the first seven causes. Its error
  serialization338-342 can retain eight causes in addition to the root. The
  eighth serialized cause alone is not the source classifier's positive result.
- Actual loaded/logout getter boundaries are Fixture178-180 and325-342. Source
  finally review and a possible second invocation are not exhaustive heap/listener,
  production receiver/cause or durability proof.

## Independently separable offline work, not an implementation assignment

A narrowly frozen **offline structural parser core** can be considered separately
from the native driver/capture/runtime contract. It consumes only explicitly
bounded caller-supplied/retained bytes and immutable structural metadata; it
does not discover a runtime, import a fixture, load native files manually, access
a live world or decide gameplay success.

Its separable contracts are: strict raw response framing and bounded JSON
tokenization/schema accounting; source-specific structural/error/identity/action
analysis with UNKNOWN native provenance unless receipts establish it; canonical
modified-UTF8, bounded single-member gzip/NBT consumption and compact typed
projection/default comparison. Synthetic fixtures must be labeled structural,
with independent at-limit/one-over/mutation evidence, never purported native
success samples. A future task must freeze supported/refused inputs, the exact
Gson-accounting requirement, outputs, finite wall/RSS/I/O bounds, permissions and
write scope before implementation.

Such an offline core does not require choosing an OS native-runtime quota or
granting process/server/cleanup authority. It also does not cure native pre-call
receiver behavior, prove actual Unicode output, obtain command/save cursors,
decode unspecified compressed-log families, establish copied-library coherence,
or satisfy source/native/Gate acceptance. R01 belongs to the separate log-capture
and diagnostic-analysis contract. No implementation or test assignment is issued
by Task26, and the entire proposal is not accepted merely because this separation
is possible.

## Input identities and actual seal verification

The supplied Task20 REPORT/proposal hashes match exactly. All six input manifests
were independently checked for safe case-unique leaf-relative regular members,
matching every covered hash; original manifests and files were not modified.

| Input | REPORT SHA256 | Manifest SHA256 | Covered files /bytes |
|---|---|---|---:|
| Task15 | d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277 | 6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760 |148 /1491613|
| Task16 | 7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3 | 2aa9ee0dad7fce9a509b9c7b70ae3021f5f4e898138e42c8fee3de099d45b105 |157 /844255|
| Task17 | fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108 | 430acfcab917021c5fb1de7b44ae3a13306db723af13df631573bc0e95316d16 |251 /2640074|
| Task19 final | 982e8bead1495d35ce38f12ad26d63e57200f912c60c933ae3b4ee8a8f10fc8e | df8c9dd1dbc7d487663474c3326ba302178ca4348923539c5bbbf91a7ffbbe3a |314 /1531314|
| Task20 final | 06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6 | b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0 |198 /1089641|
| Task21 final | a7b68817e1b0167536d5681069d450724a624e5ea0ecb258a71fc1eb2cc2353a | 9c4131dbdbfcf34e53583639172e65bd945b17f462fca808dd7acd469ef8d00d |248 /6939786|

All 1316 covered files match. INPUT-SEAL-VERIFICATION.json and
TASK21-SEAL-VERIFICATION.json retain per-member results. Manifest coverage is
not falsely extended to explicitly excluded post-seal receipts or mutable
external outputs. Task20's final seal is verified after its actual creation;
its SEAL-COVERAGE/RESULT records Root's full report/proposal reading. Task19/21
final seals are independently verified, not inferred from a coordination message.

Proposal03 is 68873 bytes/SHA256
`c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680`;
proposal15 is 46009 bytes/SHA256
`628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec`.
Task26, Task20 and Correction24 permissions were read/hash-recorded. Main fixed
disposition18/owner03, all mandatory governance, active uppercase v1.8,
post-v1.0/parallel rules, earliest incomplete v1.0/status and ADR060 were read.
The owner's exact conditional ancillary reply does not authorize this driver,
production sleep/dimension/spawn/time/air or any Gate/item/ledger closure.

Fixed final source raw SHA256 values: Fixture
`1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820`, Trace
`20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f`, ChatBounds
`16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0`.
Historical5b Trace remains
`39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0`.
Full fixed5b-to-d57 diff SHA256 is
`c5a3922d14cbdeb3fc3a081c7d46748ad0c6915f61db8076de44707c19b92832`.

New primary inspection binds fmlloader 267079 bytes/SHA256
`12d27a5d59286ab5fa8cc90cb2c73eb21f4624b765ce2e6408d5e397a6a6699b`, its unique
CRC-validated log4j2.xml 5541 bytes/SHA256
`b51029523df8874beca56c09ce4310bdae7f0885dc1412f8830f62f04c19db83`, Log4j-core
2.19.0 JAR 1864386 bytes/SHA256
`b4a1796fab7bfc36df015c1b4052459147997e8d215a7199d71d05f9e747e4f4` and installed
javap 23696 bytes/SHA256
`69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`.
Only selected XML/bytecode text is retained; no primary JAR or runtime library
is copied. No inspected method is invoked as game/runtime code.

## Commands actually run, failures and capture limits

Captured checks use fixed read-only git show/ls-tree/diff/status/branch/worktree/
rev-parse, rg, absolute Python3.13.15 `-B` compact read/hash/ZIP/seal audits and
installed javap `-c -p` static inspection. Each captured child Git/rg/javap uses
an actual 180-second subprocess timeout and retains separate unchanged raw
stdout/stderr, argv/cwd and immediate pre-start/end UTC in commands/*.json.
Compact evidence operations record their exact Python orig_argv, operation-start/
end UTC, paths/hashes and raw file payloads. For these inline operations the
pre_start_utc field is sampled after Python starts; it is not a recovered external
process-launch timestamp or an enforced child-process watchdog. Their documented
180-second budget was not approached. No captured child reached its 180-second
timeout.
COMMAND-INDEX.json provides actual times/exits/stream hashes, not test counts.

Initial permission/discovery/status/read commands and later direct displays are
session-only tool receipts, not a manufactured historical process log. Broad
status/worktree/file displays and one combined source display truncated; complete
captured bytes and focused/full relied-on source/report/governance reads followed.
One Python outer display used the ambient Windows encoding and rendered Chinese
lossily; its child Git bytes were already captured losslessly and were reread in
explicit UTF-8. This is not evidence about Java stdout.

Preserved preparation gaps: Task21 REPORT was initially absent, recorded as a
FileNotFoundError operation in input-reads.json despite that batch's exit0. Its
later complete sealed report was independently read and verified under a new
receipt, not substituted into the initial failure. A direct guessed Task19
SEAL-COVERAGE.md read is absent; that non-terminating PowerShell error remains
session-only. Its actual existing manifest/RESULT and all covered hashes were
subsequently verified. The initial input-reads summary is generated text, not
claimed as a byte-exact outer Python stdout capture. Missing historical streams/
timestamps are not reconstructed. The package is not a fully instrumented
transcript of every exploratory display.

Root's later Main central-record edits do not change these governance inputs:
all governance reads retain fixed6d Git blobs. PACKAGING-02 is explicitly a
separate later inventory input, not a substitute governance or source checkpoint.

Task20's out-of-scope37-byte placeholder and its policy-denied correction remain
explicitly unresolved in the original report. This reviewer reads its preserved
incident/permission evidence, does not touch the external original, and makes no
cleanup attempt/retry/takeover. Task21's two policy-denied output generations and
older Task06/12 retention limits also remain their own records. Their successful
or failed operations are input evidence, not this reviewer's executions.

No Java execution/discovery, source/compiler/driver/parser/test implementation,
Gradle/unit/GameTest/server/world/playerdata runtime, network/install, allocation/
reservation/quota/mount preparation, process signal, cleanup, source/worktree/
index/HEAD move, commit/push, delegation or OpenPet emission ran under Task26.

## Completion, changes, risks and Required Gate status

Completed scope: complete fixed governance/contracts/reports/final source/delta
reads; actual input/seal identities; independent installed compressed-log primary
inspection; findings and evidence-based scope dispositions; offline/runtime work
separation; compact command evidence and this report. Key decisions preserve
historical5b versus finald57, source/static versus executed outcomes, and native
getter/intervention/teardown/disk/capture/acceptance as separate domains.

Modified project/source/runtime/test files: **none**. Only the exclusive Task26
external leaf contains new report/compact identities/raw command evidence and its
later one-time seal. No persistent evidence helper script is created here; compact
operations use inline Python. No tests are added, modified or executed. Existing
Main AGENTS/untracked user/peer work was observed and left alone. No source/HEAD/
process interest or temporary runtime/build/world target is retained by Task26.

Uncompleted: R01 compressed-log policy and R02 boundary wording; actual committed
parser/driver/helper/offline tests, Unicode/Gson/native writer/resource/I/O and
ownership qualification; source tests/coherent current build/API/consumer
artifacts; actual native twenty-row/two-invocation/effects/capture/teardown/save/
exit/disk/reacquisition; broader B1/R1/M1/M2/D1, production failure ADR/risk,
dimension/spawn/time freeze, clients/TCP/GPU/multiplayer/restart/prior-world/mod/
host/item/ledger/asset/performance/release acceptance. Defensive source-valid
refusals, producer surrogate replacement, unknown retained tails, unassigned
storage/I/O authority and hardware/filesystem loss remain known risks.

Current-version `clean build`, `test`, `runData`, generated `git diff --exit-code`
and `runGameTestServer` are **UNEXECUTED BY TASK26** under explicit read-only
contract-task permissions, not PASS or NOT_APPLICABLE. Historical strict 180-second
TIMEOUT and 62 ERROR/0 FATAL reported in Tasks11/12 remain open input limitations;
they are not rerun, waived or rebound to finald57 by this task. Task21 compiles do
not substitute for those commands or any dedicated/restart/client Gate.

**Current and inherited Required Gates G0-G9 all satisfied: no.** No executable
freeze, proposal acceptance, runtime authorization, source integration, Gate PASS,
owner-scope/ledger/item change, version approval, release or tag is claimed.
Next suggestions remain within v1.8: additive disposition of R01/R02 and the
identified actual-input/resource prerequisites; separately scoped offline-core
contract/task and final-source regression qualifications if Root assigns them;
only later a separately authorized bounded capture/runtime assignment.

Root must completely read this persisted REPORT before authorizing a one-time
safe leaf-relative seal. No acknowledgement or completed own seal is inferred
here. Own covered bytes remain immutable after that seal; subsequent corrections
require a separate additive record, never edits to this or old sealed packages.

D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/REPORT.md
