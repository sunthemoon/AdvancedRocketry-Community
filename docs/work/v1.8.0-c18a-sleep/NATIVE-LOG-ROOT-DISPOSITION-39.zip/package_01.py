"""Rehost actual independent35 and Root36 seals without changing originals."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT = Path(__file__).resolve().parent
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
SPECS = json.loads((OUT / 'INPUT-SEALS-01.json').read_text(encoding='utf-8'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_name(name):
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and '..' not in pure.parts
    assert ':' not in name and '\\' not in name and name not in {'', '.'}


def safe_path(path, leaf):
    assert path.resolve().is_relative_to(leaf.resolve())
    current = path
    while current != leaf.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(), 'st_file_attributes', 0) & 0x400)
        current = current.parent


rows = []
assert len(SPECS) == 2
for spec in SPECS:
    leaf = OUT.parent / spec['leaf']
    safe_name(spec['leaf'])
    safe_name(spec['archive'])
    manifest = (leaf / 'SHA256SUMS.txt').read_bytes()
    assert sha(manifest) == spec['manifest_sha256']
    covered = {}
    folded = set()
    for line in manifest.decode('utf-8-sig').splitlines():
        match = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)', line)
        assert match
        expected, name = match.groups()
        safe_name(name)
        safe_path(leaf / name, leaf)
        assert name.casefold() not in folded
        folded.add(name.casefold())
        assert sha((leaf / name).read_bytes()) == expected
        covered[name] = expected
    assert covered['REPORT.md'] == spec['report_sha256']
    paths = {path.relative_to(leaf).as_posix(): path for path in leaf.rglob('*') if path.is_file()}
    assert set(paths) - set(covered) == {'SHA256SUMS.txt', 'SEAL-RESULT.json'}
    assert len(paths) == len({name.casefold() for name in paths})
    target = DEST / spec['archive']
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            safe_path(path, leaf)
            assert path.stat().st_size < 50 * 1024**2
            archive.write(path, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes()
        expanded = sum(entry.file_size for entry in archive.infolist())
    rows.append({'archive': spec['archive'], 'bytes': target.stat().st_size,
                 'expanded_bytes': expanded, 'sha256': sha(target.read_bytes()),
                 'manifest_sha256': spec['manifest_sha256'], 'covered_files': len(covered),
                 'covered_bytes': sum(paths[name].stat().st_size for name in covered),
                 'excluded_entries': ['SHA256SUMS.txt', 'SEAL-RESULT.json']})

archives = []
for path in sorted(DEST.glob('*.zip')):
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        assert len(entries) <= 4096
        assert len(entries) == len({entry.filename.casefold() for entry in entries})
        size = sum(entry.file_size for entry in entries)
        assert size < 100 * 1024**2
        for entry in entries:
            safe_name(entry.filename)
        assert archive.testzip() is None
    assert path.stat().st_size < 50 * 1024**2
    archives.append({'path': path.name, 'bytes': path.stat().st_size,
                     'expanded_bytes': size, 'sha256': sha(path.read_bytes())})
compressed = sum(entry['bytes'] for entry in archives)
expanded_all = sum(entry['expanded_bytes'] for entry in archives)
assert max(compressed, expanded_all) < 100 * 1024**2
record = {'utc': datetime.now(timezone.utc).isoformat(), 'archives': rows,
          'all_sleep_archives': archives, 'all_sleep_compressed_bytes': compressed,
          'all_sleep_expanded_bytes': expanded_all, 'approval': False}
with (OUT / 'PACKAGING-01.json').open('x', encoding='utf-8') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'all_sleep_archives'}), flush=True)
