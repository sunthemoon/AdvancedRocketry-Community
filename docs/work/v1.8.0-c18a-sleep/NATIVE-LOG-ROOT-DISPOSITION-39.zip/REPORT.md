# Root39 scoped native-log requirements disposition report

## Completed scope and decisions

Root completely reads the final independent35 report: 359 lines /28596 bytes,
SHA256 d96c1ffafa54b86b943adfeed6bb6d038ddad3fc828ed01e393da9cf1f931000,
in contiguous UTF-8 ranges with unchanged hashes before/after. Working-draft
reads did not substitute for that acknowledgment. Actual independent35 seal
followed exact-hash acknowledgment and preserves all failures and limitations.
No new material correction is identified in the narrow requirements candidate.
Root freezes only proposal34's refusal requirements: compressed/ambiguous/lost/
unresolved rotation cannot yield complete capture; no gzip decoding, diagnostic
waiver, capacity expansion or runtime authority is introduced. Medium26R01 is
addressed normatively, not closed by executed refusal detection. Low26R02 wording
is corrected without changing the 2049 defensive envelope. Whole-driver proposal03
is still unadopted and not executable-frozen. Separate D1 outcome freeze remains.

Record commit cd9b54a23b5bf92760b05655a427344d6b620984, parent
9edbcab9ba53f2aaf4861867a916fbe424972c07, is normally pushed on
codex/v1.8.0-classic-content. No test result is rebound to that record commit.

## Uncompleted scope and known risks

Capture implementation, identity/race/EOF/encoder/Unicode/flush/readback,
diagnostics/refusal/resource/I/O qualification, OS-enforced allocation/helper/
quota, exact complete pre-run custody inventory and successful cumulative
admission are open. Twenty observation rows, thirteen D1 rows, B1/R1/M1/M2,
old worlds, clients, items/assets and hatch decisions remain open. Fixed strict
180-second timeout and native28 62 ERROR /zero FATAL are unwaived. Task28's
.log/.xml-only collector does not prove original-directory rotation absence.
Unknown native effects and retained tails cannot become complete/clean results.
Historical missing links, denied retained outputs and external mistaken file
remain untouched. No cleanup, retry, logger/policy/limit change or owner authority
is inferred. Ledger is unchanged at 186 PLANNED /154 REVIEW; all G0-G9 are open.

## Files and tests

Exact staged/committed scope: seven files, 154 insertions /six deletions:
CURRENT_VERSION.md, COMPLETION-PLAN.md, v1.8 implementation log, additive note in
NATIVE-LOG-REVISION-STATUS-36.md, new NATIVE-LOG-DISPOSITION-39.md and two new
NATIVE-LOG-INDEPENDENT-35.zip /NATIVE-LOG-ROOT-PUBLICATION-36.zip archives.
No production, test, build, resource, public API, persistence/schema, provenance,
owner, ledger, risk, ADR or Gate change. Source tree stays
85f53265bf4ee59b65c4a88664cb2e5e208c583e, equivalent to actually qualified
d57ecda1f11dab76d882f945b0de606534ef4fb9. No tests added or executed by Root39.
Task28's actual build/test each 2192 JUnit, two DataGen and 594 required native
passes remain separate source-bound evidence, with documented limitations.

## Actual commands and results

Bounded run_39.py uses the exact pinned sealed Root33 capture algorithm in this
new exclusive output context only. Actual argv/cwd/UTC/exit, 180-second command
ceiling, raw stream hashes and before/after HEAD/upstream/src/index/owner state
are retained in each command receipt. No predecessor is written.

| Command receipt | UTC interval on 2026-10-09 | Exit / result |
|---|---|---|
| package-01 | 08:54:16.882132-08:54:17.662642 | 0; actual seals/payload/CRC/inventory |
| check-02 | 08:56:53.846104-08:56:54.556241 | 0; protected files and added links |
| whitespace-01 | 08:56:55.258192-08:56:55.398193 | 0; git diff --check |
| stage-01 | 08:56:56.088149-08:56:56.192668 | 0; exact own seven files |
| cached-stat-01 | 08:56:56.921938-08:56:56.980458 | 0; seven files, 154 /6 |
| cached-diff-01 | 08:56:57.696403-08:56:57.756489 | 0; full staged Markdown |
| cached-check-01 | 08:56:58.469565-08:56:58.528445 | 0; cached whitespace |
| commit-01 | 08:57:36.954635-08:57:37.237193 | 0; actual cd9b54a2 commit |
| push-01 | 08:57:37.934332-08:57:41.997181 | 0; normal non-forced push |

Runner Chinese presentation is lossy under ambient encoding; actual raw child
Git bytes retain correct UTF-8. Root reads the entire cached-diff-01.stdout.txt
as UTF-8 before committing. Earlier exploratory Root reads outside this leaf
include a missing not-yet-written Task35 report (outer exit1) and guessed
dimension paths/Windows wildcard rg (exit1); corrected actual paths were read.
Those tool-only observations have no invented raw/UTC receipts or test meaning.
Actual final audit/seal are later separate receipts, not backdated into this table.

## Custody and inventory

Independent35 manifest 7eccd2968b90b1a785d605b901be35ff15b7b24a6055915f791e1c31f0c12d28
covers 157 files /1250405 bytes. Rehosted ZIP is 322908 /1268087 compressed/
expanded bytes, SHA256 875b9e8a23ce870dda79de248c50343226a361b455325e6ab66d86990f88a5c7.
Root36 manifest 1931a5d1be5cf16b37dc6a3fae97648b49819513c2b9871f87dee3e3c01236e0
covers 41 files /101624 bytes. Its ZIP is 37477 /105908 bytes, SHA256
2065e73986953d7bfe15d392739d12680d9872e2a87f3ad99c17f8ab556c1327.
Each has exactly manifest self and later SEAL-RESULT.json excluded; archive SHA
covers those too. Actual safe names/reparse boundaries, covered hashes, CRC and
payload equality are verified. No original seal, ZIP or payload is overwritten.

Actual 31 sleep ZIPs total 11959697 compressed /63202254 expanded bytes. The
unchanged 65011712-byte reserve yields 76971409 /128213966; conservative admission
still fails before unmapped loose/later sets. Samples are not atomic launch
inventory, physical/expanded measures are distinct, and no category/deletion/
budget waiver is approved. Individual file and publication slice limits pass.
No full source/library/world/build export or runtime allocation occurs.

## Independent work, evidence and next current-version work

Workers37/38 have fixed9edbcab9/d57, disjoint external writes and were notified
before HEAD movement. Their generic offline-JSON contract/provenance audit remain
in progress for this checkpoint; no outcome, implementation or waiver is inferred.
Root must completely read their actual final reports before custody seal and
separate later disposition. Root39 evidence is this leaf's actual receipts,
INPUT-SEALS-01.json, PACKAGING-01.json, CHECK-02.json, final audit, full-read
acknowledgment and one-time manifest. User AGENTS.md remains untouched/unstaged,
SHA256 c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
All current-version Required Gates satisfied: NO. No tag, release or feature
delivery. Next v1.8 work: separately review/freeze any acceptable offline-core
contract and attribute retained diagnostics, while retaining all native admission
and production prerequisites.
