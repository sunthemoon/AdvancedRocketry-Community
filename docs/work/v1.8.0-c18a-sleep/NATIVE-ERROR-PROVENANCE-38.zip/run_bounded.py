"""Read-only child command custody for Task38 (fixed 180-second timeout)."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

LEAF = pathlib.Path(__file__).resolve().parent
CWD = pathlib.Path(r"D:\GitHub\AdvancedRocketry-Community")
LIMIT = 256 * 1024


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    number, *argv = sys.argv[1:]
    if argv[0] == "python":
        argv[0] = sys.executable
    prefix = LEAF / ("command-" + number)
    receipt_path = prefix.with_suffix(".json")
    if receipt_path.exists():
        raise RuntimeError("Command identity already used")
    start = utc()
    with prefix.with_suffix(".stdout.txt").open("xb") as stdout, prefix.with_suffix(".stderr.txt").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=str(CWD), stdout=stdout, stderr=stderr)
        timed_out = False
        try:
            returncode = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            returncode = process.wait()
    end = utc()
    streams = {}
    for name in ("stdout", "stderr"):
        path = prefix.with_suffix("." + name + ".txt")
        raw = path.read_bytes()
        streams[name] = {"file": path.name, "length": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        if len(raw) > LIMIT:
            raise RuntimeError("Child stream exceeds task limit; no output truncation permitted")
    receipt = {"argv": argv, "cwd": str(CWD), "start_utc": start, "end_utc": end, "timeout_seconds": 180,
               "timed_out": timed_out, "exit_code": returncode, "streams": streams}
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt))
    for name in ("stdout", "stderr"):
        raw = prefix.with_suffix("." + name + ".txt").read_bytes()
        if raw:
            print("--- " + name + " ---")
            print(raw.decode("utf-8", errors="replace"))
    sys.exit(0 if returncode == 0 and not timed_out else 1)


if __name__ == "__main__":
    main()
