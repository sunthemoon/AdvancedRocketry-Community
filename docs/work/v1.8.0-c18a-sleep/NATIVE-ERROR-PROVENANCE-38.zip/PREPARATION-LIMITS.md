# Preparation and capture limits

These are Task38 audit preparation observations, not native qualification failures.
No reconstructed child timestamps or raw command receipts are assigned to them.

- Initial task read/hash, absence check, own-leaf creation and helper creation were
  host-tool preparations before the bounded child wrapper existed. Their evidence
  is the session tool transcript; independently repeated task read/hash is
  command-081. The creation check was successful before any own-leaf write.
- A Windows Python shim lost quoting around a regex containing `|`. The host
  transcript reported `'checkpoint.?36' is not recognized as an internal or
  external command, operable program or batch file.` No successful instrumented
  command is attributed to that failed preparation. A later, separate preparation
  similarly reported `'sha256' is not recognized as an internal or external
  command, operable program or batch file.` Their child UTC, complete split raw
  streams and child argv are unavailable; the quoted errors are transcript
  excerpts, not raw stream files. Later calls use the resolved Python executable;
  individual numbered receipts preserve the argv actually given to each child.
- Command-009 exits 128: the guessed lowercase version-document Git path did not
  exist. Command-016 reads the actual uppercase version document.
- Command-019 exits 1 at the listing helper's 400-entry limit. It is a stopped
  scoped evidence-leaf listing, not a complete successful inventory. Later
  immediate-directory listings and explicit manifest verification are separate
  commands; no mutable world/cache tree was inventoried.
- Command-044 exits 128: a guessed ADR-064 basename did not exist. Command-048
  reads the actual fixed-tree ADR path.
- Initial console display misdecoded UTF-8. The persisted raw Git streams were
  unchanged. The wrapper was updated to display UTF-8; relevant governance was
  reread. Host display truncation is not raw stream truncation: retained numbered
  child streams remain complete, and targeted rereads supply missing display
  portions.
- A post-context-restoration host-tool immediate own-leaf listing has a tool
  transcript but no numbered child receipt. It only displayed names and lengths,
  made no write, and is not used as a checksum or custody result.

All numbered child receipts retain their actual start/end UTC, argv, cwd, exit
status and separate raw stdout/stderr hashes. Historical Task28 runtime timing is
not substituted for this audit's timing. No preparation error is relabeled PASS.
