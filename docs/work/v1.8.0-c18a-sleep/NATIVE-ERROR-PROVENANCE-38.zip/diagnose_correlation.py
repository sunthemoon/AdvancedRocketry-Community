"""Display retained header formatting to assess a static audit assertion failure."""
import json
import pathlib
import sys

sys.stdout.reconfigure(encoding="utf-8")
leaf = pathlib.Path(__file__).resolve().parent
data = json.loads((leaf / "OCCURRENCES.json").read_text(encoding="utf-8"))
for name, value in data["logs"].items():
    print(name)
    for row in value["occurrences"][:2]:
        print(row["header"])
