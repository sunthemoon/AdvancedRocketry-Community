# One-time leaf seal coverage

The one-time seal is allowed only after Root's complete-read acknowledgment of
the exact final REPORT bytes/hash is received and recorded in ROOT-READ-ACK.json.
The seal does not imply acceptance, a production/logging waiver or a Gate PASS.

Coverage is every immediate, leaf-relative regular evidence file except these
precise self-referential output names:

- SHA256SUMS.txt
- SEAL-RESULT.json
- SEAL-VERIFY-RESULT.json
- command-096.json, command-096.stdout.txt, command-096.stderr.txt
- command-097.json, command-097.stdout.txt, command-097.stderr.txt

There are no directory-prefix exclusions, mutable external file references,
world/cache/build/source exports or source-library binaries. Case-colliding
members, non-regular files, nested directories or reparse points are refused.
All path ancestors are checked for reparses. The leaf remains below 4 MiB and
each child raw stream below 256 KiB. Reports, own helpers, failed receipts,
selected excerpts, occurrence mappings, preparation limits, audit correction,
this coverage record and Root's acknowledgment are manifest-covered.

Seal creation and verification are separate commands, each fixed at 180 seconds
with raw split stdout/stderr and true argv/cwd/UTC/exit receipts. The seal/result
and verification/result identify actual manifest/report hashes and measured
bytes. They are excluded solely to avoid self-reference. Covered files are not
edited after sealing. No external sealed input is written or resealed.
