# Compact occurrence and source mapping

Tested source: d57ecda1f11dab76d882f945b0de606534ef4fb9.

One row is an ordered cross-view correlation, not proof of one independent failure.
Every view retains its own occurrence/line. The 62 rows correspond to 186 raw ERROR headers.
stderr has zero ERROR/FATAL headers; all three main views have zero FATAL headers.

| Row | stdout line | latest line | debug line | Observed stdout clock | Group |
|---:|---:|---:|---:|---|---|
| 1 | 273 | 228 | 1048 | 15:27:12 | P-BIND-RETRY |
| 2 | 324 | 279 | 1099 | 15:27:12 | P-BIND-RETRY |
| 3 | 724 | 679 | 1501 | 15:27:29 | RECIPE-DISABLE |
| 4 | 725 | 680 | 1502 | 15:27:29 | RECIPE-DISABLE |
| 5 | 726 | 681 | 1503 | 15:27:29 | RECIPE-DISABLE |
| 6 | 904 | 859 | 1681 | 15:27:35 | SAT-FLUSH |
| 7 | 938 | 893 | 1715 | 15:27:35 | SAT-FLUSH |
| 8 | 1032 | 987 | 1809 | 15:27:38 | P-PORT |
| 9 | 1083 | 1038 | 1860 | 15:27:38 | P-PORT |
| 10 | 1120 | 1075 | 1897 | 15:27:38 | P-PORT |
| 11 | 2010 | 1965 | 2787 | 15:27:47 | SAT-DISCOVERY |
| 12 | 2500 | 2453 | 3307 | 15:28:05 | MENU-VERSION |
| 13 | 2501 | 2454 | 3322 | 15:28:05 | MENU-VERSION |
| 14 | 2502 | 2455 | 3337 | 15:28:05 | MENU-VERSION |
| 15 | 2503 | 2456 | 3352 | 15:28:05 | MENU-VERSION |
| 16 | 2504 | 2457 | 3367 | 15:28:05 | MENU-VERSION |
| 17 | 2505 | 2458 | 3382 | 15:28:05 | MENU-VERSION |
| 18 | 2506 | 2459 | 3397 | 15:28:05 | MENU-VERSION |
| 19 | 2507 | 2460 | 3412 | 15:28:05 | MENU-VERSION |
| 20 | 2508 | 2461 | 3442 | 15:28:05 | MENU-VERSION |
| 21 | 2509 | 2462 | 3457 | 15:28:05 | MENU-VERSION |
| 22 | 2510 | 2463 | 3472 | 15:28:05 | MENU-VERSION |
| 23 | 2511 | 2464 | 3487 | 15:28:05 | MENU-VERSION |
| 24 | 2512 | 2465 | 3502 | 15:28:05 | MENU-VERSION |
| 25 | 2513 | 2466 | 3517 | 15:28:05 | MENU-VERSION |
| 26 | 2514 | 2467 | 3532 | 15:28:05 | MENU-VERSION |
| 27 | 2515 | 2468 | 3547 | 15:28:05 | MENU-VERSION |
| 28 | 2550 | 2503 | 3582 | 15:28:08 | P-BIND-GATE |
| 29 | 2601 | 2554 | 3633 | 15:28:08 | P-BIND-GATE |
| 30 | 2638 | 2591 | 3670 | 15:28:08 | P-BIND-GATE |
| 31 | 2689 | 2642 | 3721 | 15:28:08 | P-BIND-GATE |
| 32 | 2726 | 2679 | 3758 | 15:28:08 | P-BIND-GATE |
| 33 | 3603 | 3555 | 4645 | 15:29:07 | P-CONTROLLER |
| 34 | 3654 | 3606 | 4696 | 15:29:07 | P-CONTROLLER |
| 35 | 3691 | 3643 | 4733 | 15:29:07 | P-CONTROLLER |
| 36 | 4574 | 4526 | 5616 | 15:29:21 | GUARD-RECIPE |
| 37 | 4615 | 4567 | 5657 | 15:29:21 | GUARD-RECIPE |
| 38 | 4655 | 4607 | 5697 | 15:29:21 | GUARD-RECIPE |
| 39 | 4696 | 4648 | 5738 | 15:29:21 | GUARD-RECIPE |
| 40 | 4736 | 4688 | 5778 | 15:29:21 | GUARD-RECIPE |
| 41 | 4777 | 4729 | 5819 | 15:29:21 | GUARD-RECIPE |
| 42 | 4817 | 4769 | 5859 | 15:29:21 | GUARD-RECIPE |
| 43 | 4858 | 4810 | 5900 | 15:29:21 | GUARD-RECIPE |
| 44 | 4898 | 4850 | 5940 | 15:29:21 | GUARD-RECIPE |
| 45 | 4939 | 4891 | 5981 | 15:29:21 | GUARD-RECIPE |
| 46 | 4979 | 4931 | 6021 | 15:29:21 | GUARD-RECIPE |
| 47 | 5020 | 4972 | 6062 | 15:29:21 | GUARD-RECIPE |
| 48 | 5060 | 5012 | 6102 | 15:29:21 | GUARD-RECIPE |
| 49 | 5101 | 5053 | 6143 | 15:29:21 | GUARD-RECIPE |
| 50 | 5141 | 5093 | 6183 | 15:29:21 | GUARD-RECIPE |
| 51 | 5182 | 5134 | 6224 | 15:29:21 | GUARD-RECIPE |
| 52 | 5222 | 5174 | 6264 | 15:29:21 | GUARD-RECIPE |
| 53 | 5263 | 5215 | 6305 | 15:29:21 | GUARD-RECIPE |
| 54 | 5303 | 5255 | 6345 | 15:29:21 | GUARD-RECIPE |
| 55 | 5344 | 5296 | 6386 | 15:29:21 | GUARD-RECIPE |
| 56 | 5384 | 5336 | 6426 | 15:29:21 | GUARD-RECIPE |
| 57 | 5425 | 5377 | 6467 | 15:29:21 | GUARD-RECIPE |
| 58 | 5465 | 5417 | 6507 | 15:29:21 | GUARD-RECIPE |
| 59 | 5506 | 5458 | 6548 | 15:29:21 | GUARD-RECIPE |
| 60 | 5584 | 5536 | 6626 | 15:29:35 | GUARD-COMBUSTION |
| 61 | 5676 | 5628 | 6718 | 15:29:44 | GUARD-SOLAR |
| 62 | 5913 | 5865 | 6955 | 15:30:02 | SAT-BLOCKED |

## Group definitions and actual source joins

- P-BIND-RETRY / P-BIND-GATE: runtime BindingSaveFailure.accept:214 and exerciseSavedBinding:117; source excerpts command-051. Each EventBus/ChunkMap pair is one injected native save failure. The later root mismatch is only an antecedent/coordinate association, not a direct test stack.
- P-PORT / P-CONTROLLER: runtime OneShotSaveFailure.accept:226 and exerciseRetry:109; source excerpts command-052. Roots diagnostics use PrecisionAssemblerManager:398-402, excerpt command-054.
- RECIPE-DISABLE: DeferredProcessDefinition:34-47 and BoundedItemIngredientCodec:83-84 emit/construct the actual diagnostic. RecipeSignatureMigrationGameTests:52-81,408 is a source-compatible unbound-tag candidate; no runtime method/object receipt is retained. Commands 047,060,061,072.
- SAT-FLUSH: runtime SatelliteReviewGameTests:86,89 plus explicit EXPECTED_SAVE_FAILURE marker; source excerpt command-059. CheckedSavedDataFile fails on non-regular staging path.
- SAT-DISCOVERY: runtime DiscoveryRecoveryGameTests:72 plus explicit EXPECTED_SAVE_FAILURE marker; source excerpt command-062.
- SAT-BLOCKED: runtime SatelliteReviewGameTests:134 and SatelliteMissionSavedData.requireOperational:390; source excerpts commands 059,079.
- MENU-VERSION: observed eight rejected versions per side in debug.log, command-072. RecipeMenuChannelGameTests:21-48,63-67 is a one-test batch with matching reflected validator sequence, command-046. Strong batch/value/source correlation, not a retained method stack or real TCP peer handshake.
- GUARD-RECIPE: runtime RecipeSignatureSaveEventGameTests.rejected:62 and method:37/40 alternate. Twelve ID/root combinations produce 24 direct synthetic event posts. Commands 055,064 and stack excerpts 040,073.
- GUARD-COMBUSTION: runtime CombustionGeneratorGameTests:252 posts the outgoing save event directly and catches the rejection; command-056.
- GUARD-SOLAR: runtime SolarGeneratorGameTests:388 posts the outgoing save event directly and catches the rejection; command-057.
- Guard failure site: GuardedChunkSaves.fail:91-93; first recipe attempt uses refuse:56-60, second uses beforeSave:48-52. Command-058. These direct posts are not ChunkMap writer acknowledgements.

All file hashes, exact headers and prior-batch observations are in OCCURRENCES.json. Primary stack excerpts are commands 036-040,073-074.
All source excerpts hash the complete fixed Git object in memory and retain only selected lines. Their nested Git argv/cwd/UTC/exit/stream hashes are in the excerpt stdout.
