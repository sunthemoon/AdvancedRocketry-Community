"""Seal or verify this exclusively owned, finite flat evidence leaf once."""
import datetime
import hashlib
import json
import pathlib
import re
import stat
import sys

sys.stdout.reconfigure(encoding="utf-8")
LEAF = pathlib.Path(__file__).resolve().parent
EXPECTED = pathlib.Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-native-error-provenance-independent-20261009-38")
EXCLUDED = {"SHA256SUMS.txt", "SEAL-RESULT.json", "SEAL-VERIFY-RESULT.json"}
for number in ("096", "097"):
    EXCLUDED.update("command-" + number + suffix for suffix in (".json", ".stdout.txt", ".stderr.txt"))


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def checked_files():
    assert LEAF == EXPECTED
    for ancestor in (LEAF, *LEAF.parents):
        assert not (ancestor.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT), ancestor
    files = []
    names = set()
    for path in LEAF.iterdir():
        metadata = path.lstat()
        assert stat.S_ISREG(metadata.st_mode), path
        assert not (metadata.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT), path
        assert path.name.casefold() not in names, path
        names.add(path.name.casefold())
        assert path.name not in (".", "..") and not any(char in path.name for char in "\\/:\r\n")
        files.append(path)
    assert len(files) <= 500
    assert sum(path.stat().st_size for path in files) <= 4 * 1024 * 1024
    assert all(path.stat().st_size <= 256 * 1024 for path in files if path.name.endswith((".stdout.txt", ".stderr.txt")))
    return files


mode = sys.argv[1]
assert mode in ("seal", "verify")
files = checked_files()
ack = json.loads((LEAF / "ROOT-READ-ACK.json").read_text(encoding="utf-8"))
assert ack["complete_final_report_reading"] is True
assert ack["report"] == identity(LEAF / "REPORT.md")
manifest = LEAF / "SHA256SUMS.txt"
if mode == "seal":
    assert not manifest.exists()
    assert not (LEAF / "SEAL-RESULT.json").exists()
    assert not (LEAF / "SEAL-VERIFY-RESULT.json").exists()
    selected = sorted((path for path in files if path.name not in EXCLUDED), key=lambda path: path.name)
    rows = [(identity(path)["sha256"], path.name) for path in selected]
    with manifest.open("x", encoding="utf-8", newline="\n") as stream:
        for sha, name in rows:
            stream.write(sha + "  " + name + "\n")
    result = {"utc": utc(), "mode": mode, "manifest": identity(manifest),
              "report": identity(LEAF / "REPORT.md"), "covered_files": len(rows),
              "covered_bytes": sum(path.stat().st_size for path in selected),
              "excluded_names": sorted(EXCLUDED), "root_read_ack": identity(LEAF / "ROOT-READ-ACK.json")}
    with (LEAF / "SEAL-RESULT.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
else:
    rows = []
    names = set()
    total = 0
    for row in manifest.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([^\\/:\r\n]+)", row)
        assert match, row
        sha, name = match.groups()
        assert name not in EXCLUDED and name not in (".", "..")
        assert name.casefold() not in names
        names.add(name.casefold())
        actual = identity(LEAF / name)
        assert actual["sha256"] == sha, name
        total += actual["bytes"]
        rows.append(name)
    assert set(rows) == {path.name for path in files if path.name not in EXCLUDED}
    sealed = json.loads((LEAF / "SEAL-RESULT.json").read_text(encoding="utf-8"))
    assert sealed["manifest"] == identity(manifest)
    assert sealed["report"] == identity(LEAF / "REPORT.md")
    assert sealed["covered_files"] == len(rows) and sealed["covered_bytes"] == total
    result = {"utc": utc(), "mode": mode, "manifest": identity(manifest),
              "report": identity(LEAF / "REPORT.md"), "covered_files": len(rows),
              "covered_bytes": total, "all_hashes_match": True,
              "leaf_bytes_before_own_result": sum(path.stat().st_size for path in files)}
    with (LEAF / "SEAL-VERIFY-RESULT.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
checked_files()
print(json.dumps(result, indent=2))
result_name = "SEAL-RESULT.json" if mode == "seal" else "SEAL-VERIFY-RESULT.json"
print("RESULT_IDENTITY", json.dumps({"file": result_name, **identity(LEAF / result_name)}))
if mode == "verify":
    print("SEAL_RESULT_IDENTITY", json.dumps({"file": "SEAL-RESULT.json", **identity(LEAF / "SEAL-RESULT.json")}))
