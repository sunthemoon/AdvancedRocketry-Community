"""Hash-bound targeted Git-object excerpts; never exports full source files."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
CWD = r"D:\GitHub\AdvancedRocketry-Community"
commit, path, *range_args = sys.argv[1:]
ranges = [tuple(map(int, item.split(":"))) for item in range_args]
argv = ["git", "show", commit + ":" + path]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(argv, cwd=CWD, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
end = datetime.datetime.now(datetime.timezone.utc).isoformat()
streams = {name: {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
           for name, raw in (("stdout", result.stdout), ("stderr", result.stderr))}
print(json.dumps({"nested_git_argv": argv, "cwd": CWD, "start_utc": start, "end_utc": end,
                  "timeout_seconds": 180, "exit_code": result.returncode, "raw_split_streams": streams,
                  "retention": "selected line excerpts only; source object stdout hashed in memory"}))
if any(value["bytes"] > 256 * 1024 for value in streams.values()):
    raise RuntimeError("Git-object stream exceeds task limit")
if result.returncode:
    print(result.stderr.decode("utf-8", errors="replace"))
    sys.exit(1)
lines = result.stdout.decode("utf-8", errors="strict").splitlines()
print("FIXED SOURCE", commit, path, "lines", len(lines))
for number, line in enumerate(lines, 1):
    if any(first <= number <= last for first, last in ranges):
        print(str(number) + ": " + line)
