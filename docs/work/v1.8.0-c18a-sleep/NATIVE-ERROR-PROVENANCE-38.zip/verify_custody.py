"""Bounded verification of the sealed Task28 manifest and native copied metadata."""
import datetime
import hashlib
import json
import pathlib
import stat

BASE = pathlib.Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-nested-source-qualification-20261009-28").resolve()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(128 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


manifest = BASE / "SHA256SUMS.txt"
rows = manifest.read_text(encoding="utf-8-sig").splitlines()
if len(rows) > 1000:
    raise RuntimeError("Manifest count cap exceeded")
count = total = 0
names = set()
for row in rows:
    expected, name = row.split("  ", 1)
    if name.startswith("*"):
        name = name[1:]
    relative = pathlib.PurePosixPath(name.replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts or relative.as_posix().casefold() in names:
        raise RuntimeError("Unsafe or duplicate manifest name")
    names.add(relative.as_posix().casefold())
    path = BASE.joinpath(*relative.parts)
    for checked in (path, *path.parents):
        if checked == BASE.parent:
            break
        info = checked.lstat()
        if getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError("Reparse member")
    path.resolve().relative_to(BASE)
    size = path.stat().st_size
    count += 1
    total += size
    if not path.is_file() or size > 50 * 1024 * 1024 or total > 100 * 1024 * 1024:
        raise RuntimeError("Manifest size or type cap exceeded")
    if digest(path) != expected:
        raise RuntimeError("Custody mismatch " + name)
collection = json.loads((BASE / "native-01-COLLECTION.json").read_text(encoding="utf-8"))
copied_checks = []
for row in collection["copied"]:
    path = BASE / row["evidence"]
    result = {"evidence": row["evidence"], "source_metadata_path": row["source"],
              "bytes": path.stat().st_size, "sha256": digest(path)}
    if result["bytes"] != row["bytes"] or result["sha256"] != row["sha256"]:
        raise RuntimeError("Collection copy mismatch")
    copied_checks.append(result)
end = datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps({"start_utc": start, "end_utc": end, "manifest_sha256": digest(manifest),
                  "covered_files": count, "covered_bytes": total, "all_covered_hashes_match": True,
                  "native_collection_copies": copied_checks}, indent=2))
