"""Record the received complete-read acknowledgment without inventing read UTC."""
import datetime
import hashlib
import json
import pathlib
import runpy
import sys

sys.stdout.reconfigure(encoding="utf-8")
leaf = pathlib.Path(__file__).resolve().parent


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


report = identity(leaf / "REPORT.md")
assert report == {"bytes": 25482, "sha256": "2e84e95cf5bf6a7ba34bd3f439eafb3e47730eda155122ff90a18715c3463a4a"}
mapping = identity(leaf / "OCCURRENCE-MAP.md")
assert mapping == {"bytes": 6411, "sha256": "932191e693cea6135afca17b1d716bb79f6fe9c3906ef384a9c61143dd5beeba"}
message = (
    "Root completely read exact final REPORT.md, all 379 lines /25482 bytes, SHA256 "
    "2e84e95cf5bf6a7ba34bd3f439eafb3e47730eda155122ff90a18715c3463a4a, in contiguous UTF-8 ranges "
    "1–180 and 181–379. Root also read complete OCCURRENCE-MAP.md, 6411 bytes, SHA256 "
    "932191e693cea6135afca17b1d716bb79f6fe9c3906ef384a9c61143dd5beeba. This authorizes only "
    "own-leaf one-time evidence custody seal with original 4 MiB/256 KiB bounds; preserve failed "
    "checks/instrumentation and actual diagnostic/provenance/policy gaps. No waiver, R-021 acceptance, "
    "runtime/production authority, new loss/security finding or Gate approval is inferred. Return actual "
    "coverage, every exclusion and manifest/result identities."
)
record = {"recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "timestamp_meaning": "acknowledgment recording time, not fabricated Root read/message UTC",
          "source": "collaboration MESSAGE from /root to /root/sleep_native_error_provenance_audit",
          "message_verbatim": message, "complete_final_report_reading": True,
          "report": report, "report_lines": 379, "map": mapping,
          "authority": "own-leaf one-time custody seal only; no policy/runtime/Gate acceptance"}
with (leaf / "ROOT-READ-ACK.json").open("x", encoding="utf-8") as stream:
    json.dump(record, stream, indent=2, ensure_ascii=False)
    stream.write("\n")
print("ROOT_READ_ACK", json.dumps(identity(leaf / "ROOT-READ-ACK.json")))
runpy.run_path(str(leaf / "audit_own_leaf.py"), run_name="__main__")
