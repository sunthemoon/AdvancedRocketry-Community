"""Inspect selected sealed native evidence, without runtime/test invocation."""
import collections
import hashlib
import json
import pathlib
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = pathlib.Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-nested-source-qualification-20261009-28")
LEAF = pathlib.Path(__file__).resolve().parent
FILES = ["native-01.stdout.txt", "native-01.stderr.txt", "native-01-results/build/gametest/logs/latest.log", "native-01-results/build/gametest/logs/debug.log"]


def identity(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(128 * 1024), b""):
            sha.update(block)
    return {"bytes": path.stat().st_size, "sha256": sha.hexdigest()}


receipt = json.loads((BASE / "native-01.command.json").read_text(encoding="utf-8"))
collection = json.loads((BASE / "native-01-COLLECTION.json").read_text(encoding="utf-8"))
print("COLLECTION TOP KEYS", list(collection))
for key, value in collection.items():
    if isinstance(value, list):
        print(key, "list count", len(value), "sample", json.dumps(value[:1]))
    elif isinstance(value, dict):
        print(key, "dict keys", list(value)[:25])
    else:
        print(key, json.dumps(value))
manifest = (BASE / "SHA256SUMS.txt").read_text(encoding="utf-8-sig")
manifest_rows = {}
for row in manifest.splitlines():
    sha, name = row.split("  ", 1)
    if name.startswith("*"):
        name = name[1:]
    manifest_rows[name] = sha
selected = FILES + ["REPORT.md", "native-01.command.json", "native-01-COLLECTION.json", "collect-native-01.command.json", "ROOT-READ-ACK.json", "SEAL-COVERAGE.md"]
print("MANIFEST", identity(BASE / "SHA256SUMS.txt"), "entries", len(manifest_rows))
for name in selected:
    actual = identity(BASE / name)
    match = actual["sha256"] == manifest_rows.get(name)
    print("CUSTODY", name, actual, "manifest_match", match)
    if not match:
        raise RuntimeError("Selected custody mismatch " + name)
for name in FILES[:2]:
    kind = "stdout" if "stdout" in name else "stderr"
    if identity(BASE / name) != receipt["streams"][kind]:
        raise RuntimeError("Command stream mismatch")
data = {}
for name in FILES:
    raw = (BASE / name).read_bytes()
    lines = raw.decode("utf-8", errors="strict").splitlines()
    errors = []
    batches = []
    for number, line in enumerate(lines, 1):
        if re.search(r"\[[^\]]*/(?:ERROR|FATAL)\]", line):
            errors.append({"line": number, "header": line, "previous_batch": batches[-1] if batches else None})
        if "Running test batch" in line:
            batches.append({"line": number, "text": line})
    data[name] = {"identity": identity(BASE / name), "lines": len(lines), "occurrences": errors, "batches": batches}
    counts = collections.Counter(re.sub(r"^.*?\]: ", "", row["header"]) for row in errors)
    print("LOG", name, "lines", len(lines), "errors", len(errors), "groups", json.dumps(counts))
    for ordinal, occurrence in enumerate(errors, 1):
        print(name, ordinal, occurrence["line"], occurrence["header"])
same = len(data[FILES[0]]["occurrences"]) == len(data[FILES[2]]["occurrences"]) == len(data[FILES[3]]["occurrences"])
correlation = []
for index, stdout in enumerate(data[FILES[0]]["occurrences"]):
    message = stdout["header"].split("]: ", 1)[1]
    rows = {name: data[name]["occurrences"][index] for name in (FILES[0], FILES[2], FILES[3])}
    same = same and all(row["header"].split("]: ", 1)[1] == message for row in rows.values())
    correlation.append({"ordinal": index + 1, "message": message,
                        "views": {name: row["line"] for name, row in rows.items()},
                        "previous_batch": stdout["previous_batch"]})
print("ORDERED_MESSAGE_CORRELATION", same)
result = {"fixed_tested_source": receipt["fixed_source"], "fixed_src_tree": receipt["fixed_src_tree"],
          "logs": data, "ordered_message_correlation": same, "correlations": correlation}
path = LEAF / "OCCURRENCES.json"
with path.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print("OCCURRENCES", identity(path))
