"""Finite static custody and budget audit of this task's evidence leaf only."""
import collections
import datetime
import hashlib
import json
import pathlib
import re
import stat
import sys

sys.stdout.reconfigure(encoding="utf-8")
LEAF = pathlib.Path(__file__).resolve().parent
LIMIT = 4 * 1024 * 1024
STREAM_LIMIT = 256 * 1024
EXPECTED = pathlib.Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-native-error-provenance-independent-20261009-38")
assert LEAF == EXPECTED
assert not (LEAF.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def identity(path):
    raw = path.read_bytes()
    return {"file": path.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


files = []
for path in LEAF.iterdir():
    metadata = path.lstat()
    assert not (metadata.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT), path
    assert stat.S_ISREG(metadata.st_mode), path
    files.append(path)
assert len(files) <= 500
total = sum(path.stat().st_size for path in files)
assert total <= LIMIT
receipts = []
for path in sorted(LEAF.glob("command-*.json")):
    record = json.loads(path.read_text(encoding="utf-8"))
    assert record["timeout_seconds"] == 180
    assert record["cwd"] == r"D:\GitHub\AdvancedRocketry-Community"
    assert isinstance(record["argv"], list) and record["argv"]
    for key in ("start_utc", "end_utc"):
        assert datetime.datetime.fromisoformat(record[key]).utcoffset() == datetime.timedelta(0)
    assert record["start_utc"] <= record["end_utc"]
    for stream in ("stdout", "stderr"):
        stored = record["streams"][stream]
        stream_path = LEAF / stored["file"]
        assert stream_path.parent == LEAF and stream_path.name == path.stem + "." + stream + ".txt"
        actual = identity(stream_path)
        assert actual["bytes"] == stored["length"] <= STREAM_LIMIT
        assert actual["sha256"] == stored["sha256"]
    receipts.append({"receipt": path.name, "argv": record["argv"],
                     "exit_code": record["exit_code"], "timed_out": record["timed_out"]})
numbers = [int(row["receipt"].split("-")[1].split(".")[0]) for row in receipts]
assert numbers == list(range(1, max(numbers) + 1))
occurrences = json.loads((LEAF / "OCCURRENCES.json").read_text(encoding="utf-8"))
assert occurrences["fixed_tested_source"] == "d57ecda1f11dab76d882f945b0de606534ef4fb9"
assert occurrences["ordered_message_correlation"]
rows = occurrences["correlations"]
assert len(rows) == 62
raw_counts = {name: len(value["occurrences"]) for name, value in occurrences["logs"].items()}
assert sorted(raw_counts.values()) == [0, 62, 62, 62]
main_views = [value["occurrences"] for value in occurrences["logs"].values() if value["occurrences"]]
clock_thread_equal = True
for index in range(62):
    parts = []
    for view in main_views:
        header = view[index]["header"]
        match = re.match(r"^\[([^\]]+)\] \[([^/]+)/ERROR\]", header)
        assert match, header
        clock, thread = match.groups()
        time_match = re.search(r"(\d{2}:\d{2}:\d{2})(?:\.\d+)?$", clock)
        assert time_match, clock
        clock = time_match.group(1)
        parts.append((clock, thread))
    clock_thread_equal = clock_thread_equal and len(set(parts)) == 1
assert clock_thread_equal
map_text = (LEAF / "OCCURRENCE-MAP.md").read_text(encoding="utf-8")
assert len(re.findall(r"^\| \d+ \|", map_text, flags=re.MULTILINE)) == 62
print(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "scope": str(LEAF), "file_count_at_audit": len(files), "bytes_at_audit": total,
                  "leaf_budget": LIMIT, "stream_budget": STREAM_LIMIT,
                  "receipt_count_complete_at_audit": len(receipts),
                  "nonzero_exits": [row for row in receipts if row["exit_code"] != 0],
                  "timed_out": [row for row in receipts if row["timed_out"]],
                  "maximum_raw_stream_bytes": max((LEAF / r["streams"][s]["file"]).stat().st_size
                      for p in LEAF.glob("command-*.json")
                      for r in [json.loads(p.read_text(encoding="utf-8"))]
                      for s in ("stdout", "stderr")),
                  "raw_header_counts": raw_counts, "raw_total": sum(raw_counts.values()),
                  "correlated_rows": len(rows), "clock_thread_agreement": clock_thread_equal,
                  "report": identity(LEAF / "REPORT.md"),
                  "map": identity(LEAF / "OCCURRENCE-MAP.md"),
                  "occurrences": identity(LEAF / "OCCURRENCES.json")}, indent=2))
