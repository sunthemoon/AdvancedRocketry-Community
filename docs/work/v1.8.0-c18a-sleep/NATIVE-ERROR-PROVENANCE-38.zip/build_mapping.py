"""Generate compact occurrence indices, keeping raw cross-view identities separate."""
import hashlib
import json
import pathlib
import re

LEAF = pathlib.Path(__file__).resolve().parent
data = json.loads((LEAF / "OCCURRENCES.json").read_text(encoding="utf-8"))
names = ["native-01.stdout.txt", "native-01-results/build/gametest/logs/latest.log", "native-01-results/build/gametest/logs/debug.log"]


def group(number):
    if number in (1, 2): return "P-BIND-RETRY"
    if 3 <= number <= 5: return "RECIPE-DISABLE"
    if 6 <= number <= 7: return "SAT-FLUSH"
    if 8 <= number <= 10: return "P-PORT"
    if number == 11: return "SAT-DISCOVERY"
    if 12 <= number <= 27: return "MENU-VERSION"
    if 28 <= number <= 32: return "P-BIND-GATE"
    if 33 <= number <= 35: return "P-CONTROLLER"
    if 36 <= number <= 59: return "GUARD-RECIPE"
    if number == 60: return "GUARD-COMBUSTION"
    if number == 61: return "GUARD-SOLAR"
    return "SAT-BLOCKED"


lines = ["# Compact occurrence and source mapping", "", "Tested source: d57ecda1f11dab76d882f945b0de606534ef4fb9.", "",
         "One row is an ordered cross-view correlation, not proof of one independent failure.",
         "Every view retains its own occurrence/line. The 62 rows correspond to 186 raw ERROR headers.",
         "stderr has zero ERROR/FATAL headers; all three main views have zero FATAL headers.", "",
         "| Row | stdout line | latest line | debug line | Observed stdout clock | Group |", "|---:|---:|---:|---:|---|---|"]
for row in data["correlations"]:
    n = row["ordinal"]
    clock = data["logs"][names[0]]["occurrences"][n - 1]["header"].split("]", 1)[0].lstrip("[")
    lines.append(f"| {n} | {row['views'][names[0]]} | {row['views'][names[1]]} | {row['views'][names[2]]} | {clock} | {group(n)} |")
lines.extend(["", "## Group definitions and actual source joins", "",
    "- P-BIND-RETRY / P-BIND-GATE: runtime BindingSaveFailure.accept:214 and exerciseSavedBinding:117; source excerpts command-051. Each EventBus/ChunkMap pair is one injected native save failure. The later root mismatch is only an antecedent/coordinate association, not a direct test stack.",
    "- P-PORT / P-CONTROLLER: runtime OneShotSaveFailure.accept:226 and exerciseRetry:109; source excerpts command-052. Roots diagnostics use PrecisionAssemblerManager:398-402, excerpt command-054.",
    "- RECIPE-DISABLE: DeferredProcessDefinition:34-47 and BoundedItemIngredientCodec:83-84 emit/construct the actual diagnostic. RecipeSignatureMigrationGameTests:52-81,408 is a source-compatible unbound-tag candidate; no runtime method/object receipt is retained. Commands 047,060,061,072.",
    "- SAT-FLUSH: runtime SatelliteReviewGameTests:86,89 plus explicit EXPECTED_SAVE_FAILURE marker; source excerpt command-059. CheckedSavedDataFile fails on non-regular staging path.",
    "- SAT-DISCOVERY: runtime DiscoveryRecoveryGameTests:72 plus explicit EXPECTED_SAVE_FAILURE marker; source excerpt command-062.",
    "- SAT-BLOCKED: runtime SatelliteReviewGameTests:134 and SatelliteMissionSavedData.requireOperational:390; source excerpts commands 059,079.",
    "- MENU-VERSION: observed eight rejected versions per side in debug.log, command-072. RecipeMenuChannelGameTests:21-48,63-67 is a one-test batch with matching reflected validator sequence, command-046. Strong batch/value/source correlation, not a retained method stack or real TCP peer handshake.",
    "- GUARD-RECIPE: runtime RecipeSignatureSaveEventGameTests.rejected:62 and method:37/40 alternate. Twelve ID/root combinations produce 24 direct synthetic event posts. Commands 055,064 and stack excerpts 040,073.",
    "- GUARD-COMBUSTION: runtime CombustionGeneratorGameTests:252 posts the outgoing save event directly and catches the rejection; command-056.",
    "- GUARD-SOLAR: runtime SolarGeneratorGameTests:388 posts the outgoing save event directly and catches the rejection; command-057.",
    "- Guard failure site: GuardedChunkSaves.fail:91-93; first recipe attempt uses refuse:56-60, second uses beforeSave:48-52. Command-058. These direct posts are not ChunkMap writer acknowledgements.", "",
    "All file hashes, exact headers and prior-batch observations are in OCCURRENCES.json. Primary stack excerpts are commands 036-040,073-074.",
    "All source excerpts hash the complete fixed Git object in memory and retain only selected lines. Their nested Git argv/cwd/UTC/exit/stream hashes are in the excerpt stdout."])
path = LEAF / "OCCURRENCE-MAP.md"
path.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({"file": str(path), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}))
