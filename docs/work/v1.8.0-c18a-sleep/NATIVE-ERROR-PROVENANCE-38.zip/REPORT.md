# Task38 independent native diagnostic provenance report

## Findings, ordered by significance

1. **High, existing acceptance-blocking policy/evidence gap: passing the native
   suite does not clear the retained project-origin ERRORs or R-021.** The logs
   contain real injected native terrain-save failures, actual rejected SavedData
   operations and executed production save-guard throws. Some are conclusively
   exercised negative tests; that is diagnostic provenance, not an accepted
   clean-log exception. The fixed master test plan treats project-origin ERROR
   as failure. R-021 remains open and unaccepted, with whole-chunk refusal,
   sticky Level-lifetime denial, possible Level-wide saturation, no production
   online clear and no guard-layer total retry/log bound. The solar owner's
   scoped inclusion decision does not accept that whole risk or logging policy.
   This is an existing admission obligation, **not a newly reproduced High
   product defect or a new claim of observed player-data loss**. Evidence:
   [test policy](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-011.stdout.txt),
   [R-021](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-023.stdout.txt),
   [scoped owner decision](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-071.stdout.txt).
2. **Medium, unresolved executed attribution: three recipe-disable headers lack
   a runtime method/receiver/tag receipt.** Their batch, values and tested source
   strongly fit the unbound-tag validation test, but they have no stack or
   individual invocation receipt. Static test intent alone cannot establish
   which recipe objects actually emitted them. Neither harmless intentional-test
   classification nor broken shipped recipes is conclusively demonstrated.
   Keep this attribution open or obtain bounded runtime context in a separately
   authorized task; do not silently downgrade or remove the diagnostics.
3. **Medium, save-evidence boundary: 26 save-guard EventBus headers are direct
   synthetic posts, not 26 native ChunkMap write failures.** Actual test stack
   frames establish execution of the guard and expected caught refusals. They do
   not establish a native region-write acknowledgment, unload/restart behavior,
   cross-store consistency, saturation recovery or bounded logging. Five other
   injected native save failures do have paired EventBus/ChunkMap evidence.
   Conflating these two groups would incorrectly close R-021 or inflate the
   number of real writer failures. No such closure is warranted.

No arbitrary security attack, persistent inventory duplication, player-world
corruption or production server crash is reproduced by this static audit.
Absence of such proof is not safety approval. The remaining groups have the
positive provenance and explicit limits described below.

## Fixed identity, authority and scope

- Assignment: [Task38](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-NATIVE-ERROR-PROVENANCE-TASK-38.md),
  3126 bytes, SHA256
  `66a7d81ff3684b63373798be4c9638f1b65eb4363e26018b4a6170ba5f3f03c6`.
- Governance Git object: `9edbcab9ba53f2aaf4861867a916fbe424972c07`.
- Actual tested source Git object: `d57ecda1f11dab76d882f945b0de606534ef4fb9`;
  source tree `85f53265bf4ee59b65c4a88664cb2e5e208c583e`.
- Inputs: sealed Task28 qualification, not a new run or changing Main.
- Exclusive write scope is this new external evidence leaf only. No project,
  source, index, HEAD, worktree, runtime, cleanup or other-agent write authority.
  No delegation, tests, network, install, download or process inspection/termination
  was performed. Source declarations are read from fixed Git objects, not Main.
- Mandatory governance, v1.8 version, test, release, post-1.0 quality/roadmap,
  parallel and relevant ADR/risk documents were read. v1.8 remains the scoped
  development target under accepted ADR-060; inherited acceptance remains
  incomplete. The actual version document is
  `docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`, not a nonexistent lowercase
  filename. G0-G9 remain Required.
- Initial git status/worktree checks retain pre-existing owner-modified AGENTS
  and untracked peer evidence files. None were modified, staged, deleted or
  adopted. Other Root work after assignment does not change the fixed inputs.

## Custody and actual launch

The independent manifest walk validates **909 covered files, 14278320 bytes**,
all hashes matching. It reads only explicitly manifested Task28 evidence files,
with leaf containment, case uniqueness and reparse checks; it does not traverse
mutable worlds/caches. See
[custody result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-069.stdout.txt).

| Retained Task28 record | Bytes | SHA256 |
|---|---:|---|
| SHA256SUMS.txt | 169478 | `d063e2b87fae9fb0856d4141e8c1d27e15ae540f797adf15e384bc9875efa913` |
| REPORT.md | 24085 | `52f3897671a060020f11ff46b5dcb61d20576b46e48cba66bc387362ff311e02` |
| native-01.command.json | 12660 | `33a1cfb34bafec25c17bda3b97f6286e902675efe9b8a3cb965b270a27231079` |
| native-01-COLLECTION.json | 57129 | `9cfa2adbaf0979ebb3b5f726b7fd19a558c410002c280a6ab87195b342905611` |
| collect-native-01.command.json | 12671 | `f0585a7b6b02ac038f164b1d327bfb8f28a36b3757be73d847d4972ba45505fb` |

Task28's root full-read acknowledgment is 918 bytes, SHA256
`3c28e59a4b3606a5f040cb014c5261e3ce509f6a4457e097510ea8d40b3de14a`,
dated 2026-10-09 07:50:44 UTC. Its manifest/result/seal/verification receipts and
empty scratch prefix have the documented self-referential exclusions; this audit
does not claim those excluded files are manifest-covered. Task28 is never edited.

Historical native argv is `cmd.exe /d /c gradlew.bat runGameTestServer
--no-daemon --no-build-cache --rerun-tasks`, cwd
`D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28`, start
`2026-10-09T07:25:53.994666+00:00`, end
`2026-10-09T07:30:06.547652+00:00`, timeout 2400 s, exit 0, not timed out.
The retained 151 batch counts total **594 required tests**, followed by the suite
completion/pass result at stdout lines 5944-5945. These are actual historical
suite/batch observations, not individual method PASS receipts; no native XML or
20-row sleep-console observation is present. Opt-in observation is not enabled.

Collection runs 07:30:30.116813-07:30:30.340546 UTC, exit 0; metadata UTC is
07:30:30.209839. Copies match receipt/manifest hashes. The collector selects
`.log`/`.xml`, not rotated `.gz`; absence of retained gzip does not prove complete
original rotation history. Task28's authorized later cleanup removed generated
runtime/build artifacts; their retained hashes are historical metadata, not an
independent present-day artifact inspection. Its strict validator's unchanged
180-second TIMEOUT remains open. No test or strict retry was made here.

## Enumeration and cross-view correlation

| View under Task28 | Bytes | SHA256 | ERROR / FATAL |
|---|---:|---|---:|
| native-01.stdout.txt | 1706344 | `5933817e1037def591daaefe29d78301dddb601f85579c80f18f9a9e60c6c857` | 62 / 0 |
| native-01.stderr.txt | 14116 | `7be65bf31a95fcd021de94be7e620c16cf93578d0da5a46f29cd3ac4f6116a8a` | 0 / 0 |
| native-01-results/build/gametest/logs/latest.log | 1854127 | `651666bc388890faf9191006459cda6beafaf1abaae5bbf708e271a8b1a85479` | 62 / 0 |
| native-01-results/build/gametest/logs/debug.log | 2030639 | `392af1ddd7682ff144658d4e97cc71028ed78499b0a1f4b6800d9338b6bc4810` | 62 / 0 |

Strict UTF-8 decoding succeeds. Every raw header remains counted: **186 ERROR
headers, zero FATAL** across three main views; **62 ordered correlated rows**.
Exact sequence/message/thread/clock correspondence supports the join, but no
global event ID is present. These are not 186 independent failures, and not even
62 independent failures: each of five real save failures emits an EventBus and
ChunkMap pair. Repeated fixture operations remain separate rows, not silently
deduplicated. Raw log clocks around 15:27-15:30 are observed local clocks
consistent with UTC+8, not invented UTC event timestamps.

The compact
[occurrence/source map](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/OCCURRENCE-MAP.md)
enumerates every row and all three line identities; the
[machine-readable occurrence record](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/OCCURRENCES.json)
retains exact headers, hashes, clock/thread and prior-batch observations.
Stacks are retained in commands 036-040 and compact rereads 073-074.

## Group-by-group provenance

| Group | Correlated headers per view |
|---|---:|
| Precision assembler | 13 |
| Recipe disable | 3 |
| Satellite/discovery | 4 |
| Machine-menu validator | 16 |
| Direct save-guard event posts | 26 |
| Total | 62 |

### Precision assembler: 13 headers, five injected native save failures

Rows 1-2 are one binding-retry failure; rows 8-10 one migration-port failure;
rows 28-32 two binding-gate failures; rows 33-35 one migration-controller failure.
The 10 paired headers are five real `ChunkMap.save` failures. Three additional
manager headers report persisted-root hash mismatches after those failures.

Runtime stacks identify `BindingSaveFailure.accept:214` /
`exerciseSavedBinding:117` and `OneShotSaveFailure.accept:226` /
`exerciseRetry:109`. Native frames traverse `ChunkMap.save:830`,
`saveAllChunks:433`, `ServerChunkCache.save:297` and
`PrecisionAssemblerManager.flushMigrationBarrier:423`. Batch names/counts and
coordinates match the specific one-test fixtures. This is executed injection,
not a classification based only on test comments. Fixture source installs the
selected one-/two-shot listener, invokes the manager, asserts preservation and
retry states, unregisters it and verifies post-retry persisted generations or
resource conservation. See
[binding fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-051.stdout.txt),
[migration fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-052.stdout.txt).

The actual selected terrain chunk is refused on the failed attempt. A normal
return from save-all is not proof every chunk reached disk. The later mismatch
headers have no own method stack: their attribution is an antecedent/batch/
coordinate/source join, not a standalone method receipt. Their logger site is
`PrecisionAssemblerManager:398-402`,
[excerpt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-054.stdout.txt).
Although the production guard is a registered listener, these five top-level
throws come from fixture listeners, not the sticky R-021 guard. They do not prove
production saturation, repair or full shutdown/restart durability.

### Recipe definitions: three disable-until-reload headers

Rows 3-5 name `rolling_iron_bars`, `precision_control_circuit` and
`electrolyzer_water`, with `machine ingredient has no bound alternatives`, during
the 16-case `recipe_signatures` batch. `DeferredProcessDefinition:34-47` catches
the validation failure, caches it and logs disable-until-tag-reload;
`BoundedItemIngredientCodec:83-84` rejects empty alternatives. These are actual
logged validation/disable operations, not assertions alone.

`RecipeSignatureMigrationGameTests:52-81,408` constructs all three serializer
definitions using `arce_test:unbound`, performs the network roundtrip and checks
unavailability. The source/value/batch match is strong. However, there is no
runtime method frame, object identity, effective tag receipt or per-case result
connecting these exact three headers to that method. **Executed intentional-test
attribution remains unproved.** There is also no evidence these transient objects
were the shipped global recipe definitions, affected persisted items, or later
rebound successfully. Sources/context:
[candidate test](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-047.stdout.txt),
[logger](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-060.stdout.txt),
[codec](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-061.stdout.txt),
[runtime batch](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-072.stdout.txt).

### Satellite/discovery: four executed rejected operations

Rows 6-7 have the explicit `ARCE_SATELLITE_EXPECTED_SAVE_FAILURE` marker and
runtime `SatelliteReviewGameTests.aFailedLaunchFlushKeepsThePackageUntilTheReplayIsDurable:86/89`.
The fixture creates a directory at the staging-file path; two package-press
attempts encounter `CheckedSavedDataFile.replace:71` wrapping an IOException
that authority/staging paths must be regular files. Source preflight checks this
before payload encoding/writing. Package preservation is asserted; the obstacle
is removed and a subsequent replay checks durable acknowledgment.

Row 11 has `ARCE_DISCOVERY_EXPECTED_SAVE_FAILURE` and runtime
`DiscoveryRecoveryGameTests.oldPaidReceiptAndNewRemovedTargetRecoverWithoutAnotherClaim:72`.
It creates the same kind of staging obstacle, asserts unsupported-data refusal,
removes it and checks retry acknowledgment. Row 62 has runtime
`SatelliteReviewGameTests.aBlockedRegistryFailsClosedWithoutCrashing:134` and
`SatelliteMissionSavedData.requireOperational:390`; it exercises a blocked
invalid/future registry and checks package preservation/unavailable output.

The log/source joins conclusively identify executed negative fixture operations;
they are nevertheless actual I/O/unsupported-data failures. They are not
successful writes, a general restart Gate or evidence of a live production
incident. No arbitrary hostile request is established. See
[satellite fixtures](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-059.stdout.txt),
[discovery fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-062.stdout.txt),
[file preflight](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-063.stdout.txt),
and catch/blocked logger sites in commands 077-079.

### Machine-menu channel: 16 validator rejections

Rows 12-27 occur in the one-case `machine_menu_channel` batch. Debug lines
3302-3547 retain rejected values/directions: per side, missing/`ABSENT`, empty,
`0`, `2`, `01`, `1 `, explicit `ABSENT`, and `ALLOWVANILLA`. Matching protocol
`1` is accepted in both directions. `RecipeMenuChannelGameTests:21-48,63-67`
uses the reflected static Forge validator with exactly that two-direction
sequence. This unusually specific value/count/direction/batch correspondence is
strong actual provenance, not only a source-intent guess.

There is no named runtime stack, individual method receipt or real TCP peer in
these headers. Attribution to that method is a source/runtime correlation;
it is **not proof of 16 real client connection failures or compatibility with
real clients**. Accepted ADR-064 exact-protocol rejection supports the behavior
contract, not a clean-log waiver or G6/G8 approval. See
[fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-046.stdout.txt),
[actual values](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-072.stdout.txt),
[accepted contract excerpts](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-070.stdout.txt).

### Save guard: 26 executed direct event-post refusals

Rows 36-59 are 24 recipe posts: three machine IDs times four oversized roots
times two attempts. Runtime `RecipeSignatureSaveEventGameTests.rejected:62`
and method lines 37/40 alternate; first attempt reaches
`RecipeSignatureProtection:48` / `GuardedChunkSaves.refuse:60`, second reaches
sticky `GuardedChunkSaves.beforeSave:52`; both fail at `fail:93`. The outgoing
synthetic tags do not modify live machine roots, and the fixture restores its
guard state. Rows 60 and 61 name runtime
`CombustionGeneratorGameTests:252` and `SolarGeneratorGameTests:388`.
These serialize outgoing chunks then **directly post** save events with
oversized 8192-/4096-byte roots, catch the expected rejection and restore state.

All 26 are actual production guard exceptions executed by a negative harness;
they are not inferred only from fixture declarations. Unlike the five precision
pairs, there are no corresponding `ChunkMap.save` writer frames/pairs here.
Thus the evidence establishes event-level fail-closed behavior and its test
assertions, not real region-file retention or unload/shutdown/restart outcomes.
It does not measure a logging quota or production recovery. Sources:
[recipe fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-055.stdout.txt),
[combustion fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-056.stdout.txt),
[solar fixture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-057.stdout.txt),
[guard](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-058.stdout.txt).

## Policy boundaries and required disposition

Accepted ADR-064 revision 5 is an accepted scoped machine/recipe/protocol
contract; the save-refusal explanation revision remains proposed. The
disposition corrects factual disclosure without accepting R-021. ADR-068
outer-operations proposals do not select production recovery or waive logs.
The owner's exact solar choice, received 2026-10-06 by asynchronous reply, is
limited to that solar root. Bounded faithfully preservable unknown/future roots
pass unchanged; actual bounded/native preflight or physical BE-list failure is
the veto trigger, not merely unknown schema. There is no authorized discard,
reset, quarantine, forced shutdown, logger downgrade or whole-risk acceptance.

Required disposition is therefore explicit: retain all diagnostic evidence;
resolve the three recipe headers' actual context or retain the attribution gap;
separately freeze/review any negative-test diagnostic policy and production
save-refusal/log budget/recovery decision; obtain any missing native writer,
unload/restart and cross-store evidence only under a new scoped assignment.
This audit grants none of those changes or runtime permissions.

## Completed scope, files and actual commands

Completed: fixed-input/governance reading, status/worktree inspection, custody
verification, independent ERROR/FATAL enumeration, ordered cross-view mapping,
actual stack/batch/source joins, policy review and this findings-first report.
No upstream asset/code import occurs. Manual file writes use apply_patch and
are restricted to this own evidence leaf.

Modified project/source files: **none**. New own-leaf files: this report,
`OCCURRENCE-MAP.md`, `OCCURRENCES.json`, small static aggregation/custody/excerpt/
receipt helpers, numbered command receipts/raw split streams, preparation-limit
record and final own-leaf audit/seal bookkeeping. No full source/library/world/
build export or copy of the multi-megabyte native logs is retained here.

The `command-NNN.json` records are authoritative for true child argv, cwd, UTC,
exit and separate stream hashes. Every numbered child uses a fixed 180-second
timeout; fixed-object nested Git reads hash full stdout/stderr in memory and
retain only targeted source excerpts. Raw streams are checked against 256 KiB each;
the evidence leaf must remain below 4 MiB. The final static audit checks those
limits, receipt hashes and the 62-row mapping. Commands are grouped as follows:

| Commands | Actual activity / result |
|---|---|
| 001-016,020,022-026,035,045,048-050,070-071,075-076,083-084 | Status/worktrees, fixed Git governance/version/ADR/risk/checkpoint reads; successful except 009 missing lowercase path |
| 017-019,021,027-034,041-043,053,066-069,085-087 | Bounded evidence listings/reads/hash/custody and targeted searches; successful except 019 listing-limit stop |
| 036-040,065,072-074 | Actual diagnostic stack/header/batch/value excerpts; exit 0 |
| 044 | Wrong guessed ADR path; exit 128; preserved, corrected separately by 048 |
| 046-047,051-052,054-064,077-079 | Exact d57 source-object targeted declarations and logger/guard sites; exit 0 |
| 080,081-082 | Compact mapping generation, task identity reread, own-helper/map inspection; exit 0 |
| 088,090-092 | Retained identity/helper inspection, final Main status/HEAD observation and actual header-format diagnosis; exit 0 |
| 089 | Own static audit exits 1: date-bearing latest/debug clock format was not normalized to stdout format; original assertion/raw streams retained |

The original failed receipts and transcript-only preparation limits are retained
in [PREPARATION-LIMITS.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/PREPARATION-LIMITS.md).
No timestamp/argv is fabricated for uncaptured shell preparations. Console
display truncation or early UTF-8 display issues do not alter persisted bytes.
The clock formatting correction and its actual diagnostic are retained in
[AUDIT-CORRECTION.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/AUDIT-CORRECTION.md);
the unchanged correlation/count/custody/budget assertions are rerun in a separate
static command, never relabeling the failed check. Final Main HEAD observation
is `cd9b54a23b5bf92760b05655a427344d6b620984`, which is not substituted for either
fixed input; its status retains the owner AGENTS modification and peer files.
Final audit receipts after the above range are additional static evidence, not
native runs or acceptance retries.
The successful own-leaf
[static audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/command-093.stdout.txt)
checks all 92 completed receipts then present, raw counts/map, clock/thread
correlation and leaf/stream budgets: 1323426 bytes at that audit, maximum retained
child stream 84297 bytes, zero own timeouts. Its four nonzero checks remain
recorded. The wrapping command-093 receipt is finalized after the child audit,
so it is included only by a later audit/seal, not falsely in that 92 count.

## Uncompleted scope, tests, risks and Required Gates

Tests added/modified: **none**. Tests actually executed by Task38:
**NOT_EXECUTED**, including Gradle build/runData/runGameTestServer, dedicated,
restart, visual, multiplayer and security runtime. Those commands are forbidden
by this read-only assignment, not passed or treated as waived. Historical 594
required passes are Task28 evidence only. Static manifest/count/source checks
are audit checks, not replacement tests.

Uncompleted: conclusive recipe-disable invocation attribution; any diagnostic
exception/expectation approval; R-021 production impact/log/retry budget and
recovery disposition; real writer/unload/restart/cross-store/saturation evidence;
strict timeout closure; per-method receipts; frozen packaged observation driver
and twenty-row/two-invocation runtime; real clients/GPU and full release evidence.
The checkpoint32/36 open items remain open; this report cannot accept them.

Key design decision: preserve raw counts and failed operations while separating
their independently supported execution contexts. Do not infer policy authority
from test success, source names/comments, accepted unrelated contracts or the
limited solar inclusion choice. This is a finite static audit, not a remediation.

Known risks: R-021 whole terrain refusal/sticky lifetime/saturation and cross-store
divergence remain serious unquantified risks; log volume is not capped/proved;
three bare recipe diagnostics and per-method receipt absence limit attribution;
rotated-log omission limits complete-history claims. This audit demonstrates no
new persistent-loss/duplication/security incident and offers no blanket safety
conclusion.

**All current/inherited Required Gates G0-G9 satisfied: NO.** No Gate PASS,
version status, delivery ledger, accepted ADR, release, tag, source integration
or production/runtime approval is changed. Only v1.8-only remaining work is
suggested: Root dispositions these exact fixed-source diagnostics and then
assigns the independently reviewed, bounded context/production-save evidence
still missing. Do not proceed to later-version implementation.

## Evidence and read-before-seal

Evidence directory:
[sleep-native-error-provenance-independent-20261009-38](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-error-provenance-independent-20261009-38/).
This persisted report must be completely read and acknowledged by Root using
its exact final bytes/hash before a one-time seal. At report preparation it is
**unsealed**; no acknowledgment or seal is inferred. A subsequent explicit
acknowledgment/seal is retained separately and does not rewrite this report.
Only own regular evidence files can be manifest members; no external mutable
build, cache, world or Temp path is covered. Covered files are immutable after
sealing, including the original failed receipts.
