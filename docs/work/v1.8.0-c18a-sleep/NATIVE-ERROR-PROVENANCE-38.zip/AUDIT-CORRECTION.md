# Static audit formatting correction

Command-089 is preserved as exit 1 with its original raw AssertionError at the
clock/thread-agreement check. This was an own audit-helper formatting error, not
a native test failure or a custody mismatch. The original normalizer was
`clock = clock.split(".")[0]`, which kept `09Oct2026 ` on latest/debug clocks
while stdout contained only `15:27:12`.

Command-092 independently displays the actual retained first two headers from
all views. Latest/debug use `[09Oct2026 15:27:12.902]`; stdout uses `[15:27:12]`.
The corrected normalizer extracts an anchored `HH:mm:ss` with an optional
millisecond suffix, and asserts a valid match before the unchanged agreement
check. The original 62-row, raw-count, budget, custody and timeout assertions
remain unchanged. This formatting correction removes no diagnostic, changes
no production/test source and grants no Gate waiver. Later successful static
audit is separately numbered, not relabeled command-089.
