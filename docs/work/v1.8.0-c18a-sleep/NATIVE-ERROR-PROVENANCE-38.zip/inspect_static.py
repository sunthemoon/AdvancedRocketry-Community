"""Bounded read-only file/list/hash/excerpt operations for Task38."""
import hashlib
import json
import pathlib
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

mode, *args = sys.argv[1:]
if mode == "list":
    for arg in args:
        base = pathlib.Path(arg)
        files = sorted(base.iterdir())
        if len(files) > 400:
            raise RuntimeError("Bounded evidence leaf listing exceeded")
        print(str(base))
        for path in files:
            print(str(path.relative_to(base)) + "\t" + ("DIR" if path.is_dir() else str(path.stat().st_size)))
elif mode == "read":
    for arg in args:
        path = pathlib.Path(arg)
        if path.stat().st_size > 256 * 1024:
            raise RuntimeError("Use excerpt mode for large files")
        raw = path.read_bytes()
        print("FILE " + str(path) + " bytes=" + str(len(raw)) + " sha256=" + hashlib.sha256(raw).hexdigest())
        for number, line in enumerate(raw.decode("utf-8-sig").splitlines(), 1):
            print(str(number) + ": " + line)
elif mode == "excerpt":
    path = pathlib.Path(args[0])
    ranges = [tuple(map(int, item.split(":"))) for item in args[1:]]
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(128 * 1024), b""):
            sha.update(block)
    print("FILE " + str(path) + " bytes=" + str(path.stat().st_size) + " sha256=" + sha.hexdigest())
    with path.open("r", encoding="utf-8-sig", errors="replace") as stream:
        for number, line in enumerate(stream, 1):
            if any(start <= number <= end for start, end in ranges):
                print(str(number) + ": " + line.rstrip("\n"))
elif mode == "match":
    pattern = re.compile(args[0])
    for arg in args[1:]:
        path = pathlib.Path(arg)
        sha = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(128 * 1024), b""):
                sha.update(block)
        print("FILE " + str(path) + " bytes=" + str(path.stat().st_size) + " sha256=" + sha.hexdigest())
        with path.open("r", encoding="utf-8-sig", errors="replace") as stream:
            for number, line in enumerate(stream, 1):
                if pattern.search(line):
                    print(str(number) + ": " + line.rstrip("\n"))
elif mode == "frames":
    path = pathlib.Path(args[0])
    first, last = map(int, args[1:])
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    errors = [i for i, line in enumerate(lines) if re.search(r"\[[^\]]*/(?:ERROR|FATAL)\]", line)]
    print("FILE", path)
    for ordinal, start in enumerate(errors, 1):
        if not first <= ordinal <= last:
            continue
        print("OCCURRENCE", ordinal, "line", start + 1, lines[start])
        end = start + 1
        while end < len(lines) and not lines[end].startswith("["):
            end += 1
        project_count = 0
        for i in range(start + 1, end):
            line = lines[i]
            is_project_frame = "\tat " in line and "io.github.sunthemoon" in line
            if is_project_frame:
                project_count += 1
            if "GameTests" in line and "\tat " in line or "Caused by:" in line or re.match(r"[a-z].*(?:Exception|Error):", line) or is_project_frame and project_count <= 4:
                print(str(i + 1) + ": " + line)
elif mode == "json":
    path = pathlib.Path(args[0])
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    for key in args[1:]:
        print(key, json.dumps(value[key], indent=2, ensure_ascii=False))
else:
    raise RuntimeError("Unknown bounded mode")
