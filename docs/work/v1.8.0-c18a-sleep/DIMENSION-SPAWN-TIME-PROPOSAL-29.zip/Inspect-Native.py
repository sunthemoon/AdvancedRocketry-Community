"""Pinned javap method inspection; no Java application or game is executed."""
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

LEAF = Path(__file__).resolve().parent
JAR = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
JAVAP = Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
GROUPS = {
    'time': [
        ('net.minecraft.server.MinecraftServer', ['createLevels'], ['DerivedLevelData', 'ServerLevel."<init>"'], 17),
        ('net.minecraft.server.level.ServerLevel', ['tick', 'tickTime'], ['SleepStatus', 'setDayTime', 'wakeUpAllPlayers', 'resetWeatherCycle', 'tickTime:Z', 'setGameTime'], 12),
        ('net.minecraft.server.players.SleepStatus', ['update', 'areEnoughSleeping', 'areEnoughDeepSleeping', 'sleepersNeeded'], [], 0),
        ('net.minecraft.world.level.storage.DerivedLevelData', ['getGameTime', 'getDayTime', 'setGameTime', 'setDayTime', 'getXSpawn', 'getYSpawn', 'getZSpawn', 'isRaining', 'setRaining', 'isThundering', 'setThundering', 'setRainTime', 'setThunderTime'], [], 0),
        ('net.minecraft.world.level.Level', ['isDay', 'isNight'], [], 0),
        ('net.minecraft.world.entity.player.Player', ['isSleepingLongEnough'], [], 0),
    ],
    'spawn': [
        ('net.minecraft.server.level.ServerPlayer', ['startSleepInBed'], ['onPlayerSleepInBed', 'natural:()Z', 'setRespawnPosition', 'sleepingTimeCheck', 'trySleep', 'startSleepInBed'], 14),
        ('net.minecraft.server.level.ServerPlayer', ['setRespawnPosition'], [], 0),
        ('net.minecraft.server.level.ServerPlayer', ['readAdditionalSaveData', 'addAdditionalSaveData'], ['SpawnDimension', 'SpawnX', 'SpawnAngle', 'SpawnForced', 'stopSleepInBed'], 9),
        ('net.minecraft.server.players.PlayerList', ['respawn'], ['findRespawnPositionAndUseSpawnBlock', 'setRespawnPosition', 'firePlayerRespawnEvent'], 14),
        ('net.minecraft.world.entity.player.Player', ['findRespawnPositionAndUseSpawnBlock'], ['getBlockState', 'bedWorks', 'respawnAnchorWorks', 'CHARGE'], 10),
    ],
    'ancillary': [
        ('net.minecraft.world.item.CompassItem', ['getSpawnPosition'], [], 0),
        ('net.minecraft.client.renderer.item.ItemProperties$1', ['unclampedCall'], ['natural:()Z', 'getTimeOfDay', 'Math.random'], 12),
        ('net.minecraft.world.level.block.NetherPortalBlock', ['randomTick'], ['natural:()Z', 'RULE_DOMOBSPAWNING', 'STRUCTURE', 'spawn'], 17),
    ],
    'startup': [
        ('net.minecraft.resources.RegistryDataLoader', ['static'], ['DIMENSION_TYPE', 'LEVEL_STEM', 'dimension'], 8),
        ('net.minecraft.server.WorldLoader', ['load'], ['RegistryDataLoader', 'WorldDimensions', 'ReloadableServerResources'], 13),
        ('net.minecraft.server.ReloadableServerResources', ['loadResources'], ['new', 'RegistryDataLoader', 'reload'], 8),
        ('net.minecraft.world.level.storage.PrimaryLevelData', ['setTagData'], ['WorldGenSettings', 'encode', 'RegistryOps'], 10),
    ],
    'supplement': [
        ('net.minecraft.world.level.block.BedBlock', ['canSetSpawn'], [], 0),
        ('net.minecraft.server.level.ServerLevel', ['resetWeatherCycle', 'canSleepThroughNights', 'setDayTime'], [], 0),
        ('net.minecraftforge.event.ForgeEventFactory', ['fireSleepingTimeCheck', 'onPlayerSpawnSet', 'onSleepFinished'], [], 0),
        ('net.minecraft.server.MinecraftServer', ['reloadResources'], ['ReloadableServerResources', 'registries', 'RegistryDataLoader', 'loadResources'], 10),
    ],
    'spawn-target': [
        ('net.minecraft.world.level.Level', ['getSharedSpawnPos'], [], 0),
    ],
}
group = sys.argv[1]
rows = []
output = []
with zipfile.ZipFile(JAR) as z:
    for cls, names, patterns, radius in GROUPS[group]:
        entry = cls.replace('.', '/') + '.class'
        data = z.read(entry)
        command = [str(JAVAP), '-classpath', str(JAR), '-p', '-c', cls]
        started = datetime.now(timezone.utc).isoformat()
        run = subprocess.run(command, capture_output=True, timeout=180)
        ended = datetime.now(timezone.utc).isoformat()
        raw = run.stdout.decode('utf-8', errors='replace')
        lines = raw.splitlines()
        headings = [i for i, line in enumerate(lines) if re.match(r'^  (?:[^ ].*\);|static \{)', line)]
        selected = []
        for n, start in enumerate(headings):
            head = lines[start]
            if not any((' ' + name + '(') in head or (name == 'static' and 'static {}' in head) for name in names):
                continue
            end = headings[n + 1] if n + 1 < len(headings) else len(lines)
            method = lines[start:end]
            print('\nCLASS', cls, 'METHOD', head.strip())
            print('\n'.join(method))
            if patterns:
                keep = {0}
                for index, line in enumerate(method):
                    if any(p in line for p in patterns):
                        keep.update(range(max(0, index - radius), min(len(method), index + radius + 1)))
                excerpt = [line for index, line in enumerate(method) if index in keep]
            else:
                excerpt = method
            selected.append(head.strip())
            output.extend(['\nCLASS ' + cls, '\n'.join(excerpt)])
        rows.append({'class': cls, 'entry': entry, 'entry_bytes': len(data),
                     'entry_sha256': hashlib.sha256(data).hexdigest(), 'command': command,
                     'utc_start': started, 'utc_end': ended, 'exit_code': run.returncode,
                     'selected_methods': selected, 'stderr': run.stderr.decode('utf-8', errors='replace'),
                     'complete_stdout_sha256': hashlib.sha256(run.stdout).hexdigest(),
                     'complete_stdout_retained': False})
        if run.returncode:
            raise RuntimeError(rows[-1])
target = LEAF / ('NATIVE-' + group.upper() + '-EXCERPTS.txt')
target.write_text('\n'.join(output) + '\n', encoding='utf-8')
(LEAF / ('NATIVE-' + group.upper() + '-READS.json')).write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
print('Retained excerpts:', target, 'bytes=', target.stat().st_size)
