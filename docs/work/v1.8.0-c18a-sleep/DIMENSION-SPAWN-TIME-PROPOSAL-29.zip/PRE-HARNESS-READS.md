# Preliminary read receipts and capture limits

These initial commands preceded `Read-Inputs.ps1`. Their output was displayed by
the execution tool but not retained as an independent raw-stream file in this
leaf. UTC values below are actual printed observation headers, not invented
process-start/end times. The first task read had no embedded UTC header.

| Tool chunk | Printed UTC | Exit | Actual command/result |
|---|---|---|---|
| ecf911 | not captured | 0 | Get-Content -LiteralPath D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-DIMENSION-SPAWN-TIME-CONTRACT-TASK-29.md -Raw; complete task displayed |
| 1b67df | 2026-10-09T07:16:43.8401679Z | 0 | Get-Date -AsUTC -Format o; Get-FileHash task -Algorithm SHA256; git status --short; git branch --show-current; git rev-parse HEAD; git worktree list; Get-Content PROJECT-CONFIG.md, PRODUCT.md, docs/01-PORTING-PRINCIPLES.md, docs/04-VERSION-ROADMAP.md -Raw |
| 97502d | 2026-10-09T07:16:57.4964824Z | 1 | Get-Content docs/versions/v1.8.0.md, docs/05-MASTER-TEST-PLAN.md, docs/06-RELEASE-AND-ACCEPTANCE-GATES.md -Raw failed at the first nonexistent guessed version path under ErrorActionPreference=Stop |
| 344fc8 | 2026-10-09T07:17:04.0746977Z | 0 | rg --files docs/versions docs/work/v1.8.0-c18a-sleep; Get-Content docs/status/CURRENT_VERSION.md, docs/05-MASTER-TEST-PLAN.md, docs/06-RELEASE-AND-ACCEPTANCE-GATES.md -Raw; actual uppercase version filename discovered |
| 19d1c5 | 2026-10-09T07:17:12.1139594Z | 0 | Get-Content docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md, docs/16-POST-1.0-VERSION-ROADMAP.md, docs/17-V1PLUS-QUALITY-BUDGETS.md, docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md -Raw |
| 4f8eeb | 2026-10-09T07:17:23.2813813Z | 0 | Get-Content the exact three owner records, original PROPOSED-CONTRACT-01.md, RESEARCH-STATUS-01.md, CONTRACT-REVIEW-STATUS-01.md, SPAWN-RESEARCH-STATUS-02.md, AIR-RESEARCH-STATUS-02.md, BOUNDARY-REVIEW-STATUS-03.md -Raw |

For the two grouped commands, full paths were prefixed with
`docs/work/v1.8.0-c18a-sleep/`. Tool displays for chunks 1b67df/4f8eeb were
truncated; R01 repeats the first group with receipts, and R02 reads the original
proposal's latter portion. No lost display/raw bytes are claimed recovered.
Subsequent identity checks hash raw Git blobs at the fixed checkpoints and prove
the mandatory governance and three owner files equal their inspected working
copies, excluding the already-modified AGENTS and Root's later CURRENT_VERSION
record edits. Fixed status excerpts were separately read under R13.

The initial collaboration list showed Root and the three disjoint workers. It had
no embedded UTC capture. Root receives progress through messages; this worker did
not launch children or contact OpenPet/Claude. Read-command receipts from R01
onward have true pre-command/post-command UTC, command text and exit codes, but
retain only the merged-display hash, not a complete raw stream.

R05 additionally retains exit 128 for a nonexistent guessed ADR filename:
`docs/decisions/ADR-066-CLASSIC-ENVIRONMENT-ACTORS-EQUIPMENT-AND-FEEDBACK.md`.
R06 reads the actual ADR-066 path. R05/R07/R09 tool displays were also truncated;
retained selected native excerpts were read again where needed. R10 initially
inspected PrimaryLevelData.createTag; R12 repeats startup inspection with the
actual WorldGenSettings writer setTagData. Only the latter startup excerpts/read
metadata are retained, and no claim is made that R10 inspected setTagData.
