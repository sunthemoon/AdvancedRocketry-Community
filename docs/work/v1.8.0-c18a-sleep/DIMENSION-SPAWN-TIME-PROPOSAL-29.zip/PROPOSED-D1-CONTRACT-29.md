# C18a-SLEEP-01: proposed dimension, spawn-record and time sub-contract

Date: 2026-10-09 UTC. Status: **PROPOSED; not frozen, accepted, implemented or
runtime-qualified.** This is D1 only, supplementary to the original full-sleep
proposal. It is not a production-source assignment or the full sleep/API/respawn
item. Normative requirements below are proposed for fresh independent review.

## 1. Authority and scope

Governance checkpoint: `6d1b796e0e93b9953af505dd3fd9b25d47b91d97`.
Inspected isolated source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Primary platform: Minecraft 1.20.1, Forge 47.4.10, Java 17. The observed mapped
JAR, Forge source JAR and pinned javap identities are in `INPUT-HASHES.json`.

The owner's submitted answer in Main `OWNER-DECISION-01.md` is:

> 真正睡眠（推荐）：另行冻结并审核维度、出生点和时间行为后实施。

The exact ancillary question/answer in `OWNER-QUESTION-02.md` and
`OWNER-DECISION-03.md` selects natural=true with native ordinary compass,
local-clock and conditional Nether-portal piglin-attempt behavior, **no skipping
Earth's night and no changing existing spawn points**. The submitted answer is:

> 接受原生维度行为，按上述范围冻结并审核。

The recorded answer supplies no submission timestamp. It resolves the former
ancillary-choice question, not the separate freezing/review condition. It does
not select a spawn-cause recognizer, Space gap/station rule, planetary-respawn
option, custom time system, direct sleeping bypass, API, migration or Gate result.

This proposed D1 scope is the six packaged hosts below, native sleep lifecycle,
ordinary-bed-caused spawn preservation and unchanged native time ownership.
Successful rest is not a promise of morning, a safe compass target, or a new
respawn destination. Genuine breathable admission and wake are requirements of
the separate full-sleep contract, not established by dimension flags alone.

## 2. Stable identities and source-established resource facts

Level key and dimension-type key are different registry identities even where
their ResourceLocation strings match. The six proposed Level/type pairs are:

| Packaged host | Level ResourceLocation | Dimension-type ResourceLocation | Current type resource root | Fixed time |
|---|---|---|---|---|
| Moon | `advancedrocketrycommunity:moon` | `advancedrocketrycommunity:moon` | `src/generated/v1.4/resources` | 18000 |
| Space | `advancedrocketrycommunity:space` | `advancedrocketrycommunity:space` | `src/generated/v1.4/resources` | 18000 |
| Mars | `advancedrocketrycommunity:mars` | `advancedrocketrycommunity:mars` | `src/generated/v1.4/resources` | absent; native cycle |
| Venus | `advancedrocketrycommunity:venus` | `advancedrocketrycommunity:venus` | `src/generated/v1.4/resources` | absent; native cycle |
| Tau Ceti f | `advancedrocketrycommunity:tau_ceti_f` | `advancedrocketrycommunity:tau_ceti_f` | `src/generated/v1.8/resources` | absent; native cycle |
| Tau Ceti g | `advancedrocketrycommunity:tau_ceti_g` | `advancedrocketrycommunity:tau_ceti_g` | `src/generated/v1.8/resources` | absent; native cycle |

Each type resource is `data/advancedrocketrycommunity/dimension_type/<name>.json`.
All six inspected files have natural=false, bed_works=true and
respawn_anchor_works=false. Common unchanged values are ultrawarm/piglin_safe/
has_ceiling/has_raids=false; coordinate_scale=1; min_y=0; height/logical_height=256;
infiniburn=`#minecraft:infiniburn_overworld`; both monster-light limits=0.
Moon has ambient_light=0.1; the others 0. Space alone lacks skylight and uses
`advancedrocketrycommunity:planetary_space` effects; the other five have skylight
and `advancedrocketrycommunity:planetary` effects.

The current packaged dimension resources are separately owned: Space's empty
flat Level is in v0.3; Moon/Mars/Venus and both Tau Levels are in v1.8. Moon/Tau f
use multi-noise biomes, Mars a fixed biome, Venus/Tau g the ARCE patch source;
all five surfaces use their existing noise-settings IDs. Changing a type is not
permission to regenerate terrain, alter a biome/router/salt or replace a Level.
Earth's logical `advancedrocketrycommunity:earth` remains `minecraft:overworld`;
Nether/End, gas giants, logical orbits and arbitrary data-pack Levels are not added
to supported sleep hosts. Multiple stations/orbits still inhabit the one Space
Level. Lifetime body-to-Level reservations remain unchanged.

## 3. Proposed generation, startup and upgrade requirements

**D1-01.** The sole reviewed type-field delta is natural=false -> true for these
six type IDs. Preserve every other field, absence/presence of fixed_time, stable
identity and dimension/generator resource. Never edit native player or world data
to manufacture this resource delta.

**D1-02.** Preserve historical v0.3/v1.4 generated resources and their authoring
semantics. The current v1.8 `BootstrapDataGenerators` runs `V180Worldgen`, whose
DIMENSION_TYPE bootstrap exports Tau f/g, and `V180PlanetDimensions`, which does
not export types. Moon/Space historic sky-provider types and Mars/Venus historic
worldgen types are not regenerated by that v1.8 run. A later integration task must
name the exact current writer for each new/revised type and prevent two providers
writing the same output during a run; merely adding another six-type provider
would conflict with the existing Tau writer. No provider strategy is adopted here.

**D1-03.** `build.gradle` currently excludes v0.3 Moon/Space type copies in both
processResources and sourcesJar. Any v1.8 Moon/Space/Mars/Venus replacements need
precise historical-copy exclusions in both tasks without excluding their current
replacements. Require exactly one packaged entry for every type path, identical
runtime/source-resource selection, and deterministic repeated DataGen. Resource
and build changes belong to a separately declared integrator scope.

**D1-04.** The compiled startup loader loads dimension types as worldgen registry
data and Level stems as dimension data before Level creation; reloadable resources
consume frozen access. ARCE catalog reload publishes definitions/routes and checks
world bindings; it does not mutate existing Level holders. Require an ordinary
restart to adopt a reviewed type change. `/reload` must not be represented as a
running-Level natural-flag upgrade.

**D1-05.** A fresh world and a copied prior world must independently read back all
six actual started Level/type keys, complete type values, generator identity,
catalog/bindings, data ownership and saved WorldGenSettings before/after a normal
save/restart. PrimaryLevelData encodes WorldGenSettings using registry access;
this inspection does not establish prior-world merge/holder-replacement outcomes.
JSON inspection alone cannot qualify upgrade. A mismatched/missing/reused type or
unsupported mapping must not be credited as supported sleep. Preserve original
fixtures and record the mismatch; do not hot-retype, delete dimension directories,
remap keys, clear spawn records or add save-veto/world-repair behavior under D1.

The flag applies to every Level referencing a changed type, not only while a
player sleeps. A data pack reusing an owned type may therefore inherit its native
ancillary behavior; that does not make its additional Level a supported sleep
host. Installed-pack precedence, such reuse and feature-disable presentation must
be explicitly documented/qualified, not hidden by runtime client-property edits.

## 4. Proposed spawn-record operation contract

**Source-established ordering:** ServerPlayer.startSleepInBed invokes the Forge
sleep hook before natural/range/obstruction checks. At bytecode 107-122 it calls
setRespawnPosition before the time and monster checks. The setter posts
PlayerSetSpawnEvent before native fields or the set-spawn message change; a
canceled event returns before both. The event carries player, Level, nullable
position and forced flag, but no bed cause or operation identity.

**D1-06.** Ordinary bed interaction on a supported off-world host must not replace
or create the player's native respawn point, including successful sleep and later
daytime/monster refusal. Preserve dimension, nullable position, angle and forced
state. A previously absent point stays absent; an existing administrative or
off-world point is not rewritten to Overworld. Successful rest is not refused
merely because its bed-caused spawn update is prevented. Native Overworld bed
behavior remains unchanged.

**D1-07.** This constraint is operation-scoped, not a global off-world setter veto.
Null reset, operator `/spawnpoint`, native respawn restoration and unrelated
administrative/mod setters retain their existing pipeline and cancellation
behavior, including nested operations during a bed attempt. Never undo another
listener's cancellation or claim a listener priority is the exclusive final writer.
Freeze/qualify the discriminator, receiver/callback boundary, indeterminate result
and coexistence strategy in B1/R1 before an enforcing assignment. D1 selects none:
no lasting player marker, StackWalker classifier, wrapper, rollback, AT/private
access or direct startSleeping is authorized by this outcome requirement.

**D1-08.** Persistence remains native `SpawnDimension`, `SpawnX`, `SpawnY`,
`SpawnZ`, `SpawnAngle`, `SpawnForced`; no new sleep schema/SavedData/API is proposed.
Compare typed field presence/values through controlled native saves, not entire
player blobs that legitimately change statistics. Existing off-world records are
not cleared or migrated. Native respawn looks up its target before
PlayerRespawnEvent; BedBlock.canSetSpawn tests bedWorks, not natural. Thus old
off-world bed/forced records can retain native death-time behavior even on the
old natural=false baseline. D1 does not make them air/access/load-safe or complete
ADR-066's allow/force respawn policy. Native SpawnForced is not force-air permission;
packaged anchors remain disabled. Unsupported/corrupt records follow existing
native handling, without introducing a new repair/save-control policy here.

## 5. Proposed time/quorum ownership

**Source-established facts:** MinecraftServer.createLevels constructs each
non-Overworld Level with DerivedLevelData and tickTime=false. The derived data
delegates game/day-time, weather and spawn-coordinate reads to primary data; its
time/weather setters return without writing. Each ServerLevel owns its SleepStatus.
The local completion path calls SleepFinishedTimeEvent/setDayTime only when
doDaylightCycle is true, then wakes local sleepers independently of that rule;
weather reset is separately conditional on doWeatherCycle and rain.

**D1-09.** Keep native per-Level quorum and playersSleepingPercentage. Spectators
are excluded; the required count is max(1, ceil(active * percentage / 100)). Native
deep sleep requires the actual sleeping counter >=100. Two stations in Space
share one quorum; separate surface Levels do not vote together. Preserve native
creative, percentage >100, insufficient-quorum and daylight-rule behavior. Do not
set daytime ALLOW merely to make cyclic surfaces sleep at any hour.

**D1-10.** No ARCE completion listener forwards off-world completion to primary
time/weather, adds a second clock owner, or advances machine/satellite/oxygen time.
An off-world quorum can complete rest/wake without turning Earth to morning.
Overworld native completion may still advance the shared read clock and change
cyclic surfaces' observed daylight. Moon/Space fixed visual time remains 18000;
Level.isDay and isNight both return false for fixed types, while the default Forge
time check uses !isDay. Do not promise a changing Moon/Space sky or a persisted
sleep counter. Native saved-player reading stops a saved sleeping pose; disconnect,
replacement and restart occupancy/counter reconciliation still require runtime
evidence, not a newly invented offline-sleep continuation.

## 6. Accepted native ancillary effects; proposed compatibility boundaries

1. Ordinary non-lodestone compass target becomes GlobalPos(current Level key,
   Level.getSharedSpawnPos()). It is not the player's bed, station pad, oxygen-safe
   landing or a target to teleport to. Derived coordinate reads normally share
   primary spawn values; getSharedSpawnPos also retains its native out-of-border
   fallback to the Level's border center/heightmap. Preserve that behavior rather
   than substituting raw coordinates or promising a safe point. Lodestone/recovery
   compass mechanics are not redesigned by D1.
2. Native clock property uses local getTimeOfDay instead of random time. Moon/Space
   present their fixed time; other hosts follow native shared-clock observation.
   This is clock presentation, not a new independent planetary time service.
3. Loaded native Nether portal random ticks may attempt ZOMBIFIED_PIGLIN with
   STRUCTURE reason if natural, doMobSpawning, difficulty/random and floor checks
   permit. This is not guaranteed portal availability, successful mob admission,
   new portal travel routing, or the separate atmosphere natural/spawner actor
   policy. Keep other Forge spawn listeners; do not disguise the delta through
   blanket STRUCTURE cancellation.

These native effects are selected by the owner's exact candidate answer, but
their candidate-bound source/resource, startup/upgrade and client observations
remain unexecuted. Baseline 47.4.10 is primary; 47.4.23 and installed compatibility
mods need their own evidence. No reflection/transformer/custom-bed immunity or
general data-pack-host support follows from this static inspection.

## 7. Unresolved inputs and independent runtime obligations

D1 still needs a fresh complete review and explicit frozen disposition of these
requirements, resource writer/exclusion ownership, upgrade readback, unsupported
pack boundaries and compatibility/recovery notes. B1's exact cause/failure/final-
writer strategy and R1's callback/inherited-receiver boundary remain separate.
M1's registered-bed pre-admission and occupancy/adjacent-door air revocation remain
unqualified. M2's actual-host/live-access projection, gap-versus-station choice and
permission footprint remain unselected. D1 does not remedy or adopt any of those
mechanisms. Completing D1 review alone does not authorize a natural-only gameplay
patch or waive the other prerequisites.

All rows below are **UNEXECUTED**. They define finite evidence, not observed results.
Use real started packaged Levels and normal connected-player bed operations where
required; fabricated Levels/direct startSleeping and Overworld-only observation
fixtures cannot substitute. Capture candidate commit/JAR, fixture hashes, command,
UTC/exit, typed state and complete failure receipts. Run one enumerated case at a
time; no unbounded random search or timeout enlargement.

| ID | Finite verification scope | Required observations |
|---|---|---|
| D1-V01 | Six current/revised type pairs; both packaging tasks; two DataGen runs | natural-only semantic delta, one entry/path/writer, no terrain or historic changes, empty generated diff |
| D1-V02 | One fresh world and one preserved prior-world copy; six hosts; save/restart each copy twice | actual keys/holders/flags/generators, registry/catalog/binding identities and saved registry continuity; no world-directory or player-record rewrite |
| D1-V03 | One catalog reload and one controlled overriding/missing/reused-type pack configuration | started types not hot-mutated; supported-host limits and discrepancy visible; originals preserved |
| D1-V04 | Each host: ordinary successful bed use with valid preexisting home point; one absent-point control | native rest achieved once full-sleep prerequisites qualify; intended native spawn state unchanged immediately and after native save/restart |
| D1-V05 | One cyclic host: native daytime and monster refusals; early air/range/obstruction refusals | no bed-caused spawn update in early/late branches; native refusal retained; no stale cause state |
| D1-V06 | B1/R1-defined finite unrelated, nested, null/admin/restore and indeterminate controls | operation isolation/coexistence; no blanket veto; failures retained; no result credited until B1/R1 qualify |
| D1-V07 | One copied prior world with known native off-world bed and forced records; one invalid home bed | records preserved; exact native residual/fallback reported; no claim of safe planetary-respawn acceptance |
| D1-V08 | Two players same host at 100%, 50%, 101%; spectator and disconnect controls | local active/sleep/deep counts, native 100-tick threshold, insufficient-quorum/manual wake; no durable stale counter |
| D1-V09 | Two Space stations and two distinct surface hosts; off-world-only and simultaneous Overworld completion | one Space quorum/separate surface quorums; game/day time, fixed time, data owner and weather before/after; no added Earth skip/weather write |
| D1-V10 | One fixed and one cyclic host; doDaylightCycle false/true; weather-cycle/rain controls | native local wake independent of daylight write; fixed sky retained; primary weather/time ownership preserved |
| D1-V11 | Six hosts with ordinary/lodestone/recovery compass and clock; moved shared spawn and one border control | native target/presentation and unchanged other mechanics; no safe-arrival implication; later V1/V2 evidence |
| D1-V12 | One already-loaded controlled portal with enabled/disabled mob rule, peaceful/nonpeaceful and existing Forge veto | conditional STRUCTURE attempt characterized without changing portal routing/actor policy; no unsupported success claim |
| D1-V13 | Native saved sleep, leave-bed, logout/replacement, stop/restart; two real clients | pose/bed/counter reconciliation, spawn preservation, bounded messages/network; no resumed offline sleep |

The implementation still requires clean build, test, runData, git diff --exit-code
and runGameTestServer, plus affected finite packaged/restart/security checks.
Preserve existing scan/NBT/network/log/performance budgets and zero new adapter-
induced forced loading; retain native pre-normalization loaded-half proof in B1.
Client compass/clock/sleep changes need actual V1/V2 acceptance at its scheduled
stage. Static checks here do not run those commands or close G0-G9.

Recovery means preserving original world/player fixtures and stable IDs. Returning
a type to natural=false does not erase saved spawn records or retroactively prove
a safe downgrade. Any migration, quarantine, world-load/save rejection or changed
respawn fallback needs its separately scoped risk/ADR/review and recovery contract.
Fresh independent review should assess complete D1 text against fixed owners,
actual providers/resources/build selection and pinned primary methods; report
findings and remaining evidence without a prefixed verdict or implementation grant.
