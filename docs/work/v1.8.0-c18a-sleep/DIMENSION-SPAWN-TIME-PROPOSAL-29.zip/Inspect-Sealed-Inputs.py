"""In-memory inspection of small sealed research ZIPs; no extraction."""
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

LEAF = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
EXPECTED = {
    'CONTRACT-RESEARCH-01.zip': '71047c5a18ef4e2a925f6e4feefe5f18c01c27205aa8f9ec6b6d8033221e7007',
    'CONTRACT-INDEPENDENT-01.zip': '24df674e72e53187ed2c7b12651986d61151535beee070463e84f8ac5fe1d164',
    'SPAWN-FEASIBILITY-02.zip': '101452b8fcef931dbae693dd4be45937ff9f58958a4ee041d1ce561a6e7bc0e8',
    'AIR-FEASIBILITY-02.zip': 'd272e2a94129279416b01c5b489c788acbd6c2d117d62715f1b3ff7323b6c39d',
    'BOUNDARY-INDEPENDENT-03.zip': '78896073d96d27e85168aa62fb9e32a99ef01685f1f5760fd72e05a595a64664',
}
results = []
for name, expected in EXPECTED.items():
    started = datetime.now(timezone.utc).isoformat()
    path = ROOT / name
    archive_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        entries = z.infolist()
        if len(entries) > 100 or sum(i.file_size for i in entries) > 2_000_000:
            raise ValueError('ZIP size bound exceeded')
        names = [i.filename for i in entries]
        safe_names = all(not n.startswith(('/', '\\')) and ':' not in n and '..' not in n.split('/')
                         and '\\' not in n for n in names)
        unique_names = len(names) == len(set(n.casefold() for n in names))
        failures = []
        count = 0
        for line in z.read('SHA256SUMS.txt').decode('utf-8').splitlines():
            match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
            if not match:
                failures.append({'line': line, 'error': 'unsupported manifest line'})
                continue
            expected_hash, entry = match.groups()
            actual = hashlib.sha256(z.read(entry)).hexdigest()
            count += 1
            if actual != expected_hash.lower():
                failures.append({'entry': entry, 'error': 'hash mismatch'})
        bad_crc = z.testzip()
        row = {'archive': name, 'utc_start': started, 'archive_sha256': archive_hash,
               'matches_published_archive_identity': archive_hash == expected,
               'entries': len(entries), 'uncompressed_bytes': sum(i.file_size for i in entries),
               'covered_hashes': count, 'safe_relative_names': safe_names,
               'case_unique_names': unique_names, 'manifest_failures': failures, 'bad_crc_entry': bad_crc,
               'utc_end': datetime.now(timezone.utc).isoformat()}
        results.append(row)
        print(json.dumps(row))
(LEAF / 'SEALED-INPUT-CHECKS.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
if any(not r['matches_published_archive_identity'] or not r['safe_relative_names'] or
       not r['case_unique_names'] or r['manifest_failures'] or r['bad_crc_entry'] for r in results):
    raise SystemExit(1)
