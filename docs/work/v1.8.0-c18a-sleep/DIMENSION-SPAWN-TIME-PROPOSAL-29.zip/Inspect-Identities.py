"""Bounded static Git/file/ZIP identity inspection, not a runtime test."""
import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')
SOURCE = Path('D:/GitHub/arce-v180-sleep-chat-boundary-20261009')
GOV_SHA = '6d1b796e0e93b9953af505dd3fd9b25d47b91d97'
SRC_SHA = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
PACKAGE = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
GOV_PATHS = [
    'AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
    'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/status/CURRENT_VERSION.md', 'docs/status/GATE_STATUS.md',
    'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
    'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
] + ['docs/work/v1.8.0-c18a-sleep/' + name for name in [
    'OWNER-DECISION-01.md', 'OWNER-QUESTION-02.md', 'OWNER-DECISION-03.md',
    'PROPOSED-CONTRACT-01.md', 'RESEARCH-STATUS-01.md',
    'CONTRACT-REVIEW-STATUS-01.md', 'SPAWN-RESEARCH-STATUS-02.md',
    'AIR-RESEARCH-STATUS-02.md', 'BOUNDARY-REVIEW-STATUS-03.md',
]]
SOURCE_PATHS = ['build.gradle'] + [PACKAGE + name for name in [
    'datagen/FixedDimensionProvider.java', 'datagen/V180PlanetDimensions.java',
    'datagen/PlanetarySkyProvider.java', 'datagen/PlanetaryWorldgen.java',
    'datagen/V180ExoplanetWorldgen.java', 'datagen/BootstrapDataGenerators.java', 'datagen/V180Worldgen.java',
    'celestial/CelestialIds.java', 'celestial/content/PlanetaryContent.java',
    'celestial/exoplanet/ExoplanetContent.java',
    'celestial/data/PlanetaryCatalogManager.java',
    'celestial/binding/PlanetaryBindingLifecycle.java',
    'celestial/binding/PlanetaryBindings.java',
    'celestial/service/PlanetarySurfaceResolver.java',
]] + ['src/generated/' + version + '/resources/data/advancedrocketrycommunity/' + kind + '/' + name + '.json'
      for version, kind, name in [
          ('v1.4', 'dimension_type', 'moon'), ('v1.4', 'dimension_type', 'space'),
          ('v1.4', 'dimension_type', 'mars'), ('v1.4', 'dimension_type', 'venus'),
          ('v1.8', 'dimension_type', 'tau_ceti_f'), ('v1.8', 'dimension_type', 'tau_ceti_g'),
          ('v0.3', 'dimension', 'space'), ('v1.8', 'dimension', 'moon'),
          ('v1.8', 'dimension', 'mars'), ('v1.8', 'dimension', 'venus'),
          ('v1.8', 'dimension', 'tau_ceti_f'), ('v1.8', 'dimension', 'tau_ceti_g'),
      ]]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def blob(root, sha, path):
    run = subprocess.run(['git', '-C', str(root), 'show', sha + ':' + path],
                         capture_output=True, timeout=180)
    row = {'checkout': str(root), 'commit': sha, 'path': path, 'exit_code': run.returncode}
    if run.returncode:
        row['stderr'] = run.stderr.decode('utf-8', errors='replace')
    else:
        row.update(bytes=len(run.stdout), sha256=digest(run.stdout))
        working = root / path
        row['working_bytes_equal_fixed_blob'] = working.is_file() and working.read_bytes() == run.stdout
        print(f"{sha[:8]} {path} {row['sha256']} working_equal={row['working_bytes_equal_fixed_blob']}")
    return row

record = {'utc_start': datetime.now(timezone.utc).isoformat(),
          'governance': [blob(MAIN, GOV_SHA, p) for p in GOV_PATHS],
          'source': [blob(SOURCE, SRC_SHA, p) for p in SOURCE_PATHS]}
archives = []
for name in ['CONTRACT-RESEARCH-01.zip', 'CONTRACT-INDEPENDENT-01.zip',
             'SPAWN-FEASIBILITY-02.zip', 'AIR-FEASIBILITY-02.zip', 'BOUNDARY-INDEPENDENT-03.zip']:
    path = MAIN / 'docs/work/v1.8.0-c18a-sleep' / name
    data = path.read_bytes()
    with zipfile.ZipFile(path) as z:
        if len(z.infolist()) > 100 or sum(i.file_size for i in z.infolist()) > 2_000_000:
            raise ValueError('Evidence ZIP exceeds bounded inspection limits')
        entries = [{'entry': i.filename, 'bytes': i.file_size, 'sha256': digest(z.read(i))}
                   for i in z.infolist() if i.filename.endswith(('.md', '.json', 'SUMS.txt'))]
    archives.append({'path': str(path), 'bytes': len(data), 'sha256': digest(data), 'selected_entries': entries})
record['archives'] = archives
first = MAIN / 'docs/work/v1.8.0-c18a-sleep/CONTRACT-RESEARCH-01.zip'
with zipfile.ZipFile(first) as z:
    pinned = json.loads(z.read('INPUT-HASHES.json'))
record['primary_files'] = []
for row in pinned['primary_inputs']:
    data = Path(row['path']).read_bytes()
    actual = {'path': row['path'], 'bytes': len(data), 'sha256': digest(data)}
    actual['matches_sealed_primary_identity'] = (actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'])
    record['primary_files'].append(actual)
    print('PRIMARY', json.dumps(actual))
record['forge_source_entries'] = []
with zipfile.ZipFile(pinned['primary_inputs'][1]['path']) as z:
    for name in [
        'net/minecraftforge/event/entity/player/PlayerSetSpawnEvent.java',
        'net/minecraftforge/event/entity/player/PlayerSleepInBedEvent.java',
        'net/minecraftforge/event/entity/player/SleepingTimeCheckEvent.java',
        'net/minecraftforge/event/level/SleepFinishedTimeEvent.java',
    ]:
        data = z.read(name)
        record['forge_source_entries'].append({'entry': name, 'bytes': len(data), 'sha256': digest(data)})
record['task'] = {'path': 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-DIMENSION-SPAWN-TIME-CONTRACT-TASK-29.md'}
task = Path(record['task']['path']).read_bytes()
record['task'].update(bytes=len(task), sha256=digest(task))
record['utc_end'] = datetime.now(timezone.utc).isoformat()
target = LEAF / 'INPUT-HASHES.json'
target.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('INPUT-HASHES', target, 'bytes=', target.stat().st_size)
