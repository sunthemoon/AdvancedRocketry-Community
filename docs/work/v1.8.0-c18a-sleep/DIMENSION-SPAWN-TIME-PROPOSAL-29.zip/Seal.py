"""One-time evidence seal after Root's actual full-read acknowledgment."""
import hashlib
import json
import stat
import sys
from datetime import datetime, timezone
from pathlib import Path

STARTED = datetime.now(timezone.utc).isoformat()
LEAF = Path(__file__).resolve().parent
EXPECTED_LEAF = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29').resolve()
MANIFEST = LEAF / 'SHA256SUMS.txt'
RECEIPT = LEAF / 'SEAL-RECEIPT.json'
assert LEAF == EXPECTED_LEAF
assert not MANIFEST.exists() and not RECEIPT.exists(), 'Do not reseal or replace receipts'
assert (LEAF / 'ROOT-FULL-READ-ACKNOWLEDGMENT.md').is_file()
EXPECTED = {
    'PROPOSED-D1-CONTRACT-29.md': '523b38847658df2199bdbe7ecfc07bbcf8e8179ab4c31bfcce78c07d85aa1c4b',
    'REPORT.md': 'ce8bb6745d32a379bfb71d7d31488ce2c3171ec1555dbed13c2bb9ae8c258b9e',
}
for name, expected in EXPECTED.items():
    assert hashlib.sha256((LEAF / name).read_bytes()).hexdigest() == expected
files = sorted(LEAF.rglob('*'), key=lambda p: p.relative_to(LEAF).as_posix())
rows = []
names = set()
for path in files:
    attributes = getattr(path.lstat(), 'st_file_attributes', 0)
    assert not path.is_symlink() and not attributes & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)
    assert path.resolve().is_relative_to(LEAF)
    if not path.is_file():
        continue
    name = path.relative_to(LEAF).as_posix()
    assert name not in ('SHA256SUMS.txt', 'SEAL-RECEIPT.json')
    assert ':' not in name and not name.startswith('/') and '..' not in name.split('/')
    assert name.casefold() not in names
    names.add(name.casefold())
    data = path.read_bytes()
    assert len(data) <= 50_000_000
    rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
covered_bytes = sum(r['bytes'] for r in rows)
assert covered_bytes <= 100_000_000
manifest_bytes = ''.join(r['sha256'] + '  ' + r['path'] + '\n' for r in rows).encode('utf-8')
with MANIFEST.open('xb') as stream:
    stream.write(manifest_bytes)
for row in rows:
    assert hashlib.sha256((LEAF / row['path']).read_bytes()).hexdigest() == row['sha256']
receipt = {
    'utc_start': STARTED, 'utc_end': datetime.now(timezone.utc).isoformat(),
    'command': [sys.executable, '-B', str(Path(__file__).resolve())], 'exit_code': 0,
    'root_acknowledgment': 'ROOT-FULL-READ-ACKNOWLEDGMENT.md',
    'scope': 'ONE_TIME_STATIC_EVIDENCE_SEAL_ONLY_NOT_D1_FREEZE_OR_ACCEPTANCE',
    'manifest': 'SHA256SUMS.txt', 'manifest_bytes': len(manifest_bytes),
    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'covered_files': len(rows), 'covered_bytes': covered_bytes,
    'verified_covered_hashes': len(rows), 'safe_relative_case_unique_paths': True,
    'excluded_manifest_self': ['SHA256SUMS.txt'], 'all_excluded_later_receipts': ['SEAL-RECEIPT.json'],
    'no_covered_file_changed_after_manifest_write': True,
    'no_runtime_tests_or_production_changes': True,
}
with RECEIPT.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2))
print('SEAL_RECEIPT_SHA256', hashlib.sha256(RECEIPT.read_bytes()).hexdigest())
