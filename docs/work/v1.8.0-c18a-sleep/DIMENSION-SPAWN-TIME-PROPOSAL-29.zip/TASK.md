# Task 29 identity and authority

Original task: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-DIMENSION-SPAWN-TIME-CONTRACT-TASK-29.md`.
SHA-256: `9aae475f9cde781c65e4b076fe7e6fe476fe87deae24f0393c4f860d130e38bf`.
Assigned by Root on 2026-10-09 to delegated worker
`/root/sleep_dimension_spawn_time_contract`. The original task was completely read.

Exclusive writes are this evidence leaf only. Main at fixed 6d1b796e and isolated
source at fixed d57ecda1, sealed inputs, other leaves and all repository files are
read-only. No delegation/Claude, implementation, commits, worktree/HEAD mutation,
Gradle/test/Java application/game/server/world/client/driver/parser execution,
network/install, quotas/mounts or cleanup is authorized. Bounded read-only
Git/file/hash/ZIP inspection, Python -B helpers and pinned javap are allowed.
No production policy, ADR acceptance, state/Gate/ledger change or source assignment
authority is delegated. Root coordinates OpenPet and other workers.

Delivery is a self-contained PROPOSED D1 sub-contract and findings-first REPORT,
read receipts, fixed identities and small audit-relevant primary excerpts. All
runtime criteria must remain unexecuted here. Root must completely read proposal
and REPORT before authorizing a one-time manifest; later seal receipts are
explicitly excluded from that manifest to avoid self-referential checksums.

Root separately notified this worker that Root27 began Main central record edits
while this task was active. The fixed governance checkpoint remains 6d1b796e;
no later uncommitted Main content is adopted as this contract's authority.
