param(
    [Parameter(Mandatory = $true)][string]$Id,
    [Parameter(Mandatory = $true)][string]$CommandText
)
$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$started = [DateTime]::UtcNow.ToString('o')
$global:LASTEXITCODE = 0
$exitCode = 0
$output = @()
try {
    $output = @(& ([ScriptBlock]::Create($CommandText)) 2>&1)
    if ($global:LASTEXITCODE -ne 0) { $exitCode = $global:LASTEXITCODE }
} catch {
    $output += $_.ToString()
    $exitCode = 1
}
$ended = [DateTime]::UtcNow.ToString('o')
$outputText = ($output | ForEach-Object { $_.ToString() }) -join "`n"
$utf8 = [Text.UTF8Encoding]::new($false)
$hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($utf8.GetBytes($outputText))).ToLowerInvariant()
$receipt = [ordered]@{
    id = $Id
    utc_start = $started
    utc_end = $ended
    command = $CommandText
    exit_code = $exitCode
    merged_display_utf8_bytes = $utf8.GetByteCount($outputText)
    merged_display_sha256 = $hash
    raw_stream_retained = $false
    timeout_ceiling_seconds = 180
}
[IO.File]::AppendAllText((Join-Path $leaf 'READ-COMMANDS.jsonl'), (($receipt | ConvertTo-Json -Compress -Depth 5) + "`n"), $utf8)
$outputText
"READ_RECEIPT $Id exit=$exitCode start=$started end=$ended"
exit $exitCode
