# Task 29: dimension, spawn-record and time contract preparation

Date: 2026-10-09 UTC. Delegated worker `/root/sleep_dimension_spawn_time_contract`.
This report delivers static proposal/evidence only. No policy adoption, fixed
review verdict, implementation-readiness or runtime acceptance is asserted.

## Findings and uncertainties first

1. **D1 remains conditional, not unanswered product choice.** The owner's exact
   submitted answer accepts natural=true and the stated compass/clock/conditional
   portal effects, without Earth-night skipping or changing existing spawn points.
   It still requires separate freezing/review. `PROPOSED-D1-CONTRACT-29.md` separates
   that selection, independently inspected facts, proposed requirements, remaining
   inputs and unexecuted acceptance. Its content cannot itself assign production.
2. **Ordinary sleep has a spawn mutation before late refusal.** Pinned native
   ServerPlayer.startSleepInBed:107-122 calls the setter before time/monster checks;
   the setter's Forge cancellation precedes fields/message changes. Spawn event
   fields do not identify cause. The proposal requires operation-scoped preservation
   but adopts no classifier/wrapper/interceptor. B1/R1 and their unknown/final-writer/
   callback/inherited-receiver cases remain open. An observation-only candidate is
   not default-spawn preservation implementation.
3. **Resource generation and upgrade need their own evidence.** All six current
   type resources are natural=false; four current types are historical v1.4 inputs,
   two are v1.8 Tau exports. Current v1.8 generation does not regenerate Moon/Space/
   Mars/Venus types. Another provider cannot safely race the Tau type writer. Exact
   provider selection/exclusions, actual fresh/prior-world holder readback and saved
   registry continuity are unexecuted. No claim is made that a JSON edit upgrades a
   saved world or that catalog reload mutates running Levels.
4. **Native completion ownership is local rest, with shared reads.** Inspected
   non-Overworld Levels use DerivedLevelData/tickTime=false. Local SleepStatus can
   complete/wake sleepers; derived setters do not forward to primary time/weather.
   Native Overworld completion can still affect cyclic off-world observations.
   Moon/Space fixed time remains 18000. These are static native facts and proposed
   preservation, not started-Level results. No global or per-station time mechanism
   is adopted.
5. **Compass target precision and residual spawn behavior matter.** The native
   target is current-Level getSharedSpawnPos, not a bed/landing pad. Its border
   fallback is retained explicitly. Old off-world spawn records already have native
   bed/forced respawn paths because bedWorks is unchanged; preserving records does
   not make those paths air/access/load-safe. D1 does not implement allow/force,
   migrate records, supply a safe destination, redesign portals, or qualify actor
   STRUCTURE-spawn policy.
6. **Other prerequisites are not solved here.** M1's registered interaction and
   occupancy/door invalidation, M2's actual-host/access projection and Space product
   choice, and the full sleep/API/respawn item remain separate. No PENDING grace,
   occupancy exemption, permission-footprint policy, native bypass, API/schema or
   atmospheric budget change is selected. No runtime failure or success for those
   mechanisms was reproduced by this task.

## Owner, governance and source identities

Original TASK SHA-256:
`9aae475f9cde781c65e4b076fe7e6fe476fe87deae24f0393c4f860d130e38bf`.
Governance Main: `6d1b796e0e93b9953af505dd3fd9b25d47b91d97`.
Isolated source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`, clean at initial read.
Main was on `codex/v1.8.0-classic-content` with preexisting modified AGENTS and
untracked evidence. Neither was acquired or edited. Root later notified its own
central record writes; fixed Git blobs remain this task's governance input.

Exact fixed owner-record SHA-256 identities:

| Record | SHA-256 |
|---|---|
| OWNER-DECISION-01.md | db19249fdd391bf45f7833052edfa323595b2c1efb45d7ee4747b91db8ab4f8c |
| OWNER-QUESTION-02.md | b12e7cb76fb580ad949f9cc093bcf0d4730d28745a7dd3abcc5631eebefa9366 |
| OWNER-DECISION-03.md | a07290d5d9c6b721419ddcc245da2dac5082ad0f0f1958b974928ccd336d795e |

The recorded source/channel is the owner's submitted asynchronous answer in Root,
not a worker-relayed authorization. The answer has no submission timestamp; no
timestamp is inferred. Mandatory governance/version/test/Gate/quality/parallel
documents were read; raw Git identities are recorded in `INPUT-HASHES.json`.
Their working bytes matched fixed blobs, apart from known AGENTS modification and
Root's later CURRENT_VERSION edits. Fixed status excerpts confirm v1.0 acceptance
IN_PROGRESS and separate active v1.8 development under accepted ADR-060; this task
does not move either cursor or extend any historical waiver.

Primary file SHA-256 identities were remeasured against sealed research inputs:

- Official-mapped Forge 47.4.10 JAR:
  `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
- Forge 47.4.10 source JAR:
  `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
- Existing Java 17.0.7 javap.exe:
  `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d`.

## Actual inspected inputs and commands

`INPUT-HASHES.json` identifies 24 fixed governance/owner/status/proposal blobs and
27 fixed source/resource/build blobs. Identity hashing is not a full content audit
of every unrelated method in those files. Relevant content reads include:

- PROJECT-CONFIG, PRODUCT, porting principles, roadmap, v1.8 version plan, master
  test plan, G0-G9 release policy, parallel coordination, post-1.0 roadmap and
  quality budgets; fixed ADR-060 and relevant ADR-066 environment/sleep section.
- Complete three owner records and original full-sleep proposal; RESEARCH,
  CONTRACT-REVIEW, SPAWN, AIR and BOUNDARY status records; selected original
  sealed report findings and primary-input identities. Original report histories
  remain historical, including formerly pending ancillary questions.
- Source build resource roots and both exclusion tasks; FixedDimensionProvider,
  PlanetarySkyProvider, relevant PlanetaryWorldgen/V180ExoplanetWorldgen bootstrap,
  V180Worldgen, V180PlanetDimensions and BootstrapDataGenerators; stable ID/content
  definitions, PlanetaryBindings, PlanetaryBindingLifecycle, catalog manager and
  surface resolver; all six authoritative type/dimension resources. No production
  ARCE sleep/spawn/time handler was found by the recorded source-keyword inventory;
  matched direct time setters were GameTest sources, not a new runtime time owner.
- Independently pinned javap inspection of 17 distinct native/Forge classes.
  Relevant methods are createLevels/startup/reload/save-registry paths;
  ServerLevel.tick/tickTime/resetWeatherCycle/setDayTime; SleepStatus methods and
  DerivedLevelData delegates/no-op setters; fixed-time/day/night/deep-sleep checks;
  sleep/setter/save/read/respawn paths; native bedWorks check; compass/clock/portal
  methods and getSharedSpawnPos; Forge sleep-time/spawn/sleep-finished factories.
  `NATIVE-*-READS.json` records individual commands/UTC/exit and raw class hashes.
  Excerpts are deliberately small/noncontiguous, not full libraries or sources.
- Four specific event source entries were read from the pinned Forge JAR:
  PlayerSetSpawnEvent, PlayerSleepInBedEvent, SleepingTimeCheckEvent and
  SleepFinishedTimeEvent. Their raw identities are recorded; no Forge source was
  imported into production. No Advanced Rocketry/LibVulpes upstream or art was
  opened/imported. No network was used.

`READ-COMMANDS.jsonl` contains exact R01-R16 outer commands with true pre/post UTC,
exit, merged-display byte count/hash and explicit no-raw-stream-retention flag.
Python subprocesses use 180-second timeouts; all observed read commands complete
well below the assignment's 180-second ceiling. Preliminary commands and display
truncations are disclosed in `PRE-HARNESS-READS.md`, not reconstructed as raw proof.

Actual command results: R01-R04 and R06-R16 exit 0; R05 exit 128 for a nonexistent
guessed ADR filename, corrected under R06. The preliminary guessed lowercase
version filename exits 1, corrected by discovery of the actual uppercase filename.
No native javap command failed. R10's createTag inspection was insufficient for
saved registry writing; R12 reads setTagData and retains its corrected excerpts.
Hash-only output and static ZIP integrity checks are not runtime tests.

Five sealed research ZIPs were independently checked in memory against their
published archive SHA, every manifest-covered SHA, relative/case-unique names and
CRC. `SEALED-INPUT-CHECKS.json` records: CONTRACT-RESEARCH 37 covered hashes,
CONTRACT-INDEPENDENT 13, SPAWN-FEASIBILITY 83, AIR-FEASIBILITY 15 and
BOUNDARY-INDEPENDENT 10; all matched, with no CRC/name failures. The 5 archive
identities and selected entry hashes are in `INPUT-HASHES.json`. No input archive
was modified/extracted/repacked. These checks prove retained-input integrity only.

## Delivery, authority limits and unexecuted work

Completed scope: a separate self-contained PROPOSED D1 contract with stable IDs,
natural-only generation boundaries, startup/upgrade requirements, native ancillary
implications, spawn operation outcomes, time/quorum ownership and thirteen finite
runtime-obligation rows. Decision is to propose preservation requirements while
keeping all unproved mechanisms and candidate runtime outcomes separate.

Changed files: this leaf's TASK, proposal, REPORT, preliminary/read receipts,
bounded read helpers, input/sealed-input identities and small native excerpts/read
metadata only. Main/source/build/config/central state/ledger/Gate files and other
workers' evidence were not written. No commit/push/worktree/HEAD operation,
delegation/Claude, install/network, cleanup, world/server/client or observation-
driver/trace-parser execution occurred. Python -B created no intentional bytecode cache. No game
test, production implementation or test source was added/modified.

Uncompleted scope: independent full D1 review/freeze, B1/R1/M1/M2 qualification,
the eventual enforcing source assignment, every proposed runtime case, packaged
upgrade/save/restart/security and real-client observations, full sleep/respawn/API
acceptance and all v1.8 Required Gates. clean build, test, runData,
git diff --exit-code and runGameTestServer were prohibited and not run, not passed,
waived or relabeled NOT_APPLICABLE. No Gate/ledger item or release approval closes.

Outputs are in
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29/`.
Proposal: `PROPOSED-D1-CONTRACT-29.md`; report: `REPORT.md`; exact deliverable
line counts, bytes and SHA are sent to Root in `DELIVERY-IDENTITIES.json` after
this report is written. At this report checkpoint no manifest has been generated.
Root must completely read proposal/REPORT before authorizing the one-time seal.
Any later seal receipt/notification is explicitly excluded from its manifest;
no covered file may be rewritten after sealing. Root decides publication/review
assignment; this worker does not publish to Main or approve a policy.

Proposed next v1.8 work: a fresh independent reviewer reads complete D1 against
the exact owner/source/Git/native identities and checks its generation, operation,
time, compatibility and recovery boundaries. Report findings and unexecuted
obligations without a predetermined verdict. Resolve the separate prerequisites
and frozen dispositions before any enforcing implementation scope. Known risks
remain upgrade/type precedence, unwanted spawn mutation, baseline/coexistence and
callback identity, supplied-air feasibility, and overclaiming native residual
respawn/clock behavior. **All current-version Required Gates are not satisfied.**
