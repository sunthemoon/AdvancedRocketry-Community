# Independent review: proposed off-world sleep contract 01

Date: 2026-10-09 UTC. Reviewer: delegated worker `/root/sleep_contract_review`.
Task: `SLEEP-CONTRACT-REVIEW-TASK-01.md`, SHA-256
`945f9193eeaeca78ae4333934f47edf230f707746bb912875edabd05ac6493d5`.

## Findings and implementation prerequisites

This is a complete contract review, not an implementation review or Gate
acceptance. Findings below distinguish new contract corrections from already
disclosed prerequisites. `P` means the sealed
`PROPOSED-SLEEP-CONTRACT-01.md`; `S` means the exact Git blob at
`96236acb682c060796e41d3837af7991d492d3b1`. `J` means the independently inspected
Forge 47.4.10 official-mapped primary class, with method bytecode offsets.
The common Java prefix below is
`src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.
All source references are fixed-commit references, not mutable checkout claims.

### M1 — Ordinary native occupancy can invalidate the air that admitted sleep

**New Medium feasibility/contract gap; source-supported inference, not a runtime
reproduction.** P:133-148 requires an immediate normal wake at the first check
after authority becomes unavailable/PENDING. P:79-81 and 124-127 requires native
bed behavior. The contract does not resolve their interaction with existing
coarse atmosphere invalidation.

The inspected chain is concrete:

- J `LivingEntity.startSleeping`:20-41 calls `BlockState.setBedOccupied(true)`.
- J `IForgeBlock.setBedOccupied`:0-18 replaces `BedBlock.OCCUPIED` using
  `Level.setBlock(..., 3)`; it is not only a client presentation update.
- J `Level.markAndNotifyBlock`:93-108 calls `blockUpdated` for the neighbor-update
  flag. J `ServerLevel.blockUpdated`:7-10 calls `updateNeighborsAt`, whose 0-14
  posts Forge `NeighborNotifyEvent`.
- S `atmosphere/server/AtmosphereServerEvents.java`:74-89 marks the changed cell
  whenever *any* boundary provider exists. It also marks any notified adjacent
  door-like cell even when that door's OPEN property did not change.
- S `atmosphere/server/AtmosphereLevelService.java`:132-159 synchronously removes
  affected volume/provider authority and cancels affected scans. Its :223-249
  then cannot return controlled breathable air until repair/supply republishes it.
- S `atmosphere/server/AtmosphereServerEvents.java`:33-36 repairs through the
  atmosphere tick at server END. J `Player.tick`:83-97 performs the native
  sleep-time/wake check during player ticking.

A vacuum-host supplied room with a supported nonempty boundary catalog, or a bed
adjacent to an ordinary closed door, can therefore invalidate its own air just
by entering sleep. Whether the next wake check precedes successful repair is an
installed-order/room-size runtime input. The source proves synchronous revocation;
it does **not** by itself prove every bed always wakes immediately. A fabricated
manager with an empty catalog and no installed event wiring can miss this case.

**Correction/prerequisite:** add occupancy-induced invalidation to the frozen
contract and prerequisites. Qualify a real bed using the installed manager/event
adapter, with empty/nonempty catalogs and near/far doors, while recording authority,
pose, counters and scan timings. Include a room whose permitted scan cannot finish
before the next player check. If ordinary rest is interrupted, independently
review a precisely scoped way to distinguish atmosphere-neutral occupancy changes
from genuine topology/boundary changes. This may require an integration-owned
`AtmosphereServerEvents` correction and must be declared in its write scope.
Do not solve it by ignoring PENDING, delaying all loss-of-air checks, increasing
scan budgets, or bypassing native occupancy. Actual door/wall/provider/supply loss
must retain the accepted fail-closed behavior.

### M2 — Supplied Space gap rooms and required context are not reconciled

**New Medium contract ambiguity.** P:115-122 explicitly permits a supplied room
outside committed station regions. P:84-88 requires supported-host/catalog identity,
and P:135-146 requires wake on unavailable host/access state, including missing
context. The required Space projection is not specified tightly enough to tell
an implementation whether a missing orbit context is permissible.

- S `station/orbit/StationRegionBodyContextResolver.java`:21-35 returns
  `UNRESOLVED` when `findAt` has no committed region.
- S `celestial/context/BodyContextResolver.java`:42-49 returns empty immediately
  on UNRESOLVED; it does not continue to an otherwise unambiguous Space host.
- S `atmosphere/instrument/AtmosphereAnalyzerService.java`:88-100 requires an
  ORBIT context for its Space projection. Reusing that projection blindly would
  reject all gap rooms. The author report correctly calls it only a precedent,
  but the proposed sleep projection itself remains unspecified.
- S `atmosphere/server/AtmosphereManager.java`:132-141 resolves ambient air from
  the actual Level host, independently of a station's orbited surface.

**Correction:** specify the same projection for admission and continued sleep.
For the already proposed gap-allowing option, distinguish required actual Space
host/profile identity from optional station-orbit context: require an operational
registry, check the committed region at each relevant sampled position, apply
live VISIT when a region exists, and permit no-region supplied air without
requiring an invented orbit body. A blocked registry remains unavailable, not a
gap. Specify access checks for the entry cell and intended bed/eye cell when they
are on different region sides; while sleeping use the actual current position.
Narrow the phrase “missing context” so it does not immediately wake a legitimately
admitted gap sleeper. Alternatively propose station-only sleep explicitly; that
would change this product option and cannot be silently selected by a worker.
Add region-edge, operational-gap, blocked-registry and context-removal fixtures.

### B1 — The exact ordinary-bed spawn cause boundary is still an open prerequisite

**Already disclosed blocking technical input, not a newly hidden defect.** P:197-225
requires successful native sleep without overwriting the old respawn point, including
attempts that fail later time/monster admission. The proposed mechanism is not
established, and the proposal correctly says it is not implementation-assignment-ready.

Independent primary inspection confirms why:

- J `ServerPlayer.startSleepInBed`:5-19 fires the initial sleep failure event;
  53-72 tests natural; 73-106 tests range/obstruction;
  **107-122 writes spawn before** the time check at 125-139 and monster admission.
- J `ServerPlayer.setRespawnPosition`:0-21 posts `PlayerSetSpawnEvent` before
  updating fields or sending its changed-spawn message.
- The exact Forge event source declares player, target ResourceKey, position and
  forced flag, but no cause/caller/action token.
- J `PlayerList.respawn`:332-345 also calls the same setter to restore native
  respawn fields. A position/forced-only blanket rule is not cause-scoped.

The proposed short-lived marker is not a demonstrated cleanup mechanism.
Leaving a marker after an early failed native attempt, or treating the next matching
setter as proof of bed use, would threaten unrelated administrative/mod/restore
actions. This review does not supply an unproved replacement.

**Prerequisite:** retain P:215-225 as a hard source-assignment boundary. Provide
and independently review the exact public interaction wrapping/cause mechanism,
including canceled interaction, both bed halves, secondary-use/item-first behavior,
early and late native failures, reentrancy, listener exceptions, `/spawnpoint`, null
reset and respawn restoration. If no compliant public mechanism is feasible,
return a scoped alternative with its architecture/compatibility costs; do not
authorize AT/reflection/coremod or a blanket veto by implication.

### D1 — The actual-sleep choice does not decide native ancillary semantics

**Product/freezing input, not an implementation bug.** S
`docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-01.md`:12-26 selects actual sleep
conditional on dimension/spawn/time freeze and review. It expressly does not
approve arbitrary natural=true, a respawn policy, compass behavior or global skipping.
P:13-17 proposes real local rest without a shared night skip; P:41-63 proposes
natural=true including changed compass/clock/portal behavior. These are explicit
proposals, not owner-approved facts.

Before assigning source, the party with actual decision authority must record
whether to freeze this native-lifecycle/local-rest candidate and its ancillary
delta. If rejected, retain it as an alternative and separately research a narrower
mechanism. Preserving old random clock/compass or adding global night skipping is
not a cosmetic correction. No new owner question is necessary merely to perform
this review, and this report does not infer an authorization that chooses between
those outcomes. Existing integration authority, if used, must be cited with its
actual conditions; the original short reply alone is not such acceptance.

## Independently corroborated parts of the complete proposal

The review covered P:1-346, not only the author report's finding headings.
The following primary facts support the proposal's stated boundaries:

1. The six fixed packaged types have natural=false, bed_works=true and
   respawn_anchor_works=false; Moon/Space retain fixed_time 18000. Native
   `BedBlock.use` tests bedWorks before ordinary use, whereas ServerPlayer tests
   natural before starting actual sleep. Nullable `PlayerSleepInBedEvent` failure
   and time ALLOW do not bypass that earlier natural test.
2. Native sleep changes real occupancy/pose, sets the sleeping position, resets
   the counter through `Player.startSleepInBed`, and retains ServerPlayer native
   stat/criterion/list setup and wake synchronization. `LivingEntity.setPosToBed`
   offsets Y by .6875 and the native sleeping eye height is .2. The head cell is
   therefore the ordinary native sleeping eye cell. Extension-modified eye height
   remains an explicitly unexecuted compatibility input, not a tested guarantee.
3. The native player tick calls the sleep-time event and normal
   `stopSleepInBed(false, true)` on a false result. ServerPlayer reader stops saved
   sleeping pose on player load. No durable counter or restart-continuation claim
   is justified. Actual bed cleanup after logout/restart still needs fixtures.
4. Native per-Level SleepStatus excludes spectators, uses
   max(1, ceil(active * percentage / 100)), and counts long-enough actual sleepers
   (counter at least 100). Stations in the same Space Level share one quorum.
   `ServerLevel.tick`:76-145 gates the time write by doDaylightCycle but still
   wakes local sleepers; weather reset is separately gamerule/rain gated.
5. `MinecraftServer.createLevels`:430-478 constructs non-Overworld levels with
   DerivedLevelData and tickTime=false. Inspected DerivedLevelData time/weather
   reads delegate and corresponding setters immediately return. The proposal's
   no-ARCE-primary-write policy is coherent with these static facts; it is not a
   runtime observation in started upgraded Levels. Fixed-time Level isDay/isNight
   are both false, and the default time check is !isDay.
6. The independent bounded inventory scanned 7,110 native classes (10,000-entry,
   2 MiB/class, 128 MiB total, 20-javap-candidate ceilings), found seven byte
   candidates and four exact natural() calls: sleep admission, ordinary compass
   spawn target, clock property and Nether portal randomTick. The latter uses
   STRUCTURE, not NATURAL. This does not audit third-party reflective/mod uses or
   prove obtainable off-world portals. PhantomSpawner uses hasSkyLight instead.
7. Native respawn target selection happens before new-player restore/event;
   late PlayerRespawnEvent cannot prevent earlier target reads/selection. Existing
   off-world native records already have a bedWorks-based path under natural=false.
   Keeping their migration and safe-respawn work separate is acceptable for a
   declared sleep sub-slice, but cannot earn full default/opt-in planetary-respawn
   acceptance. The proposed shadow-target alternative is not frozen or implemented.
8. Existing atmosphere queries require a loaded full-cell preflight even for
   ambient BREATHABLE: base air short-circuits controlledAt's loaded check.
   Reusing authoritative air rather than suit/HUD state, retaining exposure/debit,
   keeping no new C2S or persistence object, and limiting observations are coherent
   constraints. Unsupported hosts/custom beds and safety return remain separately
   scoped rather than falsely delivered.
9. Data-generation replacements need explicit single-resource ownership and
   processResources/sourcesJar exclusions. Fresh and prior-world actual registry
   holder readback is still a necessary startup/migration qualification; editing
   generated JSON is not runtime evidence. No dimension key remapping or world
   deletion is authorized.

Forge's official [event documentation](https://docs.minecraftforge.net/en/1.20.1/concepts/events/)
confirms that cancellation and results are event-specific, and priorities run
from HIGHEST through LOWEST. It is supporting documentation, not evidence of the
specific native call order. Freeze listener ordering/coexistence and characterize
other listeners rather than promising that arbitrary later mod listeners cannot
overwrite event results. No generic ALLOW/cancel convention was substituted for
the exact locally inspected event payloads.

## Verification and testability

P:S01-S21 and R01-R02 are meaningful proposed layers but **all unexecuted**.
The independent checks here are input-integrity, fixed-source and bytecode/API
checks, not A0/A1/S1/S2/V1/V2 implementation results.

Required additions before source assignment/qualification:

- M1 occupancy/air-authority ordering fixtures using installed event wiring,
  real normal bed use and sustained/deep sleep; insufficient quorum can keep a
  sleeper present to observe continued checks. Observe scan timing/counters and
  compare genuine door/wall/provider changes; do not only check pose immediately
  after startSleepInBed.
- M2 one explicit host-versus-orbit projection, both-cell region/access cases and
  a consistent continued-sleep rule for operational Space gaps.
- B1 executable evidence for the exact cause-scoped native spawn veto before
  allowing generated natural deltas into a source slice.
- Freeze the D1 dimension/time/ancillary choice and exact integration write scope.
  Other already proposed startup, persisted Spawn-field, actual connected-player,
  gamerule, primary-time/weather, no-ticket, restart and prior-world cases remain
  mandatory. No bytecode finding replaces them.

The proposal does not raise atmosphere limits. S21 appropriately requires the
existing reference load rather than an empty-server timing. Fixed quality budgets
are mean MSPT <=25 ms, P95 <=50 ms, P99 <=100 ms, no unexpected force-loaded chunks,
and no watchdog/OOM. Additional O(sleeping connected players) observations need
measurement without silently omitting monitored sleepers. Real client V1/V2 and
full-load campaigns remain governed by ADR-018; no earlier exemption is extended.

## Actual commands, integrity and limitations

[COMMANDS.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-contract-independent-20261009-01/COMMANDS.txt)
records PowerShell read commands and UTC/exit codes.
[independent-commands.jsonl](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-contract-independent-20261009-01/independent-commands.jsonl)
records exact subprocess commands, UTC, exits and raw-output hashes.
The leaf-local Python scripts reproduce independent Git/native/event/manifest
inspections; the author's scripts were not executed.

- Initial git status/branch/worktree reads returned 0. Main had owner-modified
  AGENTS.md and many untracked owner evidence items. None was acquired, edited,
  staged, deleted or committed. Fixed Git reads remain valid if Root moves HEAD.
- Initial evidence setup returned 1 after a wrapper named R collided with the
  PowerShell Invoke-History alias, before the intended source reads. The setup
  directory/log already existed; a distinct wrapper was used. The failure is
  retained, not represented as a behavior failure.
- A guessed `docs/versions/v1.8.0.md` fixed Git read returned 128. Discovery found
  and read the actual `docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`.
  No nonexistent-path inference or test waiver followed.
- All three expected top-level candidate hashes matched, and **all 37 actual
  leaf-relative SHA256SUMS entries** were independently verified. The complete
  input seal, author report and complete proposal were read.
- Final independent input inspection returned 0: 60 raw fixed blobs and 16
  primary classes, six exact Forge source event entries (including interaction),
  all hashed. The supplemental seven-candidate exact-use inventory returned 0.
- Official Forge events documentation was opened through the web tool. Its
  observation/URL is retained in WEB-NOTE.md; it is supplementary to hashed local
  Forge primary input, not a new release-baseline choice.
- No Gradle, compiler/test suite, DataGen, GameTest, Minecraft/client/server,
  world/save/restart, install, cleanup or alternate agent/Claude command was run.
  These commands were prohibited here, not waived or NOT_APPLICABLE for a future
  implementation. No source test, upstream code/art or asset was imported.
- Low local evidence-hygiene deviation: the first supplemental Python module
  import automatically created `__pycache__/independent_checks.cpython-313.pyc`
  inside the exclusive leaf but outside its designated _tmp directory. This
  generated byproduct is retained and hashed, not behavioral evidence. Subsequent
  supplemental execution disables bytecode-cache writes. No deletion/move or
  cleanup bypass was attempted; no sealed input/repository file was affected.

Candidate SHA256SUMS.txt:
`56c720d83a73247872a5e67549e1fead940a8d0f176c911c47ce4b0fdc7ae193`.
Candidate REPORT.md:
`35790a09a7010e2223e341a4206d4839e0616698c43cc40d9f0cfe11a6ad7fc3`.
Candidate PROPOSED-SLEEP-CONTRACT-01.md:
`55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21`.
Fixed owner-decision raw blob:
`1dd0928208ffba6cda4636a632d06fe00ebbef650e6f4d9d4d2b1ed66fdf0af6`.
Mapped primary JAR:
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Forge source JAR:
`918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
All remaining fixed-blob/class/event hashes are in
[INPUT-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-contract-independent-20261009-01/INPUT-AUDIT.json).
Primary method evidence is in independent-native.txt and independent-forge-events.txt;
the bounded direct-use inventory is independent-natural-inventory.json.

## Scope, ownership, state and disposition

**Completed scope:** independent complete proposal/governance/owner/code/API review,
actual input seal checks, bounded primary reinspection and this sealed compact
evidence leaf. **Not completed:** the M1/M2 corrections, B1 mechanism proof, product
freeze, implementation and any runtime/acceptance test. No outcome was prescribed.

**Design decision:** this report selects no new sleep/respawn/time/compass product
policy. Actual sleep remains the selected owner target; refusal-only feedback is
not a substitute. Default-slice separation is reasonable, with all excluded C18
work and preserved old native-record risks explicitly retained.

**Modified files/tests:** only new files inside this external exclusive review
leaf; no repository source/docs/status/ledger or sealed candidate file changed.
No implementation test added or modified. _tmp is empty; the retained incidental
module-cache byproduct is disclosed above. No server/export/build
copy or temporary archive was created, so no cleanup was necessary or attempted.

**Released interests:** mutable Main, Root, HEAD, branch, jackhammer and all source
worktree interests were released at task start. No HEAD-moving restriction remains.
No child agent, Claude session, live native process or source write scope remains.
Root alone coordinates OpenPet; this worker reported milestones to Root.

**Known risks:** occupancy-induced self-invalidation, ambiguous Space gap context,
unproved bed-only spawn discriminator, unaccepted ancillary semantics, saved registry
upgrade behavior, existing off-world native spawn records, actual lifecycle/eye-height
compatibility, and unexecuted performance/restart/client evidence. None is hidden by
the passing input hashes.

**Required Gates:** not satisfied by this review. Fixed active development is v1.8
under ADR-060; the inherited v1.0 acceptance cursor and v1.8 G0-G9 remain open.
No Gate, ADR, owner policy or ledger unit is marked accepted/passed/delivered here.

**Next within v1.8:** correct and independently review M1/M2, establish B1's exact
native boundary, record the authorized D1 freeze/disposition, then assign disjoint
source/integration/test scopes and execute the required clean build, test, runData,
git diff --exit-code, runGameTestServer and affected finite packaged/restart/security
checks. Separately freeze planetary respawn/migration before claiming those units.
