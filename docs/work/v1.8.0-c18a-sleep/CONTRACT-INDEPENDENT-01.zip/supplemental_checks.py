"""Bounded direct-natural use inventory and final evidence-leaf checks."""
import json
import re
import sys
import zipfile
sys.dont_write_bytecode = True
from independent_checks import LEAF, MAPPED, SHA, digest, log, read, run

audit = json.loads(read(LEAF / "INPUT-AUDIT.json"))
inventory = []
candidates = []
count = 0
total = 0
with zipfile.ZipFile(MAPPED) as jar:
    entries = [entry for entry in jar.infolist()
               if entry.filename.startswith("net/minecraft/") and entry.filename.endswith(".class")]
    if len(entries) > 10000 or sum(entry.file_size for entry in entries) > 128 * 1024 * 1024:
        raise RuntimeError("bounded class inventory exceeded")
    for entry in entries:
        if entry.file_size > 2 * 1024 * 1024:
            raise RuntimeError("class limit exceeded")
        data = jar.read(entry)
        count += 1
        total += len(data)
        if b"natural" in data and b"net/minecraft/world/level/dimension/DimensionType" in data:
            candidates.append(entry.filename)
    if len(candidates) > 20:
        raise RuntimeError("javap candidate limit exceeded")
    for name in candidates:
        cls = name[:-6].replace("/", ".")
        data = jar.read(name)
        text = run([str(__import__('independent_checks').JAVAP), "-classpath", str(MAPPED), "-p", "-c", cls]).decode("utf-8")
        method = ""
        exact = []
        for line in text.splitlines():
            if re.match(r"^  [^ ].*\(", line):
                method = line.strip()
            if "dimension/DimensionType.natural:()Z" in line:
                exact.append({"method": method, "call": line.strip()})
        inventory.append({"class": cls, "entry_sha256": digest(data), "exact_calls": exact})
log("Bounded net/minecraft class byte inventory: natural + DimensionType; exact candidate javap", 0,
    classes=count, bytes=total, candidates=len(candidates))
out = {"fixed_commit": SHA, "mapped_jar_sha256": digest(read(MAPPED)),
       "limits": {"classes": 10000, "class_bytes": 2097152, "total_bytes": 134217728, "javap_candidates": 20},
       "classes_scanned": count, "bytes_scanned": total, "inventory": inventory,
       "limitation": "Direct native method uses only; not a mod/reflection/compatibility execution audit"}
(LEAF / "independent-natural-inventory.json").write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"classes": count, "candidate_count": len(candidates),
                  "exact_calls": sum(len(row['exact_calls']) for row in inventory)}, indent=2))
