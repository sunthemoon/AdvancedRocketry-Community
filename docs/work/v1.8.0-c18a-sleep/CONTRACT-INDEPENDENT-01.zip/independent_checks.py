"""Read-only fixed-input and primary API inspection; writes only this evidence leaf."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

LEAF = Path(__file__).resolve().parent
REPO = Path(r"D:\GitHub\AdvancedRocketry-Community")
PROPOSAL = Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-contract-research-20261009-01")
SHA = "96236acb682c060796e41d3837af7991d492d3b1"
LOG = LEAF / "independent-commands.jsonl"
MAPPED = Path(r"C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
FORGE = Path(r"C:\Users\Administrator\.gradle\caches\forge_gradle\maven_downloader\net\minecraftforge\forge\1.20.1-47.4.10\forge-1.20.1-47.4.10-sources.jar")
JAVAP = Path(r"C:\Program Files\Java\jdk-17.0.7\bin\javap.exe")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def log(action: str, code: int, **values: object) -> None:
    with LOG.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                                 "action": action, "exit_code": code, **values}) + "\n")


def run(args: list[str]) -> bytes:
    result = subprocess.run(args, cwd=REPO, capture_output=True, timeout=45)
    log(subprocess.list2cmdline(args), result.returncode,
        stdout_bytes=len(result.stdout), stdout_sha256=digest(result.stdout),
        stderr=result.stderr.decode("utf-8", errors="replace"))
    if result.returncode:
        raise RuntimeError("command failed: " + subprocess.list2cmdline(args))
    return result.stdout


def read(path: Path) -> bytes:
    data = path.read_bytes()
    log("read " + str(path), 0, bytes=len(data), sha256=digest(data))
    return data


def main() -> None:
    checks: dict[str, object] = {"fixed_commit": SHA, "sealed_input_files": [],
                               "fixed_blobs": [], "primary_inputs": [], "primary_entries": []}
    sums = read(PROPOSAL / "SHA256SUMS.txt").decode("utf-8-sig")
    for line in sums.splitlines():
        if not line.strip():
            continue
        expected, name = line.split(maxsplit=1)
        name = name.lstrip("*")
        path = (PROPOSAL / name).resolve()
        if not path.is_relative_to(PROPOSAL.resolve()):
            raise RuntimeError("non-contained candidate manifest entry")
        data = read(path)
        actual = digest(data)
        checks["sealed_input_files"].append({"path": name, "expected": expected,
                                           "actual": actual, "bytes": len(data),
                                           "matches": expected.lower() == actual})
    if not all(row["matches"] for row in checks["sealed_input_files"]):
        raise RuntimeError("candidate seal mismatch")

    author_inputs = json.loads(read(PROPOSAL / "INPUT-HASHES.json"))
    paths = [row["path"] for row in author_inputs["fixed_blobs"]]
    paths += ["AGENTS.md", "docs/15-REMOTE-LINUX-DEVELOPMENT-AND-VISUAL-VALIDATION.md",
              "docs/work/v1.8.0-c18-contract/OWNER-DECISIONS.md",
              "docs/work/v1.8.0-c18-contract/ACCEPTANCE.md",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/server/ServerLevelVolumeWorldView.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/service/CelestialEnvironmentService.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/compat/atmosphere/AtmosphereBoundaryRegistry.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereBoundaryGameTests.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfig.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereGameTests.java",
              "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereExposureGameTests.java"]
    excerpts = []
    for path in dict.fromkeys(paths):
        data = run(["git", "show", SHA + ":" + path])
        checks["fixed_blobs"].append({"path": path, "bytes": len(data), "sha256": digest(data)})
        if path.endswith(".java") or path.endswith("build.gradle"):
            lines = data.decode("utf-8").splitlines()
            selected = set()
            pattern = r"breathabilityAt|controlledAt|resolveEnvironment|unresolved\(|surfaceExposure|project\(|allowed\(|natural|dimension_type|exclude|startSleep|stopSleep|TickEvent|findAt|atmosphere\.tick|resolve\(WorldLocation|hasChunkAt|getChunkNow|isShapeFullBlock"
            for n, line in enumerate(lines):
                if re.search(pattern, line):
                    selected.update(range(max(0, n-3), min(len(lines), n+19)))
            if selected:
                excerpts.append("\n### " + SHA + ":" + path + "\n")
                excerpts += [f"{n+1}: {lines[n]}" for n in sorted(selected)]
    (LEAF / "fixed-source-excerpts.txt").write_text("\n".join(excerpts)+"\n", encoding="utf-8")

    for path in [MAPPED, FORGE, JAVAP]:
        data = read(path)
        checks["primary_inputs"].append({"path": str(path), "bytes": len(data), "sha256": digest(data)})

    selections = {
        "net.minecraft.server.level.ServerPlayer": r" startSleepInBed\(| stopSleepInBed\(| setRespawnPosition\(| readAdditionalSaveData\(| restoreFrom\(",
        "net.minecraft.world.entity.player.Player": r" tick\(| startSleepInBed\(| stopSleepInBed\(| isSleepingLongEnough\(| getStandingEyeHeight\(|getEyeHeight\(",
        "net.minecraft.world.entity.LivingEntity": r" startSleeping\(| setPosToBed\(| getEyeHeight\(|getEyeHeightForPose\(",
        "net.minecraft.server.level.ServerLevel": r" tick\(| wakeUpAllPlayers\(| updateSleepingPlayerList\(| tickTime\(| blockUpdated\(| updateNeighborsAt\(",
        "net.minecraft.server.MinecraftServer": r"createLevels\(",
        "net.minecraft.world.level.storage.DerivedLevelData": r"getDayTime\(|setDayTime\(|getGameTime\(|setGameTime\(|getSpawn|setSpawn|Rain|Thund",
        "net.minecraft.world.level.Level": r" isDay\(| isNight\(| setBlock\(| markAndNotifyBlock\(",
        "net.minecraft.server.players.SleepStatus": r"\(",
        "net.minecraft.world.item.CompassItem": r"getSpawnPosition\(",
        "net.minecraft.client.renderer.item.ItemProperties$1": r"unclampedCall\(",
        "net.minecraft.world.level.block.NetherPortalBlock": r"randomTick\(",
        "net.minecraft.world.level.block.BedBlock": r" use\(|findStandUpPosition\(",
        "net.minecraft.server.players.PlayerList": r"respawn\(",
        "net.minecraft.world.level.levelgen.PhantomSpawner": r"tick\(",
        "net.minecraftforge.event.ForgeEventFactory": r"onPlayerSleepInBed\(|fireSleepingTimeCheck\(|onPlayerSpawnSet\(|onSleepFinished\(",
        "net.minecraftforge.common.extensions.IForgeBlock": r"setBedOccupied\(",
    }
    native = []
    with zipfile.ZipFile(MAPPED) as jar:
        for cls, pattern in selections.items():
            entry = cls.replace(".", "/") + ".class"
            data = jar.read(entry)
            checks["primary_entries"].append({"jar": "mapped", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            text = run([str(JAVAP), "-classpath", str(MAPPED), "-p", "-c", cls]).decode("utf-8")
            native.append("\nCLASS " + cls + "\n")
            keep = False
            for line in text.splitlines():
                if re.match(r"^  [^ ].*\(", line):
                    keep = bool(re.search(pattern, line))
                if keep:
                    native.append(line)
    (LEAF / "independent-native.txt").write_text("\n".join(native)+"\n", encoding="utf-8")

    events = ["PlayerSetSpawnEvent", "PlayerSleepInBedEvent", "SleepingTimeCheckEvent", "SleepingLocationCheckEvent"]
    forge = []
    with zipfile.ZipFile(FORGE) as jar:
        entries = ["net/minecraftforge/event/entity/player/" + name + ".java" for name in events]
        entries += ["net/minecraftforge/event/entity/player/PlayerInteractEvent.java",
                    "net/minecraftforge/event/level/SleepFinishedTimeEvent.java"]
        for entry in entries:
            data = jar.read(entry)
            checks["primary_entries"].append({"jar": "forge-sources", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            log("Read Forge sources ZipArchive entry " + entry, 0, bytes=len(data), sha256=digest(data))
            forge.append("\nENTRY " + entry + "\n")
            forge += [f"{n+1}: {line}" for n, line in enumerate(data.decode("utf-8").splitlines())]
    (LEAF / "independent-forge-events.txt").write_text("\n".join(forge)+"\n", encoding="utf-8")
    checks["candidate_manifest_count"] = len(checks["sealed_input_files"])
    checks["candidate_manifest_verified"] = True
    checks["runtime_checks"] = "Not executed: read-only task prohibits Gradle/Minecraft/client launch"
    (LEAF / "INPUT-AUDIT.json").write_text(json.dumps(checks, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"manifest_verified": True, "manifest_files": checks["candidate_manifest_count"],
                      "fixed_blobs": len(checks["fixed_blobs"]),
                      "primary_classes": len(selections), "output": str(LEAF)}, indent=2))


if __name__ == "__main__":
    main()
