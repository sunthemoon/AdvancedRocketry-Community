$ErrorActionPreference = 'Stop'
$prior = 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-platform-counter-20261009-44'
foreach ($name in @('SHA256SUMS.txt', 'SEAL-RESULT.json', 'custody-seal-28.command.json')) {
    $path = Join-Path $prior $name
    Write-Output "===== $name ====="
    Get-FileHash -LiteralPath $path -Algorithm SHA256 | Format-List
    if ($name -ne 'SHA256SUMS.txt') { Get-Content -LiteralPath $path -Raw -Encoding utf8 }
}
$lines = Get-Content -LiteralPath (Join-Path $prior 'SHA256SUMS.txt') -Encoding utf8
$covered = 0; $bytes = 0L
foreach ($line in $lines) {
    if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Invalid manifest line: $line" }
    $expected = $Matches[1]; $relative = $Matches[2]
    $path = Join-Path $prior $relative
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw "Hash mismatch: $relative" }
    $covered++; $bytes += (Get-Item -LiteralPath $path).Length
}
[PSCustomObject]@{verified_covered_files=$covered; verified_covered_bytes=$bytes} | ConvertTo-Json
foreach ($path in @(
    'D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe',
    'D:/python/pyenv/pyenv-win/versions/3.13.15/Lib/subprocess.py',
    (Get-Command pwsh).Source,
    'D:/GitHub/AdvancedRocketry-Community/AGENTS.md',
    'D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-TERMINAL-COUNTER-TASK-50.md'
)) {
    [PSCustomObject]@{path=$path; bytes=(Get-Item -LiteralPath $path).Length; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json
}
$source = Get-Content -LiteralPath 'D:/python/pyenv/pyenv-win/versions/3.13.15/Lib/subprocess.py' -Encoding utf8
foreach ($range in @(@(221,238),@(1552,1611),@(1614,1639),@(1670,1697))) {
    Write-Output "===== subprocess.py $($range[0])-$($range[1]) ====="
    for ($i=$range[0]; $i -le $range[1]; $i++) { '{0}: {1}' -f $i,$source[$i-1] }
}
