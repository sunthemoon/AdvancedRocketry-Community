$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$index = @()
foreach ($file in Get-ChildItem -LiteralPath $leaf -File -Filter '*.command.json' | Sort-Object Name) {
    $r = Get-Content -LiteralPath $file.FullName -Raw -Encoding utf8 | ConvertFrom-Json
    foreach ($name in @('stdout', 'stderr')) {
        $path = Join-Path $leaf ($file.Name.Replace('.command.json', ".$name.txt"))
        $s = $r.$name
        if ($s.overflow -or $s.raw_bytes -ne $s.retained_bytes -or $s.raw_bytes -gt 262144) { throw "Incomplete/capped stream: $path" }
        if ((Get-Item -LiteralPath $path).Length -ne $s.raw_bytes) { throw "Length mismatch: $path" }
        $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $s.raw_sha256 -or $hash -ne $s.retained_sha256) { throw "Hash mismatch: $path" }
    }
    if ($r.exit_code -ne 0 -or $r.timeout -or $r.ceiling_seconds -ne 180) { throw "Command failure: $($file.Name)" }
    $index += [ordered]@{receipt=$file.Name; argv=$r.argv; cwd=$r.cwd;
        started_utc=$r.started_utc; ended_utc=$r.ended_utc; exit_code=$r.exit_code;
        stdout_bytes=$r.stdout.raw_bytes; stdout_sha256=$r.stdout.raw_sha256;
        stderr_bytes=$r.stderr.raw_bytes; timeout=$r.timeout}
}
if ($index.Count -ne 23) { throw "Unexpected prior command count: $($index.Count)" }
$cases = @('baseline', 'shutdown-buffer')
$outcomes = @()
foreach ($case in $cases) {
    $path = Join-Path $leaf "child-$case.receipt.json"
    $r = Get-Content -LiteralPath $path -Raw -Encoding utf8 | ConvertFrom-Json
    foreach ($name in @('stdout', 'stderr')) {
        $s = $r.streams.$name
        if ($s.overflow -or -not $s.eof -or $s.error_type -or $s.raw_bytes -gt 262144 -or $s.raw_bytes -ne $s.retained_bytes) { throw "Child incomplete/capped stream: $case $name" }
        $streamPath = Join-Path $leaf "child-$case.$name.txt"
        if ((Get-Item -LiteralPath $streamPath).Length -ne $s.raw_bytes) { throw 'Child raw length mismatch' }
        $hash = (Get-FileHash -LiteralPath $streamPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $s.raw_sha256 -or $hash -ne $s.retained_sha256) { throw 'Child raw hash mismatch' }
    }
    if ($r.exit_code -ne 0 -or $r.execution_failure -or $r.wait_timeout -or $r.timeout_actions.Count -ne 0) { throw "Cohort execution failure: $case" }
    if ($r.child_ceiling_seconds -ne 30 -or ($r.child_deadline_ns - $r.launch_before_ns) -ne 30000000000L) { throw 'Wrong child deadline' }
    if ($r.wait_after_ns -ge $r.child_deadline_ns) { throw 'Child wait exceeded deadline' }
    if ($r.identity_before_wait.pid -ne $r.child_pid -or $r.identity_after_wait.pid -ne $r.child_pid) { throw 'Original-handle PID mismatch' }
    if ($r.closed_before_query -or -not $r.closed_after_close) { throw 'Owned-handle closure mismatch' }
    foreach ($call in $r.post_exit_calls) {
        if ($call.handle -ne $r.original_handle -or $call.before_ns -lt $r.wait_after_ns -or $call.after_ns -gt $r.close_before_ns) { throw 'Post-exit/owned-handle interval mismatch' }
    }
    foreach ($helper in $r.helpers_before_launch) {
        if ((Get-FileHash -LiteralPath $helper.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $helper.sha256) { throw "Prelaunch helper changed: $($helper.path)" }
    }
    $childLines = Get-Content -LiteralPath (Join-Path $leaf "child-$case.stdout.txt") -Encoding utf8
    $records = @($childLines | ForEach-Object { $_ | ConvertFrom-Json })
    if (($records | Where-Object { $_.pid -ne $r.child_pid }).Count -ne 0) { throw 'Child self-reported PID mismatch' }
    $outcomes += [ordered]@{case=$case; parent_pid=$r.parent_pid; child_pid=$r.child_pid;
        original_handle=$r.original_handle; exit_code=$r.exit_code;
        post_exit_success=@($r.post_exit_calls.success); native_peak_bytes=@($r.post_exit_calls.values.PeakWorkingSetSize);
        native_current_bytes=@($r.post_exit_calls.values.WorkingSetSize);
        child_record_count=$records.Count; stdout_bytes=$r.streams.stdout.raw_bytes}
}
$files = @(Get-ChildItem -LiteralPath $leaf -File)
$bytes = ($files | Measure-Object Length -Sum).Sum
if ($bytes -gt 4194304) { throw 'Leaf exceeds fixed evidence cap' }
$encoding = [System.Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText((Join-Path $leaf 'COMMAND-INDEX.json'), ($index | ConvertTo-Json -Depth 8)+"`n", $encoding)
$result = [ordered]@{checked_prior_commands=$index.Count; measured_cohorts=$outcomes;
    checkpoint_files=$files.Count; checkpoint_bytes=$bytes; leaf_cap_bytes=4194304;
    note='Counter API availability is reported, not asserted as a required preferred result; this audit checks custody/identities/intervals/caps.'}
[IO.File]::WriteAllText((Join-Path $leaf 'AUDIT-RESULT.json'), ($result | ConvertTo-Json -Depth 8)+"`n", $encoding)
$result | ConvertTo-Json -Depth 8
$source = Get-Content -LiteralPath 'D:/python/pyenv/pyenv-win/versions/3.13.15/Lib/subprocess.py' -Encoding utf8
Write-Output '===== subprocess.py 1702-1717 ====='
1702..1717 | ForEach-Object { '{0}: {1}' -f $_,$source[$_-1] }
