"""Task50 one-parent/one-known-child cohort, no PID reopening."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import threading
import time
from counter_binding import declaration, identity, queries, utc

CAP = 262144
CHILD_SECONDS = 30
leaf = Path(__file__).resolve().parent
case = sys.argv[1]
if case not in ("baseline", "shutdown-buffer") or len(sys.argv) != 2:
    raise ValueError("Invalid fixed probe case")
prefix = "child-" + case
paths = [leaf / (prefix + suffix) for suffix in
         (".stdout.txt", ".stderr.txt", ".receipt.json")]
if any(path.exists() for path in paths):
    raise FileExistsError("Refusing overwrite of own cohort evidence")
helper_identity = []
for path in (Path(sys.executable), Path(__file__), leaf / "probe_child.py",
             leaf / "counter_binding.py", Path(subprocess.__file__)):
    helper_identity.append({"path": str(path), "bytes": path.stat().st_size,
                            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})


class Pump(threading.Thread):
    def __init__(self, stream, path):
        super().__init__(daemon=True)
        self.stream, self.path = stream, path
        self.total = self.retained = 0
        self.digest = hashlib.sha256()
        self.eof = False
        self.error_type = None

    def run(self):
        try:
            with self.path.open("xb") as output:
                while True:
                    data = self.stream.read(4096)
                    if not data:
                        self.eof = True
                        break
                    self.total += len(data)
                    self.digest.update(data)
                    keep = min(len(data), max(0, CAP - self.retained))
                    output.write(data[:keep])
                    self.retained += keep
        except Exception as error:
            self.error_type = type(error).__name__
        finally:
            self.stream.close()

    def record(self):
        return {"path": str(self.path), "raw_bytes": self.total,
                "retained_bytes": self.retained, "raw_sha256": self.digest.hexdigest(),
                "retained_sha256": hashlib.sha256(self.path.read_bytes()).hexdigest(),
                "overflow": self.total > CAP, "eof": self.eof,
                "error_type": self.error_type}


argv = [sys.executable, "-B", "-X", "tracemalloc=1", str(leaf / "probe_child.py"), case]
launch_before_utc = utc()
launch_before_ns = time.monotonic_ns()
deadline_ns = launch_before_ns + CHILD_SECONDS * 1000000000
process = subprocess.Popen(argv, cwd=str(leaf), stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           shell=False, close_fds=True, bufsize=0,
                           creationflags=subprocess.CREATE_NO_WINDOW)
launch_after_ns = time.monotonic_ns()
launch_after_utc = utc()
# Inspected installed subprocess.py retains the original CreateProcess hp here.
owned_handle = process._handle
native_handle = int(owned_handle)
pumps = [Pump(process.stdout, paths[0]), Pump(process.stderr, paths[1])]
for pump in pumps:
    pump.start()
timeout_records = []
timeout_lock = threading.Lock()


def enforce_deadline():
    with timeout_lock:
        now = time.monotonic_ns()
        if now >= deadline_ns and process.poll() is None:
            record = {"utc": utc(), "monotonic_ns": now, "pid": process.pid,
                      "handle": native_handle, "action": "known child Popen.kill at actual deadline"}
            timeout_records.append(record)
            try:
                process.kill()
                record["kill_returned"] = True
            except Exception as error:
                record["kill_error_type"] = type(error).__name__


timer = threading.Timer(max(0.0, (deadline_ns - time.monotonic_ns()) / 1e9), enforce_deadline)
timer.daemon = False
timer.start()
before_identity = identity(native_handle)
wait_before_ns = time.monotonic_ns()
wait_before_utc = utc()
wait_timeout = False
try:
    exit_code = process.wait(timeout=max(0.0, (deadline_ns - time.monotonic_ns()) / 1e9))
except subprocess.TimeoutExpired:
    wait_timeout = True
    # A millisecond-rounded wait may expire before the absolute deadline.
    delay = max(0.0, (deadline_ns - time.monotonic_ns()) / 1e9)
    if delay:
        time.sleep(delay)
    enforce_deadline()
    exit_code = process.wait(timeout=5)
wait_after_ns = time.monotonic_ns()
wait_after_utc = utc()
timer.cancel()
timer.join()
post_identity = identity(native_handle)
closed_before_query = bool(owned_handle.closed)
post_exit_calls = queries(native_handle, "parent-after-child-exit")
close_before_ns = time.monotonic_ns()
close_before_utc = utc()
owned_handle.Close()
close_after_ns = time.monotonic_ns()
close_after_utc = utc()
for pump in pumps:
    pump.join(timeout=5)
streams = {name: pump.record() for name, pump in zip(("stdout", "stderr"), pumps)}
failure = (wait_timeout or bool(timeout_records) or exit_code != 0 or
           any(item["overflow"] or not item["eof"] or item["error_type"]
               for item in streams.values()))
receipt = {"case": case, "parent_pid": os.getpid(), "parent_executable": sys.executable,
           "parent_version": sys.version, "parent_platform": sys.platform,
           "parent_sysconfig_platform": sysconfig.get_platform(),
           "parent_argv": sys.argv, "parent_cwd": os.getcwd(),
           "child_argv": argv, "child_cwd": str(leaf), "child_pid": process.pid,
           "launch_before_utc": launch_before_utc, "launch_after_utc": launch_after_utc,
           "launch_before_ns": launch_before_ns, "launch_after_ns": launch_after_ns,
           "child_deadline_ns": deadline_ns, "child_ceiling_seconds": CHILD_SECONDS,
           "wait_before_utc": wait_before_utc, "wait_after_utc": wait_after_utc,
           "wait_before_ns": wait_before_ns, "wait_after_ns": wait_after_ns,
           "exit_code": exit_code, "wait_timeout": wait_timeout,
           "timeout_actions": timeout_records, "helpers_before_launch": helper_identity,
           "original_handle": native_handle, "original_handle_type": type(owned_handle).__name__,
           "identity_before_wait": before_identity, "identity_after_wait": post_identity,
           "closed_before_query": closed_before_query, "post_exit_calls": post_exit_calls,
           "close_before_utc": close_before_utc, "close_after_utc": close_after_utc,
           "close_before_ns": close_before_ns, "close_after_ns": close_after_ns,
           "closed_after_close": bool(owned_handle.closed), "declaration": declaration(),
           "stream_cap_bytes": CAP, "streams": streams, "execution_failure": failure,
           "terminal_counter_available": all(call["success"] for call in post_exit_calls),
           "no_openprocess_or_pid_reopening": True,
           "closure": "Original subprocess.Handle.Close once; no native double-close or post-close query",
           "timeout_mechanism": "Independent own-parent Timer plus Popen.wait absolute launch+30s; only known original-handle child kill at actual deadline; no descendants",
           "environment": "inherited, no overrides"}
with paths[2].open("x", encoding="ascii", newline="\n") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps(receipt, separators=(",", ":")))
if failure:
    raise SystemExit(1)
