"""Task50 finite counter probe child; never launches another process."""
import atexit
import json
import os
import sys
import sysconfig
import time
import tracemalloc
from counter_binding import current, declaration, identity, queries, utc

case = sys.argv[1]
if case not in ("baseline", "shutdown-buffer") or len(sys.argv) != 2:
    raise ValueError("Invalid fixed probe case")
handle = current()


def emit(stage, **items):
    record = {"case": case, "stage": stage, "pid": os.getpid(),
              "utc": utc(), "monotonic_ns": time.monotonic_ns(), **items}
    sys.stdout.buffer.write((json.dumps(record, separators=(",", ":")) + "\n").encode("ascii"))
    sys.stdout.buffer.flush()


emit("identity", executable=sys.executable, version=sys.version,
     platform=sys.platform, os_name=os.name, sysconfig_platform=sysconfig.get_platform(),
     windows_version=list(sys.getwindowsversion()),
     windows_platform_version=list(sys.getwindowsversion().platform_version),
     pseudo_handle=int(handle), handle_identity=identity(handle), declaration=declaration(),
     tracing=tracemalloc.is_tracing(), traceback_limit=tracemalloc.get_traceback_limit())
emit("main-self-query", calls=queries(handle, "child-main-self"),
     traced_current_peak=tracemalloc.get_traced_memory(),
     tracer_metadata=tracemalloc.get_tracemalloc_memory())


def shutdown():
    if case == "shutdown-buffer":
        before = time.monotonic_ns()
        buffer = bytearray(16777216)
        for offset in range(0, len(buffer), 4096):
            buffer[offset] = 1
        buffer[-1] = 1
        touched = time.monotonic_ns()
        emit("atexit-buffer-live", buffer_bytes=len(buffer), stride=4096,
             allocation_touch_before_ns=before, allocation_touch_after_ns=touched,
             calls=queries(handle, "child-atexit-buffer-live"),
             traced_current_peak=tracemalloc.get_traced_memory(),
             tracer_metadata=tracemalloc.get_tracemalloc_memory())
        del buffer
        emit("atexit-buffer-released", release_after_ns=time.monotonic_ns(),
             traced_current_peak=tracemalloc.get_traced_memory(),
             tracer_metadata=tracemalloc.get_tracemalloc_memory())
    else:
        emit("atexit-baseline", traced_current_peak=tracemalloc.get_traced_memory(),
             tracer_metadata=tracemalloc.get_tracemalloc_memory())


atexit.register(shutdown)
emit("main-returning", note="Native self query excludes subsequent atexit and exit work; pseudo handle is not closed")
