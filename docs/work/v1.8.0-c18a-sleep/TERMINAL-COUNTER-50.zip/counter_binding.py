"""Task50 evidence-only binding; no process discovery or control."""
import ctypes
from ctypes import wintypes
import datetime
import time


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class Counters(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in (
            "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
            "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
            "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]


if (ctypes.sizeof(wintypes.DWORD), ctypes.sizeof(wintypes.BOOL),
        ctypes.sizeof(wintypes.HANDLE), ctypes.sizeof(ctypes.c_size_t),
        ctypes.sizeof(Counters), ctypes.alignment(Counters)) != (4, 4, 8, 8, 72, 8):
    raise RuntimeError("UNQUALIFIED: unexpected installed Windows AMD64 ABI")


kernel = ctypes.WinDLL("kernel32.dll", use_last_error=True)
psapi = ctypes.WinDLL("psapi.dll", use_last_error=True)
current = kernel.GetCurrentProcess
current.argtypes = []
current.restype = wintypes.HANDLE
get_pid = kernel.GetProcessId
get_pid.argtypes = [wintypes.HANDLE]
get_pid.restype = wintypes.DWORD
getters = []
for label, function in (("K32GetProcessMemoryInfo", kernel.K32GetProcessMemoryInfo),
                        ("GetProcessMemoryInfo", psapi.GetProcessMemoryInfo)):
    function.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    function.restype = wintypes.BOOL
    getters.append((label, function))


def declaration():
    return {"counter_size": ctypes.sizeof(Counters),
            "counter_alignment": ctypes.alignment(Counters),
            "widths": {"DWORD": ctypes.sizeof(wintypes.DWORD),
                       "BOOL": ctypes.sizeof(wintypes.BOOL),
                       "HANDLE": ctypes.sizeof(wintypes.HANDLE),
                       "SIZE_T": ctypes.sizeof(ctypes.c_size_t)},
            "fields": [{"name": name, "offset": getattr(Counters, name).offset,
                        "width": ctypes.sizeof(kind)} for name, kind in Counters._fields_],
            "memory_signature": "BOOL(HANDLE, POINTER(Counters), DWORD)",
            "pid_signature": "DWORD(HANDLE)",
            "pseudo_signature": "HANDLE()", "use_last_error": True}


def identity(handle):
    before = time.monotonic_ns()
    ctypes.set_last_error(0)
    result = int(get_pid(handle))
    error = ctypes.get_last_error()
    after = time.monotonic_ns()
    return {"pid": result if result else None, "return_DWORD": result,
            "saved_error": error, "success": result != 0,
            "before_ns": before, "after_ns": after}


def queries(handle, stage):
    records = []
    for label, function in getters:
        output = Counters()
        output.cb = ctypes.sizeof(output)
        before_utc = utc()
        before = time.monotonic_ns()
        ctypes.set_last_error(0)
        returned = int(function(handle, ctypes.byref(output), ctypes.sizeof(output)))
        error = ctypes.get_last_error()
        after = time.monotonic_ns()
        after_utc = utc()
        record = {"stage": stage, "api": label, "handle": int(handle),
                  "return_BOOL": returned, "success": returned != 0,
                  "saved_error": error, "cb_member": ctypes.sizeof(output),
                  "cb_argument": ctypes.sizeof(output), "before_ns": before,
                  "after_ns": after, "before_utc": before_utc,
                  "after_utc": after_utc, "counter_units": "bytes except PageFaultCount"}
        if returned:
            record["values"] = {name: int(getattr(output, name))
                                for name, _ in Counters._fields_}
        else:
            record["values"] = None
            record["qualification"] = "UNQUALIFIED; failed output not interpreted"
        records.append(record)
    return records
