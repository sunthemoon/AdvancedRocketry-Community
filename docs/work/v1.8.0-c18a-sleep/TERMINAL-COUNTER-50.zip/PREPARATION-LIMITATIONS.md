# Task50 preparation and transport limitations

These are retrospective narrative records of visible tool observations, not
reconstructed historical raw streams, UTC intervals or subprocess receipts.

Before creating this exclusive external leaf, the working AGENTS.md was fully
displayed alone with explicit UTF-8; separate full status/branch/HEAD/index,
worktree and live-agent checks followed. Applicable external ancestor AGENTS
checks found none, and the leaf did not exist. Working AGENTS was user-modified;
peer untracked artifacts and all worktrees were left untouched. Those direct
preparation tools did not have the later own raw-stream/UTC receipt wrapper.

An initial combined official-web/command tool display reported aggregate output
truncation (11067 original tokens /434 lines). The installed-stdlib command
block was complete; the CreateProcessW web display was incomplete. This was
reported to Root before leaf/helper/cohort creation. Later named bounded primary
sections support only their actual contents, not a repaired complete-page claim.
No browser output is represented as a subprocess raw-stream download or receipt.

A supporting three-read loop incorrectly assumed the executable
C:/Program Files/PowerShell/7/pwsh.exe. Each Process.Start failed with file-not-found;
no child or raw/command receipt was created for intended names actual-version-14,
task44-report-15 or candidate37-16. The same tool displayed the input hashes and
missing-receipt errors. It did not stop the loop after its first failure. The
worker reported this to Root before continuation. No original error stream/time
is invented here. Distinct successful prospective names 17/18/19 used the actual
Get-Command executable verified against Task44's earlier actual receipt; the
later supporting-20 record hashes that executable. Root separately supplied the
same WindowsApps path and instructed preservation of the failed attempts.

The capture helper was first copied byte-for-byte from this worker's own sealed
Task44 helper (4096 bytes, SHA256
7b39b477e271eb382ddc9cf02817d92067b043c982a512a0a19eb76000f6a264), without changing
the source. Fixed reads 01-13 used that version, with explicit overflow metadata
and no observed overflow. A prospective own-leaf edit added a throw after receipt
emission for stream overflow before successful reads 17 onward and the cohorts.
The updated capture helper hash is
af4639ef4019c6823270658ea2bc1f9217f2f7588fb4abbb03d3ce17959654e6.
No earlier receipt is relabeled as using the added failure branch.

Task44's original truncated listing, missing py, uncaptured preparation and lossy
actual-version-11 records remain in its immutable report/leaf. Task50 did not
re-run its broad listing or rewrite its three probes or U01 conclusion. All
Task50 own measurement helpers were finalized before either cohort and retain
matching pre-child-launch hashes in both actual child receipts.
