# Task50 independent own-child terminal peak-counter feasibility

Date: 2026-10-09 UTC. Delegated independent worker, not Root or author43.
Evidence-only assessment; no implementation, contract adoption or Gate authority.

## Findings first

**Q01: Attributable native post-exit peak-working-set retrieval is qualified
locally for the two named CPython 3.13.15 Windows AMD64 probe children.** Both
K32GetProcessMemoryInfo and psapi.GetProcessMemoryInfo returned BOOL 1 after
the parent's completed child-exit wait, through the exact original launch-owned
process handle, before its one-time closure. GetProcessId on that handle matched
the launched and self-reported PID before and after wait. Neither PID reopening,
foreign-process discovery nor a maximum constructed from sampled current values
was used. Actual post-exit peaks were 21204992 and 37601280 bytes.

**Q02: The local terminal-query timing covers the observed shutdown tail, rather
than ending at the child's last self query.** In the second child, the main self
reading was 20815872 bytes; a subsequent one-buffer atexit episode reached a
self-reported peak of 37601280, released the buffer, and returned before exit.
The parent's post-exit native peak remained 37601280 while current working set
was 32768. The baseline terminal peak also exceeded its main self reading. These
are actual finite observations, not required deltas or a 16 MiB equality rule.

**U01: Task44's original self-query-only lifetime conclusion remains unchanged.**
Task50 supplies separately authorized local post-exit feasibility evidence; it
does not retroactively add terminal coverage to Task44's three historical probes.
The process-lifetime interpretation still relies on the documented native process
peak, not independent proof of every OS accounting transition from creation.
Retaining a process object alone is not a documented promise that every memory
API will work after exit. The two actual successes establish this environment's
behavior; portability, other exit modes and downstream resource qualification
require separate evidence/disposition. No global U01 acceptance is asserted.

**U02: Decoder resource acceptance, complete RSS/native-allocation accounting,
hard allocator/quota enforcement and other platforms remain UNQUALIFIED.** No
decoder, synthetic JSON, resource-case family, source-aware parser, native trace,
world, runtime driver or game was created or tested. The unchanged traced and
native lifetime ceilings are each 268435456 bytes. Small counter probes are not
acceptance against those ceilings. No product defect or G0-G9 PASS is claimed.

## Handle provenance, rights, lifetime and actual closure

The inspected installed standard-library subprocess.py is 93085 bytes, SHA256
7b58820104e7243c80ced7ad4081bf971fed0a4099850bcfb50261625645ed20. Relevant ranges
221-238, 1552-1611, 1614-1639 and 1702-1717 were fully displayed; the first three
and launch/wait ranges are captured in supporting-20, termination in audit-27.
This is narrow installed-source inspection, not a library/source-tree export.

Its Windows launch calls _winapi.CreateProcess, keeps returned hp as a Handle
in Popen._handle, records the returned PID, and closes the primary-thread handle
ht immediately. Windows wait uses the same process handle and gets the exit code
without closing it. Handle.Close owns CloseHandle, guards a later destructor
close, and was called explicitly once after the post-exit queries here. Both
Popen and its Handle remained referenced throughout. No Detach, DuplicateHandle,
OpenProcess, privilege change or replacement handle was used.

The original CreateProcess handle has PROCESS_ALL_ACCESS under the documented
API contract; the memory and PID getters require query/query-limited rights.
Successful actual getters corroborate available query access, but no separate
access-mask introspection was performed.
[Process access rights](https://learn.microsoft.com/en-us/windows/win32/procthread/process-security-and-access-rights),
[GetProcessId](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocessid).

PROCESS_INFORMATION identifies the returned process handle and PID and requires
closing owned process/thread handles when finished. An open handle retains the
process object after termination; a completed wait observes its signaled exit
state. This supports attribution without reopening a potentially reused PID,
but does not itself specify post-exit memory-counter retention.
[PROCESS_INFORMATION](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-process_information),
[Process termination and retained objects](https://learn.microsoft.com/en-us/windows/win32/procthread/terminating-a-process).

| Cohort | Parent PID /child PID | Original handle | Matching PID before /after wait | Close interval, monotonic ns |
|---|---:|---:|---:|---|
| baseline | 23632 /28556 | 460 | 28556 /28556 | 157546135804400-157546135891600 |
| shutdown-buffer | 5976 /8448 | 452 | 8448 /8448 | 157560932940300-157560933028300 |

Handle.closed was false before both post-exit calls and true after Close returned
normally. No native exception occurred. This records the actual owned-wrapper
closure; no invalid/post-close API call was made to test a freed handle. The
child's GetCurrentProcess pseudo handle was 18446744073709551615 and was not
closed or treated as an independently opened real handle.
[GetCurrentProcess ownership](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getcurrentprocess).

Popen._handle and Handle.Close are private installed implementation details,
not a public cross-version subprocess handle contract. A later assigned test
must guard and verify its actual interpreter implementation, retain ownership,
wait for the exact child, and fail qualification when this facility is absent.
This report does not select a production helper/framework or grant PID access.

## Actual ABI, units, calls and error boundary

The binding uses default ctypes.Structure alignment: cb and PageFaultCount are
DWORD at offsets 0/4; the eight SIZE_T members follow at offsets 8 through 64.
In order: PeakWorkingSetSize, WorkingSetSize, QuotaPeakPagedPoolUsage,
QuotaPagedPoolUsage, QuotaPeakNonPagedPoolUsage, QuotaNonPagedPoolUsage,
PagefileUsage, PeakPagefileUsage. Actual size/alignment was 72/8 bytes; DWORD
and BOOL widths 4, HANDLE and SIZE_T widths 8. A pre-call local ABI check refuses
other widths. Memory fields are bytes; PageFaultCount is a count. Working-set
peak/current and commit/peak commit remain separate quantities.
[PROCESS_MEMORY_COUNTERS](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters).

Both DLLs use WinDLL(use_last_error=True). Memory getters have explicit
BOOL(HANDLE, POINTER(Counters), DWORD), with cb member and argument both 72.
GetProcessId has DWORD(HANDLE); GetCurrentProcess has HANDLE() with no arguments.
Returned handles are not truncated through ctypes' default int result. Each
output structure remains live through the call. The saved error is cleared,
then read immediately after the native return, before clocks/other native calls.
BOOL, not error==0, determines success. Failed output would be values=null with
explicit UNQUALIFIED status, never zero measurements or a fallback current value.
[GetProcessMemoryInfo](https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getprocessmemoryinfo),
[ctypes saved-error/signature handling](https://docs.python.org/3.13/library/ctypes.html),
[Immediate thread-local errors](https://learn.microsoft.com/en-us/windows/win32/api/errhandlingapi/nf-errhandlingapi-getlasterror).

All actual Task50 memory calls and PID getters succeeded; saved errors were 0.
No deliberately invalid, post-close or permission-failure call was introduced.
Thus the new terminal-failure branch, unavailable-export/ABI paths and actual
timeout/kill recovery were inspected but not experimentally exercised. Task44's
separate cb=0/122 failure evidence remains historical, not a new terminal-error
test. K32 and psapi calls were sequential, not an atomic equality requirement.

A working set counts resident pageable pages and can include shared pages;
AWE/large-page nonpageable allocations are excluded. It is not private commit,
all virtual memory or every native allocation. The post-exit current 32768-byte
reading is not substituted for the retained process peak.
[Working-set semantics](https://learn.microsoft.com/en-us/windows/win32/memory/working-set).

Tracemalloc was enabled at child startup with -X tracemalloc=1. It reports traced
Python blocks and separate tracer metadata, not resident working set. No reset
or clearing was performed. Its final child record still precedes interpreter
exit; post-exit retrieval here qualifies the native counter, not a terminal
tracemalloc reading.
[Tracemalloc API](https://docs.python.org/3.13/library/tracemalloc.html).

## Exact finite cohorts and observed intervals

Exactly two fresh measurement parents and two exact just-launched children ran;
no third cohort/retry or other Python invocation was used in Task50. Each child
creates no descendants. Baseline allocates no probe buffer. Shutdown-buffer
allocates/touches/releases one 16777216-byte bytearray inside one atexit callback,
touching every 4096 bytes and the last byte. There is no payload/tree/cache,
stress/repetition loop or externally altered working-set setting.

Both parents used installed D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe,
105696 bytes, SHA256
85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd.
Both parent/child identities report CPython 3.13.15 tags/v3.13.15:4061bc4,
MSC v.1944 64-bit AMD64; win32 /nt /win-amd64. Child Windows version reports
[10,0,26200,2,""] versus platform_version [10,0,26100]; the discrepancy is retained,
not converted into an unverified marketing OS name. Inspected online Python
3.13 pages identify 3.13.16, not the pinned installed 3.13.15 binary.

Actual outer argv is python.exe -B probe_parent.py <fixed-case>; child argv is
the same executable -B -X tracemalloc=1 probe_child.py <fixed-case>. Both use
this assigned leaf as cwd, shell=False, inherited environment, close_fds=True,
CREATE_NO_WINDOW and binary stdout/stderr pipes; no shell shim is involved.
The exact argv strings and all start/end UTCs are in individual raw receipts.

| Outer parent receipt | UTC start-end, 2026-10-09 | Exit /elapsed seconds | Raw stdout /stderr bytes |
|---|---|---:|---:|
| cohort-baseline-21 | 09:58:55.3634563-09:58:55.7520960 | 0 /0.3861373 | 6026 /0 |
| cohort-shutdown-buffer-22 | 09:59:10.1564514-09:59:10.5451930 | 0 /0.3857609 | 6055 /0 |

Outer stdout SHA256 respectively:
1b37d6b2b717b885014dd2692c1ba12d13bbf0f9e95996206667c6ebcb4666fb;
52f40278d2ef6f2b1907abaf96a5f88da6a22630421bd2daf2e956d24b84b28b.
Child raw stdout was 3328 and 5040 bytes, SHA256 respectively
44e1508d0c1aa7f2be83ca35c9bec65e96091ceadf8cfa88e03a731fc60b820a;
da32e52c2a9256dd74a7fbbe99bc840568e88a7548a9c6c8de20c55e97012ea5.
All four stderr streams were empty, SHA256
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.

| Native K32 stage | Peak working set | Current working set | Commit /peak commit, bytes |
|---|---:|---:|---:|
| baseline main self | 21184512 | 21184512 | 13393920 /13393920 |
| baseline after exit | 21204992 | 32768 | 77824 /13393920 |
| shutdown-buffer main self | 20815872 | 20815872 | 13205504 /13205504 |
| shutdown-buffer atexit buffer live | 37601280 | 37601280 | 30019584 /30040064 |
| shutdown-buffer after exit | 37601280 | 32768 | 77824 /30040064 |

Baseline completed wait at monotonic 157546135610700; its parent K32 query was
157546135759800-157546135774500 and psapi query 157546135792900-157546135798000.
Second child main K32 query was 157560915537300-157560915551600; its allocation/
touch interval was 157560915927800-157560919577100, buffer-live K32 query
157560919598000-157560919609900, release recorded 157560920287200. Parent wait
completed 157560932732700, followed by K32 157560932896000-157560932908600 and
psapi 157560932928200-157560932932700, before the handle-close interval above.
UTC intervals also agree. These clocks measure observation intervals, not the
unobserved exact instant the OS updated its peak; Python's monotonic clock is
shared across processes on this platform.
[Python monotonic clock](https://docs.python.org/3.13/library/time.html#time.monotonic).

Baseline last traced peak was 3746581 bytes with metadata 1555152; second child
last traced peak was 20023080 with metadata 1555952. Neither is added to native
working set or claimed to cover later tracer teardown. The actual small local
peaks do not characterize an unimplemented decoder's worst case.

## Deadlines, raw capture and evidence custody

Each own Python parent started an independent non-daemon Timer and Popen.wait
against the same fixed absolute deadline, 30 seconds from its pre-launch clock.
Only its exact known original-handle child could be killed, and only at an
actual deadline with the process still active. A rounded early wait timeout
does not permit early termination. No timeout, kill or other cleanup occurred.
The outer PowerShell raw-capture parent independently used fixed 180 seconds and
could kill only its own immediate Python parent, without a tree option. It did
not manage the Python parent's child. No foreign PID/descendant termination.

Process creation and host scheduling are not guaranteed interruptible at an
exact wall-clock boundary. Timer/wait enforcement is independent of child
cooperation, not OS hard preemption, memory control or a proof of kill recovery.
Both actual children exited well before their recorded 30-second deadlines.
The inspected Windows kill implementation uses the original process handle.
[Python wait/kill/timeout limitations](https://docs.python.org/3.13/library/subprocess.html).

The own bounded child pump threads simultaneously drain binary stdout/stderr in
4096-byte chunks, hash all observed bytes and retain at most 262144 per stream;
overflow/reader failure makes the cohort fail explicitly. They avoid the
installed communicate reader's unbounded read/list buffer. The outer capture
helper likewise uses raw asynchronous reads, fixed retention and hashes, with
prospective explicit overflow failure. Every actual stream fit and hashes match.

Task44 custody was verified read-only: report SHA256
c86b95c534cfb14981c57714e8957501c60573b797bc9b017cd5d2752092fedb is 19739 bytes /303
lines; manifest 78569fc955376069ec752f04e3523e7e425aa0fede94ca10d290f696d4f151ab
matches all 92 covered files /259336 bytes. Actual SEAL-RESULT and command receipt
show completed custody-only sealing, exit 0, timeout false, stdout 801 /stderr 0.
Its exact five exclusions are SHA256SUMS.txt, SEAL-RESULT.json and the three
custody-seal-28.command.json/stdout.txt/stderr.txt files. Those are not permission
to run Task50 and no sealed Task44 member was changed.

Fixed governance b80fb950b3965956ff6a75f8f86b9aff32aa196d and observation source
d57ecda1f11dab76d882f945b0de606534ef4fb9 remain fixed. Mandatory config/product/
principles/roadmap/version/master-test/release/post-1.0/quality/parallel/fixed
AGENTS and checkpoint45 were fully read, as were complete actual version,
Task44 REPORT and candidate37. Proposal37 is 19096 bytes /271 lines, SHA256
f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0.
Candidate caps/finite resource families and source/schema/native/diagnostic/R-021
obligations remain PROPOSED or open; Task50 does not disposition them.

Preparation instrumentation gaps, the aggregate web-display truncation and the
three file-not-found supporting-start failures are preserved in
[PREPARATION-LIMITATIONS](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/PREPARATION-LIMITATIONS.md).
No historical raw/time receipt was reconstructed. Actual named captures 17-19
follow the failed intended 14-16, not overwritten replacements. Browser/direct
tool reads have tool records, not invented full-page raw downloads. Root was
notified before continuation after both new preparation limitations.

## Completed/uncompleted scope, own files, commands, risks and Gates

Completed: mandatory independent reads, primary API assessment, installed
declaration/handle provenance, exactly two bounded cohorts, post-exit identity/
return/value/closure records and custody/raw-hash checks. No project tests were
added or modified. Counter probes and receipt audit are not decoder tests.

Uncompleted: decoder/resource-case qualification, portable bindings, alternate
exit modes, terminal failure/kill execution tests, complete RSS accounting,
hard quota enforcement and all source/runtime/native acceptance. Gradle clean
build/test/runData/generated-diff/runGameTestServer, JVM, dedicated/restart,
real-client and native Unicode tests were NOT_EXECUTED, not PASS or inapplicable.

Own writes are only this exclusive external leaf: capture/supporting/audit
helpers, evidence-only [binding](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/counter_binding.py),
[parent](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/probe_parent.py)
and [child](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/probe_child.py), raw
streams, command/child receipts, preparation note, audit/index and this report;
later acknowledgment/one-time seal are not preclaimed. Measurement helpers were
unchanged between both cohorts and match their pre-child-launch hashes. No
third production module or source/library/world/build tree was exported.

Captured commands fixed-01 through fixed-13 are fixed git show reads.
actual-version-17, task44-report-18 and candidate37-19 emit exact raw file bytes.
Supporting-20 verifies Task44 custody/installed hashes and bounded stdlib ranges.
Cohorts21/22 are the only Python parent invocations. Tracked-status23, head24,
source-stable25 and index26 are read-only Git checks. Audit27 verifies the actual
23 earlier command receipts, child raw streams/PIDs/intervals/helpers/caps and
two-cohort count. All 24 captured commands exited 0 without timeout or overflow.
The pre-audit-output checkpoint was 82 files /230512 bytes; final report/custody
volume is separately measured at seal, not assumed from this earlier checkpoint.

Final tracked status remains only M AGENTS.md, index empty and HEAD b80fb950;
source diff b80fb950 HEAD -- src scripts exited 0. Working AGENTS retains its
15797-byte hash c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
No project/index/HEAD changes, commits, pushes, peer-artifact takeover, installs,
quota/working-set-limit/affinity/privilege/environment/service/system changes,
cleanup or delegation occurred. Root coordinates OpenPet.

Known risks: private subprocess handle API/patch dependence; local Windows-only
post-exit counter behavior; native peak accounting interpretation; shared/
nonpageable residency distinctions; tracer/import/serialization overhead;
untested error/timeout recovery and alternate exit modes; preserved preparation
transport gaps; all unimplemented resource/source/runtime/diagnostic obligations.
Key decision: query after completed exit on the original still-owned handle,
retain counter identities/units/errors, and keep self/current/commit/traced and
terminal native peak distinct. No budget, deadline or acceptance scope changes.

Evidence is this assigned sleep-json-terminal-counter-20261009-50 leaf, including
individual actual receipts and
[AUDIT-RESULT](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/AUDIT-RESULT.json).
This stable report awaits Root's complete exact-hash reading before one-time
own custody seal; neither acknowledgment nor seal is asserted here.

**All current/inherited Required Gates G0-G9 satisfied: NO.** v1.8 remains
IN_PROGRESS. No ledger delivery, contract freeze, native authority, release/tag
or exception waiver follows. Next v1.8-only work is independent disposition of
these actual local counter/terminal boundaries and the core/diagnostic candidate,
then a separate bounded implementation/test assignment only if authorized.
