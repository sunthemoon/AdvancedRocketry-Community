$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$expectedLeaf = 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50'
if ([IO.Path]::GetFullPath($leaf) -ne [IO.Path]::GetFullPath($expectedLeaf)) { throw 'Wrong own seal leaf' }
$manifestPath = Join-Path $leaf 'SHA256SUMS.txt'
$resultPath = Join-Path $leaf 'SEAL-RESULT.json'
foreach ($path in @($manifestPath, $resultPath)) {
    if (Test-Path -LiteralPath $path) { throw "Refusing reseal/overwrite: $path" }
}
$report = Join-Path $leaf 'REPORT.md'
$expectedHash = '17bc576fa3d566ca85a91b8c3b8a9b13b3b98937b783d0a822a064830a835f38'
if ((Get-FileHash -LiteralPath $report -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash -or
    (Get-Item -LiteralPath $report).Length -ne 20304 -or
    (Get-Content -LiteralPath $report -Encoding utf8).Count -ne 307) { throw 'Stable report identity changed' }
$ackPath = Join-Path $leaf 'ROOT-FULL-READ-ACK.md'
if (-not (Test-Path -LiteralPath $ackPath)) { throw 'Root exact-hash full-read acknowledgment absent' }
$ack = Get-Content -LiteralPath $ackPath -Raw -Encoding utf8
if (-not $ack.Contains($expectedHash)) { throw 'Acknowledgment report hash absent' }
$exclusions = @('SHA256SUMS.txt','SEAL-RESULT.json',
    'custody-seal-28.command.json','custody-seal-28.stdout.txt','custody-seal-28.stderr.txt')
$files = @(Get-ChildItem -LiteralPath $leaf -File | Where-Object { $_.Name -notin $exclusions } | Sort-Object Name)
if ((Get-ChildItem -LiteralPath $leaf -Directory).Count -ne 0) { throw 'Unexpected directory in own flat evidence leaf' }
$coveredBytes = ($files | Measure-Object Length -Sum).Sum
if ($coveredBytes -gt 4000000) { throw 'Insufficient fixed-cap room for seal and late receipts' }
$encoding = [Text.UTF8Encoding]::new($false)
$lines = @($files | ForEach-Object {
    ((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()) + '  ' + $_.Name
})
[IO.File]::WriteAllText($manifestPath, ($lines -join "`n")+"`n", $encoding)
foreach ($line in $lines) {
    $hash = $line.Substring(0,64); $name = $line.Substring(66)
    if ((Get-FileHash -LiteralPath (Join-Path $leaf $name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash) { throw "Seal verify mismatch: $name" }
}
$result = [ordered]@{completed_utc=[DateTime]::UtcNow.ToString('o'); outcome='SEALED_CUSTODY_ONLY';
    report_sha256=$expectedHash; report_lines=307; report_bytes=20304;
    root_ack_sha256=(Get-FileHash -LiteralPath $ackPath -Algorithm SHA256).Hash.ToLowerInvariant();
    covered_files=$files.Count; covered_bytes=$coveredBytes;
    manifest_sha256=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant();
    exact_exclusions=$exclusions;
    note='Own one-time custody only; command stdout/stderr/actual-exit receipt are created later by its parent and excluded. No decoder/resource/global U01/Gate acceptance.'}
[IO.File]::WriteAllText($resultPath, ($result | ConvertTo-Json -Depth 8)+"`n", $encoding)
$result | ConvertTo-Json -Depth 8
