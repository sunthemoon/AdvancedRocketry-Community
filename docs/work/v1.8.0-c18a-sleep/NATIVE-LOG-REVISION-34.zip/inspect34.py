"""Task34 bounded read-only seal, primary, native-identity and inventory audit."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import time
import zipfile

BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
START = time.monotonic()
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def check_time():
    if time.monotonic() - START > 180:
        raise TimeoutError('180-second static inspection ceiling')
def identity(p):
    check_time()
    n = p.stat().st_size
    if n > 50000000:
        raise ValueError('input exceeds 50,000,000-byte static bound: '+str(p))
    h = hashlib.sha256()
    with p.open('rb') as f:
        while b := f.read(65536):
            check_time()
            h.update(b)
    return {'path': str(p), 'bytes': n, 'sha256': h.hexdigest()}
def safe(name):
    p = PurePosixPath(name)
    return '\\' not in name and ':' not in name and not p.is_absolute() and all(x not in ('', '.', '..') for x in name.split('/'))
def no_reparse(p):
    return not p.is_symlink() and not (getattr(p.lstat(), 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
def seal(name, exclusions):
    leaf = BASE/name
    manifest = leaf/'SHA256SUMS.txt'
    rows = []
    names = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line:
            continue
        digest, relative = line.split(None, 1)
        relative = relative.lstrip('*')
        if not re.fullmatch('[0-9a-fA-F]{64}', digest) or not safe(relative) or relative.casefold() in names:
            raise ValueError('unsafe manifest member '+relative)
        names.add(relative.casefold())
        target = leaf/relative
        ancestors = [target, *target.parents]
        if not target.is_file() or not all(no_reparse(x) for x in ancestors) or not target.resolve().is_relative_to(leaf.resolve()):
            raise ValueError('invalid seal target '+relative)
        got = identity(target)
        if got['sha256'] != digest.lower():
            raise ValueError('seal mismatch '+relative)
        rows.append({'relative':relative, 'bytes':got['bytes'], 'sha256':got['sha256']})
        if len(rows) > 20000:
            raise ValueError('too many manifest members')
    actual = [p for p in leaf.rglob('*') if p.is_file()]
    uncovered = [p.relative_to(leaf).as_posix() for p in actual if p.relative_to(leaf).as_posix().casefold() not in names]
    unexpected = [x for x in uncovered if x not in exclusions and not x.startswith('scratch/')]
    return {'leaf':str(leaf), 'manifest':identity(manifest), 'covered_files':len(rows),
            'covered_bytes':sum(x['bytes'] for x in rows), 'all_matched':True,
            'uncovered_actual':sorted(uncovered), 'unexpected_uncovered':unexpected,
            'covered_report':next(x for x in rows if x['relative']=='REPORT.md')}
out = {'argv':sys.orig_argv, 'cwd':str(Path.cwd()), 'utc_start':utc(), 'static_ceiling_seconds':180}
mode = sys.argv[1]
if mode == 'seals':
    out['seals'] = [seal('sleep-observation-driver-revision-20261009-20', {'SHA256SUMS.txt','SEAL-RESULT.json'}),
                    seal('sleep-observation-driver-revision-independent-20261009-26', {'SHA256SUMS.txt','SEAL-RESULT.json'}),
                    seal('sleep-nested-source-qualification-20261009-28', {'SHA256SUMS.txt','SEAL-RESULT.json','SEAL-VERIFY-RESULT.json','seal-01.command.json','seal-01.stdout.txt','seal-01.stderr.txt','seal-verify-01.command.json','seal-verify-01.stdout.txt','seal-verify-01.stderr.txt'})]
elif mode == 'primary':
    lib = ROOT/'.gradle/v120-jei-session/server/libraries'
    jars = [lib/'net/minecraftforge/fmlloader/1.20.1-47.4.10/fmlloader-1.20.1-47.4.10.jar',
            lib/'org/apache/logging/log4j/log4j-core/2.19.0/log4j-core-2.19.0.jar']
    out['jars'] = [identity(p) for p in jars]
    with zipfile.ZipFile(jars[0]) as z:
        members = [x for x in z.infolist() if x.filename=='log4j2.xml']
        if len(members)!=1:
            raise ValueError('nonunique log4j2.xml')
        b=z.read(members[0])
        out['xml']={'entry':'log4j2.xml','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc_read_verified':True,'text':b.decode('utf-8')}
    with zipfile.ZipFile(jars[1]) as z:
        out['log4j_entries']=[]
        for name in ['org/apache/logging/log4j/core/appender/rolling/FileExtension$2.class','org/apache/logging/log4j/core/appender/rolling/action/GzCompressAction.class','org/apache/logging/log4j/core/appender/rolling/action/GzCompressAction$ConfigurableLevelGZIPOutputStream.class']:
            entries = [x for x in z.infolist() if x.filename==name]
            if len(entries)!=1:
                raise ValueError('nonunique primary class')
            b=z.read(entries[0])
            out['log4j_entries'].append({'entry':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc_read_verified':True})
elif mode == 'native':
    leaf=BASE/'sleep-nested-source-qualification-20261009-28'
    out['metadata']=[identity(leaf/name) for name in ['native-01-COLLECTION.json','native-01.command.json','collect.py']]
    collection=json.loads((leaf/'native-01-COLLECTION.json').read_text(encoding='utf-8'))
    out['logs']=[]
    for row in collection['copied']:
        relative=row['evidence'].replace('\\','/')
        if not safe(relative):
            raise ValueError('unsafe native evidence reference')
        p=leaf/relative
        got=identity(p)
        if got['sha256']!=row['sha256'] or got['bytes']!=row['bytes']:
            raise ValueError('native copied log mismatch')
        b=p.read_bytes()
        decoded=b.decode('utf-8',errors='strict')
        got.update({'evidence_relative':relative,'strict_utf8_audit':True,'error_headers':sum('/ERROR]' in x for x in decoded.splitlines()),'fatal_headers':sum('/FATAL]' in x for x in decoded.splitlines()),'terminal_lf':b.endswith(b'\n')})
        out['logs'].append(got)
    out['command_streams']=[identity(leaf/name) for name in ['native-01.stdout.txt','native-01.stderr.txt']]
    out['retained_gz_members']=[p.relative_to(leaf).as_posix() for p in (leaf/'native-01-results').rglob('*.gz')]
    out['collector_selection_observation']='collect.py selects suffix .log/.xml, not .gz; absent retained .gz is not original directory/rotation absence proof'
elif mode == 'inventory':
    root=ROOT/'docs/work/v1.8.0-c18a-sleep'
    out['archives']=[]
    for p in sorted(root.glob('*.zip')):
        got=identity(p)
        with zipfile.ZipFile(p) as z:
            rows=z.infolist()
            names=set()
            expanded=0
            for m in rows:
                name=m.filename.rstrip('/')
                if not safe(name) or name.casefold() in names or ((m.external_attr>>16)&0o170000)==0o120000:
                    raise ValueError('unsafe ZIP member '+name)
                names.add(name.casefold())
                expanded+=m.file_size
                if m.file_size>50000000 or expanded>100000000 or len(rows)>20000:
                    raise ValueError('ZIP review bound exceeded')
                if not m.is_dir():
                    actual = 0
                    with z.open(m) as f:
                        while b := f.read(65536):
                            check_time()
                            actual += len(b)
                            if actual > m.file_size:
                                raise ValueError('expanded length mismatch')
                    if actual != m.file_size:
                        raise ValueError('expanded length mismatch')
            got.update({'expanded_bytes':expanded,'entries':len(rows),'full_crc_and_expanded_count_verified':True})
        out['archives'].append(got)
    out['compressed_archive_bytes']=sum(x['bytes'] for x in out['archives'])
    out['expanded_archive_review_bytes']=sum(x['expanded_bytes'] for x in out['archives'])
    out['external_leaves']=[]
    for leaf in sorted(BASE.glob('sleep-*')):
        if not leaf.is_dir():
            continue
        files=[]
        for p in leaf.rglob('*'):
            check_time()
            if p.is_file():
                if not no_reparse(p):
                    raise ValueError('reparse external inventory')
                files.append(p.stat().st_size)
                if len(files)>20000:
                    raise ValueError('external inventory entry bound')
        out['external_leaves'].append({'path':str(leaf),'files':len(files),'bytes':sum(files),'max_file_bytes':max(files,default=0),'sealed':(leaf/'SHA256SUMS.txt').is_file()})
    out['external_physical_bytes']=sum(x['bytes'] for x in out['external_leaves'])
    out['repository_nonarchive_files']=[{'path':str(p),'bytes':p.stat().st_size} for p in root.iterdir() if p.is_file() and p.suffix!='.zip']
    out['reserved_future_output_bytes']=65011712
    out['compressed_plus_reserved']=out['compressed_archive_bytes']+65011712
    out['expanded_plus_reserved']=out['expanded_archive_review_bytes']+65011712
    out['inventory_atomic']=False
else:
    raise ValueError(mode)
out['utc_end']=utc()
out['elapsed_seconds']=time.monotonic()-START
out['exit_code']=0
print(json.dumps(out,ensure_ascii=True))
