# Task34 compressed native-log contract revision

Date: 2026-10-09 UTC. Delegated static worker, not Root or an independent reviewer.
Status: **PROPOSED / STATIC ONLY / UNSEALED / NOT ADOPTED**.

## Findings and remaining obligations first

1. **Task26-R01 receives an explicit proposed refusal policy, not decoder closure.**
   The pinned latest/debug appenders have compressed .log.gz destinations.
   Their gzip action can close its compressed output and delete its plain source.
   This revision chooses Task26's permitted narrow alternative: every compressed
   successor or unresolved rollover makes native diagnostic capture INCOMPLETE.
   Bounded actual stored extents remain; no gzip-container diagnostic scan, guessed
   expanded size, prefix-based success, NBT-policy reuse or logger change is allowed.
   Successful capture supports only fully accounted contiguous uncompressed files.
   Independent review must accept this refusal scope before implementation freeze.
2. **The actual conservative cumulative basis does not fit unchanged budgets.**
   The sampled 26 ZIPs total 11,059,335 compressed /60,277,949 expanded bytes.
   The unchanged future reserve is 65,011,712 bytes. Expanded-plus-reserve alone
   is 125,289,661, above 100,000,000 and 100 MiB, before unarchived/loose/later
   obligations. Compressed-plus-reserve is a different incomplete subtotal,
   76,071,047, not permission to relabel the failing conservative calculation.
   No evidence is deleted, reserve reduced or measure changed to claim admission.
3. **Task28 retained logs cannot establish rotation completeness.** Its copied
   latest/debug files and raw streams match actual collection/command identities,
   and strict UTF-8 static audit reproduces 62 ERROR /zero FATAL for each log.
   However collect.py selects .log/.xml, not .gz. No retained .gz exists; that is
   not proof that no original compressed rotation existed. Task28 remains a
   standard GameTest qualification, not a driver/capture-runtime qualification.
   Its errors/strict timeout remain unwaived; this task neither reruns nor erases them.
4. **All operational prerequisites remain open.** Stable file identity/race/EOF,
   actual logger encoder/Unicode, compact-index/IO/storage/helper/resource and
   synthetic refusal qualification, fresh complete distinct-set inventory and
   pre-run disposition are unexecuted. The separately proposed OS-enforced
   <=4 GiB runtime allocation/helper/quota remains unassigned. No runtime, process
   signal, cleanup, implementation, whole-proposal adoption or Gate authority follows.

No production defect or native rotation/decompression result was observed by this
task. It changes only its assigned external leaf and preserves every domain below.

## Exact inputs, governance and source identities

Task permission: 3646 bytes, SHA256
29a9b47a0b2a91a4a993dee44fc3260c7191c2d4abbb7d063e5161a2b8d869cf.
Fixed governance: ce64a8eb79c0f6fb53f000f0c2a0e4e947ef9985.
Fixed opt-in source: d57ecda1f11dab76d882f945b0de606534ef4fb9;
src tree 85f53265bf4ee59b65c4a88664cb2e5e208c583e.

Complete mandatory fixed project/product/principles/roadmap/master-test/release/
parallel/post-v1.0/quality documents, the actual uppercase v1.8 version, fixed
CURRENT_VERSION/GATE_STATUS/ADR-060 and earliest unfinished v1.0 version were read.
The acceptance cursor remains v1.0; ADR-060 permits scoped v1.8 development,
not inherited or current acceptance. Fixed owner decisions01/03 were completely
read; exact ancillary choice is conditional freeze/review, not runtime authority.
Their SHA256 values are db19249fdd391bf45f7833052edfa323595b2c1efb45d7ee4747b91db8ab4f8c
and a07290d5d9c6b721419ddcc245da2dac5082ad0f0f1958b974928ccd336d795e.

| Complete input | Bytes | SHA256 |
|---|---:|---|
| Task20 PROPOSED-DRIVER-03.md | 68873 | c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680 |
| Task20 REPORT.md | 17261 | 06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6 |
| Task26 REPORT.md | 24412 | e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc |
| Task28 sealed REPORT.md | 24085 | 52f3897671a060020f11ff46b5dcb61d20576b46e48cba66bc387362ff311e02 |
| Fixed NESTED-BOUNDARY-STATUS-27.md | fixed Git blob | b332e427703926a06cf7c038fdb8a00d78cfe4ee14efb883d69a56b55615198e |
| Fixed DRIVER-REVIEW-STATUS-18.md | fixed Git blob | e85b7c686e245a7d6229355370cb09e0fa0b5f71090130ba328efabaadcd2860 |

Task20's complete 991-line proposal was displayed in bounded complete sections;
Task20/26/28 reports and Task28 actual collection/command/collector metadata
were completely read and hashed. Historical Task20 5b source is not retroactively
changed to d57. Independently hash-read fixed d57 source identities are:
Trace 27593 bytes /20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f;
ChatBounds 15889 /16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0;
Fixture 33987 /1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820.
These source reads are hash/identity checks, not a new source review or test result;
their full source payloads are deliberately not retained as duplicate exports.

## Actual manifest coverage and exclusions

receipt-24-seals.json and the later stricter ancestor check in receipt-35 verify
every listed safe, case-unique, contained regular member against its actual hash.
All target/ancestor reparse checks in the second audit pass. Actual uncovered
files exactly match declared exclusions; no unexpected uncovered payload exists.

| Input leaf | Manifest SHA256 | Covered files /bytes |
|---|---|---:|
| Task20 | b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0 | 198 /1089641 |
| Task26 | 9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d | 149 /1890251 |
| Task28 | d063e2b87fae9fb0856d4141e8c1d27e15ae540f797adf15e384bc9875efa913 | 909 /14278320 |

All 1256 covered files match, totaling 17,258,212 bytes. Task20/26 exclude
manifest self-reference and post-seal SEAL-RESULT.json only. Task28 additionally
excludes SEAL-VERIFY-RESULT.json and seal-01/seal-verify-01 command/stdout/stderr
files; its scratch prefix has no evidence payload in this audit.
Those post-seal records are not falsely declared manifest-covered.
The external Task20 37-byte incident original and old denied peer outputs are
not covered/transferred/modified/cleaned by this task.

## Installed primary and actual native-log identities

Task26 manifest-covered log-profile and selected FileExtension$2/GzCompressAction
bytecode captures were fully read. Installed matching containers and selected
entries were independently rehashed/CRC-read without copying whole libraries
or invoking Java/native code.

| Installed primary | Bytes | SHA256 |
|---|---:|---|
| fmlloader-1.20.1-47.4.10.jar | 267079 | 12d27a5d59286ab5fa8cc90cb2c73eb21f4624b765ce2e6408d5e397a6a6699b |
| unique log4j2.xml entry | 5541 | b51029523df8874beca56c09ce4310bdae7f0885dc1412f8830f62f04c19db83 |
| log4j-core-2.19.0.jar | 1864386 | b4a1796fab7bfc36df015c1b4052459147997e8d215a7199d71d05f9e747e4f4 |
| FileExtension$2.class | 1334 | 9dd410147ffdc917342c38872e5b029f229c73986b82757f1196562fae19e306 |
| GzCompressAction.class | 4806 | 2fe109c2bcc963b3d66d5f8096b59798f4c4761df8582d79f7b8c68b75925697 |
| ConfigurableLevelGZIPOutputStream.class | 945 | 71246b5f9de076f6c22e1b62e7eabb59389605243148cfc440397e61ee5e4247 |

The primary library paths are the existing
D:/GitHub/AdvancedRocketry-Community/.gradle/v120-jei-session/server/libraries/
net/minecraftforge/fmlloader/1.20.1-47.4.10/ and
org/apache/logging/log4j/log4j-core/2.19.0/ beneath that same libraries root.
XML latest has time/startup gzip rollover, max99/min; debug has startup/200MB
gzip rollover, max5/min. The native logger is unchanged. Class hashes bind the
actual primary backing Task26's static bytecode; no runtime method is invoked.

| Task28 native identity | Bytes | SHA256 |
|---|---:|---|
| native-01-COLLECTION.json | 57129 | 9cfa2adbaf0979ebb3b5f726b7fd19a558c410002c280a6ab87195b342905611 |
| native-01.command.json | 12660 | 33a1cfb34bafec25c17bda3b97f6286e902675efe9b8a3cb965b270a27231079 |
| collect.py | 4456 | 523df8632287d51d3b330214e3300e5e3082140a27939631433e90e56c995b83 |
| retained latest.log | 1854127 | 651666bc388890faf9191006459cda6beafaf1abaae5bbf708e271a8b1a85479 |
| retained debug.log | 2030639 | 392af1ddd7682ff144658d4e97cc71028ed78499b0a1f4b6800d9338b6bc4810 |
| native-01 stdout | 1706344 | 5933817e1037def591daaefe29d78301dddb601f85579c80f18f9a9e60c6c857 |
| native-01 stderr | 14116 | 7be65bf31a95fcd021de94be7e620c16cf93578d0da5a46f29cd3ac4f6116a8a |

Both log payloads are sealed under native-01-results/build/gametest/logs/.
Their hashes/lengths match collection metadata; strict UTF-8 audit succeeds,
both terminate in LF, and each has 62 ERROR /zero FATAL headers. This proves
only these retained files' identity/encoding sample, not original-directory
coverage, final producer EOF/flush, future charset or clean native diagnostics.
Raw logs are read in place, never recopied into this leaf.

Task28's recorded command is unfiltered gradlew.bat runGameTestServer, exact
fixed d57 source/tree, exit0, 2026-10-09T07:25:53.994666Z to 07:30:06.547652Z,
252.553 seconds, ceiling 2400. Its report's 594 required GameTests/2192 JUnit
and strict 180-second TIMEOUT are input results, not tests executed by Task34.
Its ordinary Gradle launch and separately captured stdout/stderr do not prove
the future packaged merged-pipe recipe or opt-in twenty-row observation.

## Scoped proposal and changed clauses

New PROPOSED-NATIVE-LOG-04.md is additive only. Its decisions are:
- all compressed/ambiguous native rotation refuses successful capture;
- exact owned directory, file identity/generation, offset aliases and controller
  chronology, with no filename/time ordering or prefix-based omission;
- distinct S actual stored bytes, P plain extents, C compressed stored subset,
  E_gzip UNKNOWN; all physical duplication is charged and expanded clones forbidden;
- bounded incomplete prefixes, original first failure, unknown tail/EOF/durability;
- strict qualified plaintext diagnostics, immutable raw occurrences and non-destructive
  cross-view correlation; no compressed-byte scan or blanket row19/error waiver;
- unchanged fixture/producer/chat/JSON/playerdata NBT budgets, logger, waits and
  runtime-storage prerequisite; merged cursor is not per-byte stdout provenance;
- cumulative conservative sample refuses admission, rather than relabeling volumes.

The replacement table names proposal03:121/205-219,227-240,282-325,702-750,
779-802. This is not a whole driver revision or acceptance. Task26-R02's 2049
independent-field envelope versus joint tighter 1366 loose ceiling is accurately
noted, without changing any chat/parser cap or making an at-limit native claim.

## Sampled cumulative inventory and resource boundary

receipt-28 is the bounded full-CRC/hash/count inventory, UTC
08:10:56.081378 to 08:10:56.627933 on 2026-10-09. Its 26 repository ZIPs include
Task28/29/31. Compressed storage 11,059,335 and expanded review 60,277,949 are
distinct verified quantities. Reserve 65,011,712 is the unchanged future cap,
not storage allocated or actual generated output. Expanded-plus-reserve 125,289,661
already fails the conservative proposal measure.

Loose repository sleep records add 108,640 bytes at that sample. Physical external
sleep leaves total 62,126,103, including custody duplicates and unsealed Task32/34.
External/archive differences and later/excluded files require a proper content/
custody mapping before any distinct-set accounting. No blind double counting or
unproved alias subtraction is used to assert admission. The ZIP-only failing
lower bound suffices to preserve the unresolved condition; it is not a claim
that every task receipt/loose/later set has already been admitted or mapped.
The snapshot is non-atomic; Root later changes/publishes records independently.
Fresh complete pre-run inventory and a separately reviewed disposition are required.

No archive/source/export/world/build/server/library payload tree is copied here.
No existing evidence is removed. No runtime hard allocation/helper is selected,
created, exercised or implicitly assigned by this static accounting.

## Actual commands, results, failures and capture limits

Actual work is read-only fixed Git/file/hash/ZIP/Python -B static inspection.
All writes use apply_patch solely in this task's new external leaf. Child Git
reads have exact argv/cwd/immediate UTC/exit and raw stdout/stderr base64.
Inline audit operations report Python-start UTC/original argv where available,
bounded input/result identities and exact operation outputs. Their 180-second
static ceilings are not a recovered prelaunch timestamp or an external watchdog.
No command reaches a ceiling; no process signal or cleanup is executed.

| Evidence | Actually executed work / result |
|---|---|
| INITIAL-PREFLIGHT-TOOL-RECEIPT.json | Task hash/status/branch/HEAD/worktrees/paths; outer exit0, large displayed output truncated. Existing AGENTS/untracked peer work left untouched. |
| receipt-01 through 14 | Fixed discovery, mandatory/governance reads; one guessed lowercase version git show exits 128, retained in receipt-04; actual uppercase version then read successfully. |
| receipt-15 through 20 | Full Task20/26/28 reports and complete proposal03; focused complete report displays after combined-display truncation. |
| receipt-21 through 23 | Bounded input filenames, primary excerpts/coverage, complete Task28 native metadata/collector reads; successful bounded replacement of the overlarge discovery display. |
| receipt-24/35 | Actual three-input manifest/hash/safe-member coverage, then strengthened ancestor checks; exit 0, all 1256 covered files match. |
| receipt-25 | Installed fmlloader/Log4j containers and selected XML/class CRC/hash reads; exit 0. |
| receipt-26 | Actual native metadata/raw-log/stream identities and strict retained-log encoding/header audit; exit 0. |
| receipt-27/28 | First central-directory inventory, then separate full bounded ZIP CRC/expanded-count/hash inventory; exit 0. Earlier metadata-only result is not described as full CRC proof. |
| receipt-29 through 33 | Fixed acceptance/ADR/version documents and task reread/hash; exit 0. |
| receipt-34 | Fixed d57 tree and three source length/hash checks; child Git exits 0, full source output intentionally not duplicated. |

Preserved capture limits/failures:
- The first task read and guessed-version filename discovery are transcript-only
  tool receipts without separate raw-stream process capture.
- The large initial preflight is preserved exactly as returned by the tool,
  including its truncation warning; absent complete output is not reconstructed.
- Initial multi-document/report display rendering truncated; persisted receipt
  bytes remained complete and relied-on texts were redisplayed in complete sections.
- The first broad input-file-list output exceeded the tool return bound; parsing
  that returned truncated text raised SyntaxError before a receipt was written.
  Its raw session error is not recreated as a complete subprocess transcript.
  A separately revised bounded listing succeeds as receipt-21; no input changes.
- Early audit34 records sys.argv, which omits Python/-B wrapper arguments;
  later records use sys.orig_argv. No old launch argv/time is fabricated or
  backfilled. Inline file-read receipts do not provide separate raw outer-process
  stderr; file bytes are hash-bound and UTF-8 text reads are strict.
- apply_patch transport/outer tool execution is not a fully instrumented OS
  transcript. Static helper evolution is pre-seal; command receipts describe
  their actual observations, not a claim that today's helper executed every
  earlier command. Fixed child Git raw streams remain lossless.
- No Java/javap runtime, Gradle, test/server/client, network/install, allocation/
  quota/mount, process signal, cleanup, source edit, commit/push/index/HEAD/worktree
  move, peer adoption, Claude or delegation is executed. Root owns OpenPet.

## Completion, files, tests and Gate status

Completed: complete fixed input/governance/primary/metadata reads and hashes;
actual manifest coverage and native identity audit; actual sampled compressed/
expanded inventory; narrow proposed refusal/accounting/diagnostic/EOF clauses;
compact receipts/helpers and this report.

Uncompleted: independent review/adoption, all implementation/synthetic mutation/
IO/resource/Unicode/helper tests, full future input/custody admission, native
twenty-row/two-invocation/save/reacquisition/restart/client/GPU/performance,
runtime allocation/authority and all production B1/R1/M1/M2/D1/item/asset/Gates.

Modified files: only this exclusive external leaf's audit34.py, inspect34.py,
PROPOSED-NATIVE-LOG-04.md, this REPORT, initial tool receipt and numbered compact
receipts. No repository/peer/input/sealed evidence/archive/incident file changes.
No tests are added or modified. Tests **NOT EXECUTED**: clean build, test,
runData/generated diff, runGameTestServer, driver/parser/unit/native/client/
restart/resource/visual checks. Not PASS and not NOT_APPLICABLE.

Known risks: monitoring cannot by itself prove every fleeting rotation; strict
failure of legitimate time-boundary native logs; unqualified IO/identity/encoder/
EOF/helper behavior; unknown gzip payloads; intentionally incomplete prefixes;
future live inventory growth and cumulative conservative capacity failure.
No finite wall-clock or static seal cures those risks.

**All current/inherited Required Gates G0-G9 satisfied: no.**
No source/product/Gate/item/ledger approval, accepted driver contract, production
change, native launch permission, version status, release or tag is claimed.
Next suggestion within current v1.8 only: Root fully reads this final report,
then obtains independent disposition of the refusal and cumulative obligations
before separately assigning any bounded offline/capture implementation.

Evidence leaf:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34/.
Root must fully read this final report and explicitly acknowledge its exact hash
before any one-time seal. At preparation, no acknowledgement or seal is inferred.
