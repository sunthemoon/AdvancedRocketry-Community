"""Task34 read-only audit helper; emits receipts, never writes input/output files."""
import base64
import datetime
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
PIN = 'ce64a8eb79c0f6fb53f000f0c2a0e4e947ef9985'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(argv):
    start = now()
    p = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180)
    return {'argv': argv, 'cwd': str(ROOT), 'utc_start': start, 'utc_end': now(),
            'exit_code': p.returncode, 'stdout_b64': base64.b64encode(p.stdout).decode(),
            'stderr_b64': base64.b64encode(p.stderr).decode(),
            'stdout_text': p.stdout.decode('utf-8', errors='replace'),
            'stderr_text': p.stderr.decode('utf-8', errors='replace')}

def file_receipt(path):
    p = Path(path)
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'text': data.decode('utf-8', errors='strict')}

start = now()
result = {'argv': sys.orig_argv, 'cwd': str(Path.cwd()), 'utc_start': start, 'items': []}
mode = sys.argv[1]
if mode == 'git':
    for name in sys.argv[2:]:
        receipt = run(['git', 'show', PIN + ':' + name])
        receipt['path'] = name
        receipt['stdout_sha256'] = hashlib.sha256(base64.b64decode(receipt['stdout_b64'])).hexdigest()
        result['items'].append(receipt)
elif mode == 'files':
    for name in sys.argv[2:]:
        result['items'].append(file_receipt(name))
elif mode == 'discover':
    result['items'].append(run(['git', 'ls-tree', '-r', '--name-only', PIN, '--', 'docs/work/v1.8.0-c18a-sleep']))
    result['items'].append({'sleep_dirs': [str(p) for p in BASE.iterdir() if p.name.startswith('sleep-')]})
elif mode == 'state':
    for argv in [['git', 'status', '--short'], ['git', 'branch', '--show-current'], ['git', 'rev-parse', 'HEAD'], ['git', 'worktree', 'list']]:
        result['items'].append(run(argv))
elif mode == 'source-identities':
    pin = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
    result['items'].append(run(['git', 'rev-parse', pin + ':src']))
    for name in ['SleepBoundaryTrace.java', 'SleepBoundaryChatBounds.java', 'SleepBoundaryObservationFixture.java']:
        path = 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name
        receipt = run(['git', 'show', pin + ':' + path])
        raw = base64.b64decode(receipt.pop('stdout_b64'))
        receipt.pop('stdout_text')
        receipt.update({'path':path, 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(),
                        'payload_not_copied':True, 'stdout_capture_limit':'full bytes hashed, deliberately not retained as another source copy'})
        result['items'].append(receipt)
elif mode == 'list':
    for name in sys.argv[2:]:
        p = Path(name)
        rows = []
        total = 0
        total_bytes = 0
        for q in p.rglob('*'):
            if q.is_file():
                relative = q.relative_to(p).as_posix()
                size = q.stat().st_size
                total += 1
                total_bytes += size
                if '/' not in relative or re.search(r'commands/.*(?:log-profile|log-gzip|primary)', relative):
                    rows.append({'path': relative, 'bytes': size})
                if total > 20000:
                    raise ValueError('file inventory exceeds static bound')
        result['items'].append({'root': str(p), 'files': rows, 'total_files': total, 'total_bytes': total_bytes})
else:
    raise ValueError(mode)
result['utc_end'] = now()
print(json.dumps(result, ensure_ascii=True))
