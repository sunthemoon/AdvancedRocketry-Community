# Task34 prospective seal coverage

No seal is permitted until Root fully reads final REPORT.md and explicitly
acknowledges its exact SHA256. No acknowledgment is inferred from preparation.

If separately authorized, the manifest covers every regular file in this exclusive
external leaf except SHA256SUMS.txt itself and exact post-seal SEAL-RESULT.json.
All covered files must have safe, case-unique forward-slash leaf-relative names,
contained resolution, and no reparse file or ancestor. Files must be under
50,000,000 bytes and the complete leaf under 100,000,000 bytes. These leaf hygiene
limits do not qualify the failing cumulative native-run admission.

Input manifests, libraries, native log payloads, repository archives, external
incidents, peers and live/generated external paths are not members of this seal.
Post-seal results are explicitly excluded rather than self-referenced. Root's
actual acknowledgement, if received, is preserved only afterward. Sealing does
not adopt the proposal, authorize runtime or approve any product or Required Gate.
