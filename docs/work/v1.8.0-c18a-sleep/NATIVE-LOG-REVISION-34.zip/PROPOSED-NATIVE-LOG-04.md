# Proposed native-log capture revision 34

Date: 2026-10-09 UTC. **PROPOSED / STATIC ONLY / NOT ADOPTED**.
This is a narrow additive disposition of Task26-R01 against sealed proposal03,
not an edit of Task20/26. It grants no implementation, driver, parser, native
launch, process signal, allocation, quota, mount or cleanup authority.

## 1. Chosen scope and unchanged contracts

Choose Task26's explicit incomplete-capture alternative: **compressed native-log
rotations are not supported for successful capture in this revision**. A run may
succeed only with completely accounted ordinary uncompressed latest/debug files.
Any compressed successor, rollover/replacement, lost segment or unresolved
identity/order fails capture, even when an earlier plain prefix was retained.
This makes the refusal deterministic instead of assuming that a short run cannot
cross a logger time boundary. A future supported-gzip policy requires another
separately reviewed revision, not an automatic fallback or adoption of section 8.

Fixed governance is ce64a8eb79c0f6fb53f000f0c2a0e4e947ef9985.
Fixed opt-in source reference is d57ecda1f11dab76d882f945b0de606534ef4fb9,
src tree 85f53265bf4ee59b65c4a88664cb2e5e208c583e. Task20's historical
5b source remains historical; Task28 is a distinct standard qualification.
Production sleep/dimension/spawn/time/air and all source fixture caps are unchanged.

Retain proposal03's three 16 MiB admission /17 MiB hard retained families;
32 segment identities per native family; 64 KiB read chunks, four-chunk queue,
512 KiB+4096 candidate buffer, 1 GiB total pipe-read limit, 256 MiB parser RSS
target, compact 10 MiB and emergency 1 MiB categories. Total future retained
reserve stays 62 MiB =65,011,712 bytes. No expanded-log file, second sink,
unlimited spool, extra decoder buffer or new storage category is introduced.
Metadata fits the existing compact category and individual 64 KiB receipts;
indices/projections/other compact evidence share the existing 1 MiB aggregate.
If actual required metadata cannot fit, capture refuses before allocating it.

Native waits remain 300/60/60/90 seconds, sum 630 seconds; existing phase and
global success/failure ceilings remain 1115/1145 seconds. Log inventory,
identity monitoring, copies, plaintext inspection and failure receipts consume
those existing phases. There is no extra rotation, inflate, retry or final wait.
The separately proposed <=4 GiB OS-enforced runtime allocation and its platform
helper/authority remain unassigned. Polling does not substitute for that proof.

Producer UTF-8/framing, chat/source accounting, response JSON and playerdata
NBT/gzip policies remain separate. No response can originate in a log file.
Merged stdout/stderr has one merged received-byte cursor: it does not preserve
per-byte stdout origin or original cross-stream order. Trusted raw println is a
qualified producer route, not authenticated provenance of every merged byte.
No split-stream sink or budget is silently added.

## 2. Primary-supported source families

The installed fmlloader 1.20.1-47.4.10 container and unique log4j2.xml are
rehashed in receipt-25-primary.json. The XML has these exact routes:

| Family | Active path relative to owned runtime | Rotation pattern/policy |
|---|---|---|
| latest | logs/latest.log | logs/%d{yyyy-MM-dd}-%i.log.gz; TimeBasedTriggeringPolicy and OnStartupTriggeringPolicy; max99, fileIndex=min |
| debug | logs/debug.log | logs/debug-%i.log.gz; OnStartupTriggeringPolicy and SizeBasedTriggeringPolicy size=200MB; max5, fileIndex=min |
| merged process pipe | owned redirected stdout/stderr | Not a native log family or archive; native raw capture cursors apply |

The 200MB XML value is the logger's native setting, not permission to retain or
inspect that volume. FileIndex/date/name/mtime/size do not establish a capture
sequence. No logger setting, marker filter, level, pattern, rollover maximum,
timezone or compression action is changed to avoid this boundary.

Task26's manifest-covered FileExtension$2/GzCompressAction bytecode describes
the gzip branch, complete input-file read into GZIPOutputStream and close, then
conditional source deletion. Installed class-entry CRC/hash identities are
independently recorded here. These are static facts, not an executed rollover,
proof of asynchronous completion or a qualified observer of every rename.

## 3. Identity, order and refusal transitions

A future assigned controller starts from an absent/fresh logs directory and
captures its bounded inventory before launch. Unexpected inherited files fail
prelaunch freshness; they are not silently attached to a new process. Every
scan is contained to that owned literal logs directory, rejects reparse paths
and unexpected nested paths, and bounds names/entries before constructing lists.
Latest/debug expected patterns are classified separately; any otherwise
unclassified log/compression/temp file is unresolved evidence, not ignored.

Track each opened plain file by the qualified filesystem's stable file identity
and generation, creation/open/observation UTC and monotonic cursor, exact relative
name aliases, acknowledged retained extents, source sizes and hashes. Stable
identity support and replacement/shrink/race detection require independent helper
qualification; a pathname or same size/hash at one sample is insufficient.

For successful capture, each family has exactly one contiguous plain generation
with retained offsets [0, final_length), no shrink/replacement/rename, no gap,
no compressed successor and no unexplained files. Every segment observation
counts toward the unchanged 32 identities, including an unsupported compressed
object; rename observations cannot reset that counter. Failure to enumerate the
bounded inventory, >32 identities, change during stable copy or unavailable
identity proof is CAPTURE_GAP/BUDGET/IO failure, as applicable.

Use observed controller sequence only for custody chronology. Do not sort gzip
filenames, native timestamps, filesystem mtimes or latest/debug records into a
fabricated total emission order. A compressed successor is recorded as a new
stored representation with a suspected, never assumed, predecessor relation.
Its arrival immediately sets CAPTURE_UNSUPPORTED_COMPRESSED_ROTATION and native
diagnostic completeness INCOMPLETE/UNKNOWN, prohibits the second/future fixture
invocation and initiates only already permitted failure/save/stop handling.
Do not wait for compression completion to make it admissible.

A plain prefix followed by a gzip successor remains a refused family even if
the retained prefix might cover its payload. This revision never uses a
prefix/hash coincidence to claim full expanded equality, deduplicate a missing
tail, synthesize EOF or restore success. Already retained evidence is not deleted.

## 4. Stored, observed and expanded-byte accounting

Keep distinct counters rather than calling compressed size expanded volume:

- S: actual acknowledged retained physical bytes for a family. All plain and
  compressed extents, including physically duplicated copies, consume S.
  Crossing 16 MiB prohibits further fixture commands; S never exceeds 17 MiB.
  The 1 MiB between these limits is failure/shutdown reserve, not normal admission.
- P: observed plain-generation bytes and exact retained logical offset ranges.
  Re-reading an already retained extent can use an exact identity/offset/hash
  backreference without writing another copy. If it is physically copied again,
  those bytes count again in S. Plain retained payload bytes are their own
  expanded review volume; no compression ratio is involved.
- C: actually retained compressed bytes, a subset of S, and separately the
  observed compressed file size/time if obtainable without an unbounded read.
  Do not subtract C because an original prefix has the same presumed content.
- E_gzip: expanded log payload volume. It is UNKNOWN for every compressed
  rotation under this refusal policy, not zero, ISIZE, observed plain size,
  compressed length or a guessed ratio. Zero bytes are decoded here; that
  operation count does not mean a zero-length native payload.

Admission requires the complete observed plain length and S each <=16 MiB,
all relevant plaintext interpreted within the existing bounded phases, and no
compressed or unresolved representation. A compressed file refuses regardless
of C, its header, apparent size, empty-file claim or retained original prefix.

After refusal, preserve existing plain extents and only bounded actual compressed
extents that fit remaining S<=17 MiB. Do not copy/hash a huge file in full merely
to record a refusal. Each retained prefix has actual offset/length/SHA256, obtained/
acknowledged/durable states and source identity/time; mark first unretained offset
and unknown eventual length/EOF. A prefix hash is not a complete-file hash.
Physical duplication is charged; logical backreferences do not erase custody
copies from storage accounting. No rotation is deleted or overwritten to fit.

No gzip member/header/optional-field/trailer/CRC/ISIZE/DEFLATE/expanded-EOF contract
is admitted for native diagnostic success here. Those states are NOT VALIDATED;
both valid and invalid gzip representations refuse. In particular, the playerdata
one-member ten-byte header and 1/4 MiB NBT limits do not apply to native logs.
A partial gzip cannot be described as corrupt merely because this task refuses it.
A later decoder proposal must independently bind its writer, supported profiles,
member/count/expanded/time/RSS bounds, integrity and exact-consumption policy.

## 5. Plaintext diagnostic interpretation and EOF

Retain native plaintext bytes unchanged, with per-file offsets and cross-family
backreferences. Actual pinned logger encoder/charset/configuration must be
qualified before interpreting non-ASCII diagnostics; XML declaration encoding is
not proof of PatternLayout output encoding. Task28's two retained UTF-8 logs are
audited samples, not future process-wide Unicode or logger-route qualification.

Under a separately qualified UTF-8 recipe, use strict incremental decoding;
invalid/truncated encoding, decoder repair, unexplained BOM/control/framing or
unbounded diagnostic records cause separate incomplete interpretation. Preserve
the bytes; never errors=replace, strip ANSI, join torn bytes, normalize newline
storage or reconstruct missing lines to establish completeness. Native log
patterns and multiline stack continuations are not response marker grammar.
Existing buffer/metadata/RSS/deadline bounds apply; an oversized line/index or
unsupported diagnostic structure refuses rather than silently dropping it.

Interpret WARN/ERROR/FATAL/linkage/save/compression messages and their actual
bounded stack/continuation extents across every complete admitted plain family
and the merged pipe. An observation/setup prefix in native logs is only a stray/
diagnostic finding. It cannot satisfy a raw response or acknowledged command
window. Log timestamps are correlation aids, not exact invocation causality.

Never count identical console/latest/debug views as independent incidents solely
because they occupy three families. Preserve all raw occurrences and offsets;
a derived cross-view group is only correlation with explicit supporting fields,
not destructive deduplication or a waiver. Repeated identical messages within
one source remain separate occurrences unless exact source-offset aliases prove
the same retained bytes. Uncertain cross-view correlation stays uncertain.

No diagnostics are scanned directly from gzip container bytes and called payload
diagnostics. Retained plain prefixes may yield observed findings after refusal,
but missing gzip interpretation cannot yield a clean-log result, zero total
diagnostics, native success/failure verdict or row19 waiver. Task28's 62 ERROR/
zero FATAL views remain unwaived; test command success is a separate domain.

Success additionally requires actual process/reader completion within the
existing five-second reader phase, final stable identity/size/hash/copy checks,
complete contiguous family EOF and a fully inspected final bounded line or an
explicit refusal for unresolved/truncated final text. A filesystem read reaching
current EOF while the producer/compressor remains live is not final capture EOF.
Exit alone does not prove native writer flush/durability. Any lost/replaced/
truncated tail, unfinished writer/reader, unavailable flush/readback or missing
final inventory is incomplete. Preserve original errors and first failure;
a later small latest.log or normal exit cannot overwrite that outcome.

## 6. Sampled cumulative inventory, not pre-run admission

receipt-28-inventory-crc.json samples actual current files from
2026-10-09T08:10:56.081378Z to 08:10:56.627933Z. Twenty-six actual repository
sleep ZIPs are SHA256-hashed and safe/case-unique, with full bounded CRC reads
and expanded byte-count verification. They include Task28, Task29 and Task31,
not just Task20's obsolete seventeen-archive or checkpoint27's twenty-two basis.

| Quantity | Bytes |
|---|---:|
| Actual compressed ZIP storage | 11,059,335 |
| Actual expanded ZIP review payloads | 60,277,949 |
| Unchanged future retained-output reserve | 65,011,712 |
| Compressed ZIPs plus reserve, incomplete subtotal | 76,071,047 |
| Expanded ZIPs plus reserve, already-refusing lower bound | 125,289,661 |
| Sampled loose repository sleep records | 108,640 |
| Physical external sleep leaves, including custody duplicates and live leaves | 62,126,103 |

These are separate measures. Existing external copies are not magically compressed
storage; identical archived logical sets are not blindly counted as newly
delivered logical payloads either. The physical external inventory is reported
separately and includes later/excluded files and unsealed Task32/34 snapshots.
Archive/external differences require an actual content/custody map before any
complete distinct-set admission; size equality alone cannot establish aliasing.
No such future admission or mapping is claimed here.

Even the expanded-archive-only lower bound plus the unchanged reserve exceeds
both 100,000,000 and 100 MiB=104,857,600. Loose records, unarchived sets, subsequent
Task32/34 files, task receipts and other actual reserves only add obligations.
Therefore proposal03's conservative expanded measure does not fit this sample.
Do not relabel it compressed, lower reserve, delete evidence, split one slice,
reuse earlier totals or claim the smaller compressed subtotal is permission.
A separately reviewed pre-run disposition and fresh complete actual inventory
are required. Root's later publication changes do not alter fixed governance.

## 7. Changed clauses and remaining obligations

Proposed replacements/clarifications, without changing original bytes:

| proposal03 clause | Narrow revised meaning |
|---|---|
| 121; 205-219 | Logger remains pinned; S/P/C/UNKNOWN E_gzip are distinct; no new retained budget. |
| 227-240 | Earlier seventeen-archive arithmetic is historical; sampled actual expanded lower bound fails cumulative admission. |
| 282-289 | Identity/offset custody plus explicit refusal of every rotation/compressed successor; filenames are not byte order. |
| 291-325 | Existing budget/IO/stop failure rules also apply to unsupported rotation; no new authority or wait. |
| 702-750 | Complete plaintext diagnostic correlation only; gzip bytes are not payload; merged pipe is not per-byte stdout provenance. |
| 779-802 | Remains playerdata/NBT-only; not a native-log decoder policy. |

Task26-R02's 2049 envelope is not a reachable source maximum: fixed source's
8192/6 joint estimate supplies a tighter loose combined-ID ceiling of 1366 including
the colon, potentially lower with other text. This record introduces no chat
contract or parser cap change, and never uses 2049 as an at-limit native expectation.

Remaining work is independent review of this refusal scope and cumulative-volume
disposition; separately assigned helper/encoding/identity/race/EOF/storage/IO/
resource and synthetic mutation qualification; future coherent actual inputs;
and the still-unassigned runtime allocation/permissions. If accepted, offline
tests must cover compressed arrival before/after copied prefixes, missing/
renamed/reused/shrunk identities, partial/complete gzip, misordered file names,
oversize/count/IO/final-EOF failures and diagnostic cross-view grouping, with
at-limit/one-over checks. Such cases are structural, not invented native results.

No tests were added or executed. No complete proposal acceptance, executable
freeze, native twenty-row result, production policy, ledger, item or G0-G9
approval follows. This revision is ready only for Root's full read and separate
review; sealing does not adopt it.
