"""Read-only Task34 seal planning/verification; writes are apply_patch-only."""
import datetime
import hashlib
import json
from pathlib import Path
import stat
import sys
import time

LEAF = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34')
START = time.monotonic()
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def check(p):
    for q in [p, *p.parents]:
        if q.is_symlink() or getattr(q.lstat(), 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise ValueError('reparse member/ancestor '+str(q))
def identity(p):
    check(p)
    b=p.read_bytes()
    if len(b)>=50000000 or time.monotonic()-START>180:
        raise ValueError('static evidence bound/deadline')
    return len(b), hashlib.sha256(b).hexdigest()
start=utc()
ack=json.loads((LEAF/'ROOT-READ-ACK.json').read_text(encoding='utf-8'))
for name, key in [('REPORT.md','report_sha256'),('PROPOSED-NATIVE-LOG-04.md','proposal_sha256')]:
    if identity(LEAF/name)[1]!=ack[key]:
        raise ValueError('Root-read identity changed')
mode=sys.argv[1]
manifest=LEAF/'SHA256SUMS.txt'
excluded={'SHA256SUMS.txt','SEAL-RESULT.json'}
files=[]
names=set()
for p in sorted(LEAF.rglob('*')):
    check(p)
    if not p.is_file():
        continue
    relative=p.relative_to(LEAF).as_posix()
    if ':' in relative or '\\' in relative or any(x in ('','.','..') for x in relative.split('/')) or relative.casefold() in names:
        raise ValueError('unsafe/colliding seal name')
    names.add(relative.casefold())
    if not p.resolve().is_relative_to(LEAF.resolve()):
        raise ValueError('out-of-leaf seal member')
    n,h=identity(p)
    if relative not in excluded:
        files.append({'relative':relative,'bytes':n,'sha256':h})
total=sum(x['bytes'] for x in files)
if total>=100000000:
    raise ValueError('leaf evidence budget')
out={'argv':sys.orig_argv,'cwd':str(Path.cwd()),'utc_start':start,'static_ceiling_seconds':180,
     'covered_files':len(files),'covered_bytes':total,'excluded_actual_regular':[p.relative_to(LEAF).as_posix() for p in LEAF.rglob('*') if p.is_file() and p.relative_to(LEAF).as_posix() in excluded]}
lines=''.join(x['sha256']+'  '+x['relative']+'\n' for x in files)
if mode=='plan':
    if manifest.exists() or (LEAF/'SEAL-RESULT.json').exists():
        raise ValueError('pre-existing one-time seal/result')
    out['manifest_content']=lines
    out['expected_manifest_bytes']=len(lines.encode('ascii'))
    out['expected_manifest_sha256']=hashlib.sha256(lines.encode('ascii')).hexdigest()
elif mode=='verify':
    if manifest.read_bytes()!=lines.encode('ascii'):
        raise ValueError('manifest bytes/member hashes mismatch')
    out['manifest_bytes'],out['manifest_sha256']=identity(manifest)
    out['all_covered_members_match']=True
else:
    raise ValueError(mode)
out['utc_end']=utc()
out['elapsed_seconds']=time.monotonic()-START
out['exit_code']=0
print(json.dumps(out,ensure_ascii=True))
