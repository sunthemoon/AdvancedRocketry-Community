"""Task44 bounded own-process API probe; not a decoder or production/test module."""

import ctypes
from ctypes import wintypes
import datetime
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import sysconfig
import time
import tracemalloc


FIELDS = (
    ("cb", wintypes.DWORD),
    ("PageFaultCount", wintypes.DWORD),
    ("PeakWorkingSetSize", ctypes.c_size_t),
    ("WorkingSetSize", ctypes.c_size_t),
    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
    ("QuotaPagedPoolUsage", ctypes.c_size_t),
    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
    ("PagefileUsage", ctypes.c_size_t),
    ("PeakPagefileUsage", ctypes.c_size_t),
)


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = FIELDS


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def emit(record):
    encoded = json.dumps(record, ensure_ascii=True, separators=(",", ":"))
    if len(encoded) > 32768:
        raise RuntimeError("Fixed probe record exceeds its output bound.")
    print(encoded, flush=True)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("baseline", "touch"):
        raise RuntimeError("Invalid fixed probe mode.")
    if os.name != "nt" or sys.platform != "win32":
        raise RuntimeError("Windows binding unavailable on this platform.")
    if not tracemalloc.is_tracing():
        raise RuntimeError("Startup tracing was not enabled by the actual argv.")
    mode = sys.argv[1]
    windows = sys.getwindowsversion()
    executable = Path(sys.executable)
    with executable.open("rb") as stream:
        executable_sha256 = hashlib.file_digest(stream, "sha256").hexdigest()
    emit({
        "kind": "IDENTITY", "mode": mode, "utc": utc(),
        "pid": os.getpid(), "executable": str(executable),
        "executable_sha256": executable_sha256,
        "version": sys.version, "implementation": sys.implementation.name,
        "platform": sys.platform, "os_name": os.name,
        "python_platform": sysconfig.get_platform(),
        "windows_version": list(windows),
        "windows_platform_version": windows.platform_version,
        "pointer_bytes": ctypes.sizeof(ctypes.c_void_p),
        "argv": sys.argv, "cwd": os.getcwd(),
        "dont_write_bytecode": sys.dont_write_bytecode,
        "tracemalloc_frames": tracemalloc.get_traceback_limit(),
        "scope": "Own process only; no subprocesses or configuration changes.",
    })
    kernel32 = ctypes.WinDLL("kernel32.dll", use_last_error=True)
    psapi = ctypes.WinDLL("psapi.dll", use_last_error=True)
    get_current_process = kernel32.GetCurrentProcess
    get_current_process.argtypes = []
    get_current_process.restype = wintypes.HANDLE
    functions = (
        ("kernel32.K32GetProcessMemoryInfo", kernel32.K32GetProcessMemoryInfo),
        ("psapi.GetProcessMemoryInfo", psapi.GetProcessMemoryInfo),
    )
    for _, function in functions:
        function.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(ProcessMemoryCounters), wintypes.DWORD
        ]
        function.restype = wintypes.BOOL
    pointer_size = ctypes.sizeof(ctypes.c_void_p)
    expected_offsets = [0, 4] + [8 + i * pointer_size for i in range(8)]
    actual_offsets = [getattr(ProcessMemoryCounters, name).offset for name, _ in FIELDS]
    abi_checks = {
        "DWORD_is_4": ctypes.sizeof(wintypes.DWORD) == 4,
        "BOOL_is_4": ctypes.sizeof(wintypes.BOOL) == 4,
        "HANDLE_is_pointer": ctypes.sizeof(wintypes.HANDLE) == pointer_size,
        "SIZE_T_is_pointer": ctypes.sizeof(ctypes.c_size_t) == pointer_size,
        "field_offsets_match_declared_layout": actual_offsets == expected_offsets,
        "structure_size_matches_layout": ctypes.sizeof(ProcessMemoryCounters) == 8 + 8 * pointer_size,
    }
    handle = get_current_process()
    emit({
        "kind": "BINDING", "utc": utc(), "abi_checks": abi_checks,
        "structure_bytes": ctypes.sizeof(ProcessMemoryCounters),
        "structure_alignment": ctypes.alignment(ProcessMemoryCounters),
        "fields": [{"name": name, "width": ctypes.sizeof(kind),
                    "offset": getattr(ProcessMemoryCounters, name).offset}
                   for name, kind in FIELDS],
        "DWORD_bytes": ctypes.sizeof(wintypes.DWORD),
        "BOOL_bytes": ctypes.sizeof(wintypes.BOOL),
        "HANDLE_bytes": ctypes.sizeof(wintypes.HANDLE),
        "SIZE_T_bytes": ctypes.sizeof(ctypes.c_size_t),
        "pseudo_handle_unsigned": handle,
        "handle_owner": "GetCurrentProcess pseudo handle; never opened, duplicated or closed.",
        "available_symbols": [name for name, _ in functions],
    })
    if not all(abi_checks.values()) or handle is None:
        raise RuntimeError("ABI or own pseudo-handle qualification failed.")

    def query(label, function_name, function, cb=None):
        counters = ProcessMemoryCounters()
        counters.cb = ctypes.sizeof(counters)
        argument_cb = ctypes.sizeof(counters) if cb is None else cb
        traced_current, traced_peak = tracemalloc.get_traced_memory()
        before_utc = utc()
        before_ns = time.monotonic_ns()
        ctypes.set_last_error(0)
        result = function(handle, ctypes.byref(counters), argument_cb)
        # Read the ctypes thread-private saved error before any further API call.
        error = ctypes.get_last_error()
        after_ns = time.monotonic_ns()
        after_utc = utc()
        record = {
            "kind": "COUNTER_QUERY", "label": label, "function": function_name,
            "utc_before": before_utc, "utc_after": after_utc,
            "monotonic_before_ns": before_ns, "monotonic_after_ns": after_ns,
            "argument_cb": argument_cb, "return_BOOL": result,
            "saved_last_error": error, "success": bool(result),
            "traced_current_bytes_before": traced_current,
            "traced_peak_bytes_before": traced_peak,
        }
        if result:
            record["counters"] = {name: getattr(counters, name) for name, _ in FIELDS}
        else:
            record["counter_values_interpreted"] = False
            failure = ctypes.WinError(error)
            record["failure_type"] = type(failure).__name__
            record["failure_winerror"] = failure.winerror
        emit(record)
        if not result and cb is None:
            raise ctypes.WinError(error)
        return record

    for name, function in functions:
        query("baseline", name, function)
    if mode == "baseline":
        # Valid own handle and valid output buffer, deliberately invalid byte count.
        # This observes return/error handling only, not a resource or decoder test.
        for name, function in functions:
            query("deliberate_cb_zero", name, function, cb=0)
        for name, function in functions:
            query("valid_after_error_probe", name, function)
    else:
        allocation_start_ns = time.monotonic_ns()
        buffer = bytearray(16 * 1024 * 1024)
        for index in range(0, len(buffer), 4096):
            buffer[index] = 1
        buffer[-1] = 1
        emit({
            "kind": "BOUNDED_BUFFER", "bytes": len(buffer),
            "touch_stride_bytes": 4096, "last_byte_touched": True,
            "retained_buffers": 1, "allocation_start_ns": allocation_start_ns,
            "touch_end_ns": time.monotonic_ns(),
            "scope": "Counter probe only; no synthetic JSON or native trace.",
        })
        for name, function in functions:
            query("buffer_live", name, function)
        del buffer
        gc.collect()
        emit({"kind": "BUFFER_RELEASED", "monotonic_ns": time.monotonic_ns(),
              "retained_buffers": 0, "allocator_return_to_OS_not_asserted": True})
        for name, function in functions:
            query("after_buffer_release", name, function)
    current, peak = tracemalloc.get_traced_memory()
    emit({
        "kind": "PROBE_END", "utc": utc(), "monotonic_ns": time.monotonic_ns(),
        "traced_current_bytes": current, "traced_peak_bytes": peak,
        "tracemalloc_metadata_bytes": tracemalloc.get_tracemalloc_memory(),
        "scope": "Finite API availability/ABI/self-counter probe, not decoder qualification.",
    })


if __name__ == "__main__":
    main()
