$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$manifestPath = Join-Path $leaf 'SHA256SUMS.txt'
$resultPath = Join-Path $leaf 'SEAL-RESULT.json'
if ((Test-Path -LiteralPath $manifestPath) -or (Test-Path -LiteralPath $resultPath)) {
    throw 'Refusing to reseal this evidence leaf.'
}
$reportPath = Join-Path $leaf 'REPORT.md'
$ackPath = Join-Path $leaf 'ROOT-FULL-READ-ACK.md'
$expectedReportHash = 'c86b95c534cfb14981c57714e8957501c60573b797bc9b017cd5d2752092fedb'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $reportPath).Hash.ToLowerInvariant() -ne $expectedReportHash) {
    throw 'Report identity changed.'
}
if (-not (Test-Path -LiteralPath $ackPath)) { throw 'Root complete-read acknowledgement is absent.' }
$ack = Get-Content -Raw -LiteralPath $ackPath
if (-not $ack.Contains($expectedReportHash)) { throw 'Acknowledgement does not bind the report hash.' }
$exclusions = @('SHA256SUMS.txt', 'SEAL-RESULT.json',
    'custody-seal-28.command.json', 'custody-seal-28.stdout.txt', 'custody-seal-28.stderr.txt')
$leafItem = Get-Item -LiteralPath $leaf
if ($leafItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Leaf is a reparse point.' }
$all = @(Get-ChildItem -LiteralPath $leaf)
$names = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$covered = @()
foreach ($file in ($all | Sort-Object Name)) {
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Only regular direct evidence files may be sealed.'
    }
    if (-not $names.Add($file.Name)) { throw 'Case-colliding member name.' }
    if ($exclusions -contains $file.Name) { continue }
    $covered += $file
}
$coveredBytes = ($covered | Measure-Object Length -Sum).Sum
if ($coveredBytes -gt 4194304) { throw 'Covered evidence exceeds the unchanged leaf budget.' }
$rows = @()
foreach ($file in $covered) {
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash.ToLowerInvariant()
    $rows += "$hash  $($file.Name)"
}
$encoding = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText($manifestPath, ($rows -join "`n") + "`n", $encoding)
foreach ($row in $rows) {
    $hash = $row.Substring(0, 64)
    $name = $row.Substring(66)
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $leaf $name)).Hash.ToLowerInvariant() -ne $hash) {
        throw 'Covered evidence changed while sealing; failure must be retained.'
    }
}
$result = [ordered]@{
    completed_utc = [DateTime]::UtcNow.ToString('o'); outcome = 'SEALED_CUSTODY_ONLY'
    report_sha256 = $expectedReportHash; report_bytes = (Get-Item -LiteralPath $reportPath).Length
    root_ack_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $ackPath).Hash.ToLowerInvariant()
    covered_files = $covered.Count; covered_bytes = $coveredBytes
    manifest_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $manifestPath).Hash.ToLowerInvariant()
    exact_exclusions = $exclusions
    note = 'Seal command raw stdout/stderr/actual-exit receipt are produced by the parent after this child exits and explicitly excluded; no decoder or Gate qualification.'
}
[IO.File]::WriteAllText($resultPath, ($result | ConvertTo-Json -Depth 6) + "`n", $encoding)
$result | ConvertTo-Json -Depth 6
