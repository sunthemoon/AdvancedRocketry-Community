$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$indexPath = Join-Path $leaf 'COMMAND-INDEX.json'
$inputsPath = Join-Path $leaf 'INPUT-IDENTITIES.json'
$auditPath = Join-Path $leaf 'AUDIT-RESULT.json'
foreach ($path in @($indexPath, $inputsPath, $auditPath)) {
    if (Test-Path -LiteralPath $path) { throw "Refusing overwrite: $path" }
}
$receipts = @(Get-ChildItem -LiteralPath $leaf -File -Filter '*.command.json' | Sort-Object Name)
$index = @()
foreach ($file in $receipts) {
    $receipt = Get-Content -Raw -LiteralPath $file.FullName | ConvertFrom-Json
    $name = $file.Name.Substring(0, $file.Name.Length - '.command.json'.Length)
    foreach ($streamName in @('stdout', 'stderr')) {
        $path = Join-Path $leaf "$name.$streamName.txt"
        $stream = $receipt.$streamName
        $actualFile = Get-Item -LiteralPath $path
        $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
        if ($actualFile.Length -ne $stream.raw_bytes -or
            $actualHash -ne $stream.raw_sha256 -or $stream.overflow -or
            $stream.raw_bytes -gt 262144) { throw "Raw receipt mismatch: $path" }
    }
    if ($receipt.exit_code -ne 0 -or $receipt.timeout -or $receipt.ceiling_seconds -ne 180) {
        throw "Unexpected captured command failure: $name"
    }
    $index += [ordered]@{ name = $name; argv = $receipt.argv; cwd = $receipt.cwd
        started_utc = $receipt.started_utc; ended_utc = $receipt.ended_utc
        exit_code = $receipt.exit_code; stdout_bytes = $receipt.stdout.raw_bytes
        stdout_sha256 = $receipt.stdout.raw_sha256; stderr_bytes = $receipt.stderr.raw_bytes
        stderr_sha256 = $receipt.stderr.raw_sha256 }
}
$counterReceipts = @($index | Where-Object { $_.name -like 'counter-*' })
if ($counterReceipts.Count -ne 3) { throw 'Fresh counter-probe count is not exactly three.' }
$inputs = @()
foreach ($pair in @(
    @('assignment44', 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-PLATFORM-COUNTER-TASK-44.md'),
    @('clarification46', 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-COUNTER-TIMEOUT-CLARIFICATION-46.md'),
    @('actual-version', 'D:/GitHub/AdvancedRocketry-Community/docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md'),
    @('proposal37', 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md'),
    @('independent40', 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-json-core-independent-20261009-40/REPORT.md'),
    @('python-executable', 'D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe'),
    @('actual-user-agents', 'D:/GitHub/AdvancedRocketry-Community/AGENTS.md'),
    @('own-counter-helper', (Join-Path $leaf 'counter_probe.py')),
    @('own-prequery-helper', (Join-Path $leaf 'prequery_probe.py')),
    @('own-capture-helper', (Join-Path $leaf 'capture.ps1'))
)) {
    $file = Get-Item -LiteralPath $pair[1]
    $inputs += [ordered]@{ name = $pair[0]; path = $file.FullName; bytes = $file.Length
        sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash.ToLowerInvariant() }
}
$encoding = [System.Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText($indexPath, ($index | ConvertTo-Json -Depth 8) + "`n", $encoding)
[IO.File]::WriteAllText($inputsPath, ($inputs | ConvertTo-Json -Depth 8) + "`n", $encoding)
$files = @(Get-ChildItem -LiteralPath $leaf -File)
foreach ($file in $files) {
    if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Own evidence file is a reparse point.' }
}
$bytes = ($files | Measure-Object -Property Length -Sum).Sum
if ($bytes -gt 4194304) { throw 'Own leaf exceeds 4 MiB.' }
$result = [ordered]@{ completed_utc = [DateTime]::UtcNow.ToString('o')
    prior_captured_commands = $index.Count; actual_counter_children = $counterReceipts.Count
    raw_hashes_lengths_caps_match = $true; captured_failures = 0
    limitations_not_erased = 'Preparation gaps and lossy actual-version-11 are documented, not validated as correct content.'
    own_checkpoint_files = $files.Count; own_checkpoint_bytes = $bytes
    own_leaf_cap_bytes = 4194304; note = 'Report, audit command streams/receipt and later acknowledgement/seal are not yet in this checkpoint.' }
[IO.File]::WriteAllText($auditPath, ($result | ConvertTo-Json -Depth 6) + "`n", $encoding)
$result | ConvertTo-Json -Depth 6
