"""Task44 final bounded counter probe: one buffer episode before first query."""

import ctypes
from ctypes import wintypes
import gc
import hashlib
from pathlib import Path
import sys
import sysconfig
import time
import tracemalloc

from counter_probe import FIELDS, ProcessMemoryCounters, emit, utc


def main():
    if sys.platform != "win32" or not tracemalloc.is_tracing():
        raise RuntimeError("Required Windows/startup-tracing environment unavailable.")
    with Path(sys.executable).open("rb") as stream:
        executable_sha256 = hashlib.file_digest(stream, "sha256").hexdigest()
    emit({"kind": "IDENTITY", "executable": sys.executable,
          "executable_sha256": executable_sha256, "version": sys.version,
          "python_platform": sysconfig.get_platform(), "utc": utc(),
          "mode": "one_buffer_before_first_counter_query"})
    start_ns = time.monotonic_ns()
    buffer = bytearray(16 * 1024 * 1024)
    for index in range(0, len(buffer), 4096):
        buffer[index] = 1
    buffer[-1] = 1
    live_current, live_peak = tracemalloc.get_traced_memory()
    touch_end_ns = time.monotonic_ns()
    del buffer
    gc.collect()
    release_end_ns = time.monotonic_ns()
    emit({"kind": "BOUNDED_PREQUERY_EPISODE", "buffer_bytes": 16777216,
          "retained_buffers_after_release": 0, "touch_stride_bytes": 4096,
          "last_byte_touched": True, "allocation_start_ns": start_ns,
          "touch_end_ns": touch_end_ns, "release_end_ns": release_end_ns,
          "traced_live_current_bytes": live_current, "traced_live_peak_bytes": live_peak,
          "counter_queries_before_release": 0,
          "scope": "Counter probe only; no decoder, JSON payload or native trace."})
    kernel32 = ctypes.WinDLL("kernel32.dll", use_last_error=True)
    get_current = kernel32.GetCurrentProcess
    get_current.argtypes = []
    get_current.restype = wintypes.HANDLE
    handle = get_current()
    query = kernel32.K32GetProcessMemoryInfo
    query.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemoryCounters), wintypes.DWORD]
    query.restype = wintypes.BOOL
    counters = ProcessMemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    before_utc = utc()
    before_ns = time.monotonic_ns()
    ctypes.set_last_error(0)
    returned = query(handle, ctypes.byref(counters), ctypes.sizeof(counters))
    error = ctypes.get_last_error()
    after_ns = time.monotonic_ns()
    after_utc = utc()
    record = {"kind": "FIRST_COUNTER_QUERY_AFTER_RELEASE", "return_BOOL": returned,
              "saved_last_error": error, "utc_before": before_utc, "utc_after": after_utc,
              "monotonic_before_ns": before_ns, "monotonic_after_ns": after_ns,
              "argument_cb": ctypes.sizeof(counters), "success": bool(returned)}
    if returned:
        record["counters"] = {name: getattr(counters, name) for name, _ in FIELDS}
    else:
        record["counter_values_interpreted"] = False
    emit(record)
    if not returned:
        raise ctypes.WinError(error)
    current, peak = tracemalloc.get_traced_memory()
    emit({"kind": "PROBE_END", "utc": utc(), "traced_current_bytes": current,
          "traced_peak_bytes": peak, "tracemalloc_metadata_bytes": tracemalloc.get_tracemalloc_memory(),
          "no_predicted_delta_assertion": True, "scope": "Counter availability/history, not resource-case acceptance."})


if __name__ == "__main__":
    main()
