param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$Executable,
    [Parameter(Mandatory)][string[]]$Arguments,
    [Parameter(Mandatory)][string]$WorkingDirectory
)
$ErrorActionPreference = 'Stop'
$leaf = $PSScriptRoot
$limit = 262144
$ceiling = 180
$outPath = Join-Path $leaf "$Name.stdout.txt"
$errPath = Join-Path $leaf "$Name.stderr.txt"
$receiptPath = Join-Path $leaf "$Name.command.json"
foreach ($path in @($outPath, $errPath, $receiptPath)) {
    if (Test-Path -LiteralPath $path) { throw "Refusing overwrite: $path" }
}
$psi = [System.Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $Executable
$psi.WorkingDirectory = $WorkingDirectory
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
foreach ($argument in $Arguments) { $psi.ArgumentList.Add($argument) }
$process = [System.Diagnostics.Process]::new()
$process.StartInfo = $psi
$startedUtc = [DateTime]::UtcNow.ToString('o')
$watch = [System.Diagnostics.Stopwatch]::StartNew()
$started = $process.Start()
if (-not $started) { throw 'Child start returned false.' }
$childPid = $process.Id
$states = @()
foreach ($pair in @(
    @('stdout', $process.StandardOutput.BaseStream, $outPath),
    @('stderr', $process.StandardError.BaseStream, $errPath)
)) {
    $buffer = [byte[]]::new(4096)
    $states += [PSCustomObject]@{
        name = $pair[0]; stream = $pair[1]; path = $pair[2]
        buffer = $buffer; pending = $pair[1].ReadAsync($buffer, 0, $buffer.Length)
        eof = $false; bytes = [long]0; stored = [System.IO.MemoryStream]::new()
        hash = [System.Security.Cryptography.SHA256]::Create()
    }
}
$timedOut = $false
while (-not ($process.HasExited -and $states[0].eof -and $states[1].eof)) {
    foreach ($state in $states) {
        if (-not $state.eof -and $state.pending.IsCompleted) {
            $count = $state.pending.GetAwaiter().GetResult()
            if ($count -eq 0) { $state.eof = $true; continue }
            $state.bytes += $count
            [void]$state.hash.TransformBlock($state.buffer, 0, $count, $null, 0)
            $retain = [Math]::Min($count, [Math]::Max(0, $limit - $state.stored.Length))
            if ($retain -gt 0) { $state.stored.Write($state.buffer, 0, $retain) }
            $state.pending = $state.stream.ReadAsync($state.buffer, 0, $state.buffer.Length)
        }
    }
    if (-not $timedOut -and -not $process.HasExited -and $watch.Elapsed.TotalSeconds -ge $ceiling) {
        $timedOut = $true
        $process.Kill()
    }
    Start-Sleep -Milliseconds 5
}
$process.WaitForExit()
$endedUtc = [DateTime]::UtcNow.ToString('o')
$watch.Stop()
$summaries = @{}
foreach ($state in $states) {
    [void]$state.hash.TransformFinalBlock([byte[]]::new(0), 0, 0)
    $bytes = $state.stored.ToArray()
    [System.IO.File]::WriteAllBytes($state.path, $bytes)
    $summaries[$state.name] = [ordered]@{
        raw_bytes = $state.bytes; retained_bytes = $bytes.Length
        raw_sha256 = [Convert]::ToHexString($state.hash.Hash).ToLowerInvariant()
        retained_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $state.path).Hash.ToLowerInvariant()
        overflow = ($state.bytes -gt $limit)
    }
    $state.hash.Dispose(); $state.stored.Dispose()
}
$receipt = [ordered]@{
    argv = @($Executable) + $Arguments; cwd = $WorkingDirectory
    started_utc = $startedUtc; ended_utc = $endedUtc
    immediate_child_pid = $childPid; exit_code = $process.ExitCode
    elapsed_seconds = $watch.Elapsed.TotalSeconds
    ceiling_seconds = $ceiling; timeout = $timedOut
    timeout_mechanism = 'Parent .NET Process.Kill() only on its known immediate child at actual >=180 seconds; no tree option.'
    stream_cap_bytes = $limit; stdout = $summaries.stdout; stderr = $summaries.stderr
    parent = 'PowerShell 7.6.6, .NET Process, asynchronous raw-byte reads; no environment overrides.'
}
[System.IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 8) + "`n", [System.Text.UTF8Encoding]::new($false))
$process.Dispose()
$receipt | ConvertTo-Json -Depth 8
