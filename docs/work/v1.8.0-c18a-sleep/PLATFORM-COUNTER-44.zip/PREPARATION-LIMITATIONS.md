# Preparation limitations

Before creation of this evidence leaf, tool calls checked the assignment hash,
the project status, branch, HEAD, worktree list, applicable AGENTS paths, sibling
evidence names, Python command locations, and assignment-leaf absence. Tool
transcript records exist, but no local raw stream, byte hash, or independently
recorded UTC receipt was captured for those historical calls. They are not
retroactively represented as raw-capture-compliant commands.

The initial overbroad `rg --files` and sibling-directory listing yielded truncated
tool output. This was a preparation listing, not a required content read. It was
not rerun. The actual project AGENTS file was subsequently read in full through a
separate bounded tool response. `Get-Command python,py` found the python shim but
no py command; a later command ended with exit 1 because that lookup omitted a
missing command. The limitation is retained rather than reported as a success.

The project HEAD was b0b818261621d6c607386925535a62f027dfbf8b on
codex/v1.8.0-classic-content. The tracked working-tree difference was M AGENTS.md;
the first status also displayed pre-existing untracked archives and documentation.
All project changes remain untouched. The worktree count was 87. Collaboration
inspection showed Root, the independent Task44 worker, author37/43 and completed
reviewer40. Root owns OpenPet progress updates. No worker delegation occurred.

Ancestor AGENTS probes found only the project's AGENTS.md; no AGENTS file existed
at D:/, D:/GitHub, D:/GitHub/ARCE-Task-Evidence, or its v1.8.0 evidence parent.
The assigned leaf was absent immediately before its creation.

Fixed governance content reads made before receipt setup (PROJECT-CONFIG,
PRODUCT, and porting principles) were complete tool responses, not historical
raw receipts. Separately named receipt-bearing reads follow for all required
fixed content, with no inference from the truncated preparation listing.

Task44 timeout clarification46 was read in full and its stated hash verified:
7e8aaa1a251b71654d479c1d97cfa00580c114d2860d87678358e36aca6da23c.
It prospectively allows the receipt parent to stop only its own known immediate
child on the fixed 180-second timeout. No foreign process or tree authority is
inferred. No timeout-triggered termination has yet occurred.
