# Task44 independent Windows self-process peak counter assessment

Date: 2026-10-09 UTC. Delegated independent worker, not Root or author37/43.
Evidence-only task; no project implementation, contract adoption or Gate authority.

## Findings first and qualification boundary

**Q01: The declared standard-library ctypes binding is qualified locally for the
Windows API-reported own-process peak working set, in bytes, up to each successful
query in the three named CPython 3.13.15 Windows AMD64 children.** Both exports
were available; actual widths/layout matched the documented declaration; valid
self queries returned nonzero; the bounded invalid-size probe returned zero and
preserved its immediate saved error without interpreting failed output.

The process-lifetime-so-far interpretation is an inference from the documented
process peak and its mapping to the process Working Set Peak counter, supported
by retained history after release and a first query made only after a released
buffer episode. It is not the maximum of this worker's sampled current values.
The API pages call the field a process peak but do not explicitly spell out its
creation-time origin or give an independently testable reset contract. This
report therefore qualifies the named **native process-peak measurement**, not an
independent proof of every internal OS accounting transition since process birth.

**U01: Strict birth-to-exit lifetime coverage remains UNQUALIFIED.** A self query
cannot include later allocations during record serialization, interpreter shutdown
or process exit. A later resource assignment must explicitly disposition this
boundary, sample after all case generation/decode/results are live, and retain
the final query interval. It must not relabel that reading as an observed terminal
process-lifetime maximum. No post-exit/foreign-PID measurement is authorized here.

**U02: Decoder resource acceptance, other platform/interpreter bindings, complete
RSS accounting and hard allocator/quota enforcement remain UNQUALIFIED.** These
finite counter probes did not implement or run a decoder, synthetic JSON payload,
source-aware parser, native fixture, full driver or resource-case cohort. No
product defect, exception waiver, R-021 acceptance or G0-G9 approval is claimed.

## Official API and measurement meanings

The base PROCESS_MEMORY_COUNTERS declaration orders two DWORD fields followed by
eight SIZE_T fields. Its peak/current working-set members are byte counts; its
PagefileUsage is commit charge, and PeakPagefileUsage is the lifetime commit peak.
Neither commit field is substituted for working-set peak.
[PROCESS_MEMORY_COUNTERS, syntax and members](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters).

GetProcessMemoryInfo takes HANDLE, a pointer to the counters structure, and a
DWORD byte size; it returns BOOL, nonzero on success and zero on failure. Modern
Windows exposes K32GetProcessMemoryInfo in kernel32; psapi's older named export
is a wrapper. Current-Windows query or limited-query access is required.
[GetProcessMemoryInfo, parameters/returns/remarks](https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getprocessmemoryinfo).

The official performance mapping associates PeakWorkingSetSize with Working Set
Peak, rather than Working Set or commit; the linked process-object definition
describes that counter as the maximum working-set size for the process. These
sources support the accumulated-peak interpretation above, not a resettable
operation-specific interval or a terminal measurement made after exit.
[API performance mapping](https://learn.microsoft.com/en-us/previous-versions/windows/desktop/legacy/aa965225(v=vs.85)),
[linked Process Object: Working Set Peak](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2003/cc780836(v=ws.10)).

A Windows working set covers resident pageable pages, including applicable shared
pages; nonpageable AWE/large-page allocations are excluded. It is not all virtual
address space, private commit, all process-owned physical memory or every native
allocation. Residency can change independently of Python object lifetimes.
[Working Set](https://learn.microsoft.com/en-us/windows/win32/memory/working-set).

tracemalloc reports current/peak traced memory blocks, not working set. Startup
tracing can be enabled with -X tracemalloc=1; tracing has metadata overhead and
does not establish that untraced native allocations are counted. No peak reset or
trace clearing was performed. The probes separately report tracer metadata.
[Python 3.13 tracemalloc API](https://docs.python.org/3.13/library/tracemalloc.html#tracemalloc.get_traced_memory).

## Actual declaration, ABI and error handling

The evidence helper's ProcessMemoryCounters is a ctypes.Structure with no _pack_
override. Its actual field layout was:

| Field | ctypes type | Width /offset, bytes |
|---|---|---:|
| cb | wintypes.DWORD | 4 /0 |
| PageFaultCount | wintypes.DWORD | 4 /4 |
| PeakWorkingSetSize | c_size_t | 8 /8 |
| WorkingSetSize | c_size_t | 8 /16 |
| QuotaPeakPagedPoolUsage | c_size_t | 8 /24 |
| QuotaPagedPoolUsage | c_size_t | 8 /32 |
| QuotaPeakNonPagedPoolUsage | c_size_t | 8 /40 |
| QuotaNonPagedPoolUsage | c_size_t | 8 /48 |
| PagefileUsage | c_size_t | 8 /56 |
| PeakPagefileUsage | c_size_t | 8 /64 |

Total size was 72 bytes, alignment 8. DWORD and BOOL were 4 bytes; HANDLE,
void-pointer and SIZE_T were 8. The native declarations use 32-bit unsigned DWORD,
int BOOL, opaque pointer HANDLE and pointer-width SIZE_T, not a one-byte c_bool or
fixed 32-bit memory-count field.
[Windows data types](https://learn.microsoft.com/en-us/windows/win32/winprog/windows-data-types).

Both DLLs were loaded with ctypes.WinDLL(..., use_last_error=True). The own-handle
getter had argtypes=[] and restype=wintypes.HANDLE. Each memory getter had
argtypes=[wintypes.HANDLE, POINTER(ProcessMemoryCounters), wintypes.DWORD] and
restype=wintypes.BOOL. Both cb member and valid cb argument used sizeof(counters).
The output object remained alive through the call and was passed by reference.
Default Structure alignment and explicit signatures avoid implicit int-return
handle truncation. These are the actual declarations, not generated test code.
[Python 3.13 ctypes types/signatures/alignment/error-copy handling](https://docs.python.org/3.13/library/ctypes.html).

The helper clears ctypes' saved error before each query, then retrieves its saved
last error immediately after the BOOL return, before further API calls. Success
is decided by BOOL alone; a success need not imply a newly cleared system error.
Failure never exposes zero-initialized output as measured counters. Unexpected
valid-call failure raises WinError and fails the probe instead of manufacturing
zero/PASS. Windows advises immediate thread-local error retrieval and does not
guarantee one fixed error number across OS versions.
[GetLastError](https://learn.microsoft.com/en-us/windows/win32/api/errhandlingapi/nf-errhandlingapi-getlasterror).

The deliberate cb=0 call still supplied a valid own handle and correctly sized
output buffer. Both exports returned BOOL 0 and saved error 122; the OSError
winerror was also 122. The failed structure was not interpreted. Later valid
calls succeeded. Error 122 is ERROR_INSUFFICIENT_BUFFER; no expected numeric error
or predicted memory delta was required to obtain these observations.
[System Error Codes, error 122](https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--0-499-).

GetCurrentProcess returned the actual unsigned pointer representation
18446744073709551615. It is a pseudo handle for the calling process, not an opened
real handle. No OpenProcess, DuplicateHandle, PID enumeration or CloseHandle was
used. A pseudo handle need not be closed; a separately duplicated real handle
would have different ownership, but none was created.
[GetCurrentProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getcurrentprocess).

## Installed identity and actual probe results

All three children used D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe,
105696 bytes, SHA256
85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd.
They reported CPython 3.13.15, tags/v3.13.15:4061bc4, MSC v.1944 64-bit AMD64;
sys.platform=win32, os.name=nt, sysconfig platform win-amd64, pointer size 8.
The first two recorded getwindowsversion=[10,0,26200,2,""] and platform_version
[10,0,26100]. That discrepancy is retained; no unverified Windows marketing name
or more precise host build identity is inferred. Python's inspected 3.13 online
docs identify 3.13.16, not the installed 3.13.15 binary; actual ABI/probes bind this
installed binary only, not a claim of identical behavior in later patches.

Exactly three fresh Python children ran, with no descendants. Actual argv used
-B -X tracemalloc=1 and the own helper path; all had the own leaf as cwd. Each
buffer probe allocated/touched/released exactly one 16777216-byte bytearray,
touching offsets at stride 4096 and the last byte. No buffer remained after its
release; only one was retained at a time, in separate fresh processes. There was
no stress/repetition loop, payload/tree/cache or unbounded sample collection.

| Own immediate child /receipt | UTC start-end, 2026-10-09 | Exit /seconds | Raw stdout /stderr bytes |
|---|---|---:|---:|
| PID 17192, counter-baseline-19 | 09:35:33.5563306-09:35:33.8793659 | 0 /0.3202782 | 5961 /0 |
| PID 26752, counter-touch-20 | 09:36:01.1877725-09:36:01.5050290 | 0 /0.314669 | 6711 /0 |
| PID 26212, counter-prequery-21 | 09:37:18.6246173-09:37:18.9249991 | 0 /0.2976076 | 1656 /0 |

Stdout SHA256 respectively:
3005aa5e5e53bb0a8289c0a881fa8ec324d0718a5dc8507062341d26abb4485b;
cc8d4e0063661d3bf8308d61e42ad44bc38f2fe1b259a28870061a5ee0faf8b9;
3f13bfaf5923902d583a312e7fdc5ad27a2d4605aecbaff00d606ee16978c712.
Every stderr was empty, SHA256
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.

Selected actual K32 byte values follow; psapi calls were sequential, not atomic
cross-counter equality tests. The complete streams retain every query, counter,
traced value, UTC and monotonic before/after interval.

| Probe stage | Peak working set | Current working set | Commit /peak commit |
|---|---:|---:|---:|
| Baseline child, initial | 24293376 | 24088576 | 14794752 /15196160 |
| Touch child, before buffer | 24133632 | 23871488 | 14577664 /15028224 |
| Touch child, buffer live | 40652800 | 40652800 | 31391744 /31412224 |
| Touch child, after release | 40652800 | 23871488 | 14577664 /31412224 |
| Prequery child, first memory query after release | 39936000 | 23203840 | 13996032 /30822400 |

Touch allocation/touch interval was monotonic 156171881321700-156171896587400 ns;
release was recorded at 156171898909400. Its final K32 query interval was
156171909519600-156171909541200 ns. The third episode ran
156249324744000-156249329314800 ns, release ended 156249331747800, and its first
memory query was 156249332049700-156249332075000. That third child made no earlier
memory-counter call, so its reported peak is not a maximum constructed from our
polling. API-load/import/tracer overhead and OS residency affect the readings;
the exact 16 MiB buffer is not asserted to imply an exact working-set delta.

Final traced peaks were 5009912, 20902738 and 20646011 bytes; tracer metadata was
1714320, 1704208 and 1687728 bytes respectively. Those different quantities were
not added to or substituted for native peak working set. These probe numbers
are not a worst-case decoder performance result or acceptance against 256 MiB.

## Prospective test-file binding, not an implementation assignment

A later separately assigned structural-resource test may place a small guarded
Windows binding directly in scripts/test_sleep_observation_json_core.py, within
its own frozen write scope. It should retain explicit field widths/signatures,
native size/alignment checks, own pseudo-handle semantics, BOOL/error handling,
counter identity and byte units; unavailable DLL/symbol/ABI/call failures remain
UNQUALIFIED. Do not silently substitute current working set, traced allocations,
commit counters, task-manager estimates or zero. No third production/helper
module, general process monitor or native resource-control framework is assigned.

The case must keep interpreter, generated input and live result within the named
final counter interval and report startup traced peak separately. It must not
subtract an idle baseline from the native peak, reset it by changing OS settings,
or poll current values and call that a lifetime peak. This task does not choose
how to resolve strict terminal-lifetime coverage; that remains a visible boundary.
The unchanged proposed traced/native peak ceilings are each 268435456 bytes;
counter availability does not prove any decoder case respects them. The proposed
finite cohort, deadline and all source/schema/runtime obligations stay unexecuted.

## Governance reads, capture boundaries and preparation failures

Fixed governance is b0b818261621d6c607386925535a62f027dfbf8b; observation source is
d57ecda1f11dab76d882f945b0de606534ef4fb9. All mandatory fixed config/product/
principles/roadmap/version/master-test/release/post-1.0/quality/parallel documents
and fixed AGENTS were fully displayed, plus the complete actual v1.8 version,
fixed checkpoint42, exact proposal37 and independent40. Proposal37 is 19096
bytes /271 lines, f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0;
review40 is 18632 /280, aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60.
Their decisions remain PROPOSED; this worker does not disposition diagnostic43.
Actual file/receipt identities are in INPUT-IDENTITIES.json and COMMAND-INDEX.json.

Assignment44 and prospective timeout clarification46 were fully read and hash
verified. Before leaf/helper creation the worker inspected status/worktrees,
applicable AGENTS and live team state. The initial broad listing truncated;
missing py lookup and historical uncaptured/raw-time gaps remain in
PREPARATION-LIMITATIONS.md. No broad-listing retry or fake historical receipt was
created. The separately captured actual-version-11 emitted lossy console bytes,
so it is not a correct content read. Distinct actual-version-12 emitted raw file
bytes, hash 902b0e65585f47c4e4beec39f365c5046346799a2e77dee276ebaa58e433b051,
and was fully read. No failed receipt was overwritten.

The own PowerShell parent used .NET Process.ArgumentList, inherited environment,
redirected raw byte streams, asynchronous bounded retention and streaming hashes.
The fixed 180-second external check stops only its known immediate child on an
actual timeout via Process.Kill(), without a tree option, as clarification46
permits. No timeout or termination occurred. The 5 ms polling interval and host
scheduling do not promise exact OS preemption at 180.000 seconds; it is not a
memory quota. Each retained stream is capped at 262144 bytes; overflow would be
explicit failure, not a complete-content claim. No actual overflow occurred.

Browser requests consulted official Windows and Python 3.13 documents only as
primary supporting sources. Search-result suggestions from unrelated Microsoft
Q&A/.NET contexts were not used as API evidence. One manually guessed PSAPI
performance-information URL returned a browser internal error; the successful
distinct API-linked page is cited above. Browser/editor/direct-read transports
have tool records, not invented subprocess raw-stream/UTC receipts or downloads.

## Actual commands, files, tests, risks and Gates

Receipts governance-01 through governance-10 are fixed git show reads;
actual-version-11/12, proposal37-13, independent40-14 and checkpoint42-15 are
separately named reads. checkpoint-paths-16 is narrow git grep;
checkpoint42-fixed-17 and gate-status-fixed-18 are fixed git show reads. The three
counter receipts are the only Python child invocations. fixed-agents-22 and
final-tracked-status-23/final-head-24/source-unchanged-25/index-paths-26 are read-only
Git checks. evidence-audit-27 validates prior actual raw lengths/hashes/caps and
three-child count. All 27 captured commands exited 0; deliberate API failures and
lossy content/preparation limitations remain distinct from command exit status.

The pre-report audit checkpoint was 85 files /232810 bytes, below 4194304. Its
own result/command receipt, this report, final acknowledgment and one-time seal
follow that checkpoint; their final volume is reported separately, not invented.
Only the assigned absent-new external leaf was written: own capture/probe/audit
helpers, this report, preparation note, indexes, raw receipts and later custody
files. Helpers were not modified after their probes; their post-probe identities
are retained, not falsely described as pre-start helper-hash attestations.

Root moved Main normally to b80fb950b3965956ff6a75f8f86b9aff32aa196d during this
task after advance notification. Remaining reads kept fixed b0b/d57 identities.
The final tracked status still showed only M AGENTS.md; its 15797-byte hash stayed
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
The final index-path read was empty; git diff --exit-code b0b HEAD -- src scripts
returned 0. This worker did not move HEAD/index, commit, push, modify the project,
take over untracked peer artifacts, clean anything or delegate. Root coordinates
OpenPet. No installs, quotas, working-set limits, affinity/privilege/environment/
service/system changes, foreign process management or game execution occurred.

Completed: required independent reads, official API assessment, installed identity,
bounded ABI/availability/return/error/history probes, own evidence and findings.
Uncompleted: strict terminal-lifetime proof, platform portability, decoder/code/
synthetic resource tests, complete parser/driver/source/native behavior, allocation
hard enforcement, diagnostics/R-021 disposition and all acceptance work.
Key decisions: explicit native byte counter and ABI; own pseudo handle only;
traced/current/peak/commit separated; late-lifetime and portability gaps visible;
all inherited caps unchanged and failures preserved.

Tests added/modified: NONE in the project. Tests executed: only these three
bounded platform-counter probes and receipt/hash checks, not decoder tests.
Gradle clean build/test/runData/generated-diff/runGameTestServer, JVM/Minecraft,
dedicated/restart/real-client/native Unicode tests were NOT_EXECUTED by this task,
not PASS or NOT_APPLICABLE. No source result is rebound to a record-only commit.

Known risks: strict exit-tail coverage; limited local interpreter/architecture;
OS-residency/shared/nonpageable interpretation; tracer/native overhead; uncaptured
preparation and lossy read limits; untested actual timeout/error-wrapper recovery;
unqualified downstream resources and all preserved diagnostic/native obligations.
Evidence: this exclusive sleep-json-platform-counter-20261009-44 leaf and its
actual individual receipts. Custody sealing does not adopt a contract or qualify
a future implementation. The report must remain stable for Root's complete
exact-hash read before the one-time seal; no acknowledgment/seal is preclaimed.

**All current and inherited Required Gates G0-G9 satisfied: NO.** v1.8 remains
IN_PROGRESS. No ledger delivery, release/tag or Gate permission follows.
Next v1.8-only work: Root disposition of the exact prospective core/diagnostic
choices and explicit resource-measurement boundary, then a separate bounded
implementation/test assignment if authorized. All native/source prerequisites
and fixed traced/process ceilings remain unchanged.
