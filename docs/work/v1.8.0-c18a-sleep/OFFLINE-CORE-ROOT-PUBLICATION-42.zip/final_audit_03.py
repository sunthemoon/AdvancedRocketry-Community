"""Reuse protected actual-receipt audit for pushed Root42 record state."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/final_audit_03.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '67be47ed4742907d12ed07e25cedca59e11b93a884f99ab88588cd64907cabe3'
source = raw.decode('utf-8')
old_head = "head = 'cd9b54a23b5bf92760b05655a427344d6b620984'"
assert source.count(old_head) == 1
source = source.replace(old_head, "head = 'b0b818261621d6c607386925535a62f027dfbf8b'")
source = source.replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                        'cd9b54a23b5bf92760b05655a427344d6b620984')
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
