# Root42: offline-core candidate and diagnostic audit publication

Root is sole Main integrator at cd9b54a23b5bf92760b05655a427344d6b620984.
Read completely actual final author37 proposal/report and independent38 report/
map before their actual seals; verify actual custody before publication. Root39
seal/report is a separate record-only publication input. Do not infer review40's
result, adoption of37, an error waiver, R-021 acceptance or source/runtime proof.

Exclusive external writes: this new leaf. Main write_scope: new
docs/work/v1.8.0-c18a-sleep/OFFLINE-CORE-AND-DIAGNOSTICS-STATUS-42.md;
new immutable OFFLINE-JSON-CORE-PROPOSAL-37.zip, NATIVE-ERROR-PROVENANCE-38.zip
and NATIVE-LOG-ROOT-DISPOSITION-39.zip in that directory; additive note in
NATIVE-LOG-DISPOSITION-39.md; CURRENT_VERSION, COMPLETION-PLAN and v1.8 log.
No source/build/API/schema/assets/provenance/ledger/Gate/risk/ADR/owner change,
old sealed file/archive overwrite or cleanup. No decoder/tests/runtime/helper/
quota/server/process/Claude authority. Review40 has fixedcd9 inputs and no
mutable Main dependency; notify before HEAD movement.

Read-only static Git/rg/hash/ZIP/manifest/Python -B inspection and exact own
stage/commit/normal push permitted, child ceiling180 seconds with actual argv/
cwd/UTC/exit/raw streams and protected identities. Verify covered payloads/
exclusions/reparse/safe unique names/CRC, actual archives/file/slice volumes and
added links. Preserve predecessor samples; compute later actual totals without
waiving failed conservative admission. Complete cached stat/diff/check and raw
UTF-8 reading before commit. Report actual failures/limits. Complete final own
report must be read/audited before one-time evidence custody seal.
