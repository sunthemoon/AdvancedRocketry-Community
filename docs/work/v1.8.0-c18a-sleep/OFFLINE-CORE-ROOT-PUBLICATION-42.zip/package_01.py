"""Reuse verified archive algorithm for three actual Root42 inputs only."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/package_01.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '7e177d58e499f9b938cf0814d357a492c409a2bef6b7b68cc148a880e4515e35'
source = raw.decode('utf-8').replace('assert len(SPECS) == 2', 'assert len(SPECS) == 3')
old_check = "assert set(paths) - set(covered) == {'SHA256SUMS.txt', 'SEAL-RESULT.json'}"
old_output = "'excluded_entries': ['SHA256SUMS.txt', 'SEAL-RESULT.json']"
assert source.count(old_check) == 1 and source.count(old_output) == 1
source = source.replace(old_check, "assert set(paths) - set(covered) == set(spec['excluded_entries'])")
source = source.replace(old_output, "'excluded_entries': spec['excluded_entries']")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
