"""Reuse pinned bounded capture runner in Root42-exclusive output context."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-d1-outcome-disposition-20261009-33/run_33.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'c61e26150fcfca530c161e701c9fef9ea57a59901fec6154a46a136638e0e356'
exec(compile(raw, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
