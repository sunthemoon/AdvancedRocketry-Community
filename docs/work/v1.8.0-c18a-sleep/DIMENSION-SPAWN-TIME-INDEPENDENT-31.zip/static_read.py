"""Hash and line-number bounded files or exact Git blobs."""
import hashlib
import pathlib
import subprocess
import sys

kind, identity, start, end = sys.argv[1:]
start, end = int(start), int(end)
if kind == "file":
    raw = pathlib.Path(identity).read_bytes()
else:
    raw = subprocess.check_output(["git", "show", identity], timeout=180)
lines = raw.decode("utf-8", errors="replace").splitlines()
print(f"INPUT {kind} {identity} bytes={len(raw)} lines={len(lines)} sha256={hashlib.sha256(raw).hexdigest()}")
for i, line in enumerate(lines, 1):
    if start <= i <= end:
        print(f"{i:04d}: {line}")
