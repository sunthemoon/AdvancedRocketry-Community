"""Small read-only identity, manifest and ZIP audits."""
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29')
ROOT = pathlib.Path(__file__).resolve().parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def manifest_check(raw, get):
    results = []
    for line in raw.decode('utf-8-sig').splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        digest, name = line.split(None, 1)
        name = name.strip().lstrip('*')
        if pathlib.PurePosixPath(name).is_absolute() or '..' in pathlib.PurePosixPath(name).parts:
            raise ValueError(name)
        body = get(name)
        results.append({'name': name, 'bytes': len(body), 'sha256': sha(body), 'matches': sha(body) == digest})
    return results

mode = sys.argv[1]
if mode == 'integrity':
    x = json.loads((AUTHOR / 'INPUT-HASHES.json').read_bytes())
    out = {'author': {}, 'archives': [], 'primary': [], 'source': [], 'governance': []}
    manifest = (AUTHOR / 'SHA256SUMS.txt').read_bytes()
    checked = manifest_check(manifest, lambda name: (AUTHOR / name).read_bytes())
    out['author'] = {'manifest_sha256': sha(manifest), 'files': checked,
                     'uncovered': sorted(p.name for p in AUTHOR.iterdir() if p.is_file() and p.name not in {r['name'] for r in checked}),
                     'seal_receipt': json.loads((AUTHOR / 'SEAL-RECEIPT.json').read_bytes()),
                     'seal_receipt_sha256': sha((AUTHOR / 'SEAL-RECEIPT.json').read_bytes())}
    for v in x['archives']:
        p = pathlib.Path(v['path'])
        raw = p.read_bytes()
        with zipfile.ZipFile(p) as z:
            names = z.namelist()
            manifest_name = next(n for n in names if n.endswith('SHA256SUMS.txt'))
            items = manifest_check(z.read(manifest_name), z.read)
            out['archives'].append({'path': str(p), 'sha256': sha(raw), 'matches_author_index': sha(raw) == v['sha256'],
                                    'entries': len(names), 'covered': len(items), 'covered_bytes': sum(i['bytes'] for i in items),
                                    'all_covered_match': all(i['matches'] for i in items), 'crc_failure': z.testzip(),
                                    'case_unique': len({n.lower() for n in names}) == len(names),
                                    'safe_names': all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names),
                                    'manifest_sha256': sha(z.read(manifest_name))})
    for v in x['primary_files']:
        raw = pathlib.Path(v['path']).read_bytes()
        out['primary'].append({'path': v['path'], 'bytes': len(raw), 'sha256': sha(raw), 'matches': sha(raw) == v['sha256']})
    for kind in ['source', 'governance']:
        commit = 'd57ecda1f11dab76d882f945b0de606534ef4fb9' if kind == 'source' else '7cf661e7861971a61ac26d786ae0ae1e33ff2af6'
        for v in x[kind]:
            raw = subprocess.check_output(['git', '-C', v['checkout'], 'show', commit + ':' + v['path']], timeout=180)
            out[kind].append({'commit': commit, 'path': v['path'], 'bytes': len(raw), 'sha256': sha(raw),
                              'matches_author_previous_commit': sha(raw) == v['sha256']})
    (ROOT / 'INPUT-IDENTITY-AUDIT.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'author_manifest_sha256':out['author']['manifest_sha256'],
        'author_covered':len(checked),'author_bytes':sum(i['bytes'] for i in checked),
        'author_all_match':all(i['matches'] for i in checked),'author_uncovered':out['author']['uncovered'],
        'seal_receipt':out['author']['seal_receipt'],'seal_receipt_sha256':out['author']['seal_receipt_sha256'],
        'archives':out['archives'],'primary':out['primary'],
        'source_count':len(out['source']), 'source_all_match':all(i['matches_author_previous_commit'] for i in out['source']),
        'governance_differences':[i for i in out['governance'] if not i['matches_author_previous_commit']]}, indent=2))
elif mode == 'zip-read':
    p, name, start, end = sys.argv[2:]
    with zipfile.ZipFile(p) as z:
        raw = z.read(name)
    lines = raw.decode('utf-8-sig', errors='replace').splitlines()
    print(f'INPUT {p}!{name} bytes={len(raw)} lines={len(lines)} sha256={sha(raw)}')
    for i, line in enumerate(lines, 1):
        if int(start) <= i <= int(end):
            print(f'{i:04d}: {line}')
elif mode == 'resources':
    x = json.loads((AUTHOR / 'INPUT-HASHES.json').read_bytes())
    for v in x['source']:
        if not v['path'].endswith('.json'):
            continue
        raw = subprocess.check_output(['git', '-C', v['checkout'], 'show', v['commit'] + ':' + v['path']], timeout=180)
        body = json.loads(raw)
        print(f"INPUT {v['commit']}:{v['path']} bytes={len(raw)} sha256={sha(raw)}")
        if '/dimension_type/' in v['path']:
            for i, line in enumerate(raw.decode('utf-8').splitlines(), 1):
                print(f'{i:04d}: {line}')
        else:
            print(json.dumps({'type':body['type'], 'generator':body['generator']['type'],
                'settings':body['generator'].get('settings'), 'biome_source':body['generator'].get('biome_source')},sort_keys=True))
