# Task31: independent review of proposed D1 dimension, spawn and time contract

Date: 2026-10-09 UTC. Reviewer: fresh delegated independent reviewer,
`/root/sleep_d1_contract_review`; not Root, proposal author or implementer.

## 1. Findings first

**No new material contract defect identified in the complete narrowed D1 proposal
or its author report.** No Critical, High, Medium or Low correction is requested
for those two deliverables under the fixed inputs below. This is a static
contract review, not a finding that off-world sleep, upgrade, respawn safety,
compatibility or the full item works.

The proposal explicitly retains rather than resolves the implementation and
runtime prerequisites. Its limits are material: [P](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29/PROPOSED-D1-CONTRACT-29.md):77-114,
133-153, 202-218 and 220-253. These are **remaining obligations, not newly found
defects or waived conditions**. In particular:

- No current resource-writer/exclusion implementation is selected or qualified.
- B1 operation-cause/unknown/coexistence and R1 callback/inherited-receiver proof
  remain separate; a global off-world spawn veto is not an acceptable substitute.
- M1 real registered-bed admission and occupancy/adjacent-door air revocation,
  and M2 actual-host/live-access, Space gap/station and permission-footprint
  choices remain open. The six type IDs alone do not establish breathable sleep.
- All thirteen D1 verification rows remain unexecuted. Static native ordering does
  not establish previous-world holder replacement, actual native disk saves,
  real client behavior or installed-mod/pack compatibility.

## 2. Scoped disposition and readiness

The text is sufficient as a **reviewed D1 outcome-contract candidate**: it names
the exact six hosts, sole intended type delta, native spawn-state preservation,
local quorum/shared time ownership, owner-selected ancillary effects and bounded
proof/recovery requirements without silently selecting the unresolved mechanisms.
Root can consider an explicit D1 outcome-contract frozen disposition based on this
review. This reviewer neither freezes nor accepts it, nor grants a source or
runtime assignment. A frozen outcome contract would not make its implementation
choices or verification rows completed.

It is **not ready as a self-contained production implementation assignment**.
Before such an assignment, the integrator must identify writer/build ownership
and the permitted candidate delta; B1/R1 and M1/M2 prerequisites must receive
their separate scoped decisions and qualifications. Actual fresh/prior-world,
pack, native operation/persistence, time, client and recovery proof remains due.
No natural-only gameplay patch, direct sleeping bypass, public API, schema,
planetary-respawn policy, hatch policy, ledger delivery or Required Gate is
approved here.

## 3. Exact reviewed inputs and custody

Task: [SLEEP-D1-CONTRACT-INDEPENDENT-REVIEW-TASK-31.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-D1-CONTRACT-INDEPENDENT-REVIEW-TASK-31.md),
64 lines /3672 bytes, SHA-256
`1a779394c55829a1b6974589870acb3102d3bb0b6ead538e132f6c7082474955`.

Complete deliverables read, including later complete UTF-8 rereads:

| Input | Lines /bytes | SHA-256 |
|---|---:|---|
| P: PROPOSED-D1-CONTRACT-29.md | 256 /18826 | 523b38847658df2199bdbe7ecfc07bbcf8e8179ab4c31bfcce78c07d85aa1c4b |
| [A: author REPORT.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29/REPORT.md) | 181 /11942 | ce8bb6745d32a379bfb71d7d31488ce2c3171ec1555dbed13c2bb9ae8c258b9e |

Author seal was verified against actual files, not merely Root's notification.
`SHA256SUMS.txt` SHA-256 is
`867174864e118b89f617fb90b1f63eff5967e011fe7d513be0a0746acce7fdc8`.
All 26 covered files /220252 bytes match, with safe case-unique relative names.
Actual receipt records 2026-10-09T07:37:04.511916+00:00 to
07:37:04.530679+00:00. Manifest excludes itself and only the later
`SEAL-RECEIPT.json`; the latter's SHA-256 is
`8bf4f981960c7c5f20039f4f283d5451988e7816081df31f2fa0967075663986`.
Neither seal supplies product approval or a runtime result.

Governance was read from fixed Main Git objects at
`7cf661e7861971a61ac26d786ae0ae1e33ff2af6`, not mutable HEAD files. Complete
mandatory PROJECT-CONFIG, PRODUCT, porting principles, roadmap, v1.8 version,
master test plan, release/Gates, parallel coordination, post-1.0 roadmap and
quality-budget documents were read. The first incomplete roadmap version's
v1.0 document, CURRENT_VERSION, GATE_STATUS, ADR-060 and relevant ADR-066
environment/sleep section were also read. v1.0 acceptance remains IN_PROGRESS;
v1.8 work is under ADR-060's scoped exception, not inherited Gate completion.

Complete owner and existing sleep-status records, original full-sleep proposal,
and the fixed latest NESTED-BOUNDARY-STATUS-27, DRIVER-REVIEW-STATUS-18 and
SOURCE-REVIEW-STATUS-08 were read. Important identity anchors:

| Fixed governance input | SHA-256 |
|---|---|
| OWNER-DECISION-01.md | db19249fdd391bf45f7833052edfa323595b2c1efb45d7ee4747b91db8ab4f8c |
| OWNER-QUESTION-02.md | b12e7cb76fb580ad949f9cc093bcf0d4730d28745a7dd3abcc5631eebefa9366 |
| OWNER-DECISION-03.md | a07290d5d9c6b721419ddcc245da2dac5082ad0f0f1958b974928ccd336d795e |
| Original proposed full-sleep contract | 55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21 |
| v1.8 version document | 902b0e65585f47c4e4beec39f365c5046346799a2e77dee276ebaa58e433b051 |
| CURRENT_VERSION.md | 2e1cacece7040ae01461bd6fb9a50e6b78190fe94e2bea57ae6db4b7ed291ac1 |
| GATE_STATUS.md | 55b7140a6e59684b9de4fd1df4a122d3dc76c94d57075b3cc77332119f6fc539 |
| NESTED-BOUNDARY-STATUS-27.md | b332e427703926a06cf7c038fdb8a00d78cfe4ee14efb883d69a56b55615198e |

The author's declared governance at P:10 is the earlier
`6d1b796e0e93b9953af505dd3fd9b25d47b91d97`. Independent fixed-checkpoint diff
and current record reads establish that subsequent observation/status additions
do not grant production sleep/dimension/spawn/time/air authority or close D1,
B1/R1/M1/M2. Checkpoint27:93-99 and 141-145 explicitly retain those boundaries.
This is historical-input identification, not a request to rewrite the sealed
author proposal to claim it originally used the later checkpoint.

The exact accepted words are preserved: OWNER-DECISION-01 selects
“真正睡眠（推荐）：另行冻结并审核维度、出生点和时间行为后实施。”;
OWNER-DECISION-03 selects “接受原生维度行为，按上述范围冻结并审核。” in the
recorded question's scope. No absent submission timestamp, wider authorization
or technical mechanism is inferred.

All five original research/review ZIP identities, manifest-covered member hashes,
safe case-unique names and CRC were independently verified without extraction or
repacking. The relevant report disposition ranges were read as listed, not every
archive report or every enclosed source file:

| Archive | SHA-256 | Covered files /bytes; report lines read |
|---|---|---|
| CONTRACT-RESEARCH-01.zip | 71047c5a18ef4e2a925f6e4feefe5f18c01c27205aa8f9ec6b6d8033221e7007 | 37 /1181793; 1-90 |
| CONTRACT-INDEPENDENT-01.zip | 24df674e72e53187ed2c7b12651986d61151535beee070463e84f8ac5fe1d164 | 13 /963887; 1-220 |
| SPAWN-FEASIBILITY-02.zip | 101452b8fcef931dbae693dd4be45937ff9f58958a4ee041d1ce561a6e7bc0e8 | 83 /1144778; 1-95 |
| AIR-FEASIBILITY-02.zip | d272e2a94129279416b01c5b489c788acbd6c2d117d62715f1b3ff7323b6c39d | 15 /693057; 1-100 |
| BOUNDARY-INDEPENDENT-03.zip | 78896073d96d27e85168aa62fb9e32a99ef01685f1f5760fd72e05a595a64664 | 10 /391381; 1-160 |

## 4. Independent source and primary assessment

Source identity is fixed `d57ecda1f11dab76d882f945b0de606534ef4fb9` in the
read-only isolated worktree. The 27 author-indexed source/resource blobs were
independently hashed and matched. Reads used `git show <fixed-SHA>:<path>`.
No peer build/generated runtime output or full library/source/world was acquired.

The following separates established facts from proposed outcomes and open proof.
P line ranges refer to the complete proposal identified above; relevant fixed
source paths and selected primary methods are retained in this leaf's receipts.

| Subject and P lines | Independent result and boundary |
|---|---|
| Stable keys, flags and generators; 39-68, 72-75 | Six type JSONs and six Level JSONs agree with the table. Type/Level registry identities are distinct. All currently natural=false, bed_works=true, anchors=false; Moon/Space fixed_time=18000. Space is the shared flat Level, not one Level per station. Logical Earth maps to Overworld. Generator/biome/noise identities are preserved, not authorized for alteration. |
| Providers and packaging; 77-91 | FixedDimensionProvider's historic semantics, PlanetarySkyProvider, PlanetaryWorldgen, BootstrapDataGenerators:65-68, V180Worldgen:52-53, V180ExoplanetWorldgen:312-318 and V180PlanetDimensions confirm separate current ownership. Current v1.8 run writes Tau types but V180PlanetDimensions writes no types. build.gradle's processResources/sourcesJar both exclude older v0.3 Moon/Space types; no new v1.4-type exclusion is already established. P correctly requires precise later ownership, single writers/entries and both packaging selections rather than adopting a provider. |
| Startup/reload/upgrade; 93-114 | Pinned WorldLoader and RegistryDataLoader load dimension types/Level stems before server Level construction; reload uses frozen access. PlanetaryCatalogManager reload publishes catalog/routes and validates bindings, not existing native type holders. PrimaryLevelData writes WorldGenSettings through registry access. These observations do not determine prior-world merge or replacement; P correctly requires restarted actual holders, generator/catalog/binding and saved readback. Overriding/missing/reused types and feature-disable remain compatibility proof, not automatic support. |
| Bed/setter order; 118-141 | ServerPlayer.startSleepInBed hook precedes natural/range/obstruction checks; its bytecode 107-122 spawn setter precedes daytime/monster refusals. setRespawnPosition posts cancellable PlayerSetSpawnEvent before message and native field changes. The event contains no bed-cause/operation token. P's successful and late-failure preservation is a normative requirement, not a claim the existing handler implements it. Nested unrelated setters, null/admin/restore, other cancellation and unknown outcomes remain B1/R1 obligations; no classifier or priority is selected. |
| Persistence/death; 143-153 | ServerPlayer native save/load uses the named Spawn fields. PlayerList reads its respawn target before PlayerRespawnEvent, and BedBlock.canSetSpawn tests bedWorks rather than natural. Existing off-world records therefore retain possible native death behavior even on the old baseline. P correctly preserves those records and typed state, while making no new safe-air/access/loading or ADR-066 allow/force acceptance. Native SpawnForced is not an air permission. Actual saves/restarts/death remain unexecuted. |
| Time/quorum; 157-181 | MinecraftServer.createLevels constructs non-Overworld ServerLevels with DerivedLevelData/tickTime=false. Derived time/weather reads share primary data while derived setters are no-ops; SleepStatus is local. Native quorum excludes spectators and uses its percentage/deep-counter rules. ServerLevel tick gates time event/write on doDaylightCycle but wakes local players independently; rain/weather reset has separate native conditions. P does not forward derived completion to primary data or promise Earth morning. Fixed types have both isDay/isNight false; Forge's default sleep-time check uses !isDay. Native load stops saved sleeping pose. Runtime multiplayer and reconciliation are still required. |
| Changed-flag consumers; 185-206 | Native ordinary compass constructs GlobalPos(current Level key, getSharedSpawnPos), including native border fallback, not a bed or safe arrival. Clock uses local getTimeOfDay, which consults DimensionType fixed/cyclic time. Loaded NetherPortalBlock randomTick conditionally attempts ZOMBIFIED_PIGLIN/STRUCTURE; the delta is neither guaranteed spawning nor new travel/atmosphere policy. The four direct gameplay consumers of natural were independently corroborated; 47.4.23, installed mods, reflection/transformation and additional pack hosts are not qualified. |
| Proof/recovery; 210-253 | Thirteen finite UNEXECUTED rows cover generation/packaging, fresh/prior-world/reload, success/late/early refusal, unrelated/nested setters, old spawn records, quorum/Space/shared clocks/weather, compasses/clocks/portal and native restart/client reconciliation. Source/JAR/fixture/typed-state and failure receipts are required. Reverting natural alone is not a safe downgrade or spawn migration. P retains forced-loading, world/NBT/network/log/performance limits and separate risk/ADR scope for any repair or save/load control. |

Pinned local primaries were independently hashed, not resolved online or installed:

| Primary | Bytes | SHA-256 |
|---|---:|---|
| Forge 1.20.1-47.4.10 mapped official JAR | 19355242 | 95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e |
| Forge 47.4.10 sources JAR | 1621504 | 918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0 |
| JDK 17.0.7 javap.exe | 23696 | 69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d |

Their absolute paths are in [INPUT-IDENTITY-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-d1-contract-independent-20261009-31/INPUT-IDENTITY-AUDIT.json).
Twenty-two bounded independent javap calls returned 0; selected annotated methods,
actual argv/UTC/exit and full-output hashes are retained in the spawn/time/startup/
ancillary/supplement/time-path-correction/registry-list native records. Full class
disassemblies are not copied. Four relevant Forge event source excerpts were read
from the pinned sources ZIP. One LevelReader selection was empty and subsequently
corrected to LevelTimeAccess; the empty read is not credited as evidence.

The natural-consumer inventory scanned 7110 net/minecraft class entries,
38435385 bytes under explicit 10000-entry, 2 MiB/class and 128 MiB aggregate
ceilings. Five classes have the exact natural method reference: the four gameplay
consumers above plus DimensionType's own accessor/codec reference. Constant-pool
presence is not itself a direct call or complete mod/reflection coverage. The four
gameplay call sites were separately inspected; this is a native baseline inventory.

## 5. Actual commands, errors and verification limits

All durable read-command receipts retain exact argv, cwd, true pre/post UTC,
exit, raw captured stdout/stderr byte counts and hashes. Python audit helpers use
`-B` and 180-second subprocess limits. The read-command index is a snapshot;
later individual receipts remain authoritative. Representative actual families:

| Actual command family | Result /evidence |
|---|---|
| `git status --short`, `git branch --show-current`, `git worktree list`, fixed rev-parse | Read-only state checks; later captured Main has pre-existing modified AGENTS.md and HEAD 7cf, isolated source HEAD d57 with no tracked change. No state was acquired or changed. |
| `python -B <leaf>/static_read.py git <fixed-SHA>:<path> <start> <end>` | Complete mandatory/owner/deliverable reads or explicitly selected source/native ranges; raw input hash and numbered content retained in named stdout. |
| `python -B <leaf>/audit.py integrity` | Actual Task29 manifest, five ZIP manifests/CRC/names, 27 fixed source blobs and pinned primaries match; compact input audit retained. |
| `python -B <leaf>/audit.py zip-read <archive> REPORT.md <start> <end>` | Listed historical disposition excerpts only; no extraction/repack or full archive source copy. |
| `python -B <leaf>/native.py <group>`; pinned `javap -classpath <mapped-JAR> -p -c <class>` | Twenty-two successful static reads; method-selection correction disclosed above. Exact native commands are recorded per group. |
| Fixed-source Git grep /bounded JSON and constant-pool audit | Provider/key/handler locations and current resource projections established. No production sleep/spawn/time handler was found by the retained scoped keyword inventory; this is not universal absence proof. |
| `git diff --stat 6d1b796e... 7cf661e... -- <named governance paths>` | Exit 0; later observation/status additions independently identified; new fixed status records completely read. |

Errors and capture limitations are preserved, not relabeled as successful proof:
[PRE-HARNESS-AND-CAPTURE-LIMITS.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-d1-contract-independent-20261009-31/PRE-HARNESS-AND-CAPTURE-LIMITS.md).
Initial tool reads predate the durable helper and some displays were truncated;
material inputs were later captured independently. The start-state process has
exit 0 but a nonterminating Get-FileHash-unavailable error; Python subsequently
established the task hash. Exploratory shell-regex failures lack durable receipts;
no historical UTC or exit is invented. A later incorrect capture-helper argument
call failed before child creation; its corrected diagnostic then returned 1 for
missing old receipt filenames, with raw stderr retained. Subsequent listing/read
resolved the evidence-location question. No such command is counted as successful
qualification. UTF-8 rereads and targeted views replace missing content, not old
receipts or tool-display history.

No Gradle, compiler, test, Java application, game/server, network, installation,
runtime/quota/mount operation, process signal or cleanup ran. No delegation or
Claude was used. No project/proposal/author/sealed input was edited, and no
commit/push/worktree/index/HEAD mutation occurred. Only this exclusive external
leaf contains reviewer-created helpers, compact excerpts, hashes, receipts and
report. Root coordinates OpenPet; the reviewer emits no pet events.

The required implementation clean build, explicit test, repeated runData/diff,
runGameTestServer, dedicated packaged/prior-world save/restart, V1/V2 clients and
the D1 finite rows are **NOT EXECUTED here because Task31 prohibits them**. This
is not a Gate waiver, NOT_APPLICABLE classification or adopted result from any
other candidate. Source review and static primary evidence cannot close G0-G9.

## 6. Completion, residual risks and evidence handoff

Completed: complete narrowed proposal/report independent review; owner/governance
comparison; fixed source/resource/provider/build inspection; independent primary
ordering/ownership/consumer assessment; actual author and original archive
integrity checks; findings-first scoped report. No project files or tests changed.

Unfinished: explicit Root D1 disposition; separately assigned implementation
ownership/decisions; B1/R1/M1/M2 qualification; all D1 runtime/persistence/upgrade/
client/pack/mod/recovery proof; full sleep/API/respawn item and Required Gates.
Known risks are the unresolved obligations above, baseline-only static coverage,
old off-world native death behavior and disclosed read-capture gaps. No existing
open operational/log/storage/retention condition is waived by this review.

**Current-version all Required Gates satisfied: NO.** Neither ledger/item status,
v1.0 inherited acceptance, v1.8 development status, release/tag nor ADR approval
changes. Suggested action is confined to v1.8: Root reads this complete report,
records its scoped D1 outcome disposition if justified, and preserves independent
prerequisite/runtime assignments. No Main HEAD movement is required by this
review; all material inputs are fixed Git objects or hashed sealed/primary files.

Evidence leaf:
[sleep-d1-contract-independent-20261009-31](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-d1-contract-independent-20261009-31/).
This REPORT is initially unsealed for Root's complete reading. One-time manifest
sealing occurs only after that acknowledgment; its actual manifest coverage,
hash and every excluded post-seal receipt will be separately reported. The seal
is evidence custody only, not contract freezing, implementation or Gate authority.
