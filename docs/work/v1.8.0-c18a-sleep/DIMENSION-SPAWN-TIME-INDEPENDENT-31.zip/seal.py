"""One-time evidence-only manifest; no project/runtime operations."""
import datetime
import hashlib
import json
import pathlib
import re
import stat
import sys

ROOT = pathlib.Path(__file__).resolve().parent
EXPECTED = pathlib.Path(
    'D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-d1-contract-independent-20261009-31'
).resolve()
REPORT_SHA = '9bf95deec7cf3753a2d55586fe7221ebb6fd86e066241080e78865c6dccbd7e4'
MANIFEST = ROOT / 'SHA256SUMS.txt'
RECEIPT = ROOT / 'SEAL-RECEIPT.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def regular_files():
    result = []
    for p in sorted(ROOT.iterdir(), key=lambda q: q.name):
        assert stat.S_ISREG(p.lstat().st_mode), 'Non-regular leaf entry: ' + p.name
        assert p.resolve().parent == EXPECTED, 'Out-of-leaf entry'
        assert re.fullmatch(r'[A-Za-z0-9_.-]+', p.name), 'Unsafe relative name'
        result.append(p)
    assert len({p.name.casefold() for p in result}) == len(result)
    return result

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ROOT == EXPECTED, 'Unexpected evidence leaf'
assert not MANIFEST.exists() and not RECEIPT.exists(), 'Already sealed'
report = (ROOT / 'REPORT.md').read_bytes()
assert len(report) == 20171 and len(report.splitlines()) == 237
assert sha(report) == REPORT_SHA, 'Report differs from Root-read identity'
ack = (ROOT / 'ROOT-FULL-READ-ACKNOWLEDGMENT.md').read_text(encoding='utf-8')
assert REPORT_SHA in ack and 'one-time evidence-only seal' in ack
files = regular_files()
rows = []
total = 0
for p in files:
    raw = p.read_bytes()
    assert len(raw) <= 50000000, 'Oversize retained file'
    rows.append({'name': p.name, 'bytes': len(raw), 'sha256': sha(raw)})
    total += len(raw)
assert total <= 100000000, 'Oversize evidence leaf'
body = ''.join(row['sha256'] + '  ' + row['name'] + '\n' for row in rows).encode('ascii')
with MANIFEST.open('xb') as f:
    f.write(body)
for row in rows:
    raw = (ROOT / row['name']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
assert sha((ROOT / 'REPORT.md').read_bytes()) == REPORT_SHA
assert {p.name for p in regular_files()} == {row['name'] for row in rows} | {'SHA256SUMS.txt'}
finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt = {
    'started_utc': started, 'finished_utc': finished,
    'argv': [sys.executable, '-B', str(pathlib.Path(__file__).resolve())],
    'cwd': str(pathlib.Path.cwd()), 'exit_code': 0,
    'scope': 'ONE_TIME_STATIC_EVIDENCE_SEAL_ONLY_NOT_D1_FREEZE_OR_ACCEPTANCE',
    'root_acknowledgment': 'ROOT-FULL-READ-ACKNOWLEDGMENT.md',
    'report_lines': 237, 'report_bytes': 20171, 'report_sha256': REPORT_SHA,
    'manifest': 'SHA256SUMS.txt', 'manifest_bytes': len(body),
    'manifest_sha256': sha(body), 'covered_files': len(rows),
    'covered_bytes': total, 'verified_covered_hashes': len(rows),
    'safe_relative_case_unique_regular_files': True,
    'excluded_manifest_self': ['SHA256SUMS.txt'],
    'all_excluded_post_seal_receipts': ['SEAL-RECEIPT.json'],
    'no_covered_file_changed_after_manifest_write': True,
    'no_runtime_tests_or_project_changes': True,
}
with RECEIPT.open('x', encoding='utf-8', newline='\n') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
assert {p.name for p in regular_files()} == {row['name'] for row in rows} | {'SHA256SUMS.txt', 'SEAL-RECEIPT.json'}
print(json.dumps(receipt, indent=2))
print('SEAL_RECEIPT_SHA256=' + sha(RECEIPT.read_bytes()))
