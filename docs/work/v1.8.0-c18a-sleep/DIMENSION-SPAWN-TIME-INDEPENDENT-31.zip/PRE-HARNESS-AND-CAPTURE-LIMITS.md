# Task31 capture limits

The first two tool calls preceded the durable capture helper. They read the task,
listed available OpenPet tools, then read Main status/branch/worktrees, task hash,
the external evidence directory names, PROJECT-CONFIG and PRODUCT. Tool exit was
0 for both exec commands. The second display was truncated. No independently
captured pre-start UTC or raw subprocess bytes exist for those preliminary calls;
no such metadata is reconstructed here. All material task, governance, source and
primary conclusions are backed by later captured checks.

`start-state.receipt.json` records a command with exit 0 whose stderr nevertheless
contains a nonterminating PowerShell error: Get-FileHash was unavailable in that
NoProfile process. Task SHA was independently measured in `task31.stdout.txt`.
The original stderr and zero exit are retained, not relabeled as full success.

Exploratory commands labeled `status-abridged` and `adr066-sleep-locations`
encountered a shell-regex-pipeline error through the local Git shim. No receipt
files with those labels exist in this leaf; their exact subprocess exit/UTC/raw
bytes are not reconstructed. The later receipt index's zero-exit count cannot
establish their success. Direct fixed-blob status reads and the later grep with
separate -e expressions replace missing content, not missing historical receipts.

The earliest proposal29/report29 excerpts used Python's inherited console encoding.
Their exact captured bytes remain. Subsequent complete UTF-8 reads retain the exact
owner wording and both full deliverable contents. Their raw input hashes agree.

Some tool display envelopes were truncated, including the author input JSON and
native method bundles. Capture helper stdout/stderr files retain the complete
script output; targeted excerpt views were rerun for the assessed methods. Those
outputs are annotated selected javap excerpts, not the complete raw javap stream.
Full javap output hashes and actual argv/UTC/exit are recorded; the full class
disassembly is deliberately not retained. The original class-entry bytes remain
inside the pinned read-only primary JAR, not copied into this leaf.

`supplement.native-reads.json` contains a successful javap read of LevelReader with
no selected getTimeOfDay method. The method actually belongs to LevelTimeAccess;
`time-path-correction.native-reads.json` records the corrected primary read. The
empty selection is retained and not credited as proof of that method.

Exploratory `rg` views of this leaf's own excerpts were display-only and have no
independently recorded UTC/raw stream. Their referenced native reads and targeted
file excerpts are retained separately. A display-only Get-Content of this note and
capture.py after context restoration has the same limitation.

One later call omitted capture.py's cwd positional argument:
`python -B <leaf>/capture.py capture-error-review python -B -c <leaf-note/read-expression>`.
Its tool result exited 1 with WinError 2 before a child process could be created;
no durable helper receipt/raw bytes or pre-start UTC were produced. The corrected
call's expression then requested two nonexistent old receipt filenames and exited
1 with FileNotFoundError. That corrected call is durably retained in
`capture-error-review.receipt.json`, stdout and stderr; subsequent leaf listing
and capture-limit reads established what actually exists. Neither error changes
the material input checks or is counted as a successful read.

No game, compiler, Gradle, installation,
network, cleanup, delegation, Claude, process signal or HEAD/index mutation ran.

This note is a truthful summary of capture limitations, not substitute historical
raw proof. Root coordinates OpenPet; this reviewer emitted no pet events.
