"""Bounded static read receipts for Task31; no runtime qualification."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
name, cwd, *argv = sys.argv[1:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
env = dict(os.environ, PYTHONIOENCODING="utf-8")
proc = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=180, env=env)
finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
out = ROOT / (name + ".stdout.txt")
err = ROOT / (name + ".stderr.txt")
out.write_bytes(proc.stdout)
err.write_bytes(proc.stderr)
receipt = {
    "argv": argv, "cwd": cwd, "env_override": {"PYTHONIOENCODING": "utf-8"}, "started_utc": started,
    "finished_utc": finished, "exit_code": proc.returncode,
    "stdout": out.name, "stdout_bytes": len(proc.stdout),
    "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(),
    "stderr": err.name, "stderr_bytes": len(proc.stderr),
    "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest(),
}
(ROOT / (name + ".receipt.json")).write_text(
    json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
sys.stdout.buffer.write(proc.stdout)
sys.stderr.buffer.write(proc.stderr)
sys.exit(proc.returncode)
