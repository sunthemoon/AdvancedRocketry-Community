"""Pinned bounded javap excerpts and a natural() constant-pool inventory."""
import datetime
import hashlib
import json
import pathlib
import re
import struct
import subprocess
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
INDEX = json.loads(pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-dimension-spawn-time-contract-20261009-29/INPUT-HASHES.json').read_bytes())
JAR = pathlib.Path(INDEX['primary_files'][0]['path'])
FORGE = pathlib.Path(INDEX['primary_files'][1]['path'])
JAVAP = pathlib.Path(INDEX['primary_files'][2]['path'])

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def inspect(group, classes):
    receipts = []
    excerpts = []
    with zipfile.ZipFile(JAR) as z:
        for cls, wanted in classes:
            raw = z.read(cls.replace('.', '/') + '.class')
            argv = [str(JAVAP), '-classpath', str(JAR), '-p', '-c', cls]
            start = datetime.datetime.now(datetime.timezone.utc).isoformat()
            p = subprocess.run(argv, capture_output=True, timeout=180)
            end = datetime.datetime.now(datetime.timezone.utc).isoformat()
            lines = p.stdout.decode('utf-8', errors='replace').splitlines()
            selected = []
            for i, line in enumerate(lines):
                if line.startswith('  ') and not line.startswith('    ') and '(' in line and line.rstrip().endswith(';'):
                    next_i = next((j for j in range(i + 1, len(lines)) if lines[j].startswith('  ') and not lines[j].startswith('    ') and '(' in lines[j] and lines[j].rstrip().endswith(';')), len(lines))
                    if any(v in line for v in wanted):
                        selected.append(line.strip())
                        excerpts.append(f'CLASS {cls} entry_sha256={sha(raw)} METHOD {line.strip()}')
                        excerpts.extend(f'{j + 1:05d}: {lines[j]}' for j in range(i, next_i))
            receipts.append({'argv': argv, 'cwd': str(pathlib.Path.cwd()), 'start_utc': start, 'end_utc': end,
                             'exit_code': p.returncode, 'stderr': p.stderr.decode('utf-8', errors='replace'),
                             'input_class_sha256': sha(raw), 'full_stdout_sha256': sha(p.stdout),
                             'full_stdout_retained': False, 'selected_methods': selected})
    (ROOT / (group + '.native-reads.json')).write_text(json.dumps(receipts, indent=2) + '\n', encoding='utf-8')
    text = '\n'.join(excerpts) + '\n'
    (ROOT / (group + '.native-excerpts.txt')).write_text(text, encoding='utf-8')
    print(text)
    if any(r['exit_code'] for r in receipts):
        sys.exit(1)

mode = sys.argv[1]
if mode == 'spawn':
    inspect(mode, [('net.minecraft.server.level.ServerPlayer', ['startSleepInBed(', 'setRespawnPosition(', 'readAdditionalSaveData(', 'addAdditionalSaveData(']),
                   ('net.minecraft.server.players.PlayerList', ['respawn(']),
                   ('net.minecraft.world.entity.player.Player', ['findRespawnPositionAndUseSpawnBlock(', 'isSleepingLongEnough(']),
                   ('net.minecraft.world.level.block.BedBlock', ['canSetSpawn('])])
elif mode == 'time':
    inspect(mode, [('net.minecraft.server.level.ServerLevel', [' tick(', 'tickTime(', 'resetWeatherCycle(', 'setDayTime(']),
                   ('net.minecraft.server.players.SleepStatus', ['areEnoughSleeping(', 'areEnoughDeepSleeping(', 'sleepersNeeded(', 'removeAllSleepers(', 'update(']),
                   ('net.minecraft.world.level.storage.DerivedLevelData', ['getGameTime(', 'getDayTime(', 'setGameTime(', 'setDayTime(', 'getSpawn', 'isRaining(', 'setRaining(', 'setRainTime(', 'setThunder', 'isThundering(']),
                   ('net.minecraft.world.level.Level', ['isDay(', 'isNight(', 'getSharedSpawnPos(']),
                   ('net.minecraftforge.event.ForgeEventFactory', ['fireSleepingTimeCheck(', 'onSleepFinished('])])
elif mode == 'startup':
    inspect(mode, [('net.minecraft.server.MinecraftServer', ['createLevels(', 'reloadResources(']),
                   ('net.minecraft.server.WorldLoader', [' load(', 'loadAndReplaceLayer(']),
                   ('net.minecraft.server.ReloadableServerResources', ['loadResources(']),
                   ('net.minecraft.world.level.storage.PrimaryLevelData', ['setTagData('])])
elif mode == 'ancillary':
    inspect(mode, [('net.minecraft.world.item.CompassItem', ['getSpawnPosition(']),
                   ('net.minecraft.client.renderer.item.ItemProperties$1', ['unclampedCall(']),
                   ('net.minecraft.world.level.block.NetherPortalBlock', ['randomTick('])])
elif mode == 'supplement':
    inspect(mode, [('net.minecraft.world.level.storage.DerivedLevelData', ['getXSpawn(', 'getYSpawn(', 'getZSpawn(']),
                   ('net.minecraft.world.level.dimension.DimensionType', ['timeOfDay(', 'natural(']),
                   ('net.minecraft.world.level.LevelReader', ['getTimeOfDay(']),
                   ('net.minecraft.server.level.ServerLevel', ['canSleepThroughNights(', 'wakeUpAllPlayers('])])
elif mode == 'time-path-correction':
    inspect(mode, [('net.minecraft.world.level.LevelTimeAccess', ['getTimeOfDay('])])
elif mode == 'registry-list':
    cls = 'net.minecraft.resources.RegistryDataLoader'
    with zipfile.ZipFile(JAR) as z:
        raw = z.read(cls.replace('.', '/') + '.class')
    argv = [str(JAVAP), '-classpath', str(JAR), '-p', '-c', cls]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, capture_output=True, timeout=180)
    end = datetime.datetime.now(datetime.timezone.utc).isoformat()
    lines = p.stdout.decode('utf-8', errors='replace').splitlines()
    selected = set()
    for i, line in enumerate(lines):
        if any(v in line for v in ['Registries.DIMENSION_TYPE', 'Registries.LEVEL_STEM', 'WORLDGEN_REGISTRIES:', 'DIMENSION_REGISTRIES:']):
            selected.update(range(max(0,i-7),min(len(lines),i+8)))
    print(f'CLASS {cls} entry_sha256={sha(raw)}')
    for i in sorted(selected):
        print(f'{i+1:05d}: {lines[i]}')
    (ROOT / 'registry-list.native-reads.json').write_text(json.dumps({'argv':argv,'cwd':str(pathlib.Path.cwd()),
        'start_utc':start,'end_utc':end,'exit_code':p.returncode,'input_class_sha256':sha(raw),
        'full_stdout_sha256':sha(p.stdout),'full_stdout_retained':False,'stderr':p.stderr.decode('utf-8',errors='replace')},indent=2)+'\n',encoding='utf-8')
elif mode == 'forge':
    with zipfile.ZipFile(FORGE) as z:
        for entry in INDEX['forge_source_entries']:
            raw = z.read(entry['entry'])
            print(f"ENTRY {entry['entry']} sha256={sha(raw)} bytes={len(raw)}")
            for i, line in enumerate(raw.decode('utf-8').splitlines(), 1):
                print(f'{i:04d}: {line}')
elif mode == 'inventory':
    count = 0
    size = 0
    found = []
    with zipfile.ZipFile(JAR) as z:
        entries = [v for v in z.infolist() if v.filename.startswith('net/minecraft/') and v.filename.endswith('.class')]
        assert len(entries) <= 10000
        for v in entries:
            assert v.file_size <= 2 * 1024 * 1024
            raw = z.read(v.filename)
            size += len(raw)
            assert size <= 128 * 1024 * 1024
            count += 1
            if b'natural' not in raw or b'net/minecraft/world/level/dimension/DimensionType' not in raw:
                continue
            cp = [None]
            n = struct.unpack_from('>H', raw, 8)[0]
            pos = 10
            while len(cp) < n:
                tag = raw[pos]
                pos += 1
                if tag == 1:
                    length = struct.unpack_from('>H', raw, pos)[0]
                    pos += 2
                    cp.append((tag, raw[pos:pos+length].decode('utf-8', errors='replace')))
                    pos += length
                elif tag in (7, 8, 16, 19, 20):
                    cp.append((tag, struct.unpack_from('>H', raw, pos)[0]))
                    pos += 2
                elif tag in (9, 10, 11, 12, 17, 18):
                    cp.append((tag, *struct.unpack_from('>HH', raw, pos)))
                    pos += 4
                elif tag in (3, 4):
                    cp.append((tag,))
                    pos += 4
                elif tag in (5, 6):
                    cp.extend([(tag,), None])
                    pos += 8
                elif tag == 15:
                    cp.append((tag,))
                    pos += 3
                else:
                    raise ValueError((v.filename, tag))
            for item in cp:
                if item and item[0] in (10, 11):
                    owner = cp[cp[item[1]][1]][1]
                    nat = cp[item[2]]
                    method, desc = cp[nat[1]][1], cp[nat[2]][1]
                    if owner == 'net/minecraft/world/level/dimension/DimensionType' and method == 'natural' and desc == '()Z':
                        found.append({'class':v.filename, 'sha256':sha(raw), 'methodref':f'{owner}.{method}{desc}'})
    result = {'jar_sha256':sha(JAR.read_bytes()), 'native_classes':count, 'native_bytes':size, 'exact_methodref_consumers':found,
              'limits':{'classes':10000,'class_bytes':2097152,'total_bytes':134217728},
              'limitation':'Constant-pool method references are static candidates, not runtime invocation or third-party/reflection coverage.'}
    (ROOT / 'NATURAL-CONSUMER-INVENTORY.json').write_text(json.dumps(result,indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
