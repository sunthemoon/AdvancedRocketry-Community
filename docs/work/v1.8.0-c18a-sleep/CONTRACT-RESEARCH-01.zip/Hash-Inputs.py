"""Read and hash fixed Git blobs and the bounded native primary inputs."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = '96236acb682c060796e41d3837af7991d492d3b1'
LOG = LEAF / 'commands.log'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def log(text):
    with LOG.open('a', encoding='utf-8') as output:
        output.write(text + '\n')

paths = set(re.findall(r'COMMAND=git show ' + COMMIT + r':(.*?) ; display', LOG.read_text(encoding='utf-8-sig')))
paths.add('docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-01.md')
blobs = []
missing = []
for path in sorted(paths):
    args = ['git', '-C', str(REPO), 'show', COMMIT + ':' + path]
    start = now()
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    log('BEGIN UTC=' + start + ' COMMAND=' + json.dumps(args))
    log('END UTC=' + now() + ' EXIT_CODE=' + str(result.returncode))
    if result.returncode:
        missing.append({'path': path, 'exit_code': result.returncode, 'stderr': result.stderr.decode('utf-8', errors='replace')})
        continue
    blobs.append({'path': path, 'bytes': len(result.stdout), 'sha256': digest(result.stdout)})

mapped = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sources = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar')
javap = pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin/javap.exe')
primary = []
for path in [mapped, sources, javap]:
    log('BEGIN UTC=' + now() + ' COMMAND=SHA256 read bytes ' + str(path))
    data = path.read_bytes()
    primary.append({'path': str(path), 'bytes': len(data), 'sha256': digest(data)})
    log('END UTC=' + now() + ' EXIT_CODE=0')

classes = sorted(set(re.findall(r'CLASS=(net\.[^\s]+)', LOG.read_text(encoding='utf-8-sig'))))
entries = []
with zipfile.ZipFile(mapped) as archive:
    for class_name in classes:
        name = class_name.replace('.', '/') + '.class'
        data = archive.read(name)
        entries.append({'jar': 'mapped', 'entry': name, 'bytes': len(data), 'sha256': digest(data)})
with zipfile.ZipFile(sources) as archive:
    for file in sorted(LEAF.glob('net_minecraftforge*.java')):
        name = file.name.replace('_', '/')
        data = archive.read(name)
        entries.append({'jar': 'forge-sources', 'entry': name, 'bytes': len(data), 'sha256': digest(data)})

output = {'observed_utc': now(), 'fixed_commit': COMMIT, 'fixed_blobs': blobs,
          'failed_path_discovery': missing, 'primary_inputs': primary, 'primary_entries': entries}
(LEAF / 'INPUT-HASHES.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
log('HASH-INPUTS SUMMARY UTC=' + now() + ' fixed_blobs=' + str(len(blobs)) + ' failed_paths=' + str(len(missing)) + ' primary_entries=' + str(len(entries)) + ' EXIT_CODE=0')
print(json.dumps({'fixed_blobs': len(blobs), 'failed_paths': len(missing), 'primary_entries': len(entries), 'primary_inputs': primary}, indent=2))
