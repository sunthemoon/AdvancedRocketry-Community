param([Parameter(Mandatory=$true)][string[]]$Entries)
$ErrorActionPreference = 'Stop'
$jar = 'C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar'
$log = Join-Path $PSScriptRoot 'commands.log'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($jar)
try {
    foreach ($path in $Entries) {
        $command = "Read ZipArchive entry '$path' in '$jar'"
        Add-Content $log "BEGIN UTC=$([DateTime]::UtcNow.ToString('o')) COMMAND=$command"
        $entry = $zip.GetEntry($path)
        if ($null -eq $entry) { Add-Content $log "END UTC=$([DateTime]::UtcNow.ToString('o')) EXIT_CODE=1 ERROR=Entry not found"; throw "Entry not found: $path" }
        $reader = [System.IO.StreamReader]::new($entry.Open())
        try { $content = $reader.ReadToEnd() } finally { $reader.Dispose() }
        $name = $path.Replace('/','_')
        $content | Set-Content -LiteralPath (Join-Path $PSScriptRoot $name) -Encoding utf8
        "=== $path ===" | Tee-Object -FilePath $log -Append
        $n = 0
        $content -split "`n" | ForEach-Object { $n++; ('{0,5}: {1}' -f $n,$_.TrimEnd("`r")) } | Tee-Object -FilePath $log -Append
        Add-Content $log "END UTC=$([DateTime]::UtcNow.ToString('o')) EXIT_CODE=0"
    }
} finally { $zip.Dispose() }
