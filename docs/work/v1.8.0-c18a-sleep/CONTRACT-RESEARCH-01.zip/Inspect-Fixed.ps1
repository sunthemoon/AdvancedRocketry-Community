param(
    [Parameter(Mandatory=$true)][string[]]$Paths,
    [int]$From = 1,
    [int]$To = 2147483647
)
$ErrorActionPreference = 'Stop'
$commit = '96236acb682c060796e41d3837af7991d492d3b1'
$leaf = $PSScriptRoot
$log = Join-Path $leaf 'commands.log'
foreach ($path in $Paths) {
    $command = "git show ${commit}:$path ; display lines $From..$To"
    Add-Content -LiteralPath $log -Value "BEGIN UTC=$([DateTime]::UtcNow.ToString('o')) COMMAND=$command"
    $lines = @(git -C 'D:/GitHub/AdvancedRocketry-Community' show "${commit}:$path" 2>&1)
    $rc = $LASTEXITCODE
    "=== $path ===" | Tee-Object -FilePath $log -Append
    if ($rc -eq 0) {
        for ($i = [Math]::Max(1,$From); $i -le [Math]::Min($To,$lines.Count); $i++) {
            ('{0,5}: {1}' -f $i,$lines[$i-1]) | Tee-Object -FilePath $log -Append
        }
    } else { $lines | Tee-Object -FilePath $log -Append }
    Add-Content -LiteralPath $log -Value "END UTC=$([DateTime]::UtcNow.ToString('o')) EXIT_CODE=$rc"
    if ($rc -ne 0) { throw "Failed: $command" }
}
