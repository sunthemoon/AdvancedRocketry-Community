"""Verify fixed inputs and seal this exclusive leaf; do not modify the repository."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
TASK = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-CONTRACT-TASK-01.md')
COMMIT = '96236acb682c060796e41d3837af7991d492d3b1'
LOG = LEAF / 'commands.log'
MANIFEST = LEAF / 'SHA256SUMS.txt'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def append(message):
    with LOG.open('a', encoding='utf-8') as stream:
        stream.write(message + '\n')


def run(args, retain_output=True):
    append('BEGIN UTC=' + now() + ' COMMAND=' + json.dumps(args))
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if retain_output:
        append(result.stdout.decode('utf-8', errors='replace').rstrip())
    else:
        append('STDOUT_BYTES=' + str(len(result.stdout)) + ' STDOUT_SHA256=' + digest(result.stdout))
    if result.stderr:
        append(result.stderr.decode('utf-8', errors='replace').rstrip())
    append('END UTC=' + now() + ' EXIT_CODE=' + str(result.returncode))
    if result.returncode:
        raise RuntimeError('Final read-only command failed: ' + repr(args))
    return result.stdout


def verify_row(row, data):
    if len(data) != row['bytes'] or digest(data) != row['sha256']:
        raise RuntimeError('Input hash/length changed: ' + repr(row))


if MANIFEST.exists():
    raise RuntimeError('Refusing to modify a previously sealed evidence leaf')

started = now()
append('FINAL AUDIT BEGIN UTC=' + started + ' COMMAND=' + json.dumps([sys.executable, str(pathlib.Path(__file__).resolve())]))
inputs = json.loads((LEAF / 'INPUT-HASHES.json').read_text(encoding='utf-8'))
if inputs['fixed_commit'] != COMMIT:
    raise RuntimeError('Unexpected fixed source commit')

for row in inputs['fixed_blobs']:
    verify_row(row, run(['git', '-C', str(REPO), 'show', COMMIT + ':' + row['path']], retain_output=False))

for row in inputs['primary_inputs']:
    append('BEGIN UTC=' + now() + ' COMMAND=SHA256 verify recorded primary input ' + row['path'])
    verify_row(row, pathlib.Path(row['path']).read_bytes())
    append('END UTC=' + now() + ' EXIT_CODE=0')

archives = {'mapped': pathlib.Path(inputs['primary_inputs'][0]['path']),
            'forge-sources': pathlib.Path(inputs['primary_inputs'][1]['path'])}
for archive_kind, archive_path in archives.items():
    with zipfile.ZipFile(archive_path) as archive:
        for row in inputs['primary_entries']:
            if row['jar'] != archive_kind:
                continue
            append('BEGIN UTC=' + now() + ' COMMAND=SHA256 verify primary JAR entry ' + str(archive_path) + '!/' + row['entry'])
            verify_row(row, archive.read(row['entry']))
            append('END UTC=' + now() + ' EXIT_CODE=0')

final_git = {}
for name, args in [
    ('status', ['status', '--short']),
    ('branch', ['branch', '--show-current']),
    ('head', ['rev-parse', 'HEAD']),
    ('worktrees', ['worktree', 'list', '--porcelain']),
]:
    final_git[name] = run(['git', '-C', str(REPO)] + args).decode('utf-8').rstrip()

files = []
for path in LEAF.rglob('*'):
    if path.is_symlink():
        raise RuntimeError('Symlink is not valid leaf-contained evidence: ' + str(path))
    if not path.is_file():
        continue
    relative = path.relative_to(LEAF).as_posix()
    if relative.startswith('/') or '..' in pathlib.PurePosixPath(relative).parts:
        raise RuntimeError('Non-leaf path in evidence inventory')
    if path.stat().st_size > 50 * 1024 * 1024:
        raise RuntimeError('Evidence file exceeds 50 MiB')
    files.append(path)

proposal = (LEAF / 'PROPOSED-SLEEP-CONTRACT-01.md').read_text(encoding='utf-8')
ids = re.findall(r'^\| ((?:S|R)\d\d)\b', proposal, re.MULTILINE)
if len(ids) != len(set(ids)) or len(ids) != 23:
    raise RuntimeError('Expected 23 distinct explicitly unexecuted matrix cases')

required = {'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
            'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
            'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
            'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-01.md'}
if not required.issubset({row['path'] for row in inputs['fixed_blobs']}):
    raise RuntimeError('Missing required fixed input')

audit = {
    'started_utc': started,
    'preseal_completed_utc': now(),
    'fixed_commit': COMMIT,
    'assignment_input': {'path': str(TASK), 'bytes': TASK.stat().st_size,
                         'sha256': digest(TASK.read_bytes())},
    'verified_fixed_blobs': len(inputs['fixed_blobs']),
    'verified_primary_input_files': len(inputs['primary_inputs']),
    'verified_primary_entries': len(inputs['primary_entries']),
    'required_reads_present': True,
    'proposed_matrix_case_count': len(ids),
    'matrix_execution': 'UNEXECUTED',
    'repository_write_scope': 'NONE',
    'mutable_main_head_interests': 'RELEASED; never acquired',
    'final_git_observation': final_git,
    'final_git_note': 'Read-only observation of mutable integration checkout; does not pin Root HEAD or claim absence of other-agent changes.',
    'retained_data': 'Leaf-contained reports, inspection helpers/log, bounded native excerpts, primary hashes and audit/checksum metadata. No world, clone, server, build or archive created.',
    'checks_executed': 'Read-only Git/native primary checks and evidence integrity; no Gradle/Minecraft/runtime checks.',
    'preseal_exit_code': 0,
    'sealing': 'SHA256SUMS.txt will list every leaf file except itself; immediate verification result is returned on stdout without modifying the sealed leaf.',
}
(LEAF / 'FINAL-AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
append('FINAL AUDIT PRESEAL END UTC=' + now() + ' EXIT_CODE=0 fixed_blobs=' + str(len(inputs['fixed_blobs'])) + ' primary_entries=' + str(len(inputs['primary_entries'])))

# All evidence inputs are final before creating the manifest. No writes follow it.
files = sorted((path for path in LEAF.rglob('*') if path.is_file() and path != MANIFEST),
               key=lambda path: path.relative_to(LEAF).as_posix())
total = sum(path.stat().st_size for path in files)
if total >= 100 * 1024 * 1024:
    raise RuntimeError('Evidence leaf exceeds 100 MiB')
manifest_lines = [digest(path.read_bytes()) + '  ' + path.relative_to(LEAF).as_posix()
                  for path in files]
MANIFEST.write_text('\n'.join(manifest_lines) + '\n', encoding='ascii')
for line in MANIFEST.read_text(encoding='ascii').splitlines():
    expected, relative = line.split('  ', 1)
    if digest((LEAF / relative).read_bytes()) != expected:
        raise RuntimeError('Sealed evidence verification failed: ' + relative)
print(json.dumps({'seal_verified_utc': now(), 'exit_code': 0,
                  'sealed_leaf': str(LEAF), 'file_count_excluding_manifest': len(files),
                  'leaf_total_bytes_including_manifest': total + MANIFEST.stat().st_size,
                  'report_sha256': digest((LEAF / 'REPORT.md').read_bytes()),
                  'proposal_sha256': digest((LEAF / 'PROPOSED-SLEEP-CONTRACT-01.md').read_bytes()),
                  'manifest_sha256': digest(MANIFEST.read_bytes()),
                  'all_manifest_paths_leaf_relative': True,
                  'mutable_main_head_interests': 'RELEASED'}, indent=2))
