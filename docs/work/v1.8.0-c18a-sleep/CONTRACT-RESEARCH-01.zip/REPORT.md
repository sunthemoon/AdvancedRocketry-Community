# Sleep contract research report

Task: SLEEP-CONTRACT-TASK-01. Worker: `/root/sleep_contract_research`.
Status: **RESEARCH DELIVERED; CONTRACT PROPOSED ONLY.**
Date: 2026-10-09 UTC. Initial recorded check: 02:28:45.1873373 UTC.
Fixed source: `96236acb682c060796e41d3837af7991d492d3b1`.

Only write scope: this exclusive external evidence leaf,
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-contract-research-20261009-01`.
No Main/worktree HEAD ownership was acquired. Mutable Main/HEAD interests were
expressly released to Root before substantive inspection. No delegation or Claude.

## Findings, ordered by consequence

These are design constraints and existing behavior findings, not a review verdict
on an implementation that does not exist. Repository line references below all
refer to the fixed commit, not mutable checkout files. Native offsets refer to
the hashed locally cached Forge 47.4.10 official-mapped primary classes.

### F1. Native admission and spawn persistence cannot be treated as one air hook

All six packaged off-world dimension types use `natural=false`,
`bed_works=true`, `respawn_anchor_works=false`. Native BedBlock uses bedWorks
before attempting sleep, while ServerPlayer rejects sleep on non-natural types.
This means the existing beds do not explode there but native actual sleep fails.
Changing bedWorks alone will not solve it.

Primary evidence:

- `src/generated/v1.4/resources/data/advancedrocketrycommunity/dimension_type/`
  `moon.json`/`space.json`:3,6,16,18; `mars.json`/`venus.json`:3,15,17.
- `src/generated/v1.8/resources/data/advancedrocketrycommunity/dimension_type/`
  `tau_ceti_f.json`/`tau_ceti_g.json`:3,15,17.
- `net_minecraft_world_level_block_BedBlock.javap.txt`, use offsets 57-61 and
  canSetSpawn 0-7: bedWorks selects explosion versus normal bed interaction.
- `net_minecraft_server_level_ServerPlayer-sleep-spawn.javap.txt`,
  startSleepInBed 5-19: Forge failure hook; 53-72: natural refusal;
  73-106: native range/obstruction; **107-122: spawn update before** time check
  125-139 and monster check 140-258; 259-303: native start/stat/criterion/list.
- The extracted PlayerSleepInBedEvent has a nullable failure status, not an
  Event.Result ALLOW that bypasses natural. SleepingTimeCheckEvent addresses
  time, not the earlier dimension restriction. Event documentation can be
  imprecise about call names; compiled call order above is primary evidence.

Consequences: a breathability-only rejection hook can deny sleep, but cannot enable
it; a naive `natural=true` edit enables spawn mutations even on later daytime/
monster refusal. A default-false respawn policy needs explicit spawn preservation,
not a false assumption that sleep success is the only spawn-writing action.

The owner's exact chosen reply and its conditional scope are in
`docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-01.md`:12-26. Its fixed blob SHA-256 is
`1dd0928208ffba6cda4636a632d06fe00ebbef650e6f4d9d4d2b1ed66fdf0af6`.
ADR-066:282-290 already requires air refusal and allow/force defaults false;
that paragraph is not an implemented respawn option or an approval of a mechanism.

**Open technical input:** PlayerSetSpawnEvent carries no cause identifier. The
draft's scoped ordinary-bed veto needs a proven public interaction/cause boundary
before source assignment. A lasting flag from PlayerSleepInBedEvent can survive
an earlier native range/obstruction failure; a blanket veto also intercepts
respawn restoration or other spawn operations. ServerPlayer restoreFrom was
additionally inspected: it clones PlayerPersisted data and fires PlayerEvent.Clone
after the target lookup already performed by PlayerList, so Clone is not a
pre-selection substitute. The report does not manufacture that missing boundary.

### F2. Late respawn checking is insufficient for the accepted loaded-safe policy

ServerPlayer writes native dimension/position/angle/forced fields to player data.
The PlayerList respawn routine resolves the saved Level and invokes
findRespawnPositionAndUseSpawnBlock **before** creating/restoring the new player
and long before PlayerRespawnEvent. That lookup directly reads the spawn block;
it may mutate an anchor charge. A late event cannot retroactively prevent those
reads, selection or mutation. Air/permissions can change after the bed is saved.

Primary evidence:

- ServerPlayer addAdditionalSaveData:246-360 writes SpawnX/Y/Z, SpawnForced,
  SpawnAngle and SpawnDimension; readAdditionalSaveData:174-321 reads them,
  with a ResourceKey codec (no numeric dimension persistence).
- PlayerList respawn:22-72 reads saved fields/Level and invokes native lookup;
  82-107 chooses target or Overworld; 332-345 restores spawn fields;
  **733** fires PlayerRespawnEvent after admission/position/packets/registration.
- `net_minecraft_world_entity_player_Player.javap.txt`,
  findRespawnPositionAndUseSpawnBlock:0-5 directly gets block state;
  14-116 anchor path includes the 77-110 decrement; 117-152 bed path checks
  bedWorks, not natural; 153-254 forced/foreign block alternatives.
- PlayerSetSpawnEvent.java:15-20 is cancellable. ServerPlayer setRespawnPosition:
  0-21 calls that event before the write or message. It offers default new-bed
  spawn suppression, but no future death-time target validation.

Consequences: enabling natural sleep must not be mislabelled implementing C18
safe respawn. Existing administrative/native off-world spawn records can already
respawn at beds under natural=false. The proposal isolates a default sleep slice
without deleting those records, and explicitly keeps their safe-policy/migration
obligations open. A separate shadow-target/safe-Overworld-first candidate is
outlined for opt-in respawn, but its persistence, recovery and packet ordering
are not frozen or demonstrated. Native SpawnForced is not an air-only bypass.

### F3. Native off-world completion is local rest, not global night skipping

Non-Overworld Levels in the inspected MinecraftServer are constructed with
DerivedLevelData and tickTime false. That data delegates time/weather reads to
primary data, but ignores its setters. Each ServerLevel still has its own native
SleepStatus and wakes its players on sufficient deep sleep. The ordinary
off-world completion's setDayTime/resetWeather calls do not themselves write the
primary time/weather.

Primary evidence:

- `net_minecraft_server_MinecraftServer.javap.txt`, createLevels:409-442 selects
  non-Overworld and constructs DerivedLevelData; 444-481 constructs ServerLevel,
  with iconst_0 at 478 for tickTime.
- `net_minecraft_world_level_storage_DerivedLevelData.javap.txt`, getGameTime/
  getDayTime/getX/Y/ZSpawn/isRaining/isThundering delegate; setDayTime,
  setGameTime and weather setters immediately return.
- `net_minecraft_server_level_ServerLevel.javap.txt`, tick:39-120 obtains local
  quorum and executes the daylight-gated setDayTime; 120-145 wakes local players
  and conditionally resets weather. tickTime:0-79 is controlled by tickTime.
- `net_minecraft_server_players_SleepStatus.javap.txt`, update:50-85 excludes
  spectators and counts this Level's players; sleepersNeeded is max(1,
  ceil(active*percentage/100)); deep-sleep test uses native long-enough players.
- Player isSleepingLongEnough:0-21 requires actual sleeping and counter >=100.
- Level isDay/isNight:0-23/0-22 both exclude fixed-time types; the extracted
  SleepingTimeCheckEvent default is `!Level.isDay()`.

Consequences: do not forward off-world SleepFinishedTimeEvent to the Overworld
without a new shared-time/multiplayer contract. Space's stations share one native
Level quorum, not a quorum per logical orbit. Overworld sleep can change the
shared read clock for other cyclic surfaces; fixed Moon/Space presentation remains
18000. Existing OrbitalSkyTest:24-41 and ADR-047:134-140 pin that fixed Space
time for disc/sun placement. The recommended default preserves this ownership;
all actual started-Level/time/weather results remain unexecuted.

### F4. `natural=true` also changes compass, clock and portal-spawn behavior

A bounded constant-pool candidate scan read 7,110 Minecraft classes from the
19,355,242-byte cached mapped JAR (hard limits: 10,000 entries, 2 MiB/class,
128 MiB/JAR). Seven candidates were then bytecode-inspected; four exact
DimensionType.natural() invocations were found. This is a native direct-use
inventory, not an exhaustive compatibility-mod or reflective-use audit.

Primary evidence:

- `natural-reference-candidates.txt` and `natural-use-sites.txt`.
- CompassItem getSpawnPosition:0-25 uses current-Level shared spawn for natural
  types, null otherwise. It does not use ServerPlayer's bed.
- ItemProperties$1 unclampedCall:51-75 uses getTimeOfDay for natural types,
  Math.random otherwise (native clock property).
- NetherPortalBlock randomTick:0-40 gates on natural, doMobSpawning, randomized
  difficulty; 43-90 checks a floor and attempts ZOMBIFIED_PIGLIN with STRUCTURE
  reason. No assertion was made that a portal is ordinarily obtainable/active
  off-world, or that the atmosphere actor/spawn leaf is implemented.
- ServerLevel/Gui were false-positive candidates for an exact natural() invocation;
  their zero exact-use counts were retained. PhantomSpawner separately uses
  hasSkyLight, not an exact natural invocation in its inspected tick method.

Consequences: freezing a dimension change while omitting these effects is unsafe
product documentation. The proposal deliberately discloses native compass/clock/
portal semantics instead of inventing a new global client-property override or
blanket spawn cancellation. Preserving old ancillary behavior would be additional
compatibility work. This choice is subject to separate contract review, not
authorized merely by the owner's target selection.

### F5. The sleeping eye can be the bed head cell; cached suit protection is not air

Native startSleeping changes pose and position. LivingEntity setPosToBed offsets
Y by .6875 and its final getEyeHeight returns .2 for SLEEPING: the ordinary eye
cell is the head block itself. Sampling only the standing eye or `bed.above()`
can admit a different air cell than the sleeping player actually occupies.

Primary evidence:

- `net_minecraft_world_entity_LivingEntity-pose.javap.txt`, setPosToBed:0-28.
- `net_minecraft_world_entity_LivingEntity-sleep-eye.javap.txt`, getEyeHeight:0-19.
- LivingEntity startSleeping:20-70 updates occupancy, pose, position, sleeping
  position, movement. ServerPlayer stopSleepInBed retains native wake broadcast
  and connection teleport synchronization.
- AtmosphereLevelService.java:223-248 returns base-air BREATHABLE before its
  controlledAt loaded-cell check; controlled supply requires an indexed volume
  and loaded active provider that can still supply. An adapter must preflight
  the queried full chunk itself even on an ambient-breathable host.
- AtmosphereManager.java:118-141 reuses Level services and falls back to
  conservative non-Overworld vacuum when environment resolution fails.
- PlayerLifeSupportService.java:63-113 reads actual eye, handles suit oxygen and
  damage separately, and then applies exposure; sleeping is not an exemption.
- BodyContextResolver.java:38-61 resolves one captured catalog and explicit
  instance/unambiguous surface; StationRegionBodyContextResolver.java:21-35
  resolves only committed Space regions. AtmosphereAnalyzerService.java:64-85
  supplies a local precedent for connected actor/full-chunk/coherent profile
  checks and actual Space ambient identity, not a generic API to copy blindly.

Consequences: admission needs entry and intended sleeping cells; continued sleep
needs actual-eye observation and native wake when live air becomes pending or
unavailable. The proposal never treats suit oxygen, HUD cache or an orbit body's
surface air as room air. It preserves existing scan/dirty budgets and adds no
room scan. Eye-height compatibility and actual occupancy cleanup still need native
fixtures; none was executed here.

## Alternatives and recommendation

| Candidate | Benefit | Main cost / limit | Research recommendation |
|---|---|---|---|
| Packaged natural=true + native sleep + server air/wake/default spawn veto | keeps normal native range, blocked, monster, occupied, time, counter, stat and synchronization | deliberate compass/clock/portal delta; default spawn veto must be correctly scoped; registry upgrade readback required | smallest complete native default-sleep candidate; review explicitly before implementation |
| Keep natural=false; only return failure text | very small, no ancillary changes | does not perform the owner's chosen actual sleep | not a replacement for selected feature |
| Keep natural=false; direct startSleeping from event/interaction | can preserve ancillary flags and fake fewer dimension effects | bypasses native admission, ServerPlayer stat/criterion/list setup and Player counter reset; must reconstruct all invariants and interop | not recommended without an independently justified contract; no bypass code proposed |
| Access Transformer/reflection/native interception of dimension gate | can narrow dimension exception while retaining more native checks | new architecture/compatibility maintenance, private API or bytecode boundary; ADR proof/approval needed | not needed for initial recommended candidate; not assigned |
| Forward local completion into primary time | intuitive shared night skip | changes awake players in other Levels, surface environment, sky/gamerules and repeated simultaneous completion | non-minimal product change; not implied by actual sleep |
| Native off-world spawn + late PlayerRespawnEvent check | reuses native fields | target already inspected/possibly mutated before event; unsafe-load/air/access policy not guaranteed | not acceptable proof of ADR-066 respawn semantics |

The proposed contract spells out the recommended default-only native-lifecycle
slice and an explicit separate prerequisite for opt-in respawn. Its scope is
not the whole C18 ledger. No numerical balance, new owner authorization, contract
acceptance or production-side flag edit is asserted.

## Required reads and current state

Read all task-required governance documents through fixed `git show`, including
PROJECT-CONFIG (approved identity, Java 17/Forge 47.4.10), PRODUCT, principles,
roadmap, v1.8 plan, master test plan, release Gates, post-1.0 roadmap, quality
budgets and parallel coordination. Relevant fixed ADRs/status/code/resources/
tests were inspected; exact read blobs and SHA-256 are in INPUT-HASHES.json.
ADR-066 was inspected at relevant environment/sleep/authority boundaries; this
was not a new audit of its unrelated 965-line equipment/research scope.

CURRENT_VERSION:24-54,103-117 identifies active v1.8 implementation under ADR-060,
not advancement of the v1.0 acceptance cursor. It records actual-sleep selection
as conditional and says no sleep source is assigned. All v1.8 Required Gates
remain G0-G9 (version plan:216-247); inherited acceptance is still IN_PROGRESS.
No version, ledger, ADR, state or upstream file was edited.

Existing relevant test sources inspected include AtmosphereGameTests (sealed,
open, invalidation, no-forced-load cases), AtmosphereExposureGameTests,
V180ExoplanetResourcesTest:101-108 (cyclic exoplanet types), and OrbitalSkyTest
(fixed Space presentation). No ARCE sleep/respawn policy implementation was found
in the fixed source keyword inventory. Existing tests are not claimed to prove
new sleeping or future respawn behavior.

No pinned Advanced Rocketry/LibVulpes upstream source or asset was opened. Thus no
upstream-derived runtime file or asset was imported and no new provenance import
is proposed. Retained Forge event excerpts retain their original copyright and
LGPL-2.1-only notices; they are primary research evidence, not copied mod source.

## Actual checks, commands and outcomes

commands.log records exact fixed-file and native inspection commands, UTC begin/
end stamps, exit codes and retained output. Inspect-Fixed.ps1, Inspect-Native.ps1,
Inspect-Forge.ps1 and Hash-Inputs.py are leaf-local reproducible read helpers.

- Initial `git status --short`, branch, worktree list, `rev-parse HEAD` and
  `cat-file -t` returned 0. The source commit was present; Main was on
  codex/v1.8.0-classic-content at the fixed SHA. Existing modified AGENTS and
  many untracked owner evidence files were not touched. The separate jackhammer
  worktree was listed but never acquired or modified.
- Fixed `git show`/`git grep`/`git ls-tree` inventories and relevant file reads
  executed. Successful fixed read blobs were hashed from raw Git stdout.
- Two guessed station paths did not exist (`station/server/StationAccessService`
  and `station/server/StationProtectionEvents`); git returned 128 and the helper
  process returned 1. These discovery errors are retained, not runtime failures.
  The correct StationAccessService and region resolver were subsequently read.
- `Get-Command javap` failed because the binary was not on PATH (outer command
  exit 1). No install was attempted; existing Java 17 JDK javap was used by
  absolute path. This incidental discovery failure is recorded here because it
  preceded native helper logging.
- One guessed native class name, `net.minecraft.server.commands.SpawnPointCommand`,
  was absent; javap returned 1 and the helper process returned 1. Its command and
  error are retained. No source/behavior inference was made from the absent name.
  This failure stopped that exploratory command before its later wrapper probe;
  that later probe is not claimed executed.
- Successful absolute-path javap inspections on selected primary classes returned 0.
  The bounded 7,110-class candidate scan and seven-candidate exact-use inspections
  returned 0. The scan was static byte inspection, not server execution.
- ZipArchive extraction of five specific Forge source event entries returned 0.
- `python .../Hash-Inputs.py` returned 0: 49 successful fixed blobs, 2 retained
  nonexistent discovery paths, 19 native class/event entries. INPUT-HASHES.json
  binds raw fixed blobs and exact native classes/events; it does not claim those
  cache files are an executed build or source candidate artifact.
- Official Forge event/network documentation was browsed as a supporting API
  reference, not as evidence of Minecraft's specific bytecode call order.
  [Forge events](https://docs.minecraftforge.net/en/1.20.1/concepts/events/) warns
  that results/cancellation are event-specific;
  [SimpleImpl](https://docs.minecraftforge.net/en/1.20.1/networking/simpleimpl/)
  describes main-thread handling and the danger of trusting client positions.

Primary mapped JAR SHA-256:
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Forge sources JAR SHA-256:
`918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
The checksum manifest seals only files in this leaf, never mutable build/Temp
inputs; INPUT-HASHES.json separately describes the observed primary inputs.

## Unexecuted checks and tests

No Gradle command, compiler/test suite, DataGen, GameTest, Minecraft client,
dedicated server, install, world save/restart, remote Linux or V1/V2 run was
permitted or executed. All proposed matrix cases S01-S21/R01-R02 are unexecuted.
No test was added to the repository. The static primary findings do not prove
started-world registry replacement, normal connected bed use, occupancy cleanup,
time/weather runtime, default spawn-veto context or optional respawn durability.

The implementation commands still required are `./gradlew clean build`,
`./gradlew test`, `./gradlew runData`, `git diff --exit-code`,
`./gradlew runGameTestServer`, and affected finite packaged/restart/security
checks. They were prohibited in this read-only research, not marked passed or
waived. ADR-018 schedules the full long-load/remote/real-client campaign; it does
not grant any new Gate credit.

## Retained data, ownership and final disposition

Retained in this leaf: REPORT, proposed contract, leaf-local read helpers,
commands.log, INPUT-HASHES.json, bounded javap excerpts, five licensed Forge
event excerpts, native-use inventory, and final audit/checksum metadata. No world,
server copy, clone, build directory, native process or temporary archive was
created. No cleanup outside the leaf occurred. All retained items are research
evidence, not a source delivery package; no complete repository was duplicated.

Main, jackhammer and mutable HEAD interests are released; fixed-commit read
references impose no restriction on Root moving HEAD. There are no implementation
write scopes to hand back. Root coordinates OpenPet updates; the worker sent
milestone messages and did not spam the pet runtime.

Next within v1.8: resolve the exact ordinary-bed spawn cause boundary and
independently review and decide/freeze the minimal default sleep
contract (including dimension ancillary effects and default spawn-veto scope),
then assign its disjoint source/test scope. Separately freeze opt-in respawn and
old-record recovery before exposing those options. No v1.9 work is proposed.

**Does this meet all current-version Required Gates? No.** It completes the
assigned research/evidence task only. The contract is not approved, no runtime
behavior is delivered, no ledger unit closes, and no Gate changes.
