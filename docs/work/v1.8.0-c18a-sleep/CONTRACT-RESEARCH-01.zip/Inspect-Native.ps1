param(
    [Parameter(Mandatory=$true)][string]$Class,
    [Parameter(Mandatory=$true)][string]$Methods,
    [string]$Suffix = 'default'
)
$ErrorActionPreference = 'Stop'
$jar = 'C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
$javap = 'C:/Program Files/Java/jdk-17.0.7/bin/javap.exe'
$log = Join-Path $PSScriptRoot 'commands.log'
$command = "& '$javap' -classpath '$jar' -p -c '$Class' ; retain method regex '$Methods'"
Add-Content -LiteralPath $log -Value "BEGIN UTC=$([DateTime]::UtcNow.ToString('o')) COMMAND=$command"
$lines = @(& $javap -classpath $jar -p -c $Class 2>&1)
$rc = $LASTEXITCODE
if ($rc -ne 0) {
    $lines | Tee-Object -FilePath $log -Append
    Add-Content -LiteralPath $log -Value "END UTC=$([DateTime]::UtcNow.ToString('o')) EXIT_CODE=$rc"
    throw "javap failed, exit code $rc"
}
$out = [System.Collections.Generic.List[string]]::new()
$out.Add("CLASS=$Class INPUT=Forge 1.20.1-47.4.10 mapped official 1.20.1")
$keep = $false
foreach ($line in $lines) {
    if ($line -cmatch '^  [^ ].*\(') { $keep = $line -cmatch $Methods }
    if ($keep) { $out.Add([string]$line) }
}
$name = $Class.Replace('.','_') + '-' + $Suffix + '.javap.txt'
$out | Set-Content -LiteralPath (Join-Path $PSScriptRoot $name) -Encoding utf8
$out | Tee-Object -FilePath $log -Append
Add-Content -LiteralPath $log -Value "END UTC=$([DateTime]::UtcNow.ToString('o')) EXIT_CODE=$rc"
