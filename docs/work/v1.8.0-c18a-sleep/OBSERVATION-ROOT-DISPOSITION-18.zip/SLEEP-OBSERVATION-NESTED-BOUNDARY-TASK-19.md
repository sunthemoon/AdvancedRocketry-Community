# Sleep observation nested receiver source task 19

Date: 2026-10-09. You are a delegated implementation worker, not Root. Use a
neutral engineering voice, do not delegate further and do not send OpenPet events.

## Scope and ownership

Read mandatory repository governance at fixed Main 30944465a6e07215990182fb0dd935e65303e27a,
including the uppercase active v1.8 version document and parallel rules. Start by
checking status, worktrees and supplied ownership. Your exclusive source worktree
is D:/GitHub/arce-v180-sleep-chat-boundary-20261009, branch
codex/v1.8.0-sleep-chat-boundary, based on corrected 5b45132000ade1e3c8d130a6b8ccb29f07535124.
Your evidence write_scope is D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-nested-boundary-20261009-19/.
Source write_scope is adapterTest SleepBoundaryTrace.java and, only if needed to
keep a focused responsibility, a new SleepBoundaryChatBounds.java in that package.
No Main/source production/Fixture/build/registration/status/asset/API changes.
Root owns central records. Do not touch or take over existing peer outputs.

## Input and observable outcome

Read the complete sealed primary wire report at
sleep-observation-wire-qualification-20261009-17/REPORT.md and its manifest,
and corrected source review/qualification at tasks 06, 11 and 12. The primary
report identifies a nested ClickEvent/EntityTooltipInfo admission boundary.
Implement bounded native-chat preflight for this boundary: unsupported nested
receiver implementations must be refused before their overridable serializer
or getter is invoked; pinned ordinary native nested receivers remain supported.
Add focused adapter tests exercising admitted and unsupported nested receivers,
with evidence that refusals occur before receiver behavior. Preserve all current
budgets, evidence schema, failure/intervention semantics and native behavior.
Do not implement parser, driver, twenty-case launch, encoding policy or gameplay.
Review class responsibility if it exceeds 500 lines; explain the chosen split.
No forced verdict or assumed native gameplay outcome is supplied.

## Commands and delivery

Permitted: scoped reads, immutable Git diffs, rg/hash/ZIP checks, apply_patch edits,
and ./gradlew.bat compileJava compileTestJava compileAdapterTestJava --no-daemon
--no-build-cache --rerun-tasks (1800-second ceiling), after >=10 GiB disk and
owned temp/process preflight. No tests, GameTest, packaged native server, network
download, install, process takeover, or cleanup retry. Do not delete peer paths.
Own disposable outputs can be cleaned once using native contained PowerShell;
if denied, record exact retention and stop cleanup, without alternative attempts.
Use installed JDK 17 and absolute Python -B; record raw argv/cwd/pre-start/end
UTC/exits/streams and failures. Compile is not executed-test evidence.

After checks, inspect staged stat and commit/push only assigned source normally
to your branch; do not move Main or other HEADs. Provide REPORT.md with findings,
exact diff/commits/source hashes, added tests versus executed commands, provenance,
ownership/retention, risks and Required Gate limits. No Gate/item/ledger closure.
Send REPORT for Root complete reading before a one-time safe leaf-relative seal.
Do not seal pre-emptively. Final line: REPORT path.
