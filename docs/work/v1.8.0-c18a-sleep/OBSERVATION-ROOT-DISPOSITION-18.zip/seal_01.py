"""Final audit and one-time seal of the Main6d static records checkpoint."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = Path(__file__).resolve().parent
HEAD = '6d1b796e0e93b9953af505dd3fd9b25d47b91d97'
OWNER = 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
START = datetime.now(timezone.utc).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(name, argv):
    out = LEAF / ('final-01-' + name + '.log')
    receipt = out.with_suffix('.json')
    assert not out.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with out.open('xb') as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    record = {'argv': argv, 'cwd': str(ROOT), 'start_utc': start,
              'end_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode,
              'log_bytes': out.stat().st_size, 'log_sha256': sha(out.read_bytes())}
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    assert result.returncode == 0, record
    return out.read_text(encoding='utf-8').strip()

assert not (LEAF / 'SHA256SUMS.txt').exists()
assert sha((ROOT / 'AGENTS.md').read_bytes()) == OWNER
assert check('head', ['git', 'rev-parse', 'HEAD']) == HEAD
assert check('upstream', ['git', 'rev-parse', '@{u}']) == HEAD
assert check('tracked-status', ['git', 'status', '--short', '--untracked-files=no']) == 'M AGENTS.md'
assert not check('index', ['git', 'diff', '--cached', '--name-only'])
assert check('src-tree', ['git', 'rev-parse', 'HEAD:src']) == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
assert not check('whitespace', ['git', 'diff', '--check'])
for path in sorted(LEAF.glob('publication-*.json')):
    record = json.loads(path.read_text(encoding='utf-8'))
    log = path.with_suffix('.log')
    assert record['exit_code'] == 0 and record['start_utc'] <= record['end_utc']
    assert record['log_bytes'] == log.stat().st_size and record['log_sha256'] == sha(log.read_bytes())
    assert record['owner_agents_sha256'] == OWNER
for row in json.loads((LEAF / 'PACKAGING-01.json').read_text(encoding='utf-8'))['archives']:
    path = ROOT / 'docs/work/v1.8.0-c18a-sleep' / row['archive']
    assert sha(path.read_bytes()) == row['archive_sha256']
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
for name in ['SLEEP-OBSERVATION-NESTED-BOUNDARY-TASK-19.md', 'SLEEP-OBSERVATION-DRIVER-REVISION-TASK-20.md']:
    raw = (LEAF.parent / name).read_bytes()
    with (LEAF / name).open('xb') as stream:
        stream.write(raw)
    assert (LEAF / name).read_bytes() == raw
summary = {'start_utc': START, 'end_utc': datetime.now(timezone.utc).isoformat(),
           'checkpoint': HEAD, 'report_sha256': sha((LEAF / 'REPORT.md').read_bytes()),
           'owner_agents_sha256': OWNER, 'publication_raw_receipts_verified': True,
           'runtime_test_or_gate_approval': False}
with (LEAF / 'PRESEAL-AUDIT.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(summary, indent=2) + '\n')
rows = []
for path in sorted(LEAF.rglob('*')):
    assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
    if path.is_file():
        name = path.relative_to(LEAF).as_posix()
        assert ':' not in name and '\\' not in name and '..' not in Path(name).parts
        assert path.stat().st_size < 50 * 1024 ** 2
        rows.append((name, sha(path.read_bytes()), path.stat().st_size))
assert len(rows) == len({name.casefold() for name, _, _ in rows})
assert sum(size for _, _, size in rows) < 100 * 1024 ** 2
manifest = LEAF / 'SHA256SUMS.txt'
with manifest.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(''.join(digest + '  ' + name + '\n' for name, digest, _ in rows))
for name, digest, _ in rows:
    assert sha((LEAF / name).read_bytes()) == digest
print(json.dumps({'report_sha256': summary['report_sha256'], 'manifest_sha256': sha(manifest.read_bytes()),
                  'covered_files': len(rows), 'covered_bytes': sum(size for _, _, size in rows),
                  'manifest_excludes': ['SHA256SUMS.txt'], 'seal_utc': datetime.now(timezone.utc).isoformat()}), flush=True)
