"""Rehost three fully read sealed inputs; preserve explicit post-seal exclusions."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
OUT = Path(__file__).resolve().parent
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
SPECS = [
    ('sleep-observation-root-review-20261009-07', 'OBSERVATION-ROOT-PUBLICATION-07.zip',
     '7196bf56914cd2419bb8d1f9d974732c444958a9c91d43d7bf27f72596df370a',
     '07278c2686b05a3e2982c26ef7d65f538c6da66e0e5611743e16fb59975a3b66', []),
    ('sleep-observation-driver-contract-independent-20261009-16', 'OBSERVATION-DRIVER-INDEPENDENT-16.zip',
     '2aa9ee0dad7fce9a509b9c7b70ae3021f5f4e898138e42c8fee3de099d45b105',
     '7b04e8cdbc7b178081ce677d220234702160ef2c72f052dad16b9a389d5a08b3',
     ['SEAL-RESULT.json', 'commands/52-seal.json', 'commands/52-seal.stdout.txt', 'commands/52-seal.stderr.txt']),
    ('sleep-observation-wire-qualification-20261009-17', 'OBSERVATION-WIRE-QUALIFICATION-17.zip',
     '430acfcab917021c5fb1de7b44ae3a13306db723af13df631573bc0e95316d16',
     'fb169613d32c0aa14ea6f81c66c7dd31263c4a44634ff044d486b859c71d1108',
     ['SEAL-RESULT.json', 'SEAL-STDOUT.txt', 'SEAL-STDERR.txt'])]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

start = datetime.now(timezone.utc).isoformat()
results = []
for leaf_name, zip_name, manifest_sha, report_sha, extras in SPECS:
    leaf = BASE / leaf_name
    raw_manifest = (leaf / 'SHA256SUMS.txt').read_bytes()
    assert sha(raw_manifest) == manifest_sha
    covered = {}
    for line in raw_manifest.decode('utf-8-sig').splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
        assert match
        expected, name = match.groups()
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
        assert name.casefold() not in {key.casefold() for key in covered}
        assert sha((leaf / name).read_bytes()) == expected.lower()
        covered[name] = expected.lower()
    assert covered['REPORT.md'] == report_sha
    paths = {}
    for path in leaf.rglob('*'):
        assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
        if path.is_file():
            assert path.stat().st_size < 50 * 1024 ** 2
            paths[path.relative_to(leaf).as_posix()] = path
    assert set(paths) == set(covered) | {'SHA256SUMS.txt', *extras}
    assert len(paths) == len({name.casefold() for name in paths})
    target = DEST / zip_name
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.write(path, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes()
        expanded = sum(info.file_size for info in archive.infolist())
    results.append({'archive': zip_name, 'bytes': target.stat().st_size,
                    'expanded_bytes': expanded, 'archive_sha256': sha(target.read_bytes()),
                    'entries': len(paths), 'covered_entries': len(covered),
                    'covered_bytes': sum(paths[name].stat().st_size for name in covered),
                    'report_sha256': report_sha, 'manifest_sha256': manifest_sha,
                    'noncovered_postseal_entries': extras, 'crc_payloads_verified': True})
total_compressed = total_expanded = 0
for path in DEST.glob('*.zip'):
    assert path.stat().st_size < 50 * 1024 ** 2
    total_compressed += path.stat().st_size
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        total_expanded += sum(info.file_size for info in archive.infolist())
assert total_expanded < 100 * 1024 ** 2
record = {'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
          'archives': results, 'all_sleep_compressed_bytes': total_compressed,
          'all_sleep_expanded_bytes': total_expanded,
          'runtime_or_executable_approval': False}
with (OUT / 'PACKAGING-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
