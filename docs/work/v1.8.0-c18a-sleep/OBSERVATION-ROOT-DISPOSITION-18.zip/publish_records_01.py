"""Publish only fully read contract dispositions and immutable compact evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = Path(__file__).resolve().parent
BASE = '30944465a6e07215990182fb0dd935e65303e27a'
OWNER = 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
DOCS = sorted(['docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',
    'docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-08.md',
    'docs/work/v1.8.0-c18a-sleep/DRIVER-REVIEW-STATUS-18.md'])
ZIPS = sorted(['docs/work/v1.8.0-c18a-sleep/' + name for name in (
    'OBSERVATION-ROOT-PUBLICATION-07.zip', 'OBSERVATION-DRIVER-INDEPENDENT-16.zip',
    'OBSERVATION-WIRE-QUALIFICATION-17.zip')])
EXPECTED = sorted(DOCS + ZIPS)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def run(name, argv):
    out = LEAF / ('publication-01-' + name + '.log')
    receipt = out.with_suffix('.json')
    assert not out.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with out.open('xb') as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    record = {'argv': argv, 'cwd': str(ROOT), 'start_utc': start,
              'end_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode,
              'head': git('rev-parse', 'HEAD'), 'log_bytes': out.stat().st_size,
              'log_sha256': sha(out.read_bytes()),
              'owner_agents_sha256': sha((ROOT / 'AGENTS.md').read_bytes())}
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    assert result.returncode == 0, record

assert git('rev-parse', 'HEAD') == BASE
assert git('rev-parse', '@{u}') == BASE
assert git('branch', '--show-current') == 'codex/v1.8.0-classic-content'
assert not git('diff', '--cached', '--name-only')
assert sha((ROOT / 'AGENTS.md').read_bytes()) == OWNER
assert sorted(git('diff', '--name-only').splitlines()) == sorted(['AGENTS.md', *[p for p in DOCS if not p.endswith('DRIVER-REVIEW-STATUS-18.md')]])
for name in DOCS:
    if name.endswith('v1.8.0-implementation-log.md'):
        continue
    path = ROOT / name
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            assert (path.parent / target.split('#', 1)[0]).exists(), (name, target)
record = json.loads((LEAF / 'PACKAGING-01.json').read_text(encoding='utf-8'))
for row in record['archives']:
    assert sha((ROOT / 'docs/work/v1.8.0-c18a-sleep' / row['archive']).read_bytes()) == row['archive_sha256']
expanded = 0
for path in (ROOT / 'docs/work/v1.8.0-c18a-sleep').glob('*.zip'):
    assert path.stat().st_size < 50 * 1024 ** 2
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        expanded += sum(info.file_size for info in archive.infolist())
assert expanded < 100 * 1024 ** 2
for name, argv in (
    ('whitespace', ['git', 'diff', '--check']),
    ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('bootstrap', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py', '--require-approved-review']),
    ('stage', ['git', 'add', '--', *EXPECTED]),
    ('staged-stat', ['git', 'diff', '--cached', '--stat']),
    ('staged-whitespace', ['git', 'diff', '--cached', '--check']),
):
    run(name, argv)
assert sorted(git('diff', '--cached', '--name-only').splitlines()) == EXPECTED
run('commit', ['git', 'commit', '-m', 'docs(sleep): preserve independent driver and wire findings'])
run('push', ['git', 'push', 'origin', 'HEAD:codex/v1.8.0-classic-content'])
assert git('rev-parse', 'HEAD:src') == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
assert git('status', '--short', '--untracked-files=no') == 'M AGENTS.md'
