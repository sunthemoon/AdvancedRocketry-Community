# Sleep observation driver contract revision task 20

Date: 2026-10-09. You are a delegated contract worker, not Root. No persona,
nested delegation or OpenPet updates. This is static documentation work only.

Exclusive write_scope: D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-20261009-20/.
No source/worktree/index/HEAD/central docs/world/runtime interests are assigned.
Read fixed governance at Main 30944465a6e07215990182fb0dd935e65303e27a and the
complete sealed proposal/report 15, review 16 and primary wire report 17,
including their manifests and task permissions. Source remains fixed 5b451320.
Task 19 separately addresses nested receiver source preflight; do not assume its
result, source identity, compilation or tests. Keep this dependency explicit.

Produce a self-contained proposed driver/parser contract revision addressing
the actual Task16-R01/R02/R03 and Task17 findings. Freeze exact future encoding
and line-framing recipe, finite owned capture/storage budgets and reserved
failure receipts, IO/overflow/forced-stop outcomes, bounded structural JSON
counting and compatibility/refusal semantics, native chat union and nested
receiver limits, and native NBT modified-UTF-8/gzip/type/consumption policy.
Check all resulting budgets and deadlines together. Preserve original source
caps and reviewed runtime ceilings; do not silently raise them to make inputs
pass. An additional defensive refusal must be a separate capture failure,
not gameplay failure or successful observation. Preserve case 19 intervention
attribution and getter versus teardown-save/disk boundaries. State unsupported
wire inputs and unresolved assumptions precisely, without asserting closure.

Only read-only Git/rg/hash/ZIP/installed javap primary inspection and Python -B
compact evidence operations with 180-second command ceilings are permitted.
No tests, parser/driver implementation, Java execution/discovery, server, Gradle,
network/download/install/copy of runtime libraries, cleanup, source change,
commit/push or Main mutation. Do not import expected observations/native verdicts.

Retain actual raw command receipts (pre-start UTC/argv/cwd/end/exit/streams),
input identities and failures. Write PROPOSED-DRIVER-03.md and REPORT.md with
changes, evidence-based disposition, remaining prerequisites and risks. Mark
PROPOSED, not executable-frozen/accepted. No Gate/ledger/owner scope change.
Send complete REPORT/proposal for Root reading before one-time leaf-relative
sealing; preserve all original sealed records. Final line: REPORT path.
