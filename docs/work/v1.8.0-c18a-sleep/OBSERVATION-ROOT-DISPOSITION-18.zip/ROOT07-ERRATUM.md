# Root checkpoint 07 receipt-schema clarification

Date: 2026-10-09. This additive correction does not change sealed checkpoint 07.
Its REPORT's sentence about all command receipts including an owner AGENTS digest
is too broad. Publication 01's original commit/push receipts include argv/cwd,
pre-start/end UTC, exit, HEAD, raw-log SHA and tracked-status, but do not include
log_bytes or owner_agents_sha256. Publications 02/03 do include those two fields.
The later Root audit checks the current owner digest and original publication-01
raw-log hashes, without reconstructing missing historical fields or timestamps.
These limitations are not a gameplay test failure or an owner authorization.

Checkpoint 07 failed helper 04 and successful helper 05 remain separate; the
successful seal covers 98 files /111205 bytes with REPORT SHA
07278c2686b05a3e2982c26ef7d65f538c6da66e0e5611743e16fb59975a3b66
and manifest SHA 7196bf56914cd2419bb8d1f9d974732c444958a9c91d43d7bf27f72596df370a.
The original complete REPORT was read before sealing. Its named Main checkpoint
is 30944465, not later contract-review or source-revision outcomes.
