"""Preserve the established strict repository check's 180-second ceiling."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

LEAF = Path(__file__).resolve().parent
REPO = Path("D:/GitHub/arce-v180-sleep-observation-qualification-20261009")
SOURCE = "5b45132000ade1e3c8d130a6b8ccb29f07535124"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip() == SOURCE
out = LEAF / "strict-01"
assert not out.exists()
out.mkdir()
argv = [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]
record = {"argv": argv, "cwd": str(REPO), "source": SOURCE, "timeout_seconds": 180,
          "started_utc": datetime.now(timezone.utc).isoformat()}
with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
    try:
        result = subprocess.run(argv, cwd=REPO, stdout=stdout, stderr=stderr, timeout=180, check=False)
        record["exit"] = result.returncode
    except subprocess.TimeoutExpired:
        record["exit"] = "TIMEOUT"
record["ended_utc"] = datetime.now(timezone.utc).isoformat()
record["streams"] = {name: {"bytes": (out / name).stat().st_size,
                                  "sha256": hashlib.sha256((out / name).read_bytes()).hexdigest()}
                     for name in ("stdout.log", "stderr.log")}
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
