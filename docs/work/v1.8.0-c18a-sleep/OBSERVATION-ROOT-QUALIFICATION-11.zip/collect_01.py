"""Collect actual fixed-source results and artifact identities before own cleanup."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

LEAF = Path(__file__).resolve().parent
REPO = Path("D:/GitHub/arce-v180-sleep-observation-qualification-20261009")
SOURCE = "5b45132000ade1e3c8d130a6b8ccb29f07535124"

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO).decode("utf-8").strip()

assert git("rev-parse", "HEAD") == SOURCE and not git("status", "--short")
results = {}
for name in ("build-01", "test-01", "data-01a", "data-01b", "native-01", "publish-01", "consumer-01"):
    path = LEAF / name / "RESULT.json"
    value = json.loads(path.read_text(encoding="utf-8"))
    assert value["source"] == SOURCE and value["exit"] == 0 and not value["source_status_after"]
    assert value["log_sha256"] == digest(LEAF / name / "command.log")
    results[name] = {"receipt": path.relative_to(LEAF).as_posix(), "receipt_sha256": digest(path),
                     "exit": value["exit"], "start_utc": value["started_utc"], "end_utc": value["ended_utc"]}
native = LEAF / "native-01"
text = (native / "build_gametest_logs_latest.log").read_text(encoding="utf-8")
markers = re.findall(r"All (\d+) required tests passed", text)
assert len(markers) == 1
batches = [line for line in text.splitlines() if "Running test batch 'sleep_" in line]
error_lines = [line for line in text.splitlines() if re.search(r"\[[^]\r\n]*/ERROR\]", line)]
fatal_lines = [line for line in text.splitlines() if re.search(r"\[[^]\r\n]*/FATAL\]", line)]
assert not (native / "NATIVE-SUMMARY.json").exists()
(native / "ERROR-LINES.txt").write_text("\n".join(error_lines) + "\n", encoding="utf-8")
native_summary = {"actual_required_tests_passed": int(markers[0]), "sleep_batch_lines": batches,
                  "error_headers": len(error_lines), "fatal_headers": len(fatal_lines),
                  "log_gate_waiver": False, "twenty_case_console_command_executed": False,
                  "native_xml_report_exists": (REPO / "build/gametest-results.xml").exists()}
(native / "NATIVE-SUMMARY.json").write_text(json.dumps(native_summary, indent=2) + "\n", encoding="utf-8")
dest = LEAF / "artifact-audit-01"
assert not dest.exists()
dest.mkdir()
report_dir = REPO / "compat-test-mod/build/reports/consumer-boundary"
if not report_dir.is_dir():
    matches = sorted((REPO / "compat-test-mod/build").rglob("fixture-artifact.json"))
    assert len(matches) == 1
    report_dir = matches[0].parent
for name in ("classpath.json", "negative-import.json", "fixture-artifact.json"):
    shutil.copyfile(report_dir / name, dest / name)
boundary = {name: json.loads((dest / name).read_text(encoding="utf-8"))
            for name in ("classpath.json", "negative-import.json", "fixture-artifact.json")}
assert boundary["negative-import.json"]["exit_code"] == 1
assert boundary["fixture-artifact.json"]["reobfuscated"] is True
paths = sorted((REPO / "build/libs").glob("*.jar")) + [Path(boundary["fixture-artifact.json"]["file"])]
artifacts = []
for path in paths:
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        classes = sorted(name for name in names if name.endswith(".class"))
        if path.parent == REPO / "build/libs":
            assert not any(name.startswith("io/github/sunthemoon/arceadaptertest/") for name in classes)
        else:
            assert any(name.endswith("/SleepBoundaryObservationFixture.class") for name in classes)
            assert any(name.endswith("/SleepBoundaryTrace.class") for name in classes)
            assert all(name.startswith("io/github/sunthemoon/arceadaptertest/") for name in classes)
    artifacts.append({"source_path": str(path), "bytes": path.stat().st_size, "sha256": digest(path),
                      "entries": len(names), "classes": classes})
assert digest(Path(boundary["classpath.json"]["published_file"])) == boundary["classpath.json"]["published_sha256"]
assert digest(Path(boundary["fixture-artifact.json"]["file"])) == boundary["fixture-artifact.json"]["sha256"]
record = {"source": SOURCE, "src_tree": git("rev-parse", "HEAD:src"), "collected_utc": datetime.now(timezone.utc).isoformat(),
          "results": results, "native": native_summary, "artifacts": artifacts,
          "source_status": git("status", "--short"), "full_required_gates_satisfied": False}
(dest / "ARTIFACTS.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
for name, args in (("status", ["status", "--short"]), ("diff", ["diff", "--exit-code"]), ("whitespace", ["diff", "--check"])):
    start = datetime.now(timezone.utc).isoformat()
    with (dest / (name + ".log")).open("xb") as stream:
        result = subprocess.run(["git", *args], cwd=REPO, stdout=stream, stderr=subprocess.STDOUT, timeout=180, check=False)
    receipt = {"argv": ["git", *args], "cwd": str(REPO), "started_utc": start,
               "ended_utc": datetime.now(timezone.utc).isoformat(), "exit": result.returncode,
               "log_sha256": digest(dest / (name + ".log")), "bytes": (dest / (name + ".log")).stat().st_size}
    (dest / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    assert result.returncode == 0 and not (dest / (name + ".log")).read_bytes()
print(json.dumps({"native": native_summary, "artifact_identities": [{k: item[k] for k in ("source_path", "bytes", "sha256", "entries")} for item in artifacts]}, indent=2), flush=True)
