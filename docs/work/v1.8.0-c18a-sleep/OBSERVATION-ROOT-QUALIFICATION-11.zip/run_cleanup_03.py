"""Capture native cleanup via the read-only discovered installed PowerShell."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
exe = Path("C:/Program Files/WindowsApps/Microsoft.PowerShell_7.6.6.0_x64__8wekyb3d8bbwe/pwsh.exe")
assert exe.is_file()
argv = [str(exe), "-NoProfile", "-File", str(LEAF / "Cleanup-Owned-02.ps1")]
out = LEAF / "cleanup-command-03"
assert not out.exists()
out.mkdir()
record = {"argv": argv, "cwd": str(ROOT), "started_utc": datetime.now(timezone.utc).isoformat(),
          "timeout_seconds": 180, "helper_sha256": hashlib.sha256((LEAF / "Cleanup-Owned-02.ps1").read_bytes()).hexdigest(),
          "native_executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest()}
(out / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
    try:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=180, check=False)
        record["exit"] = result.returncode
    except subprocess.TimeoutExpired:
        record["exit"] = "TIMEOUT"
    except OSError as error:
        record.update(exit="LAUNCH_ERROR", error_type=type(error).__name__, error=str(error))
record.update(ended_utc=datetime.now(timezone.utc).isoformat(),
              streams={name: {"bytes": (out / name).stat().st_size, "sha256": hashlib.sha256((out / name).read_bytes()).hexdigest()}
                       for name in ("stdout.log", "stderr.log")})
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
raise SystemExit(0 if record["exit"] == 0 else 1)
