# Root corrected passive-observation development qualification 11

Date: 2026-10-09 UTC. Scope: fixed-source short development regression only.
No production sleep or twenty-case console observation is implemented/executed.

## Findings and limits first

- The approved-identity repository validator reaches its unchanged **180-second
  TIMEOUT**, with zero-byte stdout/stderr. This is not a passed link report or
  Required Gate. No timeout extension or filtered substitute is used.
- The existing unfiltered standard GameTest exits 0 and reports **588 required
  tests passed**, including `sleep_trace` (5) and `sleep_console` (4) batches.
  Latest.log retains **62 ERROR headers /0 FATAL**; diagnostics and stacks are
  preserved without a log-Gate waiver. Passing tests are not log acceptance.
- The twenty native-Java simulated-transport rows, actual spawn-event frames,
  handler outcomes, typed saved Spawn fields and packaged driver remain
  **UNEXECUTED**. The nine guard/bound GameTests do not substitute for them.
- Two own cleanup preparation failures are preserved: incompatible Split-Path
  parameters and an assumed absent MSI PowerShell location. Neither reached
  deletion or was a tool-policy denial. The separately captured corrected
  native PowerShell cleanup exits 0 and removes only six owned output targets.

No assigned Gradle/JUnit/GameTest/consumer execution failed. No source,
assertion, cap, dependency, timeout, world data, policy or Gate is weakened.

## Fixed source, authority and ownership

Source: **5b45132000ade1e3c8d130a6b8ccb29f07535124**.
Source base: b9bec789978de0df67c93e976239d6d36e41532b.
Complete src tree: **001b12375461d7dddec6d74b69f7e0ea7d966188**.
Governance checkpoint: 608f04360522f9aa2d1fdaab09d853d4cb4075f9.
Only SleepBoundaryObservationFixture.java and SleepBoundaryTrace.java are added
to adapterTest. Neither production/API nor build/resources are changed.

Task 11 SHA-256 is
53e3de1d5f2f297741f65e9e394e350e43ad1574fe37b283a2df6ad1ee35756b.
Task 13 SHA-256 is
c517b1017e3f0a40d34a57c0a967c0501584972c176698fda49f7def9b644825.
Root reads the complete independent source review before standard GameTest
activation and later reads the complete sealed final report, SHA-256
3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0.
Historical F01/F02 remain valid for older candidates and are source-fixed at 5b451320.
That review runs three independent compiles, not these tests/runtime commands.
Task 13 permits only standard unfiltered development regression, not a driver
or native twenty-case invocation. The later owner record 03 does not expand it.

Detached checkout:
D:/GitHub/arce-v180-sleep-observation-qualification-20261009.
Exclusive evidence leaf: this report's directory. Child TEMP/TMP/java.io.tmpdir
are exclusively owned per-command children. Root writes only own disposable
checkout/evidence outputs here; Main source/index/HEAD, peers and sealed inputs
are not modified by these qualification commands. Main documentation publication
is a distinct Root task. No Claude/subordinate runtime is used by this executor.

Installed Oracle JDK 17.0.7 /Gradle 8.8 /Forge 1.20.1-47.4.10 remain fixed. Every
sustained command checks C:/D: >=10 GiB. Native launch additionally records
memory/live-process preflight; the separate prior Root check observes about
20 GiB available physical memory. JVM input overrides and exact build/source/JDK
hashes are in COMMAND/RESULT receipts; no tool/library installation is changed.

## Actually executed commands

All Gradle argv begin with the assigned gradlew.bat and
`--no-daemon --no-build-cache --rerun-tasks`. Every Gradle ceiling stays 2400 seconds.
Each row has exact argv/cwd/pre-start UTC/end UTC/exit/raw merged output/input
hashes/before-after source and disk state in its own immutable cohort directory.
All UTC times below are 2026-10-09; receipts retain subsecond precision.

| Cohort | Command suffix | UTC start/end | Result |
|---|---|---|---|
| build-01 | clean build | 05:19:55 /05:22:54 | Exit 0; 20 tasks executed; 2192 JUnit cases /381 XML; zero failures/errors/skips. |
| test-01 | test | 05:24:49 /05:28:14 | Exit 0; separate forced test; 2192 /381; zero failures/errors/skips. |
| data-01a | runData | 05:29:37 /05:30:27 | Exit 0; separate diff/status empty. |
| data-01b | runData | 05:33:22 /05:35:01 | Exit 0; second diff/status empty. |
| native-01 | runGameTestServer | 05:37:41 /05:43:14 | Exit 0; 18 executed tasks; 588 required tests pass. |
| publish-01 | publishMavenJavaPublicationToLocalProjectRepositoryRepository --offline | 05:43:32 /05:44:24 | Exit 0; 17 tasks executed; local publication only. |
| consumer-01 | -p compat-test-mod clean build -ParceVersion=1.20.1-1.8.0-dev --offline | 05:44:42 /05:45:02 | Exit 0; 10 tasks executed; API-only reobfuscated consumer. |
| strict-01 | python -B scripts/validate_repository.py --require-approved-identity | 05:40:49 /05:43:49 | TIMEOUT at 180 seconds; stdout/stderr zero bytes. |

Both JUnit XML cohorts are separately copied/hash-inventoried. Failures/errors/
skips are zero in each actual 2192-case run. DataGen's separate diff/status
commands retain empty raw files and actual printed argv/exits, but their original
helper does not persist separate per-Git-command UTC receipts. No timestamps
are reconstructed; final independently instrumented status/diff/whitespace
receipts exit 0 with zero-byte logs. Source stays clean at the fixed SHA.

Latest native log records sleep_trace:1 (5) at 13:39:33 and sleep_console:1 (4)
at 13:41:34 local time, then the 588 completion at 13:43:10. Full stdout/latest/
debug are retained. The standard definition produces no native XML result;
no reporter/namespace/run argument is added. It tests nine fixture guard/bound
methods, not the twenty console rows. A setup-guard unit intervention is not
an observation-command launch or a demonstrated security-manager failure.

Existing deprecation/ResourceLocation warnings are retained. Consumer :test
NO-SOURCE is not credited as an additional unit run. Its negative javac probe
returns 1 for the unavailable real host internal package as the existing check
requires; the consumer Gradle execution itself returns 0.

## Actual artifact identities and API boundary

Artifact-audit-01 retains original classpath.json, negative-import.json and
fixture-artifact.json plus the actual archive/class inventory. CRC/unique names,
selected publication hash, reobfuscation and fixture class scope are checked.
Normal/API/sources host archives contain no adapter-test classes. The separate
consumer fixture contains the two corrected SleepBoundary classes and does not
bundle host implementation or API classes. No artifact binary is archived here.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Normal runtime |6073913|0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011|
| API classifier |51052|aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b|
| Sources |2892005|7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a|
| Reobfuscated consumer fixture |191702|93194a0bb197b5051174d66f2f4ddcd58649fc0764d83b5da3ac0ab7aca600aa|

The complete independent Task 12 report is subsequently read by Root through
its Evidence paths section; its separately produced four artifact identities
match these actual Root values. Its reported 588/2192 and strict/log results are
not counted as another Root execution. Its final seal remains a distinct later
input/publication. Neither qualification launches that fixture in a packaged
observation server, or closes playerdata serialization/restart/client proof.

## Cleanup and failure preservation

CLEANUP-ATTEMPT-01.md/02.md preserve transcript-only first-attempt limitations.
No missing original raw stream or UTC is invented. Original failing helpers
are kept unchanged. Get-Process/Get-Command discovers the actual installed
MSIX PowerShell executable; no policy/configuration is changed. Native helper 02
via separately captured run_cleanup_03.py exits 0 at 05:50:15..05:50:18 UTC.
CLEANUP-02.json and cleanup-command-03 record every absolute target, containment,
ancestor/descendant reparse, empty process-overlap and post-delete check.

Only own checkout build/.gradle/run-data/compat-test-mod build/.gradle and own
leaf _tmp are removed. Source checkout, world sources, user caches, peers and
all retained results/receipts remain. No process is terminated by cleanup.
Independent source and regression reviewers' policy-denied retained outputs
are not adopted for Root deletion or retried here; their failures remain open.

## Evidence and unfinished acceptance

Reproducibility inputs are fixed commits, permission-task copies/hashes, build/
JDK/environment receipts, XML, native raw logs, consumer receipts, artifact/hash
inventories, strict receipt and original/corrected cleanup helpers/results.
No source/build/world/runtime export or binary copy is placed in evidence.
One-time SHA256SUMS.txt covers only safe own-leaf files, excluding itself;
temporary/build locations are never manifest entries. Old/failed cohorts remain.

Actual off-world sleep, dimension/spawn/time contract freeze, M1 neutral air
transition, M2 Space branch/access, B1/R1 exact cause/coexistence/indeterminate
failure behavior remain unfinished. All twenty simulated native rows, real TCP/
client/decoder, restart/death/prior world, six hosts/Space, inherited/custom/
cached receivers, monster/item-first/secondary mods, interpreted/JIT/development,
long-load/performance/GPU/multiplayer, asset/ledger/item and Required Gates stay
open. Existing Spawn records/global night skipping/migration/new respawn/hatch
O1/O2/O3 are not changed. No policy, schema/API, provenance, release or tag is made.

**Current/inherited Required Gates satisfied: no.** This qualification supplies
actual fixed-source short regression, not full sleep/B1/production acceptance.
Next v1.8 work is separately freezing/reviewing a bounded observation driver
against corrected source and resolving the already-recorded production
prerequisites before any actual-sleep implementation assignment.
