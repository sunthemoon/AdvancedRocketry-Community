# Corrected cleanup launch-location failure

run_cleanup_02.py returned tool exit 1 with FileNotFoundError / WinError 2 before
the native helper could start. It assumed the PowerShell 7 MSI location, which
is absent on this machine. cleanup-command-02/stdout.log and stderr.log are empty;
there is no command-result receipt. The Python failure remains in the tool
transcript, not a reconstructed native stderr or UTC receipt. No deletion or
native cleanup execution is claimed. This is a location-discovery failure, not
tool-policy denial. A subsequent read-only Get-Process/Get-Command probe identifies
the actual running MSIX PowerShell executable under WindowsApps. The unchanged
Cleanup-Owned-02.ps1 must run through that verified native executable with a
separately named complete capture; no shell or execution policy is changed.
