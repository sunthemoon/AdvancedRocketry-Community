"""Capture one corrected native PowerShell cleanup, without deletion in Python."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
argv = ["C:/Program Files/PowerShell/7/pwsh.exe", "-NoProfile", "-File", str(LEAF / "Cleanup-Owned-02.ps1")]
out = LEAF / "cleanup-command-02"
assert not out.exists()
out.mkdir()
record = {"argv": argv, "cwd": str(ROOT), "started_utc": datetime.now(timezone.utc).isoformat(),
          "timeout_seconds": 180, "helper_sha256": hashlib.sha256((LEAF / "Cleanup-Owned-02.ps1").read_bytes()).hexdigest()}
with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
    result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=180, check=False)
record.update(ended_utc=datetime.now(timezone.utc).isoformat(), exit=result.returncode,
              streams={name: {"bytes": (out / name).stat().st_size, "sha256": hashlib.sha256((out / name).read_bytes()).hexdigest()}
                       for name in ("stdout.log", "stderr.log")})
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
