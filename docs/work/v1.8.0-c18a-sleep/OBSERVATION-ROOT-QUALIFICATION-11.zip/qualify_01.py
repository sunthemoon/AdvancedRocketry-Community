"""One fixed-source verification command, with raw receipts and no implicit retry."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

LEAF = Path(__file__).resolve().parent
REPO = Path("D:/GitHub/arce-v180-sleep-observation-qualification-20261009")
SOURCE = "5b45132000ade1e3c8d130a6b8ccb29f07535124"
JAVA_HOME = "C:/Program Files/Java/jdk-17.0.7"
COMMANDS = {
    "build-01": ["clean", "build"], "test-01": ["test"],
    "data-01a": ["runData"], "data-01b": ["runData"],
    "publish-01": ["publishMavenJavaPublicationToLocalProjectRepositoryRepository", "--offline"],
    "consumer-01": ["-p", "compat-test-mod", "clean", "build", "-ParceVersion=1.20.1-1.8.0-dev", "--offline"],
}

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while data := stream.read(1024 * 1024):
            result.update(data)
    return result.hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO).decode("utf-8").strip()

name = sys.argv[1]
if name not in COMMANDS:
    raise SystemExit("Command not authorized by this pre-review runner")
out = LEAF / name
if out.exists():
    raise SystemExit(f"Refusing to replace cohort {out}")
assert git("rev-parse", "HEAD") == SOURCE
assert not git("status", "--short"), "Source checkout must be clean before command"
assert not any(os.environ.get(key) for key in ("_JAVA_OPTIONS", "JDK_JAVA_OPTIONS")), "Unfrozen JVM injection"
free = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
assert min(free.values()) >= 10 * 1024 ** 3, free
out.mkdir()
tmp = LEAF / "_tmp" / name
tmp.mkdir(parents=True)
env = dict(os.environ, JAVA_HOME=JAVA_HOME, TEMP=str(tmp), TMP=str(tmp),
           JAVA_TOOL_OPTIONS=f"-Djava.io.tmpdir={tmp.as_posix()} -Dfile.encoding=UTF-8")
env["PATH"] = JAVA_HOME + "/bin;" + env["PATH"]
argv = [str(REPO / "gradlew.bat"), "--no-daemon", "--no-build-cache", "--rerun-tasks", *COMMANDS[name]]
inputs = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat",
          "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties",
          "compat-test-mod/build.gradle", "compat-test-mod/settings.gradle",
          "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java",
          "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java"]
record = {"name": name, "source": SOURCE, "src_tree": git("rev-parse", "HEAD:src"),
          "argv": argv, "cwd": str(REPO), "started_utc": utc(), "timeout_seconds": 2400,
          "free_space_before": free, "environment": {key: env[key] for key in ("JAVA_HOME", "TEMP", "TMP", "JAVA_TOOL_OPTIONS")},
          "replaced_parent_java_tool_options": bool(os.environ.get("JAVA_TOOL_OPTIONS")),
          "java_executable_sha256": digest(Path(JAVA_HOME) / "bin/java.exe"),
          "jdk_release": (Path(JAVA_HOME) / "release").read_text(encoding="utf-8"),
          "inputs": [{"path": path, "bytes": (REPO / path).stat().st_size, "sha256": digest(REPO / path)} for path in inputs]}
with (out / "java-version.log").open("xb") as stream:
    version = subprocess.run([str(Path(JAVA_HOME) / "bin/java.exe"), "-version"], env=env,
                             stdout=stream, stderr=subprocess.STDOUT, timeout=30, check=False)
assert version.returncode == 0
record["java_version_exit"] = version.returncode
(out / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with (out / "command.log").open("xb") as stream:
    try:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=2400, check=False)
        record["exit"] = result.returncode
    except subprocess.TimeoutExpired:
        record["exit"] = "TIMEOUT"
record.update(ended_utc=utc(), source_after=git("rev-parse", "HEAD"),
              source_status_after=git("status", "--short"),
              free_space_after={drive: shutil.disk_usage(drive).free for drive in free},
              log_bytes=(out / "command.log").stat().st_size, log_sha256=digest(out / "command.log"))
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: record[key] for key in ("name", "source", "started_utc", "ended_utc", "exit", "source_status_after", "log_sha256")}), flush=True)
if name in ("build-01", "test-01"):
    paths = sorted((REPO / "build/test-results/test").glob("TEST-*.xml"))
    assert paths, "No just-run JUnit XML"
    assert sum(path.stat().st_size for path in paths) < 50 * 1024 * 1024
    dest = out / "junit"
    dest.mkdir()
    cases, inventory = [], []
    for path in paths:
        raw = path.read_bytes()
        cases.extend(ET.fromstring(raw).iter("testcase"))
        shutil.copyfile(path, dest / path.name)
        inventory.append({"path": "junit/" + path.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    junit = {"source": SOURCE, "xml_files": len(paths), "actual_cases": len(cases),
             "failures": sum(case.find("failure") is not None for case in cases),
             "errors": sum(case.find("error") is not None for case in cases),
             "skips": sum(case.find("skipped") is not None for case in cases), "files": inventory}
    (out / "JUNIT.json").write_text(json.dumps(junit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in junit.items() if key != "files"}), flush=True)
if name.startswith("data-"):
    for label, args in (("diff", ["diff", "--exit-code"]), ("status", ["status", "--short"])):
        with (out / (label + ".log")).open("xb") as stream:
            result = subprocess.run(["git", *args], cwd=REPO, stdout=stream, stderr=subprocess.STDOUT, timeout=180, check=False)
        print(json.dumps({"name": label, "argv": ["git", *args], "cwd": str(REPO), "exit": result.returncode,
                          "log_bytes": (out / (label + ".log")).stat().st_size}), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
raise SystemExit(0 if record["exit"] == 0 else 1)
