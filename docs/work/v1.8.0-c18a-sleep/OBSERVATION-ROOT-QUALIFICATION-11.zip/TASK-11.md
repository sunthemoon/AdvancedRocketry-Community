# Root passive observation qualification 11

Date: 2026-10-09 UTC. Executor/integrator: Root. This is a separate verification
assignment, not an expansion of source-worker compile-only permissions.

Fixed source: 5b45132000ade1e3c8d130a6b8ccb29f07535124, including additive
9f21a3daab7e6f3b38029742979a328306146fcf. Fixed governance checkpoint:
608f04360522f9aa2d1fdaab09d853d4cb4075f9. Root read the actual corrective diff;
the complete corrected independent source review is pending. Source candidate
is normally pushed and source-clean, not integrated or runtime-qualified.

Root-owned detached checkout:
D:/GitHub/arce-v180-sleep-observation-qualification-20261009.
Exclusive evidence/scratch:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-root-qualification-20261009-11/**.
Only own disposable checkout build/run-data/.gradle/compat-test-mod outputs may
be written additionally. No tracked source, author/reviewer/peer/sealed evidence,
Main index/HEAD, user AGENTS or source-world edits. Main integration/docs remain
a later separate Root action. No new source fix is silently made here.

## Finite commands and prerequisite

First verify exact source SHA, clean tracked/untracked source state, actor/class
scope, installed JDK 17.0.7 identity, wrapper/Gradle/Forge/build input hashes,
>=10 GiB on C: and D: and available memory. Set child TEMP/TMP/java.io.tmpdir to
this leaf's own scratch; record any frozen JVM environment. Trusted pinned
existing Gradle dependency resolution is allowed. Do not install or change a
tool/library/version. Preserve old source/test/cohort failures.

Authorized before final source review: forced clean build, explicit test, twice
runData followed by separate git diff --exit-code/status; local publication and
the existing independent API-only compat-test-mod clean build. Commands use
--no-daemon --no-build-cache --rerun-tasks, and the established offline local
publication/consumer recipe. Each command keeps the existing 2400-second ceiling.
Capture complete raw logs, argv/cwd/UTC/exit, before/after source state and disk,
actual JUnit XML/counts/failures/errors/skips and exact artifact/API/fixture identity.
Never replace a failed receipt or infer execution from a cached task.

The standard unfiltered runGameTestServer is authorized ONLY after Root has read
the complete fixed-candidate independent source review and resolved material
findings, and the above checks support launch. It uses the existing Gradle run
definition/namespaces, not a new external driver or sleep command, unchanged
2400-second ceiling, disk/memory/owned-process preflight and retained native
stdout/latest/debug/results. Native counts/log problems remain actual results,
not prefilled from the previous 579-test source. No filtered rerun substitutes
for this check. Strict repository check remains 180 seconds, not a passed link
report when it times out.

NOT authorized by this task: packaged observation driver, the twenty-case console
command, a novel launcher/parser, real TCP/client, long-load/remote/GPU, prior
world/restart/death, off-world natural/spawn/time/air policy, StackWalker
enforcement, owner ancillary/gap/hatch choices or Gate acceptance. Driver/parser
freeze, review and finite runtime require later explicit assignments.

## Retention, cleanup and report

Compact receipts/logs/results/XML/artifact hashes only, no whole source/build/
world/runtime archive. Preserve all failed setup/actions and distinguish tests
from native simulated transport. No source/full-item/ledger delivery is inferred.
After own processes/readers finish, enumerate and containment/reparse/process-
check only Root-created disposable outputs; use native PowerShell -LiteralPath
cleanup and retain logs/results/input manifests. Do not remove source checkout
or peer paths, retry denied cleanup through another shell, or overwrite seals.
Report actual commands/results/evidence/scope/known risks and all unfinished
B1/R1/M1/M2/D1, owner question, asset/item/client/performance and Required Gates.
Do not seal before final evidence inspection, and do not mark v1.8 complete.
