$ErrorActionPreference = 'Stop'
$root = 'D:\GitHub\arce-v180-sleep-observation-qualification-20261009'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-observation-root-qualification-20261009-11'
$receipt = Join-Path $leaf 'CLEANUP-02.json'
if (Test-Path -LiteralPath $receipt) { throw 'Refusing to replace cleanup receipt' }
$started = [DateTime]::UtcNow.ToString('o')
$targets = @(
    (Join-Path $root 'build'), (Join-Path $root '.gradle'), (Join-Path $root 'run-data'),
    (Join-Path $root 'compat-test-mod\build'), (Join-Path $root 'compat-test-mod\.gradle'),
    (Join-Path $leaf '_tmp')
)
$processes = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and
    ($_.CommandLine.IndexOf($root, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
     $_.CommandLine.IndexOf($root.Replace('\','/'), [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
     $_.CommandLine.IndexOf((Join-Path $leaf '_tmp'), [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
     $_.CommandLine.IndexOf((Join-Path $leaf '_tmp').Replace('\','/'), [StringComparison]::OrdinalIgnoreCase) -ge 0)
} | Select-Object ProcessId, ParentProcessId, Name, CommandLine)
if ($processes.Count -ne 0) { throw 'Live process overlap; cleanup not attempted' }
$checks = @()
foreach ($target in $targets) {
    $absolute = [IO.Path]::GetFullPath($target)
    $allowed = $absolute.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase) -or
               $absolute -eq (Join-Path $leaf '_tmp')
    if (-not $allowed -or $absolute -eq $root -or $absolute -eq $leaf) {
        throw "Target outside exact assigned output scope: $absolute"
    }
    $ancestor = $absolute
    while ($ancestor) {
        if (Test-Path -LiteralPath $ancestor) {
            $item = Get-Item -LiteralPath $ancestor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Reparse ancestor: $ancestor"
            }
        }
        $parent = [IO.Path]::GetDirectoryName($ancestor)
        if ($parent -eq $ancestor) { break }
        $ancestor = $parent
    }
    $files = @()
    if (Test-Path -LiteralPath $absolute) {
        $children = @(Get-ChildItem -LiteralPath $absolute -Force -Recurse)
        if (@($children | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count) {
            throw "Reparse child: $absolute"
        }
        $files = @($children | Where-Object { -not $_.PSIsContainer })
    }
    $bytes = ($files | Measure-Object -Property Length -Sum).Sum
    $checks += [pscustomobject]@{ target = $absolute; existed = (Test-Path -LiteralPath $absolute);
        files_before = $files.Count; bytes_before = [long]$bytes; containment_reparse_checked = $true }
}
foreach ($check in $checks) {
    if ($check.existed) { Remove-Item -LiteralPath $check.target -Recurse -Force }
    $check | Add-Member -NotePropertyName absent_after -NotePropertyValue (-not (Test-Path -LiteralPath $check.target))
    if (-not $check.absent_after) { throw "Owned output remains: $($check.target)" }
}
[pscustomobject]@{ started_utc = $started; ended_utc = [DateTime]::UtcNow.ToString('o');
    targets = $checks; process_overlap = $processes; process_termination = $false;
    peer_cleanup = $false; source_worktree_removed = $false } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $receipt -Encoding UTF8
Get-Content -LiteralPath $receipt -Raw
