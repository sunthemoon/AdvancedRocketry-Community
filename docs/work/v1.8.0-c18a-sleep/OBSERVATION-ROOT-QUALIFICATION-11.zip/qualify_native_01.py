"""Run only activated standard, unfiltered GameTest regression on a fixed source."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

LEAF = Path(__file__).resolve().parent
REPO = Path("D:/GitHub/arce-v180-sleep-observation-qualification-20261009")
SOURCE = "5b45132000ade1e3c8d130a6b8ccb29f07535124"
JAVA = Path("C:/Program Files/Java/jdk-17.0.7")
TASK = LEAF.parent / "SLEEP-OBSERVATION-STANDARD-GAMETEST-ACTIVATION-13.md"
REVIEW = LEAF.parent / "sleep-observation-source-independent-20261009-06/REPORT.md"

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO).decode("utf-8").strip()

assert digest(TASK) == "c517b1017e3f0a40d34a57c0a967c0501584972c176698fda49f7def9b644825"
assert digest(REVIEW) == "3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0"
assert git("rev-parse", "HEAD") == SOURCE and not git("status", "--short")
assert not any(os.environ.get(key) for key in ("_JAVA_OPTIONS", "JDK_JAVA_OPTIONS"))
for name in ("build-01", "test-01", "data-01a", "data-01b"):
    result = json.loads((LEAF / name / "RESULT.json").read_text(encoding="utf-8"))
    assert result["source"] == SOURCE and result["exit"] == 0 and not result["source_status_after"]
    assert result["log_sha256"] == digest(LEAF / name / "command.log")
for name in ("data-01a", "data-01b"):
    assert not (LEAF / name / "diff.log").read_bytes()
    assert not (LEAF / name / "status.log").read_bytes()
free = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
assert min(free.values()) >= 10 * 1024 ** 3
out = LEAF / "native-01"
assert not out.exists()
out.mkdir()
tmp = LEAF / "_tmp/native-01"
tmp.mkdir(parents=True)
env = dict(os.environ, JAVA_HOME=str(JAVA), TEMP=str(tmp), TMP=str(tmp),
           JAVA_TOOL_OPTIONS=f"-Djava.io.tmpdir={tmp.as_posix()} -Dfile.encoding=UTF-8")
env["PATH"] = str(JAVA / "bin") + ";" + env["PATH"]
argv = [str(REPO / "gradlew.bat"), "--no-daemon", "--no-build-cache", "--rerun-tasks", "runGameTestServer"]
preflight_argv = ["powershell.exe", "-NoProfile", "-Command",
                 "Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize | ConvertTo-Json; "
                 "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(java|javaw)\\.exe$' } | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Depth 4"]
with (out / "process-memory-preflight.log").open("xb") as stream:
    preflight = subprocess.run(preflight_argv, stdout=stream, stderr=subprocess.STDOUT, timeout=30, check=False)
assert preflight.returncode == 0
inputs = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew.bat",
          "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties",
          "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java",
          "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java"]
record = {"source": SOURCE, "src_tree": git("rev-parse", "HEAD:src"), "argv": argv,
          "cwd": str(REPO), "started_utc": utc(), "timeout_seconds": 2400,
          "free_space_before": free, "environment": {key: env[key] for key in ("JAVA_HOME", "TEMP", "TMP", "JAVA_TOOL_OPTIONS")},
          "activation_sha256": digest(TASK), "sealed_source_review_sha256": digest(REVIEW),
          "java_executable_sha256": digest(JAVA / "bin/java.exe"),
          "process_memory_preflight_argv": preflight_argv,
          "process_memory_preflight_log_sha256": digest(out / "process-memory-preflight.log"),
          "inputs": [{"path": name, "bytes": (REPO / name).stat().st_size, "sha256": digest(REPO / name)} for name in inputs]}
(out / "COMMAND.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with (out / "command.log").open("xb") as stream:
    try:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=2400, check=False)
        record["exit"] = result.returncode
    except subprocess.TimeoutExpired:
        record["exit"] = "TIMEOUT"
record.update(ended_utc=utc(), source_after=git("rev-parse", "HEAD"), source_status_after=git("status", "--short"),
              free_space_after={drive: shutil.disk_usage(drive).free for drive in free},
              log_bytes=(out / "command.log").stat().st_size, log_sha256=digest(out / "command.log"))
inventory = []
for relative in ("build/gametest/logs/latest.log", "build/gametest/logs/debug.log", "build/gametest-results.xml"):
    source = REPO / relative
    if source.is_file():
        assert source.stat().st_size < 50 * 1024 ** 2
        target = out / relative.replace("/", "_")
        shutil.copyfile(source, target)
        inventory.append({"path": target.name, "source_path": relative, "bytes": target.stat().st_size, "sha256": digest(target)})
record["retained_native_files"] = inventory
(out / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: record[key] for key in ("source", "started_utc", "ended_utc", "exit", "source_status_after", "log_sha256", "retained_native_files")}), flush=True)
raise SystemExit(0 if record["exit"] == 0 else 1)
