# Standard unfiltered regression activation 13

Date: 2026-10-09 UTC. Integrator: Root. This activates only the conditional
standard GameTest command in Tasks 11 and 12 for immutable source
5b45132000ade1e3c8d130a6b8ccb29f07535124.

Root read the complete independent source REPORT.md snapshot at
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-independent-20261009-06/REPORT.md:
19054 bytes, SHA-256 20338d51cf83027a24609127a79e480e0fc965a5a29e17a6a1eedb0f63d4e860.
It retains F01/F02 in both old candidates and identifies their actual source
corrections at the fixed revision, with no remaining material finding in the
explicitly narrowed source stage. All three independent compiles return 0.
The nine source GameTest methods were not executed by that review. Final seal
may update report status/retention wording; its actual digest is a later record,
not silently substituted for this read snapshot. Source identity stays fixed.

Root adopts those two source corrections for standard development regression,
not gameplay/driver/Gate approval. Each executor must read the full source
review, verify fixed clean source and its own build/DataGen prerequisites,
>=10 GiB disk/memory/own process conditions, then run only the existing
unfiltered runGameTestServer definition/namespaces with
--no-daemon --no-build-cache --rerun-tasks. The unchanged per-command ceiling is
2400 seconds; native output/counts/errors are observed, not prefilled. Preserve
all failures and source/JDK/argv/cwd/UTC/exits/raw stdout/latest/debug/results.
No filtered or assertion-weakened rerun substitutes for it.

This DOES NOT authorize the twenty-case console command, a packaged observation
driver/parser/launcher, real clients/TCP, restart/death/old worlds, off-world
dimension/spawn/time/air changes, production StackWalker enforcement, owner
policy, cleanup of policy-denied peer trees, Gate/item/ledger/delivery approval
or v1.8 completion. Those remain separate unfinished assignments/decisions.
