"""Audit compact actual receipts and make one immutable leaf-relative seal."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

LEAF = Path(__file__).resolve().parent
EXTERNAL = LEAF.parent
REPO = Path("D:/GitHub/arce-v180-sleep-observation-qualification-20261009")
SOURCE = "5b45132000ade1e3c8d130a6b8ccb29f07535124"

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

assert not (LEAF / "SHA256SUMS.txt").exists()
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip() == SOURCE
assert not subprocess.check_output(["git", "status", "--short"], cwd=REPO).strip()
for number, source_name, expected in (
    (11, "SLEEP-OBSERVATION-ROOT-QUALIFICATION-TASK-11.md", "53e3de1d5f2f297741f65e9e394e350e43ad1574fe37b283a2df6ad1ee35756b"),
    (13, "SLEEP-OBSERVATION-STANDARD-GAMETEST-ACTIVATION-13.md", "c517b1017e3f0a40d34a57c0a967c0501584972c176698fda49f7def9b644825"),
):
    path = EXTERNAL / source_name
    assert digest(path) == expected
    dest = LEAF / f"TASK-{number}.md"
    assert not dest.exists()
    shutil.copyfile(path, dest)
checks = []
for name in ("build-01", "test-01", "data-01a", "data-01b", "native-01", "publish-01", "consumer-01"):
    value = json.loads((LEAF / name / "RESULT.json").read_text(encoding="utf-8"))
    assert value["source"] == SOURCE and value["exit"] == 0 and not value["source_status_after"]
    assert digest(LEAF / name / "command.log") == value["log_sha256"]
    assert min(value["free_space_before"].values()) >= 10 * 1024 ** 3
    checks.append(name)
    if name in ("build-01", "test-01"):
        junit = json.loads((LEAF / name / "JUNIT.json").read_text(encoding="utf-8"))
        cases = []
        for entry in junit["files"]:
            path = LEAF / name / entry["path"]
            assert path.stat().st_size == entry["bytes"] and digest(path) == entry["sha256"]
            cases.extend(ET.fromstring(path.read_bytes()).iter("testcase"))
        assert len(cases) == junit["actual_cases"]
        for tag, key in (("failure", "failures"), ("error", "errors"), ("skipped", "skips")):
            assert sum(case.find(tag) is not None for case in cases) == junit[key] == 0
strict = json.loads((LEAF / "strict-01/RESULT.json").read_text(encoding="utf-8"))
assert strict["source"] == SOURCE and strict["timeout_seconds"] == 180 and strict["exit"] == "TIMEOUT"
for name, entry in strict["streams"].items():
    assert digest(LEAF / "strict-01" / name) == entry["sha256"]
cleanup = json.loads((LEAF / "CLEANUP-02.json").read_text(encoding="utf-8-sig"))
assert not cleanup["process_overlap"] and not cleanup["process_termination"] and not cleanup["peer_cleanup"]
assert all(entry["absent_after"] and not Path(entry["target"]).exists() for entry in cleanup["targets"])
assert not (LEAF / "_tmp").exists()
audit = {"checked_utc": datetime.now(timezone.utc).isoformat(), "source": SOURCE,
         "receipt_checks": checks, "junit_xml_hashes_and_cases_verified": True,
         "strict_timeout_preserved": True, "owned_cleanup_targets": cleanup["targets"],
         "peer_retention_not_cleaned": True, "no_gameplay_or_gate_approval": True}
(LEAF / "PRESEAL-AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
paths = []
for path in LEAF.rglob("*"):
    assert not path.is_symlink() and not (getattr(path.lstat(), "st_file_attributes", 0) & 0x400)
    if path.is_file():
        assert path.stat().st_size < 50 * 1024 ** 2
        paths.append(path)
assert sum(path.stat().st_size for path in paths) < 100 * 1024 ** 2
names = [path.relative_to(LEAF).as_posix() for path in paths]
assert len(names) == len(set(name.casefold() for name in names)) and "REPORT.md" in names
assert all(not name.startswith("/") and ".." not in Path(name).parts and ":" not in name and "\\" not in name for name in names)
manifest = LEAF / "SHA256SUMS.txt"
with manifest.open("x", encoding="utf-8", newline="\n") as stream:
    for path in sorted(paths, key=lambda item: item.relative_to(LEAF).as_posix()):
        stream.write(digest(path) + "  " + path.relative_to(LEAF).as_posix() + "\n")
for line in manifest.read_text(encoding="utf-8").splitlines():
    expected, name = line.split("  ", 1)
    assert digest(LEAF / name) == expected
print(json.dumps({"covered_files": len(paths), "covered_bytes": sum(path.stat().st_size for path in paths),
                  "report_sha256": digest(LEAF / "REPORT.md"), "manifest_sha256": digest(manifest)}), flush=True)
