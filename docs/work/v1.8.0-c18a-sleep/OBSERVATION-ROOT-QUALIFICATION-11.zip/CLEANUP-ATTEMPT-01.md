# Initial owned-output cleanup preparation failure

The tool invocation of Cleanup-Owned-01.ps1 from Main returned exit 1:
`Split-Path -LiteralPath $ancestor -Parent` at line 36 has an incompatible
PowerShell parameter set. The complete failure remains in the Root tool
transcript; it was not separately redirected before launch. No original raw
file or precise start/end UTC is reconstructed here. Failure occurred during
the first target's ancestor validation, before the deletion loop or receipt
write. No deletion or cleanup success is claimed. This was a script parameter
error, not a tool-policy denial. The original helper remains unchanged; a new
separately named native PowerShell helper uses System.IO.Path parent resolution
and must record its actual streams/UTC/exit independently.
