# Proposed M1/M2 corrections to sleep contract 01

Status: **PROPOSED research text, not frozen, approved, implemented or qualified.**
Baseline: `46c566dd7000d9fcd29c985d23100d8c04891eaf`, Java 17,
Minecraft 1.20.1 / Forge 47.4.10. These are precise replacements/additions to
`docs/work/v1.8.0-c18a-sleep/PROPOSED-CONTRACT-01.md`, not a new spawn/time policy.

## A. Replace the identity/access paragraphs in sections 3 and 4

Use one private, per-server sleep eligibility projection for admission and
continued sleep. Its conceptual results are `HOST_UNAVAILABLE`,
`CELL_UNAVAILABLE`, `ACCESS_UNAVAILABLE`, `ACCESS_DENIED`, `PENDING`,
`NON_BREATHABLE`, or `ELIGIBLE`; these names are proposed internal outcomes,
not additions to the public API or network. Projection state is transient.

1. Before catalog, station, Level or atmosphere queries, require the installed
   owning server thread and non-reentrant operation, the exact connected living
   nonspectating real ServerPlayer, its real connection, and the actual loaded
   server Level object. FakePlayer, removed/replaced/disconnected actors and
   stale Level bindings are unavailable. Never infer authority from a client,
   suit, creative immunity or a previous successful sleep.
2. Capture the active immutable celestial catalog. Require a supported packaged
   actual Level key and exactly one current definition mapped to it, with the
   expected supported host body ID and valid atmosphere definition. The six
   proposed supported hosts remain Moon, Space, Mars, Venus, Tau Ceti f and
   Tau Ceti g; this adds no custom host or Overworld sleep interception. Missing,
   ambiguous or substituted host/profile identity is unavailable even if a
   vent previously supplied the cell. For Space require the actual fixed Space
   host, not the station's orbit body. Do not change global BodyContextResolver
   precedence, create a SURFACE context for a Space gap, or alter analyzer/API
   behavior to implement this private projection.
3. Construct cells from finite server-owned coordinates. Require spawnable,
   build-height and world-border bounds and a currently loaded full chunk at
   every sampled cell before the manager call. Deriving a bed target also
   requires the loaded native bed halves and supported FACING/PART identity;
   no loading getChunk fallback is permitted. Invalid geometry or unsupported
   eye-height/bed integration is unavailable rather than a guessed cell.
4. On supported surfaces the actual host identity is required; station-orbit
   identity is not relevant. In actual Space first require the existing
   StationRegistrySavedData to be operational. A missing/unavailable/blocked
   registry is ACCESS_UNAVAILABLE, **not** an operational empty registry.
   Use the existing `operational()` read-authority boundary; do not silently
   substitute `updatesAvailable()` (checked-write quarantine is a separate
   mechanism) or infer readiness from `findAt().isEmpty()`.
5. For each distinct sampled Space cell do one committed `findAt(x,z)`. If a
   committed station contains that cell, require live VISIT through the existing
   access service with the real player UUID and existing operator semantics.
   Invitations alone grant no VISIT. If none exists in an operational registry,
   classify the cell as an operational gap with no station authority to bypass.
   Reserved-only cells are not committed stations. Query current state each
   decision, not an admission-time retained membership snapshot.
6. The candidate gap-allowing rule permits a loaded supplied breathable cell
   outside every committed station region. It grants neither ownership nor
   exemption from independently applicable adrift/safety-return/travel rules.
   Actual Space air is obtained only from the actual host and the existing
   manager's authoritative supplied-volume mechanism. A station's vacuum flag,
   orbit body's surface air, optional orbit label, or HUD is never air authority.
7. Only `AtmosphereManager.breathabilityAt(actualLevel, cell) == BREATHABLE`
   satisfies air. PENDING and all nonbreathable/unavailable outcomes refuse or
   wake. The sleep projection does not create a scan, provide oxygen, alter
   exposure, or debit a second resource bank. If captured server/catalog
   bindings change before the decision is returned, return unavailable.

Admission uses the actual entry eye cell and native intended sleeping eye cell
at the normalized bed head, deduplicating equal cells. **Both** get the same
host, loaded-cell, Space-registry, region/access and air projection, even when
on opposite sides of a station edge or in different stations. Authorizing only
the player's entry station or only the head station is insufficient. This is
at most two air lookups and two indexed station lookups, never a station search
or room scan. Native interaction/cancellation, distance, obstruction, occupied
bed, monster and time behavior remain in force. Normalizing either clicked
half must yield the same head and intended sample; this projection does not
silently change other mods' interaction/bed-footprint permission policies.

During actual sleep the same projection uses the **actual current eye cell**,
not entry position, historical station or `getSleepingLocation()` as an
unchecked coordinate. At most one air and one indexed station lookup per
sleeping-player check. On any required unavailable/denied/pending/nonbreathable
result, use the normal native wake path on the first native check after that
authoritative result exists. Do not pollute time admission with a forced ALLOW.

Station-orbit BodyContext is optional descriptive information in this proposed
projection, not required actual-host identity. Its absence in an operational
Space gap is valid. Loss of only an optional orbit label/body reference is not
by itself an air/access loss; any real host/profile loss or live permission
loss still wakes. Deleting a committed region can change the cell to an
operational gap; under this **proposed** gap rule it need not wake if host and
air remain eligible, and independently applicable safety return still acts.
A registry becoming blocked never performs that transition. No missing orbit
reference is erased, repaired or replaced with Earth by this slice.

Replace section 4's broad "missing context" test with "unavailable required
actual-host/profile or Space-registry/access projection". Test disappearance of
required identity separately from removal of optional orbit presentation.

**Product alternative, not selected:** station-only Space sleep could instead
require a committed accessible station and a valid orbit context at both
samples and continued sleep. That rejects supplied gap rooms and changes
region-deletion/missing-orbit behavior. It requires an explicit contract/product
disposition; it is not an implementation fallback. A requirement to authorize
the whole bed footprint, beyond the two specified air samples, also needs an
explicit bounded access rule rather than an accidental clicked-half rule.

## B. Add an occupancy/atmosphere feasibility prerequisite to sections 4 and 8

Native ordinary sleep changes BedBlock.OCCUPIED through a real setBlock call
with neighbor notifications. The current installed atmosphere adapter can
synchronously revoke the supplied air that admitted the attempt, independently
of any genuine leak. Nearby doors can cause the same revocation with an empty
external catalog. Larger/contended scans cannot be assumed to repair before
the next player wake check. Source evidence is not a runtime timing result.

Also inspect the installed pre-admission RightClickBlock listener: native
useItemOn posts it before BedBlock.use, head normalization and sleep admission.
Only a door-like or exactly registered clicked BlockState is dirtied there,
even if that registered state's compiled classification is DEFAULT. An unrelated
nonempty catalog does not alone dirty an unregistered bed at RightClickBlock.
NeighborNotify separately dirties the changed position for any nonempty catalog
and marks notified loaded adjacent door-like cells even with an empty catalog.
Qualification must preserve this phase/condition distinction; the interaction
event is not an authenticated paired end of a successful native bed operation.

Before assigning the default sleep implementation, qualify normal connected
player bed use through the installed manager and event wiring, with empty and
nonempty compiled boundary catalogs, head/foot interactions, near/far doors,
both OCCUPIED directions, small and multi-pass rooms, and reference-load
contention. Observe service publication, actual player pose/eye/counter, dirty
and scan metrics, and finite vent oxygen/FE/phase. Do not test only a direct
start call or a newly fabricated empty-catalog manager.

If rest is interrupted, an integration-owned correction needs an independently
reviewed **exact public transition/cause boundary**. The current
NeighborNotifyEvent's current state/position/directions are not sufficient
proof of an OCCUPIED-only mutation. An exemption must prove all of:

- authentic bounded before/after native state identity, both affected bed
  halves, and a properly terminated operation including failure/exception/wake;
- unchanged effective atmosphere classification under the actual tag/door/
  compiled-provider/fluid/collision precedence and catalog generation;
- no missed neighbor-induced door/provider or other topology change, including
  OPEN changes performed without a new notify bit after the observed event;
- retained immediate revocation and cancellation for every genuine or unknown
  loss, in-flight/completed-result invalidation, and overflow/reload/unload;
- no restoring a revoked volume from an old snapshot, no ignore-PENDING or
  blanket grace interval, no provider callback in a tick, no public API change,
  new NBT store, raised scan/cache/queue/debit budget or skipped native occupancy.

A current bed state, equal hypothetical occupied/unoccupied classification,
same position, sleeping UUID flag, or "the nearby door is still closed" is not
sufficient evidence alone. A provider may deliberately make OCCUPIED affect
permeability; that is a real boundary change and must revoke authority.
The existing measurement-item invalidation exemption does not authorize a bed
interaction exemption: native sleep is not a non-mutating item-only read.

No safe transition recognizer is supplied or authorized by this correction.
If the public boundary cannot be established, preserve fail-closed behavior
and keep this sleep prerequisite open. Return scoped alternatives for review;
do not ship a blanket bed/door exclusion, custom sleeping bypass, global delay,
AT/reflection/coremod, or enlarged budget as an implicit repair.

## C. Proposed additional qualification cases (all unexecuted)

| ID | Fixture/action | Evidence to collect |
|---|---|---|
| M1-01 | Installed empty/unrelated-nonempty/registered-bed catalogs including registered DEFAULT; ordinary head and foot use; no nearby door versus each notified side | distinct pre-admission RightClick versus occupancy NeighborNotify conditions, actual authority publication order, pose, eye, counter; no synthetic manager substitute |
| M1-02 | Small and multi-pass permitted rooms; competing vents/scans; insufficient native quorum to retain a sleeper beyond deep sleep | next native check versus service END/repair; scan inspections/jobs/cells/dirty counts within unchanged caps |
| M1-03 | Native leave-bed/time/quorum/air-loss wake, both OCCUPIED directions and paired half shape updates | native occupancy and synchronization; no recurring self-invalidation or cached operation leak |
| M1-04 | Real wall/door/provider/supply loss interleaved with rest; redstone door OPEN update after its neighbor event; same bed state reached by wall replacement | immediate revocation; no current-state-only exemption or stale completed-result publication |
| M1-05 | OCCUPIED-sensitive compiled rule on a bed, unrelated nonempty rule, sealing/permeable tags, provider/tag reload, unloaded opposite half/provider | genuine changes never treated as neutral; no force load/callback/old-generation authorization |
| M1-06 | Dirty backlog/overflow, in-flight and unconsumed completed scan, normal/exceptional/canceled/reentrant native operation | all original ADR-024 revocation guarantees and bounded lifecycle cleanup retained |
| M2-01 | Each six packaged actual hosts; missing/ambiguous/substituted mapping/profile with an old supplied room | same admission/continued projection; no vent or orbit atmosphere substitutes host identity |
| M2-02 | Operational Space gap with valid supply; ordinary vacuum gap; blocked/future/corrupt/unavailable registry with apparently empty findAt | gap versus unavailable distinguished; air refusal/wake; no implicit operational recovery |
| M2-03 | Entry-eye/head-eye station/gap and gap/station combinations; two stations with different access; boundary and negative coordinates, both clicked halves | VISIT at both distinct admission samples; normalization independent of clicked half; one actual-eye continued sample |
| M2-04 | Remove member/invitation-only actor/operator; change committed region; delete station while room remains; only orbit body/label removed | required access/host loss versus optional orbit loss distinguished according to the reviewed product disposition |
| M2-05 | Ambient breathable host but unloaded sample; unsupported eye-height extension, chunk edge, saved restart/reconnect | loaded full-cell preflight before manager; zero new chunks/tickets; unknown compatibility does not guess |

All original S01-S21/R01-R02 requirements and B1/D1 prerequisites remain. These
new cases neither prove the spawn cause discriminator nor select the dimension,
spawn, compass, portal or time policy. Implementation must still execute the
version commands and affected finite packaged/restart/security checks; later
V1/V2 and full-load evidence remain governed by the existing scheduling rules.
