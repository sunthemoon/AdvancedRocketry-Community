"""Bounded read-only fixed Git/primary inspection for task 02; no runtime launch."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

LEAF = Path(__file__).resolve().parent
REPO = Path(r"D:\GitHub\AdvancedRocketry-Community")
SHA = "46c566dd7000d9fcd29c985d23100d8c04891eaf"
PARENT = Path(r"D:\GitHub\ARCE-Task-Evidence\v1.8.0")
MAPPED = Path(r"C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
FORGE = Path(r"C:\Users\Administrator\.gradle\caches\forge_gradle\maven_downloader\net\minecraftforge\forge\1.20.1-47.4.10\forge-1.20.1-47.4.10-sources.jar")
JAVAP = Path(r"C:\Program Files\Java\jdk-17.0.7\bin\javap.exe")
LOG = LEAF / "commands.jsonl"
PREFIX = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record(action: str, code: int, **kwargs: object) -> None:
    with LOG.open("a", encoding="utf-8") as out:
        out.write(json.dumps({"utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                              "action": action, "exit_code": code, **kwargs}) + "\n")


def run(argv: list[str]) -> bytes:
    begin = dt.datetime.now(dt.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=45)
    record(subprocess.list2cmdline(argv), result.returncode, argv=argv, start_utc=begin,
           cwd=str(REPO), stdout_bytes=len(result.stdout), stdout_sha256=digest(result.stdout),
           stderr_bytes=len(result.stderr), stderr_sha256=digest(result.stderr),
           stderr=result.stderr.decode("utf-8", errors="replace"))
    if result.returncode:
        raise RuntimeError(f"command failed ({result.returncode}): {argv}")
    return result.stdout


def read(path: Path) -> bytes:
    data = path.read_bytes()
    record("read", 0, path=str(path), bytes=len(data), sha256=digest(data))
    return data


def write(name: str, data: str) -> None:
    path = LEAF / name
    if not path.resolve().is_relative_to(LEAF.resolve()):
        raise RuntimeError("output outside own leaf")
    path.write_text(data, encoding="utf-8", newline="\n")


def blob(path: str) -> tuple[str, dict[str, object]]:
    data = run(["git", "show", SHA + ":" + path])
    return data.decode("utf-8-sig"), {"path": path, "bytes": len(data), "sha256": digest(data)}


def inputs() -> None:
    audit: dict[str, object] = {"fixed_commit": SHA, "seals": [], "fixed_blobs": []}
    for dirname in ("sleep-contract-independent-20261009-01", "sleep-contract-research-20261009-01"):
        root = PARENT / dirname
        manifest = read(root / "SHA256SUMS.txt")
        rows = []
        for line in manifest.decode("utf-8-sig").splitlines():
            if not line.strip():
                continue
            expected, name = line.split(maxsplit=1)
            path = (root / name.lstrip("*")).resolve()
            if not path.is_relative_to(root.resolve()):
                raise RuntimeError("uncontained input seal")
            data = read(path)
            rows.append({"path": name, "bytes": len(data), "expected": expected,
                         "actual": digest(data), "matches": expected.lower() == digest(data)})
        if not all(row["matches"] for row in rows):
            raise RuntimeError("input seal mismatch")
        audit["seals"].append({"leaf": dirname, "manifest_sha256": digest(manifest), "entries": rows})
    read(PARENT / "SLEEP-AIR-FEASIBILITY-TASK-02.md")
    governance = [
        "AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md",
        "docs/04-VERSION-ROADMAP.md", "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md",
        "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
        "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
        "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
        "docs/decisions/ADR-003-ATMOSPHERE-BUDGET.md",
        "docs/decisions/ADR-008-SHARED-SPACE-STATION-REGIONS.md",
        "docs/decisions/ADR-014-TRAVEL-TARGET-ROUTES-BODY-CONTEXT.md",
        "docs/decisions/ADR-041-STATION-ORBIT-ENVIRONMENT.md",
        "docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md",
        "docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md",
        "docs/status/CURRENT_VERSION.md", "docs/status/GATE_STATUS.md",
        "docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-01.md",
        "docs/work/v1.8.0-c18a-sleep/PROPOSED-CONTRACT-01.md",
    ]
    for n, path in enumerate(governance):
        data, item = blob(path)
        audit["fixed_blobs"].append(item)
        write(f"_tmp/governance-{n:02}.txt", f"# {SHA}:{path}\n" + data)
    paths = run(["git", "ls-tree", "-r", "--name-only", SHA, "--", PREFIX]).decode("utf-8").splitlines()
    pattern = (r"atmosphere/(server/|scan/|life/VentSupply|AtmosphereLimits|content/Airlock|vent/)|"
               r"compat/atmosphere/AtmosphereBoundary|compat/api/.*Boundary|"
               r"celestial/(context/|service/Celestial(Environment|Catalog))|"
               r"station/(service/StationAccess|model/StationRegistry|model/StationRegion|"
               r"persistence/StationRegistrySavedData|orbit/StationRegionBodyContextResolver)")
    selected = [path for path in paths if re.search(pattern, path)]
    sections = []
    for path in selected:
        data, item = blob(path)
        audit["fixed_blobs"].append(item)
        sections.append(f"\n## {path}\n" + "\n".join(f"{i+1}: {line}" for i, line in enumerate(data.splitlines())))
    write("fixed-source.txt", "\n".join(sections) + "\n")
    write("INPUT-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"seals": [{"leaf": s["leaf"], "count": len(s["entries"])} for s in audit["seals"]],
                      "fixed_blobs": len(audit["fixed_blobs"]), "source_files": len(selected)}))


def native() -> None:
    classes = {
        "net.minecraft.world.entity.LivingEntity": ["startSleeping", "stopSleeping", "setPosToBed", "checkBedExists"],
        "net.minecraft.world.entity.player.Player": ["tick()", "startSleepInBed", "stopSleepInBed"],
        "net.minecraft.world.level.block.BedBlock": ["use(", "updateShape", "getShape"],
        "net.minecraft.world.level.Level": ["setBlock(", "markAndNotifyBlock"],
        "net.minecraft.world.level.chunk.LevelChunk": ["setBlockState"],
        "net.minecraft.server.level.ServerLevel": ["blockUpdated", "updateNeighborsAt", "tick("],
        "net.minecraftforge.common.extensions.IForgeBlock": ["setBedOccupied"],
        "net.minecraftforge.event.ForgeEventFactory": ["onNeighborNotify", "fireSleepingTimeCheck"],
    }
    events = ["net/minecraftforge/event/level/BlockEvent.java",
              "net/minecraftforge/event/entity/player/SleepingTimeCheckEvent.java",
              "net/minecraftforge/common/extensions/IForgeBlock.java",
              "net/minecraftforge/common/extensions/IForgeBlockState.java"]
    audit: dict[str, object] = {"primary_files": [], "primary_entries": [], "bounds":
                              {"class_count": len(classes), "entry_bytes_max": 2 * 1024 * 1024,
                               "subprocess_timeout_seconds": 45}}
    for path in (MAPPED, FORGE, JAVAP):
        data = read(path)
        audit["primary_files"].append({"path": str(path), "bytes": len(data), "sha256": digest(data)})
    native_sections = []
    with zipfile.ZipFile(MAPPED) as archive:
        for cls, selectors in classes.items():
            entry = cls.replace(".", "/") + ".class"
            if archive.getinfo(entry).file_size > 2 * 1024 * 1024:
                raise RuntimeError("class ceiling exceeded")
            data = archive.read(entry)
            audit["primary_entries"].append({"jar": "mapped", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            output = run([str(JAVAP), "-classpath", str(MAPPED), "-p", "-c", cls]).decode("utf-8").replace("\r\n", "\n")
            chunks = re.split(r"(?=^  (?:public|protected|private|static).*[;{]$)", output, flags=re.MULTILINE)
            for chunk in chunks:
                header = chunk.splitlines()[0] if chunk.splitlines() else ""
                if any(selector in header for selector in selectors):
                    native_sections.append(f"\n## {cls}\n{chunk}")
    event_sections = []
    with zipfile.ZipFile(FORGE) as archive:
        for entry in events:
            if archive.getinfo(entry).file_size > 2 * 1024 * 1024:
                raise RuntimeError("event ceiling exceeded")
            data = archive.read(entry)
            audit["primary_entries"].append({"jar": "sources", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            record("jar-entry-read", 0, jar=str(FORGE), entry=entry, bytes=len(data), sha256=digest(data))
            text = data.decode("utf-8")
            if entry.endswith("BlockEvent.java"):
                start = text.index("    public static class NeighborNotifyEvent")
                end = text.index("    public static class", start + 1)
                excerpt = text[max(0, start - 1100):end]
            elif "extensions/" in entry:
                lines = text.splitlines()
                indices = set()
                for n, line in enumerate(lines):
                    if re.search(r"setBedOccupied|Atmosphere|onBlockStateChange", line):
                        indices.update(range(max(0, n - 9), min(len(lines), n + 24)))
                excerpt = "\n".join(f"{n+1}: {lines[n]}" for n in sorted(indices))
            else:
                excerpt = text
            event_sections.append(f"\n## {entry}\n{excerpt}")
    if len(native_sections) < 15:
        raise RuntimeError("incomplete selected primary extraction")
    write("native-methods.txt", "\n".join(native_sections) + "\n")
    write("forge-events.txt", "\n".join(event_sections) + "\n")
    write("PRIMARY-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"classes": len(classes), "source_entries": len(events), "sections": len(native_sections)}))


def extra() -> None:
    paths = [
        "docs/decisions/ADR-024-STATE-BASED-ATMOSPHERE-BOUNDARIES.md",
        PREFIX + "api/atmosphere/AtmosphereBoundaryProvider.java",
        PREFIX + "api/atmosphere/AtmosphereBoundary.java",
        PREFIX + "AdvancedRocketryCommunity.java",
        PREFIX + "atmosphere/instrument/AtmosphereAnalyzerService.java",
        PREFIX + "station/service/StationRuntime.java",
        PREFIX + "station/service/StationManager.java",
        PREFIX + "gametest/AtmosphereBoundaryGameTests.java",
        PREFIX + "gametest/AtmosphereGameTests.java",
    ]
    audit = json.loads((LEAF / "INPUT-AUDIT.json").read_text(encoding="utf-8"))
    sections = []
    for path in paths:
        data, item = blob(path)
        audit["fixed_blobs"].append(item)
        lines = data.splitlines()
        if path.endswith("StationManager.java"):
            selected = set()
            for i, line in enumerate(lines):
                if re.search(r"findAt|accessService|operational|StationRegistrySavedData|allowed\(|onBlockBroken|onBlockPlaced", line):
                    selected.update(range(max(0, i - 5), min(len(lines), i + 15)))
        elif path.endswith("AdvancedRocketryCommunity.java"):
            selected = set()
            for i, line in enumerate(lines):
                if re.search(r"atmosphereEvents|atmosphereManager|boundaryCatalog|lifeSupport|onNeighborNotify|onRightClickBlock|stationEvents|StationRegionBodyContextResolver", line):
                    selected.update(range(max(0, i - 6), min(len(lines), i + 14)))
        elif path.endswith("GameTests.java"):
            selected = set()
            for i, line in enumerate(lines):
                if re.search(r"door|dirty|invalid|Dirty|boundary|provider|Boundary|suppl|debit", line):
                    selected.update(range(max(0, i - 4), min(len(lines), i + 13)))
        else:
            selected = set(range(len(lines)))
        sections.append(f"\n## {path}\n" + "\n".join(f"{i+1}: {lines[i]}" for i in sorted(selected)))
    write("extra-source.txt", "\n".join(sections) + "\n")
    write("INPUT-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"extra_blobs": len(paths), "total_fixed_blobs": len(audit["fixed_blobs"])}))


def doors() -> None:
    classes = {"net.minecraft.world.level.block.DoorBlock": ["neighborChanged", "setOpen", "updateShape", "use("],
               "net.minecraft.world.level.block.TrapDoorBlock": ["neighborChanged", "use("],
               "net.minecraft.world.level.block.FenceGateBlock": ["neighborChanged", "use("]}
    audit = json.loads((LEAF / "PRIMARY-AUDIT.json").read_text(encoding="utf-8"))
    sections = []
    with zipfile.ZipFile(MAPPED) as archive:
        for cls, selectors in classes.items():
            entry = cls.replace(".", "/") + ".class"
            if archive.getinfo(entry).file_size > 2 * 1024 * 1024:
                raise RuntimeError("class ceiling exceeded")
            data = archive.read(entry)
            audit["primary_entries"].append({"jar": "mapped", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            output = run([str(JAVAP), "-classpath", str(MAPPED), "-p", "-c", cls]).decode("utf-8").replace("\r\n", "\n")
            for chunk in re.split(r"(?=^  (?:public|protected|private|static).*[;{]$)", output, flags=re.MULTILINE):
                header = chunk.splitlines()[0] if chunk.splitlines() else ""
                if any(selector in header for selector in selectors):
                    sections.append(f"\n## {cls}\n{chunk}")
    if len(sections) != 8:
        raise RuntimeError(f"unexpected door method extraction: {len(sections)}")
    audit["bounds"]["class_count"] = 11
    write("door-methods.txt", "\n".join(sections) + "\n")
    write("PRIMARY-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"classes": 3, "sections": len(sections)}))


def interaction() -> None:
    classes = {"net.minecraft.server.level.ServerPlayerGameMode": ["useItemOn("],
               "net.minecraftforge.common.ForgeHooks": ["onRightClickBlock("]}
    audit = json.loads((LEAF / "PRIMARY-AUDIT.json").read_text(encoding="utf-8"))
    sections = []
    with zipfile.ZipFile(MAPPED) as archive:
        for cls, selectors in classes.items():
            entry = cls.replace(".", "/") + ".class"
            if archive.getinfo(entry).file_size > 2 * 1024 * 1024:
                raise RuntimeError("class ceiling exceeded")
            data = archive.read(entry)
            audit["primary_entries"].append({"jar": "mapped", "entry": entry, "bytes": len(data), "sha256": digest(data)})
            output = run([str(JAVAP), "-J-Dfile.encoding=UTF-8", "-classpath", str(MAPPED), "-p", "-c", cls]).decode("utf-8").replace("\r\n", "\n")
            for chunk in re.split(r"(?=^  (?:public|protected|private|static).*[;{]$)", output, flags=re.MULTILINE):
                header = chunk.splitlines()[0] if chunk.splitlines() else ""
                if any(selector in header for selector in selectors):
                    sections.append(f"\n## {cls}\n{chunk}")
    if len(sections) != 2:
        raise RuntimeError(f"unexpected interaction method extraction: {len(sections)}")
    audit["bounds"]["class_count"] = 13
    write("interaction-methods.txt", "\n".join(sections) + "\n")
    write("PRIMARY-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"classes": 2, "sections": len(sections)}))


def final_state() -> None:
    sections = []
    for argv in (["git", "status", "--short"], ["git", "branch", "--show-current"],
                 ["git", "rev-parse", "HEAD"], ["git", "worktree", "list", "--porcelain"]):
        data = run(argv)
        sections.append("$ " + subprocess.list2cmdline(argv) + "\n" + data.decode("utf-8"))
    write("final-repository.txt", "\n".join(sections))
    print("Final read-only repository status captured; no repository mutation performed.")


def admission() -> None:
    cls = "net.minecraft.server.level.ServerPlayer"
    entry = cls.replace(".", "/") + ".class"
    audit = json.loads((LEAF / "PRIMARY-AUDIT.json").read_text(encoding="utf-8"))
    with zipfile.ZipFile(MAPPED) as archive:
        if archive.getinfo(entry).file_size > 2 * 1024 * 1024:
            raise RuntimeError("class ceiling exceeded")
        data = archive.read(entry)
    output = run([str(JAVAP), "-J-Dfile.encoding=UTF-8", "-classpath", str(MAPPED),
                  "-p", "-c", cls]).decode("utf-8").replace("\r\n", "\n")
    sections = []
    for chunk in re.split(r"(?=^  (?:public|protected|private|static).*[;{]$)", output, flags=re.MULTILINE):
        header = chunk.splitlines()[0] if chunk.splitlines() else ""
        if "startSleepInBed(" in header:
            sections.append(f"\n## {cls}\n{chunk}")
    if len(sections) != 1:
        raise RuntimeError("unexpected admission extraction")
    audit["primary_entries"].append({"jar": "mapped", "entry": entry,
                                    "bytes": len(data), "sha256": digest(data)})
    audit["bounds"]["class_count"] = 14
    previous = (LEAF / "interaction-methods.txt").read_text(encoding="utf-8")
    write("interaction-methods.txt", previous + "\n".join(sections) + "\n")
    write("PRIMARY-AUDIT.json", json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"classes": 1, "sections": len(sections)}))


def cleanup() -> None:
    # Exactly one native cleanup attempt, restricted to this worker's own scratch.
    script = r"""
$ErrorActionPreference = 'Stop'
$leaf = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-air-feasibility-20261009-02'
$target = Join-Path $leaf '_tmp'
$resolved = (Resolve-Path -LiteralPath $target).ProviderPath
if ($resolved -ne $target -or -not $resolved.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Containment check failed' }
$ancestors = @('D:\GitHub', 'D:\GitHub\ARCE-Task-Evidence', 'D:\GitHub\ARCE-Task-Evidence\v1.8.0', $leaf, $target)
foreach ($path in $ancestors) { if ((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Ancestor reparse point found' } }
$items = @(Get-ChildItem -LiteralPath $target -Force -Recurse)
if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) { throw 'Scratch reparse point found' }
$owners = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(java|javaw|gradle|javap)\.exe$' -and $_.CommandLine -and $_.CommandLine.IndexOf($leaf, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
if ($owners.Count -ne 0) { throw 'Owned native process still active' }
$count = @($items | Where-Object { -not $_.PSIsContainer }).Count
Remove-Item -LiteralPath $resolved -Recurse -Force
@{ target=$resolved; removed_files=$count; native_processes=$owners.Count; remaining=(Test-Path -LiteralPath $target); utc=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Compress
"""
    result = run(["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script])
    write("CLEANUP.json", result.decode("utf-8"))
    print(result.decode("utf-8"))


def seal() -> None:
    files = sorted(path for path in LEAF.rglob("*") if path.is_file() and path.name != "SHA256SUMS.txt"
                   and "_tmp" not in path.relative_to(LEAF).parts)
    lines = [f"{digest(path.read_bytes())}  {path.relative_to(LEAF).as_posix()}" for path in files]
    write("SHA256SUMS.txt", "\n".join(lines) + "\n")
    print(json.dumps({"files": len(files), "bytes": sum(path.stat().st_size for path in files),
                      "manifest_sha256": digest((LEAF / "SHA256SUMS.txt").read_bytes())}))


if __name__ == "__main__":
    (LEAF / "_tmp").mkdir(exist_ok=True)
    {"inputs": inputs, "native": native, "extra": extra, "doors": doors,
     "interaction": interaction, "admission": admission, "final-state": final_state,
     "cleanup": cleanup, "seal": seal}[sys.argv[1]]()
