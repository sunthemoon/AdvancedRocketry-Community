# Actual command record and capture boundary

Working directory for substantive Git/javap subprocesses:
`D:/GitHub/AdvancedRocketry-Community`. Task start read main task 02; initial
status timestamp printed `2026-10-09T03:18:50.6334243Z`. Initial status, branch,
HEAD and worktree reads exited 0. Main owner modifications were left untouched.
Material input work then used this leaf's script with exact fixed Git objects;
its subprocesses and read hashes are in commands.jsonl.

Each recorded Python launch was supplied to the PowerShell execution tool as:

```powershell
$ErrorActionPreference='Stop'; Get-Date -AsUTC -Format o;
python -B 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-air-feasibility-20261009-02\inspect_air.py' <mode>;
$code=$LASTEXITCODE; Get-Date -AsUTC -Format o; exit $code
```

| Mode | Printed start UTC | Printed end UTC | Actual exit/result |
|---|---|---|---|
| inputs | 03:20:53.1049720 | 03:20:56.9354583 | 0; seals 13/37 matched; 72 initial fixed blobs/51 selected source files |
| native (first) | 03:21:54.9027327 | 03:21:58.4400124 | 0 process exit; extraction incomplete, zero sections; disclosed setup failure |
| native (corrected) | 03:22:27.8398496 | 03:22:31.4411036 | 0; eight mapped classes/four source entries/24 selected sections |
| extra (first) | 03:25:18.1800621 | 03:25:18.8906774 | 1; nonexistent guessed Git object returned 128, preserved in log |
| extra (corrected) | 03:25:47.8019739 | 03:25:48.6180475 | 0; nine additional fixed blobs, 81 unique total |
| doors | 03:27:47.1013695 | 03:27:48.5210112 | 0; three mapped classes/eight selected sections |
| cleanup | 03:33:00.7132987 | 03:33:01.6741007 | 0; one native contained/reparse/process-checked Remove-Item attempt; 21 owned scratch files removed |
| final-state | 03:33:08.9504111 | 03:33:09.6378722 | 0; raw git status/branch/HEAD/worktree capture |
| interaction (first) | 03:50:03.0969246 | 03:50:04.2371777 | 1 batch exit; two javap subprocesses exited 0, strict decoding of ForgeHooks display failed at byte 218507 (0xa1) |
| interaction (corrected) | 03:50:28.3924614 | 03:50:29.5791280 | 0; explicit javap UTF-8 output encoding, two classes/two selected methods |
| final-state (last) | 03:56:13.8720479 | 03:56:14.5526455 | 0; final raw git status/branch/HEAD/worktree capture, mutable Main HEAD 2ad2ea944d87176f6b4171c2c13c69502c106db5 |
| admission | 03:57:19.5162690 | 03:57:20.3520507 | 0; one ServerPlayer class/one startSleepInBed method, strict UTF-8 output; research only, no spawn-cause proof |

Date is 2026-10-09 for every UTC above. The script's exact material subprocess
argv, cwd, start UTC, completion UTC, stdout/stderr byte counts and raw hashes
are logged by subprocess capture, not inferred from rendered tool text. The
log retains timezone-aware timestamps; the extra-discovery records use +08:00
and normalize to the UTC launch table above. The interaction correction adds
only `-J-Dfile.encoding=UTF-8` to the local javap display process, not runtime
Minecraft settings or replacement decoding. The failed batch published no
supplementary extracts/audit; both original raw subprocess hashes are retained.
The explicit exploratory guessed-path failure remains in that log. Script changes
only corrected evidence extraction or added bounded read modes, not source
implementation. The command log retains both original and corrected native
stdout hashes; zero-section output is never counted as behavioral evidence.

Interactive PowerShell discovery/display calls additionally read the task,
complete independent report/audit/manifest, author script metadata, fixed-tree
path listings, temporary governance extracts, the whole fixed proposed sleep
contract, selected source/native/event extracts and command counters. These
were read-only and are retained by the task tool transcript. Their original
rendered output streams were not separately raw-captured into this leaf;
commands.jsonl must not be misrepresented as a raw archive of every interactive
display pipeline. The raw material inputs and meaningful subprocess evidence
are captured independently there and can reproduce the extracts.

A later metadata-only Select-String used a guessed nonexistent author leaf
`sleep-contract-candidate-20261009-01`; PowerShell printed a nonterminating
read error and its outer command exited 0. The actual already-verified author
leaf was `sleep-contract-research-20261009-01`. The corrected metadata display
was truncated; neither display establishes a new source conclusion or replaces
the earlier complete contract read/raw input hash. This interactive failure
is disclosed within the same unarchived-display limitation.

The initial long combined display was truncated by tool rendering, and a later
combined multiline Select-String display was also truncated. They supplied no
negative behavioral conclusion. The complete independent report and full
contract/governance were subsequently read in bounded displays; material Git
blob bytes were captured/hash-checked without truncation by the inspection
script. No arbitrary normalized tool output hash was substituted for raw bytes.

Seal command, after report completion:

```powershell
python -B 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-air-feasibility-20261009-02\inspect_air.py' seal
```

The seal writes only leaf-relative hashes of compact owned evidence files,
excluding itself and the empty _tmp directory. The final response records its
actual file/byte count and manifest SHA-256. No sealed file is subsequently
edited; an independent post-seal verification reads the manifest and checks
its owned files without appending to the sealed command log.

No Gradle, build, compiler, unit/GameTest, client/server, world-writing test,
runtime hook, install, reflection/private access, AT/coremod, public API change,
spawn/time policy, full-tree/archive copy, web request, Claude or child agent
was used. Future implementation version commands are prohibited here, not
waived or NOT_APPLICABLE. Cleanup was only this worker's own _tmp; no denied
target retry, alternate-shell cleanup or peer cleanup occurred.
