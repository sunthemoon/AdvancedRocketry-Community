# Off-world sleep: M1/M2 atmosphere/access feasibility, task 02

Date: 2026-10-09 UTC. Delegated worker: `/root/sleep_air_feasibility`.
Fixed repository input: `46c566dd7000d9fcd29c985d23100d8c04891eaf`.
Platform: Minecraft 1.20.1 / Forge 47.4.10 / installed Java 17.

## Findings first

### M1 remains an implementation prerequisite: no safe event-only neutral-bed discriminator

The independent review's self-invalidation concern is corroborated at the new
fixed baseline. **Static evidence proves synchronous authority revocation, not
an observed immediate wake or an observed universal failure to rest.** Ordinary
native occupancy may coexist with fail-closed atmosphere without changing the
scan/debit rules, but only if a narrowly qualified transition/observation
mechanism distinguishes genuinely neutral writes and all consequential changes.
That mechanism is not provided by the current NeighborNotifyEvent alone.

Three primary facts make a simple exemption or occupancy-only repair unsafe:

1. The event contains the **current** state, position, notified directions and
   force-redstone flag; it contains no old state or caller/cause token. A bed's
   current OCCUPIED state and even equal hypothetical occupied/unoccupied air
   classification do not prove the previous block was that same bed. An
   OCCUPIED-only write and replacement of a sealing wall with that bed state
   can produce the same observable event payload. This is a source-supported
   indistinguishability argument, not an executed exploit.
2. `ServerLevel.updateNeighborsAt` posts the event **before** its neighborUpdater
   runs. Native `DoorBlock.neighborChanged` can subsequently update POWERED/OPEN
   using setBlock flag **2**, without the neighbor-notify bit. The adjacent door
   can still be closed when the atmosphere listener runs and open afterward.
   Thus removing the existing adjacent-door invalidation merely because OPEN
   has not yet changed is not a faithful preservation of redstone air loss.
3. Native `ServerPlayerGameMode.useItemOn` posts RightClickBlock before invoking
   the cached block state's `use`. The installed listener preemptively dirties
   a door-like clicked block or an **exactly registered clicked BlockState**,
   including a registered bed compiled as DEFAULT. A nonempty catalog for an
   unrelated block does **not** dirty an ordinary unregistered bed at this
   interaction phase. It does dirty the changed bed position at the later
   NeighborNotify phase. These different conditions must remain distinct.

The provider catalog may legitimately classify a bed differently by OCCUPIED.
Its callbacks compile **every** BlockState, can claim another namespace's block,
and retain an immutable result table; nothing prohibits an occupancy-sensitive
pure rule. Such a transition is genuine topology/classification change and must
still revoke. `instanceof BedBlock`, a bed tag, a player UUID marker or a blanket
"occupied changes are cosmetic" predicate is insufficient.

**Disposition:** the proposed contract must explicitly retain M1 as a hard
qualification/source-assignment prerequisite. Do not infer that an integration
worker is authorized to suppress notifications, add a grace interval, restore
revoked authority from an old scan, or change public boundary APIs. The proposed
bounded alternatives and exact qualification conditions are below and in
[PROPOSED-CORRECTIONS-02.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/PROPOSED-CORRECTIONS-02.md).

### M2 has a precise bounded candidate correction, not a chosen product policy

Admission and continued sleep can use one private projection that separates
**required actual host/profile + live station access** from **optional orbit
description**. For the existing proposed gap-allowing branch:

- Require the supported real Level's unique expected host definition/profile.
  In Space this is the actual Space host, not the orbited surface.
- Require a separately operational station registry before interpreting an
  absent committed region as a gap. `findAt().isEmpty()` alone does not suffice.
- On both distinct admission samples (entry eye and normalized sleeping head/eye),
  check their own committed regions and live VISIT independently. One station's
  permission does not authorize another sampled cell across an edge.
- While sleeping, use the same rule at the actual current eye. Operational
  supplied gaps are permitted by this **proposed** branch; missing optional
  orbit context cannot immediately invalidate a legitimately admitted gap.
- Blocked registry, missing/ambiguous actual host/profile, unavailable loaded
  state and denied live access still refuse/wake. Remove only an optional orbit
  label while host/access/air remain valid: this branch does not wake solely
  for that removal. Station deletion can become an operational gap; it never
  exempts the independent adrift/safety-return policy.

This deliberately does **not** change BodyContextResolver, analyzer behavior,
station persistence, the public API or atmosphere truth. A station-only branch
would reject supplied gaps and require a different missing-orbit/deletion policy;
it is an explicit product alternative, **not selected here**. Neither branch is
owner-approved by this research. The only recorded owner selection remains
actual sleep conditional on separately freezing/reviewing dimension, spawn and
time behavior.

### Qualification cannot be replaced by service-only fixtures or this bytecode review

Existing atmosphere GameTests inspected here create their own services and, in
the door case, explicitly call `markDirty`. Their source supports the expected
revocation/rescan behavior but does not reproduce the installed sleep event
ordering. No test was executed in this task. The current packaged natural=false
baseline also does not reach native sleeping occupancy through ordinary bed use;
a later, separately authorized native-admission candidate is needed to qualify
actual off-world sleeping. A direct startSleeping bypass is not equivalent.

All B1 spawn-cause and D1 dimension/time/ancillary prerequisites from the complete
independent review remain untouched. This M1/M2 research does not establish B1,
approve natural=true or authorize any runtime hook, new spawn/time policy or
source assignment.

## Fixed primary evidence and exact boundaries

`S` below means a raw Git object at the fixed SHA, with source line numbers.
The common Git-object prefix is
`src/main/java/io/github/sunthemoon/advancedrocketrycommunity/`.
These are immutable object identifiers, not assertions about a mutable checkout.
All raw object hashes are in
[INPUT-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/INPUT-AUDIT.json).
Line-numbered extracts are in
[fixed-source.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/fixed-source.txt)
and [extra-source.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/extra-source.txt).
`J` means mapped primary bytecode, method offsets, in
[native-methods.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/native-methods.txt)
[door-methods.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/door-methods.txt)
and [interaction-methods.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/interaction-methods.txt).
[forge-events.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/forge-events.txt)
contains exact primary Forge event/extension source excerpts; their complete
input entry hashes are in
[PRIMARY-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/PRIMARY-AUDIT.json).

### Native mutation and notification ordering

- J `ServerPlayerGameMode.useItemOn`:7-13 caches the clicked BlockState;
  34-44 invokes ForgeHooks.onRightClickBlock; 46-59 handles cancellation.
  J `ForgeHooks.onRightClickBlock`:13-23 posts the event before returning it.
  Item-first use at 114-143 and block-use/sneak decisions at 224-248 can prevent
  native block use. Only afterward does :251-259 call the cached state's use.
  J `BedBlock.use`:11-56 normalizes foot to head, :57-144 retains the native
  spawn-capability/explosion branch, :145-184 checks occupancy, and :185-188
  calls Player.startSleepInBed. Thus the installed interaction listener runs
  before native head normalization/admission and any occupancy write, even on
  attempts later canceled/refused. It is not a paired successful-operation end
  or proof that no other event listener/item-first action changed the world.
- J `ServerPlayer.startSleepInBed`:5-19 calls the Forge initial sleep-failure
  factory, :39-72 checks existing sleep/alive/natural, :73-106 range/obstruction,
  :107-122 calls setRespawnPosition, :125-139 checks sleep time and :140-258
  checks native monster admission. Only :259-273 delegates to Player's native
  sleep start and :296-306 updates the sleeping-player list. J
  `Player.startSleepInBed`:0-7 invokes startSleeping and resets the counter.
  The initial admission event is therefore after interaction invalidation but
  before occupancy; time and monster failures can occur after the respawn call.
  This ordering corroborates the unchanged B1 prerequisite; inspecting this
  admission method neither proves a cause-scoped spawn veto nor authorizes one.
- J `LivingEntity.startSleeping`:20-41 invokes setBedOccupied(true) **before**
  setting SLEEPING pose at 44-48, positioning, and setting sleeping position.
  A filter demanding that the player already isSleeping at the neighbor event
  would miss entry. Wake's `lambda$stopSleeping$11`:33-41 invokes occupancy
  false. Both directions require qualification.
- J `IForgeBlock.setBedOccupied`:0-18 calls Level.setBlock with the OCCUPIED
  replacement and flag 3. It is a real world-state write, not only presentation.
- J `BedBlock.updateShape`:27-72 returns the opposite half's OCCUPIED value;
  a mismatch can instead return air at 73-79. The paired half and geometry must
  be validated, not exempted from cleanup or silently ignored. Its inspected
  `getShape` depends on connected direction, not OCCUPIED, which supports the
  ordinary vanilla shape's occupancy independence; it is not a universal
  provider/third-party collision guarantee.
- J `Level.setBlock(pos,state,flags,depth)` keeps old state internally and calls
  markAndNotifyBlock at 163-173. J `markAndNotifyBlock`:93-106 calls blockUpdated
  on flag 1; 151-186 updates indirect/direct neighbor shapes; 189-202 invokes
  Level/block onBlockStateChange after neighbor work. These callbacks have old
  state but are method extension points, **not** a globally subscribed paired
  old/new event in the inspected installed atmosphere adapter. Using them for
  every native bed/Level would need an independently demonstrated public
  integration; subclass/reflection/AT/coremod is not authorized here.
- J `ServerLevel.updateNeighborsAt`:0-14 obtains the current state and posts
  NeighborNotifyEvent; 21-31 invokes the neighborUpdater afterward. Its
  isCanceled result is popped at 17-20 on this path. Canceling physics is not
  an approved substitute for fixing atmosphere observation.
- J `DoorBlock.neighborChanged`:0-46 reads neighbor power, then 125-157 writes
  POWERED/OPEN with flag 2. TrapDoorBlock's corresponding write is 78-96 with
  flag 2. DoorBlock.setOpen uses flag 10 at 27-47, also without flag 1. The
  existing pre-interaction/pre-neighbor invalidation therefore has a concrete
  role. This task does not promise observation of every arbitrary same-JVM
  mod mutation using flags that do not notify.

### Installed atmosphere invalidation, publication and debit

- S `AdvancedRocketryCommunity.java`:372-394 actually freezes the loading-time
  boundary catalog, passes it to the installed manager, registers atmosphere
  neighbor/interaction/placement/fluid/chunk/reload/server-tick listeners, and
  registers PlayerLifeSupportService. An empty fabricated manager omits this
  installed catalog and event wiring.
- S `AtmosphereServerEvents`:58-72 preemptively invalidates only door-like or
  **exactly registered clicked BlockState** interactions after the server/loaded
  guards. S `AtmosphereBoundaryCatalog`:24-29 uses containsKey for registered
  state and isEmpty for the separate any-provider check; DEFAULT classification
  does not remove registration. Its measurement-item exception requires the
  nonMutatingItem predicate and block use DENY; ordinary native bed use is not
  that exception. A registered bed can therefore revoke **before** sleep
  admission as well as on occupancy, but an unrelated provider does not make
  arbitrary bed RightClick dirty. Both phases need qualification. :75-89 instead
  invalidates any notified changed cell when the compiled catalog is nonempty
  (or the changed state is door-like), and independently marks every notified
  loaded adjacent door-like cell even with an empty catalog. :34-36 repairs at
  server END. No unconditional bed-interaction invalidation is claimed.
- S `AtmosphereLevelService`:132-160 cancels affected scans/unconsumed completed
  results and removes indexed/provider authority synchronously, then queues
  bounded repair. An authority loss immediately after invalidation can report
  VACUUM rather than PENDING, because canceled scans are no longer indexed;
  both outcomes must wake under the proposed rule. Do not require the literal
  PENDING enum to recognize loss.
- :188-219 prunes vents, processes dirty work, clears provider publication,
  schedules/advances scans, accepts completed volumes and applies supply.
  :346-368 publishes only completed volume results. :390-411 elects one provider
  per volume and publishes it only on a breathable supply result.
- :223-249 returns base ambient breathable or valid current controlled supply.
  Base ambient short-circuits the loaded guard, so sleep preflights the full
  sampled chunk itself. Controlled air requires an indexed volume, the loaded
  provider's ACTIVE status and current `canSupplyAtmosphere()`; a remembered
  volume/HUD or station vacuum flag does not suffice.
- S `OxygenVentBlockEntity`:75-98 performs the existing supply commit/debit.
  :298-303 checks current oxygen, FE and data usability. S `VentSupplyEngine`:
  25-34 debits finite oxygen by cadence and 20 FE; :38-59 requires SEALED,
  elected provider and sufficient resources. Sleep must add no second debit,
  exempt sleeping consumption or republish resources after genuine loss.
- S `VolumeScanCoordinator`:71-118 respects per-task and per-Level inspection
  budgets. :167-189 also removes affected completed-but-unconsumed results.
  S `VolumeIndex`:80-92 removes volumes around dirty cells. Existing indexed
  cells/bounds do **not** retain authenticated old BlockStates for a generic
  transition comparator; adding an observation journal is not a pre-existing
  capability merely because a bounded volume index exists.
- J `Player.tick`:0-1 fires player pre-tick; 41-97 increments native sleep
  counter then checks sleep time/wakes normally; 139-140 calls LivingEntity.tick
  afterward. S `PlayerLifeSupportService`:45-49 uses LivingTick and :68-113
  performs its own existing air/equipment/exposure behavior. The sleep adapter
  should query authoritative air directly, not wait for a later HUD snapshot.

These facts determine local call order, not when an ordinary network bed action
arrives relative to server END, scan publication or the next actual player tick.
Whether repair completes first depends on installed runtime order, room size,
budget and contention. No universal wake timing was executed or inferred.

### Host/access identity and region edges

- S `CelestialCatalog`:116-119 returns a host only for one Level candidate.
  S `CelestialEnvironmentService`:18-27 reads this actual mapped atmosphere;
  S `AtmosphereManager`:135-141 does not use station orbit. If mapping is absent
  the manager has a non-Overworld vacuum fallback and can still know a supplied
  room; the sleep projection must reject missing actual host **before** that
  fallback could appear to authorize supported sleep.
- S `StationRegistrySavedData`:82-83 defines operational read state; :204-209
  returns empty find/findAt while blocked. :118-120 separately defines checked
  update availability. Do not conflate an operational read registry with every
  optional checked-write capability, or a blocked empty read with a valid gap.
- S `StationRegistryModel`:217-232 performs bounded grid lookup and committed
  containment. Reserved cells have no committed StationState. S `StationRegion`:
  21-23 has inclusive X/Z containment; negative/grid/expanded-region edges must
  be exercised. S `StationAccessService`:21-35 allows existing operator/owner
  and members' VISIT/BUILD, not invitations. No name-sorted limited destination
  listing or nearest-station scan is needed for sleep.
- S `StationRegionBodyContextResolver`:21-35 returns authoritative UNRESOLVED
  in a gap. S `BodyContextResolver`:42-54 terminates on UNRESOLVED and rejects
  missing orbit body references. This is correct for orbit/travel context and
  is **not** equivalent to the gap-compatible sleep host projection.
- S `AtmosphereAnalyzerService`:71-85 requires ORBIT in Space. It is a precedent
  for thread/actor/full-chunk/catalog checks, not a reusable gap-admission rule.
  No analyzer or public BodyContext semantics need change for this proposal.
- Accepted ADR-066 section 3.3 makes actual air necessary for off-world sleep;
  a suit/force-respawn option is not air. ADR-014 intentionally leaves gaps
  unresolved for body context. ADR-041 distinguishes stored orbit environment
  from atmosphere and allows non-atmospheric fallback behavior. The proposed
  private projection does not grant orbit air or rewrite those contracts.

## Alternatives and integration scope

All alternatives below are **proposed**, not authorized implementations.

| Alternative | Feasibility/cost and safety boundary |
|---|---|
| Keep the installed coarse invalidation unchanged | Preserves accepted fail-closed semantics and all budgets. It may interrupt/deny ordinary rest in affected rooms; cannot silently count as fulfilling the owner's actual-sleep target. Runtime characterization remains necessary. |
| Exact public operation/transition recognizer for qualified neutral native bed writes | Potentially smallest integration correction if authentic before/after identity and paired failure/wake cleanup can be demonstrated. It must also account for pre-interaction invalidation, both halves, actual compiled-rule/tag precedence, and subsequent door/provider reactions. An earlier sleep/admission flag without a paired end is not such a mechanism. No recognizer is proven here. |
| Internal bounded observation journal at existing authority publication | Could supply prior-state evidence, but adds boundary/frontier state, catalog generations, initialization/eviction/reload/unload handling and synchronous transition observation. Current volume cells omit sealed-frontier old states; a journal must fit existing limits or refuse/retain coarse invalidation, never raise caps or treat absent witness as neutral. Greater integration/compatibility/performance scope; no source or API change approved. |
| Narrow content/compatibility eligibility | Only accepting rooms/bed placements demonstrated not to self-invalidate is possible as a proposed limitation, but rejects otherwise valid supplied rooms near doors/nonempty catalogs and is a product change, not a universal repair. It still needs actual installed qualification and explicit disposition. |
| Station-only Space projection | Resolves M2 by rejecting all operational gaps and making station/orbit availability required. This changes the proposed product rule; not selected by a worker or inferred from owner actual-sleep selection. |

No blanket bed/door exclusion, PENDING allowance, delayed-all-loss check, scan
budget increase, physics cancellation, native occupancy bypass, direct pose
toggle, private access or public boundary API extension is proposed as a fix.
Comparing current door OPEN to an earlier snapshot after the operation also
cannot on its own preserve **synchronous** revocation during reentrant listener
queries; any such buffering needs a separately reviewed authority contract.
Already revoked volumes cannot be restored merely because a later comparison
looks unchanged. Genuine or uncertain changes retain ordinary fail-closed repair.

Proposed future write boundaries, requiring a new explicit assignment:

- Sleep worker: new private `atmosphere/sleep/**`, sleep-specific unit/GameTest
  fixtures and its own task records, using frozen integration inputs.
- Integrator: `AtmosphereServerEvents` and any precisely necessary internal
  atmosphere-manager/classifier/observation changes, central listener/lifecycle
  wiring, translations, contract/ADR changes and dimension/DataGen/build files
  only when their separate D1/B1 dependencies are satisfied. Existing events,
  provider/table precedence and budget regression fixtures must be reviewed.
- If an internal journal is chosen, explicitly add its actual scan/index/world
  observation files and tests to the integrator's exclusive scope; do not hide
  this as a sleep-only adapter edit. Public API signatures/class bytes stay
  unchanged. No station schema/access service or BodyContext API redesign is
  needed for the proposed M2 private read projection.
- Independent verifier: its own read-only evidence leaf and authorized later
  runtime fixture resources, not Main/status/ledger writes.

## Exact qualification prerequisites (all runtime work unexecuted)

1. Record the authorized dimension/spawn/time/ancillary disposition and establish
   B1's exact public bed-action boundary independently. The baseline alone
   cannot perform ordinary off-world sleeping. Declare a finite qualification
   candidate and permitted source/test/integration scopes; do not introduce
   AT/reflection/coremod or direct-start substitutes during qualification.
2. Freeze the private projection and the gap-versus-station-only product branch.
   Include required-host loss, optional-orbit loss, operational gap versus blocked
   registry, both admission cells' edges/access and actual-eye continued checks.
3. Observe the installed boundary catalog and real event adapters, actual
   connected player's normal head/foot bed use, occupancy in both halves,
   pose/eye and native counter, and the existing atmosphere metrics/public vent
   resource readbacks. Use public or explicitly owned fixture observations,
   not reflective private-field access. Exercise empty/nonempty catalogs, an
   unrelated provider, an OCCUPIED-sensitive provider, tag precedence and reload.
4. Include near/far closed doors and a permitted room needing multiple task
   passes; use native insufficient quorum to retain sleep through deep sleep.
   Record when each notification, native check, authority revocation/repair,
   vent debit and server END occurs. Probe actual saved restart/disconnect
   cleanup. Do not equate transient entry pose with sustained rest.
5. Interleave real door use/redstone transitions, wall replacement/removal,
   provider removal, FE/oxygen exhaustion, provider chunk unload and reload
   with entry/continued/wake operations. Inspect dirty backlog/overflow,
   in-flight and completed-result cancellation. A claimed neutral exemption
   must not mask a wall-to-bed replacement or flag-2 door reaction.
6. Preserve 4,096 cells/volume, 256 task and 1,024 Level inspections/tick, 64
   jobs, 128 indexed volumes/65,536 indexed cells, 8,192 dirty positions/256
   dirty processing per tick, 1,024 tracked vents; provider compilation stays
   256 providers/1,024 blocks/16,384 states with existing callback bounds.
   No new NBT root or sleep debit. Reference-load sleep overhead must fit mean
   MSPT <=25 ms, P95 <=50 ms and P99 <=100 ms with zero unexpected tickets,
   watchdog/OOM. No monitor cap silently leaves some sleepers unobserved.
7. Execute the version's clean build, test, runData, generated diff check and
   runGameTestServer, actual-diff independent review and affected finite packaged
   lifecycle/save/restart/security checks on committed source/JAR identities.
   V1/V2 and full-load acceptance remain governed by ADR-018 and existing Gates;
   no exemption is extended. The added M1-01..06/M2-01..05 cases in the proposal
   supplement, not replace, S01-S21/R01-R02.

## Commands, hashes, failures and owned evidence

[COMMANDS.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/COMMANDS.md)
lists actual launch strings and limitations.
[commands.jsonl](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/commands.jsonl)
records exact material subprocess argv, cwd, start/end UTC, exits, raw stdout
and stderr byte counts/SHA-256, reads and native source-entry hashes. Author and
independent scripts were **read only, never executed**; this leaf's inspection
script was executed with Python `-B` and only emits evidence inside this leaf.

- Both input seals were independently checked: **13 independent-review entries
  and 37 author-candidate entries, all 50 matched**. The complete independent
  report/manifest/primary extracts and whole proposed sleep contract were read.
- Fixed input inspection read **81 unique Git blobs**, including mandatory
  project/version/Gate/parallel/v1+ governance, owner decision, full proposed
  contract, accepted ADR-066 and ADR-024. Source-supported facts above refer
  to this task's fixed SHA, not inherited source line numbers at 96236acb.
- Bounded primary inspection read **14 mapped classes and four Forge source
  entries**, capped at 2 MiB/entry and 45 seconds/javap invocation. It performed
  **24 javap invocations**: eight initial extraction attempts, eight corrected
  inspections, three door supplements, two two-class interaction attempts and
  one ServerPlayer admission supplement.
  No compiler, game or library install.
- The first native extraction returned exit 0 but retained **zero selected
  sections** because the extractor's regex did not handle Windows CRLF. That
  output is not behavioral evidence. CRLF handling was corrected and a minimum
  section-count check added; the corrected run returned 0 with **24** selected
  sections and the door supplement returned 0 with **eight**. All original
  raw subprocess hashes remain in the command log. The setup failure is
  disclosed rather than represented as a native PASS.
- The first interaction supplement's two javap subprocesses returned 0, but
  strict UTF-8 decoding of the full ForgeHooks display failed at byte 218507
  (`0xa1`) and the Python batch returned **1** at 03:50:04 UTC. Neither
  supplementary extract nor audit was published by that failed batch. The
  corrected supplement explicitly passed `-J-Dfile.encoding=UTF-8` to javap,
  retained strict decoding and the two-section check, and returned 0 with
  **two** selected methods. Both original raw output hashes remain in the log;
  the encoding failure is not a failed Minecraft behavior test or a waiver.
  The later ServerPlayer admission supplement returned 0 with one additional
  method in interaction-methods.txt, completing the inspected admission call
  order without executing a bed action or expanding the research to B1 proof.
- Extra input discovery guessed a nonexistent StationServerEvents Git object.
  Git show returned **128**, its stderr/hash is retained, and the Python batch
  returned **1** at 03:25:18 UTC. Tree discovery found the actual StationManager;
  the corrected nine-blob batch returned 0. No missing-file test waiver followed.
- Initial and final git status/branch/HEAD/worktree reads were read-only. Main
  had pre-existing modified AGENTS.md and many untracked owner evidence items;
  none was edited, staged, committed, moved, deleted or acquired by this worker.
  The last 03:56:14 UTC status capture observes mutable Main HEAD
  `2ad2ea944d87176f6b4171c2c13c69502c106db5`. This task did not move HEAD and
  did not adopt that later checkout as its source baseline; every source claim
  remains tied to the explicit fixed Git objects at 46c566dd.
  Final raw status is in
  [final-repository.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/final-repository.txt).
- One native checked scratch cleanup succeeded at **03:33:01 UTC**, after
  resolved containment, ancestor/descendant reparse and owned native-process
  checks. It removed exactly **21 owned temporary governance extracts**, with
  zero owned native processes and no remaining scratch files. No denied retry,
  alternate-shell cleanup, peer cleanup or policy bypass occurred. Result:
  [CLEANUP.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-feasibility-20261009-02/CLEANUP.json).
- Interactive read-only discovery/display calls are retained in the task's tool
  transcript, not as independently captured raw terminal streams in this leaf.
  Their original display stream must not be described as raw-hashed. Material
  source/native/integrity commands and inputs **are** independently raw-hashed;
  this standalone command-capture limitation is explicit, not an invented PASS.
- No Gradle/build/test/DataGen/GameTest, Minecraft client/server, world/save/
  restart, runtime hook, implementation, install, reflection/private access,
  AT/coremod, web request, Claude or further delegation was executed. Those
  runtime checks are prohibited here, **not waived or NOT_APPLICABLE** later.
  No upstream AR/LibVulpes code, official art or full tree/build archive copied.

Important raw input SHA-256 values:

| Input | SHA-256 |
|---|---|
| Fixed owner decision | `1dd0928208ffba6cda4636a632d06fe00ebbef650e6f4d9d4d2b1ed66fdf0af6` |
| Fixed proposed contract / sealed author contract (identical bytes) | `55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21` |
| Accepted ADR-066 | `8a5e06789b94595f26ae04cd9bf0ee63ff37710835224a0750055427486bf63a` |
| Mapped 47.4.10 primary JAR | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Forge 47.4.10 source JAR | `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0` |
| Installed javap | `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d` |

The compact owned seal has **15 leaf-relative files**, excluding SHA256SUMS.txt
itself. It includes report/proposal, script, command/raw-input audits, primary
and fixed-source extracts, final status and cleanup result. Scratch/cache file
count is **0**, retained full-tree/build/archive count **0**, worker-created
live child/native process count **0**, repository writes **0**. File bytes and
manifest SHA are produced by the actual seal command; no self-referential hash
is embedded in this report. The leaf is research evidence only.

## Scope, remaining work, risks and Gates

**Completed:** M1/M2 fixed-source/primary research, input seal verification,
bounded private host/access proposal, native notification/debit/check-order
analysis, alternatives, future qualification matrix/scopes and sealed external
evidence. **Uncompleted:** proven public neutral-transition recognizer, source
assignment/implementation, B1 cause proof, D1 product freeze, runtime wake timing,
installed regression, restart/visual/performance and release acceptance. Initial
interactive displays are not independently raw-stream archived as noted above.

**Design:** keep actual-host identity and optional orbit context separate; use
one per-cell projection at admission and continued sleep; retain all genuine/
unknown atmosphere loss and unchanged budgets. These are proposed corrections,
not approval or a new architecture/API policy.

**Files/tests changed:** only the 15 new external evidence files plus their seal
manifest in this exclusive leaf. No repository source/docs/state/ledger or
sealed input changed. No source tests added/modified; M1-01..06 and M2-01..05
are proposed unexecuted cases.

**Known risks:** pre-interaction/occupancy self-invalidation, unobserved neutral
cause/old state, before-neighbor OPEN ordering, occupancy-sensitive providers,
optional orbit versus required-host ambiguity, region deletion/access changes,
native eye-height/bed extensions, scan contention, and all previously disclosed
spawn/time/registry-upgrade/lifecycle risks. A passing hash seal proves none of
their runtime outcomes.

**Ownership released:** Main/Root/HEAD/branch/worktrees and all mutable repository
interests were released at task start. No peer process or source scope was
claimed. Root owns OpenPet updates; this worker sent research milestones only.

**Required Gates:** not satisfied by this research. v1.8 development is permitted
under accepted ADR-060 while inherited v1.0 acceptance and v1.8 G0-G9 remain
open. No policy, ADR, Gate, ledger/item completion, release, tag or delivery is
approved or modified.

**Next within v1.8:** independently review the proposed M1/M2 corrections,
establish the exact public neutral-transition and B1 boundaries, record the
authorized D1/product disposition, then assign explicit disjoint source and
qualification scopes. Execute the required committed-candidate implementation
checks before making any acceptance or delivery claim.
