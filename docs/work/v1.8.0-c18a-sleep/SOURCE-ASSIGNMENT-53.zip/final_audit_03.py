"""Own assignment receipt audit at unchanged committed Main baseline."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/final_audit_03.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '67be47ed4742907d12ed07e25cedca59e11b93a884f99ab88588cd64907cabe3'
source = raw.decode('utf-8').replace('cd9b54a23b5bf92760b05655a427344d6b620984',
                                   'e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1')
source = source.replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                        'e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1')
source = source.replace("'src', 'build.gradle'", "'src', 'scripts', 'build.gradle'")
source = source.replace("assert len(raw) == identity['bytes']", "assert len(raw) <= 262144\n        assert len(raw) == identity['bytes']")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
