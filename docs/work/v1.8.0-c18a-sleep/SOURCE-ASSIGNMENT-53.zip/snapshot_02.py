"""Copy only Root-owned prospective tasks, never peer evidence or source trees."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
tasks = [
 ('SLEEP-JSON-CORE-FUNCTIONAL-TASK-53.md', 'TASK-SOURCE-53.md', '945ba46e4feaa0e0c3f1d8e907ffef45b466ce47a3e0600a780edbe4c7a4f63d'),
 ('SLEEP-JSON-TERMINAL-INDEPENDENT-TASK-55.md', 'TASK-TERMINAL-REVIEW-55.md', 'fba8f9ca864b40e5fcec23dea37f139bea15e17947a5f5afb15949a03b97ce49'),
 ('SLEEP-AIR-IMPLEMENTATION-FEASIBILITY-TASK-56.md', 'TASK-M1-FEASIBILITY-56.md', 'e80c1796ec1352c8c1bd8ec5b257a52be70c5e38875cec7a86c3de323ffa02e8')]
rows = []
for source, target, expected in tasks:
    raw = (OUT.parent / source).read_bytes()
    assert len(raw) < 262144 and hashlib.sha256(raw).hexdigest() == expected
    with (OUT / target).open('xb') as output:
        output.write(raw)
    rows.append({'source': source, 'retained': target, 'bytes': len(raw), 'sha256': expected})
with (OUT / 'TASK-INPUTS-02.json').open('x', encoding='utf-8') as output:
    output.write(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows), flush=True)
