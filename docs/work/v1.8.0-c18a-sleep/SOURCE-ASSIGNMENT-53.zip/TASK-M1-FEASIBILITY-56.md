# Task56 supplied-air sleep implementation feasibility

You are a delegated engineering worker, not Root or an independent reviewer.
Do not use Root persona and do not delegate. Root coordinates OpenPet.

Fixed current source/governance is e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1;
historical sleep observation source d57ecda1 remains separately identified.
Before any own write, inspect git status/HEAD/branch/worktrees and live agents,
read actual working Main AGENTS.md and all mandatory governance/version/quality/
parallel docs completely in narrow UTF-8 displays. Main has an owner-modified
AGENTS.md; do not edit it or any peer file. Record actual preparation failures
or truncation separately; no historical raw receipts/compliance reconstruction.

Read complete fixed sleep PROPOSED-CONTRACT-01.md, CONTRACT-REVIEW-STATUS-01.md,
AIR-RESEARCH-STATUS-02.md, BOUNDARY-REVIEW-STATUS-03.md, D1-OUTCOME-FREEZE-33.md and
current OFFLINE-CORE-CONTRACT-FREEZE-52.md. Inspect actual bounded members and
complete reports/proposals in AIR-FEASIBILITY-02.zip and
BOUNDARY-INDEPENDENT-03.zip if that exact archive exists; if its filename differs,
use the fixed boundary checkpoint's explicit link, not guessed paths. These are
under docs/work/v1.8.0-c18a-sleep. Historical proposals are not accepted executable
assignments. D1 freezes outcomes only; B1/R1/M1/M2 remain implementation prerequisites.
Space station-versus-supplied-gap policy is separately awaiting owner answer;
do not select it or infer approval here.

Scope: inspect the CURRENT installed supplied-air invalidation/admission/wake
interfaces and registered boundary/provider semantics to produce an additive,
source-supported M1 feasibility proposal suitable for later independent review.
Map exact source/event order, admitted old/new state evidence and lifecycle
ownership, and identify the smallest implementation delta that could satisfy
the existing true-sleep/air/admission/wake requirements. If the available public
boundaries cannot establish those requirements, identify the exact missing
mechanism/evidence instead of inventing authority or promising a result. Assess
registered-bed pre-admission, occupancy/wake, adjacent-door transitions, genuine
loss and provider reload/removal separately. Tie candidate tests to real native
operations and current services, not fabricated observations. Preserve B1/R1,
actual-host/live-access M2 and D1 scopes separately; do not solve them by unrelated
global state changes or relabel their pending evidence as M1 proof.

Inspect the existing AtmosphereServerEvents/Runtime/Manager/LevelService,
boundary catalog/registry/provider/classification APIs, compiled scan/volume
models and relevant existing tests/utilities before proposing new infrastructure.
Read precise fixed source files and primary installed Forge/Minecraft public
declarations or official docs where necessary. No upstream source/art import,
whole source export, broad native class inventory or private-field/AT/ASM grant.
No test/world/Gradle/native/game process execution; static javap/file/Git checks
are allowed with bounded retained output and exact identities.

Exclusive write_scope is only NEW external leaf
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-air-implementation-feasibility-20261009-56.
No repository/worktree/index/HEAD edits, commits, pushes, resource/native decoder
cohort, install, quota/environment/system/service/privilege change or cleanup.
Peer53 owns its exact two Python files; peer55 owns a separate evidence leaf.
Do not change any sealed file or terminate/enumerate foreign processes.
Own static command children fixed180 seconds, split retained streams<=262144
with actual raw length/hash/exit/UTCs; own leaf<=4 MiB. Preserve actual failures;
corrected bounded static checks use distinct names and explicit scope, never
unchanged retries or policy-denied operation alternatives. No assertions of
allocator/OS hard preemption or runtime qualification from static checks.

Output one additive PROPOSED-M1-IMPLEMENTATION-FEASIBILITY-01.md plus REPORT.md.
Specify exact candidate write boundaries/dependencies, API/domain invariants,
unchanged scan/NBT/network/log/per-tick budgets and evidence-based tests; include
tradeoffs/unsupported cases/missing decisions without forced verdicts. Any candidate
must retain fail-closed genuine/unknown loss, zero new adapter-forced loading and
the existing budgets; no cap/timeout/resource change, PENDING grace or gameplay
exception is authorized. Feasibility only is not runtime proof or production
assignment. No expectation that a particular mechanism exists or passes.

Report findings/status first with exact file/line evidence, fixed inputs/hashes,
actual reads/commands/results/limits and protected state; tests NOT_EXECUTED,
all remaining Gates and v1.8-only next work. Keep stable complete proposal/report
for Root exact-hash full read and custody acknowledgment before one-time own seal.
Record actual exclusions/manifest/result, not prospective permissions. No version,
ledger, product-policy, ADR/risk acceptance or Gate authority. Return paths,
hashes/bytes/lines and unresolved requirements to Root.
