# Task53 two-file pure functional JSON-core implementation

You are a delegated implementation worker, not Root or an independent reviewer.
Use direct engineering style, no Root persona and no further delegation. Root
coordinates OpenPet. This is a new task; sealed37/43 leaves stay immutable.

Assigned worktree D:/GitHub/arce-v180-sleep-json-core-20261009-53, branch
codex/v1.8.0-sleep-json-core. Committed baseline/freeze is exactly
e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1; observation source remains historical
d57ecda1f11dab76d882f945b0de606534ef4fb9. Check branch/HEAD/status/worktrees and
live agents before writes. Read complete mandatory project governance, exact
V1.8.0-CLASSIC-CONTENT-COMPLETION version, quality/parallel rules and the actual
working Main AGENTS.md completely in narrow UTF-8 displays before any own helper
or source write. Do not edit/copy-over that user file. No broad tree discovery,
aggregate truncated content or retrospective preparation receipt/compliance.

Normative inputs: committed docs/work/v1.8.0-c18a-sleep/
OFFLINE-CORE-CONTRACT-FREEZE-52.md; complete external37 proposal
sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md
(271 lines /19096 bytes, SHA256
f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0);
complete43 PROPOSED-DIAGNOSTIC-CONVENTION-01.md (244 /15960, SHA256
69f6d6b85379b23d67566ead27db5d75e6ef039066e28614f7767ebf29298048);
actual40 and49 final reports for constraints/findings, not desired results.
External leaves are under D:/GitHub/ARCE-Task-Evidence/v1.8.0. Verify actual input
hashes/custody. Immutable proposal labels remain historical; disposition52 adopts
only the stated internal contract. No source contract or bounds may be relaxed.

Exclusive repository write_scope is exactly:
scripts/sleep_observation_json_core.py
scripts/test_sleep_observation_json_core.py
No other production module, registry/build/status/plan/ADR/risk/provenance/world/
source-schema/native-driver file. Root owns all central files and Main integration.
Your exclusive NEW evidence leaf is
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-core-source-20261009-53.
Helpers/receipts/report/patches belong only there; do not write any peer leaf.

Implement and test the complete frozen pure functional byte-oriented iterative
decoder, data/API/error/diagnostic behavior. The exact37/43 documents govern all
types, caps, precedence, reservation, consumed-prefix, UTF-16/UTF-8/escape/number,
ordinal/span ownership, deadline and maximum metrics. Derive evidence-based test
assertions from that normative contract, not from implementation output. Preserve
testable independent deadline/guard boundaries without public limit overrides.
Inspect existing adjacent pure JSON utilities/tests first; only reuse behavior
that demonstrably matches this contract. No upstream/Mojang/Forge assets/code.
Unexpected exception/OOM is not fabricated Refused. No eager json.loads/full-text
clone/recursive parser/cache/unbounded token list or actual numeric conversion.
Use standard library only; no package install. Match existing code comment language.

This is PURE FUNCTIONAL IMPLEMENTATION, not whole decoder/resource acceptance.
Do not add or execute resource measurement cohorts, platform helper bindings,
source-aware chat/schema/Gson/framing/NBT/logs/provenance/native trace integration,
OS hard quotas or world/game/Gradle/native/client processes. Required version
Gradle/native/dedicated/restart/visual commands remain NOT_EXECUTED/open here,
not PASS or inapplicable. Fixed finite resource requirements from37 remain later
mandatory: <=12 fresh cases, both268435456-byte peaks, decode60/external180,
split262144 and4 MiB leaf; no acceptance substitution by small functional tests.

Allowed commands: narrow reads/hash/Git checks; Python3.13.15 -B functional
unittest/py_compile with no __pycache writes (compile in memory instead if needed),
bounded evidence/receipt audit, git diff --check. Unit command external deadline
is fixed180 seconds, split raw stdout/stderr retained<=262144 with actual argv/
cwd/UTC/exit/hash/length; timeout/overflow explicit failure. Test values stay within
the frozen bounded families; no stress/fuzz/random/infinite cases or extra platform
probe. The parent's own just-launched immediate Python child may be stopped only
at its actual timeout; no descendants/foreign PID/tree management or cleanup.
Own evidence leaf<=4 MiB. Preserve actual failures/gaps; no unchanged failure
retry, assertion weakening, cap/time increase or deletion. Correct source/test
changes can be tested in a distinct named cohort with original evidence retained.

After functional tests pass, read exact cached stat/full UTF-8 diff/check, confirm
only two owned files and notify Root before your isolated branch commit. You may
commit only these two files with a conventional source/test message; no Main HEAD
move or amend. Run a distinct focused functional test against that actual committed
source and identify SHA in report. Ask Root to confirm before any normal branch
push; never force push. Uncommitted snapshots are intermediate only, not delivery.

Final REPORT findings/status first, exact modified files/line sizes, normative
input hashes, actual tests/counts/UTCs/argv/exits/raw receipts, source commit and
source hashes/patch, independent review/resource/Gate gaps, protected state,
preparation limitations and v1.8-only next work. Do not supply anticipated verdicts
or claim no defects from tests alone. Stable report must be completely read and
exact-hash acknowledged by Root before any one-time custody seal. Do not self-mark
version/ledger/Gates delivered or passed. Report path/hash/bytes/lines and status
to Root; implementation source will undergo fresh independent actual-diff review.
