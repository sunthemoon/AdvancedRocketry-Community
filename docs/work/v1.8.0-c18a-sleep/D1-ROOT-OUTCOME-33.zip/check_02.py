"""Validate exact Root33 record scope, added links and unchanged production."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

MAIN=Path('D:/GitHub/AdvancedRocketry-Community')
LEAF=Path(__file__).resolve().parent
BASE='53dd312b5fcf4bbfcd1bd75d1f5abe13c1eb3d1a'
DOCS=['docs/status/CURRENT_VERSION.md','docs/status/COMPLETION-PLAN.md',
      'docs/work/v1.8.0-implementation-log.md','docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md',
      'docs/work/v1.8.0-c18a-sleep/NESTED-QUALIFICATION-32.md',
      'docs/work/v1.8.0-c18a-sleep/D1-OUTCOME-FREEZE-33.md']
def git(*args):
    p=subprocess.run(['git',*args],cwd=MAIN,capture_output=True,timeout=180)
    assert p.returncode==0 and not p.stderr
    return p.stdout
assert git('rev-parse','HEAD').decode().strip()==BASE
assert git('rev-parse','@{upstream}').decode().strip()==BASE
assert git('rev-parse','HEAD:src').decode().strip()=='85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').decode().splitlines())=={'AGENTS.md',*DOCS[:-1]}
assert hashlib.sha256((MAIN/'AGENTS.md').read_bytes()).hexdigest()=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
assert not git('diff','--','src','build.gradle','compat-test-mod','docs/provenance',
               'docs/status/GATE_STATUS.md','docs/decisions','docs/11-RISK-REGISTER.md')
links=[]
for name in DOCS:
    if name==DOCS[-1]:
        text=(MAIN/name).read_text(encoding='utf-8')
    else:
        diff=git('diff','--unified=0','--',name).decode('utf-8')
        text='\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' in target or target.startswith('#'):
            continue
        path=((MAIN/name).parent/target.split('#',1)[0]).resolve()
        assert path.is_relative_to(MAIN.resolve()) and path.exists(),(name,target)
        links.append({'file':name,'target':target})
owner=(MAIN/'docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md').read_text(encoding='utf-8')
old=git('show',BASE+':docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md').decode('utf-8')
assert owner.split('Date: 2026-10-09',1)[1]==old.split('Date: 2026-10-09',1)[1]
status=(MAIN/'docs/status/CURRENT_VERSION.md').read_text(encoding='utf-8')
assert 'sleep_d1_outcome_contract: FROZEN_INDEPENDENTLY_REVIEWED_IMPLEMENTATION_PREREQUISITES_OPEN' in status
assert 'tested_code_commit: d57ecda1f11dab76d882f945b0de606534ef4fb9' in status
r={'utc':datetime.now(timezone.utc).isoformat(),'main':BASE,'links':links,
   'production_and_owner_answer_unchanged':True,'all_d1_rows_unexecuted':True,
   'whole_historical_link_portability':False,'gate_approval':False}
with (LEAF/'CHECK-02.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='links'}),flush=True)
