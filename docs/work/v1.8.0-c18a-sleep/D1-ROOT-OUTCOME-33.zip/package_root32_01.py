"""Verify/rehost sealed Root32 before an independent outcome disposition."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT=Path(__file__).resolve().parent
LEAF=OUT.parent/'sleep-observation-integration-20261009-32'
DEST=Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def safe(path):
    assert path.resolve().is_relative_to(LEAF.resolve())
    current=path
    while current!=LEAF.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(),'st_file_attributes',0)&0x400)
        current=current.parent
manifest=(LEAF/'SHA256SUMS.txt').read_bytes()
assert sha(manifest)=='c48d06be85daa397689ba61db4f845e66fa14ac7a9534147419310276ea55bba'
covered={}
for line in manifest.decode('utf-8-sig').splitlines():
    m=re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
    assert m
    expected,name=m.groups()
    pure=PurePosixPath(name)
    assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
    safe(LEAF/name)
    assert sha((LEAF/name).read_bytes())==expected
    covered[name]=expected
assert covered['REPORT.md']=='a4a7b78e0416082cccff70d1b5685f430c2a841e660d833b4423733cf595e5d8'
paths={p.relative_to(LEAF).as_posix():p for p in LEAF.rglob('*') if p.is_file()}
assert set(paths)-set(covered)=={'SHA256SUMS.txt','SEAL-RESULT.json'}
assert len(paths)==len({n.casefold() for n in paths})
assert len(covered)==143 and sum(paths[n].stat().st_size for n in covered)==496961
target=DEST/'OBSERVATION-ROOT-INTEGRATION-32.zip'
assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(paths.items()):
        safe(path)
        assert path.stat().st_size<50*1024**2
        z.write(path,name)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and set(z.namelist())==set(paths)
    for name,path in paths.items():
        assert z.read(name)==path.read_bytes()
    expanded=sum(i.file_size for i in z.infolist())
archives=[]
for path in sorted(DEST.glob('*.zip')):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        size=sum(i.file_size for i in z.infolist())
    assert path.stat().st_size<50*1024**2
    archives.append({'path':path.name,'bytes':path.stat().st_size,'expanded_bytes':size,'sha256':sha(path.read_bytes())})
compressed=sum(x['bytes'] for x in archives)
expanded_all=sum(x['expanded_bytes'] for x in archives)
assert max(compressed,expanded_all)<100*1024**2
r={'utc':datetime.now(timezone.utc).isoformat(),'archive':target.name,'bytes':target.stat().st_size,
   'expanded_bytes':expanded,'sha256':sha(target.read_bytes()),'covered_files':143,'covered_bytes':496961,
   'manifest_sha256':sha(manifest),'excluded_entries':['SHA256SUMS.txt','SEAL-RESULT.json'],
   'all_sleep_archives':archives,'all_sleep_compressed_bytes':compressed,'all_sleep_expanded_bytes':expanded_all}
with (OUT/'PACKAGING-01.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='all_sleep_archives'}),flush=True)
