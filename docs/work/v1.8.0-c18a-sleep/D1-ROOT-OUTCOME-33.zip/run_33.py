"""Capture bounded Root33 record commands without writing into sealed Root32."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

LEAF=Path(__file__).resolve().parent
MAIN=Path('D:/GitHub/AdvancedRocketry-Community')
def utc():
    return datetime.now(timezone.utc).isoformat()
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def state():
    r={'utc':utc(),'owner_agents_sha256':sha((MAIN/'AGENTS.md').read_bytes())}
    for name,args in [('head',['rev-parse','HEAD']),('upstream',['rev-parse','@{upstream}']),
                      ('src_tree',['rev-parse','HEAD:src']),('index',['diff','--cached','--name-only']),
                      ('tracked_status',['status','--porcelain=v1','--untracked-files=no'])]:
        argv=['git','-C',str(MAIN),*args]
        started=utc()
        p=subprocess.run(argv,capture_output=True,timeout=180)
        r[name]={'argv':argv,'start_utc':started,'end_utc':utc(),'exit_code':p.returncode,
                 'stdout':p.stdout.decode('utf-8'),'stderr':p.stderr.decode('utf-8')}
    return r
name,*argv=sys.argv[1:]
assert name and all(c.isalnum() or c in '-_' for c in name) and argv
receipt=LEAF/(name+'.command.json')
assert not receipt.exists()
r={'name':name,'argv':argv,'cwd':str(MAIN),'timeout_seconds':180,
   'helper_sha256':sha(Path(__file__).read_bytes()),'before':state()}
started=time.monotonic()
r['start_utc']=utc()
try:
    p=subprocess.run(argv,cwd=MAIN,capture_output=True,timeout=180)
    code,out,err,timed_out=p.returncode,p.stdout,p.stderr,False
except subprocess.TimeoutExpired as e:
    code,out,err,timed_out=124,e.stdout or b'',e.stderr or b'',True
r.update(end_utc=utc(),elapsed_seconds=time.monotonic()-started,exit_code=code,
         timed_out=timed_out,after=state(),streams={})
for suffix,raw in [('stdout',out),('stderr',err)]:
    with (LEAF/(name+'.'+suffix+'.txt')).open('xb') as f:
        f.write(raw)
    r['streams'][suffix]={'bytes':len(raw),'sha256':sha(raw)}
with receipt.open('x',encoding='utf-8') as f:
    f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['name','argv','start_utc','end_utc','exit_code','timed_out']}),flush=True)
print(out.decode('utf-8',errors='replace'),flush=True)
print(err.decode('utf-8',errors='replace'),file=sys.stderr,flush=True)
sys.exit(code)
