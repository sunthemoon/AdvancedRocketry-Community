"""Audit actual Root33 receipt hashes and protected committed state."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

LEAF=Path(__file__).resolve().parent
MAIN=Path('D:/GitHub/AdvancedRocketry-Community')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def git(*args):
    p=subprocess.run(['git',*args],cwd=MAIN,capture_output=True,timeout=180)
    assert p.returncode==0 and not p.stderr
    return p.stdout
head='55cf9bd802be2614fc27d56479684f58caceda60'
assert git('rev-parse','HEAD').decode().strip()==head
assert git('rev-parse','@{upstream}').decode().strip()==head
assert git('rev-parse','HEAD:src').decode().strip()=='85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert git('status','--porcelain=v1','--untracked-files=no')==b' M AGENTS.md\n'
assert not git('diff','--cached','--name-only')
assert not git('diff','53dd312b5fcf4bbfcd1bd75d1f5abe13c1eb3d1a','HEAD','--','src','build.gradle','compat-test-mod',
               'docs/provenance','docs/status/GATE_STATUS.md','docs/decisions','docs/11-RISK-REGISTER.md')
assert sha((MAIN/'AGENTS.md').read_bytes())=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
rows=[]
for path in sorted(LEAF.glob('*.command.json')):
    r=json.loads(path.read_text())
    for suffix,identity in r['streams'].items():
        raw=(LEAF/(r['name']+'.'+suffix+'.txt')).read_bytes()
        assert len(raw)==identity['bytes'] and sha(raw)==identity['sha256']
    assert r['exit_code']==0 and not r['timed_out']
    rows.append({k:r[k] for k in ['name','argv','start_utc','end_utc','exit_code']})
record={'utc':datetime.now(timezone.utc).isoformat(),'main':head,'commands':rows,
        'report_sha256':sha((LEAF/'REPORT.md').read_bytes()),'production_unchanged':True,'gate_approval':False}
with (LEAF/'FINAL-AUDIT-03.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='commands'}),flush=True)
