"""Strict UTF-8 bounded file or fixed Git-object reader."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
kind, target, *ranges = sys.argv[1:]
if kind == "git":
    child = subprocess.run(["git", "show", target], capture_output=True,
                           cwd="D:/GitHub/AdvancedRocketry-Community", timeout=180)
    assert child.returncode == 0, child.stderr.decode("utf-8")
    data = child.stdout
elif kind == "file":
    data = Path(target).read_bytes()
else:
    raise ValueError(kind)
assert len(data) <= 262144
lines = data.decode("utf-8", errors="strict").splitlines()
first, last = map(int, ranges) if ranges else (1, len(lines))
assert 1 <= first <= last <= len(lines)
print(json.dumps({"kind": kind, "target": target, "bytes": len(data),
                  "sha256": hashlib.sha256(data).hexdigest(), "lines": len(lines),
                  "first": first, "last": last}))
for number in range(first, last + 1):
    print(f"{number:04}: {lines[number - 1]}")
