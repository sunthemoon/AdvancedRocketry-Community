"""One-time Task55 custody seal, requiring Root's exact-report read acknowledgment."""
import datetime
import hashlib
import json
from pathlib import Path
import stat
import sys

sys.stdout.reconfigure(encoding="utf-8")
leaf = Path(__file__).resolve().parent
assert leaf == Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55").resolve()
expected = sys.argv[1]
assert len(expected) == 64 and all(c in "0123456789abcdef" for c in expected)
excluded = ["SHA256SUMS.txt", "SEAL-RESULT.json", "custody-seal-final.command.json",
            "custody-seal-final.stdout.txt", "custody-seal-final.stderr.txt"]
assert all(not (leaf / name).exists() for name in excluded)
report = (leaf / "REPORT.md").read_bytes()
assert hashlib.sha256(report).hexdigest() == expected
lines = len(report.decode("utf-8", errors="strict").splitlines())
ack_path = leaf / "ROOT-READ-ACK.json"
ack_data = ack_path.read_bytes()
ack = json.loads(ack_data)
assert ack["source"] == "/root" and ack["complete_read"] is True
assert ack["report_sha256"] == expected
assert ack["report_bytes"] == len(report) and ack["report_lines"] == lines
assert ack["one_time_custody_seal_acknowledged"] is True
assert isinstance(ack["message"], str) and ack["message"]
files = sorted(leaf.iterdir(), key=lambda p: p.name)
assert all(p.is_file() and not p.is_symlink() for p in files)
assert all(not (p.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
           for p in files)
assert len({p.name.casefold() for p in files}) == len(files)
assert sum(p.stat().st_size for p in files) + 2 * 262144 + 16384 <= 4194304
receipts = []
for path in files:
    if not path.name.endswith(".command.json"):
        continue
    record = json.loads(path.read_bytes())
    for stream in ("stdout", "stderr"):
        data = path.with_name(path.name.replace(".command.json", "." + stream + ".txt")).read_bytes()
        assert len(data) == record[stream + "_bytes"] == record[stream + "_total_bytes"] <= 262144
        assert hashlib.sha256(data).hexdigest() == record[stream + "_sha256"]
    assert record["timeout_seconds"] == 180
    assert not record["timed_out"] and not record["stream_limit_exceeded"]
    receipts.append({"receipt": path.name, **record})
parents = [r for r in receipts if len(r["argv"]) == 4
           and Path(r["argv"][2]).name == "probe_parent.py"]
assert len(parents) == 2
assert sorted(r["argv"][-1] for r in parents) == ["baseline", "shutdown-buffer"]
assert all(r["exit_code"] == 0 for r in parents)
assert sorted(p.name for p in leaf.glob("child-*.receipt.json")) == [
    "child-baseline.receipt.json", "child-shutdown-buffer.receipt.json"]
covered = [p for p in files if p.name not in excluded]
manifest = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.name + "\n"
                   for p in covered).encode("utf-8")
manifest_path = leaf / "SHA256SUMS.txt"
with manifest_path.open("xb") as output:
    output.write(manifest)
for line in manifest.decode("utf-8").splitlines():
    digest, name = line.split("  ", 1)
    assert (leaf / name).is_file()
    assert hashlib.sha256((leaf / name).read_bytes()).hexdigest() == digest
result = {
    "outcome": "SEALED_CUSTODY_ONLY",
    "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "leaf": str(leaf), "manifest_sha256": hashlib.sha256(manifest).hexdigest(),
    "manifest_bytes": len(manifest), "covered_files": len(covered),
    "covered_bytes": sum(p.stat().st_size for p in covered),
    "exact_exclusions": excluded,
    "report": {"path": "REPORT.md", "sha256": expected,
               "bytes": len(report), "lines": lines},
    "root_read_ack_sha256": hashlib.sha256(ack_data).hexdigest(),
    "verified_prior_command_receipt_pairs": len(receipts),
    "preserved_nonzero_receipts": [{"receipt": r["receipt"], "exit_code": r["exit_code"]}
                                  for r in receipts if r["exit_code"]],
    "measurement_parents": len(parents), "measurement_children": 2,
    "maximum_prior_raw_stream_bytes": max(max(r["stdout_bytes"], r["stderr_bytes"])
                                         for r in receipts),
    "leaf_volume_limit_bytes": 4194304,
    "outer_seal_receipt": "custody-seal-final.command.json",
    "physical_totals_note": "Final outer receipt and streams are written after this result; verify actual whole-leaf totals separately.",
    "authority": "Custody only; no U01/U02 or R49-01 disposition, helper adoption, resource qualification or Gate acceptance."
}
result_path = leaf / "SEAL-RESULT.json"
with result_path.open("x", encoding="utf-8", newline="\n") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
assert sum(p.stat().st_size for p in leaf.iterdir()) <= 4194304
print(json.dumps(result, indent=2))
