"""Static verification of four exact sealed input leaves; no probe execution."""
import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
INPUTS = [
    ("sleep-offline-json-core-contract-20261009-37",
     "1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763", False),
    ("sleep-json-platform-counter-20261009-44",
     "78569fc955376069ec752f04e3523e7e425aa0fede94ca10d290f696d4f151ab", True),
    ("sleep-offline-convention-independent-20261009-49",
     "008f32c53416765d83360d55344db299329dfa8615b1918e9498673c6e4192a4", False),
    ("sleep-json-terminal-counter-20261009-50",
     "80b87339c9f48e85e4e38ca90b5acc31eb385879141027ae9434c65273d88b80", True),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    assert path.is_file() and not path.is_symlink()
    assert not getattr(path.lstat(), "st_file_attributes", 0) & 0x400
    data = path.read_bytes()
    assert len(data) <= 4194304
    return data


def verify_receipt(path):
    r = json.loads(read(path))
    suffix = ".command.json" if path.name.endswith(".command.json") else ".receipt.json"
    prefix = path.name[:-len(suffix)]
    streams = r.get("streams")
    maximum = 0
    for index, name in enumerate(("stdout", "stderr")):
        data = read(path.parent / (prefix + "." + name + ".txt"))
        maximum = max(maximum, len(data))
        assert len(data) <= 262144
        if isinstance(streams, list):
            s = streams[index]
            assert len(data) == s["bytes"] and sha(data) == s["sha256"]
        elif isinstance(streams, dict):
            s = streams[name]
            if "raw_bytes_observed" in s:
                assert len(data) == s["raw_bytes_observed"] == s["retained_bytes"]
                assert sha(data) == s["sha256"]
                assert not r["stream_limit_exceeded"] and not r["reader_errors"]
            else:
                assert len(data) == s["raw_bytes"] == s["retained_bytes"]
                assert sha(data) == s["raw_sha256"] == s["retained_sha256"]
                assert not s["overflow"] and s["eof"] and s["error_type"] is None
        elif name in r:
            s = r[name]
            assert len(data) == s["raw_bytes"] == s["retained_bytes"]
            assert sha(data) == s["raw_sha256"] == s["retained_sha256"]
            assert not s["overflow"]
        else:
            assert len(data) == r[name + "_bytes"]
            assert sha(data) == r[name + "_sha256"]
    return {"receipt": path.name, "exit_code": r["exit_code"], "maximum_stream": maximum}


for name, expected_manifest, extra in INPUTS:
    leaf = BASE / name
    for ancestor in (leaf, *leaf.parents):
        assert not ancestor.is_symlink()
        assert not getattr(ancestor.lstat(), "st_file_attributes", 0) & 0x400
    manifest = read(leaf / "SHA256SUMS.txt")
    assert sha(manifest) == expected_manifest
    covered = {}
    case_names = set()
    for line in manifest.decode("utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
        assert match, line
        expected, relative = match.groups()
        p = PurePosixPath(relative.replace("\\", "/"))
        assert not p.is_absolute() and all(part not in ("", ".", "..") for part in p.parts)
        assert ":" not in relative
        relative = p.as_posix()
        assert relative.casefold() not in case_names
        case_names.add(relative.casefold())
        path = leaf.joinpath(*p.parts)
        assert path.resolve().is_relative_to(leaf.resolve())
        data = read(path)
        assert sha(data) == expected.lower(), str(path)
        covered[relative] = len(data)
    physical = {p.relative_to(leaf).as_posix(): p.stat().st_size
                for p in leaf.rglob("*") if p.is_file()}
    exclusions = {"SHA256SUMS.txt", "SEAL-RESULT.json"}
    if extra:
        exclusions.update("custody-seal-28." + suffix
                          for suffix in ("command.json", "stdout.txt", "stderr.txt"))
    assert set(physical) - set(covered) == exclusions
    seal = json.loads(read(leaf / "SEAL-RESULT.json"))
    declared = seal.get("exact_exclusions", seal.get("exclusions"))
    if declared is None:
        verification = seal["verification"]
        declared = verification.get("exact_exclusions", verification.get("excluded"))
    assert set(declared) == exclusions
    if "stdout_base64" in seal:
        for stream in ("stdout", "stderr"):
            data = base64.b64decode(seal[stream + "_base64"], validate=True)
            assert len(data) == seal[stream + "_bytes"] <= 262144
            assert sha(data) == seal[stream + "_sha256"]
        assert seal["exit_code"] == 0 and not seal["timed_out"]
    receipts = [verify_receipt(p) for p in sorted(leaf.glob("*.command.json"))]
    receipts += [verify_receipt(p) for p in sorted(leaf.glob("*.receipt.json"))]
    print(json.dumps({"leaf": name, "covered_files": len(covered),
                      "covered_bytes": sum(covered.values()),
                      "physical_files": len(physical), "physical_bytes": sum(physical.values()),
                      "manifest_bytes": len(manifest), "manifest_sha256": sha(manifest),
                      "seal_result_sha256": sha(read(leaf / "SEAL-RESULT.json")),
                      "exact_exclusions": sorted(exclusions),
                      "retained_raw_receipts_verified": len(receipts),
                      "nonzero_receipts": [r for r in receipts if r["exit_code"]],
                      "maximum_stream_bytes": max(r["maximum_stream"] for r in receipts),
                      "actual_seal_result": seal}, indent=2))
