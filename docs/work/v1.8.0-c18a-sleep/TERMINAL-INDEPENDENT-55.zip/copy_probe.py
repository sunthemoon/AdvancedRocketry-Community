"""One-time exact copies of the three authorized evidence-only probe files."""
import hashlib
import json
from pathlib import Path

leaf = Path(__file__).resolve().parent
assert leaf == Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55")
source = leaf.parent / "sleep-json-terminal-counter-20261009-50"
expected = {
    "counter_binding.py": "6dcd9d15299518cbac2c1ac4fc7bd0bd02d40c54b3941cbec8d5d7951299dddd",
    "probe_parent.py": "ed3870c44f09def09403a2a03ac197f7381e55f4bc0a618c8493070eed48d2cc",
    "probe_child.py": "e59fe04d89eb9de8b8980dd9d840145e87105495da1eef8fa830cf80c34f5c7e",
}
assert not (leaf / "PROBE-COPY-IDENTITIES.json").exists()
assert all(not (leaf / name).exists() for name in expected)
records = []
for name, identity in expected.items():
    data = (source / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == identity
    with (leaf / name).open("xb") as output:
        output.write(data)
    assert (leaf / name).read_bytes() == data
    records.append({"source": str(source / name), "copy": str(leaf / name),
                    "bytes": len(data), "sha256": identity, "byte_equal": True})
with (leaf / "PROBE-COPY-IDENTITIES.json").open("x", encoding="ascii") as output:
    json.dump(records, output, indent=2)
    output.write("\n")
assert sum(p.stat().st_size for p in leaf.rglob("*") if p.is_file()) < 4194304
print(json.dumps(records, indent=2))
