"""Static launch-owned receipt/interval verification, never a counter caller."""
import hashlib
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
leaf = Path(sys.argv[1])
own = leaf == Path(__file__).resolve().parent
outer_names = (["31-cohort-baseline", "32-cohort-shutdown"] if own else
               ["cohort-baseline-21", "cohort-shutdown-buffer-22"])
expected_helpers = {
    "python.exe": "85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd",
    "subprocess.py": "7b58820104e7243c80ced7ad4081bf971fed0a4099850bcfb50261625645ed20",
    "probe_parent.py": "ed3870c44f09def09403a2a03ac197f7381e55f4bc0a618c8493070eed48d2cc",
    "probe_child.py": "e59fe04d89eb9de8b8980dd9d840145e87105495da1eef8fa830cf80c34f5c7e",
    "counter_binding.py": "6dcd9d15299518cbac2c1ac4fc7bd0bd02d40c54b3941cbec8d5d7951299dddd",
}
for case, outer_name in zip(("baseline", "shutdown-buffer"), outer_names):
    prefix = "child-" + case
    r = json.loads((leaf / (prefix + ".receipt.json")).read_bytes())
    outer = json.loads((leaf / (outer_name + ".stdout.txt")).read_bytes())
    assert outer == r
    assert r["child_cwd"] == str(leaf)
    assert Path(r["child_argv"][-2]) == leaf / "probe_child.py"
    assert r["child_argv"][-1] == case
    assert r["child_argv"][1:4] == ["-B", "-X", "tracemalloc=1"]
    assert r["child_ceiling_seconds"] == 30
    assert r["child_deadline_ns"] - r["launch_before_ns"] == 30000000000
    assert r["launch_before_ns"] <= r["launch_after_ns"] <= r["wait_before_ns"] <= r["wait_after_ns"]
    assert r["wait_after_ns"] < r["child_deadline_ns"]
    assert r["identity_before_wait"]["pid"] == r["child_pid"]
    assert r["identity_after_wait"]["pid"] == r["child_pid"]
    assert not r["closed_before_query"] and r["closed_after_close"]
    for helper in r["helpers_before_launch"]:
        p = Path(helper["path"])
        data = p.read_bytes()
        assert len(data) == helper["bytes"]
        assert hashlib.sha256(data).hexdigest() == helper["sha256"] == expected_helpers[p.name]
    for stream in ("stdout", "stderr"):
        s = r["streams"][stream]
        data = (leaf / (prefix + "." + stream + ".txt")).read_bytes()
        assert len(data) == s["raw_bytes"] == s["retained_bytes"] <= 262144
        assert hashlib.sha256(data).hexdigest() == s["raw_sha256"] == s["retained_sha256"]
        assert not s["overflow"] and s["eof"] and s["error_type"] is None
    records = [json.loads(line) for line in (leaf / (prefix + ".stdout.txt")).read_bytes().splitlines()]
    assert all(x["case"] == case and x["pid"] == r["child_pid"] for x in records)
    assert all(r["launch_before_ns"] <= x["monotonic_ns"] <= r["wait_after_ns"] for x in records)
    assert [x["stage"] for x in records] == (["identity", "main-self-query", "main-returning",
            "atexit-buffer-live", "atexit-buffer-released"] if case == "shutdown-buffer" else
            ["identity", "main-self-query", "main-returning", "atexit-baseline"])
    d = r["declaration"]
    assert d["counter_size"] == 72 and d["counter_alignment"] == 8
    assert [x["offset"] for x in d["fields"]] == [0, 4, 8, 16, 24, 32, 40, 48, 56, 64]
    for call in r["post_exit_calls"]:
        assert call["handle"] == r["original_handle"]
        assert r["wait_after_ns"] <= call["before_ns"] <= call["after_ns"] <= r["close_before_ns"]
        assert call["cb_argument"] == call["cb_member"] == 72
        assert call["values"] is not None if call["success"] else call["values"] is None
    if case == "shutdown-buffer":
        assert records[3]["buffer_bytes"] == 16777216 and records[3]["stride"] == 4096
        assert records[3]["allocation_touch_after_ns"] < records[4]["release_after_ns"]
    print(json.dumps({"leaf": str(leaf), "case": case, "parent_pid": r["parent_pid"],
                      "child_pid": r["child_pid"], "original_handle": r["original_handle"],
                      "exit_code": r["exit_code"], "wait_timeout": r["wait_timeout"],
                      "timeout_actions": r["timeout_actions"],
                      "execution_failure": r["execution_failure"],
                      "terminal_counter_available": r["terminal_counter_available"],
                      "post_exit_calls": r["post_exit_calls"],
                      "main_self_peak": records[1]["calls"][0]["values"]["PeakWorkingSetSize"],
                      "buffer_live_peak": records[3]["calls"][0]["values"]["PeakWorkingSetSize"]
                          if case == "shutdown-buffer" else None,
                      "last_traced_current_peak": records[-1]["traced_current_peak"],
                      "last_tracer_metadata": records[-1]["tracer_metadata"],
                      "streams": r["streams"], "all_checked_identities_and_intervals_match": True}, indent=2))
