"""Own bounded custody audit with unique index output; not a probe runner."""
import hashlib
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
leaf = Path(__file__).resolve().parent
index_path = leaf / ("COMMAND-INDEX-" + sys.argv[1] + ".json")
assert not index_path.exists() and not (leaf / "SHA256SUMS.txt").exists()
records = []
for p in sorted(leaf.glob("*.command.json")):
    r = json.loads(p.read_bytes())
    for name in ("stdout", "stderr"):
        data = p.with_name(p.name.replace(".command.json", "." + name + ".txt")).read_bytes()
        assert len(data) == r[name + "_bytes"] == r[name + "_total_bytes"] <= 262144
        assert hashlib.sha256(data).hexdigest() == r[name + "_sha256"]
    assert r["timeout_seconds"] == 180 and not r["timed_out"]
    assert not r["stream_limit_exceeded"]
    records.append({"receipt": p.name, **r})
cohorts = [r for r in records if len(r["argv"]) == 4
           and Path(r["argv"][2]).name == "probe_parent.py"]
assert len(cohorts) == 2
assert sorted(r["argv"][-1] for r in cohorts) == ["baseline", "shutdown-buffer"]
assert all(r["exit_code"] == 0 for r in cohorts)
with index_path.open("x", encoding="utf-8") as output:
    json.dump(records, output, indent=2)
    output.write("\n")
files = [p for p in leaf.rglob("*") if p.is_file()]
volume = sum(p.stat().st_size for p in files)
assert volume <= 4194304
agents = Path("D:/GitHub/AdvancedRocketry-Community/AGENTS.md").read_bytes()
print(json.dumps({"verified_prior_command_receipts": len(records),
                  "nonzero_receipts": [{"receipt": r["receipt"], "exit_code": r["exit_code"]}
                                        for r in records if r["exit_code"]],
                  "measurement_parents": len(cohorts), "measurement_children": 2,
                  "maximum_own_raw_stream_bytes": max(max(r["stdout_bytes"], r["stderr_bytes"])
                                                       for r in records),
                  "leaf_files_at_checkpoint": len(files), "leaf_bytes_at_checkpoint": volume,
                  "unique_index_file": index_path.name,
                  "unique_index_sha256": hashlib.sha256(index_path.read_bytes()).hexdigest(),
                  "working_agents_bytes": len(agents),
                  "working_agents_sha256": hashlib.sha256(agents).hexdigest(),
                  "helpers": [{"path": p.name, "bytes": p.stat().st_size,
                               "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                              for p in sorted(leaf.glob("*.py"))]}, indent=2))
