"""Bounded evidence receipt; no shell, environment override, or tree management."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

LEAF = Path(__file__).resolve().parent
CAP = 262144
VOLUME = 4194304
DEADLINE = 180


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    name, *argv = sys.argv[1:]
    assert name and all(c.isalnum() or c in "-_" for c in name)
    cwd = "D:/GitHub/AdvancedRocketry-Community"
    if argv and argv[0] == "--own-leaf-cwd":
        argv.pop(0)
        cwd = str(LEAF)
    assert argv
    assert not (LEAF / "SHA256SUMS.txt").exists()
    paths = [LEAF / (name + suffix) for suffix in
             (".command.json", ".stdout.txt", ".stderr.txt")]
    assert all(not p.exists() for p in paths)
    current = sum(p.stat().st_size for p in LEAF.rglob("*") if p.is_file())
    assert current + 2 * CAP + 16384 <= VOLUME
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    proc = subprocess.Popen(argv, cwd=cwd,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    buffers = [bytearray(), bytearray()]
    totals = [0, 0]
    overflow = threading.Event()

    def collect(stream, index):
        while True:
            block = stream.read(8192)
            if not block:
                return
            totals[index] += len(block)
            remaining = CAP - len(buffers[index])
            buffers[index].extend(block[:max(0, remaining)])
            if totals[index] > CAP:
                overflow.set()

    readers = [threading.Thread(target=collect, args=(proc.stdout, 0)),
               threading.Thread(target=collect, args=(proc.stderr, 1))]
    for thread in readers:
        thread.start()
    timed_out = False
    stopped = False
    while proc.poll() is None:
        if time.monotonic() - clock >= DEADLINE or overflow.is_set():
            timed_out = time.monotonic() - clock >= DEADLINE
            proc.kill()  # Only this wrapper's launch-owned immediate child.
            stopped = True
            break
        time.sleep(0.01)
    proc.wait(timeout=10)
    for thread in readers:
        thread.join(timeout=10)
    assert all(not t.is_alive() for t in readers)
    stdout, stderr = map(bytes, buffers)
    paths[1].write_bytes(stdout)
    paths[2].write_bytes(stderr)
    receipt = {
        "argv": argv, "cwd": cwd,
        "utc_start": start,
        "utc_end": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "elapsed_seconds": time.monotonic() - clock,
        "exit_code": proc.returncode, "timeout_seconds": DEADLINE,
        "timed_out": timed_out, "stream_limit_bytes": CAP,
        "stream_limit_exceeded": overflow.is_set(),
        "immediate_child_stopped": stopped,
        "stdout_total_bytes": totals[0], "stdout_bytes": len(stdout),
        "stdout_sha256": digest(stdout),
        "stderr_total_bytes": totals[1], "stderr_bytes": len(stderr),
        "stderr_sha256": digest(stderr),
        "leaf_volume_limit_bytes": VOLUME,
    }
    paths[0].write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt))
    print(stdout.decode("utf-8", errors="replace"))
    if stderr:
        print("STDERR:", stderr.decode("utf-8", errors="replace"))
    assert sum(p.stat().st_size for p in LEAF.rglob("*") if p.is_file()) <= VOLUME
    if timed_out or overflow.is_set() or proc.returncode:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
