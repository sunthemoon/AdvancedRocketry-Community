# Task55 independent terminal-counter assessment

Date: 2026-10-09 UTC. Delegated independent reviewer, not Root or Task50's author.
Evidence-only review and exactly two authorized finite reproduction parents.
This is a new disjoint leaf; sealed Task49 and all other inputs were not edited.

## Findings first

### R55-01 - Medium qualification dependency: local terminal retrieval is not downstream resource acceptance

The Task50 original-handle method independently reproduced attributable native
post-exit peak-working-set retrieval on this installed Windows AMD64 / CPython
3.13.15 environment. Both named original children and both new Task55 children
were queried after completed exit waits, through their retained launch handles,
before closure. The new shutdown-buffer child's terminal peak preserved its
observed atexit peak after the buffer was released. This addresses the *query
timing* limitation for these finite normal-exit observations; it does not add
terminal coverage to Task44's historical self-query-only runs.

The remaining dependency is the unchanged37 process-lifetime interpretation and
qualification/disposition, not an observed product defect. A documented process
peak and successful terminal retrieval support the local method; neither proves
every OS accounting transition from process birth, promises post-exit API success
in every exit mode, selects a platform helper, or qualifies a decoder's traced
and native ceilings. The reviewer does not close R49-01/U01/U02 globally. In
particular, retaining a process object is not by itself a documented guarantee
that every memory API works after exit. [Process termination](https://learn.microsoft.com/en-us/windows/win32/procthread/terminating-a-process),
[native counters](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters).

Tight evidence: [unchanged37:226-243](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md#L226),
[actual49:10-28](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-convention-independent-20261009-49/REPORT.md#L10),
[actual50:8-40](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-counter-20261009-50/REPORT.md#L8),
[parent:77-128](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/probe_parent.py#L77),
[own baseline raw result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/31-cohort-baseline.stdout.txt),
[own shutdown raw result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/32-cohort-shutdown.stdout.txt).

### R55-02 - Informational integration boundary: exit 0 and custody audits are not counter qualification

The exact parent computes execution failure from timeout, child exit and stream
conditions separately from `terminal_counter_available`. A future API failure
can therefore be recorded as unavailable without changing its execution exit to
nonzero; PID identity is also recorded, not included in that execution predicate.
This is explicit in the evidence format, not a concealed observed failure. All
four inspected actual children had successful calls, matching identities and
normal closure. A consumer must inspect BOOL success, identity, availability and
timing/closure records, rather than turn exit 0 or a custody audit into PASS.

References: [parent:132-164](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/probe_parent.py#L132),
[binding:56-90](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/counter_binding.py#L56),
[independent static audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/verify_measurements.py).
Unavailable/error/permission/ABI/timeout-kill paths were not fault-injected.

No new Critical/High/Medium execution, attribution, ABI, unit or post-wait ordering
defect was identified in the exact finite Task50 evidence. This statement does not
remove R55-01, establish a portable API contract, or waive unexecuted requirements.

## Preparation, identity and actual gaps

Task55 instructions were completely read before writes; a saved later complete
read confirms 65 lines /4267 bytes, SHA256
fba8f9ca864b40e5fcec23dea37f139bea15e17947a5f5afb15949a03b97ce49.
[Task55](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-JSON-TERMINAL-INDEPENDENT-TASK-55.md),
[preparation record](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/PREPARATION.md).

Before any own leaf/helper write, complete narrow strict UTF-8 reads covered
working AGENTS.md and fixed b80fb950b3965956ff6a75f8f86b9aff32aa196d objects:
PROJECT-CONFIG.md, PRODUCT.md, porting principles, roadmap, exact v1.8 version,
master test plan, release/Gates, post-1.0 roadmap, quality budgets, parallel rules,
fixed AGENTS.md, previous v1.7 version and ADR-060. Git status, branch, HEAD and
worktrees and the live-agent list were inspected before writes. Main was on
codex/v1.8.0-classic-content; user-modified AGENTS.md and peer work were not taken
over. External ancestor AGENTS.md files were absent; the assigned leaf was new.

Working AGENTS.md: 15797 bytes, SHA256
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09, unchanged at
the own audit checkpoint. Pre-write Git inspections all exited 0 during
10:14:01.573251Z-10:14:01.926125Z. Tool-only status/worktree streams were displayed,
not saved as historical receipt files; their actual hashes are in PREPARATION.md.
Bootstrap tool transport had no retained receipt or independent historical outer
watchdog. No retrospective raw logs, timestamps or stronger compliance claim
were invented. Task55 had no helper-before-complete-AGENTS ordering gap.

Actual preparation failures: the initial multiline Python shim transport failed
with injected `|| goto :error` SyntaxError before intended Git execution. A guessed
fixed docs/versions/V1.8.0.md lookup failed (Git 128, wrapper 1); only its stderr
hash was displayed before the assertion. A narrow nonrecursive version listing
located the actual file, which was then completely read. These failures remain
disclosed. This is the same worker session as Task49, not Task50's author; the
Task49 preparation gaps remain historical input facts, not corrected by Task55.

The combined first display of proposal37/report37 was tool-truncated by 1047
tokens, although the saved raw streams were complete. Focused commands 06/07
completely displayed the affected proposal tail/report beginning at unchanged
hashes. No original truncated display is represented as a complete read.

## Fixed inputs, complete reads and actual custody

Governance stays fixed at b80fb950b3965956ff6a75f8f86b9aff32aa196d; observation
source stays fixed at d57ecda1f11dab76d882f945b0de606534ef4fb9. Root's separate
documentation-only commits are not input rebinding. The latter object was
verified to be a commit; source behavior was not rerun or changed.

All leaf names below are under D:/GitHub/ARCE-Task-Evidence/v1.8.0/.

| Exact input | Lines / bytes | SHA256 |
| --- | --- | --- |
| sleep-offline-json-core-contract-20261009-37 / PROPOSED-OFFLINE-JSON-CORE-01.md | 271 /19096 | f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0 |
| Same37 / REPORT.md | 225 /16797 | 1f775414b3937a5d1813b57b511c616c0003bc09c7cadba07bf7424844b9bbb2 |
| sleep-json-platform-counter-20261009-44 / REPORT.md | 303 /19739 | c86b95c534cfb14981c57714e8957501c60573b797bc9b017cd5d2752092fedb |
| sleep-offline-convention-independent-20261009-49 / REPORT.md | 316 /24827 | 81ed06d8e26a0999d2f2da5b7254d93c8b01da3bc10e52f33dd8bbd367f7228f |
| sleep-json-terminal-counter-20261009-50 / REPORT.md | 307 /20304 | 17bc576fa3d566ca85a91b8c3b8a9b13b3b98937b783d0a822a064830a835f38 |

Commands 01-07 provide those full reads and focused display completion. Task50's
binding, parent, child, capture, audit, preparation/limits, actual seal result,
two child raw streams, two parent raw objects and shutdown child receipt were
completely read. Installed subprocess ranges were separately read, not exported.
Manifest verification is a full contained-member hash check, not merely reading
a permission message or the report's claim of a future seal.

The corrected actual-schema verifier (21) checked 445 covered files /1696264
bytes and 137 retained receipt/raw-stream pairs across all four actual leaves.
It verified safe relative contained case-unique manifest names, no reparse
members, every covered hash, exact physical exclusions and raw lengths/hashes.
Embedded seal streams for37/49 and excluded seal receipt triples for44/50 were
also checked. All covered hashes matched. The preserved failed verifier/path
commands below are schema/lookup errors, not findings of input mutation.
[Actual custody result](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/21-input-custody-actual-schemas.stdout.txt).

| Leaf | Covered files / bytes | Actual whole leaf files / bytes | Verified receipt pairs |
| --- | --- | --- | --- |
| 37 | 90 /649019 | 92 /659856 | 27 |
| 44 | 92 /259336 | 97 /270884 | 28 |
| 49 | 173 /514813 | 175 /533339 | 55 |
| 50 | 90 /273096 | 95 /284173 | 27 |

Exact exclusions37/49: SHA256SUMS.txt and SEAL-RESULT.json only. Exact exclusions44/50:
those two plus custody-seal-28.command.json, custody-seal-28.stdout.txt and
custody-seal-28.stderr.txt. Two historical37 nonzero receipts are retained;
all44/49/50 retained receipt exits are 0. Their seals convey custody, not acceptance.

| Leaf | SHA256SUMS.txt SHA256 | SEAL-RESULT.json SHA256 |
| --- | --- | --- |
| 37 | 1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763 | 719d27a044cc4b6e964245e6451cc09bb7d452ddd01c5a207f068cb3ebe3d38f |
| 44 | 78569fc955376069ec752f04e3523e7e425aa0fede94ca10d290f696d4f151ab | 11ee35b3c91b4ec8e33c7620af99bc146b730812b59c536ae92eee7e85fbd4bf |
| 49 | 008f32c53416765d83360d55344db299329dfa8615b1918e9498673c6e4192a4 | 20722c2ef94ff713c567fcf6abb48fb55a656d2c0a0b85965df1fbb4bfc7b2b3 |
| 50 | 80b87339c9f48e85e4e38ca90b5acc31eb385879141027ae9434c65273d88b80 | c1843634de354731de5774d7f7c17c67da0ce6b1f1229875df90871394096155 |

Task50's actual result completed 10:09:55.7476597Z, SEALED_CUSTODY_ONLY, with its
recorded Root-read acknowledgment hash. Actual result and excluded raw receipts
were inspected. This report does not reinterpret that prior acknowledgment as
Task55 acceptance or U01/U02 closure. No unrelated archive/ZIP audit was performed.

## Independent API, installed source and lifetime assessment

The actual Python executable is D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe,
105696 bytes, SHA256
85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd.
Runtime identifies CPython 3.13.15 / MSC v1944 AMD64. Installed Lib/subprocess.py
is 93085 bytes /2258 lines, SHA256
7b58820104e7243c80ced7ad4081bf971fed0a4099850bcfb50261625645ed20.

Complete ranges 221-238, 1552-1639 and 1702-1717 show original CreateProcess hp
retained in Popen._handle, immediate thread-handle closure, wait/exit-code calls
on that same handle without process-handle closure, and guarded Handle.Close.
The original process and Handle remain referenced until the query and explicit
close. No Detach, DuplicateHandle, OpenProcess, PID reopening/discovery or foreign
management occurs in the probe. `_handle` and Handle.Close are installed private
implementation details, not a public portable Python contract. The compiled
_winapi implementation was not independently disassembled.
[Installed lifetime evidence](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/27-installed-launch-wait.stdout.txt),
[Python subprocess](https://docs.python.org/3.13/library/subprocess.html).

Microsoft documents CreateProcess-returned process handles with PROCESS_ALL_ACCESS
and GetProcessMemoryInfo's query/limited-query requirements on modern Windows.
This supports the rights assumption; the actual rights bitmask was not queried.
Successful actual calls supply local evidence. Handle/PID before and after wait,
and the child's self PID, all match. No reusable-PID attribution is substituted
for the original handle. [Process rights](https://learn.microsoft.com/en-us/windows/win32/procthread/process-security-and-access-rights),
[PROCESS_INFORMATION](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-process_information),
[GetProcessId](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocessid),
[GetProcessMemoryInfo](https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getprocessmemoryinfo).

The binding explicitly declares BOOL(HANDLE, pointer, DWORD), DWORD(HANDLE) and
HANDLE(), uses WinDLL/use_last_error, guards widths 4/4/8/8 and size72/alignment8,
and records offsets 0,4,8 through64. Both cb values are72. It immediately captures
the ctypes saved error before further timestamps/APIs. BOOL, not error-zero,
determines query success. Failed output is None/UNQUALIFIED, never a zero peak.
All inspected actual post-exit calls returned BOOL1/error0. K32 and psapi wrapper
agreement is useful consistency, not two independent accounting mechanisms.
[Binding:12-90](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/counter_binding.py#L12),
[ctypes](https://docs.python.org/3.13/library/ctypes.html),
[GetLastError](https://learn.microsoft.com/en-us/windows/win32/api/errhandlingapi/nf-errhandlingapi-getlasterror).

PeakWorkingSetSize is kept distinct from current working set, commit/pagefile
fields, traced Python blocks and allocator quotas; PageFaultCount is a count, not
bytes. The documented peak-working-set field mapping supports the native peak
interpretation, but does not independently observe every birth-to-exit event.
Working set measures resident pageable pages, can include shared pages, and excludes
AWE/large-page allocations. It is not complete native-allocation/virtual-memory
accounting or a hard memory quota. [Counter structure](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters),
[peak field mapping](https://learn.microsoft.com/en-us/previous-versions/windows/desktop/legacy/aa965225(v=vs.85)),
[working set](https://learn.microsoft.com/en-us/windows/win32/memory/working-set).

Child self calls use the current-process pseudohandle, not the parent's own
handle; that pseudohandle is not closed. Parent queries use the retained real
child handle and explicitly close it once after both exports; false-before-query
and true-after-close are recorded. No post-close memory query was attempted.
[GetCurrentProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getcurrentprocess).

## Exact copies, original observations and two independent cohorts

Input/helper/receipt verification and original measurement audit completed before
the optional reproduction. Command30 made one-time exact-byte copies of only
the permitted evidence helpers; both own parents recorded their matching hashes
before launch. No helper behavior was changed and no third measurement parent
or failed-cohort retry occurred. [Copy identities](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/PROBE-COPY-IDENTITIES.json).

| Exact helper | Bytes | SHA256 |
| --- | --- | --- |
| counter_binding.py | 3888 | 6dcd9d15299518cbac2c1ac4fc7bd0bd02d40c54b3941cbec8d5d7951299dddd |
| probe_parent.py | 7405 | ed3870c44f09def09403a2a03ac197f7381e55f4bc0a618c8493070eed48d2cc |
| probe_child.py | 2505 | e59fe04d89eb9de8b8980dd9d840145e87105495da1eef8fa830cf80c34f5c7e |

Original50 observations, independently audited29: baseline parent23632/child28556,
handle460, main native peak21184512 and terminal21204992 bytes; shutdown
parent5976/child8448, handle452, main20815872, atexit37601280 and terminal37601280.
Both terminal current working sets were32768, not their peaks. The shutdown
buffer was released before exit. Original baseline/shutdown outer stdout hashes:
1b37d6b2b717b885014dd2692c1ba12d13bbf0f9e95996206667c6ebcb4666fb and
52f40278d2ef6f2b1907abaf96a5f88da6a22630421bd2daf2e956d24b84b28b.
[Original static audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/29-original-measurements-audit.stdout.txt).

Actual new parent argv: the exact installed python.exe, `-B`, own probe_parent.py,
and respectively `baseline` / `shutdown-buffer`; cwd is this new own leaf.
Each launches one own probe_child.py with `-B -X tracemalloc=1`, same case and
no descendants. Inherited environment, CREATE_NO_WINDOW; no environment, quota,
working-set, affinity, privilege or service modifications. Baseline allocates no
probe buffer; shutdown uses exactly one16777216-byte bytearray, touches page
strides and last byte, releases it in one atexit callback. No JSON/stress data.

| Own cohort | Actual outer UTC interval | Parent / child / original handle | Main / atexit / post-exit peak bytes | Last traced peak / metadata bytes |
| --- | --- | --- | --- | --- |
| 31 baseline | 10:25:42.494313Z-10:25:42.699014Z | 13984 /7444 /484 | 20901888 /not run /20922368 | 3766040 /1558160 |
| 32 shutdown-buffer | 10:26:00.324657Z-10:26:00.538804Z | 1936 /28280 /460 | 20934656 /37720064 /37720064 | 20042751 /1559056 |

Both outer and child exits0; outer elapsed0.2047006000066176 and0.21414470000308938
seconds. Both post-exit current working sets32768 and commit77824; peak commit
13312000 and30216192. Both exports returned BOOL1/error0, matching the original
and self PID. Stream EOFs complete, no overflow/errors, no timeout/kill action;
handle closed=false before queries and true after explicit close.

| Cohort | wait-after ns | K32 query interval ns | psapi query interval ns | Close interval ns |
| --- | --- | --- | --- | --- |
| baseline | 159153152604400 | 159153152756900-159153152770500 | 159153152789500-159153152794300 | 159153152801000-159153152889300 |
| shutdown | 159170984494000 | 159170984637200-159170984650400 | 159170984668400-159170984673400 | 159170984679900-159170984768200 |

Shutdown buffer interval159170967356100-159170970811100, live query
159170970826600-159170970837400, release159170971535200, all before wait-after.
The inspected Windows Python monotonic clock is shared across processes; nanosecond
values are ordering/difference evidence, not UTC epoch values. [Python monotonic](https://docs.python.org/3.13/library/time.html#time.monotonic).
The native peak increase is observed, not asserted to equal exactly16MiB; no
baseline subtraction or maximum assembled from current samples is used.

The startup-enabled tracer was never reset/cleared. Its last reported peak is
still a pre-exit traced-block sample; the native terminal query does not turn it
into a terminal tracemalloc reading. Metadata is separate. The native/traced
lifetimes and measurements must remain distinct. [tracemalloc](https://docs.python.org/3.13/library/tracemalloc.html).

| Actual raw file | Bytes | SHA256 |
| --- | --- | --- |
| 31-cohort-baseline.stdout.txt | 6057 | 90db0e2094b2901a4838cfe27f23f003f3dace0c231b39fb283f2c9a138658b8 |
| child-baseline.stdout.txt | 3322 | 835e0f58a51e63e897aacc8b4adcbf434fb78d727c8749fd9a17c825dec774e2 |
| 32-cohort-shutdown.stdout.txt | 6096 | ae4c757215595b8b2af2eefd2e60b4d91fcb87bf6fa15a4a24ce161849c86782 |
| child-shutdown-buffer.stdout.txt | 5047 | d17fb2624113e17dc627750a3cbe61e4b71fc1fe31a97f7e7b5733f0057e2007 |

All four corresponding stderr files are0 bytes, SHA256
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.
Audit33 matches each parent raw object to its retained child receipt, rechecks
all helper/runtime identities, child raw lengths/hashes, PID attribution, ABI,
the30-second launch deadline and wait/query/close order. Commands40/41 completely
displayed the own child raw records. [Independent audit33](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/33-own-measurement-audit.stdout.txt).

## Deadlines, bounded capture and untested conditions

Each copied parent has an absolute launch-before+30s child deadline, an independent
non-daemon Timer and bounded wait. A rounded early timeout waits until the actual
deadline before known-original-handle kill. Continuous bounded pumps drain both
child pipes. Outer receipt watchdog is180s and can stop only its own immediate
launched child, never foreign PIDs/descendants. Each stream retains<=262144 bytes;
overflow, timeout and actual stopping are explicit. These mechanisms are not OS
hard preemption or allocator quota; scheduling/launch/cleanup can delay receipt
completion. No timeout, blocked pipe, reader fault or kill path was executed.
[Parent deadline/pump code](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/probe_parent.py#L20),
[own outer capture](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/capture.py).

Own capture's `--own-leaf-cwd` transport support was added prospectively before
the two cohorts; it is not a change to copied probe behavior. Static verifier
and audit fixes were prospective; their present helper hashes do not pretend to
be the historical code identity of failed earlier receipts. Own reader threads
do not provide fault-injection proof of all I/O errors; retained successful raw
objects/lengths/hashes establish the observed capture, not general fault tolerance.

No unsupported ABI/export, rights failure, API-unavailable result, post-close
query, process-killed exit, OOM, alternate interpreter/patch/OS, independent birth
accounting instrumentation, or cross-platform reproduction was exercised.
Child sys.getwindowsversion reported10.0.26200 while platform_version reported
10.0.26100; both raw values are preserved without silently choosing one. Online
Python3.13 documentation displayed3.13.16; installed source/runtime are3.13.15.
Official primary browser checks were tool outputs, not downloaded leaf files or
fabricated subprocess receipts, and do not establish patch-portable behavior.

## Actual commands, preserved failures and evidence volume

[COMMAND-INDEX-57.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/COMMAND-INDEX-57.json)
contains all56 prior captured command argv, cwd, actual UTC intervals, exit codes,
split raw bytes/hashes and watchdog/cap fields. Its SHA256 is
af668fe30303797f24dcabc124c1176d6dcba9eb7b6b7358180e42786ae83624. Receipt57 records
the audit itself (10:35:41.884765Z-10:35:41.975500Z, exit0); it does not claim to
include its own future receipt. Earlier COMMAND-INDEX-43.json remains unchanged.

Command families: 01-07 full input reads/display completion;08-16 actual50 seal,
helpers/preparation and receipt schemas;17-21 failed and corrected custody reads;
22-25 actual50 child/parent raw records;26-28 installed ownership/wait/kill source;
29 original measurement static audit;30 exact helper copies;31/32 the ONLY own
measurement parents;33 own static audit;34-39 protected Git state;40/41 own child
raw reads;42/43 failed/corrected own audit;44-47 failed/corrected final task/prep
rereads;48/49 binding/parent line references;50/51 findings focus reads;52-55 fixed
source trees/current checkpoint;56 seal-helper AST parse ONLY;57 custody/index
audit. All static commands other than the six listed below exited0. Browser and
initial bootstrap/pre-write tool-only actions are separately described above.

| Preserved receipt | UTC start-end (2026-10-09 Z) | Exit / actual failure | stderr bytes / SHA256 |
| --- | --- | --- | --- |
| 17-input-custody | 10:20:56.353667-10:20:56.494941 | 1; assumed37 verification.exact_exclusions key | 309 /23f0ed637e8da780907b7cd15dd4fe6b4d788689cfe0683656eec4f2713a9df5 |
| 19-input-custody-schema-corrected | 10:21:16.388143-10:21:16.751207 | 1; assumed49 raw_bytes stream key | 543 /95ea4e14ef41471b2cd2c46541555cb5864745eeadaa35bb6a6170f294adb0f7 |
| 20-receipt49-schema | 10:21:25.754684-10:21:25.823860 | 1; guessed absent01-working-diff.command.json | 772 /d0d8b6af88b1c1247388b3c60f74400a312b14131041f0cb8ab740b80a0e4941 |
| 42-own-pre-report-audit | 10:27:57.520810-10:27:57.600509 | 1; substring argv count incorrectly included static parent reads | 237 /124bfbf502603620b32a70090014c7c11c02a4586b2b4b98c993a2ef16f98058 |
| 44-task55-complete-reread | 10:32:51.044338-10:32:51.113233 | 1; omitted reader's required file selector | 294 /05d40c15c5a00e891f1350568e94fb72115e4605a84c1381089e3c35e9b97974 |
| 45-preparation-reread | 10:32:51.178163-10:32:51.247693 | 1; same omitted selector in second static read | 294 /05d40c15c5a00e891f1350568e94fb72115e4605a84c1381089e3c35e9b97974 |

Their raw failures remain unchanged. Complete actual schemas/interface were
inspected before separately named bounded corrections:21 actual-input schemas,
43 exact4-argv parent count,46/47 explicit file selector. The44/45 pair is an
actual repeated static invocation mistake, not successful reading or compliant
first attempt. No failed probe cohort existed or was retried. Receipt19's partial
stdout4704 bytes/hash d73eaa774120dfbee750d224c2270af2ebaf86e6fb0e7fd9eb913e13ba2294de
is also retained; the other listed failed stdout streams are empty.

Audit57 verified56 prior raw pairs, exactly2 own measurement parents/2 children,
maximum own raw stream27298 bytes, and user AGENTS identity. Its measured checkpoint
was188 files /500056 bytes, including the newly written index but before audit57's
outer files and this report. This is not a fabricated final-seal count. All own
files remain well below4MiB. A final report-read receipt and actual one-time seal
will be separately identified; no future result/count/hash is asserted here.

## Write scope and protected state

Exclusive new write scope is
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-json-terminal-independent-20261009-55/.
Only own readers/capture/static custody/audit/copy/seal helpers, exact three
authorized probe copies, preparation, raw receipts, indexes and this report were
written there. No peer/sealed input, Main source/doc/worktree, index or HEAD was
edited by this reviewer; no commit, push, cleanup, install or delegation occurred.

Measured Git commands34/35 exited0 with empty stdout/stderr for committed b80-to-
then-HEAD and working src/scripts diffs. Command36 tracked status showed only
` M AGENTS.md`;38 cached names were empty. Command37/55 then-HEAD was Root's
e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1 documentation-only freeze. Commands52-54
confirmed d57:src, b80:src and then-HEAD:src all equal
85f53265bf4ee59b65c4a88664cb2e5e208c583e. Later Root doc-only HEAD moves do not
alter the fixed inputs and are not claimed to have been performed by this worker.

## Required Gates, completed scope and remaining v1.8 work

Completed: independent complete exact input reads, actual four-leaf custody/raw
verification, official API and installed-source assessment, exact-copy two-cohort
local reproduction, result attribution/order/hash checks, protected-state checks
and this findings-first report. No project functionality or diagnostic convention
was adopted or implemented. Added tests are evidence-only finite counter checks
and static verifiers; no product/decoder tests were added or run.

Unfinished/unqualified: unchanged37's finite<=12 structural resource-case families,
decoder/generated input/live-result qualification, each traced/native lifetime
ceiling268435456 bytes, decode<=60s absolute deadline and mandatory unavailable-
counter handling across the actual intended decoder cases. Native terminal
retrieval is distinct from terminal traced coverage. Other-platform and complete
RSS/native-allocation/hard-quota claims remain unqualified. Payload/node/name/depth/
string/numeric caps and required deadline checks were not amended or tested here.

No Gradle clean build/runData/runGameTestServer, native server, decoder, world,
NBT/framing/schema driver, persistence/restart, client visual or license Gate
execution was authorized or performed. They are NOT_RUN/OUT_OF_SCOPE, not PASS.
Fixed v1.8 remains IN_PROGRESS with separate G0-G9; previous v1.7 is IN_PROGRESS,
not PASSED. ADR-060 development-only status does not grant acceptance. This task
does NOT satisfy all current-version Required Gates and cannot change their state.

Key decisions: use fixed commits/exact sealed inputs; keep original-owned handle
and exact unchanged probe behavior; preserve independent native/traced/lifetime
semantics and all failures; do not select helper or narrow qualification. Known
risks and R49-01/U01/U02 remain explicit above. v1.8-only next step: Root can
separately disposition the measured local feasibility and remaining lifetime
boundary; any decoder/resource qualification requires its own bounded assignment
against the unchanged requirements. No future-version implementation is proposed.

## Report custody protocol - pending, not acceptance

This stable report is delivered for Root's complete exact-hash read before any
one-time own seal. seal.py was only AST-parsed at command56; no seal was executed
at report preparation. Root acknowledgment must name the exact report hash,
bytes and lines; it will be saved with its actual message and received UTC in
ROOT-READ-ACK.json before that sole seal execution.

The prospective seal excludes exactly manifest self, SEAL-RESULT.json and the
three outer custody-seal-final receipt/stream files because they are written
after covered-member enumeration. Actual exclusions, result/receipt hashes and
covered/whole-leaf totals must be checked and delivered after the actual seal;
they are not assumed here. No existing report/helper/raw evidence is rewritten
after seal. Custody acknowledgment/review/manifest verification does not authorize
R49-01/U01/U02 closure, diagnostic adoption, helper selection, measurement narrowing,
decoder/runtime tests, production behavior or Gate acceptance.
