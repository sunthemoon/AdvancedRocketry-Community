# Task40 independent offline JSON core contract review

Date: 2026-10-09 UTC. Fresh delegated independent reviewer, not Root or author37.
Static review only. The candidate remains **PROPOSED**; this report grants no
adoption, implementation, test, native-runtime, production or Gate authority.

## Findings first

### R01 - Low: preflight and partial-token diagnostic accounting needs a fixed convention

The proposed result always contains integer metrics, including `input_bytes` and
`consumed_bytes`, and an error offset in `0..input_bytes`. It also returns
`INPUT_TYPE` for objects that are not exactly built-in bytes. The contract does
not specify the metric/offset sentinel for that case. An implementation must not
derive a length by invoking arbitrary rejected objects' methods merely to fill
these diagnostics. See [proposal01:37-40, 154-183](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md#L158).

For failures within a token, the document says counters describe "admitted work"
and reserves nodes/names before construction/decode, but does not precisely say
whether a reservation commits the counter before lexical completion, or how
`consumed_bytes` treats a inspected-but-unconsumed offending byte. A malformed
string or escaped duplicate name can therefore yield different metrics under
reasonable implementations without changing accepted input. See
[proposal01:84-89, 99-106, 158-182](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-offline-json-core-contract-20261009-37/PROPOSED-OFFLINE-JSON-CORE-01.md#L158).

Before implementation, specify these diagnostic conventions and assert them in
the proposed preflight/mid-token refusal tests. This is a minor API/accounting
ambiguity, not an identified admission bypass, unsafe allocation, native defect
or reason to change any existing cap. This reviewer does not silently choose the
sentinel or counter convention on the contract owner's behalf.

No Critical, High or Medium contradiction requiring a wider source/schema/runtime
scope is identified in this narrowed contract. No executable decoder was inspected
or exercised, so this is not a claim that an implementation is correct or safe.

## Supported scope and implementability assessment

The candidate supplies a coherent standalone generic-decoding sub-slice, subject
to the diagnostic clarification above and separate integrator disposition:

- Exact built-in immutable bytes; a compact object root, EOF after the object,
  no insignificant whitespace; bounded ordinary JSON values below that root.
  Root primitives/arrays, comments, alternate quoting, repairs and framing are
  explicitly outside the supported profile, not silently normalized.
- Scalar-only canonical UTF-8 and paired surrogate escapes; decoded-name equality
  and escaped aliases checked before decoding the member value or overwriting a
  name. Raw versus escaped supplementary scalars have the same equality relation;
  no Unicode normalization or preservation of lone surrogate strings is promised.
- Unchanged inclusive limits: 524288 original bytes; 65536 value nodes and global
  names; 64 names/object and container depth; 4096 UTF-16 units/string or name;
  64 ASCII bytes/numeric lexeme. Iterative checked construction, bounded scratch
  and no eager unqualified general JSON tree are explicitly required.
- Numbers are inert frozen `JsonNumber` lexemes with original-byte spans. This is
  an explicit new internal representation, not an inherited native number type.
  It avoids generic magnitude expansion without claiming finite source float or
  int32/int64 validity. Boolean versus number remains distinguishable downstream.
- Success and refusal are separate frozen result records. The success tree is
  deliberately mutable/exclusively owned and cannot replace original evidence
  bytes. Refusal returns no partial tree; locations use bounded ordinals rather
  than unbounded textual key paths. Unexpected exceptions/OOM/host termination
  remain qualification failures, not manufactured successful refusals.
- The absolute cooperative monotonic deadline, fixed 60-second call maximum,
  180-second external child ceiling, 256 KiB streams, 4 MiB evidence and 256 MiB
  traced/peak-process budgets are stated. Cooperative checks are expressly not
  OS preemption, hard allocator enforcement or a promise of a receipt after OOM.
- Prospective ownership is exactly the two internal script/test files, in a later
  assigned isolated worktree. No integration call site, public framework, central
  build/state edit or native helper is included.

These conclusions come from complete proposal01 lines 22-191 and 245-271, compared
with complete predecessor proposal03 lines 635-686 and 690-699. The predecessor's
numeric field/range policy belongs to its whole source-aware parser; deferring it
here is explicit separation, not a claim that structural decoding satisfies it.
Unknown generic keys are acceptable only at this layer, whereas the subsequent
source-schema union still requires its exact known keys/types/collections.

The dominated global-name boundary is correctly identified: each successful name
has a value, so `names <= nodes - 1 <= 65535`. Its 65536/65537 private-counter test
is not an accepted end-to-end payload. The node recipe, root plus an array plus
65534 scalar values, accounts for 65536 nodes. Depth root plus 63 nested arrays
accounts for 64 containers. These are static arithmetic observations; no synthetic
bytes, decoder, prototype or test were created or executed by Task40.

The synthetic plan covers supported values, at-limit/one-over bytes/nodes/object
names/depth/UTF-16/numbers, duplicate aliases, malformed UTF-8/escapes, wrong root,
deadline/error behavior and clearly labeled structural resource cases. Peak
tracemalloc is kept separate from lifetime peak RSS/working-set. Platform counter
availability, units and meaning require independent checking; unsupported counters
remain UNQUALIFIED. These are finite verification requirements, not measured
worst-case performance or proof that every legal payload fits the resource budget.

## Actual fixed-source boundaries and residual qualification

Actual d57 Trace35-40 fixes source event/byte/frame/identity limits and the Gson
policy. Trace100-139 and 324-328 perform source-specific counter-writer accounting
and final serialization, not this Python generic decoder's accounting. Trace236-241
preflights native component receivers/budget before native serialization.
ChatBounds28-98 separately bounds visits/depth/text and exact native receivers.
Fixture77-106 and 114-126 distinguish opt-in console/native execution and raw
response emission from any successful structural decode. These are selected
boundary reads, **not a new exhaustive review of all three Java files**.

The proposal accurately leaves source schema, exact Gson row-byte 131072 checks,
int32/int64/finite-float conversions, source-specific string/collection caps and
provenance downstream. The defensive 2049 combined-ID envelope is not called a
reachable native maximum; `floor(8192/6)+1 = 1366` is only a loose shared-budget
analytical ceiling, consistent with ChatBounds34-44 and review26 R02.

No generic-decoding success qualifies producer Unicode/lone-surrogate fidelity,
framing/cursors, diagnostic/native-log capture, NBT/modified UTF-8/gzip, source
serializer behavior, actual native effects, saved Spawn/durability, the twenty
observation rows, D1 runtime rows, production B1/R1/M1/M2, clients or Gates.
Checkpoint39's separate narrowed log refusal freeze is read as a requirements
disposition, not as generic parser execution or whole-driver adoption. Standard
d57 results in checkpoint32 remain historical, including strict timeout and
unwaived native errors; nothing is rerun or rebound to this record-only review.

## Fixed identities and complete-read coverage

Governance: `cd9b54a23b5bf92760b05655a427344d6b620984`.
Observation source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Author37 governance stays historical `9edbcab9ba53f2aaf4861867a916fbe424972c07`.
Predecessor20 source stays historical 5b451320; no earlier result is retrofitted.

| Complete input | Bytes /lines | SHA256 |
|---|---:|---|
| Task40 | 4586 /70 | b3a89e613a4a1592099832745538c1aa48c2cdbfc8c490ee7ab6e79e359bdaf0 |
| Supplement41 | 1946 /30 | 932753ab8eb1674fd6b7331e32cea80edf83a9235334db71df46affddf32938b |
| Task37 | 4634 /77 | 8d356475549ff4971a38c6566750a22833bd85807a3634791496e913d7564152 |
| Author37 proposal01 | 19096 /271 | f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0 |
| Author37 REPORT | 16797 /225 | 1f775414b3937a5d1813b57b511c616c0003bc09c7cadba07bf7424844b9bbb2 |
| Task20 proposal03 | 68873 /991 | c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680 |
| Task20 REPORT | 17261 /245 | 06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6 |
| Independent26 REPORT | 24412 /332 | e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc |

All mandatory governance documents are completely displayed from fixed Git
objects: config 81, product 105, principles 170, roadmap 157, actual uppercase v1.8
247, master-test 332, release-gates 196, post-1.0 roadmap 227, quality 222, parallel 199
and fixed AGENTS 220 lines. ADR060's 132 lines are also read. Fixed checkpoints 27/32/
33/36/39 are completely read at 149/166/113/105/109 lines, owner01/03 at 30/39.
The actual fixed tree was narrowly inspected before reading the version path.
Proposal03 is displayed through four contiguous nontruncated ranges, 1-250,
251-500, 501-750 and 751-991, all at the same SHA. The other required final
documents are completely displayed without truncation. Raw storage alone is not
used as a substitute for complete required reading.

| d57 source identity | Bytes /lines | Git blob /SHA256 |
|---|---:|---|
| Fixture | 33987 /497 | 8e02816298e750a0b80f5b164ee2b87871028112 /1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |
| Trace | 27593 /445 | 5caa936f41328f216afffa80fc86682a17a6b743 /20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f |
| ChatBounds | 15889 /238 | b9a2758179f27369b0dd56392bb4b3220fdb8d6b /16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0 |

Only selected numbered source excerpts and whole-blob identities are retained.
No full source/library/world/build tree or archive is exported or extracted.

## Actual commands, preparation failures and limits

Initial Task40 Get-Content/Get-FileHash and the combined bootstrap exploration
are tool-only records with no saved raw split-stream receipt or independently
enforced 180-second child watchdog. The latter mistakenly included a broad
fixed `docs/work` tree listing. The tool reports 147704 original tokens /7006
lines and truncated output. Its raw-stream size/hashes cannot be established;
it is **not** counted as a compliant bounded check or completed required read.
No helper/leaf/source/index/HEAD write had occurred. The reviewer stopped and
reported this, then received the exact separate bounded-retry Supplement41.
The broad command is not rerun, and bootstrap streams/timestamps are not invented.

Corrected pre-write status and worktree commands are separately displayed with
true child argv/cwd/UTC/exit/raw hashes and explicit 180-second timeouts. They
return 0, with 10820/13143 stdout bytes and empty stderr. Their stdout hashes are
28e0b7475a80b16beb69d3c58b7096f629b034ed40181f98a526121a9af49746 and
06fea2ab7d967824b82b49894033899feb6610a7e4aa306a855a45af8fbd00ef.
Those are actual printed receipts, not persisted raw captures reconstructed later.

Applicable working AGENTS and external ancestors are checked before leaf/helper
creation. Only repository AGENTS exists among the five named checked ancestors;
its actual working bytes are 15797, SHA256
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.
The first inline Python display has lossy ambient encoding; a complete explicit
UTF-8 reread of all 327 lines precedes writing, together with Supplement41.
These inline displays lack an independent child watchdog/persisted split-stream
capture. This further preparation instrumentation gap is separately reported to
Root and retained, not erased by subsequent captured rereads. Tool exits are 0
and actual durations under one second; that is not a manufactured watchdog.
Live team state is checked with collaboration.list_agents; no delegation occurs.
The own leaf is confirmed absent and then created; no existing leaf is overwritten.

Subsequent operations use `python -B <own-leaf>/static_receipt.py <unique-name>
-- <actual-child-argv>`, cwd `D:/GitHub/AdvancedRocketry-Community`. Each retains
unaltered `.stdout`, `.stderr` and `.json` containing immediate pre-start/end UTC,
actual argv/cwd/exit, 180-second timeout and stream lengths/SHA256. Operations are
fixed Git show/ls-tree/grep/status/rev-parse, bounded explicit file reads, own-leaf
inspection and actual external-seal hashing. No captured operation times out or
exceeds 256 KiB; original receipts are never overwritten. Exact per-command
identities/results remain in the receipts and final command index.

Actual static tooling is Python 3.13.15, executable
`D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe`, SHA256
85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd.
This identity is not qualification of a future decoder environment. Final status
matches the corrected preflight status hash; user AGENTS/untracked files remain.
Root independently moves Main to b0b818261621d6c607386925535a62f027dfbf8b during
this review; no task input is rebound and the reviewer never moves HEAD/index.

## Actual custody and evidence volume

`actual-custody-audit` verifies every one of the 437 covered members across the three input
leaves, safe case-unique relative names, regular/contained files, ancestor/member
reparse absence, actual manifest hashes and exact uncovered-file inventories.
The actual author37 seal is inspected after creation, not inferred from permission.

| Actual input seal | Manifest SHA256 | Covered files /bytes |
|---|---|---:|
| Author37 | 1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763 | 90 /649019 |
| Task20 | b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0 | 198 /1089641 |
| Independent26 | 9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d | 149 /1890251 |

Each excludes exactly `SHA256SUMS.txt` self and `SEAL-RESULT.json`. Author37's
actual manifest is 8615 bytes; its result is 2222 bytes, SHA256
719d27a044cc4b6e964245e6451cc09bb7d452ddd01c5a207f068cb3ebe3d38f.
Its complete physical leaf is 92 files /659856 bytes. Actual Root-read ACK and
coverage text bind the exact final proposal/report and custody-only permission.
Embedded result streams are independently decoded/hash-checked where recorded;
all three seal exits are 0. Custody is not adoption or behavior qualification.
Task20's external placeholder remains outside its covered leaf; no incident,
runtime output or earlier denied cleanup target is examined or modified here.
Committed ZIP CRC/archive-to-external-leaf equality is **not rerun by Task40**;
this conclusion covers the actual named external manifests/files, not all archives.

The own pre-report/pre-final-index checkpoint is 623029 bytes. Final command index,
report identity audit and eventual seal necessarily follow this report's creation;
their actual volume/count/hash results are delivered separately. The unchanged
4 MiB own-leaf and 256 KiB stream caps remain. This is not a cumulative sleep-slice
launch inventory, a conservative-admission fix or permission to relabel/delete
old evidence. No temporary archive, runtime/build/world directory is created.

## Completion, modifications, tests, risks and Gates

Completed: fixed mandatory governance/checkpoint/owner reads; complete exact final
candidate/predecessor/task reads; selected actual three-source-boundary inspection;
independent actual external seal/hash/custody checks; findings and supported-scope
assessment; bounded static evidence and this report in the exclusive leaf.

Uncompleted: integrator disposition and R01 diagnostic convention; implementation,
synthetic/boundary/resource qualification; source schema/conversions/Gson and
provenance; framing/capture/log/NBT; native observations, production and acceptance.
No conclusion about independent38 diagnostics is borrowed into this review.

Key review decisions: unchanged bounds and refusal profile; number representation
and mutable result ownership kept explicit; additional defensive source-valid
refusals separated from native failures; source/runtime/Gate evidence not inferred
from generic structural success. No source test assertion or budget is weakened.

Modified files: only this assigned new external leaf's REPORT, static evidence and
sealing helpers, unique raw command receipts and later own index/ack/coverage/
manifest/result. No project/source/test/API/schema/asset/provenance/ledger/status,
other leaf, index or HEAD modification; no commit/push/worktree creation/cleanup.
Root coordinates OpenPet; this reviewer emits no pet events or delegates work.

**Tests added/modified/executed: NONE; all decoder tests NOT_EXECUTED.**
Gradle clean build/test/runData/generated diff/runGameTestServer, JVM/server,
dedicated/restart/real-client/native Unicode and performance/resource tests are
NOT_EXECUTED under this static task, not PASS or NOT_APPLICABLE. Hash/manifest
checks are custody checks, not tests of decoder/native behavior.

Known risks: Low diagnostic ambiguity; unqualified actual allocation/RSS/deadline
and platform counters; deliberately stricter refusal of source-valid input;
irrecoverable producer surrogate loss; all downstream source/native prerequisites;
and disclosed bootstrap/truncation/encoding/watchdog/raw-capture gaps. Historical
timeout, native errors, retention/incidents and link issues remain unwaived.

**All current and inherited Required Gates G0-G9 satisfied: NO.** Fixed v1.8
status remains IN_PROGRESS; no release/tag, ledger delivery, accepted candidate,
executable assignment or whole-driver/native qualification follows this review.
Next v1.8-only work: integrator disposition of the exact candidate and diagnostic
convention; only then a separately assigned bounded implementation/test slice.
All subsequent schema/Gson/provenance/runtime prerequisites remain separate.

Root must completely read this stable final REPORT at its actual lines/bytes/SHA
before a one-time own custody seal. No acknowledgement or own seal is preclaimed.
