import base64
import datetime
import hashlib
import json
import pathlib
import stat
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
CWD = 'D:/GitHub/AdvancedRocketry-Community'
EXPECTED = 'aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60'
EXCLUDED = {'SHA256SUMS.txt', 'SEAL-RESULT.json'}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(b):
    return hashlib.sha256(b).hexdigest()

def check_path(p):
    for q in [p] + list(p.parents):
        s = q.lstat()
        assert not stat.S_ISLNK(s.st_mode)
        assert not (getattr(s, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    assert p.resolve().is_relative_to(ROOT)

def child():
    assert not any((ROOT / n).exists() for n in EXCLUDED)
    report = (ROOT / 'REPORT.md').read_bytes()
    assert len(report) == 18632 and len(report.splitlines()) == 280 and sha(report) == EXPECTED
    ack = json.loads((ROOT / 'ROOT-READ-ACK.json').read_bytes())
    assert ack['report_sha256'] == EXPECTED and ack['custody_permission_only'] is True
    rows = []
    seen = set()
    for p in sorted(ROOT.rglob('*')):
        check_path(p)
        relative = p.relative_to(ROOT).as_posix()
        assert ':' not in relative and '\\' not in relative
        assert relative.casefold() not in seen
        seen.add(relative.casefold())
        assert not any(x in ['.', '..'] for x in pathlib.PurePosixPath(relative).parts)
        if p.is_dir():
            continue
        assert stat.S_ISREG(p.lstat().st_mode)
        b = p.read_bytes()
        assert len(b) < 50000000
        rows.append((relative, len(b), sha(b)))
        if p.suffix == '.json' and (ROOT / (p.stem + '.stdout')).exists():
            r = json.loads(b)
            assert r['exit'] == 0 and r['error'] is None and r['timeout_seconds'] == 180
            for stream in ['stdout', 'stderr']:
                raw = (ROOT / (p.stem + '.' + stream)).read_bytes()
                assert len(raw) == r[stream + '_bytes'] <= 262144
                assert sha(raw) == r[stream + '_sha256']
    manifest = ''.join(d + '  ' + n + '\n' for n, _, d in rows).encode('utf-8')
    covered_bytes = sum(s for _, s, _ in rows)
    assert covered_bytes + len(manifest) + 262144 < 4194304
    with (ROOT / 'SHA256SUMS.txt').open('xb') as f:
        assert f.write(manifest) == len(manifest)
        f.flush()
    assert (ROOT / 'SHA256SUMS.txt').read_bytes() == manifest
    for n, size, digest in rows:
        b = (ROOT / n).read_bytes()
        assert len(b) == size and sha(b) == digest
    print(json.dumps({'covered_files': len(rows), 'covered_bytes': covered_bytes,
                      'manifest_bytes': len(manifest), 'manifest_sha256': sha(manifest),
                      'all_covered_match': True, 'report_sha256': EXPECTED,
                      'excluded': sorted(EXCLUDED)}))

def outer():
    assert not any((ROOT / n).exists() for n in EXCLUDED)
    argv = [sys.executable, '-B', str(pathlib.Path(__file__).resolve()), '--child']
    started = utc()
    clock = time.monotonic()
    p = subprocess.run(argv, cwd=CWD, capture_output=True, timeout=180)
    ended = utc()
    assert len(p.stdout) <= 262144 and len(p.stderr) <= 262144
    result = {'kind': 'actual-one-time-custody-seal-not-adoption-or-qualification',
              'argv': argv, 'cwd': CWD, 'start_utc': started, 'end_utc': ended,
              'elapsed_seconds': time.monotonic() - clock, 'exit': p.returncode,
              'timeout_seconds': 180, 'stream_limit_bytes': 262144,
              'excluded_from_manifest': True}
    for stream, b in [('stdout', p.stdout), ('stderr', p.stderr)]:
        result[stream + '_bytes'] = len(b)
        result[stream + '_sha256'] = sha(b)
        result[stream + '_base64'] = base64.b64encode(b).decode('ascii')
    if p.returncode == 0:
        result['verification'] = json.loads(p.stdout)
    encoded = (json.dumps(result, indent=2) + '\n').encode('utf-8')
    assert sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file()) + len(encoded) <= 4194304
    with (ROOT / 'SEAL-RESULT.json').open('xb') as f:
        f.write(encoded)
    print(p.stdout.decode('utf-8'))
    if p.stderr:
        print(p.stderr.decode('utf-8'))
    files = [p for p in ROOT.rglob('*') if p.is_file()]
    print(json.dumps({'seal_result_bytes': len(encoded), 'seal_result_sha256': sha(encoded),
                      'actual_files': len(files), 'actual_bytes': sum(p.stat().st_size for p in files)}))
    raise SystemExit(p.returncode)

if __name__ == '__main__':
    if '--child' in sys.argv:
        child()
    else:
        outer()
