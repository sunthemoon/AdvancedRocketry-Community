import datetime
import hashlib
import json
import subprocess
import sys

SOURCE = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
CWD = 'D:/GitHub/AdvancedRocketry-Community'
RANGES = {
    'SleepBoundaryTrace.java': [(28, 149), (302, 445)],
    'SleepBoundaryChatBounds.java': [(28, 140), (180, 238)],
    'SleepBoundaryObservationFixture.java': [(40, 113)],
}
name = sys.argv[1]
path = 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name
argv = ['git', 'show', SOURCE + ':' + path]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = subprocess.run(argv, cwd=CWD, capture_output=True, timeout=180)
print(json.dumps({'argv': argv, 'cwd': CWD, 'start_utc': start,
                  'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'exit': p.returncode, 'stdout_bytes': len(p.stdout),
                  'stderr_bytes': len(p.stderr),
                  'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                  'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()}))
if p.returncode or len(p.stdout) > 262144 or len(p.stderr) > 262144:
    raise SystemExit('SOURCE_INSPECTION_STOP')
lines = p.stdout.decode('utf-8').splitlines()
print('SOURCE_LINES=' + str(len(lines)))
for first, last in RANGES[name]:
    print('RANGE=' + str(first) + '-' + str(last))
    for n in range(first, min(last, len(lines)) + 1):
        print(str(n) + ': ' + lines[n - 1])
