import hashlib
import json
import pathlib
import stat

BASE = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
EXPECTED = {
    'sleep-offline-json-core-contract-20261009-37': ('1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763', 90, 649019),
    'sleep-observation-driver-revision-20261009-20': ('b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0', 198, 1089641),
    'sleep-observation-driver-revision-independent-20261009-26': ('9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d', 149, 1890251),
}

def h(b):
    return hashlib.sha256(b).hexdigest()

def regular(p):
    for q in [p] + list(p.parents):
        s = q.lstat()
        assert not (getattr(s, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT), str(q)
    assert p.is_file(), str(p)

for name, (digest, count, size) in EXPECTED.items():
    leaf = BASE / name
    manifest = leaf / 'SHA256SUMS.txt'
    regular(manifest)
    raw = manifest.read_bytes()
    assert len(raw) <= 262144
    assert h(raw) == digest, name
    members = {}
    for line in raw.decode('utf-8').splitlines():
        if not line.strip():
            continue
        expected, relative = line.split('  ', 1)
        path = pathlib.PurePosixPath(relative)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in relative
        assert ':' not in relative and len(expected) == 64
        assert relative.casefold() not in members
        p = leaf.joinpath(*path.parts)
        regular(p)
        assert p.resolve().is_relative_to(leaf.resolve())
        assert p.stat().st_size <= 4194304
        data = p.read_bytes()
        assert h(data) == expected, relative
        members[relative.casefold()] = (relative, len(data), expected)
    actual = {p.relative_to(leaf).as_posix() for p in leaf.rglob('*') if p.is_file()}
    uncovered = actual - {x[0] for x in members.values()}
    assert uncovered == {'SHA256SUMS.txt', 'SEAL-RESULT.json'}, uncovered
    assert len(members) == count and sum(x[1] for x in members.values()) == size
    result = leaf / 'SEAL-RESULT.json'
    regular(result)
    rb = result.read_bytes()
    assert len(rb) <= 262144
    record = {'leaf': str(leaf), 'manifest_bytes': len(raw), 'manifest_sha256': h(raw),
              'covered_files': len(members), 'covered_bytes': sum(x[1] for x in members.values()),
              'exclusions': sorted(uncovered), 'seal_result_bytes': len(rb), 'seal_result_sha256': h(rb),
              'actual_files': len(actual), 'actual_bytes': sum(p.stat().st_size for p in leaf.rglob('*') if p.is_file())}
    if name.endswith('-37'):
        assert len(rb) == 2222 and h(rb) == '719d27a044cc4b6e964245e6451cc09bb7d452ddd01c5a207f068cb3ebe3d38f'
    print(json.dumps(record, ensure_ascii=True))
    print('SEAL_RESULT=' + rb.decode('utf-8'))
    for extra in ['SEAL-COVERAGE.md', 'ROOT-READ-ACK.json']:
        p = leaf / extra
        if p.exists():
            data = p.read_bytes()
            assert len(data) <= 262144
            print('CUSTODY_DOCUMENT=' + extra + ' BYTES=' + str(len(data)) + ' SHA256=' + h(data))
            print(data.decode('utf-8'))
