# Task40 one-time custody coverage

ROOT-READ-ACK.json records the actual Root complete-read acknowledgment for the
stable 280-line /18632-byte REPORT at SHA256
aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60.
It permits this own leaf's one-time seal only. R01 and all implementation/test/
native/Gate prerequisites remain open; the candidate stays PROPOSED.

The manifest covers all existing regular files in this exclusive leaf, including
helpers, raw captured static streams and receipts, command index, REPORT, actual
acknowledgment and this coverage document. Complete exact exclusions:

1. SHA256SUMS.txt: manifest self-reference.
2. SEAL-RESULT.json: sole later operation result, with actual child argv/cwd,
   pre-start/end UTC/exit and unchanged raw split streams encoded as base64 with
   hashes. It cannot exist before sealing.

No wildcard or additional command/stream exclusion is admitted. Case-unique safe
relative names, regular containment and all ancestor/member reparse boundaries
are checked. Report/ack identity, all captured split-stream identities, every
written manifest entry and the unchanged 4 MiB/256 KiB limits are verified.

The original broad truncated bootstrap and later inline preflight instrumentation
gaps remain the report's disclosed tool-only limitations; no retrospective raw
streams or timestamps are invented. This seal binds actual retained custody only,
not every historical tool action, parser behavior, native success or acceptance.
Covered bytes and manifest are immutable after the seal. Future corrections must
be separate additive records, not edits to this package or predecessor packages.
