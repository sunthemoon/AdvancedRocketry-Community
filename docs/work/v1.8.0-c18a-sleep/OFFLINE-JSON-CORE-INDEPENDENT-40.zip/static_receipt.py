import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
CWD = 'D:/GitHub/AdvancedRocketry-Community'
LIMIT = 262144
BUDGET = 4194304

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def volume():
    return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())

def main():
    p = argparse.ArgumentParser()
    p.add_argument('name')
    p.add_argument('--start', type=int, default=1)
    p.add_argument('--end', type=int, default=100000)
    p.add_argument('argv', nargs=argparse.REMAINDER)
    args = p.parse_args()
    argv = args.argv
    if argv and argv[0] == '--':
        argv = argv[1:]
    if not argv:
        raise SystemExit('Missing argv')
    targets = [ROOT / (args.name + suffix) for suffix in ['.stdout', '.stderr', '.json']]
    if any(t.exists() for t in targets):
        raise SystemExit('Receipt already exists')
    start = utc()
    try:
        result = subprocess.run(argv, cwd=CWD, capture_output=True, timeout=180)
        out, err, code = result.stdout, result.stderr, result.returncode
        error = None
    except subprocess.TimeoutExpired as exc:
        out, err, code = exc.stdout or b'', exc.stderr or b'', None
        error = 'TIMEOUT_180_SECONDS'
    if len(out) > LIMIT or len(err) > LIMIT:
        error = 'STREAM_LIMIT_STOP'
    receipt = {'argv': argv, 'cwd': CWD, 'start_utc': start, 'end_utc': utc(),
               'timeout_seconds': 180, 'stream_limit_bytes': LIMIT, 'exit': code,
               'error': error, 'stdout_bytes': len(out), 'stderr_bytes': len(err),
               'stdout_sha256': sha(out), 'stderr_sha256': sha(err),
               'display_start': args.start, 'display_end': args.end}
    encoded = (json.dumps(receipt, indent=2, ensure_ascii=True) + '\n').encode('utf-8')
    if volume() + len(out) + len(err) + len(encoded) > BUDGET:
        print(json.dumps(receipt))
        raise SystemExit('OWN_LEAF_LIMIT_STOP')
    for t, data in zip(targets, [out, err, encoded]):
        with t.open('xb') as f:
            f.write(data)
    print(json.dumps(receipt))
    if error:
        raise SystemExit(error)
    lines = out.decode('utf-8-sig', errors='strict').splitlines()
    for n in range(max(1, args.start), min(len(lines), args.end) + 1):
        print(str(n) + ': ' + lines[n - 1])
    if err:
        print('STDERR=' + err.decode('utf-8', errors='strict'))
    print('LINES=' + str(len(lines)) + ' OWN_LEAF_BYTES=' + str(volume()))
    raise SystemExit(code)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
