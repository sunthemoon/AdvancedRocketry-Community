"""Check only this review's own persisted command evidence before sealing."""
import hashlib
import json
import pathlib
import stat

LEAF = pathlib.Path(__file__).resolve().parent
EXPECTED = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-owner-decision-independent-20261009-14").resolve()
assert LEAF == EXPECTED
assert not (LEAF / "SHA256SUMS.txt").exists()
files = []
for path in LEAF.rglob("*"):
    details = path.lstat()
    assert not path.is_symlink()
    assert not getattr(details, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT
    path.resolve().relative_to(LEAF)
    if path.is_file():
        assert path.stat().st_size <= 50 * 1024 * 1024
        files.append(path)
assert sum(p.stat().st_size for p in files) <= 100 * 1024 * 1024
commands = [json.loads(line) for line in (LEAF / "commands.jsonl").read_text(encoding="utf-8").splitlines()]
verified_streams = 0
context_reads = 0
exits = {}
for record in commands:
    assert record["argv"]
    assert record["pre_start_utc"] and record["end_utc"]
    exits[str(record["exit_code"])] = exits.get(str(record["exit_code"]), 0) + 1
    if record.get("context_only"):
        context_reads += 1
        continue
    for stream in ("stdout", "stderr"):
        path = LEAF / record[stream]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == record[stream + "_sha256"]
        verified_streams += 1
assert (LEAF / "ROOT-READ-CONFIRMATION.md").is_file()
assert (LEAF / "EXPLORATORY-FAILURES.md").is_file()
task = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OWNER-DECISION-REVIEW-TASK-14.md")
assert hashlib.sha256(task.read_bytes()).hexdigest() == "3112dbb1441687f4e62e3d12ac23cf7ec1321f38a345d046e41244c86141b6dd"
print(json.dumps({"leaf": str(LEAF), "contained_regular_files_before_final_capture": len(files),
                  "bytes_before_final_capture": sum(p.stat().st_size for p in files),
                  "captured_command_records_checked": len(commands),
                  "verified_raw_stream_files": verified_streams,
                  "context_reads_without_whole_document_copies": context_reads,
                  "recorded_exit_counts": exits,
                  "report_sha256": hashlib.sha256((LEAF / "REPORT.md").read_bytes()).hexdigest(),
                  "task_sha256_reverified": True, "root_full_read_record_present": True,
                  "safe_scope_and_hash_audit": "PASS"}, indent=2))
