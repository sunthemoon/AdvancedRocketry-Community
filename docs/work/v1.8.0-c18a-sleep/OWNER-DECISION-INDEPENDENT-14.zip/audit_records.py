"""Fixed-blob record checks. No repository writes or source exports."""
import datetime
import hashlib
import io
import json
import pathlib
import re
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
LEAF = pathlib.Path(__file__).resolve().parent
CWD = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
NEW = "48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514"
OLD = "608f04360522f9aa2d1fdaab09d853d4cb4075f9"
PREFIX = "docs/work/v1.8.0-c18a-sleep/"
TASK = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-OWNER-DECISION-REVIEW-TASK-14.md")


def git(*args):
    argv = ["C:/Program Files/Git/cmd/git.exe", *args]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=CWD, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=180)
    end = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record = {"argv": argv, "cwd": str(CWD), "pre_start_utc": start,
              "end_utc": end, "exit_code": result.returncode,
              "stdout_bytes": len(result.stdout),
              "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
              "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()}
    if result.returncode:
        number = len(list(LEAF.glob("inner-failure-*.stdout.txt"))) + 1
        for stream in ("stdout", "stderr"):
            name = "inner-failure-" + str(number) + "." + stream + ".txt"
            (LEAF / name).write_bytes(getattr(result, stream))
            record[stream] = name
    with (LEAF / "fixed-input-reads.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    if result.returncode:
        print(json.dumps(record, ensure_ascii=False))
        print(result.stderr.decode("utf-8", errors="replace"))
        raise SystemExit(result.returncode)
    return result.stdout


def blob(path, rev=NEW):
    return git("show", rev + ":" + path)


def text_blob(path, rev=NEW):
    return blob(path, rev).decode("utf-8")


def numbered(path, start, end):
    value = text_blob(path)
    print("\nFIXED " + NEW + ":" + path)
    for number, line in enumerate(value.splitlines(), 1):
        if start <= number <= end:
            print(str(number) + ": " + line)


def references():
    pattern = "OWNER-QUESTION-02|OWNER-DECISION-03|ancillary.*(pending|unanswered)|pending.*ancillary|unanswered.*ancillary|连带.*待答"
    print(git("grep", "-n", "-I", "-E", pattern, NEW, "--", "*.md").decode("utf-8"))
    print("APPLICABLE AGENTS PATHS")
    for path in git("ls-tree", "-r", "--name-only", NEW).decode("utf-8").splitlines():
        if pathlib.PurePosixPath(path).name == "AGENTS.md":
            print(path)


def transcription():
    source = TASK.read_bytes()
    source_text = source.decode("utf-8")
    question = source_text.split("Exact question:\n", 1)[1].split("\n\n", 1)[0].strip()
    answer = source_text.split("Exact submitted answer:\n", 1)[1].split("\n\n", 1)[0].strip()
    item = '["request_user_input_async","call_2b69aa5cae214f4fb422c90bfc225f8f",0]'
    decision = text_blob(PREFIX + "OWNER-DECISION-03.md")
    quotes = [line[2:] for line in decision.splitlines() if line.startswith("> ")]
    question_record = text_blob(PREFIX + "OWNER-QUESTION-02.md")
    old_decision = text_blob(PREFIX + "OWNER-DECISION-01.md", OLD)
    new_decision = text_blob(PREFIX + "OWNER-DECISION-01.md")
    checks = {
        "task_sha256": hashlib.sha256(source).hexdigest(),
        "source_channel_independently_seen": False,
        "exact_question_equal_to_direct_owner_source_supplied_by_root": quotes[0] == question,
        "exact_answer_equal_to_direct_owner_source_supplied_by_root": quotes[1] == answer,
        "exact_item_id_present": item in decision,
        "date_timezone_present": "Date: 2026-10-09 (Asia/Taipei)." in decision,
        "missing_submission_timestamp_disclosed": "supplies no submission\ntimestamp" in decision,
        "question_record_same_exact_question": "> " + question in question_record,
        "question_record_first_choice_equals_answer": "1. " + answer in question_record,
        "decision_01_original_body_preserved": new_decision.split("Date:", 1)[1] == old_decision.split("Date:", 1)[1],
    }
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    numbered(PREFIX + "OWNER-DECISION-03.md", 1, 34)
    numbered(PREFIX + "OWNER-QUESTION-02.md", 1, 22)


def links_scope():
    changed = git("diff", "--name-only", OLD, NEW).decode("utf-8").splitlines()
    names = set(git("ls-tree", "-r", "--name-only", NEW).decode("utf-8").splitlines())
    issues = []
    count = 0
    old_names = set(git("ls-tree", "-r", "--name-only", OLD).decode("utf-8").splitlines())
    for path in changed:
        data = text_blob(path)
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", data):
            if re.match(r"[A-Za-z]:/", target) or "://" in target:
                continue
            clean = target.split("#", 1)[0]
            if not clean:
                continue
            normalized = pathlib.PurePosixPath(path).parent.joinpath(clean)
            parts = []
            for part in normalized.parts:
                if part == "..":
                    parts.pop()
                elif part != ".":
                    parts.append(part)
            resolved = "/".join(parts)
            count += 1
            if resolved not in names:
                old_content = text_blob(path, OLD) if path != PREFIX + "OWNER-DECISION-03.md" else ""
                issues.append({"from": path, "target": target, "resolved": resolved,
                               "present_in_previous_text": target in old_content,
                               "missing_from_previous_tree": resolved not in old_names})
    additions = git("diff", "--unified=0", OLD, NEW).decode("utf-8")
    added_links = re.findall(r"\[[^\]]*\]\(([^)]+)\)", "\n".join(line[1:] for line in additions.splitlines() if line.startswith("+") and not line.startswith("+++")))
    print(json.dumps({"changed_files": changed, "all_changed_files_are_markdown": all(p.endswith(".md") for p in changed),
                      "local_link_count": count, "missing_local_link_targets": issues,
                      "links_on_added_lines": added_links}, indent=2))
    for scope in ("src", "docs/PORTING_MATRIX.md", "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md", "docs/status/GATE_STATUS.md"):
        old_oid = git("rev-parse", OLD + ":" + scope).decode().strip()
        new_oid = git("rev-parse", NEW + ":" + scope).decode().strip()
        print(json.dumps({"scope": scope, "old_oid": old_oid, "new_oid": new_oid, "unchanged": old_oid == new_oid}))


def archives():
    names = git("ls-tree", "-r", "--name-only", NEW, "--", PREFIX).decode("utf-8").splitlines()
    for path in names:
        if not path.endswith(".zip"):
            continue
        current = blob(path)
        previous = blob(path, OLD)
        with zipfile.ZipFile(io.BytesIO(current)) as archive:
            entries = archive.infolist()
            paths = [entry.filename for entry in entries]
            safe = all(not pathlib.PurePosixPath(name).is_absolute() and ".." not in pathlib.PurePosixPath(name).parts and "\\" not in name for name in paths)
            checksums = [name for name in paths if pathlib.PurePosixPath(name).name in ("SHA256SUMS.txt", "checksums.txt")]
            reports = [name for name in paths if pathlib.PurePosixPath(name).name == "REPORT.md"]
            print(json.dumps({"path": path, "unchanged": current == previous,
                              "sha256": hashlib.sha256(current).hexdigest(),
                              "compressed_bytes": len(current), "entry_count": len(entries),
                              "expanded_bytes": sum(entry.file_size for entry in entries),
                              "safe_paths": safe,
                              "case_unique": len(set(p.casefold() for p in paths)) == len(paths),
                              "crc_bad_entry": archive.testzip(),
                              "manifests": [{"path": n, "sha256": hashlib.sha256(archive.read(n)).hexdigest()} for n in checksums],
                              "reports": [{"path": n, "sha256": hashlib.sha256(archive.read(n)).hexdigest()} for n in reports]}, indent=2))


def remaining():
    print(git("grep", "-n", "-I", "-E", "pending|unanswered|not selected|not owner-approved|D1|M1|M2|R1", NEW, "--", PREFIX + "*.md", "docs/status/CURRENT_VERSION.md", "docs/status/COMPLETION-PLAN.md", "docs/work/v1.8.0-implementation-log.md").decode("utf-8"))
    for name in ("CONTRACT-RESEARCH-01.zip", "CONTRACT-INDEPENDENT-01.zip", "BOUNDARY-INDEPENDENT-03.zip", "SPAWN-FEASIBILITY-02.zip", "AIR-FEASIBILITY-02.zip"):
        print("\nHISTORICAL ARCHIVE " + name)
        with zipfile.ZipFile(io.BytesIO(blob(PREFIX + name))) as archive:
            lines = archive.read("REPORT.md").decode("utf-8").splitlines()
            for index, line in enumerate(lines, 1):
                if re.search("pending|unanswered|ancillary|D1", line, re.IGNORECASE):
                    print(str(index) + ": " + line)
                    if index < len(lines):
                        print(str(index + 1) + ": " + lines[index])


def local_agents():
    path = CWD / "AGENTS.md"
    value = path.read_bytes()
    print("LOCAL AGENTS SHA256 " + hashlib.sha256(value).hexdigest())
    print(value.decode("utf-8"))


def missing_links():
    path = "docs/work/v1.8.0-implementation-log.md"
    names = set(git("ls-tree", "-r", "--name-only", NEW).decode("utf-8").splitlines())
    for number, line in enumerate(text_blob(path).splitlines(), 1):
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", line):
            if target.endswith(".zip"):
                base = "docs/work/" + target
                while "/../" in base:
                    base = re.sub(r"[^/]+/\.\./", "", base, count=1)
                if base not in names:
                    print(str(number) + ": " + line)


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "refs":
        references()
    elif mode == "transcription":
        transcription()
    elif mode == "links-scope":
        links_scope()
    elif mode == "archives":
        archives()
    elif mode == "remaining":
        remaining()
    elif mode == "local-agents":
        local_agents()
    elif mode == "missing-links":
        missing_links()
    elif mode == "lines":
        numbered(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))
    else:
        raise SystemExit("Unsupported mode: " + mode)
