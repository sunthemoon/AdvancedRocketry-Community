"""Run bounded read-only review commands and preserve their actual streams."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

LEAF = pathlib.Path(__file__).resolve().parent
CWD = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")


def run(label, argv):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=CWD, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=180)
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout_file = LEAF / (label + ".stdout.txt")
    stderr_file = LEAF / (label + ".stderr.txt")
    context_only = label.startswith("context-") and result.returncode == 0
    if not context_only:
        stdout_file.write_bytes(result.stdout)
        stderr_file.write_bytes(result.stderr)
    record = {
        "label": label, "argv": argv, "cwd": str(CWD),
        "pre_start_utc": started, "end_utc": ended,
        "exit_code": result.returncode,
        "stdout": None if context_only else stdout_file.name,
        "stderr": None if context_only else stderr_file.name,
        "context_only": context_only,
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    }
    with (LEAF / "commands.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    print(json.dumps(record, ensure_ascii=False))
    print(result.stdout.decode("utf-8", errors="replace"))
    if result.stderr:
        print(result.stderr.decode("utf-8", errors="replace"), file=sys.stderr)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(run(sys.argv[1], sys.argv[2:]))
