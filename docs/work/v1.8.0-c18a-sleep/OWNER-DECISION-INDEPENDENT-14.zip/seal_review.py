"""Create a one-time safe own-leaf manifest after Root has read the report."""
import datetime
import hashlib
import json
import pathlib
import stat
import sys

sys.stdout.reconfigure(encoding="utf-8")
LEAF = pathlib.Path(__file__).resolve().parent
EXPECTED = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-owner-decision-independent-20261009-14").resolve()
MANIFEST = LEAF / "SHA256SUMS.txt"


def files():
    result = []
    for path in LEAF.rglob("*"):
        attributes = path.lstat()
        if path.is_symlink() or getattr(attributes, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError("Reparse or symlink path: " + str(path))
        path.resolve().relative_to(LEAF)
        if path.is_file() and path != MANIFEST:
            if path.stat().st_size > 50 * 1024 * 1024:
                raise RuntimeError("Over-sized file: " + str(path))
            result.append(path)
    if sum(path.stat().st_size for path in result) > 100 * 1024 * 1024:
        raise RuntimeError("Evidence exceeds 100 MiB")
    return sorted(result, key=lambda path: path.relative_to(LEAF).as_posix())


if __name__ == "__main__":
    if LEAF != EXPECTED:
        raise SystemExit("Unexpected evidence leaf")
    if sys.argv[1:] != ["--root-full-read-confirmed"]:
        raise SystemExit("Root full-read confirmation is required")
    if MANIFEST.exists():
        raise SystemExit("Refusing to overwrite an existing seal")
    confirmation = LEAF / "ROOT-READ-CONFIRMATION.md"
    if not confirmation.is_file():
        raise SystemExit("Missing recorded Root full-read confirmation")
    entry_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    inventory = files()
    record = {"argv": [sys.executable, "-B", str(pathlib.Path(__file__).resolve()), *sys.argv[1:]],
              "cwd": str(pathlib.Path.cwd()), "script_entry_utc": entry_utc,
              "independent_process_launch_pre_start_utc": None,
              "inventory_checked_files_before_receipt": len(inventory),
              "mode": "one-time own-leaf SHA256SUMS; manifest excludes itself"}
    with (LEAF / "SEAL-INVOCATION.json").open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, indent=2) + "\n")
    inventory = files()
    data = "".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(LEAF).as_posix() + "\n" for path in inventory).encode("utf-8")
    with MANIFEST.open("xb") as handle:
        handle.write(data)
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = LEAF / relative
        path.resolve().relative_to(LEAF)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError("Post-seal mismatch: " + relative)
    print(json.dumps({"manifest": str(MANIFEST),
                      "manifest_sha256": hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
                      "covered_files": len(inventory),
                      "covered_bytes": sum(path.stat().st_size for path in inventory),
                      "verified": True,
                      "report_sha256": hashlib.sha256((LEAF / "REPORT.md").read_bytes()).hexdigest()}, indent=2))
