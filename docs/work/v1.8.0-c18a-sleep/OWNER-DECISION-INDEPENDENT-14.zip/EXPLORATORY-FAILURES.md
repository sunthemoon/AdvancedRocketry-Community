# Exploratory shell failures

Two direct tool calls intended to start the reference scan failed before the
Python capture helper ran. Both tool returns had exit code 1 and the following
combined rendered output:

```text
'OWNER-DECISION-03' is not recognized as an internal or external command,
operable program or batch file.
```

The first attempted command used a single-quoted pipe-containing expression;
the second used a double-quoted expression. Both used the same repository cwd
and `review_checks.py` with labels `08-owner-references` and
`08-owner-references-corrected`, respectively. These attempts were not completed
reference scans. Their tool-reported elapsed times were 0.298471 and 0.309718
seconds. No pre-start UTC or independently split child stdout/stderr was captured
for either attempt; none is reconstructed here. The later explicit-argv Python
reference scan is recorded separately with actual timestamps and raw streams.

The actual command strings sent to `exec_command` were:

```text
python -B "D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-owner-decision-independent-20261009-14/review_checks.py" "08-owner-references" git grep -n -I -E 'OWNER-QUESTION-02|OWNER-DECISION-03|ancillary.*(pending|unanswered)|pending.*ancillary|unanswered.*ancillary|连带.*待答' 48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514 -- '*.md'
python -B "D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-owner-decision-independent-20261009-14/review_checks.py" "08-owner-references-corrected" git grep -n -I -E "OWNER-QUESTION-02|OWNER-DECISION-03|ancillary.*(pending|unanswered)|pending.*ancillary|unanswered.*ancillary|连带.*待答" 48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514 -- "*.md"
```

No `shell` field was supplied. The explicit environment cwd was
`D:/GitHub/AdvancedRocketry-Community`; command-level pre-start times and the
shell's actual parsed argv were not observed. This record preserves tool-returned
output, not a claim of unavailable independent process raw streams.

Early successful tool renderings of captured Git output displayed mojibake due
to Python's console encoding. The original Git stdout bytes are preserved in
`05-diff.stdout.txt`; subsequent displays use UTF-8. This did not alter Git blobs.
