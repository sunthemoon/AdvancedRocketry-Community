"""Independent fixed-input verification; each invocation preserves one cohort."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009')
SOURCE = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
JAVA = Path('C:/Program Files/Java/jdk-17.0.7')
OPTIONS = ['--no-daemon', '--no-build-cache', '--rerun-tasks']
ROUTES = {
    'identity-01': ['--version'],
    'build-01': ['clean', 'build'],
    'test-01': ['test'],
    'data-01a': ['runData'],
    'data-01b': ['runData'],
    'publish-01': ['publishMavenJavaPublicationToLocalProjectRepositoryRepository', '--offline'],
    'consumer-01': ['-p', 'compat-test-mod', 'clean', 'build', '-ParceVersion=1.20.1-1.8.0-dev', '--offline'],
    'native-01': ['runGameTestServer'],
}

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, timeout=60).decode('utf-8').strip()

def capture(out, label, argv, cwd=REPO, env=None, ceiling=180):
    record = {'argv': argv, 'cwd': str(cwd), 'started_utc': utc(), 'timeout_seconds': ceiling}
    with (out / (label + '.log')).open('xb') as stream:
        try:
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
            record['pid'] = child.pid
            record['exit'] = child.wait(timeout=ceiling)
        except subprocess.TimeoutExpired:
            record['exit'] = 'TIMEOUT'
            # Stop only this helper's directly owned child. Descendants are retained for explicit owned-process review.
            child.kill()
            child.wait(timeout=30)
    record.update(ended_utc=utc(), log_bytes=(out / (label + '.log')).stat().st_size,
                  log_sha256=sha(out / (label + '.log')))
    save(out / (label + '.json'), record)
    return record

name = sys.argv[1]
if name not in ROUTES:
    raise SystemExit('Route is not authorized by the pre-review task')
if name == 'native-01':
    activation = LEAF.parent / 'SLEEP-OBSERVATION-STANDARD-GAMETEST-ACTIVATION-13.md'
    assert sha(activation) == 'c517b1017e3f0a40d34a57c0a967c0501584972c176698fda49f7def9b644825'
    for prerequisite in ('build-01', 'test-01', 'data-01a', 'data-01b'):
        result = json.loads((LEAF / prerequisite / 'RESULT.json').read_text())
        assert result['execution']['exit'] == 0 and not result['source_status_after'], prerequisite
    for prerequisite in ('data-01a', 'data-01b'):
        assert (LEAF / prerequisite / 'diff.log').stat().st_size == 0, prerequisite
out = LEAF / name
if out.exists():
    raise SystemExit('Refusing to replace an actual cohort')
head = git('rev-parse', 'HEAD')
status = git('status', '--short')
assert head == SOURCE and not status, (head, status)
assert not any(os.environ.get(k) for k in ('_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')), 'Unexpected parent JVM injection'
free = {d: shutil.disk_usage(d).free for d in ('C:/', 'D:/')}
assert min(free.values()) >= 10 * 1024 ** 3, free
out.mkdir(parents=True)
tmp = LEAF / '_tmp' / name
tmp.mkdir(parents=True)
env = dict(os.environ, JAVA_HOME=str(JAVA), TEMP=str(tmp), TMP=str(tmp),
           JAVA_TOOL_OPTIONS=f'-Djava.io.tmpdir={tmp.as_posix()} -Dfile.encoding=UTF-8')
env['PATH'] = str(JAVA / 'bin') + ';' + env['PATH']
paths = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
         'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties',
         'compat-test-mod/build.gradle', 'compat-test-mod/settings.gradle',
         'compat-test-mod/negative-fixture/InternalImportProbe.java',
         'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java',
         'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java']
identity = {'source': head, 'source_tree': git('rev-parse', 'HEAD:src'), 'source_status_before': status,
            'name': name, 'free_space_before_bytes': free, 'jdk_release': (JAVA / 'release').read_text(),
            'java_sha256': sha(JAVA / 'bin/java.exe'), 'javac_sha256': sha(JAVA / 'bin/javac.exe'),
            'child_environment': {k: env[k] for k in ('JAVA_HOME', 'TEMP', 'TMP', 'JAVA_TOOL_OPTIONS')},
            'parent_java_tool_options': os.environ.get('JAVA_TOOL_OPTIONS'),
            'inputs': [{'path': p, 'bytes': (REPO / p).stat().st_size, 'sha256': sha(REPO / p)} for p in paths]}
save(out / 'INPUTS.json', identity)
preflight = capture(out, 'preflight', ['powershell', '-NoProfile', '-Command',
    "$o=Get-CimInstance Win32_OperatingSystem; $p=Get-CimInstance Win32_Process | Where-Object {$_.Name -match 'java|gradle|python'} | Select-Object ProcessId,ParentProcessId,Name,CommandLine; @{utc=[DateTime]::UtcNow.ToString('o'); freeMemoryKiB=$o.FreePhysicalMemory; totalMemoryKiB=$o.TotalVisibleMemorySize; processes=$p} | ConvertTo-Json -Depth 5"])
java = capture(out, 'java-version', [str(JAVA / 'bin/java.exe'), '-version'], env=env, ceiling=30)
assert java['exit'] == 0
argv = [str(REPO / 'gradlew.bat'), *OPTIONS, *ROUTES[name]]
run = capture(out, 'command', argv, env=env, ceiling=2400)
identity.update(source_after=git('rev-parse', 'HEAD'), source_status_after=git('status', '--short'),
                free_space_after_bytes={d: shutil.disk_usage(d).free for d in free}, execution=run)
save(out / 'RESULT.json', identity)
text = (out / 'command.log').read_text(encoding='utf-8', errors='replace')
tasks = [line for line in text.splitlines() if line.startswith('> Task ')]
save(out / 'TASKS.json', {'actual_log_task_lines': tasks,
                        'cached_or_uptodate_lines': [line for line in tasks if 'UP-TO-DATE' in line or 'FROM-CACHE' in line]})
if name in ('build-01', 'test-01'):
    files = sorted((REPO / 'build/test-results/test').glob('TEST-*.xml'))
    dest = out / 'junit'
    dest.mkdir()
    inventory, cases = [], []
    for p in files:
        shutil.copyfile(p, dest / p.name)
        raw = p.read_bytes()
        root = ET.fromstring(raw)
        inventory.append({'path': 'junit/' + p.name, 'bytes': len(raw), 'sha256': sha(p), 'suite': dict(root.attrib)})
        for case in root.iter('testcase'):
            cases.append({'xml': p.name, **case.attrib,
                          'failure': [dict(e.attrib, detail=e.text) for e in case.findall('failure')],
                          'error': [dict(e.attrib, detail=e.text) for e in case.findall('error')],
                          'skipped': [dict(e.attrib, detail=e.text) for e in case.findall('skipped')]})
    result = {'xml_files': len(files), 'cases': len(cases), 'failures': sum(bool(c['failure']) for c in cases),
              'errors': sum(bool(c['error']) for c in cases), 'skips': sum(bool(c['skipped']) for c in cases),
              'executed_test_task': any(line == '> Task :test' for line in tasks), 'files': inventory}
    save(out / 'JUNIT.json', result)
    save(out / 'CASES.json', cases)
    print(json.dumps({k: v for k, v in result.items() if k != 'files'}), flush=True)
if name.startswith('data-'):
    diff = capture(out, 'diff', ['git', 'diff', '--exit-code'])
    state = capture(out, 'status', ['git', 'status', '--short'])
    save(out / 'DATAGEN.json', {'diff': diff, 'status': state})
    if diff['exit'] != 0 or (out / 'status.log').stat().st_size:
        raise SystemExit('Actual generated source diff/status is not empty')
if name == 'consumer-01':
    reports = REPO / 'compat-test-mod/build/reports/consumer'
    dest = out / 'consumer-receipts'
    dest.mkdir()
    for p in reports.glob('*.json'):
        shutil.copyfile(p, dest / p.name)
if name == 'native-01':
    native_dir = REPO / 'build/gametest'
    retained = []
    for p in sorted(native_dir.rglob('*')):
        if not p.is_file() or 'world' in p.relative_to(native_dir).parts:
            continue
        relative = p.relative_to(native_dir)
        if p.suffix.lower() not in ('.log', '.xml', '.json', '.csv', '.txt', '.properties'):
            continue
        destination = out / 'native' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, destination)
        retained.append({'path': 'native/' + relative.as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)})
    summary = {'retained_raw_files': retained}
    for label, path in [('stdout', out / 'command.log'), ('latest', out / 'native/logs/latest.log'),
                        ('debug', out / 'native/logs/debug.log')]:
        if path.exists():
            raw_text = path.read_text(encoding='utf-8', errors='replace')
            summary[label] = {'required_completion_markers': re.findall(r'All (\d+) required tests passed', raw_text),
                              'error_headers': len(re.findall(r'^.*\bERROR\b.*$', raw_text, re.MULTILINE)),
                              'fatal_headers': len(re.findall(r'^.*\bFATAL\b.*$', raw_text, re.MULTILINE)),
                              'sleep_lines': [line for line in raw_text.splitlines() if 'sleepboundary' in line.lower()
                                              or 'ARCE_SLEEP_BOUNDARY_SETUP_FAILURE' in line]}
    save(out / 'NATIVE.json', summary)
artifacts = list((REPO / 'build/libs').glob('*.jar'))
if name == 'consumer-01':
    artifacts += list((REPO / 'compat-test-mod/build/libs').glob('*.jar'))
if name == 'publish-01':
    artifacts += list((REPO / 'build/repo').rglob('*.jar'))
save(out / 'ARTIFACTS.json', [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in artifacts])
print(json.dumps({'name': name, 'exit': run['exit'], 'source_after': identity['source_after'],
                  'source_status_after': identity['source_status_after'], 'ended_utc': run['ended_utc']}), flush=True)
raise SystemExit(0 if run['exit'] == 0 else 1)
