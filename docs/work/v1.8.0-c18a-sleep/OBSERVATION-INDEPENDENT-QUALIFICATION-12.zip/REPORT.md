# Independent passive observation regression qualification 12

Date: 2026-10-09 UTC. Delegated independent verifier, not Root.

## Findings first

1. **Strict repository validation is unfinished:** the independently executed
   approved-identity validator reached its unchanged 180-second ceiling. Actual
   result is **TIMEOUT**, with a zero-byte buffered raw log, not PASS or a passed
   link report. Only its directly owned Python child was stopped at the ceiling.
   No retry, timeout enlargement, assertion change or exception suppression was
   used. The helper's own successful receipt writing does not change the
   validator's TIMEOUT result.
2. **Native log acceptance remains open:** the standard full GameTest exits 0
   and reports all **588 required tests passed**, but raw stdout, latest.log and
   debug.log each retain **62 ERROR headers / zero FATAL**. Latest.log logger
   counts are EventBus 31, NetworkRegistry 16, ARCE 10 and ChunkMap 5. These
   include deliberate failure-path diagnostics; they are not removed, waived or
   converted into a log-Gate PASS. Full raw messages and stack traces remain.
3. **Owned-output cleanup failed before launch:** the single direct native
   PowerShell attempt was rejected by tool policy. No deletion is claimed and
   no other shell, retry, policy change, Root or peer takeover was used. Six
   exclusively owned output/temp targets remain: **5,827 files /308,834,406
   bytes**. Read-only native containment/reparse/process inspection confirms
   their actual retention and no live owned Java/Python process.

No failed Gradle/JUnit/GameTest/consumer cohort was observed in this assigned
regression. That result is narrower than sleep gameplay acceptance. The prior
source review's historical F01/F02 findings and failed preparation/cleanup
cohorts are preserved in its unchanged sealed package; its independent compile
receipts are input review, **not tests independently rerun by this worker**.

## Fixed input and exclusive scope

- Task 12 SHA-256:
  `41a14a3dbfdb0f3907f33699fc3dcfa4eebcce7da2fb9cd1ad21aa965c503ccb`.
- Fixed source: `5b45132000ade1e3c8d130a6b8ccb29f07535124`.
  Base: `b9bec789978de0df67c93e976239d6d36e41532b`.
  Complete src tree: `001b12375461d7dddec6d74b69f7e0ea7d966188`.
- Fixed governance: `608f04360522f9aa2d1fdaab09d853d4cb4075f9`.
  The twelve mandatory governance/proposal files read here are byte-identical
  between that checkpoint and the assigned source; see GOVERNANCE-IDENTITY.json.
  Earliest incomplete acceptance remains v1.0; active v1.8 development is
  separate under ADR-060. Neither inherited nor current G0-G9 is approved.
- Detached checkout:
  `D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009`.
- Exclusive evidence/scratch:
  `D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-qualification-independent-20261009-12`.
  Only this leaf and the named checkout's disposable Gradle/DataGen/consumer
  outputs were written. Main/source-author/Root/shared HEAD interests were
  released at preparation. Root owns OpenPet; no delegation was performed.
- Actual source changes at the fixed candidate are exactly the assigned two
  adapterTest files. This verifier added or changed **no tracked source, test,
  assertion, build input, resource, status, ledger, source world or user AGENTS**,
  and performed no staging, commit, push, branch switch or HEAD movement.

The complete proposal, external Tasks 05/08/10/11, fixed source files/diff,
current-version/parallel/v1+ governance and ADR-060 were read. SOURCE.diff is
67,181 bytes, SHA-256
`168632ce7d408424f61944c81737c8f39fb5d811913257c0085a76b6e53434ff`.
Fixture source is 33,987 bytes,
`1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820`;
Trace source is 31,470 bytes,
`39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0`.

## Separate standard GameTest activation

Root's Activation 13 was independently hash-verified and read completely:
`c517b1017e3f0a40d34a57c0a967c0501584972c176698fda49f7def9b644825`.
The complete source-review REPORT snapshot used by that activation was read:
19,054 bytes,
`20338d51cf83027a24609127a79e480e0fc965a5a29e17a6a1eedb0f63d4e860`.
It is retained separately as SOURCE-REVIEW-READ-SNAPSHOT.md. The later sealed
report was independently verified and retained without replacing the original
read snapshot: 19,464 bytes,
`3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0`.
This review disposition authorized only the conditional standard development
GameTest; it supplied no driver, twenty-case, sleep-policy or Gate authority.

Root subsequently reported a documentation-only owner response outside this
frozen governance checkpoint. It was not adopted as additional Task 12 source
or runtime authority. Owner policy implementation/acceptance remains outside
this regression; no subsequent Main commit is claimed as independently tested.

## Independently executed commands and results

All Gradle commands used the installed wrapper from the assigned checkout,
with `--no-daemon --no-build-cache --rerun-tasks`. Actual passed argv, cwd,
start/end UTC, child PID, ceiling, raw merged stdout/stderr, exit, hashes,
before/after source state and C:/D: disk counters are preserved per cohort.
EXECUTED-COMMANDS.json gives the consolidated exact Gradle invocation receipts.
Each Gradle command retained the unchanged **2400-second** ceiling.

All UTC times below are on 2026-10-09.

| Cohort | Command suffix | UTC start to end | Actual result |
|---|---|---|---|
| identity-01 | `--version` | 05:27:53.692518 to 05:27:54.420387 | Exit 0; Gradle 8.8 / Oracle Java 17.0.7. |
| build-01 | `clean build` | 05:28:03.018437 to 05:31:13.162550 | Exit 0; :test actually executes 2,192 JUnit cases /381 XML; zero failures/errors/skips. |
| test-01 | `test` | 05:31:29.865534 to 05:34:28.999867 | Exit 0; separate actual :test execution, again 2,192 /381 /zero failures/errors/skips. |
| data-01a | `runData` | 05:35:29.485249 to 05:36:13.212314 | Exit 0; separate `git diff --exit-code` exit 0, zero-byte diff/status. |
| data-01b | `runData` | 05:36:21.867942 to 05:37:10.820254 | Exit 0; second independent zero-byte diff/status, diff exit 0. |
| publish-01 | `publishMavenJavaPublicationToLocalProjectRepositoryRepository --offline` | 05:37:21.134221 to 05:38:09.329673 | Exit 0; local publication only. |
| consumer-01 | `-p compat-test-mod clean build -ParceVersion=1.20.1-1.8.0-dev --offline` | 05:38:16.436109 to 05:38:42.636309 | Exit 0; API-only classpath and independent reobfuscation receipts. |
| native-01 | `runGameTestServer` | 05:39:01.877710 to 05:44:45.552524 | Exit 0; existing unfiltered run/namespaces, all 588 required tests pass; log acceptance remains open. |

Strict actual argv was `python -B scripts/validate_repository.py
--require-approved-identity`, in the same assigned cwd, UTC 05:41:42.251437 to
05:44:42.266910, **TIMEOUT at 180 seconds**. It was a read-only validator run
while the separately authorized native regression completed normally. No new
native launch or changed validation budget followed the timeout.

Separate archived final commands `git diff --check`, fixed-base/source
`git diff --check`, `git diff --exit-code`, `git status --short` and
`git rev-parse HEAD` all return 0. Diff/status/whitespace logs are empty;
HEAD remains exactly 5b451320. Cached/UP-TO-DATE task lines are retained in
TASKS.json but never credited as executed. Consumer :test is NO-SOURCE, not
an additional unit-test run; its negative javac probe intentionally returns 1
for the unavailable real internal package and is separately attributed.

## Exact test evidence and limits

Build and explicit-test XML copies, XML hashes/suite attributes and every
testcase/failure/error/skip are retained independently under build-01 and
test-01, with JUNIT.json and CASES.json. Both have :test execution receipts.

The native run's existing latest.log records `sleep_trace:1` (5 tests) at
13:41:04 local time and `sleep_console:1` (4 tests) at 13:43:07. All 588
required tests complete at 13:44:41. Those groups exercise the nine assigned
source GameTest methods: command opt-in/console/thread/reentrancy/setup-marker
guards and trace identity/event/byte/frame/metadata/chat bounds. The raw
stdout includes the named setup-guard unit failure intervention; that is not
an invocation of the twenty-case observation command.

The unchanged standard run produced no native XML/CSV result file outside its
disposable world. Its actual native results are the complete batch/completion
logs, recorded without adding a reporter or launch argument. Full raw stdout,
latest.log, debug.log, configuration and observed result summary are retained
under native-01; all ERROR messages/stack traces are preserved. Source method
existence, these guard/bound tests and completion counts **do not prove actual
spawn-event frames, sleep handler outcomes or saved typed Spawn disk fields**.

## Tool/dependency and artifact identity

Installed Oracle JDK is 17.0.7+8-LTS-224, Java 17, amd64. Java executable
SHA-256 is
`308e8c921fd9d152ad526e5f0988682e8f96792a6313f185fa6b20db671a791f`.
Wrapper distribution is Gradle 8.8, ForgeGradle resolves existing 6.0.54,
Forge remains 1.20.1-47.4.10 with official 1.20.1 mappings. JDK release,
java/javac, wrapper/build/consumer/source hashes and installed primary
Gradle/Forge/eventbus JAR identities are preserved in INPUTS.json and
DEPENDENCY-TOOL-IDENTITY.json. No version, build configuration or tool/library
installation was changed.

Each Gradle command checks **at least 10 GiB free on both C: and D:** immediately
before launch and captures disk/memory/process preflight. Native counters are
C: 30,544,990,208 /D: 293,931,577,344 free bytes before launch. Child
TEMP/TMP/java.io.tmpdir are this leaf's own per-cohort children. The parent's
JAVA_TOOL_OPTIONS replacement is recorded; unexpected _JAVA_OPTIONS or
JDK_JAVA_OPTIONS were rejected, not silently inherited.

| Independently produced artifact | Bytes | SHA-256 |
|---|---:|---|
| Normal runtime JAR | 6,073,913 | `0a8048308b30b00b5838b46d779b89f1097bdb0a33078c0dffedfb5e95a9a011` |
| API JAR | 51,052 | `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b` |
| Sources JAR | 2,892,005 | `7a031dc3d4bf36649b4caf0066063b08aedc81842038537a260e47d44bf8943a` |
| API-only consumer fixture JAR, reobfuscated | 191,702 | `93194a0bb197b5051174d66f2f4ddcd58649fc0764d83b5da3ac0ab7aca600aa` |

Consumer receipts resolve exactly the requested `1.20.1-1.8.0-dev:api`
publication from this checkout's local repository, with 114 dependency JARs
on the audited compile classpath and 40 fixture source/resource inputs.
Forge-remapped API SHA-256 is
`a04dbac3aa097869f9f47eb57c619acdc1d62925f6d8e489820c68796e7aee6e`.
The original classifier bytes match the selected publication; host internals
are absent from the compile classpath. Negative-import and fixture metadata/
entries/reobfuscation checks execute as existing consumer checks. The fixture
contains the ten actual SleepBoundary class files, but was **not launched in
a packaged server** here. No artifact binary, whole source, build or world
archive is copied into the compact evidence.

## Cleanup, retention and record hygiene

All Gradle/native/consumer children ended. The strict owned child was stopped
only for its finite ceiling. No unrelated process was terminated. The native
server saves/stops normally before its command exits.

The single PowerShell deletion attempt was policy-denied before launch.
CLEANUP-POLICY-DENIAL.md records the exact six targets, proposed native checks
and no-retry boundary. RETAINED-OUTPUTS.json is subsequent **read-only** native
evidence: all target containment checks true, root/descendant reparse counts
zero, no live owned Java/Python process. It does not retroactively credit the
rejected preflight or authorize another cleanup. Source checkout is retained.
Disposable output/temp retention is not a whole-tree evidence export.

Preparation-only limitations are transcript-visible, not invented archived
validation runs: a guessed lowercase version path and two guessed assignment
paths were absent; the real uppercase version and complete external task files
were read. Some broad exploratory displays were truncated; focused complete
source/review reads followed. These outputs were not presented as PASS.

The compact evidence is approximately 12 MB; no individual evidence file is
near 50 MB. Any sealing follows Root's complete read of this persisted report.
The eventual leaf-relative manifest covers compact evidence files, not live
build/Temp paths; policy-retained `_tmp` is disposable retention, explicitly
outside compact seal coverage. Any post-seal verification receipt is kept
outside its own manifest to avoid a cyclic hash. No peer or sealed input was
modified.

## Unexecuted checks, known risks and Gate status

**UNEXECUTED:** twenty-case observation command and all actual native spawn
frames/outcomes; packaged driver/parser/server qualification; real transport,
decoder/scheduling/TCP/client; prior-world, restart, death and native saved
Spawn serialization; all colors/facings/hands, inherited/custom bed receivers,
stale state, secondary/item-first/monster/coexistence, interpreted/JIT;
six-host/Space atmosphere/access; long-load, performance reference workload,
GPU/remote and real multiplayer. No source test is weakened and no missing
run is marked PASS, waived or not-applicable.

B1/R1/M1/M2/D1, exact cause/enforcement, installed air/access neutral
transition, production StackWalker failure strategy, separate policy contract
qualification, item/ledger/assets/client/performance and current/inherited
Required Gate acceptance remain unfinished. Native-Java EmbeddedChannel
simulation is not TCP/client evidence; this regression does not even execute
the proposed twenty simulated-transport rows. Getters/compiled code do not
close disk/restart, real-world or full-item obligations. No public/persistent
ID, migration, asset provenance, owner policy, ledger delivery, Gate PASS,
version approval, release publication or tag is created.

**Required Gates satisfied by this task: no.** Completed scope is independently
rerun fixed-source short development regression and compact evidence; strict
validation, log acceptance and cleanup failure remain explicit. No full sleep
item or gameplay implementation is claimed.

Recommendation within v1.8 only: use these receipts with the separate actual
source review to freeze/review a finite observation driver/runtime assignment,
then execute only that later authorized stage. Preserve all pinned historical
cohorts and separately address strict/log/retention limits; do not infer B1 or
natural-dimension sleep acceptance from this regression.

## Evidence paths

Primary evidence is this leaf's build-01/test-01 XML/cases, data-01a/data-01b
raw runs and separate diff/status receipts, publish-01 artifacts,
consumer-01/consumer-receipts, native-01 raw logs/NATIVE-RESULTS.json,
strict-01 actual TIMEOUT receipt, final Git receipts, input/tool/governance
manifests, SOURCE.diff, distinct review snapshots and cleanup-denial/retention
records. All conclusions above are from this worker's own executed receipts;
no Root runtime result is counted as an independent rerun.
