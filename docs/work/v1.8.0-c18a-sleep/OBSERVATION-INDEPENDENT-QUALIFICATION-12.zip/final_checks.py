"""Compact independent immutable-input/final-state receipts; no game launch."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009')
SOURCE = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
GOVERNANCE = '608f04360522f9aa2d1fdaab09d853d4cb4075f9'

def run(label, argv, ceiling=180):
    out = LEAF / label
    if out.exists():
        raise SystemExit('Refusing to replace receipt')
    out.mkdir()
    tmp = LEAF / '_tmp' / label
    tmp.mkdir(parents=True)
    env = dict(os.environ, TEMP=str(tmp), TMP=str(tmp), JAVA_HOME='C:/Program Files/Java/jdk-17.0.7',
               JAVA_TOOL_OPTIONS=f'-Djava.io.tmpdir={tmp.as_posix()} -Dfile.encoding=UTF-8')
    record = {'argv': argv, 'cwd': str(REPO), 'timeout_seconds': ceiling,
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'child_environment': {k: env[k] for k in ('TEMP', 'TMP', 'JAVA_HOME', 'JAVA_TOOL_OPTIONS')}}
    with (out / 'raw.log').open('xb') as stream:
        child = subprocess.Popen(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record['pid'] = child.pid
        try:
            record['exit'] = child.wait(timeout=ceiling)
        except subprocess.TimeoutExpired:
            record['exit'] = 'TIMEOUT'
            child.kill()
            child.wait(timeout=30)
    record.update(ended_utc=datetime.now(timezone.utc).isoformat(),
                  raw_log_bytes=(out / 'raw.log').stat().st_size,
                  raw_log_sha256=hashlib.sha256((out / 'raw.log').read_bytes()).hexdigest())
    (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record

mode = sys.argv[1]
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == SOURCE
if mode == 'strict':
    run('strict-01', ['python', '-B', 'scripts/validate_repository.py', '--require-approved-identity'], 180)
elif mode == 'final':
    run('diff-check-01', ['git', 'diff', '--check'])
    run('source-diff-check-01', ['git', 'diff', '--check', 'b9bec789978de0df67c93e976239d6d36e41532b', SOURCE])
    run('final-diff-01', ['git', 'diff', '--exit-code'])
    run('final-status-01', ['git', 'status', '--short'])
    run('final-head-01', ['git', 'rev-parse', 'HEAD'])
    docs = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
            'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
            'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
            'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
            'docs/work/v1.8.0-c18a-sleep/PROPOSED-OBSERVATION-01.md']
    manifest = []
    for path in docs:
        data = subprocess.check_output(['git', 'show', f'{GOVERNANCE}:{path}'], cwd=REPO)
        source = subprocess.check_output(['git', 'show', f'{SOURCE}:{path}'], cwd=REPO)
        manifest.append({'path': path, 'fixed_governance': GOVERNANCE, 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest(), 'source_identical': data == source})
    (LEAF / 'GOVERNANCE-IDENTITY.json').write_text(json.dumps(manifest, indent=2) + '\n')
else:
    raise SystemExit('Unknown finite check')
