"""Audit own compact actual receipts, then seal once after Root's complete read."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

LEAF = Path(__file__).resolve().parent
REPO = Path('D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009')
SOURCE = '5b45132000ade1e3c8d130a6b8ccb29f07535124'

def sha(p):
    digest = hashlib.sha256()
    with p.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

assert not (LEAF / 'SHA256SUMS.txt').exists(), 'No replacement seal allowed'
assert not (LEAF / 'SEAL-RESULT.json').exists(), 'No replacement post-seal receipt allowed'
assert (LEAF / 'ROOT-READ-AND-SEAL-AUTHORIZATION.md').is_file()
audit = {'started_utc': datetime.now(timezone.utc).isoformat(),
         'argv': ['python', '-B', str(Path(__file__).resolve())], 'cwd': str(REPO),
         'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip(),
         'source_status': subprocess.check_output(['git', 'status', '--short'], cwd=REPO).decode(),
         'report_sha256_at_root_read_and_seal': sha(LEAF / 'REPORT.md'),
         'root_authorization': 'ROOT-READ-AND-SEAL-AUTHORIZATION.md',
         'independent_gradle_cohorts': [], 'junit': [], 'datagen': [], 'consumer': {},
         'excluded_from_compact_manifest': ['_tmp/**', 'SEAL-RESULT.json', 'SHA256SUMS.txt']}
assert audit['source'] == SOURCE and not audit['source_status']
source_diff = subprocess.check_output(['git', 'diff', 'b9bec789978de0df67c93e976239d6d36e41532b', SOURCE], cwd=REPO)
assert hashlib.sha256(source_diff).hexdigest() == sha(LEAF / 'SOURCE.diff')
for path in LEAF.glob('*/RESULT.json'):
    cohort = path.parent
    record = read(path)
    run = record['execution']
    assert record['source'] == SOURCE and record['source_after'] == SOURCE and not record['source_status_after']
    assert run['exit'] == 0 and run['timeout_seconds'] == 2400
    assert sha(cohort / 'command.log') == run['log_sha256']
    assert (cohort / 'command.log').stat().st_size == run['log_bytes']
    assert min(record['free_space_before_bytes'].values()) >= 10 * 1024 ** 3
    assert all(sha(REPO / row['path']) == row['sha256'] for row in record['inputs'])
    tasks = read(cohort / 'TASKS.json')
    audit['independent_gradle_cohorts'].append({'name': cohort.name, 'exit': run['exit'],
         'command_log_sha256': run['log_sha256'], 'raw_log_bytes': run['log_bytes'],
         'cached_or_uptodate_task_lines_not_credited': tasks['cached_or_uptodate_lines']})
    for artifact in read(cohort / 'ARTIFACTS.json'):
        p = Path(artifact['path'])
        assert p.is_relative_to(REPO)
        assert p.stat().st_size == artifact['bytes'] and sha(p) == artifact['sha256']
for name in ('build-01', 'test-01'):
    out = LEAF / name
    recorded = read(out / 'JUNIT.json')
    assert recorded['executed_test_task'] is True
    cases = []
    for row in recorded['files']:
        p = out / row['path']
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
        cases.extend(ET.fromstring(p.read_bytes()).iter('testcase'))
    observed = {'cohort': name, 'xml_files': len(recorded['files']), 'cases': len(cases),
                'failures': sum(c.find('failure') is not None for c in cases),
                'errors': sum(c.find('error') is not None for c in cases),
                'skips': sum(c.find('skipped') is not None for c in cases)}
    assert all(observed[k] == recorded[k] for k in ('xml_files', 'cases', 'failures', 'errors', 'skips'))
    assert len(read(out / 'CASES.json')) == observed['cases']
    audit['junit'].append(observed)
for name in ('data-01a', 'data-01b'):
    out = LEAF / name
    recorded = read(out / 'DATAGEN.json')
    for kind in ('diff', 'status'):
        assert recorded[kind]['exit'] == 0 and (out / (kind + '.log')).stat().st_size == 0
        assert sha(out / (kind + '.log')) == recorded[kind]['log_sha256']
    audit['datagen'].append({'cohort': name, 'diff_exit': recorded['diff']['exit'],
                            'diff_bytes': (out / 'diff.log').stat().st_size, 'status_bytes': (out / 'status.log').stat().st_size})
native = read(LEAF / 'native-01/NATIVE.json')
for row in native['retained_raw_files']:
    p = LEAF / 'native-01' / row['path']
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
audit['native'] = read(LEAF / 'native-01/NATIVE-RESULTS.json')
latest = (LEAF / 'native-01/native/logs/latest.log').read_text(encoding='utf-8')
assert re.findall(r'All (\d+) required tests passed', latest) == audit['native']['required_completion_markers']
assert len(re.findall(r'^.*\bERROR\b.*$', latest, re.MULTILINE)) == audit['native']['error_header_count']
assert len(re.findall(r'^.*\bFATAL\b.*$', latest, re.MULTILINE)) == audit['native']['fatal_headers']
assert sum(audit['native']['error_logger_groups'].values()) == audit['native']['error_header_count']
strict = read(LEAF / 'strict-01/receipt.json')
assert strict['timeout_seconds'] == 180 and strict['exit'] == 'TIMEOUT'
assert sha(LEAF / 'strict-01/raw.log') == strict['raw_log_sha256']
audit['strict'] = strict
consumer = LEAF / 'consumer-01/consumer-receipts'
classpath = read(consumer / 'classpath.json')
assert sha(Path(classpath['published_file'])) == classpath['published_sha256']
assert sha(Path(classpath['remapped_api'])) == classpath['remapped_sha256']
assert all(sha(Path(row['file'])) == row['sha256'] for row in classpath['compile_classpath'])
assert all(sha(Path(row['file'])) == row['sha256'] for row in classpath['fixture_sources'])
negative = read(consumer / 'negative-import.json')
assert negative['exit_code'] == 1 and 'compiler.err.doesnt.exist' in negative['diagnostics']
fixture = read(consumer / 'fixture-artifact.json')
assert sha(Path(fixture['file'])) == fixture['sha256'] and fixture['reobfuscated'] is True
audit['consumer'] = {'requested_api': classpath['requested_api'], 'classpath_jars': len(classpath['compile_classpath']),
                    'fixture_sources': len(classpath['fixture_sources']), 'negative_javac_exit': negative['exit_code'],
                    'reobfuscated_fixture_sha256': fixture['sha256']}
retained = read(LEAF / 'RETAINED-OUTPUTS.json')
assert retained['cleanup'] == 'POLICY_DENIED_BEFORE_LAUNCH_NO_RETRY' and not retained['liveOwnedProcesses']
for row in retained['targets']:
    assert row['exists'] and Path(row['target']).is_dir() and row['containment'] is True
    assert row['rootReparse'] is False and row['descendantReparseCount'] == 0
assert not (LEAF / 'CLEANUP-RESULT.json').exists() and not (LEAF / 'CLEANUP-RAW.log').exists()
audit['retention'] = {'targets': len(retained['targets']), 'files': sum(row['fileCount'] for row in retained['targets']),
                      'bytes': sum(row['bytes'] for row in retained['targets']), 'deletion_retried': False,
                      'process_observation_utc': retained['observedUtc']}
audit['ended_utc'] = datetime.now(timezone.utc).isoformat()
audit['audit_result'] = 'ACTUAL_RECEIPT_AND_SCOPE_INTEGRITY_VERIFIED_NOT_GATE_APPROVAL'
save(LEAF / 'FINAL-AUDIT.json', audit)
paths = [p for p in sorted(LEAF.rglob('*')) if p.is_file() and '_tmp' not in p.relative_to(LEAF).parts
         and p.name not in ('SHA256SUMS.txt', 'SEAL-RESULT.json')]
assert sum(p.stat().st_size for p in paths) <= 100 * 1024 ** 2
assert all(p.stat().st_size <= 50 * 1024 ** 2 and not p.is_symlink() for p in paths)
lines = []
for p in paths:
    relative = p.relative_to(LEAF).as_posix()
    assert not relative.startswith('/') and '..' not in p.relative_to(LEAF).parts
    lines.append(sha(p) + '  ' + relative)
(LEAF / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
for line in (LEAF / 'SHA256SUMS.txt').read_text().splitlines():
    digest, relative = line.split('  ', 1)
    assert sha(LEAF / relative) == digest
result = {'verified_utc': datetime.now(timezone.utc).isoformat(), 'source': SOURCE,
          'report': str(LEAF / 'REPORT.md'), 'report_bytes': (LEAF / 'REPORT.md').stat().st_size,
          'report_sha256': sha(LEAF / 'REPORT.md'), 'manifest_sha256': sha(LEAF / 'SHA256SUMS.txt'),
          'covered_files': len(paths), 'covered_bytes': sum(p.stat().st_size for p in paths),
          'excluded_retention': '_tmp/**', 'explicitly_outside_manifest': ['SEAL-RESULT.json'],
          'manifest_verified': True, 'gate_approval': False}
save(LEAF / 'SEAL-RESULT.json', result)
print(json.dumps(result, indent=2), flush=True)
