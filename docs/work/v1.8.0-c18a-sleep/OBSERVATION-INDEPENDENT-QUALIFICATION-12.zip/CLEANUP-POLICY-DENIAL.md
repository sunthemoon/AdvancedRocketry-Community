# Owned-output cleanup policy denial

The single direct native PowerShell cleanup attempt was rejected by the tool
policy before process creation (`CreateProcess ... rejected: blocked by policy`).
The displayed diagnostic was truncated. No PowerShell transcript, deletion or
cleanup success receipt was produced. This is a retained operational failure,
not a successful cleanup or failed source/test run.

The proposed command used one PowerShell session end to end, explicit absolute
containment, native `Get-Item -LiteralPath` resolution, root/descendant reparse
checks, owned Java/Python process checks and `Remove-Item -LiteralPath` only.
Only these disposable task-12 outputs were named:

- D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009/build
- D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009/run-data
- D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009/.gradle
- D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009/compat-test-mod/build
- D:/GitHub/arce-v180-sleep-observation-independent-qualification-20261009/compat-test-mod/.gradle
- D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-qualification-independent-20261009-12/_tmp

The source checkout, Main, peer checkouts/evidence, source worlds, sealed inputs
and the shared Gradle cache were never proposed for deletion. A preceding
read-only native process check found no owned Java/Python process. The rejected
command's own preflight never ran and is not credited as execution.

No other shell, cleanup helper, retry, policy change, Root or peer takeover is
used after the denial. Subsequent native PowerShell work is read-only inventory
and process/containment/reparse observation, with evidence written only to this
leaf. All named targets are retained; RETAINED-OUTPUTS.json records their actual
state. This report grants no cleanup exemption or future retry authority.
