"""Use the merge-base incoming delta; preserve the failed endpoint cohort."""
import hashlib
from pathlib import Path

original = Path(__file__).with_name('inspect_candidate_01.py')
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '90f2ba934ebba904ee16550c5bba941e0d41af3b8f8e98b3069ae06ca024bf66'
source = raw.decode('utf-8').replace('candidate-01-', 'candidate-02-').replace('CANDIDATE-INPUT-01.json', 'CANDIDATE-INPUT-02.json')
old = "capture('candidate-02-merge-base', ['merge-base', MAIN, SOURCE])\nchanges = capture('candidate-02-paths', ['diff', '--name-only', MAIN, SOURCE]).decode().splitlines()"
new = "ancestor = capture('candidate-02-merge-base', ['merge-base', MAIN, SOURCE]).decode().strip()\ncapture('candidate-02-endpoint-paths', ['diff', '--name-only', MAIN, SOURCE])\nchanges = capture('candidate-02-paths', ['diff', '--name-only', ancestor, SOURCE]).decode().splitlines()"
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace("['diff', '--stat', MAIN, SOURCE]", "['diff', '--stat', ancestor, SOURCE]")
source = source.replace("['diff', '--binary', MAIN, SOURCE]", "['diff', '--binary', ancestor, SOURCE]")
source = source.replace("'main': MAIN, 'source': SOURCE, 'incoming_paths': changes", "'main': MAIN, 'source': SOURCE, 'merge_base': ancestor, 'incoming_paths': changes")
exec(compile(source, str(original) + ':corrected02', 'exec'))
