"""Read-only source binding, changed-link and protected-state checks for Root32."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
SHA = 'ce64a8eb79c0f6fb53f000f0c2a0e4e947ef9985'
def git(*args):
    p = subprocess.run(['git',*args],cwd=ROOT,capture_output=True,timeout=180)
    assert p.returncode==0 and not p.stderr
    return p.stdout
assert git('rev-parse','HEAD').decode().strip()==SHA
assert git('rev-parse','@{upstream}').decode().strip()==SHA
assert git('rev-parse','HEAD:src').decode().strip()=='85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert not git('diff','--cached','--name-only')
assert hashlib.sha256((ROOT/'AGENTS.md').read_bytes()).hexdigest()=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
assert not git('diff', '7cf661e7861971a61ac26d786ae0ae1e33ff2af6', 'HEAD', '--',
               'src/main','src/test','src/generated','build.gradle','settings.gradle','gradle.properties',
               'gradlew','gradlew.bat','gradle/wrapper','compat-test-mod/build.gradle',
               'compat-test-mod/settings.gradle','compat-test-mod/gradle.properties')
docs = ['docs/status/CURRENT_VERSION.md','docs/status/COMPLETION-PLAN.md',
        'docs/work/v1.8.0-implementation-log.md',
        'docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-08.md',
        'docs/work/v1.8.0-c18a-sleep/NESTED-BOUNDARY-STATUS-27.md',
        'docs/work/v1.8.0-c18a-sleep/NESTED-QUALIFICATION-32.md']
assert set(git('diff','--name-only').decode().splitlines())=={'AGENTS.md',*docs[:-1]}
assert not git('diff','--name-only','--','docs/provenance','docs/status/GATE_STATUS.md','docs/decisions','docs/11-RISK-REGISTER.md')
links=[]
for name in docs:
    text=(ROOT/name).read_text(encoding='utf-8')
    if name.endswith('v1.8.0-implementation-log.md'):
        text=text.split('## 2026-10-09 final nested observation',1)[0]
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if '://' in target or target.startswith('#'):
            continue
        resolved=((ROOT/name).parent/target.split('#',1)[0]).resolve()
        assert resolved.is_relative_to(ROOT.resolve()) and resolved.exists(),(name,target)
        links.append({'file':name,'target':target})
record={'main':SHA,'protected_owner_and_production':True,'checked_links':links,
        'whole_historical_log_portability':False,'new_runtime_or_gate_approval':False,
        'auxiliary_git_note':'Structured read values; not separately raw child receipts.'}
with (OUT/'RECORD-CHECK-04.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({'main':SHA,'checked_links':len(links),'protected_owner_and_production':True}),flush=True)
