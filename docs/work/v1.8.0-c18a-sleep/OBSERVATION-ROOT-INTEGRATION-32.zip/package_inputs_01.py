"""Rehost fully read Root27/D1 proposal29 seals, without modifying inputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
SPECS = [
    ('sleep-observation-checkpoint-20261009-27', 'OBSERVATION-ROOT-CHECKPOINT-27.zip',
     '18c52c49faec5ee2865d2f77184d2dcff1ca2d348f8cb66df05fcc020804d5df',
     'b00dcaf12ad085c859fe6b9fca3c8dbaf000affef402a48ebfdce5a70df0422a', []),
    ('sleep-dimension-spawn-time-contract-20261009-29', 'DIMENSION-SPAWN-TIME-PROPOSAL-29.zip',
     '867174864e118b89f617fb90b1f63eff5967e011fe7d513be0a0746acce7fdc8',
     'ce8bb6745d32a379bfb71d7d31488ce2c3171ec1555dbed13c2bb9ae8c258b9e', ['SEAL-RECEIPT.json'])]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def safe(path, leaf):
    assert path.resolve().is_relative_to(leaf.resolve())
    current = path
    while current != leaf.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(), 'st_file_attributes', 0) & 0x400)
        current = current.parent

started = datetime.now(timezone.utc).isoformat()
rows = []
for leaf_name, archive_name, manifest_sha, report_sha, extras in SPECS:
    leaf = BASE / leaf_name
    safe(leaf / 'SHA256SUMS.txt', leaf)
    raw_manifest = (leaf / 'SHA256SUMS.txt').read_bytes()
    assert sha(raw_manifest) == manifest_sha
    covered, names = {}, set()
    for line in raw_manifest.decode('utf-8-sig').splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line)
        assert match
        expected, name = match.groups()
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
        assert name.casefold() not in names
        names.add(name.casefold())
        safe(leaf / name, leaf)
        assert sha((leaf / name).read_bytes()) == expected.lower()
        covered[name] = expected.lower()
    assert covered['REPORT.md'] == report_sha
    paths = {}
    for path in leaf.rglob('*'):
        safe(path, leaf)
        if path.is_file():
            assert path.stat().st_size < 50 * 1024 ** 2
            paths[path.relative_to(leaf).as_posix()] = path
    assert set(paths) == set(covered) | {'SHA256SUMS.txt', *extras}
    assert len(paths) == len({name.casefold() for name in paths})
    target = DEST / archive_name
    assert not target.exists()
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.write(path, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes()
        expanded = sum(info.file_size for info in archive.infolist())
    rows.append({'archive': archive_name, 'bytes': target.stat().st_size,
                 'expanded_bytes': expanded, 'archive_sha256': sha(target.read_bytes()),
                 'covered_entries': len(covered), 'covered_bytes': sum(paths[x].stat().st_size for x in covered),
                 'manifest_sha256': manifest_sha, 'report_sha256': report_sha,
                 'noncovered_postseal_entries': extras, 'crc_payloads_verified': True})
archives, compressed, expanded = [], 0, 0
for path in sorted(DEST.glob('*.zip')):
    assert path.stat().st_size < 50 * 1024 ** 2
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        size = sum(info.file_size for info in archive.infolist())
    compressed += path.stat().st_size
    expanded += size
    archives.append({'path': path.name, 'bytes': path.stat().st_size, 'expanded_bytes': size,
                     'sha256': sha(path.read_bytes())})
assert max(compressed, expanded) < 100 * 1024 ** 2
record = {'orig_argv': sys.orig_argv, 'operation_start_utc': started,
          'operation_end_utc': datetime.now(timezone.utc).isoformat(),
          'timing_note': 'Sampled inside Python; not a reconstructed external launcher start.',
          'archives': rows, 'all_sleep_archives': archives, 'all_sleep_compressed_bytes': compressed,
          'all_sleep_expanded_bytes': expanded, 'runtime_or_contract_approval': False}
with (OUT / 'PACKAGING-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
