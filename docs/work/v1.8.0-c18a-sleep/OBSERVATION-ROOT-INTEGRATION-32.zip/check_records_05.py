"""Correct link-check scope only; preserve failed04 and its original assertions."""
import hashlib
from pathlib import Path

original = Path(__file__).with_name('check_records_04.py')
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '3e4932f95feac3bea3fe78d37093b7fecefed8504517e370d052ff36e4144789'
source = raw.decode('utf-8')
old = "    text=(ROOT/name).read_text(encoding='utf-8')\n    if name.endswith('v1.8.0-implementation-log.md'):\n        text=text.split('## 2026-10-09 final nested observation',1)[0]\n"
new = "    if name.endswith('NESTED-QUALIFICATION-32.md'):\n        text=(ROOT/name).read_text(encoding='utf-8')\n    else:\n        diff=git('diff','--unified=0','--',name).decode('utf-8')\n        text='\\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))\n"
assert source.count(old)==1
source = source.replace(old,new).replace('RECORD-CHECK-04.json','RECORD-CHECK-05.json')
exec(compile(source,str(Path(__file__)), 'exec'), {'__file__':str(Path(__file__)), '__name__':'__main__'})
