# Root final observation qualification and conditional test-source integration32

Date: 2026-10-09 UTC. Root is the sole Main integrator. Main base:
7cf661e7861971a61ac26d786ae0ae1e33ff2af6. Candidate:
d57ecda1f11dab76d882f945b0de606534ef4fb9. This is the opt-in observation/test
slice only, not production off-world sleep, native driver or a release Gate.

Before any source integration Root must completely read Task28's final report,
verify its actual command/result/raw logs/XML/native/artifact/state evidence and
one-time manifest, and check fixed candidate source/review/caps/permissions.
Task21's complete independent source review and Task26's contract disposition
are already read; no scoped implementation finding may be bypassed. If source,
test, attribution or artifact problems remain, stop integration and record them.
Do not infer a fresh result from historical5b, a compile, declared counts or an
uncommitted snapshot. Keep strict/log/cleanup limits and failed cohorts explicit.

Exclusive evidence/scratch: this leaf. Main write_scope: a new qualification/
integration record and compact ZIPs under docs/work/v1.8.0-c18a-sleep; additive
supersession notes in SOURCE-REVIEW-STATUS-08.md and NESTED-BOUNDARY-STATUS-27.md;
CURRENT_VERSION.md, COMPLETION-PLAN.md and v1.8.0-implementation-log.md. Separately
read/rehost sealed Root27/Task29 and later completed independent31 without
assuming its findings or D1 freeze. No old sealed input or archive is modified.

Conditional non-forced Git merge is permitted solely for the reviewed fixed
candidate's three adapterTest Java files. Inspect full incoming source diff,
ancestor/build/resource/public/API identities and protect any unrelated changes.
No production source/resource/schema/API/build edits or conflict resolution are
authorized here. An unexpected changed path, conflict or foreign index mutation
stops merge for a separately scoped decision. Before moving Main HEAD confirm
other active workers retain fixed source/governance interests. No amend/rebase/
force/reset/checkout overwrite. Inspect staged stat/diff or merge input before
commit. Normally push the verified test slice before starting another slice.
Bind tested source SHA and source-content equivalence separately from merge SHA;
do not claim a merge-SHA Gradle/native rerun or packaged observation qualification.

Validate archive manifests/safe unique paths/CRC/payload, whole slice actual
file/directory volumes, owner AGENTS hash, unchanged ledger/Gates and changed
links/whitespace/approved-bootstrap/accepted-ledger. Capture exact command argv/
cwd/start/end UTC/exit/raw streams and before/after identities; preserve failures
under distinct records. Only exact task files may be staged for record commits.
No user/peer/untracked historical evidence takeover or cleanup. Task28 remains
responsible for its own one-attempt generated output cleanup under clarification30.

No driver/parser implementation, twenty-row invocation, OS quota/helper/process
authority, world/player migration/repair, production dimension/spawn/time/air/
respawn, Space/hatch policy or Required Gate approval. All source tests, static
contracts, actual capture/gameplay outcomes and acceptance remain distinct.
Final report must be fully read/audited before one-time sealing. Later outcomes
use a new checkpoint, not mutation of these or older sealed bytes.
