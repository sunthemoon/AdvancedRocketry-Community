"""One-time evidence custody seal; post-seal result is explicitly excluded."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

LEAF=Path(__file__).resolve().parent
started=datetime.now(timezone.utc).isoformat()
assert not (LEAF/'SHA256SUMS.txt').exists() and not (LEAF/'SEAL-RESULT.json').exists()
assert (LEAF/'FINAL-AUDIT-06.json').exists() and (LEAF/'FULL-READ-ACK.md').exists()
paths=sorted(p for p in LEAF.rglob('*') if p.is_file())
names=set()
lines=[]
for path in paths:
    assert path.resolve().is_relative_to(LEAF.resolve())
    current=path
    while current!=LEAF.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(),'st_file_attributes',0)&0x400)
        current=current.parent
    name=path.relative_to(LEAF).as_posix()
    assert name.casefold() not in names and path.stat().st_size<50*1024**2
    names.add(name.casefold())
    lines.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+name)
assert sum(p.stat().st_size for p in paths)<100*1024**2
raw=('\n'.join(lines)+'\n').encode('utf-8')
with (LEAF/'SHA256SUMS.txt').open('xb') as f:
    f.write(raw)
for path,line in zip(paths,lines):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==line[:64]
result={'argv':sys.orig_argv,'cwd':str(Path.cwd()),'start_utc':started,
        'end_utc':datetime.now(timezone.utc).isoformat(),'exit_code':0,
        'covered_files':len(paths),'covered_bytes':sum(p.stat().st_size for p in paths),
        'manifest_sha256':hashlib.sha256(raw).hexdigest(),
        'report_sha256':hashlib.sha256((LEAF/'REPORT.md').read_bytes()).hexdigest(),
        'excluded':['SHA256SUMS.txt','SEAL-RESULT.json'],'gate_approval':False}
with (LEAF/'SEAL-RESULT.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
