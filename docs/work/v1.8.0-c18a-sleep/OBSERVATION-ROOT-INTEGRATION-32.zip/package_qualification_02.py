"""Package sealed Task28, retaining explicitly excluded post-seal receipts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT = Path(__file__).resolve().parent
LEAF = OUT.parent/'sleep-nested-source-qualification-20261009-28'
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def safe(path):
    assert path.resolve().is_relative_to(LEAF.resolve())
    current = path
    while current != LEAF.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(), 'st_file_attributes',0)&0x400)
        current = current.parent

manifest = (LEAF/'SHA256SUMS.txt').read_bytes()
assert sha(manifest) == 'd063e2b87fae9fb0856d4141e8c1d27e15ae540f797adf15e384bc9875efa913'
covered = {}
for line in manifest.decode('utf-8-sig').splitlines():
    match = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
    assert match
    expected, name = match.groups()
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
    safe(LEAF/name)
    assert sha((LEAF/name).read_bytes()) == expected
    covered[name] = expected
assert covered['REPORT.md'] == '52f3897671a060020f11ff46b5dcb61d20576b46e48cba66bc387362ff311e02'
seal = json.loads((LEAF/'SEAL-RESULT.json').read_text())
paths = {p.relative_to(LEAF).as_posix():p for p in LEAF.rglob('*') if p.is_file()}
assert set(paths) == set(covered)|set(seal['excluded'])
assert len(paths) == len({n.casefold() for n in paths})
for name,path in paths.items():
    safe(path)
    assert path.stat().st_size < 50*1024**2 and not name.startswith('scratch/')
target = DEST/'NESTED-SOURCE-QUALIFICATION-28.zip'
assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(paths.items()):
        z.write(path,name)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and set(z.namelist()) == set(paths)
    for name,path in paths.items():
        assert z.read(name) == path.read_bytes()
    expanded = sum(i.file_size for i in z.infolist())
archives = []
for path in sorted(DEST.glob('*.zip')):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        size = sum(i.file_size for i in z.infolist())
    assert path.stat().st_size < 50*1024**2
    archives.append({'path':path.name,'bytes':path.stat().st_size,'expanded_bytes':size,'sha256':sha(path.read_bytes())})
compressed_all = sum(x['bytes'] for x in archives)
expanded_all = sum(x['expanded_bytes'] for x in archives)
assert max(compressed_all,expanded_all) < 100*1024**2
result = {'utc':datetime.now(timezone.utc).isoformat(),'archive':target.name,
          'bytes':target.stat().st_size,'expanded_bytes':expanded,'sha256':sha(target.read_bytes()),
          'covered_files':len(covered),'covered_bytes':sum(paths[n].stat().st_size for n in covered),
          'manifest_sha256':sha(manifest),'excluded_postseal_entries':sorted(seal['excluded']),
          'excluded_postseal_identities':{n:{'bytes':paths[n].stat().st_size,'sha256':sha(paths[n].read_bytes())} for n in seal['excluded']},
          'all_sleep_archives':archives,'all_sleep_compressed_bytes':compressed_all,
          'all_sleep_expanded_bytes':expanded_all,'crc_payloads_verified':True,'gate_approval':False}
with (OUT/'PACKAGING-02.json').open('x',encoding='utf-8') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['all_sleep_archives','excluded_postseal_identities']}),flush=True)
