"""Verify Root32 actual command streams and publication identities before seal."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def git(*args):
    p = subprocess.run(['git',*args],cwd=MAIN,capture_output=True,timeout=180)
    assert p.returncode==0 and not p.stderr
    return p.stdout
assert git('rev-parse','HEAD').decode().strip()=='53dd312b5fcf4bbfcd1bd75d1f5abe13c1eb3d1a'
assert git('rev-parse','@{upstream}').decode().strip()=='53dd312b5fcf4bbfcd1bd75d1f5abe13c1eb3d1a'
assert git('rev-parse','HEAD:src').decode().strip()=='85f53265bf4ee59b65c4a88664cb2e5e208c583e'
assert git('status','--porcelain=v1','--untracked-files=no')==b' M AGENTS.md\n'
assert not git('diff','--cached','--name-only')
assert sha((MAIN/'AGENTS.md').read_bytes())=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
commands=[]
for path in sorted(LEAF.glob('*.command.json')):
    r=json.loads(path.read_text())
    for suffix, identity in r['streams'].items():
        raw=(LEAF/(r['name']+'.'+suffix+'.txt')).read_bytes()
        assert len(raw)==identity['bytes'] and sha(raw)==identity['sha256']
    assert r['before']['owner_agents_sha256']==r['after']['owner_agents_sha256']=='c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
    assert r['exit_code']==(1 if r['name']=='record-check-04' else 0)
    commands.append({k:r[k] for k in ['name','argv','start_utc','end_utc','exit_code','timed_out']})
for name in ['candidate-01','candidate-02']:
    for path in sorted(LEAF.glob(name+'-*.json')):
        r=json.loads(path.read_text())
        # Earlier inspection helper has a separate receipt shape.
        for name, identity in r['streams'].items():
            raw=(LEAF/name).read_bytes()
            assert len(raw)==identity['bytes'] and sha(raw)==identity['sha256']
        assert r['exit']==0
record={'utc':datetime.now(timezone.utc).isoformat(),'main':'53dd312b5fcf4bbfcd1bd75d1f5abe13c1eb3d1a',
        'src_tree':'85f53265bf4ee59b65c4a88664cb2e5e208c583e','commands':commands,
        'report_sha256':sha((LEAF/'REPORT.md').read_bytes()),'new_gate_approval':False}
with (LEAF/'FINAL-AUDIT-06.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='commands'}),flush=True)
