"""Capture the full incoming test-only merge input; do not move HEAD."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
MAIN = '7cf661e7861971a61ac26d786ae0ae1e33ff2af6'
SOURCE = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
EXPECTED = sorted('src/adapterTest/java/io/github/sunthemoon/arceadaptertest/' + name for name in (
    'SleepBoundaryObservationFixture.java', 'SleepBoundaryTrace.java', 'SleepBoundaryChatBounds.java'))
BUILD = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
         'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties',
         'compat-test-mod/build.gradle', 'compat-test-mod/settings.gradle', 'compat-test-mod/gradle.properties']

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def capture(name, args):
    argv = ['git', *args]
    stdout, stderr = OUT / (name + '.stdout'), OUT / (name + '.stderr')
    assert not stdout.exists() and not stderr.exists()
    started = datetime.now(timezone.utc).isoformat()
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err, timeout=180, check=False)
    record = {'argv': argv, 'cwd': str(ROOT), 'start_utc': started,
              'end_utc': datetime.now(timezone.utc).isoformat(), 'exit': result.returncode,
              'streams': {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
                          for path in (stdout, stderr)}}
    with (OUT / (name + '.json')).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0, record
    return stdout.read_bytes()

assert capture('candidate-01-main', ['rev-parse', 'HEAD']).decode().strip() == MAIN
assert not capture('candidate-01-index', ['diff', '--cached', '--name-only']).strip()
capture('candidate-01-worktrees', ['worktree', 'list', '--porcelain'])
capture('candidate-01-merge-base', ['merge-base', MAIN, SOURCE])
changes = capture('candidate-01-paths', ['diff', '--name-only', MAIN, SOURCE]).decode().splitlines()
assert sorted(changes) == EXPECTED, changes
capture('candidate-01-stat', ['diff', '--stat', MAIN, SOURCE])
capture('candidate-01-full-diff', ['diff', '--binary', MAIN, SOURCE])
identities = []
for index, path in enumerate(EXPECTED):
    raw = capture('candidate-01-source-' + str(index), ['show', SOURCE + ':' + path])
    identities.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
for path in BUILD:
    left = subprocess.check_output(['git', 'rev-parse', MAIN + ':' + path], cwd=ROOT).decode().strip()
    right = subprocess.check_output(['git', 'rev-parse', SOURCE + ':' + path], cwd=ROOT).decode().strip()
    assert left == right, path
    identities.append({'path': path, 'main_git_blob': left, 'source_git_blob': right})
for path in ('src/main', 'src/test', 'src/generated', 'src/adapterTest'):
    left = subprocess.check_output(['git', 'rev-parse', MAIN + ':' + path], cwd=ROOT).decode().strip()
    right = subprocess.check_output(['git', 'rev-parse', SOURCE + ':' + path], cwd=ROOT).decode().strip()
    if path != 'src/adapterTest':
        assert left == right, path
    identities.append({'tree': path, 'main': left, 'source': right})
record = {'main': MAIN, 'source': SOURCE, 'incoming_paths': changes, 'identities': identities,
          'auxiliary_identity_note': 'Blob/tree rev-parse reads are audit values, not separately raw child receipts.',
          'head_moved': False}
with (OUT / 'CANDIDATE-INPUT-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
