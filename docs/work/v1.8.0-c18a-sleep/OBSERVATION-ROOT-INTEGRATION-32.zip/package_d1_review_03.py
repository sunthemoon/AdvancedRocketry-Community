"""Rehost completely read sealed independent D1 review31; no D1 adoption."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT = Path(__file__).resolve().parent
LEAF = OUT.parent/'sleep-d1-contract-independent-20261009-31'
DEST = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def safe(path):
    assert path.resolve().is_relative_to(LEAF.resolve())
    current = path
    while current != LEAF.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(),'st_file_attributes',0)&0x400)
        current = current.parent

manifest = (LEAF/'SHA256SUMS.txt').read_bytes()
assert sha(manifest) == '7ca1eb90067eef4ec6736010e87b2fce242b29db9bf88741bff63a9f29cdae3d'
covered = {}
for line in manifest.decode('utf-8-sig').splitlines():
    m = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)',line)
    assert m
    expected,name = m.groups()
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
    safe(LEAF/name)
    assert sha((LEAF/name).read_bytes()) == expected
    covered[name] = expected
assert covered['REPORT.md'] == '9bf95deec7cf3753a2d55586fe7221ebb6fd86e066241080e78865c6dccbd7e4'
paths = {p.relative_to(LEAF).as_posix():p for p in LEAF.rglob('*') if p.is_file()}
assert set(paths)-set(covered) == {'SHA256SUMS.txt','SEAL-RECEIPT.json'}
assert len(paths) == len({n.casefold() for n in paths})
assert len(covered)==286 and sum(paths[n].stat().st_size for n in covered)==1342288
assert sha(paths['SEAL-RECEIPT.json'].read_bytes()) == 'da8d41283791823fa15411b1380e5778891f92cd3b4fd34848763c2de9da2945'
target = DEST/'DIMENSION-SPAWN-TIME-INDEPENDENT-31.zip'
assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(paths.items()):
        safe(path)
        assert path.stat().st_size < 50*1024**2
        z.write(path,name)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and set(z.namelist()) == set(paths)
    for name,path in paths.items():
        assert z.read(name) == path.read_bytes()
    expanded = sum(i.file_size for i in z.infolist())
all_archives = []
for path in sorted(DEST.glob('*.zip')):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        size = sum(i.file_size for i in z.infolist())
    assert path.stat().st_size < 50*1024**2
    all_archives.append({'path':path.name,'bytes':path.stat().st_size,'expanded_bytes':size,'sha256':sha(path.read_bytes())})
compressed_all = sum(x['bytes'] for x in all_archives)
expanded_all = sum(x['expanded_bytes'] for x in all_archives)
assert max(compressed_all,expanded_all) < 100*1024**2
result = {'utc':datetime.now(timezone.utc).isoformat(),'archive':target.name,
          'bytes':target.stat().st_size,'expanded_bytes':expanded,'sha256':sha(target.read_bytes()),
          'manifest_sha256':sha(manifest),'covered_files':len(covered),'covered_bytes':1342288,
          'excluded_entries':['SHA256SUMS.txt','SEAL-RECEIPT.json'],
          'all_sleep_archives':all_archives,'all_sleep_compressed_bytes':compressed_all,
          'all_sleep_expanded_bytes':expanded_all,'crc_payloads_verified':True,'d1_approval':False}
with (OUT/'PACKAGING-03.json').open('x',encoding='utf-8') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='all_sleep_archives'}),flush=True)
