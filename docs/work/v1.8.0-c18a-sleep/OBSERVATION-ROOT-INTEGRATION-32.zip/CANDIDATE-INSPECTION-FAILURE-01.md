# Candidate-inspection preparation failure01

Root's first helper compares all Main/source endpoint paths to the three expected
incoming adapter files. That comparison also lists Main-only documentation
updates after the common ancestor, so it exits1 at the path assertion before
source reads/artifact checks or any merge. Its actual preceding Git command
receipts and endpoint list remain unchanged. The outer traceback remains a
session tool receipt, not reconstructed process UTC/raw child capture.

Actual common ancestor is b9bec789978de0df67c93e976239d6d36e41532b. A separate
corrected helper uses ancestor-to-candidate to inspect the actual incoming
merge delta, retains the full endpoint list for disclosure, and still requires
exactly three adapter files plus identical production/test/generated/build
inputs between Main and candidate. No unexpected incoming path is waived;
no documentation/source overwrite, HEAD move or scope expansion occurs.
