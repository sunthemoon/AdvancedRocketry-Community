# Record-check04 scope failure

The 08:07:34.683478 to 08:07:35.180992 UTC command exits 1. Its complete raw
stderr and identities are retained. The helper incorrectly validates every
historical COMPLETION-PLAN link against a repository-only containment rule;
it encounters an inherited absolute external evidence link. This is not a
new Task32 link or a source/production failure. No stage/commit follows it.

Separate helper05 pins the unchanged04 bytes and checks only actual added
lines in changed tracked documents plus the complete new qualification32.
Owner/source/production/index/scope checks remain identical. Whole historical
plan/log portability is not approved, and no old link or file is changed or
deleted. Later validation outcomes are distinct, not a replacement receipt.
