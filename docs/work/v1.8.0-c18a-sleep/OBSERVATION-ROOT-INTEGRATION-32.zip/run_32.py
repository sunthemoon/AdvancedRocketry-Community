"""Capture Root32 commands, including failed cohorts, without invoking a shell."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def state():
    result = {'utc': utc(), 'owner_agents_sha256': digest((MAIN/'AGENTS.md').read_bytes())}
    for name, args in [('head', ['rev-parse', 'HEAD']),
                       ('upstream', ['rev-parse', '@{upstream}']),
                       ('src_tree', ['rev-parse', 'HEAD:src']),
                       ('index', ['diff', '--cached', '--name-only']),
                       ('tracked_status', ['status', '--porcelain=v1', '--untracked-files=no'])]:
        argv = ['git', '-C', str(MAIN), *args]
        started = utc()
        p = subprocess.run(argv, capture_output=True, timeout=180)
        result[name] = {'argv': argv, 'start_utc': started, 'end_utc': utc(),
                        'exit_code': p.returncode, 'stdout': p.stdout.decode('utf-8'),
                        'stderr': p.stderr.decode('utf-8')}
    return result

name, *argv = sys.argv[1:]
assert name and all(c.isalnum() or c in '-_' for c in name) and argv
receipt = LEAF/(name+'.command.json')
assert not receipt.exists()
record = {'name': name, 'argv': argv, 'cwd': str(MAIN), 'timeout_seconds': 180,
          'helper_sha256': digest(Path(__file__).read_bytes()), 'before': state()}
start = time.monotonic()
record['start_utc'] = utc()
try:
    p = subprocess.run(argv, cwd=MAIN, capture_output=True, timeout=180)
    code, stdout, stderr, timed_out = p.returncode, p.stdout, p.stderr, False
except subprocess.TimeoutExpired as error:
    code, stdout, stderr, timed_out = 124, error.stdout or b'', error.stderr or b'', True
record.update(end_utc=utc(), elapsed_seconds=time.monotonic()-start,
              exit_code=code, timed_out=timed_out, after=state(), streams={})
for suffix, raw in [('stdout', stdout), ('stderr', stderr)]:
    with (LEAF/(name+'.'+suffix+'.txt')).open('xb') as stream:
        stream.write(raw)
    record['streams'][suffix] = {'bytes': len(raw), 'sha256': digest(raw)}
with receipt.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
print(stdout.decode('utf-8', errors='replace'), flush=True)
print(stderr.decode('utf-8', errors='replace'), file=sys.stderr, flush=True)
sys.exit(code)
