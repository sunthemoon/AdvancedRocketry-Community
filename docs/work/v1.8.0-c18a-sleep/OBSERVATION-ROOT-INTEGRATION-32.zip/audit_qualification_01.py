"""Independently verify Task28 seal, raw receipts and retained result evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
LEAF = OUT.parent/'sleep-nested-source-qualification-20261009-28'
SOURCE = Path('D:/GitHub/arce-v180-sleep-nested-qualification-20261009-28')
SHA = 'd57ecda1f11dab76d882f945b0de606534ef4fb9'
TREE = '85f53265bf4ee59b65c4a88664cb2e5e208c583e'
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def load(name):
    return json.loads((LEAF/name).read_text(encoding='utf-8'))
def safe(path):
    assert path.resolve().is_relative_to(LEAF.resolve())
    current = path
    while current != LEAF.parent:
        assert not current.is_symlink() and not (getattr(current.lstat(), 'st_file_attributes', 0)&0x400)
        current = current.parent

manifest = (LEAF/'SHA256SUMS.txt').read_bytes()
assert digest(manifest) == 'd063e2b87fae9fb0856d4141e8c1d27e15ae540f797adf15e384bc9875efa913'
covered, names = {}, set()
for line in manifest.decode('utf-8-sig').splitlines():
    match = re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+)', line)
    assert match
    expected, name = match.groups()
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and '..' not in pure.parts and ':' not in name and '\\' not in name
    assert name.casefold() not in names
    names.add(name.casefold())
    path = LEAF/name
    safe(path)
    assert digest(path.read_bytes()) == expected
    covered[name] = expected
assert covered['REPORT.md'] == '52f3897671a060020f11ff46b5dcb61d20576b46e48cba66bc387362ff311e02'
seal = load('SEAL-RESULT.json')
files = {p.relative_to(LEAF).as_posix(): p for p in LEAF.rglob('*') if p.is_file()}
assert set(files)-set(covered) == set(seal['excluded'])
assert not any(n.startswith('scratch/') for n in files)
assert len(covered) == seal['covered_files']
assert sum(files[n].stat().st_size for n in covered) == seal['covered_bytes']
for p in files.values():
    safe(p)

receipts = []
for path in sorted(LEAF.glob('*.command.json')):
    r = json.loads(path.read_text())
    for suffix, identity in r['streams'].items():
        raw = (LEAF/(r['name']+'.'+suffix+'.txt')).read_bytes()
        assert len(raw) == identity['bytes'] and digest(raw) == identity['sha256']
    for point in ['before', 'after']:
        s = r[point]
        assert s['head']['exit'] == 0 and s['head']['stdout'].strip() == SHA
        assert s['src_tree']['exit'] == 0 and s['src_tree']['stdout'].strip() == TREE
        for k in ['status','tracked_diff','index_diff','src_diff']:
            assert s[k]['exit'] == 0 and not s[k]['stdout'] and not s[k]['stderr']
        for name, identity in s['inputs'].items():
            raw = (SOURCE/name).read_bytes()
            assert len(raw) == identity['bytes'] and digest(raw) == identity['sha256']
    receipts.append({k:r[k] for k in ['name','argv','cwd','start_utc','end_utc',
                                   'elapsed_seconds','exit_code','timed_out','timeout_seconds']})
by_name = {r['name']: r for r in receipts}
for name in ['build-01','test-01','data-01','data-02','native-01',
             'publish-corrected-02','compat-01','cleanup-01','seal-01','seal-verify-01']:
    assert by_name[name]['exit_code'] == 0 and not by_name[name]['timed_out']
assert by_name['publish-01']['exit_code'] == 1 and not by_name['publish-01']['timed_out']
assert by_name['strict-01']['timed_out'] and by_name['strict-01']['timeout_seconds'] == 180
assert not (LEAF/'strict-01.stdout.txt').read_bytes() and not (LEAF/'strict-01.stderr.txt').read_bytes()
for name in ['data-01-diff','data-01-status','data-02-diff','data-02-status',
             'diff-check-01','post-cleanup-diff-corrected-02','post-cleanup-status-corrected-02']:
    assert by_name[name]['exit_code'] == 0
    assert not (LEAF/(name+'.stdout.txt')).read_bytes() and not (LEAF/(name+'.stderr.txt')).read_bytes()

junit = {}
collections = {}
for cohort in ['build-01','test-01','native-01','publish-corrected-02','compat-01']:
    c = collections[cohort] = load(cohort+'-COLLECTION.json')
    for copied in c['copied']:
        path = LEAF/copied['evidence'].replace('\\','/')
        raw = path.read_bytes()
        assert len(raw) == copied['bytes'] and digest(raw) == copied['sha256']
    if cohort not in ['build-01','test-01']:
        continue
    counts = {'xml_files':0, 'tests':0, 'failures':0, 'errors':0, 'skipped':0, 'actual_testcases':0}
    for path in sorted((LEAF/(cohort+'-results')).rglob('TEST-*.xml')):
        root = ET.fromstring(path.read_bytes())
        assert root.tag == 'testsuite'
        counts['xml_files'] += 1
        for key in ['tests','failures','errors','skipped']:
            counts[key] += int(root.attrib[key])
        counts['actual_testcases'] += len(root.findall('testcase'))
    assert counts == c['junit']['counts']
    assert counts['actual_testcases'] == counts['tests']
    assert not any(counts[k] for k in ['failures','errors','skipped'])
    junit[cohort] = counts

raw = (LEAF/'native-01.stdout.txt').read_text(encoding='utf-8', errors='replace')
terminal = [int(n) for n in re.findall(r'All (\d+) required tests passed', raw)]
batches = [{'name':n, 'discovered_tests':int(c)} for n,c in
           re.findall(r"Running test batch '([^']+)' \((\d+) tests\)", raw)]
actual = load('FINAL-RESULT-AUDIT.json')
assert batches == actual['native']['batches']
assert sum(x['discovered_tests'] for x in batches) == actual['native']['batch_total']
assert terminal == [int(n) for n in actual['native']['terminal_required_pass_counts']]
logs = [{'view':'stdout','error_headers':raw.count('/ERROR]'), 'fatal_headers':raw.count('/FATAL]')}]
for copied in collections['native-01']['copied']:
    path = LEAF/copied['evidence'].replace('\\','/')
    text = path.read_text(encoding='utf-8', errors='replace')
    logs.append({'view':path.name,'error_headers':text.count('/ERROR]'),'fatal_headers':text.count('/FATAL]')})
for a, c in zip(logs[1:], collections['native-01']['native_log_inventory']):
    assert a['error_headers'] == c['error_headers'] and a['fatal_headers'] == c['fatal_headers']
assert not list((LEAF/'native-01-results').rglob('*.xml'))

# Generated binaries were intentionally removed by their author. Independently
# compare the retained pre-cleanup identity/entry inventories, not nonexistent JARs.
artifacts = []
for artifact in actual['artifacts']:
    cohort_rows = [x for c in collections.values() for x in c['artifacts'] if x['path']==artifact['path']]
    assert cohort_rows and all(x['sha256']==artifact['sha256'] and x['bytes']==artifact['bytes'] for x in cohort_rows)
    assert artifact['duplicate_entries'] == 0
    is_fixture = 'arce-adapter-compat-test' in artifact['path']
    assert bool(artifact['observation_class_entries']) == is_fixture
    if is_fixture:
        assert not artifact['api_class_entries']
    artifacts.append({k:artifact[k] for k in ['path','bytes','sha256','zip_entries','duplicate_entries','observation_class_entries']})
consumer = actual['consumer']
assert consumer['negative-import.json']['exit_code'] == 1
assert consumer['fixture-artifact.json']['sha256'] == next(x['sha256'] for x in artifacts if 'arce-adapter-compat-test' in x['path'])
assert consumer['classpath.json']['published_sha256'] == next(x['sha256'] for x in artifacts if x['path'].endswith('-api.jar'))

cleanup = load('CLEANUP-OUTPUT-INVENTORY.json')
cleanup_result = load('CLEANUP-RESULT.json')
assert cleanup_result['success'] and len(cleanup_result['removed']) == len(cleanup['targets'])
cleaned = []
for target in cleanup['targets']:
    assert target['exists'] and int(target['bytes']) == sum(int(x['bytes']) for x in target['files'])
    path = Path(target['path'])
    if path.name == 'scratch':
        assert not any(p.is_file() for p in path.rglob('*'))
    else:
        assert not path.exists()
    cleaned.append({'path':target['path'],'files':len(target['files']),'bytes':int(target['bytes'])})
result = {'utc':datetime.now(timezone.utc).isoformat(), 'source':SHA, 'src_tree':TREE,
          'manifest_sha256':digest(manifest),'covered_files':len(covered),
          'covered_bytes':sum(files[n].stat().st_size for n in covered),
          'excluded_postseal_files':sorted(set(files)-set(covered)),
          'verified_command_receipts':len(receipts),'commands':receipts,'junit':junit,
          'native':{'terminal_required_pass_counts':terminal,'batch_count':len(batches),
                    'batch_total':sum(x['discovered_tests'] for x in batches),
                    'sleep_batches':[x for x in batches if x['name'].startswith('sleep_')],
                    'log_views':logs,'native_xml':0,'per_method_pass_receipts':False},
          'artifacts':artifacts, 'artifact_note':'Retained pre-cleanup metadata and cross-cohort identities; binaries not reopened.',
          'consumer_negative_exit':consumer['negative-import.json']['exit_code'],
          'cleanup_targets':cleaned,'cleanup_bytes':sum(x['bytes'] for x in cleaned),
          'new_runtime_or_gate_approval':False}
with (OUT/'QUALIFICATION-AUDIT-01.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['commands','artifacts','cleanup_targets']}), flush=True)
