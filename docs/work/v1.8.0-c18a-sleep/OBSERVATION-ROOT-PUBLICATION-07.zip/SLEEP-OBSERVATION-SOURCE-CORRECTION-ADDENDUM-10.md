# Passive observation setup ownership correction 10

Date: 2026-10-09 UTC. Additive instruction to delegated source worker Task 05/08.
All existing two-file write_scope, commands, caps and source-only non-goals remain.
No prior task, fixed source, raw receipt or review cohort is replaced.

Independent actual-source review found a setup guard leak in both e72b41 and
0c05cc27: run sets INVOKING before constructing SleepBoundaryTrace/Fixture,
but the responsible try/finally begins only after construction (0c05 fixture
lines 101-106). An initialization/permission/class-initialization failure in
that interval never removes the server-thread ThreadLocal marker. It leaves
later invocations reentrancy-blocked. No such failure was executed.

Correct ownership so every failure after marker acquisition releases that exact
marker, including trace/fixture initialization failure, while preserving bounded
actual failure and partial-acquisition cleanup evidence. Retained-class metadata
unavailability is not a native success or reason to change an underlying event.
Do not install a SecurityManager, bypass native checks, change global JVM state
or launch runtime/failure injection. Tests may be added but only the already
authorized exact compile command may execute in this source assignment.

Deliver as a new commit and separate compile/raw receipts; no amend, forced push,
Main/reviewer HEAD move or early seal. Root later supplies the actual revision
SHA for an additive independent review.
