"""Check and publish only the direct owner decision and its current references."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
LEAF = Path(__file__).resolve().parent
BASE = "608f04360522f9aa2d1fdaab09d853d4cb4075f9"
OWNER_HASH = "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
EXPECTED = sorted([
    "docs/status/COMPLETION-PLAN.md", "docs/status/CURRENT_VERSION.md",
    "docs/work/v1.8.0-implementation-log.md",
    *["docs/work/v1.8.0-c18a-sleep/" + name for name in (
        "OWNER-DECISION-03.md", "OWNER-QUESTION-02.md", "OWNER-DECISION-01.md",
        "RESEARCH-STATUS-01.md", "SPAWN-RESEARCH-STATUS-02.md", "AIR-RESEARCH-STATUS-02.md",
        "BOUNDARY-REVIEW-STATUS-03.md", "CONTRACT-REVIEW-STATUS-01.md",
        "PROPOSED-OBSERVATION-01.md", "OBSERVATION-ASSIGNMENT-05.md", "SOURCE-REVIEW-STATUS-07.md")],
])

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT).decode("utf-8").strip()

def run(name, argv, timeout=180):
    log = LEAF / ("publication-02-" + name + ".log")
    receipt = log.with_suffix(".json")
    assert not log.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with log.open("xb") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=timeout, check=False)
    record = {"argv": argv, "cwd": str(ROOT), "start_utc": start,
              "end_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
              "head": git("rev-parse", "HEAD"), "log_bytes": log.stat().st_size,
              "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
              "owner_agents_sha256": hashlib.sha256((ROOT / "AGENTS.md").read_bytes()).hexdigest()}
    receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

assert git("rev-parse", "HEAD") == BASE
assert git("branch", "--show-current") == "codex/v1.8.0-classic-content"
assert not git("diff", "--cached", "--name-only")
assert hashlib.sha256((ROOT / "AGENTS.md").read_bytes()).hexdigest() == OWNER_HASH
assert sorted(git("diff", "--name-only").splitlines()) == sorted(["AGENTS.md", *[p for p in EXPECTED if p != "docs/work/v1.8.0-c18a-sleep/OWNER-DECISION-03.md"]])
for name, argv in (
    ("whitespace", ["git", "diff", "--check"]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py"]),
    ("bootstrap", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py"]),
    ("stage", ["git", "add", "--", *EXPECTED]),
    ("staged-stat", ["git", "diff", "--cached", "--stat"]),
    ("staged-whitespace", ["git", "diff", "--cached", "--check"]),
):
    run(name, argv)
assert sorted(git("diff", "--cached", "--name-only").splitlines()) == EXPECTED
run("commit", ["git", "commit", "-m", "docs(sleep): record accepted native dimension scope"])
run("push", ["git", "push", "origin", "HEAD:codex/v1.8.0-classic-content"])
assert git("rev-parse", "HEAD:src") == "368c91b05ecf98c1b817ec6e499708ff47c8399b"
assert git("status", "--short", "--untracked-files=no") == "M AGENTS.md"
