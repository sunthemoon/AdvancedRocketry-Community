# Packaged observation primary wire-contract qualification 17

You are a delegated read-only primary-inspection worker, not Root. Neutral
engineering voice; do not delegate or send competing OpenPet events. This is
static inspection, not driver/parser implementation or runtime permission.

Repository D:/GitHub/AdvancedRocketry-Community; fixed source
5b45132000ade1e3c8d130a6b8ccb29f07535124 and governance/owner record
48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514. Read mandatory AGENTS/governance,
active v1.8/post-v1.0/parallel rules and the two corrected adapter sources.
No worktree creation/movement or Main/source/peer HEAD/index/process interest.

Static contract input:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/PROPOSED-DRIVER-02.md
SHA256628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec.
Read its complete relevant contracts and sibling REPORT/seal. Source/standard
regression input: sealed Root Task11 and independent Task12 leaves under
D:/GitHub/ARCE-Task-Evidence/v1.8.0; REPORT/manifest identities are those named
in Task16. They supply current actual artifact/source/JDK boundary receipts,
not native twenty-case or packaged launch evidence.

Inspect exact pinned primary contracts required by the proposed offline parser:
1. System.out println route, native bootstrap/stream replacement, logger/profile
   configuration and supported raw/wrapped output framing for the stated packaged
   Forge recipe. Distinguish static proof, historical observed bytes and still
   unqualified current-runtime properties; do not launch a discovery server.
2. Corrected supported native component-to-JSON serializer union and bounds,
   including nested contents/style/hover forms, primitive variants and structural
   depth/node/collection accounting relevant to proposed parser limits.
3. Native SpawnDimension encoding/decoding wire type, coordinate/angle/forced
   types and present/absent/default projection for the two fresh owned actors.
   Keep getter, typed serialization and actual disk/restart evidence distinct.

Use actual installed/pinned Minecraft/Forge/JDK/library primary source/bytecode,
existing qualified native recipe input identities and relevant fixed fixtures.
Verify input hashes; inspect additional installed dependencies only as needed.
Report the evidence-supported contract and any unresolved boundary; do not
assume a wrapper, successful outcome, StringTag or closure. No code/assets are
copied from upstream; do not bundle complete primary JARs/source trees.

Write exclusively:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-wire-qualification-20261009-17/**.
Allowed commands: read-only Git/rg/file/hash/ZIP inspection, installed javap
including private bytecode for static inspection only (no invocation/reflection/
access change), Python -B compact evidence helpers. Ceiling180seconds. No
driver/parser/tests/Gradle/GameTest/native server/client/world/network, settings,
install, source/status/ledger/build/Main/index/HEAD/peer/original-seal edits,
commit/push, cleanup or process termination. Capture actual material command
pre-start UTC/argv/cwd/exit/raw streams and failures without reconstruction.

Deliver REPORT.md with findings/precise contract, fixed primary method/input
identities and bytecode/source evidence, proposed-parser compatibility results,
scope/limits and unfinished proof. Notify Root for full read before one-time
leaf-relative SHA256SUMS seal. No Gate, cause/enforcement or gameplay approval.
