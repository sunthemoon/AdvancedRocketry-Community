"""Check and publish only corrected-source evidence/current-state records."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
LEAF = Path(__file__).resolve().parent
BASE = "48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514"
OWNER_HASH = "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
DOCS = sorted([
    "docs/status/COMPLETION-PLAN.md", "docs/status/CURRENT_VERSION.md",
    "docs/work/v1.8.0-implementation-log.md",
    "docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-07.md",
    "docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-08.md",
])
ZIPS = sorted(["docs/work/v1.8.0-c18a-sleep/" + name for name in (
    "OBSERVATION-SOURCE-05.zip", "OBSERVATION-SOURCE-INDEPENDENT-06.zip",
    "OBSERVATION-DRIVER-DESIGN-09.zip", "OBSERVATION-ROOT-QUALIFICATION-11.zip",
    "OBSERVATION-INDEPENDENT-QUALIFICATION-12.zip", "OWNER-DECISION-INDEPENDENT-14.zip",
    "OBSERVATION-DRIVER-CONTRACT-15.zip")])
EXPECTED = sorted(DOCS + ZIPS)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT).decode("utf-8").strip()

def run(name, argv, timeout=180):
    log = LEAF / ("publication-03-" + name + ".log")
    receipt = log.with_suffix(".json")
    assert not log.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with log.open("xb") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=timeout, check=False)
    record = {"argv": argv, "cwd": str(ROOT), "start_utc": start,
              "end_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
              "head": git("rev-parse", "HEAD"), "log_bytes": log.stat().st_size,
              "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
              "owner_agents_sha256": hashlib.sha256((ROOT / "AGENTS.md").read_bytes()).hexdigest()}
    receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

assert git("rev-parse", "HEAD") == BASE
assert git("branch", "--show-current") == "codex/v1.8.0-classic-content"
assert not git("diff", "--cached", "--name-only")
assert hashlib.sha256((ROOT / "AGENTS.md").read_bytes()).hexdigest() == OWNER_HASH
assert sorted(git("diff", "--name-only").splitlines()) == sorted(["AGENTS.md", *[p for p in DOCS if not p.endswith("SOURCE-REVIEW-STATUS-08.md")]])
for name in DOCS:
    if name.endswith("v1.8.0-implementation-log.md"):
        continue
    path = ROOT / name
    for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        if "://" not in target and not target.startswith("#"):
            assert (path.parent / target.split("#", 1)[0]).exists(), (name, target)
expanded = 0
for path in (ROOT / "docs/work/v1.8.0-c18a-sleep").glob("*.zip"):
    assert path.stat().st_size < 50 * 1024 ** 2
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        expanded += sum(item.file_size for item in archive.infolist())
assert expanded < 100 * 1024 ** 2
for name, argv in (
    ("whitespace", ["git", "diff", "--check"]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("bootstrap", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py", "--require-approved-review"]),
    ("stage", ["git", "add", "--", *EXPECTED]),
    ("staged-stat", ["git", "diff", "--cached", "--stat"]),
    ("staged-whitespace", ["git", "diff", "--cached", "--check"]),
):
    run(name, argv)
assert sorted(git("diff", "--cached", "--name-only").splitlines()) == EXPECTED
run("commit", ["git", "commit", "-m", "docs(sleep): preserve corrected observation qualification"])
run("push", ["git", "push", "origin", "HEAD:codex/v1.8.0-classic-content"])
assert git("rev-parse", "HEAD:src") == "368c91b05ecf98c1b817ec6e499708ff47c8399b"
assert git("status", "--short", "--untracked-files=no") == "M AGENTS.md"
