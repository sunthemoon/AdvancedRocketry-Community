"""Audit and one-time seal only the immutable Main-309 records checkpoint."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
LEAF = Path(__file__).resolve().parent
INPUT = LEAF.parent
BASE = '30944465a6e07215990182fb0dd935e65303e27a'
OWNER = 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
START = datetime.now(timezone.utc).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def run(name, argv):
    out = LEAF / ('audit-04-' + name + '.log')
    receipt = out.with_suffix('.json')
    assert not out.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with out.open('xb') as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    record = {'argv': argv, 'cwd': str(ROOT), 'start_utc': start,
              'end_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode,
              'log_bytes': out.stat().st_size, 'log_sha256': sha(out.read_bytes())}
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    assert result.returncode == 0, record
    return out.read_text(encoding='utf-8').strip()

assert not (LEAF / 'SHA256SUMS.txt').exists()
assert sha((ROOT / 'AGENTS.md').read_bytes()) == OWNER
assert run('head', ['git', 'rev-parse', 'HEAD']) == BASE
assert run('upstream', ['git', 'rev-parse', '@{u}']) == BASE
assert run('tracked-status', ['git', 'status', '--short', '--untracked-files=no']) == 'M AGENTS.md'
assert not run('index', ['git', 'diff', '--cached', '--name-only'])
assert run('source-tree', ['git', 'rev-parse', 'HEAD:src']) == '368c91b05ecf98c1b817ec6e499708ff47c8399b'
assert not run('whitespace', ['git', 'diff', '--check'])
run('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
run('bootstrap', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py', '--require-approved-review'])

publications = []
for path in sorted(LEAF.glob('publication-*.json')):
    record = json.loads(path.read_text(encoding='utf-8'))
    log = path.with_suffix('.log')
    assert record['exit_code'] == 0
    assert record['start_utc'] <= record['end_utc']
    assert record['log_bytes'] == log.stat().st_size
    assert record['log_sha256'] == sha(log.read_bytes())
    assert record['owner_agents_sha256'] == OWNER
    publications.append({'receipt': path.name, 'receipt_sha256': sha(path.read_bytes())})

copies = []
tasks = ['SLEEP-OBSERVATION-SOURCE-CORRECTION-TASK-08.md',
         'SLEEP-OBSERVATION-SOURCE-CORRECTION-ADDENDUM-10.md',
         'SLEEP-OWNER-DECISION-REVIEW-TASK-14.md',
         'SLEEP-OBSERVATION-DRIVER-CONTRACT-TASK-15.md',
         'SLEEP-OBSERVATION-DRIVER-CONTRACT-REVIEW-TASK-16.md',
         'SLEEP-OBSERVATION-WIRE-QUALIFICATION-TASK-17.md']
for name in tasks:
    raw = (INPUT / name).read_bytes()
    dest = LEAF / name
    assert not dest.exists()
    with dest.open('xb') as stream:
        stream.write(raw)
    copies.append({'name': name, 'bytes': len(raw), 'sha256': sha(raw)})

archives = []
for path in sorted((ROOT / 'docs/work/v1.8.0-c18a-sleep').glob('*.zip')):
    assert path.stat().st_size < 50 * 1024 ** 2
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        expanded = sum(info.file_size for info in archive.infolist())
    rel = path.relative_to(ROOT).as_posix()
    committed = subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=ROOT)
    assert committed == path.read_bytes()
    archives.append({'path': rel, 'sha256': sha(committed),
                     'bytes': len(committed), 'expanded_bytes': expanded})
assert len(archives) == 14
assert sum(row['bytes'] for row in archives) == 4742468
assert sum(row['expanded_bytes'] for row in archives) == 28801331
record = {'start_utc': START, 'end_utc': datetime.now(timezone.utc).isoformat(),
          'checkpoint': BASE, 'report_sha256': sha((LEAF / 'REPORT.md').read_bytes()),
          'owner_agents_sha256': OWNER, 'publication_receipts_verified': publications,
          'exact_permission_copies': copies, 'archives': archives,
          'runtime_test_or_later_task_16_17_result': False}
(LEAF / 'PRESEAL-AUDIT-04.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
rows = []
for path in sorted(LEAF.rglob('*')):
    assert not path.is_symlink() and not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
    if path.is_file():
        name = path.relative_to(LEAF).as_posix()
        assert ':' not in name and '\\' not in name and '..' not in Path(name).parts
        assert path.stat().st_size < 50 * 1024 ** 2
        rows.append((name, sha(path.read_bytes()), path.stat().st_size))
assert len(rows) == len({row[0].casefold() for row in rows})
assert sum(row[2] for row in rows) < 100 * 1024 ** 2
manifest = LEAF / 'SHA256SUMS.txt'
with manifest.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(''.join(digest + '  ' + name + '\n' for name, digest, _ in rows))
for name, digest, _ in rows:
    assert sha((LEAF / name).read_bytes()) == digest
print(json.dumps({'covered_files': len(rows), 'covered_bytes': sum(row[2] for row in rows),
                  'report_sha256': record['report_sha256'], 'manifest_sha256': sha(manifest.read_bytes()),
                  'manifest_excludes': ['SHA256SUMS.txt'], 'seal_utc': datetime.now(timezone.utc).isoformat()}), flush=True)
