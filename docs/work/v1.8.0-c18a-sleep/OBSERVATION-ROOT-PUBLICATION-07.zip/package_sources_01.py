"""Package only verified immutable compact source/review/design evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

EXTERNAL = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
DEST = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep")
OUT = Path(__file__).resolve().parent
GROUPS = [
    ("sleep-observation-source-20261009-05", "OBSERVATION-SOURCE-05.zip",
     "826eac68b52a3e77a0823f6d33f1b645101a27d73c28462c2a1bffd5e0cea37a", set()),
    ("sleep-observation-source-independent-20261009-06", "OBSERVATION-SOURCE-INDEPENDENT-06.zip",
     "8a15258723e165c3a0e128278134af5ae6c74f2967cf457548ea0ccf9b155de0", {"SEAL-RESULT.json"}),
    ("sleep-observation-driver-design-20261009-09", "OBSERVATION-DRIVER-DESIGN-09.zip",
     "b7e7be0bebd828922a27832475e4ceb6a7e5d33d2f00c9b4b8e16f2cb5f1043a", set()),
]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def safe(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and ".." not in p.parts and ":" not in name and "\\" not in name
    assert p.as_posix() == name

rows = []
start = datetime.now(timezone.utc).isoformat()
for leaf_name, zip_name, manifest_hash, extras in GROUPS:
    leaf = EXTERNAL / leaf_name
    manifest = leaf / "SHA256SUMS.txt"
    assert digest(manifest.read_bytes()) == manifest_hash
    covered = {}
    for line in manifest.read_text(encoding="utf-8-sig").splitlines():
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
        assert match, line
        expected, name = match.groups()
        safe(name)
        assert name.casefold() not in {n.casefold() for n in covered}
        assert digest((leaf / name).read_bytes()) == expected.lower(), name
        covered[name] = expected.lower()
    assert "REPORT.md" in covered
    paths = {}
    for path in leaf.rglob("*"):
        assert not path.is_symlink() and not (getattr(path.lstat(), "st_file_attributes", 0) & 0x400), path
        if path.is_file():
            name = path.relative_to(leaf).as_posix()
            safe(name)
            assert path.stat().st_size < 50 * 1024 ** 2
            paths[name] = path
    assert set(paths) == set(covered) | {"SHA256SUMS.txt"} | extras, set(paths) ^ (set(covered) | {"SHA256SUMS.txt"} | extras)
    assert len({name.casefold() for name in paths}) == len(paths)
    assert sum(path.stat().st_size for path in paths.values()) < 100 * 1024 ** 2
    dest = DEST / zip_name
    assert not dest.exists()
    with zipfile.ZipFile(dest, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.write(path, name)
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes(), name
        expanded = sum(item.file_size for item in archive.infolist())
    assert digest(manifest.read_bytes()) == manifest_hash
    rows.append({"source_leaf": str(leaf), "archive": str(dest), "archive_bytes": dest.stat().st_size,
                 "archive_sha256": digest(dest.read_bytes()), "expanded_bytes": expanded,
                 "entries": len(paths), "manifest_covered_entries": len(covered),
                 "manifest_sha256": manifest_hash, "report_sha256": covered["REPORT.md"],
                 "postseal_noncovered_files": sorted(extras), "crc_and_all_payloads_verified": True})
    print(json.dumps(rows[-1]), flush=True)
total_compressed = 0
total_expanded = 0
for path in DEST.glob("*.zip"):
    total_compressed += path.stat().st_size
    with zipfile.ZipFile(path) as archive:
        total_expanded += sum(info.file_size for info in archive.infolist())
assert total_expanded < 100 * 1024 ** 2
record = {"started_utc": start, "ended_utc": datetime.now(timezone.utc).isoformat(), "archives": rows,
          "all_sleep_archive_compressed_bytes": total_compressed,
          "all_sleep_archive_expanded_bytes": total_expanded,
          "source_or_runtime_change": False}
target = OUT / "PACKAGING-01.json"
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
