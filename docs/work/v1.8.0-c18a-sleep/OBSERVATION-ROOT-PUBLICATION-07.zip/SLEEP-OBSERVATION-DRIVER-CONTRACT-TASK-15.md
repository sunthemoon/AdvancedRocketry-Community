# Corrected-source observation driver contract proposal 15

You are a delegated planning worker, not Root. Use a neutral engineering voice,
do not delegate, and do not send competing OpenPet events. This is static
contract preparation only, not an executable driver or runtime assignment.

Repository: D:/GitHub/AdvancedRocketry-Community. Fixed corrected source:
5b45132000ade1e3c8d130a6b8ccb29f07535124; source base b9bec789978de0df67c93e976239d6d36e41532b.
Fixed current governance/owner-record checkpoint:
48e8ea5b70de3cb01a3fd303c2b0bb4a200fe514. Read mandatory AGENTS/governance,
active v1.8/post-v1.0/parallel rules, observation assignment/proposal and the
committed exact owner decision03. You hold no Main/source/peer HEAD or process
interest. No worktree creation/move.

Primary proposal input, sealed and read-only:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-design-20261009-09/REPORT.md
and PROPOSED-DRIVER.md. Its REPORT SHA256 is
83e255f95ddf4a0cd77c8b983093f50c16370cf84d482d8d3a22dc7d6f5857fe;
manifest SHA256 b7e7be0bebd828922a27832475e4ceb6a7e5d33d2f00c9b4b8e16f2cb5f1043a.
Independent source-review input, sealed and read-only:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-independent-20261009-06/REPORT.md;
REPORT SHA256 3fb635aca10c20463e8703329b36b0917bf78858a415586aa093027173e934a0,
manifest 8a15258723e165c3a0e128278134af5ae6c74f2967cf457548ea0ccf9b155de0.

Read the two full fixed corrected adapter source files and actual schemas,
registration/default gate, native twenty-row actions and teardown. Prepare a
new PROPOSED-DRIVER-02.md and REPORT.md suitable for later independent review.
Identify exact structural/parser/launch/phase/retention contracts from actual
source and existing packaged Forge recipe. Separate integrity, execution,
observation, interventions, native outcomes, cleanup, save evidence and acceptance.
Do not encode desired native outcomes or prefill tested counts/artifact hashes.
Artifact identities must be actual later qualification inputs, not assumed from
the earlier source. Record any unresolved implementation assumptions/questions.

Scope remains one fresh packaged native process with two sequential invocations
of the exact twenty-case native-Java console fixture, if subsequently assigned.
No TCP/client, restart/death/prior world, inheritance/custom bed/monster/item/mod
qualification, off-world natural/spawn/time/air implementation, cause enforcement,
air-gap/station choice, migration, global night skip or Gate/ledger/item closure.
The owner response does not expand this observation-only scope. Preserve source
caps and existing standard-test budgets; distinguish any proposed bounded driver
phase ceiling from measured performance. No new runtime permission is inferred.

Write scope exclusively:
D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15/**.
Allowed: read-only Git/rg/file/hash/ZIP/JSON inspection, installed public javap
if needed, Python -B own compact documentation/evidence helpers; 180-second
command ceiling. No source/production/test/build/status/ledger/Main/index/HEAD/
original seal/peer writes; no executable driver/parser/tests, Gradle, GameTest,
native server/client/world, network, cleanup or process termination. No commit/
push or subordinate delegation. Capture actual material commands with raw
streams/argv/cwd/pre-start UTC/exit and limits; no invented reconstruction.

Deliver findings/issues and the complete proposed contract, fixed-input hashes,
commands and boundaries. Notify Root for full read before a one-time
SHA256SUMS.txt seal. Final answer: report/proposal paths and actual sealed hashes.
