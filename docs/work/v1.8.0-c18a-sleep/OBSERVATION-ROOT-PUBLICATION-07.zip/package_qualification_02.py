"""Verify and package compact sealed regression/owner-review evidence only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

EXTERNAL = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
DEST = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep")
OUT = Path(__file__).resolve().parent
GROUPS = [
    ("sleep-observation-root-qualification-20261009-11", "OBSERVATION-ROOT-QUALIFICATION-11.zip",
     "8f6a602a85fb91ab194068ee119ac3e72b170d95c06701aba38da56b1dd175f1", set(), False),
    ("sleep-observation-qualification-independent-20261009-12", "OBSERVATION-INDEPENDENT-QUALIFICATION-12.zip",
     "542d90ea3197a1a3615ebf5b1a16048fea0a0c14dcdcdc6704904756c307c0f6", {"SEAL-RESULT.json"}, True),
    ("sleep-owner-decision-independent-20261009-14", "OWNER-DECISION-INDEPENDENT-14.zip",
     "891c7c20d7e0ff72e845aa8641caa9c6a33f70b2d97bebceb9a794454a687284", set(), False),
]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def safe(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and ".." not in p.parts and ":" not in name and "\\" not in name
    assert p.as_posix() == name

rows = []
start = datetime.now(timezone.utc).isoformat()
for leaf_name, zip_name, manifest_hash, extras, retained_tmp in GROUPS:
    leaf = EXTERNAL / leaf_name
    manifest = leaf / "SHA256SUMS.txt"
    assert digest(manifest.read_bytes()) == manifest_hash
    covered = {}
    for line in manifest.read_text(encoding="utf-8-sig").splitlines():
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
        assert match, line
        expected, name = match.groups()
        safe(name)
        assert name.casefold() not in {n.casefold() for n in covered}
        assert digest((leaf / name).read_bytes()) == expected.lower(), name
        covered[name] = expected.lower()
    assert "REPORT.md" in covered
    paths = {}
    excluded = []
    for path in leaf.rglob("*"):
        assert not path.is_symlink() and not (getattr(path.lstat(), "st_file_attributes", 0) & 0x400), path
        if path.is_file():
            name = path.relative_to(leaf).as_posix()
            safe(name)
            if retained_tmp and name.startswith("_tmp/"):
                excluded.append({"path": name, "bytes": path.stat().st_size})
                continue
            assert path.stat().st_size < 50 * 1024 ** 2
            paths[name] = path
    assert set(paths) == set(covered) | {"SHA256SUMS.txt"} | extras
    assert len({name.casefold() for name in paths}) == len(paths)
    assert sum(path.stat().st_size for path in paths.values()) < 100 * 1024 ** 2
    dest = DEST / zip_name
    assert not dest.exists()
    with zipfile.ZipFile(dest, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.write(path, name)
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(paths)
        for name, path in paths.items():
            assert archive.read(name) == path.read_bytes(), name
        expanded = sum(item.file_size for item in archive.infolist())
    rows.append({"source_leaf": str(leaf), "archive": str(dest), "archive_bytes": dest.stat().st_size,
                 "archive_sha256": digest(dest.read_bytes()), "expanded_bytes": expanded,
                 "entries": len(paths), "manifest_covered_entries": len(covered),
                 "manifest_sha256": manifest_hash, "report_sha256": covered["REPORT.md"],
                 "postseal_noncovered_files": sorted(extras), "excluded_policy_retained_tmp": excluded,
                 "crc_and_all_payloads_verified": True})
    print(json.dumps(rows[-1]), flush=True)
compressed = sum(path.stat().st_size for path in DEST.glob("*.zip"))
expanded = 0
for path in DEST.glob("*.zip"):
    with zipfile.ZipFile(path) as archive:
        expanded += sum(info.file_size for info in archive.infolist())
assert expanded < 100 * 1024 ** 2
target = OUT / "PACKAGING-02.json"
assert not target.exists()
target.write_text(json.dumps({"started_utc": start, "ended_utc": datetime.now(timezone.utc).isoformat(),
    "archives": rows, "all_sleep_archive_compressed_bytes": compressed,
    "all_sleep_archive_expanded_bytes": expanded, "runtime_or_gate_approval": False}, indent=2) + "\n", encoding="utf-8")
