"""Capture development-record checks; no build, test, or game launch."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
LEAF = Path(__file__).resolve().parent
CANDIDATE = "0c05cc27112f5f4a71faa66bc16b5f7f4390f345"
BASE = "b9bec789978de0df67c93e976239d6d36e41532b"
CHECKS = [
    ("main-head", ["git", "rev-parse", "HEAD"]),
    ("main-tracked-status", ["git", "status", "--short", "--untracked-files=no"]),
    ("main-index", ["git", "diff", "--cached", "--stat"]),
    ("main-whitespace", ["git", "diff", "--check"]),
    ("candidate-scope", ["git", "diff", "--name-status", BASE, CANDIDATE]),
    ("candidate-whitespace", ["git", "diff", "--check", BASE, CANDIDATE]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py"]),
    ("bootstrap", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py"]),
]

def utc():
    return datetime.now(timezone.utc).isoformat()

records = []
for name, argv in CHECKS:
    output = LEAF / f"check-01-{name}.log"
    if output.exists():
        raise SystemExit(f"Refusing to overwrite {output}")
    start = utc()
    with output.open("xb") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    record = {"name": name, "argv": argv, "cwd": str(ROOT), "start_utc": start,
              "end_utc": utc(), "exit_code": result.returncode,
              "log": output.name, "log_bytes": output.stat().st_size,
              "log_sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    records.append(record)
    print(json.dumps(record), flush=True)
    receipt = LEAF / "check-01.json"
    receipt.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    if result.returncode:
        raise SystemExit(result.returncode)

owner = ROOT / "AGENTS.md"
print(json.dumps({"owner_agents_sha256": hashlib.sha256(owner.read_bytes()).hexdigest()}))
