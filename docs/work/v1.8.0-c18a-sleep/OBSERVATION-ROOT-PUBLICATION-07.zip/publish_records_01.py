"""Publish only Root's already reviewed four-file development checkpoint."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
LEAF = Path(__file__).resolve().parent
EXPECTED = sorted([
    "docs/status/COMPLETION-PLAN.md", "docs/status/CURRENT_VERSION.md",
    "docs/work/v1.8.0-c18a-sleep/SOURCE-REVIEW-STATUS-07.md",
    "docs/work/v1.8.0-implementation-log.md",
])
OWNER_HASH = "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09"
assert hashlib.sha256((ROOT / "AGENTS.md").read_bytes()).hexdigest() == OWNER_HASH
assert subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT).decode().strip() == "codex/v1.8.0-classic-content"
staged = subprocess.check_output(["git", "diff", "--cached", "--name-only"], cwd=ROOT).decode().splitlines()
assert sorted(staged) == EXPECTED, staged
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True)
for name, argv in [
    ("commit", ["git", "commit", "-m", "docs(sleep): record observation source bounds findings"]),
    ("push", ["git", "push", "origin", "HEAD:codex/v1.8.0-classic-content"]),
]:
    log = LEAF / f"publication-01-{name}.log"
    receipt = LEAF / f"publication-01-{name}.json"
    assert not log.exists() and not receipt.exists()
    start = datetime.now(timezone.utc).isoformat()
    with log.open("xb") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    record = {"argv": argv, "cwd": str(ROOT), "start_utc": start,
              "end_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
              "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
              "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
              "git_tracked_status": subprocess.check_output(["git", "status", "--short", "--untracked-files=no"], cwd=ROOT).decode().splitlines()}
    receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
