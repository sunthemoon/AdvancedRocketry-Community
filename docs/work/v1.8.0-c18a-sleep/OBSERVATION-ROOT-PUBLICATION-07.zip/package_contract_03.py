"""Package only the immutable corrected-source static driver proposal."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

LEAF = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-contract-20261009-15")
OUT = Path(__file__).resolve().parent
DEST = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep/OBSERVATION-DRIVER-CONTRACT-15.zip")
MANIFEST = "6966dcbf0b9cab637eb486c71476c4ce2a149c2c3563cf2842f38639fa9e2760"

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

start = datetime.now(timezone.utc).isoformat()
assert digest((LEAF / "SHA256SUMS.txt").read_bytes()) == MANIFEST
covered = {}
for line in (LEAF / "SHA256SUMS.txt").read_text(encoding="utf-8-sig").splitlines():
    match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
    assert match
    expected, name = match.groups()
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and ".." not in pure.parts and ":" not in name and "\\" not in name
    assert name.casefold() not in {key.casefold() for key in covered}
    assert digest((LEAF / name).read_bytes()) == expected.lower()
    covered[name] = expected.lower()
assert covered["REPORT.md"] == "d28eee20f0f4161e7d88f7bbc189b29a2c0a10d62cab62702496d4f3390a2277"
assert covered["PROPOSED-DRIVER-02.md"] == "628dd661e8e0c812ebda511d0f9b40abc99d46259eb3140ca5eeefbb79fdf0ec"
paths = {}
for path in LEAF.rglob("*"):
    assert not path.is_symlink() and not (getattr(path.lstat(), "st_file_attributes", 0) & 0x400)
    if path.is_file():
        assert path.stat().st_size < 50 * 1024 ** 2
        paths[path.relative_to(LEAF).as_posix()] = path
assert set(paths) == set(covered) | {"SHA256SUMS.txt", "SEAL-RESULT.json"}
assert len(paths) == len({name.casefold() for name in paths})
assert not DEST.exists()
with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(paths.items()):
        archive.write(path, name)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(paths)
    for name, path in paths.items():
        assert archive.read(name) == path.read_bytes()
    expanded = sum(info.file_size for info in archive.infolist())
record = {"started_utc": start, "ended_utc": datetime.now(timezone.utc).isoformat(),
          "archive": str(DEST), "archive_bytes": DEST.stat().st_size,
          "archive_sha256": digest(DEST.read_bytes()), "expanded_bytes": expanded,
          "entries": len(paths), "manifest_covered_entries": len(covered),
          "manifest_sha256": MANIFEST, "postseal_noncovered_files": ["SEAL-RESULT.json"],
          "report_sha256": covered["REPORT.md"], "proposal_sha256": covered["PROPOSED-DRIVER-02.md"],
          "crc_and_all_payloads_verified": True, "executable_or_runtime_approval": False}
target = OUT / "PACKAGING-03.json"
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
