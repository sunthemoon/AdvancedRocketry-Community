# Passive observation source correction 08

Date: 2026-10-09 UTC. You are the already assigned delegated source worker,
not Root. No further delegation or Claude; Root owns OpenPet.

This supplements SLEEP-OBSERVATION-SOURCE-TASK-05.md, whose identity, isolated
branch/worktree, two-file write_scope, actor/case inventory, source-only command
permissions and non-goals remain unchanged. The first fixed candidates are
e72b41dea67404b5abba48bb499a1b4d5d743389 and
0c05cc27112f5f4a71faa66bc16b5f7f4390f345. Their commits, actual compilation
receipts and normal publication are preserved, not amended or relabeled.

## Actual source finding and correction boundary

Root read the complete two-file source at 0c05cc27. SleepBoundaryTrace.append
first adds the candidate JsonObject, then bytes() creates the complete JSON
String and UTF-8 array before testing the cap. Frame strings and native chat
serialization are likewise materialized before size rejection. The author
confirmed this limits accepted output, not pre-allocation trace memory. The
measurement fields cover a prefix rather than the complete serialized capture.

Correct bounded size accounting and serialization within the same two files.
Retain the frozen 64 frames plus one sentinel, 32/128 events, 128 KiB per case,
512 KiB per invocation and 512 identity tokens. Oversized/unavailable metadata,
chat or capture must leave explicit incomplete evidence rather than a valid
truncated observation. No native cancellation, sleep/spawn/time/air policy or
check substitution is authorized. Do not resolve the finding by weakening caps
or claiming a merely post-allocation check is pre-allocation protection.

Time/allocation field names and recorded scope must describe what is actually
measured. Public allocation remains read-only when already enabled, otherwise
unmeasured. Add boundary tests for the real accounting implementation where
feasible; compiling them is not execution. Keep each class below 500 lines, or
ask Root for a disjoint responsibility scope before adding another class.

Preserve the already mentioned uncommitted cleanup/preflight refinement as its
own diff/reason record. It may be included only within Task 05's existing native
identity, bounded preparation and independent cleanup requirements; do not
silently expand fixture/runtime scope.

## Execution and delivery

Commit only the authorized source, check staged stat and whitespace, then run
only the same exact compileAdapterTestJava --no-daemon --no-build-cache
--rerun-tasks after disk/JDK/own TEMP/TMP preflight. Record actual candidate SHA,
argv/cwd/UTC/exit/raw logs; fixes are new commits and normal pushes. Do not move
Main or any reviewer worktree's HEAD. No tests, build, DataGen, GameTest, driver,
server, client or world is authorized. Retain all original failures and limits.

Report actual corrections and remaining findings to Root. Independent reviewers
continue their own fixed-candidate review. Do not seal the current external leaf
before Root has received the complete source findings and assigned any final
additive review. No source integration, runtime permission, B1/R1/M1/M2/D1 or
Gate/item/ledger completion is granted here.
