"""Bounded read-only input inspection; no project writes or extraction."""
import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

REPO = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")


def git(argv):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(["git", *argv], cwd=REPO, capture_output=True, timeout=180)
    print(json.dumps({"argv": ["git", *argv], "cwd": str(REPO), "pre_utc": start,
                      "post_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      "exit_code": result.returncode, "stderr": result.stderr.decode("utf-8", "replace")}))
    result.check_returncode()
    return result.stdout


def read(source):
    if source.startswith("git:"):
        return git(["show", source[4:]])
    return pathlib.Path(source).read_bytes()


def identity(source, data):
    print(json.dumps({"input": source, "bytes": len(data),
                      "lines": len(data.splitlines()), "sha256": hashlib.sha256(data).hexdigest()}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["text", "identity", "names", "context", "zip"])
    parser.add_argument("sources", nargs="*")
    parser.add_argument("--first", type=int, default=1)
    parser.add_argument("--last", type=int, default=100000)
    args = parser.parse_args()
    if args.mode == "context":
        for argv in (["status", "--short"], ["branch", "--show-current"], ["rev-parse", "HEAD"],
                     ["worktree", "list", "--porcelain"]):
            print(git(argv).decode("utf-8", "replace"))
        return
    for source in args.sources:
        if args.mode == "names":
            for path in pathlib.Path(source).iterdir():
                if path.name.lower().startswith("sleep"):
                    print(path)
            continue
        data = read(source)
        identity(source, data)
        if args.mode == "text":
            for number, line in enumerate(data.decode("utf-8-sig", "strict").splitlines(), 1):
                if args.first <= number <= args.last:
                    print(f"{number:04d} {line}")
        elif args.mode == "zip":
            with zipfile.ZipFile(source) as archive:
                entries = archive.infolist()
                print(json.dumps({"members": len(entries), "compressed_member_bytes": sum(i.compress_size for i in entries),
                                  "expanded_member_bytes": sum(i.file_size for i in entries)}))
                for member in entries:
                    print(json.dumps({"member": member.filename, "bytes": member.file_size, "compressed": member.compress_size}))


if __name__ == "__main__":
    main()
