"""Compact read-only receipt index and input identity summary for Task35."""
import hashlib
import json
import pathlib
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = pathlib.Path(__file__).resolve().parent
records = []
identities = {}
for path in sorted(ROOT.glob("*.command.json")):
    record = json.loads(path.read_bytes())
    records.append({"receipt": path.name, **record})
for path in sorted(ROOT.glob("*.stdout.txt")):
    try:
        lines = path.read_text(encoding="utf-8", errors="strict").splitlines()
    except UnicodeDecodeError:
        continue
    for line in lines:
        if line.startswith('{"input":'):
            value = json.loads(line)
            identities[value["input"]] = value
for name, obj in (("COMMAND-INDEX.json", records), ("INPUT-IDENTITIES.json", identities)):
    path = ROOT / name
    if path.exists():
        raise SystemExit("Existing output: " + name)
    data = (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.write_bytes(data)
    print(json.dumps({"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}))
print(json.dumps({"indexed_commands": len(records), "unique_read_identities": len(identities),
                  "limitation": "index ends before its own invocation completes; later final/seal receipts are separate"}))
