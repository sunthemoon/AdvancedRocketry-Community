"""One-time evidence manifest only; no runtime/capture implementation."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).absolute().parent
EXCLUDED = {"SHA256SUMS.txt", "SEAL-RESULT.json"}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe(path):
    absolute = path.absolute()
    for component in (absolute, *absolute.parents):
        if component.is_symlink() or getattr(component.lstat(), "st_file_attributes", 0) & 0x400:
            raise ValueError("Reparse component: " + str(component))
    absolute.resolve().relative_to(ROOT)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(65536):
            value.update(block)
    return value.hexdigest()


def inventory():
    records = []
    names = set()
    for path in sorted(ROOT.rglob("*")):
        safe(path)
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError("Nonregular member: " + str(path))
        name = path.relative_to(ROOT).as_posix()
        if not re.fullmatch(r"[A-Za-z0-9_.\-/]+", name) or any(
                part in ("", ".", "..") for part in name.split("/")):
            raise ValueError("Unsafe member: " + name)
        if name.casefold() in names:
            raise ValueError("Case collision: " + name)
        names.add(name.casefold())
        size = path.stat().st_size
        if size >= 50000000:
            raise ValueError("Oversize member: " + name)
        records.append({"path": name, "bytes": size, "sha256": digest(path)})
    if sum(row["bytes"] for row in records) >= 100000000:
        raise ValueError("Oversize leaf")
    return records


if "--inner" not in sys.argv[1:]:
    if any((ROOT / name).exists() for name in EXCLUDED):
        raise SystemExit("Seal/result already exists; no overwrite permitted")
    command = [sys.executable, "-B", str(pathlib.Path(__file__).resolve()), "--inner"]
    pre = now()
    completed = subprocess.run(command, cwd=os.getcwd(), capture_output=True,
                               timeout=180, check=False)
    post = now()
    if completed.returncode != 0:
        sys.stdout.buffer.write(completed.stdout)
        sys.stderr.buffer.write(completed.stderr)
        raise SystemExit(completed.returncode)
    receipt = json.loads(completed.stdout.decode("utf-8", errors="strict"))
    receipt["actual_command_receipt"] = {
        "argv": command, "cwd": os.getcwd(), "pre_utc": pre, "post_utc": post,
        "timeout_seconds": 180, "exit_code": completed.returncode,
        "capture": "Complete actual inner static seal command stdout/stderr bytes embedded below; no separate post-seal receipt files",
        "stdout": {"bytes": len(completed.stdout),
                   "sha256": hashlib.sha256(completed.stdout).hexdigest(),
                   "raw_utf8": completed.stdout.decode("utf-8", errors="strict")},
        "stderr": {"bytes": len(completed.stderr),
                   "sha256": hashlib.sha256(completed.stderr).hexdigest(),
                   "raw_utf8": completed.stderr.decode("utf-8", errors="strict")}
    }
    data = (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    final_rows = inventory()
    actual_manifest = (ROOT / "SHA256SUMS.txt").read_bytes()
    final_covered = [row for row in final_rows if row["path"] not in EXCLUDED]
    regenerated = ("".join(row["sha256"] + "  " + row["path"] + "\n"
                           for row in final_covered)).encode("ascii")
    if regenerated != actual_manifest:
        raise SystemExit("Covered payload changed before excluded result creation")
    if sum(row["bytes"] for row in final_rows) + len(data) >= 100000000:
        raise SystemExit("Excluded result would exceed evidence leaf hygiene limit")
    with (ROOT / "SEAL-RESULT.json").open("xb") as stream:
        stream.write(data)
    print(json.dumps({"manifest": receipt["manifest"],
                      "covered_files": receipt["covered_files"],
                      "covered_bytes": receipt["covered_bytes"],
                      "excluded_regular_payloads": sorted(EXCLUDED),
                      "result_bytes": len(data),
                      "result_sha256": hashlib.sha256(data).hexdigest(),
                      "actual_inner_exit_code": completed.returncode,
                      "report_sha256": receipt["report_sha256"]}))
    raise SystemExit(completed.returncode)

start = now()
safe(ROOT)
if any((ROOT / name).exists() for name in EXCLUDED):
    raise SystemExit("Seal/result already exists; no overwrite permitted")
ack = json.loads((ROOT / "ROOT-READ-ACK.json").read_bytes())
report = ROOT / "REPORT.md"
if not ack.get("exact_hash_full_read_acknowledgment") or ack["report_sha256"] != digest(report):
    raise SystemExit("Exact-hash full-read acknowledgment does not match report")
before = inventory()
manifest = ("".join(row["sha256"] + "  " + row["path"] + "\n" for row in before)).encode("ascii")
with (ROOT / "SHA256SUMS.txt").open("xb") as stream:
    stream.write(manifest)
after = inventory()
covered = [row for row in after if row["path"] not in EXCLUDED]
if covered != before:
    raise SystemExit("Covered payload changed during seal verification")
result = {
    "argv": sys.argv, "cwd": os.getcwd(), "pre_utc": start, "post_utc": now(),
    "scope": "One-time evidence-only manifest; no adoption/freeze/launch/Gate authority",
    "manifest": {"path": str(ROOT / "SHA256SUMS.txt"), "bytes": len(manifest),
                 "sha256": hashlib.sha256(manifest).hexdigest()},
    "covered_files": len(covered), "covered_bytes": sum(row["bytes"] for row in covered),
    "coverage": "All regular leaf payloads except manifest self and sole later SEAL-RESULT.json",
    "covered_rehash_verified": True, "safe_names_case_unique_no_reparse": True,
    "excluded_regular_payloads_after_result": sorted(EXCLUDED),
    "report_sha256": digest(report), "root_ack_sha256": digest(ROOT / "ROOT-READ-ACK.json"),
    "limits": "Sampled evidence leaf verification only; excluded result is created separately after actual command result"
}
print(json.dumps(result, ensure_ascii=False, indent=2))
