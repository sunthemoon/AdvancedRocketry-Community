# Task35 independent narrowed native-log contract review

## 1. Findings first

**No new material correction was identified in this narrowed, explicitly static
candidate.** This is a review of requirements and evidence, not a qualified
capture implementation, contract adoption, executable freeze or launch approval.

1. **Prior Medium R01 is addressed at the normative refusal-contract level only.**
   [Task26 report](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/REPORT.md), lines 10-43, permitted either bounded compressed-log support or an explicit narrowed refusal. [Proposal34](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34/PROPOSED-NATIVE-LOG-04.md), lines 9-17, 95-107 and 113-149, selects refusal for every compressed successor, rollover/replacement, lost segment or unresolved identity/order. It does not scan gzip containers as plaintext or let a retained prefix restore completeness. The pinned logger XML and gzip bytecode independently support the need for that distinction. Actual refusal detection, identity continuity and bounded retention are still unimplemented/unqualified; this report does not close R01 as an executed runtime result.
2. **Prior Low R02 wording is corrected without changing the parser envelope.**
   Proposal34, lines 245-248, identifies 1366 as a loose source-derived analytical identifier bound, not a demonstrated attainable output or the existing 2049 parser envelope. Fixed `SleepBoundaryChatBounds.java`, lines 34-44, jointly charges namespace and path at six times their lengths within 8192, plus other text; the colon adds one. The calculation `floor(8192/6)+1 = 1366` is coherent as an upper bound. No parser/input limit was raised or test weakened.
3. **Blocking, already-declared admission obligation: the conservative inventory does not fit.**
   Proposal34, lines 199-230, accurately distinguishes its sampled 26-ZIP basis from live admission and compressed storage from expanded review volume. Independent CRC/hash reads reproduce 11,059,335 compressed and 60,277,949 expanded bytes. Adding the unchanged 65,011,712-byte future reserve to expanded volume gives 125,289,661, already above both 100,000,000 and 100 MiB. Later observed archives increase it further. This is not a newly concealed defect: [author report34](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34/REPORT.md), lines 17-23, expressly refuses admission. Neither the smaller compressed subtotal nor any unassigned helper authorizes a run.
4. **Residual qualification limits remain explicit, not capabilities established by this review.**
   Proposal34, lines 153-166, 187-195 and 250-262, and report34, lines 31-36 and 254-258, leave actual encoder/Unicode, identity/race/EOF/flush/readback, compact-index/I/O, refusal tests, reservation/resource enforcement and complete pre-run inventory open. The <=4 GiB OS-enforced allocation/helper authority remains unassigned. Task28's collector omits `.gz`; retained plaintext cannot prove original rotation completeness. No evidence reviewed here removes the prior strict timeout, log, failure-retention or platform-authority issues.

**Scoped readiness:** the narrowed requirements are coherent enough for Root's
explicit disposition of this refusal candidate. Implementation, full executable
freeze, adoption, synthetic qualification, native execution and inventory admission
remain separate unsatisfied obligations. No production defect or executed rotation
outcome was observed by Task35.

## 2. Identity, authority and read scope

Reviewer identity: fresh delegated independent reviewer `/root/sleep_native_log_contract_review`,
not Root, author or implementer. No delegation, Claude or OpenPet was used. Root
coordinates desktop-pet status. No owner authority is inferred from agent messages.

[Task35](D:/GitHub/ARCE-Task-Evidence/v1.8.0/SLEEP-NATIVE-LOG-CONTRACT-INDEPENDENT-REVIEW-TASK-35.md)
was completely read: 58 lines, 3935 bytes, SHA256
`8efd6163e7be0e9c57db7f921c02ff83d710a719bad02e712a1a81d155d6a234`.
All reviewer writes stay in
[this external leaf](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35).
Repository, worktrees, inputs, sealed leaves, archives, incidents and runtime paths
were read-only. No HEAD/index/worktree operation, process signal or cleanup occurred.

Fixed review governance is `55cf9bd802be2614fc27d56479684f58caceda60`.
Fixed opt-in source is `d57ecda1f11dab76d882f945b0de606534ef4fb9`;
its `src` tree is `85f53265bf4ee59b65c4a88664cb2e5e208c583e`.
Author34 actually used governance `ce64a8eb79c0f6fb53f000f0c2a0e4e947ef9985`;
the later review checkpoint is not retroactively substituted for that history.
Task20's historical source `5b45132000ade1e3c8d130a6b8ccb29f07535124` is likewise
not rebound to d57.

Mandatory project/product, porting/roadmap, version, master test/Gate, parallel,
post-1.0/quality, current status, ADR-060, checkpoints32/33 and owner-decision documents
were completely read from fixed55cf Git objects. Their exact paths, line counts,
byte counts and SHA256 values are preserved in
[INPUT-IDENTITIES.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/INPUT-IDENTITIES.json),
11751 bytes, SHA256 `32f212db191a52718cbe38359d0c71f4d5d27bd0c76058de79f526c305e887a0`.
This includes the complete v1.0.0 and v1.8.0 version documents, not merely current
status summaries. Earliest incomplete acceptance is v1.0.0; scoped v1.8.0 development
does not release it or bypass ADR-060/Gates.

Fixed owner records preserve the decisions “真正睡眠（推荐）：另行冻结并审核维度、出生点和时间行为后实施。”
and “接受原生维度行为，按上述范围冻结并审核。” The later added lines in fixed55cf
OWNER-DECISION-03.md are not attributed to the author's older file identity.
Checkpoint33 freezes D1 outcomes only: all 13 D1 rows are unexecuted and B1/R1/M1/M2
implementation/runtime proof remains open. No driver, production, helper or launch
authority follows. Fixed status remains 186 PLANNED /154 REVIEW; no delivery or
version status was changed by this review.

## 3. Completely read contract/evidence inputs and custody

The following texts were completely read and their raw bytes independently hashed.
Line counts refer to decoded split lines; identities refer to entire original bytes.

| Input | Lines | Bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Proposal34](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34/PROPOSED-NATIVE-LOG-04.md) | 262 | 16791 | `dca05c9708e65c163b31bf331bcd9e7bec550089ec5ac1d96500e80c19489ed3` |
| [Report34](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-compressed-log-contract-revision-20261009-34/REPORT.md) | 270 | 18314 | `7561ac38212b0d003f2698244d567cf4746f8d870ce87176542b9ae2f5558ac5` |
| [Proposal20](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-20261009-20/PROPOSED-DRIVER-03.md) | 991 | 68873 | `c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680` |
| [Report20](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-20261009-20/REPORT.md) | 245 | 17261 | `06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6` |
| [Independent report26](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-driver-revision-independent-20261009-26/REPORT.md) | 332 | 24412 | `e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc` |
| [Sealed report28](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-nested-source-qualification-20261009-28/REPORT.md) | 347 | 24085 | `52f3897671a060020f11ff46b5dcb61d20576b46e48cba66bc387362ff311e02` |
| [Fixed checkpoint32](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep/NESTED-QUALIFICATION-32.md), Git55cf | 166 | 11016 | `3502871b6c9aed1672f9226f940e260a86583eafb75d3f96d66b694cca4035ec` |
| [Fixed checkpoint33](D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-sleep/D1-OUTCOME-FREEZE-33.md), Git55cf | 109 | 7441 | `f18dd47d3bd452b17c58c74aaa57b5cc573037c681ba6491bc1bfd7de89749e6` |

Actual Task34 seal was available during this review, not fabricated from assignment.
[manifests01.stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/manifests01.stdout.txt)
records independent hash/path/reparse/case-safety verification of all declared
covered payloads in four actual sealed leaves, and actual uncovered regular files.

| Leaf | Covered files / bytes | Manifest bytes / SHA256 | Actual exclusions |
| --- | --- | --- | --- |
| Task34 | 44 /890872 | 4013 /`531ae2fb8fe0619d52c83745fbccfd80594cd8cfdfb42f8dff61f2591b20d88c` | manifest self; `SEAL-RESULT.json` |
| Task20 | 198 /1089641 | 20689 /`b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0` | manifest self; `SEAL-RESULT.json` |
| Task26 | 149 /1890251 | 14376 /`9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d` | manifest self; `SEAL-RESULT.json` |
| Task28 | 909 /14278320 | 169478 /`d063e2b87fae9fb0856d4141e8c1d27e15ae540f797adf15e384bc9875efa913` | nine files listed below |

Task28 exclusions are exactly `SHA256SUMS.txt`, `SEAL-RESULT.json`,
`SEAL-VERIFY-RESULT.json`, `seal-01.command.json`, `seal-01.stdout.txt`,
`seal-01.stderr.txt`, `seal-verify-01.command.json`, `seal-verify-01.stdout.txt`
and `seal-verify-01.stderr.txt`. Its scratch directory is empty. These exclusions
are disclosed, not described as manifest-covered evidence.

Task34 ROOT-READ-ACK.json was completely read: 9 lines/1033 bytes/SHA256
`861927317bb59db2e3f32e390f399820d6763611c27ad89ab98bb07987564f5f`.
It contains Root's actual exact-report/proposal full-read acknowledgment and
evidence-only seal permission, with no supplied message timestamp. This is custody,
not independent review/adoption. Task34 SEAL-COVERAGE.md is 17 lines/1062 bytes,
SHA256 `644556249cc9bbb8f87ffed3cbafd22f11541e68d551223b3d8756412e66faec`;
SEAL-RESULT.json is 76 lines/12283 bytes,
SHA256 `bfd37612710254328462c396100ac271e8d27edf6ccf217494a8eff4371a9867`.
Input identities were unchanged from assignment. No sealed input was edited.

The predecessor's external 37-byte incident remains external/retained, not absorbed
into its seal, deleted, normalized or waived. Historical peer/Root retained-output
and preparation-failure limits remain as recorded; this review did not reacquire
or claim a new complete audit of all such external payloads.

## 4. Fixed-source comparison and separated domains

These entire source files were hashed from d57; the listed relevant ranges were
read, not represented as a fresh exhaustive source review. No source export was
retained. Base directory is
[adapterTest](D:/GitHub/AdvancedRocketry-Community/src/adapterTest/java/io/github/sunthemoon/arceadaptertest).

| File | Lines /bytes | SHA256 | Inspected ranges |
| --- | --- | --- | --- |
| SleepBoundaryTrace.java | 445 /27593 | `20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f` | 25-115, 215-350 |
| SleepBoundaryChatBounds.java | 238 /15889 | `16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0` | 25-110 |
| SleepBoundaryObservationFixture.java | 497 /33987 | `1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820` | 65-155, 315-350 |

Trace lines 35-40 establish the existing 64-frame/32-case-event/128-total-event,
128 KiB-case/512 KiB-total/512-ID and JSON serialization policies. Chat preflight
and actual JSON byte checks at lines 235-241 remain producer constraints; they are
not a maximum native diagnostic-line size. Spawn getters at 312-315 are native
fields, not NBT. Error projection at 338-348 keeps bounded causes/root classification.
ChatBounds' exact nested receiver checks at 75-94 remain distinct from arbitrary
logger text. Fixture lines 77-90 retain opt-in and console guards; lines 105/122
emit setup/raw observations, and lines 325-342 restore/remove native state.

Proposal34 lines 42-47 and 168-185 preserve this separation: native log diagnostics
cover admitted full logs and the merged pipe, including WARN/ERROR/FATAL and their
continuations, not just bounded producer JSON. Log markers are diagnostic text,
not an independent response source. Cross-view correlation must not destructively
deduplicate physical byte accounting or treat repeated occurrences as incident
counts. Existing row19 remains unwaived. Playerdata bounded gzip policies in
Proposal20 lines 779-802 do not apply to arbitrary Log4j rotations. A merged pipe
cursor orders the captured bytes but does not authenticate each byte as stdout.

## 5. Independently pinned logger primaries

Installed primary root is
[server libraries](D:/GitHub/AdvancedRocketry-Community/.gradle/v120-jei-session/server/libraries).
Entire containers were streamed/rehashed. Only bounded unique primary entries were
CRC-read; no library was extracted or copied. XML was completely read, bytecode
was inspected statically with bounded `javap -p -c` commands.

| Primary | Bytes | SHA256 |
| --- | ---: | --- |
| `net/minecraftforge/fmlloader/1.20.1-47.4.10/fmlloader-1.20.1-47.4.10.jar` | 267079 | `12d27a5d59286ab5fa8cc90cb2c73eb21f4624b765ce2e6408d5e397a6a6699b` |
| its unique `log4j2.xml` | 5541 | `b51029523df8874beca56c09ce4310bdae7f0885dc1412f8830f62f04c19db83` |
| `org/apache/logging/log4j/log4j-core/2.19.0/log4j-core-2.19.0.jar` | 1864386 | `b4a1796fab7bfc36df015c1b4052459147997e8d215a7199d71d05f9e747e4f4` |
| its `FileExtension$2.class` | 1334 | `9dd410147ffdc917342c38872e5b029f229c73986b82757f1196562fae19e306` |
| its `GzCompressAction.class` | 4806 | `2fe109c2bcc963b3d66d5f8096b59798f4c4761df8582d79f7b8c68b75925697` |
| its `GzCompressAction$ConfigurableLevelGZIPOutputStream.class` | 945 | `71246b5f9de076f6c22e1b62e7eabb59389605243148cfc440397e61ee5e4247` |
| [installed javap.exe](C:/Program%20Files/Java/jdk-17.0.7/bin/javap.exe) | 23696 | `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d` |

XML lines 40-46 configure latest.log to dated indexed `.log.gz` with time/startup
triggers and max99/min indexing. Lines 48-54 configure debug.log to indexed
`.log.gz`, startup/200MB triggers and max5/min indexing. Patterns at 41/49 include
newline/exception text; XML's UTF-8 declaration at line1 is not proof of the actual
PatternLayout output encoder. No setting was changed.

The gzip action read loop, stream close paths and conditional source deletion are
visible in the static bytecode; FileExtension$2 constructs that action. This
establishes possible source loss/compressed successors, not observed native
rotation timing, installed encoder behavior, file identities or durable output.
[gzipjavap01.stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/gzipjavap01.stdout.txt)
is 16312 bytes/SHA256 `fcfb1b1384d01284d219f05bb62ce04e13bee5704dc5d52958079e6377aca401`;
[extensionjavap01.stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/extensionjavap01.stdout.txt)
is 1445 bytes/SHA256 `5a83ef3931accb0a79c77efe69c696b3995fd4818e32beb4a91e996d63c775d3`.
No inspected logger or Minecraft method was invoked by this inspection.

## 6. Native28 evidence versus proposed capabilities

The actual Task28 capture/collector texts were completely read. Actual collection,
command, copied logs and raw stream identities were independently rehashed under
[native01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/native01.stdout.txt)
and [collection01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/collection01.stdout.txt).
These are input audits, not reruns or copied full log payloads.

| Task28 payload | Bytes | SHA256 |
| --- | ---: | --- |
| native-01-COLLECTION.json | 57129 | `9cfa2adbaf0979ebb3b5f726b7fd19a558c410002c280a6ab87195b342905611` |
| native-01.command.json | 12660 | `33a1cfb34bafec25c17bda3b97f6286e902675efe9b8a3cb965b270a27231079` |
| capture.py, 108 lines | 6666 | `068459b036ecb1182f0699defa555d7ff1306e06f69b275393e3d572e78ec5cf` |
| collect.py, 73 lines | 4456 | `523df8632287d51d3b330214e3300e5e3082140a27939631433e90e56c995b83` |
| native-01.stdout.txt | 1706344 | `5933817e1037def591daaefe29d78301dddb601f85579c80f18f9a9e60c6c857` |
| native-01.stderr.txt | 14116 | `7be65bf31a95fcd021de94be7e620c16cf93578d0da5a46f29cd3ac4f6116a8a` |
| native-01-results/build/gametest/logs/latest.log, 5922 lines | 1854127 | `651666bc388890faf9191006459cda6beafaf1abaae5bbf708e271a8b1a85479` |
| native-01-results/build/gametest/logs/debug.log, 7056 lines | 2030639 | `392af1ddd7682ff144658d4e97cc71028ed78499b0a1f4b6800d9338b6bc4810` |

The command receipt binds its capture helper hash and actual command
`cmd.exe /d /c gradlew.bat runGameTestServer --no-daemon --no-build-cache --rerun-tasks`:
2026-10-09T07:25:53.994666Z to 07:30:06.547652Z, 252.553 seconds, exit0,
2400-second capture timeout, fixed d57 and no opt-in. This is standard Gradle
development qualification, not the future packaged driver or merged-pipe capture.
The reported 2192 JUnit/381 XML and 594 required GameTests/151 batches remain input
evidence, not Task35 test results. Strict 180-second timeout remains open.

Copied log sizes/hashes match their actual collection records. Independent strict
UTF-8 parsing reproduces 62 ERROR/zero FATAL headers in each, with final LF. Those
are two views' occurrences, not 124 independent incidents or proof of clean logs.
Collector lines 42-51 select `.log`/`.xml` and use replacement decoding for their
inventory. The later strict audit supports only these retained plaintext samples.
Zero retained `.gz` cannot prove there was no original rotation, nor durable flush,
complete family order, original EOF or future collector support.

## 7. Identity, refusal, raw-byte and budget assessment

Proposal34 lines 73-93 require fresh owned directories, no reparse objects, bounded
enumeration, exact stable generation/identity and at most 32 segment identities
including compressed members. Lines 95-107 forbid filename/mtime guesses as order
proof and require immediate UNSUPPORTED plus INCOMPLETE/UNKNOWN on unsupported
arrival, blocking a second invocation. Only the already-permitted failure/save/stop
sequence may proceed; no new kill, cleanup, retry or runtime permission follows.

Lines 113-149 distinguish stored physical bytes `S`, logical plaintext offsets `P`,
compressed stored subset `C` and unknown expanded `E_gzip`. Retained acknowledgment
copies are charged physically; aliases cannot erase physical obligations. Gzip
expanded length is UNKNOWN, never inferred as zero or container size. Admission
requires complete plain coverage and the 16 MiB limit; refusal retains only actual
bounded extents within 17 MiB, with offsets/hash/state and unknown EOF where necessary.
The contract supplies no decompression sink, expanded-log category or unbounded spool.

Lines 153-166 preserve raw bytes unchanged and require actual logger-charset
qualification before strict incremental UTF-8 use. No replacement, ANSI stripping,
synthetic line joining or oversized-structure truncation can manufacture a clean
diagnostic result. Lines 187-195 separate process completion, reader completion,
family EOF/identity/hash/size and readback/flush proof. Exit/current EOF alone does
not establish durability. An earlier failure survives later save/stop outcomes.
These are appropriate requirements, not implemented receipts or proven Windows
identity/flush semantics. Unsupported compressed input may yield a diagnostic
prefix, but cannot yield complete/clean capture.

Unchanged Proposal20/34 budgets remain three 16 MiB admission/17 MiB hard families,
32 identities per native family, 64 KiB reads/four-chunk queue, 512 KiB+4096 candidate
buffer, 1 GiB pipe-read limit, 256 MiB parser RSS target, 10 MiB compact and 1 MiB emergency,
62 MiB=65,011,712 retained reserve. Individual compact receipts retain 64 KiB caps;
indices/projections share the existing 1 MiB aggregate. Native waits 300/60/60/90 sum 630;
success/failure global ceilings 1115/1145 remain. Monitoring/copy/inspection/refusal
consume those phases, not an additional final/rotation wait. Polling is not proof
of the separately proposed <=4 GiB OS-enforced runtime allocation. No cap, logger,
phase, failure disposition or platform-authority boundary was relaxed.

## 8. Actual sampled cumulative accounting

Author34's sealed `receipt28-inventory-crc.json` is 17600 bytes/SHA256
`ab750b299ffc5b9f93f1a7a5278242c488cc3841ebc7de2ddf16e93affdd6a4d`.
Its actual sample runs 08:10:56.081378Z-08:10:56.627933Z on 2026-10-09, non-atomic.
Independent arithmetic reproduces 26 ZIPs: 11,059,335 compressed /60,277,949 expanded;
plus unchanged reserve: 76,071,047 compressed-based /125,289,661 expanded-based.
The recorded 108,640 loose-repository and 62,126,103 external-physical byte sums were
checked as receipt arithmetic, not recreated historical filesystem truth or a
complete alias map. They are not subtracted, blindly deduplicated or relabeled.

Fixed checkpoint33 lines 104-108 records the later 27-ZIP basis with Root32 archive:
11,214,293 compressed /60,789,137 expanded; expanded+reserve 125,800,849.
Task35 [inventoryactual01](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/inventoryactual01.stdout.txt)
independently sampled actual 29 ZIPs at 08:35:31.297686Z-08:35:31.600609Z, full CRC/hash
reads without extraction. All 26 author-sampled archives still match exact identities,
entry counts and expanded totals. Bounds were 64 archives/4096 entries and 100 MiB
expanded per archive; unsafe members fail the inspection.

Later-than-author inputs were `OBSERVATION-ROOT-INTEGRATION-32.zip`
(154958 compressed/511188 expanded/145 entries, SHA256
`d42fef90e2bf0dc30d446f88e1ad2e95b8046e9c6f47d49a04b3b1465b618de6`),
`D1-ROOT-OUTCOME-33.zip` (44305/131954/52,
`ddb08915b590236c548f867462f4a926ee3cf1bf20f6646f2c91d3c23936604f`)
and `NATIVE-LOG-REVISION-34.zip` (340714/907168/46,
`a394890b605308546e98099843ed8a6dbb1b230cb1a5fdfc5e8efaa026f42745`).
The actual 29 subtotal is 11,599,312 compressed /61,828,259 expanded; with reserve,
76,611,024 /126,839,971. This later sampled state is not attributed to author34,
nor asserted to be the final atomic distinct-set inventory at a future launch.
Expanded review volume is not compressed physical storage, reserve is not actual
allocation, and evidence leaf hygiene is not cumulative native-run admission.
No deletion, category change, relabeling, waiver or budget increase was authorized.

## 9. Actual commands, errors and capture limitations

[COMMAND-INDEX.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-native-log-contract-independent-20261009-35/COMMAND-INDEX.json)
contains 44 actual command receipts, 52925 bytes/SHA256
`502c72be7c02e314b2e7f33e0d645827ac1cad0b56bf6cecbeb3a7ad72a4f9f2`.
Each records actual argv/cwd/pre/post UTC/exit, complete captured subprocess raw
stdout/stderr paths/bytes/hashes and errors, with 180-second limits. `index01`,
`handoff01`, `conclusioninputs01`, `scopefinal01` and final-report/seal checks occur
after that index and have separately identified receipts/results. All audited
commands completed without timeout. No sustained native command or process signal
was executed. Read-only Git status/branch/worktree observations protect other work.

Successful checks include complete input/fixed-governance reads/hashes; safe actual
manifest verification; installed JAR/XML/class CRC/hash checks; bounded javap;
Task28 helper/command/collection/log/raw identity checks and strict copied-log audit;
historical/current ZIP arithmetic/CRC/hash checks; selected d57 source comparisons.
These success statements describe only the named static checks, not runtime Gates.

Errors are retained, not normalized into successful commands:
- `bootstrap` mistakenly used ambient Windows PowerShell/quoting: Get-FileHash was unavailable and escaped `$_` became repeated invalid `\` commands. Outer exit 0 did not mean its hash/enumeration commands succeeded; stderr is 491944 bytes. Correct Python receipts supersede only those failed inspections, not the preserved errors.
- `governance01` display used ambient CP936, producing unreadable/lossy Chinese presentation. Original Git bytes were hashed, but no separate original child stdout export was retained. `governance02` repeated the complete reads with UTF-8 presentation.
- `governance03` guessed nonexistent lowercase `docs/versions/v1.8.0.md`: child Git exit 128/helper exit 1, aborting the rest of that batch. `versionnames01` and later actual uppercase version reads supply the missing inspections.
- `inventorykeys01` lost quoted Python path arguments under PowerShell native argument handling: SyntaxError/exit 1. Separately named helper-based `inventorykeys02/03` succeeded.

Tool displays of broad preflight and combined report/proposal reads were truncated.
Stored subprocess streams remain complete, but a stored complete stream is not
itself proof it was read. Required report/proposal displays were consumed through
focused replays (`report3402/03`, `proposal2002` and contiguous proposal2003-05),
so the required complete text reads do not depend on hidden truncated portions.
Initial task/preflight calls before the wrapper and a few direct read-only helper
displays have only actual tool transcript results, not reconstructed OS UTC/raw
receipts. Manual apply_patch transports likewise were not separately instrumented.
No missing historical capture was fabricated. Binary `javap.exe` line count in the
generic identity index is incidental, not a text-read assertion. Selected metadata
fields and source excerpts are expressly bounded; full logs/libraries/source were
not exported. Reviewer helpers evolved before sealing; old receipts were retained.

Root independently changed record-only central files during this task. The fixed
review inputs were not replaced by live HEAD. Observed user AGENTS.md and unrelated
untracked files were left untouched; no reviewer staging/commit/push occurred.

## 10. Completion, unfinished work, files/tests and Gates

Completed scope: independent static requirements/predecessor/source/primary/custody
and accounting review, with read-only evidence rechecks and this external report.
Key design judgment: explicit all-rotation refusal preserves the unchanged bounds
without pretending compressed containers are complete diagnostic text; normative
coherence is distinct from qualified helper behavior.

Unfinished scope: Root disposition/adoption; whole-driver executable freeze;
implementation; synthetic refusal/identity/race/Unicode/diagnostic/I/O/resource and
EOF/durability tests; platform helper/allocation authority; fresh complete inventory
and successful admission; native driver execution, production implementation and
acceptance. Prior failure/retention/log/strict-timeout issues remain open.

Modified files: only new reviewer-leaf helpers (`audit.py`, `inspect.py`, `verify.py`,
`prepare.py`, `seal.py`), command/raw receipts, compact input/command indices,
this REPORT.md and prospective SEAL-COVERAGE.md. Actual Root acknowledgment and
one-time seal/result may be added only after exact-hash complete-read acknowledgment.
No repository, author, peer, native log, archive, library, world or incident changed.
No test or production source was added or modified.

Tests/required commands NOT EXECUTED BY TASK35: clean build/test, runData, generated
diff qualification, runGameTestServer, synthetic parser/refusal/capture tests,
native server/driver, restart/persistence, client/real-GPU V1 or multiplayer V2.
They are not PASS or NOT_APPLICABLE. Task28 input results do not satisfy them for
this new proposed runtime. No G0-G9 Required Gate or v1.8.0/earliest-v1.0 acceptance
is newly satisfied; all Required Gates are not met. No tag/release/delivery mark.

Evidence is the external leaf and its named receipts, exact input identities,
actual manifests and independently observed primary hashes. This report is sent
complete and unsealed to Root with exact path/lines/bytes/SHA256. A one-time seal is
permitted only after Root's exact-hash full-read acknowledgment; its coverage and
every exclusion must be reported separately. Sealing is evidence custody only.
The next recommendation is scoped Root disposition within the current v1.8.0
sleep slice, retaining every outstanding implementation/runtime/admission and
acceptance obligation rather than advancing to a later feature or launch.
