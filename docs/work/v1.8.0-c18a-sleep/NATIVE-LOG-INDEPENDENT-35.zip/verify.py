"""Independent static custody, primary and sampled-inventory checks."""
import hashlib
import json
import os
import pathlib
import re
import stat
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
BASE = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
REPO = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while block := stream.read(65536):
            h.update(block)
            size += len(block)
    return {"path": str(path), "bytes": size, "sha256": h.hexdigest()}


def emit(value):
    print(json.dumps(value, ensure_ascii=False))


def no_reparse(path):
    for part in (path, *path.parents):
        if part.exists():
            value = part.lstat()
            if part.is_symlink() or getattr(value, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise ValueError("reparse path: " + str(part))


def manifests():
    for name in ("sleep-compressed-log-contract-revision-20261009-34",
                 "sleep-observation-driver-revision-20261009-20",
                 "sleep-observation-driver-revision-independent-20261009-26",
                 "sleep-nested-source-qualification-20261009-28"):
        root = BASE / name
        no_reparse(root)
        manifest = root / "SHA256SUMS.txt"
        emit({"manifest": digest(manifest)})
        seen, total = set(), 0
        for line in manifest.read_text(encoding="utf-8-sig").splitlines():
            expected, relative = line.split("  ", 1)
            p = pathlib.PurePosixPath(relative)
            if p.is_absolute() or ".." in p.parts or "\\" in relative or ":" in relative:
                raise ValueError("unsafe member: " + relative)
            if relative.casefold() in seen or not re.fullmatch("[a-fA-F0-9]{64}", expected):
                raise ValueError("duplicate/invalid member: " + relative)
            seen.add(relative.casefold())
            path = root.joinpath(*p.parts)
            no_reparse(path)
            path.resolve().relative_to(root.resolve())
            if not path.is_file():
                raise ValueError("nonregular member: " + relative)
            actual = digest(path)
            if actual["sha256"] != expected.lower():
                raise ValueError("hash mismatch: " + relative)
            total += actual["bytes"]
        uncovered = []
        for path in root.rglob("*"):
            no_reparse(path)
            if path.is_file() and path.relative_to(root).as_posix().casefold() not in seen:
                uncovered.append(path.relative_to(root).as_posix())
        emit({"leaf": str(root), "covered_files": len(seen), "covered_bytes": total,
              "all_match": True, "actual_uncovered_regular": sorted(uncovered)})


def primaries():
    libraries = REPO / ".gradle/v120-jei-session/server/libraries"
    cases = [(libraries / "net/minecraftforge/fmlloader/1.20.1-47.4.10/fmlloader-1.20.1-47.4.10.jar", ["log4j2.xml"]),
             (libraries / "org/apache/logging/log4j/log4j-core/2.19.0/log4j-core-2.19.0.jar",
              ["org/apache/logging/log4j/core/appender/rolling/FileExtension$2.class",
               "org/apache/logging/log4j/core/appender/rolling/action/GzCompressAction.class",
               "org/apache/logging/log4j/core/appender/rolling/action/GzCompressAction$ConfigurableLevelGZIPOutputStream.class"])]
    for path, requested in cases:
        no_reparse(path)
        emit({"container": digest(path)})
        with zipfile.ZipFile(path) as archive:
            for wanted in requested:
                candidates = [i for i in archive.infolist() if i.filename == wanted]
                if len(candidates) != 1 or candidates[0].file_size > 65536:
                    raise ValueError("unsupported primary member: " + wanted)
                data = archive.read(candidates[0])
                emit({"member": wanted, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                      "crc": candidates[0].CRC, "crc_checked": True})
                if wanted.endswith(".xml"):
                    for number, line in enumerate(data.decode("utf-8").splitlines(), 1):
                        print(f"XML:{number:04d} {line}")


def native():
    root = BASE / "sleep-nested-source-qualification-20261009-28"
    paths = ["native-01-COLLECTION.json", "native-01.command.json", "capture.py", "collect.py",
             "native-01.stdout.txt", "native-01.stderr.txt",
             "native-01-results/build/gametest/logs/latest.log", "native-01-results/build/gametest/logs/debug.log"]
    for relative in paths:
        path = root / relative
        emit(digest(path))
        if relative.endswith(".log"):
            data = path.read_bytes()
            text = data.decode("utf-8", "strict")
            lines = text.splitlines()
            emit({"log": relative, "strict_utf8": True, "terminates_lf": data.endswith(b"\n"),
                  "line_count": len(lines), "ERROR_headers": sum(bool(re.match(r"^\[[^\n]*?/ERROR\]", s)) for s in lines),
                  "FATAL_headers": sum(bool(re.match(r"^\[[^\n]*?/FATAL\]", s)) for s in lines),
                  "first_line": lines[0], "last_line": lines[-1]})
    for relative in ("native-01.command.json", "native-01-COLLECTION.json"):
        obj = json.loads((root / relative).read_bytes())
        emit({"metadata": relative, "keys": list(obj)})
        for key, value in obj.items():
            if key not in ("pre", "post", "files", "jars", "junit", "source_files", "artifact_inventory", "artifacts", "copied"):
                rendering = json.dumps(value, ensure_ascii=False)
                if len(rendering) <= 18000:
                    emit({"field": key, "value": value})
                else:
                    emit({"field": key, "display": "OMITTED over 18000 characters; identity above"})


def inventory():
    receipt = BASE / "sleep-compressed-log-contract-revision-20261009-34/receipt-28-inventory-crc.json"
    emit(digest(receipt))
    original = json.loads(receipt.read_bytes())
    emit({"author_receipt_keys": list(original)})
    for key, value in original.items():
        if isinstance(value, dict):
            emit({"field": key, "keys": list(value)})
        elif isinstance(value, list):
            emit({"field": key, "length": len(value), "first": value[:1]})
        else:
            emit({"field": key, "value": value})
    result = json.loads(original["exec_result"]["output"])
    emit({"inner_keys": list(result)})
    for key, value in result.items():
        if isinstance(value, list):
            emit({"inner_field": key, "length": len(value), "first": value[:1]})
        elif isinstance(value, dict):
            emit({"inner_field": key, "keys": list(value)})
        else:
            emit({"inner_field": key, "value": value})


def native_collection():
    root = BASE / "sleep-nested-source-qualification-20261009-28"
    obj = json.loads((root / "native-01-COLLECTION.json").read_bytes())
    for entry in obj["copied"]:
        actual = digest(root / entry["evidence"])
        if (entry["bytes"], entry["sha256"]) != (actual["bytes"], actual["sha256"]):
            raise ValueError("collection mismatch")
        emit({"collection_entry": entry, "actual_match": True})
    for entry in obj["native_log_inventory"]:
        emit({"collection_log": {k: v for k, v in entry.items() if k != "headers"},
              "retained_headers": len(entry["headers"])})
    gz = list(root.rglob("*.gz"))
    emit({"retained_gz_count": len(gz), "limitation": "collector suffix selection does not prove original gz absence"})


def inventory_actual():
    import datetime
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt = BASE / "sleep-compressed-log-contract-revision-20261009-34/receipt-28-inventory-crc.json"
    historical = json.loads(json.loads(receipt.read_bytes())["exec_result"]["output"])
    expected = {pathlib.Path(e["path"]).name: e for e in historical["archives"]}
    root = REPO / "docs/work/v1.8.0-c18a-sleep"
    compressed = expanded = hist_compressed = hist_expanded = 0
    observed = set()
    for count, path in enumerate(root.glob("*.zip"), 1):
        if count > 64:
            raise ValueError("archive inventory over 64")
        no_reparse(path)
        entry = digest(path)
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            if len(infos) > 4096 or sum(i.file_size for i in infos) > 100 * 1024**2:
                raise ValueError("archive bound exceeded")
            seen = set()
            actual_expanded = 0
            for info in infos:
                p = pathlib.PurePosixPath(info.filename)
                if p.is_absolute() or ".." in p.parts or ":" in info.filename or "\\" in info.filename or len(info.filename) > 4096:
                    raise ValueError("unsafe archive name")
                if info.filename.casefold() in seen or info.flag_bits & 1:
                    raise ValueError("duplicate/encrypted archive member")
                seen.add(info.filename.casefold())
                n = 0
                with archive.open(info) as stream:
                    while data := stream.read(65536):
                        n += len(data)
                        if n > info.file_size:
                            raise ValueError("expanded count overflow")
                if n != info.file_size:
                    raise ValueError("expanded length mismatch")
                actual_expanded += n
        entry.update(entries=len(infos), expanded_bytes=actual_expanded, full_crc_read=True)
        compressed += entry["bytes"]
        expanded += actual_expanded
        observed.add(path.name)
        if path.name in expected:
            declared = expected[path.name]
            if any(entry[k] != declared[k] for k in ("bytes", "sha256", "entries", "expanded_bytes")):
                raise ValueError("historical archive identity differs: " + path.name)
            hist_compressed += entry["bytes"]
            hist_expanded += actual_expanded
            entry["author_sample_member"] = True
        else:
            entry["author_sample_member"] = False
        emit(entry)
    if not set(expected).issubset(observed):
        raise ValueError("historical archive absent")
    reserve = 62 * 1024**2
    emit({"sampling_start_utc": start, "sampling_end_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "atomic": False, "author26_compressed_verified": hist_compressed, "author26_expanded_verified": hist_expanded,
          "observed_archive_count": len(observed), "observed_compressed": compressed, "observed_expanded": expanded,
          "unchanged_future_reserve": reserve, "observed_compressed_plus_reserve": compressed + reserve,
          "observed_expanded_plus_reserve": expanded + reserve,
          "author_loose_record_bytes_sum": sum(e["bytes"] for e in historical["repository_nonarchive_files"]),
          "author_external_physical_bytes_sum": sum(e["bytes"] for e in historical["external_leaves"]),
          "limitation": "archive CRC/hash read is a sampled identity audit, not atomic live inventory or complete distinct-set admission"})


if __name__ == "__main__":
    {"manifests": manifests, "primaries": primaries, "native": native, "inventory": inventory,
     "native_collection": native_collection, "inventory_actual": inventory_actual}[sys.argv[1]]()
