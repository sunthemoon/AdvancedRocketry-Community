# Task35 prospective evidence-only seal coverage

The report remains unsealed until Root acknowledges a complete read of its exact
final SHA256. ROOT-READ-ACK.json is created only after the actual message arrives.

The one-time manifest covers every regular file in this exclusive external review
leaf except SHA256SUMS.txt itself and the sole later SEAL-RESULT.json. Covered
files require safe, case-unique leaf-relative names, contained resolution and no
reparse file or ancestor. Each file must be below 50,000,000 bytes and the complete
leaf below 100,000,000 bytes. These hygiene checks are not native-run admission.

No repository, peer leaf, input manifest, library, native log, ZIP, runtime,
incident or other external payload is a member of this review seal. Their observed
identities are review evidence, not custody transfer or permission to modify them.
The actual seal result is expressly excluded, not self-referenced. Sealing grants
no contract adoption, executable freeze, implementation, runtime or Gate authority.
