"""Read-only review command receipts; all writes stay beside this helper."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    label, cwd, *argv = sys.argv[1:]
    if not label.replace("-", "").replace("_", "").isalnum():
        raise SystemExit("invalid receipt label")
    prefix = ROOT / label
    if prefix.with_suffix(".command.json").exists():
        raise SystemExit("receipt exists; use a new label")
    receipt = {"argv": argv, "cwd": cwd, "pre_utc": now(), "timeout_seconds": 180,
               "capture": "complete subprocess stdout/stderr bytes; tool display may be bounded"}
    try:
        result = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=180, check=False)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
        receipt["error"] = None
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b"", error.stderr or b"", None
        receipt["error"] = "TIMEOUT; partial output only"
    except OSError as error:
        stdout, stderr, code = b"", str(error).encode("utf-8"), None
        receipt["error"] = repr(error)
    receipt.update(post_utc=now(), exit_code=code)
    for stream, data in (("stdout", stdout), ("stderr", stderr)):
        path = prefix.with_suffix("." + stream + ".txt")
        path.write_bytes(data)
        receipt[stream] = {"path": str(path), "bytes": len(data),
                           "sha256": hashlib.sha256(data).hexdigest()}
    prefix.with_suffix(".command.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, ensure_ascii=False))
    sys.stdout.flush()
    sys.stdout.buffer.write(stdout)
    sys.stderr.buffer.write(stderr)
    return 0 if code == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
