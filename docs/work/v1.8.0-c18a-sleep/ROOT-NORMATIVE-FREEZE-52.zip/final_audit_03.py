"""Audit exact committed Root52 scope and finite raw receipts."""
import hashlib
from pathlib import Path

original = Path(__file__).resolve().parent.parent / 'sleep-native-log-disposition-20261009-39/final_audit_03.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '67be47ed4742907d12ed07e25cedca59e11b93a884f99ab88588cd64907cabe3'
source = raw.decode('utf-8').replace('cd9b54a23b5bf92760b05655a427344d6b620984',
                                   'e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1')
source = source.replace('9edbcab9ba53f2aaf4861867a916fbe424972c07',
                        'b80fb950b3965956ff6a75f8f86b9aff32aa196d')
source = source.replace("'src', 'build.gradle'", "'src', 'scripts', 'build.gradle'")
source = source.replace("assert len(raw) == identity['bytes']", "assert len(raw) <= 262144\n        assert len(raw) == identity['bytes']")
scope = """
assert set(git('diff', '--name-only', 'b80fb950b3965956ff6a75f8f86b9aff32aa196d', head).decode().splitlines()) == {
 'docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
 'docs/work/v1.8.0-implementation-log.md',
 *('docs/work/v1.8.0-c18a-sleep/' + name for name in (
   'OFFLINE-CORE-INDEPENDENT-STATUS-45.md', 'OFFLINE-CORE-CONTRACT-FREEZE-52.md',
   'DIAGNOSTIC-CONVENTION-43.zip', 'PLATFORM-COUNTER-44.zip',
   'OFFLINE-CORE-ROOT-REVIEW-45.zip', 'OFFLINE-CONVENTION-INDEPENDENT-49.zip'))}
"""
source = source.replace('rows = []', scope + '\nrows = []')
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
