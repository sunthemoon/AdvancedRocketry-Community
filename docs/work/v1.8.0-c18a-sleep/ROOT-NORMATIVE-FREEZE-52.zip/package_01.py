"""Four declared actual custody schemas; pinned archive algorithm, no adoption."""
import base64
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
specs = json.loads((OUT / 'INPUT-SEALS-01.json').read_text(encoding='utf-8'))
assert [s['profile'] for s in specs] == [43, 44, 45, 49]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for spec in specs:
    leaf = OUT.parent / spec['leaf']
    raw = (leaf / 'SEAL-RESULT.json').read_bytes()
    assert sha(raw) == spec['seal_sha256']
    result = json.loads(raw)
    profile = spec['profile']
    if profile in (43, 49):
        assert result['exit_code'] == 0 and result['timed_out'] is False
        assert result['timeout_seconds'] == 180
        overflow = 'output_limit_exceeded' if profile == 43 else 'stream_limit_exceeded'
        assert result[overflow] is False
        for stream in ('stdout', 'stderr'):
            data = base64.b64decode(result[stream + '_base64'], validate=True)
            assert len(data) == result[stream + '_bytes'] <= 262144
            assert sha(data) == result[stream + '_sha256']
        verify = result['verification']
        assert json.loads(base64.b64decode(result['stdout_base64'])) == verify
        assert verify['manifest_sha256'] == spec['manifest_sha256']
        if profile == 43:
            assert verify['all_covered_match'] is True
            assert set(verify['excluded']) == set(spec['exclusions'])
            for document in verify['documents']:
                data = (leaf / document['path']).read_bytes()
                assert len(data) == document['bytes'] and sha(data) == document['sha256']
                assert len(data.splitlines()) == document['lines']
        else:
            assert verify['all_covered_hashes_match'] is True
            assert verify['report_sha256'] == spec['report_sha256']
            assert set(verify['exact_exclusions']) == set(spec['exclusions'])
    elif profile == 44:
        assert result['outcome'] == 'SEALED_CUSTODY_ONLY'
        assert result['manifest_sha256'] == spec['manifest_sha256']
        assert result['report_sha256'] == spec['report_sha256']
        assert set(result['exact_exclusions']) == set(spec['exclusions'])
        command = json.loads((leaf / 'custody-seal-28.command.json').read_bytes())
        assert command['exit_code'] == 0 and command['timeout'] is False
        assert command['ceiling_seconds'] == 180
        for stream in ('stdout', 'stderr'):
            data = (leaf / ('custody-seal-28.' + stream + '.txt')).read_bytes()
            meta = command[stream]
            assert meta['overflow'] is False
            assert len(data) == meta['raw_bytes'] == meta['retained_bytes'] <= 262144
            assert sha(data) == meta['raw_sha256'] == meta['retained_sha256']
    elif profile == 45:
        assert result['exit_code'] == 0 and result['gate_approval'] is False
        assert result['manifest_sha256'] == spec['manifest_sha256']
        assert result['report_sha256'] == spec['report_sha256']
        assert set(result['excluded']) == set(spec['exclusions'])

original = OUT.parent / 'sleep-native-log-disposition-20261009-39/package_01.py'
raw = original.read_bytes()
assert sha(raw) == '7e177d58e499f9b938cf0814d357a492c409a2bef6b7b68cc148a880e4515e35'
source = raw.decode('utf-8').replace('assert len(SPECS) == 2', 'assert len(SPECS) == 4')
source = source.replace("{'SHA256SUMS.txt', 'SEAL-RESULT.json'}", "set(spec['exclusions'])")
source = source.replace("'excluded_entries': ['SHA256SUMS.txt', 'SEAL-RESULT.json']", "'excluded_entries': spec['exclusions']")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__': str(Path(__file__)), '__name__': '__main__'})
