# Root52 offline-core normative contract disposition

Root is sole integrator. Base/upstream:
b80fb950b3965956ff6a75f8f86b9aff32aa196d. Protected src remains
85f53265bf4ee59b65c4a88664cb2e5e208c583e. User AGENTS.md SHA256
c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09
is untouched/unstaged. Status/worktrees/agents are checked before new writes.

Exclusive new own evidence leaf is this directory. Main write scope is exactly
CURRENT_VERSION.md, COMPLETION-PLAN.md, v1.8 implementation log, additive note in
OFFLINE-CORE-INDEPENDENT-STATUS-45.md, new OFFLINE-CORE-CONTRACT-FREEZE-52.md,
and four new sleep archives: DIAGNOSTIC-CONVENTION-43.zip,
PLATFORM-COUNTER-44.zip, OFFLINE-CORE-ROOT-REVIEW-45.zip,
OFFLINE-CONVENTION-INDEPENDENT-49.zip.

Root completely reads actual stable37/43 proposals and37/40/43/44/49 reports
before relevant custody acknowledgments. Final49 is 316 lines /24827 bytes,
SHA256 81ed06d8e26a0999d2f2da5b7254d93c8b01da3bc10e52f33dd8bbd367f7228f.
Use actual completed input seals, never pending permission or assumed schemas.

Disposition freezes only candidate37 plus additive43 as the normative internal
generic decoder/API/diagnostic and finite qualification contract. R01 is addressed
at the normative level, not by executed code. Keep inclusive caps, mandatory
deadline checks and strict process-lifetime resource requirements unchanged.
R49-01/U01/U02 stay open. Actual44 qualifies only its named local peak-so-far
queries; Task50's two bounded own-child cohorts are independently assessed later.
No prospective result, counter substitution, requirement narrowing or waiver.

Prepare a separate pure functional decoder/test implementation leaf using exactly
the two prospective scripts files and a new isolated committed-baseline worktree
only after this disposition is committed. Resource platform selection/cohort
qualification, source-aware schema/Gson/framing/NBT/logs/driver and native behavior
remain subsequent prerequisites; no complete decoder/native qualification inferred.

No source/test/build/API/schema/asset/provenance/owner/risk/ADR/ledger/Gate edit by
Root52; no cleanup, runtime/native launch, quota, cap/category change or waiver.
Verify all actual manifest members/exclusions/result/raw hashes and archive
CRC/payload/safe-path/volume. Own receipt children fixed180 seconds, split streams
bounded; preserve failures and gaps. Check exact protected Main scope/added links,
diff whitespace, stage only nine files, read cached stat/full raw UTF-8 Markdown,
cached check, notify agents before normal commit/push. Final own audit and complete
REPORT read precede custody-only one-time seal. Version/active goal remain open.
