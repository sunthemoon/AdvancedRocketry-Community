# Root52 normative offline-core contract disposition

Date: 2026-10-09 UTC. Root sole integration scope; version/active goal remain open.

## Completed scope and key decisions

Complete sealed37/43 proposals and40/43/44/49 actual reports are read before
exact-hash custody acknowledgments. Main disposition52 freezes only complete37
plus additive43 generic decoder/API/diagnostics and unchanged finite qualification
requirements. Independent49 finds no new material diagnostic correction. R01 is
addressed normatively, not by executed decoder assertions. R49-01/U01/U02 remain
open; three44 self queries and two separately sealed50 post-exit observations
remain distinct. Root completely reads50's307-line/20304-byte report before its
actual seal. Independent55 is separately assigned with fixed b80/d57 inputs and
no outcome supplied. No platform helper, cap, lifetime narrowing or waiver.

Five Markdown and four sealed43/44/45/49 ZIP files are committed and normally
pushed at e21fdbd75043c1f626fa6ab7d2894a75f5d9dba1; parent b80fb950. Complete src
tree85f53265bf4ee59b65c4a88664cb2e5e208c583e remains unchanged; production sleep/
natural/air/spawn/time/API/schema unchanged. New two-file pure functional source
task will use a separate committed-baseline worktree; it is not delivered here.

## Modified files and evidence

Main exact9-file scope: CURRENT_VERSION.md, COMPLETION-PLAN.md,
v1.8 implementation log, additive OFFLINE-CORE-INDEPENDENT-STATUS-45.md,
new OFFLINE-CORE-CONTRACT-FREEZE-52.md, DIAGNOSTIC-CONVENTION-43.zip,
PLATFORM-COUNTER-44.zip, OFFLINE-CORE-ROOT-REVIEW-45.zip and
OFFLINE-CONVENTION-INDEPENDENT-49.zip. Root-owned external writes are only this
new leaf's task/helpers/input pins/receipts/packaging/check/preparation/report;
later final audit/ack/one-time seal are not preclaimed.

INPUT-SEALS-01.json pins actual manifests/reports/result hashes and each declared
profile/exclusion. Before first package run, actual44's different command schema
is read and reflected explicitly; no flat-schema guess is executed. Four actual
seals, embedded stream hashes43/49, separate44 excluded raw command streams,
all covered member hashes/exact exclusions, safe paths/case uniqueness, CRC and
byte-for-byte ZIP payload equality pass. Root45's original package failure is
preserved unchanged in its packet, not relabeled.

PACKAGING-01.json records actual40 sleep ZIPs13596605 compressed /67429275 expanded
bytes. Unchanged65011712 reserve gives132440987 conservative expanded-plus FAIL
before loose/later sets; compressed-plus78608317 is a different measure. No
atomic launch inventory, deletion/reclassification, capacity waiver or native run.
Individual publication file/slice limits pass. No old sealed member changes.

## Actual commands and results

All9 retained bounded static/package/Git command receipts exit0/no timeout; raw
split streams are preserved with lengths/hashes. Exact argv/cwd/UTCs and protected
before/after state are in each *.command.json. No claim about uncaptured commands.

- package-01:10:11:41.680223-10:11:42.869312 UTC, four archives and actual volume.
- links-02:10:15:03.726838-10:15:04.498801, added local links/protected scope only;
  not whole historical portability. whitespace-03:10:15:05.195214-05.329998.
- stage-04:10:15:52.187734-52.306877; staged-stat-05:52.990395-53.051894;
  staged-diff-06:53.724650-53.784248; staged-check-07:54.469854-54.529475.
  Exact9 files /163 insertions /13 deletions; entire raw UTF-8 Markdown diff and
  stat are read before commit. Thin Python console's CP936 rendering is lossy,
  but raw retained UTF-8 is intact and separately read completely.
- commit-08:10:17:33.712790-33.976875; push-09:10:17:34.660651-38.736062.
  Both fixed-input workers confirm no mutable-HEAD dependency before Main move.

PREPARATION-LIMITATIONS.md retains the direct combined display's wrong-path
exit1 and truncation; later complete narrow reads do not fabricate its missing
raw receipt. A separate Task55 creation orchestration has a JavaScript syntax
failure before any patch/tool execution, followed by corrected task creation;
neither is a project test. The pinned runner is post-capture/fixed180, not an
independent streaming allocator/quota; outputs are finite static ones, checked
again in final audit. No policy-denied cleanup is retried.

## Tests, uncompleted scope, risks and Gates

No tests are added or modified. Python decoder/synthetic/resource tests, Gradle
clean build/test/runData/generated-diff/runGameTestServer, native Unicode,
dedicated/restart/real-client tests are NOT_EXECUTED, not PASS or inapplicable.
Historical2192JUnit/594GameTest results remain attributed to actuald57/Task28,
not to this docs commit. Actual20 observations/thirteen D1 rows remain unexecuted.

Uncompleted: functional implementation and independent actual-source review;
terminal/platform/finite resource qualification; source schema/Gson/framing/NBT/
provenance; whole driver/runtime/helper/quota/capture/Unicode/I/O; native logs/
recipe attribution, R-021 save/log/recovery; B1/R1/M1/M2/Space/old-world/client/
item/asset/hatch acceptance. Risk/capacity/preparation/strict-timeout obligations
remain explicit. User AGENTS hashc2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09
is untouched/unstaged; final tracked state only M AGENTS.md, index empty, Main
HEAD/upstream e21fdbd7. Inherited untracked/peer files and processes untouched.

Ledger186 PLANNED /154 REVIEW, ADR-068 PROPOSED/R-021 OPEN unchanged. **All Required
Gates G0-G9 satisfied: NO.** No release/tag/waiver/feature delivery. Evidence path
is this exclusive sleep-offline-core-contract-freeze-20261009-52 leaf and committed
disposition52/ZIPs. Next v1.8-only work is separate functional53 and independent55,
then actual-source and unchanged finite resource qualification; these do not
replace remaining full sleep/version acceptance.
