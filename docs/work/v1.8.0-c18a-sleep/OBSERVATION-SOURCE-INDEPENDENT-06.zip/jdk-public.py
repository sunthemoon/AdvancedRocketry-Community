import hashlib
import json
from pathlib import Path
import zipfile

p = Path('C:/Program Files/Java/jdk-17.0.7/lib/src.zip')
h = hashlib.sha256()
with p.open('rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
with zipfile.ZipFile(p) as z:
    b = z.read('java.base/java/lang/StackWalker.java')
    lines = b.decode('utf-8').splitlines()
print(json.dumps({'container': str(p), 'bytes': p.stat().st_size, 'sha256': h.hexdigest(),
                  'member': 'java.base/java/lang/StackWalker.java', 'member_bytes': len(b),
                  'member_sha256': hashlib.sha256(b).hexdigest()}, indent=2))
for i in range(338, 367):
    print(f'{i + 1}: {lines[i]}')
