import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
result = {'targets': [], 'source_status': []}
checkouts = ['D:/GitHub/arce-v180-sleep-observation-review-20261009',
             'D:/GitHub/arce-v180-sleep-observation-review-final-20261009',
             'D:/GitHub/arce-v180-sleep-observation-review-corrected-20261009']
targets = [Path(cwd) / child for cwd in checkouts for child in ('build', '.gradle')]
targets += [ROOT / cohort / 'temp' for cohort in ('candidate01-compile', 'final-compile', 'corrected-compile')]
for p in targets:
    files = [f for f in p.rglob('*') if f.is_file()] if p.exists() else []
    item = {'target': str(p), 'exists': p.exists(), 'files': len(files), 'bytes': sum(f.stat().st_size for f in files)}
    result['targets'].append(item)
    print(json.dumps(item))
for cwd in checkouts:
    result['source_status'].append({'cwd': cwd, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd).decode().strip(),
        'status_porcelain': subprocess.check_output(['git', 'status', '--porcelain'], cwd=cwd).decode()})
(ROOT / 'RETAINED-OUTPUTS.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result['source_status'], indent=2))
