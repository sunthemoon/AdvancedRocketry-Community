import hashlib
import json
from pathlib import Path
import subprocess
import sys

print('python', sys.executable)
for argv in [
    ['git', 'rev-parse', 'HEAD'],
    ['git', 'status', '--short'],
    ['git', 'diff', '--check', 'b9bec789978de0df67c93e976239d6d36e41532b', 'e72b41dea67404b5abba48bb499a1b4d5d743389'],
    ['git', 'diff', '--stat', 'b9bec789978de0df67c93e976239d6d36e41532b', 'e72b41dea67404b5abba48bb499a1b4d5d743389'],
    ['git', 'show', 'e72b41dea67404b5abba48bb499a1b4d5d743389:gradle.properties'],
    ['git', 'show', 'e72b41dea67404b5abba48bb499a1b4d5d743389:gradle/wrapper/gradle-wrapper.properties']
]:
    print('===', json.dumps(argv), '===')
    p = subprocess.run(argv, capture_output=True)
    print('exit', p.returncode)
    print(p.stdout.decode('utf-8', errors='replace'))
    print(p.stderr.decode('utf-8', errors='replace'))
    if p.returncode:
        raise SystemExit(p.returncode)
for p in Path('C:/Program Files/Java').iterdir():
    print('installed_java_directory', p)
p = Path('C:/Users/Administrator/.gradle/gradle.properties')
if p.exists():
    for line in p.read_text(encoding='utf-8').splitlines():
        if line.startswith(('org.gradle.java.home', 'org.gradle.jvmargs')):
            print('user_gradle_property', line)
