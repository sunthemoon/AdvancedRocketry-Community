import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent / 'primary'
ROOT.mkdir(exist_ok=False)
JDK = Path('C:/Program Files/Java/jdk-17.0.7')
cache = Path('C:/Users/Administrator/.gradle/caches')
forge = next((cache / 'forge_gradle/minecraft_user_repo/net/minecraftforge/forge').glob('1.20.1-47.4.10_mapped_official_1.20.1/forge-*-mapped_official_1.20.1.jar'), None)
if forge is None:
    forge = next((cache / 'forge_gradle/minecraft_user_repo/net/minecraftforge/forge').glob('1.20.1-47.4.10_mapped_official_1.20.1/*.jar'))
eventbus = next((cache / 'modules-2/files-2.1/net.minecraftforge/eventbus/6.0.5').glob('*/eventbus-6.0.5.jar'))
inputs = {}
for p in (forge, eventbus, JDK / 'bin/java.exe', JDK / 'bin/javap.exe', JDK / 'bin/javac.exe'):
    inputs[str(p)] = {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
commands = [(['java_version'], [str(JDK / 'bin/java.exe'), '-version'])]
for jar, cls in [(forge, 'net.minecraft.commands.CommandSourceStack'),
                 (forge, 'net.minecraft.server.players.PlayerList'),
                 (forge, 'net.minecraft.server.level.ServerPlayer'),
                 (forge, 'net.minecraft.server.network.ServerGamePacketListenerImpl'),
                 (forge, 'net.minecraft.world.level.block.BedBlock'),
                 (forge, 'net.minecraftforge.event.ForgeEventFactory'),
                 (eventbus, 'net.minecraftforge.eventbus.EventBus'),
                 (eventbus, 'net.minecraftforge.eventbus.ASMEventHandler')]:
    commands.append(([cls], [str(JDK / 'bin/javap.exe'), '-public', '-c', '-s', '-classpath', str(jar), cls]))
    with zipfile.ZipFile(jar) as z:
        name = cls.replace('.', '/') + '.class'
        inputs[name] = {'container': str(jar), 'bytes': len(z.read(name)), 'sha256': hashlib.sha256(z.read(name)).hexdigest()}
receipts = []
for label, argv in commands:
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, capture_output=True)
    name = label[0].replace('.', '_')
    receipt = {'argv': argv, 'cwd': str(Path.cwd()), 'start_utc': start,
               'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': p.returncode}
    for suffix, data in [('stdout', p.stdout), ('stderr', p.stderr)]:
        (ROOT / (name + '-' + suffix + '.txt')).write_bytes(data)
        receipt[suffix] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    receipts.append(receipt)
    print(name, 'exit', p.returncode, 'stdout_bytes', len(p.stdout), 'stderr_bytes', len(p.stderr))
    if p.returncode:
        break
(ROOT / 'audit.json').write_text(json.dumps({'inputs': inputs, 'commands': receipts}, indent=2) + '\n', encoding='utf-8')
print('forge', forge, inputs[str(forge)])
print('eventbus', eventbus, inputs[str(eventbus)])
