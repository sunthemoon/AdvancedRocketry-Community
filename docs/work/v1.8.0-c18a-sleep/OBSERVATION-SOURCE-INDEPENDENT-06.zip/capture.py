import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--compile', action='store_true')
parser.add_argument('--java-home')
parser.add_argument('--source-sha')
parser.add_argument('argv', nargs=argparse.REMAINDER)
args = parser.parse_args()
argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
leaf = ROOT / args.label
leaf.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
if args.java_home:
    env['JAVA_HOME'] = args.java_home
    env['PATH'] = str(Path(args.java_home) / 'bin') + os.pathsep + env.get('PATH', '')
receipt = {'argv': argv, 'cwd': str(Path(args.cwd).resolve()), 'start_utc': now(),
           'environment': {k: env.get(k) for k in ('JAVA_HOME', 'GRADLE_USER_HOME', 'TEMP', 'TMP')}}
if args.source_sha:
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.cwd).decode().strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=args.cwd).decode()
    receipt['source_before'] = {'expected': args.source_sha, 'actual': actual, 'status_porcelain': status}
    if actual != args.source_sha or status:
        raise RuntimeError('Assigned fixed source identity or tracked state differs')
if args.compile:
    receipt['free_space_before_bytes'] = {d: shutil.disk_usage(d).free for d in ('C:/', 'D:/')}
    if min(receipt['free_space_before_bytes'].values()) < 10 * 1024**3:
        raise RuntimeError('Insufficient disk space for compilation')
    temp = leaf / 'temp'
    temp.mkdir()
    env['TEMP'] = env['TMP'] = str(temp)
    receipt['child_temp'] = str(temp)
(leaf / 'started.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
with (leaf / 'stdout.txt').open('wb') as stdout, (leaf / 'stderr.txt').open('wb') as stderr:
    result = subprocess.run(argv, cwd=args.cwd, env=env, stdout=stdout, stderr=stderr)
receipt.update({'end_utc': now(), 'exit': result.returncode})
if args.source_sha:
    receipt['source_after'] = {
        'actual': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=args.cwd).decode().strip(),
        'status_porcelain': subprocess.check_output(['git', 'status', '--porcelain'], cwd=args.cwd).decode()}
for name in ('stdout.txt', 'stderr.txt'):
    data = (leaf / name).read_bytes()
    receipt[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
if args.compile:
    receipt['free_space_after_bytes'] = {d: shutil.disk_usage(d).free for d in ('C:/', 'D:/')}
(leaf / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
print((leaf / 'stdout.txt').read_text(encoding='utf-8', errors='replace'))
print((leaf / 'stderr.txt').read_text(encoding='utf-8', errors='replace'))
raise SystemExit(result.returncode)
