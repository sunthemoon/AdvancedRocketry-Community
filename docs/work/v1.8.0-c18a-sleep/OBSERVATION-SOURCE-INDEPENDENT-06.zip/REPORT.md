# Independent passive sleep-observation source review 06

## Findings first

**No remaining material source finding identified in the explicitly narrowed
candidate 5b45132000ade1e3c8d130a6b8ccb29f07535124.** The two Medium findings
below remain valid for both retained earlier candidates and are source-fixed
in the corrected candidate. This supports preparing a separately frozen and
reviewed finite driver/runtime assignment. It does not establish executed
tests, native frames/outcomes, production acceptance or any Required Gate.

`Fixture` means src/adapterTest/java/io/github/sunthemoon/arceadaptertest/
SleepBoundaryObservationFixture.java; `Trace` means the adjacent
SleepBoundaryTrace.java. References always name the immutable source SHA,
not a mutable author checkout. Full historical detail is also retained in
[OLD-COHORT-REVIEW.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-independent-20261009-06/OLD-COHORT-REVIEW.md).

### Medium F01, historical: byte limits checked after allocation

At 0c05cc27112f5f4a71faa66bc16b5f7f4390f345, Trace:96-104 adds a completed
JsonObject to the array before serializing the complete root/current object
to a String and UTF-8 byte array, and only afterward removes a rejected
record. Trace:129-145 materializes frame descriptors/names, snapshots and
event objects before that check. Fixture:385-388 likewise serializes native
chat before checking its length. The byte-cap tests at Trace:334-343 verify
removal/final size after creating oversized values, not pre-allocation
admission. The same defects exist at e72b41dea67404b5abba48bb499a1b4d5d743389,
Trace:91-99, 123-138, 328-337 and Fixture:373-376.

These mechanisms bounded accepted output, not size before allocation, and
added repeated whole-root formatting/allocation on the server thread. This
was a blocking source-contract finding for later driver/runtime preparation,
not a demonstrated production vulnerability or changed native sleep decision.
The frame/event/identity count limits were present and were not the defect.

**Corrected-source disposition:** At 5b451320, Trace:104-143 counts through a
counter-only JsonWriter/BudgetWriter before attaching a record; no complete
String or UTF-8 byte array is allocated for admission. Trace:168-181 and
208-219 cap metadata/descriptor lengths and preflight a conservative upper
budget before descriptor/stack JSON creation. Trace:240-293 preflights a
finite native component tree before native chat-to-JSON allocation: depth,
nodes, siblings, arguments, text and supported contents/styles/hover routes
are bounded; unsupported item/NBT or custom forms become incomplete capture.
Trace:377-381 counts the final root before allocating its bounded output
builder. Original 64-frame-plus-sentinel, 32-event/128-KiB case and
128-event/512-KiB invocation caps are unchanged. Newly added UTF-8/escape/
surrogate and metadata/chat preflight test content is not credited as run.

### Medium F02, historical: pre-try construction leaks invocation marker

At both earlier candidates, Fixture:101-106 sets INVOKING, constructs Trace
and Fixture, and only afterward enters the try/finally that removes the
marker. A trace class-initialization/construction failure therefore bypasses
marker removal and the structured acquisition-failure receipt; later
eligible() calls on that server thread remain rejected by the retained
marker. Trace:34-36 creates the retained-class StackWalker statically.
Installed Java 17's public getInstance(Set<Option>) documentation explicitly
permits permission denial, within the frozen named permission/metadata
failure scope. No security manager, injection or game reproduction was run.

Primary basis: installed JDK public java.base/java/lang/StackWalker.java:
339-367, especially 347-357/364-366, retained in
[jdk-public-api/stdout.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-independent-20261009-06/jdk-public-api/stdout.txt).

**Corrected-source disposition:** At 5b451320, Fixture:93-110 invokes trace
creation through withInvocation(); its finally at 106 covers all work after
marker acquisition, including trace initialization. Its bounded setup-failure
receipt returns a failure rather than leaving an unpaired marker. The new
setupFailureReleasesTheExactInvocationMarker method source-checks both the
failed and subsequent invocation, but has not executed here.

## Actual scope and independently inspected design

The full base-to-candidate diffs and both additive deltas were read. Every
candidate changes exactly the assigned two new adapterTest files, with no
production/API/central registration/build/resources/status/ledger/assets
change. The corrected files are 497 and 498 lines; neither exceeds 500.
Actual included commits are e72b41, 0c05cc, 9f21a3daab7e6f3b38029742979a328306146fcf
and 5b451320, recorded by fixed Git log, not author narration.

- Build.gradle:22-30/505-513 keeps adapterTest compilation on platform plus
  independently compiled API classes, not host main output. The authorized
  command executed only six API compilations and compileAdapterTestJava.
  Adjacent AdapterTestMod and JackhammerContinuationFixture conventions were
  read. New source has no client, private/reflection, AT/coremod or production
  enforcement dependency.
- Command registration is default-disabled by arce.sleepBoundaryObservation.
  Exact native console identity, permission 4, server-thread ownership,
  non-reentrancy, an empty ordinary-player list and both absent fixture UUIDs
  are required. Native withSource() preserves the instance only when its
  underlying source is identical (public bytecode offsets 0-9); NULL/RCON or
  entity sources are not treated as native console.
- Two owned native PlayerList actors and open EmbeddedChannels are checked by
  identity with their Level, listener, connection, UUID/list and level-list
  membership. Native placeNewPlayer/remove retains load/logout-save ownership.
  Fixed chunk preparation, native login/teleport loading and actual-outbound
  public simulated teleport acceptance are separately attributed. It is not
  TCP receipt, scheduling/decoder, real-client login/input/ack or no-ticket proof.
- Exactly twenty named rows preserve eight off/on day/night/head/foot pairs,
  range/occupied controls, native forced/unforced/null setters, guarded nested
  setters and synthetic events, direct/forwarded callbacks, the declared
  observer failure and a later administrative observation. Native permission,
  reach, hit, time, occupied and pending-teleport checks remain native. No
  direct sleep call replaces the stated public handleUseItemOn action.
- Observation is passive; injecting controls are labeled separately and
  guarded. Event/actor/receiver identity, native tuple/cancellation, declared
  route/control/context/depth and native before/after outcomes remain distinct.
  LOWEST/receiveCanceled is not claimed as a final writer. Loaded block identity
  is expressly not an inherited receiver/callback cause proof. Failure or
  incomplete capture is not a successful-sleep assertion.
- Exact owned listeners are unregistered; cleanup attempts use non-short-
  circuit boolean accumulation. Owned sleepers wake normally, loaded Spawn
  getter tuples are restored/checked, native actor removal includes partial
  Level registration, own channels close/release/check disconnected, captured
  cells/time/rules restore/check independently. This is inspected source,
  not executed teardown proof. The twenty native cases have never run here.
- Prefix duration/allocation is now explicitly named and scoped; it excludes
  native snapshot/event-record creation, append accounting and output
  serialization. Unsupported allocation measurement remains null/unmeasured;
  no global JVM measurement is enabled and no reference-load budget is proved.

Relevant public installed bytecode was independently read: CommandSourceStack,
PlayerList, ServerPlayer, ServerGamePacketListenerImpl, BedBlock,
ForgeEventFactory, EventBus/ASMEventHandler and its public factory/transformer
surface, plus Component.Serializer, Style, MutableComponent,
TranslatableContents and HoverEvent.EntityTooltipInfo. Native handleUseItemOn
keeps reach checks (91-137), hit geometry (140-196), pending teleport (235),
permission (249) and native use route (272). Native setRespawnPosition posts
the event (15), returns on cancellation (21), then updates the actual Spawn
fields (75-118). Public native chat serialization recurses through components/
arguments; the corrected preflight covers only its explicitly supported forms.
No private member was invoked or reflected into. Full raw public javap logs,
argv/UTC/exit/output hashes and primary identities are retained locally.

## Fixed inputs, source and diff hashes

Preparation used governance commit 8b3a6329a34b728029ecb71db111c74ee7bf5c9a
and source base b9bec789978de0df67c93e976239d6d36e41532b only. Mandatory v1.0
and active v1.8 governance, ADR-060, complete observation proposal, complete
prior independent review and the source-only disposition were read before
handoff. No mutable author source/diff or compiler was accessed before it.
The earliest incomplete acceptance cursor remains v1.0; ADR-060 permits
separate v1.8 development without satisfying inherited or current Gates.

TASK-05 SHA-256 matches a793aa4c994537401b0b728af3254e4e6815474fe5d149a6095e53b65550eb65.
Prior review archive SHA-256 a820d0a48aa09b19795075e13c57823c6e596448de7bd641f07f16c88282a9bf
verified CRC, 140 unique safe names and 139 manifest-covered files totaling
813872 bytes; manifest da8d3f2b2344d58572c0f61b579e1a268259c06e921949e73078dcd7188c8f0d.
Its conclusion was not substituted for actual source review.

| Actual retained Git diff | Bytes | SHA-256 |
|---|---:|---|
| base to e72b41 | 53266 | cd34dfb71dc22a1260a471e551e8cbad2ef9d9d16fca88f3391c8c93f749d709 |
| base to 0c05cc | 54967 | 6f6322a5cc326d82ada8d82a2496ed19a9d064ef41529f7d4c3ed273f69a3492 |
| e72b41 to 0c05cc | 7857 | cd5851f77aaab7ebb5670afb3b2815b84cda64261494488462aadf876222ef89 |
| base to 5b451320 | 67181 | 168632ce7d408424f61944c81737c8f39fb5d811913257c0085a76b6e53434ff |
| 0c05cc to 5b451320 | 28317 | d1f1b915031c7aaa48ff190c49d7083c1078d2e8a8bc1dc76646121ea396c485 |

Corrected Fixture source: 33987 bytes, SHA-256
1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820.
Corrected Trace source: 31470 bytes, SHA-256
39bc68fabfd0cadaaa48e93b45e2ca828c1d5590341f9bd4e756f4ac734f7af0.
INPUT-INDEX.json preserves both earlier cohorts' source/build/input and
compiled-class hashes; INPUT-INDEX-CORRECTED.json adds the corrected source,
ten actual sleep class hashes and actual Gradle launcher identity without
replacing the earlier index.

Primary mapped Forge 47.4.10 JAR: 19355242 bytes, SHA-256
95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e.
Installed eventbus 6.0.5 JAR: 53985 bytes, SHA-256
ae8bd4ea6b32509ace6dba904698b52e13d222625488c8291a05ab870e66c1dd.
Installed JDK src.zip: 43420134 bytes, SHA-256
eb661f48670025c35656435c2f716180dd913968daa7000e79c3a27288500059;
StackWalker member: 24857 bytes, SHA-256
9802cfe5cfd6bd6879dde8fe41d3854435e9284e292abae90353cb21e529345f.
No complete primary JAR, JDK source, build or source export is stored in evidence.

## Commands actually run and complete independent compile results

All three authorized compilations used:

```text
./gradlew.bat compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks
```

Actual Windows child argv was cmd.exe /d /c gradlew.bat followed by those exact
arguments. JAVA_HOME/PATH selected installed C:/Program Files/Java/jdk-17.0.7.
Actual runtime printed Java 17.0.7, JVM 17.0.7+8-LTS-224, Oracle Corporation,
amd64; wrapper/distribution/log identity is Gradle 8.8. Child TEMP/TMP were
each cohort's own evidence temp child, not shared Temp. All disk values below
were checked immediately before compilation; C and D both exceeded 10 GiB.

| Cohort / actual cwd suffix under D:/GitHub | Source SHA | UTC start to end | Exit / tasks | C free before / D free before, bytes |
|---|---|---|---|---|
| arce-v180-sleep-observation-review-20261009 | e72b41dea67404b5abba48bb499a1b4d5d743389 | 04:58:02.158054 to 04:58:23.205121 | 0 / 7 executed | 30565625856 / 296044093440 |
| arce-v180-sleep-observation-review-final-20261009 | 0c05cc27112f5f4a71faa66bc16b5f7f4390f345 | 04:59:22.338448 to 04:59:41.810570 | 0 / 7 executed | 30564720640 / 296041795584 |
| arce-v180-sleep-observation-review-corrected-20261009 | 5b45132000ade1e3c8d130a6b8ccb29f07535124 | 05:16:55.313721 to 05:17:12.818310 | 0 / 7 executed | 30554148864 / 295441575936 |

All times are 2026-10-09 UTC. Each complete raw stdout is 1048 bytes; each
complete stderr is respectively 561/567/571 bytes. Hashes and before/after
disk/source/cwd/argv/UTC details are in candidate01-compile, final-compile and
corrected-compile receipt.json beside the original raw streams. The existing
JackhammerContinuationFixture:78 ResourceLocation deprecation warning and
general deprecation notes were retained, not suppressed. No compile failed.
The first detached identity was checked before the first compile; both earlier
identities/statuses were independently rechecked afterward. Corrected source
identity and clean tracked status were checked before and after its compile.

Other material commands were read-only fixed Git diff/show/log/status/hash
inventory, installed public javap/ZIP reads and Python -B own evidence helpers.
git diff --check passed for each fixed candidate. All assigned detached HEADs
remain unchanged and their tracked status is clean. This says nothing about
Main or author worktree cleanliness, and no Main/author inspection was borrowed.

Preserved preparation failures/capture limits:

- The initial broad fixed tree listing exceeded the tool display budget; focused
  complete fixed reads followed. A guessed lowercase v1.8 version filename was
  absent; the actual uppercase tracked version file was then read completely.
  These exploratory outputs and initial leaf/JDK/disk reads are transcript-only,
  not retroactively presented as archived raw commands.
- candidate01-input failed before reading source with a PowerShell argument-
  quoting/parser error: exit 1, stdout 0, stderr 2579 bytes. candidate01-identity
  failed on the machine's script execution policy: exit 1, stdout 0, stderr
  419 bytes. Both complete failures were kept; direct Python/read-only corrected
  identity inspection then succeeded without changing the execution policy.
- Some diff/public-javap displays exceeded the tool budget. Their complete
  archived raw files were retained and relevant source/method sections reread.
  Display truncation is not truncation of the archived compile/raw evidence.
- An inconclusive cleanup helper and subsequent policy-rejected cleanup are
  separately recorded below. They are not passed cleanup or failed source runs.

## Tests present, not executed

The corrected source includes nine GameTest methods:

- defaultDisabledRegistrationNeedsExplicitOptIn
- nativeConsoleIdentityPermissionAndReentrancyAreGuarded
- nativeConsoleCannotInvokeFromAnotherThread
- setupFailureReleasesTheExactInvocationMarker
- tokensUseIdentityAndHaveAHardCap
- structuredAndEventCapsStopFurtherCapture
- deepPublicWalkerRetainsOnlyBoundedFramesAndSentinel
- byteAccountingMatchesEscapesUtf8AndSplitSurrogates
- oversizedDescriptorAndChatAreRefusedBeforeSerialization

Their content was inspected and compiled only. No test, clean build, DataGen,
GameTest/server/client/world, driver, native observer, security-manager/failure
injection or other runtime process was executed by this reviewer. No source
assertion, cap, timeout or budget was weakened by this reviewer. Missing runs
are UNEXECUTED, not PASS, waived or not-applicable.

## Ownership, cleanup and acceptance status

Root owns OpenPet; this reviewer sent no competing pet events and delegated
nothing. Main/source-author/HEAD/branch/runtime/peer evidence interests were
released at preparation. Only this assigned external evidence leaf and three
explicitly assigned detached checkouts' disposable compile outputs were written.
No tracked source/test, Main, status, ledger, original seal, author or peer file
was edited/staged/committed/switched/deleted. No process was terminated.

Owned compilation subprocesses ended. An initial PowerShell-stdin cleanup
wrapper returned exit 0 but produced no per-target receipt, so it is recorded
as inconclusive. The subsequent direct native PowerShell cleanup command was
rejected by tool policy before launch. Its proposed targets were exclusively
owned build/.gradle/temp children, with containment/reparse/live-process checks;
no deletion was claimed and no alternative-shell or subsequent deletion retry
was attempted after the denial. Details are in
[CLEANUP-POLICY-DENIAL.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-source-independent-20261009-06/CLEANUP-POLICY-DENIAL.md).
Actual read-only RETAINED-OUTPUTS.json confirms all six build/.gradle trees
remain: 320 files /5608016 bytes total; the three temp children are empty and
remain. Source worktrees are retained as instructed. No whole source-tree/
world/server/runtime/build export is included in evidence. Root may record
the retained-output status; this is not transfer of deletion ownership or
permission to retry policy-denied cleanup, and creates no cleanup exemption.

Completed: fixed preparation/integrity, actual source/delta/adjacent/primary
review, preservation of two historical Medium findings and their actual
corrected-source disposition, three independent compile runs, compact receipts
and actual owned retention inventory. No current material source blocker was
identified at 5b451320 for the narrower later driver preparation.

Unfinished: execution of those tests and all twenty native rows; separately
frozen/reviewed packaging/driver/parser/launch; actual native frames and saved
typed Spawn disk fields; real connected/client, restart/death/prior-world,
six-host/Space, inheritance/custom receiver/stale state/secondary/monster/item,
interpreted/JIT/development and coexistence qualification. Getter and logout
input projections are not serialization/disk/restart evidence, and Embedded
transport is not TCP/client evidence. B1/R1/M1/M2/D1, exact cause/enforcement,
owner ancillary choice, air-gap/station policy, production failure strategy,
ADR/risk acceptance, item/ledger/assets and strict/native-log/client/provenance
acceptance remain open. **Current and inherited Required Gates are not
satisfied by this source review or compilation. No Gate/version/item approval
is made.**

Recommendation within v1.8 only: Root may use this source review to prepare
and independently review a finite driver/runtime contract, then issue explicit
test/runtime assignments. Compilation does not authorize launch. Root fully
read the pre-seal report (19054 bytes, SHA-256
20338d51cf83027a24609127a79e480e0fc965a5a29e17a6a1eedb0f63d4e860)
before directing sealing via the Root coordination channel on 2026-10-09.
That source-fix disposition is input to standard development regression,
not runtime/driver/Gate approval. The leaf-relative manifest preserves every
original failed/preliminary cohort and raw receipt. SEAL-RESULT.json is an
explicit post-seal verification receipt outside manifest coverage, avoiding
a cyclic self-hash; the covered report does not embed its own final hash.
