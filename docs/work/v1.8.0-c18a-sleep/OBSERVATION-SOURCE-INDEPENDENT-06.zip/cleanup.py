import subprocess

script = r'''
$ErrorActionPreference = 'Stop'
$roots = @(
    'D:\GitHub\arce-v180-sleep-observation-review-20261009',
    'D:\GitHub\arce-v180-sleep-observation-review-final-20261009',
    'D:\GitHub\arce-v180-sleep-observation-review-corrected-20261009'
)
$evidence = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-observation-source-independent-20261009-06'
$targets = @()
foreach ($root in $roots) {
    foreach ($child in @('build', '.gradle')) {
        $targets += [pscustomobject]@{ Root = $root; Target = (Join-Path $root $child) }
    }
}
foreach ($cohort in @('candidate01-compile', 'final-compile', 'corrected-compile')) {
    $targets += [pscustomobject]@{ Root = $evidence; Target = (Join-Path $evidence ($cohort + '\temp')) }
}
$processes = Get-CimInstance Win32_Process
$live = @($processes | Where-Object {
    $line = $_.CommandLine
    $line -and ($roots | Where-Object { $line.Contains((Split-Path $_ -Leaf)) })
})
if ($live.Count -ne 0) {
    $live | Select-Object ProcessId, Name, CommandLine | ConvertTo-Json -Depth 3
    throw 'A process still names an owned review checkout; cleanup not attempted.'
}
Write-Output 'No live process command line names any owned review checkout.'
$results = @()
foreach ($entry in $targets) {
    $root = (Resolve-Path -LiteralPath $entry.Root).Path.TrimEnd('\')
    if (-not (Test-Path -LiteralPath $entry.Target)) {
        $results += [pscustomobject]@{ Target = $entry.Target; Outcome = 'ABSENT' }
        continue
    }
    $target = (Resolve-Path -LiteralPath $entry.Target).Path
    if (-not $target.StartsWith($root + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Resolved target is outside explicit owned root: ' + $target)
    }
    $items = @((Get-Item -LiteralPath $target -Force)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
    if (@($items | Where-Object { $_.Attributes -band [System.IO.FileAttributes]::ReparsePoint }).Count -ne 0) {
        throw ('Reparse point detected; cleanup not attempted: ' + $target)
    }
    $files = @($items | Where-Object { -not $_.PSIsContainer })
    $bytes = ($files | Measure-Object -Property Length -Sum).Sum
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    if (Test-Path -LiteralPath $target) { throw ('Owned target remains: ' + $target) }
    $results += [pscustomobject]@{ Target = $target; Outcome = 'REMOVED'; Files = $files.Count; Bytes = $bytes }
}
$results | ConvertTo-Json -Depth 3
'''
p = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', '-'],
                   input=script.encode('utf-8'), capture_output=True)
print(p.stdout.decode('utf-8', errors='replace'))
print(p.stderr.decode('utf-8', errors='replace'))
raise SystemExit(p.returncode)
