import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
inputs = {}
governance = '8b3a6329a34b728029ecb71db111c74ee7bf5c9a'
paths = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
         'docs/04-VERSION-ROADMAP.md', 'docs/05-MASTER-TEST-PLAN.md',
         'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
         'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
         'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
         'docs/versions/V1.0.0-COMMUNITY-MVP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
         'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
         'docs/work/v1.8.0-c18a-sleep/PROPOSED-OBSERVATION-01.md',
         'docs/work/v1.8.0-c18a-sleep/OBSERVATION-REVIEW-STATUS-04.md',
         'docs/work/v1.8.0-c18a-sleep/OBSERVATION-ASSIGNMENT-05.md',
         'docs/status/CURRENT_VERSION.md', 'docs/status/GATE_STATUS.md']
for path in paths:
    data = subprocess.check_output(['git', 'show', governance + ':' + path])
    inputs[governance + ':' + path] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
for name in ['SLEEP-OBSERVATION-SOURCE-TASK-05.md', 'SLEEP-OBSERVATION-SOURCE-REVIEW-TASK-06.md']:
    p = ROOT.parent / name
    data = p.read_bytes()
    inputs[str(p)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
cohorts = []
for name, sha, cwd in [
    ('candidate01', 'e72b41dea67404b5abba48bb499a1b4d5d743389', 'D:/GitHub/arce-v180-sleep-observation-review-20261009'),
    ('final', '0c05cc27112f5f4a71faa66bc16b5f7f4390f345', 'D:/GitHub/arce-v180-sleep-observation-review-final-20261009')]:
    result = {'name': name, 'expected_source': sha, 'cwd': cwd}
    for argv in [['git', 'rev-parse', 'HEAD'], ['git', 'status', '--porcelain'],
                 ['git', 'show', '--no-patch', '--format=fuller', sha],
                 ['git', 'diff', '--name-status', 'b9bec789978de0df67c93e976239d6d36e41532b', sha],
                 ['git', 'diff', '--check', 'b9bec789978de0df67c93e976239d6d36e41532b', sha]]:
        p = subprocess.run(argv, cwd=cwd, capture_output=True)
        print(json.dumps({'argv': argv, 'exit': p.returncode}))
        print(p.stdout.decode('utf-8', errors='replace'))
        print(p.stderr.decode('utf-8', errors='replace'))
        if p.returncode: raise SystemExit(p.returncode)
    for path in ['src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java',
                 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java',
                 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterTestMod.java',
                 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/JackhammerContinuationFixture.java',
                 'build.gradle', 'settings.gradle', 'gradle.properties',
                 'gradle/wrapper/gradle-wrapper.properties', 'gradle/wrapper/gradle-wrapper.jar']:
        data = subprocess.check_output(['git', 'show', sha + ':' + path], cwd=cwd)
        inputs[sha + ':' + path] = {'bytes': len(data), 'lines': len(data.splitlines()), 'sha256': hashlib.sha256(data).hexdigest()}
    classes = {}
    for p in Path(cwd).glob('build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest/SleepBoundary*.class'):
        data = p.read_bytes()
        classes[str(p.relative_to(cwd))] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    result['compiled_sleep_classes'] = classes
    cohorts.append(result)
(ROOT / 'INPUT-INDEX.json').write_text(json.dumps({'inputs': inputs, 'cohorts': cohorts}, indent=2) + '\n', encoding='utf-8')
print('input_count', len(inputs))
