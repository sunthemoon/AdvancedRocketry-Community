# Owned cleanup outcome

An initial owned cleanup helper at 2026-10-09T05:21:10 UTC used PowerShell
stdin. Its wrapper returned exit 0 with only four stdout bytes and no stderr;
it produced no per-target receipt. This is an inconclusive invocation, not
successful cleanup. Its complete wrapper streams/receipt remain in
owned-cleanup. A later read-only inventory establishes the actual targets.

A direct native PowerShell command was then submitted through exec_command
from this evidence directory. It declared only these owned checkout roots:

- D:/GitHub/arce-v180-sleep-observation-review-20261009
- D:/GitHub/arce-v180-sleep-observation-review-final-20261009
- D:/GitHub/arce-v180-sleep-observation-review-corrected-20261009

Its targets were only each checkout's build and .gradle subdirectories and
the candidate01-compile, final-compile and corrected-compile temp children
inside this evidence leaf. The submitted command checked absolute resolved
containment, rejected reparse points, rejected matching live non-helper
processes, used native Remove-Item -LiteralPath, and never killed a process.
It named no Root qualification, author, peer, world or shared Gradle-cache
deletion target.

The tool rejected this command before CreateProcess with `blocked by policy`.
The rejection as returned in the tool transcript truncated the embedded long
command; no OS process exit or native transcript exists for that rejected
launch. No successful deletion is claimed. No alternative-shell, force,
elevation or subsequent deletion retry was attempted after that denial.

RETAINED-OUTPUTS.json is the actual subsequent read-only target inventory.
These directories remain for Root's separately authorized disposition; all
detached source checkouts are retained. Compiled sleep class hashes were
recorded before the attempted cleanup. No complete build/source/runtime/world
export is included in evidence. This denial is an owned-cleanup limitation,
not a failed compile or evidence of a source/runtime failure.
