$ErrorActionPreference = 'Stop'
Write-Output '=== Detached identity ==='
git rev-parse HEAD
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
git status --short
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
git diff --check b9bec789978de0df67c93e976239d6d36e41532b e72b41dea67404b5abba48bb499a1b4d5d743389
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
git diff --stat b9bec789978de0df67c93e976239d6d36e41532b e72b41dea67404b5abba48bb499a1b4d5d743389
Write-Output '=== Gradle properties ==='
git show e72b41dea67404b5abba48bb499a1b4d5d743389:gradle.properties
Write-Output '=== Wrapper properties ==='
Get-Content -LiteralPath './gradle/wrapper/gradle-wrapper.properties'
Write-Output '=== Java installations ==='
Get-ChildItem -LiteralPath 'C:/Program Files/Java' -Directory | Select-Object FullName
Write-Output '=== User Gradle properties ==='
if (Test-Path -LiteralPath 'C:/Users/Administrator/.gradle/gradle.properties') {
    Get-Content -LiteralPath 'C:/Users/Administrator/.gradle/gradle.properties'
}
Write-Output '=== Python executable ==='
python -B -c 'import sys;print(sys.executable)'
exit $LASTEXITCODE
