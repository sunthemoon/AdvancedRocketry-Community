import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = 'D:/GitHub/arce-v180-sleep-observation-review-corrected-20261009'
assert not (ROOT / 'SHA256SUMS.txt').exists()
assert not (ROOT / 'SEAL-RESULT.json').exists()

def digest(data):
    return hashlib.sha256(data).hexdigest()

checks = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'input_hashes_verified': 0, 'raw_receipts_verified': 0, 'source_status': [], 'retained_targets_verified': 0}
for filename in ('INPUT-INDEX.json', 'INPUT-INDEX-CORRECTED.json'):
    index = json.loads((ROOT / filename).read_text())
    for key, value in index['inputs'].items():
        if ':' in key and len(key.split(':', 1)[0]) == 40:
            data = subprocess.check_output(['git', 'show', key], cwd=REPO)
        elif 'container' in value:
            with zipfile.ZipFile(value['container']) as z:
                data = z.read(key)
        else:
            data = Path(key).read_bytes()
        assert len(data) == value['bytes'] and digest(data) == value['sha256'], key
        checks['input_hashes_verified'] += 1
for receipt_path in ROOT.rglob('receipt.json'):
    receipt = json.loads(receipt_path.read_text())
    for name in ('stdout.txt', 'stderr.txt'):
        data = (receipt_path.parent / name).read_bytes()
        assert len(data) == receipt[name]['bytes'] and digest(data) == receipt[name]['sha256'], str(receipt_path)
    checks['raw_receipts_verified'] += 1
for cohort, source, cwd in [
    ('candidate01', 'e72b41dea67404b5abba48bb499a1b4d5d743389', 'D:/GitHub/arce-v180-sleep-observation-review-20261009'),
    ('final', '0c05cc27112f5f4a71faa66bc16b5f7f4390f345', 'D:/GitHub/arce-v180-sleep-observation-review-final-20261009'),
    ('corrected', '5b45132000ade1e3c8d130a6b8ccb29f07535124', REPO)]:
    p = ROOT / (cohort + '-compile')
    receipt = json.loads((p / 'receipt.json').read_text())
    assert receipt['exit'] == 0
    assert receipt['argv'] == ['cmd.exe', '/d', '/c', 'gradlew.bat', 'compileAdapterTestJava', '--no-daemon', '--no-build-cache', '--rerun-tasks']
    assert min(receipt['free_space_before_bytes'].values()) >= 10 * 1024**3
    assert 'BUILD SUCCESSFUL' in (p / 'stdout.txt').read_text()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd).decode().strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=cwd).decode()
    assert head == source and not status
    checks['source_status'].append({'source': head, 'cwd': cwd, 'status_porcelain': status})
for label in ('candidate01-input', 'candidate01-identity'):
    assert json.loads((ROOT / label / 'receipt.json').read_text())['exit'] == 1
assert (ROOT / 'OLD-COHORT-REVIEW.md').is_file()
retained = json.loads((ROOT / 'RETAINED-OUTPUTS.json').read_text())
for target in retained['targets']:
    p = Path(target['target'])
    files = [f for f in p.rglob('*') if f.is_file()] if p.exists() else []
    assert p.exists() == target['exists']
    assert len(files) == target['files'] and sum(f.stat().st_size for f in files) == target['bytes']
    checks['retained_targets_verified'] += 1
checks['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(ROOT / 'PRESEAL-VERIFICATION.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
files = sorted(p for p in ROOT.rglob('*') if p.is_file())
entries = []
total = 0
for p in files:
    assert not p.is_symlink() and not (p.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT), str(p)
    name = p.relative_to(ROOT).as_posix()
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
    data = p.read_bytes()
    assert len(data) <= 50 * 1024 * 1024
    entries.append((name, digest(data)))
    total += len(data)
assert total <= 100 * 1024 * 1024
assert len({n for n, h in entries}) == len(entries)
manifest = ''.join(h + '  ' + n + '\n' for n, h in entries).encode('utf-8')
(ROOT / 'SHA256SUMS.txt').write_bytes(manifest)
for line in (ROOT / 'SHA256SUMS.txt').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert digest((ROOT / name).read_bytes()) == expected, name
result = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'covered_files': len(entries), 'covered_bytes': total,
          'report_bytes': (ROOT / 'REPORT.md').stat().st_size,
          'report_sha256': digest((ROOT / 'REPORT.md').read_bytes()),
          'manifest_bytes': len(manifest), 'manifest_sha256': digest(manifest),
          'all_covered_hashes_match': True, 'safe_unique_leaf_relative_names': True,
          'preseal_checks': checks,
          'outside_manifest': ['SHA256SUMS.txt', 'SEAL-RESULT.json'],
          'cleanup_policy_denial_retained_no_retry': True}
(ROOT / 'SEAL-RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
