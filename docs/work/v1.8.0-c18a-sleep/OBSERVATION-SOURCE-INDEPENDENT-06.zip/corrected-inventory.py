import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
sha = '5b45132000ade1e3c8d130a6b8ccb29f07535124'
base = 'b9bec789978de0df67c93e976239d6d36e41532b'
cwd = 'D:/GitHub/arce-v180-sleep-observation-review-corrected-20261009'
result = {'source': sha, 'base': base, 'cwd': cwd, 'commands': [], 'inputs': {}, 'compiled_sleep_classes': {}}
for argv in [['git', 'rev-parse', 'HEAD'], ['git', 'status', '--porcelain'],
             ['git', 'log', '--format=%H %s', base + '..' + sha],
             ['git', 'diff', '--name-status', base, sha], ['git', 'diff', '--check', base, sha],
             ['git', 'diff', '--stat', base, sha]]:
    p = subprocess.run(argv, cwd=cwd, capture_output=True)
    item = {'argv': argv, 'exit': p.returncode, 'stdout': p.stdout.decode('utf-8', errors='replace'),
            'stderr': p.stderr.decode('utf-8', errors='replace')}
    result['commands'].append(item)
    print(json.dumps(item))
    if p.returncode: raise SystemExit(p.returncode)
for path in ['src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryObservationFixture.java',
             'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SleepBoundaryTrace.java',
             'build.gradle', 'settings.gradle', 'gradle.properties', 'gradle/wrapper/gradle-wrapper.properties',
             'gradle/wrapper/gradle-wrapper.jar']:
    data = subprocess.check_output(['git', 'show', sha + ':' + path], cwd=cwd)
    result['inputs'][sha + ':' + path] = {'bytes': len(data), 'lines': len(data.splitlines()), 'sha256': hashlib.sha256(data).hexdigest()}
for p in Path(cwd).glob('build/classes/java/adapterTest/io/github/sunthemoon/arceadaptertest/SleepBoundary*.class'):
    data = p.read_bytes()
    result['compiled_sleep_classes'][str(p.relative_to(cwd))] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
cache = Path('C:/Users/Administrator/.gradle')
gradle = next((cache / 'wrapper/dists/gradle-8.8-bin').glob('*/gradle-8.8/lib/gradle-launcher-8.8.jar'))
result['inputs'][str(gradle)] = {'bytes': gradle.stat().st_size, 'sha256': hashlib.sha256(gradle.read_bytes()).hexdigest()}
forge = next((cache / 'caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge').glob('1.20.1-47.4.10_mapped_official_1.20.1/*.jar'))
with zipfile.ZipFile(forge) as z:
    for cls in ['net.minecraft.network.chat.Component$Serializer', 'net.minecraft.network.chat.Style',
                'net.minecraft.network.chat.MutableComponent', 'net.minecraft.network.chat.contents.TranslatableContents',
                'net.minecraft.network.chat.HoverEvent$EntityTooltipInfo']:
        name = cls.replace('.', '/') + '.class'; data = z.read(name)
        result['inputs'][name] = {'container': str(forge), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(ROOT / 'INPUT-INDEX-CORRECTED.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('corrected_compiled_class_count', len(result['compiled_sleep_classes']))
