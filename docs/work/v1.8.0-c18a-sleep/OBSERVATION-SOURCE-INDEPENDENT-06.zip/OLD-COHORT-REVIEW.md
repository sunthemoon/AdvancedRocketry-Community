# Independent source findings: retained initial cohorts

This records the reviewer's own source/primary inspection of immutable
e72b41dea67404b5abba48bb499a1b4d5d743389 and
0c05cc27112f5f4a71faa66bc16b5f7f4390f345. No author report, admission,
compiler result or mutable author file is substituted for this inspection.

## Findings first

### Medium F01: trace limits are checked after the relevant allocation

At 0c05cc27112f5f4a71faa66bc16b5f7f4390f345,
SleepBoundaryTrace.java:96-104 first adds a completed JsonObject to the
array, then serializes the entire root/current object to a String and UTF-8
byte array, and only afterward removes a rejected object. Event frame name/
descriptor and snapshot materialization at lines 129-145 precedes that
check. SleepBoundaryObservationFixture.java:385-388 similarly invokes
Component.Serializer.toJson before testing native chat length. The source
therefore limits accepted serialized output, not size before allocation.
The byte-cap tests at SleepBoundaryTrace.java:334-343 assert removal/final
size after deliberately building an oversized value; they do not validate
pre-allocation bounds. The same mechanisms exist in e72b41 at Trace:91-99,
123-138, 328-337 and Fixture:373-376.

This conflicts with the frozen source-review requirement for trace
size-before-allocation bounds. It also adds repeated whole-root formatting
and UTF-8 allocation to each append on the server thread. It is a blocking
source-contract finding for the later finite driver/runtime freeze, not a
demonstrated production denial-of-service or changed native sleep decision.
Count/identity/frame limits are present and are not the defective mechanism.
Retain the original caps and native decisions; bound metadata/text and check
remaining bytes with a non-materializing bounded writer/counter before
retaining/formatting a record. Oversized capture must remain incomplete.

### Medium F02: pre-try trace construction can leave the invocation marker

At both immutable candidates, SleepBoundaryObservationFixture.java:101-106
sets INVOKING, constructs SleepBoundaryTrace and Fixture, and only then
enters the try/finally that eventually removes INVOKING. A failure during
trace class initialization/construction therefore bypasses removal and the
declared structured acquisition-failure result. Subsequent eligible() calls
on that server thread are rejected by the retained marker. Trace.java:34-36
constructs the retained-class StackWalker in static initialization; the
installed Java 17 public getInstance(Set<Option>) contract explicitly permits
a permission SecurityException, so this is within the frozen named
permission/metadata failure scope rather than an invented native result.

The actual installed JDK public source is retained in jdk-public-api output:
java.base/java/lang/StackWalker.java:339-367, container/member hashes in that
receipt. No SecurityManager, injection, game process or reproduction was
executed. Cover all work after marker acquisition with its removal finally;
ensure unavailable trace metadata/initialization has an explicit failed or
incomplete outcome without an unpaired action marker.

## Other inspected boundaries and limits

No additional material source defect was identified in these cohorts from
the actual two-file diff, build/API-only classpath, native-console identity,
thread/player/UUID guards, native handler/setter routes, owned PlayerList
registration/removal, genuine/nested/synthetic/callback attribution,
frame/event/identity counts, event passivity or non-short-circuit cleanup
attempts. That is static review, not proof of executed cleanup or admission.

The diagnostic allocation and duration interval ends before JSON append/
serialization, and allocation ends before event snapshot/object creation.
It must not be interpreted as end-to-end observer overhead or reference-load
performance. Native getters and the logout-save-input projection are not
native saved disk fields, persistence/restart or real-client proof.

Both fixed sources independently compiled with the exact authorized
compileAdapterTestJava --no-daemon --no-build-cache --rerun-tasks command,
JDK 17.0.7 and Gradle 8.8, with seven tasks executed and exit 0. Complete raw
stdout/stderr and before/after disk/UTC/cwd/argv receipts are in
candidate01-compile and final-compile. No tests or twenty native cases ran.
The existing JackhammerContinuationFixture ResourceLocation deprecation
warning and general deprecation notes were preserved, not suppressed.

Six newly present GameTest methods were source-reviewed/compiled, not run.
The original two detached checkouts and evidence cohorts remain separate;
neither HEAD was moved or source fixed by this reviewer. Both old cohorts
require changes before the source supports an authorized runtime freeze.
No item/ledger/asset/Gate status or owner decision changes.
