import base64
import datetime
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys
import time

LEAF = Path(__file__).resolve().parent
EXPECTED = "81ed06d8e26a0999d2f2da5b7254d93c8b01da3bc10e52f33dd8bbd367f7228f"
EXCLUDED = ["SEAL-RESULT.json", "SHA256SUMS.txt"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def child():
    assert not (LEAF / "SHA256SUMS.txt").exists()
    assert not (LEAF / "SEAL-RESULT.json").exists()
    report = (LEAF / "REPORT.md").read_bytes()
    ack = json.loads((LEAF / "ROOT-READ-ACK.json").read_bytes())
    assert sha(report) == EXPECTED == ack["report_sha256"]
    assert len(report) == 24827 == ack["report_bytes"]
    assert len(report.decode("utf-8").splitlines()) == 316 == ack["report_lines"]
    assert ack["custody_permission_only"] is True
    for path in (LEAF, *LEAF.parents):
        assert not (getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    files = sorted(LEAF.iterdir(), key=lambda p: p.name)
    assert len({p.name.casefold() for p in files}) == len(files)
    entries = []
    covered_bytes = 0
    receipts = 0
    max_raw = 0
    for path in files:
        assert path.is_file() and not path.is_symlink()
        assert not (getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
        assert path.resolve().is_relative_to(LEAF.resolve())
        assert ":" not in path.name and "\\" not in path.name and "/" not in path.name
        data = path.read_bytes()
        covered_bytes += len(data)
        entries.append((sha(data), path.name))
        if path.name.endswith(".command.json"):
            meta = json.loads(data)
            for stream in ("stdout", "stderr"):
                raw = (LEAF / path.name.replace(".command.json", "." + stream + ".txt")).read_bytes()
                info = meta["streams"][stream]
                assert len(raw) == info["retained_bytes"] == info["raw_bytes_observed"]
                assert sha(raw) == info["sha256"] and len(raw) <= 262144
                max_raw = max(max_raw, len(raw))
            assert meta["timeout_seconds"] == 180
            assert not meta["timed_out"] and not meta["stream_limit_exceeded"] and not meta["reader_errors"]
            receipts += 1
    assert covered_bytes + 32768 < 4194304
    manifest = "".join(f"{hashed}  {name}\n" for hashed, name in entries).encode("utf-8")
    (LEAF / "SHA256SUMS.txt").write_bytes(manifest)
    for hashed, name in entries:
        assert sha((LEAF / name).read_bytes()) == hashed
    print(json.dumps({"all_covered_hashes_match": True,
                      "covered_files": len(entries), "covered_bytes": covered_bytes,
                      "manifest_bytes": len(manifest), "manifest_sha256": sha(manifest),
                      "report_bytes": len(report), "report_lines": 316, "report_sha256": EXPECTED,
                      "exact_exclusions": EXCLUDED, "raw_receipts_verified": receipts,
                      "maximum_own_raw_stream_bytes": max_raw}))


def parent():
    assert not (LEAF / "SHA256SUMS.txt").exists()
    assert not (LEAF / "SEAL-RESULT.json").exists()
    assert (LEAF / "ROOT-READ-ACK.json").exists()
    argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--child"]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    proc = subprocess.Popen(argv, cwd="D:/GitHub/AdvancedRocketry-Community",
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timeout = False
    try:
        stdout, stderr = proc.communicate(timeout=180)
    except subprocess.TimeoutExpired:
        timeout = True
        proc.kill()
        stdout, stderr = proc.communicate()
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = {"kind": "ONE_TIME_CUSTODY_ONLY_NOT_ADOPTION_OR_QUALIFICATION",
              "argv": argv, "cwd": "D:/GitHub/AdvancedRocketry-Community",
              "utc_start": started, "utc_end": ended,
              "elapsed_seconds": time.monotonic() - start,
              "exit_code": proc.returncode, "timeout_seconds": 180,
              "timed_out": timeout, "stream_limit_bytes": 262144,
              "stream_limit_exceeded": len(stdout) > 262144 or len(stderr) > 262144,
              "stdout_bytes": len(stdout), "stdout_sha256": sha(stdout),
              "stdout_base64": base64.b64encode(stdout).decode("ascii"),
              "stderr_bytes": len(stderr), "stderr_sha256": sha(stderr),
              "stderr_base64": base64.b64encode(stderr).decode("ascii"),
              "verification": json.loads(stdout) if proc.returncode == 0 else None,
              "exact_exclusions": EXCLUDED, "excluded_from_manifest": True}
    if result["stream_limit_exceeded"]:
        raise RuntimeError("Seal child stream cap exceeded; stop and report")
    data = (json.dumps(result, indent=2) + "\n").encode("utf-8")
    assert sum(p.stat().st_size for p in LEAF.iterdir() if p.is_file()) + len(data) < 4194304
    (LEAF / "SEAL-RESULT.json").write_bytes(data)
    print(data.decode("utf-8"), end="")
    raise SystemExit(proc.returncode)


if __name__ == "__main__":
    child() if sys.argv[1:] == ["--child"] else parent()
