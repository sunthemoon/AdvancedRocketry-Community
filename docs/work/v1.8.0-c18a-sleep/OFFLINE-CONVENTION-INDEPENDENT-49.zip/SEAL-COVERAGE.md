# Task49 one-time custody coverage

The actual Root complete-read acknowledgment for the unchanged 316-line,
24827-byte REPORT at SHA256
81ed06d8e26a0999d2f2da5b7254d93c8b01da3bc10e52f33dd8bbd367f7228f
is retained verbatim in ROOT-READ-ACK.json. It authorizes own custody sealing only.
The actual operation checks report/ACK identity and every existing own raw receipt.

SHA256SUMS.txt covers every regular file present in this assigned flat leaf,
including REPORT, static helpers, unique raw receipts, the exact acknowledgment
and this coverage record. Exactly two names are excluded:

1. SHA256SUMS.txt: manifest self-reference.
2. SEAL-RESULT.json: sole later operation result containing actual child argv/cwd,
   pre-start/end UTC/exit, fixed 180-second timeout metadata, actual split stream
   lengths/SHA256/base64 and the actual manifest verification/counts.

No prefix exclusion, external mutable file or later command triple is admitted.
Safe case-unique names, regular containment and ancestor/member reparse absence
are checked. Own split streams remain <=256 KiB and aggregate evidence <=4 MiB.
Counts and result identities are established only by the actual operation.
Covered files and manifest remain immutable afterward; corrections must be
separate additive records. No historical raw streams/timestamps are fabricated.

R49-01/U01/U02, original preparation/discovery/encoding/helper-write ordering
gaps and all source/native/policy/Gate obligations remain unchanged. Custody is
not diagnostic adoption, R01 closure, a measurement-requirement change, decoder
or test assignment, resource qualification, native execution or acceptance.
