import hashlib
from pathlib import Path
import sys

names = sys.argv[1:]
start = 1
end = 1000000
if names and names[0] == "--range":
    start = int(names[1])
    end = int(names[2])
    names = names[3:]
for name in names:
    path = Path(name)
    data = path.read_bytes()
    lines = data.decode("utf-8-sig").splitlines()
    print(f"FILE {path.as_posix()} bytes={len(data)} lines={len(lines)} sha256={hashlib.sha256(data).hexdigest()}")
    for number, line in enumerate(lines, 1):
        if start <= number <= end:
            print(f"{number:04d}: {line}")
