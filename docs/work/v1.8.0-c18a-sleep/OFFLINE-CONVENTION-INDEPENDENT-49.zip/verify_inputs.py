import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat


def digest(data):
    return hashlib.sha256(data).hexdigest()


base = Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
inputs = [
    ("sleep-offline-json-core-contract-20261009-37", "1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763", 90, 649019),
    ("sleep-offline-json-core-independent-20261009-40", "56151ac5caf85fd27df961844c9debffbe85c23c5d97147a82398b121308a3e5", 140, 691694),
    ("sleep-offline-diagnostic-convention-20261009-43", "8764692b5fe5b3dc34dfde4c4a39b05786530890174485b472f47a1a5dd19bd9", 75, 307482),
    ("sleep-json-platform-counter-20261009-44", "78569fc955376069ec752f04e3523e7e425aa0fede94ca10d290f696d4f151ab", 92, 259336),
]
for name, expected_hash, expected_count, expected_size in inputs:
    leaf = base / name
    for ancestor in (leaf, *leaf.parents):
        assert not (getattr(ancestor.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT), ancestor
    manifest = (leaf / "SHA256SUMS.txt").read_bytes()
    assert digest(manifest) == expected_hash, name
    covered = {}
    for line in manifest.decode("utf-8-sig").splitlines():
        hashed, relative = line.split("  ", 1)
        relative = relative.removeprefix("*")
        pure = PurePosixPath(relative)
        assert not pure.is_absolute() and ".." not in pure.parts and "\\" not in relative and ":" not in relative, relative
        assert relative.casefold() not in {x.casefold() for x in covered}, relative
        path = leaf / relative
        assert path.is_file() and not path.is_symlink(), relative
        assert not (getattr(path.lstat(), "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT), relative
        assert path.resolve().is_relative_to(leaf.resolve()), relative
        data = path.read_bytes()
        assert digest(data) == hashed.lower(), relative
        covered[relative] = len(data)
    physical = {p.name: p.stat().st_size for p in leaf.iterdir() if p.is_file()}
    assert not any(p.is_dir() for p in leaf.iterdir()), name
    exclusions = ["SEAL-RESULT.json", "SHA256SUMS.txt"]
    if name.endswith("-44"):
        exclusions += ["custody-seal-28.command.json", "custody-seal-28.stdout.txt", "custody-seal-28.stderr.txt"]
    assert set(physical) - set(covered) == set(exclusions), name
    assert len(covered) == expected_count and sum(covered.values()) == expected_size, name
    result = json.loads((leaf / "SEAL-RESULT.json").read_bytes())
    embedded = {}
    for stream in ("stdout", "stderr"):
        if stream + "_base64" in result:
            data = base64.b64decode(result[stream + "_base64"], validate=True)
            assert len(data) == result[stream + "_bytes"], (name, stream)
            assert digest(data) == result[stream + "_sha256"], (name, stream)
            embedded[stream] = {"bytes": len(data), "sha256": digest(data)}
            if stream == "stdout":
                assert json.loads(data) == result["verification"], name
    receipt_count = 0
    failures = []
    max_stream = 0
    for path in sorted(leaf.glob("*.json")):
        meta = json.loads(path.read_bytes())
        if not isinstance(meta, dict) or "argv" not in meta:
            continue
        checked = False
        if isinstance(meta.get("streams"), list):
            for info in meta["streams"]:
                raw_path = Path(info["path"])
                assert raw_path.parent.resolve() == leaf.resolve(), raw_path
                raw = raw_path.read_bytes()
                assert len(raw) == info["bytes"] and digest(raw) == info["sha256"], raw_path
                max_stream = max(max_stream, len(raw))
            checked = True
        elif "stdout_bytes" in meta and "stdout_base64" not in meta:
            for stream in ("stdout", "stderr"):
                raw_path = path.with_suffix("." + stream)
                raw = raw_path.read_bytes()
                assert len(raw) == meta[stream + "_bytes"] and digest(raw) == meta[stream + "_sha256"], raw_path
                max_stream = max(max_stream, len(raw))
            checked = True
        elif path.name.endswith(".command.json"):
            for stream in ("stdout", "stderr"):
                raw_path = leaf / path.name.replace(".command.json", "." + stream + ".txt")
                raw = raw_path.read_bytes()
                info = meta[stream]
                assert len(raw) == info["retained_bytes"] == info["raw_bytes"], raw_path
                assert digest(raw) == info["raw_sha256"] == info["retained_sha256"], raw_path
                assert not info["overflow"], raw_path
                max_stream = max(max_stream, len(raw))
            checked = True
        if checked:
            receipt_count += 1
            code = meta.get("exit_code", meta.get("exit"))
            if code != 0:
                failures.append({"receipt": path.name, "exit": code})
            assert max_stream <= 262144, name
    print(json.dumps({"leaf": name, "manifest_bytes": len(manifest), "manifest_sha256": digest(manifest),
                      "covered_files": len(covered), "covered_bytes": sum(covered.values()),
                      "physical_files": len(physical), "physical_bytes": sum(physical.values()),
                      "exact_exclusions": sorted(exclusions), "all_covered_hashes_match": True,
                      "seal_result_sha256": digest((leaf / "SEAL-RESULT.json").read_bytes()),
                      "embedded_seal_streams": embedded, "checked_receipts": receipt_count,
                      "preserved_nonzero_receipts": failures, "maximum_checked_stream_bytes": max_stream}))
