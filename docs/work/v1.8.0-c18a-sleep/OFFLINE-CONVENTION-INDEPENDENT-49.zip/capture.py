import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import threading
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("cwd")
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
leaf = Path(__file__).resolve().parent
argv = args.argv
if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
    raise ValueError("argv must be a nonempty string array")
existing_bytes = sum(p.stat().st_size for p in leaf.iterdir() if p.is_file())
if existing_bytes + 2 * 262144 + 16384 > 4194304:
    raise RuntimeError("Own evidence admission exceeds 4 MiB reservation")
for suffix in (".command.json", ".stdout.txt", ".stderr.txt"):
    if (leaf / (args.label + suffix)).exists():
        raise FileExistsError(args.label + suffix)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
proc = subprocess.Popen(argv, cwd=args.cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
streams = {"stdout": bytearray(), "stderr": bytearray()}
seen = {"stdout": 0, "stderr": 0}
errors = []
exceeded = threading.Event()


def reader(name, pipe):
    try:
        while True:
            block = pipe.read(4096)
            if not block:
                break
            seen[name] += len(block)
            if seen[name] > 262144:
                exceeded.set()
            room = 262144 - len(streams[name])
            streams[name].extend(block[:room])
    except Exception as exc:
        errors.append(repr(exc))


threads = [threading.Thread(target=reader, args=(n, p)) for n, p in
           (("stdout", proc.stdout), ("stderr", proc.stderr))]
for thread in threads:
    thread.start()
timed_out = False
while proc.poll() is None:
    if exceeded.is_set() or time.monotonic() - start >= 180:
        timed_out = time.monotonic() - start >= 180
        proc.kill()
        break
    time.sleep(0.02)
exit_code = proc.wait()
for thread in threads:
    thread.join()
for name in streams:
    (leaf / (args.label + "." + name + ".txt")).write_bytes(streams[name])
receipt = {"argv": argv, "cwd": args.cwd, "utc_start": started,
           "utc_end": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "elapsed_seconds": time.monotonic() - start, "exit_code": exit_code,
           "timeout_seconds": 180, "stream_limit_bytes": 262144,
           "timed_out": timed_out, "stream_limit_exceeded": exceeded.is_set(),
           "reader_errors": errors,
           "streams": {n: {"raw_bytes_observed": seen[n],
                           "retained_bytes": len(streams[n]),
                           "sha256": sha(streams[n])} for n in streams}}
(leaf / (args.label + ".command.json")).write_text(
    json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
if streams["stdout"]:
    print(streams["stdout"].decode("utf-8", errors="replace"), end="")
if streams["stderr"]:
    print("STDERR:\n" + streams["stderr"].decode("utf-8", errors="replace"), end="")
if timed_out or exceeded.is_set() or errors:
    raise SystemExit(2)
raise SystemExit(exit_code)
