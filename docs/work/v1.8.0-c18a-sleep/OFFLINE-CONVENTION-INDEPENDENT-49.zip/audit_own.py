import hashlib
import json
from pathlib import Path
import sys

leaf = Path(__file__).resolve().parent
checks = []
for path in sorted(leaf.glob("*.command.json")):
    meta = json.loads(path.read_bytes())
    for stream in ("stdout", "stderr"):
        raw = (leaf / path.name.replace(".command.json", "." + stream + ".txt")).read_bytes()
        info = meta["streams"][stream]
        assert len(raw) == info["retained_bytes"] == info["raw_bytes_observed"]
        assert hashlib.sha256(raw).hexdigest() == info["sha256"]
        assert len(raw) <= 262144
    assert meta["timeout_seconds"] == 180
    assert not meta["timed_out"] and not meta["stream_limit_exceeded"] and not meta["reader_errors"]
    checks.append({"receipt": path.name, "exit_code": meta["exit_code"],
                   "stdout_bytes": meta["streams"]["stdout"]["retained_bytes"],
                   "stderr_bytes": meta["streams"]["stderr"]["retained_bytes"]})
files = [p for p in leaf.iterdir() if p.is_file()]
volume = sum(p.stat().st_size for p in files)
assert volume < 4194304
executable = Path(sys.executable)
print(json.dumps({"kind": "STATIC_RECEIPT_CUSTODY_AUDIT_NOT_DECODER_TEST",
                  "python_executable": str(executable), "version": sys.version,
                  "executable_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
                  "receipts_checked": len(checks), "all_checked_raw_hashes_match": True,
                  "preserved_nonzero_exits": [x for x in checks if x["exit_code"] != 0],
                  "files_before_current_capture": len(files), "bytes_before_current_capture": volume,
                  "largest_prior_raw_stream": max((max(x["stdout_bytes"], x["stderr_bytes"]) for x in checks), default=0),
                  "actual_commands": checks}, indent=2))
