"""Task43 custody inspection of the two named immutable input leaves."""
import base64
import hashlib
import json
import pathlib
import re
import stat

BASE = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
EXPECTED = [
    ("sleep-offline-json-core-contract-20261009-37", 90, 649019,
     "1bc82159dd724b0a2a7cb9e759d5ff4b59c61a9881d32933ea2a662ff8c06763",
     "719d27a044cc4b6e964245e6451cc09bb7d452ddd01c5a207f068cb3ebe3d38f"),
    ("sleep-offline-json-core-independent-20261009-40", 140, 691694,
     "56151ac5caf85fd27df961844c9debffbe85c23c5d97147a82398b121308a3e5",
     "df4fefb4d7ee3dde29ea75af63dc83439dd489a35854ab7fef27f4db9040a209"),
]
EXCLUDED = {"SHA256SUMS.txt", "SEAL-RESULT.json"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def no_reparse(path):
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise SystemExit("reparse/symlink boundary: " + str(part))


for name, count, volume, manifest_hash, result_hash in EXPECTED:
    root = BASE / name
    no_reparse(root)
    manifest = (root / "SHA256SUMS.txt").read_bytes()
    if len(manifest) > 65536 or digest(manifest) != manifest_hash:
        raise SystemExit("manifest identity mismatch")
    records = []
    seen = set()
    total = 0
    for line in manifest.decode("utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise SystemExit("malformed manifest line")
        sha, rel = match.groups()
        pp = pathlib.PurePosixPath(rel)
        if pp.is_absolute() or "\\" in rel or ":" in rel or any(p in ("", ".", "..") for p in rel.split("/")):
            raise SystemExit("unsafe relative member")
        if rel.casefold() in seen or rel in EXCLUDED:
            raise SystemExit("duplicate or excluded manifest member")
        seen.add(rel.casefold())
        path = root.joinpath(*pp.parts)
        no_reparse(path)
        if not path.is_file() or not path.resolve().is_relative_to(root.resolve()) or path.stat().st_size > 4 * 1024 * 1024:
            raise SystemExit("member boundary failure")
        raw = path.read_bytes()
        if digest(raw) != sha:
            raise SystemExit("member hash mismatch: " + rel)
        records.append(rel)
        total += len(raw)
        if len(records) > 512 or total > 4 * 1024 * 1024:
            raise SystemExit("bounded input inventory exceeded")
    actual = []
    actual_bytes = 0
    for path in root.rglob("*"):
        no_reparse(path)
        if path.is_file():
            actual.append(path.relative_to(root).as_posix())
            actual_bytes += path.stat().st_size
        if len(actual) > 512:
            raise SystemExit("actual input inventory exceeds bound")
    if set(actual) - set(records) != EXCLUDED or set(records) - set(actual):
        raise SystemExit("actual manifest exclusions differ")
    if len(records) != count or total != volume:
        raise SystemExit("actual coverage differs")
    raw_result = (root / "SEAL-RESULT.json").read_bytes()
    if digest(raw_result) != result_hash or len(raw_result) > 8192:
        raise SystemExit("seal result identity mismatch")
    result = json.loads(raw_result)
    if result.get("exit_code", result.get("exit")) != 0 or result.get("timed_out", False):
        raise SystemExit("input seal did not succeed")
    if result["timeout_seconds"] != 180 or result["stream_limit_bytes"] != 262144:
        raise SystemExit("input seal command limits differ")
    for stream in ("stdout", "stderr"):
        raw = base64.b64decode(result[stream + "_base64"], validate=True)
        if len(raw) != result[stream + "_bytes"] or len(raw) > 262144 or digest(raw) != result[stream + "_sha256"]:
            raise SystemExit("input seal embedded stream mismatch")
    verification = result["verification"]
    if verification["covered_files"] != count or verification["covered_bytes"] != volume or not verification["all_covered_match"]:
        raise SystemExit("input seal coverage claim differs")
    if verification["manifest_sha256"] != manifest_hash or set(verification["excluded"]) != EXCLUDED:
        raise SystemExit("input seal manifest/exclusion claim differs")
    print(json.dumps({"leaf": str(root), "covered_files": count, "covered_bytes": total,
                      "manifest_bytes": len(manifest), "manifest_sha256": digest(manifest),
                      "result_bytes": len(raw_result), "result_sha256": digest(raw_result),
                      "whole_leaf_files": len(actual), "whole_leaf_bytes": actual_bytes,
                      "exact_exclusions": sorted(EXCLUDED), "all_covered_match": True,
                      "embedded_streams_match": True, "safe_unique_regular_contained_no_reparse": True}))
