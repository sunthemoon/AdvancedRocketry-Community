# Task43 one-time custody coverage

The manifest covers every regular file in this exclusive flat evidence leaf
except exactly SHA256SUMS.txt self and the sole later SEAL-RESULT.json. No prefix,
external mutable file, runtime/build/world output or directory is a member.
The seal result retains actual child argv/cwd/UTC/exit, 180-second watchdog and
split stream lengths/hashes/base64. Streams remain <=256 KiB and leaf <=4 MiB.
Coverage counts and final identities are determined by the actual seal execution,
not this prospective coverage description.

Root's actual complete final proposal/report read acknowledgement is recorded
verbatim in ROOT-READ-ACK.json and checked against the final bytes before sealing.
No original report/proposal or historical input is changed. Preparation bootstrap,
quoting, discovery01 unretained over-cap nested output, pre-clarification48
continuation and inner-receipt limitations remain as disclosed in REPORT.md.
Later custody does not retroactively establish full command-limit compliance.
The candidate remains PROPOSED; no adoption, implementation/test/resource/native/
runtime/production, diagnostic waiver, R-021 or Gate authority follows this seal.
