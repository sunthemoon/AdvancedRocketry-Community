"""One-time Task43 custody seal after Root's exact final-document read."""
import base64
import datetime
import hashlib
import json
import pathlib
import stat
import subprocess
import sys
import threading
import time

ROOT = pathlib.Path(__file__).resolve().parent
EXCLUDED = {"SHA256SUMS.txt", "SEAL-RESULT.json"}
LIMIT = 262144
AGGREGATE = 4194304
CWD = "D:/GitHub/AdvancedRocketry-Community"
sys.stdout.reconfigure(encoding="utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def child():
    for p in (ROOT, *ROOT.parents):
        info = p.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise SystemExit("reparse ancestor")
    if any((ROOT / name).exists() for name in EXCLUDED):
        raise SystemExit("seal already exists")
    ack = json.loads((ROOT / "ROOT-READ-ACK.json").read_bytes())
    if not ack["custody_permission_only"]:
        raise SystemExit("absent custody-only acknowledgement")
    documents = []
    for name, prefix in (("REPORT.md", "report"), ("PROPOSED-DIAGNOSTIC-CONVENTION-01.md", "proposal")):
        raw = (ROOT / name).read_bytes()
        if (len(raw), len(raw.decode().splitlines()), sha(raw)) != (ack[prefix + "_bytes"], ack[prefix + "_lines"], ack[prefix + "_sha256"]):
            raise SystemExit("final document differs from Root read")
        documents.append({"path": name, "bytes": len(raw), "lines": len(raw.decode().splitlines()), "sha256": sha(raw)})
    files = sorted(ROOT.iterdir(), key=lambda p: p.name)
    if len(files) > 256:
        raise SystemExit("own bounded file inventory exceeded")
    names = set()
    entries = []
    total = 0
    for p in files:
        info = p.lstat()
        if not stat.S_ISREG(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise SystemExit("nonregular or reparse own member")
        if p.name.casefold() in names or any(c in p.name for c in ("/", "\\", ":", "\n", "\r")):
            raise SystemExit("unsafe or duplicate own name")
        names.add(p.name.casefold())
        raw = p.read_bytes()
        entries.append((sha(raw), p.name))
        total += len(raw)
    manifest = "".join(digest + "  " + name + "\n" for digest, name in entries).encode()
    if total + len(manifest) + 8192 > AGGREGATE:
        raise SystemExit("insufficient final aggregate headroom")
    with (ROOT / "SHA256SUMS.txt").open("xb") as out:
        out.write(manifest)
    for digest, name in entries:
        if sha((ROOT / name).read_bytes()) != digest:
            raise SystemExit("covered member changed")
    print(json.dumps({"all_covered_match": True, "covered_files": len(entries), "covered_bytes": total,
                      "manifest_bytes": len(manifest), "manifest_sha256": sha(manifest),
                      "documents": documents, "excluded": sorted(EXCLUDED)}, sort_keys=True))


if sys.argv[1:] == ["--child"]:
    child()
    raise SystemExit(0)
if sys.argv[1:]:
    raise SystemExit("unexpected seal argument")
if any((ROOT / name).exists() for name in EXCLUDED):
    raise SystemExit("one-time seal refuses existing artifacts")
argv = [sys.executable, "-B", str(pathlib.Path(__file__).resolve()), "--child"]
started = utc()
begin = time.monotonic()
proc = subprocess.Popen(argv, cwd=CWD, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
buffers = [bytearray(), bytearray()]
overflow = threading.Event()


def drain(stream, target):
    while True:
        data = stream.read(4096)
        if not data:
            break
        room = LIMIT - len(target)
        target.extend(data[:room])
        if len(data) > room:
            overflow.set()
            proc.kill()
            break


threads = [threading.Thread(target=drain, args=(stream, target))
           for stream, target in zip((proc.stdout, proc.stderr), buffers)]
for thread in threads:
    thread.start()
timed_out = False
try:
    proc.wait(timeout=180)
except subprocess.TimeoutExpired:
    timed_out = True
    proc.kill()
    proc.wait()
for thread in threads:
    thread.join(timeout=5)
if any(thread.is_alive() for thread in threads):
    raise SystemExit("own seal stream drain failed")
result = {"kind": "actual-one-time-custody-seal-not-adoption-or-qualification",
          "argv": argv, "cwd": CWD, "start_utc": started, "end_utc": utc(),
          "elapsed_seconds": time.monotonic() - begin, "exit_code": proc.returncode,
          "timeout_seconds": 180, "timed_out": timed_out, "output_limit_exceeded": overflow.is_set(),
          "stream_limit_bytes": LIMIT, "excluded_from_manifest": True}
for name, raw in zip(("stdout", "stderr"), buffers):
    result[name + "_bytes"] = len(raw)
    result[name + "_sha256"] = sha(raw)
    result[name + "_base64"] = base64.b64encode(raw).decode("ascii")
if proc.returncode == 0 and not timed_out and not overflow.is_set():
    result["verification"] = json.loads(buffers[0])
raw_result = (json.dumps(result, indent=2) + "\n").encode()
if len(raw_result) > 8192:
    raise SystemExit("bounded seal result exceeded")
with (ROOT / "SEAL-RESULT.json").open("xb") as out:
    out.write(raw_result)
files = [p for p in ROOT.iterdir() if p.is_file()]
volume = sum(p.stat().st_size for p in files)
print(json.dumps({"result_bytes": len(raw_result), "result_sha256": sha(raw_result),
                  "whole_leaf_files": len(files), "whole_leaf_bytes": volume,
                  "verification": result.get("verification"), "exit_code": proc.returncode}))
if timed_out or overflow.is_set() or volume > AGGREGATE:
    raise SystemExit("actual seal limit unmet")
raise SystemExit(proc.returncode)
