# Offline JSON core diagnostic convention candidate 01

Date: 2026-10-09 UTC. Status: **PROPOSED; NOT ADOPTED OR IMPLEMENTED**.
This additive Task43 candidate answers independent40 R01 for the actual Task37
API. Root and a separate independent review must disposition it. The old proposal
and review remain immutable. No decoder, generated payload or test is supplied.

## 1. Basis and unchanged boundaries

Fixed governance: `b0b818261621d6c607386925535a62f027dfbf8b`.
Observation source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Task37 governance remains historical 9edbcab9; review40 remains historical cd9b54a2.
The exact Task37 proposal is 19096 bytes /271 lines, SHA256
`f3658d5c631a04dfc6e053883f6ab56843fc441e163d78561f86041a862ee6f0`.
The exact review40 REPORT is 18632 bytes /280 lines, SHA256
`aea5da915c1c7c2e059d2b624ef55dfae831291d8633018b0889f8ad72b95f60`.
R01 at review40 lines 9-30 asks for an input-type sentinel and precise reservation,
partial-token and consumption accounting, without changing admission or limits.

The prospective `decode_payload(payload: bytes, *, deadline_ns: int)` signature,
Decoded/Refused/DecodeMetrics/DecodeError/JsonNumber shapes and fixed refusal codes
stay unchanged. Input remains exact built-in immutable bytes, compact object root,
canonical scalar-only UTF-8, paired surrogate escapes and no repair/normalization.
Numbers remain inert lexemes; no int/float/Decimal conversion is added.
Inclusive caps stay 524288 bytes, 65536 nodes/global names, 64 names/object and
container depth, 4096 UTF-16 units/string or name, 64 ASCII bytes/number.
The existing cooperative absolute <=60-second deadline and 180-second external
ceiling stay unchanged; streams <=256 KiB, evidence <=4 MiB, resource ceilings
<=256 MiB stay separate and unqualified. This is diagnostic precision, not a new
resource, input, clock, platform-helper, source-schema or runtime policy.

## 2. D43-01: preflight precedence and sentinels

Take the existing entry monotonic-clock sample once as `t0`. Before any scan,
decoded buffer, node, key or container allocation, stop at the first failed step:

1. Check `type(payload) is bytes`. Otherwise return INPUT_TYPE. Do not call len,
   bytes, repr, iteration, indexing, equality or any rejected object's method.
2. For exact bytes, obtain its built-in length once as `n`; set input_bytes=n.
   If n>524288, return INPUT_BYTES before checking deadline arguments or content.
3. Check `type(deadline_ns) is int`, excluding bool and subclasses. An invalid
   type, or an exact integer greater than t0+60000000000, is DEADLINE_ARGUMENT.
   Do not coerce, stringify or calculate a remaining-time diagnostic from it.
4. If the exact deadline is <=t0, return DEADLINE. Otherwise scanning may begin.

INPUT_TYPE returns all seven metrics as integer zero, byte_offset=0, empty root
location, name_span=None and limit_name/limit/observed=None. The zero input_bytes
is a diagnostic sentinel, not a claim that the rejected object is an empty buffer.
Every other preflight refusal retains actual n as input_bytes and sets the other
six metrics to zero; byte_offset=0, location empty, name_span=None. INPUT_BYTES
alone has limit_name="input_bytes", limit=524288, observed=n. Obtaining the exact
built-in length observes the caller's whole supplied buffer without scanning its
tail. It is not fabricated token work. Oversized refused input_bytes is not
clamped to the admitted cap. Deadline refusals have no limit fields.

No root/key/value token is reserved during preflight. Unsupported root, leading
BOM, leading whitespace and empty-input lexical failures likewise reserve no
node/name and consume no bytes. Their existing Task37 lexical codes are retained.
This order intentionally reports oversized malformed bytes as INPUT_BYTES and
does not invoke rejected-object hooks to manufacture diagnostic data.

## 3. D43-02: admission reservations, not completed-token counts

`nodes` and `names` count successful admission reservations in this call, including
a later incomplete or malformed token. They are not counts of a returned tree.
The seven metrics are snapshotted at refusal, then partial objects/scratch are
discarded without decrementing that snapshot. No partial tree is returned.

A reservation attempt occurs only in a grammar-permitted value/key slot with a
recognized introducer. Object/array/string, numeric-minus/digit and literal
initials are value introducers; a name requires an opening double quote. Invalid
slot punctuation, an unsupported root or an unrecognized value initial does not
reserve an invented token. A legal empty-container close reserves nothing new.
A recognized literal/number/string initial may reserve a node even though its
remaining spelling later fails. Names themselves are not value nodes.

At one value admission, perform the existing pre-allocation deadline check, then
the proposed nodes+1 guard, then (only for a container) the proposed depth+1 guard.
Only if all pass, atomically commit nodes+1 and any container entry/max-depth
update, before constructing/attaching/pushing or consuming the introducer. A DEPTH
failure therefore does not increment nodes for the refused container. NODES has
precedence if both guards would fail. Scalar admission does not change depth.

At one key admission, perform the existing deadline check, then local object's
proposed names+1 guard, then whole-call proposed names+1 guard. Only if both pass,
atomically commit both reservations before decoding/consuming the opening quote.
OBJECT_NAMES precedes NAMES if both would fail. A rejected admission changes
neither counter. A successfully reserved duplicate or malformed key counts in
names and the object's private reservation count, even if never inserted. A
duplicate's associated value is not reserved or decoded.

Member ordinals use the object's prior local reservation count: first attempted
member is 0, the next is 1, and an attempted 65th is 64. Array element ordinals use
the next element index. Successful lexical completion or attachment does not
increment a reservation counter again. Closing a container never subtracts nodes
or names; max_container_depth is the greatest successfully admitted entry depth.
Root object admission counts node 1 and depth 1, even if its later syntax fails.
The successful-tree names<=nodes-1 relation is not asserted for refusal snapshots:
an admitted malformed/duplicate name may have no admitted value.

## 4. D43-03: committed cursor and bounded lookahead

Let `c` start at 0. consumed_bytes is exactly the contiguous original-byte prefix
length committed by the scanner, namely c, not the furthest inspected offset.
Successful return requires c=n. Never add inspected-but-uncommitted bytes, clamp
c to an error offset, or retroactively subtract already committed valid prefixes.

Advance c only for successfully admitted token introducers, valid punctuation,
literal characters matched in order, number-prefix characters accepted by the
finite-state number grammar, valid string scalar atoms, and closing quotes.
A scalar atom is one raw canonical UTF-8 scalar, one ordinary JSON escape, one
non-surrogate Unicode escape, or one complete high/low escaped surrogate pair.
Validate the whole atom using bounded lookahead, and check its UTF-16 admission,
before committing any bytes or decoded units of that atom. An invalid/truncated
atom commits none of its inspected bytes. Do not admit a lone high surrogate
temporarily while waiting for its partner. Lookahead remains bounded scratch,
not a token list or a decoded full-input copy.

An unexpected separator/byte, outside-string whitespace, illegal numeric next
character or trailing byte is not committed. A number grammar prefix may end
in an incomplete sign/fraction/exponent state; its already accepted prefix bytes
stay consumed if the next character or EOF fails grammar. An illegal character
is not counted as a prospective numeric byte, even after a 64-byte prefix.
A legal numeric-prefix continuation that would become byte 65 is NUMBER_BYTES
before retaining/committing that byte. A valid complete key consumes its closing
quote before duplicate comparison; the duplicate's colon/value remain untouched.

Consequently, malformed UTF-8/escape/surrogate errors may point at c, while a
string/number bound can point back to its token's opening offset with c later in
the token. An error offset and consumed_bytes intentionally need not be equal.
Inspecting several bytes to identify an invalid atom does not increase c.

## 5. D43-04: maxima for admitted partial prefixes

max_string_utf16_units is the greatest admitted decoded-prefix length of any
reserved name/value string, completed or not. Each new string starts a private
unit count at 0. After validating one scalar atom, calculate current_units+width
(BMP width 1, supplementary width 2). If it exceeds 4096, refuse before extending
the buffer or committing that atom; otherwise commit the units and update the
maximum. Invalid UTF-8/escapes or a rejected surrogate pair add zero units. Empty
strings keep the maximum unchanged. A duplicate's complete reserved name can
contribute to the maximum even though it is not inserted. There is no decoded
prefix contribution from an admission refused before its opening quote.

max_number_bytes is the greatest retained grammar-prefix length of any reserved
number, completed or not. Accepted sign, digits, decimal point, exponent marker
and exponent sign each add one ASCII byte, even before the grammar is complete.
Check <=64 before retaining/committing each such character, then update the
maximum. A malformed suffix/EOF does not erase the prefix maximum; an illegal
next character adds zero. Neither metric is the longest scanned tail or the
length of the last successfully completed token. Neither may exceed its cap.

For any bound refusal, unchanged counters/maxima report admitted work; observed
reports only the first attempted over-limit quantity. It is not the metric after
an overflowing increment and not a whole-input inventory:

| Code | Fixed limit_name /limit | observed |
|---|---|---|
| INPUT_BYTES | input_bytes /524288 | Exact built-in supplied-buffer length n. |
| NODES | nodes /65536 | Current reserved nodes+1. |
| NAMES | names /65536 | Current global reserved names+1. |
| OBJECT_NAMES | object_names /64 | Current local reserved names+1. |
| DEPTH | container_depth /64 | Current active depth+1. |
| STRING_UNITS | string_utf16_units /4096 | Current token's admitted units plus the validated scalar width; can be 4097 or 4098. |
| NUMBER_BYTES | number_bytes /64 | Current admitted numeric-prefix length+1, namely 65. |

All other codes have limit_name/limit/observed=None. No key text, numeric magnitude,
unscanned-tail count, deadline value, payload excerpt or traceback is included.

## 6. D43-05: error offsets, spans and ordinal ownership

Preserve Task37's offset rule: EOF uses n; malformed UTF-8 uses the leading
offending byte; invalid escape/surrogate uses its introducing backslash; a
node/name/container/string/number bound uses the introducing token. Duplicate
uses the duplicate key's opening quote. Other lexical/structural refusals use
the unexpected byte at c (or n for EOF); this addendum does not reclassify their
existing refusal codes. Preflight offsets are the sentinel 0 described above.

Location is the ordinal trail of the owning container plus the pending slot's
member/element ordinal for a key, colon, value, or admission/token failure. A
separator/close/trailing-data failure after a completed slot belongs to that
container, without an invented next slot; if a comma has already opened a new
required slot, the new pending ordinal applies. Root/preflight/trailing bytes
after the root use the empty trail. Member names never appear in location.
The trail to an admitted depth-64 container has 63 edges, so its attempted slot,
including a depth-65 refusal, has at most 64 ordinal segments. Do not append an
extra segment for a quote/scalar or truncate an overlong location after building it.

name_span, when present, is a half-open original-byte interval, including any
committed opening/closing quotes: 0<=start<end<=n. During a reserved key's lexical
failure it is [opening_quote,c); the opening quote has been committed, but no
closing quote or rejected lookahead is invented. For duplicate detection it is
the completed key's full quoted span. Before key admission, name_span=None.
For a direct object's colon/value/admission failure, use that member's completed
key span. For an array element, container separator/close, root or preflight
failure, name_span=None; do not reuse a stale outer-object key. Inside a nested
object, its own pending member controls the span, not an ancestor's name.
Spans contain offsets only and do not copy or decode the referenced bytes.

At any existing cooperative deadline checkpoint, snapshot the same counters and
c without an additional scan or partial-token completion. byte_offset=c; location
and any name_span follow the owning pending slot above. At preflight they are
zero/empty/None; before successful return they are n/empty/None. All limit fields
are None. Clearing partial work does not reset the returned metrics.
Actual wall-clock scheduling/checkpoint timing is not reproducible byte timing.
This addendum fixes a checkpoint's diagnostic state, not new clock callbacks or
an exact optional-check cadence; Task37's required check points remain mandatory.

## 7. Verification dependency, not executed evidence

A later explicitly assigned bounded implementation/test slice must independently
assert the complete metrics and DecodeError fields, not just a refusal code:

- Preflight: each rejected input type without invoking its methods; sentinel zero;
  exact-byte oversized/malformed and invalid/expired/too-far deadline precedence;
  actual oversized input length with no scan or token allocation.
- Reservation: completed versus malformed/incomplete value/key/literal/number;
  root reservation; no token for unrecognized initials or legal empty closure;
  duplicate counts name but not value; atomic failed node/depth and local/global
  name admissions, preserving prior admitted counters and tie precedence.
- Cursor/maxima: mid-string malformed UTF-8/escape/pair and EOF; admitted valid
  prefixes followed by invalid atoms; valid supplementary width crossing the
  UTF-16 cap; incomplete numeric prefixes, illegal suffix versus legal byte 65;
  duplicate closing quote versus untouched colon; syntax and trailing lookahead.
- Locations/spans: incomplete and complete key intervals; direct member versus
  nested object/array ownership; comma-opened pending slots versus separators;
  depth-64 trail and depth-65 attempted slot; error offset distinct from c.
- Deadline: private controlled clock readings at required pre-allocation/mid-scan/
  pre-return points, with no public hook and no new enclosing-budget reset.

Task37's at-limit/one-over/resource families and <=12 fresh resource cases remain
the proposed finite plan; this addendum adds assertions to relevant cases, not
more process cases or relaxed budgets. The global-name guard is still dominated
for successful end-to-end trees; seeded bounded private-counter checks are not
native traces or fabricated accepted payloads. Allocation/RSS, latency, platform
counter availability/units and failure after OOM remain unqualified.

Every row above is **NOT_EXECUTED**. No generated fixture, prototype, decoder,
platform measurement, source-schema/Gson conversion, framing/capture/NBT/log
implementation or runtime invocation is created or assigned. Root/fresh review
must decide this additive convention and candidate37 before executable work.
Diagnostic precision does not prove native Unicode, twenty observation rows,
D1's thirteen rows, production sleep/air/natural/spawn/time, R-021 acceptance,
clean-log exceptions or Gates. **All current v1.8 Required Gates satisfied: NO.**
