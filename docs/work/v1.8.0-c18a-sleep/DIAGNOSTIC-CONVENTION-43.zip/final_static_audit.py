"""Inspect own static evidence and actual tool identity; no decoder/tests."""
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
LIMIT = 262144


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


receipts = []
maximum = 0
for path in sorted(ROOT.glob("*.receipt.json")):
    data = json.loads(path.read_bytes())
    if data["timeout_seconds"] != 180 or data["stream_limit_bytes"] != LIMIT:
        raise SystemExit("receipt limit mismatch")
    if data["timed_out"] or data["output_limit_exceeded"]:
        raise SystemExit("captured outer limit unmet")
    for stream in data["streams"]:
        p = pathlib.Path(stream["path"])
        if p.parent.resolve() != ROOT or p.stat().st_size > LIMIT:
            raise SystemExit("own stream boundary failure")
        raw = p.read_bytes()
        if len(raw) != stream["bytes"] or sha(raw) != stream["sha256"]:
            raise SystemExit("own raw stream identity mismatch")
        maximum = max(maximum, len(raw))
    receipts.append({"receipt": path.name, "exit_code": data["exit_code"],
                     "argv": data["argv"], "stdout_bytes": data["streams"][0]["bytes"],
                     "stderr_bytes": data["streams"][1]["bytes"]})
files = sorted(p for p in ROOT.iterdir() if p.is_file())
volume = sum(p.stat().st_size for p in files)
if volume > 4 * 1024 * 1024:
    raise SystemExit("own aggregate bound unmet")
print(json.dumps({"python_executable": sys.executable, "python_version": sys.version,
                  "python_executable_sha256": sha(pathlib.Path(sys.executable).read_bytes()),
                  "pre_capture_files": len(files), "pre_capture_bytes": volume,
                  "verified_prior_receipts": len(receipts), "maximum_prior_stream_bytes": maximum,
                  "preparation_full_compliance_not_established": True}))
for record in receipts:
    print(json.dumps(record))
for name in ("PROPOSED-DIAGNOSTIC-CONVENTION-01.md", "REPORT.md"):
    path = ROOT / name
    if path.exists():
        raw = path.read_bytes()
        print(json.dumps({"path": str(path), "bytes": len(raw), "lines": len(raw.decode().splitlines()), "sha256": sha(raw)}))
for argv in ([] if sys.argv[1:] == ["--documents-only"] else (["git", "status", "--short"], ["git", "rev-parse", "HEAD"])):
    result = subprocess.run(argv, capture_output=True, timeout=30)
    if len(result.stdout) > LIMIT or len(result.stderr) > LIMIT:
        raise SystemExit("focused Git stream bound unmet")
    print(json.dumps({"argv": argv, "exit": result.returncode,
                      "stdout_bytes": len(result.stdout), "stdout_sha256": sha(result.stdout),
                      "stderr_bytes": len(result.stderr), "stderr_sha256": sha(result.stderr)}))
    if result.returncode:
        raise SystemExit(result.returncode)
    if argv[1] == "rev-parse":
        print("ACTUAL_HEAD", result.stdout.decode().strip())
