"""Task43 static inspection receipts, not a decoder or test runner."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import threading
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = pathlib.Path(__file__).resolve().parent
LIMIT = 256 * 1024
AGGREGATE = 4 * 1024 * 1024
TIMEOUT = 180
CWD = "D:/GitHub/AdvancedRocketry-Community"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


label, *argv = sys.argv[1:]
if not label or not argv or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in label):
    raise SystemExit("invalid receipt label or absent argv")
paths = [ROOT / (label + suffix) for suffix in (".stdout.txt", ".stderr.txt", ".receipt.json")]
if any(p.exists() for p in paths):
    raise SystemExit("receipt already exists")
if sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file()) + 2 * LIMIT + 8192 > AGGREGATE:
    raise SystemExit("insufficient aggregate receipt headroom")
started = utc()
start = time.monotonic()
proc = subprocess.Popen(argv, cwd=CWD, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
buffers = [bytearray(), bytearray()]
overflow = threading.Event()


def read(stream, target):
    while True:
        chunk = stream.read(4096)
        if not chunk:
            break
        remaining = LIMIT - len(target)
        target.extend(chunk[:remaining])
        if len(chunk) > remaining:
            overflow.set()
            proc.kill()
            break


threads = [threading.Thread(target=read, args=(stream, target))
           for stream, target in zip((proc.stdout, proc.stderr), buffers)]
for thread in threads:
    thread.start()
timed_out = False
try:
    proc.wait(timeout=TIMEOUT)
except subprocess.TimeoutExpired:
    timed_out = True
    proc.kill()
    proc.wait()
for thread in threads:
    thread.join(timeout=5)
if any(thread.is_alive() for thread in threads):
    raise SystemExit("stream drain failed; stop inspection")
for path, data in zip(paths, buffers):
    with path.open("xb") as out:
        out.write(data)
receipt = {
    "argv": argv, "cwd": CWD, "start_utc": started, "end_utc": utc(),
    "elapsed_seconds": time.monotonic() - start, "exit_code": proc.returncode,
    "timeout_seconds": TIMEOUT, "timed_out": timed_out,
    "output_limit_exceeded": overflow.is_set(), "stream_limit_bytes": LIMIT,
    "aggregate_limit_bytes": AGGREGATE,
    "streams": [{"path": str(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
                for p, b in zip(paths, buffers)],
}
with paths[2].open("x", encoding="utf-8", newline="\n") as out:
    json.dump(receipt, out, ensure_ascii=True, indent=2)
    out.write("\n")
print(json.dumps(receipt, ensure_ascii=True))
for stream, data in zip(("stdout", "stderr"), buffers):
    print("=== " + stream + " ===")
    print(data.decode("utf-8", errors="replace"))
if overflow.is_set() or timed_out:
    raise SystemExit("command limit reached; stop and report")
raise SystemExit(proc.returncode)
