"""Task43 bounded read-only document inspection; no payload or decoder execution."""
import hashlib
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
MAIN = "b0b818261621d6c607386925535a62f027dfbf8b"
BASE = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")
LIMIT = 180000


def git(*args):
    result = subprocess.run(["git", *args], capture_output=True, timeout=30)
    if result.returncode:
        raise SystemExit(result.stderr.decode("utf-8", "replace"))
    if len(result.stdout) > 256 * 1024 or len(result.stderr) > 256 * 1024:
        raise SystemExit("nested static Git stream cap exceeded")
    return result.stdout


def display(identity, raw, start=None, end=None):
    if len(raw) > LIMIT:
        raise SystemExit("document exceeds inspection size")
    lines = raw.decode("utf-8").splitlines()
    print("DOCUMENT", identity, "BYTES", len(raw), "LINES", len(lines),
          "SHA256", hashlib.sha256(raw).hexdigest())
    if start is None:
        print(raw.decode("utf-8"))
    else:
        print("RANGE", start, end)
        for i in range(start - 1, min(end, len(lines))):
            print(str(i + 1) + ": " + lines[i])


mode = sys.argv[1]
if mode == "git-docs":
    for path in sys.argv[2:]:
        display(MAIN + ":" + path, git("show", MAIN + ":" + path))
elif mode == "git-lines":
    path, start, end = sys.argv[2:]
    display(MAIN + ":" + path, git("show", MAIN + ":" + path), int(start), int(end))
elif mode == "file-lines":
    path, start, end = sys.argv[2:]
    display(path, pathlib.Path(path).read_bytes(), int(start), int(end))
elif mode == "files":
    for path in sys.argv[2:]:
        display(path, pathlib.Path(path).read_bytes())
elif mode == "paths":
    for path in git("ls-tree", "-r", "--name-only", MAIN, "docs/work/v1.8.0-c18a-sleep").decode().splitlines():
        if (path.startswith("docs/work/v1.8.0-c18a-sleep/") and path.endswith(".md")) or ("OWNER" in path) or ("owner" in path):
            print(path)
    for name in ("sleep-offline-json-core-contract-20261009-37", "sleep-offline-json-core-independent-20261009-40"):
        for path in sorted((BASE / name).iterdir()):
            if path.name in ("SHA256SUMS.txt", "SEAL-RESULT.json", "REPORT.md") or "ACK" in path.name:
                print(path, path.stat().st_size)
else:
    raise SystemExit("unknown static inspection mode")
