"""One-time Task37 custody seal, only after the actual Root acknowledgement."""
import base64
import datetime
import hashlib
import json
import pathlib
import stat
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = pathlib.Path(__file__).resolve().parent
MANIFEST = ROOT / "SHA256SUMS.txt"
RESULT = ROOT / "SEAL-RESULT.json"
EXCLUSIONS = {"SHA256SUMS.txt", "SEAL-RESULT.json"}
STREAM_LIMIT = 262144
LEAF_LIMIT = 4194304


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe(path):
    for item in (path, *path.parents):
        s = item.lstat()
        if stat.S_ISLNK(s.st_mode) or getattr(s, "st_file_attributes", 0) & 0x400:
            raise ValueError("reparse/symlink member or ancestor")


def seal_child():
    if MANIFEST.exists() or RESULT.exists():
        raise ValueError("seal/result already exists; never overwrite")
    safe(ROOT)
    acknowledgement = json.loads((ROOT / "ROOT-READ-ACK.json").read_text(encoding="utf-8"))
    identities = []
    for name, prefix in (("REPORT.md", "report"), ("PROPOSED-OFFLINE-JSON-CORE-01.md", "proposal")):
        raw = (ROOT / name).read_bytes()
        if len(raw) != acknowledgement[prefix + "_bytes"] or sha(raw) != acknowledgement[prefix + "_sha256"]:
            raise ValueError("final document changed after Root reading")
        identities.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
    paths = []
    folded = set()
    for path in sorted(ROOT.rglob("*")):
        safe(path)
        if path.is_dir():
            continue
        if not path.is_file() or not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError("nonregular or external member")
        name = path.relative_to(ROOT).as_posix()
        if ":" in name or "\\" in name or any(p in ("", ".", "..") for p in pathlib.PurePosixPath(name).parts) or name.casefold() in folded:
            raise ValueError("unsafe/case-duplicate relative name")
        folded.add(name.casefold())
        if name in EXCLUSIONS:
            raise ValueError("unexpected pre-existing excluded member")
        if path.stat().st_size > STREAM_LIMIT:
            raise ValueError("own file exceeds conservative stream-sized file bound")
        raw = path.read_bytes()
        paths.append((name, raw))
        if name.endswith(".receipt.json"):
            receipt = json.loads(raw)
            for stream in receipt["streams"]:
                target = pathlib.Path(stream["path"])
                if target.parent.resolve() != ROOT.resolve():
                    raise ValueError("receipt points outside leaf")
                stream_raw = target.read_bytes()
                if len(stream_raw) != stream["bytes"] or sha(stream_raw) != stream["sha256"]:
                    raise ValueError("captured stream changed")
    manifest_bytes = "".join(sha(raw) + "  " + name + "\n" for name, raw in paths).encode("ascii")
    total = sum(len(raw) for name, raw in paths)
    if total + len(manifest_bytes) + 65536 > LEAF_LIMIT or len(manifest_bytes) > STREAM_LIMIT:
        raise ValueError("seal/result evidence headroom exceeded")
    with MANIFEST.open("xb") as out:
        out.write(manifest_bytes)
    for name, raw in paths:
        if (ROOT / name).read_bytes() != raw:
            raise ValueError("member changed during seal")
    if MANIFEST.read_bytes() != manifest_bytes:
        raise ValueError("manifest readback changed")
    print(json.dumps({"covered_files": len(paths), "covered_bytes": total,
        "manifest_bytes": len(manifest_bytes), "manifest_sha256": sha(manifest_bytes),
        "all_covered_match": True, "documents": identities,
        "excluded": sorted(EXCLUSIONS)}, sort_keys=True))


if sys.argv[1:] == ["--child"]:
    seal_child()
    raise SystemExit(0)
if sys.argv[1:]:
    raise SystemExit("no arguments allowed for seal controller")
if MANIFEST.exists() or RESULT.exists():
    raise SystemExit("seal already attempted/completed; no retry")
argv = [sys.executable, "-B", str(pathlib.Path(__file__).resolve()), "--child"]
started = utc()
start = time.monotonic()
timed_out = False
try:
    child = subprocess.run(argv, cwd="D:/GitHub/AdvancedRocketry-Community", capture_output=True, timeout=180)
    code, stdout, stderr = child.returncode, child.stdout, child.stderr
except subprocess.TimeoutExpired as failure:
    timed_out = True
    code, stdout, stderr = None, failure.stdout or b"", failure.stderr or b""
ended = utc()
if len(stdout) > STREAM_LIMIT or len(stderr) > STREAM_LIMIT:
    raise SystemExit("unexpected seal stream overflow; stop without retry")
verification = json.loads(stdout.decode("utf-8")) if code == 0 else None
result = {
    "kind": "actual-one-time-static-custody-seal-not-adoption-or-qualification",
    "argv": argv, "cwd": "D:/GitHub/AdvancedRocketry-Community", "start_utc": started,
    "end_utc": ended, "elapsed_seconds": time.monotonic() - start, "exit_code": code,
    "timeout_seconds": 180, "timed_out": timed_out, "stream_limit_bytes": STREAM_LIMIT,
    "stdout_bytes": len(stdout), "stderr_bytes": len(stderr), "stdout_sha256": sha(stdout),
    "stderr_sha256": sha(stderr), "stdout_base64": base64.b64encode(stdout).decode("ascii"),
    "stderr_base64": base64.b64encode(stderr).decode("ascii"), "verification": verification,
    "excluded_from_manifest": True,
}
encoded = (json.dumps(result, indent=2, ensure_ascii=True) + "\n").encode("ascii")
if sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file()) + len(encoded) > LEAF_LIMIT:
    raise SystemExit("post-seal result exceeds leaf budget; stop without retry")
with RESULT.open("xb") as out:
    out.write(encoded)
print(json.dumps({"result_path": str(RESULT), "result_bytes": len(encoded), "result_sha256": sha(encoded),
    "leaf_files": sum(1 for p in ROOT.rglob("*") if p.is_file()),
    "leaf_bytes": sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file()),
    "verification": verification, "exit_code": code, "timed_out": timed_out}, sort_keys=True))
raise SystemExit(0 if code == 0 else 1)
