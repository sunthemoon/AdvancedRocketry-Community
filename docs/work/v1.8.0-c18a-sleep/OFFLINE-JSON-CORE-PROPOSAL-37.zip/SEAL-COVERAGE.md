# Task37 one-time static custody coverage

The actual Root acknowledgement in ROOT-READ-ACK.json confirms complete reading
of the exact final 225-line REPORT and 271-line proposal, with their byte counts
and SHA256 identities. It authorizes only this leaf's one-time custody seal.
It does not adopt/freeze the candidate or authorize decoder/tests/runtime work.

The manifest covers every existing regular file in this exclusive leaf,
including the acknowledgement, helpers, raw static streams and receipts,
disclosed failures and this coverage record. Only two exact names are excluded:

1. `SHA256SUMS.txt`: manifest self-reference.
2. `SEAL-RESULT.json`: sole post-seal operation result containing actual child
   argv/cwd/pre-start/end UTC/exit, raw split streams as base64 and hashes,
   and written-manifest verification/counts. It cannot exist before sealing.

No wildcard exclusion, external path, mutable build/Temp reference or hidden
post-seal command triple is admitted. Existing ancestors/members are checked for
reparse/symlink containment and case-unique safe relative names before hashing.
The unchanged 4 MiB leaf and 256 KiB stream limits apply. All captured receipts'
raw stream lengths/hashes are rechecked. Final REPORT/proposal hashes must match
the actual Root acknowledgement before manifest creation. No old seal changes.

After sealing, covered bytes and manifest remain immutable; later corrections
need an additive record. This package establishes custody only, not observation,
synthetic qualification, source/native compatibility, parser-wide success or Gate.
