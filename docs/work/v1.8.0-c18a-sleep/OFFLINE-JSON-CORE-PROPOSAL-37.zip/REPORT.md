# Task37 bounded offline JSON core contract report

Date: 2026-10-09 UTC. Delegated static contract worker, not Root. Status:
**PROPOSED; NO IMPLEMENTATION, TEST QUALIFICATION, FREEZE OR GATE AUTHORITY**.

## Findings, ambiguities and fixed identities first

1. The generic JSON core is separable from process capture, source schema, native
   provenance and NBT. Proposal03's byte/node/name/depth/UTF-16/duplicate/Unicode/
   numeric-lexeme limits can remain fixed while a checked byte tokenizer builds
   only admitted values. This is a candidate design, not a resource guarantee or
   parser qualification. Actual successful generic decode would not establish
   source-valid rows/chat, exact Gson accounting, observed Unicode or native facts.
2. Numeric magnitude handling was not a complete generic API contract in
   proposal03. Candidate D03 uses immutable ASCII lexemes and original-byte spans,
   never eager int/float/Decimal conversion or exponent expansion. Finite float
   and exact signed-int32/int64 source checks remain a separate subsequent task.
   This choice needs Root and fresh independent disposition, not silent adoption.
3. Root-object/no-whitespace admission follows proposal03's compact payload
   profile. D01 preserves it explicitly even though it refuses otherwise legal
   JSON. Unknown bounded fields remain generically acceptable, not schema-valid.
   D02 selects an iterative in-call checked tokenizer, not after-the-fact limits
   on an unchecked `json.loads` tree. Result types, locations and deadline checks
   are proposed new internal API decisions, not inherited implemented behavior.
4. D04 identifies a dominated boundary: every object name has a value, so a
   successful root-object document has `names <= nodes - 1 <= 65535`. The unchanged
   global-name ceiling 65536 cannot be reached by an accepted end-to-end payload
   under the node ceiling. Its at-limit/one-over guard needs a labeled bounded
   private-counter unit test, not a fabricated accepted trace or relaxed node cap.
5. The final ChatBounds source preserves separate identifier fields plus one
   shared 8192 estimated-byte text budget. The 2049 combined-ID envelope remains
   a downstream defensive parser envelope, not a reachable emitted maximum.
   The analytical loose ceiling is 1366 including colon, potentially lower with
   other admitted text; neither number is executed native at-limit evidence.
6. The 256 MiB allocation/RSS ceiling, finite decode deadline, platform peak-memory
   counter behavior and interruption responsiveness remain qualification work.
   Tracemalloc alone is not RSS and size/counter limits are not OS allocator
   enforcement. This preparation does not select/launch a measurement helper.
   Independent35's separate logger review result is not read or inferred here.
7. Preparation capture/ordering gaps are disclosed below. They do not disappear
   because later inspections succeed and are not decoder/native failures.

Fixed Main governance: `9edbcab9ba53f2aaf4861867a916fbe424972c07`.
Actual observation source: `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Task37 is 4634 bytes, SHA256
`8d356475549ff4971a38c6566750a22833bd85807a3634791496e913d7564152`.
Fixed Git objects, not moving Main files, supply governance/source/archive inputs.
The task's predecessor history remains historical, including proposal03's 5b
source and independent26's earlier governance. No result is rebound to a new SHA.

| Actual complete input | Bytes /lines | SHA256 |
|---|---:|---|
| Task20 PROPOSED-DRIVER-03.md | 68873 /991 | c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680 |
| Task20 REPORT.md | 17261 /245 | 06943124ed5aa69efc952cb11c77db2ef2ab76961d64a3ea5b5a615a1b5a61b6 |
| Independent26 REPORT.md | 24412 /332 | e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc |

Actual d57 source identities and compact relevant source excerpts are in receipts
24-26. All three complete blobs were loaded/hash-checked; only selected byte/
output/preflight/source-policy excerpts are retained, not a full source export.
This is not a complete independent semantic review of the fixture or serializer.

| Final source file | Bytes /lines | Git blob /SHA256 |
|---|---:|---|
| SleepBoundaryObservationFixture.java | 33987 /497 | 8e02816298e750a0b80f5b164ee2b87871028112 /1291421a8d7071ba1aecd117921e0331183e861b2d9ba16f9a2926ca093cc820 |
| SleepBoundaryTrace.java | 27593 /445 | 5caa936f41328f216afffa80fc86682a17a6b743 /20766c2ab5ea7dc2692acce2e901941c02d04d7b5a5a667b37204d3f2d65bf2f |
| SleepBoundaryChatBounds.java | 15889 /238 | b9a2758179f27369b0dd56392bb4b3220fdb8d6b /16af6b1ce1d6434ba3645a19dc6fad8b1141a9bc99b193f0505dbad577940fc0 |

## Actual commands and failures

Receipt names below correspond to this leaf's `*.receipt.json`, unchanged split
`*.stdout.txt`/`*.stderr.txt`, true child argv/cwd/start/end UTC/exit and SHA256.
For captured operations the outer watchdog is 180 seconds, each stream is
256 KiB maximum and aggregate admission reserves room below 4 MiB. Nested Git
reads in static helpers use an additional 30-second timeout. These are static
inspection commands, not tests. No captured child timeout/output overflow occurs.

Actual cwd is `D:/GitHub/AdvancedRocketry-Community`. The wrapper child shape is
`python -B <this-leaf>/capture_command.py <unique-label> <actual-child-argv>`.
Receipts 04 onward predominantly run `python -B <this-leaf>/inspect_inputs.py`
with the recorded fixed document/file/range operation. The custody/audit helpers
are separately named below; exact arguments and raw split stream hashes are in
the receipts rather than reconstructed from this table.

| Actual command/receipt | Result |
|---|---|
| Transcript-only bootstrap: Get-FileHash/Get-Content Task37; Python -B tooling identity, Test-Path leaf, Get-Location | Tool exits 0; correct task SHA, Python 3.13.15, leaf absent. No historical argv/UTC/split-stream receipt or explicit 180-second child watchdog exists for these two initial commands. |
| 01-repository-state: read-only git status/branch/worktree, rg, actual AGENTS and OpenPet skill read | Child exit 0; wrapper presentation subsequently exits 1 on ambient GBK UnicodeEncodeError. Original child streams/receipt remain intact. |
| 02-repository-state: explicit UTF-8 display repetition | Exit 0; sees user/peer work and current worktrees. Broad tool display truncates; supplied instructions and focused fixed-governance reads are separately read. |
| 03-input-paths attempted PowerShell expression | Outer shell exits 1 (`32` not recognized) before the receipt wrapper starts because nested quoting/pipes split. No 03 split streams/receipt is invented. Replaced by a bounded Python inspection, not counted as completed discovery. |
| 04-input-paths; 07-focused-paths | Exit 0; fixed-tree paths and two named leaf inventories; broad 04 display truncates. 07 reads the relied-on exact paths. No external ancestor AGENTS exists at the three checked parents. |
| 05-governance-a | Exit 0; PROJECT-CONFIG/PRODUCT/principles/roadmap fixed Git contents/hashes. |
| 06-governance-b | Exit 1; guessed lowercase docs/versions/v1.8.0.md is absent. |
| 08-governance-b; 09-governance-c; 21-governance-status | Exit 0; actual uppercase v1.8 document, master tests/Gates, post-1.0/budgets/parallel rules, fixed AGENTS and ADR060. |
| 10-main-checkpoints | Exit 0; complete fixed27/32/33/36 and owner01/03 records. Their authority/results/remaining limits stay distinct. |
| 11-driver-proposal | Exit 0; full raw proposal captured, but tool presentation truncates. |
| 12-proposal-001-250 through 15-proposal-751-991 | Each exit 0; complete nontruncated ranges cover all 991 proposal lines at one unchanged input SHA. |
| 16-author-report; 17-independent-report | Each exit 0; complete raw inputs captured. The combined tool presentation truncates independent26's beginning. |
| 18-review-001-170; 19-review-171-332 | Each exit 0; complete nontruncated ranges cover all 332 independent26 lines. Author20 was completely displayed in16. |
| 20-custody-records | Exit 0; actual seal-coverage/results and independent26 Root-read acknowledgement. |
| 22-input-seals: Python -B audit_inputs.py | Exit 1 after Task20 matches; the helper mistakenly applies a 256 KiB input-member bound to independent26's source-paths.stdout.bin. This is not a member hash mismatch finding. |
| 23-input-seals: separately corrected bounded input audit | Exit 0; both complete seals and fixed-Main ZIP CRC/payload/inventory equality verified, 347 covered files in total. Input/member bound is 4 MiB; unchanged own output-stream bound is 256 KiB. No input or older receipt is edited. |
| 24-source-excerpts; 25-source-generic-boundaries; 26-source-byte-writer | Each exit 0; actual d57 source identities and compact selected source facts. |
| 27-final-static-audit: Python -B final_static_audit.py | Exit 0; verifies 25 earlier captured receipts/stream hashes, no timeout/overflow; 80 own files/608994 bytes before its new capture. Latest HEAD remains fixed9ed. |

The capture helper is first created after checking the assigned external leaf is
absent but before its first captured Git status/worktree command. That preparation
ordering does not fully meet the requested pre-write status ordering; no Main
write follows it. Status/worktree/instructions are checked before proposal/report
work. One later apply_patch attempt fails context verification before any edit;
its raw error is session-only, not a fabricated subprocess receipt. Unsealed own
helpers are corrected where disclosed; older captured streams are not overwritten.

The report/document final identity audit and eventual seal receipt necessarily
follow report creation. Their actual results are delivered separately, not
preclaimed in the chronology above. Each uses a unique receipt or an explicitly
excluded self-contained post-seal result. No full instrumentation of bootstrap/
shell/editor tool activity is claimed. Tool display truncation is not treated as
complete required-input reading. Synthetic/native/parser execution never occurs.

## Completed and uncompleted scope

Completed: required fixed governance/version/test/parallel and ADR060 reads;
actual fixed checkpoints and owner decisions; complete proposal03/author20/
independent26 reading; selected actual final-source boundary inspection and hashes;
actual two-seal/ZIP custody verification; one implementation-ready candidate
contract and this report, with bounded static evidence in the exclusive leaf.

Uncompleted: Root/fresh independent disposition, implementation assignment, actual
decoder/tests/resource measurements, source schema/chat/count/type/conversion/
Gson qualification, framing/cursors/provenance, NBT/gzip, log-capture/diagnostic
qualification, native runtime/artifact/world/file operations and observations.
All production sleep, D1 runtime proof, B1/R1/M1/M2, clients/persistence/recovery,
full content/assets, hatch decisions, acceptance and inherited/current Gates remain
outside this task. Independent35 remains separate; its result is not inferred.

## Candidate decisions and modification boundaries

[PROPOSED-OFFLINE-JSON-CORE-01.md](PROPOSED-OFFLINE-JSON-CORE-01.md) states exact
prospective module/test write_scope, compact immutable-bytes API, checked iterative
tree construction, inert number records, UTF-16/Unicode/duplicate rules, all
unchanged generic bounds, bounded ordinal locations/errors, cooperative absolute
deadline and clearly labeled synthetic at-limit/one-over/malformed verification.
Resource commands have finite external time/output/evidence limits; actual
allocation/RSS/latency remain unqualified. All choices remain PROPOSED.

Only this assigned new external leaf is written. New files are the proposal,
report, four static evidence helpers (`capture_command.py`, `inspect_inputs.py`,
`audit_inputs.py`, `final_static_audit.py`), unique command receipts/raw streams
and, only after actual Root acknowledgement, seal coverage/ack/helper/manifest/
result. The helpers are evidence operations, not a decoder or test implementation.
No project/source/test/world/library/asset/API/schema/ledger/status/index/HEAD edit,
commit, push, worktree creation, cleanup, delegation or OpenPet emission is made
by this worker. Root coordinates OpenPet. Existing user/peer changes are untouched.

The latest read-only status27 sees user AGENTS and additional central record edits
under docs/status and docs/work. Those belong to their existing owners, not Task37.
It records 154 status lines and status-output SHA256
`1d500d5037493f6dfaba024f99e078eaa18a4413190c4fadd18c4c2956e64edd`.
This is an observed checkpoint, not a claim that another agent cannot subsequently
change Main. Fixed Git object reads do not depend on those mutable documents.

## Tests and actually established evidence

**Tests added/modified/executed: NONE; decoder tests NOT_EXECUTED.**
Gradle clean build/test/runData/generated diff/runGameTestServer, dedicated server,
restart/client/Unicode/native observations and performance/resource checks are
NOT_EXECUTED under Task37's explicit static permissions, not PASS or
NOT_APPLICABLE. Hash/ZIP/receipt audits are custody checks, not decoder behavior
or synthetic/native observation evidence. Standard d57 qualification at32 remains
its historical result, including strict timeout and unwaived native errors.

## Custody, sizes and limits

Receipt23 independently verifies safe leaf-relative names, case uniqueness,
regular/contained files, ancestor/member reparse absence, every covered hash,
actual exclusions, fixed-Main ZIP member uniqueness, CRC and exact external-leaf
bytes/inventory equality. No archive is extracted into a new tree.

| Actual input seal | Manifest SHA256 | Covered files /bytes |
|---|---|---:|
| Task20 | b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0 | 198 /1089641 |
| Independent26 | 9a87f2cba6c1faa59c981bada8800eca8b006d34fd2980257656823dc5850f3d | 149 /1890251 |

Both exclude only `SHA256SUMS.txt` self and later `SEAL-RESULT.json`; the fixed-Main
archives cover these too. Task20 ZIP: 390531 compressed/1113197 expanded bytes,
SHA256 `7f06f8a3845b3589118d3c0db67406721515b9190575880e88cc58016701267a`.
Independent26 ZIP: 416142 compressed/1915240 expanded bytes, SHA256
`61240d2fbfbb0bc04cdc7b3a3193677ce4739f83f39f328dfb172e333c5cbd6c`.
Both are read from the fixed9ed committed sleep record directory; no moving
archive/input is substituted. Root's complete-read acknowledgement is an old
input custody record, not permission to seal this task before a new acknowledgement.

Actual static Python executable is
`D:/python/pyenv/pyenv-win/versions/3.13.15/python.exe`, version3.13.15,
SHA256 `85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd`.
It is tooling identity, not a qualified future decoder interpreter or native JDK.
Own27 pre-capture volume is 608994 bytes; largest captured stream so far is
70050 bytes. Final own volume/manifest custody must be measured after Root's
complete final-document reading, with the unchanged 4 MiB aggregate and 256 KiB
per-stream caps. This package is not a new complete slice-wide launch inventory
or a fix for proposal03's failing conservative retained-evidence admission.
No source/library/build/world copy, temporary archive or cleanup target is created.

## Risks, Gate status and next current-v1.8 work

Known risks: stricter refusals of otherwise source-valid JSON, producer surrogate
loss that a decoder cannot recover, unsupported escaped lone surrogates, proposed
API/number/compact-profile compatibility choices, dominated global-name tests,
unqualified allocator/RSS/deadline/measurement behavior and disclosed bootstrap/
presentation/ordering instrumentation gaps. Resource limits do not guarantee an
error receipt after OOM or host termination. No native or gameplay failure is
established by this static work. Old capture, retention, incident, link and Gate
limitations remain their own open records and are not waived here.

**All current-version and inherited Required Gates G0-G9 satisfied: NO.**
No production change, parser-wide/source/native qualification, observation,
freeze, accepted contract, Main publication, ledger delivery, release or tag is
claimed. Next work is Root's complete candidate/report reading and fresh independent
review within v1.8; only a later explicit bounded implementation/test task after
disposition. Source-specific schema/Gson/provenance checks remain subsequent
required work, not bypassed by this generic sub-slice.

Do not seal this leaf until Root confirms complete final-report reading. No Root
acknowledgement or own completed seal is inferred in this report. Seal hashes/
counts and exact exclusions are returned through coordination after that event.
