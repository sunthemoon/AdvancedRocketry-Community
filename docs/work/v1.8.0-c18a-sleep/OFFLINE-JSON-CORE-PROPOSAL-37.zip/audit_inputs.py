"""Task37 bounded verification of two named static evidence seals."""
import hashlib
import io
import json
import pathlib
import re
import stat
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
MAIN = "9edbcab9ba53f2aaf4861867a916fbe424972c07"
BASE = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe(path):
    for item in (path, *path.parents):
        s = item.lstat()
        if stat.S_ISLNK(s.st_mode) or getattr(s, "st_file_attributes", 0) & 0x400:
            raise ValueError("reparse/symlink: " + str(item))


items = [
    ("sleep-observation-driver-revision-20261009-20", "OBSERVATION-DRIVER-REVISION-20.zip", "b06be719195e36b50e607ca6aa0a1de992e45932a2d05c3e3eac9825928e14c0", "7f06f8a3845b3589118d3c0db67406721515b9190575880e88cc58016701267a"),
    ("sleep-observation-driver-revision-independent-20261009-26", "OBSERVATION-DRIVER-REVISION-INDEPENDENT-26.zip", None, "61240d2fbfbb0bc04cdc7b3a3193677ce4739f83f39f328dfb172e333c5cbd6c"),
]
for leafname, archive, expected_manifest, expected_archive in items:
    leaf = BASE / leafname
    safe(leaf)
    manifest = (leaf / "SHA256SUMS.txt").read_bytes()
    if len(manifest) > 65536:
        raise ValueError("manifest byte bound")
    entries = {}
    folded = set()
    for line in manifest.decode("utf-8-sig").splitlines():
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64}) [ *](.+)", line)
        if not match:
            raise ValueError("invalid manifest line: " + line[:100])
        expected, name = match.groups()
        p = pathlib.PurePosixPath(name)
        if p.is_absolute() or "\\" in name or any(x in ("", ".", "..") for x in p.parts) or ":" in name or len(name) > 4096 or name.casefold() in folded:
            raise ValueError("unsafe/duplicate manifest name")
        folded.add(name.casefold())
        member = leaf.joinpath(*p.parts)
        safe(member)
        if not member.is_file() or not member.resolve().is_relative_to(leaf.resolve()):
            raise ValueError("not contained regular file")
        raw = member.read_bytes()
        if len(raw) > 4194304 or digest(raw) != expected.lower():
            raise ValueError("member hash/size mismatch: " + name)
        entries[name] = (expected.lower(), len(raw))
    if len(entries) > 512:
        raise ValueError("entry bound")
    actual = {p.relative_to(leaf).as_posix() for p in leaf.rglob("*") if p.is_file()}
    extras = sorted(actual - entries.keys())
    if extras != ["SEAL-RESULT.json", "SHA256SUMS.txt"]:
        raise ValueError("unexpected exclusions: " + str(extras))
    result = subprocess.run(["git", "show", MAIN + ":docs/work/v1.8.0-c18a-sleep/" + archive], capture_output=True, timeout=30)
    if result.returncode or len(result.stdout) > 1048576:
        raise ValueError("archive unavailable or over inspection bound")
    archive_bytes = result.stdout
    if digest(archive_bytes) != expected_archive:
        raise ValueError("fixed archive hash mismatch")
    archive_checks = []
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
        names = z.namelist()
        if len(names) > 512 or sum(i.file_size for i in z.infolist()) > 4194304:
            raise ValueError("archive bounds")
        archive_folded = set()
        for info in z.infolist():
            name = info.filename
            p = pathlib.PurePosixPath(name)
            if p.is_absolute() or "\\" in name or ":" in name or any(x in ("", ".", "..") for x in p.parts) or name.casefold() in archive_folded:
                raise ValueError("unsafe/duplicate archive member")
            archive_folded.add(name.casefold())
            if info.is_dir():
                continue
            if info.file_size > 4194304:
                raise ValueError("archive member byte bound")
            raw = z.read(info)
            member = leaf.joinpath(*p.parts)
            if not member.is_file() or raw != member.read_bytes():
                raise ValueError("archive/live-seal disagreement: " + name)
            archive_checks.append(name)
        if set(archive_checks) != actual:
            raise ValueError("archive/live-seal file inventory mismatch")
    observed_manifest = digest(manifest)
    # Task26's authoritative manifest identity is read from the actual fixed archive,
    # not from an unverified remembered value in this helper.
    if expected_manifest is not None and observed_manifest != expected_manifest:
        raise ValueError("Task20 manifest identity mismatch")
    print(json.dumps({"leaf": str(leaf), "manifest_bytes": len(manifest), "manifest_sha256": observed_manifest,
        "covered_files": len(entries), "covered_bytes": sum(x[1] for x in entries.values()), "all_covered_match": True,
        "exclusions": extras, "archive_git_object": MAIN + ":docs/work/v1.8.0-c18a-sleep/" + archive,
        "archive_bytes": len(archive_bytes), "archive_sha256": digest(archive_bytes), "archive_expanded_bytes": sum(i.file_size for i in z.infolist()),
        "archive_files": len(archive_checks), "archive_crc_and_exact_leaf_equality": True}, sort_keys=True))
task = BASE / "SLEEP-OFFLINE-JSON-CORE-CONTRACT-TASK-37.md"
raw = task.read_bytes()
print(json.dumps({"task_path": str(task), "bytes": len(raw), "sha256": digest(raw)}))
if digest(raw) != "8d356475549ff4971a38c6566750a22833bd85807a3634791496e913d7564152":
    raise ValueError("task changed")
