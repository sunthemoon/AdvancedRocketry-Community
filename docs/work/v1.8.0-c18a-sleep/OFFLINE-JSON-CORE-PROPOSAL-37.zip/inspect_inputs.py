"""Bounded Task37 static inspection only."""
import hashlib
import pathlib
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
MAIN = "9edbcab9ba53f2aaf4861867a916fbe424972c07"
SOURCE = "d57ecda1f11dab76d882f945b0de606534ef4fb9"
EXTERNAL = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0")


def git(*args):
    result = subprocess.run(["git", *args], capture_output=True, timeout=30)
    if result.returncode:
        raise SystemExit(result.stderr.decode("utf-8", "replace"))
    return result.stdout


def show(commit, path):
    data = git("show", commit + ":" + path)
    if len(data) > 180000:
        raise SystemExit("requested document exceeds bounded inspection size")
    print("===", commit + ":" + path, len(data), hashlib.sha256(data).hexdigest(), "===")
    print(data.decode("utf-8"))


def file(path):
    data = path.read_bytes()
    if len(data) > 180000:
        raise SystemExit("requested file exceeds bounded inspection size")
    print("===", path, len(data), hashlib.sha256(data).hexdigest(), "===")
    print(data.decode("utf-8"))


mode = sys.argv[1]
if mode == "paths":
    for commit in (MAIN, SOURCE):
        for path in git("ls-tree", "-r", "--name-only", commit).decode("utf-8").splitlines():
            if re.search("sleep|SLEEP|AGENTS|GATE_STATUS|OWNER|owner", path):
                print(commit, path)
    for leaf in ("sleep-observation-driver-revision-20261009-20", "sleep-observation-driver-revision-independent-20261009-26"):
        for path in sorted((EXTERNAL / leaf).iterdir()):
            print(path, path.stat().st_size if path.is_file() else "DIRECTORY")
    for parent in (EXTERNAL, EXTERNAL.parent, EXTERNAL.parent.parent):
        path = parent / "AGENTS.md"
        print("APPLICABLE", path, path.exists())
        if path.exists():
            file(path)
elif mode == "focused-paths":
    for commit in (MAIN, SOURCE):
        for path in git("ls-tree", "-r", "--name-only", commit).decode("utf-8").splitlines():
            if ("docs/work/v1.8.0-c18a-sleep/" in path and path.endswith(".md")) or ("docs/versions/" in path and "1.8" in path) or (path.endswith(".java") and re.search("sleep", path, re.I)) or (path.startswith("scripts/") and path.endswith(".py")):
                print(commit, path)
elif mode == "git-docs":
    for path in sys.argv[2:]:
        show(MAIN, path)
elif mode == "source":
    for path in sys.argv[2:]:
        show(SOURCE, path)
elif mode == "files":
    for path in sys.argv[2:]:
        file(pathlib.Path(path))
elif mode == "file-lines":
    path = pathlib.Path(sys.argv[2])
    raw = path.read_bytes()
    lines = raw.decode("utf-8").splitlines()
    start, end = map(int, sys.argv[3:5])
    print("FILE", path, "BYTES", len(raw), "SHA256", hashlib.sha256(raw).hexdigest(), "TOTAL_LINES", len(lines), "RANGE", start, end)
    for i in range(start - 1, min(end, len(lines))):
        print(str(i + 1) + ": " + lines[i])
elif mode == "source-ranges":
    for entry in sys.argv[2:]:
        path, ranges = entry.split("=", 1)
        raw = git("show", SOURCE + ":" + path)
        lines = raw.decode("utf-8").splitlines()
        print("SOURCE", SOURCE + ":" + path, "BYTES", len(raw), "SHA256", hashlib.sha256(raw).hexdigest(), "GIT_BLOB", git("rev-parse", SOURCE + ":" + path).decode().strip(), "LINES", len(lines))
        for part in ranges.split(","):
            start, end = map(int, part.split("-"))
            for i in range(start - 1, min(end, len(lines))):
                print(str(i + 1) + ": " + lines[i])
elif mode == "read-captured":
    data = pathlib.Path(sys.argv[2]).read_bytes().decode("utf-8", "replace").splitlines()
    start, end = map(int, sys.argv[3:5])
    print("TOTAL_LINES", len(data), "RANGE", start, end)
    for i in range(start - 1, min(end, len(data))):
        print(str(i + 1) + ": " + data[i])
else:
    raise SystemExit("unknown inspection mode")
