# Offline observation JSON core candidate 01

Date: 2026-10-09 UTC. Status: **PROPOSED; NOT FROZEN, IMPLEMENTED OR QUALIFIED**.
Task37 proposes only an internal Python-standard-library tokenizer/decoder for
one caller-supplied immutable JSON payload. Root and fresh independent review
must disposition the choices below before a separate implementation assignment.
Successful decoding establishes this narrow structural profile only.

## 1. Fixed basis and prospective ownership

Governance is Git commit `9edbcab9ba53f2aaf4861867a916fbe424972c07`.
Actual observation source is `d57ecda1f11dab76d882f945b0de606534ef4fb9`.
Proposal03's historical source remains 5b451320; no historical result is rebound.
The actual proposal03 is 68873 bytes, SHA256
`c8c69f84b09c4b4d1b3863a42ef11acea6e9fb9594731d8031c5d2926d7ec680`.
The actual independent26 REPORT is 24412 bytes, SHA256
`e0aecb06ed75c04b5985d591908ef9f9a684a74aba9df618bbc1bc7cf4f00dcc`.
Its generic accounting is at proposal03 lines 635-686; compact payload admission
is at 690-699. Final Trace35-40/100-139/324-328 and ChatBounds28-98 distinguish
source byte serialization/preflight from additional offline defensive limits.

If assigned later, exactly these two repository-relative files are proposed:

- `scripts/sleep_observation_json_core.py`: internal decoder and result types.
- `scripts/test_sleep_observation_json_core.py`: synthetic unit/boundary/resource
  tests, including bounded platform measurement support in that test file only.

Use a newly assigned isolated worktree based on the integrator-selected committed
baseline. No directory-wide write ownership, central build/registration/status/
ledger edit, public package or third production module is implied. Neither file
exists or is created by Task37. Future parser integration must directly call this
module rather than copy its decoder or introduce a configurable JSON framework.
The integration call site is a subsequent disjoint task, not this write_scope.

## 2. Supported profile and deliberate refusals

Input is exactly a built-in `bytes` instance, not a path, stream, generator,
mutable bytearray, memoryview, string or bytes subclass. Its size is checked before
tokenization or a decoded copy. The caller supplies exactly the already isolated
payload: no marker, LF/CRLF terminator, logger prefix or process cursor.

Candidate D01 preserves the proposal's compact-object profile: one nonempty byte
sequence containing a JSON object root, immediately followed by end of payload.
An empty object is supported. Arrays, strings, numbers, booleans and null are
supported as member/array values, not as the document root. No insignificant
whitespace is admitted outside quoted strings, including leading/trailing space.
This intentionally refuses otherwise legal general JSON. It is a payload lexical
profile, not framing implementation; there is no marker or newline scanner.

Use ordinary JSON punctuation, double-quoted names/strings, exact lowercase
`true`, `false`, `null`, and the number grammar below. Refuse comments, single
quotes, trailing commas, missing separators/values/closures, multiple roots,
trailing bytes, empty input, BOM at payload start, raw control characters U+0000
through U+001F inside strings, invalid escapes and malformed UTF-8. Whitespace
and escaped control characters inside strings remain valid string content.
No repair, normalization, case folding, coercion, substitution or second parser.

UTF-8 string decoding admits only canonical scalar encodings: reject malformed
continuations, overlong encodings, truncation, raw surrogate encodings and values
above U+10FFFF. JSON escapes admit `\"`, `\\`, `\/`, `\b`, `\f`, `\n`, `\r`,
`\t`, and exactly four hexadecimal digits after `\u` (either hex case).
A high-surrogate escape must be immediately followed by a low-surrogate `\u`
escape; combine it into the corresponding scalar. Lone/reversed/split pairs are
refused, never preserved as Python surrogate strings. Raw supplementary scalars
and equivalent escaped pairs therefore compare identically. U+FEFF inside a
string is not a leading payload BOM and is allowed. NUL is allowed only escaped.

Object-name equality is the exact decoded UTF-16 unit sequence, before insertion.
For this accepted scalar-only domain, ordinary Python string equality has the
same equality relation; no extra normalized/UTF-16 copy is required. Escaped-name
aliases are duplicates at every object depth. Duplicate detection precedes the
member's value decode and any last-wins/first-wins overwrite.

Unknown field names and arbitrary bounded nested values are accepted generically.
Their acceptance is expressly not approval under the observation/chat schema.

## 3. Fixed bounds and admission points

All bounds are inclusive and fixed, with no caller override or compatibility mode.

| Quantity | Maximum | Counting and refusal point |
|---|---:|---|
| Original payload bytes | 524288 | `len(payload)` before scanning; prefix/terminator are not input. |
| JSON value nodes | 65536 | Each object, array, string, number, boolean and null is one; root is one. Reserve before constructing/attaching the next value. |
| Member names, whole payload | 65536 | Names are not value nodes. Reserve before decoding the next name. |
| Names in one object | 64 | Check before decoding the next key; retain at most 64 decoded names in that object's duplicate set. |
| Container depth | 64 | Root object depth 1; each entered object/array adds 1. Check before creating/pushing a container. Scalars do not add depth. |
| One decoded string or name | 4096 UTF-16 units | Count BMP scalar as 1 and supplementary scalar as 2; check before extending the bounded decoded buffer. |
| One numeric lexeme | 64 ASCII bytes | Count sign/digits/decimal point/exponent marker/sign; check before retaining byte 65 or constructing a number record. |

Punctuation is not a node/name. Containers count even when empty. Array elements
and object member values count recursively; no independent generic per-array
limit is invented. The node bound already bounds all generic array elements.
Collection-specific observation/chat limits are downstream, not lost or relaxed.
Only bounded original input plus admitted tree/counters/stack/string scratch is
retained. No token list, full decoded-payload clone, unlimited queue, global tree,
process log list, duplicated retained AST or cache survives the call.

Candidate D02 is an iterative byte-oriented scanner with an explicit stack of at
most 64 container frames, rather than recursion, regex backtracking or eager
`json.load`/`json.loads` with after-the-fact traversal. Containers may be ordinary
Python dict/list, but every value/key/depth/string/number reservation is checked
inside tokenization before the corresponding allocation/attachment. A string
scratch buffer can contain only <=4096 admitted scalar characters/UTF-16 units;
do not slice an unchecked 512 KiB string token and decode it first. Raw UTF-8
validation and JSON escape processing happen while consuming original bytes.

Candidate D04 records an accounting dependency: every object member has a value,
so a successful root-object tree has `names <= nodes - 1 <= 65535`. The unchanged
global-name ceiling 65536 is therefore dominated by the node ceiling for accepted
documents. Do not fabricate a successful document with 65536 names. Its guard can
be independently checked with a bounded private-counter unit test; that test is
not an end-to-end accepted payload or a source/native result.

## 4. Numbers without magnitude expansion

Candidate D03 stores all numbers as inert frozen `JsonNumber` records, never as
Python int, float or Decimal during generic decode. Record fields are
`lexeme: str` (ASCII, <=64 bytes), `start: int`, `end: int` (original-byte span).
Number grammar is exactly:

`-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?`

The tokenizer must implement a finite state scan of this grammar and require a
legal next delimiter/end; no leading plus/zeros, missing fractional/exponent
digits, Unicode digits, NaN or Infinity tokens. Preserve lexical sign, exponent
case, fraction and negative zero. Strings containing such words are just strings.

Large magnitudes/exponents within 64 bytes remain inert lexical numbers. Never
compute `10**exponent`, expand digits/zeros, invoke Decimal arithmetic, or use
`float()` as a generic admission check. Thus `1e999999` is generically supported
without a claim that it is a finite source float or in any source integer range.
Later schema work must separately specify bounded exact-int32/int64 and finite
float conversions, rejecting booleans as integers and preserving raw angle-bit
fields. This candidate supplies neither conversion helpers nor range policy.
Keeping number lexemes does not establish exact source-Gson row-byte accounting.

## 5. Internal API, results and locations

Prospective API: `decode_payload(payload: bytes, *, deadline_ns: int) -> DecodeResult`.
`deadline_ns` is an exact built-in int, excluding bool, on `time.monotonic_ns()`.
Reject expired deadlines and deadlines more than60 seconds after entry. The caller
uses its existing absolute offline-phase deadline; repeated calls do not reset
that enclosing budget. A fixed module constant supplies the 60-second maximum,
not a user-configurable runtime. There are no callbacks, hooks, plugins or I/O.

Result is one of two frozen dataclass shapes:

- `Decoded(kind="JSON_CORE_DECODED", value: dict, metrics: DecodeMetrics)`.
  Values are dict/list/str/bool/None/JsonNumber; all numbers use JsonNumber.
  Insertion order is retained, not sorted. Freezing the result record does not
  freeze its tree: downstream code owns it exclusively and must not treat it as
  immutable evidence or re-encode it in place of the original caller bytes.
- `Refused(kind="JSON_CORE_REFUSED", error: DecodeError, metrics: DecodeMetrics)`.
  No partial tree is returned. The caller retains the original immutable bytes;
  refusal does not open, write, copy, capture, discard or hash a file.

Metrics are only bounded integers: `input_bytes`, `consumed_bytes`, `nodes`,
`names`, `max_container_depth`, `max_string_utf16_units`, `max_number_bytes`.
Failure counters describe admitted work, not a completed whole-input inventory.
No native outcome, provenance, schema verdict or Gate field is included.

DecodeError fields: fixed `code`, `byte_offset` (0..input_bytes, EOF uses length),
`location` (<=64 member/element ordinal segments), optional `name_span`
`(start,end)` into original bytes, optional fixed `limit_name`, and bounded integer
`limit`/`observed`. Member ordinals are zero-based insertion order and element
ordinals are array indices; the root location is empty. For a key failure the
current object plus attempted member ordinal identifies it. Do not echo arbitrary
key text, payload excerpts, traceback or unbounded exception messages. Original
byte offset plus name span/ordinals makes a refused field inspectable without
constructing a potentially 256 KiB human-readable key path. Schema names remain
the responsibility of the subsequent source-aware layer.

Fixed codes: `INPUT_TYPE`, `INPUT_BYTES`, `DEADLINE_ARGUMENT`, `DEADLINE`,
`ROOT_TYPE`, `WHITESPACE`, `UTF8`, `BOM`, `STRING_CONTROL`, `STRING_ESCAPE`,
`SURROGATE`, `DUPLICATE_NAME`, `STRING_UNITS`, `NUMBER_GRAMMAR`, `NUMBER_BYTES`,
`NODES`, `NAMES`, `OBJECT_NAMES`, `DEPTH`, `SYNTAX`, `TRAILING_DATA`.
Input/type/byte/deadline preflight precedes scanning; otherwise report the first
left-to-right detected refusal. A bound's `observed` is the first attempted
over-limit quantity, not a fabricated count of an unscanned tail. Malformed UTF-8
in a string reports its leading offending byte; a bad escape/surrogate reports
the introducing backslash; a bound/key/container reports the introducing token.
Rejecting oversized malformed input as INPUT_BYTES is intentional precedence.

Deadline checks occur at entry, before node/key/container allocation, at least
once per 4096 newly consumed input bytes, and before successful return. Expiry
clears partial work and returns DEADLINE when execution can resume. This is a
cooperative check, not OS scheduling/preemption proof. Unexpected implementation
exceptions, MemoryError, interpreter/host termination and unavailable resource
measurement are qualification failures, not a fabricated complete refusal or
successful decode. A small error allocation cannot be guaranteed after host OOM.

## 6. Finite synthetic verification and resource qualification

No tests or fixtures run/create under Task37. A later separately authorized test
task uses only clearly labeled STRUCTURAL SYNTHETIC bytes, generated in memory;
no file is labeled a native successful trace. No fixture import or game startup.
Use standard-library unittest, not pip/Gradle/JVM. Provisional commands from the
assigned worktree are `python -B scripts/test_sleep_observation_json_core.py` for
functional checks and the same file with a fixed resource-case argument for each
fresh resource process. Such arguments are a test-only finite enum, not a decoder
configuration. A wrapper records executable/argv/cwd/UTC/exit/raw stream hashes.
Each child has an unchanged 180-second external ceiling; each decode retains the
<=60-second absolute deadline. Every stream<=256 KiB; the whole test evidence
leaf<=4 MiB, with no full decoded-tree dumps or saved synthetic payload corpus.

| Synthetic family | Required verification |
|---|---|
| Supported values | Empty root; bounded nested arrays/objects; all scalar types; number record versus bool; exact strings and insertion order; repeated calls do not retain prior trees. |
| Bytes | Construct a legal compact object exactly 524288 bytes using bounded strings/arrays; independently assert generated length. Add one legal byte inside a non-full string for 524289. A separate 1 MiB caller-bytes case verifies refusal before token work; no unbounded synthetic allocation. |
| Nodes/depth | Root plus array plus 65534 zeros gives 65536 nodes; 65535 zeros gives 65537. Root plus 63 nested arrays reaches 64 containers; 64 nested arrays reaches 65. Assert counters and refusal token, not a recursion-limit workaround. |
| Names | 64 versus 65 distinct names/object. Test names-not-nodes accounting and private global-name guard at 65536/65537; document its unreachable successful end-to-end boundary. Do not relax node limits to test it. |
| Strings | 4096/4097 ASCII UTF-16 units; 2048 supplementary scalars versus those plus one BMP scalar; raw versus escaped equivalent names; escaped NUL/control; Unicode normalization-distinct names stay distinct. |
| Numbers | 64/65-byte valid lexemes; negative zero, fractions and exponents; a 64-byte huge exponent remains inert; invalid sign/leading-zero/dot/exponent/nonfinite forms refuse without expansion/conversion. |
| Malformation | Duplicate raw/escaped names at nested levels; invalid UTF-8 variants and truncations; each escape form; lone/high-low/reversed surrogates; BOM versus in-string U+FEFF; controls/whitespace/comments/trailing/missing syntax and wrong root. |
| Deadline/error | Entry expiry, too-far/non-int deadline, cooperative mid-scan expiry, stable original-byte offsets/spans, bounded ordinal location and no partial tree. Tests of checks use private clock patching, not a public callback API. |

Resource cohort has a fixed maximum of 12 fresh process cases: maximum-byte valid
payload, maximum-node valid payload, combined high-node/string payload, depth 64,
4096-unit supplementary string, repeated distinct 64-name objects, 64-byte huge
numbers, duplicate late in an object, late malformed UTF-8, byte/node one-over,
and cooperative deadline refusal. A case may combine byte/node-one-over tests
but must measure and report each call. Generate at most two bounded payloads per
process, discard the first result before another call, and keep no repeated AST.

In each resource process, record Python executable/version/hash, OS/architecture,
case recipe/input length/hash, start/end monotonic and actual result/counters.
Measure peak traced Python allocation with `tracemalloc` and process lifetime peak
RSS/working-set, including interpreter, generated input and result, using a
validated standard-library platform counter: `resource.getrusage` on applicable
POSIX or `ctypes` plus the native process-memory counter on Windows. Bind and
independently check counter availability, field meaning and units before relying
on it; this document does not execute/select a platform helper. Unsupported or
unverifiable counters leave RSS **UNQUALIFIED**, never zero/PASS.

Both traced peak and lifetime peak RSS/working-set must be<=256 MiB (268435456
bytes), retaining proposal03's ceiling. Traced allocation alone is not RSS,
sampled current RSS alone is not lifetime peak, and polling alone is not a hard
allocator/quota. A failed resource/latency case blocks qualification without
raising caps, deleting cases or increasing timeout. Fixed input/counters/stack/
scratch bounds make logical allocation finite by design; actual worst-case
256 MiB and 60-second behavior, interruption responsiveness and Python allocator
effects remain **qualification obligations, not established guarantees**.

## 7. Disposition dependencies and excluded subsequent work

D01 compact object-only payload, D02 iterative checked tree, D03 inert number
representation/deferred conversions, D04 dominated global-name boundary, the API/
error locations and fixed resource recipes are explicit candidate decisions.
Root and fresh independent review must accept or amend these without changing old
seals. No compatibility flag or post-refusal budget widening is proposed.

Subsequent source-aware work still must implement exact root/row/event/status/
identity/error/action/lifecycle/chat unions and their field/collection/UTF-16
limits; source-Gson row-byte 131072 accounting; signed int32/int64 and finite float
checks; event/control/cause semantics; and source/provenance/capture results.
In particular, error 256/content 1024/combined-ID 2049 are separate stricter field
envelopes, not generic 4096 replacements. 2049 is a defensive envelope, not a
reachable source maximum: ChatBounds' shared 8192 estimate gives an analytical
combined-ID loose ceiling 1366 including colon, potentially lower with other text.

Framing/cursors, process/source runtime discovery, launches, worlds/files/capture,
logger interpretation/diagnostic acceptance, native Unicode/Gson output proof,
NBT/modified-UTF8/gzip, saved Spawn/default/durability comparison, 20-row trace
observation, production sleep/air/dimension/spawn/time, D1 runtime rows and any
Gate acceptance are excluded. Independent35's log review is separate; no result
is inferred. Generic decode success cannot bypass any of these prerequisites.
The source-valid whole-trace node refusal and escaped-lone-surrogate refusal
remain deliberate additional restrictions, not native gameplay failures or a
claim of universal source compatibility. Parser-wide/native qualification stays
open. **All current v1.8 Required Gates satisfied: NO.**
