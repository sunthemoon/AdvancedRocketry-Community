"""Own-leaf static custody/size inspection only; never decoder qualification."""
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
root = pathlib.Path(__file__).resolve().parent
files = sorted(p for p in root.iterdir() if p.is_file())
total = sum(p.stat().st_size for p in files)
if total > 4194304 or any(p.stat().st_size > 262144 for p in files):
    raise SystemExit("own evidence file/aggregate budget exceeded")
receipts = []
for path in files:
    if not path.name.endswith(".receipt.json"):
        continue
    receipt = json.loads(path.read_text(encoding="utf-8"))
    for stream in receipt["streams"]:
        member = pathlib.Path(stream["path"])
        if member.parent.resolve() != root.resolve():
            raise SystemExit("receipt stream outside leaf")
        raw = member.read_bytes()
        if len(raw) != stream["bytes"] or hashlib.sha256(raw).hexdigest() != stream["sha256"]:
            raise SystemExit("receipt stream changed")
    receipts.append({"receipt": path.name, "exit_code": receipt["exit_code"], "timeout": receipt["timed_out"], "overflow": receipt["output_limit_exceeded"], "elapsed_seconds": receipt["elapsed_seconds"]})
print(json.dumps({"own_files_before_this_capture": len(files), "own_bytes_before_this_capture": total,
    "verified_receipts": receipts, "all_stream_hashes_match": True}, indent=2))
for name in ("PROPOSED-OFFLINE-JSON-CORE-01.md", "REPORT.md"):
    path = root / name
    if path.exists():
        raw = path.read_bytes()
        print(json.dumps({"path": str(path), "bytes": len(raw), "lines": len(raw.decode("utf-8").splitlines()), "sha256": hashlib.sha256(raw).hexdigest()}))
print(json.dumps({"python_executable": sys.executable, "python_version": sys.version,
    "python_executable_sha256": hashlib.sha256(pathlib.Path(sys.executable).read_bytes()).hexdigest()}))
for argv in (["git", "rev-parse", "HEAD"], ["git", "status", "--porcelain=v1", "--untracked-files=normal"]):
    result = subprocess.run(argv, capture_output=True, timeout=30)
    if result.returncode:
        raise SystemExit("Git inspection failed")
    print(json.dumps({"nested_readonly_argv": argv, "exit_code": result.returncode,
        "stdout_bytes": len(result.stdout), "stdout_sha256": hashlib.sha256(result.stdout).hexdigest()}))
    if argv[1] == "rev-parse":
        print(result.stdout.decode("utf-8"))
    else:
        lines = result.stdout.decode("utf-8").splitlines()
        print("STATUS_LINES", len(lines), "TRACKED", [x for x in lines if not x.startswith("?? ")])
