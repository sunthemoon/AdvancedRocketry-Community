import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = Path(__file__).resolve().parent.parent
COMMIT = '46c566dd7000d9fcd29c985d23100d8c04891eaf'
DOCS = [
    'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/05-MASTER-TEST-PLAN.md',
    'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
]
tree = subprocess.run(['git', 'ls-tree', '-r', '--name-only', COMMIT, 'docs/decisions'], capture_output=True, check=True).stdout.decode()
adr = [p for p in tree.splitlines() if '066' in p]
if len(adr) != 1:
    raise RuntimeError('ADR-066 discovery count: ' + str(adr))
DOCS += adr
hashes = []
with (ROOT / 'governance-fixed.txt').open('wb') as out:
    for path in DOCS:
        argv = ['git', 'show', COMMIT + ':' + path]
        p = subprocess.run(argv, capture_output=True, check=True)
        hashes.append({'argv': argv, 'exit_code': p.returncode, 'sha256': hashlib.sha256(p.stdout).hexdigest(), 'size': len(p.stdout)})
        out.write(('\n===== ' + path + ' =====\n').encode())
        out.write(p.stdout)
review = Path(r'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-contract-independent-20261009-01')
checks = []
for line in (review / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    expected, relative = line.split(maxsplit=1)
    path = review / relative.lstrip('*')
    if not path.resolve().is_relative_to(review.resolve()):
        raise RuntimeError('Manifest outside review leaf')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    checks.append({'relative': relative, 'expected': expected, 'actual': actual, 'matches': actual == expected})
if not all(c['matches'] for c in checks):
    raise RuntimeError('Review seal mismatch')
inputs = []
for path in [review / 'REPORT.md', review / 'SHA256SUMS.txt', review / 'INPUT-AUDIT.json', Path(r'D:\GitHub\ARCE-Task-Evidence\v1.8.0\SLEEP-SPAWN-FEASIBILITY-TASK-02.md')]:
    inputs.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size})
(ROOT / 'INPUTS.json').write_text(json.dumps({'commit': COMMIT, 'fixed_blobs': hashes, 'external_inputs': inputs, 'review_seal': checks}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'governance_paths': DOCS, 'review_seal_entries': len(checks), 'all_match': True}, indent=2))
print((review / 'REPORT.md').read_text(encoding='utf-8'))
