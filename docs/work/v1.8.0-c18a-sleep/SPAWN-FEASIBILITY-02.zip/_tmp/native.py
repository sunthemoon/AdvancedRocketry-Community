import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ROOT = Path(__file__).resolve().parent.parent
MAPPED = Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
FORGE = Path(r'C:\Users\Administrator\.gradle\caches\forge_gradle\maven_downloader\net\minecraftforge\forge\1.20.1-47.4.10\forge-1.20.1-47.4.10-sources.jar')
JAVAP = Path(r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe')
CLASSES = {
    'net.minecraft.server.level.ServerPlayer': ['startSleepInBed', 'setRespawnPosition', 'getRespawnPosition', 'getRespawnDimension', 'getRespawnAngle', 'isRespawnForced', 'readAdditionalSaveData', 'restoreFrom', 'stopSleepInBed'],
    'net.minecraft.server.level.ServerPlayerGameMode': ['useItemOn'],
    'net.minecraft.server.network.ServerGamePacketListenerImpl': ['handleUseItemOn'],
    'net.minecraft.world.level.block.BedBlock': ['use', 'canSetSpawn', 'lambda$use'],
    'net.minecraft.world.entity.player.Player': ['startSleepInBed', 'tick', 'stopSleepInBed', 'bedInRange', 'isSleepingLongEnough'],
    'net.minecraft.world.entity.LivingEntity': ['startSleeping', 'stopSleeping'],
    'net.minecraft.server.players.PlayerList': ['respawn'],
    'net.minecraft.server.commands.SetSpawnCommand': ['setSpawn'],
    'net.minecraftforge.common.ForgeHooks': ['onRightClickBlock'],
    'net.minecraftforge.event.ForgeEventFactory': ['onPlayerSleepInBed', 'onPlayerSpawnSet', 'onPlayerSetSpawn', 'fireSleepingTimeCheck', 'fireSleepingLocationCheck'],
    'net.minecraftforge.common.extensions.IForgeItem': ['onItemUseFirst', 'doesSneakBypassUse'],
}
EVENTS = [
    'net/minecraftforge/event/entity/player/PlayerSetSpawnEvent.java',
    'net/minecraftforge/event/entity/player/PlayerSleepInBedEvent.java',
    'net/minecraftforge/event/entity/player/PlayerInteractEvent.java',
    'net/minecraftforge/common/extensions/IForgeItem.java',
]
audit = {'primary_files': [], 'classes': [], 'commands': [], 'events': [], 'limits': {'class_count': 15, 'class_bytes': 2097152, 'javap_bytes_per_class': 2097152, 'filtered_total_bytes': 524288, 'event_bytes_per_entry': 131072}}
for path in [MAPPED, FORGE, JAVAP]:
    audit['primary_files'].append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size})
snippets = []
with zipfile.ZipFile(MAPPED) as jar:
    for cls, wanted in CLASSES.items():
        entry = cls.replace('.', '/') + '.class'
        data = jar.read(entry)
        assert len(data) <= audit['limits']['class_bytes']
        audit['classes'].append({'entry': entry, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        argv = [str(JAVAP), '-J-Dfile.encoding=UTF-8', '-classpath', str(MAPPED), '-c', '-p', cls]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        p = subprocess.run(argv, capture_output=True, timeout=30)
        end = datetime.datetime.now(datetime.timezone.utc).isoformat()
        assert len(p.stdout) <= audit['limits']['javap_bytes_per_class']
        audit['commands'].append({'argv': argv, 'start_utc': start, 'end_utc': end, 'exit_code': p.returncode, 'raw_stdout_sha256': hashlib.sha256(p.stdout).hexdigest(), 'raw_stderr_sha256': hashlib.sha256(p.stderr).hexdigest(), 'stderr': p.stderr.decode('utf-8', errors='replace'), 'retention': 'Only selected method disassembly is retained; no whole-class export.'})
        if p.returncode != 0:
            raise RuntimeError('javap failed: ' + cls)
        (ROOT / 'NATIVE-INPUTS.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
        lines = p.stdout.decode('utf-8').splitlines()
        starts = [i for i, line in enumerate(lines) if re.match(r'^  [^ ].*\(.*\);$', line)]
        snippets.append('\n===== ' + cls + ' =====\n')
        headers = [lines[i].strip() for i in starts]
        audit['classes'][-1]['selected_headers'] = []
        for idx, i in enumerate(starts):
            if any((name + '(') in lines[i] or name == 'lambda$use' and 'lambda$use$' in lines[i] for name in wanted):
                j = starts[idx + 1] if idx + 1 < len(starts) else len(lines)
                snippets.append('\n'.join(lines[i:j]) + '\n')
                audit['classes'][-1]['selected_headers'].append(lines[i].strip())
        print(cls + ': ' + str(audit['classes'][-1]['selected_headers']))
joined = ''.join(snippets).encode('utf-8')
assert len(joined) <= audit['limits']['filtered_total_bytes']
(ROOT / 'native-methods.txt').write_bytes(joined)
with zipfile.ZipFile(FORGE) as jar, (ROOT / 'forge-public-inputs.txt').open('wb') as out:
    for entry in EVENTS:
        data = jar.read(entry)
        assert len(data) <= audit['limits']['event_bytes_per_entry']
        audit['events'].append({'entry': entry, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        out.write(('\n===== ' + entry + ' =====\n').encode())
        out.write(data)
(ROOT / 'NATIVE-INPUTS.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
print('Retained native selected bytes: ' + str(len(joined)))
