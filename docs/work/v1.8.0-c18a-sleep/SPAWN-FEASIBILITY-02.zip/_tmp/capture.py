import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

ROOT = Path(__file__).resolve().parent.parent
name = sys.argv[1]
argv = sys.argv[2:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = subprocess.run(argv, cwd=r'D:\GitHub\AdvancedRocketry-Community', capture_output=True)
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
out = ROOT / (name + '.stdout.txt')
err = ROOT / (name + '.stderr.txt')
out.write_bytes(p.stdout)
err.write_bytes(p.stderr)
meta = {
    'argv': argv, 'cwd': r'D:\GitHub\AdvancedRocketry-Community',
    'start_utc': started, 'end_utc': ended, 'exit_code': p.returncode,
    'stdout': out.name, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
    'stderr': err.name, 'stderr_sha256': hashlib.sha256(p.stderr).hexdigest(),
}
meta['argv_file_inputs'] = [{'path': a, 'sha256': hashlib.sha256(Path(a).read_bytes()).hexdigest()} for a in argv if Path(a).is_file()]
(ROOT / (name + '.command.json')).write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')
print(json.dumps(meta))
print(p.stdout[:40000].decode('utf-8', errors='replace'))
if len(p.stdout) > 40000:
    print('[Console bounded to 40000 bytes; full raw output retained]')
print(p.stderr.decode('utf-8', errors='replace'), file=sys.stderr)
sys.exit(p.returncode)
