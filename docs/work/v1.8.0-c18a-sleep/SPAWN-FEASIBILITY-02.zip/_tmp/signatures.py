import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ROOT = Path(__file__).resolve().parent.parent
JAVAP = r'C:\Program Files\Java\jdk-17.0.7\bin\javap.exe'
MAPPED = r'C:\Users\Administrator\.gradle\caches\forge_gradle\minecraft_user_repo\net\minecraftforge\forge\1.20.1-47.4.10_mapped_official_1.20.1\forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
EVENTBUS = r'C:\Users\Administrator\.gradle\caches\modules-2\files-2.1\net.minecraftforge\eventbus\6.0.5\699143dd438431d06b57416944f7cedbe52e1475\eventbus-6.0.5.jar'
CHOICES = [
    (MAPPED, 'net.minecraft.server.level.ServerPlayer', ['setRespawnPosition', 'startSleepInBed']),
    (MAPPED, 'net.minecraftforge.event.ForgeEventFactory', ['onPlayerSpawnSet']),
    (MAPPED, 'net.minecraft.world.level.block.BedBlock', ['use']),
    (MAPPED, 'net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase', ['use']),
    (MAPPED, 'net.minecraft.server.level.ServerPlayerGameMode', ['useItemOn']),
    (MAPPED, 'net.minecraft.server.network.ServerGamePacketListenerImpl', ['handleUseItemOn']),
    (EVENTBUS, 'net.minecraftforge.eventbus.api.IEventBus', ['post']),
    (EVENTBUS, 'net.minecraftforge.eventbus.EventBus', ['post']),
]
audit = {'commands': [], 'classes': [], 'primary_eventbus': {'path': EVENTBUS, 'sha256': hashlib.sha256(Path(EVENTBUS).read_bytes()).hexdigest()}, 'limits': {'class_count': 10, 'raw_bytes_per_class': 2097152, 'retained_bytes': 131072}}
out = []
for jarpath, cls, wanted in CHOICES:
    with zipfile.ZipFile(jarpath) as jar:
        entry = cls.replace('.', '/') + '.class'
        data = jar.read(entry)
        audit['classes'].append({'jar': jarpath, 'entry': entry, 'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)})
    argv = [JAVAP, '-J-Dfile.encoding=UTF-8', '-classpath', jarpath, '-p', '-s', '-c', cls]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, capture_output=True, timeout=30)
    audit['commands'].append({'argv': argv, 'start_utc': started, 'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': p.returncode, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})
    assert p.returncode == 0 and len(p.stdout) <= 2097152
    lines = p.stdout.decode('utf-8').splitlines()
    starts = [i for i, line in enumerate(lines) if re.match(r'^  [^ ].*;$', line)]
    methods = []
    selected = []
    out.append('\n===== ' + cls + ' =====\n')
    for n, i in enumerate(starts):
        if '(' not in lines[i]:
            continue
        j = starts[n + 1] if n + 1 < len(starts) else len(lines)
        descriptors = [line.strip().removeprefix('descriptor: ') for line in lines[i:j] if line.strip().startswith('descriptor: ')]
        if len(descriptors) != 1:
            raise RuntimeError('Descriptor count: ' + lines[i])
        methods.append({'signature': lines[i].strip(), 'descriptor': descriptors[0]})
        if any((name + '(') in lines[i] for name in wanted):
            selected.append(methods[-1])
            if cls in ['net.minecraftforge.eventbus.EventBus', 'net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase']:
                out.append('\n'.join(lines[i:j]) + '\n')
            else:
                out.append(lines[i] + '\n    descriptor: ' + descriptors[0] + '\n')
    for m in selected:
        m['same_descriptor_count_in_declared_class'] = sum(v['descriptor'] == m['descriptor'] for v in methods)
    audit['classes'][-1]['selected'] = selected
    print(cls + ': ' + json.dumps(selected))
joined = ''.join(out).encode()
assert len(joined) <= audit['limits']['retained_bytes']
(ROOT / 'signature-and-dispatch.txt').write_bytes(joined)
(ROOT / 'SIGNATURE-INPUTS.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
print('Retained signature/dispatch bytes: ' + str(len(joined)))
