import datetime
import hashlib
import json
import os
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ROOT = Path(__file__).resolve().parent.parent
EXPECTED = Path(r'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-spawn-feasibility-20261009-02').resolve()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ROOT == EXPECTED
assert not (ROOT / 'SHA256SUMS.txt').exists(), 'Do not overwrite a sealed leaf'
files = sorted(p for p in ROOT.rglob('*') if p.is_file())
assert len(files) <= 150
assert not any(p.is_symlink() or os.path.isjunction(p) for p in ROOT.rglob('*'))
assert all(p.resolve().is_relative_to(ROOT) for p in files)
assert not any('__pycache__' in p.parts for p in files)
assert all(p.stat().st_size < 50 * 1024 * 1024 for p in files)
assert sum(p.stat().st_size for p in files) < 100 * 1024 * 1024
command_checks = []
for path in sorted(ROOT.glob('*.command.json')):
    m = json.loads(path.read_text(encoding='utf-8'))
    for kind in ['stdout', 'stderr']:
        actual = hashlib.sha256((ROOT / m[kind]).read_bytes()).hexdigest()
        assert actual == m[kind + '_sha256'], str(path) + ' ' + kind
    command_checks.append({'command': path.name, 'raw_hashes_match': True, 'underlying_exit_code': m['exit_code']})
review = Path(r'D:\GitHub\ARCE-Task-Evidence\v1.8.0\sleep-contract-independent-20261009-01')
review_checks = []
for line in (review / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    expected, rel = line.split(maxsplit=1)
    path = review / rel.lstrip('*')
    assert path.resolve().is_relative_to(review.resolve())
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    review_checks.append(rel)
message = 'Seal generated once; every listed relative file independently reread and verified. No cleanup attempted.\n'
stdout = message.encode('utf-8')
(ROOT / 'seal.stdout.txt').write_bytes(stdout)
(ROOT / 'seal.stderr.txt').write_bytes(b'')
metadata = {
    'argv': ['python', '-B', str(Path(__file__).resolve())],
    'cwd': r'D:\GitHub\AdvancedRocketry-Community',
    'start_utc': started, 'recorded_before_seal_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code_on_success': 0, 'stdout': 'seal.stdout.txt', 'stderr': 'seal.stderr.txt',
    'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
    'stderr_sha256': hashlib.sha256(b'').hexdigest(),
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(ROOT / 'SEAL-COMMAND.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
audit = {
    'fixed_commit': '46c566dd7000d9fcd29c985d23100d8c04891eaf',
    'review_manifest_recheck_count': len(review_checks),
    'review_manifest_recheck_pass': True,
    'raw_command_output_checks': command_checks,
    'owned_cleanup_attempts': 0, 'denied_cleanup': 0, 'cleanup_retries': 0,
    'world_server_export_build_copies': 0, 'archives': 0, 'native_processes_started': 0,
    'seal_generation_attempts': 1, 'own_seal_verification_passes_on_success': 1,
    'runtime_tests_executed': 0, 'all_required_gates_open': True,
    'command_instrumentation_limits': 'Pre-harness/display reads and failed first-native internal commands do not have complete independent UTC/raw-hash metadata; see COMMAND-NOTES.md.',
}
(ROOT / 'FINAL-AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
files = sorted(p for p in ROOT.rglob('*') if p.is_file())
entries = []
for path in files:
    relative = path.relative_to(ROOT).as_posix()
    entries.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + relative)
(ROOT / 'SHA256SUMS.txt').write_text('\n'.join(entries) + '\n', encoding='utf-8')
for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    expected, relative = line.split(maxsplit=1)
    path = ROOT / relative
    assert path.resolve().is_relative_to(ROOT)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
sys.stdout.write(message)
