# Proposed qualification: ordinary native bed spawn cause

Status: **UNEXECUTED**. This plan grants no runtime/source permission. Execute
only after a reviewed task assigns an isolated worktree, exact source/test writes,
fixed commit, finite fixture copies and process/cleanup ownership. No expected
verdict is prefilled. Use this report's public candidate only if explicitly chosen;
if another mechanism is chosen, run the same behavioral/coexistence observations.

## 1. Freeze the candidate before test implementation

Record supported hosts/native bed classes, ordinary packet caller definition,
direct-mod-call exclusions, installed class/signature fingerprint, event listener
priority/receiveCanceled policy, stack traversal ceiling and allocation ceiling,
and the MATCH/NON_MATCH/INDETERMINATE handling. Decide how an unrecognized ordinary
operation is refused before the setter without canceling unrelated spawn actions.
Do not claim readiness while this behavior is unspecified.

The separate ancillary choice must be recorded by actual authority before
production dimension resources are changed. A controlled experimental fixture
must describe any natural=true experiment as such, with no release/Gate credit.
M1/M2 are separate dependencies, not assumed fixed by a spawn discriminator.

## 2. Trace actual invocation, not a fabricated event-only success

Use a real connected nonspectating living ServerPlayer in the actual packaged
Level. Drive normal bed use from a connected client through the native use-on
packet/ack path. Do not substitute FakePlayer, a direct startSleeping call,
direct startSleepInBed only, or a synthetic event for the positive ordinary case.
Direct calls are useful negative/caller tests but are not ordinary runtime proof.

Record a bounded per-attempt trace: sequence/hand, clicked and native normalized
head positions, real player/Level identity, current item counts/durability,
RightClickBlock decisions/cancellation, each item-first callback/result,
native sleep event result, native spawn-event tuple and final cancellation,
classifier result and examined frame count, and final sleep outcome/pose/occupancy.
Capture frame class+method-type in the controlled qualification harness, including
the *nearest* dispatcher. Do not log unbounded stacks or a warning every tick.
Before and after, capture native getters and exact saved SpawnDimension/X/Y/Z/
Angle/Forced field values, including presence/types and float bits where applicable.

Record native time/monster/range/obstruction refusal, actual eye cell, atmosphere
authority state/scan timings, native counter/quorum/stat/criterion, item-use
criterion, normal wake packets and chunks/tickets. Snapshotting the player's
entire mutable data as a second runtime truth store is not required.

## 3. Minimal discriminating cases

Use a distinct old home point and distinct off-world bed; also repeat with an
absent old point and old forced/angle values. Every row records actual results,
not a prefilled PASS. Keep native failures and native admin operations unchanged
except the deliberately reviewed ordinary-bed spawn veto.

| ID | Fixture/action | Evidence to compare |
|---|---|---|
| Q01 | Each native bed color, head/foot, four facings, either hand | One ordinary block/sleep event sequence; normalized head; fields before/after; native item-use criterion. |
| Q02 | Empty/nonempty main/off hands; secondary use; test item with PASS and consuming/FAIL item-first; sneak-bypass combinations | Native item-first count and whether block branch runs; no forced bed activation or new item consumption. |
| Q03 | RightClickBlock prior cancellation, useBlock DENY/ALLOW, useItem DENY, prior sleep failure, occupied player/villager, invalid/missing other half | No marker/classifier residue; preserve actual native branch ordering and prior vetoes. Test foot/head across a loaded-chunk edge and unavailable normalized half without forcing a load. |
| Q04 | In-range success, too far, obstruction, already sleeping/dead/spectator, non-natural control Level | Setter/event presence and fields compared to control; early refusals remain native. Packet reach failure and direct native range failure are distinct fixtures. |
| Q05 | Cyclic daytime and live nearby monster; native night success; compatible time result; creative | Spawn boundary before time/monster refusal; both refused and successful ordinary attempts preserve prior fields; no artificial ALLOW or native-check replacement. |
| Q06 | Outside, PENDING, missing host/profile, station VISIT removed, entry/intended eye on different region sides | Accepted air rules and M2 projection used consistently; old spawn cannot change through a rejected action; no suit/HUD override. |
| Q07 | Real native sleep in supplied room; nonempty boundary catalog and adjacent door; room scan exceeding one player-check interval | M1 installed occupancy authority revocation/repair timings; sustained/deep sleep versus premature wake recorded. Compare genuine topology/provider/supply loss, without relaxing fail-closed checks or budgets. |
| Q08 | `/spawnpoint` while physically off-world, direct mod setter forced=false to the very same bed tuple, null reset, Overworld/Nether setter | Exact native field/message/admin outcome unchanged from control; classifier NON_MATCH for unrelated setter origin. Current off-world location alone must not cause veto. |
| Q09 | Death/new-player restoration with valid Overworld point and existing old off-world native point | PlayerList setter path is not ordinary sleep; preserve old-record residual semantics and all native fields. No migration or unsafe-respawn credit. |
| Q10 | Other listener calls administrative setter from RightClickBlock, PlayerSleepInBedEvent, PlayerSetSpawnEvent and SleepingTimeCheckEvent | Closest genuine setter/factory distinguished from enclosing sleep; intentional nested admin operation preserved while ordinary bed setter remains vetoed. |
| Q11 | Listener directly posts synthetic PlayerSetSpawnEvent, or calls Forge spawn factory, inside a genuine ordinary spawn event | Innermost dispatch origin distinguished; no search past nearer dispatch to outer native sleep. Record callback effects and cancellations independently. |
| Q12 | Nested ordinary use for same/other player plus nested administrative setter; same-priority and receiveCanceled listeners | Classifier isolation, recursion depths, no action-marker leakage; characterize native/mod recursion, not an invented total rollback guarantee. |
| Q13 | Controlled throwing listener at interaction, initial sleep, spawn and late time event; throw after occupancy/criterion | Record exception propagation, actual native partial effects and retained Spawn fields; subsequent unrelated setter/reset works. Do not swallow errors to manufacture successful sleep. |
| Q14 | Cold and warmed JIT, normal and interpreted qualification launches, development and packaged reobfuscated JAR | Actual identical frame-class/MethodType match or explicit incompatibility. Member-name assumptions, descriptor uniqueness and examined-frame ceiling checked against started runtime. |
| Q15 | Frame ceiling and changed-dispatch/metadata failure via test-owned seams; JVM permission denial where controllable | Implemented INDETERMINATE behavior tested; neither silently writes home over a bed nor broadly vetoes administrative operations. Failure injection cannot stand in for genuine positive trace. |
| Q16 | Prior/late spawn cancellation; later listener clears cancellation; mod directly changes fields; alternate bed override/direct mod sleep | Document precise supported coexistence, exceptions and refused unsupported behavior. Do not claim arbitrary cancellation writers are controlled. |
| Q17 | Save while sleeping; manual leave, air-loss wake, bed removal, teleport, logout, reconnect, stop/restart and subsequent death | Native pose/occupancy cleanup; exact preserved Spawn fields; no resumed sleep or second persistent object; old invalid-home-bed fallback retained. |
| Q18 | Six actual packaged Levels, fresh and copied prior-world startup; two connected clients; installed reference workload | Real registry/type ownership, native lifecycle/quorum/time snapshots, V1/V2 and fixed performance/no-ticket observations retained separately. No ancillary decision inferred from a trace. |

## 4. Pure/native/runtime layers and execution order

1. Pure tests of signature/class sequence classifier with bounded immutable frame
   records: each adjacent frame missing/replaced, nearer synthetic dispatcher,
   nearer administrative setter, remapped names, repeated signatures, limit at
   each boundary, unsupported metadata and exception result. No class reflection
   or private API is needed. These test the decision function, not a live JVM.
2. Registered Forge tests cover native early/late branches and listener isolation.
   Restore only test-owned listeners/fixtures with explicit finally cleanup;
   do not modify an existing user's world or global bus internals.
3. Finite packaged S1 run obtains the real connected ordinary traces and native
   save/restart/death observations. Save fresh and prior-world source copies,
   source/JAR hashes, commands, config, sequence/result logs and exact fixture
   inventories. Keep all failures and distinguish development versus packaged.
4. Independent fresh-session reviewer checks actual diff and reruns relevant
   unit/native/package cases with its own Temp and scope. M1/M2, failure behavior
   and production provenance may not be resolved by author testimony alone.
5. Actual V1/V2 and reference-load obligations remain required under ADR-018;
   no software-rendering/unattended-client result replaces them.

Proposed future commands (not executed here; Windows equivalent of Required
Gate commands; substitute the *assigned* isolated worktree as cwd):

```powershell
git status --short
git rev-parse HEAD
git worktree list
Get-PSDrive -Name D
./gradlew.bat clean build
./gradlew.bat test
./gradlew.bat runData
git diff --exit-code
./gradlew.bat runGameTestServer
git diff --check
```

Check at least 10 GB free immediately before full build/GameTest/packaged launch.
Targeted proposed JUnit class filtering may be added only after actual test names
exist; do not fill a nonexistent command/test with a PASS. Keep native tests that
cannot run in the GameTest environment in the finite packaged connected-client
harness, not downgraded to direct calls. Bind each evidence cohort to a committed
source SHA and actual JAR SHA-256. Preserve exact exits, raw logs and skipped tests.

Packaged launcher arguments, test-driver transport and finite stop conditions
must be recorded in the later task using the established repository harness;
none was inspected or launched under this read-only assignment. That integration
detail remains an input, not a fabricated runnable script here.

## 5. Qualification result shape

Deliver findings first; per-case actual event/field/lifecycle traces; passed,
failed, skipped and unexecuted cases; maximum examined frames and measured
allocation/timing; exact supported and unsupported calling/mod paths; exception
and indeterminate results; old-record residual risks; own process/fixture cleanup;
leaf-relative input/evidence hashes and independent review. Separate cause-proof
from actual sleep/air/time acceptance. All Required Gates remain open until their
own implementation/release evidence and owner approval exist.
