# Official primary documentation read

The web tool opened these three primary pages during the research; the local
time check made after exploration returned `2026-10-09 03:31:20 UTC`. This is
an after-read record, not a fabricated exact browser retrieval timestamp.

- [Java 17 StackWalker](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.html):
  current-thread ordered frame stream, scoped walk lifetime, optional class
  reference and creation-time permission behavior. The estimateDepth argument
  is a hint, not a traversal limit.
- [Java 17 StackFrame](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.StackFrame.html):
  public declaring-class, MethodType, descriptor and bytecode-index APIs;
  class/MethodType require retained class references. Installed JDK disassembly
  independently confirms the platform implementation, without invoking a hook.
- [Forge 1.20.1 events](https://docs.minecraftforge.net/en/1.20.1/concepts/events/):
  event-specific cancellation/results and HIGHEST-to-LOWEST listener priorities.
  Documentation is not evidence of a native cause token or a final continuation.

No external content was downloaded into source or imported as an asset. Exact
Minecraft/Forge/EventBus call order comes from locally hashed primary classes,
not a web summary. The StackWalker provenance algorithm is an inference from
these capabilities and those inspected calls, not an endorsed Oracle/Forge
sleep-integration recipe.
