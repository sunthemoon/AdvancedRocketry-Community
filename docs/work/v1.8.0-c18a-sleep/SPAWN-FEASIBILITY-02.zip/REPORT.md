# Off-world ordinary-bed spawn preservation: public-boundary feasibility

Research task 02, 2026-10-09 UTC. Delegated worker
`/root/sleep_spawn_feasibility`. Fixed repository input:
`46c566dd7000d9fcd29c985d23100d8c04891eaf`; Minecraft 1.20.1, Forge 47.4.10,
EventBus 6.0.5, installed Java 17.0.7. This is not implementation, an accepted
contract, runtime proof, source assignment or a delivery/Gate decision.

## Findings and feasibility first

### F1. An event-only action marker does not establish the required boundary

**Verified public-API limitation.** Neither `RightClickBlock` nor
`PlayerSleepInBedEvent` supplies a continuation/finally callback around the
subsequent native bed action. The inspected `PlayerSetSpawnEvent` supplies
player, target Level key, nullable position and forced flag, but no cause,
operation token, angle or changed-spawn-message flag. A marker established in
an earlier listener can survive canceled interaction, item-first consumption,
secondary-use suppression, range/obstruction refusal or an exception, without
ever reaching the spawn event. Clearing it on a tick, time check, wake, or the
next matching setter is not an exact lifetime boundary.

A real wrapping `try/finally` would solve marker lifetime, but not itself the
cause problem: unrelated administrative setters invoked by another listener
*inside* that wrapped bed call must remain allowed. A matching player/Level/
bed-position/forced=false tuple also does not prove cause. Respawn restoration
uses the same setter and can restore forced=false bed records.

No universally preserving public interaction wrapper was established in this
research. The current proposal's B1 source-assignment prerequisite stays open.

### F2. A bounded, stateless public caller classifier is a concrete alternative

**Static feasibility candidate, not a demonstrated runtime mechanism.** Java 17
offers current-thread stack inspection and a scoped, automatically closed frame
stream. Its public frame API can report declaring class and method type; the
installed JDK implements both. This avoids inventing a persistent player flag
or re-executing the native interaction. [Java 17 StackWalker](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.html),
[StackFrame API](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/StackWalker.StackFrame.html).

At `PlayerSetSpawnEvent`, a proposed classifier can require the **innermost
actual event dispatch** and the following *contiguous* caller sequence:

```text
EventBus.post(Event, dispatcher)
EventBus.post(Event)
ForgeEventFactory.onPlayerSpawnSet(Player, ResourceKey, BlockPos, boolean)
ServerPlayer.setRespawnPosition(ResourceKey, BlockPos, float, boolean, boolean)
ServerPlayer.startSleepInBed(BlockPos)
BedBlock.use(BlockState, Level, BlockPos, Player, hand, hit)
BlockBehaviour.BlockStateBase.use(Level, Player, hand, hit)
ServerPlayerGameMode.useItemOn(ServerPlayer, Level, ItemStack, hand, hit)
ServerGamePacketListenerImpl.handleUseItemOn(native packet)
```

The callback/dispatcher frames above the innermost dispatch are not cause
evidence. The adjacent caller chain below it is. The exact public single-argument
bus-post frame must be preceded by its two-argument dispatch frame, not found by
searching arbitrarily past a nearer dispatch. This distinction excludes a
synthetic event posted directly by another listener while an outer genuine bed
setter remains on the stack. Likewise, use the **nearest** setter/factory,
not any enclosing sleep frame; a nested administrative setter has a different
immediate caller and must not be vetoed.

All selected method descriptors occur exactly once in their declaring classes
in the inspected primary JARs. A class-reference/`MethodType` fingerprint can
avoid hardcoded readable method names that change under member remapping. The
actual signatures, uniqueness counts and bridge/dispatch bytecode are retained
in [signature evidence](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/signature-and-dispatch.txt)
and [signature input audit](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/SIGNATURE-INPUTS.json).
No production remapping or JIT stack was observed. Do not hardcode bytecode
offsets or source line numbers as a portable cause API.

The candidate would cancel only a genuine matched, non-null, non-forced setter
for an eligible real player and one of the supported off-world hosts. It would
not clear an existing cancellation, manipulate native spawn fields, start sleep,
replay events, or modify item-first/secondary-use selection. It needs no mutable
action state, so refusal, reentrancy and exception unwinding cannot leave its
own stale marker. This is a proposal for qualification, not executed source.

### F3. Stack provenance is baseline-sensitive, not a semantic Forge guarantee

**Unresolved compatibility/architecture decision.** `StackWalker` is public,
but the selected sequence is an observed Minecraft/Forge/EventBus implementation
structure, not a published Forge bed-cause contract. It cannot establish object
receiver identity from frames; the event player/Level/position must still be
validated independently. Signature uniqueness is proved only for these installed
classes, not transformer-added methods, altered buses, subclasses or other
Forge versions. A mod directly calling `startSleepInBed`, calling `BedBlock.use`
without the ordinary packet pipeline, replacing the block method, or posting
its own event is deliberately outside this exact ordinary-action definition.

A proposed traversal ceiling of **64 frames**, including callback overhead and
the whole chain, is a qualification input, not a measured approved budget.
`estimateDepth` is not a ceiling: traversal must explicitly stop. Use an explicit
`MATCH / NON_MATCH / INDETERMINATE` result. Permission denial, unsupported frame
metadata, truncated traversal, changed dispatch or an unrecognized native
ordinary call may not be silently treated as safe. Neither allowing a possibly
ordinary setter nor vetoing all unknown off-world setters satisfies this task.
The admission-time diagnostic/disable strategy and its consistency with the
later spawn-event classifier still need a reviewed design and fault fixtures.
No fail-safe solution to this indeterminate case was implemented or proved here.

Other listeners can modify cancellation after this listener or mutate player
data independently. A LOWEST-priority listener is not an exclusive final commit
hook; same-priority order and `receiveCanceled` listeners still matter. Freeze
coexistence conditions rather than promising universal compatibility.
[Forge event ordering](https://docs.minecraftforge.net/en/1.20.1/concepts/events/).

**Disposition:** the stateless provenance candidate is worth an isolated,
explicitly authorized qualification. Its public API availability and static
caller chain are supported; its production effectiveness, bounded failure policy
and compatibility are not. B1 cannot be declared closed from this report.

## Exact native boundary: independently inspected facts

`J` below means the hashed installed official-mapped Forge 47.4.10 class. Numbers
are bytecode offsets, not Java source line numbers. Full selected-method evidence
is [native-methods.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/native-methods.txt).

| Boundary | Exact observation |
|---|---|
| Native packet | `handleUseItemOn` invokes the same-thread guard at 9; verifies reach and hit geometry before gameplay; checks pending teleport and `ServerLevel.mayInteract` at 235-252; invokes `gameMode.useItemOn` at 272. Native checks do not replace live station VISIT/air/loaded-host checks. |
| GameMode before event | `useItemOn` reads clicked state at 10 and checks enabled features at 24, then posts `RightClickBlock` at 41. A canceled event returns its cancellation result at 46-59. Spectator behavior then returns at 60-99. |
| Item-first | When useItem is not DENY, native `ItemStack.onItemUseFirst` runs at 125-131. Every result other than PASS returns immediately at 133-143. A bed click does not prove that bed code will run. |
| Secondary-use | At 144-216, either hand being nonempty matters. Secondary use suppresses default block use unless both hand items report sneak bypass. useBlock=ALLOW overrides that suppression, but not a consuming item-first result; DENY skips the block branch. |
| Actual block call | At 251-262 native state.use runs. A consuming result triggers the native ITEM_USED_ON_BLOCK criterion at 272-280, then returns. Otherwise item-use/cooldown/creative count restoration follows at 286-393. |
| Both bed halves | `BedBlock.use` returns CONSUME on client. On server, a foot position advances along FACING and reads the head at 24-50; a different head block returns CONSUME. Actual head input reaches sleep, not the original foot. This head read precedes `PlayerSleepInBedEvent`; a loaded-half admission preflight cannot be postponed solely to that later event. |
| Bed and occupied state | canSetSpawn checks bedWorks, not natural. If false, native explosion/removal occurs before sleep. Occupied beds can evict a villager or report occupied and return without native player sleep. Supported current packaged beds have bedWorks=true. |
| First sleep hook | `ServerPlayer.startSleepInBed` posts `PlayerSleepInBedEvent` at 7. A non-null failure returns at 15-19. The event is not a generic cancelable/result-ALLOW event. |
| Early refusals | Already sleeping/dead, natural=false, range and obstruction return before any bed spawn update: checks 39-106. A marker cannot assume it will reach a setter. |
| Spawn then late refusals | Native setter executes at 122 with current dimension, normalized head, current yaw, forced=false, sendMessage=true. Time check at 127 and monster refusal at 252-258 are later. Preserving spawn must cover these refused attempts, not only successful sleep. |
| Spawn event commit boundary | `setRespawnPosition`: post at 15, cancellation returns at 21. Native changed-spawn message is 65-72; position/Level/angle/forced fields are assigned at 75-93. Canceling this genuine event leaves those native operations unexecuted. A listener can still independently mutate data. |
| Null reset | The setter supplies OVERWORLD to the event when position is null (0-15), then resets position=null, dimension=OVERWORLD, angle=0, forced=false at 99-118. Off-world current player location is not a reason to veto null reset. |
| Administrative setter | Native `/spawnpoint` implementation calls the setter at 47 with forced=true, sendMessage=false. That tuple is useful corroboration, not a general mod/restore cause discriminator. |
| Respawn restoration | `PlayerList.respawn` reads old native fields at 22-47 and selects/uses the spawn block at 69. It calls the same setter on the new player at 345 with old forced state and sendMessage=false. Its direct caller is PlayerList, not sleep. |
| Real lifecycle retained | Successful native sleep calls Player.startSleepInBed at 261, which calls startSleeping and resets the counter. LivingEntity changes native bed occupancy, pose and sleeping position. Player.tick checks sleep time at 88 and uses normal stopSleepInBed(false,true) at 97. Saved-player load stops a saved sleeping pose at 164-174 before reading native Spawn fields. |
| Listener exceptions | Inspected EventBus dispatch catches Throwable at 121, invokes its exception handler, then rethrows at 141. These native methods provide no outer action-marker finally callback. A provenance-only observer has no action marker to clean; this is not a promise of native transaction rollback after arbitrary mod exceptions. |

Forge source documentation is retained with copyright notices in
[forge-public-inputs.txt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/forge-public-inputs.txt).
Its `RightClickBlock.setCanceled(true)` sets both useBlock and useItem to DENY.
The class exposes decisions and hit data, not a completion callback.

## Alternatives and costs

| Alternative | Assessment against this task |
|---|---|
| Earlier event marker, clear at time/tick/wake/next setter | Not established: no exact finally boundary; early exits/cancellation/item-first/exception leak; context alone can veto unrelated nested administrative operations. |
| Cancel RightClickBlock and directly call state.use under try/finally | Calls native bed checks, but skips native item-first/secondary-use/block-selection and GameMode criterion behavior; later outer listeners have not completed. Not compliant with unchanged ordinary interaction. Reproducing those checks manually is the prohibited native-check/pipeline replacement. |
| Re-enter public GameMode.useItemOn inside the event | Reposts the interaction event, changing ordering and duplicating other listeners' effects. Outer dispatch can still reject after inner effects. A recursion guard does not repair those semantics. Not a preserving wrapper. |
| Cancel initial sleep event, re-enter startSleepInBed | Duplicate sleep-event dispatch and altered veto/exception order; requires recursion state. No faithful generic event continuation demonstrated. |
| Snapshot and restore native fields after setter | Native field/message mutation already occurred. Early/late exceptions, vetoed restoration and nested administrative changes can lose correctness. Public getters/setter do not make this a preservation transaction. |
| Dedicated ARCE bed subclass or substituted player/controller | Changes registry/interaction architecture and does not cover ordinary existing vanilla beds. A bed-wide marker still does not distinguish a nested administrative setter. Requires a new product/architecture scope, not implied permission. |
| Bounded StackWalker provenance | No replay or lifetime marker; exact fixed caller chain and unique signatures verified. Needs production/JIT/remap, event-origin, indeterminate handling, reentrancy, callback and compatibility qualification; not a semantic public cause guarantee. |
| Explicit upstream semantic bed-spawn cause event | Cleanly addresses the missing datum, but requires an approved Forge/baseline/integration maintenance decision and new primary/runtime evidence. No Forge fork, AT, reflection, private invocation, mixin/coremod or runtime hook is authorized or implemented here. |

No alternative silently selects natural/time/compass/clock/portal/respawn policy.
If the owner rejects ancillary natural=true semantics, these spawn findings do
not authorize that change anyway.

## Qualification, product inputs and remaining scope

[QUALIFICATION-PLAN.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/QUALIFICATION-PLAN.md)
contains executable ordering, fixtures, traces, invariants and exact proposed
commands. **None of those implementation/runtime tests was executed.** Research
checks performed here are fixed-input integrity, public source/bytecode inspection,
signature uniqueness and seal validation only.

Inputs that remain unresolved:

1. Acceptance or rejection of the ancillary-policy candidate, by actual decision
   authority; no answer is supplied here.
2. Whether a baseline-qualified provenance discriminator is an acceptable
   architecture, its supported JVM/Forge/mod boundary and its indeterminate
   admission/setter strategy. This is not authorized by merely wanting actual
   sleep.
3. Exact meaning of ordinary bed action: this candidate targets real native
   connected-player packet use, not arbitrary mod calls or custom bed classes.
4. Independent review M1 occupancy-induced air revocation and M2 actual Space
   host/optional orbit/gap-region projection. Neither is solved by spawn cause
   classification; installed continuation evidence remains required.
5. Existing off-world native spawn records, future allow/force policy and
   migration remain outside this slice; preserving fields does not make those
   records air/access/load-safe.

**Completed:** complete prescribed governance/accepted ADR/owner/contract/review
reading; all 13 actual independent-review manifest entries verified; installed
primary-method/event and signature/dispatch inspection; alternatives and this
qualification plan. **Not completed:** B1 runtime mechanism proof, its independent
review/acceptance, M1/M2 correction, ancillary freeze, any source implementation,
native sleep/save/respawn/restart/client/performance test or full command-trace
completeness for the preliminary pre-harness exploration (see command notes).

**Files/tests:** only new files in this exclusive external leaf, including four
inspection scripts plus sealing script in _tmp, raw command outputs/input audits,
report/plan/notes/manifest. No repository file or gameplay test was changed. No
new schema, protocol, migration, asset or source provenance import was created.

**Known risks:** baseline-sensitive provenance and cancellation coexistence;
unknown failure handling; genuine mod recursion/native partial side effects;
loaded-foot/head and extension compatibility; M1/M2; old native off-world records;
unexecuted production/restart/client/reference-load evidence.

**Required Gates:** all v1.8 G0-G9 remain open; inherited acceptance remains v1.0
IN_PROGRESS under ADR-060. Prohibited commands were not waived or marked
NOT_APPLICABLE. No Gate, ledger unit, ADR or policy is accepted/delivered here.

## Commands, fixed hashes and custody

[COMMAND-NOTES.md](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/COMMAND-NOTES.md)
discloses all failed exploration and instrumentation limits. `NNN-*.command.json`
records actual subprocess argv, UTC, exits and raw stdout/stderr hashes. Internal
successful javap commands have their own UTC/exit/raw hash entries in the native
and signature audits. [INPUTS.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/INPUTS.json)
has fixed-blob hashes and review-manifest verification; native entry/tool hashes
are in [NATIVE-INPUTS.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-spawn-feasibility-20261009-02/NATIVE-INPUTS.json).

| Fixed input | SHA-256 |
|---|---|
| Complete proposed contract | `55313b1b2cb4841ce3838094e4fd702cc2e4fda8e2aa5045235d835566397c21` |
| Owner decision | `1dd0928208ffba6cda4636a632d06fe00ebbef650e6f4d9d4d2b1ed66fdf0af6` |
| Independent review REPORT | `e0466f41886a38971f51a3f5132356ccb8fcf86b68bcdeccef05bdc17ec1fc56` |
| Independent review manifest | `6b71f01a03f03344a6bc458b8a23841309a988199ca9363e94703f4ae97f84a1` |
| Accepted ADR-066 raw blob | `8a5e06789b94595f26ae04cd9bf0ee63ff37710835224a0750055427486bf63a` |
| Primary mapped Forge JAR | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Primary Forge source JAR | `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0` |
| EventBus 6.0.5 JAR | `ae8bd4ea6b32509ace6dba904698b52e13d222625488c8291a05ab870e66c1dd` |
| Installed Java17 javap | `69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d` |

Initial Main had owner changes and untracked evidence. No interest in those files,
Main, HEAD, branch, source worktrees or processes was acquired. Those mutable
interests were explicitly released to Root at task start. Root's later Main/HEAD
changes are expected: final observed HEAD is `80bbf16d9e76708b7e39c50d21b3cff1a66432ef`;
none changes these fixed-blob findings. No other agent or Claude was invoked.
Root coordinates OpenPet.

Own cleanup/seal counters: server/world/export/build copies=0, archives=0,
started native processes=0, peer process/file cleanup=0, owned cleanup attempts=0,
denied cleanup=0, cleanup retries/bypasses=0, generated Python bytecode caches=0.
The small _tmp scripts are retained reproducibility inputs, not a server/export
copy. One final seal-generation and one verification pass are recorded in
FINAL-AUDIT.json; the manifest is leaf-relative and contains no build/Temp/peer
target. Do not amend this sealed report; use a separate correction if needed.

**Next within v1.8:** independently review these alternatives, resolve the exact
ordinary-action and provenance/indeterminate contract, then explicitly authorize
isolated qualification. Combine its actual findings with M1/M2 and the authorized
ancillary disposition before assigning a default sleep source slice. No later
version work or planetary-respawn delivery follows from this research.
