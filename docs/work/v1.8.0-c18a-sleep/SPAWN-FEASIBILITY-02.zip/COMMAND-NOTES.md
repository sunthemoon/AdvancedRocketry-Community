# Actual command evidence and failed exploration

All execution in this task was read-only Git/PowerShell/Python -B or bounded
javap, plus creation of new evidence files in the exclusive leaf. No Gradle,
Minecraft/client/server, runtime hook, reflection/private invocation, AT/coremod,
install/network target, migration or world-change command was executed.

## Instrumented commands

`001-005`: Main status, HEAD, worktree list, fixed complete contract/owner blobs.
`006`: input audit failed with exit 1 because guessed docs/adr path returned no
ADR-066. `007`: actual fixed docs tree discovery returned 0; 6,612 path lines
were retained and the real docs/decisions path identified. This initial discovery
had no explicit pre-enumeration entry ceiling; later inspection uses exact paths
and explicit byte/class ceilings. It is a disclosed evidence-tooling limit,
not a claim that a broad discovery scan is a preferred pattern.

`008`: underlying input audit returned 0 and wrote its audit, but the outer
capture process returned 1 while printing UTF-8-decoded output through a GBK
console (UnicodeEncodeError). Its metadata distinguishes the underlying exit
from the wrapper failure; raw output is retained. Console encoding was made
explicit for subsequent commands. `009`: corrected input audit returned 0,
verified all 13 actual independent-review manifest entries, read full review,
and hashed 11 prescribed fixed governance/ADR blobs. It did not run the author's
or independent reviewer's scripts.

`010`: first native inspection returned 1. Its header selector did not account
for CRLF; it also failed decoding localized javap bytes as UTF-8 at ForgeHooks.
The outer raw stdout/stderr, time range and exit are retained. Per-javap metadata
for this failed attempt was held in memory and lost at that exception; its exact
internal per-command UTC/raw hash is **not available** and was not invented.
The original script version was not retained before correction. This is a
command-evidence completeness limitation of the failed exploration. `011`
independently reinspected all 11 whitelisted primary classes successfully with
explicit UTF-8, wrote all actual internal argv/UTC/exits/raw hashes, retained
only selected native methods (129,225 bytes), and extracted four Forge source
entries. The native ceilings were 15 classes, 2 MiB/class and 512 KiB selected
total; no source tree or class/archive export was produced.

`012-013`: bounded eventbus-directory discovery returned 0; first table display
truncated its path, so the second printed its FullName. Only one installed
EventBus JAR was found. `014`: eight exact-class signature/dispatch inspections
returned 0, verified each selected descriptor appears once in its declaring
class, and retained 8,924 bytes. Each internal javap command is timed/hashed.

`015`: PowerShell split the unquoted JVM property argument into `-J-Dfile` and
`.encoding=UTF-8`. javap emitted three class-not-found errors while returning
**exit 0** and only the StackFrameInfo declarations; this is failed exploration,
not a passing disassembly check. `016`: quoted argument rerun returned 0 with
empty stderr and actual installed JDK getMethodType/getDescriptor bytecode.
Both raw outputs/errors are retained; no runtime stack walking was executed.

`017-019`: fixed current-version/Gate/ADR-060 reads returned 0. `020-021`: final
Main status/HEAD reads returned 0. Root had moved HEAD and made its own additional
changes, as allowed after mutable-interest release. No peer file was modified,
acquired, staged or cleaned by this worker.

## Preliminary setup and display reads

Before the capture harness existed, the tool transcript records these actual
PowerShell reads: full TASK Get-Content; git status --short, branch --show-current,
rev-parse HEAD, worktree list; a process-name-filtered Get-Process for codex/claude/
java/javaw; and Test-Path for the exclusive leaf. They returned 0; only codex was
shown by that filter. Directory setup used New-Item for leaf/_tmp and returned 0.
Manual leaf scripts/docs were created with apply_patch. Those initial tool calls
and later bounded display reads do not have independent per-command UTC/raw
transcript hashes in this leaf. No exact timestamp or missing raw content is
manufactured. Substantive input data was subsequently captured and hashed;
inspection/manifest hashes bind the retained files, not an imagined transcript.

The capture harness bounds console display to 40,000 bytes while retaining
complete raw subprocess output. Tool-side output truncation is not a source
read failure. All Python commands use -B; no bytecode cache was created. Browser
read observations are separately documented in WEB-NOTE.md.

## Explicitly unexecuted

clean build, test, runData, git diff --exit-code, runGameTestServer, compilation,
source tests, native interaction, save/stop/restart/death, packet/client, JIT,
reobfuscation, GPU, performance and all proposed qualification cases. They are
prohibited by this research task, not passed, waived or NOT_APPLICABLE for an
implementation. No setup/error exit was relabeled as a gameplay result.
