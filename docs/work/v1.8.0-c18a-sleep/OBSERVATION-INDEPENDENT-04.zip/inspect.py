"""Owned evidence read/audit utilities; no imported input scripts or code execution."""
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile
import io

sys.stdout.reconfigure(encoding="utf-8")
mode = sys.argv[1]
if mode == "read":
    path = pathlib.Path(sys.argv[2])
    data = path.read_bytes()
    print(json.dumps({"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}))
    start = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    end = int(sys.argv[4]) if len(sys.argv) > 4 else 100000
    for index, line in enumerate(data.decode("utf-8-sig").splitlines(), 1):
        if start <= index <= end:
            print(f"{index}: {line}")
elif mode == "audit":
    for name in ["sleep-spawn-feasibility-20261009-02", "sleep-air-feasibility-20261009-02"]:
        root = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0") / name
        manifest = root / "SHA256SUMS.txt"
        covered = []
        for line in manifest.read_text(encoding="utf-8-sig").splitlines():
            digest, relative = line.split(None, 1)
            relative = relative.lstrip("*")
            path = root / relative
            if path.resolve().is_relative_to(root.resolve()) is False:
                raise SystemExit("Manifest escapes leaf")
            data = path.read_bytes()
            actual = hashlib.sha256(data).hexdigest()
            covered.append({"name": relative, "bytes": len(data), "sha256": actual, "matches": actual.lower() == digest.lower()})
        print(json.dumps({"root": str(root), "manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(), "covered_count": len(covered), "covered_bytes": sum(item["bytes"] for item in covered), "unique_names": len({item["name"] for item in covered}), "all_match": all(item["matches"] for item in covered), "covered": covered}, indent=2))
elif mode == "zip":
    commit_path = sys.argv[2]
    data = subprocess.check_output(["git", "show", commit_path])
    archive = zipfile.ZipFile(io.BytesIO(data))
    names = archive.namelist()
    if len(names) > 1000 or sum(item.file_size for item in archive.infolist()) > 20_000_000:
        raise SystemExit("ZIP budget exceeded")
    print(json.dumps({"input": commit_path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "entries": len(names), "uncompressed_bytes": sum(item.file_size for item in archive.infolist()), "crc_bad": archive.testzip(), "names": names}))
    if len(sys.argv) > 3:
        member = sys.argv[3]
        content = archive.read(member)
        print(json.dumps({"member": member, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}))
        for index, line in enumerate(content.decode("utf-8-sig").splitlines(), 1):
            print(f"{index}: {line}")
else:
    raise SystemExit("Unknown inspection mode")
