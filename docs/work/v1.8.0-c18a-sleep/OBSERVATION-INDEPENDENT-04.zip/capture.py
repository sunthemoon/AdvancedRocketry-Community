"""Owned bounded read-only review command capture; never execute input helpers."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = pathlib.Path(__file__).resolve().parent
identifier = sys.argv[1]
command = sys.argv[2:]
if not identifier.replace("-", "").isalnum() or not command:
    raise SystemExit("Expected unique identifier and exact command arguments")
out = ROOT / (identifier + ".stdout.txt")
err = ROOT / (identifier + ".stderr.txt")
if out.exists() or err.exists():
    raise SystemExit("Capture ID already exists")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd="D:/GitHub/AdvancedRocketry-Community", capture_output=True, check=False)
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
out.write_bytes(result.stdout)
err.write_bytes(result.stderr)
record = {
    "id": identifier, "cwd": "D:/GitHub/AdvancedRocketry-Community", "argv": command,
    "started_utc": started, "ended_utc": ended, "exit_code": result.returncode,
    "stdout": out.name, "stdout_bytes": len(result.stdout), "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
    "stderr": err.name, "stderr_bytes": len(result.stderr), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
}
with (ROOT / "COMMANDS.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(record, ensure_ascii=True) + "\n")
print(json.dumps(record, ensure_ascii=True))
if result.stdout:
    for number, line in enumerate(result.stdout.decode("utf-8", errors="replace").splitlines(), 1):
        print(f"{number}: {line}")
if result.stderr:
    print("STDERR:")
    print(result.stderr.decode("utf-8", errors="replace"))
raise SystemExit(result.returncode)
