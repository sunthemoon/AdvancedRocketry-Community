"""Read installed primary JAR entries and bounded public javap excerpts only."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
ROOT = pathlib.Path(__file__).resolve().parent
JAR = pathlib.Path("C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar")
FORGE = pathlib.Path("C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar")
JAVAP = pathlib.Path("C:/Program Files/Java/jdk-17.0.7/bin/javap.exe")
FILES = [JAR, FORGE, JAVAP]
EXPECTED = ["95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e", "918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0", "69a40703b689ad2db695ea126a0f9a81ccdab85f6b95fa53c4ea0ca4f0c0205d"]
audit = {"files": [], "classes": [], "commands": [], "forge_sources": []}
for path, expected in zip(FILES, EXPECTED):
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    audit["files"].append({"path": str(path), "bytes": len(data), "sha256": digest, "expected_match": digest == expected})
    if digest != expected:
        raise SystemExit("Primary input hash differs: " + str(path))
CLASSES = {
    "net.minecraft.server.players.PlayerList": ["placeNewPlayer", "load", "remove", "getPlayer"],
    "net.minecraft.network.Connection": ["channelActive", "setListener", "setPacketListener", "isConnected", "send", "disconnect", "getPacketListener"],
    "net.minecraft.server.network.ServerGamePacketListenerImpl": ["handleUseItemOn", "handleAcceptTeleportPacket", "teleport", "ServerGamePacketListenerImpl", "isAcceptingMessages"],
    "net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket": ["ClientboundPlayerPositionPacket", "getId"],
    "net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket": ["ServerboundAcceptTeleportationPacket", "getId"],
    "net.minecraft.network.protocol.game.ServerboundUseItemOnPacket": ["ServerboundUseItemOnPacket", "getHand", "getHitResult", "getSequence"],
    "net.minecraft.server.level.ServerPlayerGameMode": ["useItemOn"],
    "net.minecraft.server.level.ServerPlayer": ["startSleepInBed", "stopSleepInBed", "setRespawnPosition", "addAdditionalSaveData", "getRespawnPosition", "getRespawnAngle", "getRespawnDimension", "isRespawnForced"],
    "net.minecraft.world.level.block.BedBlock": ["use"],
    "net.minecraftforge.event.ForgeEventFactory": ["onPlayerSpawnSet"],
}
excerpts = []
with zipfile.ZipFile(JAR) as jar:
    for name, methods in CLASSES.items():
        entry = name.replace(".", "/") + ".class"
        data = jar.read(entry)
        if len(data) > 2_000_000:
            raise SystemExit("Class budget exceeded")
        audit["classes"].append({"entry": entry, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        argv = [str(JAVAP), "-J-Dfile.encoding=UTF-8", "-classpath", str(JAR), "-public", "-c", "-s", name]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(argv, capture_output=True, check=False, timeout=45)
        end = datetime.datetime.now(datetime.timezone.utc).isoformat()
        audit["commands"].append({"argv": argv, "started_utc": start, "ended_utc": end, "exit_code": result.returncode, "stdout_bytes": len(result.stdout), "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(), "stderr_bytes": len(result.stderr), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()})
        if result.returncode or len(result.stdout) > 2_000_000:
            raise SystemExit("javap failure/budget exceeded")
        text = result.stdout.decode("utf-8")
        sections = re.split(r"(?m)(?=^  public .+;\r?$)", text)
        selected = [section for section in sections if any(re.search(r"(?:\.| )" + re.escape(method) + r"\(", section.splitlines()[0]) for method in methods)]
        if not selected:
            raise SystemExit("No selected methods: " + name)
        excerpts.append("# " + name + "\n" + "\n".join(selected))
with zipfile.ZipFile(FORGE) as jar:
    for entry in ["net/minecraftforge/event/entity/player/PlayerSetSpawnEvent.java"]:
        data = jar.read(entry)
        audit["forge_sources"].append({"entry": entry, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        excerpts.append("# " + entry + "\n" + data.decode("utf-8"))
(ROOT / "NATIVE-AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8", newline="\n")
(ROOT / "native-public.txt").write_text("\n".join(excerpts), encoding="utf-8", newline="\n")
print(json.dumps({"files_verified": len(audit["files"]), "classes_inspected": len(audit["classes"]), "javap_calls": len(audit["commands"]), "forge_source_entries": len(audit["forge_sources"]), "selected_bytes": (ROOT / "native-public.txt").stat().st_size}))
