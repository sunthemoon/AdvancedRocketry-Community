"""Finalize this owned evidence leaf once; validate captures and compact seal."""
import datetime
import hashlib
import json
import pathlib
import sys

sys.stdout.reconfigure(encoding="utf-8")
root = pathlib.Path(__file__).resolve().parent
expected = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/sleep-observation-proposal-independent-20261009-04").resolve()
if root != expected:
    raise SystemExit("Unexpected evidence leaf")
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = root / "SHA256SUMS.txt"
receipt = root / "SEAL-RESULT.json"
index = root / "INPUT-INDEX.json"
if any(path.exists() for path in [manifest, receipt, index]):
    raise SystemExit("Final outputs already exist; refusing overwrite")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def contained_file(path):
    if not path.resolve().is_relative_to(root):
        raise SystemExit("File escapes evidence leaf")
    if getattr(path.stat(follow_symlinks=False), "st_file_attributes", 0) & 0x400:
        raise SystemExit("Reparse point in evidence leaf")
    if path.is_symlink():
        raise SystemExit("Symbolic link in evidence leaf")

contained_file(root)
commands = [json.loads(line) for line in (root / "COMMANDS.jsonl").read_text(encoding="utf-8").splitlines()]
fixed_inputs = []
for command in commands:
    for stream in ["stdout", "stderr"]:
        path = root / command[stream]
        contained_file(path)
        data = path.read_bytes()
        if len(data) != command[stream + "_bytes"] or digest(data) != command[stream + "_sha256"]:
            raise SystemExit("Captured output changed: " + path.name)
    argv = command["argv"]
    if len(argv) == 3 and argv[:2] == ["git", "show"] and command["exit_code"] == 0:
        fixed_inputs.append({"git_object": argv[2], "bytes": command["stdout_bytes"], "sha256": command["stdout_sha256"], "raw_output": command["stdout"]})
index.write_text(json.dumps({"fixed_commit": "ff1e60c6d527825e2c68b5675d18a568cda791ed", "git_inputs": fixed_inputs, "captured_commands_verified": len(commands), "note": "Other installed and external primary identities are in NATIVE-AUDIT.json and primary-audit.stdout.txt; no input helper was executed."}, indent=2) + "\n", encoding="utf-8", newline="\n")
files = []
for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
    contained_file(path)
    if path.is_file() and path not in [manifest, receipt]:
        data = path.read_bytes()
        files.append((path.relative_to(root).as_posix(), len(data), digest(data)))
manifest.write_text("".join(f"{sha}  {name}\n" for name, size, sha in files), encoding="utf-8", newline="\n")
verified = []
for line in manifest.read_text(encoding="utf-8").splitlines():
    sha, name = line.split("  ", 1)
    path = root / name
    contained_file(path)
    data = path.read_bytes()
    if digest(data) != sha:
        raise SystemExit("Final seal mismatch")
    verified.append((name, len(data)))
if len({name for name, size in verified}) != len(files):
    raise SystemExit("Duplicate sealed file name")
report = root / "REPORT.md"
result = {"leaf": str(root), "argv": [sys.executable, *sys.argv], "started_utc": start, "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit_code": 0, "manifest": "SHA256SUMS.txt", "manifest_bytes": manifest.stat().st_size, "manifest_sha256": digest(manifest.read_bytes()), "report": "REPORT.md", "report_bytes": report.stat().st_size, "report_sha256": digest(report.read_bytes()), "covered_files": len(verified), "covered_bytes": sum(size for name, size in verified), "all_hashes_verified": True, "captured_commands_verified": len(commands), "fixed_git_inputs": len(fixed_inputs), "coverage_exclusions": ["SHA256SUMS.txt (manifest)", "SEAL-RESULT.json (non-cyclic verification receipt)"], "full_leaf_files": len(verified) + 2}
receipt.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
text = json.dumps(result, indent=2)
print(text)
