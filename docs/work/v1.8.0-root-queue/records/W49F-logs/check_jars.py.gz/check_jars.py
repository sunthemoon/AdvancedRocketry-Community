import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

record = json.loads(Path('docs/provenance/v1.8.0-c18d-new-art.json').read_text(encoding='utf-8'))
original = json.loads(subprocess.check_output(['git', 'show', '453f1fd5:docs/provenance/v1.8.0-c18d-new-art.json']))
old_hashes = {entry['target_path'].split('/resources/', 1)[1]: entry['target_sha256']
              for entry in original['entries'] if entry['generator_class'].endswith('.V180ClosureModels')}
bindings = [entry for entry in record['entries'] if entry['generator_class'].endswith('.V180ClosureModels')]
assert len(bindings) == 13
jars = [jar for jar in Path('build/libs').glob('*.jar') if not jar.name.endswith('-api.jar')]
assert len(jars) == 2, jars
result = {'tested_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'jars': []}
for jar_path in sorted(jars):
    checks = []
    with zipfile.ZipFile(jar_path) as jar:
        names = jar.namelist()
        for entry in bindings:
            resource = entry['target_path'].split('/resources/', 1)[1]
            assert names.count(resource) == 1, (jar_path, resource, names.count(resource))
            expected = Path(entry['target_path']).read_bytes()
            actual = jar.read(resource)
            assert actual == expected, (jar_path, resource)
            digest = hashlib.sha256(actual).hexdigest()
            assert digest == entry['target_sha256'] == old_hashes[resource], resource
            checks.append({'resource': resource, 'committed_target': entry['target_path'], 'copies': 1, 'sha256': digest, 'v18_bytes': True, 'unchanged_w49_bytes': True})
    result['jars'].append({'artifact_name': jar_path.name, 'sha256': hashlib.sha256(jar_path.read_bytes()).hexdigest(), 'models': checks})
Path('build/w49f/jar-check.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print('PASS: all 13 models occur exactly once in both runtime and sources JARs, identical to v1.8 and original W49 bytes.')
