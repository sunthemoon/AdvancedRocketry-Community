import hashlib
import json
import re
import subprocess
from pathlib import Path

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

historical = ['src/generated/' + version for version in ('v0.2', 'v0.4', 'v0.8', 'v1.2', 'v1.5', 'v1.6', 'v1.7')]
historical += ['docs/provenance/' + version + '-generated-resources.json' for version in ('v0.2.0', 'v0.4.0', 'v0.8.0')]
subprocess.run(['git', 'diff', '--exit-code', '453f1fd5', '--', *historical, 'build.gradle'], check=True)
assert not git('status', '--porcelain')
assert not Path('build/gametest/world').exists()
lock = Path('D:/GitHub/ARCE-Task-Evidence/locks/heavy-jvm/owner.txt')
owner = lock.read_text().strip() if lock.exists() else None
assert owner is None or not owner.startswith('W49F-'), owner
record = json.loads(Path('docs/provenance/v1.8.0-c18d-new-art.json').read_text())
for entry in record['entries']:
    actual = hashlib.sha256(Path(entry['source_path']).read_bytes()).hexdigest()
    assert actual == entry['source_sha256']
    authored = subprocess.check_output(['git', 'show', entry['authoring_commit'] + ':' + entry['source_path']])
    assert hashlib.sha256(authored).hexdigest() == actual
    assert hashlib.sha256(Path(entry['target_path']).read_bytes()).hexdigest() == entry['target_sha256']
suite = Path('build/w49f/python-suite.log').read_text(encoding='utf-8')
match = re.search(r'Ran (\d+) tests in ([0-9.]+)s', suite)
assert match
assert Path('build/w49f/python-suite.exit.txt').read_text().strip() == '0'
assert 'OK (skipped=4)' in suite
summary = {'tested_source_commit': git('rev-parse', 'HEAD'), 'branch': git('branch', '--show-current'),
           'historical_files_and_build_script_unchanged_from': git('rev-parse', '453f1fd5'),
           'historical_paths': historical, 'source_and_target_hashes_verified': len(record['entries']),
           'java_unit_suite': json.loads(Path('build/w49f/unit-summary.json').read_text()),
           'python_suite': {'tests': int(match.group(1)), 'seconds': float(match.group(2)),
                            'failures': 0, 'errors': 0, 'skipped': 4,
                            'skip_reason': 'Historical v0.2, v0.3, v0.4 and v0.5 local build artifacts are absent.',
                            'temp': 'C:/Users/Administrator/AppData/Local/Temp'},
           'gametest': {'required_passed': 1057, 'fatal': 0, 'expected_error': 97, 'expected_warn': 255,
                        'unchanged_expectations': 100, 'world_removed': True},
           'committed_source_datagen_clean': 'written: 0' in Path('build/w49f/runData.log').read_text(),
           'worker_heavy_lock_released': True, 'other_worker_lock_owner_at_check': owner}
assert summary['committed_source_datagen_clean']
Path('build/w49f/verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
print('PASS: clean committed source, 29 source/target hashes, seven historical roots, three sealed records, unchanged build script, removed world and released worker lock.')
