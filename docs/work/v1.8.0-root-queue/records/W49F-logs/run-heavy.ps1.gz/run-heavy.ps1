param([Parameter(Mandatory=$true)][string]$Task)
$ErrorActionPreference = 'Stop'
$lock = 'D:\GitHub\ARCE-Task-Evidence\locks\heavy-jvm'
$ownerFile = Join-Path $lock 'owner.txt'
$deadline = (Get-Date).AddHours(3)
while ($true) {
    try {
        New-Item -ItemType Directory -Path $lock -ErrorAction Stop | Out-Null
        break
    } catch {
        if (-not (Test-Path -LiteralPath $lock)) { throw }
        if (((Get-Date) - (Get-Item -LiteralPath $lock).CreationTime).TotalHours -ge 3 -or (Get-Date) -ge $deadline) {
            throw 'Heavy-JVM lock is stale or the bounded wait expired; not removing foreign lock.'
        }
        Write-Output "Waiting for heavy-JVM lock: $(Get-Content -LiteralPath $ownerFile -ErrorAction SilentlyContinue)"
        Start-Sleep -Seconds 60
    }
}
try {
    Set-Content -LiteralPath $ownerFile -Value "W49F-$Task PID=$PID $(Get-Date -Format o)"
    Get-PSDrive C,D | ForEach-Object {
        if ($_.Free -lt 10GB) { throw "Drive $($_.Name) has less than 10 GB free" }
        Write-Output "Drive $($_.Name): $([math]::Round($_.Free/1GB,2)) GB free"
    }
    .\gradlew.bat --offline $Task --console=plain 2>&1 | Tee-Object -FilePath "build/w49f/$Task.log"
    $code = $LASTEXITCODE
} finally {
    if ((Get-Item -LiteralPath $lock).FullName -ne 'D:\GitHub\ARCE-Task-Evidence\locks\heavy-jvm' -or
        -not ((Get-Content -LiteralPath $ownerFile) -match "^W49F-$Task PID=$PID ")) {
        throw 'Refusing to release an unowned lock'
    }
    # Remove only our owner file and then the empty lock, without recursive deletion.
    Remove-Item -LiteralPath $ownerFile -Force
    Remove-Item -LiteralPath 'D:\GitHub\ARCE-Task-Evidence\locks\heavy-jvm' -Force
}
exit $code
