import hashlib
import json
import subprocess
from pathlib import Path

record_path = Path('docs/provenance/v1.8.0-c18d-new-art.json')
record = json.loads(record_path.read_text(encoding='utf-8'))
authoring_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
source_commit = subprocess.check_output(['git', 'rev-parse', '453f1fd5'], text=True).strip()
branch = subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip()
updated = 0
for entry in record['entries']:
    if not entry['generator_class'].endswith('.V180ClosureModels'):
        continue
    asset_path = entry['target_path'].split('/resources/', 1)[1]
    entry['target_path'] = 'src/generated/v1.8/resources/' + asset_path
    actual = hashlib.sha256(Path(entry['target_path']).read_bytes()).hexdigest()
    assert actual == entry['target_sha256'], asset_path
    entry['source_sha256'] = hashlib.sha256(Path(entry['source_path']).read_bytes()).hexdigest()
    entry['source_branch'] = branch
    entry['source_commit'] = source_commit
    entry['authoring_commit'] = authoring_commit
    entry['transformation'] = [
        'Generate the W49 NEW texture binding as a v1.8 copy in the provider output; '
        'retain the asset-relative model/item ID and identical JSON bytes. Historical '
        'generated resources and their sealed provenance remain immutable; Root excludes '
        'superseded copies from packaged resources. No copied legacy JSON.'
    ]
    updated += 1
assert updated == 13
core = {key: value for key, value in record.items() if key != 'review'}
canonical = (json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
record['review']['content_digest'] = hashlib.sha256(canonical).hexdigest()
assert record['review']['status'] == 'PENDING_HUMAN_REVIEW'
record_path.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'Updated {updated} binding entries at authoring commit {authoring_commit}; all target hashes unchanged.')
