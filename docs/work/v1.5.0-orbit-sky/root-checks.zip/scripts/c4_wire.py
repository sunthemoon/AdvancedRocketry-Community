from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
S = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'


def edit(path, pairs):
    s = path.read_text(encoding='utf-8')
    for old, new in pairs:
        assert s.count(old) == 1, (path.name, old[:100])
        s = s.replace(old, new)
    path.write_text(s, encoding='utf-8', newline='\n')


edit(S / 'celestial/network/CelestialNetwork.java', [
    ('''/** Instance-owned, exact-version SimpleChannel for the display snapshot. */''',
     '''/** Instance-owned, exact-version SimpleChannel for the display snapshot and the station sky context. */'''),
    ('''    private static final String PROTOCOL_VERSION = "2";''',
     '''    /** 3: ADR-047 added message 1, the station sky context. */
    private static final String PROTOCOL_VERSION = "3";'''),
    ('''                .consumerMainThread(CelestialSnapshotPacket::handle)
                .add();
    }''', '''                .consumerMainThread(CelestialSnapshotPacket::handle)
                .add();
        channel.messageBuilder(StationSkyContextPacket.class, 1, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(StationSkyContextPacket::encode)
                .decoder(StationSkyContextPacket::decode)
                .consumerMainThread(StationSkyContextPacket::handle)
                .add();
    }'''),
    ('''    public void send(ServerPlayer player, CelestialSnapshotPacket packet) {
        channel.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }''', '''    public void send(ServerPlayer player, CelestialSnapshotPacket packet) {
        channel.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    public void sendSkyContext(ServerPlayer player, StationSkyContextPacket packet) {
        channel.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }'''),
])

edit(S / 'AdvancedRocketryCommunity.java', [
    ('''        MinecraftForge.EVENT_BUS.addListener(snapshotSynchronizer::onDatapackSync);
''', '''        MinecraftForge.EVENT_BUS.addListener(snapshotSynchronizer::onDatapackSync);
        StationSkyContextService skyContexts = new StationSkyContextService(celestialNetwork::sendSkyContext);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerChangedDimension);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerRespawn);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onPlayerLoggedOut);
        MinecraftForge.EVENT_BUS.addListener(skyContexts::onServerStopping);
'''),
    ('''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialNetwork;
''', '''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialNetwork;
import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.StationSkyContextService;
'''),
])

# Sky selection: an optional orbited body from the station sky context.
edit(S / 'celestial/visual/SkySelection.java', [
    ('''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialSnapshot;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;''', '''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialSnapshot;
import java.util.Map;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;'''),
    ('''    private ResourceLocation previousLevel;
    private Selection selected;

    public Selection resolve(ResourceLocation level, CelestialSnapshot snapshot, Map<ResourceLocation, SkyProfile> profiles) {
        if (level != null && level.equals(previousLevel) && snapshot == previousSnapshot && profiles == previousProfiles) {
            return selected;
        }
        previousLevel = level;
        previousSnapshot = snapshot;
        previousProfiles = profiles;
        selected = null;''', '''    private ResourceLocation previousLevel;
    private Optional<ResourceLocation> previousOrbit = Optional.empty();
    private Selection selected;

    public Selection resolve(ResourceLocation level, CelestialSnapshot snapshot, Map<ResourceLocation, SkyProfile> profiles) {
        return resolve(level, snapshot, profiles, Optional.empty());
    }

    /**
     * ADR-047: with a station sky context, the Level's sky also shows the orbited body, and the sun
     * follows that body's solar intensity. An unknown body or a body without a profile adds nothing.
     */
    public Selection resolve(ResourceLocation level, CelestialSnapshot snapshot, Map<ResourceLocation, SkyProfile> profiles,
                             Optional<ResourceLocation> orbit) {
        if (level != null && level.equals(previousLevel) && snapshot == previousSnapshot && profiles == previousProfiles
                && orbit.equals(previousOrbit)) {
            return selected;
        }
        previousLevel = level;
        previousSnapshot = snapshot;
        previousProfiles = profiles;
        previousOrbit = orbit;
        selected = null;'''),
    ('''        if (match != null) {
            SkyProfile profile = profiles.get(match.visualProfile());
            if (profile != null) {
                selected = new Selection(match.bodyId(), match.visualProfile(), profile, match.pressure(), match.solarIntensity());
            }
        }
        return selected;
    }''', '''        if (match != null) {
            SkyProfile profile = profiles.get(match.visualProfile());
            if (profile != null) {
                Optional<Orbit> orbited = orbit.flatMap(body -> orbited(body, snapshot, profiles));
                selected = new Selection(match.bodyId(), match.visualProfile(), profile, match.pressure(),
                        orbited.map(Orbit::solarIntensity).orElse(match.solarIntensity()), orbited);
            }
        }
        return selected;
    }

    private static Optional<Orbit> orbited(ResourceLocation body, CelestialSnapshot snapshot,
                                           Map<ResourceLocation, SkyProfile> profiles) {
        for (var entry : snapshot.entries()) {
            if (entry.bodyId().equals(body)) {
                SkyProfile profile = profiles.get(entry.visualProfile());
                return profile == null ? Optional.empty()
                        : Optional.of(new Orbit(entry.bodyId(), profile, entry.solarIntensity()));
            }
        }
        return Optional.empty();
    }'''),
    ('''        previousProfiles = null;
        selected = null;
    }

    public record Selection(ResourceLocation bodyId, ResourceLocation profileId, SkyProfile profile,
            double pressure, double solarIntensity) { }''', '''        previousProfiles = null;
        previousOrbit = Optional.empty();
        selected = null;
    }

    /** {@code solarIntensity} is the effective sun: the orbited body's when there is one. */
    public record Selection(ResourceLocation bodyId, ResourceLocation profileId, SkyProfile profile,
            double pressure, double solarIntensity, Optional<Orbit> orbit) {
        public Selection(ResourceLocation bodyId, ResourceLocation profileId, SkyProfile profile,
                         double pressure, double solarIntensity) {
            this(bodyId, profileId, profile, pressure, solarIntensity, Optional.empty());
        }
    }

    /** The body a station orbits, as its sky shows it. */
    public record Orbit(ResourceLocation bodyId, SkyProfile profile, double solarIntensity) { }'''),
])

edit(S / 'client/sky/PlanetarySkyClient.java', [
    ('''        return SELECTION.resolve(level.dimension().location(), CelestialClientCache.snapshot().orElse(null), RESOURCES.profiles());''',
     '''        return SELECTION.resolve(level.dimension().location(), CelestialClientCache.snapshot().orElse(null),
                RESOURCES.profiles(), StationSkyContextCache.orbitBody());'''),
    ('''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialClientCache;
''', '''import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.CelestialClientCache;
import io.github.sunthemoon.advancedrocketrycommunity.celestial.network.StationSkyContextCache;
'''),
    ('''    public static void logout() {
        cleanup(false);
    }''', '''    public static void logout() {
        StationSkyContextCache.clear();
        cleanup(false);
    }

    /** A new Level (dimension change or respawn): the server re-sends the station sky context. */
    public static void levelChanged() {
        StationSkyContextCache.clear();
    }'''),
])

edit(S / 'client/sky/ClientSkyEvents.java', [
    ('''    @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut event) {
        PlanetarySkyClient.logout();
    }''', '''    @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut event) {
        PlanetarySkyClient.logout();
    }

    @SubscribeEvent public static void levelChanged(ClientPlayerNetworkEvent.Clone event) {
        PlanetarySkyClient.levelChanged();
    }'''),
])

edit(S / 'client/sky/PlanetarySkyRenderer.java', [
    ('''/** Five fixed GPU meshes; no profile-dependent geometry, textures or per-frame uploads. */''',
     '''/**
 * Five fixed GPU meshes; no profile-dependent geometry, textures or per-frame uploads. The orbited body
 * of a station (ADR-047) reuses the sun disc mesh, turned toward the nadir and tinted.
 */'''),
    ('''    private boolean failed;
''', '''    private boolean failed;
    /** Angular radius of the orbited body seen from a station: a large disc below it. */
    private static final double ORBITED_BODY_DEGREES = 35;
'''),
    ('''            tint(0xFFFFFF, 1, SkyMath.stars(profile, selection.pressure(), daylight));
            draw(stars, rotating, projection);''', '''            tint(0xFFFFFF, 1, SkyMath.stars(profile, selection.pressure(), daylight));
            draw(stars, rotating, projection);
            if (selection.orbit().isPresent()) {
                float radius = (float) (100 * Math.tan(Math.toRadians(ORBITED_BODY_DEGREES)));
                var below = new Matrix4f(view).rotateX((float) Math.PI).scale(radius, 1, radius);
                tint(selection.orbit().orElseThrow().profile().dayColor(), 1, 1);
                draw(sun, below, projection);
            }'''),
])
print('ok')
