"""Archive the ADR-047 contract review into the orbit-sky packet."""
import hashlib, json, zipfile
from pathlib import Path
OUT = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.5.0-orbit-sky')
SRC = Path(open('C:/Users/Administrator/AppData/Local/Temp/arce-v150-sky-review-current.txt').read().strip().replace('/c/', 'C:/'))
sha = lambda b: hashlib.sha256(b).hexdigest()
rows = []
with zipfile.ZipFile(OUT / 'independent-review-sky.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(SRC.rglob('*')):
        if p.is_file():
            rel = p.relative_to(SRC).as_posix(); data = p.read_bytes()
            z.writestr(zipfile.ZipInfo(rel, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
(OUT / 'independent-review-sky-files.json').write_text(json.dumps(rows, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
raw = (OUT / 'independent-review-sky.zip').read_bytes()
ev = json.loads((OUT / 'evidence-archives.json').read_text())
ev['archives'].append({'name': 'independent-review-sky.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
                       'manifest': 'independent-review-sky-files.json', 'source_directory': str(SRC), 'excluded': [],
                       'reviewed': 'ADR-047 revision 1 against 50a0f42'})
(OUT / 'evidence-archives.json').write_text(json.dumps(ev, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
print('PASS', len(rows), sha(raw))
