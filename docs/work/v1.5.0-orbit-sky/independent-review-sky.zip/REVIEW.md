# Independent contract review — ADR-047 Per-station sky context (ORBIT-03), revision 1

- Subject: `docs/decisions/ADR-047-PER-STATION-SKY-CONTEXT.md` (uncommitted, PROPOSED, revision 1)
- Code baseline: commit `50a0f42` on `codex/v1.5.0-orbital-station-warp`. All code references below
  are `git show 50a0f42:<path>` line numbers unless marked otherwise.
- Method: read-only. I read the ADR, AGENTS.md, the v1.5 plan, COMPLETION-PLAN C4, the v1.5
  implementation log, ADR-036/041/044/046, docs 07/15/17, the planetary sky guide and the code
  listed in the brief. I ran no Gradle, no server and no write git command.
- Working-tree note: while the review was running, uncommitted implementation files appeared in
  the working tree (see F13). They were not the subject of this review, and every finding below
  is about the ADR text measured against `50a0f42`.

## Verdict

**Accept with changes.** The core architecture is sound:
- the context is derived on the server;
- it is one bounded S2C message on the existing display channel;
- it carries no station identity;
- it uses the O(1) `findAt` lookup, with no chunk access;
- it follows ADR-046's ORBIT-03 carve-out.

Revision 1 still has three High contract defects:
- F1: the disc is absent or invisible for the default Earth orbit and for the Moon;
- F2: the disc sits exactly where the Space sun always is, because Space uses fixed time 18000;
- F3: the client clears the context on a Level change, but the server re-sends only when the
  context differs, so the sky stays stale.

It also has four Medium issues. All of these must be fixed in a revision 2 before acceptance.
None requires a different architecture.

## Findings

### F1 — High — The disc colour/profile rule makes the feature absent or invisible for most stations

**Evidence**

The ADR ties the disc to "the body present in the snapshot with a profile", tinted with "the
body profile's day colour", and says "a body without a sky profile means the generic Space sky".
Against the packaged data:

- **Earth** has `visual_profile: advancedrocketrycommunity:earth`
  (`src/generated/v0.3/.../celestial_bodies/earth.json:16`). No `celestial_visuals/earth.json`
  exists: the only packaged profiles are moon, space, mars and venus (`src/generated/v1.4/...`,
  `SkyProfiles.java:12-22`). This is deliberate: ADR-036:17 says "Earth retains the vanilla
  renderer". Stations are created around the body under the player's current Level
  (`StationManager.java:74-80`), so an Earth orbit is the default case. Under rule 1 of the ADR,
  those stations see no change at all.
- **Moon**: the day colour is `0x010208` (`celestial_visuals/moon.json` `day_color` 66056;
  `SkyProfiles.java:13`). The Space sky is `0x01030B` (`SkyProfiles.java:15`). The disc would be
  practically invisible. The day colour is a surface sky colour, not the body's appearance from
  orbit.
- **Gas giant**: orbitable, with profile `gas_giant`, which has no resource
  (`gas_giant.json:10-12,26`). No disc.
- Only Mars, Venus and Tau Ceti e (which uses the mars profile) would show anything.

The stated consequence "Players see the body their station orbits" is therefore false for the
default and most common cases. Plan §11.1 (orbit body, star and sun shown correctly) cannot be
met.

**Required change**

Define a colour source for the orbited body that does not depend on the surface-sky day colour.
Either:
- (a) a fixed neutral default colour when the body has no profile, plus a minimum-luminance floor,
  or a fixed colour, when the profile colour is too dark against the Space sky; or
- (b) an optional `orbit_color` sky-profile field with a default. ADR-036:39 requires "defaults or
  a new explicit schema" for new fields. This option also needs DataGen values and provenance.

Add a table of the expected appearance of every packaged orbitable body (Earth, Moon, Mars,
Venus, gas giant, Tau Ceti e), and a JUnit test that checks it.

### F2 — High — The nadir disc sits exactly on the permanently-nadir Space sun; draw order is unspecified

**Evidence**

- The Space dimension type has `fixed_time: 18000` (`src/generated/v1.4/.../dimension_type/space.json:6`).
- With `DimensionType.timeOfDay(18000)` = 0.5, `level.getSunAngle()` = π.
- The renderer draws the sun mesh at local +Y rotated by `rotateX(angle)`
  (`PlanetarySkyRenderer.java:58-65`, `SkyGeometry.sun`, y = 100). The Space sun is therefore
  always straight down, at the nadir.
- The ADR puts the orbited body's disc "toward the nadir … at a fixed angular size".

The two changes the ADR adds therefore collide permanently. Either:
- the disc (much larger than the sun: ≤ 12° radius, halo ≤ 30°) eclipses the sun, and "the sun's
  size and opacity follow the orbited body's solar intensity" is never visible; or
- the sun is drawn over the planet, which is physically wrong.

The ADR gives no disc angle, no angular radius and no draw order. The deferred per-station sun
angle (ADR-041, stored 270°) makes this more pressing, not less.

**Required change**

Specify all of the following:
- the disc direction and angular radius, as numbers;
- the draw order (for example sphere → horizon → stars → sun/halo → disc, opaque);
- the intended relation to the sun at the fixed Space time. Either state that the body
  deliberately eclipses the sun (a station in the planet's shadow) and drop or reword the sun
  claim, or offset the disc or the sun so that both are visible.

Add a pure JUnit test for the angular relation between the disc and the sun at `fixed_time`
18000.

### F3 — High — The client clears on a Level change, the server sends only on change: the sky goes stale

**Evidence**

- Server side of the ADR: the server "sends it only when it differs from the last one sent".
  There is no server-side reset.
- Client side of the ADR: "a Level change clears it, and the server re-sends it within 10 ticks".
  Under the server rule, that re-send does not happen when the context is unchanged.
- Space has `bed_works: true` (`space.json:3`), so respawning inside your own station is a normal
  case.
- Forge 1.20.1 fires `ClientPlayerNetworkEvent.Clone` on every respawn packet, including a death
  respawn in the same dimension.

If the client clears on `Clone`, the server's context is unchanged (X → X). Nothing is re-sent,
and the station shows the generic sky until the context changes.

If the client instead detects a Level change by ClientLevel identity, the same stale state follows
a cross-dimension round trip inside one 10-tick window (commands, portals, rocket travel).

**Required change**

Choose one consistent rule and name the exact events:
- **(A)** The client never clears on a Level change and applies the context only in the Space
  Level. The server rule stays as written.
- **(B)** The client clears on `ClientPlayerNetworkEvent.Clone`. The server removes the player's
  last-sent entry on `PlayerEvent.PlayerChangedDimensionEvent` and `PlayerEvent.PlayerRespawnEvent`,
  so the next pass re-sends a present context.

Add GameTests for:
- a death respawn inside the same station;
- a Space → other Level → Space round trip within one pass.

### F4 — Medium — The ADR does not declare that it amends ADR-036 and ADR-046

**Evidence**

- ADR-036:16-17 says "Shared space has a generic space profile, not a fabricated per-station orbit
  context".
- ADR-036:85-87 says "No … new server context packet".
- ADR-046:72-74 pins "celestial 2" in the UI-01 text. ADR-046:70-71 only says the per-station sky
  "may add a bounded S2C context under its own ADR and protocol bump".
- `docs/PLANETARY-SKY-GUIDE.md:21-22` says Space has "a generic space sky, not a station-specific
  parent-planet disc".
- ADR-047's `development_dependency` omits ADR-036, and the ADR has no `amends:` line.

**Required change**

- Add `amends: ADR-036 (server context packet; per-station Space presentation), ADR-046 (UI-01 pinned celestial version 2 → 3)`.
- Add ADR-036 to `development_dependency`.
- List the guide update among the deliverables.

### F5 — Medium — The stated ID bound and message size are wrong

**Evidence**

- The ADR says the decoder rejects "more than 256 characters (the `BoundedCelestialCodecs` ID
  bound)" and that "A message is at most 260 bytes".
- In the code, `BoundedCelestialCodecs.MAX_RESOURCE_LOCATION_CHARS = 128`
  (`BoundedCelestialCodecs.java:17`).
- `StationState` rejects orbit IDs longer than 128 (`StationState.java:55`), and the station NBT
  codec reads at most 128 (`StationNbtCodec.java:253`).
- The ADR says "one boolean", but `FriendlyByteBuf.readBoolean` accepts any non-zero byte. The
  snapshot codec uses a strict 0/1 `readFlag` (`CelestialSnapshotCodec.java:156-162`).
- The ADR does not say what a malformed message does. The existing envelope decoder throws
  (`CelestialSnapshotPacket.java:55-57`).

**Required change**

- Name the constant and the value: 128 characters.
- Maximum message size: 132 bytes including the SimpleChannel discriminator (1 + 1 + 2-byte
  VarInt + 128).
- The encoder uses the same bound.
- Decode the flag strictly as 0 or 1.
- State what a malformed message does: either the decoder throws (connection error, as the
  envelope already does) or the message is ignored and the previous context is kept.

### F6 — Medium — The sun is not consistent with ADR-041's effective solar intensity

**Evidence**

- ADR-041:47-49 and the resolver (`StationOrbitEnvironmentResolver.java:46-50`) use the orbited
  body's `solar_intensity` whenever the body is in the catalog, whether or not it has a sky profile.
  They fall back to Space only when the body is missing.
- The ADR ties the sun to "the body present in the snapshot with a profile".
- Example: the gas giant has `solar_intensity: 0.04` (`gas_giant.json:25`) and no profile. The
  client would draw the Space sun (intensity 1.0), while `/arce station environment` reports
  `solar=0.04`. Doc 17 §8 requires "天体/天空与服务端环境一致" (the sky must agree with the server
  environment).
- The ADR says opacity "follows" solar intensity, but the renderer's opacity is binary:
  `solarIntensity() > 0 ? sunOpacity : 0` (`PlanetarySkyRenderer.java:63`).

**Required change**

Split the rule:
- **Body in the snapshot:** the sun uses its `solarIntensity`, profile or not. The disc is drawn
  with the F1 colour source.
- **Body missing from the snapshot:** the Space sun and no disc. This matches ADR-041's
  missing-body fallback.

State whether opacity stays binary.

### F7 — Medium — The verification plan misses plan items and the V0 deviation is not recorded

**Evidence**

- The GameTest list has no case with two or more players in different stations with different
  orbits at the same time. That case is plan §11.3 (多个站点视觉与数据不串: visuals and data of
  different stations must not mix).
- There is no respawn or dimension-change re-send test (F3).
- There is no case for the blocked registry, the quarantined registry, deletion, or expansion.
- Nothing checks that the map empties after logout and at stop.
- There is no geometry or colour test (F1, F2).
- There is no traceability table, unlike ADR-044 §8. The relevant plan items are §11.1, §11.3,
  §11.4, §12.1, §12.4 and §13.5 (真实客户端站点天空缓存释放: releasing the station sky cache on a
  real client).
- COMPLETION-PLAN C4 (`docs/status/COMPLETION-PLAN.md:71-73`: "V0 冒烟即可", V0 smoke is enough)
  and implementation log item 8 (`docs/work/v1.5.0-implementation-log.md:150`: "V0 only here")
  promise V0. The ADR records V0 as not run but does not record this as a deviation.
- `docs/15` §1 names the local Windows machine as the real-GPU (H2/V1) node.

**Required change**

- Add the missing GameTest and JUnit cases above.
- Add a plan traceability table.
- Record the V0 deviation in the implementation log.
- Cap ORBIT-03 at `implemented-unverified`.
- List the V1 cases for ACC-02:
  - each packaged body;
  - a warp seen live;
  - release on logout, resource reload and dimension change;
  - no OpenGL errors;
  - frame time against a baseline.
- List the V2 case for ACC-02: two clients in two stations.
- State that an unattended agent client launch is not V1 evidence.

### F8 — Low — Wiring and lifecycle are under-specified

These matter because of the known defect where runtime bridges are cleared at stop (log §Open
risks: `StationRuntime` is installed at construction, `AdvancedRocketryCommunity.java:146`, and
cleared at stop, `:337`). A second integrated-server session loses such bridges.

**Required change**

- **Construction:** the service is instance-owned and constructed once at mod construction, like
  `CelestialSnapshotSynchronizer` (`:177-182`).
- **Registry access:** it gets the registry from `StationRegistrySavedData.get(server)`, never from
  `StationRuntime`.
- **Map:** keyed by player UUID, because a respawn creates a new `ServerPlayer`. It is used only on
  the server thread, entries for offline players are pruned each pass, and a failure for one
  player does not stop the pass for the others.
- **Dependency direction:** station → `celestial.network` only. Celestial must not import station,
  as ADR-041 did for gravity.
- **Client cache:** in common code with no `net.minecraft.client` imports (AGENTS §3.3), using an
  atomic reference, cleared on `LoggingOut` and, as a defence, on `LoggingIn`.

### F9 — Low — Client-side gating and the selection cache key

**Required change**

- Apply the context only when the resolved Level is `CelestialIds.SPACE_LEVEL`. This guards
  against a previous body bleeding into another Level (ADR-036:47-48). A stale "orbit" context
  must never change the sun on a planetary surface.
- Add the context, compared by value, to `SkySelection`'s one-entry cache key
  (`SkySelection.java:15`).
- Look up the orbited body only on a cache miss.

### F10 — Low — Precision and editorial fixes

- **Catalog changes:** "a catalog change becomes visible at the next pass" is misleading. Catalog
  changes reach the client through message 0 on data-pack sync
  (`CelestialSnapshotSynchronizer.onDatapackSync`), and the context carries only the ID.
- **Quarantined registry:** `findAt` ignores `updatesQuarantined`
  (`StationRegistrySavedData.java:208-210, 325-327`). State that a quarantined but operational
  registry follows the in-memory committed state, as `environment` and gravity do.
- **Protocol vs payload schema:** say explicitly that the channel protocol goes 2 → 3 and the
  snapshot payload schema stays 2 (`CelestialSnapshotCodec.SCHEMA_VERSION`, `:22`). Only
  `CelestialSnapshotV2Test.java:45` changes; `:46` stays.
- **UI non-goal:** give ADR-046's no-screen disposition as the reason (the `environment` command
  is the UI), not "needs V1 first".
- **Position source:** `player.blockPosition()`, the same as `environment`
  (`StationCommands.java:229`) and gravity (`CelestialGravityController.java:40`).

### F11 — Info — Disclosure check: equivalent to the existing command, with nuances

**Evidence**

- `/arce station environment` has no `requires` (`StationCommands.java:72`). It resolves the
  caller's own `blockPosition` and prints `orbit=<id>` (including "(unavailable)") to any player in
  a region (`:227-253`). Only name and UUID are gated (`:239-241`).
- The snapshot already carries every catalog body, including discovery-required ones:
  `CelestialSnapshotCodec.java:32-51` writes `catalog.definitions()` without a discovery filter.
- There is no station identity in the context.
- The message is S2C only, with no server handler.
- `findAt` is an O(1) map lookup (`StationRegistryModel.java:217-231`) that returns empty while
  the registry is blocked (`StationRegistrySavedData.java:208-210`).
- No chunk is accessed.

**Nuances to record**

- The push is automatic and bypasses the command spam limiter.
- It shows region boundaries and orbit changes at 10-tick resolution, so visitors learn that a
  warp committed. ADR-046 already lists "visitors not notified" as a gap, not as a secret.

This is acceptable.

### F12 — Info — The protocol choice is sound

- Extending `celestial_snapshot` keeps `NetworkProtocolPinTest`'s assertion of four channel
  sources (`:60`).
- A new channel would change that count to 5, and would still break mixed client/server pairs
  under exact matching (`CelestialNetwork.java:20-21`).
- Required updates:
  - `network-protocols.txt:5`, plus a line for index 1;
  - `CelestialSnapshotV2Test.java:45`;
  - the CHANGELOG (`CHANGELOG.md:146-147` names "celestial display protocol 2");
  - the ADR-046 wording;
  - the plan YAML `network_protocol` at ACC.
- `BetaOperationalReport` reads the constant at run time. Its test uses constructed values, and the
  scripts use `\d+` patterns, so nothing else pins "2".
- Rolling back to "2" is valid, because the rolled-back format equals the original protocol 2.

### F13 — Info — Uncommitted implementation in the working tree already diverges from revision 1

These files appeared during the review and were not reviewed as the subject:
- `StationSkyContextService`, `StationSkyContextPacket`, `StationSkyContextCache`;
- edits to `CelestialNetwork`, `SkySelection`, the sky client, events and renderer, the pin table
  and tests.

Visible differences from ADR revision 1:
- a default colour `0x6E8FB4` for bodies without a profile (the ADR says "generic sky");
- the disc reuses the sun mesh instead of "one additional mesh";
- the server forgets on dimension change and respawn (option B of F3), which the ADR does not
  mention;
- the disc is drawn before the sun at the nadir, so the sun is drawn over the planet (F2);
- `SkySelection` has no Space-Level gate (F9).

Revision 2 must match what is implemented. Following the ADR-041 process note, acceptance should
come before the implementation commit.

## Required changes

1. **F1:** a colour source for the orbited body that works for Earth, with no profile, and for the
   Moon, whose profile is dark. Include an expected-appearance table for every packaged orbitable
   body and a test.
2. **F2:** the disc direction, angular radius and draw order as numbers, and a stated relation to
   the Space sun, which is always at the nadir (`fixed_time` 18000). Include a pure angular test.
3. **F3:** one consistent rule for Level changes, (A) or (B), with the exact Forge events. Include
   GameTests for a same-station respawn and a round trip within one pass.
4. **F4:** declare the amendments of ADR-036 and ADR-046 (UI-01), add ADR-036 as a dependency and
   list the sky-guide update.
5. **F5:** a 128-character bound by constant name, at most 132 bytes, strict boolean decoding and
   a defined result for a malformed message.
6. **F6:** the sun follows the orbited body whenever it is in the snapshot, profile or not. Missing
   body means the Space sun and no disc. Clarify opacity.
7. **F7:**
   - add the verification cases listed in F7 (two players in two stations, blocked, quarantined,
     deletion, expansion, map cleanup, geometry and colour);
   - add the plan traceability table;
   - record the V0 deviation from C4 and log item 8, and cap ORBIT-03 at `implemented-unverified`;
   - list the ACC-02 V1/V2 cases.
8. **F8–F10:** the wiring and lifecycle statements, Space-Level gating and the cache key, and the
   editorial fixes.

## Residual risks

- **Unverified visuals.** Visual correctness (colour, size, eclipse and legibility) stays unverified
  until V1 in ACC-02. Automated tests cannot establish it, and the renderer's `failed` fallback
  (`PlanetarySkyRenderer.java:67-71`) is the only runtime safety net.
- **Transient mismatch.** The sky may disagree with the server for up to 10 ticks after a move,
  warp commit, expansion or deletion. This is accepted presentation latency.
- **Mixed builds.** The exact-version bump makes mixed development builds refuse each other. Only
  development builds are affected, and it should be noted in the CHANGELOG.
- **Stale sky on failure.** If the server pass throws, or the service is not wired in a second
  integrated session (the C5 class of defect), the client keeps its last context until logout.
- **Provisional numbers.** The fixed angular size and colours are provisional. Rings, moons, the
  night side and per-station sun elevation remain explicit non-goals.

## Closing statement

This is an independent contract review of a proposed ADR against commit `50a0f42`. It is not a
Gate approval, an acceptance of ADR-047, or a verification of any implementation. It does not
change any version status. The maintainer decides acceptance after revision 2 addresses the
required changes.
