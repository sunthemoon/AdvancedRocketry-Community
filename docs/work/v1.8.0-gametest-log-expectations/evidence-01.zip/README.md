# GameTest log expectations: evidence 01

Date: 2026-10-10. Author: Claude. Subject commit: e2ed43eb on
fix/v1.8.0-gametest-log-expectations (parent ba680996).

- logs/: copies of eleven GameTest logs; logs/SOURCES.txt names each original on D:.
- results/check-*.txt: argv, output and exit code of scripts/check_gametest_log.py per log.
- results/inventory-07.txt: grouped ERROR/WARN inventory of log 07 (Root run of 30ca28ef).
- results/unit-tests.txt: python -m unittest tests.test_check_gametest_log -v.
- results/mutation-results.txt and scripts/mutate.py: eleven single mutations of the checker.
- results/tested-files.sha256: hashes of the three tested files; equal to the committed blobs.
- results/log-hashes.sha256: hashes of the copied logs.
- validators/: repository validators and Python test modules run in the worktree with the new
  documents present; check_new_links.py runs the validator's link check on the two new documents.
- SHA256SUMS.txt: every other file in this folder.
