"""Runs the repository validator's Markdown link check on the given files only."""
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "scripts"))
from validate_repository import markdown_link_errors  # noqa: E402

paths = [root / name for name in sys.argv[2:]]
broken, checked = markdown_link_errors(root, paths)
print(f"files={len(paths)} links_checked={checked} broken={broken}")
sys.exit(1 if broken else 0)
