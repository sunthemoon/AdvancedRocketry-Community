"""Applies one mutation at a time to a copy of check_gametest_log.py and runs its unit tests."""
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path(sys.argv[1])
WORK = Path(sys.argv[2])
MUTANTS = [
    ("FATAL ignored", 'problems.append(describe(entry, "FATAL entry"))', "pass"),
    ("count check one-sided", "if seen[batch] != count:", "if seen[batch] < count:"),
    ("max check removed", "elif (total := sum(seen.values())) > expectation.maximum:",
     "elif (total := sum(seen.values())) > expectation.maximum + 1000:"),
    ("banner not required", "if parsed.completed_tests is None:", "if False:"),
    ("stack ignored", "self.stack_contains is None\n                or any",
     "True\n                or any"),
    ("any batch allowed", "return batch in self.counts", "return True"),
    ("message prefix match", "self.message.fullmatch(entry.message)", "self.message.match(entry.message)"),
    ("ambiguity hidden", "if len(matched) == 1:", "if len(matched) >= 1:"),
    ("max allowed on ERROR", 'if level != "WARN":', "if False:"),
    ("batch suffix kept", r"(?P<name>.+):\d+' \(", r"(?P<name>.+:\d+)' \("),
    ("shutdown not separated", "batch = SHUTDOWN_BATCH", "pass"),
]

results = []
for name, old, new in MUTANTS:
    if WORK.exists():
        shutil.rmtree(WORK)
    (WORK / "scripts").mkdir(parents=True)
    (WORK / "tests").mkdir()
    shutil.copy(REPO / "scripts" / "check_gametest_log.py", WORK / "scripts")
    shutil.copy(REPO / "scripts" / "gametest_expected_log.json", WORK / "scripts")
    shutil.copy(REPO / "tests" / "test_check_gametest_log.py", WORK / "tests")
    for package in ("scripts", "tests"):
        source = REPO / package / "__init__.py"
        if source.exists():
            shutil.copy(source, WORK / package)
    target = WORK / "scripts" / "check_gametest_log.py"
    text = target.read_text(encoding="utf-8")
    if text.count(old) != 1:
        results.append((name, f"PATTERN COUNT {text.count(old)}"))
        continue
    target.write_text(text.replace(old, new), encoding="utf-8", newline="\n")
    run = subprocess.run([sys.executable, "-B", "-m", "unittest", "tests.test_check_gametest_log"],
                         cwd=WORK, capture_output=True, text=True)
    summary = run.stderr.strip().splitlines()[-1] if run.stderr.strip() else ""
    results.append((name, "KILLED" if run.returncode else "SURVIVED", summary))
shutil.rmtree(WORK, ignore_errors=True)
for result in results:
    print(" | ".join(result))
