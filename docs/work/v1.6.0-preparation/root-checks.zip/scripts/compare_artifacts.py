"""Compare this run's JAR hashes with the v1.5 closure run (the accepted development baseline)."""
import json
import pathlib

EV = pathlib.Path(__file__).resolve().parent.parent
BASE = pathlib.Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v150-closure-d95cd36780924befbdea0321233c2187/artifacts.json")
now = {row["name"]: row for row in json.loads((EV / "artifacts.json").read_text())["artifacts"]}
then = {row["name"]: row for row in json.loads(BASE.read_text())["artifacts"]}
rows = []
for name in sorted(set(now) | set(then)):
    a, b = now.get(name), then.get(name)
    rows.append({"name": name, "current_sha256": a and a["sha256"], "v150_closure_sha256": b and b["sha256"],
                 "identical": bool(a and b and a["sha256"] == b["sha256"] and a["bytes"] == b["bytes"])})
result = {"baseline_source": str(BASE), "all_identical": all(r["identical"] for r in rows), "artifacts": rows}
(EV / "artifact-comparison.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
