"""Mutation check: re-create the revision-2 rebind behaviour (R2-H2) and confirm the revision-3 vectors reject it.

Revision 2 had no paid_terminal: a rebound mission set CLAIMED without binding back, and the terminal the
mission is *bound* to rematerialized when it had no receipt. The copy is changed in Temp only.
"""
import importlib.util
import pathlib
import shutil
import subprocess
import sys

SOURCE = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community/docs/work/v1.6.0-preparation")
WORK = pathlib.Path(__file__).resolve().parent.parent / "mutation-rebind"
if WORK.exists():
    shutil.rmtree(WORK)
WORK.mkdir()
shutil.copy(SOURCE / "examples.json", WORK / "examples.json")
text = (SOURCE / "check_examples.py").read_text(encoding="utf-8")
original = '''            if action.endswith("BIND_BACK"):
                mission["bound"] = terminal'''
mutated = '''            if action.endswith("BIND_BACK"):
                mission["paid"] = mission["bound"]  # revision 2: no bind-back, payment tracked by binding'''
assert original in text
text = text.replace(original, mutated)
(WORK / "check_examples.py").write_text(text, encoding="utf-8", newline="\n")
result = subprocess.run([sys.executable, "-B", str(WORK / "check_examples.py")], capture_output=True, text=True,
                        env={"PYTHONUTF8": "1", "SYSTEMROOT": r"C:\Windows"})
print("mutated checker exit", result.returncode)
print(result.stderr[-1500:])
sys.exit(0 if result.returncode != 0 else 1)
