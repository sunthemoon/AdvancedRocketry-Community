"""Fetch the v1.6 legacy audit set from the pinned MIT commit and check manifest hashes.

Upstream bytes stay in the separate audit directory; only hashes/paths are recorded here.
"""
import csv, hashlib, json, pathlib, sys, time, urllib.request

REPO = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")
COMMIT = "c5cd5af62fc07cd4e0d24f06a16033f181c47c04"
BASE = f"https://raw.githubusercontent.com/Advanced-Rocketry/AdvancedRocketry/{COMMIT}/"
OUT = pathlib.Path(sys.argv[1])
RECORD = pathlib.Path(sys.argv[2])

JAVA = [
 "api/IMission.java", "api/ISatelliteIdItem.java", "api/SatelliteRegistry.java", "api/DataStorage.java",
 "api/satellite/IDataHandler.java", "api/satellite/SatelliteBase.java", "api/satellite/SatelliteProperties.java",
 "mission/MissionGasCollection.java", "mission/MissionOreMining.java", "mission/MissionResourceCollection.java",
 "satellite/SatelliteBiomeChanger.java", "satellite/SatelliteComposition.java", "satellite/SatelliteData.java",
 "satellite/SatelliteDefunct.java", "satellite/SatelliteDensity.java", "satellite/SatelliteMassScanner.java",
 "satellite/SatelliteMicrowaveEnergy.java", "satellite/SatelliteOptical.java", "satellite/SatelliteOreMapping.java",
 "satellite/SatelliteSpyTelescope.java",
 "item/ItemAsteroidChip.java", "item/ItemSatellite.java", "item/ItemSatelliteIdentificationChip.java",
 "item/ItemData.java", "item/ItemMultiData.java",
 "tile/satellite/TileSatelliteBuilder.java", "tile/satellite/TileSatelliteTerminal.java",
 "tile/hatch/TileSatelliteHatch.java", "tile/hatch/TileDataBus.java",
 "tile/multiblock/TileObservatory.java", "tile/multiblock/energy/TileMicrowaveReciever.java",
 "util/Asteroid.java", "util/XMLAsteroidLoader.java", "util/FluidGasGiantGas.java",
 "network/PacketSatellite.java", "network/PacketAsteroidInfo.java",
 "stations/SpaceObjectManager.java", "api/ARConfiguration.java",
 "dimension/DimensionProperties.java", "entity/EntityRocket.java",
 "item/ItemSatellitePowerSource.java", "item/ItemSatellitePrimaryFunction.java",
]
PREFIX = "src/main/java/zmaster587/advancedRocketry/"

manifest = {}
with open(REPO / "legacy-manifest/java-files.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        manifest[row["path"]] = row

rows = []
for rel in JAVA:
    path = PREFIX + rel
    entry = manifest.get(path)
    row = {"path": path, "in_manifest": entry is not None}
    try:
        with urllib.request.urlopen(BASE + path, timeout=30) as resp:
            data = resp.read()
        dest = OUT / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        digest = hashlib.sha256(data).hexdigest()
        row.update(bytes=len(data), sha256=digest,
                   manifest_sha256=entry["sha256"] if entry else None,
                   hash_match=(entry is not None and entry["sha256"] == digest),
                   lines=data.count(b"\n"))
    except Exception as exc:  # retained as a failed fetch, not hidden
        row.update(error=repr(exc))
    rows.append(row)
    time.sleep(0.1)

summary = {
    "upstream_commit": COMMIT,
    "requested": len(JAVA),
    "fetched": sum(1 for r in rows if "sha256" in r),
    "in_manifest": sum(1 for r in rows if r["in_manifest"]),
    "hash_matches": sum(1 for r in rows if r.get("hash_match")),
    "failures": [r["path"] for r in rows if "error" in r],
    "not_in_manifest": [r["path"] for r in rows if not r["in_manifest"]],
    "files": rows,
}
RECORD.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in summary.items() if k != "files"}, indent=2))
