"""Apply the round-3 Low findings (R3-L1..L6) to ADR-049/050/051 and the reference checker."""
import pathlib

ROOT = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")
EDITS = {
    "docs/decisions/ADR-050-MISSION-SCHEDULER-AND-RECOVERY.md": [
        # R3-L1
        ("  - launches of **every** kind and decommissions (ADR-049 §6, §7): the registry\n"
         "    is written before the terminal extracts the package or blanks the chip.\n"
         "    Launches are rare, at most one per satellite;\n",
         "  - launches of **every** kind and decommissions (ADR-049 §6, §7): the registry\n"
         "    is written before the terminal extracts the package or blanks the chip.\n"
         "    Launches are rare, at most one per satellite;\n"
         "  - the `REBIND_CONFLICT` bind-back (ADR-051 §7), which only follows an\n"
         "    operator rebind. A crash can therefore not undo it;\n"),
        # R3-L4
        ("**mission ≤ 4 KiB** (worst case about 3.7 KiB)",
         "**mission ≤ 4 KiB** (worst case about 3,804 bytes)"),
        ("its lifecycle: the claim, acknowledgement and quarantine fields.",
         "its lifecycle: the claim, acknowledgement, quarantine and rebind fields\n"
         "(`paid_terminal`, `rebound` and a rebound `bound_terminal`)."),
        ("A schema-1\nmission is at most about 450 bytes and grows by about 150 bytes (kind, seed,\n"
         "epoch, version, quarantine reservation), so 8,192 missions need about 4.8 MiB of\nthe 6 MiB.",
         "A schema-1\nmission is at most 597 bytes with 128-character IDs and grows by about 150 bytes\n"
         "(kind, seed, epoch, version, quarantine reservation). So 8,192 missions need\n"
         "about 5.84 MiB of the 6 MiB, and a v1.5 root, capped at 4 MiB, needs at most\n"
         "about 5.17 MiB after growth."),
    ],
    "docs/decisions/ADR-051-RESOURCE-MISSION-INSTANCES-AND-DELIVERY.md": [
        # R3-L3
        ("| ALLOCATED | owner cancel after reconciliation | AVAILABLE if not expired, else EXPIRED |",
         "| ALLOCATED | owner cancel after reconciliation, mission not `rebound` | AVAILABLE if not expired, else EXPIRED |\n"
         "| ALLOCATED | owner cancel of a `rebound` mission | QUARANTINED |"),
        # R3-L1
        ("| ACTIVE or READY, bound elsewhere (rebound) | present | Same, and also bind the mission back here (`bound_terminal` = here); audit `REBIND_CONFLICT` |",
         "| ACTIVE or READY, bound elsewhere (rebound) | present | Same, and also bind the mission back here (`bound_terminal` = here) with a registry barrier flush; audit `REBIND_CONFLICT` |"),
        # R3-L5
        ("- state read from chunk storage is persisted by definition;\n"
         "- state created in memory, or read from a carried item root, becomes persisted\n"
         "  when a `ChunkDataEvent.Save` tag for the terminal's chunk contains it;",
         "- an ID or receipt is persisted when it is present in the terminal's entry of a\n"
         "  `ChunkDataEvent.Load` or `ChunkDataEvent.Save` tag for the terminal's chunk.\n"
         "  That is the only signal. `BlockEntity.load` is shared by chunk loading, the\n"
         "  host's carried-root placement and third-party block-entity movers, so\n"
         "  everything else starts unpersisted;"),
    ],
    "docs/decisions/ADR-049-SATELLITE-BLUEPRINTS-AND-ASSEMBLY.md": [
        # R3-L6
        ("- If the flush fails, nothing changes.\n",
         "- If the flush fails, the launch result is an error and the package stays in the\n"
         "  terminal. The satellite registered in memory is persisted later, and the\n"
         "  next launch attempt with that package returns `IDEMPOTENT` and consumes it.\n"),
        ("`SATELLITE_NOT_FOUND`, and an operator may blank it.",
         "`SATELLITE_NOT_FOUND`. The player discards it and uses a new blank chip.\n"
         "An operator can also blank it with the new `satellite blank-chip` command\n"
         "(held item, permission level 2, audit line)."),
    ],
    # R3-L2
    "docs/work/v1.6.0-preparation/check_examples.py": [
        ('        return "INVALID_LAYOUT"\n    if kind == "data":\n        if primary is not None:\n'
         '            return "INVALID_LAYOUT"\n    elif primary is None or primary["role"] != "primary" or primary["kind"] != kind:\n'
         '        return "INVALID_LAYOUT"',
         '        return "INVALID_COMPONENTS"\n    if kind == "data":\n        if primary is not None:\n'
         '            return "INVALID_COMPONENTS"\n    elif primary is None or primary["role"] != "primary" or primary["kind"] != kind:\n'
         '        return "INVALID_COMPONENTS"'),
    ],
}
for name, pairs in EDITS.items():
    path = ROOT / name
    text = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert text.count(old) == 1, (name, old[:70])
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8", newline="\n")
    print("updated", name, len(pairs))
generator = pathlib.Path(__file__).with_name("generate_examples.py")
text = generator.read_text(encoding="utf-8")
count = text.count('"INVALID_LAYOUT"')
generator.write_text(text.replace('"INVALID_LAYOUT"', '"INVALID_COMPONENTS"'), encoding="utf-8", newline="\n")
print("generator INVALID_LAYOUT ->", count)
