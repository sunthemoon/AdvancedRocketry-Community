"""Mark ADR-048..052 ACCEPTED and append their acceptance records."""
import pathlib

ROOT = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community/docs/decisions")
BASIS = "maintainer standing authorization to proceed with recommended solutions"
EVIDENCE = "[preparation evidence](../work/v1.6.0-preparation/VERIFICATION.md)"
REVIEWS = {
    "ADR-049": "round 1 accepted it with required changes; round 2 again with required changes; round 3 accepted it",
    "ADR-050": "rounds 1 and 2 accepted it with required changes; round 3 accepted it",
    "ADR-051": "round 1 rejected revision 1; round 2 accepted revision 2 with required changes; round 3 accepted revision 3",
    "ADR-052": "round 1 accepted it with required changes; round 2 accepted revision 2",
}


def record(adr):
    return (
        "\n## Acceptance record\n\n"
        f"Accepted on 2026-09-30 by root under the maintainer's {BASIS}, after three\n"
        f"independent contract-review rounds: {REVIEWS[adr]}. Every Critical, High and\n"
        "Medium finding is resolved. The final Low findings are applied in this text.\n"
        f"Reports and dispositions are in the {EVIDENCE}. Acceptance freezes this\n"
        "contract for the v1.6 slices. It is not a runtime-completion claim, a Gate\n"
        "PASS or a publication decision. Later changes need a new revision and review.\n"
    )


for path in sorted(ROOT.glob("ADR-0[45][0-9]-*.md")):
    adr = path.name[:7]
    if adr not in ("ADR-048", "ADR-049", "ADR-050", "ADR-051", "ADR-052"):
        continue
    text = path.read_text(encoding="utf-8")
    assert text.count("status: PROPOSED\n") == 1, adr
    text = text.replace("status: PROPOSED\n", "status: ACCEPTED\n", 1)
    if adr == "ADR-048":
        text = text.replace('accepted_by: ""\naccepted_at: ""\n', 'accepted_by: sunthemoon\naccepted_at: 2026-09-30\n', 1)
        old = ("## Acceptance record\n\nPending independent contract review of ADR-048..052 in the\n"
               "[preparation evidence](../work/v1.6.0-preparation/VERIFICATION.md). Root records\n"
               "acceptance separately from the independent review; acceptance permits\n"
               "development, not runtime-completion claims, inherited Gate PASS or publication.\n")
        new = ("## Acceptance record\n\n"
               "Recorded on 2026-09-30 under the maintainer's standing direction to continue\n"
               "implementation and use recommended solutions. This is a scoped application of\n"
               "that authorization, not a new manual approval message for this numbered ADR.\n"
               "Three independent contract-review rounds found no required change to this ADR.\n"
               "ADR-049..052 are ACCEPTED in the same step, which satisfies the version's third\n"
               f"prerequisite. Reports and dispositions are in the {EVIDENCE}. Root records\n"
               "this acceptance separately from the reviews. It permits development, not\n"
               "runtime-completion claims, inherited Gate PASS or publication.\n")
        assert text.count(old) == 1
        text = text.replace(old, new)
    else:
        marker = "related: ["
        assert text.count(marker) == 1, adr
        text = text.replace(marker, f"accepted_by: sunthemoon\naccepted_at: 2026-09-30\nacceptance_basis: {BASIS}\n{marker}", 1)
        text = text.rstrip("\n") + "\n" + record(adr)
    path.write_text(text, encoding="utf-8", newline="\n")
    print("accepted", adr)
