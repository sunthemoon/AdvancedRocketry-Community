"""Add the three separately fetched files to the audit record (hash-checked against the manifest)."""
import csv, hashlib, json, pathlib
REPO = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")
UP = pathlib.Path(r"C:/Users/Administrator/AppData/Local/Temp/arce-v160-upstream-audit-a4ceab6678b544b3af0bd4a798dd60d6")
EXTRA = ["src/main/java/zmaster587/advancedRocketry/AdvancedRocketry.java",
         "src/main/java/zmaster587/advancedRocketry/entity/EntityStationDeployedRocket.java",
         "src/main/java/zmaster587/advancedRocketry/api/StatsRocket.java"]
manifest = {r["path"]: r for r in csv.DictReader(open(REPO / "legacy-manifest/java-files.csv", newline="", encoding="utf-8"))}
rec = json.loads(pathlib.Path("upstream-audit-fetch.json").read_text(encoding="utf-8"))
for p in EXTRA:
    data = (UP / p).read_bytes()
    d = hashlib.sha256(data).hexdigest()
    rec["files"].append({"path": p, "in_manifest": p in manifest, "bytes": len(data), "sha256": d,
                         "manifest_sha256": manifest[p]["sha256"], "hash_match": manifest[p]["sha256"] == d,
                         "lines": data.count(b"\n"), "fetched": "separately (curl), same pinned commit"})
files = rec["files"]
rec.update(requested=len(files), fetched=sum(1 for r in files if "sha256" in r),
           in_manifest=sum(1 for r in files if r["in_manifest"]),
           hash_matches=sum(1 for r in files if r.get("hash_match")))
pathlib.Path("upstream-audit-fetch.json").write_text(json.dumps(rec, indent=2) + "\n", encoding="utf-8")
print({k: rec[k] for k in ("requested", "fetched", "in_manifest", "hash_matches", "failures")})
