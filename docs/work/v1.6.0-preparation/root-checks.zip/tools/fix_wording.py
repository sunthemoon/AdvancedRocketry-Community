import pathlib
edits = {
 "docs/decisions/ADR-051-RESOURCE-MISSION-INSTANCES-AND-DELIVERY.md": [
  ("- `receipts`: ≤ 256 entries of `mission_id`, each with a runtime `serialized` flag.",
   "- `receipts`: ≤ 256 entries of `mission_id`, each with a runtime `persisted` flag."),
  ("and the satellite, and adds the reward and an unserialized receipt to the",
   "and the satellite, and adds the reward and an unpersisted receipt to the"),
  ("  `serialized` set only from a chunk-save tag; terminal ID persistence before",
   "  persistence set only from chunk storage or a chunk-save tag; terminal ID persistence before"),
 ],
 "docs/work/v1.6.0-implementation-log.md": [
  ("normative text. The disposition table is in the",
   "normative text. The disposition tables are `review-01-dispositions.md` and\n`review-02-dispositions.md` in the"),
 ],
}
for name, pairs in edits.items():
    p = pathlib.Path(name)
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert old in s, (name, old[:50])
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
