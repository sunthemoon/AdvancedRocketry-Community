"""Acceptance-time status edits for C6 (index, version doc, README, CURRENT_VERSION, plan, log)."""
import pathlib

ROOT = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community")


def edit(name, pairs):
    path = ROOT / name
    text = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert text.count(old) == 1, (name, old[:80])
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8", newline="\n")
    print("updated", name)


edit("DOCUMENT-INDEX.md", [
    ("- [v1.6 实施日志](docs/work/v1.6.0-implementation-log.md)：卫星与资源任务的分块任务、契约状态与实际验证范围。",
     "- [v1.6 实施日志](docs/work/v1.6.0-implementation-log.md)：卫星与资源任务的分块任务、契约状态与实际验证范围。\n"
     "- [v1.6 准备验证](docs/work/v1.6.0-preparation/VERIFICATION.md)：三轮独立契约审核、处置表、参考向量与未改动运行时的检查。"),
    ("docs/decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md)（提议）", "docs/decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md)（已接受）"),
    ("docs/decisions/ADR-049-SATELLITE-BLUEPRINTS-AND-ASSEMBLY.md)（提议）", "docs/decisions/ADR-049-SATELLITE-BLUEPRINTS-AND-ASSEMBLY.md)（第 3 版，已接受）"),
    ("docs/decisions/ADR-050-MISSION-SCHEDULER-AND-RECOVERY.md)（提议）", "docs/decisions/ADR-050-MISSION-SCHEDULER-AND-RECOVERY.md)（第 3 版，已接受）"),
    ("docs/decisions/ADR-051-RESOURCE-MISSION-INSTANCES-AND-DELIVERY.md)（提议）", "docs/decisions/ADR-051-RESOURCE-MISSION-INSTANCES-AND-DELIVERY.md)（第 3 版，已接受）"),
    ("docs/decisions/ADR-052-RESOURCE-TABLES-AND-SEEDS.md)（提议）", "docs/decisions/ADR-052-RESOURCE-TABLES-AND-SEEDS.md)（第 2 版，已接受）"),
])

edit("docs/versions/V1.6.0-SATELLITE-RESOURCE-MISSIONS.md", [
    ("前置版本未 `PASSED` 时，本版本只允许只读审计、测试设计和数据样例，不提前实现功能。独立 worktree 不豁免 AGENTS 的版本范围限制。\n",
     "前置版本未 `PASSED` 时，本版本只允许只读审计、测试设计和数据样例，不提前实现功能。独立 worktree 不豁免 AGENTS 的版本范围限制。\n\n"
     "已接受的开发顺序例外单独记录在 [ADR-048](../decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md)，\n"
     "不勾选上述发布前置 Gate。卫星类型、调度与资源生成契约为已接受的\n"
     "[ADR-049](../decisions/ADR-049-SATELLITE-BLUEPRINTS-AND-ASSEMBLY.md)、\n"
     "[ADR-050](../decisions/ADR-050-MISSION-SCHEDULER-AND-RECOVERY.md)、\n"
     "[ADR-051](../decisions/ADR-051-RESOURCE-MISSION-INSTANCES-AND-DELIVERY.md) 与\n"
     "[ADR-052](../decisions/ADR-052-RESOURCE-TABLES-AND-SEEDS.md)；逐项覆盖见\n"
     "[契约覆盖表](../work/v1.6.0-contract-coverage.md)，任务与实跑证据见\n"
     "[v1.6 实施日志](../work/v1.6.0-implementation-log.md)。准备阶段不代表新运行时已实现。\n"),
    ("version: v1.6.0\nstatus: PLANNED\n", "version: v1.6.0\nstatus: IN_PROGRESS\nphase: CONTRACT_FROZEN\n"),
])

edit("README.md", [
    ("the remaining warp, sky, UI and acceptance work. This is not a stable release.\n",
     "the remaining warp, sky, UI and acceptance work. This is not a stable release.\n\n"
     "**v1.6 Satellites & Resource Missions is in preparation.** Its contracts are\n"
     "accepted: satellite kinds assembled from components, a bounded offline mission\n"
     "scheduler, and asteroid and gas-giant missions with reproducible rewards. The\n"
     "[implementation log](docs/work/v1.6.0-implementation-log.md) tracks the work.\n"
     "None of these features is available yet; the runtime build remains\n"
     "`1.20.1-1.5.0-dev` until implementation begins.\n"),
])

edit("docs/status/CURRENT_VERSION.md", [
    ("```yaml\nactive_development_version: v1.5.0\nactive_development_branch: codex/v1.5.0-orbital-station-warp\n"
     "phase: IMPLEMENTING\nexecution_state: ACTIVE\npaused_at: 2026-09-30\nresumed_at: 2026-09-30\n"
     "accepted_development_baseline: 6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b\n"
     "development_log: docs/work/v1.5.0-implementation-log.md\n"
     "previous_development_handoff: docs/releases/v1.4.0/RELEASE-EVIDENCE.md\nruntime_build: 1.20.1-1.5.0-dev\n```\n",
     "```yaml\nactive_development_version: v1.6.0\nactive_development_branch: codex/v1.6.0-satellite-resource-missions\n"
     "phase: CONTRACT_FROZEN\nexecution_state: ACTIVE\n"
     "accepted_development_baseline: 940a5ed3b90a4da0ca4e43417b2bddf41ebb7307\n"
     "development_log: docs/work/v1.6.0-implementation-log.md\n"
     "previous_development_handoff: docs/releases/v1.5.0/RELEASE-EVIDENCE.md\nruntime_build: 1.20.1-1.5.0-dev\n```\n\n"
     "v1.6 preparation (C6) is complete. [ADR-048](../decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md)\n"
     "accepts v1.6 development from the v1.5 closure commit `940a5ed`, separately from\n"
     "inherited acceptance. ADR-049..052 freeze the satellite, scheduler, resource-mission\n"
     "and reward contracts after three independent review rounds\n"
     "([preparation evidence](../work/v1.6.0-preparation/VERIFICATION.md)). The runtime is\n"
     "unchanged: the rebuilt JARs are byte-identical to the v1.5 closure build. The next\n"
     "chunk is C7 in [COMPLETION-PLAN](COMPLETION-PLAN.md). The v1.5 facts below are unchanged.\n"
     "\nPrevious development version (v1.5, development complete, release `IN_PROGRESS`):\n\n"
     "```yaml\nprevious_development_version: v1.5.0\nprevious_development_branch: codex/v1.5.0-orbital-station-warp\n"
     "previous_accepted_development_baseline: 6f530ac7db4bf0e06be6d6aaef35e6ca31a5651b\n"
     "previous_development_log: docs/work/v1.5.0-implementation-log.md\n```\n"),
])

edit("docs/status/COMPLETION-PLAN.md", [
    ("### C6. v1.6 准备与契约 `[~]`", "### C6. v1.6 准备与契约 `[x]`"),
    ("- 进展（2026-09-30）：分支 `codex/v1.6.0-satellite-resource-missions`；\n"
     "  ADR-048..052 第 1 版经独立审核（0 Critical / 7 High，ADR-051 被拒），\n"
     "  第 2 版已按审核修订，等待第二次审核后接受。审核要求把 C8 拆为 C8a/C8b，\n"
     "  且 C7 需实现完整的注册表根 3 编解码。",
     "- 结果（2026-09-30）：分支 `codex/v1.6.0-satellite-resource-missions`；旧版审计\n"
     "  43 个上游文件哈希一致、未导入。ADR-048..052 经三轮独立审核后接受：第 1 轮\n"
     "  0 Critical / 7 High（ADR-051 第 1 版被拒），第 2 轮 2 High，第 3 轮无\n"
     "  Critical/High/Medium，6 个 Low 已写入正文。参考向量 13 项检查通过；运行时未改动，\n"
     "  重建 JAR 与 v1.5 收尾字节一致（`docs/work/v1.6.0-preparation/`）。C8 拆为\n"
     "  C8a/C8b，C7 需实现完整的注册表根 3 编解码。"),
    ("**C6 v1.6 准备与契约**（新会话；从 v1.5 分支的最新提交建立 v1.6 分支与实施日志）。",
     "**C7 卫星组件与代表类型**（新会话；在 `codex/v1.6.0-satellite-resource-missions` 上，\n"
     "按已接受的 ADR-049/050 实现，含完整的注册表根 3 编解码与启动前迁移）。"),
])

edit("docs/work/v1.6.0-implementation-log.md", [
    ("phase: CONTRACT_REVIEW\n", "phase: CONTRACT_FROZEN\n"),
    ("runtime_implementation_allowed: false   # true only after ADR-048..052 are ACCEPTED\n",
     "runtime_implementation_allowed: true    # ADR-048..052 ACCEPTED on 2026-09-30\n"),
    ("[ADR-048](../decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md) separately\nauthorizes this version once accepted.",
     "[ADR-048](../decisions/ADR-048-V160-DEVELOPMENT-BASELINE-EXCEPTION.md) separately\nauthorizes this version; it and ADR-049..052 are ACCEPTED."),
    ("## C6 — preparation and contracts (this chunk)", "## C6 — preparation and contracts (complete)"),
    ("normative text. The disposition tables are `review-01-dispositions.md` and\n"
     "`review-02-dispositions.md` in the\n"
     "[preparation evidence](v1.6.0-preparation/VERIFICATION.md). A second review\n"
     "checks the revised text before acceptance.",
     "normative text.\n\n"
     "The second review of `ddc71c3` found 36 of the 39 round-1 findings resolved and 3\n"
     "partial. It raised 2 new High findings (a component loss on non-`data` launches\n"
     "and a double payment after a rebind), 3 Medium and 13 Low. Revision 3 (`ba275f0`)\n"
     "answers them. The third, targeted review accepted ADR-049..051 with 6 Low\n"
     "findings, which are applied before acceptance. ADR-048 and ADR-052 were accepted\n"
     "in round 2. The disposition tables are `review-01-dispositions.md`,\n"
     "`review-02-dispositions.md` and `review-03-dispositions.md` in the\n"
     "[preparation evidence](v1.6.0-preparation/VERIFICATION.md)."),
    ("1. [~] **C6** contracts: independent reviews, apply findings, accept ADR-048..052,\n"
     "   evidence packet ([preparation](v1.6.0-preparation/VERIFICATION.md)).",
     "1. [x] **C6** contracts: three independent reviews, findings applied, ADR-048..052\n"
     "   accepted, evidence packet ([preparation](v1.6.0-preparation/VERIFICATION.md))."),
])
