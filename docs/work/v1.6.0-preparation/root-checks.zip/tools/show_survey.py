import json

d = json.load(open(r"D:/GitHub/AdvancedRocketry-Community/docs/work/v1.6.0-preparation/examples.json", encoding="utf-8"))
for case in d["survey"]:
    print(case["system"], case["mission_seed"])
    for type_id, seed, entries in case["instances"]:
        print("   ", type_id, seed, entries, sum(n for _, n in entries))
print(d["bounded"])
