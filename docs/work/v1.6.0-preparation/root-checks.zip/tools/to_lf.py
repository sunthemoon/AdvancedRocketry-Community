import pathlib
import sys

for name in sys.argv[1:]:
    path = pathlib.Path(name)
    data = path.read_bytes()
    fixed = data.replace(b"\r\n", b"\n")
    if fixed != data:
        path.write_bytes(fixed)
        print("normalized", name)
