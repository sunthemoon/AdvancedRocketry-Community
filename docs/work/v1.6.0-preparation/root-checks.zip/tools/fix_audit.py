import pathlib
p = pathlib.Path("docs/work/v1.6.0-legacy-audit.md")
s = p.read_text(encoding="utf-8")
edits = [
 ("Stats are sums; battery gets a fixed **+720** base. 100-tick build | Satellite Builder block with the same slot shape, instant server-validated assembly (ADR-049) |",
  "Stats are sums; battery gets a fixed **+720** base. 100-tick build. The chip-copy slot duplicates ID chips | Satellite Builder block with the chassis/primary/module shape, instant server-validated assembly; the chip-copy slot is not revived (ADR-049) |"),
 ("on a **worker thread**; 1,000 + 375 × zoom energy per scan |",
  "on a **worker thread**; 1,000 + 375 × zoom energy per filtered scan (250 × zoom for the unfiltered variant) |"),
 ("| Duration formula kept in integer form; rewards fully determined by a server seed and a table snapshot; one-shot instances (ADR-051/052) |",
  "| Integer duration formula with a deliberate rebalance (36,000 ticks with one drill → 12,000 at the default rating, because the logical mission has no flight); rewards fully determined by a server seed and a table snapshot; one-shot instances (ADR-051/052) |"),
 ("Small (distance 10, mass 200, probability 20, richness 0.3), Light (60, 200, 15, 0.2), Iridium-enriched (100, 75, 2, 0.2), Strange (120, 50, 1, 0.2), ±0.5 variability;",
  "Small (distance 10, mass 200, probability 20, richness 0.3), Light (60, 200, 15, 0.2), Iridium-enriched (100, 75, 2, 0.2), Strange (120, 50, 1, 0.2); mass variability 0.5 for all four, richness variability 0.5 except Iridium-enriched 0.3;"),
]
for old, new in edits:
    assert old in s, old[:60]
    s = s.replace(old, new)
old_gas = "Station-deployed rocket with intakes over a gas giant. Duration `2 × liquidCapacity / intakePower` (360 if no intake)."
assert old_gas in s
s = s.replace(old_gas, "Station-deployed rocket with intakes over a gas giant. Duration `2 × liquidCapacity / intakePower` (360 if no intake), in `entity/EntityStationDeployedRocket.java` line 383.")
p.write_text(s, encoding="utf-8", newline="\n")
print("audit updated")
