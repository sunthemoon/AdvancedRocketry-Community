"""Rewrite the acceptance records of ADR-049..052 with clean wording and wrapping."""
import pathlib
import re

ROOT = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community/docs/decisions")
HISTORY = {
    "ADR-049": ("three", "Rounds 1 and 2 accepted it with required changes, and round 3 accepted\nrevision 3."),
    "ADR-050": ("three", "Rounds 1 and 2 accepted it with required changes, and round 3 accepted\nrevision 3."),
    "ADR-051": ("three", "Round 1 rejected revision 1, round 2 accepted revision 2 with required\nchanges, and round 3 accepted revision 3."),
    "ADR-052": ("two", "Round 1 accepted it with required changes, and round 2 accepted\nrevision 2."),
}
for adr, (count, history) in HISTORY.items():
    path = next(ROOT.glob(adr + "-*.md"))
    text = path.read_text(encoding="utf-8")
    head, marker, _ = text.partition("\n## Acceptance record\n")
    assert marker, adr
    record = (
        "\n## Acceptance record\n\n"
        "Accepted on 2026-09-30 by root, under the maintainer's standing authorization\n"
        f"to proceed with recommended solutions, after {count} independent contract-review\n"
        f"rounds. {history} Every Critical, High and Medium finding is resolved, and the\n"
        "final Low findings are applied in this text. Reports and dispositions are in the\n"
        "[preparation evidence](../work/v1.6.0-preparation/VERIFICATION.md).\n\n"
        "Acceptance freezes this contract for the v1.6 slices. It is not a\n"
        "runtime-completion claim, a Gate PASS or a publication decision. Later changes\n"
        "need a new revision and review.\n"
    )
    path.write_text(head.rstrip("\n") + "\n" + record, encoding="utf-8", newline="\n")
    print("rewrote", adr)
    assert not re.search(r"maintainer's maintainer", path.read_text(encoding="utf-8"))
