import java.util.*;

/** Reviewer's Java-long cross-check of ADR-052 (signed 64-bit, >>> shifts, int weights). */
public class JavaVectors {
    static final class SplitMix64 {
        long s;
        SplitMix64(long seed) { s = seed; }
        long next() {
            s += 0x9E3779B97F4A7C15L;
            long z = s;
            z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
            z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
            return z ^ (z >>> 31);
        }
        int bounded(int n) { return (int) ((next() >>> 1) % n); }
    }

    record Ore(String item, int weight) {}
    record Type(String id, int weight, List<String> systems, int mass, int mv, int rich, int rv, String base, List<Ore> ores) {}

    static final long SURVEY01 = 0x5355525645593031L, ASTTYPE1 = 0x4153545459504531L, ASTYIELD = 0x4153545949454C44L;

    static String yieldOf(Type t, long seed) {
        SplitMix64 y = new SplitMix64(seed ^ ASTYIELD);
        int dm = y.bounded(t.mv + 1) - t.mv / 2;
        int mass = Math.max(1, Math.min(4096, t.mass * (100 + dm) / 100));
        int dr = y.bounded(t.rv + 1) - t.rv / 2;
        int rich = Math.max(0, Math.min(100, t.rich + dr));
        int ores = mass * rich / 100;
        int total = t.ores.stream().mapToInt(Ore::weight).sum();
        int[] c = new int[t.ores.size()];
        for (int i = 0; i < ores; i++) {
            int r = y.bounded(total), acc = 0;
            for (int k = 0; k < c.length; k++) { acc += t.ores.get(k).weight; if (acc > r) { c[k]++; break; } }
        }
        StringBuilder b = new StringBuilder("[");
        for (int k = 0; k < c.length; k++) if (c[k] > 0) b.append(t.ores.get(k).item).append('=').append(c[k]).append(' ');
        if (mass - ores > 0) b.append(t.base).append('=').append(mass - ores);
        return b.append(']').toString();
    }

    public static void main(String[] args) {
        SplitMix64 z = new SplitMix64(0L);
        System.out.printf("seed0 %016x %016x %016x%n", z.next(), z.next(), z.next());
        SplitMix64 b = new SplitMix64(0L);
        StringBuilder bs = new StringBuilder();
        for (int i = 0; i < 5; i++) bs.append(b.bounded(100)).append(' ');
        System.out.println("bounded(100) seed0: " + bs);
        List<Type> types = new ArrayList<>(List.of(
            new Type("example:small", 20, List.of(), 200, 50, 30, 50, "minecraft:cobblestone",
                List.of(new Ore("minecraft:iron_ore", 15), new Ore("minecraft:gold_ore", 10), new Ore("minecraft:redstone_ore", 10))),
            new Type("example:light", 15, List.of(), 200, 50, 20, 50, "minecraft:cobblestone",
                List.of(new Ore("minecraft:copper_ore", 20), new Ore("minecraft:lapis_ore", 10), new Ore("minecraft:nether_quartz_ore", 5))),
            new Type("example:dense", 2, List.of(), 75, 50, 20, 30, "minecraft:cobblestone",
                List.of(new Ore("minecraft:iron_ore", 25), new Ore("minecraft:diamond_ore", 5))),
            new Type("example:strange_tau", 1, List.of("advancedrocketrycommunity:tau_ceti"), 50, 50, 20, 50, "minecraft:cobblestone",
                List.of(new Ore("minecraft:emerald_ore", 5), new Ore("minecraft:copper_ore", 20)))));
        String system = "advancedrocketrycommunity:earth";
        List<Type> cands = types.stream().filter(t -> t.systems.isEmpty() || t.systems.contains(system))
            .sorted(Comparator.comparing(Type::id)).toList();
        int totalW = cands.stream().mapToInt(Type::weight).sum();
        SplitMix64 a = new SplitMix64(0x0123456789ABCDEFL ^ SURVEY01);
        for (int i = 0; i < 4; i++) {
            long s = a.next();
            SplitMix64 t = new SplitMix64(s ^ ASTTYPE1);
            int r = t.bounded(totalW), acc = 0;
            Type chosen = null;
            for (Type c : cands) { acc += c.weight; if (acc > r) { chosen = c; break; } }
            System.out.printf("instance %d %s %016x %s%n", i, chosen.id, s, yieldOf(chosen, s));
        }
        int tm = 1000, cfg = 1000, rating = 1;
        int intNumerator = 12_000 * tm * cfg * 10;
        long longNumerator = 12_000L * tm * cfg * 10;
        System.out.println("asteroid duration numerator int=" + intNumerator + " long=" + longNumerator);
    }
}
