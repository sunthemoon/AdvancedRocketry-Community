"""Reviewer's uncompressed-NBT size model for the ADR-049/050/051 records.

Sizes follow the NBT binary format used by NbtIo.write / SatelliteNbtSize:
named entry = 1 (type) + 2 (name length) + name bytes + payload.
Field names follow the ADR text; where the ADR is silent the existing codec style is used.
"""

def s(name):  # string payload is 2 + length (ASCII)
    return lambda n: 1 + 2 + len(name) + 2 + n

def named(name, payload):
    return 1 + 2 + len(name) + payload

INT, LONG, BYTE, UUID = 4, 8, 1, 4 + 16


def entry(item_len):  # compound {item: string, count: int} inside a list (unnamed)
    return named("item", 2 + item_len) + named("count", INT) + 1


def reward_list(name, entries, item_len):
    return named(name, 1 + 4 + entries * entry(item_len))


def instance(id_len, entries):
    body = (named("schema_version", INT) + named("instance_id", UUID) + named("owner_id", UUID)
            + named("system", 2 + id_len) + named("asteroid_type", 2 + id_len)
            + named("table_version", 2 + 16) + named("seed", LONG)
            + reward_list("yield", entries, id_len) + named("created_at", LONG)
            + named("expires_at", LONG) + named("state", 2 + len("allocated"))
            + named("source_mission", UUID) + named("allocated_mission", UUID))
    return body + 1  # end tag of the record compound (list element, unnamed)


def mission(id_len, entries):
    body = (named("schema_version", INT) + named("mission_id", UUID) + named("satellite_id", UUID)
            + named("owner_id", UUID) + named("definition_id", 2 + id_len) + named("kind", 2 + 8)
            + named("target_body", 2 + id_len) + named("instance_id", UUID) + named("seed", LONG)
            + named("started_at", LONG) + named("completes_at", LONG) + named("start_epoch", LONG)
            + named("status", 2 + len("claim_pending_discovery")) + named("ready_at", LONG)
            + named("resolved_at", LONG) + named("reward_version", 2 + 200)
            + named("quarantine", named("reason", 2 + 32) + named("previous_status", 2 + 23) + 1)
            + reward_list("reward", entries, id_len)
            + named("bound_terminal", named("terminal_id", UUID) + named("level", 2 + id_len)
                    + named("pos", LONG) + 1)
            + named("acknowledged", BYTE))
    return body + 1


def satellite(id_len, components):
    comp_list = named("components", 1 + 4 + components * (2 + id_len))
    stats = named("stats", sum(named(k, INT) for k in ("power", "battery", "data", "cargo", "rating")) + 1)
    body = (named("schema_version", INT) + named("satellite_id", UUID) + named("definition_id", 2 + id_len)
            + named("owner_id", UUID) + named("launched_at", LONG) + named("status", 2 + 17)
            + named("current_mission_id", UUID) + named("kind", 2 + 14) + named("orbit_body", 2 + id_len)
            + named("blueprint", comp_list + stats + 1)
            + named("kind_state", named("charge", LONG) + named("charge_time", LONG)
                    + named("receiver_id", UUID) + 1))
    return body + 1


print("record                      typical(ids~30, n=3)  17 entries ids~30  worst(ids=128, max entries)  ADR bound")
print(f"asteroid instance           {instance(30, 4):>8}               {instance(30, 17):>8}            {instance(128, 17):>8}                1024")
print(f"resource mission            {mission(30, 4):>8}               {mission(30, 17):>8}            {mission(128, 17):>8}                2048")
print(f"satellite (8 components)    {satellite(30, 3):>8}               {satellite(30, 8):>8}            {satellite(128, 8):>8}                1024")

# Section arithmetic from ADR-050 section 6
KiB, MiB = 1024, 1024 * 1024
sections = {"satellites": 4096 * 1 * KiB, "missions": 3072 * 2 * KiB, "instances": 2048 * 1 * KiB,
            "accounts+clock+counters": 4096 * 256}
print({k: v / MiB for k, v in sections.items()}, "sum MiB =", sum(sections.values()) / MiB)
worst = 4096 * satellite(128, 8) + 3072 * mission(128, 17) + 2048 * instance(128, 17) + 4096 * 256
print("worst-case sum at full counts (MiB) =", round(worst / MiB, 2))

# Terminal root (ADR-051 section 5): 256 receipts as UUID int arrays, 32 buffer entries
receipts_list = named("receipts", 1 + 4 + 256 * (4 + 16))
receipts_compound = named("receipts", 1 + 4 + 256 * (named("mission_id", UUID) + 1))
buffer = reward_list("reward_buffer", 32, 128)
print("terminal additions: receipts(int[] list)", receipts_list, " receipts(compound list)", receipts_compound,
      " buffer(32x128-char ids)", buffer)
print("terminal node estimate: receipts compound list ~", 1 + 256 * 2, " buffer ~", 1 + 32 * 3)
