"""Round-3 size checks: legacy schema-1 records (ADR-050 section 10 figures) and the rev-3 mission record."""

def named(name, payload):
    return 1 + 2 + len(name) + payload

INT, LONG, BYTE, UUID = 4, 8, 1, 20


def s(n):
    return 2 + n


def legacy_mission(n):  # fields of the current SatelliteNbtCodec.encodeMission (schema 1)
    return (named("schema_version", INT) + named("mission_id", UUID) + named("satellite_id", UUID)
            + named("owner_id", UUID) + named("definition_id", s(n)) + named("target_body_id", s(n))
            + named("started_at", LONG) + named("completes_at", LONG) + named("research_yield", INT)
            + named("discovery_cost", INT) + named("discovery_required", BYTE)
            + named("status", s(len("claim_pending_discovery"))) + named("ready_at", LONG)
            + named("resolved_at", LONG) + 1)


def legacy_satellite(n):  # current SatelliteNbtCodec.encodeSatellite (schema 1)
    return (named("schema_version", INT) + named("satellite_id", UUID) + named("definition_id", s(n))
            + named("owner_id", UUID) + named("launched_at", LONG) + named("status", s(len("recovery_required")))
            + named("current_mission_id", UUID) + 1)


print("schema-1 mission: 40-char IDs", legacy_mission(40), "B; 128-char IDs", legacy_mission(128), "B (ADR-050 s10 says ~450)")
print("schema-1 satellite: 40-char IDs", legacy_satellite(40), "B; 128-char IDs", legacy_satellite(128), "B (ADR-050 s10 says ~350)")
MiB = 1024 * 1024
print("8,192 worst-case legacy missions + 150 B growth:", round(8192 * (legacy_mission(128) + 150) / MiB, 2), "MiB (budget 6)")
print("bounded instead by the v1.5 4 MiB root: 4 MiB + 8,192 x 150 B =", round((4 * MiB + 8192 * 150) / MiB, 2), "MiB")
extra = named("rebound", BYTE) + named("paid_terminal", UUID)
print("rev-3 mission worst case: round-2 figure 3757 B +", extra, "=", 3757 + extra, "B (bound 4096)")
