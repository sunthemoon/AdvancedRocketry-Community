"""Reviewer's independent model of ADR-051 revision 3 sections 5-9 and ADR-050 section 8 (rebind cases).

Written from the ADR text only; it does not import check_examples.py.

Premise (ADR-051 crash cut 2 followed by a rebind): T1 paid the reward and holds a receipt and the items
(both in memory and on disk); the registry reverted to READY bound to T1; an operator rebound the mission to
T2 and that rebind is durable. The model adds registry flushes, chunk saves and crashes to the four events
used by the published vectors.
"""
import copy
import itertools
import json
import sys
from pathlib import Path

EX = json.loads((Path(__file__).parent / "tree/docs/work/v1.6.0-preparation/examples.json").read_text(encoding="utf-8"))


def initial():
    reg = {"status": "READY", "bound": "T2", "paid": None, "rebound": True, "ack": False, "instance": "ALLOCATED"}
    term = {"T1": {"receipt": "persisted", "items": 1}, "T2": {"receipt": None, "items": 0}}
    return {"R": copy.deepcopy(reg), "Rd": copy.deepcopy(reg), "T": copy.deepcopy(term), "Td": copy.deepcopy(term),
            "residual": False, "instance_seen": set()}


def reconcile(s, x):
    r, t = s["R"], s["T"][x]
    present = t["receipt"] is not None
    if r["status"] in ("ACTIVE", "READY"):
        if present:                                   # CLAIM_RECOVERED, or REBIND_CONFLICT with bind-back
            r.update(status="CLAIMED", paid=x, ack=False, instance="DEPLETED")
            if r["bound"] != x:
                r["bound"] = x
        return
    if r["status"] == "CLAIMED":
        if r["paid"] == x:
            if not r["ack"]:
                if t["receipt"] == "persisted":
                    r["ack"] = True
                elif t["receipt"] is None:           # chunk behind: rematerialize at the paid terminal only
                    t["items"] += 1
                    t["receipt"] = "unpersisted"
            elif present and s["Rd"]["status"] == "CLAIMED" and s["Rd"]["ack"] and s["Rd"]["paid"] == x:
                t["receipt"] = None                  # durable acknowledgement: drop
        return                                        # paid elsewhere: keep receipt; CANCELLED/QUARANTINED: keep


def step(s, e):
    r = s["R"]
    if e == "t1_rec":
        reconcile(s, "T1")
    elif e == "t2_rec":
        reconcile(s, "T2")
    elif e == "t2_claim":
        reconcile(s, "T2")
        if r["status"] == "READY" and r["bound"] == "T2":
            if s["T"]["T1"]["receipt"] is not None or s["Td"]["T1"]["receipt"] is not None:
                s["residual"] = True                 # T1 already paid and has not reported: the stated residual
            r.update(status="CLAIMED", paid="T2", ack=False, instance="DEPLETED")
            s["T"]["T2"]["items"] += 1
            s["T"]["T2"]["receipt"] = "unpersisted"
    elif e == "t2_cancel":                            # owner cancel at the bound terminal after reconciliation
        reconcile(s, "T2")
        if r["status"] in ("ACTIVE", "READY") and r["bound"] == "T2":
            r["status"] = "CANCELLED"
            r["instance"] = "QUARANTINED" if r["rebound"] else "AVAILABLE"
    elif e == "t1_cancel":
        reconcile(s, "T1")
        if r["status"] in ("ACTIVE", "READY") and r["bound"] == "T1":
            r["status"] = "CANCELLED"
            r["instance"] = "QUARANTINED" if r["rebound"] else "AVAILABLE"
    elif e == "op_cancel":
        if r["status"] in ("ACTIVE", "READY"):
            r["status"] = "CANCELLED"
            r["instance"] = "QUARANTINED"
    elif e == "flush":
        s["Rd"] = copy.deepcopy(r)
    elif e in ("save_t1", "save_t2"):
        x = "T1" if e == "save_t1" else "T2"
        if s["T"][x]["receipt"] == "unpersisted":
            s["T"][x]["receipt"] = "persisted"
        s["Td"][x] = copy.deepcopy(s["T"][x])
    elif e == "crash":
        s["R"] = copy.deepcopy(s["Rd"])
        s["T"] = copy.deepcopy(s["Td"])              # state read from chunk storage is persisted
    else:
        raise ValueError(e)
    s["instance_seen"].add(s["R"]["instance"])
    s["instance_seen"].add(s["Rd"]["instance"])


def run(events):
    s = initial()
    for e in events:
        step(s, e)
    payout = s["T"]["T1"]["items"] + s["T"]["T2"]["items"]
    return s, payout


# 1. The published 64 orderings, mapped onto this model's events
mapping = {"t1_return": "t1_rec", "t2_reconcile": "t2_rec", "t2_claim": "t2_claim", "owner_cancel_t2": "t2_cancel"}
mismatch = 0
for case in EX["rebind_orderings"]:
    s, payout = run([mapping[e] for e in case["events"]])
    got = [payout, s["R"]["instance"]]
    if got != [case["payments"], case["instance"]]:
        mismatch += 1
        print("MISMATCH", case["events"], got, [case["payments"], case["instance"]])
residual_cases = sum(1 for c in EX["rebind_orderings"] if c["payments"] == 2)
print(f"published orderings: {len(EX['rebind_orderings'])}, model mismatches: {mismatch}, "
      f"orderings paying twice: {residual_cases}")

# 2. Exhaustive sequences with repetition, including flushes, chunk saves and crashes
EVENTS = ("t1_rec", "t2_rec", "t2_claim", "t2_cancel", "t1_cancel", "op_cancel", "flush", "save_t1", "save_t2", "crash")
MAXLEN = int(sys.argv[1]) if len(sys.argv) > 1 else 6
checked = over_pay_without_residual = freed = lost = double_with_residual = 0
examples_bad = []
for n in range(1, MAXLEN + 1):
    for seq in itertools.product(EVENTS, repeat=n):
        s, payout = run(seq)
        checked += 1
        if "AVAILABLE" in s["instance_seen"]:
            freed += 1
            examples_bad.append(("freed", seq))
        if payout > 1 and not s["residual"]:
            over_pay_without_residual += 1
            examples_bad.append(("overpay", seq))
        if payout > 1 and s["residual"]:
            double_with_residual += 1
        if payout < 1:
            lost += 1
            examples_bad.append(("lost", seq))
print(f"exhaustive sequences up to length {MAXLEN}: {checked}")
print(f"  double payment outside the residual: {over_pay_without_residual}")
print(f"  double payment inside the residual (T2 claimed while T1 held its receipt): {double_with_residual}")
print(f"  instance ever AVAILABLE: {freed}")
print(f"  reward lost: {lost}")
for kind, seq in examples_bad[:10]:
    print("  example", kind, seq)

# 3. Residual reachable although T1 returned first: its bind-back was only flush-pending when the server crashed
s, payout = run(("t1_rec", "crash", "t2_claim"))
print(f"t1 returns first, crash before the coalesced flush, then T2 claims: payout={payout}, "
      f"classified as residual={s['residual']}")
sys.exit(1 if (mismatch or over_pay_without_residual or freed or lost) else 0)
