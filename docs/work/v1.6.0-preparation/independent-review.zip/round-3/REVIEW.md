# Targeted contract check, round 3: v1.6.0 revision 3

- **Reviewer role:** the same independent reviewer as rounds 1 and 2. I had read-only access to the repository, wrote only under `round-3/`, and left the round-1 and round-2 files unchanged.
- **Commit:** `ba275f030504846263565eaa9fec9c90e24e2d06` (`ba275f0`), compared against `ddc71c3`. I reviewed a pristine `git archive` copy in `round-3/tree`.
- **Changed files:** ADR-049, ADR-050, ADR-051, `check_examples.py`, `examples.json`, `review-02-dispositions.md`, and the implementation log. No `src/` change.
- **Scope:** as requested, not a full review.
  - R2-H1 and R2-H2 in depth.
  - The Medium and Low dispositions against the text.
  - New inconsistencies in the changed lines.
- **Date:** 2026-09-30

## Commands actually run

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive ba275f0 \| tar -x -C round-3/tree`; `git log/rev-parse/diff --stat ddc71c3 ba275f0` | 0 | 1 commit, 7 files, docs only |
| 2 | `PYTHONUTF8=1 python -B tree/docs/work/v1.6.0-preparation/check_examples.py` | **0** | **13 tests OK**, including `test_rebind_orderings` (`checker.log`) |
| 3 | `PYTHONUTF8=1 python -B rebind_model.py 6`: my independent model of ADR-051 §5–§9 and ADR-050 §8, written from the text and not importing the checker | **0** | Agrees with all 64 published orderings. Exhaustive search of **1,111,110** sequences (length ≤ 6), which adds registry flushes, chunk saves, crashes, owner cancel at T1 and operator cancel: **0** double payments outside the stated residual, **0** states with the instance AVAILABLE, **0** rewards lost (`rebind_model.log`) |
| 4 | `PYTHONUTF8=1 python -B verify_vectors_r3.py`: my round-2 independent vector checks rerun on the round-3 `examples.json` | **0** | 48 PASS: SplitMix64, `bounded`, surveys and fingerprints, the mixed-namespace case, durations, gas, truncation, 17 blueprints, reconciliation totality (`verify_vectors_r3.log`) |
| 5 | `PYTHONUTF8=1 python -B budget_r3.py` | **0** | Legacy record sizes for ADR-050 §10, and the rev-3 mission worst case: 3,804 B, within 4,096 (`budget_r3.log`) |

In the published vectors, 21 of the 64 orderings pay twice. That is exactly the set in which `t2_claim` comes before both `t1_return` and `owner_cancel_t2`; I counted the combinations by hand (1 + 4 + 8 + 8 = 21). So the vectors mark exactly the stated residual, "the new terminal claims first".

---

## 1. Round-2 items

Totals: **16 RESOLVED, 2 PARTIAL, 0 NOT RESOLVED.** Through these, round-1 H1 and M9 are now resolved. Round-1 L7 remains partial as R2-L10.

| ID | Verdict | Evidence / notes |
|---|---|---|
| **R2-H1** | **RESOLVED** | ADR-050 §2 now places a barrier on launches of every kind and on decommissions, before the terminal extracts the package or blanks the chip. ADR-049 §6 states the durability order and the replay (`IDEMPOTENT`, consuming the package). ADR-049 §7 puts the barrier on decommission, with an inert chip as the only residual. The ADR-049 Verification list adds an S2 launch cut. I enumerated every non-`data` path that touches a physical item: builder assembly (no registry change), launch and decommission (now barriered), scan (chip not consumed), receiver chip insertion and unlink (the chip is only moved; the link heals on the next check), resource start (nothing consumed), resource claim (items are created under the ADR-051 protocol) and withdraw (container only). **None still consumes an item before its registry change is durable.** Wording nit: R3-L6. |
| **R2-H2** | **RESOLVED** | ADR-051 §6 has claims set `paid_terminal`, and only the paying terminal may rematerialize or acknowledge. §7: `REBIND_CONFLICT` sets `paid_terminal` = here and binds the mission back. ADR-050 §8 and ADR-051 §8: an owner cancel of a `rebound` mission sends the instance to QUARANTINED. §9 and §11 state the residual. My independent model reproduces all 64 vectors. With flushes, saves and crashes added, the only double payment is a T2 claim executing while T1 still holds its earlier receipt, and no sequence ever makes the instance AVAILABLE; only the operator's `instance release` can. One qualification: the bind-back is only flush-pending, so a crash within the next 100 ticks turns "old terminal returns first" back into the residual (R3-L1). |
| R2-M1 | RESOLVED | ADR-050 §2: clock-only changes set only the ordinary dirty flag, so an idle server makes no coalesced flush; C9 reports flush frequency. |
| R2-M2 | RESOLVED | ADR-050 §7 never prunes the newest CLAIMED `discovery_required` mission per body. The bound holds: such records exist only for bodies recorded in the discovery store, which is capped at 128 (ADR-037/038). |
| R2-M3 | RESOLVED | ADR-049 §10: the menu extra data is the unchanged format-1 content plus a flag. A server-selected terminal view goes over the satellite channel, capped at 12 KiB and at most once per 5 ticks. My recomputation matches the stated ≈ 8.6 KiB worst case: selections ≈ 0.56 KiB, one yield 17 × 133 B ≈ 2.26 KiB, 8 summaries ≈ 1.3–1.4 KiB, buffer 32 × 133 B = 4.26 KiB. |
| R2-L1 | RESOLVED | ADR-050 §2 "Cost": the follow-up ADR must separate the snapshot epoch from the durable epoch. |
| R2-L2 | RESOLVED | ADR-051 §5: persistence is runtime-only; state from chunk storage counts as persisted; the terminal calls `setChanged()` while anything is unpersisted. For how to detect "from chunk storage", see R3-L5. |
| R2-L3 | **PARTIAL** | ADR-049 §4 reuses `OUTPUT_BLOCKED`, `INVALID_COMPONENTS`, `DEFINITION_NOT_FOUND` and `NO_POWER`, and appends new codes only; ADR-050 §11 uses `DEFINITION_NOT_FOUND`. But the checker and 8 blueprint vectors still expect `INVALID_LAYOUT` (R3-L2). |
| R2-L4 | RESOLVED | ADR-050 §3 adds `receipt_seen`, `rebound` and `paid_terminal`; ADR-049 §7 removes `link_epoch`; ADR-051 §7 states the recovery side effects and resolves the overlap through `paid_terminal`. Wording: R3-L4. |
| R2-L5 | RESOLVED | ADR-050 §5: an unacknowledged CLAIMED resource record enters the pruning queue only when its acknowledgement becomes durable. |
| R2-L6 | RESOLVED | ADR-049 §6: `IDEMPOTENT` and the package is consumed, "whatever its current mission". |
| R2-L7 | RESOLVED | ADR-049 §7: barrier before the chip is blanked; the only residual is an inert chip. Wording: R3-L6. |
| R2-L8 | RESOLVED | ADR-051 §7: "absent" means pruned or purged; replacing the file with an empty one is outside the guarantee. §11 qualifies the power-loss residual. |
| R2-L9 | RESOLVED | ADR-049 §10 and ADR-050 §6: 2 ticks for selection intents, 10 for state changes. |
| R2-L10 | **PARTIAL** | Deferred by design: `VERIFICATION.md` and `independent-review.zip` are to be committed with the acceptance, and neither is in `ba275f0`. The implementation log now names both disposition files. |
| R2-L11 | RESOLVED | ADR-050 §10: an over-cap root 3 loads with the same 8,192 bound, and per-record growth arithmetic is given. One figure is understated (R3-L4), but the conclusion holds. |
| R2-L12 | RESOLVED | ADR-049 §7 gives about 1,860 B with a test at the bound; this matches my round-2 figure of 1,859 B. |
| R2-L13 | RESOLVED | ADR-050 §8: a cancel or release releases a satellite only if that satellite names the mission. |

## 2. New findings in the changed lines

| Severity | Count |
|---|---|
| Critical | 0 |
| High | 0 |
| Medium | 0 |
| Low | 6 |

- **R3-L1 — The bind-back is not durable before the next action.**
  - *Location:* ADR-051 §9, first bullet, and the §11 row "old terminal returns first → paid once"; ADR-050 §2, which makes reconciliation flush-pending.
  - *Problem:* `REBIND_CONFLICT` is only flush-pending.
  - *Scenario:* T1 returns and binds the mission back. The server crashes before the coalesced flush, within 100 ticks. The registry reloads READY and bound to T2, so a T2 claim pays a second time. My model reproduces this with `t1_rec, crash, t2_claim`. It falls under the stated residual only when judged by the durable history.
  - *Suggestion:* Give `REBIND_CONFLICT` a barrier flush (it happens only after an operator rebind), or qualify the text as "once the bind-back is durable".
- **R3-L2 — Vectors and ADR use different refusal codes.** ADR-049 §4 now names the layout refusal `INVALID_COMPONENTS`. `check_examples.py` (`blueprint()`) and 8 `examples.json` blueprint vectors still expect `INVALID_LAYOUT`. The C7 Java tests will pin to these vectors, so rename them.
- **R3-L3 — The instance transition table misses a rebound case.** ADR-051 §2 still lists "ALLOCATED | owner cancel after reconciliation → AVAILABLE if not expired". It lacks the rule in ADR-050 §8 and ADR-051 §8 that a `rebound` mission's owner cancel goes to QUARANTINED. Add the row.
- **R3-L4 — Some figures and lists lag the rev-3 shapes.**
  - ADR-050 §3 says the mission worst case is "about 3.7 KiB". With `rebound` and `paid_terminal` it is ≈ 3,804 B, still within 4 KiB.
  - ADR-050 §7's lifecycle reservation lists only "claim, acknowledgement and quarantine fields". It should also name the rebind fields (`rebound`, the rebound `bound_terminal`).
  - ADR-050 §10 says a schema-1 mission is "at most about 450 bytes". With 128-character IDs it is 597 B. The conclusion still holds: 8,192 × (597 + 150) B = 5.84 MiB, and a v1.5 root is capped at 4 MiB anyway (≤ 5.17 MiB after growth), both within 6 MiB.
- **R3-L5 — "Read from chunk storage" needs a detectable signal.** `BlockEntity.load` is the same entry point for chunk loads, the host's carried-root placement, and third-party block-entity movers. Specify the signal: for example, only IDs and receipts present in a `ChunkDataEvent.Load` or `ChunkDataEvent.Save` tag for the terminal's chunk count as persisted; anything else starts unpersisted. Otherwise a mod-moved terminal could acknowledge before its new chunk is saved.
- **R3-L6 — Wording of the flush-failure and inert-chip cases.**
  - ADR-049 §6 says "If the flush fails, nothing changes". In the current code the registry mutation happens before the barrier, so a failed barrier leaves the satellite in memory (persisted later) while the package stays. The outcome is still safe, because the replay consumes the package. The text should say that instead.
  - ADR-049 §7 says "an operator may blank it" about an inert chip, but names no command. Either add one or point to `/clear` plus a blank chip.

## 3. Per-ADR verdicts

| ADR | Verdict | Notes |
|---|---|---|
| ADR-049 | **ACCEPT** | Non-blocking Low follow-ups R3-L2 and R3-L6. Fix R3-L2 before C7 pins the vectors. |
| ADR-050 | **ACCEPT** | Non-blocking Low follow-up R3-L4. |
| ADR-051 | **ACCEPT** | Non-blocking Low follow-ups R3-L1, R3-L3 and R3-L5. R3-L1 is cheap to close with a barrier, and I recommend it. |

No Critical, High or Medium finding remains in the checked scope. The evidence items (`VERIFICATION.md`, `independent-review.zip`) still have to be committed with the acceptance record (R2-L10).

## 4. Not verified

- This was a targeted check. I did not re-review unchanged sections of ADR-049..052, ADR-048 or the coverage table beyond the scope listed above.
- The rebind model is an abstraction of one mission and two terminals. It does not model the epoch wait for claims, buffer-full or receipt-full refusals, player withdrawals, or more than two terminals.
- No runtime measurement: nothing is implemented, and Gradle and game runs were not permitted.
- Forge facts are as verified in rounds 1 and 2 (47.4.10 bytecode). None were re-checked here, because revision 3 relies on no new ones.
