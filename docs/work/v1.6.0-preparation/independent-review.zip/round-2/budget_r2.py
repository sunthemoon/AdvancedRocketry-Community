"""Reviewer's round-2 size model: revision-2 record shapes and the terminal menu extra data (ADR-049 section 10)."""

def named(name, payload):
    return 1 + 2 + len(name) + payload

INT, LONG, BYTE, UUID = 4, 8, 1, 20  # UUID as int[4]: length 4 + 16


def s(n):
    return 2 + n


def entry(n):
    return named("item", s(n)) + named("count", INT) + 1


def rlist(name, entries, n):
    return named(name, 1 + 4 + entries * entry(n))


def mission(n, entries, quarantine=True):
    body = (named("schema_version", INT) + named("mission_id", UUID) + named("satellite_id", UUID)
            + named("owner_id", UUID) + named("definition_id", s(n)) + named("kind", s(8))
            + named("target_body", s(n)) + named("instance_id", UUID) + named("seed", LONG)
            + named("started_at", LONG) + named("completes_at", LONG) + named("start_epoch", LONG)
            + named("status", s(23)) + named("ready_at", LONG) + named("resolved_at", LONG)
            + named("reward_version", s(200)) + rlist("reward", entries, n)
            + named("bound_terminal", named("terminal_id", UUID) + named("level", s(n)) + named("pos", LONG) + 1)
            + named("acknowledged", BYTE) + named("ack_epoch", LONG))
    if quarantine:
        body += named("quarantine", named("reason", s(32)) + named("previous_status", s(23))
                      + named("receipt_seen", BYTE) + 1)
    return body + 1


def instance(n, entries):
    body = (named("schema_version", INT) + named("instance_id", UUID) + named("owner_id", UUID)
            + named("system", s(n)) + named("asteroid_type", s(n)) + named("table_version", s(16))
            + named("candidate_fingerprint", s(16)) + named("seed", LONG) + rlist("yield", entries, n)
            + named("created_at", LONG) + named("expires_at", LONG) + named("state", s(11))
            + named("source_mission", UUID) + named("allocated_mission", UUID)
            + named("quarantine", named("reason", s(32)) + named("previous_state", s(11)) + 1))
    return body + 1


def satellite(n, comps):
    stats = named("stats", sum(named(k, INT) for k in ("power", "battery", "data", "cargo", "rating")) + 1)
    kind_state = named("kind_state", named("charge", LONG) + named("charge_time", LONG)
                       + named("scan_energy", INT) + named("scan_radius_blocks", INT)
                       + named("scan_cell_blocks", INT) + named("output_multiplier_percent", INT)
                       + named("receiver_id", UUID) + named("link_epoch", LONG) + 1)
    body = (named("schema_version", INT) + named("satellite_id", UUID) + named("definition_id", s(n))
            + named("owner_id", UUID) + named("launched_at", LONG) + named("status", s(17))
            + named("current_mission_id", UUID) + named("kind", s(14)) + named("orbit_body", s(n))
            + named("blueprint", named("components", 1 + 4 + comps * s(n)) + stats
                    + named("legacy_blueprint", BYTE) + 1) + kind_state)
    return body + 1


print("rev-2 record worst cases (128-char IDs):")
print(f"  mission (17 reward entries, quarantine fields) = {mission(128, 17)} B  bound 4096")
print(f"  instance (17 yield entries, quarantine)        = {instance(128, 17)} B  bound 4096")
print(f"  satellite (8 components, all kind fields)       = {satellite(128, 8)} B  bound 2048")


# Terminal menu extra data (FriendlyByteBuf): writeUtf = varint length + bytes; UUID = 16; varint up to 5.
def utf(n):
    return (1 if n < 128 else 2) + n

pos = 8
adr029 = 1 + 1 + 1 + 128 * utf(128) + 1 + 16 * (utf(128) + 1 + 16 * 1)       # marker/version, targets, 16 data defs
schema2_defs = 1 + 16 * (utf(128) + 1 + 1 + 16 * 1)                            # id, kind, count, 16 target indices
products = 1 + 8 * utf(128)
missions = 1 + 64 * (16 + 1 + 1 + 5 + 5)                                       # id, status, kind, remaining, index
buffer = 1 + 32 * (utf(128) + 3)                                                # item + count varint
inst_ids_only = 1 + 16 * (16 + utf(128) + 5)                                    # id, type, expiry
inst_with_yield = 1 + 16 * (16 + utf(128) + 5 + 1 + 17 * (utf(128) + 3))        # plus full yield
base = pos + 5 + adr029 + schema2_defs + products + missions + buffer
print("terminal menu extra data (worst case, 128-char IDs):")
print(f"  without instance yields: {base + inst_ids_only} B (limit 32,600)")
print(f"  with the full yield of 16 instances: {base + inst_with_yield} B (limit 32,600)")
print(f"  16 instance yields alone: {inst_with_yield} B")
