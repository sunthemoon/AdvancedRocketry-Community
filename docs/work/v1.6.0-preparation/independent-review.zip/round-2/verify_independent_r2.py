"""Reviewer's round-2 re-derivation of ADR-049/051/052 revision-2 rules (does not import the checker)."""
import hashlib
import itertools
import json
import math
import sys
from pathlib import Path

EX = json.loads((Path(__file__).parent / "tree/docs/work/v1.6.0-preparation/examples.json").read_text(encoding="utf-8"))
M64 = (1 << 64) - 1
fails = []


def check(name, got, want):
    ok = got == want
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"\n   got  {got}\n   want {want}"))
    if not ok:
        fails.append(name)


def const(s):
    return int.from_bytes(s.encode("ascii"), "big")


def sm(seed):
    st = seed & M64
    while True:
        st = (st + 0x9E3779B97F4A7C15) & M64
        z = st
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        yield z ^ (z >> 31)


def bnd(g, n):
    return (next(g) >> 1) % n


check("seed0 published", [f"{next(g):016x}" for g in [sm(0)] for _ in range(3)] if False else
      (lambda g: [f"{next(g):016x}" for _ in range(3)])(sm(0)),
      ["e220a8397b1dcdaf", "6e789e6aa1b965f4", "06c45d188009454f"])
check("seed0 in examples", EX["splitmix64_seed0"], ["e220a8397b1dcdaf", "6e789e6aa1b965f4", "06c45d188009454f"])
for c in EX["splitmix64"]:
    check(f"splitmix {c['seed']}", (lambda g: [f"{next(g):016x}" for _ in c["outputs"]])(sm(int(c["seed"], 16))), c["outputs"])
for c in EX["bounded"]:
    check(f"bounded {c['seed']}/{c['n']}", (lambda g: [bnd(g, c["n"]) for _ in c["values"]])(sm(int(c["seed"], 16))), c["values"])


def yield_of(t, seed):
    y = sm(seed ^ const("ASTYIELD"))
    mv, rv = t["mass_variability_pct"], t["richness_variability_pct"]
    dm = bnd(y, mv + 1) - mv // 2
    mass = min(4096, max(1, t["mass"] * (100 + dm) // 100))
    dr = bnd(y, rv + 1) - rv // 2
    rich = min(100, max(0, t["richness_pct"] + dr))
    n_ore = mass * rich // 100
    tw = sum(o["weight"] for o in t["ores"])
    cnt = [0] * len(t["ores"])
    for _ in range(n_ore):
        r = bnd(y, tw)
        acc = 0
        for k, o in enumerate(t["ores"]):
            acc += o["weight"]
            if acc > r:
                cnt[k] += 1
                break
    out = [[o["item"], c] for o, c in zip(t["ores"], cnt) if c]
    if mass - n_ore:
        out.append([t["base_item"], mass - n_ore])
    return out


def survey(types, system, seed, count, order):
    cands = sorted([t for t in types if not t["systems"] or system in t["systems"]], key=order)
    fp = hashlib.sha256("".join(f"{t['id']}\t{t['weight']}\t{t['table_version']}\n" for t in cands)
                        .encode("utf-8")).hexdigest()[:16]
    a = sm(seed ^ const("SURVEY01"))
    out = []
    for _ in range(count):
        s = next(a)
        r = bnd(sm(s ^ const("ASTTYPE1")), sum(t["weight"] for t in cands))
        acc = 0
        for t in cands:
            acc += t["weight"]
            if acc > r:
                out.append([t["id"], f"{s:016x}", yield_of(t, s)])
                break
    return fp, out


def full_string(t):
    # Java String.compareTo on ResourceLocation.toString(): UTF-16 code units; IDs are ASCII here
    return [ord(ch) for ch in t["id"]]


def path_first(t):
    ns, path = t["id"].split(":", 1)
    return (path, ns)


for c in EX["survey"]:
    fp, inst = survey(EX[c["types"]], c["system"], int(c["mission_seed"], 16), c["count"], full_string)
    check(f"survey {c['types']} {c['mission_seed']} fingerprint", fp, c["candidate_fingerprint"])
    check(f"survey {c['types']} {c['mission_seed']} instances", inst, c["instances"])
    pf_fp, pf_inst = survey(EX[c["types"]], c["system"], int(c["mission_seed"], 16), c["count"], path_first)
    if c["types"] == "mixed_namespace_types":
        print("INFO mixed-namespace: full-string order types", [i[0] for i in inst],
              "| path-first types", [i[0] for i in pf_inst], "| fingerprints", fp, pf_fp)
        check("mixed-namespace path-first differs (instances)", pf_inst != c["instances"], True)
        check("mixed-namespace path-first differs (fingerprint)", pf_fp != c["candidate_fingerprint"], True)

# Durations and gas re-derived with integer arithmetic
for c in EX["asteroid_duration"]:
    d = -(-(12000 * c["time_multiplier_pct"] * c["config_pct"] * 10) // (100 * 100 * c["rating"]))
    check(f"asteroid duration {c}", min(72000, max(200, d)), c["duration"])
for c in EX["gas"]:
    cap = c["cargo"] * 64
    rate = max(1, c["amount_per_1000_ticks"] * c["rating"] // 10)
    base = min(72000, max(200, -(-(cap * 1000) // rate)))
    check(f"gas {c['amount_per_1000_ticks']}/{c['rating']}/{c['cargo']}/{c['config_pct']}",
          {"rate": rate, "base": base, "amount": min(cap, rate * base // 1000),
           "duration": min(72000, max(200, -(-(base * c["config_pct"]) // 100)))}, c["expected"])
for c in EX["truncation"]:
    rem, out = c["cargo"] * 64, []
    for item, n in c["entries"]:
        take = min(n, rem)
        if take:
            out.append([item, take])
        rem -= take
    check(f"truncation cargo {c['cargo']}", out, c["delivered"])

# Blueprints per ADR-049 rev 2 section 4 order: INVALID_LAYOUT, (DEFINITION_UNAVAILABLE n/a), STAT_LIMIT, REQUIREMENT_UNMET
CAT = EX["components"]
ROLE_STAT = {"power": ("power", "power_generation"), "battery": ("battery", "battery_capacity"),
             "data_storage": ("data", "data_capacity"), "cargo": ("cargo", "cargo_stacks")}
CAPS = {"power": 1000, "battery": 1_000_000, "data": 100_000, "cargo": 27, "rating": 100}


def my_blueprint(case):
    s, kind = case["slots"], case["kind"]
    ch = CAT.get(s["chassis"]) if s["chassis"] else None
    pr = CAT.get(s["primary"]) if s["primary"] else None
    mods = [CAT[m] for m in s["modules"]]
    if ch is None or ch["role"] != "chassis" or len(mods) > 6 or any(m["role"] not in ROLE_STAT for m in mods):
        return "INVALID_LAYOUT"
    if kind == "data":
        if pr is not None:
            return "INVALID_LAYOUT"
    elif pr is None or pr["role"] != "primary" or pr.get("kind") != kind:
        return "INVALID_LAYOUT"
    st = {"power": 0, "battery": 720, "data": 0, "cargo": 0, "rating": pr["primary_rating"] if pr else 0}
    for m in mods:
        k, f = ROLE_STAT[m["role"]]
        st[k] += m[f]
    if any(st[k] > v for k, v in CAPS.items()):
        return "STAT_LIMIT"
    if st["power"] < 1 or (kind == "survey" and (st["data"] < 1 or st["battery"] < case.get("scan_energy", 0))) \
            or (kind in ("asteroid_miner", "gas_harvester") and st["cargo"] < 1):
        return "REQUIREMENT_UNMET"
    return st


for c in EX["blueprints"]:
    check(f"blueprint {c['name']}", my_blueprint(c), c["expected"])

# Reconciliation table: totality and a two-terminal composition after an operator rebind
regs = {r["registry"] for r in EX["reconciliation"]}
recs = {r["receipt"] for r in EX["reconciliation"]}
pairs = {(r["registry"], r["receipt"]) for r in EX["reconciliation"]}
check("reconciliation is total (12 x 3 = 36 unique pairs)", (len(pairs), len(EX["reconciliation"]), len(regs) * len(recs)), (36, 36, 36))
table = {(r["registry"], r["receipt"]): r["action"] for r in EX["reconciliation"]}
# Scenario: T1 paid (receipt serialized), registry reverted to READY, operator rebinds to T2, T1 returns first.
t1 = table[("READY_ELSEWHERE", "SERIALIZED")]        # evaluated at T1 (mission now bound to T2)
t2 = table[("CLAIMED_HERE", "NONE")]                 # evaluated at T2 after T1 set CLAIMED (not acknowledged)
print(f"INFO rebind composition: T1 -> {t1}; then T2 -> {t2}")
check("rebind composition pays at most once (expected by ADR-051 section 9)", t2 != "REMATERIALIZE", True)

print()
print("FAILURES:", fails if fails else "none")
sys.exit(1 if fails else 0)
