import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Reviewer's Java cross-check of the revision-2 survey ordering, fingerprint and mixed-namespace vector. */
public class JavaVectorsR2 {
    static final class SplitMix64 {
        long s;
        SplitMix64(long seed) { s = seed; }
        long next() {
            s += 0x9E3779B97F4A7C15L;
            long z = s;
            z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
            z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
            return z ^ (z >>> 31);
        }
        long bounded(long n) { return (next() >>> 1) % n; }
    }

    record T(String id, int weight, String version) {}

    static String fingerprint(List<T> sorted) throws Exception {
        StringBuilder b = new StringBuilder();
        for (T t : sorted) b.append(t.id).append('\t').append(t.weight).append('\t').append(t.version).append('\n');
        byte[] d = MessageDigest.getInstance("SHA-256").digest(b.toString().getBytes(StandardCharsets.UTF_8));
        return HexFormat.of().formatHex(d).substring(0, 16);
    }

    static List<String> types(List<T> sorted, long seed, int count) {
        final long SURVEY01 = 0x5355525645593031L, ASTTYPE1 = 0x4153545459504531L;
        SplitMix64 a = new SplitMix64(seed ^ SURVEY01);
        long total = sorted.stream().mapToLong(T::weight).sum();
        List<String> out = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            long s = a.next();
            long r = new SplitMix64(s ^ ASTTYPE1).bounded(total), acc = 0;
            for (T t : sorted) { acc += t.weight; if (acc > r) { out.add(t.id); break; } }
        }
        return out;
    }

    public static void main(String[] args) throws Exception {
        List<T> mixed = List.of(new T("zeta:alpha", 1, "0000000000000b01"), new T("alpha:zeta", 3, "0000000000000b02"));
        List<T> fullString = new ArrayList<>(mixed);
        fullString.sort(Comparator.comparing(T::id));                       // String.compareTo on toString()
        List<T> pathFirst = new ArrayList<>(mixed);                           // ResourceLocation.compareTo order
        pathFirst.sort(Comparator.comparing((T t) -> t.id.substring(t.id.indexOf(':') + 1))
                .thenComparing(t -> t.id.substring(0, t.id.indexOf(':'))));
        System.out.println("full-string " + fingerprint(fullString) + " " + types(fullString, 7L, 4));
        System.out.println("path-first  " + fingerprint(pathFirst) + " " + types(pathFirst, 7L, 4));
        List<T> builtin = new ArrayList<>(List.of(new T("example:small", 20, "0000000000000a01"),
                new T("example:light", 15, "0000000000000a02"), new T("example:dense", 2, "0000000000000a03")));
        builtin.sort(Comparator.comparing(T::id));
        System.out.println("earth fingerprint " + fingerprint(builtin));
    }
}
