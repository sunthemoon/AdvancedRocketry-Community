import json
from pathlib import Path

e = json.loads((Path(__file__).parent / "tree/docs/work/v1.6.0-preparation/examples.json").read_text(encoding="utf-8"))
print(list(e.keys()))
print(json.dumps(e["mixed_namespace_types"], indent=None)[:2000])
for s in e["survey"]:
    print(s["types"], s["system"], s["mission_seed"], s["count"], s["candidate_fingerprint"], [i[0] for i in s["instances"]])
print("reconciliation rows:", len(e["reconciliation"]))
for r in e["reconciliation"]:
    print("  ", r["registry"], r["receipt"], r["action"])
for b in e["blueprints"]:
    print(b["name"], "|", b["kind"], "|", b["slots"], "|", b.get("scan_energy"), "|", b["expected"])
print(json.dumps(e["asteroid_types"][0])[:500])
print(list(e["components"].keys()))
