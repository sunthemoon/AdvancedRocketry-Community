# Independent contract review, round 2: v1.6.0 ADR-048..052, revision 2

- **Reviewer role:** the same independent reviewer as round 1. I did not write the documents. I had read-only access to the repository and wrote files only under `round-2/` of my Temp directory. The round-1 `REVIEW.md` is unchanged.
- **Commit reviewed:** `ddc71c3018d526f236611a174037598959804740` (`ddc71c3`, branch `codex/v1.6.0-satellite-resource-missions`), compared against `ab207f0`. I reviewed a pristine `git archive` copy in `round-2/tree`. I did not open the untracked `AdvancedRocketry-Community-v1plus-Development-Docs/` directory.
- **Date:** 2026-09-30
- **Scope of the change:** documentation only (14 files). ADR-049, ADR-050 and ADR-051 are at revision 2, and ADR-052 has revision-2 edits. Also new or changed: the dispositions, the coverage table, the porting-matrix rows, the audit, the vectors and checker, the implementation log and COMPLETION-PLAN. No `src/` file changed, so the current-code observations from round 1 still apply.

## Commands actually run

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `git -C … archive ddc71c3 \| tar -x -C round-2/tree`; `git log/rev-parse/diff --stat ab207f0 ddc71c3` | 0 | 1 commit, 14 files, docs only |
| 2 | `PYTHONUTF8=1 python -B tree/docs/work/v1.6.0-preparation/check_examples.py` | **0** | 12 tests OK (`checker.log`) |
| 3 | `PYTHONUTF8=1 python -B verify_independent_r2.py` (fresh re-derivation from the rev-2 text; does not import the checker) | **1** | **48 PASS**: every vector, including fingerprints, the mixed-namespace case, all 17 blueprints and the 36-pair totality. **1 deliberate FAIL**: a two-terminal composition property of the reconciliation table, which is finding R2-H2 (`verify_independent_r2.log`) |
| 4 | `java JavaVectorsR2.java` (JDK 17; `String.compareTo`, `MessageDigest`, Java `long`) | **0** | Mixed-namespace fingerprint `17084859989b3213` and type sequence match the vector. Path-first order gives `1a68d547fae6b171` and a different sequence. Earth fingerprint `a5f21d1626a4b74b` matches (`java_vectors_r2.log`) |
| 5 | `PYTHONUTF8=1 python -B budget_r2.py` | **0** | Worst cases: mission 3,757 B, instance 3,253 B, satellite 1,859 B; terminal menu 30,886 B without instance yields, 67,078 B with them (`budget_r2.log`) |
| 6 | `curl` upstream `entity/EntityStationDeployedRocket.java` at `c5cd5af…`, `sha256sum` | 0 | Hash matches `legacy-manifest`; the gas duration is at line 383, as the corrected audit says |
| 7 | `javap -c -p` on the Forge 47.4.10 mapped jar (same classes as round 1, re-inspected) | 0 | See "Forge/Minecraft facts re-verified" below |

**Forge/Minecraft facts re-verified (47.4.10 bytecode):**
- `ServerLevel.save` saves `DimensionDataStorage` before chunks.
- `ChunkMap.processUnloads` saves up to 20 chunks per tick, with a 10 s cooldown.
- `ChunkMap.save` returns early unless `isUnsaved()`. Otherwise it runs `ChunkSerializer.write` (`saveWithFullMetadata`), then posts `ChunkDataEvent.Save`, then calls `IOWorker.store` asynchronously.
- The unload path posts `ChunkEvent.Unload` and then calls the same `save`.
- The full-chunk `ChunkEvent.Load` is posted after `registerAllBlockEntitiesAfterLevelLoad`, so a missing-terminal check run on that event sees block entities.

---

## 1. Dispositions of the round-1 findings

Totals: **36 RESOLVED, 3 PARTIAL (H1, M9, L7), 0 NOT RESOLVED.**

| ID | Verdict | Evidence in revision 2 / notes |
|---|---|---|
| H1 | **PARTIAL** | ADR-050 §2 defines the write policy. Barriers stay only on `data` launch/start/claim/cancel and discovery replay; everything else only marks the registry dirty; a coalesced flush runs at most once per 100 ticks; the save epoch is defined; flush cost is a C9 gate. Two defects remain: (a) removing the barrier from non-`data` launches opens a component-loss window (**R2-H1**); (b) the clock advance marks the registry dirty on every pass, so the "coalesced" flush runs every 100 ticks even on an idle server (**R2-M1**). |
| H2 | RESOLVED | ADR-050 §5: entries are removed on cancel, quarantine or early claim; capacity is checked before any map mutation; a failed schedule changes nothing; a queue never holds more entries than records it serves. Verification includes churn beyond 1,024 cycles and atomic schedule failure. (Pruning queue detail: R2-L5.) |
| H3 | RESOLVED | ADR-050 §3 sets the bounds to 4/4/2 KiB, derived from field maxima, enforced at create/change time and never only at encode. Types or tables that could not fit are rejected at load (ADR-052 §2). My recomputation of the rev-2 shapes: mission 3,757 B, instance 3,253 B, satellite 1,859 B, all within bounds. ADR-049 §7's "about 1.7 KiB" is outdated (R2-L12). |
| H4 | RESOLVED | ADR-050 §10: a legacy root loads above the count limits (≤ 8,192 missions), and admission refuses new starts until retention drains it. §6: per-owner limits apply at admission only. An S1 fixture with 8,192 missions and a 300-satellite owner is planned. (Wording: R2-L11.) |
| H5 | RESOLVED | ADR-051 §7 row "CLAIMED, acknowledged → drop once `ack_epoch < E`" frees receipts independently of pruning. An A1 test with more than 256 claims is planned. The logic holds under ADR-050 §2's epoch definition. (Liveness after reload: R2-L2.) |
| H6 | RESOLVED | ADR-051 §7 now covers every combination, including the blocked registry ("Nothing; resource actions refused"), CANCELLED, QUARANTINED and rebound. The vectors hold 36 unique (12 × 3) pairs; I checked independently that the set is complete. "Absent" drops a receipt, which never pays, so it cannot duplicate within the stated guarantee (wording: R2-L8). However, the rebound rows compose into a double payment across two terminals (**R2-H2**). |
| H7 | RESOLVED | ADR-050 §8 and ADR-051 §8: owners cancel resource missions only at the bound terminal after reconciliation; operator and quarantine cancels send the instance to QUARANTINED. The crash-cut row "registry reverted, then an operator cancels" now holds. The owner-cancel variant after a rebind is part of R2-H2. |
| M1 | RESOLVED | ADR-051 §6: `serialized` is set only from a `ChunkDataEvent.Save` tag that contains the receipt; IOWorker loss is named as a residual in §11. The event ordering is re-verified in bytecode. |
| M2 | RESOLVED | ADR-051 §4–§5: a mission binds only to a terminal whose ID has been seen in a chunk-save tag; otherwise `AWAITING_WORLD_SAVE`. (Liveness after restart: R2-L2.) |
| M3 | RESOLVED | ADR-051 §10: `ARCE_MISSION_DELIVERY` lines of at most 512 bytes, plus the `mission inspect` fields. |
| M4 | RESOLVED | ADR-049 §1 and ADR-050 §9 now agree: an unknown kind blocks the whole registry. |
| M5 | RESOLVED | ADR-050 §4, §8 and §9: precise invariants; QUARANTINED counts as unfinished and keeps the satellite binding; `satellite recover`; dangling references from finished records are allowed. (Edge case: R2-L13.) |
| M6 | RESOLVED | ADR-050 §7 reserves the lifecycle maximum at admission. The `receipt_seen` field is missing from the shape list (R2-L4). |
| M7 | RESOLVED | ADR-050 §6–§7: eligibility 1,200 ticks after resolution, a per-owner retained cap of 128, and a stated throughput (at least 2,048 per 1,200 ticks; consistent with 64 removals per pass). This retention rule introduces **R2-M2** (conflict with ADR-038). |
| M8 | RESOLVED | ADR-050 §5: expiry allows 16 removals with 32 inspections per pass, pruning 64 with 128. §7 adds `mission purge`. ADR-051 §2: instance removal does not depend on the 1,536 threshold. (Re-queue rule: R2-L5.) |
| M9 | **PARTIAL** | ADR-049 §10 fixes the channel `advancedrocketrycommunity:satellite` protocol 1, terminal menu format 2, builder and receiver menus, and keeps the four existing channel versions. But the 32,600-byte terminal payload cannot hold 16 instances with their yields in the worst case (**R2-M3**). |
| M10 | RESOLVED | ADR-049 §6–§7 snapshot the kind parameters into the satellite; ADR-050 §11. |
| M11 | RESOLVED | ADR-049 §9: the existing holder keeps the link; unlink on break, by the owner when the receiver is missing, or by an operator; receiver root schema 1. |
| M12 | RESOLVED | ADR-052 §4 requires `toString()` compared with `String.compareTo` and explicitly not `ResourceLocation.compareTo`. The mixed-namespace vector reproduces in Python and Java, and path-first order gives a different sequence and fingerprint. |
| M13 | RESOLVED | ADR-052 §4 adds `candidate_fingerprint` to missions and instances; §7 returns `VERSION_CHANGED`. Fingerprints reproduced independently. |
| M14 | RESOLVED | `v1.6.0-contract-coverage.md` maps every item in version-document §8–§14. ADR-049 §10 disposes of the star map, with a porting-matrix row. ADR-050 §6 and ADR-049 §8 make limits configurable up to fixed maxima. |
| M15 | RESOLVED | ADR-050 §10 freezes every root-3 shape for C7 and plans no root 4. COMPLETION-PLAN and the implementation log split C8 into C8a and C8b. |
| M16 | RESOLVED | ADR-051 Context, §11 and Verification match the save paths I re-verified. |
| L1 | RESOLVED | ADR-050 §1 (`/time` changes only the day time). |
| L2 | RESOLVED | ADR-050 §4 lists lazy `data` completion and reconciliation to CLAIMED. |
| L3 | RESOLVED | ADR-052 §3 (64-bit arithmetic; nothing exceeds 2⁴⁰), ADR-049 §4 and §8 (saturating charge), and a checker assertion. |
| L4 | RESOLVED | ADR-049 §3–§6: `data` is terminal-only; refusal codes and their order; launch re-validation; missionless replay returns `IDEMPOTENT`; `satellite_package`; builder 10,000 FE. Follow-ups: R2-L3 (code names), R2-L6 (replay with a mission). |
| L5 | RESOLVED | ADR-049 §3 and §8: Y range, ratio definition, radius divisible by cell, scans independent of missions. |
| L6 | RESOLVED | ADR-052 §5 and §8 (Iridium richness variability 30; the rebalance is stated). The audit is corrected: 250 × zoom; the gas formula at upstream line 383, which I verified by hash and line. The chip-copy slot and the legacy blueprint label are recorded in ADR-049. |
| L7 | **PARTIAL** | Done: porting-matrix rows (7 new) and the dispositions file. Missing: `v1.6.0-preparation/VERIFICATION.md` is still absent, although every rev-2 ADR header and the implementation log link to it; `independent-review-01.zip`, which the dispositions say is archived "in this directory", is not in the commit; the status-file update is deferred to acceptance (R2-L10). |
| L8 | RESOLVED | ADR-050 §2: the file holds E+1 and load sets E from the file. I checked that the claim guard `E > start_epoch` holds across save, crash and load. |
| L9 | RESOLVED | ADR-049 §10 and ADR-051 §4: selection is server-side state; no packet carries an index. |
| L10 | RESOLVED | ADR-051 §4–§5: minting is recorded as a balance decision; the buffer counts items; withdrawal is menu-only; no automation exposure. |
| L11 | RESOLVED | ADR-051 §7 (terminal→missions index; the multi-tick pass blocks actions) and §9 (missing-terminal rule; the bytecode shows block entities are registered before the full-chunk `ChunkEvent.Load`). |
| L12 | RESOLVED | The implementation log has a class-size split plan per chunk. |
| L13 | RESOLVED | ADR-049 Migration and ADR-050 §10 (whole world refused by v1.5; builder/receiver blocks and chips lost; five-backup limit stated). |
| L14 | RESOLVED | ADR-050 §11 (`BODY_UNAVAILABLE`, solar output 0, starts refused, system recomputed at start). |
| L15 | RESOLVED | ADR-052 §7 `INPUTS_UNAVAILABLE`. |
| L16 | RESOLVED | Slot-based blueprint vectors, including missing, misplaced and duplicate parts and refusal order, and a total reconciliation function. I re-derived all 17 blueprint vectors independently. |

---

## 2. New and remaining findings (revision 2)

| Severity | Count |
|---|---|
| Critical | 0 |
| High | 2 |
| Medium | 3 |
| Low | 13 |

### High

**R2-H1 — Non-`data` launches lost their barrier flush, so assembled components can be lost.**
- *Location:* ADR-050 §2 ("barrier flushes … remain only on the existing `data` paths"; "all v1.6-kind operations" only mark dirty); ADR-049 §6 (launch consumes the package on success; there is no crash-cut rule).
- *Why it matters:* Today `SatelliteManager.launch` flushes the registry before the terminal extracts the package. ADR-010 relies on that order so the package never disappears before its satellite is durable. Revision 2 keeps that order only for `data`. For `survey`, `solar`, `asteroid_miner` and `gas_harvester`, the registry becomes durable at the next coalesced flush, up to 100 ticks later. The terminal chunk, meanwhile, is usually saved within a tick or two by `processUnloads` (verified).
- *Failure scenario:*
  1. A non-`data` launch succeeds and the package is extracted, making the chunk dirty.
  2. An incremental chunk save writes the terminal without the package.
  3. The server crashes before the coalesced flush.
  4. After restart the satellite does not exist, the package is gone, and the chip points at nothing (`SATELLITE_NOT_FOUND`).

  Every component consumed at assembly is lost. This violates version-document §14 ("奖励和组件资源守恒") and matches docs/17 High (a cross-store loss).
- *Required change:* Keep a barrier flush for launches of every kind; launches are rare, at most one per satellite. Alternatively, make launch two-phase: keep the package in the terminal marked "launching" and consume it only once `save_epoch > launch_epoch`, reconciled like receipts. Add a launch crash cut, "chunk saved, registry not", to ADR-049 and the S2 list. Decommission has the same ordering question; see R2-L7.

**R2-H2 — After an operator rebind, the reconciliation rows still pay twice when the old terminal returns.**
- *Location:* ADR-051 §7 (the row "ACTIVE or READY, bound elsewhere (rebound) | present → set CLAIMED, no items; `REBIND_CONFLICT`" and the row "CLAIMED, not acknowledged, bound here | none → rematerialize") and §9 ("If the old terminal comes back with a receipt, §7 records `REBIND_CONFLICT` or `REBIND_DOUBLE_PAY`"; the residual is limited to a terminal that "never returns"); `examples.json` and `check_examples.py` `reconcile()`.
- *Failure scenario:*
  1. T1 pays a claim; its chunk is saved with the receipt and items.
  2. The registry reverts to READY. This is crash-cut row 2, which the Context calls normal: "often before the registry".
  3. The player picks T1 up, carrying the raw root. The chunk at T1's last position loads without T1, so the mission shows `TERMINAL_MISSING`.
  4. An operator runs the only offered recovery: `mission rebind` to T2.
  5. The player places T1 again. T1's reconciliation finds `READY_ELSEWHERE + SERIALIZED` and sets the mission to CLAIMED, not acknowledged, still bound to T2.
  6. T2's next reconciliation finds `CLAIMED_HERE + NONE` and rematerializes the reward a second time.

  The checker's own function yields `SET_CLAIMED_NO_ITEMS_REBIND_CONFLICT` and then `REMATERIALIZE`. My composition check reproduces this (`verify_independent_r2.log`). The same rebind also lets the owner cancel at T2 after T2's reconciliation, which never sees T1's receipt, and return the instance to AVAILABLE. This is a duplication path in exactly the case §9 presents as handled.
- *Required change:* Record where a mission was paid: a `paid_terminal` field set by a claim, or by `CLAIM_RECOVERED` / `REBIND_CONFLICT` to the terminal that holds the receipt. Allow rematerialization only at `paid_terminal`. `REBIND_CONFLICT` must set `paid_terminal` to the old terminal and rebind the mission back to it, or mark it acknowledged through the old terminal's receipt. After a rebind, owner cancellation must also wait until the old terminal has been reconciled or declared missing by an operator, or send the instance to QUARANTINED. Add a two-terminal composition test to the vectors: every rebind ordering must pay at most once.

### Medium

**R2-M1 — The coalesced flush is effectively permanent, because clock advances mark the registry dirty.**
- *Location:* ADR-050 §2 ("A coalesced flush runs at most once per 100 ticks while the registry is dirty") and §5 ("Every 20 ticks … advance the clock"). Code: `SatelliteMissionSavedData.completeDue` calls `setDirty()` whenever `clockAdvanced()`.
- *Problem:* The clock advances on every pass, so the registry is always dirty. The coalesced flush therefore runs every 100 ticks forever, even on an idle server. Each run is a full serialize + gzip + fsync + read-back decode + deep compare on the main thread. That is 60 times the autosave rate, with cost proportional to a root of up to 16 MiB. The clock does not need this: after a restart, `MonotonicMissionClock` rebuilds elapsed time from `level.dat` game time.
- *Required change:* Clock-only changes must not trigger the coalesced flush; persist them at autosave or shutdown only. Define which mutations are "urgent", for example resource starts (the epoch wait) and acknowledgements (receipt drop). State the expected steady-state flush frequency for the C9 measurement.

**R2-M2 — Retention prunes the evidence that ADR-038 uses to repair discoveries.**
- *Location:* ADR-050 §7 (finished records eligible 1,200 ticks after resolution; per-owner cap 128) and §4 (`data` claim "ADR-010/037/038 unchanged"); ADR-038 §4 ("repairs missing discoveries evidenced by historical CLAIMED missions with `discoveryRequired=true` … Historical CLAIMED receipts stay CLAIMED while waiting for missing/full/future celestial data"). Code: `SatelliteManager.initializeDiscoveryReplay` queues CLAIMED paid receipts whose target is not recorded as discovered.
- *Problem:* On any server above the 1,536 / 128 thresholds, CLAIMED `data` missions disappear 1,200 ticks after their claim. If the celestial store is later restored from backup, or is future, full or missing, the accepted ADR-038 repair has no evidence left. This silently narrows an accepted ADR.
- *Required change:* Exempt discovery evidence from pruning. A bounded form is to keep the newest CLAIMED `discovery_required` mission per target body, at most 128. Alternatively, amend ADR-038 explicitly and record the new limit.

**R2-M3 — The terminal's menu payload cannot meet its 32,600-byte bound in the worst case.**
- *Location:* ADR-049 §10 (the terminal menu carries "the player's ≤ 16 instances", "tested at maximum"); ADR-052 Consequences ("Players can see an instance's exact yield before they mine it").
- *Problem:* My worst-case estimate with 128-character IDs is 30,886 B for the ADR-029 part, schema-2 definitions, products, 64 mission summaries and 32 buffer entries, but *without* instance yields. Sixteen instance yields of 17 entries each add 38,609 B, for 67,078 B in total. The ADR does not say whether yields are in the payload, so a "maximum-size" test either fails or the implementation truncates silently.
- *Required change:* Send only instance summaries in the menu data. Send the selected instance's yield on selection over the new satellite channel, as a bounded S2C message (≤ ~2.3 KiB). Restate the byte budget per section, with the computation.

### Low

- **R2-L1** — ADR-050 §2 "Cost": the fallback of moving the write to a writer thread, with "the epoch would advance on completion", would break the epoch invariant. A mission started after the snapshot but before completion would record `start_epoch = E` yet be missing from the file written as E+1. The follow-up ADR must separate a snapshot epoch (assigned at serialization, used for `start_epoch`) from the durable epoch (advanced on completion).
- **R2-L2** — Liveness after reload.
  - `serialized` is persisted as the value *before* the event, so on disk it is normally `false`. A terminal loaded from disk with receipts, or with a terminal ID not yet "seen", makes no progress until something dirties its chunk: `ChunkMap.save` returns early if the chunk is not unsaved (verified).
  - Consequences: acknowledgements and receipt drops wait, and the first resource start after every restart returns `AWAITING_WORLD_SAVE`.
  - Required: treat receipts and IDs read from chunk storage as serialized/persisted, keeping the stored flag only for carried roots; or have the terminal call `setChanged()` while it holds unserialized state.
- **R2-L3** — ADR-049 §4–§6 introduce `OUTPUT_OCCUPIED`, `INVALID_LAYOUT`, `DEFINITION_UNAVAILABLE`, `NO_ENERGY` and `RESEARCH_LOCKED`. The existing `SatelliteOperationCode` already has `OUTPUT_BLOCKED`, `INVALID_COMPONENTS`, `DEFINITION_NOT_FOUND` and `NO_POWER`. The terminal persists `last_result` as an enum **ordinal** and sends it in menu data. Reuse the existing codes or map them explicitly, and state that new constants are appended only.
- **R2-L4** — The field lists disagree across ADRs:
  - ADR-051 §7 records `receipt_seen` on the quarantine, but ADR-050 §3's quarantine shape is {`reason`, `previous_status`}, and the §7 lifecycle reservation must include the extra field;
  - ADR-049 §7 `link_epoch` has no stated use;
  - `REBIND_CONFLICT` does not say whether the claim side effects (instance DEPLETED, satellite released) apply;
  - "CLAIMED, acknowledged | present" and "CLAIMED, bound elsewhere | present" overlap when both hold. The vectors model only one `CLAIMED_ELSEWHERE` state.
- **R2-L5** — ADR-050 §5: "inspected but not yet eligible goes back … at its next eligible time" has no defined time for CLAIMED resource records that are not yet durably acknowledged. Enqueue them for pruning when the acknowledgement becomes durable, not by time.
- **R2-L6** — ADR-049 §6: replay returns `IDEMPOTENT` only while the satellite is missionless. If a package reappears after a crash and the satellite has since started a mission, the replay gets `IDENTITY_CONFLICT` and the package can never be consumed. Treat any existing satellite with the same identity as idempotent and consume the package.
- **R2-L7** — Decommission: the chip is blanked in the terminal (chunk) and the record is removed only on the next dirty flush. After a crash either the satellite survives with a blank chip (operator `recover-chip` is needed) or a bound chip points at a removed satellite, and the chip is wasted. Give decommission the same barrier or two-phase rule as R2-H1, or document the operator recovery.
- **R2-L8** — ADR-051 §7 "Absent means pruned" and §11:
  - Records are also deleted by `mission purge` (ADR-050 §7). This is harmless, since a drop never pays, but the sentence is inaccurate.
  - While the registry file is replaced by a fresh one (for example an operator removes a corrupt file), terminals drop every receipt. Restoring the real file later rematerializes recent unacknowledged claims. Say that this is outside the guarantee.
  - The residual row's "never duplicated" holds only for process interruption; ADR-038 itself excludes power loss of directory metadata. Qualify it.
- **R2-L9** — ADR-049 §10 applies the 10-tick per-player rate limit to every intent, including the new previous/next selection buttons. Cycling 16 instances then takes up to 8 s. Give selection its own, cheaper limit.
- **R2-L10** — Evidence bookkeeping, remaining from L7:
  - `VERIFICATION.md` is linked from ADR-049..052 revision 2, ADR-048 and the implementation log, but does not exist;
  - the implementation log says the disposition table is in `VERIFICATION.md`; it is actually in `review-01-dispositions.md`;
  - `independent-review-01.zip` is referenced but not committed.
- **R2-L11** — ADR-050 §10 describes the over-cap load only for a "legacy root". State that a root-3 file still above the count limits (a server stopped before retention drained it) also loads, with the same 8,192 load bound. Give the byte-budget arithmetic for the migration's growth (schema-2 fields plus lifecycle reservation) instead of "a v1.5 root is at most 4 MiB".
- **R2-L12** — ADR-049 §7 still says the satellite worst case is "about 1.7 KiB". With the rev-2 kind state (scan parameters, multiplier, receiver link and link epoch, legacy flag) my model gives 1,859 B: within 2 KiB, but with only about 189 B of margin. Update the figure and keep the encode/decode test at the bound.
- **R2-L13** — ADR-050 §8/§9: cancelling or releasing a QUARANTINED `MISSING_SATELLITE` mission must not release a satellite that does not name it. The current `finishMission` throws in that case. State that only a satellite whose `current_mission` is this mission is released.

---

## 3. Reproducibility (review question 3)

- `check_examples.py` (revised) exits 0 with 12 tests.
- My independent Python derivation reproduces every revised vector (48/48):
  - SplitMix64 against the published seed-0 outputs and the other seeds;
  - `bounded`;
  - all four survey vectors, **including `candidate_fingerprint`** (hashed independently from the ADR-052 §4 line format);
  - the mixed-namespace vector, where path-first order gives a different type sequence and fingerprint;
  - asteroid durations, gas, truncation;
  - all 17 slot-based blueprints under the ADR-049 §4 refusal order;
  - totality of the reconciliation table (36 unique pairs).
- The Java cross-check confirms the full-string ordering and SHA-256 fingerprints with `String.compareTo` and `MessageDigest`.
- ADR-052 revision 2 and the checker implement the same algorithm.
- The only deviation I found is semantic: the table's rows compose unsafely across two terminals (R2-H2).

## 4. Per-ADR verdicts

| ADR | Verdict | Required changes |
|---|---|---|
| ADR-048 | **ACCEPT** | None to its text. Fix the evidence links as part of the acceptance packet (R2-L10). Its acceptance remains conditional on ADR-049..052, as it states. |
| ADR-049 | **ACCEPT WITH REQUIRED CHANGES** | R2-H1 (launch durability rule and crash cut), R2-M3, R2-L3, R2-L6, R2-L7, R2-L9, R2-L12 |
| ADR-050 | **ACCEPT WITH REQUIRED CHANGES** | R2-H1 (write-policy exception for launches), R2-M1, R2-M2, R2-L1, R2-L4 (`receipt_seen`), R2-L5, R2-L11, R2-L13 |
| ADR-051 | **ACCEPT WITH REQUIRED CHANGES** | R2-H2 (`paid_terminal` and the rebind rules, plus a composition vector), R2-L2, R2-L4, R2-L8. The round-1 grounds for rejection (H5, H6, H7) are resolved. |
| ADR-052 | **ACCEPT** | None. M12, M13, L3, L6 and L15 are resolved and the vectors reproduce independently. |

The two High items change specific rules: one write-policy exception and one reconciliation field/row. A targeted check of those changed rules and their new vectors is enough; a full third review is not needed.

## 5. Not verified

- **Runtime cost.** Flush timing, MSPT and heap were not measured; nothing is implemented, and Gradle and game runs were not permitted. R2-M1's cost is inferred from `CheckedSavedDataFile` (fsync, read-back, compare) and the 100-tick period.
- **Forge compatibility channel.** Bytecode was checked only on 47.4.10, not 47.4.23.
- **Menu payload sizes.** The R2-M3 figures are my FriendlyByteBuf estimate. The real payload depends on field choices the ADR does not fix.
- **Hash-check coverage.** I re-verified one more upstream file (`EntityStationDeployedRocket.java`), for 17 of 43 in total. `upstream-audit-fetch.json` / `root-checks.zip` and `independent-review-01.zip` are still not in the commit.
- **Third-party mods.** I did not check whether any mod posts `ChunkDataEvent.Save` for purposes other than chunk saving.
