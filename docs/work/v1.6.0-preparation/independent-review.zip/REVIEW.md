# Independent contract review: v1.6.0 ADR-048..052

- **Reviewer role:** independent contract reviewer. I did not write any of the documents under review. I had read-only access to the repository and wrote files only in this Temp directory.
- **Commit reviewed:** `ab207f04d26cccd972d0607088e0b02c2c97c6ee` (`ab207f0`, branch `codex/v1.6.0-satellite-resource-missions`, parent `940a5ed`). I reviewed a pristine `git archive` copy in `./tree`. I did not open the untracked `AdvancedRocketry-Community-v1plus-Development-Docs/` directory.
- **Date:** 2026-09-30
- **Scope:** ADR-048, ADR-049, ADR-050, ADR-051 and ADR-052; `docs/work/v1.6.0-legacy-audit.md`; `docs/work/v1.6.0-preparation/{examples.json,check_examples.py}`; `docs/work/v1.6.0-implementation-log.md`. I checked them against AGENTS.md, the v1.6 version document, docs/17, COMPLETION-PLAN C6–C9, ADR-010/018/021/029/037/039/040/043/044, the current satellite, terminal and persistence code, Minecraft 1.20.1 / Forge 47.4.10 bytecode, and the pinned upstream MIT sources.

## Commands actually run (all in this directory)

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `git -C D:/GitHub/AdvancedRocketry-Community archive ab207f0 \| tar -x -C tree` | 0 | Pristine tree extracted |
| 2 | `git rev-parse HEAD` / `git show --stat ab207f0` | 0 | HEAD = ab207f0; 10 files, docs only |
| 3 | `PYTHONUTF8=1 python -B tree/docs/work/v1.6.0-preparation/check_examples.py` | **0** | 11 tests OK (`checker.log`) |
| 4 | `PYTHONUTF8=1 python -B verify_independent.py` (my own re-derivation from the ADR text; it does not import the checker) | **0** | 28 PASS, 0 FAIL, plus INFO lines (`verify_independent.log`) |
| 5 | `java JavaVectors.java` (JDK 17.0.7; Java `long` and `>>>` semantics) | **0** | SplitMix64 seed 0, `bounded(100)` and all 4 instances of survey vector 1 match; demonstrates an int overflow (`java_vectors.log`) |
| 6 | `PYTHONUTF8=1 python -B nbt_budget.py` (NBT size model of the proposed records) | **0** | Worst-case record sizes (`nbt_budget.log`) |
| 7 | `curl` of 16 upstream files at `c5cd5af…`, then `sha256sum` compared with `legacy-manifest/java-files.csv` | 0 | 16/16 hashes match (`upstream/hashes.txt`) |
| 8 | `jar xf` + `javap -c -p` on `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar` (ServerLevel, ChunkMap, MinecraftServer, ChunkStorage, IOWorker, ChunkSerializer, LevelChunk, ResourceLocation) | 0 | Save-ordering facts in §Q1 (`mc/*.txt`) |

I ran no Gradle, game or server command, as the review permissions required.

## Summary

| Severity | Count |
|---|---|
| Critical | 0 |
| High | 7 |
| Medium | 16 |
| Low | 16 |

I found no stable, crash-free item duplication path, so there is no Critical finding. The High findings are:

- the delivery protocol's exactly-once claim fails in three concrete, crash- or operator-dependent scenarios (H5, H6, H7);
- three persistence problems that can block or silently stop the registry: stale scheduler entries (H2), under-sized record bounds (H3) and a migration of over-cap legacy data that blocks startup (H4);
- an unspecified synchronous write-through policy that conflicts with the performance budgets (H1).

---

## Findings

### Critical

None.

### High

**H1 — Registry write policy is unspecified. The current code rewrites the whole registry synchronously after every operation. ADR-051's save-ordering premise is false for this registry.**
- *Location:* ADR-050 §4 and §6; ADR-051 Context and §6. Code: `SatelliteManager.java` calls `data.flush(server)` after the scheduler pass whenever `completed > 0` (l.84), and after launch (l.125), start (l.164), cancel (l.331/354), claim (l.487) and discovery replay (l.455). `AtomicSavedData.flush` calls `CheckedSavedDataFile.replace`, which serializes the whole payload, gzips it, calls `FileChannel.force(true)`, reads the file back, fully decodes it, compares it with `equals`, and then does an atomic move, all on the main thread.
- *Problem:* ADR-051 says "SavedData is written only at autosave". For `SatelliteMissionSavedData` this is not true: every mutation is a synchronous, fsynced full rewrite. ADR-050 raises the root from 4 MiB to 16 MiB and adds many new mutating paths: reconciliation, acknowledgements, pruning of up to 64 records per pass, expiry of up to 16 instances per pass, survey scan payments and solar link changes. The contracts never state whether these paths flush. The version document §13 requires "SavedData dirty 合并而非每条任务每 tick 写". docs/17 §4 sets MSPT budgets (P95 ≤ 50 ms, P99 ≤ 100 ms).
- *Failure scenario:* With a multi-MiB root, each flush costs serialization, gzip, fsync, read-back and a deep compare. During a 1,024-mission backlog the scheduler flushes on every pass for 32 passes. While more than 1,536 finished records exist, pruning changes state every 20 ticks. Each start, claim or cancel click (up to one per player per 10 ticks) triggers another full rewrite. The C9 500/1,000-mission test would measure this cost, not the design.
- *Required change:* ADR-050 must state the write policy. Recommended: a mutation only sets the dirty flag; persistence happens at autosave and shutdown; an explicit barrier flush is allowed only where a protocol needs one, with a rate bound. The ADR-051 epoch rule already makes an immediate flush unnecessary for claims. Rewrite the ADR-051 context to match (see M16). State how long `AWAITING_WORLD_SAVE` can last under the chosen policy (up to one 6,000-tick autosave). C9 must record flush time at the 16 MiB bound and at the 500/1,000 loads.

**H2 — Stale scheduler entries can make every mission start on the server throw, and leave ACTIVE missions that are never scheduled.**
- *Location:* ADR-050 §4 ("≤ 32 completions, ≤ 64 queue inspections (unchanged)"), §5 and §7. Code: `MissionDeadlineScheduler.schedule` throws when `queue.size() >= 1,024` (l.37–38). `SatelliteMissionRegistry.cancel` (l.342–370) never removes the queue entry. `startMission` mutates `satellites` and `missions` (l.235–236) before calling `scheduler.schedule` (l.237).
- *Problem:* The queue size counts stale entries: cancelled missions stay queued until their deadline is due and they reach the head. v1.6 missions last up to 72,000 ticks and can be cancelled, so stale entries can accumulate. The per-owner limit of 64 unfinished missions does not bound churn.
- *Failure scenario:* One player alternates start and cancel on long gas or survey missions at the allowed rate of one intent per 10 ticks. That creates one stale entry per 20 ticks, so 1,024 entries exist after about 20,500 ticks. From then on every start on the server throws `IllegalStateException` after the maps were mutated. The satellite stays bound to an ACTIVE mission that is not in the queue. ADR-050 §3 says only the scheduler moves ACTIVE to READY, so that mission never completes until a restart rebuilds the queue. Stale entries at the head also use up the 64 inspections, so the claim "1,024 due complete in exactly 32 passes" no longer holds.
- *Required change:* Remove the queue entry on cancel, quarantine or reconcile (a `remove(Object)` over at most 1,024 entries is bounded), or compact the queue and bound it by the unfinished count. Check capacity before any mutation and make a failed schedule atomic. Apply the same rule to the instance-expiry queue. Add an A0 churn test: start/cancel with long deadlines, beyond 1,024 cycles.

**H3 — Per-record size bounds do not match the field bounds. An oversize record stops all registry saves.**
- *Location:* ADR-049 §7 (satellite ≤ 1 KiB), ADR-050 §2 (mission ≤ 2 KiB) and §6 (section budgets), ADR-051 §2 (instance ≤ 1 KiB). Code: `SatelliteNbtCodec.requireBound` checks the record bound on both encode and decode (l.110–114). `SatelliteMissionSavedData.save` throws on overflow. `AtomicSavedData.save` logs once and keeps the dirty state.
- *Problem:* My NBT model (`nbt_budget.log`) gives these sizes:

  | Record | 17 entries, ~30-char IDs | Worst case (128-char IDs) | ADR bound |
  |---|---|---|---|
  | Asteroid instance | 1,260 B | 3,122 B | 1,024 B |
  | Resource mission | 1,761 B | 3,721 B | 2,048 B |
  | Satellite (8 components) | — | 1,720 B | 1,024 B |

  The ADRs allow both 16 ores plus a base item per type and item IDs of up to 128 characters. The section arithmetic (13 MiB) and the 16 MiB root are derived from bounds that valid data can exceed.
- *Failure scenario:* A data pack adds an asteroid type with 16 ores. A survey then creates an instance record larger than 1 KiB. If the record bound is enforced at encode, as the current codec does, every later registry save throws. Persistence stops silently after one log line. The save epoch never advances, so every resource claim returns `AWAITING_WORLD_SAVE`, and all progress is lost at the next restart. If the bound is enforced only at decode, the next load blocks the registry instead.
- *Required change:* Derive every record bound from the field maxima, or tighten the fields (for example, store yield items as indices into a snapshot palette). Reject types and tables at load whose worst-case record does not fit. Enforce the bound at mutation time (`STORAGE_BUDGET`) and never only at encode. Recompute the §6 section table. Add worst-case encode/decode tests.

**H4 — No migration rule for legacy registries that exceed the new caps. The pre-start migration would block server startup.**
- *Location:* ADR-050 §5 (3,072 missions of every status replace 8,192; 64 unfinished per owner; 256 satellites per owner) and §9. Code: `WorldDataMigrationService.discoverSources` → `ManagedSavedDataPayloadValidator` loads every managed file with the new decoder and throws `INVALID_SCHEMA`. `BetaWorldMigrationEvents` rethrows it, which blocks startup. The current load rejects `missions.size() > MAX_MISSIONS`.
- *Problem:* v1.5 keeps up to 8,192 missions and never prunes them; the audit itself says so. ADR-050 does not say what happens when a legacy root holds more than 3,072 missions, or an owner holds more than 256 satellites or more than 64 unfinished missions.
- *Failure scenario:* A long-running v1.5 server with 4,000 historical data missions is upgraded. Semantic validation fails and the whole world refuses to start ("迁移后关键状态错误").
- *Required change:* State that per-owner limits apply only at admission. Either keep the load bound at 8,192 or more for migrated data and let retention drain the excess, or prune eligible finished records during migration after the backup and record the pruned IDs in the migration report. Add an S1 fixture with a v1.5 root at 8,192 missions and an owner with 300 satellites.

**H5 — Receipts are dropped only when records are pruned, so a terminal permanently refuses claims after 256 resource claims on typical servers.**
- *Location:* ADR-051 §5 (receipts ≤ 256) and §6 (table row "CLAIMED, acknowledged → Nothing (a present receipt is kept until the record is pruned)"); ADR-050 §6 (pruning runs only "while more than 1,536 finished records exist"; "retention can never block [claims]").
- *Problem:* On a server with no more than 1,536 finished records, nothing is ever pruned, so receipts are never dropped. When a terminal holds 256 receipts, claims fail with `TERMINAL_RECEIPTS_FULL`. READY missions bound to that terminal cannot be claimed there. Rebind is limited to missing terminals, so the only remaining action is to cancel, which pays nothing.
- *Failure scenario:* A single player runs 64 gas harvesters that claim at one terminal. After four rounds the terminal is full, and every READY mission bound to it is stuck.
- *Required change:* Drop a receipt once its acknowledgement is durable, that is, once `acknowledged = true` has been written by a completed registry save (for example, store `ack_epoch` and drop when `ack_epoch < current save_epoch`). From then on, no restart can revert the registry to ACTIVE or READY for that mission. Make this independent of pruning. Add a test with more than 256 claims at one terminal while fewer than 1,536 records are finished.

**H6 — The reconciliation table is not total, and treats "absent" as "pruned". A blocked registry makes terminals drop every receipt, which later duplicates rewards.**
- *Location:* ADR-051 §6 (reconciliation table); `check_examples.py` `reconcile()` raises `ValueError` for any other state. Code: `SatelliteMissionSavedData.mission()` returns `Optional.empty()` when the registry is not operational (l.204–206).
- *Problem:* The table has rows only for ACTIVE, READY, CLAIMED, CLAIMED+ack and "record pruned". It has no row for:
  - CANCELLED plus a receipt (see H7);
  - QUARANTINED plus a receipt;
  - a mission rebound to another terminal (ADR-051 §8);
  - "registry unavailable" (blocked by a future or invalid schema).

  An implementation built on the current API will see "absent" for every mission while the registry is blocked.
- *Failure scenario:* After an upgrade problem the registry is blocked. Terminals keep ticking and reconcile against it, so every receipt matches the "record pruned → drop receipt" row. The operator fixes the file and restarts. Every CLAIMED, unacknowledged mission now matches "absent → add the reward and receipt again". Players who already withdrew those items receive them a second time.
- *Required change:** Add explicit rows:
  - registry not operational → no action;
  - CANCELLED or QUARANTINED + receipt → keep the receipt, log, add no items;
  - rebound to another terminal → keep the receipt.

  Define "pruned" positively: the registry is operational and the record is below a persisted prune watermark or in a tombstone set. Make the reference function total over every registry status × receipt state, and add vectors for the new rows.

**H7 — Cancellation paths bypass reconciliation, so an asteroid instance can be mined twice.**
- *Location:* ADR-050 §3 (cancel by "owner at a terminal, or operator"; QUARANTINED → CANCELLED), §7 ("Owners cancel ACTIVE or READY missions at **any** terminal with the matching chip; operators can cancel by ID") and §8 (`mission cancel <id>`); ADR-051 §6 ("Owners can cancel a resource mission only at its bound terminal (after reconciliation), and operators by ID. So a mission that paid through a receipt cannot also be cancelled").
- *Problem:* The conclusion in ADR-051 depends on every cancel being preceded by reconciliation. Operator cancel, QUARANTINED → CANCELLED, and ADR-050 §7's any-terminal owner cancel are not preceded by it. ADR-050 and ADR-051 also contradict each other on where owners may cancel.
- *Failure scenario:*
  1. The claim is paid: the terminal chunk holds the receipt and items.
  2. The registry reverts to READY (crash-cut row 2, or a failed claim flush).
  3. The bound terminal's chunk stays unloaded.
  4. The owner, or an operator, cancels the READY mission, so the instance returns to AVAILABLE.
  5. The owner starts a new asteroid mission on the same instance and claims it: a second reward.
  6. When the old terminal loads, it hits the missing CANCELLED + receipt row.
- *Required change:* For `asteroid`/`gas` missions, every cancel (owner, operator or quarantine release/cancel) must either require the bound terminal to be loaded and freshly reconciled, or must not return the instance to AVAILABLE (move it to EXPIRED or QUARANTINED instead). Align ADR-050 §7 with ADR-051. Add this cut to the S2 fault injection list.

### Medium

**M1 — `serialized` can be set by `saveAdditional` calls that are not chunk saves.** *Location:* ADR-051 §6 ("marked `serialized` once the terminal's `saveAdditional` has written it").
- *Problem:* `saveAdditional` is not specific to chunk saves. The terminal's own `carriedData()` calls it (l.562–566). So do `/data get block`, `/clone`, structure capture, and mods that call `saveWithFullMetadata` or `serializeNBT`.
- *Scenario:* An operator runs `/data get block` on the terminal right after a claim. The receipt is marked serialized, the next reconciliation acknowledges it, and a write-through flush (H1) makes the acknowledgement durable. The server crashes before the chunk's first real save. After restart the state is "acknowledged, no receipt → Nothing", so the reward is lost. This loss is outside the documented residual.
- *Required change:* Set `serialized` only from the chunk-save path: `ChunkDataEvent.Save` is posted in `ChunkMap.save` right after `ChunkSerializer.write` (verified). Verify that the terminal's tag in that chunk data contains the receipt. Name the asynchronous IOWorker write explicitly in the residual.

**M2 — Terminal identity is not durable before missions bind to it.** *Location:* ADR-051 §5 (`terminal_id` created "when the block entity is first placed or loaded"; schema-1 roots "load with a new `terminal_id`") and §8.
- *Scenario:* A schema-1 terminal is loaded after the upgrade and receives UUID X. A resource mission binds to X, and the registry is flushed immediately. The server crashes before the terminal's chunk is saved. On restart the terminal loads its schema-1 root again and receives UUID Y. The mission is orphaned (`TERMINAL_MISSING`) and needs an operator rebind. A newly placed terminal has the same problem.
- *Required change:* Refuse to bind until the terminal's `terminal_id` has been chunk-serialized (the same mechanism as M1), or derive IDs for migrated roots deterministically. Document the recovery path.

**M3 — The rebind residual relies on an "audit trail" that nothing writes.** *Location:* ADR-051 §8 ("operators check the audit trail first").
- *Problem:* Only operator commands write audit lines. Claims, rematerializations, acknowledgements and receipt drops are never logged, so an operator cannot tell whether the lost terminal had already paid.
- *Required change:* Write one bounded log line per claim, rematerialization, acknowledgement and receipt drop, containing the mission ID, terminal ID, epoch and reward hash. Have `mission inspect` show the bound terminal and the last reconcile result.

**M4 — ADR-049 and ADR-050 contradict each other on unknown kinds.**
- *Problem:* ADR-049 §1 says unknown kind strings are "record quarantined". ADR-050 §8 says an unknown kind "blocks the registry". The difference is between one quarantined record and every satellite on the server being unavailable.
- *Required change:* Choose one behaviour and write it in both ADRs.

**M5 — Quarantine and recovery semantics are ambiguous and can deadlock.** *Location:* ADR-050 §3, §7 and §8.
- *Problems:*
  - (a) "A satellite named by no mission becomes RECOVERY_REQUIRED" literally matches every idle satellite.
  - (b) No command recovers a satellite. `SatelliteState.recover()` has no production caller.
  - (c) It is unspecified whether QUARANTINED counts as unfinished (for the caps and for invariant 2).
  - (d) `requireRecovery()` clears `current_mission`. After that, releasing the quarantined mission can never satisfy invariant 1, so the two wait on each other forever.
  - (e) The current `finishRestore` requires every mission, finished or not, to reference an existing satellite (l.97–101). ADR-049 §7 decommission and ADR-050 pruning will create exactly such dangling references, and ADR-051 instances will keep `source_mission` pointing at pruned records.
- *Required change:* Word the invariants precisely. Add `satellite recover <id>`. Define how QUARANTINED is counted. State that finished records and instances may reference decommissioned satellites or pruned missions.

**M6 — A record that grows in place can exceed an exact-size budget.** *Location:* ADR-050 §6.
- *Problem:* Admission checks the exact current size. Claims, acknowledgements and load-time quarantine then add fields to existing records. A claim can therefore be refused with `STORAGE_BUDGET`, which contradicts "retention can never block [claims]", and a load-time quarantine can overflow the budget.
- *Required change:* At admission, reserve the worst-case size of the record over its whole lifecycle.

**M7 — Retention age limits throughput, and there is no per-owner cap on retained records.** *Location:* ADR-050 §5 and §6.
- *Problem:* With a 24,000-tick minimum age and a 3,072-record total, sustained completion throughput is at most (3,072 − unfinished) / 24,000 per tick. With 1,024 missions unfinished that is about 0.085 per tick (about 1.7 per second).
- *Scenarios:*
  - The C9 500/1,000-mission load with short missions reaches `CAPACITY_REACHED` for everyone within minutes.
  - Start/cancel churn needs no successful mission: about three players, or alt accounts, can keep the global 3,072 cap full, because only unfinished missions are limited per owner.
- *Required change:* Add a per-owner cap on retained records. Prune finished data, survey and cancelled records by count, with a short age limit. Include the throughput analysis in the C9 plan.

**M8 — The pruning and expiry passes have no inspection bound, and some records can never be pruned.** *Location:* ADR-050 §4 and §6; ADR-051 §2.
- *Problem:* "Oldest eligible by `resolved_at`" has no inspection limit when the oldest records are ineligible (unacknowledged or QUARANTINED). A resource record whose terminal is never loaded again, for example one carried away as an item and never placed, is never acknowledged and so never pruned. That can end in a permanent `CAPACITY_REACHED`.
- *Required change:* Keep eligibility-ordered queues with a fixed inspection budget per pass. Add a diagnostic and a bounded operator purge. State whether the more-than-1,536 condition also applies to instance pruning.

**M9 — The terminal menu contradicts "format unchanged", and network protocol versions are unspecified.**
- *Problems:*
  - ADR-049 §3 says "ADR-029's limit and menu format are unchanged".
  - Yet §6 and §10 need the terminal to launch non-`data` kinds into a chosen `orbit_body`, list up to 32 definitions, and carry index choices for asteroid instances and gas products, withdraw and decommission.
  - A survey scan result is a new S2C packet (≤ 8 KiB).
  - The ADRs name neither the channel nor the protocol or menu `FORMAT_VERSION` bumps. Current terminal menu data is `FORMAT_MARKER -1 / FORMAT_VERSION 1` (`SatelliteTerminalTargets`). The four existing channels were pinned in the v1.5 C1 review.
- *Required change:* List every new or changed packet and menu payload, with its channel, version bump, byte bound, and rejection of mixed-version clients. Correct ADR-049 §3.

**M10 — Kind parameters are not in the satellite snapshot.**
- *Problem:* ADR-049 §7 snapshots only the component IDs and the five stats. Survey scans need `scan_energy`, `scan_radius_blocks` and `scan_cell_blocks`, and solar output needs `output_multiplier_percent`, all read from the definition. ADR-050 §10 nevertheless claims that removing a definition affects only new starts.
- *Required change:* Snapshot the kind parameters into the kind state at launch, or specify what happens when the definition is gone.

**M11 — Solar receiver link semantics.** *Location:* ADR-049 §9.
- *Problems:*
  - "The most recent assertion by the receiver actually holding the chip wins" ping-pongs every 20 ticks when duplicate chips exist. The existing `/arce satellite admin recover-chip` creates duplicates. Every flip is a SavedData write, and a flush under H1.
  - Both receivers can produce energy for up to 20 ticks per flip.
  - A link to a destroyed receiver is never cleared, and decommission requires "no receiver link", so that satellite can never be decommissioned.
  - The receiver block entity root has no schema version, preflight or carry rule, which AGENTS §3.3 requires.
- *Required change:* Keep the first valid holder as the link owner until it is verified not to hold the chip. Unlink when the receiver is removed. Allow unlinking when the receiver is missing. Specify the receiver root.

**M12 — The survey-v1 candidate ordering is easy to implement differently, and the vectors cannot detect it.** *Location:* ADR-052 §4.
- *Problem:* The ADR says candidates are "sorted by ID string (ascending, ordinal)". In 1.20.1, `ResourceLocation.compareTo` compares the path first and then the namespace (verified in bytecode). Every vector uses the single namespace `example:`, so an implementation using natural `ResourceLocation` order passes all of them. My mixed-namespace demonstration (`verify_independent.log`) gives a different type sequence: `zeta:alpha ×4` versus `zeta:alpha, zeta:alpha, alpha:zeta, alpha:zeta`.
- *Required change:* Specify "`toString()` compared with `String.compareTo`". Add a mixed-namespace vector in which path order and full-string order disagree.

**M13 — `mission verify` cannot audit survey type selection.** *Location:* ADR-052 §4 and §7.
- *Problem:* Type selection depends on the whole candidate set: membership, order and weights. Instances store only the chosen type's `table_version`, and `reward_version` is just `survey-v1`.
- *Scenario:* Adding, removing or reweighting any other type makes verification report `MISMATCH` (called a defect) or a false `MATCH`, instead of `VERSION_CHANGED`.
- *Required change:* Persist a fingerprint of the candidate set (a hash over the sorted IDs and their versions) with the survey mission or its instances.

**M14 — Coverage gaps against the version document.**
- *Problems:*
  - Star-map integration (§6 step 8; §11 "星图任务目标与实际天体一致") is in no contract.
  - §10 "玩家离线数小时后受限补算" and "两个玩家同 tick 结算" appear in no verification list.
  - The logical design makes §10 "任务实例区块卸载/回收" and §11 "小行星实例…视觉" not applicable, but neither has a recorded disposition or replacement test.
  - docs/17 §5 requires *configurable* hard limits, while the contracts fix constants.
- *Required change:* Add a coverage table that maps each item in version-document §8–§14 to a contract section and test level, or to an ADR-recorded disposition. Either make the limits configurable up to fixed maxima, or record the deviation.

**M15 — The C7/C8 split does not match the root-3 migration.** *Location:* implementation log; ADR-050 §9.
- *Problem:* C7 implements "registry root 3 (ADR-050 §9)", but mission schema 2, instances, `save_epoch` and counters are C8 content. Unless C7 freezes the full set of root-3 record shapes, C8 must either change root 3 silently (ADR-048 forbids silent schema changes) or add root 4. Root 4 means another migration and backup, and `WorldDataMigrationService.MAX_BACKUPS = 5` can block startup. C8 also bundles six slices.
- *Required change:* Freeze all root-3 shapes in C7, keeping unused sections empty but decodable, or plan root 4 explicitly. Split C8.

**M16 — The ADR-051 crash-cut model misses common save orders.** *Location:* ADR-051 Context, crash-cut table and S1/S2 list.
- *Problem:* In 1.20.1, `ChunkMap.processUnloads` saves up to 20 dirty chunks every tick (`saveChunkIfNeeded`, 10-second cooldown). Autosave skips chunks saved within the last 10 s, and chunk writes are asynchronous through IOWorker. The terminal chunk is therefore normally saved within seconds of a claim, not only "when it unloads". Row 2 ("chunk written (unload) before autosave") is the ordinary case, and the S2 cut "after a chunk unload before autosave" does not exercise it.
- *Required change:* Correct the context and add S2 cuts after an incremental chunk save and after an explicit registry flush.

### Low

- **L1** — ADR-050 §1: "An operator's forward time jump advances it" is incorrect. `/time set|add` changes day time; game time only advances per tick. Rewrite it, or name the actual mechanism (a level.dat edit or a mod).
- **L2** — ADR-050 §3: "Only the scheduler moves ACTIVE to READY" contradicts the existing lazy completion at claim time (`SatelliteMissionRegistry.claim` l.277–281, `data`, "ADR-010/037 unchanged"). It also contradicts reconciliation row 1 (ACTIVE → CLAIMED). List both transitions explicitly.
- **L3** — ADR-052 §5 does not state that 64-bit arithmetic is required. The asteroid-duration numerator overflows Java `int` once tm × cfg exceeds 17,895; my Java check gives `int = −259,084,288` for 1000/1000. The vector catches this, but the text should say `long`. The same applies to the survey charge `power × Δticks` (use `long` and saturate).
- **L4** — ADR-049 §3–§6 leave several points open:
  - whether the builder can assemble `data`;
  - whether schema-2 `data` definitions may have a `primary_component`;
  - the refusal codes `INVALID_LAYOUT` and `REQUIREMENT_UNMET`, which the checker uses but the ADR does not define, and the precedence among refusal codes;
  - re-validation of caps and requirements at launch after a catalog change;
  - the result of replaying an idempotent idle launch (the current code returns `IDENTITY_CONFLICT` when there is no mission);
  - which package item non-`data` kinds use (the existing item is `data_satellite_package`);
  - the builder's energy storage.
- **L5** — ADR-049 §8 scan specification is incomplete:
  - the Y range scanned;
  - whether the cell value is an "ore count ratio" or a count, given the 0..65,535 range;
  - whether 2 × radius must be divisible by the cell size;
  - whether a survey satellite can scan while on a mission.
- **L6** — Legacy numbers:
  - ADR-052 §8 and the audit give "variability 50" for all four types, but upstream Iridium-enriched has `richnessVariability=0.3` (upstream l.1159; `examples.json` correctly uses 30).
  - The audit's "duration formula kept" hides a rebalance: upstream "30 minutes with one drill" (36,000 ticks) becomes 12,000.
  - The audit omits ore mapping's basic scan cost (250 × zoom).
  - The legacy chip-copy slot is dropped without a note.
  - Payload-based schema-1 data satellites are given a fabricated blueprint (a data-storage unit that was never consumed).
- **L7** — Evidence and bookkeeping:
  - ADR-048 and the implementation log link `v1.6.0-preparation/VERIFICATION.md`, which does not exist.
  - The audit cites `root-checks.zip` / `upstream-audit-fetch.json`, which are not committed. I re-verified 16 of the 43 files myself.
  - `CURRENT_VERSION.md` still names v1.5, and COMPLETION-PLAN still shows C6 as `[ ]`.
  - `PORTING_MATRIX.md` has no rows for the rocket satellite bay, physical asteroids/Observatory, biome changer, spy telescope, microwave receiver, or asteroid/gas missions, although the ADRs say these are deferred "to the v1.8 porting matrix".
- **L8** — Save-epoch reload semantics are unstated. If the epoch loads as the on-disk value, missions started in the last saved interval need one more save before they can be claimed. State whether load sets the epoch to disk + 1.
- **L9** — Index intents for asteroid instances and gas products must carry or check a snapshot generation. Expiry or new survey claims can shift the list between the snapshot and the click.
- **L10** — Gas rewards: filled hydrogen canisters (stack size 16) come from nothing, and rocket fuel returns empty canisters (ADR-027 remainder), so gas missions mint canister materials. "Cargo × 64" is a logical unit for items that stack to 16. Withdraw behaviour with a full player inventory is unspecified. The new bottom-face buffer handler changes the terminal's existing all-sides `ITEM_HANDLER` exposure.
- **L11** — Reconciliation mechanics are unspecified: the per-terminal index of bound missions; reconciliation over more than 64 missions across several ticks, which must block actions until it finishes; and how a missing terminal is detected.
- **L12** — AGENTS §3.4 size rules: `SatelliteTerminalBlockEntity` (657 lines), `SatelliteManager` (544) and `SatelliteMissionRegistry` (463) will exceed 800 lines once delivery, instances and budgets are added. Plan the class splits.
- **L13** — Downgrade: a v1.5 host blocks the whole world's startup (pre-start `FUTURE_SCHEMA`), not just the registry. Builder and receiver blocks, including any bound chips inside them, become air on v1.5. State both.
- **L14** — ADR-050 §10 does not cover a celestial body being removed or re-parented: an `orbit_body` that has disappeared, or a system that has changed, for surveys, scans, solar output and asteroid-start checks.
- **L15** — ADR-052 §7 verify: asteroid mission verification after the instance has been pruned (DEPLETED records are removed after 24,000 ticks) needs an outcome such as `INPUTS_UNAVAILABLE`.
- **L16** — Checker coverage: `blueprint()` has no vectors for a missing or duplicate chassis, or a primary in a module slot, and `reconcile()` is partial (H6).

---

## Answers to the review questions

**Q1 — State machines, exactly-once and save ordering.**

*Sound parts:*
- One registry mutation for every satellite↔mission↔instance transition.
- A claim that is never ACTIVE → CLAIMED without a receipt.
- Rematerialization from the stored snapshot.
- The epoch rule. It is correct for its purpose: after a crash, the registry always still contains the mission, so a receipt cannot refer to a mission that never persisted.

*Defects:* H5, H6, H7, M1, M2 and M16.

*Verified in bytecode (Forge 47.4.10 mapped jar):*
- `MinecraftServer` autosaves every 6,000 ticks. `saveEverything` saves players first, then `saveAllChunks` over `getAllLevels()`.
- `ServerLevel.save` calls `saveLevelData()` (`DimensionDataStorage.save`) before `ServerChunkCache.save`. So within one autosave the Overworld data storage is saved before that level's chunks, and levels are saved in order.
- `ChunkMap.processUnloads` saves up to 20 chunks per tick (`bipush 20`, `saveChunkIfNeeded`, 10,000 ms cooldown).
- `ChunkMap.save` runs `ChunkSerializer.write` on the main thread. That reaches `LevelChunk.getBlockEntityNbtForSaving` → `BlockEntity.saveWithFullMetadata` → `saveAdditional`. It then posts `ChunkDataEvent.Save` and calls `ChunkStorage.write` → `IOWorker.store` (asynchronous; the future is ignored).
- The non-flush autosave path does not call `flushWorker`; only the shutdown (`flush=true`) path does.
- `AtomicSavedData` overrides `save(File)` and the registry is flushed explicitly after operations. This contradicts the ADR-051 context (H1, M16).

**Q2 — Consistency.**
- Consistent: the scheduler numbers (32 completions and 64 inspections match `SatelliteLimits`), 1,024 unfinished, 4,096 satellites, the ADR-029 preflight (64 KiB, depth 20, 2,048 nodes), `Size=6`, and the terminal-root additions fitting in 64 KiB (receipts about 5–9 KiB, buffer about 4.8 KiB).
- The audit's claims about the permanent 8,192 lock and the 4 MiB save-time throw are correct. Nuance: the load path also checks the 4 MiB bound and blocks. At save time the exception is swallowed by `AtomicSavedData`, so persistence silently stops.
- Inconsistent: M4, M9, H7, L2, H3 (record bounds), and L6 (legacy variability).

**Q3 — Budgets and performance.** The §6 arithmetic is internally correct (4 + 6 + 2 + 1 = 13 MiB), but it rests on record bounds that valid data can exceed (H3). Other problems: flush cost (H1), stale queue entries (H2), pruning and expiry inspection bounds (M8), and retention throughput (M7). The survey scan is bounded: at most 576 cells, 16,384 reads per tick per job, 4 jobs, `getChunkNow` only. A full-height scan at radius 48 is about 3.5 M block reads, roughly 216 ticks per job.

**Q4 — Security and authority.**
- Good: C2S intents carry no stats, seeds, positions or rewards; the scan centre comes from the server; seeds come from `SecureRandom`; there are zero chunk tickets; instances have no coordinates; forged NBT is limited to what creative already allows (owner mismatch is still refused).
- Remaining items: H7 (operator cancel), M9 (protocol versions) and L9 (stale indices).
- `/arce satellite admin recover-chip` creates duplicate chips, which M11 must handle.

**Q5 — Scope.** No v1.7 content is present; the logical `asteroid_miner` is not the v1.7 orbital laser drill. The deferrals are adequately justified: the version document itself allows "逻辑任务方案", and ADR-010 anticipated terminal-only launch. The biome changer rejection is consistent with the matrix row "地球化 DEFERRED". The deferrals are not registered in the porting matrix (L7). The coverage gaps are in M14.

**Q6 — Migration.** The forward path follows ADR-040 (validate, one backup, stage, atomic replace). Problems: over-cap legacy data (H4), the C7/C8 schema split (M15), and the backup limit (M15). Item schema 2 and terminal root 2 are fail-closed on v1.5 (FUTURE → blocked and preserved), which is correct. Downgrade notes are in L13.

**Q7 — Reproducibility.**
- The checker passes (exit 0).
- My independent Python re-derivation and my Java cross-check agree with every vector:
  - SplitMix64 seed 0 gives `e220a8397b1dcdaf 6e789e6aa1b965f4 06c45d188009454f`, matching the published reference;
  - the domain constants equal their ASCII names;
  - `bounded` matches;
  - all three survey vectors match;
  - the hand values match: 12,000 ticks and 25,715 ticks (1.8e9 / 70,000 rounded up), gas 576/64/72/64/192, and blueprint sums 4/720/1,000 and 40/10,720/1,000.
- The ADR-052 text and the checker implement the same algorithm: domain constants, draw order (dm, then dr, then the ores), clamping, `(next>>>1)%n`, first cumulative weight greater than r, yield order, truncation, and the duration and gas formulas.
- Remaining gaps: the ordering trap (M12), the unstated overflow (L3), and partial checker coverage (L16).

**Q8 — Implementability of C7–C9.** They are implementable once the required changes are made. Specific concerns: the root-3 split (M15); C8 is too large and should be split; the operator commands of ADR-050 §8 and ADR-052 §7 are not assigned to a chunk; the class-size splits (L12).

---

## Per-ADR verdicts

| ADR | Verdict | Required changes |
|---|---|---|
| **ADR-048** baseline exception | **ACCEPT WITH REQUIRED CHANGES** | Link only evidence that exists, or mark the link pending; record the rejected and deferred items in `PORTING_MATRIX.md` with target versions (L7). Acceptance stays conditional on ADR-049..052 being ACCEPTED, as the ADR already states. |
| **ADR-049** blueprints and assembly | **ACCEPT WITH REQUIRED CHANGES** | H3 (satellite record bound), M4, M9, M10, M11, M14 (star map and configurable-limit parts), L4, L5, L6. |
| **ADR-050** scheduler and recovery | **ACCEPT WITH REQUIRED CHANGES** | H1, H2, H3, H4, H7 (§7 cancel rule), M5, M6, M7, M8, M15, L1, L2, L14. The High items change normative text, so the revised sections need a second independent review before this ADR becomes ACCEPTED. |
| **ADR-051** instances and delivery | **REJECT (revise and resubmit)** | Its central exactly-once guarantee does not hold as written: H5, H6 and H7, plus M1, M2, M3, M16 and H3 (instance bound). The architecture (bound terminal, receipts, save epoch) is viable. The reconciliation table, the receipt-retention rule, the cancellation rule and the crash-cut model must be rewritten and re-reviewed. L8–L11 should be addressed at the same time. |
| **ADR-052** tables and seeds | **ACCEPT WITH REQUIRED CHANGES** | M12 (ordering specification plus a mixed-namespace vector), M13 (candidate-set fingerprint), L3 (64-bit arithmetic), L6 (Iridium variability 30), L15, and a check at table load that a type's worst-case records fit their bounds (from H3). |

## Not verified

- **Runtime behaviour and cost.** Nothing proposed is implemented. I did not measure flush or save time at 16 MiB, MSPT, or heap use, and ran no Gradle, GameTest or dedicated server, as the permissions required.
- **Forge compatibility channel.** I checked bytecode only for Forge **47.4.10**, not the 47.4.23 compatibility channel. Vanilla `ChunkMap.scheduleUnload` save-on-unload is from memory and a partial disassembly; I did not trace it fully.
- **Callers of `saveAdditional`.** I did not audit every vanilla or third-party path that calls `saveAdditional` or `saveWithFullMetadata`. I verified the terminal's own `carriedData()`, and that the terminal does not override `getUpdateTag`.
- **Menu extra-data limit.** I did not check the 32,600-byte limit in `NetworkHooks` bytecode; I relied on ADR-029.
- **Upstream audit coverage.**
  - I hash-checked 16 of the 43 audited files; all match.
  - I did not locate the legacy gas-mission duration formula ("2 × liquidCapacity / intakePower, 360 if no intake"), because its call site is not in the files I fetched.
  - I checked the ore-mapping worker-thread claim only through its `Thread.interrupted()` checks.
- **Durability.** Directory-entry durability of the atomic rename after power loss, and IOWorker completion latency, are reasoning only.
- **Canister fuel remainder (L10).** Taken from the ADR-027 text, not traced in code.
- **Missing evidence.** The audit's `root-checks.zip` and the preparation `VERIFICATION.md` are not in the commit, so I could not check the claimed 43/43 hash record itself.
