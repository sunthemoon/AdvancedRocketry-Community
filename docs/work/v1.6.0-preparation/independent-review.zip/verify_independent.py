"""Independent re-derivation of ADR-052/049 arithmetic from the ADR text (reviewer-written).

Does not import check_examples.py. Reads examples.json only to compare outputs.
"""
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).parent / "tree" / "docs" / "work" / "v1.6.0-preparation"
EX = json.loads((ROOT / "examples.json").read_text(encoding="utf-8"))
M64 = 0xFFFFFFFFFFFFFFFF
failures = []


def check(name, got, want):
    ok = got == want
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"\n  got  {got}\n  want {want}"))
    if not ok:
        failures.append(name)


def ascii_const(text):
    assert len(text) == 8
    return int.from_bytes(text.encode("ascii"), "big")


def splitmix(seed):
    state = seed & M64
    while True:
        state = (state + 0x9E3779B97F4A7C15) & M64
        z = state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        yield z ^ (z >> 31)


def below(gen, n):
    # ADR-052: (next() >>> 1) % n
    return (next(gen) >> 1) % n


# 1. Domain constants from their ASCII names
check("SURVEY01 constant", ascii_const("SURVEY01"), 0x5355525645593031)
check("ASTTYPE1 constant", ascii_const("ASTTYPE1"), 0x4153545459504531)
check("ASTYIELD constant", ascii_const("ASTYIELD"), 0x4153545949454C44)

# 2. SplitMix64 seed 0 against the widely published reference outputs
PUBLISHED_SEED0 = [0xE220A8397B1DCDAF, 0x6E789E6AA1B965F4, 0x06C45D188009454F]
g = splitmix(0)
check("splitmix64 seed 0 (published)", [next(g) for _ in range(3)], PUBLISHED_SEED0)
check("splitmix64 seed 0 (examples.json)", [int(x, 16) for x in EX["splitmix64_seed0"]], PUBLISHED_SEED0)
for case in EX["splitmix64"]:
    g = splitmix(int(case["seed"], 16))
    check(f"splitmix64 seed {case['seed']}", [f"{next(g):016x}" for _ in case["outputs"]], case["outputs"])
for case in EX["bounded"]:
    g = splitmix(int(case["seed"], 16))
    check(f"bounded seed {case['seed']} n={case['n']}", [below(g, case["n"]) for _ in case["values"]], case["values"])


# 3. asteroid-v1 and survey-v1 re-derived from ADR-052 text
def yield_of(t, seed):
    y = splitmix(seed ^ ascii_const("ASTYIELD"))
    mv = t["mass_variability_pct"]
    dm = below(y, mv + 1) - mv // 2
    mass = min(4096, max(1, t["mass"] * (100 + dm) // 100))
    rv = t["richness_variability_pct"]
    dr = below(y, rv + 1) - rv // 2
    rich = min(100, max(0, t["richness_pct"] + dr))
    ore_total = mass * rich // 100
    total_w = sum(o["weight"] for o in t["ores"])
    tally = {o["item"]: 0 for o in t["ores"]}
    for _ in range(ore_total):
        r = below(y, total_w)
        acc = 0
        for o in t["ores"]:
            acc += o["weight"]
            if acc > r:
                tally[o["item"]] += 1
                break
    out = [[o["item"], tally[o["item"]]] for o in t["ores"] if tally[o["item"]]]
    if mass - ore_total:
        out.append([t["base_item"], mass - ore_total])
    return out


def survey(types, system, mseed, count, key=lambda t: t["id"]):
    cands = sorted([t for t in types if not t["systems"] or system in t["systems"]], key=key)
    stream = splitmix(mseed ^ ascii_const("SURVEY01"))
    res = []
    for _ in range(count):
        s = next(stream)
        tg = splitmix(s ^ ascii_const("ASTTYPE1"))
        r = below(tg, sum(c["weight"] for c in cands))
        acc = 0
        for c in cands:
            acc += c["weight"]
            if acc > r:
                chosen = c
                break
        res.append([chosen["id"], f"{s:016x}", yield_of(chosen, s)])
    return res


for case in EX["survey"]:
    check(f"survey {case['system']} seed {case['mission_seed']}",
          survey(EX["asteroid_types"], case["system"], int(case["mission_seed"], 16), case["count"]),
          case["instances"])


# 4. Hand-computable durations, gas and blueprint sums (independent formulas)
def ceil_div(a, b):
    return -(-a // b)


check("asteroid duration rating 10 = 12000 (hand)", min(72000, max(200, ceil_div(12000 * 100 * 100 * 10, 100 * 100 * 10))), 12000)
check("asteroid duration tm150 cfg100 r7 (hand: 1.8e9/70000=25714.29 -> 25715)",
      min(72000, max(200, math.ceil(12000 * 150 * 100 * 10 / (100 * 100 * 7)))), 25715)
for case in EX["asteroid_duration"]:
    d = min(72000, max(200, ceil_div(12000 * case["time_multiplier_pct"] * case["config_pct"] * 10,
                                     100 * 100 * case["rating"])))
    check(f"asteroid duration vector {case}", d, case["duration"])
for case in EX["gas"]:
    cap = case["cargo"] * 64
    rate = max(1, case["amount_per_1000_ticks"] * case["rating"] // 10)
    base = min(72000, max(200, ceil_div(cap * 1000, rate)))
    amount = min(cap, rate * base // 1000)
    dur = min(72000, max(200, ceil_div(base * case["config_pct"], 100)))
    check(f"gas vector {case['amount_per_1000_ticks']}/{case['rating']}/{case['cargo']}/{case['config_pct']}",
          {"rate": rate, "base": base, "amount": amount, "duration": dur}, case["expected"])
check("blueprint legacy data sums (hand)", {"power": 4, "battery": 720 + 0, "data": 1000, "cargo": 0, "rating": 0},
      EX["blueprints"][0]["expected"])
check("blueprint survey sums (hand 40, 720+10000, 1000, 0, 10)",
      {"power": 40, "battery": 10720, "data": 1000, "cargo": 0, "rating": 10}, EX["blueprints"][1]["expected"])
check("blueprint miner at cap (3x9=27 cargo)", EX["blueprints"][3]["expected"]["cargo"], 27)

# 5. Java int overflow exposure of the asteroid-duration numerator
num = 12000 * 1000 * 1000 * 10
print(f"INFO asteroid numerator max {num} > Integer.MAX_VALUE {2**31-1}: {num > 2**31 - 1}")
print(f"INFO asteroid numerator tm150 cfg150: {12000*150*150*10} > int max: {12000*150*150*10 > 2**31-1}")

# 6. Candidate ordering trap: ID string order vs ResourceLocation.compareTo (path, then namespace)
mixed = [
    dict(EX["asteroid_types"][0], id="zeta:alpha", weight=20),
    dict(EX["asteroid_types"][1], id="alpha:zeta", weight=15),
]
by_string = survey(mixed, "advancedrocketrycommunity:earth", 0x0123456789ABCDEF, 4)
by_rl = survey(mixed, "advancedrocketrycommunity:earth", 0x0123456789ABCDEF, 4,
               key=lambda t: (t["id"].split(":", 1)[1], t["id"].split(":", 1)[0]))
print("INFO mixed-namespace types by ID string :", [x[0] for x in by_string])
print("INFO mixed-namespace types by RL.compareTo:", [x[0] for x in by_rl])
print("INFO orders differ ->", [x[0] for x in by_string] != [x[0] for x in by_rl])

print()
print("FAILURES:", failures if failures else "none")
sys.exit(1 if failures else 0)
