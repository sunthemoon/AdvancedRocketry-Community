"""Add review-round-2 archives to the STATION-04 packet and bind the staged fix commit."""
import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUN = Path(__file__).resolve().parent.parent
REVIEW = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-orbit-review-93e171ae7db0458da7e8885be4229cb3')
OUT = ROOT / 'docs/work/v1.5.0-orbit-environment'
BASE = '442e4a71700e2d6402c48ffeaf99429a17b4b283'
# Reviewer's full repository exports (git archive of 89600ae and two mutation copies, with build output)
# and re-extracted copies of already committed evidence ZIPs; reproducible from git and mutate.py.
REVIEW_EXCLUDED = ('scratch/',)
EXCLUDED = ('station-server/', 'attempt-01-failed/station-server/', '__pycache__/', 'packaging/out/')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def bundle(name, source, excluded):
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            relative = path.relative_to(source).as_posix()
            if any(relative.startswith(prefix) or ('/' + prefix) in relative for prefix in excluded):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                data = path.read_bytes()
                archive.writestr(zipfile.ZipInfo(relative, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)
    raw = (OUT / (name + '.zip')).read_bytes()
    return {'name': name + '.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
            'manifest': name + '-files.json', 'source_directory': str(source), 'excluded': list(excluded)}


def archive():
    tested = json.loads((RUN / 'implementation-files.json').read_text())
    for relative, digest in tested.items():
        assert sha((ROOT / relative).read_bytes()) == digest, relative
    for row in json.loads((RUN / 'artifacts.json').read_text())['artifacts']:
        assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
    log = (RUN / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace')
    assert 'All 239 required tests passed' in log and 'EXIT_CODE=0' in log and '> Task :test\n' in log
    archives = [bundle('review-fix-checks', RUN, EXCLUDED), bundle('independent-review', REVIEW, REVIEW_EXCLUDED)]
    write('review-fix.json', {'schema_version': 1, 'reviewed_commits': ['f27b11a46f4897e12df93ea0bc1bf05fc0e30832',
          '442e4a71700e2d6402c48ffeaf99429a17b4b283'], 'fix_base': BASE, 'archives': archives,
          'review_sha256': sha((REVIEW / 'REVIEW.md').read_bytes()), 'fix_tested_files': tested,
          'junit': json.loads((RUN / 'junit-summary.json').read_text()),
          'scope': 'ADR-041/ORBIT-02 review and its fixes; confirmation review pending'})
    print('PASS:', ', '.join(f"{a['name']} {a['members']}" for a in archives))


def finalize():
    prefix = OUT.relative_to(ROOT).as_posix() + '/'
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)#]+)(#[^)]*)?\)', (ROOT / relative).read_text(encoding='utf-8')):
                target = target[0]
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write('fix-source-identity.json', {'base_commit': BASE, 'files': rows})
    write('fix-links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    for index in OUT.glob('*-files.json'):
        with zipfile.ZipFile(index.with_name(index.name.replace('-files.json', '.zip'))) as archive:
            listing = json.loads(index.read_text())
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(r['path'] for r in listing)
            for row in listing:
                raw = archive.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    # This commit also edits the STATION-03 packet's report; refresh both packets' checksum lists.
    for packet in (OUT,):
        paths = sorted(p for p in packet.iterdir() if p.name != 'SHA256SUMS.txt')
        (packet / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                               encoding='ascii', newline='\n')
    print('PASS:', len(rows), 'staged identities,', len(links), 'links, all ZIP readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--finalize', action='store_true')
    finalize() if parser.parse_args().finalize else archive()
