# Independent review: ADR-041 contract, ORBIT-02 implementation (`f27b11a`), and review-fix confirmation (`442e4a7`)

- Branch: `codex/v1.5.0-orbital-station-warp`. HEAD `442e4a71700e2d6402c48ffeaf99429a17b4b283`. The tracked tree equalled HEAD throughout the review.
- Scope:
  - **A.** Contract review of `docs/decisions/ADR-041-STATION-ORBIT-ENVIRONMENT.md` (PROPOSED).
  - **B.** `git diff 89600ae f27b11a` ("feat(station): add station gravity and orbit environment display").
  - **C.** `git diff f27b11a 442e4a7` ("fix(station): require non-silent player commands and extend native coverage"), including ADR-042 and `native-checks-2.zip`.
- Reviewer: an independent agent, not the implementer. Date: 2026-09-30.
- **This is not a Gate approval.** It does not accept ADR-041 or ADR-042 on the maintainer's behalf. It does not mark STATION-03/04 or ORBIT-01/02 `verified`. It does not approve any v1.5 G0-G9 Gate, candidate or release.

## Verdict on ADR-041: ACCEPT WITH CHANGES (not acceptable as written)

**What is sound.**
- The core design is sound and bounded:
  - one server-side, constant-time resolver: indexed `findAt` plus one catalog lookup, with no scan, chunk load or block read;
  - "configured" and "effective" gravity kept separate, with a physics clamp at 4.0, while `EnvironmentQueries` still reports the configured value (API 1.7 bytes unchanged);
  - the celestial controller receives a function, so there is no celestial→station import and no bidirectional dependency;
  - the ADR-040 local-actor rule and checked candidate commit are reused;
  - no packet, schema, translation key or client state is added;
  - sky, exposure, oxygen, warp and rockets are correctly excluded.
- It is consistent with ADR-034 (Space exposure stays disabled) and ADR-036 (generic Space sky).

**Changes required before acceptance:**
1. **Narrow the checked-mutation rule** (see M1). As written, "Checked management updates may change only the region or environment of a station" permits a region **shrink** (768→512) and arbitrary vacuum, solar-angle or gravity (up to 10,000) changes at the model layer. That contradicts ADR-040 ("No arbitrary rectangle, offset center, relocation or **shrink** is permitted") and ADR-041's own "values above 1,000 are not settable by command". The rule must name exactly two transitions:
   - the one 512→768 growth, with the environment unchanged;
   - a gravity-only change, with the region, vacuum and angle unchanged.
2. **Bound the rate of gravity writes** (see M2). "Direct, reversible, no confirmation" plus a synchronous full-registry fsync commit needs a stated per-station or per-actor cooldown, or coalescing, and a performance check in ORBIT-04.
3. **Dispose of the solar scope explicitly** (see M3). V150-ORBIT-02 is titled "Server effects and actual solar behavior", and the version plan lists 光照/太阳能 (lighting/solar) rules (§3 and §6 step 4). The ADR makes solar display-only. Either map the remaining solar work to a named leaf or version, or record it as an AGENTS §5 exemption with owner, reason, expiry and recovery.
4. **Qualify the compatibility claim** "Existing stations store 0, so existing worlds see no gravity change" (see L1). It holds only for the default Space definition with an active catalog and records that were never edited.
5. **Explicitly amend ADR-028** (see L2). ADR-028 says "the existing gravity controller remains Level-based; this API does not apply a station-specific gravity modifier", and its API returns empty for unknown orbit bodies, while ADR-041 physics applies the station's gravity in that case.

**Recommended changes:**
- Define "sun angle" as a stored, display-only value with no reference frame or effect until ORBIT-03.
- Decide who may see station name and UUID through `environment` (L5).
- State that an `OUTCOME_UNKNOWN` quarantine now blocks both expansion and gravity until restart.
- Extend the Verification section (L3).

## Findings (by severity)

There are no Critical or High findings.

### M1: the checked-update model guard was widened beyond ADR-040 (production code, defense in depth; not reachable today)

**Type:** production and contract.

**Where.**
- `station/model/StationState.java:219-232`: `sameAuthorityAs` compares every field except `region` and `environment`.
- `station/model/StationRegistryModel.java:106-120`: `replaceChecked` accepts any replacement that differs from the expected state and passes `sameAuthorityAs`.
- Before `f27b11a`, `replaceExpanded` accepted only `expected.withExpandedRegion()` from an unexpanded station.
- `StationCheckedUpdateTest.modelPublishesOnlyRegionOrEnvironmentUpdatesOfTheObservedState` was loosened to match. There is no test that rejects a shrink or a vacuum or angle change.

**Proof.** In `probes/ReviewProbe.java` (log `probes/ReviewProbe.log`), `model.replaceChecked(expanded, <same station with the 512 region>)` is accepted. `replaceChecked(current, <gravity 9999, vacuum=false, angle=1>)` is also accepted.

**Reachability.**
- Today the only callers are `checkedExpand`, which uses `withExpandedRegion`, and `checkedSetGravity`, which uses `withGravityMilli(0..1000)` (`StationRegistrySavedData.java:205-224`). No production shrink or vacuum path exists.

**Failure scenario.**
1. A later WARP or UI slice routes an orbit or region operation through `checkedReplace`/`replaceChecked` and trusts the model to enforce ADR-040.
2. A bug that produces a 512-wide state for an expanded station, or flips `vacuum`, is silently published and persisted.
3. A shrink releases a claimed ring. That ring's blocks lose build protection, and ADR-040 forbids this outcome.

**Fix.**
- Make the model accept only the two named transitions, or split it into `replaceExpanded` and `replaceGravity`.
- Add negative tests for shrink, vacuum, angle and gravity above 1,000.
- Align the ADR-041 text.

### M2: the gravity command is a repeatable synchronous full-registry fsync on the server thread with no cooldown

**Type:** production, performance and abuse.

**Where.**
- `StationGravityService.set` (`station/service/StationGravityService.java:203-233`) leads to `checkedReplace` (`StationRegistrySavedData.java:236-281`).
- That path runs the following on the server thread, bounded only by the 4 MiB registry cap:
  - a full `encode` of the registry;
  - migrate plus decode validation;
  - `CheckedSavedDataFile.replace`, which writes the file, calls `FileChannel.force(true)`, reads the file back and decodes it (`CheckedSavedDataFile.java:50-65`);
  - an atomic move.
- Expansion uses the same path, but it is one-shot per station and confirmation-gated. Gravity can be toggled indefinitely.

**Who can trigger it.**
- Any player can own one station through the Station Deployment Kit (`StationManager.createForPlayer`).
- Vanilla `detectRateSpam` (`bytecode/ServerGamePacketListenerImpl.javap.txt`: +20 per command, kick above 200, ops exempt) lets a non-op sustain about one command per second, after a burst of about 10.

**Failure scenario.**
1. On a server with a large registry (hundreds to thousands of stations), several owners script alternating `/arce station gravity 0` and `/arce station gravity 1` (`1` means 1 %; only 0..100 is accepted).
2. Each call re-encodes, fsyncs, re-reads and decodes the whole registry on the main thread.
3. MSPT spikes can exceed the P99 budget of 100 ms in `docs/17-V1PLUS-QUALITY-BUDGETS.md`.

**Not measured.** The evidence contains no timing for this path.

**Fix.**
- Add a per-station or per-actor cooldown (for example, 100 ticks), or debounce the writes.
- State the bound in ADR-041.
- Measure the path at 10 and 100 stations in ORBIT-04.

### M3: the ADR sets the solar scope to "display only" while the leaf and version plan promise solar behavior, with no disposition

**Type:** contract, scope and acceptance.

**The conflict.**
- ADR-041:95-96 says "No solar power generation or machine; solar intensity is exposed for display and future consumers only".
- `docs/work/v1.5.0-implementation-log.md` names the leaf "`V150-ORBIT-02` Server effects and actual solar behavior".
- The version plan asks for 轨道参数、光照/太阳能和可选重力 (§3: orbit parameters, lighting/solar and optional gravity) and 实现轨道光照/太阳能/重力规则 (§6 step 4: implement orbital lighting/solar/gravity rules).
- No document says which leaf or version will deliver the rest, and no AGENTS §5 exemption is recorded.

**Failure scenario.** ORBIT-02 is later marked `verified` when its titled outcome ("actual solar behavior") has not been implemented. This is the same pattern as the previous review's STATION-04 M1.

**Fix.** In ADR-041, map each version-plan orbit item to one of the following:
- ORBIT-02, ORBIT-03 or ORBIT-04;
- a named later leaf;
- an exemption with owner, expiry and recovery condition.

Then rename or re-scope ORBIT-02 accordingly.

### L1: "existing worlds see no gravity change" is conditional

**Type:** contract and compatibility; small production impact.

**Where.** ADR-041:68 and the CHANGELOG ("Existing stations keep zero gravity").

**Change.** Inside a committed region, the station's stored gravity now overrides the Space profile (`CelestialGravityController.java:40-44` with `StationManager.effectiveGravity`). Gravity inside existing station regions changes when:
- a data pack overrides `advancedrocketrycommunity:space` with a non-zero `gravity_multiplier`, because the stored 0 now wins inside stations;
- there is no active celestial catalog (a failed initial load leaves `current()` empty) or the Space Level mapping is unavailable. Previously the fallback was 1.0 (`orElse(1.0D)`); now stations get 0;
- a legacy or hand-edited record has a non-zero `gravity_milli`. That value now becomes effective, up to 4.0. Migration preserves environments verbatim, so the claim that "migrated stations use BASIC_SPACE" (ADR-041:16-17) is an assumption, not a guarantee.

**Fix.** Document these conditions in the ADR and CHANGELOG, or define the precedence differently. Add a GameTest or unit test for a Space definition with non-zero gravity.

### L2: ADR-041 does not explicitly amend ADR-028's controller statement

**Type:** contract consistency.

- ADR-028 ("Lifecycle, lookup and freshness") says "the existing gravity controller remains Level-based; this API does not apply a station-specific gravity modifier". It also says that unknown or deleted orbit bodies return empty.
- ADR-041 changes the controller and applies station gravity even when the orbit body is missing. The API still returns empty for that station, so API and physics intentionally diverge.

**Fix.** Add an "Amends ADR-028" note that states both points.

### L3: evidence and test gaps against ADR-041's own Verification list

**Type:** tests and evidence.

- **Production wiring is not exercised.**
  - `StationOrbitGameTests.java:67-70` builds its own `StationManager` and `CelestialGravityController` with a test catalog, and calls `onLivingTick` directly.
  - The registered production controller (`AdvancedRocketryCommunity.java:155-156`) is never exercised. Regressing it to the one-argument constructor would leave every test green.
  - **Fix:** post `LivingEvent.LivingTickEvent` on `MinecraftForge.EVENT_BUS`, or otherwise drive the registered listener.
- **Resolver `at()` is not unit-tested.**
  - The ADR lists "resolver inside/outside/boundary/negative coordinates, 512 and 768 regions, … blocked registry, … API value unchanged".
  - `StationOrbitEnvironmentResolverTest` tests only `resolve(station, catalog)`. The Space filter, blocked registry and position mapping in `at()` have no unit test.
  - No test shows `EnvironmentQueries` returning 10.0 while effective gravity is 4.0.
  - Existing `StationRegionBoundaryTest` covers `findAt`. My probe independently checked 32 boundary and negative cases, all OK (Info I1).
- **No gravity-specific policy matrix.** Silent source, FakePlayer, operator, invitee, gap and not-in-Space are tested only through expansion. The code is shared, so the risk is low.
- **`CelestialGravityControllerTest` is unchanged.** It does not test override precedence or the empty fallback.
- **The native gravity set/restart readback has not been run.** This is disclosed, and ORBIT-02 is correctly still `implemented-unverified`.

### L4: ADR-042 is formally complete, but the leaf text is stale and the ADR was self-accepted

**Type:** evidence, docs and process.

**What is formally complete.**
- ADR-042 names an owner, a reason, an expiry ("before V150-ACC-02") and a recovery condition (STATION-04 reopens and v1.5 cannot pass G0-G9).
- It does not lower a Gate: MIG-01 now names both cases (`implementation-log.md:144-145`).
- Its argument that a check against this world would be vacuous is true: `native/before/decoded.json` shows `transactions: 0`, and there is no `rocket_transfers` file.

**Remaining problems.**
- (a) **Self-acceptance.** The ADR is marked `ACCEPTED` in the same fix commit, with `acceptance_basis: maintainer standing goal`. No independent review is recorded before acceptance. By contrast, ADR-036 and ADR-040 record a reviewer, and ADR-041 in this same stream is still PROPOSED.
- (b) **Stale STATION-04 leaf text.** The leaf in `implementation-log.md:275-294` was not updated.
  - Outcome (line 279) still promises "rocket identities".
  - Acceptance (line 283) still lists "unknown-body handling".
  - Evidence (line 293) still says "Not covered: invitations … added-ring block contents", although those are now covered.
  - If the leaf is ticked `verified`, its visible outcome overclaims.
- (c) **Vacuous evidence cited as support.** The ADR-042 bullet "rocket transaction and transfer authorities left byte-equal" (line 43) is vacuous for this fixture (empty authority, no transfers file). It should be labelled as such rather than cited.
- (d) **Stale harness docstring.** The docstring in `native_station_expansion_check.py` still says "No real clients, invitations, …".

**Fix.** Update the leaf text to "verified for ADR-042 scope". Annotate the vacuous bullet. Record the review before, or together with, acceptance.

### L5: `/arce station environment` shows station name and UUID to any visitor

**Type:** production, privacy-policy consistency.

- `StationCommands.java:195-215` replies to any player standing in a region with the station name, UUID, orbit and gravity.
- `/arce station list` (`StationCommands.java:91-97`) deliberately filters non-ops to stations they own or are a member of, or were invited to.
- The ADR allows "any player in Space", so this is a design choice. It does not grant authority, because the UUID alone permits nothing. It is inconsistent with the `list` visibility policy.
- **Suggestion:** show environment values to everyone, but show name and UUID only to the owner, members, invitees and operators.

### L6: runtime changes landed before the ORBIT-01 contract was accepted

**Type:** process.

- `docs/work/v1.5.0-implementation-log.md:105` (TODO 2) says to "freeze the effective orbit environment contract … in an ADR before runtime changes".
- `f27b11a` implemented ORBIT-02 against a PROPOSED ADR-041.
- The statuses are honestly labelled `proposed` and `implemented-unverified`, so nothing is falsely claimed. The required ADR changes above (M1-M3) now imply code rework.

### Info

**I1: verified correct (production).**
- **Region boundaries and negative coordinates.** `Entity.blockPosition()` floors, `findAt` uses `floorDiv((x+512)/1024)`, and the region bounds are inclusive. My probe placed a player just inside and just outside every edge of 512- and 768-wide stations at cells (-1,-1), (0,0), (-2,3) and (5,-7). All 32 checks returned the right station or none, and the right effective gravity.
- **Other Levels.** Non-Space Levels return empty after one key comparison, so their gravity is unchanged. Space gaps and a blocked registry keep the Level profile.
- **UNCHANGED avoids writes.** `withGravityMilli` returns `this`, and `checkedReplace` returns `UNCHANGED` at lines 246-248, before `encode` and any I/O. This is covered by a unit test and the GameTest (audit line `GRAVITY_UNCHANGED`).
- **Percent to milli.** The mapping is `percent*10` (0..100 % → 0..1000 milli, where 100 % = 1 g). Brigadier bounds the argument to `integer(0,100)`, with a second guard in the service.
- **Effective gravity bound.** Effective gravity is at most 4.0, so `applyMultiplier` cannot throw.
- **Public API 1.7 is unchanged.** No API source changed. `build/libs/*-api.jar` has SHA-256 `50cc9ba0…10bf`, the same as the v1.4 and STATION evidence. `ServerEnvironmentQueries.java:81` still reports `gravityMilli/1000`.
- **Dependency hygiene.** No `celestial` class imports `station`, and there are no `net.minecraft.client` imports in `station`.

**I2: per-tick cost is acceptable, but unmeasured.**
- Each ServerPlayer tick in Space costs a `DimensionDataStorage` cache `HashMap` lookup, a synchronized `findAt` (`floorDiv` + `HashMap` + `contains`), a catalog map lookup and about 3 small allocations.
- There is no I/O, chunk access or iteration over stations. Outside Space the cost is a single key comparison.
- The ADR's "same lookup build protection already uses" is right about the kind of lookup, not its frequency: build protection runs per block event, not per tick.

**I3: the rename refactor preserves expansion decisions.**
- `StationLocalActor.check` keeps the same order: authority → local → Space → chunk → station → permission, then `ALREADY_EXPANDED`.
- `CheckedUpdate.UNCHANGED` maps to `ALREADY_EXPANDED`. `EXPAND` became `MANAGE_STATION`, with identical `StationAccessService` semantics.
- Changes that the VERIFICATION "no behavior change" statement does not list:
  - Diagnostic codes `ARCE_STATION_EXPANSION_{WRITE_FAILED,OUTCOME_UNKNOWN,REPLACED_DESPITE_ERROR}` became `ARCE_STATION_UPDATE_*`. A service-level candidate failure still logs `ARCE_STATION_EXPANSION_WRITE_FAILED stage=candidate`, so operators must search for both.
  - The texts for `STATION_CHANGED`, `WRITE_FAILED` and `OUTCOME_UNKNOWN` changed; the "run /arce station expand again" hint was lost.
  - Audit lines gained `gravity_milli`.
  - The quarantine is now shared between gravity and expansion.
- A gravity change also invalidates a pending expansion confirmation (`STATION_CHANGED`). That is fail-safe.

**I4: rocket fuel planning ignores station gravity.** `RocketTargetFlightPlanner.java:137-145` still quotes gravity 0 for station targets. A station at 100 % gravity is therefore quoted as 0 g for launch fuel. This is consistent with the ADR non-goal, but should be decided in the route or warp contract.

**I5: `StationManager.setGravity` trusts its caller.** `setGravity(ServerPlayer, boolean issuedByPlayer, int)` is public and trusts a caller-asserted boolean. This is the same pattern as the previous review's I3.

**I6: the 442e4a7 L1 fix is correct for Forge 1.20.1-47.4.10.**
- `CommandSourceStack.withSuppressedOutput()` returns `this` if and only if `silent || source.alwaysAccepts()` (`bytecode/CommandSourceStack.javap.txt`).
- `CommandSource.alwaysAccepts()` defaults to `false`. A scan of all 8,613 classes in the mapped jar found only `DebugCommand$Tracer` overriding it, returning `true`.
- `Entity`, `ServerPlayer` and Forge `FakePlayer` do not override it. `Entity.createCommandSourceStack` uses the 9-argument constructor, so the source is not silent.
- These paths all use `withSuppressedOutput`, so they are rejected:
  - `FunctionCommand`;
  - `AdvancementRewards`;
  - `ServerFunctionManager`'s game-loop sender.
- These paths never had the player as their source, so they are rejected as before:
  - signs, which use `CommandSource.NULL`;
  - command blocks;
  - `/execute as` from another source.
- Chat commands arrive through the player's own non-silent source (`handleChatCommand` → `detectRateSpam` → `performChatCommand`).
- `probes/SilentProbe.java` confirms the behaviour on a real stack: non-silent is accepted; `withSuppressedOutput()` and `withSuppressedOutput().withPermission(2)` (the advancement-reward shape) are rejected.
- No legitimate typed command is rejected.
- **Residual (documented):** a mod calling `performPrefixedCommand(player.createCommandSourceStack(), …)` non-silently is still accepted.
- **Wording nit:** the `NOT_LOCAL_PLAYER` text says "/execute cannot …", but a player's own typed `/execute as @s run …` is, correctly, accepted.

**I7: the new GameTest steps are not vacuous.**
- **Silent step.** It asserts result 0 followed by `NO_CONFIRMATION`. With the old check (`source.source == player`) it would have returned `ISSUED` (1). The archived `native-checks-2.zip:gametest-latest.log` shows `request code=NOT_LOCAL_PLAYER` exactly at that point: after the two `/execute` rejections and `NO_CONFIRMATION`, and before `NO_CONFIRMATION` and then the FakePlayer's `NOT_LOCAL_PLAYER`.
- **FakePlayer step.** It requires a delivered reply containing the `NOT_LOCAL_PLAYER` text. That proves the source was non-silent and `issuedBy` was true, so the rejection came from the player-list identity check.
- **Stale-object step.** It uses a real `PlayerList.remove`, a rejoin, and then the stale object's own source, which gets `NOT_LOCAL_PLAYER`.
- **Suggestion:** the silent step infers its reason. It could assert the audit or result code directly.

**I8: the native harness additions are sound.**
- **Invitation.**
  - It is written by the pinned v1.4 host (`576eaaf8…`) through its own `arce station invite … probe1`, issued from a connected probe owner.
  - The probe fixture is the rebuilt jar `08c0ff3f…`, which is test-only and has a full-match allow-list.
  - The v1.4 payload is asserted to equal the source with only owner, members and invitations changed.
  - The upgrade payload is asserted to equal the expected payload, invitation included, and the restart payload equals the upgrade payload.
- **Markers.**
  - Three sit in the ring and one in the gap. I checked them against the regions (-256..255 → -384..383) and the neighbour at 768..1279.
  - Each marker is checked with `execute if block`, which must report "Test passed". A missing or unloaded block yields "Test failed" or "not loaded" and fails the check.
  - `forceload` is setup only, happens outside the probe chunk-count windows and is removed afterwards.
- **Caveat.** Phase-1 `forceload` may generate chunks in the world copy. It does not touch the source; the source inventory is unchanged.

**I9: other work appeared during the review.** Untracked `docs/decisions/ADR-043-…` and `ADR-044-…` appeared in the working tree; these are the implementer's concurrent work and were not reviewed. Tracked files still equal `442e4a7`.

**I10: evidence integrity checks out.**
- `sha256sum -c` passes for both evidence directories.
- ZIP members equal their indexes, with 0 mismatches:

  | Archive | Members |
  |---|---|
  | `root-checks.zip` | 401 |
  | `native-checks-2.zip` | 258 |
  | `independent-review-2.zip` | 33 |

- `implementation-files.json` hashes equal the committed blobs: 20/20 at `f27b11a` (the only changed source file missing is the deleted `StationExpansionResult.java`) and 3/3 at `442e4a7`.
- Both full runs show `> Task :test` executed.
- Run 01 of the `f27b11a` evidence failed only on the disclosed GameTest bug ("Published gravity update differs"), and run 02 passed all 239 GameTests.
- The `442e4a7` full run passed 239 GameTests.
- My build reproduced the main JAR `8f2d1234…a29` used by the native run.

## Answers to the specific questions

- **Is effective gravity correct at region boundaries and for negative coordinates?** Yes (I1). The probe covered 32 boundary cases, including negative cells and both widths.
- **Can the checked update path change fields it should not?**
  - Identity, owner, name, cell, pad, orbit, members, invitations, creation time and schema are all protected.
  - The model does, however, accept a region shrink and any change to vacuum, angle or gravity (M1). This is not reachable from production callers today.
- **Is the gravity command's percent-to-milli mapping and bound correct, and does UNCHANGED avoid writes?** Yes to all three (I1).
- **Does the controller change behavior for existing worlds or non-station positions?**
  - Non-station positions: no.
  - Existing station regions: only under the conditions in L1 (a Space gravity override pack, no catalog, or a non-zero legacy record).
- **Is the per-tick cost a concern?** Not a correctness concern: it is O(1) and in-memory (I2). The real cost concern is the gravity write path (M2).
- **Does the rename preserve expansion behavior?** Yes for decisions and outcomes. Log codes and texts changed as listed in I3.
- **Is public API 1.7 truly unchanged?** Yes (I1).
- **Is `source.source == player && source.withSuppressedOutput() != source` correct?** Yes for 47.4.10 (I6).
- **Do the GameTests exercise the checks for the right reason?** Yes (I7).
- **Is ADR-042 an acceptable scope record, or does it hide a lowered bar?** It is acceptable in form and does not lower a Gate. It still needs the L4 fixes: record the review before acceptance, update the stale leaf text, and label the vacuous rocket evidence.
- **Are the native additions sound and non-vacuous?** Yes (I8).

## What I verified and how

1. **Code review.** I read `89600ae..f27b11a` and `f27b11a..442e4a7` in full, plus the full current sources for:
   - `StationRegistrySavedData`, `StationState`, `StationRegistryModel`, `StationRegion`, `StationGridCell` and `StationEnvironmentProfile`;
   - `StationLocalActor`, `StationGravityService`, `StationExpansionService` and `StationManager`;
   - `CelestialGravityController`, `CelestialEnvironmentService` and `CelestialCatalogManager`;
   - `StationCommands`, both GameTest classes, the unit tests, the probe and `CheckedSavedDataFile`.
2. **Contract documents.** I read ADR-028, ADR-034, ADR-036, ADR-040, ADR-041 and ADR-042, the version plan, the implementation log, the CHANGELOG, both VERIFICATION files and the previous `REVIEW.md` (the re-review in `arce-v150-station-rereview-…`).
3. **Bytecode.** I ran `javap` on `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar` for:
   - `CommandSourceStack`, `CommandSource`, `ServerPlayer` and `FakePlayer`;
   - `FunctionCommand`, `AdvancementRewards` and `ServerFunctionManager`;
   - `SignBlockEntity`, `BaseCommandBlock`, `ServerGamePacketListenerImpl` and `DebugCommand$Tracer`.

   I also scanned the whole jar for `alwaysAccepts` (`bytecode/`).
4. **Probes.** I compiled two probes against `build/classes/java/main` plus the runGameTestServer classpath (`probes/`):
   - `ReviewProbe`: the model-guard acceptance and 32 boundary checks;
   - `SilentProbe`: the `withSuppressedOutput` identity semantics.
5. **Tests.** I ran a targeted unit-test run and a full unit-test run in the main tree. I did not use `clean`, GameTest, `runData` or any server.
6. **Evidence.** I verified the checksums, checked ZIP members against their indexes, bound the evidence to the commit blobs, read the full-run and GameTest logs (audit sequences), and read the native harness, `summary.json`, `commands.json` and `decoded.json`.

## Commands and exit codes

All Gradle commands used `JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"` in `D:/GitHub/AdvancedRocketry-Community` at HEAD `442e4a7`.

| Command | Exit | Result |
|---|---|---|
| `./gradlew test --tests '*StationOrbit*' --tests '*StationCheckedUpdateTest' --tests '*StationExpansion*' --tests '*StationAccessServiceTest' --tests '*celestial.*' --offline --no-daemon --no-build-cache --console=plain` | 0 | `:test` executed; 27 suites / 172 tests; 0 failures, errors or skips. Log: `gradle-targeted-test.log`; XML in `junit-targeted/` |
| `./gradlew test --offline --no-daemon --no-build-cache --console=plain` | 0 | `:test` executed; 174 fresh suites / 967 tests; 0 failures, errors or skips. Log: `gradle-full-test.log`; summary: `full-test-summary.json` |
| `javac` + `java ReviewProbe` | 0 | 32 OK checks. INFO: shrink accepted = true; environment change accepted = true |
| `javac` + `java SilentProbe` | 0 | Non-silent true; silent false; silent + perm2 false |
| `javap -c -p …` (several classes) | 0 | See `bytecode/`. One helper grep pipeline exited 1 only because a pattern had no match |
| Python scan of the jar for `alwaysAccepts` | 0 | 8,613 classes; 3 references (`bytecode/alwaysAccepts-scan.txt`) |
| `sha256sum -c SHA256SUMS.txt` (orbit-environment and station-native) | 0 | All entries OK |
| Python ZIP-member and index verification | 0 | 401/258/33 members, 0 mismatches |
| Python evidence-to-blob binding | 0 | 20/20 (`f27b11a`), 3/3 (`442e4a7`) |
| Read-only `git diff`, `git show`, `git log`, `git status` and `git grep` | 0 | — |

**Side effects.**
- Both Gradle runs executed `:jar` and `:reobfJar` in the main tree's `build/`. The rebuilt JARs are byte-identical to the evidence: main `8f2d1234…a29`, API `50cc9ba0…10bf` (`jar-hashes-after-review.txt`).
- No tracked file was modified, staged or committed.
- `scratch/` was deleted after its results were recorded.

## Residual risks

- There is no native evidence for gravity set, restart and readback, and no real-client observation of attribute sync or movement feel at boundaries.
- There is no performance measurement for the per-tick lookup or for the gravity write path at 10, 100 and 4,096 stations.
- The model-level invariants rely on the callers until M1 is fixed.
- Datapack-dependent Space gravity semantics inside stations (L1) are untested.
- Mods that dispatch non-silent commands as the player remain trusted (documented).
- ADR-042 deferrals depend on MIG-01 actually building rocket and missing-body fixtures before ACC-02.

**This review is not a Gate approval.** ADR-041 needs the listed changes and maintainer acceptance. ORBIT-02 remains `implemented-unverified`. STATION-03 and STATION-04 still need the maintainer's decision; the L4 documentation fixes are recommended first.
