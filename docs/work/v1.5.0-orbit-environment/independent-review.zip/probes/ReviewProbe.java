import io.github.sunthemoon.advancedrocketrycommunity.station.model.*;
import io.github.sunthemoon.advancedrocketrycommunity.station.orbit.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public final class ReviewProbe {
    static int failures = 0;
    static void check(boolean ok, String what) {
        System.out.println((ok ? "OK   " : "FAIL ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        ResourceLocation earth = new ResourceLocation("advancedrocketrycommunity", "earth");
        // --- 1. Model guard: which checked replacements are accepted? ---
        StationGridCell cell = new StationGridCell(-3, 2);
        StationState base = StationState.fromReservation(new StationReservation(UUID.randomUUID(), UUID.randomUUID(),
                "Probe", cell, earth, 0));
        StationRegistryModel model = new StationRegistryModel();
        model.restoreStation(base);
        StationState expanded = model.replaceChecked(base, base.withExpandedRegion());
        StationState shrunk = new StationState(expanded.schemaVersion(), expanded.stationId(), expanded.ownerId(),
                expanded.name(), expanded.cell(), expanded.cell().region(StationLimits.REGION_SIZE),
                expanded.landingPad(), expanded.orbitBody(), expanded.createdAtGameTime(), expanded.environment(),
                expanded.members(), expanded.invitations());
        boolean shrinkAccepted;
        try {
            model.replaceChecked(expanded, shrunk);
            shrinkAccepted = true;
        } catch (RuntimeException e) {
            shrinkAccepted = false;
        }
        System.out.println("INFO model.replaceChecked(768 -> 512 shrink) accepted = " + shrinkAccepted
                + " (ADR-040 forbids shrink; old replaceExpanded rejected it)");
        StationState current = model.find(base.stationId()).orElseThrow();
        StationState vacuumOff = new StationState(current.schemaVersion(), current.stationId(), current.ownerId(),
                current.name(), current.cell(), current.region(), current.landingPad(), current.orbitBody(),
                current.createdAtGameTime(), new StationEnvironmentProfile(9_999, false, 1), current.members(),
                current.invitations());
        boolean envAccepted;
        try {
            model.replaceChecked(current, vacuumOff);
            envAccepted = true;
        } catch (RuntimeException e) {
            envAccepted = false;
        }
        System.out.println("INFO model.replaceChecked(vacuum=false, angle=1, gravity=9999) accepted = " + envAccepted);

        // --- 2. Region boundaries with negative cells, as the gravity controller resolves them ---
        StationRegistryModel registry = new StationRegistryModel();
        int[][] cells = {{-1, -1}, {0, 0}, {-2, 3}, {5, -7}};
        List<StationState> placed = new ArrayList<>();
        for (int i = 0; i < cells.length; i++) {
            StationState s = StationState.fromReservation(new StationReservation(UUID.randomUUID(), UUID.randomUUID(),
                    "S" + i, new StationGridCell(cells[i][0], cells[i][1]), earth, 0)).withGravityMilli(100 * (i + 1));
            if (i % 2 == 1) {
                s = s.withExpandedRegion();
            }
            registry.restoreStation(s);
            placed.add(s);
        }
        for (StationState s : placed) {
            StationRegion r = s.region();
            int cz = s.cell().centerZ();
            // Player standing just inside/outside each edge, using the controller's blockPosition() rounding.
            double[][] probes = {
                    {r.minimumX() + 0.0, true ? 1 : 0}, {r.minimumX() - 0.01, 0},
                    {r.maximumX() + 0.99, 1}, {r.maximumX() + 1.0, 0}};
            for (double[] p : probes) {
                BlockPos pos = BlockPos.containing(p[0], 128.0, cz + 0.5);
                Optional<StationState> hit = registry.findAt(pos.getX(), pos.getZ());
                boolean expectInside = p[1] == 1;
                OptionalDouble g = hit.map(st -> OptionalDouble.of(
                        StationOrbitEnvironmentResolver.resolve(st, Optional.empty()).effectiveGravity()))
                        .orElse(OptionalDouble.empty());
                check(hit.isPresent() == expectInside && (!expectInside
                                || (hit.get().equals(s) && g.getAsDouble() == s.environment().gravityMilli() / 1000.0)),
                        "cell=" + s.cell() + " width=" + r.width() + " x=" + p[0] + " block=" + pos.getX()
                                + " inside=" + hit.isPresent() + " gravity=" + g);
            }
            int cx = s.cell().centerX();
            double[][] zprobes = {{r.minimumZ(), 1}, {r.minimumZ() - 0.5, 0}, {r.maximumZ() + 0.5, 1},
                    {r.maximumZ() + 1.0, 0}};
            for (double[] p : zprobes) {
                BlockPos pos = BlockPos.containing(cx + 0.5, 64.0, p[0]);
                Optional<StationState> hit = registry.findAt(pos.getX(), pos.getZ());
                check(hit.isPresent() == (p[1] == 1) && (hit.isEmpty() || hit.get().equals(s)),
                        "cell=" + s.cell() + " width=" + r.width() + " z=" + p[0] + " block=" + pos.getZ()
                                + " inside=" + hit.isPresent());
            }
        }
        // Gap between two expanded neighbours never resolves.
        check(registry.findAt(-1024 + 384, -1024).isEmpty() || registry.findAt(-1024 + 384, -1024).get().region().width() == 768,
                "gap sanity");
        System.out.println("failures=" + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
