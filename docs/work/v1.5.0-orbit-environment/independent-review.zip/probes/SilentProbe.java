import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public final class SilentProbe {
    public static void main(String[] args) {
        CommandSource plain = new CommandSource() {
            public void sendSystemMessage(Component c) {}
            public boolean acceptsSuccess() { return true; }
            public boolean acceptsFailure() { return true; }
            public boolean shouldInformAdmins() { return false; }
        };
        CommandSourceStack chat = new CommandSourceStack(plain, Vec3.ZERO, Vec2.ZERO, null, 0, "p",
                Component.literal("p"), null, null);
        CommandSourceStack silent = chat.withSuppressedOutput();
        CommandSourceStack silentPerm = silent.withPermission(2);
        boolean nonSilentAccepted = chat.source == plain && chat.withSuppressedOutput() != chat;
        boolean silentAccepted = silent.source == plain && silent.withSuppressedOutput() != silent;
        boolean silentPermAccepted = silentPerm.source == plain && silentPerm.withSuppressedOutput() != silentPerm;
        System.out.println("issuedBy(non-silent own source) = " + nonSilentAccepted);
        System.out.println("issuedBy(withSuppressedOutput) = " + silentAccepted);
        System.out.println("issuedBy(withSuppressedOutput().withPermission(2)) [advancement reward shape] = " + silentPermAccepted);
        System.out.println("source preserved by withSuppressedOutput = " + (silent.source == plain));
        System.exit(nonSilentAccepted && !silentAccepted && !silentPermAccepted ? 0 : 1);
    }
}
