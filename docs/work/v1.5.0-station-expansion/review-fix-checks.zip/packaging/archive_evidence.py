"""Archive the STATION-03 independent review and fix round; bind the staged fix commit."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUN = Path(__file__).resolve().parent.parent
REVIEW = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v150-station-expansion-review-2be54341cce94d0ea3f6ab2ff9d25d22')
OUT = ROOT / 'docs/work/v1.5.0-station-expansion'
BASE = 'fa005706a81e585f3b296bdfaa837268b69e5b73'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def junit(name):
    suites = [ET.parse(p).getroot() for p in sorted((RUN / name).glob('TEST-*.xml'))]
    return {'suites': len(suites), **{k: sum(int(s.attrib.get(k, '0')) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}}


def bundle(name, source, excluded):
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            relative = path.relative_to(source)
            if any(relative.as_posix().startswith(prefix) for prefix in excluded):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                data = path.read_bytes()
                archive.writestr(zipfile.ZipInfo(relative.as_posix(), (2026, 9, 30, 0, 0, 0)), data,
                                 zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': relative.as_posix(), 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)
    raw = (OUT / (name + '.zip')).read_bytes()
    return {'name': name + '.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
            'manifest': name + '-files.json', 'source_directory': str(source), 'excluded': list(excluded)}


def archive():
    tested = json.loads((RUN / 'implementation-files.json').read_text())
    for relative, digest in tested.items():
        assert sha((ROOT / relative).read_bytes()) == digest, relative
    changed = set(git('diff', '--name-only', BASE, '--', 'src/main', 'src/test', 'src/adapterTest',
                      'gradle.properties').decode().split())
    changed |= set(git('ls-files', '--others', '--exclude-standard', '--', 'src/main', 'src/test',
                       'src/adapterTest').decode().split())
    assert changed == set(tested), sorted(changed ^ set(tested))
    for row in json.loads((RUN / 'artifacts.json').read_text())['artifacts']:
        assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
    assert junit('full-junit-03') == {'suites': 173, 'tests': 961, 'failures': 0, 'errors': 0, 'skipped': 0}
    assert junit('focused-junit')['tests'] == 91 and junit('focused-junit')['failures'] == 0
    log = (RUN / 'root-gradle-03.log').read_text(encoding='utf-8', errors='replace')
    assert 'All 238 required tests passed' in log and 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log
    for name in ('root-gradle-01-failed.log', 'root-gradle-02-failed.log'):
        assert 'EXIT_CODE=1' in (RUN / name).read_text(encoding='utf-8', errors='replace'), name
    review = (REVIEW / 'REVIEW.md').read_text(encoding='utf-8')
    assert 'M1' in review and 'Medium' in review
    archives = [bundle('independent-review', REVIEW, ()),
                bundle('review-fix-checks', RUN, ('packaging/out/', 'packaging/__pycache__/'))]
    write('review-fix.json', {'schema_version': 1, 'reviewed_commit': BASE, 'archives': archives,
          'review_sha256': sha((REVIEW / 'REVIEW.md').read_bytes()),
          'fix_tested_files': tested,
          'junit': {'focused': junit('focused-junit'), 'run_01_failed': junit('full-junit-01-failed'),
                    'run_02_failed': junit('full-junit-02-failed'), 'run_03': junit('full-junit-03')},
          'gametests_required_passed_run_03': 238,
          'expansion_audit_codes_run_03': json.loads((RUN / 'junit-summary.json').read_text())[
              'expansion_audit_codes_run_03'],
          'scope': 'Review of fa00570 and the fix round; the fix is not yet independently re-reviewed'})
    print('PASS:', ', '.join(f"{a['name']} {a['members']}" for a in archives))


def finalize():
    prefix = OUT.relative_to(ROOT).as_posix() + '/'
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write('fix-source-identity.json', {'base_commit': BASE, 'files': rows})
    write('fix-links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    for index in OUT.glob('*-files.json'):
        with zipfile.ZipFile(index.with_name(index.name.replace('-files.json', '.zip'))) as archive:
            listing = json.loads(index.read_text())
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(r['path'] for r in listing)
            for row in listing:
                raw = archive.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(p for p in OUT.iterdir() if p.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                        encoding='ascii', newline='\n')
    print('PASS:', len(rows), 'staged identities,', len(links), 'links, all ZIP readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--finalize', action='store_true')
    finalize() if parser.parse_args().finalize else archive()
