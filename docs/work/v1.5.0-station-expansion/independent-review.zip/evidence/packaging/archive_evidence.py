"""Archive V150-STATION-03 evidence and bind the staged tree; reads Temp, writes the packet only."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUN = Path(__file__).resolve().parent.parent
OUT = ROOT / 'docs/work/v1.5.0-station-expansion'
BASE = '37e4be6296093b9ab41020e3e8f4be5439146676'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def junit(name):
    suites = [ET.parse(p).getroot() for p in sorted((RUN / name).glob('TEST-*.xml'))]
    return {'suites': len(suites), **{k: sum(int(s.attrib.get(k, '0')) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}}


def archive():
    tested = json.loads((RUN / 'implementation-files.json').read_text())
    for relative, digest in tested.items():
        assert sha((ROOT / relative).read_bytes()) == digest, relative
    changed = set(git('diff', '--name-only', BASE, '--', 'src/main', 'src/test', 'gradle.properties').decode().split())
    changed |= set(git('ls-files', '--others', '--exclude-standard', '--', 'src/main', 'src/test').decode().split())
    assert changed == set(tested), sorted(changed ^ set(tested))
    artifacts = json.loads((RUN / 'artifacts.json').read_text())
    for row in artifacts['artifacts']:
        assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
    assert artifacts['api_jar_identical_to_station_schema']
    final, first, failed = junit('full-junit-03'), junit('full-junit-01'), junit('full-junit-02-failed')
    assert final == first == {'suites': 173, 'tests': 959, 'failures': 0, 'errors': 0, 'skipped': 0}, (final, first)
    assert failed['tests'] == 959 and failed['failures'] == 1 and failed['errors'] == 0, failed
    for name in ('root-gradle-01.log', 'root-gradle-03.log'):
        log = (RUN / name).read_text(encoding='utf-8', errors='replace')
        assert 'All 238 required tests passed' in log and 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log, name
    assert 'EXIT_CODE=1' in (RUN / 'root-gradle-02-failed.log').read_text(encoding='utf-8', errors='replace')

    members = []
    for path in sorted(RUN.rglob('*')):
        relative = path.relative_to(RUN)
        if relative.parts[0] == 'packaging' and len(relative.parts) > 1 and relative.parts[1] in ('out', '__pycache__'):
            continue
        assert not path.is_symlink(), path
        if path.is_file():
            members.append((relative.as_posix(), path))
    rows = []
    with zipfile.ZipFile(OUT / 'root-checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for key, path in members:
            data = path.read_bytes()
            bundle.writestr(zipfile.ZipInfo(key, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write('root-checks-files.json', rows)
    raw = (OUT / 'root-checks.zip').read_bytes()
    write('evidence-archives.json', {'schema_version': 1, 'base_commit': BASE, 'source_directory': str(RUN),
          'excluded': ['packaging/out/', 'packaging/__pycache__/'],
          'archives': [{'name': 'root-checks.zip', 'bytes': len(raw), 'sha256': sha(raw), 'members': len(rows),
                        'manifest': 'root-checks-files.json'}]})
    summary = json.loads((RUN / 'junit-summary.json').read_text())
    write('root-checks.json', {'base_commit': BASE, 'tested_implementation_files': tested,
          'junit': {'run_01': first, 'run_02_failed': failed, 'run_03': final},
          'gametests_required_passed': 238, 'expansion_audit_codes_run_03': summary['expansion_audit_codes_run_03'],
          'scope': 'Short development checks, not independent review or Required Gate approval'})
    write('development-artifacts.json', artifacts)
    print('PASS: tested sources/artifacts match;', len(rows), 'members')


def finalize():
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii')
    prefix = OUT.relative_to(ROOT).as_posix() + '/'
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write('source-identity.json', {'base_commit': BASE, 'files': rows})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    listing = json.loads((OUT / 'root-checks-files.json').read_text())
    with zipfile.ZipFile(OUT / 'root-checks.zip') as bundle:
        assert bundle.testzip() is None and sorted(bundle.namelist()) == sorted(r['path'] for r in listing)
        for row in listing:
            raw = bundle.read(row['path'])
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(p for p in OUT.iterdir() if p.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                        encoding='ascii', newline='\n')
    print('PASS:', len(rows), 'staged identities,', len(links), 'local links, ZIP readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--finalize', action='store_true')
    finalize() if parser.parse_args().finalize else archive()
