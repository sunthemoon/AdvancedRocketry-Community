"""Reviewer helper: check extracted root-checks.zip members against root-checks-files.json."""
import hashlib
import json
import os
import sys

index_path = sys.argv[1]
root = os.path.abspath(sys.argv[2])
if os.name == "nt":
    root = "\\\\?\\" + root.replace("/", "\\")


def member(path):
    return os.path.join(root, path.replace("/", os.sep))


index = json.load(open(index_path, encoding="utf-8"))
bad = 0
paths = set()
for entry in index:
    path = entry["path"]
    paths.add(path)
    with open(member(path), "rb") as handle:
        data = handle.read()
    if hashlib.sha256(data).hexdigest() != entry["sha256"] or len(data) != entry["bytes"]:
        bad += 1
        print("MISMATCH", path)
actual = set()
for directory, _, files in os.walk(root):
    for name in files:
        actual.add(os.path.relpath(os.path.join(directory, name), root).replace(os.sep, "/"))
print("index entries", len(index), "mismatched", bad)
print("extra members", sorted(actual - paths))
print("missing members", sorted(paths - actual))
