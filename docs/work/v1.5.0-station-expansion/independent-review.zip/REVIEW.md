# Independent review: V150-STATION-03 confirmed owner/operator station expansion

- Commit under review: `fa005706a81e585f3b296bdfaa837268b69e5b73` (branch `codex/v1.5.0-orbital-station-warp`)
- Base: `37e4be6296093b9ab41020e3e8f4be5439146676`
- Contract: `docs/decisions/ADR-040-STATION-REGIONS-AND-MIGRATION.md` ("Stable geometry and expansion policy",
  "Runtime authority and checked mutation"), STATION-03 leaf in `docs/work/v1.5.0-implementation-log.md`, AGENTS.md sections 3 and 5.
- Reviewer: independent agent (not the implementer). Review date 2026-09-30.
- **This is not a Gate approval.** It does not verify STATION-03, approve v1.5 G0-G9, or replace maintainer acceptance.

## Summary

The checked-commit core is sound: the live registry is not mutated before a known replacement on any exception path
I traced, the `AtomicSavedData` extraction is mechanically identical, confirmations behave as specified, and production
code loads no chunk and touches no block. The targeted tests pass on my run.

There is one contract defect (Medium). The command trusts whatever entity the command source carries. Because of that,
`/execute as <owner> ...`, command blocks, functions and op-authored sign click events can drive both steps for a player
who never sees the warning. That fails the leaf's explicit acceptance item "no console bypass". The remaining findings
are Low: robustness gaps and tests that could not catch some regressions.

## Findings (ordered by severity)

### M1 (Medium, production/contract defect): entity-redirected command sources bypass "no console/remote-operator bypass" and the owner's explicit confirmation

- `src/main/java/.../station/command/StationCommands.java:139-140` and `:159-160`: both handlers take the actor from
  `context.getSource().getPlayerOrException()`, which returns the source's **entity** (`CommandSourceStack.entity`)
  whenever it is a `ServerPlayer` (bytecode of `getPlayerOrException` confirmed).
- `src/main/java/.../station/service/StationExpansionService.java:130-141`: identity, position, Space check, loaded
  chunk and operator status all come from that entity (`player.getUUID()`, `player.blockPosition()`,
  `player.hasPermissions(2)`). Nothing checks that the command came from that player's own connection.
- Vanilla `/execute as <targets>` (permission level 2) redirects through `CommandSourceStack.withEntity`. That method
  keeps the **original output `source`** and permission level (bytecode of `ExecuteCommand.lambda$register$7` and
  `CommandSourceStack.withEntity` confirmed). Command blocks and functions behave the same way.
- Failure scenario A (console or remote op): Alice owns station S and is standing on its pad. The server console, or an
  operator anywhere, runs `execute as Alice run arce station expand`. The service issues a confirmation bound to Alice.
  The reply containing S's UUID, the bounds and the "blocks in the added area join the station" warning goes to the
  **console**, not to Alice. The console then runs `execute as Alice run arce station expand confirm <S>` and gets
  `EXPANDED`. Alice never saw the warning and never confirmed. The same works with `execute as <any op standing in
  another station>`, which gives a remote-operator bypass of the "operator must be local" rule.
- Failure scenario B (op-authored sign): `SignBlockEntity.executeClickCommandsIfPresent` runs the RUN_COMMAND click
  event of **every** line. Each runs with `CommandSourceStack(CommandSource.NULL, ..., permission 2, ..., entity=player)`
  (bytecode confirmed). A sign whose lines run `arce station expand` and `arce station expand confirm <S>` expands S
  when Alice clicks it inside S, and all output is discarded.
- Contract affected: ADR-040 says owner/operator "must explicitly confirm this consequence", that there is "no console
  or remote-operator bypass", and that "The command/UI must warn about existing blocks before confirmation". The
  STATION-03 acceptance line in the implementation log says "no console bypass". `CHANGELOG.md:23` ("Members, invitees
  and the console cannot expand") and `VERIFICATION.md:88` ("the registered command rejects the console") overstate what
  was tested. The GameTest only tries a bare `server.createCommandSourceStack()` (`StationExpansionGameTests.java:124-130`).
- Impact bound: every path needs permission-level-2 authoring (console, op, command block, function, NBT-edited sign).
  Ordinary players gain no privilege, and ops can already `admin delete`/`transfer` remotely. The service correctly
  uses the player's own `hasPermissions(2)`, not the source's, so a level-2 sign or `execute as <non-op>` does not
  grant operator status. This is still a failed acceptance criterion for this leaf.
- Possible fixes (for the implementer to choose): require that the source's output is the player itself, for example
  via an access transformer on `CommandSourceStack.source` and a `source == player` check; or reject sources whose
  permission level or position differ from the player's own. Add a GameTest for `execute as` and for command-block
  sources.

### L1 (Low, production/contract): FakePlayers are accepted as "actual server players"

- `StationCommands.java:140,160` / `StationExpansionService.java:130-141`: nothing rejects
  `net.minecraftforge.common.util.FakePlayer` (or a player without a live connection). ADR-040 says owner and operator
  "must be actual server players".
- The implementer's own GameTest demonstrates the gap: the owner and the "local operator" that succeed are FakePlayers
  (`StationExpansionGameTests.java:158-167`, used at `:60`, `:84` and `:133`), including through the registered command (`:133-139`).
- Scenario: another mod dispatches a command, such as a sign click, with a FakePlayer that carries the owner's GameProfile
  and stands inside the station. It can request and confirm. Authoring such a command context again needs op-level
  setup, so this is Low.
- Observation outside the reviewed commit: the uncommitted STATION-04 prep in the working tree (`src/adapterTest/.../StationExpansionProbe.java`,
  `compat-test-mod/README.md`) drives expansion as a FakePlayer from a level-2 command. That would not be evidence of
  real-player behavior, and it would conflict with fixing L1 or M1.

### L2 (Low, production robustness): post-replacement failure handling is not fully "verified recovery"

- `station/persistence/StationRegistrySavedData.java:268-276`: after the committer was invoked and threw, any
  **readable** on-disk payload that is not the candidate returns `WRITE_FAILED` ("previous file retained"). That
  includes `Optional.empty()` (file absent). The code neither checks that the file equals the acknowledged registry
  (`encode(new CompoundTag(), null)`) nor calls `setDirty()`. If the target is absent or holds some other content while
  the registry is clean, ordinary saves never reassert the acknowledged authority. ADR-040 requires "otherwise
  quarantine mutations and require verified recovery". Realistically, a failed atomic rename leaves the old target
  intact, so this is defensive. A one-line `setDirty()` in this branch, or an equality check against the acknowledged
  encoding, would close it. `VERIFICATION.md:36` describes this branch as "the file still holds other valid content".
  The content is only decoded, not validated.
- `StationRegistrySavedData.java:249`: `registry.replaceExpanded` runs after a verified replacement without its own
  handling. If it threw, the exception would reach `StationExpansionService.java:100-104`, be logged as
  `WRITE_FAILED stage=candidate`, and leave the file expanded, memory unexpanded and no quarantine. A restart would then
  silently grow the station. It can only throw if the model changes between line 222 and line 249. That needs a
  mutation from a thread other than the server thread, and I found no such caller, so this is theoretical.

### L3 (Low, test defect): no test would catch a "publish before write, roll back on failure" regression

- None of the injected committers in `src/test/.../station/persistence/StationCheckedExpansionTest.java` (lines
  105-107, 121-124, 131-134) inspect the live registry **during** the commit. If `checkedExpand` published the expansion
  first and restored it on failure, every test would still pass. The ADR's central rule ("Stage an immutable candidate
  without mutating the live model") therefore rests on code reading only. Suggested test: a committer that asserts
  `data.find(id)` still equals `observed` and that `data.findAt(gap)` is empty before it moves the file.
- `failureBeforeReplacementLeavesAuthorityAndLaterSavesUnexpanded` (line 91) does not exercise a later save.
- The service-level `catch (RuntimeException)` path that maps candidate encode/validation failures to `WRITE_FAILED`
  (`StationExpansionService.java:98-104`) has no test.

### L4 (Low, test defect): GameTest and unit coverage are weaker than the verification text implies

- `StationExpansionGameTests.java:70-76`: the unloaded-chunk rejection and the "request did not load the chunk"
  assertion run only `if (!gapLoaded)`. If the chunk is already loaded, the test passes without them. The archived run 03
  did execute this branch (audit `request:CHUNK_UNLOADED` = 1, verified in `gametest-latest-03.log`), but future runs are
  not guaranteed to.
- Logout wiring (`AdvancedRocketryCommunity.java:148`) is not exercised. The GameTest builds a private `StationManager`
  (`:56`) and calls `onPlayerLoggedOut` on it directly (`:92`). Deleting the registration line would leave every test
  green. Clearing at server stop (`AdvancedRocketryCommunity.java:110,302`) is also covered only by unit-level `clear()`.
  I verified both wirings by reading the code.
- The console check (`:124-130`) accepts any `CommandSyntaxException`, so an unknown command would also pass it. The
  later operator step does prove the literal exists. There is no `execute as` case (see M1).
- `src/test/.../station/service/StationExpansionServiceTest.java:33` (`locationAndAuthorityAreCheckedBeforePermission`)
  uses only authorized actors (owner, `operator=true`), so it cannot detect a permission-first ordering despite its name.

### I1 (Info, evidence)

- `VERIFICATION.md` lists `gradlew compileJava` and a focused 89-test run with no archived logs; the ZIP holds only
  the three full-run logs. I reproduced the focused run: exit 0, 14 suites, 89 tests, 0 failures (see commands).
- The wording issues are listed under M1 (console) and L2 ("other valid content").

No Critical or High findings.

## What I verified and how

(a) **The live registry is never mutated before a known-successful replacement.** I traced every path in
`StationRegistrySavedData.checkedExpand` (lines 215-251):
- unavailable, quarantined, stale and already-expanded return before any IO;
- `encode` and `requireValidCandidate` build a separate tag and a separately decoded model; exceptions propagate
  before IO and the service maps them to `WRITE_FAILED`;
- identity, ancestry, regular-file, encode-size, open/write/force and readback failures all raise before the committer
  runs, `replacementAttempted` stays false, the result is `WRITE_FAILED`, the registry is untouched and the pending file
  is deleted;
- a committer failure is resolved by reading the file: `EXPANDED` only when the payload equals the candidate,
  otherwise `WRITE_FAILED` or `OUTCOME_UNKNOWN` (quarantine plus `setDirty`).

The only publish is `registry.replaceExpanded` at line 249, after success. Encoding the candidate does not mutate the
model (`stations()` returns a sorted copy and `StationState` is immutable). Residual gaps are in L2.
`StationState.equals` covers all 12 fields, so the stale check is exact.

(b) **The `AtomicSavedData` extraction preserves behavior.** I compared the old `AtomicSavedData.flush(Path, Committer)`
body with the new `CheckedSavedDataFile.replace` body mechanically (`extraction-diff.txt`). The only differences are the
signature, `save(new CompoundTag())` becoming `payload.get()` (evaluated at the same point inside the `try`), the
`setDirty()` / `setDirty(false)` / `saveFailureReported` lines staying in the `AtomicSavedData` wrapper, and `Committer`
becoming public. The helper methods are byte-for-byte the same. Order is unchanged: dirty is set, then identity,
ancestry and regular-file checks, then the payload, stage, force, readback, re-check and commit. Pending cleanup (only
if staged, with suppressed cleanup failures) and exception types (`UncheckedIOException` for IO, `RuntimeException`
otherwise) are unchanged. One trivial nuance: `setDirty()` now runs before path normalization, so a path that fails to
normalize leaves the object dirty, which is harmless. `AtomicSavedDataTest` is unchanged and passes 6/6. The
discovery-only type restriction is unchanged.

(c) **Confirmations.**
- Binding: actor UUID (map key), station UUID (`take`), the complete observed `StationState` (re-compared in `confirm`)
  and the registry instance (identity `!=` in `take`, and `located.authority() != data` in `confirm`).
- One-shot: `take` removes first and every status consumes; I verified the GameTest's audit sequence.
- Expiry: valid while `now - issued <= 200`, expired at 201 and when `now < issued`, matching the unit test's boundary.
- Capacity: a new actor is refused at 128 after a purge; an existing actor may replace its own entry.
- Purge: insertion order equals issue order because remove-then-put moves an entry to the end; purging stops at the
  first live entry, so the work is bounded.
- Logout: `AdvancedRocketryCommunity.java:148` to `StationManager.onPlayerLoggedOut` to `forget`.
- Server stop: `AdvancedRocketryCommunity.java:110` (`ServerStoppedEvent`) to `onServerStopped` to
  `stationManager.clear()` (`:302`) to `expansion.clear()`.
- Across sessions the registry-instance binding also rejects stale entries.

(d) **No chunk loading or block mutation.**
- Production expansion code uses only `player.serverLevel()`, `server.getLevel`, `player.blockPosition()`,
  `Level.hasChunkAt` and `findAt`. The bytecode of `ChunkSource.hasChunk` (`getChunk(..., FULL, false)`) and
  `ServerChunkCache.hasChunk` (holder ticket-level check only) confirms `hasChunkAt` adds no ticket and schedules no load.
- There are no `setBlock`, `getChunk(..., true)` or platform calls.
- The bare console is rejected (`getPlayerOrException`). A non-local operator player is rejected by the position and
  Space check. Members and invitees get `UNAUTHORIZED`, because `StationAccessService.allowed` grants members only
  VISIT/BUILD and grants invitees nothing.
- Entity-redirected sources are the exception (M1).

(e) **Ordinary callers.** `StationRegistrySavedData` still extends plain `SavedData`. `flush(server)` and every
mutator are unchanged. `save()` now delegates to `encode(target, null)`, which is identical to the old body including
the size bound. Creation, membership, transfer and delete do not call the new API.

(f) **Test strength.** See L3 and L4. The remaining assertions are meaningful. For example, the GameTest's
loaded-chunk-count check would catch a ring scan that uses `getChunk`, and a real rename is used for the "replaced
despite error" path.

(g) **Concurrency and lifecycle.**
- Everything runs on the server thread (commands, the logout event, `ServerStoppedEvent`, GameTests).
- `StationExpansionConfirmations` is intentionally unsynchronized.
- The `StationRegistrySavedData` instance is stable per server session (`computeIfAbsent`, never evicted). A new world
  or server gives a new instance, which rejects stale confirmations.
- `expansionQuarantined` is per instance, so it lasts until restart as documented.
- No position-keyed cache of station regions exists: `ServerEnvironmentQueries` and `RocketTargetContextService`
  resolve through the live `findAt`, so the expansion is visible in the same operation.
- There is no off-thread caller of registry mutators (relevant to L2b).

**Evidence packet.**
- `root-checks.zip` SHA-256 `feda5de5...6add24` matches `VERIFICATION.md` and `SHA256SUMS.txt`, and all 8
  `SHA256SUMS.txt` entries match.
- All 537 extracted members match `root-checks-files.json` (bytes and SHA-256; no extra or missing members;
  `verify_zip_index.py`).
- All 20 `tested_implementation_files` hashes equal the committed blobs and the working-tree files, and they are exactly
  the changed `src/main`, `src/test` and `gradle.properties` paths.
- `gametest-latest-03.log`: `All 238 required tests passed`; the `station_expansion:1` batch ran; the 20 audit lines
  match the claimed per-code counts exactly; 15 ERROR / 0 FATAL, all unrelated injected failures or
  `server.properties`, with no `EXPANSION_WRITE_FAILED`/`OUTCOME_UNKNOWN`.
- `root-gradle-03.log`: `:test`, `:runData` and `:runGameTestServer` executed, BUILD SUCCESSFUL, EXIT_CODE=0.
- Run 02 failed only on `ModMetadataTest`, and the new literal still pins the exact new sentence (not weakened).
- run_03 JUnit XML for the new suites: 5/3/8 tests, 0 failures.
- The three development JAR hashes in `VERIFICATION.md` equal the files in `build/libs`. My run rebuilt the main JAR
  (reproducible build) and it came out byte-identical, `7d595306...5010c0c`.

## Commands I ran (exit codes)

All Gradle runs used `JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"`, `--offline --no-daemon --console=plain`, no `clean`,
no `runData`/`runGameTestServer`.

| Command | Exit | Result |
|---|---:|---|
| `./gradlew test --tests '*StationExpansion*' --tests '*StationCheckedExpansionTest' --tests '*AtomicSavedDataTest' --tests '*StationRegistry*' --tests '*StationAccessServiceTest' --tests '*ModMetadataTest' --offline --no-daemon --no-build-cache --console=plain` | 0 | `:test` **executed** (not UP-TO-DATE/FROM-CACHE); 8 suites, **37 tests, 0 failures/errors/skipped**: StationExpansionConfirmationsTest 5, StationExpansionServiceTest 3, StationCheckedExpansionTest 8, AtomicSavedDataTest 6, StationRegistryModelTest 5, StationRegistrySavedDataTest 5, StationAccessServiceTest 4, ModMetadataTest 1. `compileJava`/`compileTestJava` were UP-TO-DATE against the committed sources. Log `targeted-tests.log`, XML in `test-results/` |
| `./gradlew test --tests '*station.*' --tests '*persistence.migration.*' --offline --no-daemon --no-build-cache --console=plain` (reproduces the unarchived claim) | 0 | `:test` executed; 14 suites, **89 tests**, 0 failures. Log `focused-station-migration-tests.log`, XML in `test-results-focused/` |
| `git diff 37e4be6 fa00570` (stat, full, per file), `git show` of old and new files | 0 | read-only |
| `sha256sum` of the ZIP and packet JSONs; `python verify_zip_index.py` | 0 | all match |
| Python hash check of the 20 tested files against `git show fa00570:<path>` and the working tree | 0 | 20/20 match; path set equal |
| `jar xf` / `javap -c` on the mapped Forge 1.20.1-47.4.10 jar (`CommandSourceStack`, `ExecuteCommand`, `SignBlockEntity`, `ChunkSource`, `ServerChunkCache`) | 0 | behavior cited in M1 and (d) |
| `diff` of the old `flush` body against `CheckedSavedDataFile.replace` | 1 (differences found, as expected) | `extraction-diff.txt` |

Side effects: the Gradle runs rewrote build outputs only (untracked). `build/test-results/test` now holds my focused
run's XML; the implementer's full-run XML is preserved in the ZIP. `build/libs/*-dev.jar` was rebuilt byte-identical. I
made no tracked-file change and ran no git write command. During the review the working tree already contained, or
gained, **uncommitted changes not made by me**: `src/adapterTest/.../AdapterTestMod.java` (modified 01:26),
untracked `src/adapterTest/.../StationExpansionProbe.java` (01:26) and `compat-test-mod/README.md` (modified 01:30,
content describes the STATION-04 probe). They are not part of `fa00570`, and the `adapterTest` source set is not
compiled by `:test`. All 20 reviewed files were byte-identical to the commit.

## Residual risks (not findings)

- There is no native, dedicated-server, real-client, multiplayer or same-world restart evidence for expansion
  (deferred to STATION-04). FakePlayers are not networked players.
- Process kill or power loss during the rename is untested. There is no directory fsync (claimed as unclaimed by
  ADR-040).
- `CheckedSavedDataFile` rejects any symlinked or junctioned ancestor of the world directory, so on such hosts expansion
  always returns `WRITE_FAILED`. This policy predates the slice (shared with discovery saves).
- After `OUTCOME_UNKNOWN` the unreadable file stays on disk until the next ordinary save. A crash before then leaves a
  file that pre-start validation will block (fail-closed). This is recoverable only from a backup or from the retained
  dirty state.
- The expanded ring adopts existing blocks, and deletion's rocket entity query now covers up to 768 by 768. Both are
  accepted in ADR-040.

## Statement

This is an independent code and evidence review. It is **not** a Gate approval, does not mark STATION-03 `verified`,
and does not approve any v1.5 Required Gate. M1 fails the leaf's own "no console bypass" acceptance item and should be
resolved, or explicitly waived by the maintainer through an ADR, before the leaf is marked verified.
