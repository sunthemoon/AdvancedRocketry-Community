"""Supplement completed cohort observations/errors without rewriting the runner's results."""
import collections
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

root = Path(__file__).resolve().parent
cohort = root / sys.argv[1]
tree = root / sys.argv[2]
assert cohort.parent == root and tree.parent == root
assert (cohort / 'results.json').is_file()
results = json.loads((cohort / 'results.json').read_text('utf-8'))
console = (cohort / 'native.log').read_text('utf-8',errors='replace')
latest = (cohort / 'native-latest.log').read_text('utf-8')
observations = [dict(console_line=i,line=line) for i,line in enumerate(console.splitlines(),1) if 'ARCE_SEAL_INSTALLED_RULE' in line]
errors = []
batch = None
for number,line in enumerate(latest.splitlines(),1):
    found = re.search("Running test batch '([^']+)'",line)
    if found:
        batch = found.group(1)
    if '/ERROR]' in line or '/FATAL]' in line:
        errors.append(dict(line_number=number,last_announced_batch=batch,header=line))
native_xml = []
for path in sorted((tree / 'build/gametest').rglob('*.xml')):
    target = cohort / 'native-xml' / path.relative_to(tree / 'build/gametest')
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,target)
    native_xml.append(dict(relative_path=target.relative_to(cohort).as_posix(),sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
supplement = dict(source=results['source'],observation_source='native.log console output',
                  observations=observations,native_error_headers=errors,native_xml=native_xml,
                  runner_observation_projection=results['native_observations'],
                  extraction_note='System.out observations are read from retained console output, not inferred missing from native-latest.log.')
(cohort / 'native-supplement.json').write_text(json.dumps(supplement,indent=2)+'\n','utf-8')
print(json.dumps(dict(source=results['source'],observations=observations,error_headers=len(errors),native_xml=len(native_xml))))
