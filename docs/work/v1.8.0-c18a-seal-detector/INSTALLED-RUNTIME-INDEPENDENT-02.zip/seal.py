"""Seal only compact retained regular payloads after disposable cleanup."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS.txt'
assert not manifest.exists(), 'Already sealed.'
assert (root / 'REPORT.md').is_file()
assert not any((root / name).exists() for name in ('source-cache','source-cache-corrected','gradle-cache','temp'))
files = sorted(path for path in root.rglob('*') if path.is_file() and path != manifest)
assert all(not path.is_symlink() for path in files)
assert all(path.stat().st_size <= 50 * 1024**2 for path in files)
total = sum(path.stat().st_size for path in files)
assert total < 100 * 1024**2
lines = [hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.relative_to(root).as_posix() for path in files]
manifest.write_text('\n'.join(lines)+'\n','utf-8')
for line in manifest.read_text('utf-8').splitlines():
    digest,name = line.split('  ',1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
print(f'Sealed and verified {len(files)} payload files; {total} payload bytes; manifest SHA-256 {hashlib.sha256(manifest.read_bytes()).hexdigest()}.')
