# Independent review: installed-runtime seal detector

Reviewer: delegated read-only Codex agent `/root/seal_installed_runtime_review`.
Date: 2026-10-08. This report is source review and independently executed evidence, not release or Gate approval.

## Findings first

1. **Medium test-evidence limitation, resolved in the corrected pin.** The original test captured `Component.getString()` and compared the rendered projection, not the response payload's translation identity, nested arguments or style. See original `SealDetectorRuntimeGameTests.java` [lines 137-142 and 206-209](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/review-inputs/original-test-source.java#L137). Translation fallback can discard distinctions in that projection; this is an assertion limitation, not an observed production defect or a claim that fallback actually occurred during the original run. The corrected test compares immediately serialized expected and actual Components through `Component.Serializer.toJson`, including the non-overlay flag: [lines 138-146 and 208-214](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/review-inputs/corrected-test-source.java#L138). The [actual correction diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/response-correction.diff) changes only test capture/assertion and observation output. Independently retained primary bytecode inspection supports this distinction; the corrected native cohort records the six expected serialized payloads.

2. **Open inherited acceptance failure; not introduced by the test-only delta.** Strict repository validation exits 1 in both genuine cohorts: 44 checks passed and one broken-Markdown-link check failed, with the emitted list capped at 256 entries. Missing inherited external/untracked archive targets and other invalid evidence references remain failures. No validator exemption, archive substitution or ignored failure was used. Both genuine [original](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-02/repository.log) and [corrected](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-03/repository.log) logs have SHA-256 `5af00089550e59579d9ff73c08d3a919a0cf66857915a5f4ee2729b54dd60ea0`. This prevents an all-Required-Gate conclusion, even though product tests pass.

3. **Low procedural limitation, reported separately by Root.** Root reported that the dedicated task existed before source authoring, but the central v1.8.0 implementation log was updated only after Root verification, contrary to AGENTS section 4.1 preparation order. Root explicitly retains the deviation without a retroactive compliance or waiver claim. Neither reviewed candidate diff includes that later central-log addition. This review does not independently reconstruct authorship chronology or approve subsequent record changes; those require separate actual-record review.

**No remaining new Critical, High or Medium production-code finding was identified in the corrected actual diff or the inspected adjacent boundaries.** No production code changes occur in either candidate delta. This statement is scoped to the inspected slice, not a whole-mod absence-of-defects assertion.

## Scope, inputs and actual source review

- Base: `80328a2d25c0c695cc9c8b09ee79910bfc458ec9`.
- Original candidate: `8b608d88205be9ff4cd19bdf9516317c9a6494d5`; reviewed independently and executed without modifying it.
- Corrected candidate: `794dd123f9af0047adbab385eddeb1c9d5089773`, parent original candidate; separately cloned, reviewed and fully rerun.
- Original [actual diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/candidate.diff) adds the installed-runtime task and two native GameTests. The [base-to-corrected diff](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/corrected-candidate.diff) retains that scope. Neither delta changes runtime behavior, source sets, timeout, production budgets, registrations, ledger delivery or version/Gate status.
- Read live main AGENTS, PROJECT-CONFIG, PRODUCT, required porting/roadmap/test/Gate/version/parallel/v1+ governance, ADR-024/060/066/067, the committed detector task, UPSTREAM, NOTICE and provenance policies. [Governance identities](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/review-inputs/governance-identities.json) retain read-input hashes; live AGENTS SHA-256 is `c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`.
- Adjacent review covered the existing adapter fixture/startup boundary registration, state-bearing full-collision boundary block, registered detector/item/feedback/runtime catalog flow, existing locally compiled-catalog test, exported API and Gradle compile/runtime/packaging boundaries. No additional reviewer-written test or source file was introduced.

The tests call the actually registered `advancedrocketrycommunity:seal_detector` through `ServerPlayerGameMode.useItemOn` with the real main/off-hand stacks. They use the existing fixture's public startup registration, assert one registration event, and do not import host implementation classes, compile a replacement catalog, replace runtime state or replay registration. Adapter compile inputs remain platform plus independently exported API outputs; the native hosted runtime necessarily loads the actual host. The existing locally compiled-catalog test is unchanged and remains distinct evidence. Normal runtime, API and sources JAR inspections contain no adapter-test entries.

Each new test measures closed/open/closed state changes while collision stays full. It checks actor-only, non-overlay system-chat payloads, ambient supply reported as not-known-supplied, item-wide two-tick cooldown shared across hands, unchanged held-stack identity/count/custom data, and no mutation of the two selected cells. Fixture setup requires loaded, block-entity-free cells. Owned players/channels are removed/released and cell states restored through success/failure cleanup. Exact checks are in the [corrected source snapshot](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/review-inputs/corrected-test-source.java).

## Actual commands and independent outcomes

Java: Oracle 17.0.7+8 LTS. Gradle: 8.8. Forge: 1.20.1-47.4.10. Commands used process-local `JAVA_HOME`, private leaf `GRADLE_USER_HOME`, D: `TEMP`/`TMP`/`TMPDIR`, and `JAVA_TOOL_OPTIONS=-Djava.io.tmpdir=<leaf>/temp`. Dependencies were copied read-only from installed caches into the private cache; no global cache/environment changes, installs or online dependency fetching were performed. C: and D: exceeded 10 GiB before sustained commands; exact byte observations are retained with each command.

Complete argv, UTC times, cwd, free-space readings, exit codes and log hashes are retained separately in [original commands/results](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-02/results.json) and [corrected commands/results](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-03/results.json). Gradle rows below used native `cmd.exe /d /c gradlew.bat`.

| Actual command | Original cohort-02 | Corrected cohort-03 |
| --- | --- | --- |
| `java -version`; `gradlew.bat --version --offline` | 0; 0 | 0; 0 |
| `clean build --no-daemon --offline --no-build-cache --rerun-tasks` | 0 | 0; all 20 actionable tasks executed |
| `runData --no-daemon --offline`, first invocation | 0 | 0 |
| `git --no-optional-locks diff --exit-code`, after first DataGen | 0; empty | 0; empty |
| Same DataGen and diff, second invocation | 0; 0, empty | 0; 0, empty |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | 0 | 0 |
| `python -B scripts/validate_bootstrap_provenance.py` | 0 | 0 |
| `python -B scripts/validate_repository.py --require-approved-identity` | 1; 44 pass / one failed check | 1; 44 pass / one failed check |
| `git --no-optional-locks diff --check`; same with base and candidate SHA | 0; 0 | 0; 0 |
| `runGameTestServer --no-daemon --offline --no-build-cache`, unfiltered | 0 | 0 |

Original genuine execution ran 15:15:57-15:33:50 UTC; corrected genuine execution ran 15:36:48-15:52:44 UTC. **Each** clean build produced 378 JUnit XML suites with 2,179 actual testcase nodes, zero failures/errors/skips; each unfiltered native run completed all 553 required GameTests successfully. [Original unit XML](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-02/unit-xml.zip) and [corrected unit XML](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-03/unit-xml.zip) are retained. The configured native runner emitted no separate GameTest XML; terminal totals and raw console/latest/debug logs are the native result evidence.

Both native runs contain **62 ERROR headers and zero FATAL headers** in `native-latest.log`; they are not error-free runs. All headers and last-announced batch context remain in the [original supplement](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-02/native-supplement.json) and [corrected supplement](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-03/native-supplement.json), with raw logs retained. Context includes negative migration/flush, binding, recipe and satellite tests; batch context alone is not proof of causality or permission to discard errors. Neither run has an ERROR header while the detector batch is the last announced batch. Test pass totals do not settle the whole-mod logging Gate.

The original console records two hand observations with closed/open/closed, three actor replies and zero peer replies. Its initial result extractor searched `native-latest.log`, so `native_observations` there is empty; the original immutable result is retained and the supplement locates the actual console lines 2371/2378. The corrected [console log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-03/native.log) lines 2369/2376 additionally records all six payloads: outer `message.advancedrocketrycommunity.seal_detector.reading`, nested boundary sealed/open/sealed and `supply.not_known_supplied`, each `overlay=false`. These are independent observations, not borrowed Root results.

### All failed preparation/invocation attempts retained

- Initial private clone checkout encountered Windows long-path omissions in historical tracked XML. Initial cache-copy preparation also encountered eight locked `*.lock` files; robocopy exited 9 and the outer preparation exited 1. [Initial setup log/script](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/setup.log) remain. This was setup failure, not a product-test outcome. The separate correction enabled long paths only in the owned clone, restored its pinned tracked files, and copied private caches excluding lock files; robocopy returned 1 for successful copies, outer setup 0. [Correction log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/setup-correction.log) remains.
- Cohort-01 passed forward-slash `C:/Windows/System32/cmd.exe` as the Python argv executable spelling. Every Gradle invocation failed with a 41-byte shell syntax error before Gradle execution: version/build/DataGen twice/native each exit 1. Java, ledger, provenance and whitespace exited 0; strict repository validation exited 1. Empty post-DataGen diffs do not count as successful DataGen in this attempt. **Zero JUnit and zero native tests executed**. [Entire failed cohort](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cohort-01/results.json), raw logs and original runner remain. Cohort-02 used native Windows executable spelling in a separate wrapper; cohort-03 used another fresh corrected-pin clone.
- All aggregate runners exited 1; in genuine cohorts this is solely the retained strict repository failure, not failed build or native tests. Initial mistaken document-name reads were resolved by locating the actual version/ADR filenames; no repository file was changed to accommodate them.

## Source, artifact and evidence identities

Original `src` Git tree: `91e6c1a233de4ae65bbff4b25c96dc2d35509acc`.
Corrected `src` Git tree: `005126337796bcdb1abbfda699bd601c4c2db253`.
Seven unchanged build-input Git blob IDs are retained in both genuine results. Both independently built cohorts observed these identical normal artifacts:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `advancedrocketry-community-1.20.1-1.8.0-dev.jar` | 6,027,872 | `dd93cb968430eba12fb13539bbdfb29e943af1f16a6b6a8ebb3257a14d9a6b87` |
| `advancedrocketry-community-1.20.1-1.8.0-dev-api.jar` | 51,052 | `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b` |
| `advancedrocketry-community-1.20.1-1.8.0-dev-sources.jar` | 2,873,767 | `ed57d4d0923c1571b421979a8e6068165b70dc048b755b8d8bdd8faf1c27d2a9` |

JAR inventories have 3,564 / 48 / 2,832 entries respectively and zero adapter fixture entries. Identical observed hashes do not establish release reproducibility or G9. Disposable build JARs were deleted, with identities retained rather than duplicating reproducible artifacts.

Independent bounded `javap -p -c` commands for `Component$Serializer`, `TranslatableContents`, `Language$1` and `LanguageHook` each exited 0 against the private mapped primary JAR SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`. [Inspection commands/output identities](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/review-inputs/primary-inspection.json) and those four bounded outputs remain.

The compact leaf retains actual diffs, exact test/task/AGENTS snapshots, input identities, all runners/setup/cleanup scripts, every command cohort, raw logs, unit XML, supplemental native observations and cleanup inventory. `SHA256SUMS.txt` seals retained payloads using relative names; no entry relies on deleted build/cache/Temp files. This report and retained payloads must not be silently modified after sealing.

## Cleanup, permissions and release of interests

All commands ended before cleanup. Ownership declaration, resolved absolute containment within the new evidence leaf, ancestor and recursive child reparse checks, own-process checks, and pinned clean HEAD checks passed. Both disposable source clones still had their assigned SHA and empty status before deletion. Exactly **one** native PowerShell `Remove-Item -LiteralPath ... -Recurse -Force` attempt succeeded, exit 0; no denial/retry, policy change or alternative deletion mechanism occurred. [Cleanup log](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cleanup.log) and [inventory](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01/cleanup-inventory.json) remain.

Removed only owned `source-cache` (1,418,760,853 bytes), `source-cache-corrected` (1,418,717,041 bytes), private `gradle-cache` (3,563,513,660 bytes) and task `temp` (235,008 bytes), including fresh disposable generated worlds/build outputs. No source-world input, main/Root checkout, global cache, sealed external evidence or another agent's process was targeted. Final observed free space was C: 30,517,469,184 bytes and D: 301,031,006,208 bytes. No own Java/Python/Git process referring to the leaf remained when the cleanup process check ran. All own command sessions ended; no HEAD/index/source edits, Git commit or push were performed by this reviewer. Main/Root source, HEAD and input read interests are released.

## Established, not established and remaining v1.8.0 work

**Established:** actual corrected test-only delta reviewed; installed startup state rule reached through registered detector use in both hands; structural response identity and actor-only/non-overlay boundary, shared cooldown and held-data/cell non-mutation checked; complete independent uncached build, twice clean DataGen and unfiltered native test execution retained; packaging excludes adapter tests; original limitations/failures preserved.

**Not established:** actual client packet delivery/rendering, real-GPU V1 or two-client V2, packaged S1/S2/restart/persistence, complete detector/query-order/actor/lifecycle/precedence/reload/unload/recipe-unlock matrix, closure of every native ERROR source, ledger delivery, ADR-068 acceptance, O1/O2/O3 completion or full v1.8.0 Required Gates. Governance acceptance cursor remains v1.0 IN_PROGRESS with v1.8 development under ADR-060; this review does not advance it. R-021 and broader G0-G9 work are not closed here.

**Recommendation:** retain the corrected-pin evidence for this narrowly bounded detector slice; separately repair inherited strict-validation references and review subsequent documentation changes, then complete the remaining applicable v1.8.0 detector/client/packaged-server/restart obligations. All Required Gates are **not** satisfied by this report. No source fix remains requested for the reviewed response-capture issue.
