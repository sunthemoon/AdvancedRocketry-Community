"""Retain source/governance IDs and independently inspect bounded platform bytecode."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
main = Path('D:/GitHub/AdvancedRocketry-Community')
tree = root / 'source-cache'
inputs = root / 'review-inputs'
inputs.mkdir()
governance = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
              'docs/04-VERSION-ROADMAP.md', 'docs/05-MASTER-TEST-PLAN.md',
              'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md', 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
              'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
              'docs/versions/V1.0.0-COMMUNITY-MVP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
              'docs/decisions/ADR-024-STATE-BASED-ATMOSPHERE-BOUNDARIES.md',
              'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
              'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
              'docs/decisions/ADR-067-V180-READ-ONLY-SEAL-DETECTOR.md',
              'UPSTREAM.md', 'NOTICE.md', 'docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md',
              'docs/08-ASSET-LICENSE-AND-PROVENANCE.md']
ids = {}
for name in governance:
    payload = (main / name).read_bytes()
    ids[name] = dict(bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
    if name == 'AGENTS.md':
        (inputs / 'live-main-AGENTS.md').write_bytes(payload)
review_task = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-root-20261008-01/REVIEW-TASK.md')
(inputs / 'REVIEW-TASK.md').write_bytes(review_task.read_bytes())
(inputs / 'governance-identities.json').write_text(json.dumps(ids, indent=2) + '\n', 'utf-8')
jar = root / 'gradle-cache/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'
records = []
env = dict(os.environ, JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + (root / 'temp').as_posix(),
           TEMP=str(root / 'temp'), TMP=str(root / 'temp'))
for kind in ('net.minecraft.network.chat.Component$Serializer', 'net.minecraft.network.chat.contents.TranslatableContents',
             'net.minecraft.locale.Language$1', 'net.minecraftforge.server.LanguageHook'):
    argv = ['C:/Program Files/Java/jdk-17.0.7/bin/javap.exe', '-p', '-c', '-classpath', str(jar), kind]
    out = inputs / (kind.rsplit('.', 1)[-1] + '.javap.txt')
    with out.open('xb') as stream:
        process = subprocess.run(argv, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream,
                                 stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    records.append(dict(argv=argv, exit_code=process.returncode, output=out.name,
                        sha256=hashlib.sha256(out.read_bytes()).hexdigest(), bytes=out.stat().st_size))
summary = dict(jar=str(jar), jar_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(), commands=records)
(inputs / 'primary-inspection.json').write_text(json.dumps(summary, indent=2) + '\n', 'utf-8')
print(json.dumps(summary))
assert all(r['exit_code'] == 0 for r in records)
