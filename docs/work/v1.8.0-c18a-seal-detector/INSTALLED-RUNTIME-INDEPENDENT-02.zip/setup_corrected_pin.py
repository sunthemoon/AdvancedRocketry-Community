"""Create a second owned clone for a separately supplied candidate; do not move the original clone."""
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
source = Path('D:/GitHub/arce-v180-seal-installed-runtime-20261008')
tree = root / 'source-cache-corrected'
pin = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', pin)
assert not tree.exists()
assert all(shutil.disk_usage(d).free >= 10 * 1024**3 for d in ('C:/','D:/'))
env = dict(os.environ, TEMP=str(root / 'temp'), TMP=str(root / 'temp'), PYTHONDONTWRITEBYTECODE='1')
commands = [
    ['git','--no-optional-locks','-C',str(source),'rev-parse','HEAD'],
    ['git','--no-optional-locks','-C',str(source),'status','--porcelain'],
    ['git','clone','--config','core.longpaths=true','--local','--no-hardlinks','--no-checkout',str(source),str(tree)],
    ['git','-C',str(tree),'checkout','--detach',pin],
    ['git','--no-optional-locks','-C',str(tree),'rev-parse','HEAD'],
    ['git','--no-optional-locks','-C',str(tree),'status','--porcelain'],
]
records = []
for number, argv in enumerate(commands):
    result = subprocess.run(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    log = root / f'corrected-setup-{number:02}.log'
    log.write_bytes(result.stdout)
    records.append(dict(argv=argv,exit_code=result.returncode,log=log.name,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (root / 'corrected-setup-commands.json').write_text(json.dumps(records,indent=2)+'\n','utf-8')
    assert result.returncode == 0, result.stdout.decode('utf-8',errors='replace')
    if number in (0,4):
        assert result.stdout.decode('utf-8').strip() == pin
    if number in (1,5):
        assert not result.stdout.strip()
for before, name in [('80328a2d25c0c695cc9c8b09ee79910bfc458ec9','corrected-candidate.diff'),
                     ('8b608d88205be9ff4cd19bdf9516317c9a6494d5','response-correction.diff')]:
    result = subprocess.run(['git','--no-optional-locks','-C',str(tree),'diff',before,pin],env=env,stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, result.stderr
    (root / name).write_bytes(result.stdout)
input_source = tree / 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SealDetectorRuntimeGameTests.java'
(root / 'review-inputs/corrected-test-source.java').write_bytes(input_source.read_bytes())
ownership = json.loads((root / 'ownership.json').read_text('utf-8-sig'))
(root / 'ownership-before-corrected-clone.json').write_text(json.dumps(ownership,indent=2)+'\n','utf-8')
ownership['disposable'].append(str(tree))
ownership['corrected_source_commit'] = pin
(root / 'ownership.json').write_text(json.dumps(ownership,indent=2)+'\n','utf-8')
print(json.dumps(dict(pin=pin,tree=str(tree),commands=records)))
