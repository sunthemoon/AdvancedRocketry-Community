"""Independent candidate cohort, isolated checkout and Gradle home; retain every exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / 'source-cache'
JDK = Path('C:/Program Files/Java/jdk-17.0.7')
PIN = '8b608d88205be9ff4cd19bdf9516317c9a6494d5'
TEMP = ROOT / 'temp'
TEMP.mkdir()
COHORT = ROOT / 'cohort-01'
COHORT.mkdir()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(TREE), *args]).decode('utf-8')

assert git('rev-parse', 'HEAD').strip() == PIN
assert not git('status', '--porcelain')
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + os.environ['PATH'],
           GRADLE_USER_HOME=str(ROOT / 'gradle-cache'), TEMP=str(TEMP), TMP=str(TEMP), TMPDIR=str(TEMP),
           PYTHONDONTWRITEBYTECODE='1', JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + TEMP.as_posix())
base = ['C:/Windows/System32/cmd.exe', '/d', '/c', 'gradlew.bat']
commands = [
    ('java', [str(JDK / 'bin/java.exe'), '-version']),
    ('gradle', base + ['--version', '--offline']),
    ('build', base + ['clean', 'build', '--no-daemon', '--offline', '--no-build-cache', '--rerun-tasks']),
    ('data-1', base + ['runData', '--no-daemon', '--offline']),
    ('data-1-diff', ['git', '--no-optional-locks', 'diff', '--exit-code']),
    ('data-2', base + ['runData', '--no-daemon', '--offline']),
    ('data-2-diff', ['git', '--no-optional-locks', 'diff', '--exit-code']),
    ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('provenance', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py']),
    ('repository', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
    ('whitespace-worktree', ['git', '--no-optional-locks', 'diff', '--check']),
    ('whitespace-candidate', ['git', '--no-optional-locks', 'diff', '--check', '80328a2d25c0c695cc9c8b09ee79910bfc458ec9', PIN]),
    ('native', base + ['runGameTestServer', '--no-daemon', '--offline', '--no-build-cache']),
]
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ('C:/', 'D:/')}
    assert all(value >= 10 * 1024**3 for value in free.values()), free
    start = now()
    print(json.dumps(dict(starting=name, source=PIN, utc=start)), flush=True)
    log = COHORT / (name + '.log')
    with log.open('xb') as output:
        process = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                 stdout=output, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
    record = dict(name=name, argv=argv, source=PIN, cwd=str(TREE), started_utc=start,
                  ended_utc=now(), free_bytes=free, exit_code=process.returncode,
                  log_sha256=sha(log), bytes=log.stat().st_size)
    records.append(record)
    (COHORT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n', 'utf-8')
    print(json.dumps(record), flush=True)

files = sorted((TREE / 'build/test-results/test').glob('TEST-*.xml'))
totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
actual = 0
with zipfile.ZipFile(COHORT / 'unit-xml.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        tree = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(tree.get(key, '0'))
        actual += len(tree.findall('testcase'))
        archive.write(path, path.name)
for name in ('latest', 'debug'):
    path = TREE / 'build/gametest/logs' / (name + '.log')
    if path.is_file():
        shutil.copy2(path, COHORT / ('native-' + name + '.log'))
native_log = COHORT / 'native-latest.log'
native_text = native_log.read_text('utf-8') if native_log.is_file() else ''
source_ids = {name: git('rev-parse', PIN + ':' + name).strip()
              for name in ('src', 'build.gradle', 'gradle.properties', 'settings.gradle', 'gradlew', 'gradlew.bat',
                           'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties')}
jar_contents = {}
artifacts = {}
for path in (TREE / 'build/libs').glob('*.jar'):
    artifacts[path.name] = dict(sha256=sha(path), bytes=path.stat().st_size)
    with zipfile.ZipFile(path) as archive:
        jar_contents[path.name] = dict(entries=len(archive.namelist()),
                                      adapter_test_entries=[n for n in archive.namelist() if 'arceadaptertest' in n or 'arce_adapter_test' in n])
summary = dict(source=PIN, source_ids=source_ids, commands=records,
               unit_suites=len(files), unit_totals=totals, actual_testcase_nodes=actual,
               native_error_headers=len(re.findall(r'/ERROR]', native_text)),
               native_fatal_headers=len(re.findall(r'/FATAL]', native_text)),
               native_terminal_lines=[line for line in native_text.splitlines()
                                      if re.search(r'GAME TESTS COMPLETE|All \d+ required tests passed|\d+ required tests failed', line)],
               native_failure_lines=[line for line in native_text.splitlines() if 'failed!' in line],
               native_probe_batches=[line for line in native_text.splitlines() if "Running test batch 'seal_detector_runtime" in line],
               native_observations=[line for line in native_text.splitlines() if 'ARCE_SEAL_INSTALLED_RULE' in line],
               head_unchanged=git('rev-parse', 'HEAD').strip() == PIN,
               clean=not git('status', '--porcelain'), artifacts=artifacts, jar_contents=jar_contents,
               process_environment={key: env[key] for key in ('JAVA_HOME','GRADLE_USER_HOME','TEMP','TMP','TMPDIR','JAVA_TOOL_OPTIONS')})
(COHORT / 'results.json').write_text(json.dumps(summary, indent=2) + '\n', 'utf-8')
print(json.dumps(summary), flush=True)
sys.exit(0 if all(r['exit_code'] == 0 for r in records) and summary['head_unchanged'] and summary['clean'] else 1)
