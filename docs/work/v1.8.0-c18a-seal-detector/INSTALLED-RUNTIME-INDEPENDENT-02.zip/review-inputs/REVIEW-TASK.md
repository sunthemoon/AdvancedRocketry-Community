# Independent actual-source review: C18a-SEAL-INSTALLED-RUNTIME-02

You are a delegated read-only reviewer, not Root or an implementer. Use neutral
engineering language. Do not call Claude or delegate further. Read live main
AGENTS.md and its mandatory governance, ADR-067 and the committed task below.
Inspect actual diff and adjacent fixture, runtime/item and source-set boundaries.
Report findings by severity with exact file/line evidence, independently of
Root's observations. This is not a request for release/Gate approval.

Candidate: 8b608d88205be9ff4cd19bdf9516317c9a6494d5.
Base: 80328a2d25c0c695cc9c8b09ee79910bfc458ec9.
Root source tree: D:/GitHub/arce-v180-seal-installed-runtime-20261008.
Task: docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-TASK-02.md.
Root may run a command cohort there; no source/index/HEAD writes, builds or
cleanup in that tree or main checkout.

Your only write_scope is a NEW external leaf
D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-independent-20261008-01
including your own fresh local clone/checkout and task TEMP. Pin the candidate.
Shell/Git/Java/Python and primary-source reads are allowed. No install, secrets,
global environment/cache edits, source changes, central integration or other
world ownership. Check C: and D: free space >=10 GiB before sustained commands;
use process-local D: TEMP/TMP/java.io.tmpdir. Java 17 is available at
C:/Program Files/Java/jdk-17.0.7.

Independently rerun key applicable checks: clean build with no build cache,
twice runData and empty diffs, complete unfiltered runGameTestServer,
ledger/provenance/strict repository/whitespace. Retain commands, actual exit
codes, raw logs, XML/counts, artifact/source IDs, native observations and all
attempts/errors. Root runner is readable as a tool input, not an expected
conclusion. If a correction is needed, send findings without editing source
and release read interests; corrected pins need separately retained cohorts.

After your commands end, inventory and clean only your new reproducible source
cache and ended disposable build outputs with resolved containment, ownership,
ancestor/reparse and live-process checks, using one native PowerShell attempt.
If denied, stop without retry, changing policy or another deletion mechanism.
Preserve logs/results/manifests and source-world inputs; do not seal an entire
reproducible source/build archive. Keep compact evidence <=100 MiB, single files
<=50 MiB; seal retained payload hashes and a relative SHA256SUMS.txt manifest.

Deliver REPORT.md with findings first, scope/results/commands, what is and is
not established, source/evidence identities, failures/limits, cleanup and
process/HEAD/input-interest release. Notify Root when observations change.
Final line: absolute REPORT.md path.
