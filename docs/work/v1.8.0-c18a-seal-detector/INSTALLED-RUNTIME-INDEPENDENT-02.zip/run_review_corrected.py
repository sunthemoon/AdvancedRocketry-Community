"""Preserve first invocation failures; correct cmd.exe spelling in a second cohort."""
from pathlib import Path

path = Path(__file__).with_name('run_review.py')
source = path.read_text('utf-8')
corrections = {
    "TEMP.mkdir()": "TEMP.mkdir(exist_ok=True)",
    "COHORT = ROOT / 'cohort-01'": "COHORT = ROOT / 'cohort-02'",
    "base = ['C:/Windows/System32/cmd.exe', '/d', '/c', 'gradlew.bat']":
        "base = [str(Path('C:/Windows/System32/cmd.exe')), '/d', '/c', 'gradlew.bat']",
}
for old, new in corrections.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(path), 'exec'))
