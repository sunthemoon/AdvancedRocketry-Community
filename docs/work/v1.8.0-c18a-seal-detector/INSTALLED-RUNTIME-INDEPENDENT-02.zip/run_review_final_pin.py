"""Run all independent checks on the separately supplied corrected pin in its own clone/cohort."""
from pathlib import Path
import re
import sys

pin = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}',pin)
path = Path(__file__).with_name('run_review.py')
source = path.read_text('utf-8')
corrections = {
    "TREE = ROOT / 'source-cache'": "TREE = ROOT / 'source-cache-corrected'",
    "PIN = '8b608d88205be9ff4cd19bdf9516317c9a6494d5'": f"PIN = '{pin}'",
    "TEMP.mkdir()": "TEMP.mkdir(exist_ok=True)",
    "COHORT = ROOT / 'cohort-01'": "COHORT = ROOT / 'cohort-03'",
    "native_text = native_log.read_text('utf-8') if native_log.is_file() else ''":
        "native_text = native_log.read_text('utf-8') if native_log.is_file() else ''\nconsole_text = (COHORT / 'native.log').read_text('utf-8', errors='replace')",
    "native_observations=[line for line in native_text.splitlines() if 'ARCE_SEAL_INSTALLED_RULE' in line]":
        "native_observations=[line for line in console_text.splitlines() if 'ARCE_SEAL_INSTALLED_RULE' in line]",
    "base = ['C:/Windows/System32/cmd.exe', '/d', '/c', 'gradlew.bat']":
        "base = [str(Path('C:/Windows/System32/cmd.exe')), '/d', '/c', 'gradlew.bat']",
}
for old,new in corrections.items():
    assert source.count(old) == 1, old
    source = source.replace(old,new)
exec(compile(source,str(path),'exec'))
