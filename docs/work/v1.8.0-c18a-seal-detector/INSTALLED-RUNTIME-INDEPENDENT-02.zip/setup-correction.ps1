$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot)
$checkout = Join-Path $leaf 'source-cache'
$gradleHome = Join-Path $leaf 'gradle-cache'
$log = Join-Path $leaf 'setup-correction.log'
& {
    foreach ($drive in 'C','D') { if ((Get-PSDrive -Name $drive).Free -lt 10GB) { throw "Insufficient space: $drive" } }
    git -C $checkout config --local core.longpaths true
    if ($LASTEXITCODE -ne 0) { throw "Local config exit $LASTEXITCODE" }
    git -C $checkout restore --source=8b608d88205be9ff4cd19bdf9516317c9a6494d5 --worktree .
    if ($LASTEXITCODE -ne 0) { throw "Pinned checkout restore exit $LASTEXITCODE" }
    $status = git --no-optional-locks -C $checkout status --porcelain
    if ($LASTEXITCODE -ne 0 -or $status) { throw "Review checkout is not clean: $status" }
    'Pinned checkout is clean.'
    foreach ($name in 'caches','wrapper') {
        robocopy (Join-Path 'C:\Users\Administrator\.gradle' $name) (Join-Path $gradleHome $name) /E /COPY:DAT /DCOPY:DAT /R:0 /W:0 /XJ /XF *.lock /NFL /NDL /NP
        $code = $LASTEXITCODE
        "Cache correction $name exit $code"
        if ($code -ge 8) { throw "Cache copy exit $code" }
    }
    Set-Content -LiteralPath (Join-Path $leaf 'ownership.json') -Encoding utf8 -Value (@{ owner='/root/seal_installed_runtime_review'; source_commit='8b608d88205be9ff4cd19bdf9516317c9a6494d5'; leaf=$leaf; disposable=@($checkout,$gradleHome,(Join-Path $leaf 'temp')); source_origin='D:\GitHub\arce-v180-seal-installed-runtime-20261008'; created_utc=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json)
} *>&1 | Tee-Object -FilePath $log
