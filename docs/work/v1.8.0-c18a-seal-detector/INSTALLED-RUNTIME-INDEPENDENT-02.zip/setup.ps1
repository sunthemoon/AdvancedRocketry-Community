$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot)
$source = 'D:\GitHub\arce-v180-seal-installed-runtime-20261008'
$checkout = Join-Path $leaf 'source-cache'
$gradleHome = Join-Path $leaf 'gradle-cache'
if (Test-Path -LiteralPath $checkout) { throw 'Review checkout already exists.' }
Start-Transcript -LiteralPath (Join-Path $leaf 'setup.log')
try {
    foreach ($drive in 'C','D') {
        $space = Get-PSDrive -Name $drive
        if ($space.Free -lt 10GB) { throw "Less than 10 GiB on $drive" }
        "Drive ${drive}: free $($space.Free) bytes"
    }
    git --no-optional-locks -C 'D:\GitHub\AdvancedRocketry-Community' status --short
    git --no-optional-locks -C 'D:\GitHub\AdvancedRocketry-Community' worktree list
    git --no-optional-locks -C $source status --short
    Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'java|codex|claude|gradle' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | Format-List
    git clone --local --no-hardlinks --no-checkout $source $checkout
    if ($LASTEXITCODE -ne 0) { throw "Clone exit $LASTEXITCODE" }
    git -C $checkout checkout --detach 8b608d88205be9ff4cd19bdf9516317c9a6494d5
    if ($LASTEXITCODE -ne 0) { throw "Checkout exit $LASTEXITCODE" }
    git --no-optional-locks -C $checkout rev-parse HEAD
    git --no-optional-locks -C $checkout status --porcelain
    git --no-optional-locks -C $checkout diff 80328a2d25c0c695cc9c8b09ee79910bfc458ec9 8b608d88205be9ff4cd19bdf9516317c9a6494d5 | Out-File -LiteralPath (Join-Path $leaf 'candidate.diff') -Encoding utf8
    New-Item -ItemType Directory -Path $gradleHome | Out-Null
    foreach ($name in 'caches','wrapper') {
        $from = Join-Path 'C:\Users\Administrator\.gradle' $name
        $to = Join-Path $gradleHome $name
        robocopy $from $to /E /COPY:DAT /DCOPY:DAT /R:0 /W:0 /XJ /NFL /NDL /NP
        $code = $LASTEXITCODE
        "Cache seed $name exit $code"
        if ($code -ge 8) { throw "Cache copy exit $code" }
    }
    Set-Content -LiteralPath (Join-Path $leaf 'ownership.json') -Encoding utf8 -Value (@{ owner='/root/seal_installed_runtime_review'; source_commit='8b608d88205be9ff4cd19bdf9516317c9a6494d5'; leaf=$leaf; disposable=@($checkout,$gradleHome,(Join-Path $leaf 'temp')); source_origin=$source; created_utc=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json)
} finally { Stop-Transcript }
