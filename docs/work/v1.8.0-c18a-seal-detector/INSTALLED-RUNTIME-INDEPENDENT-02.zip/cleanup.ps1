$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot)
$log = Join-Path $leaf 'cleanup.log'
& {
    $ownership = Get-Content -LiteralPath (Join-Path $leaf 'ownership.json') -Raw | ConvertFrom-Json
    if ($ownership.owner -ne '/root/seal_installed_runtime_review' -or [IO.Path]::GetFullPath($ownership.leaf) -ne $leaf) { throw 'Ownership mismatch.' }
    $names = @('source-cache','gradle-cache','temp')
    if (Test-Path -LiteralPath (Join-Path $leaf 'source-cache-corrected')) { $names += 'source-cache-corrected' }
    $targets = @($names | ForEach-Object { [IO.Path]::GetFullPath((Join-Path $leaf $_)) })
    $processes = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(java|javaw|python|git)\.exe$' -and $_.CommandLine -and $_.CommandLine.Replace('/','\').Contains($leaf,[StringComparison]::OrdinalIgnoreCase) })
    $processes | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-process-check.json') -Encoding utf8
    if ($processes.Count) { throw 'Owned command processes still refer to the evidence leaf. No cleanup attempt made.' }
    $records = @()
    $inventory = [Collections.Generic.List[object]]::new()
    foreach ($target in $targets) {
        if ($target -notin @($ownership.disposable | ForEach-Object { [IO.Path]::GetFullPath($_) })) { throw "Unrecorded target ownership: $target" }
        if (!$target.StartsWith($leaf + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or !(Test-Path -LiteralPath $target -PathType Container)) { throw "Invalid owned target: $target" }
        $cursor = Get-Item -LiteralPath $target -Force
        while ($cursor) {
            if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse ancestor: $($cursor.FullName)" }
            $cursor = $cursor.Parent
        }
        $children = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($children | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count) { throw "Reparse child in $target" }
        $bytes = 0L
        foreach ($child in $children) {
            if (!$child.PSIsContainer) {
                $bytes += $child.Length
                $inventory.Add([pscustomobject]@{ target=[IO.Path]::GetFileName($target); relative_path=[IO.Path]::GetRelativePath($target,$child.FullName); bytes=$child.Length })
            }
        }
        $records += [pscustomobject]@{ target=$target; files=@($children | Where-Object { !$_.PSIsContainer }).Count; directories=@($children | Where-Object { $_.PSIsContainer }).Count; bytes=$bytes }
        if ([IO.Path]::GetFileName($target) -like 'source-cache*') {
            $head = git --no-optional-locks -C $target rev-parse HEAD
            $gitCode = $LASTEXITCODE
            $pin = if ([IO.Path]::GetFileName($target) -eq 'source-cache-corrected') { $ownership.corrected_source_commit } else { $ownership.source_commit }
            $status = git --no-optional-locks -C $target status --porcelain
            $statusCode = $LASTEXITCODE
            if ($gitCode -ne 0 -or $statusCode -ne 0 -or $status -or $head -ne $pin) { throw 'Disposable checkout is not verifiably clean and pinned.' }
            "Released source clone HEAD $head, clean status."
        }
    }
    $inventory | Export-Csv -LiteralPath (Join-Path $leaf 'cleanup-inventory.csv') -NoTypeInformation -Encoding utf8
    $records | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-inventory.json') -Encoding utf8
    'Ownership, absolute containment, all ancestor/child reparse checks and owned-process checks passed.'
    'One native PowerShell Remove-Item attempt follows. A denied attempt will not be retried.'
    Remove-Item -LiteralPath $targets -Recurse -Force
    if (@($targets | Where-Object { Test-Path -LiteralPath $_ }).Count) { throw 'Disposable target remains after the single attempt.' }
    'Cleanup complete. Source worlds and main/Root checkouts were not targeted.'
    Get-PSDrive -Name C,D | Select-Object Name,Used,Free | ConvertTo-Json
} *>&1 | Tee-Object -FilePath $log
