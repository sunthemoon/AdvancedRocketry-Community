# Bounded retained evidence scope

The relative SHA256SUMS.txt seals only files outside the unsealed `_tmp` root.
It excludes itself and the external SEAL-RESULT.json summary. It does not seal
the whole working leaf or claim completed cleanup. The denied cleanup launcher,
raw error and actual temporary-volume observation are retained.

Root's follow-up instruction is to keep denied targets/raw evidence unchanged,
not retry or take over deletion, and finalize a bounded report/manifest excluding
`_tmp`. That instruction changes packaging scope, not the original cleanup result,
the pending five preimages, source identity or any version Gate.

The compact payload retains exact three ZIP copies and five document preimages,
command records, hashes, raw errors and review observations. No full private clone,
cache, build output, world, export or whole JAR is an admissible payload.
