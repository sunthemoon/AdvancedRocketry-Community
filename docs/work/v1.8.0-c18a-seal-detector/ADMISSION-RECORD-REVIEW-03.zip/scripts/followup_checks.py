import datetime,json,os,pathlib,subprocess,sys
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'
env=os.environ.copy(); env.update(TEMP=str(L/'_tmp/temp'),TMP=str(L/'_tmp/temp'),PYTHONDONTWRITEBYTECODE='1')
records=[]
def run(label,argv,cwd=S):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        p=subprocess.run(argv,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
        rec=dict(label=label,argv=argv,cwd=str(cwd),start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode,timeout_seconds=300)
        out,err=p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        rec=dict(label=label,argv=argv,cwd=str(cwd),start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=None,timeout_seconds=300,timeout=True)
        out,err=e.stdout or b'',e.stderr or b''
    (L/'logs'/f'{label}.stdout').write_bytes(out); (L/'logs'/f'{label}.stderr').write_bytes(err)
    records.append(rec); (L/'FOLLOWUP-COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,rec['exit'],out.decode(errors='replace')[-300:],err.decode(errors='replace')[-300:],flush=True)
    return rec,out
status,out=run('owned-missing-inventory',['git','status','--porcelain=v1','-z'])
missing=[e[3:] for e in out.split(b'\0') if e.startswith(b' D ')]
pathspec=L/'_tmp/missing-pathspec'; pathspec.write_bytes(b'\0'.join(missing)+b'\0')
if missing:
    restored,_=run('owned-longpath-restore',['git','-c','core.longpaths=true','restore','--source=HEAD','--worktree','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul'])
    if restored['exit']!=0: raise RuntimeError('Owned input restore failed')
check,out=run('owned-longpath-status',['git','-c','core.longpaths=true','status','--porcelain=v1','-z'])
if any(e.startswith(b' D ') for e in out.split(b'\0')): raise RuntimeError('Missing input still present')
(L/'FOCUSED-MARKDOWN-01.json').write_bytes((L/'FOCUSED-MARKDOWN.json').read_bytes())
run('strict-02',[sys.executable,'-B','scripts/validate_repository.py','--require-approved-identity'])
run('whitespace-02',['git','-c','core.longpaths=true','diff','--check'])
run('focused-markdown-02',[sys.executable,'-B',str(L/'scripts/focused_markdown.py')])
for r in json.loads((L/'PREIMAGES.json').read_text())['records'][:5]:
    if (L/'snapshots'/r['path']).read_bytes()!=(S/r['path']).read_bytes(): raise RuntimeError('Record copy drift')
print('All five owned record copies still exactly match preimages.',flush=True)
