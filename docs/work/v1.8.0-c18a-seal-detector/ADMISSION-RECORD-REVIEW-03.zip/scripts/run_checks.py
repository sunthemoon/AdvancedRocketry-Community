import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'; T=L/'_tmp/temp'
T.mkdir(exist_ok=True)
env=os.environ.copy(); env.update(TEMP=str(T),TMP=str(T),PYTHONDONTWRITEBYTECODE='1')
docs=json.loads((L/'PREIMAGES.json').read_text())['records'][:5]
for rec in json.loads((L/'PREIMAGES.json').read_text())['records'][5:8]:
    dst=S/rec['path']; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(L/'snapshots'/rec['path'],dst)
results=[]
def run(label,argv):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=S,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
    end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (L/'logs'/f'{label}.stdout').write_bytes(p.stdout); (L/'logs'/f'{label}.stderr').write_bytes(p.stderr)
    rec=dict(label=label,argv=argv,cwd=str(S),start_utc=start,end_utc=end,exit=p.returncode,timeout_seconds=300)
    results.append(rec); (L/'VALIDATION-COMMANDS.json').write_text(json.dumps(results,indent=2)+'\n')
    print(label,p.returncode,p.stdout.decode(errors='replace')[-1500:],p.stderr.decode(errors='replace')[-500:])
    return p.returncode
if run('archive-audit-02',[sys.executable,'-B',str(L/'scripts/audit_archives.py')]): raise RuntimeError('Archive audit failed')
for label,argv in [
('ledger',[sys.executable,'-B','scripts/validate_v180_content_ledger.py','--require-accepted']),
('bootstrap',[sys.executable,'-B','scripts/validate_bootstrap_provenance.py','--require-approved-review']),
('strict',[sys.executable,'-B','scripts/validate_repository.py','--require-approved-identity']),
('whitespace',['git','diff','--check']),
('source-input-identities',[sys.executable,'-B',str(L/'scripts/source_identity.py')]),
('focused-markdown',[sys.executable,'-B',str(L/'scripts/focused_markdown.py')])]: run(label,argv)
