import hashlib,json,pathlib,subprocess
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'
commits=['9429d00b6b24e9bd7de3b747d63528b7b7d06fa1','771543514c0ccf6f09f22b62ba1d36e9a6d9b7f9','e456ffc0eab1c0752fa5e6e57b4c63ddedbac964','a2e3c476de0188c93c0de85bf005d4a0e02e3251','452fd2a0dc12895c2e2b955c80115457459888bb','b001316102d064545fb81d9f4f2141ae52931118']
inputs=['build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties']
def git(*args): return subprocess.check_output(['git',*args],cwd=S)
report={}
for commit in commits:
    report[commit]=dict(src_tree=git('rev-parse',commit+':src').decode().strip(),inputs={f:dict(blob=git('rev-parse',commit+':'+f).decode().strip(),sha256=hashlib.sha256(git('show',commit+':'+f)).hexdigest()) for f in inputs},commit=git('show','--no-patch','--format=fuller',commit).decode())
report['diffs']={a+'..'+b:git('diff','--name-status',a,b).decode() for a,b in [(commits[0],commits[1]),(commits[1],commits[2]),(commits[3],commits[4]),(commits[4],commits[5])]}
report['source_lines']={str(p.relative_to(S)):len(p.read_text().splitlines()) for p in S.glob('src/**/SealDetectorAdmission*.java')}
for prefix in ['77154351','a2e3c476','e456ffc0','452fd2a0']:
    p=subprocess.run(['git','merge-base','--is-ancestor',prefix,'b0013161'],cwd=S); report.setdefault('ancestor_exits',{})[prefix]=p.returncode
(L/'SOURCE-IDENTITIES.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
