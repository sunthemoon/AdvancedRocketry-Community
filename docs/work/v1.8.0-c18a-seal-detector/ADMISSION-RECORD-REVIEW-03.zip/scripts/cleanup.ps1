$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot + '\..').TrimEnd('\', '/')
$expected = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\seal-admission-record-independent-resume-20261009-02'
if ($leaf -ne $expected) { throw 'Cleanup leaf identity mismatch' }
$target = [IO.Path]::GetFullPath((Join-Path $leaf '_tmp')).TrimEnd('\', '/')
if ($target -ne $leaf + '\_tmp' -or -not $target.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup absolute containment failure' }
$ancestor = $leaf
while ($ancestor) {
    $entry = Get-Item -LiteralPath $ancestor -Force
    if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Reparse ancestor: ' + $ancestor) }
    $ancestor = [IO.Path]::GetDirectoryName($ancestor)
}
$all = @(Get-CimInstance Win32_Process)
$ownedIdentities = @(Get-Content -LiteralPath (Join-Path $leaf 'logs/owned-followup-process-identities.json') -Raw | ConvertFrom-Json)
$stillLive = @($all | Where-Object { $_.ProcessId -in $ownedIdentities.ProcessId })
if ($stillLive.Count) { throw ('Owned execution PID still live; no deletion: ' + ($stillLive.ProcessId -join ',')) }
$ancestors = @($PID)
$parentPid = ($all | Where-Object { $_.ProcessId -eq $PID }).ParentProcessId
while ($parentPid -and $parentPid -notin $ancestors) {
    $ancestors += $parentPid
    $parentPid = ($all | Where-Object { $_.ProcessId -eq $parentPid }).ParentProcessId
}
$active = @($all | Where-Object {
    $_.ProcessId -notin $ancestors -and $_.CommandLine -and
    ($_.CommandLine.Contains($leaf) -or $_.CommandLine.Contains($leaf.Replace('\','/')) -or
     $_.CommandLine.Contains('scripts/followup_checks.py') -or $_.CommandLine.Contains('scripts/run_checks.py') -or
     $_.CommandLine.Contains('scripts/final_static.py') -or $_.CommandLine.Contains('scripts/corroborate.py'))
})
if ($active.Count) { throw ('Owned runtime may still read targets; no deletion: ' + ($active.ProcessId -join ',')) }
$entry = Get-Item -LiteralPath $target -Force
if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse cleanup root' }
$items = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse cleanup descendant' }
$files = @($items | Where-Object { -not $_.PSIsContainer })
$preflight = [pscustomobject]@{
    start_utc = [DateTime]::UtcNow.ToString('o')
    leaf = $leaf
    target = $target
    ownership = 'Created exclusively by this resumed independent record reviewer; includes only its private clone, owned archive extraction copies, TEMP and check outputs.'
    files = $files.Count
    logical_bytes = ($files | Measure-Object Length -Sum).Sum
    reparse_count = 0
    ended_owned_process_ids = $ownedIdentities.ProcessId
    active_owned_processes = 0
    allowed_orchestrator_ancestor_ids = $ancestors
    prior_interrupted_leaf = 'Excluded; never read, retaken, edited or deleted.'
}
$preflight | ConvertTo-Json -Depth 5 | Out-File -LiteralPath (Join-Path $leaf 'CLEANUP-PREFLIGHT.json') -Encoding utf8
# One deletion attempt of the exclusively owned, ended temporary root. A refusal stops execution.
Remove-Item -LiteralPath $target -Recurse -Force
if (Test-Path -LiteralPath $target) { throw 'Owned temporary root remains; no retry permitted' }
[pscustomobject]@{end_utc=[DateTime]::UtcNow.ToString('o'); removed=$target; attempts=1; remaining=$false; source_world_inputs='Untouched'; existing_worktrees='Untouched'} |
    ConvertTo-Json -Depth 4 | Out-File -LiteralPath (Join-Path $leaf 'CLEANUP-RESULT.json') -Encoding utf8
Write-Output ('REMOVED ' + $target)
