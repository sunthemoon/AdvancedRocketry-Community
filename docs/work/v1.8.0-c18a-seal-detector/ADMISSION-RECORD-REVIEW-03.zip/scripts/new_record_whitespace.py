import datetime,hashlib,json,pathlib,subprocess,sys
L=pathlib.Path(__file__).resolve().parents[1]
src=L/'snapshots/docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md'
lines=src.read_text(encoding='utf-8').splitlines(keepends=True)
patch='diff --git a/ADMISSION-VERIFICATION-03.md b/ADMISSION-VERIFICATION-03.md\nnew file mode 100644\n--- /dev/null\n+++ b/ADMISSION-VERIFICATION-03.md\n@@ -0,0 +1,'+str(len(lines))+' @@\n'+''.join('+'+line for line in lines)
p=L/'logs/new-record-whitespace.patch'; p.write_text(patch,encoding='utf-8',newline='\n')
cwd=L/'_tmp/whitespace'; cwd.mkdir(exist_ok=False)
args=['git','apply','--check','--no-index','--whitespace=error-all',str(p)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); result=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(L/'logs/new-record-whitespace.stdout').write_bytes(result.stdout); (L/'logs/new-record-whitespace.stderr').write_bytes(result.stderr)
(L/'NEW-RECORD-WHITESPACE.json').write_text(json.dumps(dict(argv=args,cwd=str(cwd),start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=result.returncode,patch_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),record_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),record_lines=len(lines)),indent=2)+'\n')
print('git apply whitespace check immediate exit:',result.returncode); print(result.stderr.decode(errors='replace')); sys.exit(result.returncode)
