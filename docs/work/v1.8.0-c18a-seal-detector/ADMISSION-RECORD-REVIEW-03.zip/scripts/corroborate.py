import datetime,hashlib,io,json,pathlib,re,subprocess,zipfile
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'; E=L/'_tmp/e'
report={}
def sha(data): return hashlib.sha256(data).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def fixed_source(commit):
    listing=subprocess.check_output(['git','ls-tree','-r','-z',commit,'--','src','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','gradle/wrapper'],cwd=S)
    rows=[]
    for line in listing.split(b'\0'):
        if not line: continue
        metadata,name=line.split(b'\t',1); mode,kind,oid=metadata.split()
        if kind!=b'blob': continue
        rows.append((name.decode(),oid.decode()))
    raw=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(oid for _,oid in rows)+'\n').encode(),cwd=S)
    result={}; offset=0
    for name,oid in rows:
        end=raw.index(b'\n',offset); header=raw[offset:end].split(); size=int(header[2]); offset=end+1
        result[name]=sha(raw[offset:offset+size]); offset+=size+1
    return result

for key,commit in [('original','e456ffc0eab1c0752fa5e6e57b4c63ddedbac964'),('corrected','452fd2a0dc12895c2e2b955c80115457459888bb')]:
    truth=fixed_source(commit)
    checks=[]
    for name in ['source-input-sha256.json','source-input-pre-native-sha256.json']:
        recorded=load(E/key/'retained'/name)
        mismatches=[n for n,d in recorded.items() if truth.get(n)!=d]
        canonical_bat=subprocess.check_output(['git','show',commit+':gradlew.bat'],cwd=S)
        eol_resolved=[n for n in mismatches if n=='gradlew.bat' and recorded[n]==sha(canonical_bat.replace(b'\n',b'\r\n'))]
        checks.append(dict(file=name,entries=len(recorded),missing_from_git=sorted(set(recorded)-set(truth)),unrecorded_git=sorted(set(truth)-set(recorded)),canonical_byte_mismatches=mismatches,declared_git_crlf_checkout_matches=eol_resolved,unexplained_mismatches=sorted(set(mismatches)-set(eol_resolved)),sha256=sha((E/key/'retained'/name).read_bytes())))
    report[key]={'source_manifest_vs_actual_git':checks}

for key in ['original','corrected']:
    base=E/key
    latest=base/'retained/gametest-gametest-logs/latest.log'
    text=latest.read_text(encoding='utf-8')
    batches=re.findall(r"Running test batch '([^']+)' \((\d+) tests\)",text)
    report[key]['native']=dict(latest_sha256=sha(latest.read_bytes()),scheduled=sum(int(n) for _,n in batches),batches=len(batches),admission=[x for x in batches if 'seal_detector_admission' in x[0]],required_terminal=re.findall(r'All (\d+) required tests passed',text),error_headers=len(re.findall(r'^.*\[.*?/ERROR\]',text,re.M)),fatal_headers=len(re.findall(r'^.*\[.*?/FATAL\]',text,re.M)))
    report[key]['datagen']={name:[dict(line=i,text=line) for i,line in enumerate((base/'logs'/name).read_text(encoding='utf-8').splitlines(),1) if 'Caching: total files:' in line] for name in ['data-01.log','data-02.log']}
    report[key]['forced_tasks']={name:[line for line in (base/'logs'/name).read_text(encoding='utf-8').splitlines() if 'actionable tasks:' in line] for name in ['clean-build.log','explicit-test.log']}
    commands={}
    for name in ['clean-build','explicit-test','data-01','data-01-empty-diff','data-02','data-02-empty-diff','gametest','ledger','bootstrap-provenance','strict-repository','whitespace']:
        rec=load(base/'retained'/f'{name}.json')
        commands[name]=dict(argv=rec['argv'],start_utc=rec.get('start_utc'),end_utc=rec.get('end_utc'),exit=rec['exit_code'],disk_free=rec.get('disk_free'),log_sha256=sha((base/'logs'/f'{name}.log').read_bytes()))
    report[key]['commands']=commands

root=E/'root'; root_report={}
for stage in ['cohort-01','cohort-02']:
    commands=load(root/stage/'commands.json')
    hashes=[]
    for rec in commands:
        log=root/stage/(rec['name']+'.log')
        hashes.append(dict(name=rec['name'],argv=rec['argv'],source=rec['source'],start_utc=rec['started_utc'],end_utc=rec['ended_utc'],exit=rec['exit_code'],raw_hash_matches=sha(log.read_bytes())==rec['log_sha256'],raw_bytes_match=len(log.read_bytes())==rec['bytes'],free_bytes=rec['free_bytes']))
    text=(root/stage/'native-latest.log').read_text(encoding='utf-8'); batches=re.findall(r"Running test batch '([^']+)' \((\d+) tests\)",text)
    root_report[stage]=dict(commands=hashes,native=dict(scheduled=sum(int(n) for _,n in batches),batches=len(batches),admission=[x for x in batches if 'seal_detector_admission' in x[0]],required_terminal=re.findall(r'All (\d+) required tests passed',text),error_headers=len(re.findall(r'^.*\[.*?/ERROR\]',text,re.M)),fatal_headers=len(re.findall(r'^.*\[.*?/FATAL\]',text,re.M))),datagen={name:[dict(line=i,text=line) for i,line in enumerate((root/stage/name).read_text(encoding='utf-8').splitlines(),1) if 'Caching: total files:' in line] for name in ['data-1.log','data-2.log']},forced_tasks={name:[line for line in (root/stage/name).read_text(encoding='utf-8').splitlines() if 'actionable tasks:' in line] for name in ['build.log','test.log']})
report['root']=root_report
ind_artifacts=load(E/'corrected/retained/artifact-identities.json'); root_artifacts=load(E/'root/artifacts-corrected.json')['artifacts']
report['artifact_inventory_crosscheck']=[dict(name=r['name'],bytes_match=r['bytes']==ind_artifacts[r['name']]['bytes'],hash_match=r['sha256']==ind_artifacts[r['name']]['sha256'],admission_entries_match=r['admission_entries']==ind_artifacts[r['name']]['admission_classes']) for r in root_artifacts]
root_classes=load(E/'root/artifacts-corrected.json')['compiled_class_sha256']; ind_classes=load(E/'corrected/retained/actual-admission-class-identities.json')
report['compiled_class_inventory_shapes']=dict(root=root_classes,independent=ind_classes)
report['strict_raw_output']={str(p.relative_to(E)):dict(sha256=sha(p.read_bytes()),pass_count=len(re.findall(r'^\[PASS\]',p.read_text(),re.M)),fail_count=len(re.findall(r'^\[FAIL\]',p.read_text(),re.M)),has_256_error_stop='stopped after 256 errors' in p.read_text()) for p in [E/'original/logs/strict-repository.log',E/'corrected/logs/strict-repository.log',root/'cohort-01/repository.log',root/'cohort-02/repository.log']}
report['erratum_original_manifest_sha256']=sha((E/'original/SHA256SUMS.txt').read_bytes())
report['root_preseal_links']=load(root/'record-links-after.json')
(L/'CORROBORATION.json').write_text(json.dumps(report,indent=2)+'\n')
print('Corroboration report saved:',L/'CORROBORATION.json')
