import datetime,hashlib,json,pathlib
L=pathlib.Path(__file__).resolve().parents[1]
manifest=L/'SHA256SUMS.txt'; summary=L/'SEAL-RESULT.json'
if manifest.exists() or summary.exists(): raise RuntimeError('Refuse existing seal')
files=[]
for path in L.rglob('*'):
    if '_tmp' in path.relative_to(L).parts: continue
    if path.is_symlink(): raise RuntimeError('Unexpected retained symlink')
    if path.is_file(): files.append(path)
records=[dict(path=p.relative_to(L).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)]
retained_bytes=sum(r['bytes'] for r in records)
if retained_bytes>=100*1024*1024 or any(r['bytes']>=50*1024*1024 for r in records): raise RuntimeError('Retained budget failed')
for r in json.loads((L/'PREIMAGES.json').read_text())['records']:
    if hashlib.sha256((L/'snapshots'/r['path']).read_bytes()).hexdigest()!=r['sha256']: raise RuntimeError('Preimage drift')
manifest.write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records),encoding='utf-8',newline='\n')
tmp_files=[p for p in (L/'_tmp').rglob('*') if p.is_file()]
tmp_bytes=sum(p.stat().st_size for p in tmp_files)
actual=dict(sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Bounded retained files only; unsealed _tmp excluded, cleanup denied and not retried.',payload_files=len(records),payload_bytes=retained_bytes,manifest_bytes=manifest.stat().st_size,retained_bytes_including_manifest=retained_bytes+manifest.stat().st_size,largest_payload=max(records,key=lambda r:r['bytes']),report_sha256=hashlib.sha256((L/'REPORT.md').read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),temporary_files=len(tmp_files),temporary_logical_bytes=tmp_bytes,whole_leaf_bytes_before_external_summary=retained_bytes+manifest.stat().st_size+tmp_bytes,retained_budget_pass=retained_bytes+manifest.stat().st_size<100*1024*1024 and all(r['bytes']<50*1024*1024 for r in records),whole_leaf_budget_pass=retained_bytes+manifest.stat().st_size+tmp_bytes<100*1024*1024,full_source_archive_in_payload=False)
summary.write_text(json.dumps(actual,indent=2)+'\n')
for r in records:
    if hashlib.sha256((L/r['path']).read_bytes()).hexdigest()!=r['sha256']: raise RuntimeError('Post-seal hash changed')
print(json.dumps(actual,indent=2))
