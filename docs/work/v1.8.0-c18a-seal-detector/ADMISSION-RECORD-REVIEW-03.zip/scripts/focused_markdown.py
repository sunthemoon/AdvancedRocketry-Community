import collections,datetime,hashlib,importlib,json,pathlib,subprocess,sys
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'; sys.path.insert(0,str(S/'scripts'))
validator=importlib.import_module('validate_repository')
docs=json.loads((L/'PREIMAGES.json').read_text())['records'][:5]
paths=[S/r['path'] for r in docs]
def key(err):
    prefix,target=err.split(' -> ',1)
    return prefix.rsplit(':',1)[0]+' -> '+target
before_payload={}; baseline_commands=[]
for r in docs:
    args=['git','show','HEAD:'+r['path']]; start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(args,cwd=S,stdout=subprocess.PIPE,stderr=subprocess.PIPE); before_payload[r['path']]=result
    baseline_commands.append(dict(argv=args,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=result.returncode,stderr=result.stderr.decode(errors='replace'),stdout_sha256=hashlib.sha256(result.stdout).hexdigest()))
snap={p:p.read_bytes() for p in paths}
before=[p for p in paths if before_payload[p.relative_to(S).as_posix()].returncode==0]
try:
    for p in before: p.write_bytes(before_payload[p.relative_to(S).as_posix()].stdout)
    baseline,bc=validator.markdown_link_errors(S,before)
finally:
    for p,payload in snap.items(): p.write_bytes(payload)
actual,ac=validator.markdown_link_errors(S,paths)
new=collections.Counter(map(key,actual))-collections.Counter(map(key,baseline))
report=dict(validator_sha256=hashlib.sha256((S/'scripts/validate_repository.py').read_bytes()).hexdigest(),baseline_commands=baseline_commands,baseline_links=bc,actual_links=ac,baseline_errors=baseline,actual_errors=actual,new_target_errors=dict(new),resolved_target_errors=dict(collections.Counter(map(key,baseline))-collections.Counter(map(key,actual))),limits={k:getattr(validator,k) for k in ['MAX_MARKDOWN_LINKS','MAX_MARKDOWN_ERRORS','MAX_MARKDOWN_FILE_BYTES','MAX_MARKDOWN_TOTAL_BYTES']})
(L/'FOCUSED-MARKDOWN.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2)); sys.exit(1 if new else 0)
