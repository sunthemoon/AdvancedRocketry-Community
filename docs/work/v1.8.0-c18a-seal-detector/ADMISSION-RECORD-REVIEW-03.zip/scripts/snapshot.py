import datetime, hashlib, json, pathlib, shutil, subprocess

LEAF = pathlib.Path(__file__).resolve().parents[1]
MAIN = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
DOCS = ['docs/work/v1.8.0-c18a-seal-detector/ADMISSION-TASK-03.md', 'docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md', 'docs/work/v1.8.0-implementation-log.md', 'docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md']
ARCHIVES = ['docs/work/v1.8.0-c18a-seal-detector/' + n for n in ['ADMISSION-ROOT-03.zip', 'ADMISSION-INDEPENDENT-03-ORIGINAL.zip', 'ADMISSION-INDEPENDENT-03.zip']]
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name, argv, cwd=MAIN):
    start = stamp()
    p = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (LEAF/'logs'/f'{name}.stdout').write_bytes(p.stdout)
    (LEAF/'logs'/f'{name}.stderr').write_bytes(p.stderr)
    (LEAF/'logs'/f'{name}.json').write_text(json.dumps(dict(argv=argv,cwd=str(cwd),start_utc=start,end_utc=stamp(),exit=p.returncode),indent=2)+'\n')
    if p.returncode: raise RuntimeError((name,p.returncode,p.stderr.decode(errors='replace')))
    return p.stdout.decode(errors='replace')

records=[]
for rel in DOCS + ARCHIVES + ['AGENTS.md']:
    src=MAIN/rel; dst=LEAF/'snapshots'/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    before=src.read_bytes(); shutil.copyfile(src,dst); after=src.read_bytes()
    if before != after or before != dst.read_bytes(): raise RuntimeError('Changed during snapshot: '+rel)
    records.append(dict(path=rel,bytes=len(before),sha256=hashlib.sha256(before).hexdigest()))
(LEAF/'PREIMAGES.json').write_text(json.dumps(dict(snapshot_utc=stamp(),records=records),indent=2)+'\n')
run('main-head',['git','rev-parse','HEAD'])
run('main-status',['git','status','--porcelain=v1'])
run('main-worktrees',['git','worktree','list','--porcelain'])
run('pending-record-diff',['git','diff','--binary','--']+DOCS)
for name,args in [('source-candidate',['rev-parse','452fd2a0dc12895c2e2b955c80115457459888bb:src']),('source-main',['rev-parse','b001316102d064545fb81d9f4f2141ae52931118:src']),('source-diff',['diff','--name-status','a2e3c476de0188c93c0de85bf005d4a0e02e3251','452fd2a0dc12895c2e2b955c80115457459888bb']),('integration-diff',['diff','--name-status','452fd2a0dc12895c2e2b955c80115457459888bb','b001316102d064545fb81d9f4f2141ae52931118']),('history',['log','--graph','--format=fuller','-25','b001316102d064545fb81d9f4f2141ae52931118'])]:
    run(name,['git']+args)
clone=LEAF/'_tmp'/'source'
run('clone',['git','clone','--no-hardlinks','--no-checkout',str(MAIN),str(clone)])
run('private-checkout',['git','checkout','--detach','b001316102d064545fb81d9f4f2141ae52931118'],clone)
for rel in DOCS:
    target=clone/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(LEAF/'snapshots'/rel,target)
run('private-head',['git','rev-parse','HEAD'],clone)
run('private-status',['git','status','--porcelain=v1'],clone)
final=[]
for rec in records:
    actual=hashlib.sha256((MAIN/rec['path']).read_bytes()).hexdigest()
    final.append(dict(path=rec['path'],unchanged=actual==rec['sha256'],sha256=actual))
if not all(r['unchanged'] for r in final): raise RuntimeError('Input drift before release')
(LEAF/'RELEASE-INPUT-INTERESTS.json').write_text(json.dumps(dict(released_utc=stamp(),main_source_head_read_interests='Released. Subsequent work uses owned copies and private clone only.',checks=final),indent=2)+'\n')
print('SNAPSHOT COMPLETE; all main/source/HEAD/input interests released; private clone:',clone)
