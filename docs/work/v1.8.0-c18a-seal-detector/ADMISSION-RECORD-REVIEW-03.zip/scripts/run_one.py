import datetime,json,pathlib,subprocess,sys
L=pathlib.Path(__file__).resolve().parents[1]
label=sys.argv[1]; args=sys.argv[2:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(args,cwd=L,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
(L/'logs'/f'{label}.stdout').write_bytes(p.stdout); (L/'logs'/f'{label}.stderr').write_bytes(p.stderr)
(L/'logs'/f'{label}.json').write_text(json.dumps(dict(argv=args,cwd=str(L),start_utc=start,end_utc=end,exit=p.returncode,timeout_seconds=300),indent=2)+'\n')
print(label,'immediate child exit',p.returncode); print(p.stdout.decode(errors='replace')[-1000:]); print(p.stderr.decode(errors='replace')[-2000:]); sys.exit(p.returncode)
