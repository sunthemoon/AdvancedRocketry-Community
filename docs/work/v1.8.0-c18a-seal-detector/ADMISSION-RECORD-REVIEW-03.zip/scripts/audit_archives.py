import datetime, hashlib, io, json, pathlib, re, stat, zipfile, xml.etree.ElementTree as ET
L=pathlib.Path(__file__).resolve().parents[1]
archives=L/'snapshots/docs/work/v1.8.0-c18a-seal-detector'
report={}
for file in sorted(archives.glob('*.zip')):
    key=file.stem
    short={'ADMISSION-INDEPENDENT-03-ORIGINAL':'original','ADMISSION-INDEPENDENT-03':'corrected','ADMISSION-ROOT-03':'root'}[key]
    out=L/'_tmp/e'/short
    with zipfile.ZipFile(file) as z:
        items=[v for v in z.infolist() if not v.is_dir()]
        names=[v.filename for v in items]
        problems=[]
        if len(set(n.casefold() for n in names))!=len(names): problems.append('duplicate/case-colliding names')
        for item in items:
            p=pathlib.PurePosixPath(item.filename)
            if p.is_absolute() or '\\' in item.filename or ':' in item.filename or '..' in p.parts or stat.S_ISLNK(item.external_attr>>16): problems.append('unsafe path '+item.filename)
        if problems: raise RuntimeError(problems)
        bad_crc=z.testzip()
        if bad_crc: raise RuntimeError('CRC '+bad_crc)
        manifests=[n for n in names if pathlib.PurePosixPath(n).name.lower() in ['sha256sums.txt','checksums.txt']]
        checks=[]
        for manifest in manifests:
            lines=z.read(manifest).decode('utf-8-sig').splitlines()
            listed=[]
            for line in lines:
                if not line.strip(): continue
                match=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line)
                if not match: raise RuntimeError('Bad manifest line '+line)
                digest,name=match.groups()
                name=name.replace('\\','/')
                if name not in names: raise RuntimeError('missing '+name)
                if hashlib.sha256(z.read(name)).hexdigest()!=digest.lower(): raise RuntimeError('hash '+name)
                listed.append(name)
            expected=set(names)-{manifest}
            checks.append(dict(manifest=manifest,entries=len(listed),unique=len(set(listed)),coverage_complete=set(listed)==expected,missing=sorted(expected-set(listed)),extra=sorted(set(listed)-expected)))
        xml_groups={}
        for name in names:
            if name.endswith('.xml') and 'junit' in name:
                stage=name.split('/')[1]
                root=ET.fromstring(z.read(name))
                rec=xml_groups.setdefault(stage,dict(xml=0,tests=0,failures=0,errors=0,skipped=0,testcases=0))
                rec['xml']+=1
                for field in ['tests','failures','errors','skipped']: rec[field]+=int(root.attrib.get(field,0))
                rec['testcases']+=len(root.findall('testcase'))
            if name.endswith('unit-xml.zip'):
                with zipfile.ZipFile(io.BytesIO(z.read(name))) as inner:
                    if inner.testzip(): raise RuntimeError('nested crc '+name)
                    rec=dict(xml=0,tests=0,failures=0,errors=0,skipped=0,testcases=0)
                    for member in inner.namelist():
                        if member.endswith('.xml'):
                            root=ET.fromstring(inner.read(member)); rec['xml']+=1
                            for field in ['tests','failures','errors','skipped']: rec[field]+=int(root.attrib.get(field,0))
                            rec['testcases']+=len(root.findall('testcase'))
                    xml_groups[name]=rec
        native={}
        for name in names:
            if name.endswith('native-latest.log') or name.endswith('native/latest.log') or (name.endswith('latest.log') and 'native' in name):
                content=z.read(name).decode('utf-8',errors='replace')
                native[name]=dict(error_headers=len(re.findall(r'^.*\[.*?/ERROR\]',content,re.M)),fatal_headers=len(re.findall(r'^.*\[.*?/FATAL\]',content,re.M)),terminal=[line for line in content.splitlines() if re.search(r'required tests passed|tests to run|Running test batch',line)][-8:])
        summary=dict(archive_bytes=file.stat().st_size,sha256=hashlib.sha256(file.read_bytes()).hexdigest(),zip_files=len(items),uncompressed_bytes=sum(v.file_size for v in items),largest_file=max(v.file_size for v in items),crc_bad=bad_crc,manifest_checks=checks,xml=xml_groups,native=native,report_sha256=hashlib.sha256(z.read('REPORT.md')).hexdigest())
        if 'ORIGINAL-REPORT-ERRATUM-01.md' in names: summary['erratum_sha256']=hashlib.sha256(z.read('ORIGINAL-REPORT-ERRATUM-01.md')).hexdigest()
        report[key]=summary
        if summary['largest_file']>50*1024*1024 or summary['uncompressed_bytes']>100*1024*1024: raise RuntimeError('size budget')
        out.mkdir(parents=True,exist_ok=False)
        # XML and nested XML archives are inspected above directly, avoiding MAX_PATH.
        for name in names:
            if name.endswith('.xml') or name.endswith('unit-xml.zip'): continue
            dest=out/name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(z.read(name))
        (L/'logs'/f'{key}-inventory.json').write_text(json.dumps([dict(path=v.filename,bytes=v.file_size,sha256=hashlib.sha256(z.read(v.filename)).hexdigest()) for v in items],indent=2)+'\n')
(L/'ARCHIVE-AUDIT.json').write_text(json.dumps(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archives=report),indent=2)+'\n')
print(json.dumps(report,indent=2))
