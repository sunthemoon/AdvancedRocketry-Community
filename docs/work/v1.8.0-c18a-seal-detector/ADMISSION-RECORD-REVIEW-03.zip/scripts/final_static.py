import datetime,hashlib,json,pathlib,subprocess,sys,zipfile
L=pathlib.Path(__file__).resolve().parents[1]; S=L/'_tmp/source'; results=[]
def run(label,args):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); p=subprocess.run(args,cwd=S,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    results.append(dict(label=label,argv=args,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode,stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace')))
    return p
empty=L/'_tmp/empty-file'; empty.write_bytes(b'')
run('new-record-whitespace',['git','diff','--no-index','--check',str(empty),str(S/'docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md')])
run('existing-record-whitespace',['git','diff','--check','--','docs/status/COMPLETION-PLAN.md','docs/status/CURRENT_VERSION.md','docs/work/v1.8.0-c18a-seal-detector/ADMISSION-TASK-03.md','docs/work/v1.8.0-implementation-log.md'])
run('committed-source-whitespace',['git','diff','--check','a2e3c476de0188c93c0de85bf005d4a0e02e3251','452fd2a0dc12895c2e2b955c80115457459888bb'])
run('launcher-eol-attribute',['git','check-attr','text','eol','--','gradlew.bat'])
run('private-head',['git','rev-parse','HEAD'])
run('private-status',['git','status','--porcelain=v1'])
head=run('private-src-tree',['git','rev-parse','HEAD:src'])
nested=[]
archive=L/'snapshots/docs/work/v1.8.0-c18a-seal-detector/ADMISSION-ROOT-03.zip'
with zipfile.ZipFile(archive) as z:
    import io
    for item in z.namelist():
        if item.endswith('unit-xml.zip'):
            with zipfile.ZipFile(io.BytesIO(z.read(item))) as inner:
                names=inner.namelist()
                bad=[n for n in names if pathlib.PurePosixPath(n).is_absolute() or '..' in pathlib.PurePosixPath(n).parts or ':' in n or '\\' in n]
                nested.append(dict(path=item,count=len(names),case_unique=len({n.casefold() for n in names})==len(names),unsafe=bad,crc_bad=inner.testzip(),largest_bytes=max(i.file_size for i in inner.infolist()),total_bytes=sum(i.file_size for i in inner.infolist())))
pre=json.loads((L/'PREIMAGES.json').read_text())['records']
snapshot_checks=[dict(path=r['path'],sha256_matches=hashlib.sha256((L/'snapshots'/r['path']).read_bytes()).hexdigest()==r['sha256']) for r in pre]
validator=subprocess.check_output(['git','show','HEAD:scripts/validate_repository.py'],cwd=S)
(L/'FINAL-STATIC.json').write_text(json.dumps(dict(commands=results,nested_archives=nested,snapshot_checks=snapshot_checks,validator_sha256=hashlib.sha256(validator).hexdigest(),validator_working_copy_unchanged=validator==(S/'scripts/validate_repository.py').read_bytes()),indent=2)+'\n')
print(json.dumps(dict(command_exits=[dict(label=r['label'],exit=r['exit']) for r in results],nested_archives=nested,snapshot_checks=snapshot_checks),indent=2))
sys.exit(1 if any(r['exit'] for r in results) or any(x['unsafe'] or x['crc_bad'] or not x['case_unique'] for x in nested) or not all(x['sha256_matches'] for x in snapshot_checks) else 0)
