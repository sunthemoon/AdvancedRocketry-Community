# Independent record review - C18a-SEAL-ADMISSION-03

## Findings first

No additional Critical, High, Medium or Low finding was identified in the exact
five pending records or their three admission archives. Their fixed-source,
command/result, original-finding, erratum and qualification-boundary claims are
corroborated within the evidence described below. This is a records-only review,
not a new source implementation, full item delivery or version acceptance.

**Reviewer execution limitation: cleanup was denied before its script loaded.**
The one Windows PowerShell launch exited 1 with an execution-policy
`UnauthorizedAccess` error. No preflight or deletion body ran. The exclusively
owned `_tmp` clone/extraction/check outputs remain unsealed and are excluded
from the bounded manifest. No retry, policy bypass or Root takeover occurs.
Consequently, the retained evidence satisfies the compact evidence budget, but
the entire working leaf does not; cleanup is not claimed complete.

The inherited strict Markdown failure and four native cohorts' 62 ERROR / zero
FATAL headers remain unwaived. These are retained limitations, not newly
introduced record findings or Gate passes. The original source's Medium remains
historically CHANGES_REQUESTED; its declared correction does not retroactively
change that verdict.

## Identity, read boundary and exact preimages

Reviewer: independent delegated Codex record reviewer. Only newly created files
under `D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02`
were written. No implementation edits, Claude, further delegation, OpenPet,
staging, commits, pushes, installation, global configuration changes or existing
checkout HEAD movement occurred.

Observed Main HEAD/branch:
`b001316102d064545fb81d9f4f2141ae52931118` /
`codex/v1.8.0-classic-content`. Main status/worktree inventory, actual pending
diff and Git history are retained under `logs/`. The five records and three
archives were copied byte-for-byte, hashed before/after copying, and rechecked
before releasing Main/source/HEAD/input interests at
**2026-10-09T00:51:44.121788+00:00**. Subsequent work used owned snapshots and a
private clone only. No later mutable Main state is substituted for these inputs.

| Pending record | Bytes | Exact preimage SHA-256 |
| --- | ---: | --- |
| `docs/work/v1.8.0-c18a-seal-detector/ADMISSION-TASK-03.md` | 7,682 | `806f4bdd6ba913f23581c9012b7dbe8343a0977ce474f32f5f0da73ff038f63e` |
| `docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md` | 11,837 | `e9eaf0b49ebc5fbe92c1474d3451891fd82cba34fe6811d0603a63bdbe68e435` |
| `docs/work/v1.8.0-implementation-log.md` | 527,497 | `aa365ccc6d7c6b1053b46b9574be54fe69c8f66539b4892cac9d5739d6748c3b` |
| `docs/status/CURRENT_VERSION.md` | 6,163 | `aa335b143bfedc614d04e2a9eff3e30db7221bcc243bbe62595c1e5e7cf0b0cc` |
| `docs/status/COMPLETION-PLAN.md` | 52,693 | `1b2c4d0fc7e5ba8842f6841e105a982198ecd15df9e79398c0aa0729788f4f24` |

[PREIMAGES.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/PREIMAGES.json) additionally identifies all three exact ZIP copies and excluded
user-owned dirty AGENTS.md (`c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`).
User work, inherited untracked files, unrelated worktrees and sealed evidence
were never edited/adopted/deleted. The prior interrupted reviewer leaf
`seal-admission-record-independent-20261009-01` was not read, retaken, edited,
deleted or represented as a completed review.

Read applicable AGENTS, identity/product, porting principles, roadmap, actual
v1.8 and v1.0 version documents, master tests, release Gates, post-1.0 roadmap,
quality budgets, parallel-worktree and provenance documents, accepted ADR-060
and ADR-067 revision 1, proposed ADR-068 and R-021. Acceptance stays v1.0.0;
active development stays v1.8.0 IN_PROGRESS / IMPLEMENTING.

## Source history and source-versus-record scope

Actual Git objects corroborate the chronology rather than merely the narrative:

- Preparation `771543514c0ccf6f09f22b62ba1d36e9a6d9b7f9` changes task/log/plan
  records after preparation base `9429d00b6b24e9bd7de3b747d63528b7b7d06fa1`.
- Original `e456ffc0eab1c0752fa5e6e57b4c63ddedbac964` adds only the 380-line,
  twelve-case main-source GameTest. Its src tree is
  `1661afb000ba80e2a4032076875f2afab9397e0d`.
- Corrective scope `a2e3c476de0188c93c0de85bf005d4a0e02e3251` predates
  correction; merge `c047d80551fa1af41fda24919ad85ed174618226` preserves the
  original and corrective histories.
- Corrected tested source `452fd2a0dc12895c2e2b955c80115457459888bb`, versus
  the scope base, adds exactly the 407-line GameTest and the 104-line four-case
  JUnit file. Existing production, registries, schemas, API, assets, provenance
  and ledger are unchanged.
- Integrated `b001316102d064545fb81d9f4f2141ae52931118` has the same complete
  src tree `f085b52691c4f72814566841f2d0ff69394a99e3` and seven Gradle blobs as
  corrected tested source. The candidate-to-integration differences are four
  documentation records only. The merge itself was not executed by any cohort
  or by this records reviewer.

[SOURCE-IDENTITIES.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/SOURCE-IDENTITIES.json) and [BUILD-INPUT-CONSISTENCY.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/BUILD-INPUT-CONSISTENCY.json) retain exact blobs,
canonical SHA-256 values and ancestor/diff results. All seven Gradle inputs have
one blob identity across the preparation/original/corrective/corrected/integrated
checkpoints. Independent archived pre-/post-native manifests contain 3,026
original and 3,027 corrected entries, with no unexplained discrepancy against
actual Git content. Their `gradlew.bat` working-byte hash differs from canonical
LF bytes solely by the repository's declared `eol=crlf` checkout conversion;
[GRADLEW-EOL.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/GRADLEW-EOL.json) preserves both identities. Neither seven-input identity nor
source identity is a claim to hash every transitive dependency/cache/toolchain.

The pending source/result and boundary statements are at
[ADMISSION-VERIFICATION-03.md:8-77](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/snapshots/docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md#L8-L77); state/source binding is at
[CURRENT_VERSION.md:40-79](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/snapshots/docs/status/CURRENT_VERSION.md#L40-L79); the scoped completed test checkbox is at
[COMPLETION-PLAN.md:418-427](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/snapshots/docs/status/COMPLETION-PLAN.md#L418-L427); the added historical result entry is at
[v1.8.0-implementation-log.md:57-71](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/snapshots/docs/work/v1.8.0-implementation-log.md#L57-L71). These lines distinguish committed source
from pending record publication and do not deliver a full item or accept a Gate.
Normal-push assertions are supported by retained integration/upstream/source
branch observations and cloned fixed history, not a new network push audit.

## Archive integrity, immutable correction and raw evidence

| Snapshot archive | Compressed bytes | ZIP files | Uncompressed bytes | SHA-256 |
| --- | ---: | ---: | ---: | --- |
| `ADMISSION-ROOT-03.zip` | 1,782,654 | 72 | 13,225,793 | `652bb7853b4151133498418a64a71370ec9ececc7850a9d226d4e72d13d020dc` |
| `ADMISSION-INDEPENDENT-03-ORIGINAL.zip` | 2,670,319 | 1,988 | 14,773,990 | `3ff42fa84c8388c71b76895aaa12a73dd848c76fc92b847f390ee01de99a8b88` |
| `ADMISSION-INDEPENDENT-03.zip` | 2,878,713 | 2,027 | 15,159,736 | `502a9a5fad8735237a0065c7ad28335a9c9d48651631fdd4e0ca7386e3320cb8` |

All CRCs pass, paths are safe relative names without traversal/symlink/case
collision, and each manifest completely and uniquely covers its payload:
71, 1,987 and 2,026 entries respectively, excluding itself. Nested Root unit XML
ZIPs separately pass CRC/path/case checks. [ARCHIVE-AUDIT.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/ARCHIVE-AUDIT.json) and inventories
retain independent observations. The three totals are 7,331,686 compressed and
43,159,519 uncompressed bytes; each payload file is below 50 MiB. No whole
source/build/world/JAR archive is part of their sealed payloads.

Report hashes independently match Root `09267e5ce426e564ae66dcf1fd950d1814efaca464549779f1fab449251728b8`,
original `75916e43b3dfd6db48a8b28b6181db2907f9f962b7565690c07a2a16018fc0be`
and corrected `9afc8530b24435aeb6791978bd3d370d660652fe30abd13cc3e7c44d2929e6f4`.
The new erratum is
`13597ddc308f52318951252368ee0b0fd571154c927139859c214ed70e309f71`;
the original manifest remains
`0351df93236de29d022400ef2547c90ac3236b2b8061323d305c774178c6718d`.
Original raw DataGen lines 196 and 191 independently show written 841 then 0,
not the original sealed narrative's 0 then 0. Empty-diff exits remain zero.
The correction is a new erratum in a distinct package, not an edited original
report, altered original source verdict or substituted cohort result.

Actual unit XML testcase elements corroborate 2,179 / 378 suites originally
and 2,183 / 379 corrected, at both actual forced build/test stages on both sides,
all zero failures/errors/skips. Raw actionable-task markers corroborate actual
execution. Later DataGen/native JUnit snapshots are not counted as new JUnit
executions. All four native raw latest logs independently schedule 565 tests in
147 batches, including 12 admission tests, contain the terminal all-565-required
pass marker and retain 62 ERROR / zero FATAL headers each. Console/debug copies
are not separate events. Root command log hashes/bytes match their command
records; exact argv/times/exits and failed setup/read/checker attempts remain
separate. [CORROBORATION.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/CORROBORATION.json) records these checks.

Corrected endpoint main/sources/API inventories agree across Root and independent
captures: 6,049,561 / 2,879,064 / 51,052 bytes and the three advertised hashes.
All nine compiled admission-class hashes match. Main contains the GameTest and
eight nested classes; sources contains its main-source file; API contains none.
Whole endpoint JARs were intentionally not retained and were not rebuilt here,
so this is independent inventory/provenance corroboration, not a new direct
endpoint-file hash or R1/S1/S2 execution.

The compiled original-helper witness is external unwinding-order evidence, not
an executed Minecraft cleanup body or ordinary detector hang. Corrected source
and retained disassembly put the same fixture-owned gate before both actual
closers; four actual unit cases execute the helper/gate. This supports only
retain-before-cleanup on unresolved workers, not automatic exceptional-world
recovery or installed lifecycle certification. Direct item-entry refusal,
embedded actors, uninstalled local handles, instrumented getters and controlled
post-query held replacement remain explicitly bounded, not V1/V2 or provider
authority proofs.

The archived Root pre-seal record check genuinely has 616 links / 49 inherited
errors / no introduced errors and a different exact two-document checkpoint.
It is not this final review's digest. [ADMISSION-VERIFICATION-03.md:154-158](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/snapshots/docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md#L154-L158)
correctly preserves that boundary.

## Commands actually executed by this reviewer

The executable is Python 3.13.15. Validation uses owned D-drive TEMP/TMP, no
dependency installation or global settings, and 300-second command bounds.
Recorded C/D free space before sustained commands exceeds 10 GiB. Full argv,
UTC boundaries, immediate exits and raw stdout/stderr are in
[VALIDATION-COMMANDS.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/VALIDATION-COMMANDS.json), [FOLLOWUP-COMMANDS.json](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-record-independent-resume-20261009-02/FOLLOWUP-COMMANDS.json) and matching log files.

| Actual command/check | UTC interval 2026-10-09 | Immediate child result |
| --- | --- | --- |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | 00:53:43.893756-00:53:44.171534 | 0; 653 units, 186 PLANNED / 154 REVIEW unchanged |
| `python -B scripts/validate_bootstrap_provenance.py --require-approved-review` | 00:53:44.173247-00:54:05.978426 | 0; accepted historical bootstrap, digest-bound approved review |
| Initial strict `--require-approved-identity` | 00:54:05.981011-00:58:06.464178 | 1; 44 PASS / one inherited Markdown failure; initial long-path setup limitation retained |
| Final strict `--require-approved-identity`, after owned input repair | 00:59:17.120284-01:03:18.262617 | 1; 44 PASS / one inherited Markdown failure; error traversal stops at 256 |
| `git -c core.longpaths=true diff --check` | 01:03:18.264953-01:03:18.337589 | 0; no stderr or whitespace diagnostics |
| Exact new-record patch `git apply --check --no-index --whitespace=error-all` | exact subsecond record in `NEW-RECORD-WHITESPACE.json` | 0; check only, no application |
| Unchanged-validator five-record Markdown check | 01:03:18.339415-01:03:19.480934 | 0; 617 links / no new target-error multiplicities |
| Actual Git source/input/history, XML/native/archive/artifact corroboration | individual records retained | completed checks 0; exploratory failures separately retained |
| Single native cleanup launcher | 01:03:42.969035-01:03:43.240128 | **1**, policy denied before script loading; zero deletion attempts |

Final focused errors are 62: the same 49 unsafe historical targets plus 13
inherited untracked archive targets intentionally absent from the private clone.
Baseline and reviewed copies have the same error-target multiplicities; none
are added. This is not a claim that Main has 62 errors or that the full strict
repository debt has only 256. Validator SHA-256 is unchanged:
`ff77ac86f500ce2f6c782d01084623746e87a653f76916ad1f04673683a950f2`.

No full Gradle, GameTest, native server, client or visual run was requested or
performed for this records-only scope. Archived cohorts are inspected, not
relabelled as this reviewer's new execution. No repository tests were added or
modified; only review scripts/checks and evidence were created.

### Reviewer-side failures and measurement limits

- Initial private checkout exited 0 but stderr reports 486 historical XML
  paths too long. Those missing owned clone inputs were restored only with
  per-command `core.longpaths=true`; HEAD and the five preimages stayed fixed.
  The repaired clone has no deleted inputs; strict/whitespace/focused checks
  were run afterward. No global configuration change occurred.
- Initial ZIP extraction exits 1 with a long-path `FileNotFoundError`. Raw
  stderr remains; the successful second audit reads XML inside ZIPs and copies
  only short inspection outputs. First-attempt child UTC boundaries were not
  separately instrumented and are not invented.
- The first corroboration command exits 1 after writing its JSON due to an
  `AttributeError` in presentation of a list as a mapping. Later successful
  invocations are distinct and retained; the failed command stays failed.
- A no-index diff of the new record exits 1 for a present diff, with empty
  stdout/stderr under `--check`; its enclosing ad hoc aggregator also exits 1.
  The distinct exact-patch whitespace check later exits 0. Neither earlier
  exit is silently changed to 0.
- Exploratory lookups of nonexistent lowercase version/guessed ADR filenames
  and not-yet-produced log filenames remain tool-observed lookup errors; actual
  documents were read afterward. Those shell explorations do not have separate
  child UTC intervals/full redirected transcripts. Prescribed validation and
  cleanup launches do have instrumented boundaries/raw outputs.

## Cleanup, manifest budget and outstanding obligations

Archived original Root, original independent and corrected independent cleanup
scripts/preflights/results support their three separate once-only removals of
owned ended outputs, with containment/reparse/process checks. This reviewer did
not repeat or take over those deletions. They are distinct from this reviewer's
denied cleanup launch.

At 01:04:28.1375726 UTC the entire new working leaf had **1,193,945,406 logical
bytes / 10,406 files**; its largest file was the unsealed private Git pack,
438,766,868 bytes. `_tmp` remains, and `CLEANUP-PREFLIGHT.json` does not exist
because the cleanup body never ran. `CLEANUP-LIMITATION.json` records the actual
measurement. No physical-reclaimed-space or completed-cleanup claim is made.

Root explicitly instructed retaining denied targets/raw evidence and finalizing
only a bounded report/manifest excluding `_tmp`, with no retry/takeover. The
manifest therefore seals **only files outside `_tmp`**, not the whole working
leaf. `SEAL-RESULT.json` gives the exact retained payload count/bytes/largest file
and manifest/report digests. It is an external seal summary, deliberately not
self-hashed. The three exact ZIP preimages, five document preimages, raw errors,
command records and compact observations are covered; no temporary source,
build, world, cache or whole JAR is included. Retained evidence is checked below
100 MiB total / 50 MiB per file. Unsealed pending temporary bytes are reported
separately, not hidden as an admissible whole-leaf size.

Record scope is reviewed without an introduced finding; cleanup is unfinished.
All G0-G9 remain open. Exhaustive detector/query-order/installed precedence and
lifecycle, unlock/acquisition, protection mods, packaged restart/recovery,
real-client V1/V2, compatibility/performance and human acceptance remain outside
this review. ADR-068 stays PROPOSED, R-021 unaccepted/open, physical hatch/hook/
save writer and unchosen owner policies remain disabled. The prior slice's Low
preparation timing deviation is not waived.

Suggested continuation is limited to explicit record-review/packaging metadata
for this v1.8 slice, with the cleanup denial retained, and the remaining v1.8
obligations. No version PASSED/RELEASED, full ledger delivery, tag or later-version
implementation follows. **All Main/source/HEAD/input/read/process interests are
released; no existing checkout or process is reserved by this reviewer.**
