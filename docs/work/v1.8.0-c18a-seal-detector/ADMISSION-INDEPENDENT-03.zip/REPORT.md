# Independent corrected review — C18a-SEAL-ADMISSION-03

## Findings first

Actual-diff review of the corrected two-source-file scope found **no additional Critical, High, Medium or Low source finding**. The original Medium is addressed for the corrected declared worker-retention contract, as detailed below. This is not version Gate approval: the independently executed strict repository checker still exits **1**, and the native cohort's **62 ERROR / 0 FATAL** records remain unwaived.

### Original Medium finding and corrected contract

The original `e456ffc0eab1c0752fa5e6e57b4c63ddedbac964` review found that a worker surviving cancellation/join could unwind into resource cleanup while still alive. That original report remains sealed, CHANGES_REQUESTED and unchanged. Its REPORT SHA-256 is `75916e43b3dfd6db48a8b28b6181db2907f9f962b7565690c07a2a16018fc0be`; manifest SHA-256 is `0351df93236de29d022400ef2547c90ac3236b2b8061323d305c774178c6718d`. The original package has 1,987 payload entries plus its manifest, not 1,987 total files. No original result is rebound to the correction.

At corrected `SealDetectorAdmissionGameTests.java:207–218`, the local reader takes the fixture's exact worker gate and checks it **before** service closure or manager clearing. At lines 317–318, the fixture checks that same gate **before** removing actors, closing channels or restoring cells. Both off-thread paths pass the fixture-owned gate (lines 170 and 309). `WorkerGate` (lines 371–385) refuses a new worker while its prior worker is nonterminal and refuses cleanup unless its current owned thread is TERMINATED. The helper's two-second FutureTask wait, two-second join and all native 20-tick limits remain unchanged (lines 388–399).

Independent disassembly of the actual compiled `Fixture.close` and `LocalReader.close` confirms `WorkerGate.requireStopped()` is the first cleanup action, before other mutable-resource access. The independently executed four-case unit suite tests the actual helper/gate: completion, callable-failure cause preservation, a non-cooperative survivor preventing a modeled resource close with the refusal retained as a suppressed exception, and no replacement of a live owned worker. Diagnostic threads are explicitly released and joined in `finally`; terminal-state recovery then permits the modeled close. These tests do not instantiate a Minecraft fixture under an injected timeout, and they do not prove automatic native-world recovery.

This repairs the original cleanup-order defect for the declared **retain-on-unresolved-worker** contract. A retained exceptional fixture may keep actors/cells/local handles until the disposable test host ends; no automatic recovery, poller, forced thread stop or production lifecycle hook is added or claimed. Normal native checks must still terminate before cleanup. The helper's survivor exception can supersede an earlier timeout wrapper; the completed callable-failure case's cause-preservation assertion is not a claim about every exceptional timeout combination.

### Original sealed narrative counter correction

`ORIGINAL-REPORT-ERRATUM-01.md` corrects one factual statement in the original sealed report without editing it. The original independent first DataGen actually reports written **841**, not its table's written 0; the second reports 0, and both original diffs are empty with exit 0. This was verified from the original sealed raw logs and their hashes, separately from corrected-candidate results. The original Medium, command exits, testcase/native counts and CHANGES_REQUESTED disposition are unchanged. The original immutable report must be read with this new erratum when using its DataGen table.

## Identity, actual diff and authority

- Independent delegated read-only Codex reviewer. No Claude call, further delegation, implementation edit, installation, staging/commit/push or main/source HEAD move.
- Corrected candidate: `452fd2a0dc12895c2e2b955c80115457459888bb`; `HEAD:src` is `f085b52691c4f72814566841f2d0ff69394a99e3`.
- Scope base: `a2e3c476de0188c93c0de85bf005d4a0e02e3251`. Actual diff versus this base adds exactly the 407-line GameTest class and the 104-line four-case `src/test/.../SealDetectorAdmissionWorkerGateTest.java`. Versus original e456, the source change is the declared worker-ownership/cleanup correction plus that new unit file; a docs-only scope merge precedes authoring. No production/item/service/build/registry/API/schema/resource/ledger file changes.
- Current main checkpoint `96a943437ea63e5e0b8e0ee7431632fc520d7065` and its preparation/log/active-plan records were read. Its implementation-log lines 3–55 and active-plan lines 418–426 record preparation, original finding/results, corrective scope and pending independent review distinctly. Corrected-source ADMISSION-TASK-03 was also read; its corrective scope was committed at a2e3c476 before corrected authoring. Original preparation 77154351 precedes original source. Main records acknowledge the original Medium and failures, keep both candidates distinct and make no delivery or Gate claim. Exact fixed-commit document outputs are retained, not inferred from current mutable HEAD.
- Applicable AGENTS/governance/version/quality/provenance documents, accepted ADR-060 and ADR-067 revision 1 and adjacent item/service/player/runtime/discovery/build contracts were reviewed in the original review and checked against the corrected fixed diff. Relevant unchanged authority: acceptance cursor v1.0.0; active v1.8.0 IN_PROGRESS / IMPLEMENTING; G0–G9 remain required; ADR-068 is not accepted and R-021 is not closed.
- User-owned dirty AGENTS.md, inherited untracked files and other worktrees are excluded. Existing main/source were read with optional Git locks disabled; all remaining execution uses a new detached disposable clone in this distinct leaf. Existing source is running Root's fixed cohort and was never written or moved by the reviewer.
- Write scope is only newly created files beneath `D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-independent-correction-20261009-02`; original sealed evidence is read-only. Main/source read/HEAD interests were released after static review.

## Qualification and unchanged test scope

All original 12 bounded GameTests remain. Nine directly call the actual registered item entry to qualify stack count/identity, spectator/dead/removed/missing-connection actors, foreign Level, stale same-UUID PlayerList identity and off-thread refusal. Native game-mode positive controls use ordinary embedded connected survival players, exact structured component JSON and overlay checks, peer silence and an unmasked cooldown. Refusals assert FAIL, no selected position/face/hit access, no feedback/cooldown, both held-stack identities/data and installed manager metrics.

Three local-service cases remain explicitly **uninstalled**: terminal/idempotent closure, off-thread refusal and controlled post-query held identity replacement. The callback is an owned context accessor, with a fresh local manager's metrics transition witnessing the supply query; it is not a native provider/client callback or installed replacement catalog. Local admitted readings are SEALED / NOT_KNOWN_SUPPLIED, not oxygen-provider certification. The probe instruments actor, Level and selected position/face/hit getters, not every possible context accessor.

Normal fixtures use only two loaded, BE-free owned cells and verify restoration, own both embedded channels and remove only their own PlayerList identities. The registered item, production admission/query code, installed runtime, both real-hand support and shared cooldown are unchanged. Native annotations still use existing namespace-wide discovery. Main-source GameTests and their nested worker gate enter the normal JAR as declared; the new JUnit file is not production source or public API.

Non-goals remain: exhaustive Level/chunk/cell/query-order, installed precedence/reload/unload/protection mods, installed stop/restart, packaged S1/S2, true-client V1/V2, automatic failed-fixture recovery, oxygen/resource/acquisition authority, physical hatch/hook/save writer and owner-policy decisions. No item/ledger unit or version Required Gate is delivered by this review.

## Actual independent commands and results

All prescribed commands below were independently executed in the corrected detached private clone, not borrowed from Root or the original cohort. Per-command `retained/*.json` records contain actual argv, cwd, UTC start/end, immediate child exit and both disks' free space; matching `logs/*.log` files retain combined raw stdout/stderr. `retained/command-results.json` consolidates the command records. Runner exit 0 means the sequence ended, **not** that strict exit 1 passed.

Java is explicitly selected Oracle JDK 17.0.7+8-LTS-224 from `C:/Program Files/Java/jdk-17.0.7`; Gradle 8.8, copied ForgeGradle cache 6.0.54, Forge 47.4.10 and official Minecraft 1.20.1 mappings remain unchanged. New local clone/checkout setup exits 0 at aggregate UTC 17:18:08–17:18:19. Local/per-command `core.longpaths=true` applies only to the new clone. Copying installed `caches`, `wrapper`, `native` and `jdks` into the private Gradle home uses `robocopy /E /XJ /R:0 /W:0 /XF *.lock *.lck /NFL /NDL /NJH /NJS`, UTC 17:18:34–17:19:12; each actual Robocopy child exits 1, its copied-files success result. Setup records retain aggregate times/source/destination/parameters/child results, not separate per-child UTC intervals or a full initial shell transcript. No original cache, global setting or installed software is changed.

Every Gradle invocation uses this actual argv prefix, followed only by the listed task arguments:

```text
cmd.exe /d /c gradlew.bat --offline --no-daemon --no-build-cache --rerun-tasks
-Dorg.gradle.workers.max=2
-Dorg.gradle.java.home=C:\Program Files\Java\jdk-17.0.7
-Dorg.gradle.jvmargs=-Xmx3G -Djava.io.tmpdir=<this leaf>\tmp
```

The last JVM setting is one argument in the retained argv array. GRADLE_USER_HOME, TEMP, TMP and JAVA_TOOL_OPTIONS use the newly owned D-drive leaf. Both drives exceed 10 GiB before every sustained command; the minimum recorded C-drive free space remains above 30 billion bytes. No candidate assertion, two-second wait/join, 20-tick timeout, scan limit or service budget is changed.

| Actual command/tasks | UTC interval on 2026-10-08 | Child exit | Independent result |
| --- | --- | --- | --- |
| Gradle `clean build` | 17:20:03–17:24:09 | 0 | 20 tasks executed; **2,183 actual JUnit testcase elements / 379 XML suites / 0 failures, errors or skips** |
| Gradle explicit `test` | 17:24:10–17:28:40 | 0 | 17 tasks executed; fresh **2,183 / 379 / 0 F/E/S** |
| First Gradle `runData` | 17:28:40–17:29:48 | 0 | HashCache total 841, old count 0, written **841**; outputs are byte-identical to tracked files |
| First separate `git diff --exit-code` | 17:29:48–17:29:49 | 0 | Empty tracked diff and raw output |
| Second Gradle `runData` | 17:29:49–17:30:57 | 0 | HashCache total 841, old count 841, written **0** |
| Second separate `git diff --exit-code` | 17:30:57 | 0 | Empty tracked diff and raw output |
| Unfiltered Gradle `runGameTestServer` | 17:30:57–17:36:49 | 0 | 18 tasks executed; **565 scheduled / 565 required passed**, 147 batches; admission batch 12 |
| `python scripts/validate_v180_content_ledger.py --require-accepted` | 17:36:49 | 0 | 653 units; 186 PLANNED / 154 asset REVIEW remain, no delivery claim |
| `python scripts/validate_bootstrap_provenance.py --require-approved-review` | 17:36:49–17:37:16 | 0 | Mechanical checks and digest-bound THIRD_PARTY_APPROVED review pass |
| `python scripts/validate_repository.py --require-approved-identity` | 17:37:16–17:42:10 | **1** | **44 passed / 1 failed**, Broken Markdown links; stops after 256 errors, not an exhaustive debt count |
| `git diff --check a2e3c476... HEAD` | 17:42:10 | 0 | No whitespace errors in actual committed scope |
| Initial/final status, HEAD/source-tree identity, final diff, candidate/scope/original-correction stat/patch and fixed-commit document queries | exact subsecond intervals in individual records | 0 each | Private clone clean; candidate/source identity unchanged; exact two-source-file scope |
| Selected `java -version` | 17:20:02 | 0 | Actual Oracle Java 17 binary |
| Actual nested Fixture/LocalReader/WorkerGate `javap -p -c` | 17:22:36 | 0 | Both compiled closers gate before mutable cleanup; actual owned-thread terminal-state comparison |
| Original sealed-counter audit | 17:41:26 | 0 | Original report/manifest hashes unchanged; original raw counter error documented separately |
| Independent XML/artifact/source-input/native recount | 17:42:25–17:42:28 | 0 each | Actual testcase-element totals and terminal native marker checked separately |
| Native-context/strict/DataGen/command summary | individual record retains UTC interval | 0 | Runtime-only unwaived context and separate documentary matches retained |
| Packaging inventory attempt 01 | UTC/child exit not captured | **setup failure** | Nested shell quoting yields retained Python SyntaxError before inspection starts; enclosing shell later exits 0, not a successful inventory |
| Packaging inventory attempt 02 | 17:44:39 | 0 | Normal JAR includes nine admission classes; no worker-gate JUnit class in main/API/sources JAR |
| Original raw-log manifest audit after cleanup | 17:49:54–17:49:55 | 0 | Both observed original DataGen raw logs match their original sealed manifest entries |
| Post-cleanup retained-result/command consolidation | individual record retains exact UTC interval | 0 | Includes successful cleanup and all independent validation/setup records without reading deleted build output |
| One native PowerShell cleanup invocation | 17:48:26–17:48:47 | 0 | Three exclusively owned outputs removed once after preflight; no denied retry |

The new worker-gate suite is actually recounted as four testcase elements in both clean-build and explicit-test XML. Its deliberately non-cooperative helper case takes 4.026s and 4.014s respectively, with zero cleanup before worker termination, one suppressed gate refusal, and explicit release/join in `finally`; all four cases have 0 F/E/S. Precise unit source references are `SealDetectorAdmissionWorkerGateTest.java:12–34` for completion/cause and `:37–87` for unresolved cleanup/no replacement; bounded diagnostic joining is `:99–102`.

JUnit XML snapshots retained after DataGen/native are copies of the already completed explicit test task, **not additional JUnit executions**. Native results come from scheduled-batch recount and the terminal marker in the native raw log; this run produces no native GameTest XML reporter output. No packaged JAR S1/S2 or true-client run is inferred from dev-classpath native execution.

Native latest/console/debug each record the same **62 ERROR / 0 FATAL**, not 186 distinct events. Runtime-only line-numbered context is `retained/UNWAIVED-NATIVE-ERROR-FATAL-CONTEXT.txt`; the broader context file also preserves documentary mentions, which are explicitly not runtime errors. Native failures include migration binding/save, recipe-definition rejection, satellite failure and compatibility-rejection fixtures. Intentional fixture context is **not a waiver**. Strict raw output SHA-256 is `5af00089550e59579d9ff73c08d3a919a0cf66857915a5f4ee2729b54dd60ea0`; native latest SHA-256 is `8d874360a3e63535e8e29b258497d2bcea98f7aab458f632da7432add22e66ef`. No source correction is made for these separate obligations.

One exploratory read of absent log filenames exits 1; intended setup logs exist under `clone.log`, `checkout.log`, `cache-copy.log`. Its observation/command is retained separately; UTC interval/full exploratory stdout were not independently redirected. The packaging quoting failure also has an explicit missing child-exit/timing boundary rather than a manufactured success. A later ad hoc consolidated-record presentation verifier exits 1 on a non-command list row; type-filtered reconstruction uses the authoritative standalone records instead, and the failure/observation is retained. Its separate child exit/UTC interval was not instrumented. These reviewer-side setup/read/checker limitations do not alter any prescribed cohort child result; no failure is reclassified as a candidate pass.

## Source, build-input and artifact provenance

The inspected **3,020 source files plus seven build inputs = 3,027 entries** are unchanged across the retained pre-/post-native manifests. Both manifest-file SHA-256 values are `5cc79644d0503e60fd83683275840df99dd5731e2b9e67ec3ac6ab0a8be8bd5a`; changed entries are empty. The seven build files are build.gradle, settings.gradle, gradle.properties, both wrapper launchers, wrapper JAR and wrapper properties; this is not a claim to hash every transitive toolchain/cache dependency. Final tracked diff/status are empty; HEAD and `HEAD:src` match the fixed candidate identities.

- Main JAR: **6,049,561 bytes**, SHA-256 `865ba5e264cc19a964959ab7ed9c0c0d05b7c9ac9d091ef2e919d285c9a9f019`.
- API JAR: **51,052 bytes**, SHA-256 `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
- Sources JAR: **2,879,064 bytes**, SHA-256 `d4c2cc5e3d1a21b83857ac5aac36bf97b648858045e363e93a432a901a746415`.
- Corrected GameTest source SHA-256: `ecaa52044be332952c368fee6360152a23242b87b641bff06baeb4ee0cb69b42`.
- New worker-gate unit source SHA-256: `c85d210b3b8522761aabce47d3414b48c860085437f62633199fe50f36a58630`.

Actual compiled admission class identities and JAR entry inventory are retained separately. The normal JAR contains the GameTest class plus eight nested classes, including WorkerGate; the sources JAR contains only its main-source Java file, and API JAR contains none. The new JUnit class is not packaged in those JARs. Main/API artifacts are last generated by the forced explicit-test task dependencies; sources JAR is from clean build, with unchanged source throughout. Later DataGen/native tasks do not produce JARs. No separate packaged-runtime or reproducible-release R1 certification is claimed. Whole JAR/source/build/world trees are deliberately not retained.

## Remaining risks and Gate status

Original evidence/finding is preserved separately, with the new counter erratum rather than an edit to its sealed report. The corrected source's retain-on-unresolved-worker contract is not installed recovery certification. Native ERROR/FATAL obligations, strict repository/link debt, packaged persistence/recovery, real-client acceptance, performance/compatibility and human version approval remain separate from this scoped correction. The full version Required Gates are **not satisfied**; no Gate approval or full item/ledger delivery is requested or assigned.

## Evidence, cleanup and released interests

Completed scope: independent corrected actual-diff/adjacent-contract review; unchanged worker-budget and actual compiled-closer inspection; fixed-candidate forced clean build, explicit unit execution, twice DataGen/separate empty diffs, unfiltered native, ledger/provenance/strict/whitespace; own testcase/error/artifact/input recounts; original finding disposition and narrative erratum. The reviewer modifies no repository implementation or tests. Candidate additions are the declared twelve-case main-source GameTest and four-case JUnit file; only new external evidence/tools are reviewer writes.

Uncompleted/non-goals: exhaustive detector/installed lifecycle qualification, unresolved native ERROR and strict-link obligations, automatic exceptional fixture recovery, S1/S2, V1/V2 and full version Required Gates. Key design decision reviewed is fixture-owned terminal-state refusal **before** both cleanup bodies, with retained exceptional fixtures rather than a forced stop or budget extension. Recommendation is limited to remaining v1.8 slice evidence/obligations; no next-version implementation or delivery/Gate conclusion follows.

Cleanup completed once, native PowerShell exit 0, ending at **2026-10-08T17:48:47.0027521Z**. Preflight verifies exact leaf identity, resolved absolute containment, reparse-free ancestors/roots/descendants, exclusive creation ownership and zero active owned Java/Python/cmd processes. Only the new disposable checkout (15,597 files), copied private Gradle home (17,738 files) and own TEMP (two files) are removed; all three removals succeed. No denied retry, cross-shell deletion, install, source-world input deletion, existing-worktree retirement or other-agent cleanup occurs. `logs/cleanup.log`, `retained/cleanup-preflight.json` and `retained/cleanup-command.json` retain targets/times/outcomes. Post-cleanup inspections read only retained evidence and original immutable log inputs.

The compact retained evidence is sealed using relative `SHA256SUMS.txt` entries. No whole source/build/world tree or JAR is archived. At sealing, every payload file is checked below 50 MB and the complete leaf below 100 MB; actual inventory/manifest digests are reported to Root after sealing rather than recursively placed inside their own hashed report. Original sealed files remain unchanged; the new original-counter erratum accompanies this distinct corrected evidence.

**All main/source/original-review/HEAD/read/process interests are released.** No existing checkout or other-agent process is reserved by this reviewer. The report's fixed commit references remain historical source identities, not a request to keep HEAD pinned. Full Required Gate approval remains outside this review.
