import json
import pathlib
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
data = {}
for path in sorted((LEAF / 'checkout/build/libs').glob('*.jar')):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
    data[path.name] = {
        'admission_entries': [name for name in names if 'SealDetectorAdmission' in name],
        'worker_unit_packaged': any('SealDetectorAdmissionWorkerGateTest' in name for name in names)
    }
(LEAF / 'retained/jar-packaging-inventory.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
