import hashlib
import json
import pathlib
import re

LEAF = pathlib.Path(__file__).resolve().parent
native = LEAF / 'retained/gametest-gametest-logs/latest.log'
lines = native.read_text(encoding='utf-8', errors='replace').splitlines()
matched = [i for i, line in enumerate(lines) if re.search(r'/(?:ERROR|FATAL)\]', line)]
indices = sorted({j for i in matched for j in range(max(0, i - 3), min(len(lines), i + 10))})
header = 'Native source: retained/gametest-gametest-logs/latest.log\n62 ERROR / 0 FATAL are unwaived. Console/debug copies and documentary mentions are not additional native events.\n\n'
(LEAF / 'retained/UNWAIVED-NATIVE-ERROR-FATAL-CONTEXT.txt').write_text(header + '\n'.join(str(i + 1) + ': ' + lines[i] for i in indices), encoding='utf-8')
assert sum('/ERROR]' in lines[i] for i in matched) == 62
assert sum('/FATAL]' in lines[i] for i in matched) == 0
strict = LEAF / 'logs/strict-repository.log'
raw = strict.read_bytes()
text = raw.decode('utf-8', errors='replace')
summary = re.search(r'Summary: (\d+) passed, (\d+) pending, (\d+) warnings, (\d+) failed', text)
assert summary is not None
value = {
    'source': strict.relative_to(LEAF).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest(),
    'summary': dict(zip(('passed', 'pending', 'warnings', 'failed'), map(int, summary.groups()))),
    'failures': [line.split(':', 1)[0] for line in text.splitlines() if line.startswith('[FAIL]')],
    'markdown_error_cap': 256 if 'Markdown validation stopped after 256 errors' in text else None,
    'cap_is_not_total_debt': True
}
(LEAF / 'retained/strict-result.json').write_text(json.dumps(value, indent=2), encoding='utf-8')
data = {}
for name in ('data-01', 'data-02'):
    log = LEAF / 'logs' / (name + '.log')
    content = log.read_bytes()
    counters = [line for line in content.decode('utf-8', errors='replace').splitlines() if '[minecraft/HashCache]' in line]
    data[name] = {'log_sha256': hashlib.sha256(content).hexdigest(), 'counter_lines': counters,
                  'empty_diff': json.loads((LEAF / 'retained' / (name + '-empty-diff.json')).read_text())}
(LEAF / 'retained/datagen-results.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
records = []
for path in sorted((LEAF / 'retained').glob('*.json')):
    if path.name == 'command-results.json':
        continue
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    if isinstance(value, dict) and ('argv' in value or 'clone_exit' in value or 'tool_command' in value):
        records.append({'record': path.relative_to(LEAF).as_posix(), **value})
(LEAF / 'retained/command-results.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
print(json.dumps(json.loads((LEAF / 'retained/strict-result.json').read_text()), indent=2))
print(json.dumps(data, indent=2))
print('pre-cleanup_command_records=' + str(len(records)))
