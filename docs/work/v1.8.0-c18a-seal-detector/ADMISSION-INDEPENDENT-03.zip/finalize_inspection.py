import hashlib
import json
import pathlib
import re
import shutil
import xml.etree.ElementTree as ET

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = LEAF / 'checkout'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (LEAF / 'retained' / name).write_text(json.dumps(value, indent=2, sort_keys=True), encoding='utf-8')

native = LEAF / 'retained/gametest-gametest-logs/latest.log'
text = native.read_text(encoding='utf-8', errors='replace')
batches = [(name, int(count)) for name, count in re.findall(r"Running test batch '([^']+)' \((\d+) tests\)", text)]
passed = re.findall(r'All (\d+) required tests passed', text)
save('native-result.json', {
    'source': native.relative_to(LEAF).as_posix(),
    'source_sha256': sha(native),
    'batch_count': len(batches),
    'scheduled_tests': sum(count for _, count in batches),
    'required_passed_terminal_markers': [int(value) for value in passed],
    'admission_batches': [(name, count) for name, count in batches if 'seal_detector_admission' in name],
    'error_records': len(re.findall(r'/ERROR\]', text)),
    'fatal_records': len(re.findall(r'/FATAL\]', text)),
    'all_batches': batches,
    'native_xml_files': [p.relative_to(ROOT).as_posix() for p in (ROOT / 'build/gametest').rglob('*.xml')],
    'claim_boundary': 'Native results are the scheduled-batch recount and terminal required-test marker, not inherited JUnit XML snapshots.'
})
properties = ROOT / 'build/gametest/server.properties'
if properties.is_file():
    shutil.copy2(properties, LEAF / 'retained/native-server.properties')
before = json.loads((LEAF / 'retained/source-input-pre-native-sha256.json').read_text())
after = json.loads((LEAF / 'retained/source-input-sha256.json').read_text())
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
save('source-input-comparison.json', {
    'before_entries': len(before), 'after_entries': len(after),
    'source_entries': sum(name.startswith('src/') for name in after),
    'build_input_entries': sum(not name.startswith('src/') for name in after),
    'changed_entries': changed,
    'before_manifest_sha256': sha(LEAF / 'retained/source-input-pre-native-sha256.json'),
    'after_manifest_sha256': sha(LEAF / 'retained/source-input-sha256.json')
})
unit = {}
for cohort in ('clean-build', 'explicit-test'):
    file = LEAF / 'retained' / (cohort + '-junit') / 'TEST-io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.SealDetectorAdmissionWorkerGateTest.xml'
    suite = ET.parse(file).getroot()
    cases = list(suite.iter('testcase'))
    unit[cohort] = {
        'relative_xml': file.relative_to(LEAF).as_posix(), 'sha256': sha(file),
        'actual_testcases': len(cases), 'suite_attributes': suite.attrib,
        'cases': [{'name': case.attrib['name'], 'time': case.attrib.get('time'),
                   'failure': case.find('failure') is not None,
                   'error': case.find('error') is not None,
                   'skipped': case.find('skipped') is not None} for case in cases]
    }
save('worker-gate-unit-recount.json', unit)
classes = {}
for path in sorted((ROOT / 'build/classes/java/main').rglob('SealDetectorAdmissionGameTests*.class')):
    classes[path.relative_to(ROOT).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
save('actual-admission-class-identities.json', classes)
print(json.dumps(json.loads((LEAF / 'retained/native-result.json').read_text()), indent=2))
print(json.dumps(json.loads((LEAF / 'retained/source-input-comparison.json').read_text()), indent=2))
print(json.dumps(unit, indent=2))
