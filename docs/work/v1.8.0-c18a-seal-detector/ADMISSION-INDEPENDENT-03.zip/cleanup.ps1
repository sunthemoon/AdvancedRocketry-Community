$ErrorActionPreference = 'Stop'
$leaf = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\', '/')
$expectedLeaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-independent-correction-20261009-02').TrimEnd('\', '/')
if ($leaf -ne $expectedLeaf) { throw 'Cleanup leaf mismatch' }
$ancestor = $leaf
while ($ancestor) {
    $entry = Get-Item -LiteralPath $ancestor -Force
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Reparse ancestor: ' + $ancestor) }
    $ancestor = [IO.Path]::GetDirectoryName($ancestor)
}
$owned = @('checkout', 'gradle-home', 'tmp')
$start = [DateTime]::UtcNow.ToString('o')
$all = @(Get-CimInstance Win32_Process)
$active = @($all | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and
    ($_.Name -match '^(java|javaw|python|python3|cmd)\.exe$') -and
    ($_.CommandLine.Contains($leaf) -or $_.CommandLine.Contains($leaf.Replace('\','/')))
})
$active | Select-Object ProcessId,ParentProcessId,Name,CommandLine |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $leaf 'retained/cleanup-active-processes.json')
if ($active.Count -ne 0) { throw 'Owned-leaf process is still active; no cleanup attempted' }
$targets = @()
foreach ($name in $owned) {
    $full = [IO.Path]::GetFullPath((Join-Path $leaf $name)).TrimEnd('\', '/')
    if (-not $full.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup containment failure' }
    if (-not (Test-Path -LiteralPath $full)) { throw ('Expected owned output missing: ' + $name) }
    $item = Get-Item -LiteralPath $full -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Reparse root: ' + $name) }
    $entries = @(Get-ChildItem -LiteralPath $full -Recurse -Force)
    $reparse = @($entries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
    if ($reparse.Count -ne 0) { throw ('Reparse descendants: ' + $name) }
    $targets += [pscustomobject]@{ name=$name; absolute=$full; files=@($entries | Where-Object {-not $_.PSIsContainer}).Count; reparse=0 }
}
@{ start_utc=$start; leaf=$leaf; ownership='New outputs created exclusively by independent review agent'; targets=$targets; active_owned_processes=0 } |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $leaf 'retained/cleanup-preflight.json')
foreach ($target in $targets) {
    # One native PowerShell deletion attempt per verified target; errors stop execution, with no retries.
    Remove-Item -LiteralPath $target.absolute -Recurse -Force
    if (Test-Path -LiteralPath $target.absolute) { throw ('Owned target remains: ' + $target.name) }
    Write-Output ('REMOVED ' + $target.absolute)
}
Write-Output ('END_UTC ' + [DateTime]::UtcNow.ToString('o'))
