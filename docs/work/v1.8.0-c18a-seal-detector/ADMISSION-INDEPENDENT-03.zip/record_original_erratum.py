import hashlib
import json
import pathlib

LEAF = pathlib.Path(__file__).resolve().parent
ORIGINAL = LEAF.parent / 'seal-admission-independent-20261009-01'
expected = {
    'REPORT.md': '75916e43b3dfd6db48a8b28b6181db2907f9f962b7565690c07a2a16018fc0be',
    'SHA256SUMS.txt': '0351df93236de29d022400ef2547c90ac3236b2b8061323d305c774178c6718d'
}
record = {'original_candidate': 'e456ffc0eab1c0752fa5e6e57b4c63ddedbac964',
          'original_leaf': str(ORIGINAL), 'original_seal': {}, 'observations': {}}
sealed = {}
for line in (ORIGINAL / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    value, name = line.split('  ', 1)
    sealed[name] = value
for name, wanted in expected.items():
    actual = hashlib.sha256((ORIGINAL / name).read_bytes()).hexdigest()
    assert actual == wanted, name + ' changed'
    record['original_seal'][name] = actual
for name in ('data-01', 'data-02'):
    log = ORIGINAL / 'logs' / (name + '.log')
    data = log.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == sealed[log.relative_to(ORIGINAL).as_posix()], 'Original log does not match seal'
    lines = data.decode('utf-8', errors='replace').splitlines()
    counters = [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if '[minecraft/HashCache]' in line]
    diff = ORIGINAL / 'logs' / (name + '-empty-diff.log')
    result = json.loads((ORIGINAL / 'retained' / (name + '-empty-diff.json')).read_text())
    record['observations'][name] = {
        'log_sha256': digest, 'log_matches_original_manifest': True, 'hashcache_lines': counters,
        'diff_log_bytes': diff.stat().st_size, 'diff_exit': result['exit_code'],
        'diff_log_sha256': hashlib.sha256(diff.read_bytes()).hexdigest()
    }
(LEAF / 'retained/original-datagen-counter-observation.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record, indent=2))
