# Original independent report erratum 01 — DataGen counter

This is a new correction record; no original sealed file is edited. It applies only to the original independent e456ffc0eab1c0752fa5e6e57b4c63ddedbac964 report at sibling `seal-admission-independent-20261009-01/REPORT.md`, SHA-256 `75916e43b3dfd6db48a8b28b6181db2907f9f962b7565690c07a2a16018fc0be`, whose unchanged manifest SHA-256 is `0351df93236de29d022400ef2547c90ac3236b2b8061323d305c774178c6718d`.

The original execution table incorrectly states that its first DataGen wrote zero files. Its own sealed `logs/data-01.log`, line 196, actually records:

```text
[00:58:32] [main/INFO] [minecraft/HashCache]: Caching: total files: 841, old count: 0, new count: 842, removed stale: 0, written: 841
```

Its second `logs/data-02.log`, line 191, records:

```text
[00:59:38] [main/INFO] [minecraft/HashCache]: Caching: total files: 841, old count: 841, new count: 842, removed stale: 0, written: 0
```

Both original separate `git diff --exit-code` executions still exit zero with empty raw output. The first run regenerates byte-identical tracked outputs from an empty HashCache; the second writes none. This correction changes neither any actual command result nor the source finding, JUnit/native counts, original CHANGES_REQUESTED disposition or original-candidate identity. No corrected-candidate result is substituted for original evidence.

The discrepancy was discovered by rereading the original raw logs during the distinct corrected review. The sealed narrative used an inaccurate counter summary; the raw retained evidence was correct. `retained/original-datagen-counter-observation.json` records the source log hashes, exact counter lines, original seal hashes and empty-diff exits. This erratum is sealed only in the new corrected evidence leaf and must accompany any use of the original report's DataGen table.
