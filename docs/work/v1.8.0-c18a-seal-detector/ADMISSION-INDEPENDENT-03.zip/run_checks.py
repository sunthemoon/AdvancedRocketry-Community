import datetime
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = LEAF / 'checkout'
JAVA = pathlib.Path('C:/Program Files/Java/jdk-17.0.7')
ENV = os.environ.copy()
ENV.update(JAVA_HOME=str(JAVA), GRADLE_USER_HOME=str(LEAF / 'gradle-home'),
           TEMP=str(LEAF / 'tmp'), TMP=str(LEAF / 'tmp'),
           JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=' + str(LEAF / 'tmp'),
           PYTHONDONTWRITEBYTECODE='1')
ENV['PATH'] = str(JAVA / 'bin') + os.pathsep + ENV['PATH']

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(name, argv, timeout=1800):
    for drive in ('C:/', 'D:/'):
        if shutil.disk_usage(drive).free < 10 * 1024**3:
            raise RuntimeError('Under 10 GiB: ' + drive)
    record = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'start_utc': now(),
              'disk_free': {d: shutil.disk_usage(d).free for d in ('C:/', 'D:/')}}
    path = LEAF / 'logs' / (name + '.log')
    print(json.dumps(record), flush=True)
    with path.open('wb') as output:
        proc = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT)
        record['pid'] = proc.pid
        try:
            record['exit_code'] = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            record['timeout'] = timeout
            record['exit_code'] = None
            (LEAF / 'retained' / (name + '.json')).write_text(json.dumps(record, indent=2))
            raise RuntimeError('Command timeout; process ownership needs resolution: ' + str(proc.pid))
    record['end_utc'] = now()
    (LEAF / 'retained' / (name + '.json')).write_text(json.dumps(record, indent=2))
    print(name + ' exit=' + str(record['exit_code']), flush=True)
    return record['exit_code']

def gradle(name, tasks):
    argv = ['cmd.exe', '/d', '/c', 'gradlew.bat', '--offline', '--no-daemon',
            '--no-build-cache', '--rerun-tasks', '-Dorg.gradle.workers.max=2',
            '-Dorg.gradle.java.home=' + str(JAVA),
            '-Dorg.gradle.jvmargs=-Xmx3G -Djava.io.tmpdir=' + str(LEAF / 'tmp')] + tasks
    result = run(name, argv)
    junit = ROOT / 'build/test-results/test'
    if junit.is_dir():
        target = LEAF / 'retained' / (name + '-junit')
        target.mkdir(exist_ok=True)
        for src in junit.glob('TEST-*.xml'):
            shutil.copy2(src, target / src.name)
    for sub in ('build/gametest/logs', 'run-data/logs'):
        source = ROOT / sub
        if source.is_dir():
            target = LEAF / 'retained' / (name + '-' + source.parent.name + '-logs')
            target.mkdir(exist_ok=True)
            for src in source.glob('*'):
                if src.is_file():
                    shutil.copy2(src, target / src.name)
    return result

if __name__ == '__main__':
    run('java-version', [str(JAVA / 'bin/java.exe'), '-version'])
    run('git-identity', ['git', 'show', '--no-patch', '--format=fuller', 'HEAD'])
    run('git-initial-status', ['git', 'status', '--porcelain=v1'])
    run('git-diff-stat', ['git', 'diff', '--stat', 'a2e3c476de0188c93c0de85bf005d4a0e02e3251', 'HEAD'])
    run('git-candidate-patch', ['git', 'diff', '--binary', 'a2e3c476de0188c93c0de85bf005d4a0e02e3251', 'HEAD'])
    run('git-original-correction-patch', ['git', 'diff', '--binary', 'e456ffc0eab1c0752fa5e6e57b4c63ddedbac964', 'HEAD'])
    gradle('clean-build', ['clean', 'build'])
    gradle('explicit-test', ['test'])
    gradle('data-01', ['runData'])
    run('data-01-empty-diff', ['git', 'diff', '--exit-code'])
    gradle('data-02', ['runData'])
    run('data-02-empty-diff', ['git', 'diff', '--exit-code'])
    gradle('gametest', ['runGameTestServer'])
    run('ledger', [sys.executable, 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
    run('bootstrap-provenance', [sys.executable, 'scripts/validate_bootstrap_provenance.py', '--require-approved-review'])
    run('strict-repository', [sys.executable, 'scripts/validate_repository.py', '--require-approved-identity'])
    run('whitespace', ['git', 'diff', '--check', 'a2e3c476de0188c93c0de85bf005d4a0e02e3251', 'HEAD'])
    run('git-final-status', ['git', 'status', '--porcelain=v1'])
    run('git-final-head', ['git', 'rev-parse', 'HEAD'])
