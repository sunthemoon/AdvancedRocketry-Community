import datetime
import hashlib
import json
import pathlib
import sys

LEAF = pathlib.Path(__file__).resolve().parent
EXPECTED = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-independent-correction-20261009-02').resolve()
assert LEAF == EXPECTED
manifest = LEAF / 'SHA256SUMS.txt'
assert not manifest.exists(), 'Existing seal must not be changed'
assert {p.name for p in LEAF.iterdir() if p.is_dir()} == {'logs', 'retained'}
commands = json.loads((LEAF / 'retained/command-results.json').read_text(encoding='utf-8-sig'))
assert all(isinstance(record, dict) for record in commands)
by_name = {record.get('name'): record for record in commands}
required = ('clean-build', 'explicit-test', 'data-01', 'data-01-empty-diff',
            'data-02', 'data-02-empty-diff', 'gametest', 'ledger',
            'bootstrap-provenance', 'strict-repository', 'whitespace',
            'git-final-status', 'git-final-head', 'git-final-tracked-diff',
            'git-final-source-tree', 'cleanup', 'jar-packaging-inspection-02')
assert all(name in by_name for name in required)
assert by_name['strict-repository']['exit_code'] == 1
assert all(by_name[name]['exit_code'] == 0 for name in required if name != 'strict-repository')
assert json.loads((LEAF / 'retained/source-input-comparison.json').read_text())['changed_entries'] == []
report = (LEAF / 'REPORT.md').read_text(encoding='utf-8')
assert 'Pending' not in report
assert (LEAF / 'ORIGINAL-REPORT-ERRATUM-01.md').is_file()
payload = sorted(p for p in LEAF.rglob('*') if p.is_file())
assert all(p.stat().st_size < 50_000_000 for p in payload)
assert sum(p.stat().st_size for p in payload) < 100_000_000

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

rows = [(digest(path), path.relative_to(LEAF).as_posix()) for path in payload]
manifest.write_text(''.join(value + '  ' + name + '\n' for value, name in rows), encoding='utf-8')
for value, name in rows:
    assert digest(LEAF / name) == value, name
all_files = payload + [manifest]
assert sum(path.stat().st_size for path in all_files) < 100_000_000
assert max(path.stat().st_size for path in all_files) < 50_000_000
print(json.dumps({
    'argv': [sys.executable, '-B', str(pathlib.Path(__file__).resolve())],
    'seal_verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'payload_entries': len(payload), 'total_files_including_manifest': len(all_files),
    'total_bytes_including_manifest': sum(path.stat().st_size for path in all_files),
    'maximum_file_bytes': max(path.stat().st_size for path in all_files),
    'report_sha256': digest(LEAF / 'REPORT.md'),
    'manifest_sha256': digest(manifest),
    'original_erratum_sha256': digest(LEAF / 'ORIGINAL-REPORT-ERRATUM-01.md')
}, indent=2))
