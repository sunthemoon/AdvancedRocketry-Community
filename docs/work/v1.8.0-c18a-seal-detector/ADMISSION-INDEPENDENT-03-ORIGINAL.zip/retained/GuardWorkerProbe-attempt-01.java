import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;

/** External diagnostic of the committed helper's exceptional cleanup ordering. */
public final class GuardWorkerProbe {
    public static void main(String[] args) throws Exception {
        Class<?> subject = Class.forName(
                "io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.SealDetectorAdmissionGameTests");
        Method method = subject.getDeclaredMethod("offThread", Callable.class);
        method.setAccessible(true);
        AtomicBoolean release = new AtomicBoolean();
        AtomicBoolean workerEnded = new AtomicBoolean();
        long start = System.nanoTime();
        try {
            try (OwnedFixture fixture = new OwnedFixture(workerEnded)) {
                Callable<Object> action = () -> {
                    try {
                        while (!release.get()) {
                            try { Thread.sleep(10); }
                            catch (InterruptedException ignored) { /* Controlled non-cooperative input. */ }
                        }
                        return null;
                    } finally { workerEnded.set(true); }
                };
                try { method.invoke(null, action); }
                catch (InvocationTargetException failure) {
                    System.out.println("ACTUAL_HELPER_THROW=" + failure.getCause());
                }
            }
        } finally {
            release.set(true);
            for (int i = 0; i < 100 && !workerEnded.get(); i++) { Thread.sleep(10); }
        }
        System.out.println("WORKER_ENDED_BEFORE_DIAGNOSTIC_EXIT=" + workerEnded.get());
        System.out.println("ELAPSED_MILLIS=" + ((System.nanoTime() - start) / 1_000_000));
        if (!workerEnded.get()) { throw new AssertionError("External diagnostic failed to release its worker"); }
    }
    private static final class OwnedFixture implements AutoCloseable {
        private final AtomicBoolean workerEnded;
        private OwnedFixture(AtomicBoolean workerEnded) { this.workerEnded = workerEnded; }
        @Override public void close() {
            System.out.println("OUTER_FIXTURE_CLOSE_WORKER_ENDED=" + workerEnded.get());
        }
    }
}
