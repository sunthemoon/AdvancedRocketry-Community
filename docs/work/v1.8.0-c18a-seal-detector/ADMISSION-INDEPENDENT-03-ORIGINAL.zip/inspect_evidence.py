import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

LEAF = pathlib.Path(__file__).resolve().parent
ROOT = LEAF / 'checkout'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def source_manifest():
    paths = sorted(p for p in (ROOT / 'src').rglob('*') if p.is_file() and '.cache' not in p.parts)
    paths += [ROOT / name for name in ('build.gradle', 'settings.gradle', 'gradle.properties',
                                      'gradlew', 'gradlew.bat', 'gradle/wrapper/gradle-wrapper.jar',
                                      'gradle/wrapper/gradle-wrapper.properties')]
    return {p.relative_to(ROOT).as_posix(): digest(p) for p in paths}

def summarize():
    summaries = {}
    for directory in sorted((LEAF / 'retained').glob('*-junit')):
        files = sorted(directory.glob('TEST-*.xml'))
        cases = [case for path in files for case in ET.parse(path).getroot().iter('testcase')]
        attributes = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
        for path in files:
            suite = ET.parse(path).getroot()
            for name in attributes:
                attributes[name] += int(suite.attrib.get(name, '0'))
        summaries[directory.name] = {
            'suite_files': len(files), 'actual_testcases': len(cases), 'suite_attribute_totals': attributes,
            'actual_failures': sum(case.find('failure') is not None for case in cases),
            'actual_errors': sum(case.find('error') is not None for case in cases),
            'actual_skipped': sum(case.find('skipped') is not None for case in cases)}
    (LEAF / 'retained/junit-recount.json').write_text(json.dumps(summaries, indent=2))
    print(json.dumps(summaries, indent=2))
    artifacts = {}
    for path in sorted((ROOT / 'build/libs').glob('*.jar')):
        archive = zipfile.ZipFile(path)
        names = archive.namelist()
        artifacts[path.name] = {'bytes': path.stat().st_size, 'sha256': digest(path),
                                'admission_classes': [name for name in names if 'SealDetectorAdmissionGameTests' in name]}
    (LEAF / 'retained/artifact-identities.json').write_text(json.dumps(artifacts, indent=2))
    manifest = source_manifest()
    (LEAF / 'retained/source-input-sha256.json').write_text(json.dumps(manifest, indent=2, sort_keys=True))
    print('source_input_files=' + str(len(manifest)))
    contexts = []
    counts = {}
    candidates = list((LEAF / 'logs').glob('*.log')) + list((LEAF / 'retained').rglob('*.log'))
    for path in sorted(candidates):
        lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
        matched = [i for i, line in enumerate(lines) if re.search(r'\b(?:ERROR|FATAL)\b', line)]
        if not matched:
            continue
        rel = path.relative_to(LEAF).as_posix()
        counts[rel] = len(matched)
        contexts.append('\n### ' + rel + ' (' + str(len(matched)) + ' matching lines)\n')
        ranges = set()
        for i in matched:
            for j in range(max(0, i - 3), min(len(lines), i + 10)):
                ranges.add(j)
        for j in sorted(ranges):
            contexts.append(str(j + 1) + ': ' + lines[j])
    (LEAF / 'retained/UNWAIVED-ERROR-FATAL-CONTEXT.txt').write_text('\n'.join(contexts), encoding='utf-8')
    (LEAF / 'retained/error-line-counts.json').write_text(json.dumps(counts, indent=2))
    print(json.dumps(counts, indent=2))

if __name__ == '__main__':
    summarize()
