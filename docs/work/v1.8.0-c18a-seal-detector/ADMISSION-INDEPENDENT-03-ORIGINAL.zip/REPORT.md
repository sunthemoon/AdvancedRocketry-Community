# Independent review: C18a-SEAL-ADMISSION-03

## Findings (severity first)

### Medium — a surviving refusal worker does not prevent fixture cleanup

At `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/instrument/SealDetectorAdmissionGameTests.java:361–373`, cancellation and a bounded join are followed by an exception if the worker remains alive. The surrounding try-with-resources at lines 145 and 167–173 nevertheless executes `LocalReader.close()` and/or `Fixture.close()` while that same worker can still hold and access the player/context/manager. Those closes clear the local manager, remove players and restore the world cells (lines 212 and 309–323). Thus the exceptional path does not satisfy ADMISSION-TASK-03's explicit worker-termination-before-cleanup condition.

This is a harness isolation defect on the timeout/non-cooperative failure path, not a reproduced ordinary detector gameplay defect. No tested normal refusal is alleged to block. An external Java diagnostic invokes the **actual compiled candidate's private `offThread(Callable)` method**, with a controlled callable that delays termination despite interruption. It retains the unchanged two-second wait and two-second join. Both diagnostic executions show `Guard worker outlived its fixture` followed by `OUTER_FIXTURE_CLOSE_WORKER_ENDED=false`. The external `OwnedFixture` observes Java resource-unwinding order; the diagnostic does not itself invoke the Minecraft fixture's cleanup body. That body's applicability follows from the reviewed try-with-resources scopes. Attempt 02 explicitly releases and joins its owned worker before exiting and records `WORKER_THREAD_ALIVE_BEFORE_DIAGNOSTIC_EXIT=false`. See `logs/guard-worker-probe-02.log`, its argv/time/exit record and `GuardWorkerProbe.java`.

Required correction: failed worker ownership must be resolved before any captured fixture is cleaned up or reused. A survivor must not be converted merely into an exception that unwinds into ordinary cleanup. Preserve the bounded execution and fail the test; do not increase timeouts, weaken assertions or ignore the survivor. The revised policy/implementation requires independent review and a new candidate rerun.

## Review identity, scope and authority

- Independent delegated Codex reviewer; no implementation, Claude calls, further delegation, OpenPet events, staging, commits or pushes.
- Preparation **commit** `771543514c0ccf6f09f22b62ba1d36e9a6d9b7f9`; candidate `e456ffc0eab1c0752fa5e6e57b4c63ddedbac964`. Candidate is a direct child of preparation, adding exactly one 380-line Java class, with 12 `@GameTest` methods. No production/build/registry/API/schema/asset/ledger change is present in the reviewed diff.
- ADMISSION-TASK-03's `9429d00b...` is its pre-preparation base, not the preparation commit. The preparation commit contains the actual task, the implementation-log entry (lines 3–24) and the active-plan entry (lines 418–421), and precedes source authoring in Git history. These entries declare the scope/non-goals and do not report nonexistent passing results.
- Existing main was observed at `53c031e8`; its user-owned dirty AGENTS.md and inherited untracked files were excluded and untouched. Source worktree was pinned at the candidate and only read. All execution uses a newly created detached disposable clone in this evidence leaf. Local/per-command long-path support was used only for the new clone.
- Read governance: AGENTS.md, PROJECT-CONFIG.md, PRODUCT.md, porting principles, roadmap, actual `V1.8.0-CLASSIC-CONTENT-COMPLETION.md`, master test plan, acceptance gates, post-1.0 roadmap, quality budgets, parallel-worktree rules, source/provenance documents, accepted ADR-060 and ADR-067 revision 1, the task and preparation records. The exploratory lowercase version-file lookup failed because that filename does not exist; the actual uppercase version document was then read. No missing scope was inferred from that error.
- Acceptance cursor remains v1.0.0; active development remains v1.8.0 IN_PROGRESS / IMPLEMENTING under ADR-060. No full item/ledger delivery or G0–G9 approval is made. ADR-068 and R-021 are not accepted or closed by this review.
- Only new files underneath `D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-independent-20261009-01` were written. New disposable clone/cache/TEMP/probe outputs are the only cleanup candidates.

## Contract and evidence-strength assessment

The class uses the actual registered detector and owned ordinary `ServerPlayer` instances. Their only overrides capture the two system-message overloads as component JSON and overlay flags; alive/removed/spectator/creative/permission behavior is not spoofed. `placeNewPlayer` and embedded connections establish PlayerList identity; survival mode is selected natively. Each fixture proves an admitted native game-mode use with an exact structured sealed/not-known-supplied reply, empty peer replies and a cooldown, then removes that cooldown and clears both reply lists before the refusal.

Nine item cases call the actual `item.useOn` entry directly, separating its guards from earlier game-mode/world gates: stack count two, captured-stack identity replacement, spectator, dead, removed, missing connection, foreign Level, stale same-UUID object and off-thread call. The `Probe` throws on position/face/hit access; `FAIL`, recipient silence, no cooldown, both hand object identities, full serialized held data and installed atmosphere metrics are asserted. Worker-result synchronization via `FutureTask.get` and join makes completed-path counter inspection meaningful. The stale object borrows a connection solely as input; it never owns/closes it, and the reference is cleared in `finally`.

The remaining three cases use fresh **uninstalled** local service handles and managers, not a replacement installed runtime or an alternative installed boundary catalog. Local positive controls use a sealed native block and NOT_KNOWN_SUPPLIED. Closure is terminal/idempotent (`owns` false and both valid/null reads unavailable). Off-thread local refusal precedes the instrumented actor/Level/selected getters. The post-query callback uses a fresh manager's empty-to-present metrics transition as a witness to the local supply query, replaces the actual hand stack, and proves captured and current identity differ while the reading becomes unavailable. This is an explicitly controlled context-accessor callback, not native client/provider behavior.

The context probe directly instruments actor, Level, clicked position, face and hit-location getters. Its “all context” wording should not be read as independent instrumentation of every possible `UseOnContext` accessor; hand/stack getters are not separately poisoned. Actual service source does put closure/thread refusal before `current()` and its context reads. This review does not broaden the fixture's direct observation beyond the instrumented getters.

Selected cells are two loaded, BE-free cells in the fixture's own X/Z allocation at y=180; setup captures their exact prior states and normal cleanup asserts restoration/no BE. Constructor failures preserve the original error with cleanup errors suppressed. Normal actor/channel cleanup is ownership-qualified; transient connection removal is restored in `finally`. The worker-survivor exception is the specific unresolved abnormal-cleanup finding above.

Platform bytecode inspection independently confirms UseOnContext captures its itemStack (its getter returns the stored field), ServerPlayer.hasDisconnected reads its disconnected flag, and ForgeGameTestHooks discovers annotated classes through mod scan data rather than requiring the gametest package. The instrument-package class is therefore discovered under the existing namespaces without a central discovery edit. Main-source packaging means the test and its nested classes enter the normal JAR; this is declared by the task, not hidden as a development-only artifact.

Explicit non-goals remain: exhaustive Level/chunk/cell/query-order cases, full installed catalog precedence, installed server-stop/restart lifecycle, reload/unload/protection-mod behavior, S1/S2, true-client V1/V2, oxygen/resource authority, acquisition, physical hatch/hook/save writer, and owner-policy decisions. Local closure is not installed restart certification. Structured server-side components are not rendered-language/GPU evidence.

## Execution and artifact results

All results below are independently executed on the original fixed candidate, not borrowed from Root. Full argv, cwd, UTC start/end, immediate child exit code and C:/D: free space are retained per command in `retained/*.json` and consolidated in `retained/command-results.json`; raw output is in the matching `logs/*.log`. An orchestration exit of 0 means the runner finished, **not** that its failed strict checker passed.

Java is Oracle JDK 17.0.7+8-LTS-224, selected explicitly from `C:/Program Files/Java/jdk-17.0.7`. Gradle is 8.8; copied dependency resolution contains ForgeGradle 6.0.54 and Forge baseline 47.4.10 / official Minecraft 1.20.1 mappings. The private dependency cache was copied from the installed Gradle home with `robocopy /E /XJ /R:0 /W:0 /XF *.lock *.lck`; its four successful child exits are 1 (Robocopy's copied-files success result), at aggregate UTC 16:47:15–16:47:54. No original cache was edited/deleted and no dependency install or global setting was changed. Initial clone/checkout children exited 0, with raw logs retained; their UTC start times were not instrumented, and are not retrospectively invented.

Every Gradle invocation uses `cmd.exe /d /c gradlew.bat --offline --no-daemon --no-build-cache --rerun-tasks -Dorg.gradle.workers.max=2 -Dorg.gradle.java.home=<fixed JDK> -Dorg.gradle.jvmargs=-Xmx3G -Djava.io.tmpdir=<owned D:/.../tmp>`, followed by the listed task arguments. TEMP/TMP/JAVA_TOOL_OPTIONS and GRADLE_USER_HOME are private to this leaf. The heap/concurrency selection does not change source assertions, native timeout ticks, scan limits or service budgets. Both drives exceed 10 GiB before each sustained command (the minimum recorded C: value exceeds 30 billion bytes).

| Actual command/tasks | UTC interval on 2026-10-08 | Child exit | Independent result |
| --- | --- | --- | --- |
| Gradle `clean build` | 16:48:51–16:53:18 | 0 | 20 tasks executed; 2,179 actual JUnit testcase elements / 378 XML suites, 0 failures/errors/skips |
| Gradle explicit `test` | 16:53:19–16:57:24 | 0 | 17 tasks executed; fresh 2,179 testcase elements / 378 suites, 0 failures/errors/skips |
| Gradle first `runData` | 16:57:25–16:58:32 | 0 | HashCache total files 841, written 0 |
| First `git diff --exit-code` | 16:58:33 | 0 | Empty output / tracked diff |
| Gradle second `runData` | 16:58:33–16:59:38 | 0 | HashCache total files 841, written 0 |
| Second `git diff --exit-code` | 16:59:38–16:59:39 | 0 | Empty output / tracked diff |
| Gradle unfiltered `runGameTestServer` | 16:59:39–17:06:39 | 0 | 565 tests scheduled across 147 batches; native terminal marker says all 565 required tests passed; new admission batch contains 12 |
| `python scripts/validate_v180_content_ledger.py --require-accepted` | 17:06:39 | 0 | 653 units; 186 PLANNED and 154 REVIEW remain; no closure claimed |
| `python scripts/validate_bootstrap_provenance.py --require-approved-review` | 17:06:39–17:07:07 | 0 | Mechanical validation and digest-bound THIRD_PARTY_APPROVED record pass |
| `python scripts/validate_repository.py --require-approved-identity` | 17:07:07–17:12:01 | **1** | 44 checks passed, 1 failed: Broken Markdown links; traversal stops after 256 errors, not an exhaustive remaining-debt count |
| `git diff --check <preparation> HEAD` | 17:12:01 | 0 | No whitespace errors in actual committed diff |
| Initial/final status, final HEAD, final tracked diff, src-tree identity, candidate stat/patch queries | records retain exact subsecond times | 0 each | Private clone clean, HEAD remains e456ffc0; candidate patch is the single new class |
| Java version query | 16:48:51 | 0 | Actual selected Java 17 binary |
| Initial platform javap / first Forge discovery javap | 16:50:17–16:50:18 / 16:50:40 | **1 each** | Wrong requested class name `GameTestHooks`; partial platform output retained; **checker/setup failures**, not candidate behavior failures |
| Corrected Forge discovery javap | 16:51:16 | 0 | Correct `ForgeGameTestHooks` inspected independently |
| External worker diagnostic compile/run, attempts 01 and 02 | full records retained | 0 each | Reproduces the finding; final diagnostic worker explicitly ended/joined; no candidate edits |
| Independent XML/artifact/input/error inspection | 17:12:49–17:12:51 | 0 | Recounts and hashes retained, no result inferred from test labels alone |

JUnit XML retained under the `data-*` and `gametest-*` snapshot directories is a snapshot of the previously completed explicit test task. Those later tasks do not execute JUnit again; only the clean-build and explicit-test XML sets are counted as independent JUnit executions. Native GameTest results are the native raw logs, scheduled-batch recount and final required-test marker, not those inherited JUnit snapshots. No native GameTest XML reporter was configured or produced by this cohort.

The native log contains **62 ERROR / 0 FATAL** records. Raw console/latest/debug logs and separately line-numbered context in `retained/UNWAIVED-ERROR-FATAL-CONTEXT.txt` are retained. The repeated copies are not counted as 186 distinct events. They include migration binding/save failures, machine-definition rejection, satellite failure paths and compatibility rejection fixtures; intentional-fixture context is **not** a Gate waiver. Strict link failures and native error obligations remain open, and the original Medium finding is not erased by normal-path test success.

The inspected 3,026 source/seven-build-input entries are unchanged across the retained pre-/post-native manifests; final tracked diff/status are empty and `HEAD:src` is `1661afb000ba80e2a4032076875f2afab9397e0d`. Stable item ID, resources, API schema and runtime registration are not changed by this candidate. Endpoint build artifact identities (after the forced explicit-test build, not a separate packaged-runtime run) are:

- Main JAR: 6,048,203 bytes, SHA-256 `8a2f72e12b6c843d5518fefddec73a3b5d3e9cd88d1797ba899c59b389e9be50`.
- API JAR: 51,052 bytes, SHA-256 `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.
- Sources JAR: 2,878,854 bytes, SHA-256 `ae065e7db8a1dead6fe4f63fa338dc40ee30744368bcefff14d430a3eb3f10d8`.
- New Java source SHA-256: `7414425ce5000e9fa55473ba32721bb59f4b787b5e05e3c1405c2efcb740c7a1`; actual compiled helper class recorded for the external diagnostic: `18d789ad757dcacc7f371f4d5a45cbaaa263d688574ab3a85d9b96283b825408`.

The main JAR actually contains the new test and seven nested classes; sources JAR contains its source, API JAR contains none. These identities do not certify packaged S1/S2 execution or release reproducibility R1. Reproducible source/build/world trees and whole artifacts are deliberately not archived in this compact evidence.

## Known risks and Gate status

One introduced Medium harness lifecycle finding remains unresolved. The complete version's Required Gates are not satisfied by this scoped review, regardless of successful unit/native runs. Inherited strict-link debt, unwaived native ERROR/FATAL obligations, packaged persistence/recovery, real-client evidence, performance/compatibility and human release approval remain separate.

## Completion and read interests

Completed: independent actual-diff/contract review, original-candidate forced clean build, explicit unit task, repeated deterministic DataGen/diffs, complete unfiltered native cohort, ledger/provenance/strict/whitespace checks, independent testcase recounts and failed-attempt/error retention. No repository implementation files or tests were modified by the reviewer; only the external diagnostic/evidence tools were added. Uncompleted: correction of the introduced Medium finding and any corrected-candidate validation, exhaustive detector qualification, S1/S2, V1/V2 and full version Required Gates. The review status for **e456ffc0** is **CHANGES_REQUESTED**, not VERIFIED.

Root notified the reviewer that a corrected candidate `452fd2a0...` exists. It is **not reviewed or tested by this original report**, and no original result/finding is rebound to it. Follow-up must inspect its actual diff and preserve separate evidence.

Cleanup completed once using native PowerShell at UTC 2026-10-08T17:15:24.5063428Z. Its preflight checks leaf identity, absolute containment, reparse ancestors/descendants and ended owned processes, then removes only the newly created private checkout, copied Gradle home, own TEMP, diagnostic class output and own Python bytecode cache. All five removals succeed; no denied retry, cross-shell deletion or other-agent cleanup occurs. `logs/cleanup.log` and `retained/cleanup-preflight.json` preserve actual targets/outcomes. Existing source-world inputs and original/sealed evidence remain untouched.

The compact evidence is sealed with relative `SHA256SUMS.txt` entries; no whole source/build/world archive or JAR is retained. The evidence set is below 100 MB in total and every file is below 50 MB, verified when sealing. Main/source/HEAD interests were released earlier; **all original-review read/HEAD/process interests are now released**. Recommendation: independently review/rerun the correction within this same v1.8 slice; do not proceed to item/ledger delivery or version Gate approval from this report.
