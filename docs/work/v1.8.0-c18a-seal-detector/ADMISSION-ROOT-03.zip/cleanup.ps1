$ErrorActionPreference = 'Stop'
$tree = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-seal-admission-20261009')
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-admission-root-20261009-01')
$head = git -C $tree rev-parse HEAD
if ($LASTEXITCODE -ne 0 -or $head -ne '452fd2a0dc12895c2e2b955c80115457459888bb') { throw 'Unexpected source HEAD' }
$dirty = @(git -C $tree status --porcelain)
if ($LASTEXITCODE -ne 0 -or $dirty.Count) { throw 'Source is not clean' }
$tracked = @(git -C $tree ls-files -- build run-data .gradle)
if ($LASTEXITCODE -ne 0 -or $tracked.Count) { throw 'Cleanup would include tracked input' }
$targets = @('build', 'run-data', '.gradle') | ForEach-Object { Join-Path $tree $_ }
$targets += @('cohort-01/temp', 'cohort-02/temp') | ForEach-Object { Join-Path $leaf $_ }
$live = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and
    ($_.CommandLine.Contains($tree) -or $_.CommandLine.Contains($tree.Replace('\', '/')) -or
     $_.CommandLine.Contains($leaf) -or $_.CommandLine.Contains($leaf.Replace('\', '/')))
})
if ($live.Count) { throw ('Task processes remain: ' + ($live.ProcessId -join ',')) }
$inventory = @()
foreach ($target in $targets) {
    $resolved = [IO.Path]::GetFullPath($target)
    if (-not ($resolved.StartsWith($tree + '\', [StringComparison]::OrdinalIgnoreCase) -or
              $resolved.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase))) {
        throw ('Outside owned roots: ' + $resolved)
    }
    if (-not (Test-Path -LiteralPath $resolved)) { continue }
    $ancestor = Get-Item -LiteralPath $resolved -Force
    while ($ancestor) {
        if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Reparse ancestor: ' + $ancestor.FullName) }
        $ancestor = $ancestor.Parent
    }
    $entries = @(Get-ChildItem -LiteralPath $resolved -Recurse -Force)
    if (@($entries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
        throw ('Reparse descendant: ' + $resolved)
    }
    $files = @($entries | Where-Object { -not $_.PSIsContainer })
    $inventory += [pscustomobject]@{
        target = $resolved; files = $files.Count; logicalBytes = ($files | Measure-Object Length -Sum).Sum
        reason = 'Created by this task; ended disposable build, GameTest/DataGen or TEMP output; no tracked inputs.'
    }
}
$freeBefore = @(Get-PSDrive C,D | Select-Object Name,Free)
[pscustomobject]@{ inventory = $inventory; liveTaskProcesses = $live; freeBefore = $freeBefore; utc = [DateTime]::UtcNow.ToString('o') } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-preflight.json') -Encoding utf8
# One native deletion attempt; any refusal stops the script, with no retry.
foreach ($entry in $inventory) { Remove-Item -LiteralPath $entry.target -Recurse -Force }
$remaining = @($inventory | Where-Object { Test-Path -LiteralPath $_.target })
[pscustomobject]@{
    inventory = $inventory; remaining = $remaining; allRemoved = $remaining.Count -eq 0
    freeBefore = $freeBefore; freeAfter = @(Get-PSDrive C,D | Select-Object Name,Free)
    utc = [DateTime]::UtcNow.ToString('o')
    policy = 'Logical inventory only; prior refused targets and source-world inputs untouched.'
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup.json') -Encoding utf8
if ($remaining.Count) { throw 'Disposable outputs remain' }
