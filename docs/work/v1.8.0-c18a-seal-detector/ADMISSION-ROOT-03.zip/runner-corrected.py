"""Derive a distinct fixed-candidate cohort without changing any original result."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
original = root / 'runner.py'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '979d7528766c85176c8bf7e3aec4f6ead71f2a6a689a3c21c8b8caa971f6f695'
source = original.read_text('utf-8')
replacements = {
    "PIN = 'e456ffc0eab1c0752fa5e6e57b4c63ddedbac964'": "PIN = '452fd2a0dc12895c2e2b955c80115457459888bb'",
    "BASE = '771543514c0ccf6f09f22b62ba1d36e9a6d9b7f9'": "BASE = 'a2e3c476de0188c93c0de85bf005d4a0e02e3251'",
    'assert scope == [code], scope': "unit = 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/instrument/SealDetectorAdmissionWorkerGateTest.java'\nassert scope == sorted([code, unit]), scope",
    "game_tests=(TREE / code).read_text('utf-8').count('@GameTest('))": "game_tests=(TREE / code).read_text('utf-8').count('@GameTest('),\n                    worker_test_sha256=sha(TREE / unit), worker_test_lines=len((TREE / unit).read_text('utf-8').splitlines()))",
    "ROOT / 'source-scope.json'": "ROOT / 'source-scope-corrected.json'",
    "ROOT / 'source.patch'": "ROOT / 'source-corrected.patch'",
}
for before, after in replacements.items():
    assert source.count(before) == 1, before
    source = source.replace(before, after)
effective = root / 'effective-runner-corrected.py'
with effective.open('x', encoding='utf-8', newline='\n') as output:
    output.write(source)
exec(compile(source, str(effective), 'exec'))
