"""Seal ended retained evidence once, leaving source/world/cache outputs excluded."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
dest = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-seal-detector/ADMISSION-ROOT-03.zip')
assert not dest.exists() and not (root / 'SHA256SUMS.txt').exists()
assert json.loads((root / 'cleanup.json').read_text('utf-8-sig'))['allRemoved']
files = sorted(path for path in root.rglob('*') if path.is_file())
assert all(path.resolve(strict=True).is_relative_to(root.resolve()) for path in files)
assert not any(part in ('temp', 'build', 'run-data', '.gradle', '__pycache__', 'checkout', 'gradle-home')
               for path in files for part in path.relative_to(root).parts)
rows = [dict(path=path.relative_to(root).as_posix(), bytes=path.stat().st_size,
             sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in files]
assert all(row['bytes'] < 50 * 1024 ** 2 for row in rows)
assert sum(row['bytes'] for row in rows) < 100 * 1024 ** 2
(root / 'retained-manifest.json').write_text(json.dumps(dict(
    sources=['e456ffc0eab1c0752fa5e6e57b4c63ddedbac964', '452fd2a0dc12895c2e2b955c80115457459888bb'],
    payloads=rows, payload_count=len(rows), payload_bytes=sum(row['bytes'] for row in rows)), indent=2) + '\n', encoding='utf-8')
files.append(root / 'retained-manifest.json')
(root / 'SHA256SUMS.txt').write_text(''.join(
    hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.relative_to(root).as_posix() + '\n'
    for path in sorted(files)), encoding='utf-8')
files.append(root / 'SHA256SUMS.txt')
with zipfile.ZipFile(dest, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        info = zipfile.ZipInfo(path.relative_to(root).as_posix(), (2026, 10, 9, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(path=str(dest), bytes=dest.stat().st_size, entries=len(files),
                      payloads=len(rows), payload_bytes=sum(row['bytes'] for row in rows),
                      uncompressed_bytes=sum(path.stat().st_size for path in files),
                      sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                      report_sha256=hashlib.sha256((root / 'REPORT.md').read_bytes()).hexdigest()), indent=2))
