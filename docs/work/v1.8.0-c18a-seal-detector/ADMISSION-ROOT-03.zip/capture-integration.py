"""Record committed-source equivalence and protected user work after integration."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('D:/GitHub/AdvancedRocketry-Community')
root = Path(__file__).resolve().parent
tested = '452fd2a0dc12895c2e2b955c80115457459888bb'
merge = 'b001316102d064545fb81d9f4f2141ae52931118'
def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(repo), *args]).decode().strip()
assert git('rev-parse', 'HEAD') == merge
assert git('rev-parse', '@{upstream}') == merge
assert not git('diff', '--cached', '--name-only')
inputs = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
          'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties']
identities = {name: [git('rev-parse', commit + ':' + name) for commit in (tested, merge)] for name in ['src', *inputs]}
assert all(before == after for before, after in identities.values())
agent_sha = hashlib.sha256((repo / 'AGENTS.md').read_bytes()).hexdigest()
assert agent_sha == 'c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09'
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), tested=tested,
              integrated=merge, upstream=git('rev-parse', '@{upstream}'), identities=identities,
              user_agents_sha256=agent_sha, merge_commit_not_rerun=True,
              source_branch_upstream=git('rev-parse', 'origin/test/v1.8.0-seal-admission'))
(root / 'source-integration.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
