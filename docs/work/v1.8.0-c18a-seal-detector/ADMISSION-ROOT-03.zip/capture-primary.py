"""Retain fresh, read-only disassembly of the pinned mapped platform input."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
leaf = root / 'primary'
leaf.mkdir()
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
jar_sha = hashlib.sha256(jar.read_bytes()).hexdigest()
assert jar_sha == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
records = []
for name, clazz in [('use-on-context', 'net.minecraft.world.item.context.UseOnContext'),
                    ('server-player', 'net.minecraft.server.level.ServerPlayer')]:
    argv = ['C:/Program Files/Java/jdk-17.0.7/bin/javap.exe', '-p', '-c', '-classpath', str(jar), clazz]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    log = leaf / (name + '.log')
    log.write_bytes(result.stdout)
    records.append(dict(name=name, argv=argv, started_utc=start,
                        ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        exit_code=result.returncode, bytes=len(result.stdout),
                        log_sha256=hashlib.sha256(result.stdout).hexdigest()))
    assert result.returncode == 0, records[-1]
(leaf / 'commands.json').write_text(json.dumps(dict(jar_path=str(jar), jar_sha256=jar_sha, commands=records), indent=2) + '\n', encoding='utf-8')
print(json.dumps(records))
