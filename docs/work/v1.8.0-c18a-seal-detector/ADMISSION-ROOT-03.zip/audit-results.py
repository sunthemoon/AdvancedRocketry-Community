"""Recount retained XML/log evidence without relying on cached task summaries."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
audits = []
for name in ('cohort-01', 'cohort-02'):
    leaf = root / name
    result = json.loads((leaf / 'results.json').read_text('utf-8'))
    commands = json.loads((leaf / 'commands.json').read_text('utf-8'))
    for command in commands:
        raw = (leaf / (command['name'] + '.log')).read_bytes()
        assert len(raw) == command['bytes']
        assert hashlib.sha256(raw).hexdigest() == command['log_sha256']
    units = {}
    for stage in ('build', 'test'):
        totals = dict(tests=0, failures=0, errors=0, skipped=0)
        nodes = 0
        with zipfile.ZipFile(leaf / (stage + '-unit-xml.zip')) as archive:
            assert archive.testzip() is None
            for entry in archive.namelist():
                suite = ET.fromstring(archive.read(entry))
                for key in totals:
                    totals[key] += int(suite.get(key, '0'))
                nodes += len(suite.findall('testcase'))
            units[stage] = dict(suites=len(archive.namelist()), totals=totals, actual_testcase_nodes=nodes)
        assert units[stage] == result['units'][stage]
    native = (leaf / 'native-latest.log').read_text('utf-8')
    context = []
    lines = native.splitlines()
    for index, line in enumerate(lines):
        if re.search(r'/ERROR]|/FATAL]', line):
            context.append('\n'.join(f'{number + 1}: {lines[number]}' for number in range(max(0, index - 2), min(len(lines), index + 10))))
    (leaf / 'UNWAIVED-ERROR-FATAL-CONTEXT.txt').write_text('\n\n'.join(context) + '\n', encoding='utf-8')
    batches = [(batch, int(count)) for batch, count in re.findall(r"Running test batch '([^']+)' \((\d+) tests\)", native)]
    strict = (leaf / 'repository.log').read_text('utf-8')
    audits.append(dict(cohort=name, source=result['source'], units=units,
                       command_exits={command['name']: command['exit_code'] for command in commands},
                       native_scheduled=sum(count for _, count in batches), native_batches=batches,
                       native_error_headers=len(re.findall(r'/ERROR]', native)),
                       native_fatal_headers=len(re.findall(r'/FATAL]', native)),
                       native_terminal_lines=result['native_terminal_lines'],
                       native_failure_lines=result['native_failure_lines'],
                       strict_summary=[line for line in strict.splitlines() if line.startswith('Summary:')],
                       data_hash_cache={stage: [line for line in (leaf / (stage + '.log')).read_text('utf-8').splitlines()
                                               if 'HashCache' in line] for stage in ('data-1', 'data-2')},
                       artifacts=result['artifacts'], source_clean=result['clean'], source_head_unchanged=result['head_unchanged']))
(root / 'result-audit.json').write_text(json.dumps(audits, indent=2) + '\n', encoding='utf-8')
print(json.dumps(audits, indent=2))
