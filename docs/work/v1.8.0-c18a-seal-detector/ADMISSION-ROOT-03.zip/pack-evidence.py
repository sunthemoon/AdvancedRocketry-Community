"""Validate and package an already sealed leaf without editing that leaf."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile

leaf = Path(sys.argv[1]).resolve(strict=True)
dest = Path(sys.argv[2])
record_path = Path(sys.argv[3])
assert not dest.exists() and not record_path.exists()
manifest = leaf / 'SHA256SUMS.txt'
entries = []
for line in manifest.read_text('utf-8').splitlines():
    digest, name = line.split('  ', 1)
    relative = PurePosixPath(name)
    assert len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
    assert not relative.is_absolute() and '..' not in relative.parts and ':' not in name
    path = leaf / name
    assert path.resolve(strict=True).is_relative_to(leaf) and path.is_file()
    for ancestor in (path, *path.parents):
        if ancestor == leaf.parent:
            break
        assert not ancestor.is_symlink() and not ancestor.is_junction(), ancestor
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
    entries.append(path)
assert len(set(entries)) == len(entries)
entries.append(manifest)
assert set(entries) == {path for path in leaf.rglob('*') if path.is_file()}
sizes = [path.stat().st_size for path in entries]
assert max(sizes) < 50 * 1024 ** 2 and sum(sizes) < 100 * 1024 ** 2
with zipfile.ZipFile(dest, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(entries):
        archive.write(path, path.relative_to(leaf).as_posix())
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == {path.relative_to(leaf).as_posix() for path in entries}
    for path in entries:
        assert hashlib.sha256(archive.read(path.relative_to(leaf).as_posix())).hexdigest() == hashlib.sha256(path.read_bytes()).hexdigest()
record = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), argv=sys.argv,
              leaf=str(leaf), archive_path=str(dest.resolve()), files=len(entries),
              uncompressed_bytes=sum(sizes), max_file_bytes=max(sizes), archive_bytes=dest.stat().st_size,
              archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
              report_sha256=hashlib.sha256((leaf / 'REPORT.md').read_bytes()).hexdigest(),
              manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
              payload_hashes_and_crc_valid=True)
record_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
