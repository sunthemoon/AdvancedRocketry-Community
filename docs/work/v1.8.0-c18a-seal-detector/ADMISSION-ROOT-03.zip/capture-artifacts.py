"""Retain identities and packaging inventory, not reproducible JAR/class copies."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

tree = Path('D:/GitHub/arce-v180-seal-admission-20261009')
root = Path(__file__).resolve().parent
assert subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD']).decode().strip() == '452fd2a0dc12895c2e2b955c80115457459888bb'
rows = []
for jar in sorted((tree / 'build/libs').glob('*.jar')):
    with zipfile.ZipFile(jar) as archive:
        entries = [name for name in archive.namelist() if 'SealDetectorAdmission' in name]
    rows.append(dict(name=jar.name, bytes=jar.stat().st_size,
                     sha256=hashlib.sha256(jar.read_bytes()).hexdigest(), admission_entries=entries))
classes = {path.relative_to(tree / 'build/classes/java/main').as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
           for path in (tree / 'build/classes/java/main').rglob('SealDetectorAdmission*.class')}
argv = ['git', '-C', str(tree), 'diff', '--check', 'a2e3c476de0188c93c0de85bf005d4a0e02e3251', 'HEAD']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
(root / 'source-whitespace.log').write_bytes(result.stdout)
record = dict(source='452fd2a0dc12895c2e2b955c80115457459888bb', artifacts=rows, compiled_class_sha256=classes,
              whitespace_command=dict(argv=argv, started_utc=started,
                                      ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                      exit_code=result.returncode))
(root / 'artifacts-corrected.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(rows, indent=2))
raise SystemExit(result.returncode)
