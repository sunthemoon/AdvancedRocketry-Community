"""Use the unchanged repository checker on the declared record files only."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

repo = Path('D:/GitHub/AdvancedRocketry-Community')
root = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ('before', 'after')
names = ['docs/work/v1.8.0-c18a-seal-detector/ADMISSION-TASK-03.md',
         'docs/work/v1.8.0-implementation-log.md', 'docs/status/CURRENT_VERSION.md',
         'docs/status/COMPLETION-PLAN.md']
if mode == 'after':
    names.append('docs/work/v1.8.0-c18a-seal-detector/ADMISSION-VERIFICATION-03.md')
checker = runpy.run_path(str(repo / 'scripts/validate_repository.py'))
broken, checked = checker['markdown_link_errors'](repo.resolve(), [repo / name for name in names])
def normalized(errors):
    return Counter((line.split(' -> ', 1)[0].rsplit(':', 1)[0], line.split(' -> ', 1)[1]) for line in errors)
result = dict(head=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip(),
              checker_sha256=hashlib.sha256((repo / 'scripts/validate_repository.py').read_bytes()).hexdigest(),
              checked_links=checked, errors=broken,
              document_sha256={name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names})
if mode == 'after':
    baseline = json.loads((root / 'record-links-before.json').read_text('utf-8'))
    assert result['checker_sha256'] == baseline['checker_sha256']
    added = normalized(broken) - normalized(baseline['errors'])
    result['introduced_errors'] = [dict(file=file, target=target, count=count) for (file, target), count in added.items()]
path = root / ('record-links-' + mode + '.json')
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(checked=checked, errors=len(broken), introduced=result.get('introduced_errors'))))
if mode == 'after' and result['introduced_errors']:
    raise SystemExit(1)
