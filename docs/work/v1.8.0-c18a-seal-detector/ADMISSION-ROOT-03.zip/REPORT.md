# Root development verification: C18a-SEAL-ADMISSION-03

Date: 2026-10-09 Asia/Taipei; command timestamps use UTC on 2026-10-08.
Status: corrected Root cohort completed; independent corrected review and
source integration are pending at this report's creation. No Gate approval.

## Source, preparation and authority

- Preparation is committed/pushed at `771543514c0ccf6f09f22b62ba1d36e9a6d9b7f9`
  before new source authoring. Its parent development delivery is 9429d00b.
- Original source: `e456ffc0eab1c0752fa5e6e57b4c63ddedbac964`, src tree
  `1661afb000ba80e2a4032076875f2afab9397e0d`; one new 380-line main GameTest
  class, twelve annotated cases. Its source and full cohort are not rewritten.
- Independent original review finds a Medium exceptional worker-cleanup defect.
  Corrective scope is committed/pushed at a2e3c476 before correction. Merge
  c047d805 preserves both original source and the preparation/scope history.
- Corrected source: `452fd2a0dc12895c2e2b955c80115457459888bb`, complete src tree
  `f085b52691c4f72814566841f2d0ff69394a99e3`; versus scope base a2e3c476, exactly
  the new 407-line GameTest class and new 104-line four-case unit file.
- Both candidates use identical seven Gradle inputs. Their exact blob pairs,
  working source hashes, patches and annotation counts are retained separately
  in `source-scope*.json` and the two source patch files.
- No existing production source, build, registration, ID, schema, asset,
  provenance or content ledger changes. The main-source GameTest enters normal
  main/sources JARs; those artifact identities legitimately change. API JAR
  identity stays unchanged. This is not a hidden development-only artifact.
- No Claude call or delegated implementation. The independent read-only agent
  uses its own clone/cache/evidence, and does not provide release approval.
- Main remains on the v1.8 development branch. User-owned dirty AGENTS.md,
  inherited untracked files, unrelated worktrees and sealed evidence are not
  edited, staged, removed or adopted. Acceptance cursor remains v1.0 under
  ADR-060; active v1.8 remains IN_PROGRESS / IMPLEMENTING.

## Test meaning and correction

Each owned fixture first proves native survival-mode use of the actual
registered detector, exact structured sealed/not-known-supplied component JSON,
requester-only embedded feedback and cooldown. It then removes the control's
cooldown and clears replies so the refusal cannot be masked by that control.

Nine item-entry refusals cover count two, captured stack identity replacement,
spectator, dead, removed, missing connection, foreign Level, stale same-UUID
PlayerList object and off-thread call. The probe poisons selected position,
face and hit-location getters. FAIL, no feedback/cooldown, both held identities
and serialized data, and installed atmosphere metrics are checked. This calls
actual item admission directly, not a native-client refusal path.

Three local cases cover terminal/idempotent closure, off-thread refusal before
instrumented actor/Level/selected getters, and post-query actual held-identity
change. Fresh uninstalled service/manager/catalog fixtures do not replace the
installed runtime. The fresh manager's empty-to-present metrics transition
witnesses the supply query before the controlled accessor changes the hand.
That accessor callback is not a native client/provider mutation. Hand/stack
getters are not separately poisoned; "all context" is not broader direct
instrumentation than the documented getters. Local closure is not installed
server-stop/restart qualification.

The original independent compiled-helper diagnostic proves that an unresolved
worker exception still unwinds into an external resource-close witness. Source
inspection establishes the actual Minecraft closers' applicability; the
diagnostic does not execute their bodies or reproduce an ordinary gameplay
hang. Original independent verdict remains CHANGES_REQUESTED for e456ffc0.

Correction shares one fixture-owned WorkerGate with each local reader. The
first action in both actual close methods is a terminal-state check. A surviving
worker prevents actor/channel, service/manager and cell cleanup. This fails and
retains the exceptional fixture; it does not automatically recover it. The
unchanged helper still waits two seconds, cancels/interrupts and joins for two
seconds; normal workers finish before cleanup. No forced stop, event hook,
periodic poller or production seam is introduced. Four unit cases use the actual
helper/gate for completion, callable cause/termination, non-cooperative-worker
resource-cleanup refusal followed by explicit release/join, and live-worker
replacement refusal followed by terminal reuse. The unit unwinding witness is
not itself Minecraft world-cleanup execution.

## Actual Root commands and results

Java 17.0.7 is selected explicitly. Root uses installed offline dependencies,
not a dependency install or global configuration change. C:/D: free space is
checked before each command and exceeds 10 GiB. TEMP/TMP/TMPDIR and Java temp
are the cohort's own D: directory. Full argv/cwd/UTC intervals, raw logs, hashes
and immediate child exits are retained in each `commands.json`.

| Actual command | Original e456ffc0 | Corrected 452fd2a0 |
| --- | --- | --- |
| `gradlew.bat clean build --no-daemon --offline --no-build-cache --rerun-tasks` | Exit 0; 20 actual tasks; 2,179 JUnit /378 XML /0 F/E/S | Exit 0; 20 actual tasks; 2,183 JUnit /379 XML /0 F/E/S |
| `gradlew.bat test --no-daemon --offline --no-build-cache --rerun-tasks` | Exit 0; 17 actual tasks; fresh 2,179 /378 /0 F/E/S | Exit 0; 17 actual tasks; fresh 2,183 /379 /0 F/E/S |
| `gradlew.bat runData --no-daemon --offline`, twice | Both exit 0; first written 841, second 0 | Both exit 0; written 0 each |
| Separate `git diff --exit-code` after each DataGen | Both exit 0, empty | Both exit 0, empty |
| `python -B scripts/validate_v180_content_ledger.py --require-accepted` | Exit 0 | Exit 0; 186 PLANNED /154 REVIEW unchanged |
| `python -B scripts/validate_bootstrap_provenance.py` | Exit 0 | Exit 0; mechanical check, not a new license approval |
| `python -B scripts/validate_repository.py --require-approved-identity` | **Exit 1**; 44 pass /1 inherited Markdown failure | **Exit 1**; 44 pass /same failure |
| `git diff --check` | Exit 0 | Exit 0; separate committed scope diff check also exit 0 |
| `gradlew.bat runGameTestServer --no-daemon --offline --no-build-cache` | Exit 0; all 565 required pass | Exit 0; all 565 required pass |

Original build/test end at 16:48:36.426492 /16:52:58.514474 UTC; original native
ends 17:06:58.606720 UTC. Corrected build/test end at 17:15:05.092363 /
17:18:49.167761 UTC; corrected native ends 17:31:42.070196 UTC. Each native
suite schedules 565 tests across 147 batches; the admission batch has 12.
Terminal required-test markers, not scheduling or JUnit XML, establish native
completion. Each build/test XML ZIP is captured immediately before another
task overwrites the output. Independent raw-hash/XML/batch recount is retained
in `result-audit.json`; the unit diagnostic refusal takes about four seconds.
The original first DataGen has an empty HashCache, writes 841 byte-identical
files and still leaves an empty tracked diff; its second writes zero. Do not
substitute corrected Root or independent cache-state counts for that first run.

Each native latest log retains **62 ERROR headers /0 FATAL**; raw latest/debug/
console and line-numbered context are retained, not counted three times. Some
originate in failure fixtures, but that is not a waiver. The strict checker
stops after 256 Markdown errors, not a complete remaining-debt count. Original
and corrected strict raw logs have identical SHA-256
`5af00089550e59579d9ff73c08d3a919a0cf66857915a5f4ee2729b54dd60ea0`.
The orchestrators deliberately exit 1 for that child failure, not a successful
overall Gate result. Existing warnings and failed checks are not suppressed.

Fresh read-only primary disassembly of the pinned mapped Forge JAR is retained
under `primary/`: both javap commands exit 0. The JAR SHA-256 is
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
It confirms captured held identity/context accessors and native ServerPlayer
behavior; it is API evidence, not gameplay/client acceptance. An initial
exploration looked up an incorrect v1.0 filename, then read the actual
V1.0.0-COMMUNITY-MVP document. This is not a source/runtime pass or failure.

## Artifacts, cleanup and limits

Corrected endpoint inventory and compiled-class hashes are retained in
`artifacts-corrected.json`, before owned cleanup:

- Main JAR: 6,049,561 bytes; SHA-256 `865ba5e264cc19a964959ab7ed9c0c0d05b7c9ac9d091ef2e919d285c9a9f019`.
- Sources JAR: 2,879,064 bytes; SHA-256 `d4c2cc5e3d1a21b83857ac5aac36bf97b648858045e363e93a432a901a746415`.
- API JAR: 51,052 bytes; SHA-256 `aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b`.

The main JAR contains the GameTest and eight nested classes; sources contains
its main source; API contains none. No whole JAR/source/build/world archive is
retained. These endpoint hashes are not packaged S1/S2 or R1 certification.

One native PowerShell cleanup succeeds at 17:32:53.7856427 UTC after source
pin/clean/tracked-input, ended-process, absolute-containment and reparse checks.
It removes only this task's build, run-data, .gradle and two TEMP directories.
Logical inventory is 273,864,626 bytes; no physical-reclaimed-space claim is
made. No denied retry, unrelated process termination or source-world deletion.
The clean committed source worktree and compact evidence remain.

Uncompleted: corrected independent disposition/integration at creation, full
detector qualification, unlock/acquisition, installed precedence/lifecycle,
reload/unload, protection mods, packaged/restart, real-client V1/V2, performance,
compatibility and all v1.8 Required Gates. ADR-068 remains PROPOSED, R-021 OPEN;
physical hatch/hook/save writer and unchosen owner policies remain disabled.
The original Medium record and prior slice's Low preparation deviation are
not erased. Root's passing development commands are not delivery or acceptance.

## Subsequent independent handover and source integration

Independent corrected actual review and full cohort complete with no new
Critical/High/Medium/Low source finding. The old Medium is addressed only for
declared retain-on-unresolved-worker cleanup. Both forced stages genuinely
execute 2,183 /379 /0 F/E/S, native passes all 565 required, DataGen writes 841
then 0 with both diffs empty, strict exits 1 and 62 native ERROR remain unwaived.
Three artifacts match Root. The original independent report's first DataGen
counter is wrong; a separate corrected-leaf erratum cites original sealed raw
lines/hashes, without editing its report/manifest. Reviewer setup/read/checker
failures and missing exploratory exit/time boundaries remain explicit.

Independent corrected report SHA-256:
`9afc8530b24435aeb6791978bd3d370d660652fe30abd13cc3e7c44d2929e6f4`.
Its new erratum SHA-256:
`13597ddc308f52318951252368ee0b0fd571154c927139859c214ed70e309f71`.
Original/corrected independent archives are copied only from unchanged sealed
payloads, with hashes/CRC/relative manifests/budgets verified; packaging details
are in `pack-original.json` and `pack-corrected.json`. Their total file counts
include the manifest itself. Their own cleanup succeeds once, no refused retry.

All read/process/HEAD interests release before source branch normal push and
main source merge/normal push. Main integrated source is
`b001316102d064545fb81d9f4f2141ae52931118`; `source-integration.json` records
complete src/seven Gradle inputs equal to tested 452fd2a0 and unchanged user
AGENTS.md hash. The merge SHA is not rerun. Source integration supersedes the
report-creation pending checkpoint, not any historical test identity.
Evidence-record publication/review remains pending at Root seal; no full
item/ledger delivery, version Gate or policy/ADR/risk approval is made.
