# Independent disposition-record review: installed detector runtime qualification

Reviewer: delegated read-only Codex agent
`/root/seal_installed_runtime_disposition_review`, not Root or an implementer.
Date: 2026-10-09 Asia/Taipei. Main HEAD inspected:
`c554e810780f0f9b5b8b6cd290bddd6e0822b2eb`.
This is an actual draft-record/evidence audit, not another runtime execution,
full detector delivery or release/Gate approval. No Claude or child agent was called.

## Findings first

**No introduced Critical, High, Medium or Low record finding was identified in
the six assigned draft inputs.** Their source/test/merge attribution, sealed
evidence metadata, scoped completion and remaining acceptance reconcile with
actual Git objects, payloads and raw cohort results. This does not assert absence
of defects elsewhere in the mod.

The following carry-over limitations remain open, rather than being cleared by
this record review:

- **Low procedural limitation, already disclosed.** The preparation-order
  deviation is explicitly retained at
  [verification lines 51-57](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01/snapshots/docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md#L51)
  and [implementation-log lines 11-15 and 36-39](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01/snapshots/docs/work/v1.8.0-implementation-log.md#L11).
  The dedicated task is in the original committed candidate; the later central
  log is still uncommitted during this audit. Root's chronology is separately
  attributed, not independently reconstructed from file timestamps. The draft
  does not claim retroactive compliance or an owner waiver.
- **Inherited acceptance failure, not an introduced record defect.** The actual
  draft-tree strict validator exits 1 with 44 PASS and one failing Markdown-link
  check; its emitted list is capped at 256 errors. The reviewed records retain
  the same source-cohort failure at
  [verification lines 83-91](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01/snapshots/docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md#L83).
  Both corrected native logs retain 62 ERROR headers and zero FATAL. These are
  not error-free or all-Gate-passing cohorts. No error cause, permanent repair
  or waiver is inferred from the passing test totals.

The original Medium rendered-projection assertion limitation is resolved only
for the corrected source's response-capture scope. Actual original/correction
diffs, serialized native payloads and the independent source review support
[verification lines 43-49](D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01/snapshots/docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md#L43).
Original passing runs are neither deleted nor rebound to the corrected SHA.

## Scope completed and exact inspected identities

Read live AGENTS.md, mandatory project/product/porting/roadmap/test/Gate/v1+
quality/parallel governance, both active-development v1.8 and acceptance-cursor
v1.0 plans, preceding v0.9/v1.7 Gate records, accepted ADR-060/067 and upstream
license/provenance policies. Their hashes are retained in
`governance-read-identities.json`. Only this NEW assigned external leaf was written.

The following hashes identify the actual pre-audit drafts, not a later Root
association edit or delivered documentation commit. `draft-input-hashes.json`
and `final-input-hashes.json` match exactly; all four Markdown drafts are retained
under `snapshots/`.

| Assigned path | Bytes | SHA-256 |
|---|---:|---|
| docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md | 8,827 | `564491dbf052a79c7baff19f523e1d327860fae0bed96d383b98e4c55f5a66be` |
| docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-ROOT-02.zip | 1,252,110 | `db96396eb1f0727b37893b21c36b0fc83ed4b87e5bf06251b0e2d0a8654c2b2d` |
| docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-INDEPENDENT-02.zip | 1,976,192 | `5196bc10f020da4160e9da79a398bbe4db2c8041eb721aef03b91612159208c0` |
| docs/status/COMPLETION-PLAN.md | 51,956 | `4658234c33b4f3262c8bf146dc432349856206596477eb3f24c316a73255f48f` |
| docs/status/CURRENT_VERSION.md | 5,968 | `e8130d8f17612e2277181f80ab47162c52db944fefe6acd0b19dc0e521d8e053` |
| docs/work/v1.8.0-implementation-log.md | 522,700 | `e66d5e9d235af4c1236410259434bddf9df4a37ecfffdb42934bcdf8214b05a3` |

Exact tracked draft patch: `draft-records.log`, SHA-256
`91f491b6ce52e22bfe6bbdf478f37e0ae64f1b06a1ae8b1455f6f1d7d8ca38b4`.
The new untracked verification is bound by its full snapshot and hash above;
untracked ZIPs are bound by their hashes and complete entry audit.
User-owned dirty AGENTS.md remains 15,797 bytes, SHA-256
`c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09`.

## Source, integration and attribution checks

Base is `80328a2d25c0c695cc9c8b09ee79910bfc458ec9`; original candidate is
`8b608d88205be9ff4cd19bdf9516317c9a6494d5`; actual corrected tested source is
`794dd123f9af0047adbab385eddeb1c9d5089773`. Integration c554e810 has the actual
base/tested parents, and the tested source is its ancestor. Complete `src` tree
at tested and integrated commits is
`005126337796bcdb1abbfda699bd601c4c2db253`; all seven Gradle input blob IDs match.
`src/main` is unchanged from base:
`9b1e79254d7467c8afc1c700006cf2c0318d4cd3`. Actual source/build diff and working
source/build diff both exit 0. `source-equivalence.json` retains every object ID.

Actual base-to-corrected scope is only the new task and 242-line adapter test,
with two GameTests. Archived original/corrected source patches and corrected
source/task snapshots reconcile with Git. The original independent patch is
CRLF while current Git emits LF; exact byte hashes and canonical equivalence
remain separately recorded, not mislabeled byte identity.

Read-only `git ls-remote` confirms the integrated and source branch tips are
c554e810 and 794dd123 respectively; the local tracking ref also matches c554e810.
Historical non-force push mechanics and authoring chronology remain Root's
first-hand attribution, not facts reconstructible from this remote-tip query.
This reviewer did not commit, push, select a release candidate or move HEAD.

The source genuinely exercises the existing startup-installed external
full-collision state rule through registered-item native use in both hands.
Serialized outer/nested Component keys/arguments, actor-only non-overlay
callbacks, shared cooldown, held identity/count/NBT and selected-cell
nonmutation are bounded assertions. Embedded callbacks do not prove actual
client packet delivery/rendering. Existing local-catalog coverage is unchanged
and not relabeled as installed-runtime evidence.

## Actual sealed-evidence checks and separately attributed results

Both ZIPs pass CRC, safe relative-name, no-duplicate, complete manifest coverage
and every manifest digest check. All 62 Root entries and 94 independent entries
match their separately sealed external leaves byte-for-byte. Root manifest binds
61 files plus itself; its separate pre-manifest inventory accurately describes
60 payloads /11,827,572 bytes. Independent manifest binds 93 payloads /18,512,743
bytes plus itself. REPORT digests match the draft. Neither archive was modified
or copied wholesale into this review leaf. Details: `archive-audit.json`.

Every retained command log in all six cohorts matches its recorded byte length
and SHA-256. Independent recount of zipped JUnit XML and raw native logs gives:

| Evidence owner and pin | Actual XML suites/testcases/F/E/S | Native required tests | latest.log ERROR/FATAL |
|---|---|---|---|
| Root original cohort-02, 8b608d88 | 378 /2,179 /0/0/0 | 553 pass | 62 /0 |
| Root corrected cohort-03, 794dd123 | 378 /2,179 /0/0/0 | 553 pass | 62 /0 |
| Independent original cohort-02, 8b608d88 | 378 /2,179 /0/0/0 | 553 pass | 62 /0 |
| Independent corrected cohort-03, 794dd123 | 378 /2,179 /0/0/0 | 553 pass | 62 /0 |

Both cohort-01 launcher failures have zero executed XML/native tests. Four
genuine builds record all 20 actionable tasks executed, no cached `:test` line;
both DataGen command/diff pairs succeed with empty diffs in each genuine cohort.
Corrected console observations record three structural non-overlay responses
per hand and zero peer replies. Exact sources/argv/times/digests/terminal lines
and recounted values are in `cohort-evidence-audit.json`, not a borrowed summary.
The recorded Root build end 15:29:27.798186 UTC and native end
15:42:27.726670 UTC agree with CURRENT_VERSION. Independent corrected commands
end 15:52:44 UTC. Source-cohort strict logs all retain 44 PASS /one failed check.

Root's 23/23 corrected and 19/19 original controls reconcile; eight retained
bounded primary javap outputs match their recorded hashes and common mapped-JAR
identity. Three artifact identities agree across cohorts and with the preceding
sealed placement evidence; archived inventories report no adapter fixture in
normal JARs. This reviewer did not rebuild the deleted artifacts or independently
rerun javap. The two source reviewers' successful single-attempt cleanup
scripts/results/inventories remain separately attributed; no previous refused
target or physical-space-reclamation claim is introduced.

## Commands actually executed by this record reviewer

Full read-only subprocess argv, UTC times, exit codes and raw-output hashes are
in `review-commands.json`. Python used `-B`; validator TEMP/TMP/TMPDIR and
bytecode controls point to this leaf's empty `Temp`. No install, build, native
Minecraft process, source-world operation or full runtime rerun occurred.

| Reviewer command/check | Actual result |
|---|---|
| audit_records.py initial /archives /equivalence /evidence /governance /closure | exit 0; retained outputs and snapshot checks |
| audit_records.py supplemental, original | exit 1; original CRLF-vs-LF byte comparison retained |
| supplemental, separate corrected invocation | exit 0; explicit canonical-content comparison, exact byte difference preserved |
| python -B scripts/validate_v180_content_ledger.py --require-accepted | exit 0; 186 PLANNED /154 REVIEW assets |
| python -B scripts/validate_bootstrap_provenance.py | exit 0 |
| git --no-optional-locks diff --check | exit 0 |
| same whitespace check, base to tested source | exit 0 |
| python -B scripts/validate_repository.py --require-approved-identity | **exit 1; 44 PASS /one inherited failed check** |
| focused_links.py using unchanged validator helper | exit 0 for introduced-line attribution; 613 links /49 inherited errors /zero introduced errors, no per-file cap |
| Git source/input equivalence, ancestry, tracking/remote and final state checks | exit 0; matching held inputs/clean source/empty index diff |

The optional strict run is 16:10:29.654771-16:15:30.326552 UTC; raw output SHA-256
`31f92cd5bf2a915f7965d3ce1da1ab0439fb45b5833a8b0e6c6ff50c81639fdf`.
Its outer Python command collector exits 0 only after retaining actual child
results; that does not change strict exit 1 or constitute PASS.
Initial document-name/readiness locator errors, the supplemental failed checker,
its original script/verdict/output and normalization diagnosis remain in
`EXPLORATION-AND-CHECKER-FAILURES.md` and associated raw files. No failure was
deleted, hidden behind final counts or changed by lowering a repository assertion.

## Remaining acceptance, design decisions and recommendation

The completion checkbox is only the installed-rule development-test slice,
not full item or ledger delivery. Production/API/registry/assets/schema stay
unchanged. Complete actor/thread/lifecycle/post-query admission/refusal/order,
installed tag/door precedence, unlock, reload/unload, protection mods,
packaged/restart S1/S2 and real-client V1/V2 obligations remain open. Both full
Medium physical prerequisites, O1/O2/O3, ADR-068 PROPOSED and R-021 OPEN are not
accepted by these records. Ledger totals remain unchanged.

The status records preserve v1.8 IN_PROGRESS /IMPLEMENTING and the v1.0 earliest
unfinished acceptance cursor under ADR-060. **Current-version Required Gates
are not all satisfied.** The record review requests no new source/record fix in
its inspected scope; retain the qualified source evidence and this separately
attributed audit, commit only the intended task records, and continue current
v1.8 detector verification or its existing physical/save prerequisites. Do not
advance release approval or start later-version implementation from this review.

## Modified files, tests, evidence and release of interests

Main/source files modified by reviewer: **none**. Product tests added/changed by
reviewer: **none**. New audit scripts, command logs, compact source patches,
draft snapshots, hashes, failure records and this report exist only in the
assigned NEW external leaf. No full reproducible source/build/world tree is
retained; Temp is empty and no disposable-output debt was created.

Closure observation is 2026-10-08T16:19:00.902695 UTC: all six draft hashes and
user AGENTS hash unchanged; main HEAD, whole short status and exact record patch
unchanged; staged diff empty; source worktree remains clean at 794dd123.
All validator/audit subprocesses ended. All main/source/HEAD/index/Gradle-input,
source-world and original sealed-evidence read interests are explicitly
released by this completed report. Root may package this sealed leaf and add
only the separately attributed factual archive/report association; such later
record bytes are not claimed to be these audited draft hashes.

This leaf's relative `SHA256SUMS.txt` binds the compact retained evidence and
REPORT.md. Original sealed source evidence stays untouched.

D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01/REPORT.md
