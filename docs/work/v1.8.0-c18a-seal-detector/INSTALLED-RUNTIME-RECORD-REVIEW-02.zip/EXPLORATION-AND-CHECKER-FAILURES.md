# Retained reviewer exploration and checker failures

These are record-review preparation/checker failures, not Minecraft execution
results. No main source, validator assertion, timeout or budget was changed.

## Initial document-location probes

The first PowerShell exploration printed live AGENTS.md, Git status/branch/HEAD
and worktrees. It then queried mandatory document sizes using the speculative
`docs/versions/v1.8.0.md` name and searched `docs/adr`. The former emitted
`Cannot find path 'docs/versions/v1.8.0.md' because it does not exist`; `rg --files
docs/adr` emitted `The system cannot find the file specified. (os error 2)`.
That composite command ended 0 because later process output succeeded; it was
not an error-free probe. A following combined `Get-Content` call ended 1 when it
reached the same nonexistent version file. Actual filenames were located with
`rg --files docs/versions` and `rg --files docs`; the real v1.8 plan and accepted
ADR-067 were read without changing files. These initial tool outputs were not
redirected to leaf logs; the exact observed errors and composite results are
retained here rather than invented as successful reads.

A later `rg -n 'tempfile|TemporaryDirectory|temp|write_text|write_bytes|mkdir'
scripts/validate_bootstrap_provenance.py scripts/validate_v180_content_ledger.py`
returned 1 for no matches. It was a read-only locator query, not a validator run.

## Supplemental patch byte-comparison failure

`python -B audit_records.py supplemental` initially ended 1 at the final assertion.
Its original script, failed JSON verdict and full output remain as
`audit_records-original-supplemental.py`,
`supplemental-source-evidence-checks-original.json` and
`supplemental-inspection.log`.

The mismatch is exclusively EOL representation: current `git diff` for the
original candidate emits 16,802 bytes with no CRLF; independent sealed
`candidate.diff` has 17,117 bytes, containing 315 CRLF lines. Canonical content
is identical after CRLF-to-LF normalization, with exact original digests and
counts retained in `patch-eol-diagnosis.json`. Root's archived original patch is
already LF. The separate corrected supplemental invocation ended 0 and reports
EOL-normalized comparison explicitly; no archived file was changed.

The diagnostic PowerShell call also attempted `Get-Content strict-repository.log`
before the still-running subprocess had produced it. It emitted `Cannot find
path .../strict-repository.log because it does not exist` and that composite
call ended 1. The pending validator was not killed or replaced; it subsequently
completed, and its full output, UTC times and actual exit 1 were retained.

## Optional strict repository validation

The real `python -B scripts/validate_repository.py --require-approved-identity`
run ended 1: 44 checks passed and the existing Markdown-link check failed,
stopping its emitted list at 256 errors. Exact argv/times/output digest are in
`review-commands.json`; the raw failure is in `strict-repository.log`.
The outer `audit_records.py validators` invocation is a command collector and
ended 0 after saving every child's actual result; that outer exit does not
constitute validator PASS. The strict failure remains open in REPORT.md.

Focused calls to the unchanged `markdown_link_errors` helper cover all four
draft Markdown files without altering any cap or assertion. They retain 49
inherited link errors and no error on added lines, with no per-file cap reached.
This scoped attribution does not substitute for or erase strict repository
failure.
