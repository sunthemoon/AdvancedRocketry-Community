import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = ROOT / 'SHA256SUMS.txt'
assert not manifest.exists()
assert (ROOT / 'REPORT.md').is_file()
assert not any((ROOT / 'Temp').rglob('*'))
files = sorted(p for p in ROOT.rglob('*') if p.is_file())
assert all(p.resolve().is_relative_to(ROOT.resolve()) for p in files)
assert all(p.stat().st_size < 50 * 1024 ** 2 for p in files)
assert sum(p.stat().st_size for p in files) < 100 * 1024 ** 2
assert not any(part in ('build', 'source-cache', 'source-cache-corrected', 'gradle-cache')
               for p in files for part in p.relative_to(ROOT).parts)
manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
                            p.relative_to(ROOT).as_posix() + '\n' for p in files), encoding='utf-8')
rows = manifest.read_text('utf-8').splitlines()
for row in rows:
    digest, name = row.split('  ', 1)
    relative = Path(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest
print(json.dumps(dict(payloads=len(files), payload_bytes=sum(p.stat().st_size for p in files),
                      manifest_bytes=manifest.stat().st_size,
                      manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
                      report_sha256=hashlib.sha256((ROOT / 'REPORT.md').read_bytes()).hexdigest(),
                      all_relative_manifest_digests_valid=True), indent=2))
