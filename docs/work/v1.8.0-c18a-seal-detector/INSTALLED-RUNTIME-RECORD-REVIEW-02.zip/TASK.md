# Installed-runtime detector: independent disposition-record audit

Assigned by Root on 2026-10-09 Asia/Taipei to delegated read-only Codex reviewer
`/root/seal_installed_runtime_disposition_review`. This reviewer is neither Root
nor a source implementer; no Claude invocation or further delegation is allowed.

Audit actual uncommitted Root record additions/diffs at main checkout HEAD
`c554e810780f0f9b5b8b6cd290bddd6e0822b2eb`, against accepted ADR-067, mandatory
governance, separately sealed Root and independent source/command cohorts, and
actual tested source `794dd123f9af0047adbab385eddeb1c9d5089773`.

The assigned read set is:

- `docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md`.
- `docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-ROOT-02.zip`.
- `docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-INDEPENDENT-02.zip`.
- `docs/status/COMPLETION-PLAN.md`.
- `docs/status/CURRENT_VERSION.md`.
- `docs/work/v1.8.0-implementation-log.md`.

The sole write scope is this NEW external evidence leaf:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-disposition-independent-20261009-01`.
Own compact scripts, Temp, snapshots, raw command output and report may be retained
here. No main/source/index/HEAD edits, source worlds, installs, builds, existing
sealed evidence changes or other-agent cleanup are permitted. Live user-owned
dirty AGENTS.md must stay untouched.

Read-only shell/Git/Python/Java archive/hash operations, actual ZIP manifests and
payload verification, source/seven-build-input equivalence, and record ledger,
provenance and whitespace validators with `-B` and task-local Temp are allowed.
Optional strict repository validation must retain any failure. A full runtime
rerun would not replace the separately executed committed-source cohorts and is
not assigned here.

Review findings must be evidence-based, ordered by severity, with exact file and
line references. Retain exact inspected draft hashes/patch, actual command
results, failed attempts and limitations. Seal a relative SHA256SUMS manifest;
do not duplicate reproducible source/build trees. Explicitly release every
main/source/HEAD/input read interest and end the final answer with absolute
REPORT.md path. Root will package the sealed leaf separately.

Root's 2026-10-09 follow-up confirms all six held drafts and HEAD/index are
unchanged and authorizes only a factual post-audit archive/report association in
the verification record after release. Such a later association is not part of
these inspected draft identities.
