import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')
spec = importlib.util.spec_from_file_location('reviewed_repository_validator', MAIN / 'scripts/validate_repository.py')
validator = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = validator
spec.loader.exec_module(validator)
files = [
    'docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md',
    'docs/status/COMPLETION-PLAN.md',
    'docs/status/CURRENT_VERSION.md',
    'docs/work/v1.8.0-implementation-log.md',
]
results = []
for name in files:
    if name.endswith('INSTALLED-RUNTIME-VERIFICATION-02.md'):
        changed = set(range(1, len((MAIN / name).read_text('utf-8-sig').splitlines()) + 1))
    else:
        command = ['git', '--no-optional-locks', 'diff', '--unified=0', '--', name]
        diff = subprocess.run(command, cwd=MAIN, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout.decode('utf-8')
        changed = set()
        line = None
        for row in diff.splitlines():
            match = re.match(r'@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@', row)
            if match:
                line = int(match[1])
            elif line is not None and row.startswith('+') and not row.startswith('+++'):
                changed.add(line)
                line += 1
            elif line is not None and row.startswith(' '):
                line += 1
    errors, checked = validator.markdown_link_errors(MAIN, [MAIN / name])
    introduced = []
    for error in errors:
        match = re.match(re.escape(name) + r':(\d+) ->', error)
        if match and int(match[1]) in changed:
            introduced.append(error)
    results.append(dict(path=name, checked=checked, changed_lines=sorted(changed),
                        errors=errors, introduced_errors= introduced,
                        validation_capped=any('stopped after' in e for e in errors)))
(LEAF / 'focused-link-results.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
for r in results:
    print(r['path'], 'checked', r['checked'], 'errors', len(r['errors']),
          'introduced_errors', len(r['introduced_errors']), 'capped', r['validation_capped'])
assert all(not r['introduced_errors'] for r in results)
print('No introduced link error reported by the unchanged validator. Inherited/capped results retained; not a repository PASS.')
