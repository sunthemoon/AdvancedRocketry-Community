import hashlib
import io
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

LEAF = Path(__file__).resolve().parent
MAIN = Path('D:/GitHub/AdvancedRocketry-Community')
TESTED = '794dd123f9af0047adbab385eddeb1c9d5089773'
PIN = 'c554e810780f0f9b5b8b6cd290bddd6e0822b2eb'
FILES = [
    'docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-VERIFICATION-02.md',
    'docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-ROOT-02.zip',
    'docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-INDEPENDENT-02.zip',
    'docs/status/COMPLETION-PLAN.md',
    'docs/status/CURRENT_VERSION.md',
    'docs/work/v1.8.0-implementation-log.md',
]
commands = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(name, argv, cwd=MAIN, env=None):
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (LEAF / (name + '.log')).write_bytes(result.stdout)
    commands.append(dict(name=name, argv=argv, cwd=str(cwd), started_utc=start,
                         ended_utc=datetime.now(timezone.utc).isoformat(), exit=result.returncode,
                         output_sha256=sha(result.stdout)))
    print(name, 'exit', result.returncode, result.stdout.decode('utf-8', 'replace')[:4000])
    return result

def initial():
    snapshots = LEAF / 'snapshots'
    snapshots.mkdir(exist_ok=True)
    rows = []
    for name in FILES + ['AGENTS.md']:
        data = (MAIN / name).read_bytes()
        rows.append(dict(path=name, bytes=len(data), sha256=sha(data)))
        if name.endswith('.md') and name != 'AGENTS.md':
            target = snapshots / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    (LEAF / 'draft-input-hashes.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
    run('initial-head', ['git', 'rev-parse', 'HEAD'])
    run('initial-status', ['git', 'status', '--short', '--untracked-files=all'])
    run('initial-worktrees', ['git', 'worktree', 'list', '--porcelain'])
    run('draft-records', ['git', 'diff', '--binary', '--', *FILES])
    run('source-commit', ['git', 'show', '--no-patch', '--format=fuller', TESTED])
    run('integration-commit', ['git', 'show', '--no-patch', '--format=fuller', PIN])
    run('source-scope', ['git', 'diff', '--stat', '80328a2d25c0c695cc9c8b09ee79910bfc458ec9', TESTED])
    run('source-patch', ['git', 'diff', '80328a2d25c0c695cc9c8b09ee79910bfc458ec9', TESTED])
    print('Initial hashes:', json.dumps(rows, indent=2))

def archives():
    reports = {}
    results = []
    for name in FILES:
        if not name.endswith('.zip'):
            continue
        path = MAIN / name
        which = 'root' if name.endswith('ROOT-02.zip') else 'independent'
        external = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0') / ('seal-installed-runtime-' + which + '-20261008-01')
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            result = dict(path=name, zip_bytes=path.stat().st_size, zip_sha256=sha(path.read_bytes()),
                          entries=len(names), duplicate_names=len(names) != len(set(names)), crc_bad=z.testzip(),
                          uncompressed_bytes=sum(x.file_size for x in z.infolist()), manifests=[], payloads=[], errors=[])
            for entry in names:
                data = z.read(entry)
                clean = Path(entry)
                if clean.is_absolute() or '..' in clean.parts or '\\' in entry:
                    result['errors'].append('unsafe entry ' + entry)
                eq = (external / entry).is_file() and (external / entry).read_bytes() == data
                result['payloads'].append(dict(path=entry, bytes=len(data), sha256=sha(data), external_equal=eq))
                if not eq:
                    result['errors'].append('external unequal ' + entry)
                if entry.endswith('SHA256SUMS.txt'):
                    manifest = dict(path=entry, rows=[])
                    for line in data.decode('utf-8-sig').splitlines():
                        if not line.strip():
                            continue
                        digest, rel = line.split(None, 1)
                        rel = rel.lstrip('* ')
                        valid = rel in names and sha(z.read(rel)) == digest.lower()
                        manifest['rows'].append(dict(path=rel, sha256=digest, valid=valid))
                        if not valid:
                            result['errors'].append('manifest invalid ' + entry + ' ' + rel)
                    result['manifests'].append(manifest)
                if entry == 'REPORT.md':
                    reports[which] = data.decode('utf-8-sig')
                    (LEAF / (which + '-report-inspection.txt')).write_bytes(data)
            payload_names = set(names) - {m['path'] for m in result['manifests']}
            manifested = {r['path'] for m in result['manifests'] for r in m['rows']}
            result['unmanifested_payloads'] = sorted(payload_names - manifested)
            result['extra_manifest_paths'] = sorted(manifested - set(names))
            results.append(result)
            print(which, json.dumps({k: v for k, v in result.items() if k not in ('payloads', 'manifests')}, indent=2))
            print('MANIFESTS', [(m['path'], len(m['rows'])) for m in result['manifests']])
    (LEAF / 'archive-audit.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    for name, report in reports.items():
        print('\n===== ' + name.upper() + ' REPORT =====\n' + report)
    assert all(not r['errors'] and not r['duplicate_names'] and r['crc_bad'] is None and not r['unmanifested_payloads'] for r in results)

def equivalence():
    inputs = ['build.gradle', 'settings.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
              'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties']
    ids = {}
    for ref in ['80328a2d25c0c695cc9c8b09ee79910bfc458ec9', TESTED, PIN]:
        ids[ref] = {}
        for path in ['src', 'src/main', *inputs]:
            result = run('identity-' + ref[:8] + '-' + path.replace('/', '_'),
                         ['git', '--no-optional-locks', 'rev-parse', ref + ':' + path])
            assert result.returncode == 0
            ids[ref][path] = result.stdout.decode().strip()
    assert ids[TESTED] == ids[PIN]
    assert all(ids[TESTED][p] == ids['80328a2d25c0c695cc9c8b09ee79910bfc458ec9'][p] for p in ['src/main', *inputs])
    (LEAF / 'source-equivalence.json').write_text(json.dumps(ids, indent=2) + '\n', encoding='utf-8')
    assert run('equivalent-source-build-diff', ['git', '--no-optional-locks', 'diff', '--exit-code', TESTED, PIN, '--', 'src', *inputs]).returncode == 0
    assert run('working-source-build-diff', ['git', '--no-optional-locks', 'diff', '--exit-code', '--', 'src', *inputs]).returncode == 0
    assert run('source-is-integrated', ['git', 'merge-base', '--is-ancestor', TESTED, PIN]).returncode == 0
    run('tracking-ref', ['git', 'rev-parse', 'refs/remotes/origin/codex/v1.8.0-classic-content'])
    run('remote-refs', ['git', 'ls-remote', '--heads', 'origin', 'codex/v1.8.0-classic-content', 'test/v1.8.0-seal-installed-runtime'])

def evidence():
    all_results = []
    for name in FILES:
        if not name.endswith('.zip'):
            continue
        which = 'root' if name.endswith('ROOT-02.zip') else 'independent'
        with zipfile.ZipFile(MAIN / name) as z:
            for cohort in ['cohort-01', 'cohort-02', 'cohort-03']:
                data = json.loads(z.read(cohort + '/results.json'))
                commands_data = data['commands']
                errors = []
                command_rows = []
                for row in commands_data:
                    log = z.read(cohort + '/' + row['name'] + '.log')
                    valid = row['log_sha256'] == sha(log) and row['bytes'] == len(log)
                    if not valid:
                        errors.append('command output hash/size ' + row['name'])
                    command_rows.append(dict(name=row['name'], source=row.get('source'), argv=row['argv'],
                                             exit=row['exit_code'], log_sha256=sha(log),
                                             started_utc=row['started_utc'], ended_utc=row['ended_utc'],
                                             free_bytes=row['free_bytes'], hash_size_valid=valid))
                with zipfile.ZipFile(io.BytesIO(z.read(cohort + '/unit-xml.zip'))) as xml_zip:
                    assert xml_zip.testzip() is None
                    xml_names = [n for n in xml_zip.namelist() if n.endswith('.xml')]
                    totals = dict(testcase_nodes=0, failures=0, errors=0, skipped=0)
                    for xml_name in xml_names:
                        root = ET.fromstring(xml_zip.read(xml_name))
                        totals['testcase_nodes'] += len(list(root.iter('testcase')))
                        for key in ('failures', 'errors', 'skipped'):
                            totals[key] += len(list(root.iter(key[:-1] if key in ('failures', 'errors') else key)))
                    xml_counts = dict(suites=len(xml_names), **totals)
                    if data.get('actual_testcase_nodes') != totals['testcase_nodes']:
                        errors.append('actual testcase disagreement')
                result = dict(agent=which, cohort=cohort, source=data['source'],
                              commands=command_rows, unit_xml=xml_counts, errors=errors)
                if cohort != 'cohort-01':
                    native = z.read(cohort + '/native.log').decode('utf-8-sig')
                    latest = z.read(cohort + '/native-latest.log').decode('utf-8-sig')
                    build = z.read(cohort + '/build.log').decode('utf-8-sig')
                    repo = z.read(cohort + '/repository.log').decode('utf-8-sig')
                    result.update(
                        build_terminal=[x for x in build.splitlines() if 'BUILD SUCCESSFUL' in x or 'actionable tasks:' in x],
                        cached_test_lines=[x for x in build.splitlines() if x.startswith('> Task :test ')],
                        native_terminal=[x for x in native.splitlines() if 'GAME TESTS COMPLETE' in x or 'required tests passed' in x],
                        native_error_headers=sum(1 for x in latest.splitlines() if re.search(r'\[[^\]]*/ERROR\]', x)),
                        native_fatal_headers=sum(1 for x in latest.splitlines() if re.search(r'\[[^\]]*/FATAL\]', x)),
                        native_observations=[dict(line=i, text=x) for i, x in enumerate(native.splitlines(), 1) if x.startswith('ARCE_SEAL_INSTALLED_RULE ')],
                        repository_counts=dict(passed=sum(1 for x in repo.splitlines() if x.startswith('[PASS]')),
                                               failed=sum(1 for x in repo.splitlines() if x.startswith('[FAIL]'))),
                        repository_sha256=sha(z.read(cohort + '/repository.log')),
                        datagen_diff_bytes=[len(z.read(cohort + '/data-' + n + '-diff.log')) for n in ('1', '2')],
                        artifacts=data['artifacts'],
                    )
                    assert totals['testcase_nodes'] == 2179 and len(xml_names) == 378
                    assert not any(totals[k] for k in ('failures', 'errors', 'skipped'))
                    assert result['native_error_headers'] == 62 and result['native_fatal_headers'] == 0
                    assert len(result['native_observations']) == 2
                    assert result['datagen_diff_bytes'] == [0, 0]
                    assert any('All 553 required tests passed' in x for x in result['native_terminal'])
                    if cohort == 'cohort-03':
                        assert all('payloads=' in row['text'] and row['text'].count('overlay=false') == 3
                                   and row['text'].count('message.advancedrocketrycommunity.seal_detector.reading') == 3
                                   and row['text'].count('message.advancedrocketrycommunity.seal_detector.supply.not_known_supplied') == 3
                                   for row in result['native_observations'])
                assert not errors
                all_results.append(result)
                print(which, cohort, 'source', data['source'], 'unit XML', xml_counts,
                      'native', result.get('native_terminal'), 'repository', result.get('repository_counts'))
            if which == 'root':
                retained = json.loads(z.read('retained-manifest.json'))
                assert retained['payload_count'] == len(retained['payloads']) == 60
                assert retained['payload_bytes'] == sum(r['bytes'] for r in retained['payloads']) == 11827572
                assert all(r['bytes'] == len(z.read(r['path'])) and r['sha256'] == sha(z.read(r['path'])) for r in retained['payloads'])
                scope = json.loads(z.read('scope-inspection.json'))
                assert scope['passed'] == scope['total'] == sum(scope['checks'].values()) == 23
            else:
                assert sum(x.file_size for x in z.infolist() if x.filename != 'SHA256SUMS.txt') == 18512743
    (LEAF / 'cohort-evidence-audit.json').write_text(json.dumps(all_results, indent=2) + '\n', encoding='utf-8')

def validators():
    temp = LEAF / 'Temp'
    temp.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
    for name, argv in [
        ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
        ('provenance', [sys.executable, '-B', 'scripts/validate_bootstrap_provenance.py']),
        ('whitespace', ['git', '--no-optional-locks', 'diff', '--check']),
        ('source-whitespace', ['git', '--no-optional-locks', 'diff', '--check', '80328a2d25c0c695cc9c8b09ee79910bfc458ec9', TESTED]),
        ('strict-repository', [sys.executable, '-B', 'scripts/validate_repository.py', '--require-approved-identity']),
    ]:
        run(name, argv, env=env)

def supplemental():
    code = 'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SealDetectorRuntimeGameTests.java'
    task = 'docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-TASK-02.md'
    base = '80328a2d25c0c695cc9c8b09ee79910bfc458ec9'
    original = '8b608d88205be9ff4cd19bdf9516317c9a6494d5'
    normalized = lambda b: b.replace(b'\r\n', b'\n')
    original_patch = run('actual-original-patch', ['git', '--no-optional-locks', 'diff', base, original]).stdout
    correction = run('actual-correction-patch', ['git', '--no-optional-locks', 'diff', original, TESTED]).stdout
    corrected_patch = (LEAF / 'source-patch.log').read_bytes()
    actual_code = run('actual-corrected-source', ['git', 'show', TESTED + ':' + code]).stdout
    actual_task = run('actual-source-task', ['git', 'show', TESTED + ':' + task]).stdout
    checks = {}
    with zipfile.ZipFile(MAIN / FILES[1]) as root, zipfile.ZipFile(MAIN / FILES[2]) as independent:
        checks['root-original-patch-equals-git-after-EOL-normalization'] = normalized(root.read('original-source.patch')) == normalized(original_patch)
        checks['root-correction-patch-equals-git-after-EOL-normalization'] = normalized(root.read('structural-correction.patch')) == normalized(correction)
        checks['independent-original-patch-equals-git-after-EOL-normalization'] = normalized(independent.read('candidate.diff')) == normalized(original_patch)
        checks['independent-corrected-patch-equals-git'] = independent.read('corrected-candidate.diff') == corrected_patch
        checks['independent-correction-patch-equals-git'] = independent.read('response-correction.diff') == correction
        checks['independent-corrected-source-equals-git'] = normalized(independent.read('review-inputs/corrected-test-source.java')) == normalized(actual_code)
        checks['independent-task-equals-git'] = normalized(independent.read('review-inputs/INSTALLED-RUNTIME-TASK-02.md')) == normalized(actual_task)
        inspected = json.loads(root.read('scope-inspection.json'))
        checks['root-source-hash-equals-canonical-source'] = sha(normalized(actual_code)) == inspected['code_sha256']
        checks['root-task-hash-equals-canonical-task'] = sha(normalized(actual_task)) == inspected['task_sha256']
        checks['actual-corrected-source-lines-242'] = len(actual_code.splitlines()) == 242
        for which, z, prefix in [('root', root, ''), ('independent', independent, 'review-inputs/')]:
            primary = json.loads(z.read(prefix + 'primary-inspection.json'))
            checks[which + '-primary-four-outputs'] = len(primary['commands']) == 4
            checks[which + '-primary-pinned-jar'] = primary['jar_sha256'] == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
            for row in primary['commands']:
                data = z.read(prefix + row['output'])
                checks[which + '-primary-' + row['output']] = row['exit_code'] == 0 and row['bytes'] == len(data) and row['sha256'] == sha(data)
        old_scope = json.loads(root.read('scope-inspection-original.json'))
        checks['root-original-controls-19'] = old_scope['passed'] == old_scope['total'] == sum(old_scope['checks'].values()) == 19
        previous = MAIN / 'docs/work/v1.8.0-c16a-hatches/PLACEMENT-PROVENANCE-ROOT-22.zip'
        with zipfile.ZipFile(previous) as old:
            names = old.namelist()
            artifacts = json.loads(root.read('cohort-03/results.json'))['artifacts']
            matching = []
            for name in names:
                if name.endswith('.json'):
                    text = old.read(name).decode('utf-8-sig')
                    if all(value in text for value in artifacts.values()):
                        matching.append(dict(path=name, bytes=len(old.read(name)), sha256=sha(old.read(name))))
            checks['previous-placement-archive-artifact-identities-match'] = bool(matching)
            (LEAF / 'preceding-artifact-reference.json').write_text(json.dumps(dict(
                zip_path=str(previous), zip_sha256=sha(previous.read_bytes()),
                matching_payloads=matching, observed_artifacts=artifacts), indent=2) + '\n', encoding='utf-8')
    (LEAF / 'supplemental-source-evidence-checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(checks, indent=2))
    assert all(checks.values())

def governance():
    files = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
             'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
             'docs/versions/V1.0.0-COMMUNITY-MVP.md', 'docs/releases/v0.9.0/GATE-STATUS.md',
             'docs/releases/v1.7.0/GATE-STATUS.md',
             'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
             'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
             'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md', 'docs/status/GATE_STATUS.md',
             'docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md',
             'docs/decisions/ADR-067-V180-READ-ONLY-SEAL-DETECTOR.md',
             'UPSTREAM.md', 'NOTICE.md', 'docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md',
             'docs/08-ASSET-LICENSE-AND-PROVENANCE.md']
    rows = [dict(path=p, bytes=len((MAIN / p).read_bytes()), sha256=sha((MAIN / p).read_bytes())) for p in files]
    (LEAF / 'governance-read-identities.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
    run('live-agents', ['pwsh', '-NoProfile', '-Command', "Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'codex|claude|python|java' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | Format-List"])

def closure():
    before = json.loads((LEAF / 'draft-input-hashes.json').read_text('utf-8'))
    after = [dict(path=row['path'], bytes=len((MAIN / row['path']).read_bytes()),
                  sha256=sha((MAIN / row['path']).read_bytes())) for row in before]
    assert after == before
    (LEAF / 'final-input-hashes.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf-8')
    assert run('final-head', ['git', '--no-optional-locks', 'rev-parse', 'HEAD']).stdout.decode().strip() == PIN
    assert run('final-index-diff', ['git', '--no-optional-locks', 'diff', '--cached', '--exit-code']).returncode == 0
    assert run('final-status', ['git', '--no-optional-locks', 'status', '--short', '--untracked-files=all']).stdout == (LEAF / 'initial-status.log').read_bytes()
    assert run('final-record-patch', ['git', '--no-optional-locks', 'diff', '--binary', '--', *FILES]).stdout == (LEAF / 'draft-records.log').read_bytes()
    source = Path('D:/GitHub/arce-v180-seal-installed-runtime-20261008')
    assert run('final-source-head', ['git', '--no-optional-locks', 'rev-parse', 'HEAD'], cwd=source).stdout.decode().strip() == TESTED
    assert not run('final-source-status', ['git', '--no-optional-locks', 'status', '--short'], cwd=source).stdout.strip()
    (LEAF / 'closure.json').write_text(json.dumps(dict(
        observed_utc=datetime.now(timezone.utc).isoformat(), main_head=PIN, tested_source=TESTED,
        draft_hashes_preserved=True, main_status_preserved=True, main_index_unstaged=True,
        source_worktree_clean=True, owned_temp_empty=not any((LEAF / 'Temp').rglob('*')),
        full_runtime_rerun=False), indent=2) + '\n', encoding='utf-8')

def finish_commands():
    p = LEAF / 'review-commands.json'
    old = json.loads(p.read_text(encoding='utf-8')) if p.exists() else []
    p.write_text(json.dumps(old + commands, indent=2) + '\n', encoding='utf-8')

if __name__ == '__main__':
    try:
        {'initial': initial, 'archives': archives, 'equivalence': equivalence,
         'evidence': evidence, 'validators': validators, 'supplemental': supplemental,
         'governance': governance, 'closure': closure}[sys.argv[1]]()
    finally:
        finish_commands()
