# Root verification: installed seal detector rules

Date: 2026-10-08. Task: C18a-SEAL-INSTALLED-RUNTIME-02. Root implements directly;
no Claude assistance or delegated authorship. This report is Root's evidence,
not the independent review report or a release/Gate approval.

## Scope and design

Base is 80328a2d25c0c695cc9c8b09ee79910bfc458ec9. Original source is
8b608d88205be9ff4cd19bdf9516317c9a6494d5; corrected source is
794dd123f9af0047adbab385eddeb1c9d5089773. Only the new task and one development
adapter test class change. The source worktree is owned by this task; main HEAD
and its index stay unchanged during the cohorts. User-owned main AGENTS.md
retains SHA c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09.

Two native main/off-hand cases use the actual registered detector, ordinary
survival ServerPlayer instances joined through owned EmbeddedChannels, and
ServerPlayerGameMode.useItemOn. The existing external boundary fixture remains
full-collision in both states. A closed/open/closed sequence checks startup-
installed custom-rule outcomes without building/replacing a local catalog or
runtime, adding an event/registration, or importing host implementation classes.
It also checks shared two-tick cooldown, ambient-not-known-supplied feedback,
actor-only non-overlay callbacks, both exact held identities/counts/custom NBT,
nonmutation of two selected cells, and cleanup on ordinary assertion outcomes.
These are hosted embedded fixtures, not real-client/packaged-server S1/S2/V1/V2.

## Correction and retained attempts

Original capture compares rendered Component.getString() values. Independent
source review and Root inspection identify its response-identity limitation:
rendering does not itself assert translation keys, nested arguments or style.
That is a test-evidence limit, not an observed production response defect.
794dd123 captures and compares Component.Serializer.toJson instead, and records
actual payloads in the console. No product behavior, assertion removal, timeout
expansion or performance-budget relaxation is used.

Root cohort-01 never starts Gradle: cmd.exe was passed using a forward-slash
executable path, returning syntax error/exit1. Its Java check and zero executed
test counts are retained. The runner normalizes that executable through Path;
cohort-02 genuinely executes the original source. Its all-passing native result
is not retroactively treated as structural response proof. The original runner
also scans latest.log for console observations; the raw two lines in native.log
are separately extracted, and the corrected runner uses the console explicitly.
Both runner versions, original result files and patches are retained unchanged.

Exploratory lookups of legacy TASK-01/ADR-067 names and not-yet-produced native
logs are locator failures, not product test failures. A --version probe verifies
the normalized executable before the corrected cohorts; global settings and
wrapper bytes are not edited. Supplied mandatory governance and live AGENTS are
read; the historical handoff is not substituted for latest committed state.

## Actual command results

Java is Oracle JDK 17.0.7. Process-local JAVA_HOME/PATH and owned D: TEMP/TMP/
java.io.tmpdir are recorded; both drives exceed 10 GiB before each command.
No daemon, online dependency acquisition, filter or artificial watchdog is used.
The committed candidate remains clean/pinned throughout each complete cohort.

| Command | Original cohort-02 | Corrected cohort-03 |
|---|---|---|
| clean build --no-daemon --offline --no-build-cache --rerun-tasks | exit0, all20 actionable tasks execute | exit0, all20 actionable tasks execute |
| runData --no-daemon --offline, twice | both exit0 | both exit0 |
| git diff --exit-code after each generation | both exit0, empty | both exit0, empty |
| validate_v180_content_ledger.py --require-accepted | exit0 | exit0 |
| validate_bootstrap_provenance.py | exit0 | exit0 |
| validate_repository.py --require-approved-identity | exit1, 44 PASS/one inherited link failure | same counts/exit1 |
| git diff --check | exit0 | exit0 |
| runGameTestServer --no-daemon --offline --no-build-cache, unfiltered | exit0; all553 required pass | exit0; all553 required pass |
| outer runner | exit1 because strict validation fails | same |

Both builds execute 378 JUnit XML suites, 2,179 actual testcase nodes, zero
failures/errors/skips. Corrected native terminal is observed at
2026-10-08T15:42:23.210Z; the command ends at 15:42:27.726670Z. Each completed
native-latest log has 62 unwaived ERROR headers and zero FATAL; these are retained
separately from passing test counts. There is no claim that all logged errors
are explained, removed or waived. Console payloads contain three sealed/open/
sealed readings per hand, not-known-supplied arguments, overlay=false and zero
peer callbacks. Both existing and new detector tests run in the full suite.

Root scope/identity controls are 23/23; original controls are separately 19/19.
Four bounded explicit javap commands exit0 against the mapped 47.4.10 JAR SHA
95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e, covering
Component$Serializer, TranslatableContents, Language$1 and LanguageHook.
The official Forge 1.20.x LanguageHook source is consulted as supplemental
information only (https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.x/src/main/java/net/minecraftforge/server/LanguageHook.java);
the version-sensitive facts rely on the pinned local primary input, not a
different-version issue report or a mutable branch's equivalence.

## Identities and evidence

Complete corrected src tree: 005126337796bcdb1abbfda699bd601c4c2db253.
Production src/main tree: 9b1e79254d7467c8afc1c700006cf2c0318d4cd3, unchanged.
All seven Gradle inputs match the base. Code SHA:
57651366fa011631cb1e3403eb6b8185ec14e515810c3052bebfeb23c1310cc1.
Task SHA: 15937f0473b128b4426d1e3b684630ea0e8d74ce2091087bec03911d61d3f2c6.

All three production artifacts match the preceding placement qualification:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| dev JAR | 6,027,872 | dd93cb968430eba12fb13539bbdfb29e943af1f16a6b6a8ebb3257a14d9a6b87 |
| sources JAR | 2,873,767 | ed57d4d0923c1571b421979a8e6068165b70dc048b755b8d8bdd8faf1c27d2a9 |
| API JAR | 51,052 | aa9317c6d2a5dfc71f736f7a4de4dca15f6742d6649dd05fa5b3f457fe9ade4b |

No adapter fixture is present in those artifacts. Evidence comprises commands/
logs, zipped unit XML, results, console extraction, original/corrected source
patches, pinned primary facts, scope/artifact controls and cleanup inventory.
No full reproducible source, artifact or world copy is packaged.

## Remaining scope and risk

No production source/build/registry/asset/provenance/ledger or persistent identity
changes. This qualifies only the existing fixture rule through installed
registered-item use; it does not complete custom tag/door precedence, every
actor/thread/lifecycle/post-query ordering/refusal, recipe unlock, reload/unload,
packaged restart, protection-mod, real-player or GPU obligations.
No physical hatch hook/writer or O1/O2/O3 decision; ADR-068 remains PROPOSED and
R-021 OPEN. C16-C19 and all Required Gates remain unfinished. The content ledger
remains 186 PLANNED /154 REVIEW assets. A later merge/docs SHA is not the tested
source SHA; source/build-input equivalence must be recorded separately.

## Cleanup and release

After all Root subprocesses end, one native PowerShell attempt removes only
this task's new build/GameTest/DataGen/project-cache and three TEMP outputs.
Ownership, full resolved containment, ancestor/descendant reparse points and
live task processes are checked before deletion. The inventory is in cleanup-
preflight.json/cleanup.json; all six selected outputs are removed. No physical
reclaimed-space claim is made. Own source worktree stays clean; source inputs,
user work, previous refused targets and sealed prior evidence are untouched.
Root cohort processes and source read interests are released. Sealed payload
hashes/relative manifest bind this report; independent results remain separately
attributed, and later integration is not performed by this archive.
