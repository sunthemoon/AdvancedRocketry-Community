"""Seal only ended retained evidence, not reproducible caches/source/worlds."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
DEST = Path("D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-ROOT-02.zip")
assert not DEST.exists()
assert not (ROOT / "SHA256SUMS.txt").exists()
assert not (ROOT / "retained-manifest.json").exists()
assert json.loads((ROOT / "cleanup.json").read_text("utf-8-sig"))["allRemoved"]
files = sorted(path for path in ROOT.rglob("*") if path.is_file())
assert all(path.resolve().is_relative_to(ROOT.resolve()) for path in files)
assert not any(part in ("temp", "build", "run-data", ".gradle", "source-cache", "gradle-cache")
               for path in files for part in path.relative_to(ROOT).parts)
rows = [dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
             sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in files]
assert all(row["bytes"] < 50 * 1024 ** 2 for row in rows)
assert sum(row["bytes"] for row in rows) < 100 * 1024 ** 2
(ROOT / "retained-manifest.json").write_text(json.dumps(dict(
    source="794dd123f9af0047adbab385eddeb1c9d5089773", payloads=rows,
    payload_count=len(rows), payload_bytes=sum(row["bytes"] for row in rows)), indent=2) + "\n", "utf-8")
files.append(ROOT / "retained-manifest.json")
(ROOT / "SHA256SUMS.txt").write_text("".join(
    hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(ROOT).as_posix() + "\n"
    for path in sorted(files)), "utf-8")
files.append(ROOT / "SHA256SUMS.txt")
with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 10, 8, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for line in archive.read("SHA256SUMS.txt").decode("utf-8").splitlines():
        digest, name = line.split("  ", 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(path=str(DEST), bytes=DEST.stat().st_size, entries=len(files),
                     payloads=len(rows), payload_bytes=sum(row["bytes"] for row in rows),
                     sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(),
                     report_sha256=hashlib.sha256((ROOT / "REPORT.md").read_bytes()).hexdigest()), indent=2))
