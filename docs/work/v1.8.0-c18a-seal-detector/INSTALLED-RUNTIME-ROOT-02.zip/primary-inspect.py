"""Bounded bytecode facts from the locally pinned mapped primary platform input."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
CACHE = Path("C:/Users/Administrator/.gradle/caches/forge_gradle")
jars = list(CACHE.rglob("*47.4.10*mapped*.jar"))
assert len(jars) == 1, [str(path) for path in jars]
jar = jars[0]
digest = hashlib.sha256(jar.read_bytes()).hexdigest()
assert digest == "95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e", digest
records = []
for name in ("net.minecraft.network.chat.Component$Serializer", "net.minecraft.network.chat.contents.TranslatableContents",
             "net.minecraft.locale.Language$1", "net.minecraftforge.server.LanguageHook"):
    argv = ["C:/Program Files/Java/jdk-17.0.7/bin/javap.exe", "-p", "-c", "-classpath", str(jar), name]
    process = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    assert len(process.stdout) <= 128 * 1024
    path = ROOT / (name.rsplit(".", 1)[-1] + ".javap.txt")
    path.write_bytes(process.stdout)
    records.append(dict(argv=argv, exit_code=process.returncode, output=path.name, bytes=len(process.stdout),
                        sha256=hashlib.sha256(process.stdout).hexdigest()))
result = dict(jar=str(jar), jar_sha256=digest, commands=records)
(ROOT / "primary-inspection.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result, indent=2))
raise SystemExit(0 if all(row["exit_code"] == 0 for row in records) else 1)
