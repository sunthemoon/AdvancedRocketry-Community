"""Retain the exact committed short cohort; repository failure does not hide native outcomes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

TREE = Path("D:/GitHub/arce-v180-seal-installed-runtime-20261008")
ROOT = Path(__file__).resolve().parent
JDK = Path("C:/Program Files/Java/jdk-17.0.7")
leaf = ROOT / sys.argv[1]
leaf.mkdir()
temp = leaf / "temp"
temp.mkdir()

def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(TREE), *args]).decode("utf-8")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

source = git("rev-parse", "HEAD").strip()
assert not git("status", "--porcelain")
env = dict(os.environ, JAVA_HOME=str(JDK), PATH=str(JDK / "bin") + os.pathsep + os.environ["PATH"],
           TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONDONTWRITEBYTECODE="1",
           JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=" + temp.as_posix())
base = [str(Path("C:/Windows/System32/cmd.exe")), "/d", "/c", "gradlew.bat"]
commands = [
    ("java", [str(JDK / "bin/java.exe"), "-version"]),
    ("build", base + ["clean", "build", "--no-daemon", "--offline", "--no-build-cache", "--rerun-tasks"]),
    ("data-1", base + ["runData", "--no-daemon", "--offline"]),
    ("data-1-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("data-2", base + ["runData", "--no-daemon", "--offline"]),
    ("data-2-diff", ["git", "--no-optional-locks", "diff", "--exit-code"]),
    ("ledger", [sys.executable, "-B", "scripts/validate_v180_content_ledger.py", "--require-accepted"]),
    ("provenance", [sys.executable, "-B", "scripts/validate_bootstrap_provenance.py"]),
    ("repository", [sys.executable, "-B", "scripts/validate_repository.py", "--require-approved-identity"]),
    ("whitespace", ["git", "--no-optional-locks", "diff", "--check"]),
    ("native", base + ["runGameTestServer", "--no-daemon", "--offline", "--no-build-cache"]),
]
records = []
for name, argv in commands:
    free = {drive: shutil.disk_usage(drive).free for drive in ("C:/", "D:/")}
    assert all(value >= 10 * 1024 ** 3 for value in free.values()), free
    started = now()
    print(json.dumps(dict(starting=name, source=source, utc=started)), flush=True)
    log = leaf / (name + ".log")
    with log.open("xb") as output:
        process = subprocess.run(argv, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                 stdout=output, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
    record = dict(name=name, argv=argv, source=source, cwd=str(TREE), started_utc=started,
                  ended_utc=now(), free_bytes=free, exit_code=process.returncode,
                  log_sha256=sha(log), bytes=log.stat().st_size)
    records.append(record)
    (leaf / "commands.json").write_text(json.dumps(records, indent=2) + "\n", "utf-8")
    print(json.dumps(record), flush=True)
    if name in ("build", "data-1", "data-2") and process.returncode:
        break

files = sorted((TREE / "build/test-results/test").glob("TEST-*.xml"))
totals = {key: 0 for key in ("tests", "failures", "errors", "skipped")}
actual = 0
with zipfile.ZipFile(leaf / "unit-xml.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        tree = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(tree.get(key, "0"))
        actual += len(tree.findall("testcase"))
        archive.write(path, path.name)
native_text = ""
if any(record["name"] == "native" for record in records):
    for name in ("latest", "debug"):
        path = TREE / "build/gametest/logs" / (name + ".log")
        if path.is_file():
            shutil.copy2(path, leaf / ("native-" + name + ".log"))
    path = leaf / "native-latest.log"
    if path.is_file():
        native_text = path.read_text("utf-8")
summary = dict(source=source, src_tree=git("rev-parse", "HEAD:src").strip(), commands=records,
               unit_suites=len(files), unit_totals=totals, actual_testcase_nodes=actual,
               native_error_headers=len(re.findall(r"/ERROR]", native_text)),
               native_fatal_headers=len(re.findall(r"/FATAL]", native_text)),
               native_terminal_lines=[line for line in native_text.splitlines()
                                      if re.search(r"GAME TESTS COMPLETE|All \d+ required tests passed|\d+ required tests failed", line)],
               native_failure_lines=[line for line in native_text.splitlines() if "failed!" in line],
               native_probe_batches=[line for line in native_text.splitlines() if "Running test batch 'seal_detector_runtime" in line],
               native_observations=[line for line in native_text.splitlines() if "ARCE_SEAL_INSTALLED_RULE" in line],
               head_unchanged=git("rev-parse", "HEAD").strip() == source,
               clean=not git("status", "--porcelain"),
               artifacts={path.name: sha(path) for path in (TREE / "build/libs").glob("*.jar")})
(leaf / "results.json").write_text(json.dumps(summary, indent=2) + "\n", "utf-8")
print(json.dumps(summary), flush=True)
raise SystemExit(0 if all(record["exit_code"] == 0 for record in records)
                 and summary["head_unchanged"] and summary["clean"] else 1)
