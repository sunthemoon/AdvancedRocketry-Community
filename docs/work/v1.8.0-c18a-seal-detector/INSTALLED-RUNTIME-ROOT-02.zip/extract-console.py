"""Retain console-only observations separately from the latest.log scan."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
records = []
for leaf in sorted(ROOT.glob("cohort-*")):
    path = leaf / "native.log"
    if not path.is_file():
        continue
    results = json.loads((leaf / "results.json").read_text("utf-8"))
    records.append(dict(cohort=leaf.name, source=results["source"], input=path.relative_to(ROOT).as_posix(),
                        input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                        observations=[line for line in path.read_text("utf-8").splitlines()
                                      if "ARCE_SEAL_INSTALLED_RULE" in line]))
dest = ROOT / "console-observations.json"
assert not dest.exists()
dest.write_text(json.dumps(records, indent=2) + "\n", "utf-8")
print(json.dumps(records, indent=2))
