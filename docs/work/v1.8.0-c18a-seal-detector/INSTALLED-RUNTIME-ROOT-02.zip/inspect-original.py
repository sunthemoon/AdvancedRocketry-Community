"""Scope/identity inspection, separate from hosted behavioral assertions."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

MAIN = Path("D:/GitHub/AdvancedRocketry-Community")
TREE = Path("D:/GitHub/arce-v180-seal-installed-runtime-20261008")
ROOT = Path(__file__).resolve().parent
BASE = "80328a2d25c0c695cc9c8b09ee79910bfc458ec9"
SOURCE = "8b608d88205be9ff4cd19bdf9516317c9a6494d5"
CODE = "src/adapterTest/java/io/github/sunthemoon/arceadaptertest/SealDetectorRuntimeGameTests.java"
TASK = "docs/work/v1.8.0-c18a-seal-detector/INSTALLED-RUNTIME-TASK-02.md"

def git(tree, *args):
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(tree), *args]).decode("utf-8")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

changes = git(TREE, "diff", "--name-only", BASE, SOURCE).splitlines()
inputs = ["build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat",
          "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties"]
input_objects = {name: [git(TREE, "rev-parse", pin + ":" + name).strip() for pin in (BASE, SOURCE)]
                 for name in inputs}
code = (TREE / CODE).read_text("utf-8")
checks = {
    "candidate_pin": git(TREE, "rev-parse", "HEAD").strip() == SOURCE,
    "candidate_clean": not git(TREE, "status", "--porcelain"),
    "main_head_unchanged": git(MAIN, "rev-parse", "HEAD").strip() == BASE,
    "main_index_empty": not git(MAIN, "diff", "--cached", "--name-only"),
    "main_agents_preserved": sha(MAIN / "AGENTS.md") == "c2448e9357ec77d062ab52ecefbb24724fb5c767fb4955a4cd23ef0efbd8ff09",
    "source_change_scope": set(changes) == {CODE, TASK},
    "production_tree_unchanged": git(TREE, "rev-parse", BASE + ":src/main") == git(TREE, "rev-parse", SOURCE + ":src/main"),
    "seven_gradle_inputs_unchanged": all(first == second for first, second in input_objects.values()),
    "new_test_count": code.count("@GameTest(") == 2,
    "no_host_implementation_imports": "import io.github.sunthemoon.advancedrocketrycommunity." not in code,
    "no_new_fixture_registration": ".register(" not in code,
    "no_replacement_catalog": all(word not in code for word in ("AtmosphereBoundaryRegistry", "SealDetectorRuntime.", "AtmosphereManager")),
    "native_entry": ".gameMode.useItemOn(" in code,
    "explicit_two_hands": "measure(helper, InteractionHand.MAIN_HAND)" in code and "measure(helper, InteractionHand.OFF_HAND)" in code,
    "full_collision_checked": "Block.isShapeFullBlock(state.getCollisionShape(level, target))" in code,
    "closed_open_closed": code.count("fixture.state(false);") == 2 and code.count("fixture.state(true);") == 1,
    "normal_terminal_cleanup": "try (Fixture fixture = new Fixture(helper))" in code,
    "class_below_500_lines": len(code.splitlines()) < 500,
}
artifacts = {}
for path in sorted((TREE / "build/libs").glob("*.jar")):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
    artifacts[path.name] = dict(sha256=sha(path), bytes=path.stat().st_size, entries=len(names),
                                contains_adapter_fixture=any("arceadaptertest" in name or "arce_adapter_test" in name for name in names))
if artifacts:
    checks["artifact_test_fixture_excluded"] = all(not value["contains_adapter_fixture"] for value in artifacts.values())
result = dict(source=SOURCE, base=BASE, src_tree=git(TREE, "rev-parse", "HEAD:src").strip(),
              production_tree=git(TREE, "rev-parse", "HEAD:src/main").strip(),
              changes=changes, input_objects=input_objects, code_sha256=sha(TREE / CODE),
              task_sha256=sha(TREE / TASK), artifacts=artifacts,
              checks=checks, passed=sum(checks.values()), total=len(checks))
(ROOT / "scope-inspection.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
