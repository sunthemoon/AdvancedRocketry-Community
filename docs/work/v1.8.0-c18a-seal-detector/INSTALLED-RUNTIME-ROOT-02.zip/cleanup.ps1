$ErrorActionPreference = 'Stop'
$tree = [IO.Path]::GetFullPath('D:/GitHub/arce-v180-seal-installed-runtime-20261008')
$leaf = [IO.Path]::GetFullPath('D:/GitHub/ARCE-Task-Evidence/v1.8.0/seal-installed-runtime-root-20261008-01')
$targets = @('build', 'run-data', '.gradle') | ForEach-Object { Join-Path $tree $_ }
$targets += @('cohort-01/temp', 'cohort-02/temp', 'cohort-03/temp') | ForEach-Object { Join-Path $leaf $_ }
$live = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and
    ($_.CommandLine.Contains($tree) -or $_.CommandLine.Contains($tree.Replace('\', '/')) -or
     $_.CommandLine.Contains($leaf) -or $_.CommandLine.Contains($leaf.Replace('\', '/')))
})
if ($live.Count) { throw ('Task processes remain: ' + ($live.ProcessId -join ',')) }
$inventory = @()
foreach ($target in $targets) {
    $resolved = [IO.Path]::GetFullPath($target)
    if (-not ($resolved.StartsWith($tree + '\', [StringComparison]::OrdinalIgnoreCase) -or
              $resolved.StartsWith($leaf + '\', [StringComparison]::OrdinalIgnoreCase))) {
        throw ('Outside owned roots: ' + $resolved)
    }
    if (-not (Test-Path -LiteralPath $resolved)) { continue }
    $ancestor = Get-Item -LiteralPath $resolved -Force
    while ($ancestor) {
        if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Reparse ancestor: ' + $ancestor.FullName) }
        $ancestor = $ancestor.Parent
    }
    $entries = @(Get-ChildItem -LiteralPath $resolved -Recurse -Force)
    if (@($entries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
        throw ('Reparse descendant: ' + $resolved)
    }
    $files = @($entries | Where-Object { -not $_.PSIsContainer })
    $inventory += [pscustomobject]@{
        target = $resolved; files = $files.Count; logicalBytes = ($files | Measure-Object Length -Sum).Sum
        reason = 'Created by this task; ended disposable build, GameTest/DataGen or TEMP output.'
    }
}
$freeBefore = @(Get-PSDrive C,D | Select-Object Name,Free)
[pscustomobject]@{ inventory = $inventory; liveTaskProcesses = $live; freeBefore = $freeBefore } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup-preflight.json') -Encoding utf8
# One native deletion attempt; a refusal or exception stops the script, with no retry.
foreach ($entry in $inventory) { Remove-Item -LiteralPath $entry.target -Recurse -Force }
$remaining = @($inventory | Where-Object { Test-Path -LiteralPath $_.target })
[pscustomobject]@{
    inventory = $inventory; remaining = $remaining; allRemoved = $remaining.Count -eq 0
    freeBefore = $freeBefore; freeAfter = @(Get-PSDrive C,D | Select-Object Name,Free)
    policy = 'No physical reclaimed-space claim; logical inventory only. Prior refused targets untouched.'
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $leaf 'cleanup.json') -Encoding utf8
if ($remaining.Count) { throw 'Disposable outputs remain' }
