import sys
import xml.etree.ElementTree as ET
from pathlib import Path

total = [0, 0, 0, 0]
for path in sorted(Path(sys.argv[1]).glob('TEST-*.xml')):
    root = ET.parse(path).getroot()
    row = [int(root.get(k)) for k in ('tests', 'failures', 'errors', 'skipped')]
    total = [a + b for a, b in zip(total, row)]
    failed = [tc.get('name') for tc in root.iter('testcase') if tc.find('failure') is not None or tc.find('error') is not None]
    print(root.get('name').split('.')[-1], *row, root.get('timestamp'), ('FAILED: ' + ', '.join(failed)) if failed else '')
print('TOTAL tests/failures/errors/skipped', *total)
