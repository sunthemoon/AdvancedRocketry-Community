# Independent re-review: STATION-03 fix (`e3d136f`) and STATION-04 native verification (`89600ae`)

- Commits reviewed:
  - `e3d136f264e881b2da4516c94d0446242179ea77` "fix(station): require the local player's own command for expansion". Diff: `fa00570..e3d136f`.
  - `89600aed700a984cb078ca92236da7a5a02a4e36` "test(station): verify v1.4 team upgrade, expansion and restart natively". Diff: `e3d136f..89600ae`.
- Branch: `codex/v1.5.0-orbital-station-warp`.
- Contract: ADR-040 ("Stable geometry and expansion policy", lines 55-74), AGENTS.md sections 3 and 5, and the STATION-03/04 leaves in `docs/work/v1.5.0-implementation-log.md`.
- Prior review: `arce-v150-station-expansion-review-2be54341cce94d0ea3f6ab2ff9d25d22/REVIEW.md` (findings M1, L1-L4, I1).
- Reviewer: an independent agent, not the implementer. Date: 2026-09-30.
- **This is not a Gate approval.** It does not mark STATION-03 or STATION-04 `verified`, approve any v1.5 G0-G9 Gate, or replace maintainer acceptance.

## Summary

- **The fix (`e3d136f`) closes the previous M1 for every vanilla level-2 path.** Those paths are the console, RCON, `/execute as <owner>` from the console or another op, command blocks, signs, and scheduled/tick functions. A non-local confirm is rejected before `take()`, so it cannot consume or leak the owner's pending confirmation. L2, L3 and most of L4 are fixed. My mutation runs show that the new unit tests can fail.
- **One narrower bypass class remains (Low).** A command dispatched *with the player's own command source* still passes. Examples: advancement-reward functions (which the console can trigger with `/advancement grant`), a function the player runs themselves, and mods or scripts that run commands as the player. Output from these paths is suppressed, so the owner never sees the warning. The CHANGELOG, the reply text and the Javadoc all say "functions ... are rejected", which overstates the fix.
- **The STATION-04 harness oracles are strong and not vacuous.** The recorded hashes match exactly, and my independent NBT decode reproduces every payload claim. However, the STATION-04 leaf's own acceptance list is only partly covered. The "rocket/context readback" TODO was dropped from the tracking list, and one acceptance item (unknown-body handling) is not mentioned at all (Medium, evidence/process). The full-run JUnit count reported for STATION-04 was restored from the build cache, not executed (Low, evidence).

No Critical or High findings.

## Findings (ordered by severity)

### M1 (Medium, evidence/scope/process; no production impact): STATION-04 is presented as complete pending review, but its acceptance items are only partly covered and a TODO was silently dropped

- **Acceptance text.** `docs/work/v1.5.0-implementation-log.md:260-266` (STATION-04 leaf):
  - Outcome: "original station/team/orbit/pad/**rocket identities** plus one explicit expanded region intact".
  - Acceptance: "original membership/**invitations**/**unknown-body handling**, **neighboring blocks retained**, ...".
- **What the native run actually covers.**
  - **Rocket identities.** The source world has zero rocket transactions (`native/before/decoded.json`: `"transactions": []`), and rocket entities in chunk data are not compared (`VERIFICATION.md:118`). The "rocket identities intact" outcome is therefore vacuous for this world.
  - **Invitations.** They stay empty (`VERIFICATION.md:116-117`, disclosed).
  - **Neighboring or added-ring blocks.** Not inspected (`VERIFICATION.md:119-120`, disclosed).
  - **Unknown-body handling.** Not exercised and not mentioned anywhere in the STATION-04 verification. The neighbor orbits `mars`, which exists in the v1.5 catalog. The STATION-01/02 packet also says "no native unknown-orbit result is claimed" (`docs/work/v1.5.0-station-schema/VERIFICATION.md:141`).
- **The TODO was dropped.** Commit `89600ae` deletes Remaining-TODO item 2 ("STATION-04: complete native nonempty-team/expanded-region preservation and **appropriate rocket/context readback**"). It replaces it with "STATION-03 ... and STATION-04 (native run passed) need an independent review ... before `verified`" (`implementation-log.md:86-87`). `docs/status/CURRENT_VERSION.md` then says "Next is the ORBIT-01 contract". No ADR waiver exists (AGENTS.md section 5: "任何豁免都必须写入 ADR", i.e. every exemption must be recorded in an ADR).
- **Failure scenario.** A later agent or maintainer reads the log, sees review as the only open item, and marks STATION-04 `verified`. That would record the leaf as verified with four acceptance items unmet and no waiver. A real regression in rocket/context readback or unknown-orbit retention after an expansion upgrade would then be unguarded at the native level.
- **Fix (implementer's choice).**
  - Restore the TODO.
  - Either add native coverage (for example, a copied world that contains a rocket record and an unknown-orbit station, plus a readback of the added ring's blocks) or write an ADR waiver with an owner, expiry and recovery condition.
  - List unknown-body handling explicitly under "Not covered".

### L1 (Low, production/contract and wording): commands dispatched with the player's own source still pass `source.source == player`, including console-triggerable, output-suppressed advancement-reward functions

- **Code.** `StationCommands.java:174-176` (`issuedBy` = `source.source == player`) and `StationExpansionService.java:138-140`.
- **What the check proves.** It proves that the command *source object is the player entity*, not that the player typed the command.
- **Paths that construct exactly that source.** Verified by `javap` on the mapped Forge 1.20.1-47.4.10 jar; see `bytecode/`.
  - `AdvancementRewards.lambda$grant$0`: `ServerFunctionManager.execute(fn, player.createCommandSourceStack().withSuppressedOutput().withPermission(2))`. Both `withSuppressedOutput` and `withPermission` copy the `source` field unchanged. `sendSuccess`/`sendFailure` check `silent`, so the owner receives no reply at all.
  - `FunctionCommand`: `source.withSuppressedOutput().withMaximumPermission(2)`. A function the player runs themselves keeps `source == player`, and its output is suppressed.
  - Any mod or script that calls `performPrefixedCommand(player.createCommandSourceStack(), ...)`. `Entity.createCommandSourceStack()` passes `this` as the source. Examples: KubeJS `player.runCommandSilent`, quest-mod command rewards, "sudo" commands. The in-repo STATION-04 probe does exactly this (`StationExpansionProbe.java:139-140`).
- **Failure scenario.**
  1. An administrator installs a datapack with advancement `x:grow` whose reward function contains `arce station expand` followed by `arce station expand confirm <S>`.
  2. While Alice (owner of S) stands in S, the console runs `advancement grant Alice only x:grow`. Alternatively, a `minecraft:location` or `minecraft:tick` criterion grants it automatically.
  3. Both commands run with `source == Alice`. Alice is the player-list entity, so the service returns `ISSUED` and then `EXPANDED`.
  4. Alice never sees the "blocks join the station" warning and never confirmed. ADR-040:57-66 ("must explicitly confirm", "no console ... bypass", "must warn ... before confirmation") is not met for this path.
- **Impact bound.** This needs datapack or mod installation (filesystem-level administrator, above a level-2 operator) plus a hard-coded station UUID for the confirm step (1.20.1 has no function macros). No ordinary player or plain level-2 op can use it. Every vanilla level-2 path from the previous M1 is now rejected.
- **Wording overclaims.**
  - `CHANGELOG.md:24-25`: "the console, command blocks, **functions**, signs and `/execute as` are rejected".
  - `StationExpansionCode.java:9-10` (the player-visible text): "command blocks, **functions**, signs and /execute cannot expand stations".
  - `StationCommands.java:173` and the `StationExpansionService.java:61-62` Javadoc say the same.
  - In addition, `/execute as @s` typed by the player is accepted, correctly, although the text says `/execute` cannot expand.
- **Possible fixes.**
  - Also reject silent sources. Every function and advancement-reward path uses `withSuppressedOutput`, and chat commands are never silent. `CommandSourceStack.silent` is private in 1.20.1, so this needs an Access Transformer, which AGENTS.md 3.3 permits.
  - Record the remaining mod/script-dispatch residual in ADR-040.
  - Correct the four texts.

### L2 (Low, test defect): the "connected player-list entity" half of the local-player gate (the L1 fix from the previous review) has no test

- **Code.** `StationExpansionService.java:139`: `issuedByPlayer && server.getPlayerList().getPlayer(player.getUUID()) == player`.
- **Coverage.**
  - The unit test only feeds a boolean to `check` (`StationExpansionServiceTest.onlyADirectlyCommandingConnectedPlayerIsAccepted`).
  - The GameTest's negative cases (`StationExpansionGameTests.java:94-106`) are all `/execute` wrappers, which already fail the `issuedBy` half.
  - Every accepted actor in the GameTest is a connected mock.
  - No test dispatches from a `FakePlayer`'s or a logged-out (stale) `ServerPlayer`'s own `createCommandSourceStack()`. For both, `source == player` holds and only the player-list check rejects them.
- **Failure scenario.** A refactor reduces `localPlayer` to `return issuedByPlayer;`. A FakePlayer carrying the owner's profile and standing in the station, driven by another mod, can request and confirm again. This is the previous L1 regression, and every existing unit test and GameTest stays green.
- **Suggested test.** In the GameTest, run both commands from a `FakePlayer` source and from the owner's stale object after `PlayerList.remove`, and expect `NOT_LOCAL_PLAYER`.

### L3 (Low, evidence): the STATION-04 "full run 961 JUnit passed" was restored from the build cache, not executed

- **Evidence.** `native-checks.zip:root-gradle-01.log` shows `> Task :test FROM-CACHE`, and `compileJava`/`compileTestJava` are also `FROM-CACHE`.
- The archived `full-junit/*.xml` files are byte-identical to the fix round's run 03 XML. For example, `StationExpansionServiceTest` has SHA-256 `9d439c29...` and `timestamp="2026-09-29T17:54:05"` in both.
- **Where it is reported.** `docs/work/v1.5.0-station-native/VERIFICATION.md:74` and the implementation-log verification entry report "961 JUnit / 173 suites, 0 failures" as a result of this run, without disclosure. (The GameTests did execute fresh: the log shows `02:08`-`02:09`.)
- **Why the result still holds.** `src/main` and `src/test` are unchanged between `e3d136f` and `89600ae`, so the cached result is valid for the reviewed inputs. My own targeted run (below) executed `:test`.
- **Why it still matters.** AGENTS.md requires actually executed test results. A cache hit presented as a fresh pass could hide a problem in a future slice whose inputs differ only in ways the cache key ignores.
- **Fix.** Disclose the `FROM-CACHE` status, or run `:test` with `--no-build-cache`/`--rerun-tasks` for the required run.

### Info

- **I1 (production): the new `setDirty()` calls are correct and not harmful.**
  - `StationRegistrySavedData.java:284`: after a failed committer that left non-candidate or absent content, the registry is marked dirty. Before, an absent file could stay absent.
  - Caveat: vanilla `SavedData.save(File)` writes directly (`NbtIo.writeCompressed(tag, File)`, not atomic) and clears dirty even when the write throws (bytecode checked). The "reassert" is therefore one best-effort, non-atomic write. That is the same exposure every other station mutation already has.
  - `:251-258` (publish failure mapped to `OUTCOME_UNKNOWN`): `StationRegistryModel.replaceExpanded` validates before `stations.put`, so memory stays at the observed state. The next save then reverts the expanded file to the acknowledged unexpanded authority, and quarantine blocks further expansion. The branch is unreachable on the server thread and untested, as stated.
- **I2 (test/wording).** The GameTest no longer drives `CHUNK_UNLOADED` through the registered command (`StationExpansionGameTests.java:73-77`). The claim that it is "unreachable for real players" (station-expansion `VERIFICATION.md:197`) is overstated. A same-dimension `teleportTo` followed by a command or function in the same tick can reach it before player tickets move. The production guard remains and its ordering is unit-tested, so nothing is lost at runtime.
- **I3 (design).** `StationManager.requestExpansion/confirmExpansion(ServerPlayer, boolean issuedByPlayer, ...)` are public and trust a caller-asserted boolean. Only the command path calls them today. Deriving the flag inside the service from the `CommandSourceStack` would make the gate harder to bypass by accident.
- **I4 (probe; test fixture only). The asked-for properties hold.**
  - Opt-in system property plus permission level 2.
  - At most 4 players (`PLAYERS.size() >= MAX_PLAYERS`) and at most 16 captured replies per player. Join broadcasts use the two-argument `sendSystemMessage`, so they do not consume slots.
  - Full-match allow-list: `arce station expand( confirm <lowercase uuid>)?`.
  - All probe players are removed on `ServerStoppingEvent`.
  - Imports are Minecraft/Forge/Brigadier/Gson/Netty only, and `verifyConsumerBoundary` ran in `compat-build-01.log`.

  Nits:
  - A probe player that is kicked, or replaced by a duplicate login, leaves a stale `PLAYERS` entry. A later `leave` or stop then calls `PlayerList.remove` again.
  - `stopping` stops at the first exception without reaching `PLAYERS.clear()`.
  - `join` synchronously loads one op-chosen chunk.
  - By design, the probe lets an op drive expansion for any offline UUID.

  None of these matter for a disposable fixture that the README forbids in player installs.
- **I5 (harness/evidence nits).**
  - "Checked write before save" reads the station file after the confirm probe line and before `save-all flush`. `upgrade/debug.log` shows `code=EXPANDED` at line 583, the first `Saving the game` at 594, and no autosave. The oracle proves the expansion was durable when the confirm returned. It does not prove the staged/forced/atomic mechanism (unit-proven only), and it does not check that `.arce-pending` is absent afterwards.
  - The celestial allowance (`visit_only_celestial_change`) is narrow: root equal; only earth/space; only new `first_visit_at`/`discovered_at` keys; no existing field changed; one timestamp. It accepts any subset of those additions, so "allows exactly that" (`VERIFICATION.md:61-63`) is slightly overstated. The restart phase applies no allowance and checks exact equality, which I confirmed.
  - The upgrade-phase WARNs include Forge's "mod version differences (1.4.0-dev -> 1.5.0-dev)" warning, which is not in the listed categories.
  - The attempt 01/02 harness *sources* are not archived. Only their outputs, the final harness and `patch_harness.py` are.
- **I6 (process).** During this review, the repository working tree gained uncommitted changes that I did not make. Fourteen tracked files were modified or deleted (including `StationExpansionCode.java`, `StationRegistrySavedData.java` and `StationExpansionService.java`), and new untracked ORBIT/ADR-041 files appeared (`working-tree-status-at-review.txt`). To avoid testing that work-in-progress, all my source reading after that point and all Gradle runs used a `git archive 89600ae` export (`tree-89600ae/`). The two commits themselves are unaffected.

## Prior findings: status after `e3d136f`

| Prior ID | Status | Basis |
|---|---|---|
| M1 (entity-redirected sources) | **Fixed for vanilla level-2 paths.** A residual self-source class remains (new L1). | `issuedBy` + `localPlayer` (see below). Bytecode shows that `/execute as` keeps the original source, signs use `CommandSource.NULL`, command blocks use the block, and the function game loop uses the server source. The GameTest captures `NOT_LOCAL_PLAYER` on the console for request and confirm. Native run: `EXECUTE_REJECTED` matched, with audit `request code=NOT_LOCAL_PLAYER`. |
| L1 (FakePlayers accepted) | **Fixed in code, untested** (new L2). | `getPlayer(uuid) == player` |
| L2 (no rewrite scheduling; publish failure reported as clean) | **Fixed.** | Mutation A (removing `setDirty`) fails both `refusedAtomicReplacement...` and `failedReplacementThatLeavesNoFile...`. |
| L3 (no test observes live state during commit) | **Fixed** (the service catch is still untested, as disclosed). | Mutation B (publish before write) fails `successReplaces...` at the in-committer assertion, line 55. |
| L4 (conditional chunk step; private logout; any syntax error; authorized-only order test) | **Mostly fixed.** Logout now goes through the real listener: a rejoin yields `NO_CONFIRMATION`, which would be `EXPANDED` if the listener were missing. `ERROR_NOT_PLAYER` is required. The order test uses member/outsider (Mutation B fails it). The `CHUNK_UNLOADED` integration step was removed (I2). Server-stop clearing is still unit-level only. | |
| I1 (unarchived compile/focused logs) | **Fixed.** | `review-fix-checks.zip` contains `compile-01.log` and `focused-01.log` (`:test` executed, 91 tests). |

## Specific questions answered

- **Is `source.source == player` a sound "issued by the player itself" test?**
  - It is sound against the following, because each keeps a different `source`:
    - `/execute as` from the console, RCON, another op, a command block or a function run by someone else;
    - `/execute at`/`positioned`/`in` (the service ignores the source position and level and uses `player.blockPosition()`/`serverLevel()`);
    - command blocks and command-block minecarts;
    - signs (`CommandSource.NULL`);
    - `/schedule` and tick/load functions (server source);
    - RCON (`RconConsoleSource`).
  - It is not sound against these (new L1): advancement-reward functions, the player's own `/function`, and mods that call `performPrefixedCommand(player.createCommandSourceStack(), ...)`.
  - `/trigger` runs no commands.
  - Chat or book `RUN_COMMAND` click events are sent by the player's own client. Their replies are visible to the player, so this is social engineering only.
  - I found no false rejection of a legitimate player. Chat commands use `this.player.createCommandSourceStack()`. After a respawn, the new `ServerPlayer` is both the source and the player-list entity. The singleplayer host is in the player list.
- **Does `getPlayer(uuid) == player` have gaps?**
  - It rejects FakePlayers and stale objects after logout or respawn.
  - It accepts any `ServerPlayer` that a mod inserts through `placeNewPlayer` with a fake connection. That includes bot mods, the GameTest mocks and the STATION-04 probe, so "connected" means "in the player list", not "a networked human".
  - It is untested (L2).
- **Can a non-local confirm consume or leak the owner's confirmation?**
  - No. `confirm` rejects it before `confirmations.take` (`StationExpansionService.java:84-87`). A non-local request returns before `issue`. The failure reply carries only the code text. The audit line (server log only) contains the station at the actor's position.
  - The GameTest proves non-consumption: after a console `/execute as owner ... confirm S`, the owner's confirm for another station gets `CONFIRMATION_MISMATCH`, which requires a pending entry. Run-03 audit counts match: `confirm:NOT_LOCAL_PLAYER` 2, `CONFIRMATION_MISMATCH` 1.
- **Are the new `setDirty()` after `WRITE_FAILED` and the `OUTCOME_UNKNOWN` on publish failure correct?** Yes. See I1.
- **Can the new tests fail?** Yes, for everything except the player-list check (L2). See the mutation runs below.
- **Probe properties.** Bounded, cleaned up on stop, no host internals, sound allow-list (I4).
- **Can the harness oracles pass vacuously?** I found no vacuous oracle.
  - Every probe step requires the exact action/actor, `level == space`, the host's own return value, and phrase-specific replies.
  - Station payloads are compared as complete decoded registries against an expected value derived independently from the v1.4-written payload.
  - Backup checks are exact: file set equal to the v1.4 managed files plus the manifest; per-file bytes and SHA-256 equal the manifest and the v1.4 state; schemas 2 to 3 for stations and 2 to 2 for the rest; exactly one backup directory, unchanged across restart.
  - The source-world inventory is compared.
  - `validate_log(lines, [])` requires zero ERROR/FATAL/project-WARN findings.

## What I verified and how

1. **Diffs.** I read `fa00570..e3d136f` and `e3d136f..89600ae` in full (saved as `diff-*.txt`). I re-read the committed versions of `StationCommands`, `StationExpansionService`, `StationRegistrySavedData`, `StationRegistryModel`, `CheckedSavedDataFile`, `StationCheckedExpansionTest`, `StationExpansionServiceTest` and `StationExpansionGameTests` from the `89600ae` export.
2. **Bytecode** (`bytecode/`, `javap` on `forge-1.20.1-47.4.10_mapped_official_1.20.1.jar`):
   - `CommandSourceStack.source` is `public final`;
   - `withSuppressedOutput` and `withPermission` copy `source`;
   - `sendFailure` checks `silent`;
   - `AdvancementRewards` grant path as described in L1;
   - `FunctionCommand` uses `withSuppressedOutput` + `withMaximumPermission(2)`;
   - `SignBlockEntity` uses `CommandSource.NULL`;
   - the `ServerFunctionManager` game-loop sender is `server.createCommandSourceStack()`;
   - `ServerGamePacketListenerImpl` uses `ServerPlayer.createCommandSourceStack()`;
   - `SavedData.save(File)` writes directly and clears dirty after catching `IOException`.
3. **Mutation checks** (in copies `mutA/` and `mutB/` of the export, never in the repository):
   - A:
     - Removing the `NOT_LOCAL_PLAYER` gate fails `onlyADirectlyCommandingConnectedPlayerIsAccepted`.
     - Removing the `WRITE_FAILED` `setDirty()` fails both rewrite-scheduling tests.
   - B:
     - Publishing before the checked write fails `successReplaces...` at the in-committer assertion.
     - Checking permission before Space/region fails `authorityAndLocationAreCheckedBeforePermission`.
4. **Evidence integrity** (`verify_evidence.py`, output in `verify-evidence-output.txt`, 0 FAIL):
   - **Archive hashes.**
     - `native-checks.zip` SHA-256 `c1925e02...de7a7` matches `VERIFICATION.md`, `evidence-archives.json` and `SHA256SUMS.txt`.
     - All 8 `SHA256SUMS.txt` entries match.
     - All 302 ZIP members match `native-checks-files.json` (bytes and SHA-256, no extra or missing members).
     - `review-fix-checks.zip` (553 members, `836f1535...`) and `independent-review.zip` (568 members) also match their manifests.
   - **Source identity.**
     - All 8 `fix_tested_files` equal the `e3d136f` blobs and are exactly the changed `src` set.
     - Both native `tested_implementation_files` and all 5 `source-identity.json` rows equal the `89600ae` blobs.
     - The current `build/libs` host JAR and fixture JAR hashes equal the recorded `5225de27...` and `630f50aa...`.
   - **Payload claims** (independent gzip-NBT decoder):
     - The v1.4 phase changed only `owner_id`/`members` of the target.
     - The upgrade changed only root `schema_version`/`format_epoch`, the record `schema_version`s and the target region (`-256..255` to `-384..383`).
     - `checked-write-before-save.dat` equals the post-save upgrade payload, which equals the restart payload.
     - The backup holds exactly the 4 v1.4-written files byte-for-byte, plus `manifest.json` (`manifestSchema` 2).
     - Celestial changes are exactly Earth `first_visit_at=939` plus a new Space body with `discovered_at`/`first_visit_at=939`. Restart celestial equals upgrade.
5. **Logs.**
   - Native upgrade receipt: audit order `NOT_LOCAL_PLAYER` (at the station, width 512), `UNAUTHORIZED` (member), `ISSUED`, `EXPANDED` (768), `ALREADY_EXPANDED`.
   - Log counts: 0 ERROR/FATAL/project WARN in all phases.
   - WARN breakdown: 15/11/10, consisting of offline mode, ModFileParser, VanillaPackResources, ForgeConfigSpec defaults (v1.4 phase) and the ForgeHooks version-difference warning (upgrade).
   - `gametest-latest-03.log` (fix round) and the STATION-04 `gametest-latest.log`: `All 238 required tests passed`, batch `station_expansion:1` ran, and the 22 audit lines match `review-fix.json`. The 15 ERROR lines are all the pre-existing injected failures or `server.properties`; there are no `EXPANSION_WRITE_FAILED`/`OUTCOME_UNKNOWN` lines.
   - The failed runs' reasons match the claims: run 01 "expected CHUNK_UNLOADED"; run 02 "/execute as the owner issued a confirmation" while the console line shows `NOT_LOCAL_PLAYER` (the test read Brigadier's fork count).

## Commands I ran (exit codes)

All Gradle runs used `JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"` and ran inside my directory on a `git archive 89600ae` export, never the repository working tree. None used `clean`, `runData`, `runGameTestServer` or a dedicated server.

| Command | Exit | Result |
|---|---:|---|
| `git archive --format=tar 89600ae \| tar -x -C tree-89600ae` | 0 | Read-only export (the working tree had someone else's uncommitted edits; see I6) |
| `./gradlew test --tests '*StationExpansion*' --tests '*StationCheckedExpansionTest' --tests '*AtomicSavedDataTest' --tests '*StationAccessServiceTest' --offline --no-daemon --no-build-cache --console=plain` | **0** | `:test` **executed** ("16 actionable tasks: 16 executed"). 5 suites, **28 tests, 0 failures/errors/skipped**: AtomicSavedDataTest 6, StationCheckedExpansionTest 9, StationAccessServiceTest 4, StationExpansionConfirmationsTest 5, StationExpansionServiceTest 4. Log `targeted-tests.log`, XML in `test-results/`, summary `targeted-tests-summary.txt` |
| `./gradlew compileAdapterTestJava --offline --no-daemon --console=plain` | **0** | `compileAdapterTestJava FROM-CACHE` (not a real compile). Log `compile-adaptertest.log` |
| `./gradlew compileAdapterTestJava --rerun-tasks --offline --no-daemon --no-build-cache --console=plain` | **0** | `compileAdapterTestJava` **executed**, and `StationExpansionProbe*.class` was produced. Log `compile-adaptertest-rerun.log` |
| Mutation A: `./gradlew test --tests '*StationExpansionServiceTest' --tests '*StationCheckedExpansionTest' --offline --no-daemon --no-build-cache` in `mutA/` | 1 (expected) | 13 tests, 3 failures, exactly the targeted tests. `mutation-A.log`, `mutation-A-summary.txt` |
| Mutation B: same command in `mutB/` | 1 (expected) | 13 tests, 6 failures, including the targeted `successReplaces...` (line 55) and `authorityAndLocationAreCheckedBeforePermission`. `mutation-B.log`, `mutation-B-summary.txt` |
| `python -B verify_evidence.py` | 0 | 0 FAIL; `verify-evidence-output.txt` |
| `sha256sum` of the native packet files and ZIPs | 0 | All match `SHA256SUMS.txt` |
| `unzip` of `native-checks.zip` and `review-fix-checks.zip` into `native/` and `fixchecks/` | 0 | Evidence inspected in place |
| `jar xf` / `javap -c -p` on the mapped Forge jar | 0 | See `bytecode/` |
| `git diff`, `git show`, `git log`, `git status`, `git rev-parse` (read-only) | 0 | |

**Side effects.**
- Build outputs were written only under this directory's `tree-89600ae/`, `mutA/` and `mutB/`.
- Gradle's shared user caches were read. The `--no-build-cache` runs stored no build-cache entries. The first `compileAdapterTestJava` run only *read* a cache entry.
- No repository file was modified, and no git write command was run.

## Residual risks (not findings)

- There is no real networked client, multiplayer, or long-load test. The mock connected players (GameTest and probe) prove the player-list/source rule, not client UX.
- Kill or power loss during the checked write is not exercised. There is no directory fsync (unclaimed per ADR-040).
- The expanded ring adopts existing blocks. This is accepted by ADR-040 and stated in the warning.
- A creative player can craft a written book with `RUN_COMMAND` click events and persuade an owner to click twice. The owner's own client sends both commands, and the warning is shown between the clicks.
- `CheckedSavedDataFile` refuses symlinked or junctioned world ancestors, so expansion always returns `WRITE_FAILED` on such hosts. This predates the slice.

## Statement

This is an independent code and evidence review. It is **not** a Gate approval. It does not mark STATION-03 or STATION-04 `verified` and approves no v1.5 Required Gate.

- The previous M1 is resolved for the vanilla level-2 paths it described.
- The new L1 is a narrower residual of the same contract clause. It should be fixed (reject silent sources) or accepted in ADR-040 with corrected wording.
- The new M1 should be resolved (restore the TODO and add coverage, or record an ADR waiver) before STATION-04 is marked `verified`.
