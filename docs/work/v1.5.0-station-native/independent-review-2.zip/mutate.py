"""Apply review-only mutations to a COPY of the exported 89600ae tree (never the repository)."""
import sys
from pathlib import Path

tree = Path(sys.argv[1]).resolve()
which = sys.argv[2]
assert 'arce-v150-station-rereview-' in str(tree) and 'GitHub' not in str(tree)
B = tree / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station'
SERVICE = B / 'service/StationExpansionService.java'
SAVED = B / 'persistence/StationRegistrySavedData.java'


def replace(path, old, new):
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (path, old)
    path.write_text(text.replace(old, new), encoding='utf-8')


if which == 'A':
    # M-a: drop the local-player gate in the pure check.
    replace(SERVICE, """        if (!localPlayer) {
            return StationExpansionCode.NOT_LOCAL_PLAYER;
        }
""", "")
    # M-b: drop the rewrite scheduling after a failed replacement that left non-candidate content.
    replace(SAVED, """        // Not the candidate; ordinary saves rewrite the acknowledged authority in case the file is stale.
        setDirty();
""", "")
elif which == 'B':
    # M-c: publish the expansion before the checked write (rollback-free variant).
    replace(SAVED, """        boolean[] replacementAttempted = {false};
""", """        registry.replaceExpanded(observed, expanded);
        boolean[] replacementAttempted = {false};
""")
    replace(SAVED, """        try {
            registry.replaceExpanded(observed, expanded);
        } catch (RuntimeException publishFailure) {""", """        try {
            registry.find(observed.stationId());
        } catch (RuntimeException publishFailure) {""")
    # M-d: check permission before Space/chunk/region.
    replace(SERVICE, """        if (!inSpace) {
            return StationExpansionCode.NOT_IN_SPACE;
        }
""", """        if (stationAtPosition.isPresent()
                && !access.allowed(stationAtPosition.get(), actorId, operator, StationAccessAction.EXPAND)) {
            return StationExpansionCode.UNAUTHORIZED;
        }
        if (!inSpace) {
            return StationExpansionCode.NOT_IN_SPACE;
        }
""")
else:
    raise SystemExit('unknown mutation set')
print('mutated', which, tree)
