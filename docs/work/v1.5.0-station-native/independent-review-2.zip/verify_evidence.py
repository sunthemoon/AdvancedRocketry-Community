"""Independent re-review checks of the STATION-03 fix and STATION-04 native evidence (read-only)."""
import gzip
import hashlib
import io
import json
import struct
import subprocess
import sys
import uuid
import zipfile
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
NATIVE = OUT / 'native'
results = []


def check(ok, text):
    results.append(('PASS' if ok else 'FAIL') + ': ' + text)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(commit, path):
    return subprocess.run(['git', '-C', str(REPO), 'show', f'{commit}:{path}'], capture_output=True, check=True).stdout


# ---------------------------------------------------------------- minimal NBT reader
def read_nbt(raw):
    data = gzip.decompress(raw)
    stream = io.BytesIO(data)

    def rd(fmt):
        size = struct.calcsize(fmt)
        return struct.unpack('>' + fmt, stream.read(size))[0]

    def string():
        length = rd('H')
        return stream.read(length).decode('utf-8')

    def payload(tag):
        if tag == 1: return rd('b')
        if tag == 2: return rd('h')
        if tag == 3: return rd('i')
        if tag == 4: return rd('q')
        if tag == 5: return rd('f')
        if tag == 6: return rd('d')
        if tag == 7: return list(stream.read(rd('i')))
        if tag == 8: return string()
        if tag == 9:
            inner, count = rd('b'), rd('i')
            return [payload(inner) for _ in range(count)]
        if tag == 10:
            result = {}
            while True:
                inner = rd('b')
                if inner == 0:
                    return result
                name = string()
                result[name] = payload(inner)
        if tag == 11: return [rd('i') for _ in range(rd('i'))]
        if tag == 12: return [rd('q') for _ in range(rd('i'))]
        raise ValueError('bad tag %d' % tag)

    root_tag = rd('b')
    assert root_tag == 10
    string()
    value = payload(10)
    assert stream.read() == b'', 'trailing bytes'
    return value


def nbt_uuid(value):
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


# ---------------------------------------------------------------- 1. ZIP members vs manifests
def zip_matches(zip_path, manifest_path, label):
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    expected = {row['path']: row for row in manifest}
    with zipfile.ZipFile(zip_path) as archive:
        names = [info.filename for info in archive.infolist() if not info.is_dir()]
        check(len(names) == len(set(names)), f'{label}: no duplicate ZIP members')
        check(set(names) == set(expected), f'{label}: ZIP member set equals manifest ({len(names)} vs {len(expected)})')
        bad = []
        for name in names:
            data = archive.read(name)
            row = expected.get(name)
            if row is None or row['bytes'] != len(data) or row['sha256'] != sha(data):
                bad.append(name)
        check(not bad, f'{label}: every member matches bytes+sha256 ({len(bad)} mismatches {bad[:3]})')


zip_matches(REPO / 'docs/work/v1.5.0-station-native/native-checks.zip',
            REPO / 'docs/work/v1.5.0-station-native/native-checks-files.json', 'native-checks.zip')
zip_matches(REPO / 'docs/work/v1.5.0-station-expansion/review-fix-checks.zip',
            REPO / 'docs/work/v1.5.0-station-expansion/review-fix-checks-files.json', 'review-fix-checks.zip')
zip_matches(REPO / 'docs/work/v1.5.0-station-expansion/independent-review.zip',
            REPO / 'docs/work/v1.5.0-station-expansion/independent-review-files.json', 'independent-review.zip')

# ---------------------------------------------------------------- 2. tested source hashes vs commits
fix = json.loads((REPO / 'docs/work/v1.5.0-station-expansion/review-fix.json').read_text(encoding='utf-8'))
for path, digest in fix['fix_tested_files'].items():
    check(sha(git_blob('e3d136f', path)) == digest, f'fix_tested_files {path} == e3d136f blob')
    check(sha((OUT / 'tree-89600ae' / path).read_bytes()) == digest, f'fix_tested_files {path} == 89600ae export (unchanged by STATION-04)')
changed = subprocess.run(['git', '-C', str(REPO), 'diff', '--name-only', 'fa00570', 'e3d136f', '--', 'src'],
                         capture_output=True, text=True, check=True).stdout.split()
check(set(changed) == set(fix['fix_tested_files']), f'fix_tested_files is exactly the changed src set {sorted(set(changed) ^ set(fix["fix_tested_files"]))}')

root = json.loads((REPO / 'docs/work/v1.5.0-station-native/root-checks.json').read_text(encoding='utf-8'))
for path, digest in root['tested_implementation_files'].items():
    check(sha(git_blob('89600ae', path)) == digest, f'native tested file {path} == 89600ae blob')
changed = subprocess.run(['git', '-C', str(REPO), 'diff', '--name-only', 'e3d136f', '89600ae', '--', 'src'],
                         capture_output=True, text=True, check=True).stdout.split()
check(set(changed) == set(root['tested_implementation_files']), 'native tested files are exactly the changed src set')
identity = json.loads((REPO / 'docs/work/v1.5.0-station-native/source-identity.json').read_text(encoding='utf-8'))
for row in identity['files']:
    blob = git_blob('89600ae', row['path'])
    check(sha(blob) == row['sha256'] and len(blob) == row['bytes'], f'source-identity {row["path"]} == 89600ae blob')

# Implementation JAR in build/libs (may have been rebuilt by this review's own Gradle run; recorded only)
for jar in (REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar',
            REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'):
    if jar.exists():
        results.append(f'INFO: {jar.name} currently in repo build output sha256 {sha(jar.read_bytes())}')

# ---------------------------------------------------------------- 3. native payload claims
N = NATIVE / 'native'
ST = 'advancedrocketrycommunity_stations.dat'
CE = 'advancedrocketrycommunity_celestial.dat'


def data(path):
    return read_nbt(path.read_bytes())['data']


before = data(N / 'before' / ST)
team = data(N / 'v14-team/state' / ST)
checked = data(N / 'upgrade/checked-write-before-save.dat')
upgraded = data(N / 'upgrade/state' / ST)
restarted = data(N / 'restart/state' / ST)
target = '30499d22-70c4-43d8-bdfc-2f400eeea04e'
successor = '00000000-0000-0000-0000-000000001501'


def by_id(payload):
    return {nbt_uuid(s['station_id']): s for s in payload['stations']}


check(checked == upgraded, 'checked-write-before-save payload == post-save upgrade payload')
check(restarted == upgraded, 'restart payload == upgrade payload')
bt, tt, ut = by_id(before)[target], by_id(team)[target], by_id(upgraded)[target]
check(nbt_uuid(tt['owner_id']) == successor and [nbt_uuid(m['id']) for m in tt['members']] == [nbt_uuid(bt['owner_id'])],
      'v1.4 team: successor owner, previous owner is the only member')
diff_team = {k for k in set(bt) | set(tt) if bt.get(k) != tt.get(k)}
check(diff_team == {'owner_id', 'members'}, f'v1.4 phase changed only owner/members: {sorted(diff_team)}')
diff_up = {k for k in set(tt) | set(ut) if tt.get(k) != ut.get(k)}
check(diff_up == {'region', 'schema_version'}, f'upgrade changed only region/schema on target: {sorted(diff_up)}')
check(ut['region'] == [-384, -384, 383, 383] and tt['region'] == [-256, -256, 255, 255], 'target region 512 -> 768')
root_diff = {k for k in set(team) | set(upgraded) if k != 'stations' and team.get(k) != upgraded.get(k)}
check(root_diff == {'schema_version', 'format_epoch'}, f'root diff only version/epoch: {sorted(root_diff)}')
nb_t = {k: v for k, v in by_id(team).items() if k != target}
nb_u = {k: v for k, v in by_id(upgraded).items() if k != target}
check(nb_t.keys() == nb_u.keys() and all({kk for kk in set(nb_t[s]) | set(nb_u[s]) if nb_t[s].get(kk) != nb_u[s].get(kk)} == {'schema_version'} for s in nb_t),
      'neighbor changed only record schema_version')

# backup byte identity with the v1.4-written state
backup = next((N / 'migration-backups').iterdir())
manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
files = {p.name for p in backup.iterdir()}
v14files = {p.name for p in (N / 'v14-team/state').iterdir() if p.suffix == '.dat'}
check(files == v14files | {'manifest.json'}, f'backup files == v1.4 state files + manifest ({sorted(files)})')
for row in manifest['files']:
    raw_b = (backup / row['file']).read_bytes()
    raw_s = (N / 'v14-team/state' / row['file']).read_bytes()
    check(raw_b == raw_s and sha(raw_b) == row['sha256'] and len(raw_b) == row['bytes'],
          f'backup {row["file"]} byte-identical to v1.4 state and manifest')
results.append('INFO: backup manifest ' + json.dumps({k: v for k, v in manifest.items() if k != 'files'}))

# celestial visit-only change
ce_team, ce_up, ce_re = data(N / 'v14-team/state' / CE), data(N / 'upgrade/state' / CE), data(N / 'restart/state' / CE)
old = {b['id']: b for b in ce_team['bodies']}
new = {b['id']: b for b in ce_up['bodies']}
changes = {}
for body_id in sorted(set(old) | set(new)):
    if old.get(body_id) != new.get(body_id):
        o, n = old.get(body_id) or {}, new.get(body_id) or {}
        changes[body_id] = {k: (o.get(k), n.get(k)) for k in sorted(set(o) | set(n)) if o.get(k) != n.get(k)}
results.append('INFO: celestial changes v1.4->upgrade: ' + json.dumps(changes))
check(ce_re == ce_up, 'celestial restart == upgrade (no allowance applied in restart)')

# ---------------------------------------------------------------- 4. log facts
up_latest = (N / 'upgrade/latest.log').read_text(encoding='utf-8', errors='replace').splitlines()
up_debug = (N / 'upgrade/debug.log').read_text(encoding='utf-8', errors='replace').splitlines()
confirm = [i for i, l in enumerate(up_debug) if 'code=EXPANDED' in l]
saveall = [i for i, l in enumerate(up_debug) if 'Saving' in l or 'Autosave' in l or 'save' in l.lower() and 'Saved' in l]
results.append(f'INFO: upgrade debug.log EXPANDED line indexes {confirm}; save-related lines {[(i, up_debug[i][:140]) for i in saveall][:12]}')
autosave = [l for l in up_debug if 'Autosave' in l]
check(not autosave, f'no autosave in upgrade phase ({len(autosave)})')

(OUT / 'verify-evidence-output.txt').write_text('\n'.join(results) + '\n', encoding='utf-8')
print('\n'.join(results))
print('FAILURES:', sum(r.startswith('FAIL') for r in results))
