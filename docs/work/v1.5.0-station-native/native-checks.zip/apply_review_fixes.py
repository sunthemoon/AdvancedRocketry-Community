from pathlib import Path

BASE = Path('D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/station')


def rep(path, pairs):
    p = BASE / path
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        assert s.count(old) == 1, (path, old[:70])
        s = s.replace(old, new)
    p.write_text(s, encoding='utf-8', newline='\n')


rep('service/StationExpansionCode.java', [
('''    AUTHORITY_UNAVAILABLE(false, "station authority is unavailable"),
''', '''    AUTHORITY_UNAVAILABLE(false, "station authority is unavailable"),
    NOT_LOCAL_PLAYER(false, "run this command yourself as a connected player;"
            + " command blocks, functions, signs and /execute cannot expand stations"),
'''),
])
rep('service/StationExpansionService.java', [
('''    public static StationExpansionCode check(
            StationAccessService access,
            boolean authorityAvailable,
            boolean inSpace,''', '''    public static StationExpansionCode check(
            StationAccessService access,
            boolean authorityAvailable,
            boolean localPlayer,
            boolean inSpace,'''),
('''        if (!authorityAvailable) {
            return StationExpansionCode.AUTHORITY_UNAVAILABLE;
        }
        if (!inSpace) {''', '''        if (!authorityAvailable) {
            return StationExpansionCode.AUTHORITY_UNAVAILABLE;
        }
        if (!localPlayer) {
            return StationExpansionCode.NOT_LOCAL_PLAYER;
        }
        if (!inSpace) {'''),
('''    public StationExpansionResult request(ServerPlayer player) {
        Objects.requireNonNull(player, "player");
        Located located = locate(player);''', '''    /**
     * @param issuedByPlayer whether the command source is the player itself, not a console,
     *                       command block, function, sign or {@code /execute as} wrapper
     */
    public StationExpansionResult request(ServerPlayer player, boolean issuedByPlayer) {
        Objects.requireNonNull(player, "player");
        Located located = locate(player, issuedByPlayer);'''),
('''    public StationExpansionResult confirm(ServerPlayer player, UUID stationId) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(stationId, "stationId");
        MinecraftServer server = player.getServer();
        if (server == null) {
            return StationExpansionResult.failure(StationExpansionCode.AUTHORITY_UNAVAILABLE);
        }
        StationRegistrySavedData data = StationRegistrySavedData.get(server);''', '''    public StationExpansionResult confirm(ServerPlayer player, boolean issuedByPlayer, UUID stationId) {
        Objects.requireNonNull(player, "player");
        Objects.requireNonNull(stationId, "stationId");
        MinecraftServer server = player.getServer();
        if (server == null) {
            return StationExpansionResult.failure(StationExpansionCode.AUTHORITY_UNAVAILABLE);
        }
        if (!localPlayer(server, player, issuedByPlayer)) {
            // Rejected before take(): another source cannot consume the player's confirmation.
            return audit("confirm", player, StationExpansionResult.failure(StationExpansionCode.NOT_LOCAL_PLAYER));
        }
        StationRegistrySavedData data = StationRegistrySavedData.get(server);'''),
('''        // Recheck permission, position, loaded chunk and authority against current state.
        Located located = locate(player);''', '''        // Recheck permission, position, loaded chunk and authority against current state.
        Located located = locate(player, issuedByPlayer);'''),
('''    private Located locate(ServerPlayer player) {
        MinecraftServer server = player.getServer();''', '''    /** A connected player (not a FakePlayer or detached entity) who issued the command directly. */
    private static boolean localPlayer(MinecraftServer server, ServerPlayer player, boolean issuedByPlayer) {
        return issuedByPlayer && server.getPlayerList().getPlayer(player.getUUID()) == player;
    }

    private Located locate(ServerPlayer player, boolean issuedByPlayer) {
        MinecraftServer server = player.getServer();'''),
('''        StationExpansionCode code = check(access, data.operational() && !data.expansionQuarantined(),
                inSpace, chunkLoaded, station, player.getUUID(), player.hasPermissions(2));''', '''        StationExpansionCode code = check(access, data.operational() && !data.expansionQuarantined(),
                localPlayer(server, player, issuedByPlayer), inSpace, chunkLoaded, station,
                player.getUUID(), player.hasPermissions(2));'''),
])
rep('service/StationManager.java', [
('''    public StationExpansionResult requestExpansion(ServerPlayer player) {
        return expansion.request(player);
    }

    public StationExpansionResult confirmExpansion(ServerPlayer player, UUID stationId) {
        return expansion.confirm(player, stationId);
    }''', '''    public StationExpansionResult requestExpansion(ServerPlayer player, boolean issuedByPlayer) {
        return expansion.request(player, issuedByPlayer);
    }

    public StationExpansionResult confirmExpansion(ServerPlayer player, boolean issuedByPlayer, UUID stationId) {
        return expansion.confirm(player, issuedByPlayer, stationId);
    }'''),
])
rep('command/StationCommands.java', [
('''        ServerPlayer player = context.getSource().getPlayerOrException();
        StationExpansionResult result = stations.requestExpansion(player);''', '''        ServerPlayer player = context.getSource().getPlayerOrException();
        StationExpansionResult result = stations.requestExpansion(player, issuedBy(context.getSource(), player));'''),
('''        ServerPlayer player = context.getSource().getPlayerOrException();
        StationExpansionResult result = stations.confirmExpansion(player, UuidArgument.getUuid(context, STATION));''', '''        ServerPlayer player = context.getSource().getPlayerOrException();
        StationExpansionResult result = stations.confirmExpansion(player, issuedBy(context.getSource(), player),
                UuidArgument.getUuid(context, STATION));'''),
('''    private static int expansionFailure(''', '''    /** {@code /execute as}, command blocks, functions and signs keep a different output source. */
    private static boolean issuedBy(CommandSourceStack source, ServerPlayer player) {
        return source.source == player;
    }

    private static int expansionFailure('''),
])
rep('persistence/StationRegistrySavedData.java', [
('''        registry.replaceExpanded(observed, expanded);
        return CheckedExpansion.EXPANDED;
    }''', '''        try {
            registry.replaceExpanded(observed, expanded);
        } catch (RuntimeException publishFailure) {
            // Unreachable on the owning server thread; never report a written growth as a clean failure.
            expansionQuarantined = true;
            setDirty();
            AdvancedRocketryCommunity.LOGGER.error(
                    "ARCE_STATION_EXPANSION_OUTCOME_UNKNOWN station={} stage=publish; expansion disabled until restart",
                    observed.stationId(), publishFailure);
            return CheckedExpansion.OUTCOME_UNKNOWN;
        }
        return CheckedExpansion.EXPANDED;
    }'''),
('''        AdvancedRocketryCommunity.LOGGER.error(
                "ARCE_STATION_EXPANSION_WRITE_FAILED station={} stage=replace; previous file retained",
                observed.stationId(), failure);
        return CheckedExpansion.WRITE_FAILED;''', '''        // Not the candidate; ordinary saves rewrite the acknowledged authority in case the file is stale.
        setDirty();
        AdvancedRocketryCommunity.LOGGER.error(
                "ARCE_STATION_EXPANSION_WRITE_FAILED station={} stage=replace file_present={}",
                observed.stationId(), onDisk.isPresent(), failure);
        return CheckedExpansion.WRITE_FAILED;'''),
])
print('applied')
