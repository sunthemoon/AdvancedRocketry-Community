"""Archive V150-STATION-04 native evidence and bind the staged commit; reads Temp, writes the packet only."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUN = Path(__file__).resolve().parent.parent
OUT = ROOT / 'docs/work/v1.5.0-station-native'
BASE = 'e3d136f264e881b2da4516c94d0446242179ea77'
EXCLUDED = ('station-server/', 'attempt-01-failed/station-server/', 'attempt-02-failed/station-server/',
            '__pycache__/', 'packaging/out/', 'packaging/__pycache__/')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def junit(name):
    suites = [ET.parse(p).getroot() for p in sorted((RUN / name).glob('TEST-*.xml'))]
    return {'suites': len(suites), **{k: sum(int(s.attrib.get(k, '0')) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}}


def archive():
    OUT.mkdir(exist_ok=True)
    changed = set(git('diff', '--name-only', BASE, '--', 'src', 'gradle.properties').decode().split())
    changed |= set(git('ls-files', '--others', '--exclude-standard', '--', 'src').decode().split())
    tested = {path: sha((ROOT / path).read_bytes()) for path in sorted(changed)}
    assert set(tested) == {'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/AdapterTestMod.java',
                           'src/adapterTest/java/io/github/sunthemoon/arceadaptertest/StationExpansionProbe.java'}
    summary = json.loads((RUN / 'native/summary.json').read_text())
    assert summary['result'] == 'PASS' and summary['source_world_unchanged']
    assert [c['result'] for c in summary['cycles']] == ['PASS', 'PASS', 'PASS']
    inputs = json.loads((RUN / 'native/inputs.json').read_text())
    for artifact in inputs['new']:
        path = ROOT / ('build/libs/' if artifact['mod_id'] != 'arce_adapter_test' else 'compat-test-mod/build/libs/') \
            / artifact['name']
        assert sha(path.read_bytes()) == artifact['sha256'], artifact['name']
    assert junit('full-junit') == {'suites': 173, 'tests': 961, 'failures': 0, 'errors': 0, 'skipped': 0}
    log = (RUN / 'root-gradle-01.log').read_text(encoding='utf-8', errors='replace')
    assert 'All 238 required tests passed' in log and 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log
    for name in ('attempt-01-failed/native-run-01.log', 'attempt-02-failed/native-run-02.log'):
        assert 'EXIT_CODE=1' in (RUN / name).read_text(encoding='utf-8', errors='replace'), name
    assert 'EXIT_CODE=0' in (RUN / 'native-run-03.log').read_text(encoding='utf-8', errors='replace')
    rows = []
    with zipfile.ZipFile(OUT / 'native-checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sorted(RUN.rglob('*')):
            relative = path.relative_to(RUN).as_posix()
            if any(relative.startswith(prefix) or ('/' + prefix) in relative for prefix in EXCLUDED):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                data = path.read_bytes()
                bundle.writestr(zipfile.ZipInfo(relative, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
    write('native-checks-files.json', rows)
    raw = (OUT / 'native-checks.zip').read_bytes()
    write('evidence-archives.json', {'schema_version': 1, 'base_commit': BASE, 'source_directory': str(RUN),
          'excluded': list(EXCLUDED), 'archives': [{'name': 'native-checks.zip', 'bytes': len(raw),
          'sha256': sha(raw), 'members': len(rows), 'manifest': 'native-checks-files.json'}]})
    write('native-summary.json', summary)
    write('root-checks.json', {'base_commit': BASE, 'tested_implementation_files': tested,
          'junit': junit('full-junit'), 'gametests_required_passed': 238,
          'artifacts': {'old': inputs['old'], 'new': inputs['new']},
          'scope': 'Native development check, not independent review or Required Gate approval'})
    print('PASS:', len(rows), 'members; tested', len(tested), 'files')


def finalize():
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii')
    prefix = OUT.relative_to(ROOT).as_posix() + '/'
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write('source-identity.json', {'base_commit': BASE, 'files': rows})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    listing = json.loads((OUT / 'native-checks-files.json').read_text())
    with zipfile.ZipFile(OUT / 'native-checks.zip') as bundle:
        assert bundle.testzip() is None and sorted(bundle.namelist()) == sorted(r['path'] for r in listing)
        for row in listing:
            raw = bundle.read(row['path'])
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(p for p in OUT.iterdir() if p.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                        encoding='ascii', newline='\n')
    print('PASS:', len(rows), 'staged identities,', len(links), 'links, ZIP readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--finalize', action='store_true')
    finalize() if parser.parse_args().finalize else archive()
