from pathlib import Path

p = Path(__file__).with_name('native_station_expansion_check.py')
s = p.read_text(encoding='utf-8')


def rep(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)


rep('''    def probe_command(self, process, label, actor, position, command):
        text = f'arce_station_probe {label} {actor} {position[0]} {position[1]} {position[2]} {command}'
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \\{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        require(report['actor'] == actor and report['command'] == command, 'Probe report identity differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'Production command changed the loaded chunk count: ' + label)
        self.probes.append(report)
        return report
''', '''    def probe(self, process, action, label, actor, argument):
        text = f'arce_station_probe {action} {label} {actor}' + (f' {argument}' if argument else '')
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \\{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        require(report['actor'] == actor and report['action'] == action, 'Probe report identity differs')
        self.probes.append(report)
        return report

    def join(self, process, label, actor, position):
        report = self.probe(process, 'join', label, actor, ' '.join(map(str, position)))
        require(report['connected'] is True, 'Probe player is not the connected player-list entity')
        return report

    def leave(self, process, label, actor):
        return self.probe(process, 'leave', label, actor, '')

    def probe_command(self, process, label, actor, command):
        report = self.probe(process, 'run', label, actor, command)
        require(report['command'] == command and report['level'] == HOST + ':space', 'Probe run differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'Production command changed the loaded chunk count: ' + label)
        return report
''')
rep('''CONSOLE_REJECTED = re.compile(r'A player is required to run this command here')
''', '''CONSOLE_REJECTED = re.compile(r'A player is required to run this command here')
EXECUTE_REJECTED = re.compile(r'Station expansion rejected: run this command yourself as a connected player')
''')
rep('''        phase.query(process, 'arce station expand', CONSOLE_REJECTED)
        phase.observations['console'] = 'rejected'
        member = phase.probe_command(process, 'member_request', original_owner, stand, 'arce station expand')''',
    '''        phase.query(process, 'arce station expand', CONSOLE_REJECTED)
        phase.observations['console'] = 'rejected'
        phase.join(process, 'member_join', original_owner, stand)
        phase.join(process, 'owner_join', SUCCESSOR, stand)
        phase.query(process, f'execute as {SUCCESSOR} run arce station expand', EXECUTE_REJECTED)
        phase.observations['execute_as_owner'] = 'rejected as non-local'
        member = phase.probe_command(process, 'member_request', original_owner, 'arce station expand')''')
rep('''        request = phase.probe_command(process, 'owner_request', SUCCESSOR, stand, 'arce station expand')''',
    '''        request = phase.probe_command(process, 'owner_request', SUCCESSOR, 'arce station expand')''')
rep('''        confirm = phase.probe_command(process, 'owner_confirm', SUCCESSOR, stand,
                                      'arce station expand confirm ' + target_id)''',
    '''        confirm = phase.probe_command(process, 'owner_confirm', SUCCESSOR,
                                      'arce station expand confirm ' + target_id)''')
rep('''        repeat = phase.probe_command(process, 'owner_repeat', SUCCESSOR, stand, 'arce station expand')
        require(repeat['result'] == 0 and any('already uses its largest region' in m for m in repeat['messages']),
                'Repeated expansion was not idempotent')
''', '''        repeat = phase.probe_command(process, 'owner_repeat', SUCCESSOR, 'arce station expand')
        require(repeat['result'] == 0 and any('already uses its largest region' in m for m in repeat['messages']),
                'Repeated expansion was not idempotent')
        phase.leave(process, 'owner_leave', SUCCESSOR)
        phase.leave(process, 'member_leave', original_owner)
''')
rep('''        repeat = phase.probe_command(process, 'owner_restart', SUCCESSOR, stand, 'arce station expand')''',
    '''        phase.join(process, 'member_rejoin', original_owner, stand)
        phase.join(process, 'owner_rejoin', SUCCESSOR, stand)
        repeat = phase.probe_command(process, 'owner_restart', SUCCESSOR, 'arce station expand')''')
rep('''        member = phase.probe_command(process, 'member_restart', original_owner, stand, 'arce station expand')
        require(member['result'] == 0 and any('only the owner or an operator' in m for m in member['messages']),
                'Restarted member was not rejected')
''', '''        member = phase.probe_command(process, 'member_restart', original_owner, 'arce station expand')
        require(member['result'] == 0 and any('only the owner or an operator' in m for m in member['messages']),
                'Restarted member was not rejected')
        phase.leave(process, 'owner_leave', SUCCESSOR)
        phase.leave(process, 'member_leave', original_owner)
''')
rep("""        'scope': ('v1.4-written nonempty team (admin transfer) -> v1.5 migration + probe-driven local expansion '
                  '-> restart; no real clients, invitations, crash cuts, power loss or load test')})""",
    """        'scope': ('v1.4-written nonempty team (admin transfer) -> v1.5 migration + expansion by connected '
                  'mock players (embedded channel) -> restart; no real clients, invitations, crash cuts, '
                  'power loss or load test')})""")
p.write_text(s, encoding='utf-8', newline='\n')
print('patched')
