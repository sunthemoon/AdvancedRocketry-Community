"""V150-STATION-04: three finite dedicated-server processes on a COPY of the retained v1.4 world.

1. v14-team: the pinned v1.4 host transfers one station through its existing admin command, so the
   old owner becomes a member; the world is then genuinely v1.4-written with a nonempty team.
2. upgrade: the v1.5 host migrates it before start; the opt-in fixture probe stands in for local
   players (a member is rejected, the new owner requests and confirms expansion); the station file
   is read while the server runs to show the checked write; save/stop and full readback.
3. restart: no remigration or new backup; expanded region and membership remain; repeat is idempotent.

No real clients, invitations, crash cuts, power loss or load campaign. The source world is not modified.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = HISTORY / 'server-final/world'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
OLD_HOST_SHA = '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475'
NEW_CONSUMER = REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
TARGET_NAME = 'Legacy copy witness'
SUCCESSOR = '00000000-0000-0000-0000-000000001501'
INVITEE = '00000000-0000-0000-0000-000000001502'
SPACE = 'advancedrocketrycommunity:space'
# Markers placed by the v1.4 host: three in the ring the expansion adopts, one in the gap beyond it.
MARKERS = [(300, 128, 0, 'minecraft:gold_block'), (-320, 130, 40, 'minecraft:diamond_block'),
           (10, 129, -370, 'minecraft:emerald_block'), (500, 128, 0, 'minecraft:lapis_block')]
PROBE = re.compile(r'ARCE_STATION_PROBE (\{.*\})\s*$')
CONSOLE_REJECTED = re.compile(r'A player is required to run this command here')
EXECUTE_REJECTED = re.compile(r'Station expansion rejected: run this command yourself as a connected player')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def observe_data(world, directory):
    directory.mkdir()
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def normalize_other(name, payload):
    value = copy.deepcopy(payload)
    if name == HOST + '_satellite_missions.dat':
        clock = value.pop('clock')
        require(set(clock) == {'logical_game_time', 'last_observed_game_time'}
                and all(type(v) is int and v >= 0 for v in clock.values()), 'Invalid mission clock')
    return value


def visit_only_celestial_change(before, after):
    """Connected probe players record their first Earth/Space visits; nothing else may change."""
    old = {body['id']: body for body in before['bodies']}
    new = {body['id']: body for body in after['bodies']}
    require({k: v for k, v in before.items() if k != 'bodies'} == {k: v for k, v in after.items() if k != 'bodies'},
            'Celestial root fields changed')
    require(set(old) <= set(new) and set(new) - set(old) <= {HOST + ':space'}, 'Unexpected celestial bodies')
    times = set()
    for body_id, body in new.items():
        previous = old.get(body_id)
        if previous == body:
            continue
        require(body_id in (HOST + ':earth', HOST + ':space'), 'Non-visit celestial change: ' + body_id)
        added = {k: v for k, v in body.items() if previous is None or k not in previous}
        require(previous is None or all(body[k] == previous[k] for k in previous), 'Existing celestial field changed')
        require(set(added) <= {'first_visit_at', 'discovered_at', 'id'}, 'Unexpected celestial fields')
        times.update(v for k, v in added.items() if k != 'id')
    require(len(times) <= 1, 'Visit records do not share one game time')
    return sorted(set(new) - set(old)), sorted(times)


def by_id(payload):
    return {nbt_uuid(station['station_id']): station for station in payload['stations']}


def bounds(region):
    return f'{region[0]},{region[1]}..{region[2]},{region[3]}'


def expanded_region(station):
    cx, cz = station['cell_x'] * 1024, station['cell_z'] * 1024
    return [cx - 384, cz - 384, cx + 383, cz + 383]


class Phase:
    def __init__(self, name, artifacts, probe):
        self.name, self.artifacts, self.probe = name, artifacts, probe
        self.directory = OUT / name
        self.commands, self.probes, self.observations = [], [], {}

    def query(self, process, text, pattern, timeout=30):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern, timeout, start_at=start)]

    def probe_action(self, process, action, label, actor, argument):
        text = f'arce_station_probe {action} {label} {actor}' + (f' {argument}' if argument else '')
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        require(report['actor'] == actor and report['action'] == action, 'Probe report identity differs')
        self.probes.append(report)
        return report

    def join(self, process, label, actor, position):
        report = self.probe_action(process, 'join', label, actor, ' '.join(map(str, position)))
        require(report['connected'] is True, 'Probe player is not the connected player-list entity')
        return report

    def leave(self, process, label, actor):
        return self.probe_action(process, 'leave', label, actor, '')

    def probe_command(self, process, label, actor, command):
        report = self.probe_action(process, 'run', label, actor, command)
        require(report['command'] == command and report['level'] == HOST + ':space', 'Probe run differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'Production command changed the loaded chunk count: ' + label)
        return report


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    if phase.probe:
        command.insert(1, '-Darce_adapter_test.stationSmoke=true')
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 240)
        status = server.wait_for_status(port)
        support.validate_status(status, True, phase.artifacts[0]['version'])
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        phase.commands.append('stop')
        process.command('stop')
        require(process.finish() == 0, 'Server did not stop cleanly')
        schema.validate_log(process.lines, [])
        receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                       migration_lines=[line.rstrip() for line in process.lines if '[ARCE-BETA-' in line],
                       expansion_lines=[line.rstrip() for line in process.lines if 'ARCE_STATION_EXPANSION' in line],
                       observations=phase.observations)
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        write_json(phase.directory / 'probes.json', phase.probes)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def check_backup(expected_files, source_dir):
    backups = SERVER / 'world/advancedrocketrycommunity-backups'
    directories = list(backups.iterdir())
    require(len(directories) == 1 and directories[0].is_dir(), 'Expected exactly one migration backup')
    backup = directories[0]
    manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
    require(manifest['manifestSchema'] == 2, 'Backup manifest is not per-file versioned')
    names = [row['file'] for row in manifest['files']]
    require(len(names) == len(set(names)) and set(names) == expected_files, 'Backup manifest membership differs')
    require({path.name for path in backup.iterdir()} == expected_files | {'manifest.json'}, 'Backup files differ')
    for row in manifest['files']:
        name = row['file']
        require(row['bytes'] == (backup / name).stat().st_size == (source_dir / name).stat().st_size,
                'Backup length differs from the v1.4-written input: ' + name)
        require(digest(backup / name) == row['sha256'] == digest(source_dir / name),
                'Backup differs from the v1.4-written input: ' + name)
        require(row['role'] == 'authority' and row['sourceSchema'] == 2
                and row['targetSchema'] == (3 if name == STATION else 2), 'Manifest schema differs: ' + name)
    return fixture.inventory(backups)


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    summary = json.loads((HISTORY / 'native-final/summary.json').read_text(encoding='utf-8'))
    require(summary['result'] == 'PASS' and summary['source_unchanged'], 'Historical receipt incomplete')
    old_host = support.artifact(HISTORY / 'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar',
                                HOST, '1.20.1-1.4.0-dev')
    old_consumer = support.artifact(HISTORY / 'artifacts/arce-adapter-compat-test-1.0.0.jar', support.FIXTURE, '1.0.0')
    require(old_host['sha256'] == OLD_HOST_SHA == summary['artifacts'][2]['sha256'], 'Historical host identity differs')
    require(old_consumer['sha256'] == summary['artifacts'][1]['sha256'], 'Historical consumer identity differs')
    new_host = support.artifact(REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar',
                                HOST, '1.20.1-1.5.0-dev')
    new_consumer = support.artifact(NEW_CONSUMER, support.FIXTURE, '1.0.0')
    import zipfile
    with zipfile.ZipFile(NEW_CONSUMER) as jar:
        require('io/github/sunthemoon/arceadaptertest/StationExpansionProbe.class' in jar.namelist(),
                'Rebuilt fixture lacks the station probe')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    write_json(OUT / 'inputs.json', {'history_receipt': str(HISTORY / 'native-final/summary.json'),
               'history_receipt_sha256': digest(HISTORY / 'native-final/summary.json'),
               'old': [old_host, old_consumer], 'new': [new_host, new_consumer]})
    before = observe_data(SERVER / 'world', OUT / 'before')
    old = before[STATION]
    require(old['schema_version'] == 2 and old['format_epoch'] == 'v0.9.0-beta'
            and len(old['stations']) == 2 and old['reservations'] == [], 'Unexpected historical station scope')
    targets = [station for station in old['stations'] if station['name'] == TARGET_NAME]
    require(len(targets) == 1 and targets[0]['members'] == [] and targets[0]['invitations'] == [],
            'Target station is not the retained empty-team witness')
    target_id = nbt_uuid(targets[0]['station_id'])
    original_owner = nbt_uuid(targets[0]['owner_id'])
    neighbor_id = next(sid for sid in by_id(old) if sid != target_id)
    pad = targets[0]['landing_pad']
    require(targets[0]['region'] == [pad[0] - 256, pad[2] - 256, pad[0] + 255, pad[2] + 255], 'Target is not 512 wide')
    target_expanded = expanded_region(targets[0])
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    receipts = []

    def forceload(phase, process, action):
        # Console commands need loaded chunks; this is test setup, outside every probe measurement.
        for x, y, z, block in MARKERS:
            phase.query(process, f'execute in {SPACE} run forceload {action} {x} {z}',
                        re.compile(r'(Marked|Unmarked) chunk|No chunks were|already|isn|not'))

    def check_markers(phase, process, label):
        forceload(phase, process, 'add')
        for x, y, z, block in MARKERS:
            line = phase.query(process, f'execute in {SPACE} if block {x} {y} {z} {block}',
                               re.compile(r'Test (passed|failed)|not loaded'))
            require('Test passed' in line, f'{label}: marker {block} at {x},{y},{z} changed')
        forceload(phase, process, 'remove')
        phase.observations[label] = f'{len(MARKERS)} markers intact'

    # Phase 1: a genuine v1.4 team. The v1.4 host's own invite (issued by a connected probe player
    # who owns the station) records an invitation; its admin transfer makes the old owner a member.
    def v14_actions(phase, process):
        phase.join(process, 'v14_owner_join', original_owner, stand)
        phase.join(process, 'v14_invitee_join', INVITEE, stand)
        invite = phase.probe_action(process, 'run', 'v14_invite', original_owner,
                                    f'arce station invite {target_id} probe1')
        require(invite['result'] == 1 and any('Invitation recorded for probe1' in m for m in invite['messages']),
                'v1.4 invite failed: ' + json.dumps(invite))
        phase.leave(process, 'v14_invitee_leave', INVITEE)
        phase.leave(process, 'v14_owner_leave', original_owner)
        forceload(phase, process, 'add')
        for x, y, z, block in MARKERS:
            line = phase.query(process, f'execute in {SPACE} run setblock {x} {y} {z} {block}',
                               re.compile(r'Changed the block at|Could not set the block|not loaded'))
            require('Changed the block at' in line, f'Marker {block} was not placed')
        check_markers(phase, process, 'markers_placed')
        line = phase.query(process, f'arce station admin transfer {target_id} {SUCCESSOR}',
                           re.compile(r'Station (ownership transferred|action rejected)'))
        require('ownership transferred; station=' + target_id in line, 'v1.4 transfer failed: ' + line.strip())

    stand = [pad[0], pad[1], pad[2]]
    v14 = Phase('v14-team', [old_host, new_consumer], True)
    receipts.append(run_phase(v14, port, v14_actions))
    written = observe_data(SERVER / 'world', v14.directory / 'state')
    team = written[STATION]
    require(team['schema_version'] == 2 and team['format_epoch'] == 'v0.9.0-beta'
            and all(s['schema_version'] == 1 for s in team['stations']), 'v1.4 phase did not keep its own schema')
    team_target = by_id(team)[target_id]
    require(nbt_uuid(team_target['owner_id']) == SUCCESSOR
            and [nbt_uuid(m['id']) for m in team_target['members']] == [original_owner]
            and [nbt_uuid(i['id']) for i in team_target['invitations']] == [INVITEE],
            'v1.4 invite/transfer did not produce the expected team')
    expected_team = copy.deepcopy(old)
    for station in expected_team['stations']:
        if nbt_uuid(station['station_id']) == target_id:
            station['owner_id'] = team_target['owner_id']
            station['members'] = team_target['members']
            station['invitations'] = team_target['invitations']
    require(team == expected_team, 'v1.4 phase changed station fields beyond owner/members/invitations')
    require(set(written) == set(before), 'v1.4 phase changed the managed authority set')
    celestial = HOST + '_celestial.dat'
    v14_visits = visit_only_celestial_change(before[celestial], written[celestial])
    for name in before:
        if name not in (STATION, celestial):
            require(normalize_other(name, before[name]) == normalize_other(name, written[name]),
                    'v1.4 phase changed another authority: ' + name)
    require(not (SERVER / 'world/advancedrocketrycommunity-backups').exists(), 'v1.4 phase created migration backups')
    expected_backup_files = {name for name in written}
    expected_backup_files |= {name + '_old' for name in written if (SERVER / 'world/data' / (name + '_old')).is_file()}
    require(expected_backup_files == set(written), 'Unexpected _old companions after the v1.4 phase')

    expected_upgrade = copy.deepcopy(team)
    expected_upgrade.update(schema_version=3, format_epoch='v1.5.0-orbital-station')
    for station in expected_upgrade['stations']:
        station['schema_version'] = 2
        if nbt_uuid(station['station_id']) == target_id:
            station['region'] = target_expanded
    old_bounds = bounds(team_target['region'])
    new_bounds = bounds(target_expanded)
    neighbor = by_id(team)[neighbor_id]

    def inspect(phase, process, station_id, region, label):
        line = phase.query(process, f'arce station admin inspect {station_id}', re.compile(r'region=\S+ pad='))
        require(f'region={bounds(region)} ' in line, f'{label}: inspected region differs: {line.strip()}')
        phase.observations[label] = line.strip()

    # Phase 2: v1.5 upgrade and local-player expansion through the registered command.
    def upgrade_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1002\].*migrated=1, backup=\S+-managed', l) for l in process.lines),
                'Unexpected migration startup result')
        inspect(phase, process, target_id, team_target['region'], 'target_before')
        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_before')
        check_markers(phase, process, 'markers_after_migration')
        phase.query(process, 'arce station expand', CONSOLE_REJECTED)
        phase.observations['console'] = 'rejected'
        phase.join(process, 'member_join', original_owner, stand)
        phase.join(process, 'owner_join', SUCCESSOR, stand)
        phase.join(process, 'invitee_join', INVITEE, stand)
        invitee = phase.probe_command(process, 'invitee_request', INVITEE, 'arce station expand')
        require(invitee['result'] == 0 and any('only the owner or an operator' in m for m in invitee['messages']),
                'Invitee expansion was not rejected')
        phase.leave(process, 'invitee_leave', INVITEE)
        phase.query(process, f'execute as {SUCCESSOR} run arce station expand', EXECUTE_REJECTED)
        phase.observations['execute_as_owner'] = 'rejected as non-local'
        member = phase.probe_command(process, 'member_request', original_owner, 'arce station expand')
        require(member['result'] == 0 and any('only the owner or an operator' in m for m in member['messages']),
                'Member expansion was not rejected')
        request = phase.probe_command(process, 'owner_request', SUCCESSOR, 'arce station expand')
        require(request['result'] == 1 and any(f'id={target_id} from region {old_bounds} to {new_bounds}' in m
                                               and 'expand confirm ' + target_id in m for m in request['messages']),
                'Owner request did not issue the expected confirmation')
        pending = schema.read_nbt(SERVER / 'world/data' / STATION)['data']
        require(by_id(pending)[target_id]['region'] == team_target['region'], 'Request alone changed stored authority')
        confirm = phase.probe_command(process, 'owner_confirm', SUCCESSOR,
                                      'arce station expand confirm ' + target_id)
        require(confirm['result'] == 1 and any(f'Station expanded; station={target_id} region={new_bounds}' in m
                                               for m in confirm['messages']), 'Owner confirmation failed')
        live = schema.read_nbt(SERVER / 'world/data' / STATION)['data']
        require(live == expected_upgrade, 'Checked write is not the complete expected registry before save-all')
        shutil.copyfile(SERVER / 'world/data' / STATION, phase.directory / 'checked-write-before-save.dat')
        phase.observations['checked_write_before_save'] = 'matches expected expanded registry'
        inspect(phase, process, target_id, target_expanded, 'target_after')
        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_after')
        check_markers(phase, process, 'markers_after_expansion')
        repeat = phase.probe_command(process, 'owner_repeat', SUCCESSOR, 'arce station expand')
        require(repeat['result'] == 0 and any('already uses its largest region' in m for m in repeat['messages']),
                'Repeated expansion was not idempotent')
        phase.leave(process, 'owner_leave', SUCCESSOR)
        phase.leave(process, 'member_leave', original_owner)

    upgrade = Phase('upgrade', [new_host, new_consumer], True)
    receipts.append(run_phase(upgrade, port, upgrade_actions))
    upgraded = observe_data(SERVER / 'world', upgrade.directory / 'state')
    require(upgraded[STATION] == expected_upgrade, 'Upgraded station payload differs from the expected expansion')
    visit_change = visit_only_celestial_change(written[celestial], upgraded[celestial])
    for name in written:
        if name not in (STATION, celestial):
            require(normalize_other(name, written[name]) == normalize_other(name, upgraded[name]),
                    'Upgrade changed another authority: ' + name)
    backup_snapshot = check_backup(expected_backup_files, v14.directory / 'state')
    fixture.copy_world(SERVER / 'world/advancedrocketrycommunity-backups', OUT / 'migration-backups')

    # Phase 3: same-world restart.
    def restart_actions(phase, process):
        require(any(re.search(r'\[ARCE-BETA-1001\].*migrated=0, backup=none', l) for l in process.lines),
                'Restart remigrated or created a backup')
        inspect(phase, process, target_id, target_expanded, 'target_restart')
        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_restart')
        check_markers(phase, process, 'markers_after_restart')
        phase.join(process, 'member_rejoin', original_owner, stand)
        phase.join(process, 'owner_rejoin', SUCCESSOR, stand)
        repeat = phase.probe_command(process, 'owner_restart', SUCCESSOR, 'arce station expand')
        require(repeat['result'] == 0 and any('already uses its largest region' in m for m in repeat['messages']),
                'Restarted expansion was not idempotent')
        member = phase.probe_command(process, 'member_restart', original_owner, 'arce station expand')
        require(member['result'] == 0 and any('only the owner or an operator' in m for m in member['messages']),
                'Restarted member was not rejected')
        phase.leave(process, 'owner_leave', SUCCESSOR)
        phase.leave(process, 'member_leave', original_owner)

    restart = Phase('restart', [new_host, new_consumer], True)
    receipts.append(run_phase(restart, port, restart_actions))
    restarted = observe_data(SERVER / 'world', restart.directory / 'state')
    require(restarted[STATION] == upgraded[STATION], 'Restart changed the station payload')
    restart_visits = visit_only_celestial_change(upgraded[celestial], restarted[celestial])
    for name in upgraded:
        if name not in (STATION, celestial):
            require(normalize_other(name, upgraded[name]) == normalize_other(name, restarted[name]),
                    'Restart changed another authority: ' + name)
    require(check_backup(expected_backup_files, v14.directory / 'state') == backup_snapshot,
            'Restart modified the migration backup')
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE), 'java': JAVA,
        'target_station': target_id, 'neighbor_station': neighbor_id, 'successor_owner': SUCCESSOR,
        'member': original_owner, 'invitee': INVITEE, 'markers': MARKERS,
        'regions': {'before': team_target['region'], 'after': target_expanded},
        'celestial_visit_records_from_probe_players': {
            'v14': {'new_bodies': v14_visits[0], 'game_times': v14_visits[1]},
            'upgrade': {'new_bodies': visit_change[0], 'game_times': visit_change[1]},
            'restart': {'new_bodies': restart_visits[0], 'game_times': restart_visits[1]}},
        'cycles': receipts,
        'scope': ('v1.4-written team (player invite + admin transfer) and ring/gap block markers -> v1.5 '
                  'migration + expansion by connected mock players (embedded channel) -> restart; no real '
                  'clients, rocket data, unknown orbit body, crash cuts, power loss or load test')})
    print('PASS: v1.4 team preserved; checked expansion written, restarted and idempotent; source unchanged')


if __name__ == '__main__':
    main()
