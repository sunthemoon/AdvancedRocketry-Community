"""Extend the STATION-04 harness: v1.4-written invitation (probe players) and ring/gap block markers."""
from pathlib import Path

p = Path(__file__).with_name('native_station_expansion_check.py')
s = p.read_text(encoding='utf-8')


def rep(old, new):
    global s
    assert s.count(old) == 1, old[:90]
    s = s.replace(old, new)


rep("""SUCCESSOR = '00000000-0000-0000-0000-000000001501'
""", """SUCCESSOR = '00000000-0000-0000-0000-000000001501'
INVITEE = '00000000-0000-0000-0000-000000001502'
SPACE = 'advancedrocketrycommunity:space'
# Markers placed by the v1.4 host: three in the ring the expansion adopts, one in the gap beyond it.
MARKERS = [(300, 128, 0, 'minecraft:gold_block'), (-320, 130, 40, 'minecraft:diamond_block'),
           (10, 129, -370, 'minecraft:emerald_block'), (500, 128, 0, 'minecraft:lapis_block')]
""")

rep("""    # Phase 1: genuine v1.4 team via the v1.4 host's own admin transfer command.
    def v14_actions(phase, process):
        line = phase.query(process, f'arce station admin transfer {target_id} {SUCCESSOR}',
                           re.compile(r'Station (ownership transferred|action rejected)'))
        require('ownership transferred; station=' + target_id in line, 'v1.4 transfer failed: ' + line.strip())

    v14 = Phase('v14-team', [old_host, old_consumer], False)""",
"""    def check_markers(phase, process, label):
        for x, y, z, block in MARKERS:
            line = phase.query(process, f'execute in {SPACE} if block {x} {y} {z} {block}',
                               re.compile(r'Test (passed|failed)'))
            require('Test passed' in line, f'{label}: marker {block} at {x},{y},{z} changed')
        phase.observations[label] = f'{len(MARKERS)} markers intact'

    # Phase 1: a genuine v1.4 team. The v1.4 host's own invite (issued by a connected probe player
    # who owns the station) records an invitation; its admin transfer makes the old owner a member.
    def v14_actions(phase, process):
        phase.join(process, 'v14_owner_join', original_owner, stand)
        phase.join(process, 'v14_invitee_join', INVITEE, stand)
        invite = phase.probe_action(process, 'run', 'v14_invite', original_owner,
                                    f'arce station invite {target_id} probe1')
        require(invite['result'] == 1 and any('Invitation recorded for probe1' in m for m in invite['messages']),
                'v1.4 invite failed: ' + json.dumps(invite))
        phase.leave(process, 'v14_invitee_leave', INVITEE)
        phase.leave(process, 'v14_owner_leave', original_owner)
        for x, y, z, block in MARKERS:
            line = phase.query(process, f'execute in {SPACE} run setblock {x} {y} {z} {block}',
                               re.compile(r'Changed the block at|Could not set the block'))
            require('Changed the block at' in line, f'Marker {block} was not placed')
        check_markers(phase, process, 'markers_placed')
        line = phase.query(process, f'arce station admin transfer {target_id} {SUCCESSOR}',
                           re.compile(r'Station (ownership transferred|action rejected)'))
        require('ownership transferred; station=' + target_id in line, 'v1.4 transfer failed: ' + line.strip())

    stand = [pad[0], pad[1], pad[2]]
    v14 = Phase('v14-team', [old_host, new_consumer], True)""")

rep("""            and team_target['invitations'] == [], 'v1.4 transfer did not produce the expected team')""",
    """            and [nbt_uuid(i['id']) for i in team_target['invitations']] == [INVITEE],
            'v1.4 invite/transfer did not produce the expected team')""")
rep("""            station['members'] = team_target['members']
    require(team == expected_team, 'v1.4 phase changed station fields beyond owner/members')""",
    """            station['members'] = team_target['members']
            station['invitations'] = team_target['invitations']
    require(team == expected_team, 'v1.4 phase changed station fields beyond owner/members/invitations')""")
rep("""    for name in before:
        if name != STATION:
            require(normalize_other(name, before[name]) == normalize_other(name, written[name]),
                    'v1.4 phase changed another authority: ' + name)""",
    """    celestial = HOST + '_celestial.dat'
    v14_visits = visit_only_celestial_change(before[celestial], written[celestial])
    for name in before:
        if name not in (STATION, celestial):
            require(normalize_other(name, before[name]) == normalize_other(name, written[name]),
                    'v1.4 phase changed another authority: ' + name)""")
rep("""    neighbor = by_id(team)[neighbor_id]
    stand = [pad[0], pad[1], pad[2]]
""", """    neighbor = by_id(team)[neighbor_id]
""")
rep("""        inspect(phase, process, target_id, team_target['region'], 'target_before')
        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_before')""",
    """        inspect(phase, process, target_id, team_target['region'], 'target_before')
        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_before')
        check_markers(phase, process, 'markers_after_migration')""")
rep("""        phase.join(process, 'owner_join', SUCCESSOR, stand)
        phase.query(process, f'execute as {SUCCESSOR} run arce station expand', EXECUTE_REJECTED)""",
    """        phase.join(process, 'owner_join', SUCCESSOR, stand)
        phase.join(process, 'invitee_join', INVITEE, stand)
        invitee = phase.probe_command(process, 'invitee_request', INVITEE, 'arce station expand')
        require(invitee['result'] == 0 and any('only the owner or an operator' in m for m in invitee['messages']),
                'Invitee expansion was not rejected')
        phase.leave(process, 'invitee_leave', INVITEE)
        phase.query(process, f'execute as {SUCCESSOR} run arce station expand', EXECUTE_REJECTED)""")
rep("""        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_after')
        repeat = phase.probe_command(process, 'owner_repeat', SUCCESSOR, 'arce station expand')""",
    """        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_after')
        check_markers(phase, process, 'markers_after_expansion')
        repeat = phase.probe_command(process, 'owner_repeat', SUCCESSOR, 'arce station expand')""")
rep("""    celestial = HOST + '_celestial.dat'
    visit_change = visit_only_celestial_change(written[celestial], upgraded[celestial])""",
    """    visit_change = visit_only_celestial_change(written[celestial], upgraded[celestial])""")
rep("""        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_restart')
        phase.join(process, 'member_rejoin', original_owner, stand)""",
    """        inspect(phase, process, neighbor_id, neighbor['region'], 'neighbor_restart')
        check_markers(phase, process, 'markers_after_restart')
        phase.join(process, 'member_rejoin', original_owner, stand)""")
rep("""    for name in upgraded:
        if name != STATION:
            require(normalize_other(name, upgraded[name]) == normalize_other(name, restarted[name]),
                    'Restart changed another authority: ' + name)""",
    """    restart_visits = visit_only_celestial_change(upgraded[celestial], restarted[celestial])
    for name in upgraded:
        if name not in (STATION, celestial):
            require(normalize_other(name, upgraded[name]) == normalize_other(name, restarted[name]),
                    'Restart changed another authority: ' + name)""")
rep("""        'member': original_owner, 'regions': {'before': team_target['region'], 'after': target_expanded},
        'celestial_visit_records_from_probe_players': {'new_bodies': visit_change[0], 'game_times': visit_change[1]},""",
    """        'member': original_owner, 'invitee': INVITEE, 'markers': MARKERS,
        'regions': {'before': team_target['region'], 'after': target_expanded},
        'celestial_visit_records_from_probe_players': {
            'v14': {'new_bodies': v14_visits[0], 'game_times': v14_visits[1]},
            'upgrade': {'new_bodies': visit_change[0], 'game_times': visit_change[1]},
            'restart': {'new_bodies': restart_visits[0], 'game_times': restart_visits[1]}},""")
rep("""        'scope': ('v1.4-written nonempty team (admin transfer) -> v1.5 migration + expansion by connected '
                  'mock players (embedded channel) -> restart; no real clients, invitations, crash cuts, '
                  'power loss or load test')})""",
    """        'scope': ('v1.4-written team (player invite + admin transfer) and ring/gap block markers -> v1.5 '
                  'migration + expansion by connected mock players (embedded channel) -> restart; no real '
                  'clients, rocket data, unknown orbit body, crash cuts, power loss or load test')})""")
p.write_text(s, encoding='utf-8', newline='\n')
print('patched')
