"""Generic slice packer: archive one Temp evidence directory into a docs/work packet and bind the staged tree.

Usage: archive_evidence.py --out docs/work/<packet> --base <commit> [--finalize]
Reads the evidence directory (this script's parent's parent) without modifying it.
"""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
RUN = Path(__file__).resolve().parent.parent
EXCLUDED = ('packaging/out/', '__pycache__/', 'station-server/')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def write(out, name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def archive(out, base):
    out.mkdir(parents=True, exist_ok=True)
    tested = json.loads((RUN / 'implementation-files.json').read_text())
    for relative, digest in tested.items():
        assert sha((ROOT / relative).read_bytes()) == digest, 'tested file changed: ' + relative
    for row in json.loads((RUN / 'artifacts.json').read_text())['artifacts']:
        assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
    rows = []
    with zipfile.ZipFile(out / 'root-checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sorted(RUN.rglob('*')):
            relative = path.relative_to(RUN).as_posix()
            if any(relative.startswith(prefix) or ('/' + prefix) in relative for prefix in EXCLUDED):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                data = path.read_bytes()
                bundle.writestr(zipfile.ZipInfo(relative, (2026, 9, 30, 0, 0, 0)), data, zipfile.ZIP_DEFLATED, 9)
                rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
    write(out, 'root-checks-files.json', rows)
    raw = (out / 'root-checks.zip').read_bytes()
    write(out, 'evidence-archives.json', {'schema_version': 1, 'base_commit': base, 'source_directory': str(RUN),
          'excluded': list(EXCLUDED), 'archives': [{'name': 'root-checks.zip', 'bytes': len(raw),
          'sha256': sha(raw), 'members': len(rows), 'manifest': 'root-checks-files.json'}]})
    write(out, 'root-checks.json', {'base_commit': base, 'tested_implementation_files': tested,
          'artifacts': json.loads((RUN / 'artifacts.json').read_text()),
          'junit': json.loads((RUN / 'junit-summary.json').read_text()),
          'scope': 'Short development checks, not independent review or Required Gate approval'})
    print('PASS:', len(rows), 'members; sha256', sha(raw))


def finalize(out, base):
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (out / name).exists():
            (out / name).write_text('', encoding='ascii')
    prefix = out.relative_to(ROOT).as_posix() + '/'
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', base).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith(prefix) and (ROOT / relative).exists():
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md') and (ROOT / relative).exists():
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    assert git('diff', '--name-only').decode().strip() == '', 'unstaged tracked changes remain'
    write(out, 'source-identity.json', {'base_commit': base, 'files': rows})
    write(out, 'links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only', 'links': links})
    for index in out.glob('*-files.json'):
        with zipfile.ZipFile(index.with_name(index.name.replace('-files.json', '.zip'))) as bundle:
            listing = json.loads(index.read_text())
            assert bundle.testzip() is None and sorted(bundle.namelist()) == sorted(r['path'] for r in listing)
            for row in listing:
                raw = bundle.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(p for p in out.iterdir() if p.name != 'SHA256SUMS.txt')
    (out / 'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                        encoding='ascii', newline='\n')
    print('PASS:', len(rows), 'staged identities,', len(links), 'links, ZIP readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True)
    parser.add_argument('--base', required=True)
    parser.add_argument('--finalize', action='store_true')
    args = parser.parse_args()
    target = ROOT / args.out
    finalize(target, args.base) if args.finalize else archive(target, args.base)
