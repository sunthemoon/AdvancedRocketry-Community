"""Mutation spot checks of the C12c railgun rules: apply one mutation to a pure railgun class, run the railgun unit
tests, record which tests fail, restore the file byte for byte. A mutation that no test kills is reported, not
hidden."""
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
OUT = E / 'mutations'
OUT.mkdir(exist_ok=True)
PKG = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/endgame/railgun'
GRADLEW = str(ROOT / 'gradlew.bat')
ENV = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-17.0.7')

MUTATIONS = [
    ('R1', 'RailgunRoute.java', 'the owner check of the route rule removed',
     '        if (!operator && !to.owner().equals(sourceOwner)) {', '        if (false) {'),
    ('R2', 'RailgunRoute.java', 'the star-system check removed',
     'return from.system().equals(toPlace.system()) ? EndgameCode.OK : EndgameCode.ROUTE_OUT_OF_SYSTEM;',
     'return EndgameCode.OK;'),
    ('R3', 'RailgunRoute.java', 'LOCAL without the same body',
     'boolean local = from.level().equals(to.level()) && from.body().equals(to.body());',
     'boolean local = from.level().equals(to.level());'),
    ('R4', 'RailgunRoute.java', 'the travel time without its 200-tick cap',
     '''        long travel = Math.min(Math.max(MIN_TRAVEL_TICKS + d / BLOCKS_PER_TRAVEL_TICK, MIN_TRAVEL_TICKS),
                MAX_LOCAL_TRAVEL_TICKS);''',
     '''        long travel = Math.max(MIN_TRAVEL_TICKS + d / BLOCKS_PER_TRAVEL_TICK, MIN_TRAVEL_TICKS);'''),
    ('R5', 'RailgunRoute.java', 'the source itself accepted as a launch destination',
     '!allowSource && to.id().equals(source)', 'false && to.id().equals(source)'),
    ('R6', 'RailgunLaunch.java', 'the minimum stack size ignored',
     'if (!stack.isEmpty() && stack.getCount() >= minimum) {', 'if (!stack.isEmpty()) {'),
    ('R7', 'RailgunLaunch.java', 'a launch to a destination whose registration is not durable',
     '''        if (!facts.targetDurable()) {
            return EndgameCode.AWAITING_WORLD_SAVE;
        }
''', ''),
    ('R8', 'RailgunLaunch.java', 'the energy checked after the outbox',
     '''        if (!facts.energy()) {
            return EndgameCode.INSUFFICIENT_ENERGY;
        }
        if (facts.escrowBlocked()) {
            return EndgameCode.ROOT_BUSY;
        }
        if (!facts.outboxFree()) {
            return EndgameCode.OUTBOX_FULL;
        }''',
     '''        if (facts.escrowBlocked()) {
            return EndgameCode.ROOT_BUSY;
        }
        if (!facts.outboxFree()) {
            return EndgameCode.OUTBOX_FULL;
        }
        if (!facts.energy()) {
            return EndgameCode.INSUFFICIENT_ENERGY;
        }'''),
]

results = []
originals = {name: (PKG / name).read_bytes() for name in {m[1] for m in MUTATIONS}}
try:
    for name, file, description, old, new in MUTATIONS:
        path = PKG / file
        text = originals[file].decode('utf-8')
        assert text.count(old) == 1, (name, text.count(old))
        path.write_bytes(text.replace(old, new).encode('utf-8'))
        log = OUT / f'{name}.log'
        with log.open('w', encoding='utf-8') as handle:
            code = subprocess.call([GRADLEW, 'test', '--offline', '--no-daemon', '--tests',
                                    'io.github.sunthemoon.advancedrocketrycommunity.endgame.railgun.*'],
                                   cwd=ROOT, env=ENV, stdout=handle, stderr=subprocess.STDOUT)
        failing = []
        for report in sorted((ROOT / 'build/test-results/test').glob('*railgun*.xml')):
            suite = ET.parse(report).getroot()
            for case in suite.iter('testcase'):
                if case.find('failure') is not None or case.find('error') is not None:
                    failing.append(suite.get('name').rsplit('.', 1)[-1] + '.' + case.get('name'))
        text_log = log.read_text(encoding='utf-8')
        compiled = 'compileJava FAILED' not in text_log and 'compileTestJava FAILED' not in text_log
        results.append({'mutation': name, 'file': file, 'description': description, 'gradle_exit': code,
                        'compiled': compiled, 'killed': compiled and code != 0 and bool(failing),
                        'failing_tests': failing})
        print(name, 'exit', code, 'failing', len(failing), flush=True)
        path.write_bytes(originals[file])
finally:
    for file, data in originals.items():
        (PKG / file).write_bytes(data)
restored = {file: hashlib.sha256((PKG / file).read_bytes()).hexdigest() for file in originals}
assert all(hashlib.sha256(data).hexdigest() == restored[file] for file, data in originals.items())
(OUT / 'mutations.json').write_text(json.dumps({'restored_sha256': restored, 'results': results}, indent=2)
                                    + '\n', encoding='utf-8', newline='\n')
print('killed', sum(r['killed'] for r in results), 'of', len(results))
