import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
sys.path.insert(0, str(root))
from scripts.validate_repository import markdown_link_errors

baseline = (here / 'RISK-BEFORE.md').read_bytes()
candidate = (root / 'docs/11-RISK-REGISTER.md').read_bytes()


def strip_row(data):
    lines = data.splitlines(keepends=True)
    selected = [line for line in lines if line.startswith(b'| R-021 |')]
    assert len(selected) == 1
    return b''.join(line for line in lines if not line.startswith(b'| R-021 |'))


outside = strip_row(baseline)
assert strip_row(candidate) == outside
assert hashlib.sha256(outside).hexdigest() == 'dab7044a8a8f7e20927fe5eb5a5dff15156be7ec0de0a7ea08f56ec02a362aa2'
assert hashlib.sha256(candidate).hexdigest() == '8216d438497ed9158db7f46d296dc426ef67f20d0a8fb937a397e6450c2e9133'
proposal = root / 'docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md'
assert hashlib.sha256(proposal.read_bytes()).hexdigest() == 'f6ca5fd460346969c707b6fd0fb15b7ae4ea6ea2a45db002c9e498005ada3bad'
snapshot = json.loads(Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/SOURCE22-MANIFEST-01.json').read_bytes())
changed = [name for name, row in snapshot.items()
           if hashlib.sha256((root / name).read_bytes()).hexdigest() != row['sha256']]
assert not changed, changed
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '44b394fead60d3d451dc11869a5b2cb730974ab9'
paths = {root / name for name in subprocess.check_output(
    ['git', 'ls-files', '*.md'], cwd=root, text=True).splitlines()}
paths.update((root / 'docs/work/v1.8.0-c16a-save-guard').rglob('*.md'))
broken, checked = markdown_link_errors(root, list(paths))
links = {'files': len(paths), 'links': checked, 'errors': broken,
         'private_directory_read_or_walked': False,
         'inputs': [{'path': path.relative_to(root).as_posix(),
                     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for path in sorted(paths)]}
target = here / 'MARKDOWN-LINKS-01.json'
assert not target.exists()
target.write_bytes((json.dumps(links, indent=2) + '\n').encode())
print(json.dumps({key: links[key] for key in ('files', 'links', 'errors')}), flush=True)
rows = []
for name, command in (
    ('planning', [sys.executable, '-B', 'scripts/validate_v1plus_planning.py']),
    ('ledger', [sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('whitespace', ['git', 'diff', '--check']),
    ('code-diff', ['git', 'diff', '--exit-code', '--', 'src', 'build.gradle', 'settings.gradle', 'gradle.properties', 'gradle', 'gradlew', 'gradlew.bat'])):
    start = datetime.datetime.now(datetime.timezone.utc)
    log = here / (name + '-01.log')
    command_path = here / (name + '-01.command.json')
    assert not log.exists() and not command_path.exists()
    command_path.write_bytes((json.dumps({'command': command, 'cwd': str(root),
        'started_utc': start.isoformat()}, indent=2) + '\n').encode())
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode,
           'elapsed_seconds': (datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    print(json.dumps(row), flush=True)
receipt = {'commands': rows, 'current_head': head, 'source22_inputs_exact': len(snapshot),
           'outside_r021_bytes_exact': len(outside), 'accepted_adr_unchanged': True,
           'links_exit': int(bool(broken)), 'risk_or_adr_accepted': False,
           'runtime_or_gate_approved': False}
target = here / 'PUBLICATION-CHECKS-01.json'
assert not target.exists()
target.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
sys.exit(int(bool(broken or any(row['exit'] for row in rows))))
