import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
before = Path('D:/ARCE-Task-Evidence/v1.8.0/ardr-301351e852/RISK-BEFORE.md').read_bytes()
assert hashlib.sha256(before).hexdigest() == 'fc84e8d2233cccba1abd009cdcb4eecad02f2921fc5f46126e6cf3e0ee32d0f5'
after = (root / 'docs/11-RISK-REGISTER.md').read_bytes()


def outside_row(data):
    lines = data.splitlines(keepends=True)
    rows = [index for index, line in enumerate(lines) if line.startswith(b'| R-021 |')]
    assert len(rows) == 1
    index = rows[0]
    return b''.join(lines[:index]), b''.join(lines[index+1:]), lines[index]


old_prefix, old_suffix, old_row = outside_row(before)
new_prefix, new_suffix, new_row = outside_row(after)
assert old_prefix == new_prefix and old_suffix == new_suffix
committed_risk = subprocess.check_output(['git', 'show',
    '44b394fead60d3d451dc11869a5b2cb730974ab9:docs/11-RISK-REGISTER.md'], cwd=root)
assert committed_risk == old_prefix + old_suffix
snapshot = json.loads(Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/SOURCE22-MANIFEST-01.json').read_bytes())
changed = [name for name, row in snapshot.items()
           if hashlib.sha256((root / name).read_bytes()).hexdigest() != row['sha256']]
assert not changed, changed
adr_name = 'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md'
adr = (root / adr_name).read_bytes()
assert hashlib.sha256(adr).hexdigest() == '789522c7c982209df660745442ca96fa1f83cc57b29c7f9692b609219c7c37d0'
assert subprocess.check_output(['git', 'show', '44b394fead60d3d451dc11869a5b2cb730974ab9:' + adr_name], cwd=root) == adr
proposal_name = 'docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md'
proposal = (root / proposal_name).read_bytes()
assert hashlib.sha256(proposal).hexdigest() == 'f6ca5fd460346969c707b6fd0fb15b7ae4ea6ea2a45db002c9e498005ada3bad'
target = here / 'RISK-BEFORE.md'
assert not target.exists()
target.write_bytes(before)
result = {'tested_code_commit': '1ece7e9d2515003ca705b5634ef654a6bcae8f89',
    'documentation_baseline': '44b394fead60d3d451dc11869a5b2cb730974ab9',
    'owner_edited_risk_before_sha256': hashlib.sha256(before).hexdigest(),
    'candidate_risk_sha256': hashlib.sha256(after).hexdigest(),
    'outside_r021_bytes_unchanged': True,
    'outside_r021_bytes_equal_committed_risk': True,
    'accepted_adr_bytes_unchanged': True,
    'accepted_adr_sha256': hashlib.sha256(adr).hexdigest(),
    'source22_inputs_exact': len(snapshot), 'source_changes': changed,
    'proposal_path': proposal_name, 'proposal_bytes': len(proposal),
    'proposal_sha256': hashlib.sha256(proposal).hexdigest(),
    'risk_or_runtime_accepted': False, 'gate_approved': False}
target = here / 'CANDIDATE-INTAKE-01.json'
assert not target.exists()
target.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
