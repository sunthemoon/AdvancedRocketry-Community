import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

here = Path(__file__).parent
source = here.parent / 'ardr-301351e852'
manifest = (source / 'EVIDENCE-MANIFEST.json').read_bytes()
assert hashlib.sha256(manifest).hexdigest() == 'ee2a8d16e359f6fe0e20d917f7eca29ec4826472ca0991d770d8c34a733c2fa8'
assert hashlib.sha256((source / 'REVIEW-01.md').read_bytes()).hexdigest() == '307375ed1549126349f7d2355652c6df5bc0e1547050262dc08072f87c69671e'
files = json.loads(manifest)['files']
payloads = {}
for name, row in files.items():
    parts = PurePosixPath(name).parts
    assert not PurePosixPath(name).is_absolute() and ':' not in name and '\\' not in name
    assert all(part not in ('', '.', '..') for part in parts)
    path = source.joinpath(*parts).resolve()
    assert path.is_relative_to(source.resolve())
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    payloads[name] = data
payloads['EVIDENCE-MANIFEST.json'] = manifest
assert len({name.casefold() for name in payloads}) == len(payloads)
target = Path('D:/GitHub/AdvancedRocketry-Community/docs/work/v1.8.0-c16a-save-guard/reviews/disclosure-correction-01.zip')
assert not target.exists()
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payloads.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(payloads)
    assert all(archive.read(name) == data for name, data in payloads.items())
receipt = {'target': str(target), 'entries': len(payloads), 'bytes': target.stat().st_size,
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'report_sha256': '307375ed1549126349f7d2355652c6df5bc0e1547050262dc08072f87c69671e',
           'manifest_sha256': hashlib.sha256(manifest).hexdigest(),
           'all_original_payloads_exact': True, 'originals_modified': False,
           'risk_or_adr_accepted': False, 'gate_claimed': False}
target = here / 'REVIEW-PACKET-01.json'
assert not target.exists()
target.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt))
