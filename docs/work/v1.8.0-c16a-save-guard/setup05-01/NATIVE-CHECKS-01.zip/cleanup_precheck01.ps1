$ErrorActionPreference = 'Stop'
$parent = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\guard-forced-setup-05\native-05'
$target = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\guard-forced-setup-05\native-05\server'
$out = 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\guard-forced-setup-05'
foreach ($key in @('TEMP','TMP','TMPDIR')) { Set-Item -LiteralPath "Env:$key" -Value "$out\tmp" }
$item = Get-Item -LiteralPath $target -Force
if (-not $item.PSIsContainer -or $item.FullName -cne $target) { throw 'Unexpected owned cleanup target' }
if ([IO.Path]::GetDirectoryName($item.FullName) -cne $parent) { throw 'Target outside literal runtime parent' }
$cursor = $item
while ($null -ne $cursor) {
    if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse ancestor' }
    $cursor = $cursor.Parent
}
$entries = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
if (@($entries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -ne 0) { throw 'Reparse child' }
foreach ($entry in $entries) {
    if (-not $entry.FullName.StartsWith($target + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Child outside owned target' }
}
$summary = Get-Content -LiteralPath "$parent\summary.json" -Raw -Encoding UTF8 | ConvertFrom-Json
if ($summary.result -cne 'PASS' -or $summary.cycles.Count -ne 2) { throw 'Incomplete native run' }
if (@($summary.cycles | Where-Object { $_.exit_code -ne 0 }).Count -ne 0) { throw 'Host not cleanly exited' }
$capture = Get-Content -LiteralPath "$out\stopped-05\CAPTURE-01.json" -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $capture.compressed_record_equals_original -or $capture.result -cne 'STOPPED_CAPTURE') { throw 'Missing preserved fixed capture' }
if ((Get-FileHash -LiteralPath "$out\stopped-05\chunk-11-11.nbt.zlib" -Algorithm SHA256).Hash.ToLowerInvariant() -cne $capture.compressed_record.sha256) { throw 'Preserved record mismatch' }
if ((Get-FileHash -LiteralPath "$out\stopped-05\chunks.dat" -Algorithm SHA256).Hash.ToLowerInvariant() -cne $capture.forced.sha256) { throw 'Preserved metadata mismatch' }
$portRows = @(Get-Content -LiteralPath "$target\server.properties" | Select-String -Pattern '^server-port=([0-9]{1,5})$')
if ($portRows.Count -ne 1) { throw 'Unexpected port configuration' }
$port = [int]$portRows[0].Matches[0].Groups[1].Value
$listeners = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
if ($listeners.Count -ne 0) { throw 'Owned runtime port still in use; no processes terminated' }
$files = @($entries | Where-Object { -not $_.PSIsContainer })
$bytes = ($files | Measure-Object -Property Length -Sum).Sum
$receipt = "$out\CLEANUP05-PRECHECK-01.json"
if (Test-Path -LiteralPath $receipt) { throw 'Immutable receipt already exists' }
@{ target=$target; literal_parent=$parent; regular_files=$files.Count; bytes=$bytes;
    reparse_entries=0; clean_host_exits=2; port=$port; listener_count=0;
    preserved_fixed_record=$capture.compressed_record; preserved_forced_metadata=$capture.forced;
    original_world_or_sealed_evidence_in_target=$false; cleanup_executed=$false
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $receipt -Encoding utf8NoBOM
Write-Output "PRECHECK OK: $($files.Count) files / $bytes bytes; literal $target; port $port unused"
