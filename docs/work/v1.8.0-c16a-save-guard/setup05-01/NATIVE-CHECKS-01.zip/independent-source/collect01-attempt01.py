from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/ags5-0a8c27de64')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = '73fc017ac3b121b34216e660e66b0cb583ff289a'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(HERE)

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def put(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)

def git(path):
    result = subprocess.run(['git', 'show', f'{BASE}:{path}'], cwd=ROOT, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace'))
    return result.stdout

def safe(name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or ':' in name or '\\' in name:
        raise ValueError(name)
    path = (AUTHOR / name).resolve()
    if not path.is_relative_to(AUTHOR.resolve()):
        raise ValueError(name)
    return path

manifest_raw = (AUTHOR / 'INTERNAL-MANIFEST.json').read_bytes()
assert digest(manifest_raw)['sha256'] == 'bd889e5f8ead228db99cc881c9206975b5237d584c88c89ce388a95f154fe660'
manifest = json.loads(manifest_raw)
checks = []
for name, expected in manifest['files'].items():
    actual = digest(safe(name).read_bytes())
    assert actual == expected, (name, actual, expected)
    checks.append({'path': str(safe(name)), **actual})
assert len(checks) == 70

selected = ['SOURCE-MANIFEST-02.json', 'SOURCE-02.patch', 'REPORT-01.md',
            'green-04-command.json', 'green-04-result.json', 'STATIC-02.json',
            'TOOL-HISTORY-01.md']
for name in selected:
    path = safe(name)
    if path.exists():
        put('author/' + name, path.read_bytes())
source_manifest = json.loads((AUTHOR / 'SOURCE-MANIFEST-02.json').read_bytes())
own_paths = [row['path'] for row in source_manifest['files']]
for row in source_manifest['files']:
    raw = safe('postimages/' + row['path']).read_bytes()
    assert digest(raw) == {k: row[k] for k in ('bytes', 'sha256')}
    put('candidate/' + row['path'], raw)
    if row['path'].startswith(('scripts/', 'tests/')):
        pre = git(row['path'])
        assert pre == safe('before/' + row['path']).read_bytes()
        put('before/' + row['path'], pre)

modules = ['scripts.run_v180_guard_lifecycle_smoke', 'tests.test_run_v180_guard_lifecycle_smoke',
           'tests.test_run_v180_tank_smoke', 'tests.test_run_v180_pump_smoke',
           'tests.test_run_v180_signature_smoke', 'scripts', 'tests']
visited = {}
while modules:
    name = modules.pop(0)
    if name in visited or not name.startswith(('scripts', 'tests')):
        continue
    package = name in ('scripts', 'tests')
    path = name.replace('.', '/') + ('/__init__.py' if package else '.py')
    raw = (HERE / 'candidate' / path).read_bytes() if path in own_paths else git(path)
    visited[name] = {'path': path, **digest(raw)}
    if path not in own_paths:
        put('candidate/' + path, raw)
    tree = ast.parse(raw.decode('utf-8-sig'))
    parent = name if package else name.rsplit('.', 1)[0]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.extend(alias.name for alias in node.names if alias.name.startswith(('scripts.', 'tests.')))
        elif isinstance(node, ast.ImportFrom):
            prefix = (parent + '.' + (node.module or '')).rstrip('.') if node.level else (node.module or '')
            if prefix in ('scripts', 'tests'):
                modules.extend(prefix + '.' + alias.name for alias in node.names if alias.name != '*')
            elif prefix.startswith(('scripts.', 'tests.')):
                modules.append(prefix)

governance = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
              'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
              'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
              'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
              'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
              'docs/work/v1.8.0-c16a-save-guard/COPIED-FORCED-SETUP-TASK-05.md']
fixed = []
for path in governance:
    raw = git(path)
    fixed.append({'object': BASE + ':' + path, **digest(raw)})
    if path.endswith('COPIED-FORCED-SETUP-TASK-05.md'):
        put('inputs/COPIED-FORCED-SETUP-TASK-05.md', raw)
live_agents = (ROOT / 'AGENTS.md').read_bytes()
prior = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/agfs-da887ecdc4')
for name in ['PROPOSAL-01.md', 'INSPECTION-01.json', 'LANGUAGE-CONSOLE-02.json', 'INTERNAL-MANIFEST.json']:
    raw = (prior / name).read_bytes()
    checks.append({'path': str(prior / name), **digest(raw)})
    put('inputs/prior-' + name, raw)
raw = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03/server/world/data/chunks.dat').read_bytes()
assert digest(raw) == {'bytes': 79, 'sha256': 'c9b7030c645d2995ac9be13d08964eb98f1942b2170c34b3f893100daa6acc50'}
put('inputs/original-chunks.dat', raw)
put('INPUTS-01.json', json.dumps({'base': BASE, 'author_manifest': digest(manifest_raw),
     'author_checks': checks, 'source_manifest': source_manifest, 'candidate_python_closure': visited,
     'fixed_inputs': fixed, 'live_AGENTS': digest(live_agents)}, indent=2).encode() + b'\n')
print(json.dumps({'author_files': 70, 'author_payload_bytes': sum(row['bytes'] for row in checks[:70]),
                  'python_modules': len(visited), 'own_postimages': own_paths, 'errors': 0}, indent=2))
