from pathlib import Path
import hashlib
import json
import os
import subprocess

here = Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(here)
inputs = json.loads((here/'INPUTS-01.json').read_bytes())
checks = []
def check(path, spec):
    raw = path.read_bytes()
    actual = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    assert actual == {k:spec[k] for k in ('bytes','sha256')}, (path,actual,spec)
    checks.append({'path':str(path),**actual})
for spec in inputs['author_checks']:
    check(Path(spec['path']),spec)
author = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/ags5-0a8c27de64')
check(author/'INTERNAL-MANIFEST.json',inputs['author_manifest'])
for spec in inputs['candidate_python_closure'].values():
    check(here/'candidate'/spec['path'],spec)
for path,spec in inputs['source_manifest'].items():
    check(here/'candidate'/path,spec)
    check(Path('D:/GitHub/arce-v180-guard-forced-setup-20261004')/path,spec)
context = json.loads((here/'CONTEXT-02.json').read_bytes())
check(here/'candidate'/context['object'].split(':',1)[1],context)
check(Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03/server/world/data/chunks.dat'),
      {'bytes':79,'sha256':'c9b7030c645d2995ac9be13d08964eb98f1942b2170c34b3f893100daa6acc50'})
primary = json.loads((here/'PRIMARY-03.json').read_bytes())
check(Path(primary['jar']['path']),primary['jar'])
check(Path(primary['language']['jar']),{'bytes':5229189,'sha256':'16c690f52a92ef272f3e3a5a841cbb24dadff19da5a895885b9520c5a108be38'})
command = ['git','-C','D:/GitHub/arce-v180-guard-forced-setup-20261004','diff','--cached','--name-only']
result = subprocess.run(command,capture_output=True)
assert result.returncode == 0 and result.stdout == b'', result
out = {'exact_named_checks':checks,'checks':len(checks),'drift':0,
       'author_index_read':{'command':command,'exit':result.returncode,'stdout':result.stdout.decode()},
       'source_base':inputs['base'],'native_java_launches':0,
       'no_repository_author_world_or_sealed_evidence_writes':True}
(here/'POSTCHECK-07.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'drift':0,'author_cached_diff_empty':True,'native_java_launches':0},indent=2))
