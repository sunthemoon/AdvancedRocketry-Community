from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess

here = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(here)
guard = 'scripts/run_v180_guard_lifecycle_smoke.py'
test = 'tests/test_run_v180_guard_lifecycle_smoke.py'
source = json.loads((here / 'author/SOURCE-MANIFEST-02.json').read_bytes())
trees = [ast.parse((here / side / guard).read_text(encoding='utf-8')) for side in ('before', 'candidate')]
functions = [{node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)} for tree in trees]
same = [name for name, node in functions[0].items() if ast.dump(node) == ast.dump(functions[1][name])]
assert same == ['marker', 'say_barrier', 'wait_chunk', 'wait_unload_begin', 'chunk_state_observations', 'check_fixture', 'saved_record', 'check_record', 'audit_refusal']
test_trees = [ast.parse((here / side / test).read_text(encoding='utf-8')) for side in ('before', 'candidate')]
methods = [{cls.name + '.' + method.name: method for cls in tree.body if isinstance(cls, ast.ClassDef)
            for method in cls.body if isinstance(method, ast.FunctionDef) and method.name.startswith('test_')}
           for tree in test_trees]
assert set(methods[0]) <= set(methods[1])
assertions = 0
changed = []
for name, original in methods[0].items():
    original_assertions = [ast.dump(n) for n in ast.walk(original) if isinstance(n, ast.Call)
                           and isinstance(n.func, ast.Attribute) and n.func.attr.startswith('assert')]
    current_assertions = [ast.dump(n) for n in ast.walk(methods[1][name]) if isinstance(n, ast.Call)
                          and isinstance(n.func, ast.Attribute) and n.func.attr.startswith('assert')]
    assert all(n in current_assertions for n in original_assertions), name
    assertions += len(original_assertions)
    if ast.dump(original) != ast.dump(methods[1][name]):
        changed.append(name)
assert assertions == 55 and len(methods[0]) == 30 and len(methods[1]) == 47
replay = here / 'patch-replay'
replay.mkdir()
for path in (guard, test):
    target = replay / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((here / 'before' / path).read_bytes())
commands = []
for args in (['--check', '--whitespace=error'], ['--whitespace=error']):
    command = ['git', '-c', 'core.autocrlf=false', 'apply', *args, str(here / 'author/SOURCE-02.patch')]
    result = subprocess.run(command, cwd=replay, capture_output=True)
    commands.append({'command': command, 'cwd': str(replay), 'exit': result.returncode,
                     'stdout': result.stdout.decode('utf-8', errors='replace'), 'stderr': result.stderr.decode('utf-8', errors='replace')})
    assert result.returncode == 0, commands[-1]
actual_paths = {str(path.relative_to(replay)).replace('\\', '/') for path in replay.rglob('*') if path.is_file()}
assert actual_paths == set(source)
for path, spec in source.items():
    raw = (replay / path).read_bytes()
    assert raw == (here / 'candidate' / path).read_bytes()
    assert len(raw) == spec['bytes'] and hashlib.sha256(raw).hexdigest() == spec['sha256']
out = {'unchanged_original_helpers': same, 'original_test_methods': 30, 'original_assertions': assertions,
       'changed_original_test_methods': changed, 'new_test_methods': sorted(set(methods[1]) - set(methods[0])),
       'patch_commands': commands, 'exact_replay_postimages': source, 'only_four_replay_files': True,
       'new_java_native_or_policy_files': 0}
(here / 'STATIC-04.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps(out, indent=2))
