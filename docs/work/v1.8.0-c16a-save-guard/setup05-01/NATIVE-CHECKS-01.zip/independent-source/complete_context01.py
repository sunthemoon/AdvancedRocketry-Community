from pathlib import Path
import hashlib
import json
import os
import subprocess

here = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(here)
path = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/electrolyzer/ElectrolyzerBlockEntity.java'
base = '73fc017ac3b121b34216e660e66b0cb583ff289a'
command = ['git', 'show', base + ':' + path]
result = subprocess.run(command, cwd='D:/GitHub/AdvancedRocketry-Community', capture_output=True)
assert result.returncode == 0, result.stderr
target = here / 'candidate' / path
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(result.stdout)
record = {'command': command, 'exit': result.returncode, 'object': base + ':' + path,
          'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest(),
          'reason': 'Unchanged signature Python test reads this one named Java source; initial closure omission preserved.'}
(here / 'CONTEXT-02.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
