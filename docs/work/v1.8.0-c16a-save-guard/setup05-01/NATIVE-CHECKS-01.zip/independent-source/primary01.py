from pathlib import Path
import ast
import hashlib
import json
import os
import struct
import zipfile

here = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(here)
reader = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
tree = ast.parse(reader.read_text(encoding='utf-8'))
definitions = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in ('R', 'parse')]
scope = {'struct': struct}
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(reader), 'exec'), scope)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = hashlib.sha256(jar.read_bytes()).hexdigest()
assert sha == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
selected = {
    'net/minecraft/server/commands/ForceLoadCommand.class': {'queryForceLoad', 'changeForceLoad', 'lambda$changeForceLoad$18', 'lambda$changeForceLoad$19', 'lambda$queryForceLoad$15'},
    'net/minecraft/server/level/ServerLevel.class': {'setChunkForced', 'setDefaultSpawnPos'},
    'net/minecraft/server/level/ServerChunkCache.class': {'updateChunkForced'},
    'net/minecraft/server/level/DistanceManager.class': {'updateChunkForced'},
    'net/minecraft/server/MinecraftServer.class': {'sendSystemMessage'},
    'net/minecraft/world/level/ChunkPos.class': {'toString'},
}
out = {'reader': {'path': str(reader), 'sha256': hashlib.sha256(reader.read_bytes()).hexdigest()},
       'jar': {'path': str(jar), 'bytes': jar.stat().st_size, 'sha256': sha}, 'classes': {},
       'java_launches': 0}
with zipfile.ZipFile(jar) as z:
    for name, methods in selected.items():
        raw = z.read(name)
        parsed = scope['parse'](raw, methods)
        out['classes'][name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'methods': {key: {'exceptions': spec['exceptions'], 'instructions': [i for i in spec['instructions'] if i['reference'] is not None or i['branch_target'] is not None]}
                        for key, spec in parsed['selected_methods'].items()}}
extra = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03/server/libraries/net/minecraft/server/1.20.1-20230612.114412/server-1.20.1-20230612.114412-extra.jar')
assert hashlib.sha256(extra.read_bytes()).hexdigest() == '16c690f52a92ef272f3e3a5a841cbb24dadff19da5a895885b9520c5a108be38'
with zipfile.ZipFile(extra) as z:
    raw = z.read('assets/minecraft/lang/en_us.json')
    lang = json.loads(raw)
keys = ['commands.forceload.removed.single', 'commands.forceload.removed.failure',
        'commands.forceload.query.success', 'commands.forceload.query.failure',
        'commands.setworldspawn.success']
out['language'] = {'jar': str(extra), 'member': 'assets/minecraft/lang/en_us.json',
                   'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                   'selected': {key: lang[key] for key in keys}}
assert out['language']['sha256'] == '71be3181221b2d95a8cfe3a2fcf01fec085e4478935929e489c72aec79ea499e'
(here / 'PRIMARY-03.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'named_primary_classes': len(out['classes']), 'language': out['language'], 'java_launches': 0}, indent=2))
