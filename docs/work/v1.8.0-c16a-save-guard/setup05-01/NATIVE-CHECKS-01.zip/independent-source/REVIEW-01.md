# SETUP05 independent actual-source review

Date: 2026-10-04. Reviewer: delegated worker `/root/c17_contract`, not SETUP05 author.
Scope: two Python postimages and two task records; no Java, production guard,
runtime execution, source integration, risk acceptance or version Gate review.

## Findings and disposition

**0 Critical / 0 High / 0 Medium / 0 Low source findings in this reviewed delta.**
No candidate repair is requested. The exact four postimages are technically
eligible for Root's scoped source integration and commit, subject to its own
integration checks. This is not native admission or evidence of unload success.
Native attempts 01–04 remain failed; the reported Source25 build/GameTest cohort
was not run or borrowed as SETUP05 native proof by this reviewer.

The setup removes only three fixed saved force marks on a disposable copy,
preserves target and far membership, and retains the original real event,
live restoration, compressed terrain and restart refusal oracles. Queries and
metadata alone do not establish a live ticket map, final holder disposal or a
unique cause for the historical timeouts.

## Exact reviewed identity

Fixed source object: `73fc017ac3b121b34216e660e66b0cb583ff289a`.
Moving Root HEAD was not used for the Python baseline or source verdict.
The author development worktree is
`D:/GitHub/arce-v180-guard-forced-setup-20261004`; it is read-only in this review.

Author loose evidence: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/ags5-0a8c27de64`.
All 70 manifested payloads, totalling 854,237 bytes, were independently read and
verified. [Input ledger](INPUTS-01.json) binds that verification, the fixed Git
objects and selected Python dependency closure. Its manifest SHA-256 is
`bd889e5f8ead228db99cc881c9206975b5237d584c88c89ce388a95f154fe660`.
The copied [author report](author/REPORT-01.md) is
`540e4a273e2a6153bdb3b512f4afd5e39c3a0a24387db53a9dd93e01b2a68b5d`;
author observations are not independent runtime evidence.

| Reviewed postimage | Bytes | SHA-256 |
|---|---:|---|
| [Harness](candidate/scripts/run_v180_guard_lifecycle_smoke.py) | 23,600 | `7eea858bc9808e035252f79ae56970bea996ddde80b3a1c4e3128cbff5fcb77a` |
| [Python tests](candidate/tests/test_run_v180_guard_lifecycle_smoke.py) | 35,993 | `27fd2c7d11f3d1e664d833f59a849a2ae48bb27c17133611bf4b4c5e0955082f` |
| [Own progress](candidate/docs/work/v1.8.0-c16a-save-guard/SETUP05-PROGRESS.md) | 4,521 | `7650680506cf28fa87c0a2564066360767ac755575d9d171aa05806ee5d2598f` |
| [Own handoff](candidate/docs/work/v1.8.0-c16a-save-guard/SETUP05-HANDOFF.md) | 7,293 | `fd14021676e6f44d6b2bf4021890d84eb0a84ff31e4a8a54db3214f621f44d21` |

[SOURCE-MANIFEST-02](author/SOURCE-MANIFEST-02.json):
`0eb46246ae920c4555796bbd9db6e9b5d619fdec54af7e7faec8466baabbe33c`.
[SOURCE-02.patch](author/SOURCE-02.patch): 45,052 bytes,
`b9500721eb7a68968cb193896e8a0de1d4206f08754a30a5e793e3c852b8ed08`.
Both Python preimages equal the exact fixed Git objects, not normalized copies.
Patch check and apply with `core.autocrlf=false` and `--whitespace=error`
both returned 0 in an initially two-file fresh reviewer directory. All four
postimages agree byte-for-byte and no fifth file was created. See
[independent patch/AST receipt](STATIC-04.json).

The controlling [copied-force task](inputs/COPIED-FORCED-SETUP-TASK-05.md)
and prior [preparation proposal](inputs/prior-PROPOSAL-01.md) were inspected;
the latter retains SHA-256
`8fccb73bee20f60e5a118639b50701029c355c9e93a3b4eb8022abd080d0d134`.
The preparation was authored by this reviewer, but the implementation under
review was independently authored by `/root/c16a04_fluids`.

## Source and primary observations

### Bounded saved metadata and phase identity

Harness lines 211–259 require a boolean phase and bounded immutable bytes.
Compressed and expanded caps are each 4,096 bytes. Gzip must end without trailing
or concatenated members; malformed/truncated/CRC-corrupt input refuses. The
existing NbtReader still enforces depth 16, 4,096 tags/collection entries and
duplicate-key rejection. The new subclass keeps native type IDs rather than
accepting a numerically equal List or wide scalar as the LongArray/Int fields.
The accepted shape is exactly four native tags, an empty-name compound root,
`data/Forced` TAG_Long_Array and `DataVersion` TAG_Int 3465; no extra fields.

Initial metadata requires the exact 79-byte input pin
`c9b7030c645d2995ac9be13d08964eb98f1942b2170c34b3f893100daa6acc50`
and exact unique five marks `(11,11), (16,16), (16,-2), (24,24), (32,32)`.
The reviewer independently unpacked signed long coordinates from its 83 expanded
bytes; z=-2 was not normalized. Equal logical membership in a different gzip
record is rejected for the bootstrap input.

After successful first clean stop, before the second host and after its clean
stop, only `(11,11), (32,32)` is admitted. Array ordering and lossless gzip
representation may differ in these intentionally changed metadata records;
type/version/shape/uniqueness/membership may not. Harness lines 317–319 and
365–366 place captures before launch and after clean stop; main lines 404–409
check the source and its copied bootstrap metadata before launch. Bounded raw
bytes are captured before a decode refusal; oversized/unreadable files are not
silently truncated into evidence. No direct SavedData rewrite was introduced.

### Literal isolated commands and authoritative acknowledgements

Harness lines 41–58 keep three literal Overworld removal commands for block
columns `(256,256), (256,-32), (384,384)`, corresponding to only the three allowed
nearby chunk marks. Decoded coordinates never generate console commands.
Target `(176,176)` and far `(512,512)` queries occur before and after setup.
The restart branch issues no nearby removal, remove-all, range removal or re-add.

Lines 144–203 use one setup deadline of 60 seconds across before queries,
existing spawn relocation and the removal/after-query batch. No per-command
60-second reset or setup retry loop is added. Fresh acknowledgements are exact,
unique and before the corresponding fresh native say barrier. Stale matches,
wrong cell/dimension/logger/thread/severity, duplicate matches, failed INFO
feedback and success after the barrier or deadline refuse.

Independent [mapped primary facts](PRIMARY-03.json) and
[formatting/dispatch supplement](PRIMARY-07.json) bind cached Forge 47.4.10 /
Minecraft 1.20.1 declarations, without running Java or exporting class bodies:

- `ForceLoadCommand.changeForceLoad`: the false argument reaches
  `ServerLevel.setChunkForced(...,false)` at bytecode offset 213; no changed mark
  takes `ERROR_NONE_REMOVED` at 275/278. `lambda$changeForceLoad$15` selects
  `removed` at offset 10 and formats the chunk and `ResourceKey.location`.
- `ServerLevel.setChunkForced`: false branches at 44 to 76, bypassing the
  add-path `getChunk` at 69. Named LongSet removal is at 83, SavedData dirtying
  at 94 and force-ticket update at 109. `DistanceManager.updateChunkForced`
  removes FORCED and ticking tickets at 49/59; it does not prove all other
  eligibility sources absent or guarantee unload.
- `queryForceLoad`: reads `getForcedChunks` at 17 and tests membership at 24;
  failure at 51 is not success. It has no getChunk/update-ticket call. This is
  a non-loading saved-mark query, not a complete live ticket observer.
- `ServerLevel.setDefaultSpawnPos` retains the original remove-START/add-START
  sequence at 58/81. This setup preserves the already-reviewed fixed copied
  spawn relocation rather than editing its policy or adding a guessed sleep.
- `CommandSourceStack.sendFailure` and `MinecraftServer.sendSystemMessage`
  can produce INFO text for failure. INFO severity by itself is not authority
  for success. The exact native English resource distinguishes removed.single,
  removed.failure, query.success and query.failure. The reviewed regexes match
  those exact templates and reject echoes/foreign framing.

Primary mapped JAR SHA-256:
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Named native extra JAR SHA-256:
`16c690f52a92ef272f3e3a5a841cbb24dadff19da5a895885b9520c5a108be38`.
Selected language resource SHA-256:
`71be3181221b2d95a8cfe3a2fcf01fec085e4478935929e489c72aec79ea499e`.
The reviewed phase fixtures assume this pinned English console and original
fixed metadata, not arbitrary worlds/locales.

### Existing native oracles are preserved

Nine original functions are AST-identical: marker, say_barrier, wait_chunk,
wait_unload_begin, chunk_state_observations, check_fixture, saved_record,
check_record and audit_refusal. [Structural comparison](STRUCTURE-06.json)
also establishes exact original native_cycle/main ASTs after removing only the
declared additive metadata receipt/checks and the setup wrapper replacement.
The nested send/assert_block/save functions and original runtime body are
unchanged. In particular, the independent 60-second/240-probe unload deadline,
real fixed Unload marker, both live rollback checks, explicit paired refusal
headers, clean stop, byte-equal compressed terrain, four root checks, second
same-world host and original input postchecks remain.

The compressed-terrain equality preserves original native widths/bytes; the
value-only semantic fixture decoder alone is not a universal typed-NBT proof.
The new two-host unit test is explicitly mocked. Its positive receipts do not
represent launched hosts, a real chunk event, real restoration or durable bytes.
The handoff correctly keeps these and R-021/G0–G9 open.

## Independently executed checks

All processes used process-local TEMP/TMP/TMPDIR in this reviewer D leaf and
`python -B`. No Java/Gradle/GameTest/native/client/process-control/network task
was executed. No repository, author source, original world or old evidence was
written. Only fresh reviewer copies and reports were written.

| Command / control | Actual result |
|---|---|
| `python -B collect01.py` final | 70 author payloads / 854,237 bytes verified; 30 named Python dependency modules copied from fixed objects; exit 0 |
| `python -B complete_context01.py` | One unchanged named Electrolyzer Java source copied for an existing Python source-inspection assertion; exit 0 |
| `python -B run_focused01.py focused-02` | **137 tests, 0 failures/errors/skips**, unittest 2.063 s, wrapper 2.451735 s; exit 0 |
| `python -B primary01.py` and `primary_supplement02.py` | Selected primary methods and English keys inspected; both exit 0, no Java |
| `python -B static01.py` | Exact patch check/apply 0; four exact postimages; nine unchanged helpers; 30 original methods / 55 assertions retained and 17 new methods; exit 0 |
| `python -B source_structure02.py` | Existing native/main runtime body preserved as described above; exit 0 |
| `python -B reviewer_controls01.py` final | **15 independent methods, 0 failures/errors/skips**, 0.019 s; exit 0 |
| `python -B postcheck01.py` | **117 named checks, 0 drift**, author index read empty; exit 0 |

Raw focused evidence: [command](focused-02-command.json), [result](focused-02-result.json),
[log](focused-02.log). Log SHA-256:
`13c3ef797b8072aa1c7604fb2cd0dc7a39adb306ca80acd16d132c156c335a9e`.
Independent [control source](reviewer_controls01.py) and [final log](controls-05-final.log)
cover phase membership/native widths, original pin, signed coordinates, native
array order/gzip variations, bounded predecode refusal, CRC/trailing cases,
capture-before-refusal, each literal removal's fresh acknowledgement,
primary-derived failure INFO text, shared deadline/late wake, post-barrier
acknowledgement rejection and absence of repeated restart removals.

The original 30 test methods were not deleted. Two existing spawn mocks changed
to accept/check the remaining timeout and emit their real barrier; all 55
existing assertion ASTs are retained. No production assertion or timeout was
weakened by this reviewer or the reviewed delta.

### Failed reviewer commands retained, not relabelled as pass

- Three collector attempts failed because the reviewer initially assumed two
  nonexistent JSON wrapper keys and a nonexistent `scripts/__init__.py` in the
  fixed namespace-package baseline. Separate original helpers/logs/exits remain.
- [First focused run](focused-01.log): 137 tests / one error, exit 1, because
  the review copy omitted the named Java source read by an unchanged signature
  test. [Context receipt](CONTEXT-02.json) binds the fixed source subsequently
  supplied. No test/source repair was made for the final run.
- [First independent controls](controls-05.log): 15 methods / 48 subtest errors,
  exit 1. The reviewer over-specified `SmokeError`; the existing shared
  `require` raises its documented parent `RuntimeError`. Original probe source
  and log remain. The final probe uses that actual public refusal type, while
  preserving every refusal/input/assertion and all candidate bytes.
- One exploratory `rg` Windows filename-glob command returned a filename-syntax
  error in the tool transcript. It did not modify or validate source.

Author red/mock/first-patch failures remain immutable in its verified original
70-payload evidence. They are not presented as independent reruns or removed
from history. [Final named postcheck](POSTCHECK-07.json) records the exact source,
author records/manifest, primary artifacts and tiny original metadata after
all executable controls.

## Remaining work and limits

Root must commit the independently reviewed exact source before actual native
execution and bind a separately verified current diagnostic JAR/runtime/library
cohort. No native execution was performed here, and no guarantee is made that
removing the saved nearby marks suffices for a real event/restoration. Other
tickets, queued holder transitions and callback completion remain runtime
questions. A fresh failed unload/restoration/byte check must remain FAIL.

The smallest next current-v1.8 check is the unchanged strict two-cycle copied
runtime diagnostic, after source publication and Root's scheduling/input checks.
Actual first-clean-stop and restart two-mark metadata, Unload event, both live
rollbacks, paired save refusal and exact terrain/resource bytes remain required.
First-save writer behavior, arbitrary crash recovery, cross-store conservation,
actual BE-disposal instrumentation, player repair, unsafe-native passthrough,
real clients/peers/GPU and whole-version Required Gates are not closed.

The reviewer created only this small D external review leaf. There were no C
outputs, source-world copies, official class/JAR exports, large archives or
cleanup actions. Temporary named dependency exports and patch-replay copies are
not delivery evidence; their immutable object/hash ledger is sufficient for
Root-coordinated later cleanup. The final manifest contains only selected
postimages, before-images, helpers, raw logs, results, derived primary facts and
report companions, not the whole source tree or those disposable exports.
