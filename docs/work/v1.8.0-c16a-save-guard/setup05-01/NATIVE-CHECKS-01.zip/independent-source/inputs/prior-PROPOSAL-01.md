# Fixed copied-fixture vanilla force-mark setup proposal

Status: **PROPOSED**, diagnostic fixture only. Date: 2026-10-04.
Fixed source base: `a385ba452ab756b5689a1cbf21e2177129b93dc9`.
No source patch was applied, native command executed, fixture modified or
save/repair policy selected by this investigator.

## Findings and scope

No new production defect is established by this preparation. The previously
frozen native03 **Medium fixture-eligibility finding remains unclosed** by
source arithmetic or this proposal alone. The three named standard force marks
are supported eligibility candidates, not a demonstrated unique cause or a
guarantee that removing them makes the lifecycle test pass.

Two source-backed constraints must hold in any later implementation:

1. A successful `forceload` removal and a failed removal/query both reach the
   dedicated server's **INFO** logger. Severity, command submission, a generic
   say barrier, or any string containing `Unmarked` is not sufficient proof.
   Require the one fresh exact native acknowledgement for each fixed removal.
2. The bootstrap and clean-restart forced metadata are intentionally different.
   Apply the three removals only to the initial disposable-copy setup; do not
   repeat them in the restart-retrigger phase or demand the original five-entry
   hash there. The original `native_cycle` re-adds the target before clean stop.

Root reported a fresh native04 server-thread observation of `no_save=false`,
holder level36 with full retained statuses but INACCESSIBLE; Root subsequently
reported terminal FAIL with the unchanged unload-marker timeout. Neither the
native04 raw receipt nor that mutable runtime was read for this proposal.
These are **Root-reported context**, not this investigator's independently
audited native result. Root must retain/pin terminal diagnostics before choosing
this setup. All earlier failures remain failures.

## Exact named inputs and primary authority

[Named input checks and fresh method facts](INSPECTION-01.json) bind:

| Input | Bytes | SHA-256 |
|---|---:|---|
| Fixed `scripts/run_v180_guard_lifecycle_smoke.py` | 15,723 | `d5604531386944efdbccaf65c4281343d2d993d2e7af24eee7409997465e1bf0` |
| Fixed `tests/test_run_v180_guard_lifecycle_smoke.py` | 17,253 | `4a26dfc47a5b22552061835f44c2b8c2627802716e8a790e138688c32dd0f01c` |
| Named native03 `world/data/chunks.dat` | 79 | `c9b7030c645d2995ac9be13d08964eb98f1942b2170c34b3f893100daa6acc50` |
| Mapped Minecraft1.20.1 / Forge47.4.10 primary JAR | 19,355,242 | `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e` |
| Named native03 Minecraft server-extra JAR | 5,229,189 | `16c690f52a92ef272f3e3a5a841cbb24dadff19da5a895885b9520c5a108be38` |
| Its exact `assets/minecraft/lang/en_us.json` member | 386,499 | `71be3181221b2d95a8cfe3a2fcf01fec085e4478935929e489c72aec79ea499e` |

The mapped primary is the exact known Gradle cache artifact, not a newly
downloaded source. The extra JAR is the individually named historical native03
library, not a library/world directory inventory. [Language/console facts](LANGUAGE-CONSOLE-02.json)
record those locators and hashes. The mapped and SRG class JARs do not contain
that language member; its actual resource was read from the named extra JAR.
No official art or entire class/source body was copied into this proposal.

Mandatory governance/version docs were read by fixed Git objects and current
AGENTS independently pinned. Current AGENTS is distinguished from the older
Git object, not normalized into it. Named harness/tests were live-byte-equal
to the fixed objects. The earlier report
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/agu3-2f14cb053a/REVIEW-01.md`
SHA `ccedccbafd8521c82a2bfc0980bc7229b8097fcc68d8b878b057c3e1bf7effd3`
and its selected Forced/constant facts were individually checked against its
sealed manifest. All old evidence is unchanged; no old ZIP was copied/read.

## Fresh primary semantics

- `ForceLoadCommand.register` admits `forceload remove <from>` as a single
  ColumnPos cut; `changeForceLoad` converts block columns with
  `SectionPos.blockToSectionCoord` at offsets 93/100/107/114. With from=to,
  each named command affects exactly one chunk, not a rectangular neighbor set.
  The normal command permission requirement is level2; the dedicated-console
  fixture is already OP-authorized. No client/RCON/generic command authority
  is being introduced.
- `changeForceLoad` uses the selected source Level's identity (166/173), calls
  `ServerLevel.setChunkForced(x,z,false)` (213), counts only changed marks,
  throws `ERROR_NONE_REMOVED` when no mark changed (275/278), and emits the
  single-chunk removed key for one changed mark (294/300). Its lambda chooses
  `removed` at offset10 and formats chunk plus `ResourceKey.location`.
- `ServerLevel.setChunkForced`: false at parameter3 branches 44 -> 76 to the
  named LongSet removal. The true/add path's `getChunk` at69 is skipped on
  removal. It marks the Forced SavedData dirty and calls
  `ServerChunkCache.updateChunkForced`; that delegates to
  `DistanceManager.updateChunkForced`, which removes the exact FORCED ticket
  at49 and its ticking-tracker counterpart at59. The operation changes
  vanilla force-mark/ticket state, not blocks, retained tank resources,
  production protection policy or saved target terrain.
- `queryForceLoad` reads `getForcedChunks` (17), compares the one packed
  position (24), and selects success or `ERROR_NOT_TICKING` (51). No chunk
  loader/getChunk/update-ticket call appears in that named method. This query
  proves the vanilla saved mark's membership, **not** a complete live/mod ticket
  map, holder drop, actual unload callback, completed cleanup or durability.
- `CommandSourceStack.sendFailure` forwards the red-styled Component to its
  CommandSource (36). `MinecraftServer.sendSystemMessage` takes `getString`
  (4) and logs INFO (9), just as successful console feedback. A missing mark
  is a command failure even when its English text has INFO framing.

The actual packed record expands to 83 B and holds exactly five unique
TAG_Long_Array entries: `(16,16)`, `(32,32)`, `(11,11)`, `(16,-2)`, `(24,24)`.
Fresh decode preserved signed z=-2; no coordinate normalization was used.
Earlier frozen constants establish FORCED31/MAX_LEVEL45, with Chebyshev
contributions36,52,31,44,44 respectively. Removing the three non-target entries
addresses those standard recorded candidates; the distant `(32,32)` entry must
remain. Nothing here proves all other ticket identities absent.

## Minimal proposed setup sequence

Choose this sequence only after Root preserves the new diagnostic cohort and
elects a separate source amendment. All commands run on the **fresh disposable
copy**, using the fixed Overworld context. The original source-world/library/JAR
pre/postchecks remain unchanged and mandatory.

### A. Initial copied-runtime phase

Before launch, inspect the copied **named tiny** `world/data/chunks.dat`, not
an arbitrary SavedData file or global ticket map. Require its exact source hash,
bounded gzip/NBT shape/types and the five unique entries above. Unknown/missing/
duplicate/extra marks must fail preflight and preserve evidence; do not repair,
overwrite or automatically add a missing mark.

After the existing target `forceload add 176 176` and actual LOADED barrier,
retain the existing confirmed copied-world spawn relocation. Hold that target
mark while removing the three neighbors. Before any guarded marker mutation,
submit **only** these three fixed removal commands:

```text
execute in minecraft:overworld run forceload remove 256 256
execute in minecraft:overworld run forceload remove 256 -32
execute in minecraft:overworld run forceload remove 384 384
```

Then the smallest positive membership postcheck is:

```text
execute in minecraft:overworld run forceload query 176 176
execute in minecraft:overworld run forceload query 512 512
```

One fresh uniquely labeled console say barrier closes this fixed five-command
batch. Every removal must produce exactly one fresh correct single-chunk
success, and both membership queries must produce exactly one fresh positive
target/distant-mark line. Use one bounded setup deadline no greater than the
existing60-second setup barrier budget; do not grant per-query repeated60s
waits or add a retry loop. This setup deadline is separate from, and cannot
extend/reset, the original60-second/240-probe unload deadline. If integrating
the setup into the existing spawn setup boundary, propagate one shared
remaining-time deadline across that boundary rather than increasing it.

No extra absence query is necessary for the minimum mutation proof: each exact
successful removal acknowledges one changed saved mark. Optional five-point
prequeries or removed-point absence queries are diagnostic extensions requiring
explicit fixed controls; they must not accept a generic exception as success.
Never use `forceload remove all`, `add` for the removed candidates, a multi-cell
range, relative coordinates, an arbitrary dimension, direct ticket/NBT edits,
world rewrites or a guessed sleep.

Keep the existing strict sequence thereafter:

1. original tank/AIR and marker mutation assertions;
2. original initial explicit save and sticky refusal observations;
3. live culprit removal, second explicit save and sticky refusal;
4. fresh event-start index, target force removal, original predicate/state
   diagnostic/real Unload event wait with the same60-second deadline;
5. original target reacquisition and both live old-snapshot restoration checks;
6. actual clean stop, exact original compressed terrain-record equality and
   the original four resource/root checks.

No command acknowledgement or metadata set replaces steps4-6. If no event or
restoration occurs, the fresh attempt is FAIL and remains preserved.

### B. First clean stop and restart-retrigger

The existing `native_cycle` at lines 212-223 re-adds target after the unload
event; it does not remove that mark before stopping. Therefore the stopped
copy should contain only **`(11,11)` and `(32,32)`** after the permitted setup
cut. Capture and bound-decode the named Forced metadata to prove that allowed
delta independently; require LongArray type, uniqueness, count2 and unchanged
unrelated fields/DataVersion. Gzip byte identity is not expected for this
deliberately changed SavedData; record its new hash instead. This must not
relax the separate exact compressed chunk11,11 terrain-byte oracle.

On the second same-world host, check the reduced two-mark state and retain the
existing target+far membership observations. **Do not rerun the three removals
or require their earlier successes**: absent entries should natively fail
removal, not be re-added or normalized. The original target add may already be
a no-change request because its mark is saved; query membership/actual LOADED
is the correct holding check. Keep the original independent new-Level restart
refusal/clean-stop/exact-record assertions. Source-world metadata remains the
original five-mark source and must hash unchanged.

## Exact console acknowledgement boundary

Primary templates and selected key facts are in [LANGUAGE-CONSOLE-02.json](LANGUAGE-CONSOLE-02.json).
For this fixed version, the expected coordinate substitution uses the native
ChunkPos display `[x, z]`, and dimension `minecraft:overworld`.

- Single removal key: `commands.forceload.removed.single`; the failure key is
  `commands.forceload.removed.failure` and must never satisfy it.
- Membership present/absent keys: `commands.forceload.query.success` and
  `commands.forceload.query.failure`. The positive query includes `Chunk at`,
  not a guessed `Chunk` wording.
- The parser should reuse the existing strict stdout shape: optional
  `[HH:MM:SS] `, then exactly `[Server thread/INFO] [minecraft/MinecraftServer]: `,
  the fixed escaped native text and whole-line ending. Wrong logger/thread/
  severity/dimension/coordinates, added/removed mixup, trailing text, command
  echo, stale lines, absent lines or duplicate successes refuse the setup.
  DEBUG log's differently rendered fully qualified logger must not silently
  broaden the authoritative stdout parser.

[Independently executed bounded controls](CONTROLS-03.json) verify exact
saved-set/packing, retention subset, commands/tokens, non-loading query and
false-removal source paths, positive/negative parser framing, fresh unique
acknowledgements, INFO ambiguity and the distinct bootstrap/restart sets.
These are parser/primary controls, not real command execution or unload proof.

## Commands, failures and unverified boundaries

Actual commands: fixed-object `git show a385...:<named file>`, bounded named
PowerShell/rg reads, and `python -B inspect01.py`, `language02.py`, `controls03.py`.
TEMP/TMP/TMPDIR were set to this new D evidence leaf for every helper process.
No Java/native/Gradle/server/client command or source/fixture/Git mutation ran.

- First `inspect01.py`: exit1; reviewer assumed the old sealed manifest's
  files collection was a list, but it is a keyed dictionary. Exact old helper,
  log and exit are retained under attempt01 names. Corrected keyed lookup,
  same named old inputs, final inspection exit0.
- `language02.py`: exit0; read the exact named native language member and
  fresh console method facts. Missing-language observations in mapped/SRG
  class artifacts were not treated as proof that English text does not exist.
- First `controls03.py`: 10 tests/1 failure/exit1. Reviewer incorrectly counted
  nine command tokens; the fixed literal commands have eight. Original helper,
  raw log/exit and result are retained. The corrected check asserts the full
  exact token vectors (not an expanded accepted command shape).
- Final controls: **10 tests/0 failures/errors/skips**, exit0; exact false-
  removal branch and parser conditions were retained/strengthened. Raw results
  remain in [controls-03-final.log](controls-03-final.log).
- Final named postchecks and portable link checks are in [FINAL-04.json](FINAL-04.json).
  No redundant archive/full-source/runtime export was created.

Unverified: full live ticket map, other mod/player/UNKNOWN/future tickets,
event eligibility/timing after setup, actual fresh event, completed BE disposal,
live restoration, disk resources after either new host, first-save/crash/repair/
client/peer/GPU and version Gates. Removed nearby chunks may unload in the copy;
that is intentional fixture ticket-state change, not a resource-repair mechanism
or assertion that unrelated-world saves remain writable under the sticky guard.
The eventual setup needs a separately reviewed Root source change and a fresh
actual native cohort. No new owner save/drop/repair policy is required or chosen
by this specific copy-only setup proposal.
