from pathlib import Path
import ast
import hashlib
import json
import os
import struct
import zipfile

here = Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(here)
reader = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
tree = ast.parse(reader.read_text(encoding='utf-8'))
scope = {'struct':struct}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))
                             and n.name in ('R','parse')],type_ignores=[]),str(reader),'exec'),scope)
jar = Path(json.loads((here/'PRIMARY-03.json').read_bytes())['jar']['path'])
out = {'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'selected':{}}
selected = {'net/minecraft/server/commands/ForceLoadCommand.class': {'lambda$changeForceLoad$15','lambda$queryForceLoad$10'},
            'net/minecraft/commands/CommandSourceStack.class': {'sendSuccess','sendFailure'},
            'net/minecraft/server/commands/SetWorldSpawnCommand.class': {'setSpawn'}}
with zipfile.ZipFile(jar) as z:
    for path, methods in selected.items():
        raw = z.read(path)
        parsed = scope['parse'](raw,methods)
        out['selected'][path] = {'sha256':hashlib.sha256(raw).hexdigest(),
            'methods': {name:{'references':[i for i in detail['instructions'] if i['reference'] is not None or i['branch_target'] is not None]}
                        for name,detail in parsed['selected_methods'].items()}}
(here/'PRIMARY-07.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
