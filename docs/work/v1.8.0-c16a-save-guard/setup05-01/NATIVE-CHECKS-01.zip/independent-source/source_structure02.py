from pathlib import Path
import ast
import copy
import json

here = Path(__file__).resolve().parent
trees = [ast.parse((here / side / 'scripts/run_v180_guard_lifecycle_smoke.py').read_text(encoding='utf-8'))
         for side in ('before','candidate')]
funcs = [{n.name:n for n in t.body if isinstance(n, ast.FunctionDef)} for t in trees]
native = copy.deepcopy(funcs[1]['native_cycle'])
native_try = next(n for n in native.body if isinstance(n, ast.Try))
new_cut_names = {'forced_preflight', 'forced_after_clean_stop'}
kept = []
for n in native_try.body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Subscript) and isinstance(n.targets[0].slice, ast.Constant):
        key = n.targets[0].slice.value
        if key in new_cut_names or key == 'copy_forced_setup':
            continue
        if key == 'copy_spawn_setup':
            n.value = ast.Call(func=ast.Name(id='relocate_copy_spawn',ctx=ast.Load()),
                               args=[ast.Name(id='process',ctx=ast.Load()),ast.Name(id='commands',ctx=ast.Load())],keywords=[])
    kept.append(n)
native_try.body = kept
assert ast.dump(native) == ast.dump(funcs[0]['native_cycle'])
main = copy.deepcopy(funcs[1]['main'])
kept = []
for n in main.body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'source_forced':
        continue
    if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name):
        if n.value.func.id == 'require' and any(isinstance(x, ast.Call) and isinstance(x.func, ast.Name)
                and x.func.id == 'read_forced_metadata' for x in ast.walk(n)):
            continue
        if n.value.func.id == 'write' and len(n.value.args) > 1 and isinstance(n.value.args[1], ast.Dict):
            value = n.value.args[1]
            pairs = [(k,v) for k,v in zip(value.keys,value.values) if not isinstance(k,ast.Constant) or k.value != 'source_forced_metadata']
            value.keys, value.values = [p[0] for p in pairs], [p[1] for p in pairs]
    kept.append(n)
main.body = kept
assert ast.dump(main) == ast.dump(funcs[0]['main'])
out = {'native_cycle_after_removing_only_additive_metadata_and_setup_wrapper': 'AST_IDENTICAL',
       'main_after_removing_only_additive_metadata_checks_and_input_receipt_field': 'AST_IDENTICAL',
       'preserved_nested_functions': ['send','assert_block','save'],
       'preserved_original_runtime_body': True, 'budgets_assertions_stop_restart_and_postchecks_unchanged': True}
(here / 'STRUCTURE-06.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
