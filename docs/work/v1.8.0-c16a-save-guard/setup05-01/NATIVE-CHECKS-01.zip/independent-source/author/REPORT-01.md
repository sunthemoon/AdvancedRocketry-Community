# SETUP05 development handoff

## Completed scope and status

Implemented the allocated Python-only copied-fixture setup in the registered
worktree `D:/GitHub/arce-v180-guard-forced-setup-20261004`, branch
`codex/v1.8.0-guard-forced-setup`, fixed base
`73fc017ac3b121b34216e660e66b0cb583ff289a`. This is an uncommitted development
candidate, not an independent source verdict or runtime admission. Root remains
the sole integrator. Only the two allocated Python files and two new task records
are changed; the Git index is empty.

The exact four postimages are pinned by [SOURCE-MANIFEST-02.json](SOURCE-MANIFEST-02.json).
The detailed source handoff is [SETUP05-HANDOFF.md](postimages/docs/work/v1.8.0-c16a-save-guard/SETUP05-HANDOFF.md).
The [four-file patch](SOURCE-02.patch) is 45,052 bytes, SHA-256
`b9500721eb7a68968cb193896e8a0de1d4206f08754a30a5e793e3c852b8ed08`.

## Design and preservation evidence

- Exact original 79-byte compressed Forced metadata identity and typed five-mark
  preflight are required before copying/launching. The protected target/far
  marks are checked before and after setup. Only the first copied-world cycle
  sends the three fixed literal neighbor-removal commands.
- One shared 60-second setup deadline covers positive queries, the existing
  spawn relocation and removal acknowledgements. Every acknowledgement must be
  fresh, uniquely match the authoritative native success text, and precede its
  corresponding fresh barrier. Restart never repeats neighbor removals.
- Metadata compressed/expanded bounds remain 4,096 bytes each. Native fields,
  types, DataVersion3465, four-tag shape, exact phase sets and uniqueness are
  checked. Each clean-stop and second launch require the exact retained two-mark
  set. Malformed, oversized, unknown or phase-inappropriate metadata refuses;
  bounded raw captures are preserved before decode. No decoded coordinate is
  used to construct a command.
- [STATIC-02.json](STATIC-02.json) records nine unchanged original helper ASTs,
  preserved ordered critical calls (23 native-cycle /7 main), all 30 original
  test methods and 55 original assertion calls. Seventeen new methods supply
  metadata/parser, command/framing/freshness, deadline and phase controls.
- Actual reverse patch check, forward check and forward application each exit0;
  all four replay postimages match exactly. Other named repository inputs and
  frozen external inputs remain unchanged. The original unload 60-second/240
  probes, restoration, resource/root, terrain, clean-stop and restart assertions
  are not relaxed.

## Actual commands and retained failures

All Python commands use `-B`; process-local TEMP/TMP/TMPDIR are this task's
`tmp` directory. No C-drive helper/output, global environment edit, Java,
Gradle, native process, source-world mutation, commit, push or deletion occurred.

| Receipt | Actual result |
|---|---|
| [intake log](intake.log) /[input pins](INPUTS-01.json) | exit0; fixed worktree, governance and primary inputs |
| [metadata intake](metadata-intake.log) | exit0;79 compressed /83 expanded bytes, typed original five marks |
| [red-01](red-01-result.json) /[raw](red-01.log) | exit1;14 methods,41 missing-helper subtest errors on original harness |
| [green-01](green-01-result.json) /[raw](green-01.log) | exit1;108 methods,1 original spawn-mock signature error; exploratory selectors, not final four |
| [green-02](green-02-result.json) | exit0;136 focused methods,0FES;2.560190-second wrapper |
| [green-03](green-03-result.json) | exit0;136 focused methods,0FES;2.532115-second wrapper; checkpoint before strengthened acknowledgement window |
| [green-04](green-04-result.json) /[command](green-04-command.json) /[raw](green-04.log) | exit0;137 focused methods,0FES;2.570876-second wrapper /2.185-second unittest output |
| [static-01](static-01.log) | exit1;first forward Git check lacked new-file mode markers; original patch/helper remain |
| [static-02](STATIC-02.json) /[raw](static-02.log) | exit0;explicit new-file markers, exact patch replay and source/assertion preservation |

Final focused selectors are guard lifecycle, tank, pump and signature. The
final raw log SHA-256 is
`9fcbde20cd822978322545bed750acbf820e74a64db569d54bf66c7472be4747`.
The positive two-host phase test is mocked and is not native evidence.

Exploratory absent-file lookups and one failed manual patch context are noted in
the [progress record](postimages/docs/work/v1.8.0-c16a-save-guard/SETUP05-PROGRESS.md)
and [tool-history note](TOOL-HISTORY-01.md). No raw test failure is overwritten.

## Remaining work, risks and integration boundaries

Independent actual-source review, Root integration regression, separately pinned
fresh native execution, real unload/restoration and clean-stop two-mark captures
are unrun. A successful copied setup cannot prove actual disposal, other-ticket
absence, save safety or arbitrary-crash atomicity. Native01-04 remain FAIL.
R-021, physical hatch/GuardTicket authority, client/peer/GPU and v1.8 Required
Gates remain open; this task does not satisfy them.

Root Source25/C18 activity is a different cohort and is not incorporated here.
Root may integrate only these reviewed exact postimages after its fixed cohort
permits changes. Rollback is limited to restoring the two Python files and
removing these two new task records through Root's normal scoped process; it
must not modify old failures, source fixtures, guard state or Java artifacts.

The next eligible action for this current-v1.8 leaf is independent source review.
No native outcome or acceptance is preselected.
