# Supplemental tool history

This note records transcript-only authoring observations separately from the
machine-produced command/log/result receipts. It does not create missing raw
logs, command timestamps or test execution results.

- Exploratory reads guessed absent `extract_region_chunk.py`,
  `copy_minecraft_world.py`, `v1plus_migration_support.py`,
  `test_run_dedicated_server_smoke.py` and one regression command-receipt name.
  Existing imports and the exact Root command receipt were subsequently read;
  no absent file is used as authority.
- One `apply_patch` attempt against the newly authored progress record failed
  because its expected context no longer matched. No file was changed by that
  failed attempt; a later exact-context patch succeeded.
- Static reading caught a new assertion in the wrong new-test loop before
  execution. It was relocated before running the successful checkpoint. There
  is no claimed failing test execution for that editing observation.
- First patch replay really failed: new task-record additions lacked Git's
  `new file mode 100644` headers. The original SOURCE-01.patch, helper, exit1 and
  raw log remain. SOURCE-02.patch supplies those headers; source bytes are not
  normalized. Its separate check/apply/replay results are in STATIC-02.json.

All generated helpers/output live under the owned D-drive task directory;
process-local temporary settings are recorded by the executed Python wrappers.
No C outputs, deletion, Java/native execution or Git index/HEAD update occurred.
