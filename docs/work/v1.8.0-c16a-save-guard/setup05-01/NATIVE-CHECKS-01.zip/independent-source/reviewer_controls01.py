from pathlib import Path
import ast
import gzip
import hashlib
import itertools
import json
import os
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(HERE)
sys.path.insert(0, str(HERE / 'candidate'))
from scripts import run_v180_guard_lifecycle_smoke as guard

LANG = json.loads((HERE / 'PRIMARY-03.json').read_bytes())['language']['selected']
RAW = (HERE / 'inputs/original-chunks.dat').read_bytes()

def name(text):
    raw = text.encode('ascii')
    return struct.pack('>H', len(raw)) + raw

def metadata(coords, *, level=9, array_type=12, version_type=3, version=3465, extra=b''):
    packed = [(z & 0xffffffff) << 32 | (x & 0xffffffff) for x, z in coords]
    signed = [value - 2**64 if value >= 2**63 else value for value in packed]
    payload = b'\x0a\0\0\x0a' + name('data') + bytes([array_type]) + name('Forced')
    if array_type == 9:
        payload += b'\x04'
    payload += struct.pack('>i', len(coords)) + b''.join(struct.pack('>q', value) for value in signed)
    payload += b'\0' + bytes([version_type]) + name('DataVersion')
    payload += struct.pack('>i' if version_type == 3 else '>q', version) + extra + b'\0'
    return gzip.compress(payload, compresslevel=level, mtime=0)

def line(text):
    return '[01:02:03] [Server thread/INFO] [minecraft/MinecraftServer]: ' + text

class SetupProcess:
    def __init__(self):
        self.lines, self.commands, self.waits = [], [], []
        self.replies = {
            guard.COPY_SPAWN_COMMAND: [line(LANG['commands.setworldspawn.success'] % (256, 74, -256, '0.0'))]
        }
        for command, _ in guard.PROTECTED_FORCED_QUERIES:
            chunk = '[11, 11]' if command.endswith('176 176') else '[32, 32]'
            self.replies[command] = [line(LANG['commands.forceload.query.success'] % (chunk, 'minecraft:overworld'))]
        for (command, _), chunk in zip(guard.FORCED_REMOVALS, ('[16, 16]', '[16, -2]', '[24, 24]')):
            self.replies[command] = [line(LANG['commands.forceload.removed.single'] % (chunk, 'minecraft:overworld'))]

    def command(self, command):
        self.commands.append(command)
        if command.startswith('say '):
            self.lines.append(line('[Server] ' + command[4:]))
        else:
            self.lines.extend(self.replies[command])

    def wait_for(self, pattern, timeout, start_at):
        self.waits.append(timeout)
        found = [i for i in range(start_at, len(self.lines)) if pattern.search(self.lines[i])]
        if not found:
            raise guard.server.SmokeError('No authoritative barrier')
        return found[0]

class IndependentMetadataControls(unittest.TestCase):
    def test_original_bytes_independent_signed_unpack(self):
        self.assertEqual(len(RAW), 79)
        self.assertEqual(hashlib.sha256(RAW).hexdigest(), guard.SOURCE_FORCED_SHA256)
        expanded = gzip.decompress(RAW)
        offset = expanded.index(b'Forced') + len(b'Forced')
        count = struct.unpack_from('>i', expanded, offset)[0]
        values = struct.unpack_from('>' + 'q' * count, expanded, offset + 4)
        coords = [(struct.unpack('>i', struct.pack('>I', v & 0xffffffff))[0],
                   struct.unpack('>i', struct.pack('>I', v >> 32 & 0xffffffff))[0]) for v in values]
        self.assertEqual(count, 5)
        self.assertEqual(set(coords), {(11,11), (16,16), (16,-2), (24,24), (32,32)})
        self.assertEqual(guard.check_forced_metadata(RAW, True)['expanded_bytes'], 83)

    def test_retained_native_order_and_gzip_variations_remain_semantic(self):
        for level, coords in itertools.product(range(10), (((11,11), (32,32)), ((32,32), (11,11)))):
            with self.subTest(level=level, coords=coords):
                result = guard.check_forced_metadata(metadata(coords, level=level), False)
                self.assertEqual(result['forced'], [[11,11], [32,32]])
                self.assertEqual((result['forced_type'], result['data_version'], result['tag_count']), (12,3465,4))

    def test_bootstrap_pin_is_not_substituted_by_equal_set(self):
        for level in range(10):
            raw = metadata(sorted(guard.SOURCE_FORCED), level=level)
            self.assertNotEqual(raw, RAW)
            with self.subTest(level=level), self.assertRaises(RuntimeError):
                guard.check_forced_metadata(raw, True)

    def test_phase_exact_membership_width_version_and_extra_fields(self):
        failures = [metadata(coords) for coords in ((), ((11,11),), ((11,11),(11,11)),
                    ((11,11),(32,32),(16,16)), ((11,11),(31,32)), ((32,32),(-11,11)))]
        failures += [metadata(((11,11),(32,32)), **kw) for kw in (
            {'array_type':9}, {'version_type':4}, {'version':3464}, {'extra':b'\x01\0\x01x\0'})]
        for raw in failures:
            with self.subTest(raw=raw.hex()), self.assertRaises(RuntimeError):
                guard.check_forced_metadata(raw, False)
        with self.assertRaises(RuntimeError):
            guard.check_forced_metadata(RAW, False)

    def test_expanded_limit_refuses_before_nbt_reader(self):
        with patch.object(guard, 'ForcedMetadataReader') as reader, self.assertRaises(RuntimeError):
            guard.check_forced_metadata(gzip.compress(b'0' * 4097), False)
        reader.assert_not_called()

    def test_multimember_trailing_and_crc_corruption_refuse(self):
        raw = metadata(((11,11),(32,32)))
        corrupt = bytearray(raw)
        corrupt[-8] ^= 1
        for broken in (raw + raw, raw + b'\0', bytes(corrupt), raw[:-1], b'0' * 4097):
            with self.subTest(broken=broken.hex()), self.assertRaises(RuntimeError):
                guard.check_forced_metadata(broken, False)

    def test_raw_capture_precedes_parse_failure_and_input_stays_unchanged(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            world = Path(temp) / 'world'
            (world / 'data').mkdir(parents=True)
            source = world / 'data/chunks.dat'
            source.write_bytes(b'bad')
            capture = Path(temp) / 'observed.dat'
            with self.assertRaises(RuntimeError):
                guard.read_forced_metadata(world, False, capture)
            self.assertEqual(source.read_bytes(), b'bad')
            self.assertEqual(capture.read_bytes(), b'bad')

class IndependentSetupControls(unittest.TestCase):
    def run_setup(self, process, bootstrap=True):
        commands = []
        with patch.object(guard.time, 'monotonic', return_value=0):
            result = guard.setup_copy_forced_marks(process, commands, bootstrap)
        self.assertEqual(commands, process.commands)
        return result

    def test_primary_language_literals_and_first_vs_restart_command_isolation(self):
        for bootstrap in (True, False):
            process = SetupProcess()
            result = self.run_setup(process, bootstrap)
            removes = [cmd for cmd in process.commands if 'forceload remove' in cmd]
            self.assertEqual(removes, [op[0] for op in guard.FORCED_REMOVALS] if bootstrap else [])
            self.assertEqual(len(result['removed']), 3 if bootstrap else 0)
            self.assertEqual(len(result['protected_before']), 2)
            self.assertEqual(len(result['protected_after']), 2)
            self.assertFalse(any('remove all' in cmd or 'add' in cmd for cmd in process.commands))

    def test_every_removal_requires_its_own_fresh_correct_success(self):
        for command, _ in guard.FORCED_REMOVALS:
            template = SetupProcess().replies[command][0]
            for reply in ([], [template,template], [template.replace('INFO','ERROR')],
                          [template.replace('Server thread','Worker thread')],
                          [template.replace('minecraft:overworld','minecraft:the_nether')],
                          [line(LANG['commands.forceload.removed.failure'])]):
                process = SetupProcess()
                process.lines = [template]
                process.replies[command] = reply
                with self.subTest(command=command, reply=reply), self.assertRaises(RuntimeError):
                    self.run_setup(process)

    def test_failure_feedback_at_info_is_not_a_positive_query(self):
        for command, _ in guard.PROTECTED_FORCED_QUERIES:
            process = SetupProcess()
            chunk = '[11, 11]' if command.endswith('176 176') else '[32, 32]'
            process.replies[command] = [line(LANG['commands.forceload.query.failure'] % (chunk,'minecraft:overworld'))]
            with self.subTest(command=command), self.assertRaises(RuntimeError):
                self.run_setup(process)
            self.assertFalse(any('forceload remove' in cmd for cmd in process.commands))

    def test_all_three_barriers_share_one_deadline(self):
        process, now = SetupProcess(), [0]
        old_wait = process.wait_for
        advances = iter([10,30,19])
        def wait(pattern, timeout, start_at):
            result = old_wait(pattern, timeout, start_at)
            now[0] += next(advances)
            return result
        process.wait_for = wait
        with patch.object(guard.time, 'monotonic', side_effect=lambda: now[0]):
            guard.setup_copy_forced_marks(process, [], True)
        self.assertEqual(process.waits, [60,50,20])
        self.assertEqual(now[0], 59)

    def test_late_final_barrier_refuses_without_new_budget(self):
        process, now = SetupProcess(), [0]
        old_wait = process.wait_for
        def wait(pattern, timeout, start_at):
            result = old_wait(pattern, timeout, start_at)
            now[0] += 20.001
            return result
        process.wait_for = wait
        with patch.object(guard.time, 'monotonic', side_effect=lambda: now[0]), self.assertRaises(RuntimeError):
            guard.setup_copy_forced_marks(process, [], True)
        self.assertEqual(len(process.waits), 3)
        self.assertLess(process.waits[-1], 20)

    def test_post_barrier_success_cannot_fill_prior_window(self):
        process = SetupProcess()
        command = guard.PROTECTED_FORCED_QUERIES[-1][0]
        saved = process.replies[command]
        process.replies[command] = []
        old_wait = process.wait_for
        def wait(pattern, timeout, start_at):
            result = old_wait(pattern, timeout, start_at)
            process.lines.extend(saved)
            return result
        process.wait_for = wait
        with self.assertRaises(RuntimeError):
            self.run_setup(process)
        self.assertFalse(any('forceload remove' in cmd for cmd in process.commands))

    def test_literal_operations_are_independent_of_metadata_sets(self):
        process = SetupProcess()
        with patch.object(guard, 'SOURCE_FORCED', frozenset({(999,999)})), patch.object(guard, 'RETAINED_FORCED', frozenset()):
            self.run_setup(process)
        self.assertEqual([cmd for cmd in process.commands if 'forceload remove' in cmd],
                         ['execute in minecraft:overworld run forceload remove 256 256',
                          'execute in minecraft:overworld run forceload remove 256 -32',
                          'execute in minecraft:overworld run forceload remove 384 384'])

    def test_no_live_ticket_or_runtime_claim_comes_from_metadata_or_feedback(self):
        result = self.run_setup(SetupProcess())
        self.assertNotIn('native_unload_begin', result)
        self.assertNotIn('actual_block_entity_disposal_callbacks', result)
        decoded = guard.check_forced_metadata(RAW, True)
        self.assertNotIn('holder', decoded)
        self.assertNotIn('tickets', decoded)

if __name__ == '__main__':
    unittest.main(verbosity=2)
