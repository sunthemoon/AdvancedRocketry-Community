from pathlib import Path, PurePosixPath
import hashlib
import json
import re

here = Path(__file__).resolve().parent
assert not (here/'INTERNAL-MANIFEST.json').exists(), 'Already frozen'
report = here/'REVIEW-01.md'
links = re.findall(r'\]\(([^)]+)\)',report.read_text(encoding='utf-8'))
for link in links:
    assert not re.match(r'^[A-Za-z]+:',link),link
    target = (here/link.split('#',1)[0]).resolve()
    assert target.is_relative_to(here) and target.is_file(),link
source = json.loads((here/'author/SOURCE-MANIFEST-02.json').read_bytes())
payloads = [path for path in here.iterdir() if path.is_file()]
for directory in ('author','inputs','before'):
    payloads.extend(path for path in (here/directory).rglob('*') if path.is_file())
payloads.extend(here/'candidate'/path for path in source)
out = {'format':'small-independent-source-review-v1','source_base':'73fc017ac3b121b34216e660e66b0cb583ff289a',
       'scope':'SETUP05 exact four-file development postimages; source-only, no native or Gate admission',
       'findings':{'critical':0,'high':0,'medium':0,'low':0},
       'excluded_disposable_exports':['candidate (except exact four postimages)','patch-replay'],
       'files':{}}
for path in sorted(set(payloads)):
    name = str(path.relative_to(here)).replace('\\','/')
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts
    raw = path.read_bytes()
    out['files'][name] = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
out['file_count'] = len(out['files'])
out['payload_bytes'] = sum(v['bytes'] for v in out['files'].values())
out['report_links'] = {'checked':len(links),'missing':0}
manifest = (json.dumps(out,indent=2)+'\n').encode('utf-8')
(here/'INTERNAL-MANIFEST.json').write_bytes(manifest)
for name,spec in out['files'].items():
    raw = (here/name).read_bytes()
    assert len(raw) == spec['bytes'] and hashlib.sha256(raw).hexdigest() == spec['sha256']
print(json.dumps({'report':{'path':str(report),'bytes':report.stat().st_size,'sha256':hashlib.sha256(report.read_bytes()).hexdigest()},
                 'manifest':{'path':str(here/'INTERNAL-MANIFEST.json'),'bytes':len(manifest),'sha256':hashlib.sha256(manifest).hexdigest()},
                 'file_count':out['file_count'],'payload_bytes':out['payload_bytes'],
                 'portable_links':len(links),'postfreeze_hash_errors':0},indent=2))
