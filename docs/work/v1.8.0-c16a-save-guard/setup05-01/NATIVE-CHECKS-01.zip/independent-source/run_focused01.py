from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
label = sys.argv[1] if len(sys.argv) > 1 else 'focused-01'
assert label in ('focused-01', 'focused-02')
env = dict(os.environ, TEMP=str(here), TMP=str(here), TMPDIR=str(here), PYTHONDONTWRITEBYTECODE='1')
command = [sys.executable, '-B', '-m', 'unittest', '-v',
           'tests.test_run_v180_guard_lifecycle_smoke', 'tests.test_run_v180_tank_smoke',
           'tests.test_run_v180_pump_smoke', 'tests.test_run_v180_signature_smoke']
record = {'command': command, 'cwd': str(here / 'candidate'),
          'TEMP': str(here), 'TMP': str(here), 'TMPDIR': str(here)}
(here / (label + '-command.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
start = time.monotonic()
result = subprocess.run(command, cwd=here / 'candidate', env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / (label + '.log')).write_bytes(result.stdout)
(here / (label + '.exit')).write_text(str(result.returncode) + '\n', encoding='ascii')
text = result.stdout.decode('utf-8', errors='replace')
match = re.search(r'Ran (\d+) tests? in ([\d.]+)s', text)
record.update(exit=result.returncode, seconds=time.monotonic() - start,
              tests=int(match[1]) if match else None, unittest_seconds=float(match[2]) if match else None,
              terminal=text.rstrip().splitlines()[-1], log_bytes=len(result.stdout),
              log_sha256=hashlib.sha256(result.stdout).hexdigest())
(here / (label + '-result.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode)
