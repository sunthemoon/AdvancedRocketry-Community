from pathlib import Path
import gzip
import json
import os
import re
import sys
import unittest

HERE = Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(HERE)
sys.path.insert(0,'D:/GitHub/ARCE-Task-Evidence/v1.8.0/agsr-33e6a6f556/candidate')
from scripts.inspect_celestial_saved_data import NbtReader

class TypedReader(NbtReader):
    def _payload(self,kind,depth):
        return (kind,super()._payload(kind,depth))

def forced(raw):
    assert len(raw) <= 4096
    payload = gzip.decompress(raw)
    assert len(payload) <= 4096 and payload[:3] == b'\x0a\0\0'
    reader = TypedReader(payload)
    kind,root = reader.read_root()
    assert kind == 10 and set(root) == {'data','DataVersion'} and root['DataVersion'] == (3,3465)
    assert root['data'][0] == 10 and set(root['data'][1]) == {'Forced'}
    kind,values = root['data'][1]['Forced']
    assert kind == 12 and reader.tags == 4
    coords = []
    for value in values:
        x,z = value & 0xffffffff,value >> 32 & 0xffffffff
        coords.append((x-2**32 if x >= 2**31 else x,z-2**32 if z >= 2**31 else z))
    assert len(set(coords)) == len(coords)
    return set(coords)

PREFIX = r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/INFO\] \[minecraft/MinecraftServer\]: (?:\[Not Secure\] )?\[Server\] '
EVENT = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/INFO\] \[advancedrocketrycommunity/\]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11$')

def exact(lines,label):
    expression = re.compile(PREFIX+re.escape(label)+r'$')
    positions = [i for i,line in enumerate(lines) if expression.fullmatch(line)]
    assert len(positions) == 1,(label,len(positions))
    return positions[0]

def live_cut(lines):
    positions = [exact(lines,label) for label in ('ARCE_GUARD_MARKER_MUTATED','ARCE_GUARD_ROOT_REMOVED',
        'after_removal_refusal_END','ARCE_GUARD_NOT_LOADED','ARCE_GUARD_REMOVAL_ROLLED_BACK','ARCE_GUARD_MUTATION_ROLLED_BACK')]
    assert positions == sorted(set(positions))
    events = [i for i,line in enumerate(lines) if EVENT.fullmatch(line) and positions[2] < i < positions[4]]
    assert len(events) == 1 and positions[3] < events[0]
    return events[0]

LINES = (HERE/'evidence/native-05/removal-availability-reload/stdout.txt').read_text(encoding='utf-8').splitlines()
class ActualEvidenceControls(unittest.TestCase):
    def test_native_five_two_two_types_independently_decoded(self):
        source = {(11,11),(16,16),(16,-2),(24,24),(32,32)}
        retained = {(11,11),(32,32)}
        first = HERE/'evidence/native-05/removal-availability-reload'
        second = HERE/'evidence/native-05/restart-retrigger'
        self.assertEqual(forced((first/'forced-before.dat').read_bytes()),source)
        for file in (first/'forced-after.dat',second/'forced-before.dat',second/'forced-after.dat',HERE/'evidence/stopped-05/chunks.dat'):
            self.assertEqual(forced(file.read_bytes()),retained)

    def test_record_byte_identity_for_all_actual_stopped_fragments(self):
        original = (HERE/'evidence/native-05/source-chunk-11-11.nbt.zlib').read_bytes()
        for path in (HERE/'evidence/native-05/removal-availability-reload/chunk-11-11.nbt.zlib',
                     HERE/'evidence/native-05/restart-retrigger/chunk-11-11.nbt.zlib',
                     HERE/'evidence/stopped-05/chunk-11-11.nbt.zlib'):
            self.assertEqual(path.read_bytes(),original)
        changed = bytes([original[0]^1])+original[1:]
        self.assertNotEqual(changed,original)

    def test_actual_live_cut_event_not_shutdown_event(self):
        self.assertEqual(live_cut(LINES)+1,725)
        self.assertGreater(max(i for i,line in enumerate(LINES) if EVENT.fullmatch(line)),live_cut(LINES))

    def test_shutdown_marker_cannot_replace_absent_live_cut_marker(self):
        lines = list(LINES)
        lines.pop(live_cut(lines))
        self.assertTrue(any(EVENT.fullmatch(line) for line in lines))
        with self.assertRaises(AssertionError):
            live_cut(lines)

    def test_foreign_thread_logger_cell_severity_echo_refused(self):
        event = live_cut(LINES)
        for mutate in (lambda line:line.replace('Server thread','Worker thread'),
                       lambda line:line.replace('advancedrocketrycommunity/','example/'),
                       lambda line:line.replace('/INFO]','/ERROR]'),
                       lambda line:line.replace('11,11','11,12'),lambda line:'echo '+line):
            lines = list(LINES)
            lines[event] = mutate(lines[event])
            with self.subTest(line=lines[event]),self.assertRaises(AssertionError):
                live_cut(lines)

    def test_missing_wrong_or_reordered_live_restoration_refused(self):
        index = exact(LINES,'ARCE_GUARD_REMOVAL_ROLLED_BACK')
        for replacement in ('missing',LINES[index].replace('ROLLED_BACK','REMOVED')):
            lines = list(LINES)
            lines[index] = replacement
            with self.assertRaises(AssertionError):
                live_cut(lines)
        lines = list(LINES)
        before = exact(lines,'ARCE_GUARD_NOT_LOADED')
        lines[index],lines[before] = lines[before],lines[index]
        with self.assertRaises(AssertionError):
            live_cut(lines)

    def test_restart_retrigger_has_no_mock_removal_or_second_live_unload_claim(self):
        commands = json.loads((HERE/'evidence/native-05/restart-retrigger/commands.json').read_bytes())
        lines = (HERE/'evidence/native-05/restart-retrigger/stdout.txt').read_text(encoding='utf-8').splitlines()
        self.assertEqual(commands[-1],'stop')
        self.assertFalse(any('forceload remove' in command for command in commands))
        with self.assertRaises(AssertionError):
            live_cut(lines)

    def test_cleanup_tool_block_is_not_a_native_exit_or_success(self):
        native = json.loads((HERE/'evidence/native-05.result.json').read_bytes())
        cleanup = json.loads((HERE/'evidence/CLEANUP05-RESULT-BLOCKED-01.json').read_bytes())
        self.assertEqual(native['exit'],0)
        self.assertIn('BLOCK',json.dumps(cleanup).upper())
        self.assertNotEqual(cleanup,native)

if __name__ == '__main__':
    unittest.main(verbosity=2)
