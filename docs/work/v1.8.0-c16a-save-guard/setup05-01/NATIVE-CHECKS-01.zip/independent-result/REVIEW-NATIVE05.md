# Native05 independent result audit

Date: 2026-10-04. Delegated reviewer `/root/c17_contract`, not SETUP05 implementer.
This is an audit of completed, captured results, not a native replay or a new
source/Java review. Root remains the sole integrator and acceptance owner.

## Findings and qualified result

**0 Critical / 0 High / 0 Medium / 0 Low findings in the audited bounded result.**
The actual two-host diagnostic completes with recorded outer exit 0 in
70.746109 seconds. Raw first-host observations establish the fixed real Unload
hook marker before reacquisition, both live fixed-cell rollback assertions,
save refusals after mutation and culprit removal, clean stop and exact original
compressed terrain retention. The second same-world host reloads the retained
snapshot and retriggers refusal, then stops cleanly. It does **not** perform a
second live culprit-removal/unload/reacquisition cycle.

This supports the exact SETUP05 diagnostic slice. It does not establish BE
disposal callback instrumentation, first-save writer correctness, crash or
cross-store atomicity, arbitrary world/unknown-root fidelity, player repair,
clients/peers/GPU, risk acceptance or whole-version Gates. The earlier native
attempts 01–04 remain FAIL; successful fixture isolation does not retroactively
prove a unique cause for all those failures.

## Exact cohort and evidence identity

Committed Python setup: `f1d649238284bef515ff8fafafd65611ac37bc32`.
Java/artifact source: `a5abc34809891d6b10724ee60ab9b5e97f036bae` (Source25).
The Java/build/generated diff between these objects is empty; Python setup did
not rebuild Java. Both Python postimages match the independently reviewed
SETUP05 bytes `7eea858bc9808e035252f79ae56970bea996ddde80b3a1c4e3128cbff5fcb77a`
and `27fd2c7d11f3d1e664d833f59a849a2ae48bb27c17133611bf4b4c5e0955082f`.
Moving HEAD was not used as the code baseline.

Root completed evidence is at
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-forced-setup-05`.
All individually inspected inputs, their byte sizes and hashes are recorded in
[AUDIT-01.json](AUDIT-01.json). The audit only reads named stopped/captured
files and original-template files enumerated in their explicit manifests; it
does not inspect a live server world or rely on the disposable copy remaining.

| Artifact / fragment | Bytes | SHA-256 |
|---|---:|---|
| Source25 main JAR, independently hashed in its named external location | 5,465,573 | `61c5499318dcd17d929acd9f3d28ab1e99066ba2c29da1de34603096f10f3921` |
| Exact compatibility fixture JAR | 96,772 | `765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4` |
| [Original terrain fragment](evidence/native-05/source-chunk-11-11.nbt.zlib), both phase fragments and [final stopped fragment](evidence/stopped-05/chunk-11-11.nbt.zlib) | 5,898 each | `d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8` |
| Bootstrap forced metadata | 79 | `c9b7030c645d2995ac9be13d08964eb98f1942b2170c34b3f893100daa6acc50` |
| [Final stopped forced metadata](evidence/stopped-05/chunks.dat) | 67 | `f7049dbcf6da5cd5ac8849fffd49270a031046d817a933bf0ddf329650222c12` |
| [Stopped properties](evidence/stopped-05/server.properties) | 1,351 | `4063774acf5e76b94067df4002d94e399d4c82c3a448b01b1b61e30b44c4e036` |
| [Stopped capture receipt](evidence/stopped-05/CAPTURE-01.json) | 1,543 | `72d6dceeb435493198304df47235ee4f3c9c3416e68680ca289b7657ed125841` |

The 3,009 named source-input hashes agree with the observed source files; 3,007
agree literally with fixed Git object bytes. The two explicit exceptions are
the externally maintained AGENTS additions and only `gradlew.bat`'s Windows
CRLF representation. No broad normalization waiver is applied. Their exact
manifest/object bytes and hashes are retained in AUDIT-01, not described as
3,009 literal committed objects. Both fixed Python objects are byte-exact.

All **104** source-template library files and **139** enumerated original-world
files were independently hash-checked without broad world/cache walks. Root's
[precheck](evidence/NATIVE05-PRECHECK-01.json),
[postcheck](evidence/NATIVE05-POSTCHECK-01.json) and native
[input postcheck](evidence/native-05/input-postcheck.json) agree. The stopped
copy's separate inventory has 145 entries, not the source inventory count.
The precheck records C/D free byte values above the declared 10,000,000,000-byte
threshold; this audit did not start a new native process or borrow Source25's
build/GameTest results as native proof.

## Raw executed phases, not summary-label inference

### First host: removal / availability / reload

[Commands](evidence/native-05/removal-availability-reload/commands.json) contain
46 entries; the [launch](evidence/native-05/removal-availability-reload/launch.json)
uses Java 17.0.7, Forge 47.4.10, `nogui`, the same copied runtime and explicit
`advancedrocketrycommunity.releaseTestHooks=true`. The [receipt](evidence/native-05/removal-availability-reload/receipt.json)
records clean exit 0. Selected numbered raw facts in AUDIT-01 establish:

- Stdout lines 154–164: positive target/far membership before and after setup,
  exact copied spawn relocation and the three allowed native single-mark
  removals. No arbitrary coordinate or decoded-mark command is present.
- Lines 165/167/171: original culprit tank/AIR-marker checks and confirmed live
  marker-to-STONE mutation. Explicit initial save observes paired save refusals.
- Lines 422/667: live culprit-to-AIR check followed by the second explicit save
  and retained refusal. False loaded predicate is freshly observed at line 670.
- Line 672: bounded state diagnostic is `no_save=false`, untruncated visible
  holder level 44 / full / INACCESSIBLE. It is a state observation, not a
  complete ticket map or lifecycle oracle.
- **Line 725**, `[22:37:38]`, is the real fixed `ARCE_GUARD_UNLOAD_BEGIN` hook
  marker. It follows the false predicate at `[22:37:19]` and precedes the
  target re-add/reacquisition and both rollback assertions. The coarse log
  difference is 19 seconds; the committed driver retains the single original
  60-second deadline and 240-probe bound. No new timeout is inferred from logs.
- Lines **1098/1152**: after reacquisition, the exact live conditional checks
  report the culprit tank restored and mutated marker restored to AIR.
- Lines 1206 onward: stop/shutdown/save-completion text follows those checks.
  The extra Unload marker at **1259** is shutdown, not the marker used to pass
  the earlier live cut. The stopped terrain is byte-identical to original.

First-host stdout contains **19 EventBus / 19 ChunkMap** paired refusal headers.
The known refusal stacks are present rather than suppressed. Existing refusal
audits reject unrelated ERROR/FATAL framing; these counts are not a clean-log
or R-021 closure claim.

### Second same-world host: restart retrigger

[Commands](evidence/native-05/restart-retrigger/commands.json) contain 25 entries.
It uses the same launch/cwd/installed cohort and starts from the first clean-stop
two-mark metadata. There are **no** neighbor removals, target removals, repeated
first-cycle repair operations or live rollback commands in this phase.

Raw stdout lines **77/81/85** establish the reloaded culprit/AIR snapshot and a
fresh marker mutation. Explicit save then refuses again before the fresh
`initial_refusal_END` at line 331 and stop. There are **6 EventBus / 6 ChunkMap**
paired headers. The only Unload marker, line **385**, occurs during shutdown;
it does not constitute a second live unload/reacquisition check. Receipt exit
is 0 and stopped terrain again equals the original compressed record.

The outer [actual result](evidence/native-05.result.json) records exit 0 and
70.74610939994454 seconds. Its 94-byte log hash is
`701bfcf55ed1dbff7e7fc1b371f534c72c38326aa56e37f82cceb2fdddbcca0f`.
The result labels are consistent with the raw bounded facts above, not their
substitute.

## Typed stopped-byte reconstruction

The reviewer independently parses the 54,066 expanded native chunk bytes
within the inherited byte/node bounds (531 native tags), in addition to exact
compressed equality and exact-cell block-state checks. Both phase fragments
and final stopped capture preserve the following actual native fields:

| Cell x, y=180, z=180 | Schema width/value | Fluid amount width/value | Additional native data |
|---|---|---|---|
| 182 (overflow) | TAG_Int / 1 | TAG_Int / 300,000 water | Overflow value retained, not truncated to capacity |
| 184 (tagged) | TAG_Int / 1 | TAG_Int / 5,000 lava | TAG_Compound metadata, `batch` TAG_String `native-retained` |
| 186 (future + oversized) | TAG_Int / 2 | TAG_Int / 5,000 water | TAG_Compound extension with **two TAG_Byte_Array (7)** parts, each 4,096 zero bytes |
| 188 (corrupt) | TAG_Int / 1 | TAG_Int / -1 water | Corrupt negative raw amount retained, not accepted as usable fluid |

All four BE IDs and fluid IDs are TAG_String; coordinates are TAG_Int. There is
no second carrier at `(180,180,180)` and the marker `(190,180,180)` is AIR in
each byte-equal stopped chunk. The oversized extension is neither a List nor
an IntArray; the initial reviewer assumption was corrected after actual typed
decode, not by changing any fixture or assertion.

Independently decoded forced metadata is exact four-node native shape with
DataVersion TAG_Int 3465 and Forced TAG_Long_Array (12). The stopped sequence is
five original unique marks → target/far only → target/far only. Signed `(16,-2)`
is preserved in the bootstrap decode. The deliberate metadata delta does not
relax the separate unchanged-terrain byte oracle. Metadata and successful mark
queries alone are not proof of all live/mod tickets or final callback cleanup.

## Observer attribution and primary limits

[OBSERVER-03.json](OBSERVER-03.json) binds the actual packaged observer class
SHA-256 `7ea9fd9a2bb5aa977cf30f97aff4c5adb0a28a89b44f5deb211e7b5010cba758`
and fixed Java source SHA-256
`05ed91efddf540aef34dbad0d8b8c72ed411eff5e1fc1385548022d9cc496e07`.
Selected compiled methods are inspected without Java execution or class export.
The source guards opt-in property, actual ServerLevel, Overworld, server thread,
LevelChunk and exact `(11,11)` before logging; its state command is console-only,
permission-4 and does not load a chunk.

Both captured debug logs show FORGE auto-subscription (lines 346 and 341).
Registration text alone proves an attempt, not callback execution; the raw
properly framed Unload markers supply the bounded execution observation.
The pinned primary ordering is still Unload-event **begin before BE disposal**.
Queued console work follows the server-thread unload continuation, and the
subsequent live block rollback makes the result stronger than a false loaded
predicate alone. No per-BE disposal callback, inventory capability or final
global ticket map was instrumented by this slice.

## Actual reviewer commands, controls and preserved failures

All helpers/logs/outputs and process-local TEMP/TMP/TMPDIR are only in this new
D project-parent leaf. No Java, native/server/client, Gradle, Git mutation,
network, cleanup, private-folder read or old huge-archive operation was run.

- `python -B audit01.py`, final: exit 0; raw identities/phase order/typed data
  and named input checks above. [Final audit log](audit-01-final02.log).
- `python -B controls02.py`: **8 tests / 0 failures, errors or skips**, 0.033 s,
  exit 0. [Control source](controls02.py), [raw log](controls-02.log).
  Controls independently decode all forced phases; compare all stopped terrain;
  reject replacing the live event with the remaining shutdown event, foreign
  framing/cell, missing/reordered restoration; and distinguish the second-host
  scope and blocked cleanup from runtime exit.
- `python -B observer03.py`: exit 0; exact source/class and real registration
  facts inspected read-only. No hook/source correction was applied.

Original reviewer failures are retained separately: initial hyphenated receipt
guesses were absent because the real runner uses dot-named files (the brace
notation was misread by this reviewer); audit attempt 1 assumed an extension
List while actual native type is ByteArray; attempt 2 over-specified raw slash
spelling of the resolved Windows Java executable. Their old probes/logs remain.
The final audit preserves all byte checks and verifies Windows path identity
only for that executable argument; there is no source-byte normalization waiver,
fixture mutation, suppressed native failure or lowered runtime assertion.

Root's [cleanup result](evidence/CLEANUP05-RESULT-BLOCKED-01.json) is
`BLOCKED_BY_TOOL_POLICY`: OS command not started, no OS exit, no alternative
deletion, cleanup not completed. This is independent from the recorded native
exit 0 and does not justify either a cleanup-success claim or native failure
reclassification. The reviewer neither attempted nor verified deletion of the
211,865,779-byte disposable server copy. Original source world and stopped
fragments remain distinct, protected inputs.

## Remaining current-v1.8 obligations

This closes only the observed fixed-fixture diagnostic assertions, as evidence
for Root's qualified status decision. It does not accept R-021 or redefine the
sticky guard's Level lifetime, unrelated-state rollback, logging/retry policy
or recovery procedure. Real caller/resource interactions, first-save writer
cases, other guard consumers, arbitrary unsafe raw roots, actual disposal
instrumentation, cross-store/crash scenarios, native player repair and release
client/peer/GPU Gates remain separate work. None of the earlier failures is
rewritten; the report makes no whole-version Required Gate claim.
