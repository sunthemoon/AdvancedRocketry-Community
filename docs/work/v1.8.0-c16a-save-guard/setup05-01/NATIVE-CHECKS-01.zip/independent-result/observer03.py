from pathlib import Path
import ast
import hashlib
import json
import os
import struct
import subprocess
import zipfile

here = Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(here)
tree = ast.parse(Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py').read_text(encoding='utf-8'))
scope = {'struct':struct}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))
                             and n.name in ('R','parse')],type_ignores=[]),'selected-reader','exec'),scope)
source = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java'
raw = subprocess.check_output(['git','show','f1d649238284bef515ff8fafafd65611ac37bc32:'+source],cwd='D:/GitHub/AdvancedRocketry-Community')
artifact = Path(json.loads((here/'evidence/native-05/inputs.json').read_bytes())['host']['path'])
member = 'io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.class'
with zipfile.ZipFile(artifact) as z:
    code = z.read(member)
parsed = scope['parse'](code,{'observe','register','state'})
out = {'source_object':'f1d649238284bef515ff8fafafd65611ac37bc32:'+source,
       'source_sha256':hashlib.sha256(raw).hexdigest(),'artifact_member':member,
       'class_sha256':hashlib.sha256(code).hexdigest(),'java_executions':0,
       'compiled_methods':{name:[i for i in detail['instructions'] if i['reference'] is not None or i['branch_target'] is not None]
                           for name,detail in parsed['selected_methods'].items()},'raw_registration_lines':{}}
for phase in ('removal-availability-reload','restart-retrigger'):
    lines = (here/'evidence/native-05'/phase/'debug.log').read_text(encoding='utf-8').splitlines()
    out['raw_registration_lines'][phase] = [{'line':i+1,'text':line} for i,line in enumerate(lines)
        if 'Auto-subscribing io.github.sunthemoon.advancedrocketrycommunity.gametest.GuardedChunkUnloadObservation to FORGE' in line]
    assert len(out['raw_registration_lines'][phase]) == 1
(here/'OBSERVER-03.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source_sha256':out['source_sha256'],'class_sha256':out['class_sha256'],
                  'compiled_methods':len(out['compiled_methods']),'actual_registration_lines':out['raw_registration_lines']},indent=2))
