from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re

here = Path(__file__).resolve().parent
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(here)
assert not (here/'INTERNAL-MANIFEST.json').exists()
audit = json.loads((here/'AUDIT-01.json').read_bytes())
checks = []
for row in audit['evidence_inputs']:
    raw = Path(row['path']).read_bytes()
    actual = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    assert actual == {key:row[key] for key in ('bytes','sha256')},row['path']
    checks.append({'path':row['path'],**actual})
for row in audit['artifacts'].values():
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    checks.append({'path':row['path'],'bytes':len(raw),'sha256':row['sha256']})
report = here/'REVIEW-NATIVE05.md'
links = re.findall(r'\]\(([^)]+)\)',report.read_text(encoding='utf-8'))
for link in links:
    assert not re.match(r'^[A-Za-z]+:',link),link
    target = (here/link.split('#',1)[0]).resolve()
    assert target.is_relative_to(here) and target.is_file(),link
post = {'named_evidence_and_artifact_checks':len(checks),'drift':0,'checks':checks,
        'report_links':{'count':len(links),'missing':0},'reviewer_java_native_launches':0,
        'no_cleanup_or_source_world_mutation':True}
(here/'POSTCHECK-04.json').write_text(json.dumps(post,indent=2)+'\n',encoding='utf-8')
files = {}
for path in sorted(here.rglob('*')):
    if not path.is_file():
        continue
    name = str(path.relative_to(here)).replace('\\','/')
    parsed = PurePosixPath(name)
    assert not parsed.is_absolute() and '..' not in parsed.parts
    raw = path.read_bytes()
    files[name] = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
out = {'format':'small-independent-native-result-audit-v1','source_commit':audit['source_commit'],
       'java_commit':audit['java_commit'],'scope':'Native05 two captured fixed-fixture hosts only, no replay/version Gate',
       'findings':{'critical':0,'high':0,'medium':0,'low':0},'files':files,
       'file_count':len(files),'payload_bytes':sum(row['bytes'] for row in files.values())}
raw = (json.dumps(out,indent=2)+'\n').encode()
(here/'INTERNAL-MANIFEST.json').write_bytes(raw)
for name,spec in files.items():
    data = (here/name).read_bytes()
    assert len(data) == spec['bytes'] and hashlib.sha256(data).hexdigest() == spec['sha256']
print(json.dumps({'report':{'path':str(report),'bytes':report.stat().st_size,'sha256':hashlib.sha256(report.read_bytes()).hexdigest()},
                 'manifest':{'path':str(here/'INTERNAL-MANIFEST.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
                 'file_count':len(files),'payload_bytes':out['payload_bytes'],'postchecks':len(checks),
                 'drift':0,'portable_links':len(links),'postfreeze_hash_errors':0},indent=2))
