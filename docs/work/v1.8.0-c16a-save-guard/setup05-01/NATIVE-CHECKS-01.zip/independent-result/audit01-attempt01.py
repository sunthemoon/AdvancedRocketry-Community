from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import zlib
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
INPUT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-forced-setup-05')
COMMIT = 'f1d649238284bef515ff8fafafd65611ac37bc32'
JAVA_COMMIT = 'a5abc34809891d6b10724ee60ab9b5e97f036bae'
PRIOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/agsr-33e6a6f556')
for key in ('TEMP','TMP','TMPDIR'):
    os.environ[key] = str(HERE)
sys.path.insert(0,str(PRIOR/'candidate'))
from scripts import run_v180_guard_lifecycle_smoke as guard

def pin(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def safe(base,name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and ':' not in name and '\\' not in name
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in p.parts
    path = base/name
    assert not path.is_symlink()
    return path

def put(name,raw):
    target = HERE/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)

files = ['run_native05.py','capture_stopped05.py','native-05.command.json','native-05.result.json',
         'native-05.log','NATIVE05-PRECHECK-01.json','NATIVE05-POSTCHECK-01.json','SETUP05-MANIFEST-01.json',
         'SOURCE-PUBLICATION-01.json','native-05/inputs.json','native-05/source-world-files.json',
         'native-05/input-postcheck.json','native-05/summary.json','native-05/source-chunk-11-11.nbt.zlib',
         'stopped-05/CAPTURE-01.json','stopped-05/chunk-11-11.nbt.zlib','stopped-05/chunks.dat',
         'stopped-05/server.properties','stopped-05/runtime-world-files.json',
         'CLEANUP05-PRECHECK-01.json','CLEANUP05-RESULT-BLOCKED-01.json','TOOL-OBSERVATIONS-01.md']
phases = ['removal-availability-reload','restart-retrigger']
for phase in phases:
    files += ['native-05/'+phase+'/'+name for name in ('launch.json','commands.json','receipt.json','stdout.txt',
              'latest.log','debug.log','chunk-11-11.nbt.zlib','forced-before.dat','forced-after.dat')]
ledger = []
for name in files:
    path = safe(INPUT,name)
    raw = path.read_bytes()
    assert len(raw) <= 10*1024*1024,name
    put('evidence/'+name,raw)
    ledger.append({'path':str(path),**pin(raw)})

load = lambda name: json.loads((HERE/'evidence'/name).read_bytes())
source = load('SETUP05-MANIFEST-01.json')
observations = {'source_count':len(source),'source_live_matches':0,'source_live_differences':[],
                'source_git_matches':0,'source_git_differences':[]}
for name,spec in source.items():
    raw = safe(ROOT,name).read_bytes()
    if pin(raw) == spec:
        observations['source_live_matches'] += 1
    else:
        observations['source_live_differences'].append({'path':name,'manifest':spec,'actual':pin(raw)})
requests = ''.join(COMMIT+':'+name+'\n' for name in source).encode()
batch = subprocess.run(['git','cat-file','--batch'],cwd=ROOT,input=requests,capture_output=True)
assert batch.returncode == 0
offset = 0
for name,spec in source.items():
    end = batch.stdout.index(b'\n',offset)
    header = batch.stdout[offset:end].split()
    assert header[1] == b'blob',header
    count = int(header[2])
    raw = batch.stdout[end+1:end+1+count]
    offset = end+1+count+1
    if pin(raw) == spec:
        observations['source_git_matches'] += 1
    else:
        observations['source_git_differences'].append({'path':name,'manifest':spec,'git_object_bytes':pin(raw)})
assert offset == len(batch.stdout)
code_delta = subprocess.run(['git','diff','--name-only',JAVA_COMMIT,COMMIT,'--','src','build.gradle','settings.gradle',
                             'gradle.properties','gradle','gradlew','gradlew.bat'],cwd=ROOT,capture_output=True)
assert code_delta.returncode == 0
observations['java_build_generated_delta_a5_to_f1'] = code_delta.stdout.decode('utf-8').splitlines()
for name in ('scripts/run_v180_guard_lifecycle_smoke.py','tests/test_run_v180_guard_lifecycle_smoke.py'):
    raw = subprocess.check_output(['git','show',COMMIT+':'+name],cwd=ROOT)
    assert raw == (PRIOR/'candidate'/name).read_bytes()
    put('source/'+name,raw)

inputs = load('native-05/inputs.json')
template = Path(inputs['runtime_template'])
artifacts = {}
for key in ('host','fixture'):
    spec = inputs[key]
    path = Path(spec['path'])
    assert pin(path.read_bytes()) == {k:spec[k] for k in ('bytes','sha256')}
    artifacts[key] = {**spec,'independently_hash_verified':True}
libraries_path = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/LIBRARIES-INPUTS-01.json')
libraries_raw = libraries_path.read_bytes()
libraries = json.loads(libraries_raw)
for name,spec in libraries.items():
    assert pin(safe(template/'libraries',name).read_bytes()) == spec,name
world_rows = load('native-05/source-world-files.json')
source_world = Path(inputs['source_world'])
for spec in world_rows:
    assert pin(safe(source_world,spec['path']).read_bytes()) == {k:spec[k] for k in ('bytes','sha256')},spec['path']
observations.update(library_files_verified=len(libraries),original_world_named_files_verified=len(world_rows))
ledger.append({'path':str(libraries_path),**pin(libraries_raw)})
put('evidence/LIBRARIES-INPUTS-01.json',libraries_raw)
original = (HERE/'evidence/native-05/source-chunk-11-11.nbt.zlib').read_bytes()
assert pin(original) == {'bytes':5898,'sha256':'d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'}
original_roots = guard.check_fixture(guard.regions._decode_chunk(original,11,11))

class TypedReader(guard.tanks.NbtReader):
    def _payload(self,kind,depth):
        subtype = self.payload[self.offset] if kind == 9 else None
        value = super()._payload(kind,depth)
        return (kind,{'element_type':subtype,'values':value}) if kind == 9 else (kind,value)

stream = zlib.decompressobj()
expanded = stream.decompress(original,1024*1024+1)
assert stream.eof and not stream.unused_data and not stream.unconsumed_tail and len(expanded) <= 1024*1024
reader = TypedReader(expanded)
typed = reader.read_root()
assert typed[0] == 10 and typed[1]['block_entities'][0] == 9
entities = typed[1]['block_entities'][1]['values']
typed_roots = []
for kind,entity in entities:
    assert kind == 10 and entity['arce_pressurized_tank'][0] == 10
    root = entity['arce_pressurized_tank'][1]
    fluid = root['fluid'][1]
    row = {'position':{axis:list(entity[axis]) for axis in ('x','y','z')},'id':list(entity['id']),
           'schema':list(root['schema']),'fluid_name':list(fluid['FluidName']),'amount':list(fluid['Amount'])}
    assert all(entity[axis][0] == 3 for axis in ('x','y','z'))
    assert root['schema'][0] == 3 and root['fluid'][0] == 10 and fluid['Amount'][0] == 3 and fluid['FluidName'][0] == 8
    if 'Tag' in fluid:
        row['fluid_metadata'] = fluid['Tag']
    if 'extension' in root:
        extension_kind, extension = root['extension']
        row['extension_type'] = extension_kind
        if extension_kind == 10:
            row['extension_parts'] = {key:{'type':value[0],'element_type':value[1]['element_type'],
                'length':len(value[1]['values']),'all_native_int_zero':all(v == (3,0) for v in value[1]['values'])}
                for key,value in extension.items()}
    typed_roots.append(row)

phase_facts = []
def find(lines,pattern):
    return [(i+1,line) for i,line in enumerate(lines) if pattern.search(line)]
def say(lines,label):
    values = find(lines,guard.marker(label))
    assert len(values) == 1,(label,len(values))
    return values[0][0]
def stamp(line):
    match = re.match(r'^\[(\d{2}):(\d{2}):(\d{2})\]',line)
    assert match,line
    h,m,s = map(int,match.groups())
    return h*3600+m*60+s
for phase_index,phase in enumerate(phases):
    prefix = 'native-05/'+phase+'/'
    receipt = load(prefix+'receipt.json')
    commands = load(prefix+'commands.json')
    lines = (HERE/'evidence'/prefix/'stdout.txt').read_text(encoding='utf-8').splitlines()
    launch = load(prefix+'launch.json')
    assert launch['cwd'] == str(INPUT/'native-05/server').replace('/','\\') or Path(launch['cwd']) == INPUT/'native-05/server'
    assert launch['command'][0] == 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
    assert '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
    assert launch['command'][-1] == 'nogui' and 'forge/1.20.1-47.4.10' in launch['command'][-2]
    assert receipt['exit_code'] == 0 and commands[-1] == 'stop'
    assert any('Stopping the server' in line for line in lines)
    assert any('All dimensions are saved' in line for line in lines[-30:])
    record = (HERE/'evidence'/prefix/'chunk-11-11.nbt.zlib').read_bytes()
    assert record == original
    forced_before = guard.check_forced_metadata((HERE/'evidence'/prefix/'forced-before.dat').read_bytes(),phase_index == 0)
    forced_after = guard.check_forced_metadata((HERE/'evidence'/prefix/'forced-after.dat').read_bytes(),False)
    assert receipt['forced_preflight'] == forced_before and receipt['forced_after_clean_stop'] == forced_after
    ready = next(i+1 for i,line in enumerate(lines) if guard.server.READY_MARKER.search(line))
    before = say(lines,'ARCE_GUARD_FORCED_BEFORE_END')
    spawn = say(lines,'ARCE_GUARD_COPY_SPAWN_END')
    after = say(lines,'ARCE_GUARD_FORCED_AFTER_END')
    root = say(lines,'ARCE_GUARD_ROOT_RELOADED')
    absent = say(lines,'ARCE_GUARD_MARKER_ABSENT')
    mutated = say(lines,'ARCE_GUARD_MARKER_MUTATED')
    assert ready < before < spawn < after < root < absent < mutated
    for _,pattern in guard.PROTECTED_FORCED_QUERIES:
        positions = find(lines,pattern)
        assert len(positions) == 2 and ready < positions[0][0] < before and spawn < positions[1][0] < after
    spawn_positions = find(lines,guard.COPY_SPAWN_SUCCESS)
    assert len(spawn_positions) == 1 and before < spawn_positions[0][0] < spawn
    setup_seconds_coarse = stamp(lines[after-1])-stamp(lines[before-1])
    assert setup_seconds_coarse <= 60
    removals = [cmd for cmd in commands if cmd in [x[0] for x in guard.FORCED_REMOVALS]]
    assert removals == [x[0] for x in guard.FORCED_REMOVALS] if phase_index == 0 else not removals
    if phase_index == 0:
        for _,pattern in guard.FORCED_REMOVALS:
            positions = find(lines,pattern)
            assert len(positions) == 1 and spawn < positions[0][0] < after
    refusal = guard.audit_refusal(lines)
    first_save = say(lines,'initial_refusal_END')
    assert any(guard.EVENT_ERROR.search(line) for line in lines[mutated:first_save-1])
    row = {'phase':phase,'receipt_exit_code':receipt['exit_code'],'stdout_lines':len(lines),'commands':len(commands),
           'forced_before':forced_before,'forced_after':forced_after,'terrain':pin(record),
           'setup_coarse_log_seconds':setup_seconds_coarse,'ready_line':ready,
           'setup_barriers':{'before':before,'spawn':spawn,'after':after},
           'live':{'root_reloaded':root,'marker_absent':absent,'marker_mutated':mutated},
           'refusal_headers':{key:value for key,value in refusal.items() if key != 'findings'},
           'unload_events':[{ 'line':i,'text':text} for i,text in find(lines,guard.UNLOAD_BEGIN)]}
    if phase_index == 0:
        removed = say(lines,'ARCE_GUARD_ROOT_REMOVED')
        saved = say(lines,'after_removal_refusal_END')
        not_loaded = say(lines,'ARCE_GUARD_NOT_LOADED')
        rolled_root = say(lines,'ARCE_GUARD_REMOVAL_ROLLED_BACK')
        rolled_marker = say(lines,'ARCE_GUARD_MUTATION_ROLLED_BACK')
        event = next((i,text) for i,text in find(lines,guard.UNLOAD_BEGIN) if saved < i < rolled_root)
        assert removed < saved < not_loaded < event[0] < rolled_root < rolled_marker
        assert receipt['unload_begin_line'] == event[1]
        assert any(guard.EVENT_ERROR.search(line) for line in lines[removed:saved-1])
        duration = stamp(event[1])-stamp(lines[not_loaded-1])
        assert duration <= 60
        row['live'].update(root_removed=removed,after_removal_save=saved,not_loaded=not_loaded,
                           unload_begin=event[0],root_rolled_back=rolled_root,marker_rolled_back=rolled_marker)
        row['unload_coarse_log_seconds_after_false_predicate'] = duration
        row['observed_state'] = guard.chunk_state_observations(lines,saved)
    else:
        assert 'forceload remove 176 176' not in commands
        assert not any('ROLLED_BACK' in cmd for cmd in commands)
    phase_facts.append(row)

assert (HERE/'evidence/stopped-05/chunk-11-11.nbt.zlib').read_bytes() == original
stopped_forced = guard.check_forced_metadata((HERE/'evidence/stopped-05/chunks.dat').read_bytes(),False)
assert stopped_forced == phase_facts[-1]['forced_after']
capture = load('stopped-05/CAPTURE-01.json')
assert capture['compressed_record'] == pin(original)
assert capture['properties'] == pin((HERE/'evidence/stopped-05/server.properties').read_bytes())
properties = (HERE/'evidence/stopped-05/server.properties').read_text(encoding='utf-8')
assert 'gamemode=survival' in properties and 'online-mode=false' in properties
assert 'level-name=world' in properties and 'server-port=56848' in properties
assert all(load('NATIVE05-POSTCHECK-01.json').values()) and all(load('native-05/input-postcheck.json').values())
result = load('native-05.result.json')
assert result['exit'] == 0 and result['tested_commit'] == COMMIT and result['log'] == pin((HERE/'evidence/native-05.log').read_bytes())
out = {'source_commit':COMMIT,'java_commit':JAVA_COMMIT,'actual_outer_receipt':result,
       'identity_observations':observations,'artifacts':artifacts,'phases':phase_facts,
       'original_and_both_phase_and_stopped_terrain_identical':True,
       'typed_root_projection':typed_roots,'chunk_expanded_bytes':len(expanded),'native_tags':reader.tags,
       'stopped_forced':stopped_forced,'stopped_capture':pin((HERE/'evidence/stopped-05/CAPTURE-01.json').read_bytes()),
       'evidence_inputs':ledger,'reviewer_java_native_launches':0,
       'limitations':['BE disposal callbacks not instrumented','No cross-store/crash/first-save/client/Gate claim',
                      'Second host retriggers refusal; no second live target removal/unload cycle']}
(HERE/'AUDIT-01.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'outer_exit':result['exit'],'elapsed_seconds':result['elapsed_seconds'],
                 'identity':observations,'phases':[{'name':r['phase'],'commands':r['commands'],
                   'errors':r['refusal_headers']['event_bus_error_headers'],'unload_event_lines':[e['line'] for e in r['unload_events']]} for r in phase_facts],
                 'typed_roots':typed_roots,'original_record':pin(original),'reviewer_native_launches':0},indent=2))
