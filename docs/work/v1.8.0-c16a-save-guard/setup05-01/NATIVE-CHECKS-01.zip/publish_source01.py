"""Publish exactly reviewed SETUP05 source and scoped Root progress docs."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
sys.path.insert(0, str(ROOT))
from scripts import validate_repository as validator


def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


manifest = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/ags5-0a8c27de64/SOURCE-MANIFEST-02.json').read_text(encoding='utf-8'))
scope = list(manifest) + [
    'docs/work/v1.8.0-c16a-save-guard/COPIED-FORCED-SETUP-TASK-05.md',
    'docs/status/COMPLETION-PLAN.md', 'docs/work/v1.8.0-implementation-log.md',
]
assert len(scope) == 7
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == '6c3903de9e2b9119b4ef7b8b3115e9f4ef45287a'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
for name, expected in manifest.items():
    assert pin((ROOT / name).read_bytes()) == expected, name
source = json.loads((OUT / 'SETUP05-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, expected in source.items():
    assert pin((ROOT / name).read_bytes()) == expected, name
owned = {name: pin((ROOT / name).read_bytes()) for name in scope}
paths = sorted(set(validator.tracked_markdown_files(ROOT)) |
               {ROOT / name for name in scope if name.endswith('.md')})
errors, links = validator.markdown_link_errors(ROOT, paths)
assert not errors, errors
receipt = OUT / 'SOURCE-PUBLICATION-01.json'
assert not receipt.exists()
commands = []


def run(command, expected=0):
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = result.stdout.decode('utf-8', errors='replace')
    print(output, end='', flush=True)
    commands.append({'command': command, 'exit': result.returncode, 'output': output})
    assert result.returncode == expected, command
    return result.stdout


try:
    run([sys.executable, '-B', 'scripts/validate_v1plus_planning.py'])
    run([sys.executable, '-B', 'scripts/validate_v180_content_ledger.py', '--require-accepted'])
    run(['git', 'diff', '--exit-code', '--', 'src/generated'])
    run(['git', 'diff', '--check'])
    run(['git', 'add', '--'] + scope)
    assert set(run(['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == set(scope)
    for name, expected in owned.items():
        assert pin(subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT)) == expected, name
    run(['git', 'diff', '--cached', '--check'])
    run(['git', 'diff', '--cached', '--stat'])
    run(['git', 'commit', '-m', 'test(persistence): isolate copied nearby forced chunks'])
    head = run(['git', 'rev-parse', 'HEAD']).decode().strip()
    run(['git', 'push', 'origin', 'HEAD:refs/heads/codex/v1.8.0-classic-content'])
    assert run(['git', 'rev-parse', 'refs/remotes/origin/codex/v1.8.0-classic-content']).decode().strip() == head
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
    for name, expected in source.items():
        assert pin((ROOT / name).read_bytes()) == expected, name
finally:
    receipt.write_bytes((json.dumps({'scope': scope, 'owned_pins': owned,
        'named_source_inputs': len(source), 'commands': commands,
        'markdown_files': len(paths), 'markdown_links': links, 'markdown_errors': errors,
        'Java_rebuild': False, 'native_executed': False, 'required_gates_passed': False}, indent=2, sort_keys=True) + '\n').encode())
