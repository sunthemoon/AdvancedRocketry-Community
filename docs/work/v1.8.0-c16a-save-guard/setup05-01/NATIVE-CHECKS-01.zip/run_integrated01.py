"""Run actual Root Python integration checks without launching Java/native."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
TEMP = OUT / 'tmp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
manifest = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/ags5-0a8c27de64/SOURCE-MANIFEST-02.json').read_text(encoding='utf-8'))
for name, expected in manifest.items():
    data = (ROOT / name).read_bytes()
    assert {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == expected, name
source = json.loads(Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01/SOURCE25-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, row in source.items():
    if name not in manifest:
        data = (ROOT / name).read_bytes()
        assert {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == row, name
source.update({name: row for name, row in manifest.items() if name.startswith(('scripts/', 'tests/'))})
assert len(source) == 3009


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


command = [sys.executable, '-B', '-m', 'unittest',
    'tests.test_run_v180_guard_lifecycle_smoke', 'tests.test_run_v180_pump_smoke',
    'tests.test_run_v180_tank_smoke', 'tests.test_run_v180_signature_smoke']
write('python-01.command.json', {'command': command, 'cwd': str(ROOT),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'process_TEMP_TMP_TMPDIR': str(TEMP), 'uncommitted_development_check': True})
start = time.monotonic()
with (OUT / 'python-01.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
write('python-01.result.json', {'exit': result.returncode,
    'elapsed_seconds': time.monotonic() - start,
    'log_sha256': hashlib.sha256((OUT / 'python-01.log').read_bytes()).hexdigest()})
print((OUT / 'python-01.log').read_text(encoding='utf-8')[-1000:], flush=True)
assert result.returncode == 0
write('SETUP05-MANIFEST-01.json', source)
write('INTEGRATED-POSTCHECK-01.json', {'named_inputs': len(source),
    'changed_source': [name for name in manifest if name.startswith(('scripts/', 'tests/'))],
    'Java_artifacts_rebuilt': False, 'Java_base_commit': 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
    'reviewed_four_postimages_unchanged': True, 'actual_native': 'NOT_RUN',
    'required_gates_passed': False})
