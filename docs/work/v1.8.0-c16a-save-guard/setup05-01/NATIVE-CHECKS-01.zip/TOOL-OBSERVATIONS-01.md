# Native05 tool and cleanup observations

The strict two-process native driver exits 0. A later named Get-Content read
printed the entire large summary with typed byte arrays, so the tool truncated
that display. The original bounded receipt/summary files remain preserved and
are parsed selectively; no full displayed-summary proof is claimed.

The newly owned stopped copy has 265 regular files /211,865,779 bytes. Native
PowerShell precheck runs successfully: exact absolute target and ancestors,
no reparse entries, two clean host exits, captured fixed record/metadata and
no listener on port56848. The subsequent literal Remove-Item command is rejected
before OS execution with `blocked by policy`. It has no OS exit code and did
not remove the copy. No Python, alternate shell, elevation, hidden script or
different deletion mechanism is attempted. Logs, stopped fragments, source
world, original libraries/JARs and other agents/processes remain untouched.

The copy remains storage debt independently of the successful fixed native
test. Earlier blocked C scripts and native04 copies are not retried or called
cleaned. Only the new target was checked/attempted in this cleanup step.
