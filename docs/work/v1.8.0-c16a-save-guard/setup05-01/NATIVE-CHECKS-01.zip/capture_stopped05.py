"""Capture only fixed stopped native05 facts before owned-copy cleanup."""
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
RUNTIME = OUT / 'native-05/server'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
sys.path.insert(0, str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard

summary = json.loads((OUT / 'native-05/summary.json').read_text(encoding='utf-8'))
assert summary['result'] == 'PASS' and len(summary['cycles']) == 2
assert all(row['exit_code'] == 0 for row in summary['cycles'])
assert json.loads((OUT / 'native-05.result.json').read_text(encoding='utf-8'))['exit'] == 0
target = OUT / 'stopped-05'
assert not target.exists()
target.mkdir()


def pin(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


record = guard.saved_record(RUNTIME / 'world')
expected = (OUT / 'native-05/source-chunk-11-11.nbt.zlib').read_bytes()
assert record == expected
guard.check_fixture(guard.regions._decode_chunk(record, *guard.CHUNK))
(target / 'chunk-11-11.nbt.zlib').write_bytes(record)
forced = guard.read_forced_metadata(RUNTIME / 'world', False)
assert forced == summary['cycles'][-1]['forced_after_clean_stop']
for relative, name in (('world/data/chunks.dat', 'chunks.dat'), ('server.properties', 'server.properties')):
    shutil.copyfile(RUNTIME / relative, target / name)
    assert (RUNTIME / relative).read_bytes() == (target / name).read_bytes()
world = guard.worlds.inventory(RUNTIME / 'world')
(target / 'runtime-world-files.json').write_bytes((json.dumps(world, indent=2, sort_keys=True) + '\n').encode())
mods = {path.name: pin(path) for path in sorted((RUNTIME / 'mods').iterdir()) if path.is_file()}
result = {'qualification': 'Fixed native05 stopped capture; broader writer/client/Gates unverified',
    'result': 'STOPPED_CAPTURE', 'compressed_record': pin(target / 'chunk-11-11.nbt.zlib'),
    'compressed_record_equals_original': True, 'four_typed_roots_and_two_AIR_checked': True,
    'forced': forced, 'properties': pin(target / 'server.properties'), 'installed_mods': mods,
    'runtime_world_files': len(world), 'world_inventory': pin(target / 'runtime-world-files.json'),
    'actual_block_entity_disposal_callbacks': 'NOT_INSTRUMENTED',
    'cross_store_conservation': 'NOT_VERIFIED', 'crash_recovery': 'NOT_VERIFIED',
    'first_save_writer': 'NOT_VERIFIED', 'required_gates_passed': False}
(target / 'CAPTURE-01.json').write_bytes((json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
print(json.dumps(result), flush=True)
