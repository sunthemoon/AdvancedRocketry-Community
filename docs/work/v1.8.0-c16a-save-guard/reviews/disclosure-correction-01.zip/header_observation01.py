"""Record exact revised candidate and content-addressed first-header reconstruction."""
import hashlib
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
name = 'docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md'
raw = (R / name).read_bytes()
old = b'Date: 2026-10-04. Status: PROPOSED; factual disclosure review pending.'
new = b'Date: 2026-10-04. Status: PROPOSED; not ADR acceptance or risk approval.'
assert raw.count(new) == 1
before = raw.replace(new, old)
def meta(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
assert meta(raw) == {'bytes': 9207, 'sha256': 'f6ca5fd460346969c707b6fd0fb15b7ae4ea6ea2a45db002c9e498005ada3bad'}
assert meta(before) == {'bytes': 9205, 'sha256': 'c492b78947c6753be6bf15a35e22fdbd1e96d6acdda67e794945d72dbeb4c96a'}
(B / 'PROPOSAL-FIRST-OBSERVATION.md').write_bytes(before)
(B / 'PROPOSAL-FINAL-CANDIDATE.md').write_bytes(raw)
risk = (R / 'docs/11-RISK-REGISTER.md').read_bytes()
assert meta(risk)['sha256'] == '8216d438497ed9158db7f46d296dc426ef67f20d0a8fb937a397e6450c2e9133'
(B / 'RISK-CANDIDATE.md').write_bytes(risk)
result = {'before': meta(before), 'after': meta(raw), 'risk': meta(risk),
          'only_change': {'line': 3, 'before': old.decode(), 'after': new.decode()},
          'all_other_proposal_bytes_equal': before.replace(old, new) == raw,
          'first_snapshot_provenance': 'Reconstructed by exact inverse of root-reported header-only substitution; matches the complete initial observed SHA/size, not a retained initial raw-file copy.',
          'first_check': 'review-checks-01 exit 1; pin mismatch remains immutable',
          'repository_edits': 0}
(B / 'HEADER-OBSERVATION-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
