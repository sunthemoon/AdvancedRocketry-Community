"""Bounded candidate/source/provenance checks; no Java/native/risk acceptance."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import unittest

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
PRIOR = Path('D:/ARCE-Task-Evidence/v1.8.0/asrf-5ae80336d4')
C = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'
RISK = 'docs/11-RISK-REGISTER.md'
ADR = 'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md'
PROPOSAL = 'docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md'
PINS = {RISK: '8216d438497ed9158db7f46d296dc426ef67f20d0a8fb937a397e6450c2e9133',
        PROPOSAL: 'c492b78947c6753be6bf15a35e22fdbd1e96d6acdda67e794945d72dbeb4c96a'}
O = {'fixed_code_commit': C, 'observed_utc': datetime.now(timezone.utc).isoformat(),
     'checks_scope': 'candidate identity/source/provenance consistency only; not a runtime execution',
     'Java_native_launches': 0, 'repository_edits': 0, 'observations': {}}

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def row_partition(raw):
    lines = raw.splitlines(keepends=True)
    rows = [line for line in lines if line.startswith(b'| R-021 |')]
    assert len(rows) == 1
    return rows[0], b''.join(line for line in lines if not line.startswith(b'| R-021 |'))

class CandidateControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.preparation = json.loads((B / 'PREPARATION-01.json').read_text(encoding='utf-8'))
        cls.prior_inputs = json.loads((PRIOR / 'INPUT-EVIDENCE-01.json').read_text(encoding='utf-8'))
        cls.prior_verification = json.loads((PRIOR / 'VERIFY-04.json').read_text(encoding='utf-8'))
        cls.risk_raw = (R / RISK).read_bytes()
        cls.proposal_raw = (R / PROPOSAL).read_bytes()
        cls.proposal = cls.proposal_raw.decode('utf-8')
        cls.before_raw = (B / 'RISK-BEFORE.md').read_bytes()
        cls.row, cls.outside = row_partition(cls.risk_raw)
        cls.old_row, cls.old_outside = row_partition(cls.before_raw)
        cls.sources = {}
        for name, expected in cls.preparation['selected_code'].items():
            p = subprocess.run(['git', 'show', C + ':' + name], cwd=R, capture_output=True, timeout=60)
            assert p.returncode == 0, (name, p.stderr)
            assert meta(p.stdout) == expected['fixed_new']
            assert (R / name).read_bytes() == p.stdout, name
            cls.sources[name.split('advancedrocketrycommunity/', 1)[1]] = p.stdout.decode('utf-8')
        O['observations']['fixed_source_files_live_equal'] = len(cls.sources)

    def test_01_exact_candidate_pins(self):
        self.assertEqual(meta(self.risk_raw)['sha256'], PINS[RISK])
        self.assertEqual(meta(self.proposal_raw)['sha256'], PINS[PROPOSAL])
        self.assertEqual(len(self.proposal_raw), 9205)
        O['candidate_pins'] = {RISK: meta(self.risk_raw), PROPOSAL: meta(self.proposal_raw)}

    def test_02_only_one_risk_row_changed_exact_raw_bytes(self):
        self.assertEqual(self.outside, self.old_outside)
        self.assertNotEqual(self.row, self.old_row)
        self.assertEqual(self.row.count(b'|'), self.old_row.count(b'|'))
        O['observations']['outside_R021'] = {'before': meta(self.old_outside), 'after': meta(self.outside),
                                           'byte_equal': self.outside == self.old_outside,
                                           'changed_row_bytes_before': len(self.old_row),
                                           'changed_row_bytes_after': len(self.row)}

    def test_03_accepted_ADR_byte_identical(self):
        baseline = (B / 'ADR-BEFORE.md').read_bytes()
        actual = (R / ADR).read_bytes()
        self.assertEqual(baseline, actual)
        self.assertEqual(meta(actual)['sha256'], self.preparation['live_docs_before_candidate'][ADR]['sha256'])
        self.assertIn('status: ACCEPTED', actual.decode('utf-8'))
        O['observations']['accepted_ADR'] = {**meta(actual), 'unchanged': True}

    def test_04_source_saturation_and_lifetime_match_statement(self):
        denials = self.sources['persistence/ChunkSaveDenials.java']
        guard = self.sources['persistence/GuardedChunkSaves.java']
        self.assertIn('MAX_CHUNKS = 256', denials)
        self.assertIn('reasons.containsKey(chunk)) { return; }', denials)
        self.assertIn('reasons.size() == MAX_CHUNKS) { saturated = true; return; }', denials)
        self.assertIn('saturated ? Optional.of(SATURATED)', denials)
        self.assertIn('!(level.getServer() instanceof GameTestServer)', guard)
        self.assertIn('implements ICapabilityProvider {', guard)
        self.assertNotIn('INBTSerializable', guard)
        self.assertIn('state.close(); capability.invalidate();', guard)
        O['observations']['capacity_and_lifetime_source'] = 'same 256/sticky per-Level/no native reset source'

    def test_05_table_exact_four_modules_and_six_existing_ids(self):
        for module in ('TankProtection', 'PumpProtection', 'CombustionProtection', 'RecipeSignatureProtection'):
            self.assertIn(module, self.proposal)
        for name, text in self.sources.items():
            if name.endswith('Protection.java'):
                self.assertIn('GuardedChunkSaves.beforeSave(event)', text)
                self.assertIn('256 * event.getChunk().getHeight()', text)
        migration = self.sources['machine/recipe/RecipeSignatureMigration.java']
        self.assertIn('ROOT.equals(key) ? MAX_BYTES : 65_536', migration)
        self.assertIn('ROOT.equals(key) ? 16 : 20, ROOT.equals(key) ? 256 : 4_096', migration)
        for row in ('8,192 / 16 / 1,024', '1,024 / 16 / 256', '65,536 / 20 / 4,096'):
            self.assertIn(row, self.proposal)
        self.assertIn('not an implemented physical shared-hatch', self.proposal)

    def test_06_under_byte_native_preflight_qualification(self):
        nbt = self.sources['persistence/BoundedNbt.java']
        self.assertIn('node.depth() > maxDepth', nbt)
        self.assertIn('list.isEmpty() && list.getElementType() != Tag.TAG_END', nbt)
        self.assertIn('Float.floatToRawIntBits(value) != Float.floatToIntBits(value)', nbt)
        self.assertIn('source-preflight cases, not a claim that every', self.proposal)
        self.assertIn('such representation is reachable unchanged from a naturally loaded world.', self.proposal)

    def test_07_actual_historical_log_and_chunk_evidence_stays_qualified(self):
        history = self.prior_verification['observations']
        logs = history['historical_native03_log_headers']
        self.assertEqual(len(logs['EventBus']), 6)
        self.assertEqual(len(logs['ChunkMap']), 6)
        self.assertEqual(logs['total'], 12)
        self.assertFalse(logs['current_commit_native_proof'])
        self.assertIn('historical JAR is not relabelled as a current packaged-server execution', self.proposal)
        self.assertIn('nor a promise that every environment can produce only those two headers.', self.proposal)
        self.assertIn('not a\none-attempt-per-tick claim', self.proposal)
        self.assertIn('no guard-level total logging/retry quota', self.proposal)
        O['observations']['historical_actual_counts'] = {'EventBus': 6, 'ChunkMap': 6,
                                                       'host_sha256': logs['host_sha256'],
                                                       'new_native_execution': False}

    def test_08_primary_flow_unload_and_cross_store_are_not_transaction_claims(self):
        prior = self.prior_verification['observations']
        self.assertEqual(prior['terrain_write_order'], ['POI flush', 'dirty false', 'serialize',
                                                      'Forge Save event', 'region write'])
        self.assertTrue(prior['retry']['failed_write_does_not_set_that_cooldown'])
        self.assertIn('unload continuation ignores the save boolean', self.proposal)
        self.assertIn('not a\ncross-store transaction', self.proposal)
        self.assertIn('source-derived risk scenario, not a newly reproduced duplication/loss finding', self.proposal)
        self.assertIn('not per-chunk\ndurability acknowledgements', self.proposal)

    def test_09_owner_scope_and_unaccepted_amendment(self):
        for phrase in ('Status: PROPOSED', 'without changing save', 'accepting risk or editing other risk-register rows',
                       'does not alter the accepted ADR-064 revision 5',
                       'This proposal remains PROPOSED even if its factual disclosure review passes.'):
            self.assertIn(phrase, self.proposal)
        self.assertIn('授权仅同步 R-021 和 ADR 说明（推荐）', self.proposal)
        self.assertIn('No truncation, automatic discard, online reset or narrowed', self.proposal)
        self.assertIn('No working general diagnostic/repair tool, verified repair procedure or owner', self.proposal)
        self.assertIn('risk acceptance is supplied by this proposal.', self.proposal)

    def test_10_links_and_historical_report_pin(self):
        targets = []
        for target in re.findall(r'\]\(([^)]+)\)', self.proposal):
            self.assertFalse(re.match(r'^[A-Za-z]:', target))
            path = ((R / PROPOSAL).parent / target).resolve()
            self.assertTrue(path.is_relative_to(R.resolve()))
            self.assertTrue(path.is_file(), target)
            raw = path.read_bytes()
            self.assertEqual(meta(raw)['sha256'], '3d04a317ce519df1314fe642681af0fa50127c081e9ecddfcbfd053afb60bb87')
            targets.append({'target': target, **meta(raw)})
        self.assertEqual(len(targets), 1)
        risk_target = re.findall(r'\]\(([^)]+)\)', self.row.decode('utf-8'))
        self.assertEqual(risk_target, ['work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md'])
        O['observations']['candidate_direct_links'] = targets

if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CandidateControls))
    O['actual_result'] = {'tests': result.testsRun, 'failures': len(result.failures),
                         'errors': len(result.errors), 'skips': len(result.skipped)}
    (B / 'CANDIDATE-CHECKS-01.json').write_text(json.dumps(O, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    sys.exit(not result.wasSuccessful())
