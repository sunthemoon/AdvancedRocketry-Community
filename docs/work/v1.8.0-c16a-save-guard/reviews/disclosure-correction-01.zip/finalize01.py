"""Freeze loose scoped review evidence only; no ZIP/source export."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
C = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

checks = json.loads((B / 'CANDIDATE-CHECKS-02.json').read_text(encoding='utf-8'))
prep = json.loads((B / 'PREPARATION-01.json').read_text(encoding='utf-8'))
for name, expected in checks['candidate_pins'].items():
    assert meta((R / name).read_bytes()) == expected, name
adr = 'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md'
assert (R / adr).read_bytes() == (B / 'ADR-BEFORE.md').read_bytes()
for name, entry in prep['selected_code'].items():
    raw = subprocess.check_output(['git', 'show', C + ':' + name], cwd=R)
    assert meta(raw) == entry['fixed_new']
    assert (R / name).read_bytes() == raw
links = []
for text_name in ('REVIEW-01.md', 'FACTUAL-INTAKE.md'):
    text = (B / text_name).read_text(encoding='utf-8')
    for target in re.findall(r'\]\(([^)]+)\)', text):
        p = (B / target.split('#')[0]).resolve()
        assert p.is_relative_to(B.resolve()) and p.is_file(), target
        links.append({'source': text_name, 'target': target})
post = {'fixed_code_commit': C, 'source_count': len(prep['selected_code']),
        'relevant_code_live_equal': True, 'accepted_ADR_byte_equal': True,
        'candidate_pins': checks['candidate_pins'],
        'outside_R021_byte_equal': checks['observations']['outside_R021']['byte_equal'],
        'portable_own_links': len(links), 'repository_edits': 0,
        'new_findings': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0},
        'risk_accepted_or_closed': False, 'amendment_status': 'PROPOSED',
        'Java_native_launches': 0, 'zip_created': False}
(B / 'FINAL-POSTCHECK.json').write_text(json.dumps(post, indent=2) + '\n', encoding='utf-8')
files = {p.name: meta(p.read_bytes()) for p in B.iterdir() if p.is_file() and p.name not in
         ('EVIDENCE-MANIFEST.json', 'FINAL-RECEIPT.json', 'freeze-01.log', 'freeze-01.exit')}
manifest = {'scope': 'R-021 / proposed ADR explanation factual-only correction review',
            'fixed_code_commit': C, 'report_sha256': files['REVIEW-01.md']['sha256'],
            'files': dict(sorted(files.items())), 'file_count': len(files),
            'total_bytes': sum(v['bytes'] for v in files.values()),
            'prior_evidence_copied': False, 'no_zip_or_fullsource_exports': True}
(B / 'EVIDENCE-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for name, expected in files.items():
    assert meta((B / name).read_bytes()) == expected
receipt = {'directory': str(B), 'report': meta((B / 'REVIEW-01.md').read_bytes()),
           'manifest': meta((B / 'EVIDENCE-MANIFEST.json').read_bytes()),
           'files': len(files), 'bytes': manifest['total_bytes'],
           'risk_accepted_or_closed': False, 'amendment_status': 'PROPOSED', 'zip_created': False}
(B / 'FINAL-RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
