"""Read-only factual intake, fixed Git objects; no candidate verdict."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
PRIOR = Path('D:/ARCE-Task-Evidence/v1.8.0/asrf-5ae80336d4')
OLD = '3f3d62aed3980186fe0acc9592cf93ca436405fb'
NEW = '1ece7e9d2515003ca705b5634ef654a6bcae8f89'
EXPECTED = {
    'REVIEW-01.md': '3d04a317ce519df1314fe642681af0fa50127c081e9ecddfcbfd053afb60bb87',
    'EVIDENCE-MANIFEST.json': '373dc11496fb4e326f8eef66548ef5bafcf2eebce34356888d76ce696ae809a9',
}

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

for name, expected in EXPECTED.items():
    assert meta((PRIOR / name).read_bytes())['sha256'] == expected
manifest = json.loads((PRIOR / 'EVIDENCE-MANIFEST.json').read_text(encoding='utf-8'))
for name, expected in manifest['files'].items():
    assert meta((PRIOR / name).read_bytes()) == expected
prior_inputs = json.loads((PRIOR / 'INPUT-EVIDENCE-01.json').read_text(encoding='utf-8'))
sources = {}
for key, expected in prior_inputs['inputs'].items():
    if not key.startswith(OLD + ':'):
        continue
    name = key[len(OLD) + 1:]
    p = subprocess.run(['git', 'show', NEW + ':' + name], cwd=R, capture_output=True, timeout=60)
    assert p.returncode == 0, (name, p.stderr.decode('utf-8', errors='replace'))
    sources[name] = {'old': expected, 'fixed_new': meta(p.stdout),
                     'unchanged': meta(p.stdout) == expected}
    assert sources[name]['unchanged'], name
docs = {}
for name in ('docs/11-RISK-REGISTER.md',
             'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md'):
    raw = (R / name).read_bytes()
    docs[name] = {**meta(raw), 'observed_utc': datetime.now(timezone.utc).isoformat()}
    own = 'RISK-BEFORE.md' if 'RISK-REGISTER' in name else 'ADR-BEFORE.md'
    (B / own).write_bytes(raw)
    text = raw.decode('utf-8').splitlines()
    if 'RISK-REGISTER' in name:
        selected = [(i, l) for i, l in enumerate(text, 1) if l.startswith('| R-021 |')]
        assert len(selected) == 1
    else:
        start = next(i for i, l in enumerate(text, 1) if l.startswith('### 11.'))
        end = next(i for i, l in enumerate(text, 1) if i > start and l.startswith('### 12.'))
        selected = [(i, text[i-1]) for i in range(start, end)]
    docs[name]['selected_lines'] = [{'line': i, 'text': l} for i,l in selected]
result = {'fixed_code_commit': NEW, 'prior_code_commit': OLD,
          'prior_evidence_directory': str(PRIOR), 'prior_pinned_report_and_manifest': EXPECTED,
          'prior_manifest_entries_unchanged': len(manifest['files']),
          'selected_code': sources, 'live_docs_before_candidate': docs,
          'state': 'PREPARATION_ONLY_CANDIDATE_NOT_RECEIVED',
          'Java_native_launches': 0, 'repository_edits': 0,
          'risk_acceptance_or_behavior_choice': False}
(B / 'PREPARATION-01.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'fixed_code_commit': NEW, 'prior_manifest_entries_unchanged': len(manifest['files']),
                  'unchanged_selected_source_files': len(sources),
                  'doc_pins': {k:{x:v[x] for x in ('bytes','sha256')} for k,v in docs.items()},
                  'candidate_received': False}, indent=2))
