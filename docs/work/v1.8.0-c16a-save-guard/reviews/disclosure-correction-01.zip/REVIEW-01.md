# Independent R-021 / proposed ADR explanation correction review

## Findings first

**0 Critical / 0 High / 0 Medium / 0 Low new candidate findings.** No correction to the final candidate text is required by the inspected evidence. This disposition covers factual disclosure only; **R-021 is not accepted or closed, and the explanatory amendment remains PROPOSED**. The accepted ADR is unchanged. This is not source/API/writer/runtime or version-Gate admission.

The first exact-identity check failed when Root changed only the proposal header during review. That observation and the original 10-test/1-failure output are preserved, not marked PASS. The separately announced final candidate was then checked under a new entrypoint; final **10 tests / 0 failures/errors/skips**, exit 0.

## Exact reviewed inputs and scope

Fixed code reference: **`1ece7e9d2515003ca705b5634ef654a6bcae8f89`**, not moving HEAD or the subsequent K3 documentation commit. Relevant 18 guard/consumer/codec/test files are byte-identical to the original audit's `3f3d62aed3980186fe0acc9592cf93ca436405fb` objects and their live counterparts. No source/runtime changes were authorized or implemented by this review.

| Input | Bytes | SHA-256 |
|---|---:|---|
| Owner-edited risk baseline, [snapshot](RISK-BEFORE.md) | 3,937 | `fc84e8d2233cccba1abd009cdcb4eecad02f2921fc5f46126e6cf3e0ee32d0f5` |
| Final R-021 candidate, [snapshot](RISK-CANDIDATE.md) | 4,323 | `8216d438497ed9158db7f46d296dc426ef67f20d0a8fb937a397e6450c2e9133` |
| Accepted ADR-064 revision 5, [baseline](ADR-BEFORE.md) | 35,702 | `789522c7c982209df660745442ca96fa1f83cc57b29c7f9692b609219c7c37d0` |
| Final separate explanation proposal, [snapshot](PROPOSAL-FINAL-CANDIDATE.md) | 9,207 | `f6ca5fd460346969c707b6fd0fb15b7ae4ea6ea2a45db002c9e498005ada3bad` |
| First observed proposal, [content-addressed reconstruction](PROPOSAL-FIRST-OBSERVATION.md) | 9,205 | `c492b78947c6753be6bf15a35e22fdbd1e96d6acdda67e794945d72dbeb4c96a` |

Named repository candidates are `docs/11-RISK-REGISTER.md:25` and `docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md`. Root remains sole repository writer. The reported owner authorization is **“授权仅同步 R-021 和 ADR 说明（推荐）”**: no behavior change, risk acceptance, other-row change or policy selection. Proposal lines 8-13 and 152-162 preserve that limit.

Original independent audit report SHA `3d04a317ce519df1314fe642681af0fa50127c081e9ecddfcbfd053afb60bb87`, manifest SHA `373dc11496fb4e326f8eef66548ef5bafcf2eebce34356888d76ce696ae809a9`: all 36 original manifested entries remain unchanged. This reviewer authored that earlier impact audit and had separately reviewed the earlier Root-authored guard/native03 evidence; the present task is a separate document-correction review, not a fresh native replay or a review of this reviewer's own source implementation.

## Byte and semantic preservation

- Removing exactly the one R-021 row, including its original line ending, from each risk-register version leaves **3,215 identical bytes**, SHA `dab7044a8a8f7e20927fe5eb5a5dff15156be7ec0de0a7ea08f56ec02a362aa2`. All other rows, headings, risk rules, separators and line endings are byte-equal. The changed row is 722 -> 1,108 bytes; no broad normalization was used.
- Accepted ADR-064 is exactly byte-identical to the captured baseline. Its §11 ownership, limits, unsupported-root retention, backup repair requirement, supported work and prohibition of automatic unproved legacy conversion are not changed. The new text is a standalone **proposal**, not retroactive amendment acceptance or a claim that the accepted ADR already contains the new explanation.
- All 18 selected source/test objects remain exact at fixed commit `1ece7e9d…` and live-equal in final checks. This is the relevant guard/consumer boundary, not a claim of whole-tree verification or K3 runtime validation.
- The only proposal revision between the initial and final pins is line 3: `factual disclosure review pending` -> `not ADR acceptance or risk approval`. The [header observation](HEADER-OBSERVATION-01.json) proves the exact inverse substitution recovers the initially observed complete hash/size; the first snapshot is explicitly a content-addressed reconstruction, not misrepresented as an initial raw-file capture. No body/fact/scope bytes changed.

## Original findings reconciliation

### Original M1: affected scope and trigger set

Final R-021 row and proposal lines **28-87** now accurately disclose:

- Four current guard consumers and six BE types, including Rolling/Precision/Electrolyzer; the exact root byte/depth/node limits match existing codecs.
- Physical outgoing BE-list count and native fidelity/shape checks, not only byte overflow. Crafted typed-empty lists/foreign writers/NaN cases are explicitly not universal naturally loaded-world claims.
- Complete terrain-chunk record refusal at one ordinary remembered coordinate, not per-BE quarantine, whole-region rollback or a whole-world transaction.
- The 256 distinct-entry cap and **257th distinct-denial per-ServerLevel saturation**, including later healthy/unrecorded coordinates; duplicates do not advance capacity, other Levels are independent.
- Sticky Level capability lifetime, no production online reset, nonserialized guard state and fresh-Level creation not being a repair. The description does not invent a LevelEvent.Unload-to-close callback.

This addresses the missing facts in the **candidate disclosure**. It does not grant acceptance of the separate proposed ADR text or close the underlying serious rollback/cross-store risk.

### Original M2: logger quantity and retry/durability limit

Final row and proposal lines **89-113, 133-155** correct “one ERROR” to the actual historical **six EventBus + six ChunkMap ERROR headers with traces**, and preserve its historical cohort qualification. Guard files match the fixed code, but the historical JAR is not relabelled as a current server run. No exact universal logger count/rate is promised.

No guard-level retry/log total cap is claimed; failure does not acquire the successful-save cooldown, and holder/unload scheduling still governs attempts. Dirty eligibility does not cancel unload or prove durable resident state. Save-all returning normally, exit 0 and “All chunks are saved” are not coordinate acknowledgements. Independent POI/player/entity/SavedData paths remain explicit; cross-store divergence is a source-derived unexecuted scenario, not a newly reproduced current loss claim.

## Recovery and remaining limits

Proposal lines **115-155** preserve backup-based explicit repair as a requirement, not an implemented administrator tool or verified recovery procedure. The text does not select automatic stop/read-only, quarantine, online reset, truncation, conversion or discard policy. Escrow/source identity and outside-window/resource/restart verification are future prerequisites, not claimed completed work.

The mixed/new-coordinate, unload/lifetime, saturation/other-Level, cross-store, bounded logging and offline repair/native controls remain open. Historical byte preservation only establishes its particular tested record; K3 automatic regression is not substituted for those controls. This review does not independently audit K3's full automatic cohort, current source-world stores or all Gate statuses; candidate Gate-open statements are non-admission boundaries. No source, owner-mode, GuardTicket/shared-writer, physical hatch or universal native-fidelity approval follows.

## Actual commands and results

All commands write only this new small loose directory, `D:/ARCE-Task-Evidence/v1.8.0/ardr-301351e852`:

1. `python prepare01.py`: **exit 0**. [Raw log](prepare-01.log), [result](PREPARATION-01.json), [exit](prepare-01.exit). Original 36 evidence hashes, 18 fixed Git objects and two live document baselines checked.
2. `python review_checks01.py`: **10 tests / 1 failure / 0 errors/skips; exit 1**. [Raw log](review-checks-01.log), [result](CANDIDATE-CHECKS-01.json), [exit](review-checks-01.exit). Exact proposal pin assertion detected the subsequently announced header drift. The other nine checks passed; the overall command is not PASS.
3. `python header_observation01.py`: **exit 0**. [Raw log](header-observation-01.log), [result](HEADER-OBSERVATION-01.json), [exit](header-observation-01.exit). Final pins and exact header-only inverse comparison, no repository writes.
4. `python review_checks02.py`: **10 tests / 0 failures/errors/skips; exit 0**. [Raw log](review-checks-02.log), [result](CANDIDATE-CHECKS-02.json), [exit](review-checks-02.exit). Final candidate identity, outside-row bytes, accepted ADR equality, unchanged fixed sources, factual table/guard/primary-history qualifications, authority limits and direct report/proposal links checked. The linked original audit report is byte-exact, not a wrapper falsely carrying the original hash.

These are document/source/provenance consistency controls, not production Java tests, save/restart execution or risk acceptance. No Java/Gradle/native/client/network/process action, source/repository edit, commit/HEAD move, ZIP/full source/JAR export, private-bundle read or other-agent cleanup occurred.

## Final disposition

The exact final R-021 row and separate proposed explanation can be published within the allocated **factual correction-only** scope with no unresolved new findings from this review. Root alone owns publication/status and any later ADR decision. The proposal must remain PROPOSED; native/repair/operator policy, risk acceptance/closure and all persistence/version Gates remain separate. Completed work: bounded document review and evidence bundle. Uncompleted work: runtime changes, repair tool/workflow proof, current native validation and risk/Gate approval. Next work is only a separately authorized current-v1.8 R-021 policy/repair-validation slice, not implicit execution of this proposal.
