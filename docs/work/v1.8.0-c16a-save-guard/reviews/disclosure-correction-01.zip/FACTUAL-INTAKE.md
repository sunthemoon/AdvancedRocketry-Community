# R-021 / ADR explanation correction — factual intake only

State: **preparation; candidate documents have not arrived**. No severity/disposition or acceptance verdict is assigned to a not-yet-received delta.

Read-only baseline code is `1ece7e9d2515003ca705b5634ef654a6bcae8f89`, not moving HEAD. [Executed preparation](PREPARATION-01.json) independently verified that all 18 named guard/consumer/codec/test inputs from the original audit are byte-identical to original code `3f3d62aed3980186fe0acc9592cf93ca436405fb`; all 36 original evidence entries remain unchanged. Command exit: [0](prepare-01.exit), [raw log](prepare-01.log).

Original audit report SHA: `3d04a317ce519df1314fe642681af0fa50127c081e9ecddfcbfd053afb60bb87`; original manifest SHA: `373dc11496fb4e326f8eef66548ef5bafcf2eebce34356888d76ce696ae809a9`. They remain immutable, including their two Medium disclosure findings and all failed reviewer tools.

Named baseline document bytes copied for precise future outside-row/section comparison only:

- [Risk baseline](RISK-BEFORE.md): SHA `fc84e8d2233cccba1abd009cdcb4eecad02f2921fc5f46126e6cf3e0ee32d0f5`, 3,937 bytes; exactly one R-021 row.
- [ADR baseline](ADR-BEFORE.md): SHA `789522c7c982209df660745442ca96fa1f83cc57b29c7f9692b609219c7c37d0`, 35,702 bytes. Authoritative exact pin is in `PREPARATION-01.json`.

## Source-backed reconciliation facts

| Boundary | Actual baseline behavior / evidence | Candidate check to perform when received |
|---|---|---|
| Native unit | Save-event refusal prevents the complete outgoing terrain-chunk record from being written; not one BE or the entire region file. | Meaning must remain whole terrain-chunk refusal, with unrelated terrain changes not durably retained. |
| Saturation | `ChunkSaveDenials:9-29` remembers 256 distinct denied coordinates; the 257th distinct denial sets per-ServerLevel saturation, denying every subsequent coordinate there. Duplicates preserve first reason and do not advance capacity. | Actual per-coordinate versus Level-wide scope must be distinguishable, without silently changing the threshold/policy. |
| Lifetime | Level-owned, nonserialized capability; ordinary save/unload/BE replacement does not clear recorded denial. Fresh Level state starts empty; unchanged unsafe disk roots can trigger it again. | No claim of implemented production online reset, successful live repair acknowledgement or restart-as-repair. |
| Guard inventory | Tank, Pump, Combustion and Signature protection consumers; six BE IDs including Rolling/Precision/Electrolyzer. | Inventory cannot stop at three 8,192-byte resource BEs. |
| Trigger inventory | Byte, depth/node, native-fidelity/shape preflight, plus outgoing physical BE-list count; Signature marker 1,024/16/256, other three retained roots each 65,536/20/4,096. | Byte-only description is insufficient; candidate must not equate every bounded unsupported root with refusal. |
| Bounded unknown data | Supported and faithful bounded unsupported/future/corrupt roots can remain stored with repair-required refusal of active resource use/removal; unsafe roots use native chunk-write denial. | Existing ADR §11's retention, supported jobs and no automatic unproved-legacy conversion semantics must remain intact. |
| Exception path | Guard records denial, restores dirty flag, then throws IllegalStateException; ChunkMap catches Exception and returns false. Unload discards save result and can clear live BEs. | Dirty retry eligibility cannot be presented as durability, resident-data retention, or unload cancellation. |
| Logs | Original frozen Tank03 has six EventBus ERROR + six ChunkMap ERROR headers with traces, clean exit 0 and normal all-chunks-saved information; no guard retry/log quota. Common guard bytes are identical to both reviewed commits. | Historical measurement must retain its original JAR/scope; not falsely become native proof of the new commit or a guaranteed exact total for all environments. |
| Other stores | POI, Level SavedData, entity stores and players have independent paths; terrain refusal is not a cross-store transaction. | No claim of universal world/resource atomicity; unexecuted divergence scenarios remain qualified. |
| Recovery | Existing code has no ordinary-server guard clear/admin repair tool. Backup-based repair and restart are a proposed operator workflow, not implemented functionality. | Explanatory amendment cannot manufacture administrator authority, raw-data conversion/discard permission or complete repair/native validation. |

## Review boundaries

Owner scope supplied by Root is only synchronizing R-021 and a **proposed** ADR explanation amendment. It does not authorize save-behavior changes, R-021 acceptance/closure, other risk-row edits, implementation or Gate changes.

Future candidate checks: exact pre/post byte pins; removal of the single R-021 line yields identical remaining risk-register bytes; accepted ADR original bytes/meaning remain preserved where a separate proposed amendment is delivered; no semantic change to actual guard/consumer code or existing budgets; all remaining repair/native/operator questions clearly distinguished from factual clarification. Severity/disposition will come from the received actual text, not this checklist.

No Java/Gradle/native/client/network, source/repository edits, archive/full-source exports or private-bundle reads. Only this new small loose D-drive directory is writable. No candidate verdict, risk acceptance or Gate conclusion yet.
