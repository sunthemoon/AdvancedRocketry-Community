# ADR-064 — Classic machines, fluids and components (C16)

```yaml
status: ACCEPTED
revision: 5
date: 2026-10-04
deciders: [sunthemoon]
owner: sunthemoon
target_version: v1.8.0
slices: [C16a, C16b, C16c, C16d]
accepted_at: 2026-10-04
acceptance_basis: owner confirmed controller-owned resources, existing gas-giant nitrogen, retained Fluid banks and preservation without automatic migration for unproved legacy recipes; independently reviewed bounded menu compatibility and other amendments have no open Critical/High/Medium findings under the owner's conditional authorization
development_dependency: ADR-016, ADR-019, ADR-025, ADR-051, ADR-052, ADR-054, ADR-061, ADR-062, ADR-063
supersedes: ""
```

## Context

C16 delivers the classic machines every later batch crafts with: the machine
family with power, fluids, a tank and a pump (C16a), the electric arc furnace,
lathe and cutting machine (C16b), the crystallizer, chemical reactor, precision
laser etcher and centrifuge (C16c), and the circuit components, the recipe graph
tool and a progression rebalance (C16d). The 55 C16 ledger rows name the units.
Legacy facts, read from the pinned upstream commit (`c5cd5af`) as facts only:

- **Machines.** Each legacy machine is a LibVulpes `TileMultiblockMachine`: a
  controller block in a fixed structure of hatches (item input `I`, item output
  `O`, fluid input `L`, fluid output `l`, power input `P`), casings, motors and
  machine-specific parts (`tile/multiblock/machine/*.java`). Layouts, as
  layers × rows × columns: arc furnace 5 × 5 × 5 (a blast brick shell around
  coils and air, its hatches on the roof and the front); lathe 2 × 1 × 4;
  cutting machine 1 × 2 × 3 (a motor and a saw blade); crystallizer 2 × 2 × 3
  (six quartz crucibles over the hatches); chemical reactor 2 × 2 × 3 (a
  motor); precision laser etcher 3 × 3 × 3 (slabs, two structure towers, a
  vacuum laser, a motor); centrifuge 4 × 3 × 3 (advanced structure blocks,
  registered as `casingCentrifuge`, and a motor).
  A structure accepted any motor tier (`LibVulpesBlocks.motors`) and any coil
  (`blockCoil`).
- **Recipes** (`assets/advancedrocketry/recipes/*.json`, plus code in
  `util/RecipeHandler.java` and the machines' `registerRecipes`), as time in
  ticks × energy per tick:
  - arc furnace: steel from an iron ingot and charcoal (6,000 × 1); silicon
    ingot from sand (12,000 × 1); 3 titanium aluminide from 7 aluminum and
    3 titanium ingots (9,000 × 20); 2 titanium iridium from an iridium and a
    titanium ingot (3,000 × 20);
  - lathe: 2 rods from an ingot of each material (300 × 20);
  - cutting machine: 4 silicon wafers from a silicon boule, 4 basic circuits
    from a basic circuit plate, 4 advanced circuits from an advanced circuit
    plate (300 × 100); 6 planks from a log, including lightwood (80 × 10);
  - crystallizer: a gem from its dust, a boule from an ingot and a nugget
    (300 × 20); it stops above `crystalliserMaximumGravity` (default 0,
    disabled);
  - chemical reactor: 20 mB rocket fuel from 10 mB oxygen and 10 mB hydrogen
    (100 × 10); 8 bone meal from a bone and 10 mB nitrogen (100 × 1); a
    refreshed carbon scrubber cartridge and charcoal (40 × 20); a space suit or
    armor piece with the space protection enchantment from the piece, a pipe
    sealer and four titanium aluminide sheets (100 × 10, code);
  - precision laser etcher: 2 basic circuit plates from a gold plate, redstone
    dust and 4 wafers (1,200 × 400), 2 advanced plates with a redstone block
    (1,200 × 600), each with the etcher lens kept;
  - centrifuge: 1,000 mB of enriched lava into 1,000 mB of lava and up to four
    nuggets by chance (200 × 10), the chances from `lavaCentrifugeOutputs`
    (copper, iron, tin, lead, silver 100, gold 75, diamond, uranium 10,
    iridium 1);
  - eleven XML files in the config folder overrode or added recipes.
- **Fluids** (`AdvancedRocketry.java` 718–760): oxygen, hydrogen and nitrogen
  are gaseous (density −1,000, viscosity 1,000); rocket fuel (density 800,
  viscosity 1,500, light 2); enriched lava (density 3,000, viscosity 6,000,
  1,300 K, light 15). Each had a world block and a bucket; the gases rose.
  Volcanoes held enriched lava in their conduit and in a bulb of radius 23
  under it (`MapGenVolcano` 55–75); it was the centrifuge's input.
- **Tank** (`BlockPressurizedFluidTank`, `TileFluidTank`): 64,000 mB times
  `blockTankCapacity` (default 1.0); a tank passes its fluid down into the tank
  below; the item keeps the fluid.
- **Pump** (`TilePump`): a 16,000 mB tank and an energy buffer of 1,000; it
  looks straight down to the first non-air block and, if that is a Forge fluid
  block, searches connected blocks of that fluid up to 64 blocks away with no
  bound on the search, drains one source block per operation (100 energy),
  every tick above half power and every ten ticks below, and pushes up to
  1,000 mB per tick into neighbours. It checks no protection, and vanilla
  water and lava were not Forge fluid blocks, so it did not pump them.
- **Power.** A legacy install had the LibVulpes coal generator; Advanced
  Rocketry itself makes no power before the solar generator (C17c).
- **LibVulpes** (motors, casings, hatches, the coal generator) is not an
  approved source in v1.8 (ADR-061 §4.1); its numbers and art are not used.

The project already has the v1.2 machine kernel (ADR-016, ADR-019): bounded
process definitions and transactions, data patterns for multiblocks, physical
ports, the rolling machine, the precision assembler and the electrolyzer, the
`machine_casing` block, the five coil blocks (C15a) and `endgame_casing`.
Hydrogen and oxygen exist as canister items: the electrolyzer turns two empty
canisters and 1,000 mB of water into a hydrogen and an oxygen canister, the
gas giant mission yields hydrogen canisters, and oxygen vents and suits use
oxygen canisters. ADR-061 revision 7 (accepted in the C15 review continuation) lets kernel machine recipes
name items only until C16a, which must restore tag ingredients.

## Decision

### 1. Machine family (C16a)

1. **Structure.** Every classic machine is a multiblock on the v1.2 kernel: a
   controller block, a data pattern `machine_patterns/<machine>.json` with the
   legacy layout (§8, §9), four rotations and no mirroring. A motor cell
   accepts any block of the tag `advancedrocketrycommunity:motors` (§4), a coil
   cell any block of `advancedrocketrycommunity:coils`, a casing cell
   `machine_casing`, and a legacy `*` cell a casing or any family hatch.
2. **Hatches.** Five family blocks fill the legacy hatch cells:
   `item_input_hatch` and `item_output_hatch` (four slots each),
   `fluid_input_hatch` and `fluid_output_hatch` (one fluid, 16,000 mB each)
   and `power_input_plug` (10,000 FE). **Accepted ownership correction:** the
   controller owns every Item/Fluid bank, resource
   revision, process state and journal in the same chunk snapshot, as ADR-019
   requires. Item/Fluid hatches are generation-scoped facades, never a second
   persistent resource copy. At most 64 hatches bind to one controller; each
   binds to at most one machine (a conflict refuses formation). Capabilities
   require the exact loaded, formed binding and pause during a transaction.
   Unforming or unloading retains the banks at their controller. Breaking an
   Item hatch removes and drops its assigned Item bank at the controller once.
   Breaking a Fluid hatch retains its Fluid bank at that controller; a rebuilt
   corresponding hatch can access that same bank only after valid formation and
   a new exact instance/generation binding. The retained bank is not a resource
   copy in the removed or rebuilt hatch. Binding removal or generation changes
   alone never empty or duplicate it. Retained inactive banks count toward the
   existing 64-bank and 32,768-byte controller-resource limits. Their stable
   identity and assignment must be independently reviewed in the C16a-03 leaf
   contract before implementation; a rebuild cannot silently discard a bank or
   reassign its fluid to an unrelated hatch. Breaking the controller drops all
   remaining Items once and drains the remaining Fluids without spawning another
   resource copy. Removal of a bound hatch while its controller is unavailable
   or its root unsupported fails closed for ordinary players, explosions and
   Forge-aware entity destruction; it never loads that chunk. An unbound new
   hatch is empty.
   The power plug remains physically persistent: external/per-tick FE
   transfer is not covered by the Item/Fluid batch crash-atomicity claim.
   The rolling machine, precision assembler and electrolyzer keep their v1.2
   ports.
3. **Processing.** A machine runs one recipe at a time through the kernel:
   it looks up matching recipes in full resource-ID order, reserves
   nothing, draws the recipe's energy per tick from its plugs while running,
   and at the end moves inputs and outputs in one transaction, so a broken
   hatch or a full output pauses it without losing anything. Progress survives
   chunk unloads and restarts; unloading a hatch's chunk pauses the machine.
   A redstone signal at the controller pauses the machine, as it pauses the
   v1.2 machines.
   The seven new types have at most 1,024 recipes each (64 KiB per recipe),
   32 match checks per controller per tick and 256 per Level per tick through
   a fair resumable queue; the controller starts only after the current
   candidate set was checked. A reload invalidates pending lookup cursors.
   Idle machines enqueue only on input/formation/reload changes. Existing
   v1.2 types retain their ambiguity refusal rather than silently becoming
   first-match machines. Malformed or over-limit catalogs fail closed with
   bounded diagnostics; they do not discard a running process or its resources.
4. **Recipe types.** One recipe type per machine
   (`advancedrocketrycommunity:arc_furnace`, `lathe`, `cutting`,
   `crystallizing`, `chemical_reacting`, `laser_etching`, `centrifuging`),
   with a bounded codec: at most 4 item inputs and 4 item outputs, 2 fluid
   inputs and 2 fluid outputs, counts up to 64, fluid amounts up to 16,000 mB,
   time 1–72,000 ticks, energy 1–10,000 FE per tick, and (centrifuge only)
   chance outputs with a weight of 1–100. Unknown fields fail the recipe.
5. **Menus and JEI.** Each controller has a server-authoritative menu with the
   formed state, progress, energy and the reason it waits; there are no client
   actions besides opening. Each machine has a JEI category in the client
   compat package.

### 2. Tag ingredients after binding (C16a)

This ends the deviation of ADR-061 revision 7 for every kernel machine recipe,
the v1.2 rolling, precision and electrolyzer recipes included:

1. An item ingredient may name a tag again. A recipe keeps its JSON form; its
   tags resolve on first lookup after the server's tags are bound, and again
   after each tag reload, never when the recipe is parsed. A tag that resolves
   to more than 32 items (`ProcessInput.MAX_VARIANTS`) disables that recipe
   with a logged error until the next reload; the other recipes keep working.
2. The client receives recipes in their JSON form and resolves them against
   its own synced tags, for JEI only.
3. A running process stores the recipe's ID and a SHA-256 signature built from
   its validated JSON form, not from its resolved items: recursively sort
   object keys, keep array order, write validated integer values canonically
   and include all semantic fields (ingredients, outputs, chance candidates,
   time, energy and machine-specific flags). Insignificant whitespace/object
   key order does not change it. After a tag-only reload, a process whose
   recipe still exists **and whose JSON signature still matches** keeps running, and its
   inputs are checked against the current resolution when it completes; inputs
   that no longer match pause the machine with a stated reason, nothing is
   consumed and the progress is kept (the C15aR2-I1 condition).
   A same-ID recipe JSON/time/output change or removal preserves the original
   progress and resources but pauses with `recipe_changed`/`recipe_missing`;
   it is not mistaken for a tag-only reload or silently restarted.
4. Built-in recipes use the common tags (`forge:ingots/titanium`, …) wherever
   a material is meant: the v1.2 rolling recipes move to tags in C16a.
5. **Legacy signatures.** A new bounded `arce_recipe_signature` root
   (schema 1) marks the JSON-signature format for supported new jobs. An
   unmarked existing v1.2 progress/journal uses the legacy resolved-Item format.
   A resolved-Item hash, even together with a built-in recipe ID, cannot prove
   which authored JSON produced it: custom tag payloads may resolve identically.
   Where provenance cannot be proved, preserve the original progress, journal
   and resource roots, pause in an explicit repair-required state, and do not
   automatically convert or add the new marker. Do not re-plan a retained
   pending journal with current tags, reconcile it as a different new task,
   or treat an unmarked active/pending machine as an empty new machine. No
   migration-witness framework is added in this leaf. Supported new jobs store
   their signature and marker in the controller's same snapshot. S1 must cover
   all three v1.2 machines with unproved partial progress and pending journals,
   preserved resources and roots across two restarts, as well as supported new
   jobs and tag-only reload behavior. Automatic legacy conversion remains
   unavailable without separately reviewed provenance evidence and admission.

### 3. Combustion generator (C16a)

`combustion_generator`, one block: it burns furnace fuel (vanilla burn times)
at 40 FE per tick into a 20,000 FE buffer and pushes up to 1,000 FE per tick
into adjacent energy receivers. A coal therefore gives 64,000 FE. It burns only
while its buffer has room; a fuel with a container (a lava bucket) leaves the
empty container in its slot, as a furnace does. It has a menu (fuel slot,
burn time, buffer) and lights up while burning. The numbers are new: the
LibVulpes generator is not a source (ADR-061 §4.1), and 40 FE per tick covers
one arc furnace or lathe; the etcher needs ten generators or another mod's
power, which the recipe graph (§10) counts.

### 4. Motors and casings (C16a)

1. **Motors.** Four blocks, `motor`, `advanced_motor`, `enhanced_motor` and
   `elite_motor`, in the block and item tag `advancedrocketrycommunity:motors`.
   Every machine accepts any tier, as legacy; the tiers are crafting parts of
   later recipes (rocket engines, the nuclear core). Recipes (new): a motor
   from a copper coil, two steel plates, two iron rods and a steel ingot; each
   higher tier from the tier below, a coil of the next metal (gold, titanium,
   iridium) and two plates of that metal.
2. **Casings.** `machine_casing` (v1.2) is the legacy structure block.
   `endgame_casing` is the legacy advanced structure block: its display name
   becomes "Advanced Machine Casing" and later recipes that named the legacy
   advanced casing name it.

### 5. Fluids and canisters (C16a)

1. **Fluids.** `oxygen`, `hydrogen`, `nitrogen`, `rocket_fuel` and
   `enriched_lava` are Forge fluid types with the legacy colours, density,
   viscosity, temperature and light. Rocket fuel and enriched lava have source
   and flowing world blocks and buckets; enriched lava sets entities on fire as
   lava does. The three gases have no world block and no bucket: they live in
   tanks, hatches and canisters (the legacy rising gas blocks have no 1.20.1
   counterpart without a custom fluid engine).
2. **Canisters.** A canister is a fluid container of exactly 1,000 mB:
   `empty_canister`, `hydrogen_canister`, `oxygen_canister` and a new
   `nitrogen_canister`. Filling an empty canister with 1,000 mB of a gas
   swaps it for that gas's canister; emptying one returns an empty canister
   (the Forge item fluid handler, as a bucket). Tanks, fluid hatches and
   machines therefore exchange gases with canisters, and existing canisters
   keep their meaning for vents and suits (ADR-025).
   Existing canisters retain their stack limit of 16. A Fluid item handler
   mutates only a detached count-1 unit; direct fill/drain of a stacked
   container refuses both simulation and execution without changing it.
   Player/machine interaction splits one unit, performs its 1,000 mB swap,
   then rejoins/stows the result subject to ordinary inventory capacity,
   preserving every other unit. Tests cover 16-unit stacks, partial amount
   refusal, simulate/execute, full destination inventory and existing suit/
   vent oxygen use; no legacy stack is silently made unstackable or discarded.
3. **Nitrogen source (owner confirmed).** The data-only
   correction adds 8 nitrogen canisters per 1,000 ticks to the existing
   `advancedrocketrycommunity:gas_giant` table, retaining its 8 hydrogen
   canisters per 1,000 ticks. Oxygen retains its existing electrolyzer route.
   The owner confirmed use of the existing gas-giant table.
   Tau Ceti f remains landable and `gas_giant:false`: ADR-051/052 and both
   runtime eligibility checks reject a gas-harvest table there. Atmospheric
   harvesting on f is an alternative requiring an explicit amendment to both
   table and mission contracts, not a data-only change or a false body flag.

### 6. Pressurized tank (C16a)

`pressurized_tank`: one fluid, 64,000 mB times the COMMON value
`machines.tankCapacityMultiplier` (default 1.0, range 0.25–4.0, read when a
tank is created or loaded; a tank holding more than its capacity keeps the
fluid and accepts none). Buckets and canisters fill and empty it; it exposes
the fluid to automation on every side. A resource/neighbour change schedules
one deduplicated transfer for a later server tick, never a reentrant callback.
That transfer pulls at most 1,000 mB of compatible fluid from the loaded tank
directly above (one neighbour, no column scan); it schedules a later retry
only while both still permit transfer. At most one transfer per tank per tick
and 64 transfers per Level per tick use a fair queue. Dirty requests beyond
the queue's 1,024 entries stay dirty and retry on the bounded scheduler; they
are not silently lost. The item keeps the fluid and its amount, saved with a
schema version. External transfers between independently saved tanks retain
the normal Forge automation guarantee, not an arbitrary-crash atomicity claim.

### 7. Pump (C16a)

`pump`: a 16,000 mB tank, 10,000 FE buffer, 100 FE per source block. It looks
straight down at most 64 blocks to the first non-air block; if that is a
fluid, it searches connected blocks of that fluid breadth-first within 32
blocks horizontally and 64 vertically, at most 4,096 blocks per search and 64
per tick, through loaded chunks only. It drains one source block per
operation, every 5 ticks while it has the energy. Every candidate drain uses
the complete ADR-054 section 5 chain required by ADR-061 section 6: FULL
loaded chunk, world bounds, protected zones, station BUILD authority,
dedicated-server spawn protection, the cancellable public effect event and
the standard Forge block-break event through an owner-bound FakePlayer.
A refusal leaves the source, energy and tank unchanged and stops that search
with a stable reason code. Owner lookup is server-derived, never supplied by
a client or inferred from a nearby player. It never loads chunks, keeps no cache across unloads, pumps
vanilla water and lava (they are bucket fluids in 1.20.1) and pushes up to
1,000 mB per tick into adjacent fluid receivers. The owner is the player who
placed it; a pump without an owner (placed by a machine) drains nothing.

### 8. Arc furnace, lathe and cutting machine (C16b)

1. **Electric arc furnace.** The legacy 5 × 5 × 5 layout of `blast_brick`
   (new block: hardness 3, blast resistance 6), coils and air; the legacy
   recipes and numbers (§ Context). Steel needs charcoal, as legacy.
2. **Lathe.** The legacy 2 × 1 × 4 layout; 2 rods from one ingot of each
   material with rods (C15a, iron included; 300 ticks × 20 FE).
3. **Cutting machine.** The legacy 1 × 2 × 3 layout with a motor and
   `saw_blade` (new block); wafers and circuits (300 × 100) and planks from logs
   (80 × 10): DataGen writes one recipe of six planks per vanilla log and stem
   type and one for lightwood. Recipes marked `sawmill` stop while the COMMON
   value `machines.sawmillVanillaWood` (default on) is off. The iron saw blade
   item (`iron_saw_blade`) is the crafting part of the block.

### 9. Crystallizer, chemical reactor, etcher and centrifuge (C16c)

1. **Crystallizer.** The legacy 2 × 2 × 3 layout with six `quartz_crucible`
   blocks, each crafted from a `quartz_crucible_shell` item (the legacy
   `iquartzcrucible`); a gem from its dust and a boule from an ingot and a
   nugget (300 × 20): dilithium dust to dilithium crystal, silicon ingot and
   nugget to a silicon boule. The COMMON value
   `machines.crystallizerMaximumGravity` (default 0 = no limit, range 0–10)
   stops it where the gravity at the controller exceeds the value: the body's
   gravity multiplier, or the gravity of the station containing the controller.
   ADR-058 area fields are player/trust-list effects, not machine gravity;
   the machine never substitutes its owner or a nearby player. Field-driven
   machine gravity would require a separately frozen contract.
2. **Chemical reactor.** The legacy 2 × 2 × 3 layout; rocket fuel and bone
   meal with nitrogen with the legacy numbers. The carbon cartridge refresh
   waits for C18a's cartridge and the space protection recipe for C18b's
   enchantment; those batches add them to this recipe type.
3. **Precision laser etcher.** The legacy 3 × 3 × 3 layout with slabs (any
   block of `minecraft:slabs`); the legacy structure towers and vacuum laser
   were redesigned earlier (the tower into the rocket assembler in v0.5, the
   vacuum laser into the advanced casing and the laser lens in v1.7, ADR-055),
   so `machine_casing` fills the tower cells and `endgame_casing` the laser
   cell. The two circuit plate recipes keep the legacy numbers; the etcher lens
   is the v1.7 `laser_lens`, an input that stays in its hatch, as legacy.
4. **Centrifuge.** The legacy 4 × 3 × 3 layout with `endgame_casing` (the
   legacy `casingCentrifuge` was the advanced structure block);
   1,000 mB of enriched lava into 1,000 mB of lava and up to four nuggets by
   chance (200 × 10), the chances in the data recipe, not a config list: the
   legacy weights over the nuggets this mod and vanilla register (copper 100,
   iron 100, tin 100, gold 75, iridium 1); data packs add other mods' nuggets.
   Chance candidates are a separate ordered list of at most 16 entries, not
   the four deterministic Item outputs. At completion, test each candidate
   with one independent uniform 1-100 roll in JSON order and stop after four
   successes; merge identical Items without exceeding stack limits. Built-ins
   order copper, iron, tin, gold, iridium, so the cap makes iridium's effective
   chance 0.25 percent (gold must fail), a disclosed balance difference.
   The chosen outputs are recorded with the transaction ID in the controller
   snapshot/journal before application; a full output, retry or recovery
   reuses them and never re-rolls. Before a journal reaches `PREPARED`, a bank
   revision/input change discards only the stale before/after resource plan:
   re-simulate it against current resources/revisions with the retained chance
   outcome when the inputs match again. Missing inputs preserve progress and
   outcome while paused. Once `PREPARED`, ordinary bank mutation/removal is
   locked until that exact plan is committed or recovered; never re-plan a
   retained prepared journal. The etcher's retained lens uses
   a same-channel input debit and output restoration in that same transaction.
   The random seed derives from the machine UUID, recipe signature and
   monotone batch ordinal retained when a process starts; the same incomplete
   batch recomputes the same choices even if it stopped before saving a chosen
   plan. Ordinal overflow refuses a new batch rather than wrapping.
5. **Enriched lava source.** As legacy (`MapGenVolcano` 55–75, the conduit
   and the bulb under it), volcanoes hold enriched lava: from C16a the Venus
   volcano (ADR-063 §5) places enriched lava instead of lava in its core and
   crater pool, in volcanoes generated afterwards. A pump on a crater pool
   drains it for the centrifuge. Volcanoes generated before keep vanilla lava.

### 10. Components, recipe graph and rebalance (C16d)

1. **Components.** Basic and advanced circuit plates, the basic and advanced
   circuits, the tracking circuit, the control, item IO and liquid IO circuit
   boards, the user interface and the carbon brick, as items with the legacy
   recipes (machine and crafting), named by the legacy roles. The carbon brick
   is the legacy `ingotCarbon` and gets the tag `forge:ingots/carbon`.
2. **Recipe graph tool** (ADR-061 §5.3): a JUnit check over the generated data
   and the code-registered recipes that every registered item is obtainable
   in survival from a new world, counting energy (the combustion generator),
   Level access and discovery. Its report lists each item's first route. C16d
   also runs it with the Tau Ceti Levels removed (ADR-063 revision 6).
3. **Rebalance.** Existing v1.x recipes that the classic chain supersedes
   (for example the v1.2 precision recipes that stand in for circuits) move to
   the classic components where the graph shows a route; each change is listed
   in the CHANGELOG.

### 11. Persistence and migration

New roots are independent schema 1; existing shared process/journal schemas
do not change. The root names and limits below are persistence identities, not
registration placeholders. Every ID/string is bounded by the shared ID codec;
UUIDs are fixed-size and Item/Fluid payloads count toward the aggregate root
limit before capability insertion or recipe completion. Preflight also checks
the existing 65,536-byte journal limit; overflow pauses without consuming.

| Root | Fields and ownership | Maximum NBT bytes |
|---|---|---|
| `arce_classic_machine` | machine UUID, generation, monotone batch ordinal, at most 64 part positions/bindings, recipe ID, JSON signature, progress, refusal and chosen chance outputs | 65,536 |
| `arce_classic_resources` | controller-owned Item/Fluid banks and resource revision; at most 64 banks, four Item slots or one 16,000 mB Fluid per bank | 32,768 |
| `arce_classic_hatch` | machine UUID, controller position, generation, bank key; no Item/Fluid copy; a power plug additionally owns 0-10,000 FE | 4,096 |
| `arce_combustion_generator` | fuel/container slot, 0-20,000 FE, burn duration/remaining ticks 0-1,000,000 (over-limit fuel refused intact), schema | 8,192 |
| `arce_pressurized_tank` | Fluid ID/payload and nonnegative amount, retained capacity overflow, schema; same root in its dropped Item | 8,192 |
| `arce_pump` | owner UUID, Fluid tank 0-16,000 mB, FE 0-10,000, operation cooldown, schema; no persisted search frontier | 8,192 |
| `arce_recipe_signature` | recipe ID and format `json_v1`, format marker; same controller snapshot as new JSON-signature progress | 1,024 |

All resource roots round-trip, reject impossible counts and keep unsupported
future or corrupt roots verbatim in a bounded repair-required state: no ticking,
capabilities or ordinary removal may overwrite/drop an unrecognized resource
copy. Oversized on-disk input is refused without replacing the stored chunk;
repair requires an explicit administrator workflow against a backup. Unformed
machines keep controller-owned banks; transient search/lookup work is rebuilt
within its budgets after restart. No existing block, Item or SavedData changes
ID; the v1.2 recipes keep their IDs when they move to tags. The S1 fixture must
prove supported current-format save/restart and pending-journal recovery,
refusal and verbatim retention of unproved legacy progress/journals through
repeated restarts, unknown/future refusal, supported new JSON-signature jobs
and resource conservation separately. It must not claim legacy conversion
from resolved-hash matching alone.

### 12. Generated data and assets

DataGen writes every new model, blockstate, loot table, recipe, tag, pattern
and translation into the v1.8 root. Every C16 texture is drawn new (ADR-061
§4.2): the legacy machine textures and OBJ models are references only; the
asset plan rules for them become `REGENERATE`.

### 13. Tests

- A0: recipe codecs (bounds, unknown fields, chance weights), tag resolution
  after binding and the 32-variant limit, signatures from the JSON form, the
  canister fluid handler, the tank's capacity rule, the pump's search bounds,
  the generator's numbers; pattern JSON audits; DataGen determinism; the recipe
  graph (C16d).
- A1: each machine forms, runs a recipe, pauses on a full output or a removed
  hatch without loss, resumes after a restart and refuses a hatch bound to
  another machine; tag recipes run after a reload that changes the tag; the
  generator powers a machine; the tank passes fluid down and keeps it as an
  item; the pump drains a pool within its bounds, skips a protected block and
  stops at unloaded chunks; canisters fill and empty; the crystallizer stops
  above its gravity limit; the centrifuge's chances over 10,000 runs.
- S1: a packaged dedicated server runs each machine and the pump in a world
  upgraded from v1.7, with the existing rolling, precision and electrolyzer
  machines keeping their state.

### 14. Bounded recipe-reason menu compatibility (C16a)

Rolling, precision and electrolyzer menus gain display-only whitelisted reason
IDs:0 generic/none,1 recipe_missing,2 recipe_changed,3 recipe_tags_invalid,
4 signature_migration_pending,5 signature_migration_unproven,6 retained_plan_invalid.
Unknown subjects/IDs use the existing generic fallback;no arbitrary subject
string is transmitted and no reason authorizes work.

Register a required message-empty Forge channel
`advancedrocketrycommunity:machine_menu`,exact protocol `1`,during common setup
on both physical sides. Both predicates reject absent,vanilla and other versions.
Existing six channel names/protocols are unchanged. Clients and servers must
update together;this does not promise mixed v1.7/v1.8 compatibility or alter
world/process/resource schemas.

Append only one reason data slot:rolling24/count25,precision22/count23,
electrolyzer7/count8. Existing indices,enum IDs and structural/unsupported
precedence remain unchanged. Enforce exact data-count equality explicitly;
native checkContainerDataCount alone checks only a minimum.

The local opening payload is exactly BlockPos plus unsigned-byte schema2 and
the matching unsigned-byte menu count:10 bytes before unchanged Forge outer
framing. Reject absent,truncated,unsupported,mismatched or trailing payloads
before any usable menu is constructed. The opening writer,server data and
client allocation must agree. Future incompatible layouts require a reviewed
channel protocol change.

This technical amendment follows the independently reviewed
[proposal002](../work/v1.8.0-c16a-recipe-signatures/PROPOSED-CHANGE-002.md) under
the owner's conditional authorization. Actual implementation,registered-menu
and peer-refusal tests,localization,dedicated player flow and scheduled V1/V2
remain required;no runtime,client or Required Gate is admitted by this decision.

## Alternatives

### A. Port the LibVulpes hatches and generator

Keeps the legacy look, but LibVulpes is not an approved source (ADR-061 §4.1),
and a LibVulpes namespace would collide with a real port.

### B. Gases as rising world fluids

Restores placeable oxygen, but 1.20.1 fluids flow down; a rising fluid needs a
custom fluid engine for little gameplay.

### C. Machine-specific ports for every machine

Keeps the v1.2 port model, but needs twenty-eight port blocks for seven
machines; the shared hatches match the legacy and stay bounded by binding.

## Consequences

- The classic machines and their components exist before propulsion (C17) and
  life support (C18).
- Kernel recipes accept tags again; other mods' materials work in every machine.
- Gases are container fluids; canisters become 1,000 mB containers.

## Revisit when

- the owner prefers machine-specific ports or a different power source;
- a machine exceeds its tick budget;
- a later batch needs gases in the world.

## Review history

- Revision 1 (proposed, 2026-10-03): the C16 contract, before its
  independent review.
- Revision 1 independent review: 3 High and 7 Medium findings
  ([report](../work/v1.8.0-c16-contract/reviews/REVIEW-01.md)); changes requested.
- Revision 2 (proposed, 2026-10-03): resource ownership alternatives submitted
  to the owner; full pump protection, nitrogen eligibility, signature
  conversion, bounded deterministic lookup, positive FE, machine gravity,
  nonreentrant tank scheduling, chance-output persistence and stable bounded
  roots clarified. Resource ownership and the nitrogen source remain owner
  decisions; this revision is not a frozen implementation contract.
- Revision 2 independent review found no additional unresolved
  Critical/High/Medium technical issue; all original findings are answered
  ([report](../work/v1.8.0-c16-contract/reviews/REVIEW-02.md)). The owner then
  confirmed controller-owned Item/Fluid banks with cross-chunk structures and
  nitrogen on the existing gas-giant table. The conditional authorization
  therefore accepts revision 2. This freezes the C16 contract only: C16
  runtime and all version Gates still need implementation and evidence.
- Revision 3 (accepted, 2026-10-03): the owner selected retained controller
  Fluid banks after Fluid-hatch removal. The complete amendment and corrected
  absolute-position/exact-kind leaf identity were independently reviewed with
  no unresolved Critical/High/Medium findings
  ([acceptance record](../work/v1.8.0-c16a-hatches/ACCEPTANCE.md)). Other technical
  sections, IDs, schema versions and limits are unchanged. Actual API/codec,
  formation, recovery and native evidence remain required before runtime
  admission; no version Gate or cross-store FE crash guarantee is added.
- Revision 4 (accepted, 2026-10-03): the owner rejects automatic migration
  when legacy authored-JSON provenance cannot be proved. The section 2.5
  preservation policy and aligned section 11 root/test descriptions were
  independently reviewed with no open Critical/High/Medium findings. The first
  proposal's inconsistent conversion test requirement is corrected; no root
  size, schema or ownership bound changes. Existing unsupported tasks pause
  with original roots and resources, not a fabricated JSON marker. Actual
  source revision and native persistence still require separate evidence
  ([decision and proposal](../work/v1.8.0-c16a-recipe-signatures/LEGACY-POLICY-AMENDMENT.md)).
- Revision5 (accepted,2026-10-04):the exact bounded recipe-reason menu
  compatibility amendment has independently reviewed0 Critical/High/Medium/Low.
  The pinned Forge handshake advertises required empty channels;native count
  checks require explicit equality as above. This is technical contract
  acceptance under the owner's existing conditional authorization,not code
  or mixed-client evidence. Existing schemas/gameplay authority and six
  protocols are unchanged ([acceptance receipt](../work/v1.8.0-c16a-recipe-signatures/MENU-ACCEPTANCE-01.md)).
