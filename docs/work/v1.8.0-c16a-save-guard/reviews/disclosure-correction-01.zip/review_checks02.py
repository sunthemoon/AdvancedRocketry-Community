"""Independently check revised header identity; preserve original mismatch observation."""
from pathlib import Path

source = Path(__file__).with_name('review_checks01.py').read_text(encoding='utf-8')
changes = {
    'c492b78947c6753be6bf15a35e22fdbd1e96d6acdda67e794945d72dbeb4c96a':
    'f6ca5fd460346969c707b6fd0fb15b7ae4ea6ea2a45db002c9e498005ada3bad',
    'self.assertEqual(len(self.proposal_raw), 9205)': 'self.assertEqual(len(self.proposal_raw), 9207)',
    "'CANDIDATE-CHECKS-01.json'": "'CANDIDATE-CHECKS-02.json'",
}
for old, new in changes.items():
    assert source.count(old) == 1
    source = source.replace(old, new)
exec(compile(source, str(Path(__file__).resolve()), 'exec'))
