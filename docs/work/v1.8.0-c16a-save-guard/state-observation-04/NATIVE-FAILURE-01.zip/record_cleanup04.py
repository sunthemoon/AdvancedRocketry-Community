"""Record a rejected cleanup without attempting another deletion mechanism."""
import json
import os
from pathlib import Path

OUT = Path(__file__).parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
original = (OUT / 'CLEANUP04-PRECHECK-01.json').read_text(encoding='utf-8')
assert original.endswith('`n')
body = json.loads(original[:-2])
body['correction'] = ('The original precheck remains preserved; its single-quoted PowerShell newline '
                      'suffix was literal text, not JSON whitespace. Original facts are unchanged.')
corrected = OUT / 'CLEANUP04-PRECHECK-02.json'
assert not corrected.exists()
corrected.write_bytes((json.dumps(body, indent=2) + '\n').encode())
runtime = OUT / 'native-04/server'
assert runtime.is_dir()
result = {'action': 'BLOCKED_BY_TOOL_POLICY', 'os_deletion_executed': False,
          'target': str(runtime), 'target_still_exists': runtime.is_dir(),
          'retained_runtime_bytes_at_precheck': body['bytes'],
          'source_world_deleted': False, 'logs_and_compact_captures_retained': True,
          'alternate_deletion_attempted': False,
          'qualification': ('The checked native PowerShell Remove-Item command was rejected before OS '
                            'execution. Its preceding inline Python correction also failed native '
                            'argument quoting; this separate file only corrects the precheck metadata.')}
receipt = OUT / 'CLEANUP04-RESULT-BLOCKED-01.json'
assert not receipt.exists()
receipt.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result), flush=True)
