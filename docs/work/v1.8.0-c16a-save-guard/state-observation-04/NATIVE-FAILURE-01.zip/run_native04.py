"""Capture a fresh strict lifecycle attempt with the committed diagnostic artifact."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
SERVER = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/tank-native-06/server')
JAR = OUT / 'artifacts-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'
FIXTURE = SERVER / 'mods/arce-adapter-compat-test-1.0.0.jar'
TEMP = OUT / 'tmp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
assert not os.environ.get('JAVA_TOOL_OPTIONS'), 'Preserve and review existing Java options first'
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()


def pin(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size,
                'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


source = json.loads((OUT / 'SOURCE24-MANIFEST-01.json').read_text(encoding='utf-8'))
boundary = json.loads((OUT / 'SOURCE24-BOUNDARY-01.json').read_text(encoding='utf-8'))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
assert head == boundary['tested_commit'], 'Freeze the full-build source cohort before native execution'
assert len(source) == 2997
for name, row in source.items():
    assert pin(ROOT / name) == row, name
artifact = json.loads((OUT / 'ARTIFACTS-01.json').read_text(encoding='utf-8'))[JAR.name]
assert pin(JAR) == artifact
assert pin(FIXTURE) == {'bytes': 96772, 'sha256': '765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'}
libraries = json.loads((OLD / 'LIBRARIES-INPUTS-01.json').read_text(encoding='utf-8'))
assert len(libraries) == 104
for name, row in libraries.items():
    assert pin(SERVER / 'libraries' / name) == row, name
sys.path.insert(0, str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard

world = guard.worlds.inventory(SERVER / 'world')
assert len(world) == 139
record = guard.saved_record(SERVER / 'world')
assert len(record) == 5898
assert hashlib.sha256(record).hexdigest() == 'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
guard.check_fixture(guard.regions._decode_chunk(record, *guard.CHUNK))
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
write('NATIVE04-PRECHECK-01.json', {
    'source_commit': head, 'named_source_inputs': len(source), 'libraries': len(libraries),
    'world_files': len(world), 'main_artifact': artifact, 'fixture_artifact': pin(FIXTURE),
    'free_bytes': free, 'minimum_free_bytes': 10_000_000_000,
    'process_TEMP_TMP_TMPDIR': str(TEMP), 'process_JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS'],
    'world_setup_mutation': 'Existing copied spawn setup only; no removal of other forced marks',
})
command = [sys.executable, '-B', 'scripts/run_v180_guard_lifecycle_smoke.py',
           '--runtime-template', str(SERVER), '--source-world', str(SERVER / 'world'),
           '--host-jar', str(JAR), '--fixture-jar', str(FIXTURE),
           '--work-root', str(OUT / 'native-04'),
           '--java', 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe']
write('native-04.command.json', {'command': command, 'cwd': str(ROOT), 'tested_commit': head,
      'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
before = time.monotonic()
with (OUT / 'native-04.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
row = {'exit': result.returncode, 'elapsed_seconds': time.monotonic() - before,
       'log': pin(OUT / 'native-04.log'), 'tested_commit': head, 'required_gates_passed': False}
write('native-04.result.json', row)
post = {
    'source_inputs_unchanged': all(pin(ROOT / name) == value for name, value in source.items()),
    'source_libraries_unchanged': all(pin(SERVER / 'libraries' / name) == value for name, value in libraries.items()),
    'source_world_unchanged': guard.worlds.inventory(SERVER / 'world') == world,
    'main_artifact_unchanged': pin(JAR) == artifact,
    'fixture_artifact_unchanged': pin(FIXTURE) == {'bytes': 96772, 'sha256': '765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'},
    'tested_head_unchanged': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == head,
}
write('NATIVE04-POSTCHECK-01.json', post)
assert all(post.values()), post
print(json.dumps(row), flush=True)
print((OUT / 'native-04.log').read_text(encoding='utf-8')[-5000:], flush=True)
sys.exit(result.returncode)
