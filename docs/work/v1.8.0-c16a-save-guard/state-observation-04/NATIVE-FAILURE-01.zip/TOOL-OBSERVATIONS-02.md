# Additional tool and cleanup observations

The original TOOL-OBSERVATIONS-01 and all actual build/native results remain
unchanged. Additional exploratory reads guessed absent script names or a
candidate manifest subdirectory and produced lookup errors; named-file
discovery subsequently found the actual paths. These are tool intake errors,
not runtime behavior or passing verification.

The new stopped native-04/server copy was prechecked with native PowerShell:
exact resolved D project-parent path, no reparse points, no listening port,
260 regular files / 209,666,732 bytes and preserved compact captures. The first
precheck file ended with literal backtick-n because of a single-quoted newline;
its facts were emitted successfully, but the stored JSON suffix was malformed.
The first inline Python correction failed Windows native argument quoting with
SyntaxError. Neither original is silently overwritten; record_cleanup04.py
writes a separate corrected metadata file.

The checked native PowerShell Remove-Item -LiteralPath -Recurse command was
rejected by tool policy before OS execution. No runtime file was deleted and
no alternate deletion mechanism or escalation was attempted. The newly owned
copy remains cleanup debt, as do the previously blocked C scripts and old D
copies. Original source worlds, sealed evidence and other-agent files remain
untouched. New scripts/process temporary output still use the D project parent.
