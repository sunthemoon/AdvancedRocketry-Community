"""Preserve bounded post-abort observations, never upgrading the native failure."""
import gzip
import hashlib
import io
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
RUNTIME = OUT / 'native-04/server'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
sys.path.insert(0, str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard

receipt = json.loads((OUT / 'native-04/removal-availability-reload/receipt.json').read_text(encoding='utf-8'))
assert receipt['result'] == 'FAIL'
assert json.loads((OUT / 'native-04.result.json').read_text(encoding='utf-8'))['exit'] == 1
target = OUT / 'stopped-04'
assert not target.exists()
target.mkdir()
record = guard.saved_record(RUNTIME / 'world')
(target / 'chunk-11-11.nbt.zlib').write_bytes(record)
expected = (OUT / 'native-04/source-chunk-11-11.nbt.zlib').read_bytes()
assert record == expected
guard.check_fixture(guard.regions._decode_chunk(record, *guard.CHUNK))
for relative, name in [('world/data/chunks.dat', 'chunks.dat'), ('server.properties', 'server.properties')]:
    shutil.copyfile(RUNTIME / relative, target / name)
    assert (RUNTIME / relative).read_bytes() == (target / name).read_bytes()
nodes = []


class TypedReader(guard.tanks.NbtReader):
    def _payload(self, tag_type, depth):
        nodes.append({'tag_type': tag_type, 'depth': depth})
        return super()._payload(tag_type, depth)


compressed = (target / 'chunks.dat').read_bytes()
assert len(compressed) <= 1024
with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
    expanded = stream.read(4097)
assert len(expanded) <= 4096
root = TypedReader(expanded).read_root()
forced = []
for value in root['data']['Forced']:
    x, z = value & 0xffffffff, (value >> 32) & 0xffffffff
    forced.append([x if x < 0x80000000 else x - 0x100000000,
                   z if z < 0x80000000 else z - 0x100000000])


def pin(file):
    with file.open('rb') as stream:
        return {'bytes': file.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


world_inventory = guard.worlds.inventory(RUNTIME / 'world')
(target / 'runtime-world-files.json').write_bytes((json.dumps(world_inventory, indent=2, sort_keys=True) + '\n').encode())
mods = {file.name: pin(file) for file in sorted((RUNTIME / 'mods').iterdir()) if file.is_file()}
summary = {'qualification': 'Post-abort stopped-copy observation only; native04 remains FAIL',
           'result': 'OBSERVATION_ONLY', 'compressed_record_equal_to_original': record == expected,
           'compressed_record': pin(target / 'chunk-11-11.nbt.zlib'),
           'four_fixed_tank_roots_and_two_AIR_cells_checked': True,
           'forced_metadata': pin(target / 'chunks.dat'), 'forced_expanded_bytes': len(expanded),
           'forced_tag_nodes': nodes, 'saved_forced_cells': forced,
           'copied_server_properties': pin(target / 'server.properties'),
           'installed_mods': mods, 'runtime_world_inventory': pin(target / 'runtime-world-files.json'),
           'runtime_world_files': len(world_inventory), 'real_unload': 'NOT_OBSERVED',
           'live_restoration': 'NOT_EXECUTED', 'clean_stop': 'NOT_EXECUTED',
           'restart': 'NOT_EXECUTED', 'required_gates_passed': False}
(target / 'OBSERVATION-01.json').write_bytes((json.dumps(summary, indent=2, sort_keys=True) + '\n').encode())
print(json.dumps(summary), flush=True)
