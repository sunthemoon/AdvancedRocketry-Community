"""Fresh scoped checks preserve closure and global-diff failures as failures."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(OUT / 'tmp')
python = [sys.executable, '-B']
jobs = [
    ('common-client04', python + ['scripts/check_client_imports.py']),
    ('ledger-strict04', python + ['scripts/validate_v180_content_ledger.py', '--require-accepted']),
    ('ledger-closure04', python + ['scripts/validate_v180_content_ledger.py', '--closure']),
    ('planning04', python + ['scripts/validate_v1plus_planning.py']),
    ('provenance04', python + ['scripts/validate_bootstrap_provenance.py', '--require-approved-review']),
    ('machine-resources04', python + ['scripts/validate_v120_machine_resources.py']),
    ('artifact04', python + ['scripts/validate_build_artifact.py',
        str(OUT / 'artifacts-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'),
        '--expected-version', '1.20.1-1.8.0-dev']),
    ('generated-diff04', ['git', 'diff', '--exit-code', '--', 'src/generated']),
    ('diff-check04', ['git', 'diff', '--check']),
    ('dirty-diff04', ['git', 'diff', '--exit-code']),
]
rows = []
for name, command in jobs:
    log = OUT / (name + '-01.log')
    assert not log.exists()
    (OUT / (name + '-command-01.json')).write_bytes((json.dumps({
        'command': command, 'cwd': str(ROOT),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()
    }, indent=2) + '\n').encode())
    before = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode,
           'elapsed_seconds': time.monotonic() - before,
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    print(json.dumps(row), flush=True)
target = OUT / 'STATIC04-RESULTS-01.json'
assert not target.exists()
target.write_bytes((json.dumps({'jobs': rows, 'required_gates_passed': False}, indent=2) + '\n').encode())
unexpected = [row for row in rows if row['exit'] != (1 if row['name'] in ('ledger-closure04', 'dirty-diff04') else 0)]
sys.exit(bool(unexpected))
