"""Full committed diagnostic build with compact, immutable output capture."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
HERE = Path(__file__).parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
temp = HERE / 'tmp'
temp.mkdir(exist_ok=True)
for name in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[name] = str(temp)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']


def pin(path):
    return {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(name, value):
    file = HERE / name
    assert not file.exists(), name
    file.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
source_candidate = json.loads((HERE / 'SOURCE-CANDIDATE-01.json').read_text(encoding='utf-8'))
assert head != source_candidate['baseline_head'], 'The source must be committed first'
changed_source = source_candidate['source_files']
for name, expected in changed_source.items():
    assert pin(ROOT / name) == expected, name
    blob = subprocess.check_output(['git', 'show', head + ':' + name], cwd=ROOT)
    assert {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()} == expected, name
source = json.loads((OLD / 'SETUP03-MANIFEST-01.json').read_text(encoding='utf-8'))
assert len(source) == 2995
for name, expected in source.items():
    actual = pin(ROOT / name)
    assert actual == expected or name in changed_source, name
source.update(changed_source)
assert len(source) == 2997
write('SOURCE24-MANIFEST-01.json', source)
write('SOURCE24-BOUNDARY-01.json', {'tested_commit': head, 'named_inputs': len(source),
    'not_whole_repository': True, 'changed_or_new_source': list(changed_source),
    'previous_cohort': 'SETUP03-MANIFEST-01.json', 'new_C_paths_requested': False})
flags = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
         '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + str(temp).replace('\\', '/')]
jobs = [('full-build-01', flags + ['clean', 'build', 'test', 'runData']),
        ('gametest-01', flags + ['runGameTestServer'])]
rows = []
for name, command in jobs:
    free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
    assert all(value >= 10_000_000_000 for value in free.values()), free
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(name + '.command.json', {'command': command, 'cwd': str(ROOT),
        'started_utc': started, 'free_bytes': free, 'threshold_bytes': 10_000_000_000,
        'process_TEMP': str(temp), 'tested_commit': head})
    log = HERE / (name + '.log')
    assert not log.exists()
    before = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode, 'elapsed_seconds': time.monotonic() - before,
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    write(name + '.result.json', row)
    print(json.dumps(row), flush=True)
    if result.returncode:
        break
    if name == 'full-build-01':
        junit = HERE / 'junit-01'
        junit.mkdir()
        summary = {'suites': 0, 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
        for file in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
            shutil.copyfile(file, junit / file.name)
            suite = ET.parse(file).getroot()
            summary['suites'] += 1
            for key in ('tests', 'failures', 'errors', 'skipped'):
                summary[key] += int(suite.attrib[key])
        write('JUNIT-01.json', summary)
        assert summary['tests'] == 1773 and summary['suites'] == 331
        assert not any(summary[k] for k in ('failures', 'errors', 'skipped'))
        formatter = ET.parse(junit / ('TEST-io.github.sunthemoon.advancedrocketrycommunity.'
                                      'gametest.GuardedChunkDiagnosticTextTest.xml')).getroot()
        assert int(formatter.attrib['tests']) == 8
        artifacts = HERE / 'artifacts-01'
        artifacts.mkdir()
        captures = {}
        for suffix in ('', '-sources', '-api'):
            name = 'advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar'
            file = ROOT / 'build/libs' / name
            shutil.copyfile(file, artifacts / name)
            assert pin(file) == pin(artifacts / name)
            captures[name] = pin(artifacts / name)
        write('ARTIFACTS-01.json', captures)
    if name == 'gametest-01':
        for name in ('latest.log', 'debug.log'):
            file = ROOT / 'build/gametest/logs' / name
            assert file.is_file(), str(file)
            shutil.copyfile(file, HERE / ('gametest-01-' + name))
post = {name: pin(ROOT / name) for name in source}
mismatches = [name for name in source if source[name] != post[name]]
same_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == head
write('SOURCE24-POSTCHECK-01.json', {'named_inputs': len(source), 'mismatches': mismatches,
    'tested_head_unchanged': same_head, 'required_gates_passed': False})
write('FULL-CHECKS-01.json', {'commands': rows, 'tested_commit': head,
    'source_unchanged': not mismatches and same_head, 'required_gates_passed': False})
assert not mismatches and same_head
sys.exit(rows[-1]['exit'])
