"""Capture development checks without replacing any result or global environment."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
HERE = Path(__file__).parent
temp = HERE / 'tmp'
temp.mkdir(exist_ok=True)
for name in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[name] = str(temp)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
jobs = [
    ('python-01', [sys.executable, '-B', '-m', 'unittest',
        'tests.test_run_v180_guard_lifecycle_smoke', 'tests.test_run_v180_pump_smoke',
        'tests.test_run_v180_tank_smoke', 'tests.test_run_v180_signature_smoke', '-v']),
    ('targeted-java-01', [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
        '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + str(temp).replace('\\', '/'),
        'test', '--tests', '*GuardedChunkDiagnosticTextTest']),
]
rows = []
for name, command in jobs:
    log = HERE / (name + '.log')
    assert not log.exists()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (HERE / (name + '.command.json')).write_bytes((json.dumps({
        'command': command, 'cwd': str(ROOT), 'started_utc': started,
        'free_bytes': free, 'threshold_bytes': 10_000_000_000,
        'process_TEMP': str(temp), 'development_only': True,
    }, indent=2) + '\n').encode())
    begin = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    row = {'name': name, 'exit': result.returncode, 'elapsed_seconds': time.monotonic() - begin,
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    (HERE / (name + '.result.json')).write_bytes((json.dumps(row, indent=2) + '\n').encode())
    print(json.dumps(row), flush=True)
    if result.returncode:
        print(log.read_text(encoding='utf-8', errors='replace'), flush=True)
        break
(HERE / 'CHECKS-01.json').write_bytes((json.dumps({'development_checks': rows,
    'delivery_or_gate_claimed': False}, indent=2) + '\n').encode())
sys.exit(rows[-1]['exit'])
