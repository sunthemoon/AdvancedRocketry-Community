"""Rerun unchanged repository checks with only the owner's private inventory excluded."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
TEMP = OUT / 'tmp'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)


def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


if len(sys.argv) == 1:
    command = [sys.executable, '-B', str(Path(__file__).resolve()), '--child']
    write('repository04-command-01.json', {'command': command, 'cwd': str(ROOT),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'private_directory_read_or_walked': False, 'process_TEMP_TMP_TMPDIR': str(TEMP)})
    before = time.monotonic()
    with (OUT / 'repository04-01.log').open('xb') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    row = {'exit': result.returncode, 'elapsed_seconds': time.monotonic() - before,
           'log_sha256': hashlib.sha256((OUT / 'repository04-01.log').read_bytes()).hexdigest()}
    write('repository04-result-01.json', row)
    print(json.dumps(row), flush=True)
    sys.exit(result.returncode)

assert sys.argv[1:] == ['--child']
sys.path.insert(0, str(ROOT))
from scripts import validate_repository as validator

prefix = 'AdvancedRocketry-Community-v1plus-Development-Docs/'
original = validator._bounded_git_stdout
calls = []


def inventory(command, **kwargs):
    args = list(command)
    excluded = 'ls-files' in args and '--others' in args
    if excluded:
        args.append('--exclude=/' + prefix)
    output = original(args, **kwargs)
    if 'ls-files' in args:
        assert not any(name.decode('utf-8').startswith(prefix) for name in output.split(b'\0') if name)
    calls.append({'command': args, 'foreign_directory_excluded': excluded,
                  'stdout_bytes': len(output), 'stdout_sha256': hashlib.sha256(output).hexdigest()})
    return output


validator._bounded_git_stdout = inventory
sys.argv = [str(ROOT / 'scripts/validate_repository.py'), '--require-approved-identity']
code = validator.main()
write('repository04-boundary-01.json', {
    'validator_sha256': hashlib.sha256((ROOT / 'scripts/validate_repository.py').read_bytes()).hexdigest(),
    'exit': code, 'calls': calls, 'required_gates_passed': False})
sys.exit(code)
