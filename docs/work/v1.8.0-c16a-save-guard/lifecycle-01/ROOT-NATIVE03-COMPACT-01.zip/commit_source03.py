"""Publish the exact reviewed copy-only setup; native outcome remains FAIL."""
import hashlib
import json
import subprocess
from pathlib import Path
root=Path('D:/GitHub/AdvancedRocketry-Community')
here=Path(__file__).parent
scope={
 'scripts/run_v180_guard_lifecycle_smoke.py':'4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad',
 'tests/test_run_v180_guard_lifecycle_smoke.py':'e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16',
 'docs/work/v1.8.0-c16a-save-guard/COPIED-SPAWN-SETUP-AMENDMENT-01.md':'0a923ac5f7a372e851058fda9d41bc4c8dd290c575f2affa75f4ce8f950ce386',
}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='23bec1eb1452e8c8ef37c004606aaed3a2394063'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root).strip()
assert hashlib.sha256(Path('D:/ARCE-Task-Evidence/v1.8.0/agsr3-6746c51d09/REPORT.md').read_bytes()).hexdigest()=='3101a19df281029e37dd87f798842433e4f8d3c9d9e94d8a5d84afb7e2e2c885'
for name,digest in scope.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
rows=[]
def run(label,command):
 p=here/(label+'.log'); assert not p.exists()
 r=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 p.write_bytes(r.stdout)
 rows.append({'command':command,'exit':r.returncode,'log':p.name,'log_sha256':hashlib.sha256(r.stdout).hexdigest()})
 (here/'SOURCE-COMMIT-03.json').write_text(json.dumps({'scope':scope,'commands':rows,'native_result':'FAIL'},indent=2)+'\n',encoding='utf-8')
 print(r.stdout.decode('utf-8',errors='replace'),flush=True)
 assert r.returncode==0,label
run('source-add-03',['git','add','--',*scope])
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())==set(scope)
for name,digest in scope.items():
 assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=root)).hexdigest()==digest,name
run('source-index-check-03',['git','diff','--cached','--check'])
run('source-commit-03',['git','commit','-m','test(persistence): isolate copied spawn ticket setup'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
run('source-push-03',['git','push','origin','HEAD:codex/v1.8.0-classic-content'])
remote=subprocess.check_output(['git','rev-parse','origin/codex/v1.8.0-classic-content'],cwd=root,text=True).strip()
assert head==remote
(here/'SOURCE-COMMIT-PUSH-03.json').write_text(json.dumps({'commit':head,'origin_tracking':remote,'scope':scope,'commands':rows,'source_review_sha256':'3101a19df281029e37dd87f798842433e4f8d3c9d9e94d8a5d84afb7e2e2c885','native_result':'FAIL; not runtime delivery','gate_claimed':False},indent=2)+'\n',encoding='utf-8')
print(head,flush=True)
