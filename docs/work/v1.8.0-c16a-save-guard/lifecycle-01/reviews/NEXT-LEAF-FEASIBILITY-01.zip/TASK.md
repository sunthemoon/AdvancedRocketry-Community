# Fixed-head shared hatch next-leaf inspection

Delegated read-only worker. Root is sole integrator. Fixed Git input:
355c4681a6cbddd380545a50e0f6e524bad6d295.

Exclusive write_scope: this NEW small external D evidence directory only,
for named input hashes, static probe/result and report. No implementation,
Root/AGENTS/central/status/old packet writes, commits/pushes/HEAD moves, Java/
Gradle/native/server/client/network, cleanup, OpenPet or protected-bundle/live-
world read/walk. No whole source export or archive. Existing untracked records
and user-owned AGENTS changes remain untouched.

Outcome: identify a smallest source-backed implementation subleaf, its adopted
exact inventory/dependencies/proposed future write scope and verification;
separate a scope proposal from actual source/runtime/Required Gate acceptance.
