"""Named fixed-commit inputs, adopted inventory members and existence checks."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = '355c4681a6cbddd380545a50e0f6e524bad6d295'
DOCS = ['PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md','docs/04-VERSION-ROADMAP.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md','docs/05-MASTER-TEST-PLAN.md',
    'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md','docs/16-POST-1.0-VERSION-ROADMAP.md',
    'docs/17-V1PLUS-QUALITY-BUDGETS.md','docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md']
BASE = 'docs/work/v1.8.0-c16a-hatches/'
TASKS = ['VALUES-CODEC-TASK.md','GUARD-CARRIER-ACCEPTANCE-01.md','GUARD-INVENTORY-ACCEPTANCE-01.md',
    'OWNER-MODES-INVENTORY-ACCEPTANCE-01.md','TECHNICAL-CONTRACT-02.md','GUARD-INVENTORY-TASK.md',
    'CANONICAL-BYTES-TASK.md','CANONICAL-DIGEST-TASK.md','OWNER-POWER-MODES-02.md']
PREFIX = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
SOURCES = ['persistence/GuardedChunkSaves.java','persistence/ChunkSaveDenials.java','persistence/BoundedNbt.java',
    'machine/classic/adapter/ClassicRootBundle.java','machine/classic/adapter/OwnedNativeTag.java',
    'machine/classic/adapter/ClassicNbtKeyOrder.java','machine/classic/adapter/ClassicNbtCanonicalBytes.java',
    'machine/classic/adapter/ClassicNbtCanonicalHash.java','machine/classic/resource/ClassicResourcesCodec.java',
    'gametest/GuardedChunkSaveGameTests.java']


def pin(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def git(args):
    proc=subprocess.run(['git','-C',str(ROOT),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    return proc.stdout,{'command':['git','-C',str(ROOT),*args],'exit':proc.returncode,
                       'stdout':pin(proc.stdout),'stderr':proc.stderr.decode('utf-8')}


def main():
    inputs={}; commands=[]
    head,command=git(['rev-parse','HEAD']); commands.append(command)
    assert head.decode().strip()==COMMIT and command['exit']==0
    for name in DOCS+[BASE+n for n in TASKS]+[PREFIX+n for n in SOURCES]:
        frozen,command=git(['show',COMMIT+':'+name]); commands.append(command)
        assert command['exit']==0,name
        live=(ROOT/name).read_bytes()
        assert live==frozen,name
        inputs[name]={**pin(frozen),'fixed_commit':COMMIT,'current_disk_same':True}
    agents=(ROOT/'AGENTS.md').read_bytes()
    inputs['AGENTS.md']={**pin(agents),'external_owner_modified':True,'read_only':True}
    missing=[]
    for type_ in ('GuardTicket','ClassicRawPermit','ClassicAccessCoordinator','ClassicFrameCodec',
                   'ClassicChunkObservation','ClassicSaveProtection','ClassicControllerBlockEntity','ClassicHatchBlockEntity'):
        path=PREFIX+'machine/classic/adapter/'+type_+'.java'
        body,command=git(['cat-file','-e',COMMIT+':'+path]); commands.append(command)
        assert command['exit']!=0 and not (ROOT/path).exists(),path
        missing.append(path)
    zpath=ROOT/(BASE+'guard-inventory-owner-modes-amendment-01.zip')
    inputs[str(zpath)]={**pin(zpath.read_bytes()),'role':'exact adopted additive inventory, no source import'}
    assert inputs[str(zpath)]['sha256']=='2f87e34176689cf53fab74291a81d6ccccc60ddf2f6127c4c7bd58f7fdc4958f'
    with zipfile.ZipFile(zpath) as z:
        java=z.read('postimages/JAVA-SIGNATURES.md')
        schema=z.read('postimages/SCHEMA-PROPOSAL.json')
        contract=z.read('postimages/CONTRACT-PROPOSAL.md')
        members={name:pin(data) for name,data in [('postimages/JAVA-SIGNATURES.md',java),
            ('postimages/SCHEMA-PROPOSAL.json',schema),('postimages/CONTRACT-PROPOSAL.md',contract)]}
    assert pin(java)['sha256']=='8decf75d3ad1610c99241fd0795a3cdcb144b26cb58448861d6bdc6acb2ef366'
    assert pin(schema)['sha256']=='63557630c960312d02f8064aca29d63f52cd129f05d8cf27df62a45a7195f277'
    spec=json.loads(schema)
    protocol=spec['transient_ticket_protocol']
    assert protocol['purposes']==['capability','lifecycle','load','completion','recovery']
    observed=spec['transient_inventory']['new_transient_chunk_observation']
    assert observed['proposed_be_type_ids']==['advancedrocketrycommunity:classic_hatch','advancedrocketrycommunity:lathe']
    assert '256' in observed['max_records'] and 'height' in observed['max_records']
    expected='public static void recordObservedDenial(ServerLevel level, ChunkPos position, String reason);'
    assert expected in java.decode('utf-8')
    common=(ROOT/(PREFIX+'persistence/GuardedChunkSaves.java')).read_text()
    assert 'recordObservedDenial(' not in common and 'defer(' not in common and 'serverStopped(' not in common
    assert 'state(level).deny(event.getChunk().getPos().toLong(), reason);' in common
    assert 'MAX_CHUNKS = 256' in (ROOT/(PREFIX+'persistence/ChunkSaveDenials.java')).read_text()
    output={'fixed_commit':COMMIT,'inputs':inputs,'exact_adopted_members':members,'commands':commands,
        'missing_family_types':missing,'candidate_frozen_signature':expected,
        'ticket_purposes':protocol['purposes'],'observer_scope':observed,
        'feasibility_boundary':'Only an existing common denial-entry bridge has independent present types; full family codec/native hash requires real Guard authority',
        'negative_locator_observations':['Guessed common/persistence path absent; actual persistence package found by named tracked-file query'],
        'source_writes':False,'java_runtime_execution':False,'gate_claimed':False}
    target=HERE/'INPUT-PINS-AND-CHECKS-01.json'; assert not target.exists()
    target.write_bytes((json.dumps(output,indent=2)+'\n').encode())
    print(json.dumps({'named_inputs':len(inputs),'fixed_commit_equal':True,'missing_types':len(missing),
        'proposed_signature':expected,'result':pin(target.read_bytes())},indent=2))


if __name__=='__main__':
    main()
