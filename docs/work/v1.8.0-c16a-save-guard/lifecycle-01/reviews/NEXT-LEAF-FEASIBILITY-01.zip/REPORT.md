# Fixed-head next-leaf inspection

## Observations and scope recommendation

1. **The complete frame/native-resource codec is not an independent next implementation leaf.** At fixed `355c4681a6cbddd380545a50e0f6e524bad6d295`, K1/K2/K3 exist, but the eight named Guard/coordinator/frame/observer/family-BE types do not. `docs/work/v1.8.0-c16a-hatches/VALUES-CODEC-TASK.md:23-31` expressly defers guarded frame decode, native Item/Fluid decode and checkpoint crosschecks to a real private GuardTicket; it forbids a fake ticket, permissive stub or public structural-frame substitute. The pure canonical helpers confer none of that authority.

2. **A smallest present-type production subleaf is the early-denial entry bridge only:**

   ```java
   public static void recordObservedDenial(ServerLevel level, ChunkPos position, String reason);
   ```

   This exact signature is already in the adopted additive inventory, `guard-inventory-owner-modes-amendment-01.zip!postimages/JAVA-SIGNATURES.md:477-480`. Existing `persistence/GuardedChunkSaves.java:42-60` already accesses a Level-owned denial state and records a position before refusing an actual save. Existing `persistence/ChunkSaveDenials.java:17-29` provides bounded sticky first-reason retention. Thus this one method can expose that existing operation without a Save event, chunk lookup/load, native decoding, ticket factory, new BE or schema. It is a proposed separable implementation scope, **not an implementation, acceptance or priority decision**. Root has since selected an existing-policy diagnostic native test first; its unprovided script/results are outside this inspection.

3. **The surrounding lifecycle remains unimplemented and must not be inferred from that bridge.** The same inventory separately names `defer` and `serverStopped`; observer/coordinator/ticket methods and two managed BE IDs are technical inventory, not existing runtime. The observer admission requires actual LevelChunk/provider identity, bounded load records, first-save missing-entry checks and final-unload retention (`JAVA-SIGNATURES.md:457-492`; exact observer fields are captured in the input receipt). A method recording a denial does not establish how an observer obtained it, event ordering, shutdown disposal, nonsticky busy deferral or disk nonreplacement. No such method or callback is implemented here.

## Frozen authority and dependencies

- `TECHNICAL-CONTRACT-02.md:21-29` reserves common save/events to Root and requires independent leaf review/tests/native checks. Its dependency sequence is values/codecs, guarded access, formation, then lathe; the explicit phase split above prevents reading this sequence as permission to fabricate the missing guard.
- `GUARD-CARRIER-ACCEPTANCE-01.md:21-33` admits the bounded raw-observation/first-save/sticky-denial technical contract, but does not itself freeze inventory or admit writer/native behavior.
- `GUARD-INVENTORY-ACCEPTANCE-01.md:23-41` and `OWNER-MODES-INVENTORY-ACCEPTANCE-01.md:25-44` preserve five ticket purposes, twelve roots, Bank APIs and ceilings. Charged operation eligibility and unimplemented server creative ingress remain separate. No power/carrier policy change is needed for the one-method bridge.
- Accepted ADR-064 revision 5, `docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md:107-136,411-423`, requires controller-owned banks, unsupported/unprovable retention and whole-chunk nonreplacement for unsafe emission; it does not permit current-ID/hash inference, arbitrary loading or budget expansion.
- Existing denial limits are **256 distinct chunks and 256 reason characters**, not an invented new subject/schema budget (`ChunkSaveDenials.java:9-24`). Closed state remains fail-closed, and exceeding capacity saturates Level-wide refusal without eviction. Provider invalidation closes the existing state (`GuardedChunkSaves.java:75-81`).

## Proposed future write scope and verification

If Root later assigns the bridge, the narrow source scope is one added method in existing `persistence/GuardedChunkSaves.java`, a new focused registered GameTest file, and that leaf's records. Existing registration/capability lifetime, common state limits, production consumers, private Guard/family types, frame codecs, IDs, schemas, network, power/removal and central status remain unchanged. Root is the sole implementation writer; this task supplies no patch.

Verification must retain existing `ChunkSaveDenialsTest.java` five methods and `GuardedChunkSaveGameTests.java:17-57` two real-Level bridge tests. Add real-Forge checks that early recording needs no Save event, later empty/replacement-chunk serialization is refused with the original reason, the denied chunk is made unsaved by the existing save bridge, and unrelated chunks/Level states remain writable. Reject invalid reasons and preserve exact limits; test saturation in isolated pure state, not by permanently saturating a shared GameTest Level. No forced chunk loading or online production reset may be added. Root's actual compile/scoped tests, full build/DataGen/full GameTests and independently reviewed native stopped-region tests remain future evidence. The existing tests and this read-only probe do not prove first-save omission handling, shutdown disk safety, arbitrary-crash atomicity, the open save-risk item R-021, or any Required Gate.

## Actual checks and limitations

- Named static probe exit **0**: 32 input pins; every named tracked live input matched its fixed commit object; adopted inventory ZIP/member hashes verified; eight expected missing types recorded. Exact commands/exits are in [input checks](INPUT-PINS-AND-CHECKS-01.json), with [command](static-01-command.json), [raw output](static-01.log) and [result](static-01-result.json).
- Final pin probe exit **0**: HEAD remains fixed; all 30 prior named tracked inputs unchanged; the five-method denial unit-test source matches its fixed object. This is source inspection, not test execution ([final checks](FINAL-PIN-CHECK-01.json), [raw output](static-02.log), [result](static-02-result.json)).
- A guessed `common/persistence` directory lookup failed before the corrected actual `persistence` package read; this is retained as a locator observation, not a test/source failure. The supplemental final pin check is recorded separately.
- Read only named project/version/parallel/acceptance/source inputs and the three named adopted inventory members. No protected bundle, source export, old evidence edits, Java/Gradle/GameTest/native/client, cleanup, commit or push. Only this small external evidence directory was written.
- Root's diagnostic-native priority is a later coordination instruction; its exact script, mutation bounds, pinned current/old JARs and actual outputs still require independent intake. No result for that future test or source verdict for missing implementation is asserted.

## Input identity

Fixed code/docs: `355c4681a6cbddd380545a50e0f6e524bad6d295`. Live user-owned AGENTS was read and separately pinned, not treated as a fixed-object implementation delta.

Adopted inventory ZIP: `2f87e34176689cf53fab74291a81d6ccccc60ddf2f6127c4c7bd58f7fdc4958f`.

Exact Java inventory member: `8decf75d3ad1610c99241fd0795a3cdcb144b26cb58448861d6bdc6acb2ef366`.

Exact schema inventory member: `63557630c960312d02f8064aca29d63f52cd129f05d8cf27df62a45a7195f277`.

Full named input hashes, limits and expected absence observations: [INPUT-PINS-AND-CHECKS-01.json](INPUT-PINS-AND-CHECKS-01.json). No whole-version completion recommendation is made.
