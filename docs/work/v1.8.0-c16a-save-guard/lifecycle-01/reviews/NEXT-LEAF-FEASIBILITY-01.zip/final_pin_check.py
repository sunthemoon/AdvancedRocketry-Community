"""Read-only fixed-head recheck and pin the supplemental named unit-test input."""
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = '355c4681a6cbddd380545a50e0f6e524bad6d295'

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

commands = []
def git(args):
    p = subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True)
    commands.append({'command': ['git', '-C', str(ROOT), *args], 'exit': p.returncode,
                     'stdout': pin(p.stdout), 'stderr': p.stderr.decode('utf-8')})
    assert p.returncode == 0
    return p.stdout

assert git(['rev-parse', 'HEAD']).decode().strip() == COMMIT
prior = json.loads((HERE / 'INPUT-PINS-AND-CHECKS-01.json').read_bytes())
checked = 0
for name, expected in prior['inputs'].items():
    if expected.get('fixed_commit') == COMMIT:
        assert pin((ROOT / name).read_bytes())['sha256'] == expected['sha256'], name
        checked += 1
name = 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/ChunkSaveDenialsTest.java'
frozen = git(['show', COMMIT + ':' + name])
assert frozen == (ROOT / name).read_bytes()
assert frozen.count(b'@Test') == 5
out = {'fixed_commit': COMMIT, 'prior_named_tracked_inputs_unchanged': checked,
       'supplemental_test_input': {name: pin(frozen)}, 'test_methods_observed': 5,
       'commands': commands, 'source_writes': False, 'java_executed': False,
       'native_executed': False, 'tests_replayed': False}
target = HERE / 'FINAL-PIN-CHECK-01.json'
assert not target.exists()
target.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps(out, indent=2))
