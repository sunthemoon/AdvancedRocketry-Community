"""Seal only this small owned loose evidence directory; no source/archive export."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).parent
manifest = HERE / 'MANIFEST.json'
sums = HERE / 'SHA256SUMS.txt'
assert not manifest.exists() and not sums.exists()
files = {}
for path in sorted(HERE.iterdir()):
    assert path.is_file(), str(path)
    body = path.read_bytes()
    files[path.name] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
report = (HERE / 'REPORT.md').read_text(encoding='utf-8')
links = re.findall(r'\]\(([^)]+)\)', report)
assert all((HERE / link).is_file() for link in links)
result = {'format': 'loose-evidence-manifest-v1', 'fixed_commit':
          '355c4681a6cbddd380545a50e0f6e524bad6d295', 'files': files,
          'payload_count': len(files), 'payload_bytes': sum(v['bytes'] for v in files.values()),
          'report_relative_links': len(links), 'missing_report_links': 0,
          'scope': 'read-only next-leaf inspection; no implementation or runtime admission'}
manifest.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
entries = dict(files)
body = manifest.read_bytes()
entries['MANIFEST.json'] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
sums.write_bytes((''.join(f"{v['sha256']}  {name}\n" for name, v in sorted(entries.items()))).encode('ascii'))
print(json.dumps({'manifest_sha256': entries['MANIFEST.json']['sha256'],
                  'report_sha256': files['REPORT.md']['sha256'],
                  'checksum_sha256': hashlib.sha256(sums.read_bytes()).hexdigest(),
                  'payload_count': result['payload_count'], 'payload_bytes': result['payload_bytes'],
                  'relative_links': len(links)}, indent=2))
