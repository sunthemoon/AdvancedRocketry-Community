"""Named, bounded source intake and Python tests; no Java/native launch."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
HEAD = 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce'
PREVIOUS = Path('D:/ARCE-Task-Evidence/v1.8.0/aglr2-b87bf6b735')
CANDIDATE = {
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java': 'a426612fd9986b871d7930fa413b8ad0ade1e994d911c901c3f87e3b313fdd87',
    'scripts/run_v180_guard_lifecycle_smoke.py': '544e25035fe5554994bc812727ed0bbe6e5d5e24a0165607f4d95b1dd0e67a30',
    'tests/test_run_v180_guard_lifecycle_smoke.py': '3fa8716ed3682b94b750e533d2b7462266a0912246079b74e8ae5985b2737ea9',
    'docs/work/v1.8.0-c16a-save-guard/UNLOAD-OBSERVATION-AMENDMENT-01.md': None,
}
EXTRA = ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/command/ReleaseTestCommands.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/ModIdentity.java']
def pin(path):
    data = path.read_bytes(); return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2,sort_keys=True)+'\n',encoding='utf-8')
def run(name, args):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
    with (OUT/(name+'.log')).open('wb') as log:
        result = subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    write(name+'.json', {'command': args,'cwd': str(ROOT),'started_utc': started,
                        'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'elapsed_seconds': time.monotonic()-tick,'exit_code': result.returncode,
                        'log': pin(OUT/(name+'.log'))})
    print(name,result.returncode,(OUT/(name+'.log')).read_text(encoding='utf-8'))
    return result.returncode

def intake():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == HEAD
    prior = json.loads((PREVIOUS/'INPUTS-02.json').read_text(encoding='utf-8'))['files']
    names = list(dict.fromkeys(list(prior) + list(CANDIDATE) + EXTRA))
    before = {name: pin(ROOT/name) for name in names}
    for name, expected in CANDIDATE.items():
        if expected: assert before[name]['sha256'] == expected
        target=OUT/'candidate'/name; target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/name).read_bytes())
    diffs=[]
    for name in ['scripts/run_v180_guard_lifecycle_smoke.py','tests/test_run_v180_guard_lifecycle_smoke.py']:
        old=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)
        target=OUT/'preimages'/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(old)
        assert pin(target) == prior[name]
        diffs += difflib.unified_diff(old.decode('utf-8').splitlines(True),(ROOT/name).read_text(encoding='utf-8').splitlines(True),
                                     fromfile='a/'+name,tofile='b/'+name)
    (OUT/'ACTUAL-PYTHON-DIFF.patch').write_text(''.join(diffs),encoding='utf-8')
    write('INPUTS-01.json', {'head': HEAD,'files': before,'candidate_files': list(CANDIDATE),
                           'previous_review': pin(PREVIOUS/'REVIEW-02.md'),'Java_launches': 0})
    return before

if __name__ == '__main__':
    before=intake()
    result=run('scoped-01',[sys.executable,'-B','-m','unittest',
                          'tests.test_run_v180_guard_lifecycle_smoke','tests.test_run_v180_tank_smoke'])
    after={name: pin(ROOT/name) for name in before}
    write('POSTCHECK-01.json',{'files': after,'changed': [name for name in before if before[name]!=after[name]]})
    assert before == after
    sys.exit(result)
