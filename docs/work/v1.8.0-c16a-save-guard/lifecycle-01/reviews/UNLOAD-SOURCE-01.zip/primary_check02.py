"""Reparse exact named cached classfiles; retain semantic facts, never bodies."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
CONTEXT=Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae')
def pin(path):
    raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
manifest=CONTEXT/'INTERNAL-MANIFEST.json'
assert pin(manifest)['sha256']=='035ebfa17e4d0d8ba43ec2783d86dc2788b7b8e5c3e3c5401a9e10a0f87e2d68'
rows=json.loads(manifest.read_text(encoding='utf-8'))['files']
assert pin(CONTEXT/'FEASIBILITY-01.md')['sha256']=='a39197d51f4077fd762bda24dd031e1c1dfca4787666ae878d0db41c7b9244ed'
for name in ['debug_primary02.py','FEASIBILITY-01.md','UNLOAD-PRIMARY-04.json','EVENT-PRIMARY-07.json']:
    assert pin(CONTEXT/name)==rows[name]
helper=CONTEXT/'debug_primary02.py'
# Only inspected parser/import definitions execute; its top-level evidence writer does not.
definitions=[node for node in ast.parse(helper.read_text(encoding='utf-8')).body
             if isinstance(node,(ast.Import,ast.ImportFrom,ast.ClassDef,ast.FunctionDef))]
namespace={'__file__':str(helper)}
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(helper),'exec'),namespace)
parse=namespace['parse']
mapped=Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert pin(mapped)['sha256']=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
names={
 'net/minecraft/server/level/ChunkMap.class':{'lambda$scheduleUnload$14','processUnloads'},
 'net/minecraft/server/level/ServerLevel.class':{'unload'},
 'net/minecraft/server/dedicated/DedicatedServer.class':{'handleConsoleInput','handleConsoleInputs','tickChildren'},
}
out={'Java_launches':0,'official_class_bodies_retained':False,'parser_helper':{'path':str(helper),**pin(helper)},
     'primary_context_manifest':pin(manifest),'primary_memo':pin(CONTEXT/'FEASIBILITY-01.md'),
     'mapped_jar':{'path':str(mapped),**pin(mapped)},'classes':{}}
with zipfile.ZipFile(mapped) as archive:
    for name,methods in names.items():
        raw=archive.read(name);data=parse(raw,methods)
        out['classes'][name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'methods':{}}
        for method,detail in data['selected_methods'].items():
            out['classes'][name]['methods'][method]=[{'offset':i['offset'],'reference':i['reference']}
                                                     for i in detail['instructions'] if i['reference'] is not None]

def selected(class_name,prefix):
    methods=out['classes'][class_name]['methods']
    return next(value for name,value in methods.items() if name.startswith(prefix))
chunk=selected('net/minecraft/server/level/ChunkMap.class','lambda$scheduleUnload$14')
def offset(calls,part):return next(c['offset'] for c in calls if part in c['reference'])
assert offset(chunk,'LevelChunk.setLoaded')<offset(chunk,'ChunkEvent$Unload.<init>')<offset(chunk,'IEventBus.post')<offset(chunk,'ChunkMap.save')<offset(chunk,'ServerLevel.unload')
level=selected('net/minecraft/server/level/ServerLevel.class','unload')
assert offset(level,'clearAllBlockEntities')==1
children=selected('net/minecraft/server/dedicated/DedicatedServer.class','tickChildren')
assert offset(children,'MinecraftServer.tickChildren')<offset(children,'handleConsoleInputs')
enqueued=selected('net/minecraft/server/dedicated/DedicatedServer.class','handleConsoleInput(')
assert any('List.add' in c['reference'] for c in enqueued)
assert not any('performPrefixedCommand' in c['reference'] for c in enqueued)
drained=selected('net/minecraft/server/dedicated/DedicatedServer.class','handleConsoleInputs')
assert any('performPrefixedCommand' in c['reference'] for c in drained)
event_facts=json.loads((CONTEXT/'EVENT-PRIMARY-07.json').read_text(encoding='utf-8'))
for path,entry in event_facts['libraries'].items():
    if '/eventbus/' not in path.replace('\\','/'):continue
    jar=Path(path);assert pin(jar)=={'bytes':entry['bytes'],'sha256':entry['sha256']}
    with zipfile.ZipFile(jar) as archive:raw=archive.read('net/minecraftforge/eventbus/EventBus.class')
    parsed=parse(raw,{'post'});posts={}
    for method,detail in parsed['selected_methods'].items():
        posts[method]=[{'offset':i['offset'],'reference':i['reference']} for i in detail['instructions'] if i['reference'] is not None]
    assert any('IEventBusInvokeDispatcher.invoke' in i['reference'] for calls in posts.values() for i in calls)
    assert not any('Executor.execute' in i['reference'] for calls in posts.values() for i in calls)
    # Check the normal one-argument post's actual default method-reference target.
    r=namespace['R'](raw);assert r.u4()==0xcafebabe;r.u2();r.u2();cp=[None]*r.u2();index=1
    while index<len(cp):
        tag=r.u1()
        if tag==1:cp[index]=r.n(r.u2()).decode('utf-8',errors='replace')
        elif tag in (7,8,16,19,20):cp[index]=(tag,r.u2())
        elif tag in (3,4):r.n(4)
        elif tag in (5,6):r.n(8);index+=1
        elif tag in (9,10,11,12,17,18):cp[index]=(tag,r.u2(),r.u2())
        elif tag==15:cp[index]=(tag,r.u1(),r.u2())
        else:raise AssertionError(tag)
        index+=1
    def reference(index):
        value=cp[index]
        if value[0]==15:return reference(value[2])
        if value[0] in (9,10,11):
            name=cp[value[2]]
            return cp[cp[value[1]][1]]+'.'+cp[name[1]]+cp[name[2]]
        return str(value)
    r.n(6);r.n(2*r.u2())
    def skip_attributes():
        for _ in range(r.u2()):r.u2();r.n(r.u4())
    for _ in range(r.u2()):r.n(6);skip_attributes()
    for _ in range(r.u2()):r.n(6);skip_attributes()
    bootstrap=None
    for _ in range(r.u2()):
        name=cp[r.u2()];value=r.n(r.u4())
        if name=='BootstrapMethods':bootstrap=value
    assert bootstrap is not None
    b=namespace['R'](bootstrap);values=[]
    for _ in range(b.u2()):
        handle=b.u2();arguments=[b.u2() for _ in range(b.u2())]
        values.append((handle,arguments))
    targets=[reference(index) for index in values[17][1] if isinstance(cp[index],tuple) and cp[index][0]==15]
    assert targets==['net/minecraftforge/eventbus/api/IEventListener.invoke(Lnet/minecraftforge/eventbus/api/Event;)V']
    out['eventbus']={'path':path,**pin(jar),'entry_sha256':hashlib.sha256(raw).hexdigest(),'posts':posts,
                     'normal_post_default_bootstrap17_targets':targets}
(OUT/'PRIMARY-CHECK-01.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('Named class and inline-dispatch/queue-order checks passed; no Java/native execution or class-body export.')
