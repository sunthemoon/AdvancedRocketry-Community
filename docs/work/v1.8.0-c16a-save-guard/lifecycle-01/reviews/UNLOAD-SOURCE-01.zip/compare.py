"""Verify unchanged assertions/dependencies and the bounded Java observation scope."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
def definitions(path):
    result={}
    for node in ast.parse(path.read_text(encoding='utf-8')).body:
        if isinstance(node,ast.FunctionDef):result[node.name]=ast.dump(node)
        if isinstance(node,ast.ClassDef):
            for child in node.body:
                if isinstance(child,ast.FunctionDef):result[node.name+'.'+child.name]=ast.dump(child)
    return result
script='scripts/run_v180_guard_lifecycle_smoke.py';test='tests/test_run_v180_guard_lifecycle_smoke.py'
old,new=definitions(OUT/'preimages'/script),definitions(OUT/'candidate'/script)
changed=[name for name in old if old[name]!=new[name]]
assert changed==['native_cycle','main']
assert set(new)-set(old)=={'wait_unload_begin'}
old_tests,new_tests=definitions(OUT/'preimages'/test),definitions(OUT/'candidate'/test)
assert all(value==new_tests[name] for name,value in old_tests.items())
added=sorted(set(new_tests)-set(old_tests));assert len(added)==5
java=OUT/'candidate/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java'
source=java.read_text(encoding='utf-8')
for clause in ['Boolean.getBoolean(ReleaseTestCommands.PROPERTY)', 'instanceof ServerLevel level',
               'level.dimension() != Level.OVERWORLD', '!level.getServer().isSameThread()',
               'instanceof LevelChunk chunk','chunk.getPos().x != 11 || chunk.getPos().z != 11']:
    assert clause in source
assert source.count('LOGGER.info(')==1 and '@SubscribeEvent' in source
for forbidden in ['setBlock(', 'getBlockEntity(', 'getChunk(', 'setCanceled(', '.save(', '.command(', 'Map<','List<']:
    assert forbidden not in source
inputs=json.loads((OUT/'INPUTS-01.json').read_text(encoding='utf-8'))
after={name:{'bytes':(ROOT/name).stat().st_size,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()}
       for name in inputs['files']}
assert after==inputs['files']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==inputs['head']
(OUT/'STATIC-CHECK-01.json').write_text(json.dumps({'modified_old_functions':changed,'added_functions':sorted(set(new)-set(old)),
 'unchanged_old_functions':sorted(set(old)-set(changed)),'old_tests_AST_unchanged':True,
 'old_test_cases':sum('.test_' in name for name in old_tests),'new_test_cases':sum('.test_' in name for name in new_tests),
 'added_tests':added,'observer_source_guards_checked':6,'all_named_inputs_unchanged':len(after),
 'Java_or_native_execution':False},indent=2,sort_keys=True)+'\n',encoding='utf-8')
(OUT/'POSTCHECK-02.json').write_text(json.dumps({'head':inputs['head'],'files':after,'changed':[]},indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('Old assertions/function bounds, observer-source guards and named inputs unchanged; declaration check only.')
