# Guard unload observation amendment: independent source review

## Findings

No introduced Critical/High/Medium/Low finding was observed in the exact
four-file amendment. Source recommendation: eligible for Root's separately
scheduled build/packaging and diagnostic native verification, subject to the
explicit ordinary-server-thread/console assumptions below. This is not a
native result, callback-completion proof, save-policy/risk acceptance or Gate.

## Exact source identity and scope

HEAD/baseline: `a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce`.
[INPUTS-01](INPUTS-01.json) binds 29 named current governance/source/dependency
files. The four candidate snapshots are individually preserved, together with
the two committed Python preimages and [actual Python diff](ACTUAL-PYTHON-DIFF.patch):

- [New Java observer](candidate/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java):
  `a426612fd9986b871d7930fa413b8ad0ade1e994d911c901c3f87e3b313fdd87`.
- [Lifecycle script](candidate/scripts/run_v180_guard_lifecycle_smoke.py):
  `544e25035fe5554994bc812727ed0bbe6e5d5e24a0165607f4d95b1dd0e67a30`.
- [Focused tests](candidate/tests/test_run_v180_guard_lifecycle_smoke.py):
  `3fa8716ed3682b94b750e533d2b7462266a0912246079b74e8ae5985b2737ea9`.
- [Amendment](candidate/docs/work/v1.8.0-c16a-save-guard/UNLOAD-OBSERVATION-AMENDMENT-01.md):
  exact hash/size in INPUTS-01.

Only those new/two-modified source paths and the new amendment are reviewed.
Existing Java/schema/registry/resource authority was not changed. External
user-maintained AGENTS is pinned as governance, not overwritten or attributed
to the source author. No Root or other-agent file was edited by this reviewer.

The original f9c641/9e657 tooling source is now in the fixed Git baseline.
Its prior log-classification correction remains intact. Root reports that the
old-JAR diagnostic failed restoration after 20.909501 seconds; this review
does **not** audit that native attempt or reclassify it. Its actual result
belongs to the independently assigned native evidence audit. The new observer
requires a new packaged JAR, never the old attempt's inherited result.

## Observer and ordering assessment

Java lines 20–30 contain one opt-in logging observer. It returns unless the
existing `advancedrocketrycommunity.releaseTestHooks` property is true, the
level is a ServerLevel, dimension is Overworld, the current thread is the
server thread, and the supplied chunk is a LevelChunk at (11,11). It emits one
fixed INFO marker per matching event. There is no world query/loading, mutation,
inventory access, event cancellation, save/reset, command call or mutable
static world/resource state. `event.getChunk()` is the supplied event accessor,
not a world-loading method. The source annotation is a Forge event subscriber;
no central registration file is changed. Disabled/wrong-level/thread/chunk
branches are inspected source guards, not runtime branches exercised here.

The hook deliberately marks **unload begin**, not BE cleanup completion.
[PRIMARY-CHECK-01](PRIMARY-CHECK-01.json) independently reparses exact cached
mapped Forge 47.4.10 classfiles and the pinned EventBus 6.0.5 class:

- `ChunkMap.lambda$scheduleUnload$14` posts ChunkEvent.Unload before
  `ChunkMap.save` and `ServerLevel.unload`.
- `ServerLevel.unload` invokes `clearAllBlockEntities`; the event is earlier.
- Normal EventBus `post(Event)` binds a default method-reference dispatcher
  directly to `IEventListener.invoke`; the two-argument post invokes that
  dispatcher inline. No asynchronous executor is inserted in this path.
- `DedicatedServer.handleConsoleInput` adds to the input queue; its normal
  `handleConsoleInputs` executes commands. `tickChildren` completes the normal
  server/world tick before draining that queue.

The Java marker is therefore not a cleanup receipt. However, the harness uses
ordinary process stdin: a ticket-add queued after that marker cannot execute
halfway through the same successful server-thread unload continuation. The
ticket-add command itself is queued, and subsequent fresh loaded/console
barriers acknowledge the new phase. This source-order justification does not
require interpreting the marker as completion. It excludes reentrant command
execution inside foreign listeners, other command transports and an error
aborting the continuation. Strict logs, clean exit and restoration still fail
closed; a marker does not waive those later requirements.

The separately authored primary memo remains evidence, not this source's
approval. Its original location/hash are:
`D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/FEASIBILITY-01.md`,
`a39197d51f4077fd762bda24dd031e1c1dfca4787666ae878d0db41c7b9244ed`;
context manifest `035ebfa17e4d0d8ba43ec2783d86dc2788b7b8e5c3e3c5401a9e10a0f87e2d68`.
An inspected, pinned generic parser from that context was reused for independent
named JAR reads; its top-level evidence writer was not executed. Retained
results contain semantic references/hashes, not official class bodies.

## Python oracle and bounds

`wait_unload_begin` keeps the same total 60-second observation deadline:
predicate observation first, then only the remaining time for a fresh strict
INFO/project-logger/chunk11 marker. An event alone is insufficient. The phase
start index is captured before ticket removal, so old lines cannot satisfy it.
The original 240-probe predicate bound remains. Startup/save/stop remain 300
seconds; marker origin/fixed fixture cells/stopped exact compressed-record and
root checks remain unchanged.

The ticket is not reacquired when the event is missing, stale, from a foreign
logger or late. Even a real-looking begin marker cannot substitute for later
restored culprit/marker checks. A successful source model is not a Minecraft
observation. [Independent controls](independent_controls.py) capture modeled
receipts/commands with `modeled:true`; they never instantiate a real process.

[STATIC-CHECK-01](STATIC-CHECK-01.json) verifies seven other top-level helper
function ASTs unchanged, one added helper, and only `native_cycle`/`main`
modified among old functions. All 16 old focused test cases and fixture helper
ASTs/assertions remain unchanged; five new observation tests are added. Shared
Tank helpers/tests are unchanged. Copy-only input/output checks, fixed scene
oracles, refusal header rules and deadlines were not relaxed.

## Actual commands and failures

- [Scoped Python command](scoped-01.json):
  `python -B -m unittest tests.test_run_v180_guard_lifecycle_smoke tests.test_run_v180_tank_smoke`;
  [37 tests, exit 0](scoped-01.log), unittest duration 0.056 seconds.
- [Reviewer controls command](independent-01.json): eight tests,
  [exit 0](independent-01.log), 0.070 seconds. Missing/stale/foreign event,
  shared deadline exhaustion, restoration independence and prior log negatives
  are covered; one positive source model requires both observations.
- [Primary reparse corrected command](primary-02.json): actual exit 0,
  native event/cleanup/normal-console/default-dispatch relationships checked.
- [Static/unchanged-input corrected command](static-02.json): actual exit 0;
  all 29 named inputs and HEAD remain unchanged through final checking, as
  captured in [POSTCHECK-02](POSTCHECK-02.json).

Two reviewer-only tooling failures are retained, not called candidate failures:

1. [primary-01](primary-01.log), exit 1: the first selector looked for direct
   `IEventListener.invoke` in post instead of its dispatcher indirection.
   The separately corrected primary_check02 additionally resolves the actual
   default bootstrap target; it does not replace the claim with a weaker check.
2. [static-01](static-01.log), exit 1: a lexical loading check mistook
   `event.getChunk()` for a world-loading call. Separately corrected compare02
   checks the actual world-loading spellings and preserves all other controls.

No prior failed sources/logs were overwritten. No Java/Gradle/native/client,
network, download, Git write, Root change, foreign cleanup, OpenPet or protected
development-bundle access occurred. Tiny modeled test directories exist only
inside this review's own D directory and are removed by TemporaryDirectory.

## Unverified and admission limits

Actual subscriber installation/opt-in behavior, fixed/unrelated/client/thread
runtime branches, JVM logger formatting, new-JAR packaging, native unload and
cell restoration are not executed here. Root's full Java build/DataGen/GameTest
and fresh copied-world run must be bound to the new source/JAR separately.
Matching Unload begin plus later restored cells/stopped bytes, if observed,
still does not instrument every BE callback or provider invalidation; the BE
removed beforehand cannot receive a later unload callback merely by inference.

First-save/no-old-record, saturated denial table, stale capability behavior,
independent entity/player/POI/SavedData stores, arbitrary crash atomicity,
repair/log quotas, GuardTicket/carrier/hatch runtime, visuals/multiplayer,
R-021/risk acceptance and whole-version Required Gates remain separate.
No policy or owner behavior is selected by this diagnostic amendment review.
