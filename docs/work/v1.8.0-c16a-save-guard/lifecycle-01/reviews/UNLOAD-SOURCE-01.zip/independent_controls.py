"""Finite unload-start/source-oracle controls, not native executions."""
from pathlib import Path
import json
import sys
import tempfile
import unittest
from unittest.mock import patch

OUT=Path(__file__).resolve().parent
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
PREVIOUS=Path('D:/ARCE-Task-Evidence/v1.8.0/aglr-f0f51f0d31')
sys.path.insert(0,str(ROOT)); sys.path.insert(1,str(PREVIOUS))
from independent_controls02 import TraceProcess
from scripts import run_v180_guard_lifecycle_smoke as guard
from tests.test_run_v180_guard_lifecycle_smoke import oversized_fixture, errors

LINE='[Server thread/INFO] [advancedrocketrycommunity/]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11'

class EventTrace(TraceProcess):
    def __init__(self,event='fresh',restore=True,clock=None):
        super().__init__(restore=restore)
        self.event,self.clock=event,clock
        if event=='stale': self.lines.insert(0,LINE)
    def command(self,command):
        super().command(command)
        if command.startswith('forceload remove'):
            if self.event in ('fresh','late'): self.lines.append(LINE)
            if self.event=='foreign': self.lines.append(LINE.replace('advancedrocketrycommunity/','example/Other'))
        if self.clock is not None and command.startswith('execute unless loaded'):
            self.clock[0]=59.0
    def wait_for(self,pattern,timeout,start_at=0):
        super().wait_for(pattern,timeout,start_at)
        if pattern is guard.UNLOAD_BEGIN:
            self.event_wait_timeout=timeout
            if self.clock is not None: self.clock[0]=60.1
            return next(i for i in range(start_at,len(self.lines)) if pattern.search(self.lines[i]))
        return next(i for i in range(start_at,len(self.lines)) if pattern.search(self.lines[i]))

class IndependentUnloadControls(unittest.TestCase):
    def cycle(self,process,clock=None):
        with tempfile.TemporaryDirectory(prefix='model-',dir=OUT) as folder:
            folder=Path(folder)
            with patch.object(guard.server,'CapturedProcess',return_value=process), \
                    patch.object(guard,'saved_record',return_value=b'fixed'), \
                    patch.object(guard.regions,'_decode_chunk',return_value=oversized_fixture()), \
                    patch.object(guard.time,'monotonic',side_effect=lambda: 0 if clock is None else clock[0]), \
                    patch.object(guard.time,'sleep'):
                try:
                    return guard.native_cycle(folder,folder/'evidence',['MODELED_NO_JAVA'],b'fixed',True)
                finally:
                    receipt=json.loads((folder/'evidence/receipt.json').read_text(encoding='utf-8'))
                    self.receipt=receipt
                    (OUT/(self._testMethodName+'.json')).write_text(json.dumps({'modeled':True,'commands':process.requested,
                                                                              'receipt':receipt},indent=2,sort_keys=True)+'\n',encoding='utf-8')

    def test_fresh_event_and_predicate_precede_reacquisition(self):
        process=EventTrace()
        result=self.cycle(process)
        self.assertEqual(result['result'],'PASS')
        self.assertEqual(result['unload_begin_line'],LINE)
        cut=process.requested.index('forceload remove 176 176')
        self.assertTrue(process.requested[cut+1].startswith('execute unless loaded'))
        self.assertGreater(process.requested.index('forceload add 176 176',cut),cut+1)

    def test_predicate_without_event_never_reacquires_ticket(self):
        process=EventTrace(event='missing')
        with self.assertRaisesRegex(guard.server.SmokeError,'Modeled marker unavailable'): self.cycle(process)
        self.assertEqual(process.requested.count('forceload add 176 176'),1)
        self.assertEqual(self.receipt['result'],'FAIL')

    def test_only_old_event_does_not_reacquire_ticket(self):
        process=EventTrace(event='stale')
        with self.assertRaisesRegex(guard.server.SmokeError,'Modeled marker unavailable'): self.cycle(process)
        self.assertEqual(process.requested.count('forceload add 176 176'),1)

    def test_event_from_other_logger_does_not_reacquire_ticket(self):
        process=EventTrace(event='foreign')
        with self.assertRaisesRegex(guard.server.SmokeError,'Modeled marker unavailable'): self.cycle(process)
        self.assertEqual(process.requested.count('forceload add 176 176'),1)

    def test_real_begin_marker_is_not_substituted_for_restoration(self):
        process=EventTrace(restore=False)
        with self.assertRaisesRegex(RuntimeError,'REMOVAL_ROLLED_BACK'): self.cycle(process)
        self.assertEqual(self.receipt['unload_begin_line'],LINE)
        self.assertEqual(self.receipt['result'],'FAIL')

    def test_actual_predicate_wait_consumes_same_event_deadline(self):
        clock=[0.0];process=EventTrace(event='late',clock=clock)
        with self.assertRaisesRegex(guard.server.SmokeError,'after its original deadline'): self.cycle(process,clock)
        self.assertEqual(process.event_wait_timeout,1.0)
        self.assertEqual(process.requested.count('forceload add 176 176'),1)

    def test_unchanged_log_negatives_remain_rejected(self):
        fatal='[Server thread/FATAL] [example/Other]: Exception caught during firing event: '+guard.tanks.SAVE_REFUSAL
        foreign=[line.replace('net.minecraftforge.eventbus.EventBus/EVENTBUS','example/Other').replace('minecraft/ChunkMap','example/Other') for line in errors()]
        for lines in (errors()+[fatal],foreign):
            with self.subTest(lines=lines),self.assertRaises(RuntimeError): guard.audit_refusal(lines)

    def test_marker_requires_exact_native_origin_and_no_trailing_payload(self):
        self.assertIsNotNone(guard.UNLOAD_BEGIN.search('[01:02:03] '+LINE))
        for altered in (LINE.replace('Server thread','Worker thread'),LINE.replace('/INFO]','/WARN]'),
                        LINE.replace('11,11','11,110'),LINE+' trailing','echo '+LINE):
            self.assertIsNone(guard.UNLOAD_BEGIN.search(altered))

if __name__=='__main__': unittest.main(verbosity=2)
