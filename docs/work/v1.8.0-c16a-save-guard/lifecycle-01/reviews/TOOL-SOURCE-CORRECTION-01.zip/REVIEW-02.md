# Guard lifecycle harness: correction review 02

## Findings and disposition

No introduced Critical/High/Medium/Low finding was observed in the exact
log-classification correction. Original review M1 is resolved in these
postimages: expected refusal headers must have the fixed native ERROR/logger
origin; unexpected findings, including FATAL and other loggers carrying the
same phrase, are rejected.

This is a bounded **source/oracle** disposition, not a native outcome, policy
acceptance or version Gate. It does not admit a subsequently added lifecycle
instrument.

## Exact inputs and delta

HEAD remains `355c4681a6cbddd380545a50e0f6e524bad6d295`.
[INPUTS-02](INPUTS-02.json) pins 25 named files and the previous sealed report,
manifest and reviewer probe. Only the new script/test changed from review 01;
the task, existing Tank helper/tests, process/copy helpers and named governance
inputs are unchanged.

Final [script](candidate-03/scripts/run_v180_guard_lifecycle_smoke.py):
`f9c6418758b35f327ef6c00e2a1d372a863478e0dfa72be581999a83d23645d7`.
Final [test](candidate-03/tests/test_run_v180_guard_lifecycle_smoke.py):
`9e657e2c13a13e8d26b43936d50174db062f1ba0176850c51a762da90431088d`.
[Task](candidate-03/docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md):
`6a21cd9b0cfa0fa3f54d5abe2b5d3ae70f68be6aa6fc5db5ac6089831ce739b9`.

The actual script diff adds three strict header-regex constants and changes
only `audit_refusal`; [AST-CHECK-01](AST-CHECK-01.json) independently verifies
all other top-level function ASTs unchanged. All 14 existing new-harness test
cases and three fixture helpers retain their AST/assertions; two additional
tests exercise the observed log defects and actual abbreviated/timestamped
logger forms. The task is byte-identical. The saved
`run_v180_guard_lifecycle_smoke.py.diff` and
`test_run_v180_guard_lifecycle_smoke.py.diff` are comparison evidence, not
integration proposals.

The new wrapper still calls the inherited Tank audit first, then narrows its
admission. No shared Tank or server helper was changed to obtain green tests.
Strict ERROR prefixes, expected EventBus/EVENTBUS or ChunkMap logger names,
fixed messages/chunk identity and end-of-line anchoring prevent the two
demonstrated waivers. Count parity still concerns observed headers, not a
claim of causal instrumentation or stack-trace occurrence counting.

## Actual checks

[replay.py](replay.py) captures each exact command, time, exit and raw log:

- `python -B -m unittest tests.test_run_v180_guard_lifecycle_smoke
  tests.test_run_v180_tank_smoke`: [32 tests, exit 0](scoped-02.log),
  0.057 seconds as reported by unittest; [command receipt](scoped-02.json).
- [Byte-identical original reviewer controls](independent_controls02.py):
  [10 tests, exit 0](independent-03.log), 0.056 seconds; both original oracle
  negatives now pass by rejecting their supplied logs.
- [compare.py](compare.py): function/test AST and unchanged-task checks,
  actual exit 0. [POSTCHECK-02](POSTCHECK-02.json) verifies all 25 named inputs
  unchanged through both independent replays.

These ten controls model finite console/process behavior without Java. Their
modeled PASS is never a Minecraft/native observation. Real tiny copy-isolation
checks operate only on reviewer-owned disposable files.

Original evidence remains sealed separately at
`D:/ARCE-Task-Evidence/v1.8.0/aglr-f0f51f0d31`:
report SHA `3b58f38e84f8851436683fec97f78b61ae6846d4bf365bea676bf28cf733e360`,
manifest SHA `50b45e08c19c3e9462d776e66054bd2bb2b9ad508f53d3794a24379d3c24f724`.
Its 30 green tests, actual two oracle reds, initial reviewer message-regex
fixture failure and Root initial mocked-clock error transcription are not
overwritten or reclassified. No recursive archive is duplicated.

## Remaining boundaries

A false native loaded predicate is not proof of chunk disposal or unload
callbacks. Immediate ticket reacquisition can retain the mutable chunk, in
which case the strict old-cell restoration check fails rather than falsely
passes. That timing dependency remains explicit. A later debug-report/holder
absence gate would be a distinct source amendment requiring its own review.

No original native world/runtime library/JAR was copied or read in this task,
and no server/client, Java, Gradle, network/dependency installation, Git write,
Root edit, protected bundle access or OpenPet event occurred. Runtime input
identity must be bound by the actual runner; content-addressed world/JAR
postchecks and strict stopped compressed-record equality are requirements,
not observed native results here.

Actual removal/disposal/restoration/restart behavior, callback ordering,
first-save writer, saturated refusal table, cross-store/crash conservation,
repair, log quotas, physical hatches, visuals/multiplayer and Required Gates
remain unverified. This report recommends the reviewed log correction as
eligible source tooling only; it does not close save behavior/risk disclosures
or admit a new Guard/carrier API/runtime.
