"""Independent correction replay; static and Python only."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
PREVIOUS = Path('D:/ARCE-Task-Evidence/v1.8.0/aglr-f0f51f0d31')
def pin(path):
    raw = path.read_bytes(); return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')
def run(name, args):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat(); tick = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    write(name + '.json', {'command': args, 'cwd': str(ROOT), 'started_utc': start,
                          'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'elapsed_seconds': time.monotonic()-tick, 'exit_code': result.returncode,
                          'log': pin(OUT / (name + '.log'))})
    print(name, result.returncode, (OUT / (name+'.log')).read_text(encoding='utf-8'))
    return result.returncode

old = json.loads((PREVIOUS / 'INPUTS-01.json').read_text(encoding='utf-8'))
names = ['scripts/run_v180_guard_lifecycle_smoke.py', 'tests/test_run_v180_guard_lifecycle_smoke.py',
         'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md']
before = {name: pin(ROOT / name) for name in old['files']}
assert before[names[0]]['sha256'] == 'f9c6418758b35f327ef6c00e2a1d372a863478e0dfa72be581999a83d23645d7'
assert before[names[1]]['sha256'] == '9e657e2c13a13e8d26b43936d50174db062f1ba0176850c51a762da90431088d'
changed = [name for name in before if before[name] != old['files'][name]]
assert set(changed) == set(names[:2])
for name in names:
    target = OUT / 'candidate-03' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
    diff = ''.join(difflib.unified_diff((PREVIOUS/'candidate-02'/name).read_text(encoding='utf-8').splitlines(True),
                                      target.read_text(encoding='utf-8').splitlines(True),
                                      fromfile='candidate02/'+name, tofile='candidate03/'+name))
    if diff: (OUT / (Path(name).name+'.diff')).write_text(diff, encoding='utf-8')
assert pin(OUT / 'independent_controls02.py') == pin(PREVIOUS / 'independent_controls02.py')
write('INPUTS-02.json', {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                        'files': before, 'changed_from_review01': changed,
                        'previous_report': pin(PREVIOUS/'REVIEW-01.md'),
                        'previous_manifest': pin(PREVIOUS/'EVIDENCE-MANIFEST.json'),
                        'reviewer_probe_original_unchanged': pin(OUT / 'independent_controls02.py')})
codes = [run('scoped-02', [sys.executable,'-B','-m','unittest','tests.test_run_v180_guard_lifecycle_smoke','tests.test_run_v180_tank_smoke']),
         run('independent-03', [sys.executable,'-B',str(OUT/'independent_controls02.py')])]
after = {name: pin(ROOT / name) for name in before}
write('POSTCHECK-02.json', {'files': after, 'changed': [name for name in before if before[name] != after[name]]})
assert before == after
sys.exit(max(codes))
