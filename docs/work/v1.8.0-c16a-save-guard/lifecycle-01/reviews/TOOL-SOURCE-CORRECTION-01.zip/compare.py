"""Bounded AST/pin comparisons for the corrective postimages."""
import ast
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/aglr-f0f51f0d31/candidate-02')
NEW = OUT / 'candidate-03'

def functions(path):
    result = {}
    for item in ast.parse(path.read_text(encoding='utf-8')).body:
        if isinstance(item, ast.FunctionDef): result[item.name] = ast.dump(item)
        if isinstance(item, ast.ClassDef):
            for method in item.body:
                if isinstance(method, ast.FunctionDef): result[item.name + '.' + method.name] = ast.dump(method)
    return result

names = ['scripts/run_v180_guard_lifecycle_smoke.py','tests/test_run_v180_guard_lifecycle_smoke.py']
old_script, new_script = functions(OLD/names[0]), functions(NEW/names[0])
old_tests, new_tests = functions(OLD/names[1]), functions(NEW/names[1])
changed_script = [name for name in old_script if old_script[name] != new_script[name]]
changed_tests = [name for name in old_tests if old_tests[name] != new_tests[name]]
added_tests = sorted(set(new_tests)-set(old_tests))
assert changed_script == ['audit_refusal']
assert not changed_tests and len(added_tests) == 2
task = 'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md'
assert (OLD/task).read_bytes() == (NEW/task).read_bytes()
result = {'changed_top_level_functions': changed_script,
          'unchanged_top_level_functions': sorted(set(old_script)-set(changed_script)),
          'old_test_cases': sum('.test_' in name for name in old_tests),
          'new_test_cases': sum('.test_' in name for name in new_tests),
          'old_functions_and_test_assertions_AST_unchanged': changed_tests == [],
          'added_test_functions': added_tests,
          'task_byte_identical': True,
          'previous_probe_sha256': hashlib.sha256((OUT/'independent_controls02.py').read_bytes()).hexdigest()}
(OUT/'AST-CHECK-01.json').write_text(json.dumps(result, indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(result,sort_keys=True))
