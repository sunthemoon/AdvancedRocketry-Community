"""Named readonly native02/governance intake; no source/world tree walk."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
C = 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce'
N = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
pins = {}
docs = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
        'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
        'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
        'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
        'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
for name in ['AGENTS.md']+docs:
    raw = (R/name).read_bytes() if name == 'AGENTS.md' else subprocess.check_output(['git', 'show', C+':'+name], cwd=R)
    key = str(R/name) if name == 'AGENTS.md' else C+':'+name
    pins[key] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    print('DOCUMENT', key, pins[key]); print(raw.decode('utf-8'))
names = ['NATIVE-RESULT-02.json', 'native-02/inputs.json',
         'native-02/removal-availability-reload/stdout.txt',
         'native-02/removal-availability-reload/latest.log',
         'native-02/removal-availability-reload/commands.json',
         'native-02/removal-availability-reload/receipt.json',
         'native-02/removal-availability-reload/launch.json',
         'native-02/server/server.properties']
texts = {}; excerpts = {}
for name in names:
    p = N/name; raw = p.read_bytes(); assert len(raw) <= 2*1024*1024
    pins[str(p)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    text = raw.decode('utf-8'); texts[name] = text
    if name.endswith(('.txt', '.log')):
        lines = text.splitlines()
        selected = [i for i, line in enumerate(lines) if any(s in line for s in
                    ('ARCE_GUARD', 'Unmarked chunk', 'Changed the block', 'initial_refusal_END',
                     'after_removal_refusal_END', 'Exception caught during firing event:',
                     'Failed to save chunk 11,11', 'Stopping server'))]
        excerpts[name] = [{'line': i+1, 'text': lines[i]} for i in selected]
    else: print('RECEIPT', name, text)
inputs = json.loads(texts['native-02/inputs.json'])
for name in ('host', 'fixture'):
    d = inputs[name]; p = Path(d['path']); raw = p.read_bytes()
    assert len(raw) == d['bytes'] and hashlib.sha256(raw).hexdigest() == d['sha256']
    pins[str(p)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
sources = ['scripts/run_v180_guard_lifecycle_smoke.py',
           'tests/test_run_v180_guard_lifecycle_smoke.py',
           'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java']
for name in sources:
    p = R/name; raw = p.read_bytes()
    pins[str(p)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'source': 'individually captured live postimage; not attributed to a382'}
    print('LIVE SOURCE', name, pins[str(p)])
    if name.endswith('GuardedChunkUnloadObservation.java'):
        print('\n'.join(f'{i}: {line}' for i, line in enumerate(raw.decode('utf-8').splitlines(), 1)))
for k, rows in excerpts.items():
    print('EXCERPTS', k)
    print('\n'.join(f"{r['line']}: {r['text']}" for r in rows))
out = {'fixed_context_commit': C, 'pins': pins, 'native_result': json.loads(texts['NATIVE-RESULT-02.json']),
       'phase_receipt': json.loads(texts['native-02/removal-availability-reload/receipt.json']),
       'commands': json.loads(texts['native-02/removal-availability-reload/commands.json']),
       'excerpts': excerpts, 'Java_native_launches': 0}
(B/'INTAKE-01.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
