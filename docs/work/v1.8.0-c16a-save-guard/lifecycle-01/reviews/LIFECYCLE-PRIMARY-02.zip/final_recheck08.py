"""Read only individually named inputs; write only this owned evidence folder."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OWN = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT = '23bec1eb1452e8c8ef37c004606aaed3a2394063'


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def git_bytes(spec):
    result = subprocess.run(['git', '-C', str(ROOT), 'show', spec], capture_output=True)
    if result.returncode:
        raise RuntimeError((spec, result.returncode, result.stderr.decode('utf-8', 'replace')))
    return result.stdout


intake = json.loads((OWN / 'INTAKE-01.json').read_text('utf-8'))
checks = []
drifts = []
for name, expected in intake['pins'].items():
    if name.startswith(intake['fixed_context_commit'] + ':'):
        actual = identity(git_bytes(name))
        role = 'fixed context object'
    else:
        actual = identity(Path(name).read_bytes())
        role = 'named input'
    agrees = all(actual[k] == expected[k] for k in ('bytes', 'sha256'))
    if name.startswith(str(ROOT).replace('/', '\\')):
        if name.endswith('AGENTS.md'):
            drifts.append({'name': name, 'role': 'live governance, not immutable native evidence',
                           'before': expected, 'actual': actual, 'unchanged': agrees})
            continue
        rel = Path(name).relative_to(ROOT).as_posix()
        committed = identity(git_bytes(COMMIT + ':' + rel))
        checks.append({'name': COMMIT + ':' + rel, 'role': 'fixed observer phase postimage',
                       'expected': expected, 'actual': committed,
                       'agrees': all(committed[k] == expected[k] for k in ('bytes', 'sha256'))})
        drifts.append({'name': name, 'role': 'live source, later setup proposal is not reviewed here',
                       'before': expected, 'actual': actual, 'unchanged': agrees})
        continue
    checks.append({'name': name, 'role': role, 'expected': expected,
                   'actual': actual, 'agrees': agrees})

levels = json.loads((OWN / 'LEVEL-FACTS-02.json').read_text('utf-8'))
for name, expected in levels['named_level_files'].items():
    actual = identity(Path(name).read_bytes())
    checks.append({'name': name, 'role': 'explicit permitted level.dat only',
                   'expected': {k: expected[k] for k in ('bytes', 'sha256')},
                   'actual': actual,
                   'agrees': all(actual[k] == expected[k] for k in ('bytes', 'sha256'))})

native = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-02')
installed = native / 'server/mods/advancedrocketry-community-1.20.1-1.8.0-dev.jar'
host_expected = {'bytes': 5443263, 'sha256': '5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9'}
actual = identity(installed.read_bytes())
installed_actual = actual
checks.append({'name': str(installed), 'role': 'actual installed host',
               'expected': host_expected, 'actual': actual, 'agrees': actual == host_expected})

named_primary = [
    (Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar'),
     {'bytes': 19355242, 'sha256': '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'}),
    (native / 'server/libraries/net/minecraft/server/1.20.1-20230612.114412/server-1.20.1-20230612.114412-extra.jar',
     {'bytes': 5229189, 'sha256': '16c690f52a92ef272f3e3a5a841cbb24dadff19da5a895885b9520c5a108be38'}),
    (native / 'removal-availability-reload/debug.log',
     {'bytes': 166083, 'sha256': '72ae9963db9ab792b0214cfc6b56daa989d9994e31637c5d2719b6710d4e36d3'}),
]
for path, expected in named_primary:
    actual = identity(path.read_bytes())
    checks.append({'name': str(path), 'role': 'named primary or debug input',
                   'expected': expected, 'actual': actual, 'agrees': actual == expected})

failures = [c for c in checks if not c['agrees']]
result = {'checks': checks, 'immutable_mismatch_count': len(failures),
          'qualified_live_observations': drifts, 'fixed_observer_commit': COMMIT,
          'new_setup_source_reviewed': False, 'Java_native_launches': 0,
          'no_world_inventory_or_ticket_state_claim': True}
(OWN / 'FINAL-RECHECK-08.json').write_text(json.dumps(result, indent=2) + '\n', 'utf-8')
print(json.dumps({'check_count': len(checks), 'immutable_mismatch_count': len(failures),
                  'live_observation_count': len(drifts), 'installed_host': installed_actual,
                  'Java_native_launches': 0}, indent=2))
sys.exit(bool(failures))
