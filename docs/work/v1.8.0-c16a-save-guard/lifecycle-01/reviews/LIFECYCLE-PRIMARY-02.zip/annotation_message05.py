"""Compiled annotation metadata and one exact primary English message only."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
H = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
defs = [n for n in ast.parse(H.read_text(encoding='utf-8')).body
        if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(H)}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(H), 'exec'), ns)
Reader, parse = ns['R'], ns['parse']

def metadata(b):
    r = Reader(b); r.n(8); cp = [None]*r.u2(); i = 1
    while i < len(cp):
        t = r.u1()
        if t == 1: cp[i] = r.n(r.u2()).decode('utf-8', errors='replace')
        elif t in (7, 8, 16, 19, 20): cp[i] = (t, r.u2())
        elif t in (3, 4): cp[i] = (t, r.n(4).hex())
        elif t in (5, 6): cp[i] = (t, r.n(8).hex()); i += 1
        elif t in (9, 10, 11, 12, 17, 18): cp[i] = (t, r.u2(), r.u2())
        elif t == 15: cp[i] = (t, r.u1(), r.u2())
        else: raise AssertionError(t)
        i += 1
    def attrs():
        out = {}
        for _ in range(r.u2()):
            name = cp[r.u2()]; out[name] = r.n(r.u4())
        return out
    def annotations(raw):
        q = Reader(raw)
        def element():
            t = chr(q.u1())
            if t in 'BCDFIJSZsc': return {'tag': t, 'value': cp[q.u2()]}
            if t == 'e': return {'tag': t, 'type': cp[q.u2()], 'constant': cp[q.u2()]}
            if t == '@': return ann()
            if t == '[': return [element() for _ in range(q.u2())]
            raise AssertionError(t)
        def ann():
            typ = cp[q.u2()]; values = {}
            for _ in range(q.u2()):
                name = cp[q.u2()]; values[name] = element()
            return {'type': typ, 'values': values}
        return [ann() for _ in range(q.u2())]
    r.n(6); r.n(2*r.u2())
    for _ in range(r.u2()): r.n(6); attrs()
    methods = {}
    for _ in range(r.u2()):
        access, name, desc = r.u2(), cp[r.u2()], cp[r.u2()]; a = attrs()
        if 'RuntimeVisibleAnnotations' in a:
            methods[name+desc] = {'access': access, 'annotations': annotations(a['RuntimeVisibleAnnotations'])}
    a = attrs()
    return {'class_annotations': annotations(a['RuntimeVisibleAnnotations']) if 'RuntimeVisibleAnnotations' in a else [],
            'method_annotations': methods}

ticket = json.loads((B/'TICKET-PRIMARY-03.json').read_text(encoding='utf-8'))
host = Path(ticket['compiled_observer']['jar_path'])
with zipfile.ZipFile(host) as z:
    b = z.read(ticket['compiled_observer']['class_path'])
out = {'compiled_observer_sha256': hashlib.sha256(b).hexdigest(), 'metadata': metadata(b),
       'live_registration_or_event_observed': False, 'Java_native_launches': 0}
runtime = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-02/server')
args = runtime/'libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt'
raw = args.read_bytes()
out['runtime_args'] = {'path': str(args), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
extra = runtime/'libraries/net/minecraft/server/1.20.1-20230612.114412/server-1.20.1-20230612.114412-extra.jar'
assert str(extra.relative_to(runtime)).replace('\\','/') in raw.decode('utf-8')
h = hashlib.sha256()
with extra.open('rb') as f:
    for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
with zipfile.ZipFile(extra) as z:
    b = z.read('assets/minecraft/lang/en_us.json'); assert len(b) <= 2*1024*1024
    language = json.loads(b)
out['message'] = {'jar_path': str(extra), 'jar_bytes': extra.stat().st_size, 'jar_sha256': h.hexdigest(),
    'member': 'assets/minecraft/lang/en_us.json', 'member_bytes': len(b), 'member_sha256': hashlib.sha256(b).hexdigest(),
    'key': 'commands.setworldspawn.success', 'template': language['commands.setworldspawn.success']}
primary = Path(ticket['primary_jar']['path'])
with zipfile.ZipFile(primary) as z:
    selected = {
        'net/minecraft/server/commands/SetWorldSpawnCommand.class': {'lambda$setSpawn$4', 'lambda$register$3'},
        'net/minecraft/commands/arguments/coordinates/BlockPosArgument.class': {'getSpawnablePos'},
    }
    out['additional_primary'] = {}
    for name, methods in selected.items():
        b = z.read(name)
        out['additional_primary'][name] = {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), **parse(b, methods)}
(B/'ANNOTATION-MESSAGE-05.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
print(json.dumps(out, indent=2))
