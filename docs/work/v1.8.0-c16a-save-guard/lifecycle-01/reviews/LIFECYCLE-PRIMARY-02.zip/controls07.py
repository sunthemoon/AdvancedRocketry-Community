"""Source/class/log consistency controls only; no live runtime is invoked."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import unittest
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
I = json.loads((B/'INTAKE-01.json').read_text(encoding='utf-8'))
T = json.loads((B/'TICKET-PRIMARY-03.json').read_text(encoding='utf-8'))
L = json.loads((B/'TICKET-LIFECYCLE-04.json').read_text(encoding='utf-8'))
A = json.loads((B/'ANNOTATION-MESSAGE-05.json').read_text(encoding='utf-8'))
F = json.loads((B/'REGISTRATION-FORCE-06.json').read_text(encoding='utf-8'))
H = Path(T['helper']['path'])
defs = [n for n in ast.parse(H.read_text(encoding='utf-8')).body
        if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(H)}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(H), 'exec'), ns)
parse = ns['parse']
reg = F['registration_primary']
with zipfile.ZipFile(reg['path']) as z:
    b = z.read(reg['class']['name'])
    registration = parse(b, {'lambda$inject$6'})
with zipfile.ZipFile(T['primary_jar']['path']) as z:
    b = z.read('net/minecraft/server/level/ChunkMap.class')
    forced = parse(b, {'<clinit>'})
extra = {'registration': registration, 'forced_ticket_static': forced}
(B/'ADDITIONAL-PRIMARY-07.json').write_text(json.dumps(extra, indent=2)+'\n', encoding='utf-8')

commit = '23bec1eb1452e8c8ef37c004606aaed3a2394063'
name = 'scripts/run_v180_guard_lifecycle_smoke.py'
script = subprocess.check_output(['git', 'show', commit+':'+name], cwd=R)
assert hashlib.sha256(script).hexdigest() == I['pins'][str(R/name)]['sha256']
tree = ast.parse(script.decode('utf-8'))
assignment = next(n for n in tree.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'UNLOAD_BEGIN' for t in n.targets))
def string(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str): return node.value
    assert isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add)
    return string(node.left)+string(node.right)
pattern = re.compile(string(assignment.value.args[0]))

def method(doc, cls, name):
    return next(v for k, v in doc['classes'][cls]['selected_methods'].items() if k.startswith(name+'('))
def refs(v): return [(i['offset'], i['reference']) for i in v['instructions'] if i['reference']]

class EvidenceControls(unittest.TestCase):
    def test_status_array_has_twelve_entries_and_MAX45(self):
        v = method(T, 'net/minecraft/world/level/chunk/ChunkStatus.class', '<clinit>')
        values = [(o, r) for o, r in refs(v) if 354 <= o < 390]
        self.assertEqual(len(values), 12)
        self.assertTrue(all('ChunkStatus.' in r for _, r in values))
        v = method(T, 'net/minecraft/server/level/ChunkLevel.class', '<clinit>')
        self.assertEqual(v['instructions'][0]['operand_hex'], '21')
        self.assertIn('maxDistance', refs(v)[0][1])
        self.assertTrue(any(i['opcode_hex'] == '0x60' for i in v['instructions']))
        self.assertEqual(33+len(values), 45)

    def test_START_zero_timeout_and_eight_neighbor_propagation(self):
        v = next(v for k, v in L['classes']['net/minecraft/server/level/TicketType.class']['selected_methods'].items()
                 if k.startswith('create(') and ';I)' not in k)
        self.assertTrue(any(i['opcode_hex'] == '0x9' for i in v['instructions']))
        v = method(L, 'net/minecraft/server/level/Ticket.class', 'timedOut')
        self.assertTrue(any(i['offset'] == 11 and i['branch_target'] == 29 for i in v['instructions']))
        v = method(L, 'net/minecraft/server/level/ChunkTracker.class', 'computeLevelFromNeighbor')
        self.assertEqual([i['opcode_hex'] for i in v['instructions']][-3:], ['0x4','0x60','0xac'])

    def test_actual_and_proposed_spawn_arithmetic_are_distinct_from_FULL_ring(self):
        d = json.loads((B/'LEVEL-FACTS-02.json').read_text(encoding='utf-8'))
        for v in d['named_level_files'].values():
            self.assertEqual(v['spawn_chunk'], [16,-2])
            self.assertEqual(v['Chebyshev_distance_from_spawn'], 13)
        self.assertEqual(33-11+13, 35)
        self.assertLessEqual(35, 45)
        self.assertGreater(35, 33)
        proposed = (256 >> 4, -256 >> 4)
        distance = max(abs(11-proposed[0]), abs(11-proposed[1]))
        self.assertEqual(distance, 27)
        self.assertEqual(33-11+distance, 49)
        self.assertGreater(49, 45)

    def test_compiled_registration_metadata_and_logger(self):
        ann = A['metadata']['class_annotations'][0]
        self.assertEqual(ann['values']['modid']['value'], 'advancedrocketrycommunity')
        method_ann = next(iter(A['metadata']['method_annotations'].values()))
        self.assertEqual(method_ann['access'], 9)
        self.assertEqual(method_ann['annotations'][0]['type'], 'Lnet/minecraftforge/eventbus/api/SubscribeEvent;')
        v = T['compiled_observer']['selected_methods']['<clinit>()V']
        self.assertEqual(refs(v)[0][1], 'advancedrocketrycommunity')

    def test_parser_accepts_strict_marker_but_actual_logs_contain_none(self):
        valid = '[17:17:02] [Server thread/INFO] [advancedrocketrycommunity/]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11'
        self.assertIsNotNone(pattern.fullmatch(valid))
        for bad in (valid.replace('chunk=11,11','chunk=12,11'), valid.replace('Server thread','Worker'),
                    valid.replace('/INFO', '/WARN'), valid+' unexpected'):
            self.assertIsNone(pattern.fullmatch(bad))
        for name in ('stdout.txt', 'latest.log'):
            p = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-02/removal-availability-reload')/name
            text = p.read_text(encoding='utf-8')
            self.assertNotIn('ARCE_GUARD_UNLOAD_BEGIN', text)
        self.assertEqual(I['native_result']['exit_code'], 1)
        self.assertEqual(I['phase_receipt']['result'], 'FAIL')
        self.assertTrue(I['phase_receipt']['removal_cut'])
        self.assertEqual(sum(c == 'forceload add 176 176' for c in I['commands']), 1)
        self.assertNotIn('stop', I['commands'])

    def test_auto_subscription_log_precedes_class_load_and_register(self):
        v = next(iter(registration['selected_methods'].values()))
        values = refs(v)
        log = next(o for o, r in values if 'Logger.debug(' in r)
        load = next(o for o, r in values if 'Class.forName' in r)
        register = next(o for o, r in values if 'IEventBus.register(' in r)
        self.assertLess(log, load); self.assertLess(load, register)
        self.assertEqual(len(F['debug']['excerpts']), 1)
        self.assertIn('Auto-subscribing', F['debug']['excerpts'][0]['text'])

    def test_spawn_command_replaces_START_and_bounds_only_position(self):
        v = method(T, 'net/minecraft/server/level/ServerLevel.class', 'setDefaultSpawnPos')
        values = refs(v)
        self.assertLess(next(o for o, r in values if 'removeRegionTicket' in r),
                        next(o for o, r in values if 'addRegionTicket' in r))
        v = next(iter(A['additional_primary']['net/minecraft/commands/arguments/coordinates/BlockPosArgument.class']['selected_methods'].values()))
        values = [r for _, r in refs(v)]
        self.assertTrue(any('isInSpawnableBounds' in r for r in values))
        self.assertFalse(any('getLoaded' in r or 'getChunk' in r for r in values))
        self.assertEqual(A['message']['template'], 'Set the world spawn point to %s, %s, %s [%s]')

    def test_FORCED_uses_entity_ticking_level(self):
        values = refs(next(iter(forced['selected_methods'].values())))
        put = next(o for o, r in values if 'ChunkMap.FORCED_TICKET_LEVEL' in r)
        preceding = [(o, r) for o, r in values if o < put]
        self.assertIn('ENTITY_TICKING', preceding[-2][1])
        self.assertIn('ChunkLevel.byStatus', preceding[-1][1])

result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(EvidenceControls))
(B/'CONTROLS-07.json').write_text(json.dumps({'tests': result.testsRun, 'failures': len(result.failures),
    'errors': len(result.errors), 'skips': len(result.skipped), 'native_runtime_replayed': False,
    'fixed_script_commit': commit, 'fixed_script_sha256': hashlib.sha256(script).hexdigest()}, indent=2)+'\n', encoding='utf-8')
sys.exit(not result.wasSuccessful())
