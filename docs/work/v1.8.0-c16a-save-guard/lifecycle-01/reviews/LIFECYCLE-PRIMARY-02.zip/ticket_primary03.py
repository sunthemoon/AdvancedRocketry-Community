"""Inspect exact cached ticket/holder and installed Source23 observer classfiles."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
H = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
defs = [n for n in ast.parse(H.read_text(encoding='utf-8')).body
        if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(H)}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(H), 'exec'), ns)
parse = ns['parse']
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
raw = J.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
names = {
    'net/minecraft/server/MinecraftServer.class': {'prepareLevels'},
    'net/minecraft/server/level/ServerLevel.class': {'setDefaultSpawnPos'},
    'net/minecraft/server/level/ServerChunkCache.class': {'addRegionTicket', 'removeRegionTicket'},
    'net/minecraft/server/level/DistanceManager.class': {'addRegionTicket', 'removeRegionTicket'},
    'net/minecraft/server/level/ChunkLevel.class': {'<clinit>', 'isLoaded', 'fullStatus', 'generationStatus'},
    'net/minecraft/server/level/ChunkMap.class': {'updateChunkScheduling'},
    'net/minecraft/server/level/ChunkTracker.class': {'getLevelFromNeighbor', 'computeLevel'},
    'net/minecraft/server/level/DistanceManager$ChunkTicketTracker.class': {'getLevelFromSource', 'onLevelChange'},
    'net/minecraft/world/level/chunk/ChunkStatus.class': {'<clinit>', 'maxDistance'},
}
out = {'primary_jar': {'path': str(J), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
       'classes': {}, 'Java_native_launches': 0, 'helper': {'path': str(H), 'sha256': hashlib.sha256(H.read_bytes()).hexdigest()}}
with zipfile.ZipFile(J) as z:
    for name, selected in names.items():
        b = z.read(name)
        out['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), **parse(b, selected)}
intake = json.loads((B/'INTAKE-01.json').read_text(encoding='utf-8'))
host = next((p, v) for p, v in intake['pins'].items() if p.endswith('.jar') and v['sha256'].startswith('5fd2a23d'))
p = Path(host[0]); raw = p.read_bytes(); assert hashlib.sha256(raw).hexdigest() == host[1]['sha256']
name = 'io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.class'
with zipfile.ZipFile(p) as z:
    b = z.read(name)
    out['compiled_observer'] = {'jar_path': str(p), 'jar_sha256': host[1]['sha256'], 'class_path': name,
                               'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                               **parse(b, {'observe', '<clinit>'}),
                               'contains_automatic_subscriber_descriptor': b'Lnet/minecraftforge/fml/common/Mod$EventBusSubscriber;' in b,
                               'contains_subscribe_descriptor': b'Lnet/minecraftforge/eventbus/api/SubscribeEvent;' in b}
(B/'TICKET-PRIMARY-03.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for name, c in out['classes'].items():
    print('CLASS', name, c['sha256'])
    for m, v in c['selected_methods'].items():
        print('METHOD', m)
        for i in v['instructions']:
            if i['reference'] is not None or i['branch_target'] is not None or i['opcode_hex'] in ('0x10','0x11'):
                print(i)
print('COMPILED OBSERVER', out['compiled_observer'])
