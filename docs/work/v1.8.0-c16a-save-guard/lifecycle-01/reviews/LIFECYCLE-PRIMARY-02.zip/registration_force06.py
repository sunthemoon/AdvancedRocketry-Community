"""Named debug record, primary registration order, and FORCED-ticket facts."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
N = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-02')
p = N/'removal-availability-reload/debug.log'
assert p.stat().st_size <= 50*1024*1024
h = hashlib.sha256(); excerpts = []
with p.open('rb') as f:
    for number, raw in enumerate(f, 1):
        h.update(raw)
        if b'GuardedChunkUnloadObservation' in raw or b'ARCE_GUARD_UNLOAD_BEGIN' in raw:
            excerpts.append({'line': number, 'text': raw.decode('utf-8').rstrip()})
out = {'debug': {'path': str(p), 'bytes': p.stat().st_size, 'sha256': h.hexdigest(), 'excerpts': excerpts},
       'Java_native_launches': 0, 'live_event_call_observed': False}
H = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
defs = [n for n in ast.parse(H.read_text(encoding='utf-8')).body
        if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(H)}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(H), 'exec'), ns)
parse = ns['parse']
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert hashlib.sha256(J.read_bytes()).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
out['primary'] = {}
with zipfile.ZipFile(J) as z:
    for name in ('net/minecraft/server/level/ServerChunkCache.class', 'net/minecraft/server/level/DistanceManager.class'):
        b = z.read(name)
        out['primary'][name] = {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), **parse(b, {'updateChunkForced'})}
jar = N/'server/libraries/net/minecraftforge/javafmllanguage/1.20.1-47.4.10/javafmllanguage-1.20.1-47.4.10.jar'
out['registration_primary'] = {'path': str(jar), 'exists': jar.is_file()}
if jar.is_file():
    b = jar.read_bytes(); out['registration_primary'].update(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
    with zipfile.ZipFile(jar) as z:
        name = 'net/minecraftforge/fml/javafmlmod/AutomaticEventSubscriber.class'
        raw = z.read(name)
        out['registration_primary']['class'] = {'name': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), **parse(raw, {'inject'})}
(B/'REGISTRATION-FORCE-06.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
print(json.dumps(out['debug'], indent=2))
for name, c in out['primary'].items():
    print(name)
    for m, v in c['selected_methods'].items(): print(m, v['instructions'])
c = out['registration_primary'].get('class')
if c:
    print('REGISTRATION PRIMARY', out['registration_primary']['path'], out['registration_primary']['sha256'])
    for m, v in c['selected_methods'].items():
        print(m)
        for i in v['instructions']:
            if i['reference'] is not None or i['branch_target'] is not None: print(i)
