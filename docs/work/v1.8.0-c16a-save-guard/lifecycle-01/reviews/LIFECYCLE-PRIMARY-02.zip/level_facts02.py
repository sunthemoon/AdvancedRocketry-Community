"""Decode only exact permitted stopped level.dat paths with hard IO/shape limits."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
N = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
paths = [N/'native-02/server/world/level.dat',
         Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/tank-native-06/server/world/level.dat')]

class Reader:
    def __init__(self, b): self.b = b; self.p = 0; self.nodes = 0
    def n(self, size):
        assert 0 <= size <= len(self.b)-self.p
        out = self.b[self.p:self.p+size]; self.p += size; return out
    def value(self, fmt): return struct.unpack(fmt, self.n(struct.calcsize(fmt)))[0]
    def string(self):
        size = self.value('>H'); assert size <= 65535
        return self.n(size).decode('utf-8', errors='strict')
    def tag(self, typ, depth=0):
        self.nodes += 1; assert self.nodes <= 262144 and depth <= 64
        if typ in (1, 2, 3, 4, 5, 6):
            return self.value({1:'>b',2:'>h',3:'>i',4:'>q',5:'>f',6:'>d'}[typ])
        if typ == 8: return self.string()
        if typ in (7, 11, 12):
            count = self.value('>i'); assert 0 <= count <= 1048576
            width = {7:1,11:4,12:8}[typ]; raw = self.n(count*width)
            return {'array_type': typ, 'length': count, 'sha256': hashlib.sha256(raw).hexdigest()}
        if typ == 9:
            subtype, count = self.value('>B'), self.value('>i')
            assert 0 <= count <= 262144 and (subtype != 0 or count == 0)
            return [self.tag(subtype, depth+1) for _ in range(count)]
        if typ == 10:
            out = {}
            while True:
                subtype = self.value('>B')
                if subtype == 0: return out
                name = self.string(); assert name not in out
                out[name] = self.tag(subtype, depth+1)
        raise AssertionError(typ)

out = {'named_level_files': {}, 'live_ticket_state_observed': False, 'Java_native_launches': 0}
for p in paths:
    raw = p.read_bytes(); assert len(raw) <= 2*1024*1024
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as f:
        decoded = f.read(16*1024*1024+1)
        assert len(decoded) <= 16*1024*1024 and not f.read(1)
    r = Reader(decoded); assert r.value('>B') == 10; root_name = r.string(); root = r.tag(10)
    assert r.p == len(decoded)
    data = root['Data']; fields = {k: data.get(k) for k in
        ('SpawnX', 'SpawnY', 'SpawnZ', 'SpawnAngle', 'DataVersion', 'Time', 'DayTime', 'LastPlayed', 'WasModded')}
    spawn = (data['SpawnX'] >> 4, data['SpawnZ'] >> 4)
    out['named_level_files'][str(p)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'decoded_bytes': len(decoded), 'nodes': r.nodes, 'root_name': root_name, 'fields': fields,
        'Data_keys': sorted(data), 'spawn_chunk': spawn,
        'target_chunk': [11,11], 'Chebyshev_distance_from_spawn': max(abs(11-spawn[0]),abs(11-spawn[1]))}
(B/'LEVEL-FACTS-02.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
print(json.dumps(out, indent=2))
