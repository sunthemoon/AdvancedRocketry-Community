"""Seal only the explicitly owned small analysis directory, without an archive."""
import hashlib
import json
from pathlib import Path
import re

OWN = Path(__file__).resolve().parent
assert OWN == Path('D:/ARCE-Task-Evidence/v1.8.0/agnf-1b7aa2336c')
assert not (OWN / 'INTERNAL-MANIFEST.json').exists(), 'already sealed'


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


report = OWN / 'REVIEW-NATIVE02.md'
missing = []
for target in re.findall(r'\]\(([^)]+)\)', report.read_text('utf-8')):
    if ':' in target or target.startswith('/'):
        raise AssertionError('nonportable report link ' + target)
    if not (OWN / target).resolve().is_file():
        missing.append(target)
assert not missing, missing
recheck = json.loads((OWN / 'FINAL-RECHECK-08.json').read_text('utf-8'))
assert recheck['immutable_mismatch_count'] == 0
assert len(recheck['checks']) == 29
assert recheck['Java_native_launches'] == 0
receipt = {
    'report': pin(report),
    'fixed_context_commit': 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce',
    'fixed_observer_commit': '23bec1eb1452e8c8ef37c004606aaed3a2394063',
    'source23_host_sha256': '5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9',
    'actual_native02_outcome': 'FAIL',
    'findings': {'Critical': 0, 'High': 0, 'Medium': 1, 'Low': 0},
    'immutable_named_checks': 29,
    'immutable_mismatches': 0,
    'independent_controls': {'tests': 8, 'failures': 0, 'errors': 0, 'skips': 0},
    'report_links': {'missing': missing},
    'Java_native_launches': 0,
    'new_fixture_setup_review_or_admission': False,
    'earlier_errors_preserved_by_reference': 'aglf-94222005ae/INTERNAL-MANIFEST.json 035ebfa17e4d0d8ba43ec2783d86dc2788b7b8e5c3e3c5401a9e10a0f87e2d68',
    'own_first_recheck_stdout_label_mistake_preserved': True,
}
(OWN / 'FREEZE-RECEIPT-09.json').write_text(json.dumps(receipt, indent=2) + '\n', 'utf-8')
files = {}
for path in sorted(OWN.iterdir(), key=lambda p: p.name):
    assert path.is_file() and not path.is_symlink(), path
    files[path.name] = pin(path)
manifest = {'scope': 'small read-only native02 failure investigation; no ZIP/source-tree/world export',
            'file_count': len(files), 'total_bytes': sum(p['bytes'] for p in files.values()),
            'files': files}
destination = OWN / 'INTERNAL-MANIFEST.json'
destination.write_text(json.dumps(manifest, indent=2) + '\n', 'utf-8')
print(json.dumps({'report': receipt['report'], 'manifest': pin(destination),
                  'file_count': manifest['file_count'], 'total_bytes': manifest['total_bytes'],
                  'selected_fact_pins': {name: files[name] for name in [
                      'TICKET-PRIMARY-03.json', 'TICKET-LIFECYCLE-04.json',
                      'ANNOTATION-MESSAGE-05.json', 'REGISTRATION-FORCE-06.json',
                      'ADDITIONAL-PRIMARY-07.json', 'FINAL-RECHECK-08.json']},
                  'Java_native_launches': 0}, indent=2))
