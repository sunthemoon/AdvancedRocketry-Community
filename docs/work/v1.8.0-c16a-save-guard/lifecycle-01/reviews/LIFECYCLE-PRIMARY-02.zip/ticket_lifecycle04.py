"""Read named primary spawn-command, propagation, timeout, and message facts."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
H = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
defs = [n for n in ast.parse(H.read_text(encoding='utf-8')).body
        if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(H)}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(H), 'exec'), ns)
parse = ns['parse']
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert hashlib.sha256(J.read_bytes()).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
names = {
    'net/minecraft/server/commands/SetWorldSpawnCommand.class': {'register', 'setSpawn', 'lambda$setSpawn$3', 'lambda$register$2', 'lambda$register$1', 'lambda$register$0'},
    'net/minecraft/server/level/TicketType.class': {'<clinit>', 'create'},
    'net/minecraft/server/level/Ticket.class': {'timedOut'},
    'net/minecraft/server/level/ChunkLevel.class': {'byStatus'},
    'net/minecraft/server/level/ChunkTracker.class': {'getComputedLevel', 'computeLevelFromNeighbor', 'checkNeighborsAfterUpdate'},
    'net/minecraft/server/level/DistanceManager$ChunkTicketTracker.class': {'setLevel', 'getLevel', '<clinit>'},
}
out = {'primary_jar_sha256': '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e',
       'classes': {}, 'Java_native_launches': 0}
with zipfile.ZipFile(J) as z:
    for name, selected in names.items():
        b = z.read(name)
        out['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), **parse(b, selected)}
    resource = 'assets/minecraft/lang/en_us.json'
    try: b = z.read(resource)
    except KeyError: out['spawn_message_resource'] = {'member': resource, 'available': False}
    else:
        d = json.loads(b)
        out['spawn_message_resource'] = {'member': resource, 'available': True, 'bytes': len(b),
            'sha256': hashlib.sha256(b).hexdigest(), 'key': 'commands.setworldspawn.success',
            'template': d.get('commands.setworldspawn.success')}
(B/'TICKET-LIFECYCLE-04.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for name, c in out['classes'].items():
    print('CLASS', name, 'ALL METHODS', c['all_methods'])
    for m, v in c['selected_methods'].items():
        print('METHOD', m)
        for i in v['instructions']:
            if i['reference'] is not None or i['branch_target'] is not None or i['opcode_hex'] in ('0x3','0x4','0x10','0x11'):
                print(i)
print('MESSAGE RESOURCE', out['spawn_message_resource'])
