"""Seal this small owned directory, without archives or redundant source exports."""
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent
assert B == Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae')
target = B/'INTERNAL-MANIFEST.json'
assert not target.exists(), 'Already sealed; do not rewrite evidence'
files = {}
for p in sorted(B.iterdir()):
    assert p.is_file() and not p.is_symlink(), str(p)
    raw = p.read_bytes()
    assert len(raw) <= 50*1024*1024
    files[p.name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
total = sum(v['bytes'] for v in files.values())
assert total <= 100*1024*1024
data = {'scope': 'fixed355/1ece Guard lifecycle feasibility, no execution/admission',
        'files': files, 'file_count': len(files), 'bytes': total,
        'no_zip_or_source_tree_export': True}
target.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
for name, declared in files.items():
    raw = (B/name).read_bytes()
    assert len(raw) == declared['bytes'] and hashlib.sha256(raw).hexdigest() == declared['sha256']
print(json.dumps({'directory': str(B), 'report': files['FEASIBILITY-01.md'],
      'manifest': {'path': str(target), 'bytes': target.stat().st_size,
                   'sha256': hashlib.sha256(target.read_bytes()).hexdigest()},
      'manifested_files': len(files), 'manifested_bytes': total, 'exact_postcheck_mismatches': 0}, indent=2))
