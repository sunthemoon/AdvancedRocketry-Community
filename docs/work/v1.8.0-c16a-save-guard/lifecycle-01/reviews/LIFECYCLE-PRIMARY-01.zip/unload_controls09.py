"""Correct two reviewer reference selectors without changing source or criteria."""
from pathlib import Path
import hashlib

B = Path(__file__).resolve().parent
before = (B/'unload_controls08.py').read_text(encoding='utf-8')
assert before.count("'.Map.clear('") == 1
assert before.count("'.List.add('") == 1
after = before.replace("'.Map.clear('", "'java/util/Map.clear('")
after = after.replace("'.List.add('", "'java/util/List.add('")
after = after.replace('UNLOAD-CONTROLS-08.json', 'UNLOAD-CONTROLS-09.json')
print('Reviewer dot-vs-slash class-reference selectors corrected; original fail/error retained.',
      'before_sha256', hashlib.sha256(before.encode('utf-8')).hexdigest())
exec(compile(after, str(B/'unload_controls08.py')+'[exact-class-selector-correction]', 'exec'),
     {'__file__': str(B/'unload_controls09.py'), '__name__': '__main__'})
