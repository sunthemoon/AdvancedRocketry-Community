"""Read only exact historical runtime libraries for event dispatch/filter facts."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
helper = B/'debug_primary02.py'
definitions = [n for n in ast.parse(helper.read_text(encoding='utf-8')).body
               if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(helper)}
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(helper), 'exec'), ns)
parse = ns['parse']
runtime = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v160-c9-1d4b262cc75c4042b9945eebde09cd04/attempt-04/native-server/libraries')
names = {
    runtime/'net/minecraftforge/eventbus/6.0.5/eventbus-6.0.5.jar': {
        'net/minecraftforge/eventbus/EventBus.class': {'post'},
    },
    runtime/'net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-universal.jar': {
        'net/minecraftforge/event/level/ChunkEvent$Unload.class': {'<init>'},
        'net/minecraftforge/event/level/ChunkEvent.class': {'<init>', 'getChunk'},
        'net/minecraftforge/event/level/LevelEvent.class': {'<init>', 'getLevel'},
    },
}
out = {'java_launches': 0, 'libraries': {}}
for jar, classes in names.items():
    raw = jar.read_bytes()
    entry = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'classes': {}}
    with zipfile.ZipFile(jar) as z:
        for name, selected in classes.items():
            b = z.read(name)
            entry['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), **parse(b, selected)}
    out['libraries'][str(jar)] = entry
(B/'EVENT-PRIMARY-07.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for path, entry in out['libraries'].items():
    print('JAR', path, entry['sha256'], entry['bytes'])
    for name, c in entry['classes'].items():
        print('CLASS', name, c['sha256'])
        for m, v in c['selected_methods'].items():
            print('METHOD', m, 'EXCEPTIONS', v['exceptions'])
            for i in v['instructions']:
                if i['reference'] is not None or i['branch_target'] is not None: print(i)
