"""Resolve native BE callback handles and main-thread unload/console call chain."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
helper = B/'debug_primary02.py'
tree = ast.parse(helper.read_text(encoding='utf-8'))
definitions = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
ns = {'__file__': str(helper)}
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(helper), 'exec'), ns)
R, parse = ns['R'], ns['parse']
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
assert hashlib.sha256(J.read_bytes()).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'

def bootstrap(b):
    r = R(b); r.n(8); cp = [None] * r.u2(); i = 1
    while i < len(cp):
        t = r.u1()
        if t == 1: cp[i] = r.n(r.u2()).decode('utf-8', errors='replace')
        elif t in (7, 8, 16, 19, 20): cp[i] = (t, r.u2())
        elif t in (3, 4): cp[i] = (t, r.n(4).hex())
        elif t in (5, 6): cp[i] = (t, r.n(8).hex()); i += 1
        elif t in (9, 10, 11, 12, 17, 18): cp[i] = (t, r.u2(), r.u2())
        elif t == 15: cp[i] = (t, r.u1(), r.u2())
        else: raise AssertionError(t)
        i += 1
    def ref(i):
        v = cp[i]
        if isinstance(v, str): return v
        if v[0] in (7, 8, 16, 19, 20): return cp[v[1]]
        if v[0] in (9, 10, 11):
            typ = cp[v[2]]; return ref(v[1]) + '.' + cp[typ[1]] + cp[typ[2]]
        if v[0] == 15: return 'handle-kind-' + str(v[1]) + ':' + ref(v[2])
        return str(v)
    def attributes():
        out = {}
        for _ in range(r.u2()): out[cp[r.u2()]] = r.n(r.u4())
        return out
    r.n(6); r.n(2*r.u2())
    for _ in range(r.u2()): r.n(6); attributes()
    for _ in range(r.u2()): r.n(6); attributes()
    a = attributes(); out = []
    if 'BootstrapMethods' in a:
        q = R(a['BootstrapMethods'])
        for index in range(q.u2()):
            handle = ref(q.u2()); args = [ref(q.u2()) for _ in range(q.u2())]
            out.append({'index': index, 'handle': handle, 'arguments': args})
    return out

names = {
    'net/minecraft/world/level/chunk/LevelChunk.class': {'clearAllBlockEntities'},
    'net/minecraft/server/level/ServerChunkCache.class': {'tick'},
    'net/minecraft/server/level/ChunkMap.class': {'tick', 'processUnloads'},
    'net/minecraft/server/MinecraftServer.class': {'tickChildren', 'tickServer'},
}
out = {'java_launches': 0, 'classes': {}}
with zipfile.ZipFile(J) as z:
    for name, selected in names.items():
        b = z.read(name)
        out['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                                **parse(b, selected), 'bootstraps': bootstrap(b)}
(B/'UNLOAD-BOOTSTRAP-05.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for name, c in out['classes'].items():
    print('CLASS', name)
    for m, v in c['selected_methods'].items():
        print('METHOD', m)
        for i in v['instructions']:
            if i['reference']: print(i['offset'], i['reference'])
    if name.endswith('LevelChunk.class'):
        for b in c['bootstraps']:
            if b['index'] in (4, 5, 6): print('BE CALLBACK BOOTSTRAP', b)
