"""Static unload-stage and queued-console boundaries, not actual event execution."""
import json
from pathlib import Path
import sys
import unittest

B = Path(__file__).resolve().parent
D = json.loads((B/'UNLOAD-PRIMARY-04.json').read_text(encoding='utf-8'))
S = json.loads((B/'UNLOAD-BOOTSTRAP-06.json').read_text(encoding='utf-8'))
E = json.loads((B/'EVENT-PRIMARY-07.json').read_text(encoding='utf-8'))

def method(doc, cls, name):
    values = [v for k, v in doc['classes'][cls]['selected_methods'].items() if k.startswith(name+'(')]
    assert len(values) == 1
    return values[0]

def refs(v): return [(i['offset'], i['reference']) for i in v['instructions'] if i['reference']]

class UnloadBoundaries(unittest.TestCase):
    def test_event_is_before_save_and_BE_cleanup(self):
        v = method(D, 'net/minecraft/server/level/ChunkMap.class', 'lambda$scheduleUnload$14')
        values = refs(v)
        def offset(fragment): return next(o for o, r in values if fragment in r)
        self.assertLess(offset('.setLoaded('), offset('IEventBus.post('))
        self.assertLess(offset('IEventBus.post('), offset('ChunkMap.save('))
        self.assertLess(offset('ChunkMap.save('), offset('ServerLevel.unload('))
        self.assertTrue(any('LevelChunk.clearAllBlockEntities' in r for _, r in
                            refs(method(D, 'net/minecraft/server/level/ServerLevel.class', 'unload'))))

    def test_native_BE_callbacks_precede_map_clear(self):
        c = S['classes']['net/minecraft/world/level/chunk/LevelChunk.class']
        for index, name in ((4, 'BlockEntity.onChunkUnloaded()V'), (5, 'BlockEntity.setRemoved()V')):
            b = next(v for v in c['bootstraps'] if v['index'] == index)
            self.assertTrue(any(name in a for a in b['arguments']))
        v = method(S, 'net/minecraft/world/level/chunk/LevelChunk.class', 'clearAllBlockEntities')
        calls = refs(v)
        self.assertLess(next(o for o, r in calls if 'dynamic#5:' in r),
                        next(o for o, r in calls if '.Map.clear(' in r))

    def test_stdin_enqueues_and_tick_executes(self):
        cls = 'net/minecraft/server/dedicated/DedicatedServer.class'
        queue = [r for _, r in refs(method(D, cls, 'handleConsoleInput'))]
        self.assertTrue(any('.List.add(' in r for r in queue))
        self.assertFalse(any('performPrefixedCommand' in r for r in queue))
        run = [r for _, r in refs(method(D, cls, 'handleConsoleInputs'))]
        self.assertTrue(any('performPrefixedCommand' in r for r in run))
        tick = refs(method(D, cls, 'tickChildren'))
        self.assertLess(next(o for o, r in tick if 'MinecraftServer.tickChildren' in r),
                        next(o for o, r in tick if 'handleConsoleInputs' in r))

    def test_EventBus_dispatch_calls_listeners_inline(self):
        library = next(v for p, v in E['libraries'].items() if 'eventbus-' in p)
        c = library['classes']['net/minecraftforge/eventbus/EventBus.class']
        values = [v for k, v in c['selected_methods'].items() if 'InvokeDispatcher;' in k]
        self.assertEqual(len(values), 1)
        calls = [r for _, r in refs(values[0])]
        self.assertTrue(any('IEventBusInvokeDispatcher.invoke(' in r for r in calls))
        self.assertFalse(any('Executor' in r or 'CompletableFuture' in r for r in calls))

result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(UnloadBoundaries))
(B/'UNLOAD-CONTROLS-08.json').write_text(json.dumps({'tests': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
    'scope': 'primary call-boundary controls only, no live Unload marker'}, indent=2)+'\n', encoding='utf-8')
sys.exit(not result.wasSuccessful())
