"""Recheck only the named immutable inputs; never walk a world or source tree."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
context = json.loads((B/'CONTEXT-01.json').read_text(encoding='utf-8'))
static = json.loads((B/'STATIC-01.json').read_text(encoding='utf-8'))
out = {'fixed_object_rechecks': {}, 'individual_external_file_rechecks': {},
       'world_contents_read': False, 'Java_native_launches': 0}
for name, declared in context['files'].items():
    if name == 'AGENTS.md':
        raw = (R/name).read_bytes()
        out['live_governance_observation'] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'equal_prior_read': hashlib.sha256(raw).hexdigest() == declared['sha256'],
            'user_owned_untouched': True}
        continue
    key = declared['source']+':'+name
    raw = subprocess.check_output(['git', 'show', key], cwd=R)
    actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    assert all(actual[k] == declared[k] for k in actual), key
    out['fixed_object_rechecks'][key] = actual
for key, declared in static['inputs'].items():
    raw = subprocess.check_output(['git', 'show', key], cwd=R)
    actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    assert actual == declared, key
    out['fixed_object_rechecks'][key] = actual
external = [json.loads((B/'PRIMARY-01.json').read_text(encoding='utf-8'))['primary_JAR'],
            json.loads((B/'INPUTS-01.json').read_text(encoding='utf-8'))['current_main']]
event = json.loads((B/'EVENT-PRIMARY-07.json').read_text(encoding='utf-8'))
external.extend({'path': p, 'bytes': d['bytes'], 'sha256': d['sha256']} for p, d in event['libraries'].items())
for declared in external:
    p = Path(declared['path']); h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    actual = {'bytes': p.stat().st_size, 'sha256': h.hexdigest()}
    assert actual == {k: declared[k] for k in actual}, str(p)
    out['individual_external_file_rechecks'][str(p)] = actual
out['passing_static_controls'] = {}
for name in ('STATIC-01.json', 'DEBUG-CONTROLS-03.json', 'UNLOAD-CONTROLS-09.json'):
    d = json.loads((B/name).read_text(encoding='utf-8'))
    result = d.get('actual_result', d)
    for k in ('failures', 'errors', 'skips'): assert result[k] == 0
    out['passing_static_controls'][name] = {k: result[k] for k in ('tests', 'failures', 'errors', 'skips')}
assert (B/'unload-bootstrap-05.exit').read_text().strip() == '1'
assert (B/'unload-controls-08.exit').read_text().strip() == '1'
out['retained_reviewer_failures'] = ['unload-bootstrap-05.exit=1', 'unload-controls-08.exit=1 (1 failure, 1 error)']
(B/'FINAL-CHECKS-10.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
print(json.dumps(out, indent=2))
