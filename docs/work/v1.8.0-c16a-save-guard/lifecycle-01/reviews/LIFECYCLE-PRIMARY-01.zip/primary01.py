"""Read selected mapped classfile methods in Python; no javap/Java execution."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')

class Reader:
    def __init__(self,b): self.b=b; self.p=0
    def n(self,size):
        assert self.p+size<=len(self.b)
        b=self.b[self.p:self.p+size]; self.p+=size; return b
    def u1(self): return self.n(1)[0]
    def u2(self): return struct.unpack('>H',self.n(2))[0]
    def u4(self): return struct.unpack('>I',self.n(4))[0]

def read_class(b,names):
    r=Reader(b); assert r.u4()==0xcafebabe
    minor,major=r.u2(),r.u2(); cp=[None]*r.u2(); i=1
    while i<len(cp):
        t=r.u1()
        if t==1: cp[i]=r.n(r.u2()).decode('utf-8',errors='replace')
        elif t in (7,8,16,19,20): cp[i]=(t,r.u2())
        elif t in (3,4): r.n(4)
        elif t in (5,6): r.n(8); i+=1
        elif t in (9,10,11,12,17,18): cp[i]=(t,r.u2(),r.u2())
        elif t==15: r.n(3)
        else: raise AssertionError(t)
        i+=1
    def ref(i):
        v=cp[i]
        if isinstance(v,str): return v
        if v[0] in (7,8): return cp[v[1]]
        if v[0] in (9,10,11):
            owner=cp[cp[v[1]][1]]; typ=cp[v[2]]
            return owner+'.'+cp[typ[1]]+cp[typ[2]]
        return str(v)
    r.n(6); r.n(2*r.u2())
    def attrs():
        out={}
        for _ in range(r.u2()):
            name=cp[r.u2()]; out[name]=r.n(r.u4())
        return out
    for _ in range(r.u2()): r.n(6); attrs()
    selected={}
    for _ in range(r.u2()):
        access,name,desc=r.u2(),cp[r.u2()],cp[r.u2()]; a=attrs()
        if name not in names: continue
        cr=Reader(a['Code']); stack,locals_=cr.u2(),cr.u2(); code=cr.n(cr.u4())
        # These selected small methods contain no switches/wide instructions. Decode whole instruction boundaries.
        p=0; ins=[]
        while p<len(code):
            off=p; op=code[p]; p+=1; operands=0; reference=None
            if op in (0x12,0x10,0x15,0x16,0x17,0x18,0x19,0x36,0x37,0x38,0x39,0x3a,0xa9,0xbc): operands=1
            elif op in (0x11,0x13,0x14,0x84,0xbb,0xbd,0xc0,0xc1) or 0x99<=op<=0xa8 or op in (0xc6,0xc7): operands=2
            elif 0xb2<=op<=0xb8: operands=2; reference=ref(struct.unpack_from('>H',code,p)[0])
            elif op in (0xb9,0xba): operands=4; reference=ref(struct.unpack_from('>H',code,p)[0])
            elif op in (0xc8,0xc9): operands=4
            elif op==0xc5: operands=3
            elif op in (0xaa,0xab,0xc4): raise AssertionError('unsupported instruction in selected method')
            raw=code[p:p+operands]; assert len(raw)==operands; p+=operands
            ins.append({'offset':off,'opcode_hex':hex(op),'operand_hex':raw.hex(),'reference':reference})
        selected[name+desc]={'access':access,'max_stack':stack,'locals':locals_,
                            'code_hex':code.hex(),'instructions':ins}
    return {'class_major':major,'class_minor':minor,'methods':selected}

with J.open('rb') as f:
    h=hashlib.sha256()
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
assert h.hexdigest()=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
out={'primary_JAR':{'path':str(J),'sha256':h.hexdigest(),'bytes':J.stat().st_size},'selected':{},'Java_launches':0}
with zipfile.ZipFile(J) as z:
    for name,methods in [('net/minecraft/server/commands/ExecuteCommand.class',{'isChunkLoaded'}),
                         ('net/minecraft/server/commands/SetBlockCommand.class',{'setBlock'}),
                         ('net/minecraft/commands/arguments/blocks/BlockInput.class',{'place'})]:
        b=z.read(name); out['selected'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),**read_class(b,methods)}
print(json.dumps(out,indent=2))
(B/'PRIMARY-01.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
