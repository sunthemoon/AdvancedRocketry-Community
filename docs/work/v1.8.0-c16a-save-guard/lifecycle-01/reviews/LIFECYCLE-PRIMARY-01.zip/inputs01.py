"""Exact named historical/current inputs; no world/runtime traversal or copying."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def digest_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}

old_zip = R / 'docs/work/v1.8.0-c16a-integration/ROOT-INTEGRATION-11.zip'
assert digest_file(old_zip)['sha256'] == '404d44c1df772e6a318a1d4c45ddd054a5df11dd32d8345953982867811bae65'
members = {}
with zipfile.ZipFile(old_zip) as z:
    manifest = json.loads(z.read('EVIDENCE-MANIFEST.json'))
    print('Root11 manifest schema', list(manifest) if isinstance(manifest, dict) else type(manifest).__name__)
    entries = manifest.get('files', manifest.get('entries'))
    if isinstance(entries, list):
        entries = {e['path']: e for e in entries}
    def read(name):
        raw = z.read(name)
        assert meta(raw) == {k: entries[name][k] for k in ('bytes','sha256')}
        members[name] = meta(raw)
        return raw
    inputs = json.loads(read('tank-native-06/inputs.json'))
    launch = json.loads(read('tank-native-06/oversized-refusal/launch.json'))
    receipt = json.loads(read('tank-native-06/oversized-refusal/receipt.json'))
    world_members = [n for n in z.namelist() if n.startswith('tank-native-06/') and n.endswith('source-world-files.json')]
    assert len(world_members) == 1
    inventory = json.loads(read(world_members[0]))
    # Compressed chunk equality is an archival byte check; no active region/world read.
    before = read('tank-native-06/oversized-patch/chunk-11-11.nbt.zlib')
    after = read('tank-native-06/oversized-refusal/chunk-11-11.nbt.zlib')
    assert before == after
    commands = json.loads(read('tank-native-06/oversized-refusal/commands.json'))
    stdout = read('tank-native-06/oversized-refusal/stdout.txt').decode('utf-8').splitlines()
    prior_sequence = [{'line': i, 'text': l} for i,l in enumerate(stdout,1)
                      if 'Changed the block' in l or 'Failed to save chunk 11,11' in l]
existence = {}
for key, value in [('runtime_template', inputs['runtime_template']), ('source_world', inputs['source_world']),
                   ('Tank06_runtime', launch['cwd']), ('Tank06_stopped_world', str(Path(launch['cwd'])/'world'))]:
    p = Path(value)
    existence[key] = {'path': str(p), 'exists': p.exists(), 'is_directory': p.is_dir(),
                       'contents_read': False, 'stopped_status_independently_verified': False}
for key in ('fixture', 'old'):
    declared = inputs[key]
    p = Path(declared['path'])
    entry = {'declared': declared, 'exists': p.is_file()}
    if p.is_file():
        entry['actual'] = digest_file(p)
        assert entry['actual'] == {k: declared[k] for k in ('bytes','sha256')}
    existence[key] = entry
current = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/artifacts/advancedrocketry-community-1.20.1-1.8.0-dev.jar')
actual = digest_file(current)
assert actual == {'bytes': 5441840, 'sha256': '26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a'}
current_zip = R / 'docs/work/v1.8.0-c16a-k3/ROOT-INTEGRATION-22-COMPACT-01.zip'
assert digest_file(current_zip)['sha256'] == 'ac9b47b78f4cbce140b235974d4e68e2587083c87159e9ec19a634b48a35081d'
with zipfile.ZipFile(current_zip) as z:
    raw = z.read('ARTIFACTS-01.json')
    artifacts = json.loads(raw)
    declared = next(e for e in artifacts if e['name'] == current.name)
    assert actual == {k: declared[k] for k in ('bytes','sha256')}
result = {'historical_packet': {'path': str(old_zip), **digest_file(old_zip)},
          'selected_old_members': members, 'historical_inputs': inputs, 'historical_launch': launch,
          'historical_refusal_receipt': receipt, 'historical_refusal_commands': commands,
          'historical_sequence': prior_sequence, 'source_world_inventory_members': len(inventory),
          'source_world_inventory_identity': members[world_members[0]],
          'Tank06_original_compressed_record': meta(before), 'actual_declared_path_checks': existence,
          'current_main': {'path': str(current), **actual},
          'current_artifact_receipt': {'archive': str(current_zip), 'member': 'ARTIFACTS-01.json', **meta(raw)},
          'no_runtime_world_contents_read': True, 'Java_native_launches': 0}
(B/'INPUTS-01.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'actual_paths': existence, 'source_world_inventory_files': len(inventory),
                  'retained_chunk': meta(before), 'current_main': result['current_main']}, indent=2))
