"""Named code/harness boundaries and independent static feasibility controls only."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

sys.stdout.reconfigure(encoding='utf-8')
B=Path(__file__).resolve().parent
R=Path('D:/GitHub/AdvancedRocketry-Community')
D='355c4681a6cbddd380545a50e0f6e524bad6d295'
C='1ece7e9d2515003ca705b5634ef654a6bcae8f89'
P='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
paths=[(C,P+'persistence/ChunkSaveDenials.java'),(C,P+'persistence/GuardedChunkSaves.java'),
       (C,P+'machine/tank/PressurizedTankBlock.java'),(C,P+'machine/tank/PressurizedTankBlockEntity.java'),
       (C,P+'machine/tank/TankProtection.java'),(C,P+'machine/tank/TankReleaseTestCommands.java'),
       (C,P+'gametest/GuardedChunkSaveGameTests.java'),
       (C,'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/ChunkSaveDenialsTest.java'),
       (D,'scripts/run_v180_tank_smoke.py'),(D,'scripts/run_v050_rocket_server_smoke.py'),
       (D,'tests/test_run_v180_tank_smoke.py')]
inputs={}; texts={}; excerpt={}
for commit,name in paths:
    raw=subprocess.check_output(['git','show',commit+':'+name],cwd=R)
    inputs[commit+':'+name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    s=raw.decode('utf-8'); texts[name]=s; lines=s.splitlines()
    selected=set()
    for i,l in enumerate(lines,1):
        if any(v in l for v in ('def phase(', 'def main(', 'add_argument', 'runtime-template', 'source-world',
                  'oversized', 'wait_full', 'query("forceload', 'save-all', 'process.finish',
                  'getChunkNow', 'repairRequired()', 'seed(', 'root.equals(seed', 'PROPERTY',
                  'MAX_CHUNKS', 'saturated', 'beforeSave', 'restoreGameTestFixture', 'onChunkUnloaded',
                  'onDestroyedByPlayer', 'canEntityDestroy', 'onBlockExploded', 'onRemove', 'void load(',
                  'setRemoved', 'saveAdditional', 'setUnsaved', 'data disappears')):
            selected.update(range(max(1,i-2),min(len(lines),i+5)+1))
    excerpt[name]=[{'line':i,'text':lines[i-1]} for i in sorted(selected)]
primary=json.loads((B/'PRIMARY-01.json').read_text(encoding='utf-8'))
observations={}

class FeasibilityControls(unittest.TestCase):
    def test_01_ticket_barrier_budget_is_fixed(self):
        s=texts['scripts/run_v180_tank_smoke.py']
        self.assertIn('timeout: float = 60',s)
        self.assertIn('range(240)',s)
        self.assertIn('if time.monotonic() > deadline:',s)
        self.assertIn('FULL_READY.search(line)',s)

    def test_02_existing_harness_does_not_live_unload(self):
        s=texts['scripts/run_v180_tank_smoke.py']
        self.assertIn('query("forceload add 176 176"',s)
        self.assertNotIn('forceload remove',s)
        self.assertNotIn('unless loaded',s)
        self.assertIn('process.finish(300)',s)
        self.assertIn('require(persisted == oversized_chunk',s)
        observations['existing_harness_scope']='seven host phases; stop/refusal oracle, no live ticket-removal sequence'

    def test_03_oversized_report_is_not_a_valid_release_hook_oracle(self):
        s=texts[P+'machine/tank/TankReleaseTestCommands.java']
        self.assertIn('index >= 1 && !root.equals(seed(index))',s)
        self.assertIn('Tank fixture root changed:',s)
        self.assertIn('literal("prepare")',s)
        self.assertIn('Tank fixture requires fresh empty cells',s)
        self.assertNotIn('literal("unload")',s)

    def test_04_OP_replacement_not_ordinary_removal_api(self):
        s=texts[P+'machine/tank/PressurizedTankBlock.java']
        self.assertNotIn('void onRemove(',s)
        for v in ('onDestroyedByPlayer(', 'canEntityDestroy(', 'onBlockExploded('): self.assertIn(v,s)
        self.assertNotIn('implements Clearable',s)
        methods=primary['selected']['net/minecraft/server/commands/SetBlockCommand.class']['methods']
        method=next(iter(methods.values()))
        refs=[i['reference'] for i in method['instructions'] if i['reference']]
        self.assertTrue(any('.place(' in r for r in refs))
        self.assertTrue(any('Clearable.tryClear' in r for r in refs))
        self.assertFalse(any('onDestroyedByPlayer' in r or 'BreakEvent' in r for r in refs))
        observations['OP_replacement']='default replace command is a destructive test mutation, not ordinary repair/protection permission'

    def test_05_unless_loaded_is_not_disposal_receipt(self):
        method=next(iter(primary['selected']['net/minecraft/server/commands/ExecuteCommand.class']['methods'].values()))
        refs=[i['reference'] for i in method['instructions'] if i['reference']]
        for v in ('getChunkNow', 'getFullStatus', 'ENTITY_TICKING', 'areEntitiesLoaded'):
            self.assertTrue(any(v in r for r in refs))
        self.assertFalse(any('unload' in r.lower() or 'clearAll' in r for r in refs))
        observations['loaded_predicate']='getChunkNow != null AND fullStatus ENTITY_TICKING AND areEntitiesLoaded'

    def test_06_sticky_state_has_no_ordinary_clear(self):
        s=texts[P+'persistence/GuardedChunkSaves.java']
        self.assertIn('!(level.getServer() instanceof GameTestServer)',s)
        self.assertIn('event.getChunk().setUnsaved(true)',s)
        s=texts[P+'machine/tank/PressurizedTankBlockEntity.java']
        self.assertIn('onChunkUnloaded() { TankTransfers.cancel(this)',s)
        self.assertNotIn('restoreGameTestFixture',s)

    def test_07_old_fixture_already_has_a_record(self):
        d=json.loads((B/'INPUTS-01.json').read_text(encoding='utf-8'))
        self.assertEqual(d['Tank06_original_compressed_record']['bytes'],5898)
        self.assertEqual(d['source_world_inventory_members'],135)
        self.assertEqual(d['historical_refusal_receipt']['exit_code'],0)
        self.assertFalse(d['no_runtime_world_contents_read'] is False)
        observations['first_save_gap']='preexisting stored terrain record: no new-coordinate first-write admission proof'

result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FeasibilityControls))
retained=Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/tank-native-06/server/world')
observations['Root_named_relocated_fixture']={'path':str(retained),'exists':retained.exists(),
                                            'is_directory':retained.is_dir(),'contents_read':False,
                                            'stopped_status':'Root-declared; no process or runtime check performed'}
output={'docs_commit':D,'code_commit':C,'inputs':inputs,'selected_lines':excerpt,'observations':observations,
        'actual_result':{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
                        'skips':len(result.skipped)},'Java_native_launches':0}
(B/'STATIC-01.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
sys.exit(not result.wasSuccessful())
