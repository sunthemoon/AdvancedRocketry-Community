"""Named immutable governance/fixture intake, no whole-tree exports."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
C = '355c4681a6cbddd380545a50e0f6e524bad6d295'
docs = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
        'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
        'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
        'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
        'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
        'docs/11-RISK-REGISTER.md', 'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md',
        'docs/work/v1.8.0-c16a-save-guard/TASK.md',
        'docs/work/v1.8.0-c16a-save-guard/ADR-064-SAVE-REFUSAL-EXPLANATION-PROPOSAL-01.md']
pins = {}
for name in ['AGENTS.md'] + docs:
    raw = (R / name).read_bytes() if name == 'AGENTS.md' else subprocess.check_output(['git', 'show', C + ':' + name], cwd=R)
    pins[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                  'source': 'live user-owned file' if name == 'AGENTS.md' else C}
    print('\nFILE', name, json.dumps(pins[name]))
    print(raw.decode('utf-8'))
(B / 'CONTEXT-01.json').write_text(json.dumps({'fixed_docs_commit': C, 'files': pins}, indent=2) + '\n', encoding='utf-8')
print('\nTASK CONTRACT AND NATIVE SCRIPT TRACKED PATHS')
for path in ('docs/work/v1.8.0-c16a-save-guard', 'docs/work/v1.8.0-c16a-tank',
             'docs/work/v1.8.0-c16a-pump', 'scripts',
             'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/tank',
             'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/machine/pump'):
    p = subprocess.run(['git', 'ls-tree', '-r', '--name-only', C, '--', path], cwd=R,
                       capture_output=True, timeout=60)
    assert p.returncode == 0
    lines = p.stdout.decode('utf-8').splitlines()
    print('\n'.join(n for n in lines if (not n.startswith('scripts/') or 'smoke' in n)
                    and not n.endswith('.zip')))
