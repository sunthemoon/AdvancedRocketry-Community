"""Static primary-call-boundary controls; not a runtime command/callback test."""
import json
from pathlib import Path
import sys
import unittest

B = Path(__file__).resolve().parent
D = json.loads((B/'DEBUG-PRIMARY-02.json').read_text(encoding='utf-8'))
C = D['classes']

def method(cls, name):
    values = [v for k, v in C[cls]['selected_methods'].items() if k.startswith(name+'(')]
    assert len(values) == 1
    return values[0]

def refs(value): return [(i['offset'], i['reference']) for i in value['instructions'] if i['reference'] is not None]

class PrimaryBoundaries(unittest.TestCase):
    def test_debug_command_has_no_report_branch(self):
        cls = 'net/minecraft/server/commands/DebugCommand.class'
        values = [r for _, r in refs(method(cls, 'register'))]
        for name in ('debug', 'start', 'stop', 'function'): self.assertIn(name, values)
        self.assertNotIn('report', values)
        self.assertFalse(any(m.startswith('report(') for m in C[cls]['all_methods']))

    def test_dump_is_visible_holder_rows_not_pending_cleanup_receipt(self):
        v = method('net/minecraft/server/level/ChunkMap.class', 'dumpChunks')
        columns = [r for off, r in refs(v) if off < 100 and '.' not in r and '/' not in r]
        self.assertEqual(columns, ['x', 'z', 'level', 'in_memory', 'status', 'full_status',
                                  'accessible_ready', 'ticking_ready', 'entity_ticking_ready',
                                  'ticket', 'spawning', 'block_entity_count', 'ticking_ticket',
                                  'ticking_level', 'block_ticks', 'fluid_ticks'])
        values = [r for _, r in refs(v)]
        self.assertTrue(any('.visibleChunkMap' in r for r in values))
        self.assertTrue(any('.getLastAvailable(' in r for r in values))
        self.assertFalse(any('.pendingUnloads' in r or '.updatingChunkMap' in r for r in values))
        self.assertFalse(any('.getChunkNow(' in r or '.scheduleUnload(' in r for r in values))
        self.assertTrue(any(i['branch_target'] == 126 for i in v['instructions']))

    def test_unload_has_distinct_pending_and_async_stage(self):
        cls = 'net/minecraft/server/level/ChunkMap.class'
        values = refs(method(cls, 'processUnloads'))
        update = next(o for o, r in values if '.updatingChunkMap' in r)
        remove = next(o for o, r in values if '.remove(J)' in r)
        pending = next(o for o, r in values if '.pendingUnloads' in r)
        schedule = next(o for o, r in values if '.scheduleUnload(' in r)
        self.assertLess(update, remove); self.assertLess(remove, pending); self.assertLess(pending, schedule)
        values = [r for _, r in refs(method(cls, 'scheduleUnload'))]
        self.assertTrue(any('.getChunkToSave(' in r for r in values))
        self.assertTrue(any('.unloadQueue' in r for r in values))
        self.assertTrue(any('.thenAcceptAsync(' in r for r in values))

    def test_report_is_whole_server_not_fixed_coordinate_bound(self):
        v = method('net/minecraft/server/MinecraftServer.class', 'saveDebugReport')
        values = [r for _, r in refs(v)]
        self.assertTrue(any('.levels' in r for r in values))
        self.assertTrue(any('.entrySet(' in r for r in values))
        self.assertTrue(any('ServerLevel.saveDebugReport' in r for r in values))
        self.assertTrue(any('.dumpThreads(' in r for r in values))
        self.assertEqual(D['java_launches'], 0)
        self.assertEqual(D['debug_reports_launched'], 0)

result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PrimaryBoundaries))
out = {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
       'skips': len(result.skipped), 'scope': 'four static primary controls, no native observation'}
(B/'DEBUG-CONTROLS-03.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
sys.exit(not result.wasSuccessful())
