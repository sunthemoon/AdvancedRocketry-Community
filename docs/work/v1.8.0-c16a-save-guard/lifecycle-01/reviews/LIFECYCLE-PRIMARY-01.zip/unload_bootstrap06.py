"""Replay prior reader with only its attribute-read evaluation-order bug corrected."""
from pathlib import Path
import hashlib

B = Path(__file__).resolve().parent
before = (B/'unload_bootstrap05.py').read_text(encoding='utf-8')
old = '        for _ in range(r.u2()): out[cp[r.u2()]] = r.n(r.u4())'
new = '        for _ in range(r.u2()):\n            name = cp[r.u2()]; out[name] = r.n(r.u4())'
assert before.count(old) == 1
after = before.replace(old, new).replace('UNLOAD-BOOTSTRAP-05.json', 'UNLOAD-BOOTSTRAP-06.json')
print('Corrected reviewer helper only; previous failed source/log/exit retained.',
      'before_sha256', hashlib.sha256(before.encode('utf-8')).hexdigest())
exec(compile(after, str(B/'unload_bootstrap05.py')+'[attribute-order-correction]', 'exec'),
     {'__file__': str(B/'unload_bootstrap06.py')})
