"""Selected cached classfile unload/console inspection; no JVM or world launch."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
helper = B/'debug_primary02.py'
tree = ast.parse(helper.read_text(encoding='utf-8'))
definitions = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
namespace = {'__file__': str(helper)}
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(helper), 'exec'), namespace)
parse = namespace['parse']
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
sha = hashlib.sha256(J.read_bytes()).hexdigest()
assert sha == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
names = {
    'net/minecraft/server/level/ChunkMap.class': {'lambda$scheduleUnload$14', 'processUnloads'},
    'net/minecraft/server/level/ServerLevel.class': {'unload'},
    'net/minecraft/world/level/chunk/LevelChunk.class': {'clearAllBlockEntities', 'setLoaded'},
    'net/minecraft/world/level/block/entity/BlockEntity.class': {'setRemoved', 'onChunkUnloaded'},
    'net/minecraft/server/dedicated/DedicatedServer.class': {'handleConsoleInputs', 'tickChildren', 'handleConsoleInput'},
}
out = {'jar': {'path': str(J), 'bytes': J.stat().st_size, 'sha256': sha},
       'java_launches': 0, 'classes': {}}
with zipfile.ZipFile(J) as z:
    for name, selected in names.items():
        b = z.read(name)
        out['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), **parse(b, selected)}
(B/'UNLOAD-PRIMARY-04.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for name, c in out['classes'].items():
    print('CLASS', name, c['sha256'])
    print('METHOD NAMES', '\n'.join(c['all_methods']))
    for method, detail in c['selected_methods'].items():
        print('SELECTED', method, 'EXCEPTIONS', detail['exceptions'])
        for ins in detail['instructions']:
            print(ins)
