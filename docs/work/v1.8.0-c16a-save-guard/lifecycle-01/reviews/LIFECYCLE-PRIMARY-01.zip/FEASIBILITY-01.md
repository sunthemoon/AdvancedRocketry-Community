# Guard lifecycle diagnostic: fixed-input feasibility

## Findings and limits

1. **A loaded-predicate transition is not a chunk-disposal receipt.** Pinned Minecraft `ExecuteCommand.isChunkLoaded` requires `getChunkNow != null`, `FullChunkStatus.ENTITY_TICKING`, and `ServerLevel.areEntitiesLoaded`. Any false conjunct makes `execute unless loaded` succeed. It can therefore precede disposal. Reacquisition at that point may retain the modified live chunk. A strict restoration failure must remain a failure; do not replace it with a fixed sleep or waive the cell oracle. This is a verification boundary, not a newly reproduced production defect. See [primary bytecode](PRIMARY-01.json), offsets 21/30/33/44.
2. **There is no suitable existing fixed-coordinate debug-report completion barrier.** In the pinned 1.20.1 classfile, `DebugCommand.register` has start/stop/function, not `debug report`. `ChunkMap.dumpChunks` emits the 16-column CSV shown below, iterating only `visibleChunkMap`. It does not expose `pendingUnloads`, callback completion, or the exact `getChunkNow` cache. `processUnloads` removes an updating holder, puts it in `pendingUnloads`, and schedules a future continuation on `unloadQueue`. Missing CSV rows cannot establish disposal completion. The report routines traverse all Levels/visible holders and dump other server state, without a fixed-coordinate or hard row limit. Do not add repeated whole-server reports to this bounded leaf. See [debug primary evidence](DEBUG-PRIMARY-02.json), `dumpChunks` offsets 113/116/182, `processUnloads` 61/66/80/104 and `scheduleUnload` 19/32.
3. **The reusable Tank06 fixture cannot establish first-save behavior.** It already has a stored chunk record. Existing synthetic guard GameTests exercise empty retry/replacement Java objects, not native ticket removal/disposal or an absent prior terrain record. Source references: `GuardedChunkSaveGameTests.java:22-29,41-49`; `run_v180_tank_smoke.py:265-322` does not remove the forced ticket. First-save, absent-record consequences, real invalidation timing, and saturation remain separate validation leaves.
4. **The ordinary Tank release report is unsuitable for the oversized scene.** `TankReleaseTestCommands.java:96` compares protected fixture roots with its bounded seed. The deliberately expanded future root fails that comparison. Its prepare operation also requires empty cells. Use loaded-gated fixed block-state acknowledgements plus stopped typed records, not that report/prepare command.

No new production defect is asserted by this feasibility task. R-021 remains open/unaccepted; its factual reconciliation and the standalone explanatory proposal do not approve the save policy or close risk. No current-JAR native execution was performed here.

## Fixed authority and actual checks

- Documentation commit: `355c4681a6cbddd380545a50e0f6e524bad6d295`.
- Code baseline: `1ece7e9d2515003ca705b5634ef654a6bcae8f89`; no moving-HEAD source attribution.
- Mandatory documents/live AGENTS are individually pinned in [context](CONTEXT-01.json). Code/harness/test pins and line excerpts are in [static evidence](STATIC-01.json).
- `GuardedChunkSaves.java:34-39,47-64,68-78`: transient capability belongs to ServerLevel; ordinary refusal is sticky by chunk identity, throws and restores dirty=true; reset requires actual GameTestServer; provider invalidation closes state. There is no native online reset.
- `ChunkSaveDenials.java:9,17-29,33`: 256 recorded identities, no eviction; the 257th distinct denial saturates the Level guard. A new Level receives a new transient provider; a loaded unsafe root may retrigger refusal.
- `PressurizedTankBlock.java:112-123` guards ordinary player/entity/explosion destruction but has no `onRemove` override. The pinned vanilla default `setblock ... air` path uses `Clearable.tryClear` and `BlockInput.place`, not a player BreakEvent. Neither this Tank BE nor block implements Clearable. An OP replacement is feasible as a destructive disposable test mutation, **not a product repair operation or ordinary removal permission**.
- `PressurizedTankBlockEntity.java:226-256`: retained root save/load and transfer cleanup exist; chunk unload/removal do not reset the Level guard. A native test must not call GT cleanup.
- Mapped primary JAR: 19,355,242 B, SHA-256 `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`; exact individual class pins in primary JSON files. Inspection used Python classfile parsing, not Java/javap or copied official code/assets.

CSV header is `x,z,level,in_memory,status,full_status,accessible_ready,ticking_ready,entity_ticking_ready,ticket,spawning,block_entity_count,ticking_ticket,ticking_level,block_ticks,fluid_ticks`. `in_memory` derives from holder `getLastAvailable`, not a callback-completion flag.

## Smallest independently executable existing-policy leaf

**Two clean hosts on one fresh disposable copied world**, current Source22 JAR, one target chunk `(11,11)`. This is one clean restart; it is not two-restart or whole-version admission. The sequence does not need a new save policy, serializer, online reset, production hook, or gameplay permission.

Host A:

1. Independently check the stopped input inventory/target record, four retained roots and marker AIR before copying. Copy only the approved stopped world and runtime libraries into a new disjoint D directory; install only the pinned host/compatibility JARs. Preserve input inventories before/after.
2. `forceload add 176 176`, query the same ticket, then bounded `execute if loaded 186 180 180 ... run say <unique fixed marker>` probes. All cell predicates are inside the loaded condition. Validate initial tank/marker states before mutation.
3. `setblock 190 180 180 minecraft:stone`; assert the live marker changed. `save-all flush`; require actual chunk `(11,11)` refusal/error evidence within that command's bounded transcript, not only its success text.
4. Default `setblock 186 180 180 minecraft:air` on the disposable copy; assert live culprit AIR and marker STONE. `save-all flush` again. Require actual sticky refusal after removal; retain all errors and their command attribution.
5. `forceload remove 176 176`; bounded unique whole-line `execute unless loaded 186 180 180 ...` acknowledgements, **same 60 s/240-barrier budget**, late-wake refusal. Record only the actual predicate transition, not an unload callback claim. Reacquire the same fixed ticket and bounded loaded barrier.
6. Require culprit TANK and marker AIR restored, then clean stop. The conjunction of established live AIR/STONE followed by TANK/AIR provides a separate observed snapshot-restoration oracle **if it happens**. Preserve failure if early reacquisition prevents restoration. It does not independently instrument the unload callback sequence.
7. Read the stopped target record without opening the server: exact original compressed bytes, typed roots/extensions/resources and marker AIR. Decode in addition to hashing; other owned input files/record identities remain bounded and checked. Clean exit/successful save text alone is not durability evidence.

Host B:

8. Restart the same copied world with the same current JAR/new ServerLevel. Verify original fixed scene, mutate the marker and request save, require fresh unsafe-root refusal, clean stop and the same exact stored record. This establishes a restart/retrigger observation if executed; it does not by itself prove a prior provider invalidation callback. Never use a GT reset or claim the OP mutation repaired the protected root.

The exact new diagnostic script/test/task postimages belong to Root's separately reviewed implementation; this memo **does not review or admit** `run_v180_guard_lifecycle_smoke.py`, its test file, or `NATIVE-LIFECYCLE-TASK-01.md`.

## Named reusable inputs and launch prerequisites

Read-only archived selections and exact direct-file checks are in [input ledger](INPUTS-01.json). No active/source world contents were read; existence checks alone do not prove stopped status or validate a relocated runtime.

| Input | Exact named locator / identity |
| --- | --- |
| Relocated stopped fixture | `D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/tank-native-06/server/world`; directory exists; stopped status is Root-declared, independent inventory/direct-record preflight remains required |
| Runtime template | `C:/Users/Administrator/AppData/Local/Temp/arce-v160-c9-1d4b262cc75c4042b9945eebde09cd04/attempt-04/native-server`; directory exists; libraries must be copied/pinned with no links |
| Original historical source world | Same template plus `/world`; original 135-entry receipt is archived, not revalidated by walking this source world |
| Compatibility fixture | Same template plus `/mods/arce-adapter-compat-test-1.0.0.jar`; actual 96,772 B SHA `765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4` |
| Source22 host | `D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/artifacts/advancedrocketry-community-1.20.1-1.8.0-dev.jar`; actual 5,441,840 B SHA `26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a` |
| Tank06 record | Original and refused archived payloads both 5,898 B SHA `d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8` |
| Historical evidence | `docs/work/v1.8.0-c16a-integration/ROOT-INTEGRATION-11.zip`, actual SHA `404d44c1df772e6a318a1d4c45ddd054a5df11dd32d8345953982867811bae65`; read selected manifested members in memory, not copied |

Historical native refusal had six EventBus errors and six `Failed to save chunk 11,11` errors, clean exit 0, original record unchanged. Its host SHA `ea311ed0…` is not the current Source22 host. Old C Tank06 runtime locator is absent; use the Root-supplied D relocation only after direct preflight.

Root's named fixture inventory places four remaining roots at x=182/184/186/188, y=z=180: overcapacity water, tagged lava, future schema plus expanded extension, corrupt amount respectively. The current tank at x180 was already packaged historically; this leaf does not prove entity/item-carrier persistence or cross-store conservation. The relocated world contents were not decoded here: direct typed-scene validation is a launch preflight, not an observation borrowed from directory existence. Exact root assertions must use the recorded typed scene, not invent a fresh generic fixture.

Historical actual launch: Java `C:/Program Files/Java/jdk-17.0.7/bin/java.exe`, `-Xms512M -Xmx2G -Djava.net.preferIPv4Stack=true -Dadvancedrocketrycommunity.releaseTestHooks=true @libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt nogui`. No launch here. New source review, stop/input pinning, at least 10 GiB free under AGENTS, Root-exclusive native scheduling and fresh disjoint output are prerequisites. Existing full Tank harness flags are `--runtime-template --source-world --v17-jar --host-jar --work-root`, optional `--fixture-jar --java`; they do not constitute the new diagnostic CLI. The v1.7 JAR is unnecessary for this retained-world leaf; its exact old 4,366,599 B / `4326d3d6…` path/hash is nevertheless checked in the input ledger.

## Actual commands, remaining work and scope state

Executed only Python helpers and bounded individual Git/Python reads. `context01.py`, `inputs01.py`, `primary01.py`, `static01.py`, `debug_primary02.py`, `debug_controls03.py`, `unload_primary04.py`, `unload_bootstrap06.py`, `event_primary07.py` and `unload_controls09.py` exited 0. Static feasibility controls: **7/7**; primary/debug controls: **4/4**; corrected unload controls: **4/4**. These 15 controls check frozen source/archive/call boundaries, not world behavior. Preserve `unload_bootstrap05.py` exit1 (reviewer attribute-reader evaluation order) and `unload_controls08.py` exit1 (4 tests, one failure/one error from dot-versus-slash reference selectors), their original source/logs/results, and separate corrected replays. No production assertion/budget/source changed. Raw logs/exits are adjacent; final input rechecks are separate. No Java, GameTest, native server, client, report generation, network, repo edit or cleanup was executed. No failed native attempt was reclassified.

Next leaf eligible for Root implementation/independent source review: the bounded copied-world diagnostic above with predicate/restoration qualifications. No additional owner semantic answer is required to test the existing policy destructively in a disposable copy. Separate decisions still apply to actual repair/reset/persistence policy or risk acceptance; this memo selects none.

Oldest remaining verification gaps: absent-prior-record first save; actual callback/provider invalidation and stale capability observation; native saturation and unrelated chunks/Levels; independent player/entity/POI/SavedData stores; forced interruption/crash atomicity; repair workflow and real-player/client behavior. Existing R-021, all v1.8 Required Gates, physical hatches, menus, GPU/peer and whole-version release remain unclosed by this preparation.

## Observer amendment feasibility after the reported diagnostic failure

Root subsequently reported an actual diagnostic failure at `ARCE_GUARD_REMOVAL_ROLLED_BACK` after the false predicate and reacquisition (20.909501 s), with initial/removal-save refusals and input/source equality. That is **Root-reported scope only** here: no new native failure packet/world was independently audited. It must remain an immutable failed attempt, not a pass.

An opt-in, fixed-coordinate Forge **ChunkEvent.Unload observer** is technically feasible without altering Guard save behavior. Exact additional primary evidence is in [unload call chain](UNLOAD-PRIMARY-04.json), [resolved BE bootstrap callbacks](UNLOAD-BOOTSTRAP-06.json) and [event dispatch](EVENT-PRIMARY-07.json):

- `ChunkMap.lambda$scheduleUnload$14` removes the matching pending holder at offset27, calls `LevelChunk.setLoaded(false)`52, constructs/posts `ChunkEvent.Unload`64/67, calls `save`76, then conditionally calls `ServerLevel.unload`114. The Unload event is **before**, not after, save and BE cleanup.
- `ServerLevel.unload` calls `LevelChunk.clearAllBlockEntities`1. Its bootstrap4 dispatches each `BlockEntity.onChunkUnloaded`; bootstrap5 then dispatches `setRemoved`; map clear follows at42. The diagnostic removes one BE beforehand, so it cannot claim that removed BE later received unload callbacks.
- Pinned historical EventBus 6.0.5 JAR is 53,985 B SHA `ae8bd4ea6b32509ace6dba904698b52e13d222625488c8291a05ab870e66c1dd`; its post overload iterates listeners and calls dispatcher `invoke` inline, without an asynchronous executor. Pinned Forge universal 47.4.10 is 2,777,708 B SHA `bb2f67fc423f09c30ac3d83ab629fa5cc6743a0ce1c2febae46602530f17c8f1`. `ChunkEvent` carries the supplied ChunkAccess and its world accessor.
- `DedicatedServer.handleConsoleInput` only appends to `consoleInput`; `handleConsoleInputs` executes queued commands. `DedicatedServer.tickChildren` first completes the normal server/world tick, then drains that console queue. `ServerChunkCache.tick` reaches `ChunkMap.tick/processUnloads`; the latter runs queued unload continuations directly. For an ordinary server-thread, logging-only listener, a stdin ticket-add enqueued after the marker **does not interleave halfway through that same continuation**. This is source-backed sequencing, not a native callback observation. It excludes reentrant commands from a listener/third-party callback, other command transports, and an exception aborting the continuation.

Minimal amendment boundary for independent technical/source review: release-test opt-in property only; fixed Overworld chunk `(11,11)` and real LevelChunk; require the server thread; emit one strict INFO observation per matching event; no inventories, block queries, chunk loads, save/reset operations, command calls, mutable static world cache or new C2S authority. The observer cannot swallow errors or change event cancellation. Use a fresh phase/window-bound marker, and require a following normal console barrier before reacquisition. Preserve unexpected Unload/listener exceptions as failures: the marker itself precedes subsequent listeners and cleanup.

Replace only the *insufficient timing observation* with the real event plus queued-console barrier, keeping the **original single 60 s/240-barrier budget**, late-wake refusal and every live restored-cell/stopped-byte/resource assertion. The amended hook needs its own frozen source review, fixed/unrelated/client/disabled/thread negative controls, fresh packaged JAR identity and Root-native replay. A changed host is not covered by the old Source22 native attempt. No owner policy answer is required for this logging-only copied-world diagnostic, but source/API/runtime admission is not granted by this memo.

Even a successful amended observation would establish the matching Unload event and observed restoration, not instrument every surviving BE callback/provider invalidation. First-save/no-old-record and broader Guard/repair/whole-version Gates remain separate.
