"""Read named cached primary classfiles; never launch Java or a debug report."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parent
J = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')

class R:
    def __init__(self, b): self.b = b; self.p = 0
    def n(self, size):
        assert 0 <= size <= len(self.b) - self.p
        out = self.b[self.p:self.p+size]; self.p += size; return out
    def u1(self): return self.n(1)[0]
    def u2(self): return struct.unpack('>H', self.n(2))[0]
    def u4(self): return struct.unpack('>I', self.n(4))[0]

def parse(b, selected):
    r = R(b); assert r.u4() == 0xcafebabe
    minor, major = r.u2(), r.u2(); cp = [None] * r.u2(); i = 1
    while i < len(cp):
        t = r.u1()
        if t == 1: cp[i] = r.n(r.u2()).decode('utf-8', errors='replace')
        elif t in (7, 8, 16, 19, 20): cp[i] = (t, r.u2())
        elif t in (3, 4): cp[i] = (t, r.n(4).hex())
        elif t in (5, 6): cp[i] = (t, r.n(8).hex()); i += 1
        elif t in (9, 10, 11, 12, 17, 18): cp[i] = (t, r.u2(), r.u2())
        elif t == 15: cp[i] = (t, r.u1(), r.u2())
        else: raise AssertionError(t)
        i += 1
    def ref(i):
        v = cp[i]
        if isinstance(v, str): return v
        if v[0] in (7, 8, 16, 19, 20): return cp[v[1]]
        if v[0] in (9, 10, 11):
            typ = cp[v[2]]
            return ref(v[1]) + '.' + cp[typ[1]] + cp[typ[2]]
        if v[0] in (17, 18):
            typ = cp[v[2]]
            return 'dynamic#' + str(v[1]) + ':' + cp[typ[1]] + cp[typ[2]]
        return str(v)
    r.n(6); r.n(2 * r.u2())
    def attrs():
        out = {}
        for _ in range(r.u2()):
            name = cp[r.u2()]; out[name] = r.n(r.u4())
        return out
    fields = []
    for _ in range(r.u2()):
        access, name, desc = r.u2(), cp[r.u2()], cp[r.u2()]; attrs()
        fields.append({'access': access, 'name': name, 'descriptor': desc})
    all_methods = []; methods = {}
    for _ in range(r.u2()):
        access, name, desc = r.u2(), cp[r.u2()], cp[r.u2()]; a = attrs()
        all_methods.append(name + desc)
        if name not in selected or 'Code' not in a: continue
        cr = R(a['Code']); stack, locals_ = cr.u2(), cr.u2(); code = cr.n(cr.u4())
        p = 0; ins = []
        while p < len(code):
            off = p; op = code[p]; p += 1; operands = 0; reference = None; branch = None
            if op in (0x12, 0x10, 0x15, 0x16, 0x17, 0x18, 0x19, 0x36, 0x37, 0x38, 0x39, 0x3a, 0xa9, 0xbc): operands = 1
            elif op in (0x11, 0x13, 0x14, 0x84, 0xbb, 0xbd, 0xc0, 0xc1) or 0x99 <= op <= 0xa8 or op in (0xc6, 0xc7): operands = 2
            elif 0xb2 <= op <= 0xb8: operands = 2; reference = ref(struct.unpack_from('>H', code, p)[0])
            elif op in (0xb9, 0xba): operands = 4; reference = ref(struct.unpack_from('>H', code, p)[0])
            elif op in (0xc8, 0xc9): operands = 4
            elif op == 0xc5: operands = 3
            elif op in (0xaa, 0xab):
                padding = (-p) % 4; q = p + padding
                if op == 0xaa:
                    low, high = struct.unpack_from('>ii', code, q + 4); assert high >= low
                    operands = padding + 12 + 4 * (high - low + 1)
                else:
                    count = struct.unpack_from('>i', code, q + 4)[0]; assert count >= 0
                    operands = padding + 8 + 8 * count
            elif op == 0xc4: operands = 5 if code[p] == 0x84 else 3
            raw = code[p:p+operands]; assert len(raw) == operands; p += operands
            if op == 0x12: reference = ref(raw[0])
            elif op in (0x13, 0x14, 0xbb, 0xbd, 0xc0, 0xc1): reference = ref(struct.unpack('>H', raw)[0])
            if 0x99 <= op <= 0xa8 or op in (0xc6, 0xc7): branch = off + struct.unpack('>h', raw)[0]
            elif op in (0xc8, 0xc9): branch = off + struct.unpack('>i', raw)[0]
            ins.append({'offset': off, 'opcode_hex': hex(op), 'operand_hex': raw.hex(), 'reference': reference, 'branch_target': branch})
        exceptions = []
        for _ in range(cr.u2()):
            start, end, handler, catch = cr.u2(), cr.u2(), cr.u2(), cr.u2()
            exceptions.append({'start': start, 'end': end, 'handler': handler, 'catch': ref(catch) if catch else 'any'})
        methods[name + desc] = {'access': access, 'stack': stack, 'locals': locals_, 'code_hex': code.hex(), 'instructions': ins, 'exceptions': exceptions}
    return {'major': major, 'minor': minor, 'fields': fields, 'all_methods': all_methods, 'selected_methods': methods}

sha = hashlib.sha256(J.read_bytes()).hexdigest()
assert sha == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
names = {
    'net/minecraft/server/commands/DebugCommand.class': {'register', 'report'},
    'net/minecraft/server/MinecraftServer.class': {'saveDebugReport', 'dumpServerProperties', 'dumpThreads'},
    'net/minecraft/server/level/ServerLevel.class': {'saveDebugReport'},
    'net/minecraft/server/level/ServerChunkCache.class': {'saveDebugReport', 'dumpChunks', 'getChunkNow'},
    'net/minecraft/server/level/ChunkMap.class': {'dumpChunks', 'getVisibleChunkIfPresent', 'getUpdatingChunkIfPresent', 'scheduleUnload', 'processUnloads'},
}
out = {'jar': {'path': str(J), 'bytes': J.stat().st_size, 'sha256': sha}, 'java_launches': 0, 'debug_reports_launched': 0, 'classes': {}}
with zipfile.ZipFile(J) as z:
    for name, selected in names.items():
        b = z.read(name)
        out['classes'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), **parse(b, selected)}
(B/'DEBUG-PRIMARY-02.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
for name, c in out['classes'].items():
    print(name, c['sha256'])
    print('METHODS', '\n'.join(c['all_methods']))
    for method, detail in c['selected_methods'].items():
        print('SELECTED', method, 'EXCEPTIONS', detail['exceptions'])
        for ins in detail['instructions']:
            if ins['reference'] is not None or ins['branch_target'] is not None:
                print(ins)
