# Initial locator failure

The first compound PowerShell read attempted the nonexistent
`ARTIFACTS23-RESULT-01.json` after successfully reading the actual collector
failure note, JUnit and GameTest capture. Tool exit1; original tool output is
not falsely represented as a separate raw log. A later exact directory listing
identified `ARTIFACTS23-01.json` and `ARTIFACTS23-COMPARISON-01.json`. The audit
uses those actual files. No Root/evidence change occurred.

The first independent audit script then exited1 because it used the historical
`src/generated/resources` selector (29 files) instead of actual current
`build.gradle --output src/generated/v1.8/resources` (771 files). It compared
two historical block tags which build.gradle explicitly supersedes. All first
script/derived results remain unchanged. The separately named audit02 corrects
only the current-output selector, adds later static receipt pins, and writes
distinct -02 result files. No Root source/artifact, payload/hash or assertion
is weakened. This is a reviewer selector failure, not two artifact regressions.
