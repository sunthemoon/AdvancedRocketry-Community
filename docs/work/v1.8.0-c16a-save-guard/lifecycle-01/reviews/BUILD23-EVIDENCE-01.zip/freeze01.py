"""Seal a small loose report, never a source tree or redundant archive."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'EVIDENCE-MANIFEST.json', 'SHA256SUMS', 'FREEZE-RESULT-01.json'}
def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')
links = []
for name in ['REVIEW-01.md']:
    path = ROOT / name
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        resolved = (path.parent / target.split('#', 1)[0]).resolve()
        links.append({'source': name, 'target': target, 'exists': resolved.is_file(),
                      'within_evidence': resolved.is_relative_to(ROOT)})
assert all(link['exists'] and link['within_evidence'] for link in links)
write('LINK-CHECK-01.json', {'links': links, 'missing': 0})
files = {p.relative_to(ROOT).as_posix(): pin(p) for p in sorted(ROOT.rglob('*'))
         if p.is_file() and p.name not in EXCLUDED}
assert len(files) < 100 and sum(row['bytes'] for row in files.values()) < 1024**2
write('EVIDENCE-MANIFEST.json', {'files': files, 'files_count': len(files),
                                'bytes': sum(row['bytes'] for row in files.values()),
                                'excluded_sealing_metadata': sorted(EXCLUDED),
                                'zip': 'NOT_CREATED', 'Java_launches': 0})
for name, row in files.items(): assert pin(ROOT / name) == row
(ROOT / 'SHA256SUMS').write_text(''.join(row['sha256'] + '  ' + name + '\n' for name, row in files.items()), encoding='ascii')
write('FREEZE-RESULT-01.json', {'report': pin(ROOT / 'REVIEW-01.md'),
                               'manifest': pin(ROOT / 'EVIDENCE-MANIFEST.json'),
                               'sha256sums': pin(ROOT / 'SHA256SUMS'),
                               'payload_count': len(files), 'payload_bytes': sum(row['bytes'] for row in files.values()),
                               'local_links': len(links), 'missing_links': 0, 'verified': True})
print((ROOT / 'FREEZE-RESULT-01.json').read_text(encoding='utf-8'))
