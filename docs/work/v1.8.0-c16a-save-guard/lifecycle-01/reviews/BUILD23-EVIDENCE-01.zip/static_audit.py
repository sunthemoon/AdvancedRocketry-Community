"""Verify existing static receipts, do not execute the repository checker."""
from pathlib import Path
import collections
import hashlib
import json
import re

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
BASE=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
OUT=Path(__file__).resolve().parent
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(name):return json.loads((BASE/name).read_text(encoding='utf-8'))
result=read('STATIC23-RESULTS-01.json');jobs=[];inputs={}
for item in result['jobs']:
    path=BASE/(item['name']+'-01.log')
    assert path.is_file() and digest(path)==item['log_sha256']
    jobs.append(item)
    inputs[path.name]={'bytes':path.stat().st_size,'sha256':digest(path)}
repository=read('repository-boundary-24.json');receipt=read('repository-boundary-24.result.json');command=read('repository-boundary-24.command.json')
assert digest(BASE/'repository-boundary-24.log')==receipt['log_sha256']
log=(BASE/'repository-boundary-24.log').read_text(encoding='utf-8')
counts=collections.Counter(re.findall(r'^\[(PASS|PENDING|WARN|WARNING|FAIL)\]',log,re.MULTILINE))
assert counts=={'PASS':45} and 'Summary: 45 passed, 0 pending, 0 warnings, 0 failed' in log
assert repository['exit']==receipt['exit']==0
assert repository['release_gate_claimed'] is False and receipt['gate_claim'] is False
assert command['governance_and_validator_pins']==receipt['governance_and_validator_postpins']
assert repository['validator_sha256']==command['governance_and_validator_pins']['scripts/validate_repository.py']
for call in repository['calls']:
    args=call['command']
    assert 'ls-files' in args
    if '--others' in args:
        assert call['foreign_directory_excluded'] and '--exclude=/AdvancedRocketry-Community-v1plus-Development-Docs/' in args
    else:assert not call['foreign_directory_excluded']
helper=BASE/'validate_repository_boundary24.py'
source=helper.read_text(encoding='utf-8')
assert 'validator._bounded_git_stdout = inventory' in source
assert "original = validator._bounded_git_stdout" in source
assert "args.append('--exclude=/' + prefix)" in source
for path in [helper,BASE/'STATIC23-RESULTS-01.json',BASE/'repository-boundary-24.json',BASE/'repository-boundary-24.log',BASE/'repository-boundary-24.result.json',BASE/'repository-boundary-24.command.json']:
    inputs[path.name]={'bytes':path.stat().st_size,'sha256':digest(path)}
for name in ['build23-01.log','gametest23-01.log','gametest23-native-02.log']:
    lines=(BASE/name).read_text(encoding='utf-8').splitlines()
    complete=[{'line':i+1,'text':line} for i,line in enumerate(lines) if 'GAME TESTS COMPLETE' in line or 'required tests passed' in line]
    if name=='build23-01.log':continue
    assert len(complete)==2 and '464 GAME TESTS COMPLETE' in complete[0]['text'] and 'All 464 required tests passed' in complete[1]['text']
    (OUT/(name+'.completion.json')).write_text(json.dumps(complete,indent=2)+'\n',encoding='utf-8')
out={'observed_jobs':jobs,'ordinary_static_zero_count':sum(item['exit']==0 for item in jobs),
     'preserved_nonzero_jobs':[item for item in jobs if item['exit']!=0],
     'repository_raw_line_counts':dict(counts),'repository_elapsed_seconds':receipt['elapsed_seconds'],
     'repository_receipt_pins_match':True,'unchanged_validator_with_explicit_inventory_exclusion':True,
     'repository_checker_rerun':False,'private_directory_read_or_walked_by_reviewer':False,'inputs':inputs}
(OUT/'STATIC-INTEGRITY-01.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('Existing eight-zero/two-nonzero static jobs and45 repository PASS receipts/hash pins verified; no checker rerun.')
