"""Small fixed-commit intake and bounded artifact/static checks, no Java."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
BASE=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
OUT=Path(__file__).resolve().parent
COMMIT='23bec1eb1452e8c8ef37c004606aaed3a2394063'
manifest=json.loads((BASE/'SOURCE23-MANIFEST-01.json').read_text(encoding='utf-8'))
names=['scripts/run_v180_guard_lifecycle_smoke.py','tests/test_run_v180_guard_lifecycle_smoke.py',
       'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java']
rows={}
for name in names:
    raw=subprocess.check_output(['git','show',COMMIT+':'+name],cwd=ROOT)
    row={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    assert row==manifest[name]
    path=OUT/'source23-selected'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    rows[name]=row
(OUT/'FIXED-POSTIMAGES-01.json').write_text(json.dumps({'commit':COMMIT,'files':rows,'whole_source_export':False},indent=2,sort_keys=True)+'\n',encoding='utf-8')
commands=[('static-02',[sys.executable,'-B',str(OUT/'static_audit.py')]),
          ('artifact-independent-01',[sys.executable,'-B','scripts/validate_build_artifact.py',
           str(BASE/'artifacts23-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'),'--expected-version','1.20.1-1.8.0-dev'])]
for label,command in commands:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
    with (OUT/(label+'.log')).open('wb') as log:
        result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    receipt={'command':command,'cwd':str(ROOT),'started_utc':started,
             'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'elapsed_seconds':time.monotonic()-tick,'exit_code':result.returncode,
             'log_sha256':hashlib.sha256((OUT/(label+'.log')).read_bytes()).hexdigest()}
    (OUT/(label+'.json')).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(label,result.returncode,(OUT/(label+'.log')).read_text(encoding='utf-8'))
    if result.returncode:sys.exit(result.returncode)
