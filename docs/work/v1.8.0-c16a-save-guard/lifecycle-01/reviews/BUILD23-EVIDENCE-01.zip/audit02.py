"""Read-only Source23 evidence recomputation; no native/Java/build execution."""
from pathlib import Path, PurePosixPath
import collections
import datetime
import hashlib
import json
import re
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
EVIDENCE=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
BASE=Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')
OUT=Path(__file__).resolve().parent
def pin(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':path.stat().st_size,'sha256':digest}
def write(name,value):
    if name.endswith('-01.json'):name=name[:-8]+'-02.json'
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def read(name):return json.loads((EVIDENCE/name).read_text(encoding='utf-8'))

started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
selected=['SOURCE23-MANIFEST-01.json','SOURCE23-BOUNDARY-01.json','SOURCE23-POSTCHECK-02.json',
 'build23-01-command.json','build23-01-result.json','build23-01-disk-precheck.json','build23-01.log',
 'gametest23-01-command.json','gametest23-01-result.json','gametest23-01-disk-precheck.json','gametest23-01.log',
 'GAMETEST23-CAPTURE-02.json','gametest23-native-02.log','JUNIT23-RESULT-01.json',
 'ARTIFACTS23-01.json','ARTIFACTS23-COMPARISON-01.json','BUILD-COLLECTOR-FAILURE-01.md',
 'run_build23.py','collect_build23_02.py','build-collection-02.log','build-collection-02.exit',
 'artifact23-01.log','artifact23-command-01.json','STATIC23-RESULTS-01.json',
 'repository-boundary-24.log','repository-boundary-24.json','repository-boundary-24.result.json','repository-boundary-24.command.json']
before={name:pin(EVIDENCE/name) for name in selected}
write('INPUTS-01.json',{'root_evidence':str(EVIDENCE),'files':before,
                       'baseline_source22_manifest':{'path':str(BASE/'SOURCE22-MANIFEST-01.json'),**pin(BASE/'SOURCE22-MANIFEST-01.json')},
                       'AGENTS':pin(ROOT/'AGENTS.md'),'Java_native_build_launches':0})
source=read('SOURCE23-MANIFEST-01.json')
previous=json.loads((BASE/'SOURCE22-MANIFEST-01.json').read_text(encoding='utf-8'))
removed=sorted(set(previous)-set(source));changed=sorted(n for n in previous.keys()&source.keys() if previous[n]!=source[n])
added=sorted(set(source)-set(previous));mismatches=[]
assert len(source)<=4000
for name,row in source.items():
    path=PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and 'AdvancedRocketry-Community-v1plus-Development-Docs' not in path.parts
    if pin(ROOT/name)!=row:mismatches.append(name)
build_source=(ROOT/'build.gradle').read_text(encoding='utf-8')
assert "'--output', file('src/generated/v1.8/resources/')" in build_source
generated={n.removeprefix('src/generated/v1.8/resources/'):row for n,row in source.items() if n.startswith('src/generated/v1.8/resources/')}
write('SOURCE-CHECK-01.json',{'source23_inputs':len(source),'source22_inputs':len(previous),
 'added':added,'removed':removed,'changed_baseline_inputs':changed,'current_mismatches':mismatches,
 'generated_inputs':len(generated),'manifest_identity':before['SOURCE23-MANIFEST-01.json']})

xml_rows={};totals=collections.Counter();actual=collections.Counter();timestamps=[];bad=[]
for path in sorted((EVIDENCE/'junit23-01').glob('TEST-*.xml')):
    raw=path.read_bytes();assert len(raw)<=4*1024**2
    root=ET.fromstring(raw);assert root.tag=='testsuite'
    counts={key:int(root.get(key,'0')) for key in ['tests','failures','errors','skipped']}
    cases=root.findall('testcase')
    observed={'tests':len(cases),'failures':sum(len(case.findall('failure')) for case in cases),
              'errors':sum(len(case.findall('error')) for case in cases),'skipped':sum(len(case.findall('skipped')) for case in cases)}
    if counts!=observed:bad.append(path.name)
    totals.update(counts);actual.update(observed);totals['suites']+=1
    timestamp=root.get('timestamp');timestamps.append(timestamp)
    xml_rows[path.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'counts':counts,'actual':observed,'timestamp':timestamp}
build_cmd=read('build23-01-command.json');build_result=read('build23-01-result.json')
start=datetime.datetime.fromisoformat(build_cmd['started_utc']).replace(tzinfo=None)
end=datetime.datetime.fromisoformat(build_result['ended_utc']).replace(tzinfo=None)
outside=[value for value in timestamps if not start<=datetime.datetime.fromisoformat(value)<=end]
write('XML-CHECK-01.json',{'declared':dict(totals),'actual_testcase_counts':dict(actual),'declaration_mismatches':bad,
 'claimed':read('JUNIT23-RESULT-01.json'),'oldest_timestamp':min(timestamps),'newest_timestamp':max(timestamps),
 'timestamps_outside_build_window':outside,'files':xml_rows})

jars={}
for row in read('ARTIFACTS23-01.json'):
    current=Path(row['path']);old=BASE/'artifacts'/current.name
    assert current.parent.resolve()==(EVIDENCE/'artifacts23-01').resolve()
    current_pin=pin(current);assert current_pin=={'bytes':row['bytes'],'sha256':row['sha256']}
    with zipfile.ZipFile(current) as after,zipfile.ZipFile(old) as before_zip:
        current_names=after.namelist();old_names=before_zip.namelist()
        current_crc=after.testzip();old_crc=before_zip.testzip()
        duplicate=len(current_names)-len(set(current_names))
        old_duplicate=len(old_names)-len(set(old_names))
        both=set(current_names)&set(old_names)
        altered=[name for name in sorted(both) if after.read(name)!=before_zip.read(name)]
        new=sorted(set(current_names)-set(old_names));lost=sorted(set(old_names)-set(current_names))
        resources_missing=[];resources_changed=[]
        if not current.name.endswith('-api.jar'):
            for name,identity in generated.items():
                if name not in current_names:resources_missing.append(name);continue
                raw=after.read(name)
                if {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}!=identity:resources_changed.append(name)
        jars[current.name]={'path':str(current),'current':current_pin,'baseline':pin(old),
         'entry_count':len(current_names),'baseline_entry_count':len(old_names),'duplicates':duplicate,'baseline_duplicates':old_duplicate,
         'CRC_error':current_crc,'baseline_CRC_error':old_crc,'added':new,'removed':lost,'changed':altered,
         'whole_bytes_unchanged':current_pin==pin(old),'generated_checked':0 if current.name.endswith('-api.jar') else len(generated),
         'generated_missing':resources_missing,'generated_changed':resources_changed,
         'added_entry_identities':{name:{'bytes':len(after.read(name)),'sha256':hashlib.sha256(after.read(name)).hexdigest()} for name in new}}
write('ARTIFACT-CHECK-01.json',jars)

log_analysis={}
for name in ['build23-01.log','gametest23-01.log','gametest23-native-02.log']:
    lines=(EVIDENCE/name).read_text(encoding='utf-8').splitlines()
    errors=[(index+1,line) for index,line in enumerate(lines) if re.search(r'\[[^\]]+/ERROR\]',line)]
    fatals=[(index+1,line) for index,line in enumerate(lines) if re.search(r'\[[^\]]+/FATAL\]',line)]
    markers=[(index+1,line) for index,line in enumerate(lines) if 'required tests passed' in line or 'tests done' in line or 'BUILD SUCCESSFUL' in line or 'Caching: total files:' in line]
    counter=collections.Counter(re.sub(r'^.*?\[[^\]]+/ERROR\]\s*','',line) for _,line in errors)
    log_analysis[name]={'lines':len(lines),'ERROR_headers':len(errors),'FATAL_headers':len(fatals),
     'markers':[{'line':number,'text':line} for number,line in markers],
     'ERROR_groups':dict(counter),'first_ERROR_excerpt':[{'line':number,'text':line} for number,line in errors[:4]]}
write('LOG-CHECK-01.json',log_analysis)
after_pins={name:pin(EVIDENCE/name) for name in selected};assert before==after_pins
contradictions=[]
if removed or changed or mismatches:contradictions.append('Source baseline/current drift')
if dict(totals)!=read('JUNIT23-RESULT-01.json') or bad or outside:contradictions.append('JUnit declared/actual/freshness mismatch')
for name,row in jars.items():
    if row['duplicates'] or row['CRC_error'] or row['removed'] or row['changed'] or row['generated_missing'] or row['generated_changed']:
        contradictions.append('Artifact content mismatch: '+name)
    claimed=read('ARTIFACTS23-COMPARISON-01.json')[name]
    for key in ['added','removed','changed','whole_bytes_unchanged']:
        if row[key]!=claimed[key]:contradictions.append('Artifact collector mismatch: '+name+'/'+key)
    if row['entry_count']!=claimed['members']:contradictions.append('Artifact member-count mismatch: '+name)
capture=read('GAMETEST23-CAPTURE-02.json')
if log_analysis['gametest23-01.log']['ERROR_headers']!=capture['gradle_error_headers'] or log_analysis['gametest23-native-02.log']['ERROR_headers']!=capture['native_error_headers']:
    contradictions.append('GT ERROR count mismatch')
write('AUDIT-RESULT-01.json',{'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'elapsed_seconds':time.monotonic()-tick,'contradictions':contradictions,'all_selected_evidence_unchanged':True,
 'source_inputs':len(source),'junit':dict(totals),'GT_markers':log_analysis['gametest23-native-02.log']['markers'],
 'build_gradle_exit':build_result['exit_code'],'gametest_gradle_exit':read('gametest23-01-result.json')['exit_code'],
 'corrected_collector_exit_file':int((EVIDENCE/'build-collection-02.exit').read_text().strip()),
 'original_outer_collector_exit':'1; tool-output transcription, no raw outer log',
 'Java_native_executions_by_reviewer':0})
print(json.dumps({'contradictions':contradictions,'source_inputs':len(source),'junit':dict(totals),
                  'jars':[(name,row['entry_count'],row['added']) for name,row in jars.items()],
                  'ERROR_headers':{name:row['ERROR_headers'] for name,row in log_analysis.items()}},indent=2))
sys.exit(1 if contradictions else 0)
