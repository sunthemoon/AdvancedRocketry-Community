# Source23 build evidence: independent audit

## Findings

No unresolved Critical/High/Medium/Low evidence-integrity discrepancy was found
after correcting the reviewer's historical-resource selector. The named build,
JUnit, DataGen, GameTest and artifact observations agree with their raw inputs.
This disposition is **source/build evidence only**. It does not convert the
separate failed native lifecycle attempt into a pass or authorize a Gate.

The original outer collector exit1 is real and preserved as a qualified
transcription, while both actual Gradle jobs exited0. Corrected log capture
has its separate `build-collection-02.exit` value0. These are different command
outcomes, not a normalized single successful collector execution.

## Fixed source/artifact identity

Declared Source23 closure: 2,995 inputs, manifest SHA
`bab73c802f4ae710d5e854a7ccd26417c5c0925a9421172da7b0b3d6288554e4`.
[SOURCE-CHECK-02](SOURCE-CHECK-02.json) recomputes its union with the fixed
2,992-input Source22 manifest: no removed/changed baseline entry and exactly
three additions (observer Java, lifecycle script, test). All declared live
bytes matched during this audit. This is the declared build/tool input set,
not the entire tracked repository.

Root's source-only commit `23bec1eb1452e8c8ef37c004606aaed3a2394063` preserves
the three reviewed postimages. [FIXED-POSTIMAGES-01](FIXED-POSTIMAGES-01.json)
binds their actual Git objects and the individually necessary snapshots under
`source23-selected/`. Subsequent separately authorized Python fixture changes
are outside Source23; this report is not attributed to a moving HEAD/latest
workspace. No whole source tree, archive or JAR was exported.

The independently read [artifact comparison](ARTIFACT-CHECK-02.json):

| Artifact | SHA-256 | Bytes / ZIP entries | Difference from Source22 |
| --- | --- | --- | --- |
| Main | `5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9` | 5,443,263 / 3,307 | one observer `.class` added |
| Sources | `4ab8254184549cef0ca0edbdb3d256ee8215ecf2470a7036b453baddfa8053a3` | 2,622,232 / 2,663 | one observer `.java` added |
| API | `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da` | 51,045 / 48 | whole JAR byte-identical |

All six current/baseline archives have no duplicate entry and no CRC error.
No existing main/source entry changed or disappeared. All 771 current
`src/generated/v1.8/resources` bytes match their entries in **both** non-API
JARs. Existing packaged resources also remain byte-identical to Source22.
The API comparison is exact bytes, not merely class-name compatibility.

## Actual build, test and DataGen observations

Root's recorded Java17/offline/no-daemon/workers2/2GiB command was
`gradlew.bat clean build test runData`. Actual Gradle exit0,
202.70069019997027 seconds. Raw log ends `BUILD SUCCESSFUL in 3m 22s`;
26 tasks: 18 executed, seven from cache, one up-to-date. Both-drive prechecks
exceed the declared 10,000,000,000-byte threshold. No reviewer Java ran.

[XML-CHECK-02](XML-CHECK-02.json) independently reads all 330 preserved XML
files: 1,765 declared tests and 1,765 actual testcase elements; zero actual or
declared failure/error/skipped elements. No suite declaration mismatch. All
timestamps fall inside the recorded build window (fresh suite timestamps,
not borrowed stale XML). File-by-file hashes are retained in this derived
inventory rather than duplicating XML.

The DataGen raw line is exactly qualified: total files771, old count771,
new count772, removed stale0, written0. The current output directory is derived
from pinned build.gradle `--output src/generated/v1.8/resources/`; its 771
declared files and bytes are unchanged. The raw `new count772` is retained,
not rewritten as771 or treated as a newly packaged extra resource.

Root's `runGameTestServer` Gradle exit0, 230.57891550008208 seconds. Both the
Gradle and separately copied native logs contain `464 GAME TESTS COMPLETE`
and `All 464 required tests passed`. Adjacent native lines show normal shutdown.
Exact line excerpts are in the two `.completion.json` files; original large
logs are pinned in [INPUTS-02](INPUTS-02.json), not duplicated.

[LOG-CHECK-02](LOG-CHECK-02.json) independently counts **61 ERROR headers in
each GameTest log**, zero FATAL headers. The build log has zero ERROR/FATAL.
The GameTest ERROR messages include 24 oversized recipe-save refusals,
16 machine_menu version rejections, intentional migration failure/save pairs,
three unresolved-disk-root diagnostics, recipe-binding and satellite failure
diagnostics, and one oversized combustion refusal. Full grouped counts are
retained. Required-test success is not an error-free-log claim or a blanket
waiver of these lines. This audit does not independently re-review each
negative scenario or admit unrelated runtime errors.

## Collector/static receipt integrity

Root's `run_build23.py` executed both successful Gradle jobs, then attempted
the wrong `run/gameTestServer/logs/latest.log` path and failed before creating
its first native-log/postcheck outputs. `BUILD-COLLECTOR-FAILURE-01.md` explicitly
states that original outer failure is transcribed from exec/write_stdin tool
output, not an original raw outer-output file. The script is preserved.

The separate corrected collector reads configured `build/gametest/logs/latest.log`,
produces `gametest23-native-02.log`/capture02/postcheck02 and has its own log and
exit0 file. Independently recomputed source/member/error observations agree
with those corrected products. Their success does not erase the original
collector exit1 or imply a first native capture existed.

[STATIC-INTEGRITY-01](STATIC-INTEGRITY-01.json) verifies the existing targeted
receipts and raw log hashes without rerunning the long repository checker:
eight jobs exit0; ledger-closure and dirty-diff exit1 remain unchanged. The
repository-boundary24 log has 45 actual PASS lines, no pending/warning/failure
line, matching its summary, exit0 and 307.631619-second receipt. Governance/
validator pre/post pins agree. The inspected wrapper changes only the bounded
Git inventory call by appending the explicit private-directory exclusion; the
validator file is unchanged. No private bundle was read or walked here.

Existing root artifact validator receipt reports exit0. This reviewer also
ran the bounded Python artifact validator independently with explicit
`--expected-version 1.20.1-1.8.0-dev`: [actual exit0](artifact-independent-01.json),
four PASS lines and expected main SHA/3,307 entries in
[artifact-independent-01.log](artifact-independent-01.log).

## Reviewer commands and preserved failures

- [audit.py](audit.py): first actual exit1, results preserved under -01 names.
  It selected historical `src/generated/resources` (29 files) and therefore
  compared two intentionally superseded historical block tags against current
  packaged tags. These are reviewer selector mistakes, not two artifact bugs.
- Separately corrected [audit02.py](audit02.py): actual exit0,
  [command/time/raw log](audit-02-command-result.json) and
  [AUDIT-RESULT-02](AUDIT-RESULT-02.json), no contradictions. No Root payload,
  hash, budget or assertion changed to obtain that result.
- [static_audit.py](static_audit.py): actual exit0;
  [captured command](static-02.json), verifying existing receipts only.
- [final_checks.py](final_checks.py): fixed23bec selected-source intake and
  bounded independent artifact validation, actual exit0.
- The initial absent artifact-result filename locator and first selector
  failure are described in [INITIAL-LOCATOR-FAILURE-01](INITIAL-LOCATOR-FAILURE-01.md).
  Original terminal observations are not falsely presented as raw file logs.

All individually named original evidence files were hash-stable during the
audit. No Root/workspace/source/AGENTS/risk-register edit, Java/Gradle/native/
client, network/install, Git write, archive copy, whole-tree export, OpenPet or
foreign cleanup was performed. Only a small external loose report/derived
inventory and three necessary individual source snapshots were written.

## Scope limits

This is an actual-evidence/mechanical member comparison audit, not renewed
independent source review of earlier authored K3/menu/value modules, nor a
new full-regression execution by this reviewer. Root executes the build and
GameTest commands; this reviewer recomputes their saved results and bounded
Python artifact/static checks. Earlier source reviews remain separate.

Native lifecycle02 is separately reported **FAIL** (no unload-begin within the
bounded observation). It is not inside this build-result audit and is never
borrowed as a pass. Actual unload/callbacks, old-record restoration, first save,
saturation, cross-store/crash conservation, repair/risk acceptance, physical
hatches, V1/V2 and version Required Gates remain unverified/unclosed here.
Source-only delivery and these development build checks do not close C16a or
the v1.8 ledger.
