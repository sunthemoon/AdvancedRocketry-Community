"""Bind exact native stack and selected public observation/event methods."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OWN = Path(__file__).resolve().parent
HELPER = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [node for node in ast.parse(HELPER.read_text('utf-8')).body
         if isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
namespace = {'__file__': str(HELPER)}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(HELPER), 'exec'), namespace)
mapped = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
native = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03/server/libraries/net/minecraft/server/1.20.1-20230612.114412/server-1.20.1-20230612.114412-srg.jar')
out = {'inputs': {}, 'methods': {}, 'Java_native_launches': 0}
for jar, selections in [
    (mapped, {
        'net/minecraftforge/event/level/ChunkEvent.class': {'<init>'},
        'net/minecraftforge/event/level/ChunkEvent$Unload.class': {'<init>'},
        'net/minecraftforge/event/level/LevelEvent.class': {'<init>', 'getLevel'},
        'net/minecraft/world/level/chunk/LevelChunk.class': {'getWorldForge', 'setLoaded', 'getLevel'},
        'net/minecraft/server/level/ServerLevel.class': {'noSave'},
        'net/minecraft/server/level/ChunkHolder.class': {'getLastAvailable'},
        'net/minecraft/server/level/ChunkMap.class': {'saveChunkIfNeeded'},
    }),
    (native, {
        'net/minecraft/server/level/ChunkMap.class': {'m_198874_', 'm_140353_', 'm_140280_', 'm_140258_'},
    })]:
    raw = jar.read_bytes()
    out['inputs'][str(jar)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if jar == mapped:
        assert out['inputs'][str(jar)]['sha256'] == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
    with zipfile.ZipFile(jar) as archive:
        for name, selected in selections.items():
            blob = archive.read(name)
            methods = namespace['parse'](blob, selected)['selected_methods']
            out['methods'][str(jar) + '!' + name] = {
                'class_bytes': len(blob), 'class_sha256': hashlib.sha256(blob).hexdigest(),
                'selected_methods': methods}
            print('CLASS', jar.name, name)
            for method, facts in methods.items():
                print('METHOD', method, 'access', facts['access'])
                for instruction in facts['instructions']:
                    if instruction['reference'] is not None:
                        print(instruction['offset'], instruction['reference'])
stdout = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03/removal-availability-reload/stdout.txt')
raw = stdout.read_bytes()
out['inputs'][str(stdout)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
lines = raw.decode('utf-8').splitlines()
out['post_not_loaded_stack_excerpt'] = [{'line': i, 'text': line} for i, line in enumerate(lines, 1)
                                        if 661 <= i <= 718]
(OWN / 'EVENT-STACK-03.json').write_text(json.dumps(out, indent=2) + '\n', 'utf-8')
