# Tool observations retained separately from native outcome

The first bounded PowerShell intake guessed `guard-lifecycle-01/NATIVE-RESULT-03.json`.
Its exact reader error was: `Cannot find path 'D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/NATIVE-RESULT-03.json' because it does not exist.`
The compound shell command continued and returned exit0; this is not a successful
outer-receipt read. The owner then identified the actual immutable locator
`guard-lifecycle-01/native-03-result.json`, which was separately read.

A later named manifest read emitted a truncated console result (158,660 approximate
tokens before truncation). No complete source-closure verification is inferred from
that output. Subsequent checks select individually named manifest entries and
record only their bounded identities; they do not walk the repository or runtime.

These are reader/tool observations, not native outcomes or product findings.
