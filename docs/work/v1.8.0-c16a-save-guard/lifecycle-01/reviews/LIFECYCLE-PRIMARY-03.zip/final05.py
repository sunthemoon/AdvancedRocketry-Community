"""Recheck only named inputs, then seal this small owned evidence directory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
assert OWN == Path('D:/ARCE-Task-Evidence/v1.8.0/agn3-bcad519a7e')
assert not (OWN / 'INTERNAL-MANIFEST.json').exists()


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


intake = json.loads((OWN / 'INTAKE-01.json').read_text('utf-8'))
checks = []
for name, expected in intake['pins'].items():
    if name.startswith(intake['fixed_context_commit'] + ':'):
        result = subprocess.run(['git', '-C', str(ROOT), 'show', name], capture_output=True)
        assert result.returncode == 0, result.stderr
        actual = ident(result.stdout)
    else:
        actual = ident(Path(name).read_bytes())
    checks.append({'name': name, 'expected': expected, 'actual': actual, 'agrees': actual == expected})
extra = json.loads((OWN / 'EVENT-STACK-03.json').read_text('utf-8'))
for name, expected in extra['inputs'].items():
    actual = ident(Path(name).read_bytes())
    checks.append({'name': name, 'expected': expected, 'actual': actual, 'agrees': actual == expected})
old = Path('D:/ARCE-Task-Evidence/v1.8.0/agnf-1b7aa2336c')
for name, expected_sha in [
    ('REVIEW-NATIVE02.md', '76f1053e12fab5497592dd527697e556a4a70b52cc80a861e2514ba40e84f387'),
    ('INTERNAL-MANIFEST.json', '72083029929d4f9a61180b0f5076c7746e4b6fa480ff0c349fc590083694c090')]:
    actual = ident((old / name).read_bytes())
    checks.append({'name': str(old / name), 'expected_sha256': expected_sha, 'actual': actual,
                   'agrees': actual['sha256'] == expected_sha})
failures = [check for check in checks if not check['agrees']]
assert not failures, failures
report = OWN / 'REVIEW-NATIVE03.md'
for target in re.findall(r'\]\(([^)]+)\)', report.read_text('utf-8')):
    assert ':' not in target and not target.startswith('/'), target
    assert (OWN / target).resolve().is_file(), target
controls = json.loads((OWN / 'CONTROLS-04.json').read_text('utf-8'))
assert controls['tests'] == 7 and controls['failures'] == controls['errors'] == controls['skips'] == 0
receipt = {'named_input_checks': checks, 'mismatches': len(failures), 'report': ident(report.read_bytes()),
           'controls': controls, 'actual_native03_outcome': 'FAIL',
           'findings': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0},
           'write_scope': str(OWN), 'created_C_paths': [], 'created_archives_or_runtime_copies': [],
           'deleted_paths': [], 'Java_native_launches': 0, 'old_native02_evidence_unchanged': True}
(OWN / 'FINAL-RECHECK-05.json').write_text(json.dumps(receipt, indent=2) + '\n', 'utf-8')
files = {}
for path in sorted(OWN.iterdir(), key=lambda p: p.name):
    assert path.is_file() and not path.is_symlink(), path
    files[path.name] = ident(path.read_bytes())
manifest = {'scope': 'small native03 follow-up; no archive/fullsource/runtime export',
            'files': files, 'file_count': len(files), 'total_bytes': sum(p['bytes'] for p in files.values())}
destination = OWN / 'INTERNAL-MANIFEST.json'
destination.write_text(json.dumps(manifest, indent=2) + '\n', 'utf-8')
print(json.dumps({'report': receipt['report'], 'manifest': ident(destination.read_bytes()),
                  'files': len(files), 'total_bytes': manifest['total_bytes'],
                  'named_input_checks': len(checks), 'mismatches': len(failures),
                  'created_C_paths': [], 'Java_native_launches': 0}, indent=2))
