"""Selected immutable primary method facts only; no Java or full class export."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OWN = Path(__file__).resolve().parent
HELPER = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
nodes = [node for node in ast.parse(HELPER.read_text('utf-8')).body
         if isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))]
namespace = {'__file__': str(HELPER)}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(HELPER), 'exec'), namespace)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
raw = jar.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
selections = {
    'net/minecraft/server/level/ServerChunkCache.class': {
        'getChunkDebugData', 'getVisibleChunkIfPresent', 'getChunkNow', 'tick', 'runDistanceManagerUpdates'},
    'net/minecraft/server/level/ChunkMap.class': {
        'getChunkDebugData', 'getDistanceManager', 'getVisibleChunkIfPresent', 'getUpdatingChunkIfPresent',
        'processUnloads', 'scheduleUnload', 'lambda$scheduleUnload$14', 'lambda$scheduleUnload$15', 'tick'},
    'net/minecraft/server/level/DistanceManager.class': {
        'getTicketDebugString', 'getTickets', 'runAllUpdates', 'purgeStaleTickets'},
    'net/minecraft/server/level/ChunkHolder.class': {
        'getTicketLevel', 'getFullChunkFuture', 'getChunkToSave', 'getLastAvailableStatus'},
}
out = {'primary_jar': {'path': str(jar), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
       'parser': {'path': str(HELPER), 'sha256': hashlib.sha256(HELPER.read_bytes()).hexdigest()},
       'classes': {}, 'Java_native_launches': 0}
with zipfile.ZipFile(jar) as archive:
    for name, selected in selections.items():
        blob = archive.read(name)
        parsed = namespace['parse'](blob, selected)
        methods = parsed['selected_methods']
        out['classes'][name] = {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(),
                               'methods': methods}
        print('CLASS', name)
        for method, facts in methods.items():
            print('METHOD', method, 'access', facts['access'])
            for instruction in facts['instructions']:
                if instruction['reference'] is not None or instruction['branch_target'] is not None:
                    print(instruction['offset'], instruction['reference'], instruction['branch_target'])
(OWN / 'SELECTED-PRIMARY-02.json').write_text(json.dumps(out, indent=2) + '\n', 'utf-8')
