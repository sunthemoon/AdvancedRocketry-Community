# Native guard lifecycle attempt 03: bounded failure investigation

## Findings and disposition

No newly reproduced production or observer source defect is established by the
named evidence (**0 Critical / 0 High / 0 Medium / 0 Low**). This is not a passing
native result: the actual outer command and its only phase both remain **FAIL**.
Target unload eligibility, event execution and cleanup remain verification gaps.

The original unchanged-spawn START explanation is no longer sufficient for this
attempt. The transcript confirms the exact relocation command and success before
the guarded mutations. Under the pinned primary implementation this removes the
old START ticket and adds the new one; the new standard START halo cannot retain
the target by the earlier distance13/level35 argument. Actual residual ticket
levels, propagation state, holders and pending futures were not recorded, so this
does not identify the repeat failure's unique cause or prove every ticket absent.

## Exact actual scope and identities

The outer receipt is `guard-lifecycle-01/native-03-result.json`: exit1,
88.472855500062 seconds, `2026-10-04T09:52:10.961818+00:00` to
`2026-10-04T09:53:39.435645+00:00`. The only phase receipt is FAIL with
`removal_cut=true`, timing out on the original unload marker. Its 26 commands stop
at the false-loaded predicate's closing barrier. There is no reacquisition,
restoration assertion, clean-stop command, second host or stopped-record verdict
in this run. [Named pins, receipts and exact excerpts](INTAKE-01.json).

Source23 means the existing observer host artifact, 5,443,263 B SHA-256
`5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9`.
Both that artifact and the actual installed native03 host were independently
hashed equal, as were the named compatibility fixture and its installed copy.
The launch retains `advancedrocketrycommunity.releaseTestHooks=true`.
The captured Python tool is 14,145 B SHA
`4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad`;
its focused test file is 13,600 B SHA
`e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16`.
Individually read mandatory context is bound to fixed
`23bec1eb1452e8c8ef37c004606aaed3a2394063`, not moving HEAD. The setup manifest
and boundary/postcheck receipts are pinned as named observations, not a claim
that this investigator replayed all2995 source inputs or the entire source-world
and library inventories. No world scan was performed.

### Transcript, without substituting expected outcomes

- `stdout.txt:150-153`: LOADED, its barrier, exact vanilla
  `Set the world spawn point to 256, 74, -256 [0.0]`, then the fresh spawn barrier.
- `154-160`: original tank and AIR marker acknowledgements, followed by live marker
  mutation. `411-412`: culprit removal acknowledged. Initial and post-removal
  explicit-save windows each contain three actual EventBus/ChunkMap refusal pairs.
- `657-660`: forced mark removed, then NOT_LOADED and its barrier. `661-718` contains
  another refusal pair and the native stack. This supports sticky refusal after
  live removal, not resource durability, target event execution or disposal.
- `debug.log:346`: automatic subscription attempt to FORGE. The actual stdout,
  latest.log and debug.log contain no `ARCE_GUARD_UNLOAD_BEGIN` substring at all.
  The strict original regex accepts a synthetic correctly framed line and rejects
  wrong fixed coordinates; absence is therefore not just a regex miss.

## Primary interpretation and what has changed

The previous immutable [native02 report](../agnf-1b7aa2336c/REVIEW-NATIVE02.md),
SHA `76f1053e12fab5497592dd527697e556a4a70b52cc80a861e2514ba40e84f387`,
and its manifest `72083029929d4f9a61180b0f5076c7746e4b6fa480ff0c349fc590083694c090`
are untouched. Its source-backed standard START22/MAX_LEVEL45 facts still apply;
its Medium fixture issue is not retroactively a unique native02 causal proof.

The new spawn chunk is `(16,-16)` and target `(11,11)` is distance27. Standard
START therefore contributes49, greater than45. Pinned `setDefaultSpawnPos` stores
the new spawn, removes old START radius11 and adds new START radius11 before its
success acknowledgement. Native03 has that actual acknowledgement and barrier.
This removes the unchanged-standard-START prerequisite problem under those
semantics; it does not empirically expose all neighboring/mod/player tickets.

Selected mapped primary JAR is Forge47.4.10/Minecraft1.20.1,
19,355,242 B SHA
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
[Selected methods and offsets](SELECTED-PRIMARY-02.json),
[event bridge and actual runtime stack context](EVENT-STACK-03.json):

1. `ServerChunkCache.tick` purges stale tickets, runs distance updates, then calls
   `ChunkMap.tick`. That routine skips `processUnloads` when `ServerLevel.noSave()`
   is true. Processing considers `toDrop`, moves holders to `pendingUnloads`, queues
   a continuation on `getChunkToSave()`, and separately iterates visible holders for
   periodic saving. Queue/time/future stages are distinct from FULL/ENTITY_TICKING
   readiness and from the observer's event. No arbitrary longer sleep is a proof.
2. The actual post-NOT_LOADED stack calls `m_198874_` from `m_140353_` and
   `m_140280_`. The named runtime's on-disk SRG methods directly show the visible
   holder iteration and periodic save call; corresponding mapped primary names are
   `saveChunkIfNeeded`, `processUnloads` and `tick`. This is not the
   `scheduleUnload` continuation. Thus that stack supports reaching the processing
   routine at17:52:39 (and a visible-holder save), not the target's drop/event.
   The on-disk SRG JAR is pre-runtime Forge transformation; no literal full-byte
   equivalence to the transformed class or mapped Forge class is asserted.
3. For a normal LevelChunk, `setLoaded(false)` only changes its loaded flag.
   `getWorldForge()` still returns its stored Level; ChunkEvent passes that value
   through LevelEvent. A null level merely caused by clearing the loaded flag is
   not supported by this source path. Actual event arguments were not captured.
4. The same compiled observer class hash from the unchanged Source23 JAR remains
   `e003f509a5a2b710b4398d22a87713445778c626148317d0a242b51e73bf70b4`.
   Its fixed opt-in/server-Level/Overworld/server-thread/LevelChunk/x=z11 filters,
   annotations and logger were previously independently inspected. The new debug
   subscription line is consistent with an attempt but precedes class init/register;
   it is not callback proof. No live counterexample to a particular filter,
   registration, or effective INFO filtering was captured here.

## One optional bounded non-loading observation

A diagnostic-only, fixed Overworld/chunk11,11/server-thread query can return
`level.noSave()` plus
`level.getChunkSource().getChunkDebugData(new ChunkPos(11,11))`.
Both are public primary APIs. The wrapper delegates to a visible-holder map lookup;
its returned debug text describes the holder ticket level, last available statuses
and full status, or literal `null` when that map has no holder. The status helpers
read the fixed status list and use completed-future `getNow`, not loader calls or
blocking `join`. See the independently executed [consistency controls](CONTROLS-04.json).

This is a feasibility proposal, not an admitted command/API or implementation.
An eventual hook should be opt-in/fixed coordinates, use the same logger and strict
server-thread INFO framing, cap and escape the text (for example a separately
reviewed256 UTF-8-byte cap with explicit truncation), and share the existing single
60s/240-report budget. It must not force loads, invoke `getChunk`, update tickets,
wait on futures, traverse worlds, or expose arbitrary supplied positions. Capture
after the existing false predicate, without reacquiring the target to inspect it.

A retained ticket level would distinguish continued visible retention from the
predicate's readiness loss. `null` is only visible-map absence: pending unload,
callback/BE cleanup completion and disk preservation remain separate. This query
does not identify a contributing neighboring ticket's owner or enumerate all
tickets. `DistanceManager.getTicketDebugString` is protected and reports only the
first local ticket; private `getTickets` uses computeIfAbsent and is not a public
read-only diagnostic boundary. Do not invent access/reflection/coremod authority
or use an unbounded debug dump. The observed noSave state and raw debug output
must determine the interpretation rather than a required answer embedded in
the proposed hook.

## Checks, limits and ownership

`python -B intake01.py`, `primary02.py`, `context03.py`, `controls04.py` all exit0.
Seven independent consistency tests pass with0 failures/errors/skips. They check
the actual setup line and negative framing, stage ordering, marker absence,
public/non-loading API facts, protected/private API boundaries, event-Level
retention and periodic-save stack distinction. These are static/receipt checks,
not native execution or a ticket simulation. The original missing guessed outer
locator and truncated manifest-console read are retained in
[tool observations](TOOL-OBSERVATIONS.md); neither is disguised as a successful
full receipt/closure read.

Completed scope: bounded transcript, named identities, selected primary analysis
and observation feasibility. Uncompleted scope: live residual tickets/holder
state, callback execution and completed cleanup, restoration/native byte oracle,
first-save/saturation/repair/crash/client/peer/GPU and version Gates. All three
actual failed attempts remain failures; this report grants no policy, risk, ADR,
API, writer or runtime acceptance. The next existing-policy leaf is independently
reviewed fixed non-loading state observation, if Root elects it, followed by an
unchanged strict event/restoration/record attempt with fresh evidence.

Only the already-started owned directory
`D:/ARCE-Task-Evidence/v1.8.0/agn3-bcad519a7e` was written. No C-drive path,
archive, candidate/server/world copy, repo/source/AGENTS change, deletion or
process action was created by this task. No Java/Gradle/native/client/network or
private documentation access occurred. The later instruction to place future
helpers under `D:/GitHub/ARCE-Task-Evidence` is acknowledged; no additional directory
was created after that instruction. Root alone coordinates cleanup/integration.
