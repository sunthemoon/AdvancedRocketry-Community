"""Independent bounded consistency controls, not a server or ticket simulation."""
import ast
import json
from pathlib import Path
import re
import unittest

OWN = Path(__file__).resolve().parent
intake = json.loads((OWN / 'INTAKE-01.json').read_text('utf-8'))
primary = json.loads((OWN / 'SELECTED-PRIMARY-02.json').read_text('utf-8'))
extra = json.loads((OWN / 'EVENT-STACK-03.json').read_text('utf-8'))
script = Path('D:/GitHub/AdvancedRocketry-Community/scripts/run_v180_guard_lifecycle_smoke.py')
module = ast.parse(script.read_text('utf-8'))
assignments = [node for node in module.body if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id in ('COPY_SPAWN_SUCCESS', 'UNLOAD_BEGIN')
                       for t in node.targets)]
namespace = {'re': re}
exec(compile(ast.Module(body=assignments, type_ignores=[]), str(script) + '[two regexes only]', 'exec'), namespace)
stdout = intake['excerpts']['stdout.txt']


def method(classname, prefix):
    methods = primary['classes'][classname]['methods']
    return next(facts for name, facts in methods.items() if name.startswith(prefix))


def refs(facts):
    return [i['reference'] for i in facts['instructions'] if i['reference'] is not None]


class Controls(unittest.TestCase):
    def test_actual_setup_acknowledgement_and_rejections(self):
        line = intake['phase_receipt']['copy_spawn_setup']
        pattern = namespace['COPY_SPAWN_SUCCESS']
        self.assertIsNotNone(pattern.fullmatch(line))
        for wrong in (line.replace('-256', '-32'), line.replace('INFO', 'ERROR'),
                      line.replace('Server thread', 'Worker thread'), line + ' extra'):
            self.assertIsNone(pattern.fullmatch(wrong))

    def test_recorded_stage_order(self):
        def line_of(fragment):
            return next(row['line'] for row in stdout if fragment in row['text'])
        self.assertLess(line_of('ARCE_GUARD_LOADED'), line_of('Set the world spawn point'))
        self.assertLess(line_of('Set the world spawn point'), line_of('ARCE_GUARD_COPY_SPAWN_END'))
        self.assertLess(line_of('ARCE_GUARD_COPY_SPAWN_END'), line_of('ARCE_GUARD_MARKER_MUTATED'))
        self.assertLess(line_of('ARCE_GUARD_ROOT_REMOVED'), line_of('Unmarked chunk'))
        self.assertLess(line_of('Unmarked chunk'), line_of('ARCE_GUARD_NOT_LOADED'))

    def test_missing_marker_is_not_a_regex_observation(self):
        for name in ('stdout.txt', 'latest.log', 'debug.log'):
            path = next(Path(p) for p in intake['pins'] if p.endswith('/' + name) or p.endswith('\\' + name))
            self.assertNotIn('ARCE_GUARD_UNLOAD_BEGIN', path.read_text('utf-8'))
        valid = '[17:52:40] [Server thread/INFO] [advancedrocketrycommunity/]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11'
        self.assertIsNotNone(namespace['UNLOAD_BEGIN'].fullmatch(valid))
        self.assertIsNone(namespace['UNLOAD_BEGIN'].fullmatch(valid.replace('11,11', '12,11')))

    def test_public_debug_methods_do_not_request_loads(self):
        wrapper = method('net/minecraft/server/level/ServerChunkCache.class', 'getChunkDebugData(')
        debug = method('net/minecraft/server/level/ChunkMap.class', 'getChunkDebugData(')
        self.assertEqual(wrapper['access'] & 1, 1)
        self.assertEqual(debug['access'] & 1, 1)
        calls = refs(wrapper) + refs(debug)
        self.assertTrue(any('getVisibleChunkIfPresent' in r for r in calls))
        for forbidden in ('getChunkFuture', 'addTicket', 'addRegionTicket', '.join(', '.getChunk('):
            self.assertFalse(any(forbidden in r for r in calls), forbidden)
        self.assertTrue(any('getTicketLevel' in r for r in calls))

    def test_ticket_string_is_not_a_public_complete_ticket_api(self):
        debug = method('net/minecraft/server/level/DistanceManager.class', 'getTicketDebugString(')
        tickets = method('net/minecraft/server/level/DistanceManager.class', 'getTickets(')
        self.assertEqual(debug['access'] & 4, 4)
        self.assertEqual(tickets['access'] & 2, 2)
        self.assertTrue(any('SortedArraySet.first' in r for r in refs(debug)))
        self.assertTrue(any('computeIfAbsent' in r for r in refs(tickets)))

    def test_event_level_is_not_cleared_by_loaded_flag(self):
        methods = next(v['selected_methods'] for k, v in extra['methods'].items()
                       if k.endswith('!net/minecraft/world/level/chunk/LevelChunk.class'))
        self.assertEqual(refs(methods['setLoaded(Z)V']), ['net/minecraft/world/level/chunk/LevelChunk.loadedZ'])
        self.assertIn('net/minecraft/world/level/chunk/LevelChunk.levelLnet/minecraft/world/level/Level;',
                      refs(methods['getLevel()Lnet/minecraft/world/level/Level;']))

    def test_post_false_predicate_stack_uses_periodic_save_path(self):
        stack = '\n'.join(row['text'] for row in extra['post_not_loaded_stack_excerpt'])
        self.assertIn('m_198874_', stack)
        self.assertIn('m_140353_', stack)
        self.assertNotIn('m_140181_', stack)
        self.assertNotIn('lambda$scheduleUnload', stack)
        raw_methods = next(v['selected_methods'] for k, v in extra['methods'].items()
                           if k.endswith('srg.jar!net/minecraft/server/level/ChunkMap.class'))
        process = raw_methods['m_140353_(Ljava/util/function/BooleanSupplier;)V']
        self.assertTrue(any('f_140130_' in r for r in refs(process)))
        self.assertTrue(any('m_198874_' in r for r in refs(process)))


result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
(OWN / 'CONTROLS-04.json').write_text(json.dumps({
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skips': len(result.skipped), 'Java_native_launches': 0,
    'runtime_ticket_map_or_callback_execution_proved': False}, indent=2) + '\n', 'utf-8')
raise SystemExit(not result.wasSuccessful())
