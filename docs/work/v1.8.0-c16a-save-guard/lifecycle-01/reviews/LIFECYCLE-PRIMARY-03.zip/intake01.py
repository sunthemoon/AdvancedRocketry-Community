"""Bounded, named native03 intake; no world walks or runtime mutation."""
import hashlib
import json
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
FIXED = '23bec1eb1452e8c8ef37c004606aaed3a2394063'


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    raw = path.read_bytes()
    pins[str(path)] = ident(raw)
    return raw


pins = {}
outer = json.loads(read(E / 'native-03-result.json'))
phase = E / 'native-03/removal-availability-reload'
selected = ['receipt.json', 'commands.json', 'launch.json', 'stdout.txt', 'latest.log', 'debug.log']
blobs = {name: read(phase / name) for name in selected}
inputs = json.loads(read(E / 'native-03/inputs.json'))
postchecks = {name: json.loads(read(E / name)) for name in [
    'NATIVE-POSTCHECK-03.json', 'native-03/input-postcheck.json', 'SETUP03-BOUNDARY-01.json']}
read(E / 'native-03-command.json')
manifest = json.loads(read(E / 'SETUP03-MANIFEST-01.json'))
docs = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
        'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
        'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
        'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
        'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
context = {}
for rel in docs:
    result = subprocess.run(['git', '-C', str(ROOT), 'show', FIXED + ':' + rel], capture_output=True)
    assert result.returncode == 0, (rel, result.stderr)
    expected = manifest[rel]
    actual = ident(result.stdout)
    assert actual == expected, (rel, actual, expected)
    pins[FIXED + ':' + rel] = actual
    text = result.stdout.decode('utf-8')
    context[rel] = [line for line in text.splitlines() if line.startswith('#') or
                    any(x in line for x in ('Required Gate', 'IN_PROGRESS', 'IN PROGRESS', 'v1.8.0'))]
live = ['AGENTS.md', 'scripts/run_v180_guard_lifecycle_smoke.py',
        'tests/test_run_v180_guard_lifecycle_smoke.py',
        'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java']
for rel in live:
    raw = read(ROOT / rel)
    assert ident(raw) == manifest[rel], (rel, ident(raw), manifest[rel])
for which in ('host', 'fixture'):
    expected = inputs[which]
    raw = read(Path(expected['path']))
    assert ident(raw) == {k: expected[k] for k in ('bytes', 'sha256')}
    installed = E / 'native-03/server/mods' / expected['name']
    actual = ident(read(installed))
    assert actual == ident(raw), installed

lines = {}
needles = ('Set the world spawn point', 'ARCE_GUARD_', 'Unmarked chunk',
           'Auto-subscribing io.github.sunthemoon.advancedrocketrycommunity.gametest.GuardedChunkUnloadObservation',
           'Exception caught during firing event', 'Failed to save chunk', 'Done (')
for name in ('stdout.txt', 'latest.log', 'debug.log'):
    text = blobs[name].decode('utf-8')
    lines[name] = [{'line': i, 'text': line} for i, line in enumerate(text.splitlines(), 1)
                   if any(n in line for n in needles)]
    if name != 'debug.log':
        assert 'ARCE_GUARD_UNLOAD_BEGIN' not in text
out = {'pins': pins, 'fixed_context_commit': FIXED, 'context_read': context,
       'outer': outer, 'phase_receipt': json.loads(blobs['receipt.json']),
       'commands': json.loads(blobs['commands.json']), 'launch': json.loads(blobs['launch.json']),
       'bounded_postcheck_receipts': postchecks,
       'source_world_full_inventory_independently_replayed': False,
       'excerpts': lines, 'Java_native_launches': 0}
(OWN / 'INTAKE-01.json').write_text(json.dumps(out, indent=2) + '\n', 'utf-8')
print(json.dumps({'pins': len(pins), 'outer_exit': outer['exit_code'],
                  'elapsed_seconds': outer['elapsed_seconds'],
                  'phase_result': out['phase_receipt']['result'],
                  'copy_spawn_setup': out['phase_receipt']['copy_spawn_setup'],
                  'commands': len(out['commands']), 'Java_native_launches': 0}, indent=2))
