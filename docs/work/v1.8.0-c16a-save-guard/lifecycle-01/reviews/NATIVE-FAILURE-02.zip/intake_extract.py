"""Fresh native02 named source/receipt intake and one stopped-region extraction."""
import hashlib
import json
import struct
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
WORLD = BASE / 'native-02/server/world'
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
inputs = {}
def read(path):
    data = path.read_bytes()
    inputs[str(path)] = pin(data)
    return data

manifest = json.loads(read(BASE / 'SOURCE23-MANIFEST-01.json'))
assert len(manifest) == 2995
boundary = json.loads(read(BASE / 'SOURCE23-BOUNDARY-01.json'))
folder = HERE / 'source_inputs'
assert not folder.exists()
folder.mkdir()
for name in boundary['new_inputs']:
    body = read(ROOT / name)
    assert pin(body) == manifest[name], name
    (folder / Path(name).name).write_bytes(body)
old = Path('D:/ARCE-Task-Evidence/v1.8.0/agla-54ee830a7b')
old_manifest = json.loads((old / 'MANIFEST.json').read_bytes())
reader = (old / 'audit_native01.py').read_bytes()
assert pin(reader) == old_manifest['files']['audit_native01.py']
# Reuse only pure independently authored decoding functions, never old main/results.
(HERE / 'reviewer_reader.py').write_bytes(reader)
region = WORLD / 'region/r.0.0.mca'
assert region.is_file() and not region.is_symlink() and region.stat().st_size <= 16 * 1024 * 1024
raw = read(region)
slot = 11 + 32 * 11
index = 4 * slot
sector = int.from_bytes(raw[index:index + 3], 'big')
sectors = raw[index + 3]
assert sector >= 2 and sectors >= 1 and (sector + sectors) * 4096 <= len(raw)
start = sector * 4096
length = struct.unpack_from('>I', raw, start)[0]
assert 2 <= length <= 128 * 1024 + 1 and length + 4 <= sectors * 4096
assert raw[start + 4] == 2
actual = raw[start + 5:start + 4 + length]
source = read(BASE / 'native-02/source-chunk-11-11.nbt.zlib')
assert len(source) == 5898 and pin(source)['sha256'] == 'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
(HERE / 'stopped-chunk-11-11.nbt.zlib').write_bytes(actual)
(HERE / 'captured-source-chunk-11-11.nbt.zlib').write_bytes(source)
out = {'inputs': inputs, 'source23_manifest_rows': len(manifest), 'new_source_names': boundary['new_inputs'],
       'record_allocation': {'slot': slot, 'sector': sector, 'sectors': sectors, 'length_with_codec': length},
       'record': pin(actual), 'captured_source': pin(source), 'compressed_record_equal': actual == source,
       'parser_reuse': {'exact_own_code': pin(reader), 'functions_only': ['Reader','plain','unpack','cell','markers'],
                       'prior_main_or_outcome_used': False},
       'unread_previous_worlds': True, 'runtime_start_or_source_writes': False}
target = HERE / 'INTAKE-EXTRACTION-01.json'
assert not target.exists()
target.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps({key: out[key] for key in ['source23_manifest_rows','record_allocation','record','compressed_record_equal']}, indent=2))
