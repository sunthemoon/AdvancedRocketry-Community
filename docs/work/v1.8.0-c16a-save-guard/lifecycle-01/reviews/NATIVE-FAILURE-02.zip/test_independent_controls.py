"""Fresh controls for native02 absence/deadline and exact saved-record evidence."""
import struct
import unittest
from pathlib import Path
from unittest.mock import patch

import frozen_guard as guard
import reviewer_reader as parse
from audit_native02 import UNLOAD

HERE = Path(__file__).parent

class Native02IndependentControls(unittest.TestCase):
    LINE = '[17:17:02] [Server thread/INFO] [advancedrocketrycommunity/]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11'

    def test_native_unload_pattern_accepts_exact_header_not_console_say(self):
        self.assertIsNotNone(UNLOAD.fullmatch(self.LINE))
        self.assertIsNotNone(guard.UNLOAD_BEGIN.search(self.LINE))
        for line in [self.LINE.replace('/INFO]', '/ERROR]'),
                     self.LINE.replace('advancedrocketrycommunity/', 'minecraft/MinecraftServer'),
                     self.LINE.replace('11,11', '11,12'), 'echo ' + self.LINE,
                     self.LINE + ' extra']:
            self.assertIsNone(UNLOAD.fullmatch(line))
            self.assertIsNone(guard.UNLOAD_BEGIN.search(line))

    def test_false_loaded_predicate_cannot_supply_unload_event(self):
        class Process:
            lines = ['[17:17:02] [Server thread/INFO] [minecraft/MinecraftServer]: [Server] ARCE_GUARD_NOT_LOADED']
            def wait_for(self, pattern, timeout, start_at):
                assert timeout == 59 and start_at == 0
                assert not any(pattern.search(l) for l in self.lines[start_at:])
                raise guard.server.SmokeError('fresh unload missing')
        with patch.object(guard, 'wait_chunk'), patch.object(guard.time,'monotonic',side_effect=[0,1]), \
                self.assertRaisesRegex(guard.server.SmokeError,'fresh unload missing'):
            guard.wait_unload_begin(Process(),[],0)

    def test_total_deadline_not_extended_by_event_wait(self):
        class Process:
            lines = [Native02IndependentControls.LINE]
            def wait_for(self, pattern, timeout, start_at):
                assert timeout == 0.5
                return 0
        with patch.object(guard,'wait_chunk'), patch.object(guard.time,'monotonic',side_effect=[0,59.5,60.1]), \
                self.assertRaisesRegex(guard.server.SmokeError,'after its original deadline'):
            guard.wait_unload_begin(Process(),[],0)

    def test_end_barrier_cannot_supply_unexecuted_restoration(self):
        line = '[17:17:02] [Server thread/INFO] [minecraft/MinecraftServer]: [Server] ARCE_GUARD_REMOVAL_ROLLED_BACK_END'
        self.assertIsNone(guard.marker('ARCE_GUARD_REMOVAL_ROLLED_BACK').search(line))
        self.assertIsNotNone(guard.marker('ARCE_GUARD_REMOVAL_ROLLED_BACK_END').search(line))

    def test_fresh_record_has_actual_cells_not_palette_only(self):
        compressed = (HERE/'stopped-chunk-11-11.nbt.zlib').read_bytes()
        _, value, measured = parse.unpack(compressed)
        self.assertEqual((measured['nodes'],measured['depth']),(531,7))
        self.assertEqual(parse.cell(value,(186,180,180)),{'Name':'advancedrocketrycommunity:pressurized_tank'})
        self.assertEqual(parse.cell(value,(190,180,180)),{'Name':'minecraft:air'})
        self.assertEqual(parse.cell(value,(180,180,180)),{'Name':'minecraft:air'})

    def test_byte_difference_is_refused_before_semantic_decode(self):
        compressed = (HERE/'stopped-chunk-11-11.nbt.zlib').read_bytes()
        with patch.object(guard.regions,'_decode_chunk') as decode:
            with self.assertRaisesRegex(RuntimeError,'terrain record changed'):
                guard.check_record(compressed+b'x',compressed)
            decode.assert_not_called()

    def test_typed_native_arrays_remain_distinct_and_duplicate_keys_refused(self):
        def encoded(kind,width):
            return b'\x0a\x00\x00'+bytes([kind])+b'\x00\x01a'+struct.pack('>i',1)+b'\x00'*width+b'\x00'
        first, second = parse.Reader(encoded(11,4)).root(), parse.Reader(encoded(12,8)).root()
        self.assertEqual(parse.plain(first),parse.plain(second))
        self.assertNotEqual(first,second)
        key=b'\x00\x01a'
        duplicate=b'\x0a\x00\x00\x03'+key+struct.pack('>i',1)+b'\x03'+key+struct.pack('>i',2)+b'\x00'
        with self.assertRaises(AssertionError):
            parse.Reader(duplicate).root()

    def test_literal_unload_text_is_absent_in_its_own_raw_snapshot(self):
        # Raw text absence is stronger than a failed regex match, not callback diagnosis.
        source = HERE/'raw_inputs/stdout.txt'
        self.assertNotIn('ARCE_GUARD_UNLOAD_BEGIN',source.read_text(encoding='utf-8'))

if __name__=='__main__':
    unittest.main()
