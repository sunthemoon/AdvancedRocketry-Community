"""Seal the small new native02 audit, not source/runtime originals."""
import hashlib
import json
import re
from pathlib import Path

HERE=Path(__file__).parent
BASE=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
result=json.loads((HERE/'AUDIT-RESULT-02.json').read_bytes())
pin=lambda body:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
copies={
    'native-command.json':'NATIVE-COMMAND-02.json','native-result.json':'NATIVE-RESULT-02.json',
    'native-precheck.json':'NATIVE-PRECHECK-02.json','native-postcheck.json':'NATIVE-POSTCHECK-02.json',
    'source23-boundary.json':'SOURCE23-BOUNDARY-01.json','source23-postcheck.json':'SOURCE23-POSTCHECK-02.json',
    'artifacts23.json':'ARTIFACTS23-01.json','native-traceback.log':'native-02.log',
    'phase-receipt.json':'native-02/removal-availability-reload/receipt.json',
    'phase-commands.json':'native-02/removal-availability-reload/commands.json',
    'launch.json':'native-02/removal-availability-reload/launch.json',
    'harness-postcheck.json':'native-02/input-postcheck.json',
    'inputs.json':'native-02/inputs.json'}
for target,name in copies.items():
    source=BASE/name
    body=source.read_bytes()
    assert pin(body)==result['input_pins'][str(source)]
    path=HERE/'raw_inputs'/target
    assert not path.exists()
    path.write_bytes(body)
assert pin((HERE/'raw_inputs/stdout.txt').read_bytes())==result['input_pins'][str(BASE/'native-02/removal-availability-reload/stdout.txt')]
links=re.findall(r'\]\(([^)]+)\)',(HERE/'REPORT.md').read_text(encoding='utf-8'))
assert all((HERE/link).is_file() for link in links)
files={}
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        files[path.relative_to(HERE).as_posix()]=pin(path.read_bytes())
out={'format':'loose-evidence-manifest-v1','files':files,'payload_count':len(files),
     'payload_bytes':sum(row['bytes'] for row in files.values()),'links_checked':len(links),'links_missing':0,
     'source23_manifest_sha256':result['source23_manifest_sha256'],
     'main_jar_sha256':'5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9',
     'native_result':'FAIL; exit1; no unload-begin observation/reacquisition/clean stop/restart',
     'prior_native_outcome_reused':False,'runtime_or_source_writes':False,'archive_created':False}
target=HERE/'MANIFEST.json'
assert not target.exists()
target.write_bytes((json.dumps(out,indent=2)+'\n').encode('utf-8'))
files['MANIFEST.json']=pin(target.read_bytes())
sums=HERE/'SHA256SUMS.txt'
assert not sums.exists()
sums.write_bytes(''.join(f"{row['sha256']}  {name}\n" for name,row in sorted(files.items())).encode('ascii'))
print(json.dumps({'report':files['REPORT.md'],'manifest':files['MANIFEST.json'],'checksums':pin(sums.read_bytes()),
                  'payload_count':out['payload_count'],'payload_bytes':out['payload_bytes'],'links':len(links)},indent=2))
