"""Independent stopped-record/receipt/marker audit; never starts a process."""
import hashlib
import json
import re
import struct
import zlib
from pathlib import Path, PurePosixPath

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
PHASE = BASE / 'native-01/removal-availability-reload'
NS = 'advancedrocketrycommunity'

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

class Reader:
    """Exact native tag types and bounded arrays; ASCII fixture string scope only."""
    def __init__(self, data):
        assert len(data) <= 1024 * 1024
        self.data = data
        self.offset = self.nodes = self.depth = 0

    def take(self, count):
        assert 0 <= count <= len(self.data) - self.offset
        body = self.data[self.offset:self.offset + count]
        self.offset += count
        return body

    def number(self, format):
        return struct.unpack(format, self.take(struct.calcsize(format)))[0]

    def string(self):
        size = self.number('>H')
        assert size <= 4096
        return self.take(size).decode('utf-8', errors='strict')

    def length(self):
        size = self.number('>i')
        assert 0 <= size <= 4096
        return size

    def tag(self, kind, depth):
        self.nodes += 1
        self.depth = max(self.depth, depth)
        assert self.nodes <= 4096 and depth <= 16
        formats = {1: '>b', 2: '>h', 3: '>i', 4: '>q', 5: '>f', 6: '>d'}
        if kind in formats:
            value = self.number(formats[kind])
        elif kind == 7:
            value = list(self.take(self.length()))
        elif kind == 8:
            value = self.string()
        elif kind == 9:
            child, count = self.number('>B'), self.length()
            assert child != 0 or count == 0
            value = [self.tag(child, depth + 1) for _ in range(count)]
        elif kind == 10:
            value = {}
            while True:
                child = self.number('>B')
                if child == 0:
                    break
                name = self.string()
                assert name not in value
                value[name] = self.tag(child, depth + 1)
        elif kind in (11, 12):
            value = [self.number('>i' if kind == 11 else '>q') for _ in range(self.length())]
        else:
            raise AssertionError('Unsupported native tag kind')
        return (kind, value)

    def root(self):
        assert self.number('>B') == 10
        self.string()
        root = self.tag(10, 0)
        assert self.offset == len(self.data)
        return root

def plain(node):
    kind, value = node
    if kind == 10:
        return {name: plain(child) for name, child in value.items()}
    if kind == 9:
        return [plain(child) for child in value]
    return value

def unpack(compressed):
    assert len(compressed) <= 128 * 1024
    stream = zlib.decompressobj()
    body = stream.decompress(compressed, 1024 * 1024 + 1)
    assert len(body) <= 1024 * 1024 and stream.eof and not stream.unused_data and not stream.unconsumed_tail
    reader = Reader(body)
    typed = reader.root()
    value = plain(typed)
    assert (value['xPos'], value['zPos']) == (11, 11)
    return typed, value, {'expanded_bytes': len(body), 'nodes': reader.nodes, 'depth': reader.depth}

def cell(chunk, position):
    x, y, z = position
    assert (x >> 4, z >> 4) == (11, 11)
    sections = [section for section in chunk['sections'] if section['Y'] == y >> 4]
    assert len(sections) == 1
    states = sections[0]['block_states']
    palette = states['palette']
    assert 1 <= len(palette) <= 4096
    if len(palette) == 1:
        assert not states.get('data')
        return palette[0]
    bits = max(4, (len(palette) - 1).bit_length())
    per_word = 64 // bits
    words = states['data']
    assert len(words) == (4096 + per_word - 1) // per_word
    local = (y % 16) * 256 + (z % 16) * 16 + x % 16
    word = words[local // per_word] & ((1 << 64) - 1)
    index = (word >> (local % per_word * bits)) & ((1 << bits) - 1)
    assert index < len(palette)
    return palette[index]

SAY = re.compile(r'^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Server thread/INFO\] '
                 r'\[minecraft/MinecraftServer\]: (?:\[Not Secure\] )?\[Server\] (\S+)\s*$')
REFUSAL = 'Refusing oversized tank chunk save; back up and repair first'
EVENT = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[ne\.mi\.ev\.EventBus/EVENTBUS\]: Exception caught during firing event: '
                   + re.escape(REFUSAL) + '$')
CHUNK = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[minecraft/ChunkMap\]: Failed to save chunk 11,11$')

def markers(lines):
    return [{'line': index + 1, 'marker': match.group(1), 'text': line}
            for index, line in enumerate(lines) if (match := SAY.fullmatch(line))]

def main():
    inputs = {}
    def read(path):
        body = path.read_bytes()
        inputs[str(path)] = pin(body)
        return body
    script = read(ROOT / 'scripts/run_v180_guard_lifecycle_smoke.py')
    tests = read(ROOT / 'tests/test_run_v180_guard_lifecycle_smoke.py')
    assert pin(script)['sha256'] == 'f9c6418758b35f327ef6c00e2a1d372a863478e0dfa72be581999a83d23645d7'
    assert pin(tests)['sha256'] == '9e657e2c13a13e8d26b43936d50174db062f1ba0176850c51a762da90431088d'
    required = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
                'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
                'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
                'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
                'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
                'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md', 'docs/11-RISK-REGISTER.md']
    for name in required:
        read(ROOT / name)
    for name in ['scripts/run_v180_tank_smoke.py', 'scripts/run_v180_motor_smoke.py',
                 'scripts/v120_precision_world_fixture.py', 'scripts/inspect_celestial_saved_data.py',
                 'scripts/run_dedicated_server_smoke.py']:
        read(ROOT / name)
    receipts = {name: json.loads(read(BASE / name)) for name in
                ['NATIVE-COMMAND-01.json', 'NATIVE-RESULT-01.json', 'NATIVE-PRECHECK-01.json',
                 'NATIVE-POSTCHECK-01.json', 'native-01/inputs.json', 'native-01/input-postcheck.json',
                 'native-01/source-world-files.json', 'LIBRARIES-INPUTS-01.json',
                 'native-01/removal-availability-reload/receipt.json',
                 'native-01/removal-availability-reload/commands.json',
                 'native-01/removal-availability-reload/launch.json']}
    for name in ['native-01.log', 'run_native01.py', 'TOOLING-NOTES-01.md', 'INITIAL-UNIT-FAILURE-01.txt']:
        read(BASE / name)
    logs = {name: read(PHASE / name).decode('utf-8').splitlines() for name in ['stdout.txt', 'latest.log', 'debug.log']}
    source = read(BASE / 'native-01/source-chunk-11-11.nbt.zlib')
    actual = read(HERE / 'stopped-chunk-11-11.nbt.zlib')
    assert actual == source
    typed, chunk, measured = unpack(actual)
    assert cell(chunk, (180, 180, 180)) == {'Name': 'minecraft:air'}
    assert cell(chunk, (190, 180, 180)) == {'Name': 'minecraft:air'}
    entities = typed[1]['block_entities']
    assert entities[0] == 9 and len(entities[1]) == 4
    roots = []
    for index, entity in enumerate(sorted(entities[1], key=lambda e: plain(e)['x']), 1):
        value = plain(entity)
        position = (180 + 2 * index, 180, 180)
        assert tuple(value[a] for a in ('x', 'y', 'z')) == position
        assert value['id'] == NS + ':pressurized_tank'
        assert cell(chunk, position) == {'Name': NS + ':pressurized_tank'}
        root = entity[1]['arce_pressurized_tank']
        assert root[0] == 10 and root[1]['schema'][0] == 3
        fluid = root[1]['fluid']
        assert fluid[0] == 10 and fluid[1]['Amount'][0] == 3 and fluid[1]['FluidName'][0] == 8
        assert fluid[1]['Amount'][1] == {1: 300000, 2: 5000, 3: 5000, 4: -1}[index]
        assert fluid[1]['FluidName'][1] == ('minecraft:lava' if index == 2 else 'minecraft:water')
        assert root[1]['schema'][1] == (2 if index == 3 else 1)
        if index == 2:
            assert plain(fluid[1]['Tag']) == {'batch': 'native-retained'}
        extension = {}
        if index == 3:
            for name in ('part0', 'part1'):
                kind, values = root[1]['extension'][1][name]
                assert kind in (7, 11, 12) and len(values) == 4096 and set(values) == {0}
                extension[name] = {'native_type': kind, 'elements': len(values), 'all_zero': True}
        roots.append({'position': position, 'schema_native_type': root[1]['schema'][0],
                      'schema': root[1]['schema'][1], 'fluid': plain(fluid), 'extension_arrays': extension})
    lines = logs['stdout.txt']
    observations = markers(lines)
    assert sum(m['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK_END' for m in observations) == 1
    assert not any(m['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK' for m in observations)
    boundaries = {}
    start = 0
    for key, end in [('initial_refusal', 'initial_refusal_END'), ('after_removal_refusal', 'after_removal_refusal_END')]:
        index = next(m['line'] for m in observations if m['marker'] == end)
        window = lines[start:index]
        counts = {'event_bus_error_headers': sum(bool(EVENT.fullmatch(l)) for l in window),
                  'chunk_map_error_headers': sum(bool(CHUNK.fullmatch(l)) for l in window)}
        receipt = receipts['native-01/removal-availability-reload/receipt.json'][key]
        assert all(counts[n] == receipt[n] for n in counts)
        boundaries[key] = {'first_line': start + 1, 'last_line': index, **counts}
        start = index
    actual_receipt = receipts['native-01/removal-availability-reload/receipt.json']
    assert actual_receipt['result'] == 'FAIL' and receipts['NATIVE-RESULT-01.json']['exit_code'] == 1
    commands = receipts['native-01/removal-availability-reload/commands.json']
    assert len(commands) == 31 and 'stop' not in commands
    assert not (BASE / 'native-01/restart-retrigger').exists() and not (BASE / 'native-01/summary.json').exists()
    source_inventory = receipts['native-01/source-world-files.json']
    for row in source_inventory:
        name = PurePosixPath(row['path'])
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in row['path']
        assert row['bytes'] >= 0 and re.fullmatch('[0-9a-f]{64}', row['sha256'])
    installed = {}
    for key in ('host', 'fixture'):
        row = receipts['native-01/inputs.json'][key]
        path = BASE / 'native-01/server/mods' / row['name']
        if path.is_file():
            actual_pin = pin(read(path))
            assert actual_pin == {'bytes': row['bytes'], 'sha256': row['sha256']}
            installed[key] = actual_pin
        else:
            installed[key] = {'not_independently_read': 'disposed before audit; receipt only'}
    result = {'inputs': inputs, 'native_result': receipts['NATIVE-RESULT-01.json'],
              'failure_receipt': actual_receipt, 'compressed_record_equal': True,
              'typed_record': measured, 'saved_roots': roots, 'saved_marker': cell(chunk, (190, 180, 180)),
              'saved_culprit': cell(chunk, (186, 180, 180)), 'authoritative_markers': observations,
              'refusal_windows': boundaries, 'total_event_headers': sum(bool(EVENT.fullmatch(l)) for l in lines),
              'total_chunk_headers': sum(bool(CHUNK.fullmatch(l)) for l in lines),
              'console_commands': len(commands), 'stop_sent': False, 'second_cycle_started': False,
              'source_world_inventory_rows': len(source_inventory),
              'input_preservation_claims': {'root': receipts['NATIVE-POSTCHECK-01.json'],
                                            'harness': receipts['native-01/input-postcheck.json'],
                                            'attribution': 'receipt assertions; no historical-world/library rewalk'},
              'installed_artifact_pins_independently_checked': installed,
              'limits': ['not native replay', 'false loaded predicate is not observed unload callback/disposal',
                         'failure abort is not clean stop or restart proof', 'no cross-store/crash/first-save/GuardTicket/Gate proof'],
              'tooling_failures': ['Windows rg wildcard arguments rejected during named source locator lookup',
                                   'two guessed lifecycle task filenames absent; no source/evidence changed']}
    target = HERE / 'AUDIT-RESULT-01.json'
    assert not target.exists()
    target.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    (HERE / 'observed-markers.txt').write_text('\n'.join(f"{m['line']}: {m['text']}" for m in observations) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ['compressed_record_equal', 'typed_record', 'refusal_windows',
          'total_event_headers', 'total_chunk_headers', 'console_commands', 'stop_sent',
          'second_cycle_started', 'source_world_inventory_rows']}, indent=2))

if __name__ == '__main__':
    main()
