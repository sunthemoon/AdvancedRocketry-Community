"""Fresh native02 observations and artifact/source pins, no runtime invocation."""
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

import reviewer_reader as parse

HERE = Path(__file__).parent
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
PHASE = BASE / 'native-02/removal-availability-reload'
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
inputs = {}
def read(path):
    body = path.read_bytes()
    inputs[str(path)] = pin(body)
    return body
def document(path):
    return json.loads(read(path))

UNLOAD = re.compile(r'^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Server thread/INFO\] '
                    r'\[advancedrocketrycommunity/\]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11\s*$')
EVENT = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[ne\.mi\.ev\.EventBus/EVENTBUS\]: Exception caught during firing event: '
                   r'Refusing oversized tank chunk save; back up and repair first$')
CHUNK = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[minecraft/ChunkMap\]: Failed to save chunk 11,11$')

def main():
    receipts = {name: document(BASE / name) for name in ['NATIVE-COMMAND-02.json', 'NATIVE-RESULT-02.json',
                'NATIVE-PRECHECK-02.json', 'NATIVE-POSTCHECK-02.json', 'SOURCE23-BOUNDARY-01.json',
                'SOURCE23-POSTCHECK-02.json', 'SOURCE23-MANIFEST-01.json', 'ARTIFACTS23-01.json',
                'LIBRARIES-INPUTS-01.json', 'native-02/inputs.json', 'native-02/input-postcheck.json',
                'native-02/source-world-files.json', 'native-02/removal-availability-reload/receipt.json',
                'native-02/removal-availability-reload/commands.json',
                'native-02/removal-availability-reload/launch.json']}
    manifest = receipts['SOURCE23-MANIFEST-01.json']
    assert len(manifest) == 2995
    for name, row in manifest.items():
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
        assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in path.parts
        assert set(row) == {'bytes','sha256'} and type(row['bytes']) is int and row['bytes'] >= 0
        assert re.fullmatch('[0-9a-f]{64}', row['sha256'])
    source_names = receipts['SOURCE23-BOUNDARY-01.json']['new_inputs']
    source_pins = {}
    for name in source_names:
        body = read(HERE / 'source_inputs' / Path(name).name)
        assert pin(body) == manifest[name]
        source_pins[name] = pin(body)
    for name in ['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md',
                 'docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
                 'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
                 'docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
                 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']:
        read(ROOT / name)
    read(BASE / 'run_native02.py')
    read(BASE / 'native-02.log')
    logs = {name: read(PHASE / name).decode('utf-8').splitlines() for name in ['stdout.txt','latest.log','debug.log']}
    records = [read(HERE / name) for name in ['stopped-chunk-11-11.nbt.zlib','captured-source-chunk-11-11.nbt.zlib']]
    assert records[0] == records[1] and pin(records[0])['sha256'] == 'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
    typed, chunk, limits = parse.unpack(records[0])
    assert parse.cell(chunk, (190,180,180)) == {'Name':'minecraft:air'}
    assert parse.cell(chunk, (180,180,180)) == {'Name':'minecraft:air'}
    assert len(typed[1]['block_entities'][1]) == 4
    roots = []
    for index, entity in enumerate(sorted(typed[1]['block_entities'][1], key=lambda e: parse.plain(e)['x']), 1):
        be = parse.plain(entity)
        pos = (180 + 2*index,180,180)
        assert tuple(be[a] for a in ('x','y','z')) == pos
        assert be['id'] == 'advancedrocketrycommunity:pressurized_tank'
        assert parse.cell(chunk,pos) == {'Name':'advancedrocketrycommunity:pressurized_tank'}
        root = entity[1]['arce_pressurized_tank']
        assert root[0] == 10 and root[1]['schema'] == (3, 2 if index==3 else 1)
        fluid = root[1]['fluid']
        assert fluid[0] == 10 and fluid[1]['Amount'] == (3,{1:300000,2:5000,3:5000,4:-1}[index])
        assert fluid[1]['FluidName'] == (8,'minecraft:lava' if index==2 else 'minecraft:water')
        if index == 2:
            assert parse.plain(fluid[1]['Tag']) == {'batch':'native-retained'}
        extensions = {}
        if index==3:
            for name in ['part0','part1']:
                kind, values = root[1]['extension'][1][name]
                assert kind in (7,11,12) and len(values)==4096 and set(values)=={0}
                extensions[name]={'native_type':kind,'elements':len(values),'all_zero':True}
        roots.append({'position':pos,'schema':root[1]['schema'],'fluid':parse.plain(fluid),'extensions':extensions})
    lines = logs['stdout.txt']
    markers = parse.markers(lines)
    unload_counts = {name:{'exact_info':sum(bool(UNLOAD.fullmatch(l)) for l in source),
                          'literal_text':sum('ARCE_GUARD_UNLOAD_BEGIN' in l for l in source)}
                     for name,source in logs.items()}
    assert all(row['exact_info']==0 and row['literal_text']==0 for row in unload_counts.values())
    assert any(m['marker']=='ARCE_GUARD_NOT_LOADED' for m in markers)
    assert not any(m['marker'].startswith('ARCE_GUARD_REMOVAL_ROLLED_BACK') for m in markers)
    boundaries = {}
    start=0
    for key, end in [('initial_refusal','initial_refusal_END'),('after_removal_refusal','after_removal_refusal_END')]:
        index=next(m['line'] for m in markers if m['marker']==end)
        window=lines[start:index]
        counts={'event_bus_error_headers':sum(bool(EVENT.fullmatch(l)) for l in window),
                'chunk_map_error_headers':sum(bool(CHUNK.fullmatch(l)) for l in window)}
        expected=receipts['native-02/removal-availability-reload/receipt.json'][key]
        assert all(counts[k]==expected[k] for k in counts)
        boundaries[key]={'first_line':start+1,'last_line':index,**counts}
        start=index
    commands=receipts['native-02/removal-availability-reload/commands.json']
    assert len(commands)==24 and commands.count('forceload add 176 176')==1
    assert commands.count('forceload remove 176 176')==1 and 'stop' not in commands
    assert not any('ARCE_GUARD_REMOVAL_ROLLED_BACK' in c for c in commands)
    assert not (BASE/'native-02/restart-retrigger').exists() and not (BASE/'native-02/summary.json').exists()
    assert receipts['NATIVE-RESULT-02.json']['exit_code']==1
    assert receipts['native-02/removal-availability-reload/receipt.json']['result']=='FAIL'
    artifact_pins = {}
    for row in receipts['ARTIFACTS23-01.json']:
        path=Path(row['path'])
        data=read(path)
        assert pin(data)=={'bytes':row['bytes'],'sha256':row['sha256']}
        artifact_pins[path.name]=pin(data)
    current=receipts['native-02/inputs.json']['host']
    assert current['sha256']=='5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9'
    installed={}
    for key in ['host','fixture']:
        row=receipts['native-02/inputs.json'][key]
        data=read(BASE/'native-02/server/mods'/row['name'])
        assert pin(data)=={'bytes':row['bytes'],'sha256':row['sha256']}
        installed[key]=pin(data)
    java='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java'
    with zipfile.ZipFile(current['path']) as jar:
        member=java.removeprefix('src/main/java/').removesuffix('.java')+'.class'
        assert jar.namelist().count(member)==1
        class_pin=pin(jar.read(member))
    sources=next(row for row in receipts['ARTIFACTS23-01.json'] if row['path'].endswith('-sources.jar'))
    with zipfile.ZipFile(sources['path']) as jar:
        member=java.removeprefix('src/main/java/')
        assert jar.namelist().count(member)==1 and pin(jar.read(member))==source_pins[java]
    for row in receipts['native-02/source-world-files.json']:
        path=PurePosixPath(row['path'])
        assert not path.is_absolute() and '..' not in path.parts
    result={'input_pins':inputs,'source_pins':source_pins,'source23_manifest_rows':len(manifest),
            'source23_manifest_sha256':inputs[str(BASE/'SOURCE23-MANIFEST-01.json')]['sha256'],
            'native_result':receipts['NATIVE-RESULT-02.json'],
            'phase_receipt':receipts['native-02/removal-availability-reload/receipt.json'],
            'command_count':len(commands),'commands':commands,'reacquisition_sent':False,'stop_sent':False,
            'restoration_assertion_sent':False,'cycle2_started':False,'summary_exists':False,
            'authoritative_markers':markers,'unload_marker_counts':unload_counts,'refusal_windows':boundaries,
            'total_event_headers':sum(bool(EVENT.fullmatch(l)) for l in lines),
            'total_chunk_headers':sum(bool(CHUNK.fullmatch(l)) for l in lines),
            'record':pin(records[0]),'compressed_record_equal':True,'typed_measurement':limits,'typed_roots':roots,
            'saved_marker':parse.cell(chunk,(190,180,180)),'saved_culprit':parse.cell(chunk,(186,180,180)),
            'artifact_pins':artifact_pins,'installed_pins':installed,'observer_class':class_pin,
            'observer_class_present_and_source_matches':True,
            'source_world_inventory_rows':len(receipts['native-02/source-world-files.json']),
            'postcheck_claims':{key:receipts[key] for key in ['NATIVE-POSTCHECK-02.json','SOURCE23-POSTCHECK-02.json',
                                                          'native-02/input-postcheck.json']},
            'preservation_attribution':'Full source/library/historical-world postchecks belong to executing Root/harness; no auditor full rewalk',
            'tooling_locator_failure':'Guessed ARTIFACTS23.json absent; corrected exact ARTIFACTS23-01.json read',
            'runtime_replayed':False,'prior_outcome_reused':False,'gates_claimed':False}
    target=HERE/'AUDIT-RESULT-02.json'
    assert not target.exists()
    target.write_bytes((json.dumps(result,indent=2)+'\n').encode('utf-8'))
    (HERE/'observed-markers.txt').write_text('\n'.join(f"{m['line']}: {m['text']}" for m in markers)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ['source23_manifest_sha256','command_count','unload_marker_counts',
                   'refusal_windows','total_event_headers','total_chunk_headers','record','typed_measurement']},indent=2))

if __name__=='__main__':
    main()
