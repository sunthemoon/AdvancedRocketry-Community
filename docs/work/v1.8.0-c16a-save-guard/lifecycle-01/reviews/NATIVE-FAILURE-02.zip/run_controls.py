"""Load exact frozen Source23 Python test-tool inputs, never their main runner."""
import hashlib
import importlib.util
import json
import sys
import unittest
from pathlib import Path

HERE=Path(__file__).parent
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
BASE=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(HERE))
import scripts
pin=lambda body:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
intake=json.loads((HERE/'INTAKE-EXTRACTION-01.json').read_bytes())
frozen=HERE/'source_inputs'
for name in ['run_v180_guard_lifecycle_smoke.py','test_run_v180_guard_lifecycle_smoke.py']:
    source=next(key for key in intake['inputs'] if key.endswith('/'+name) or key.endswith('\\'+name))
    assert pin((frozen/name).read_bytes())==intake['inputs'][source]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module
guard=load('scripts.run_v180_guard_lifecycle_smoke',frozen/'run_v180_guard_lifecycle_smoke.py')
scripts.run_v180_guard_lifecycle_smoke=guard
sys.modules['frozen_guard']=guard
author=load('frozen_author_tests',frozen/'test_run_v180_guard_lifecycle_smoke.py')
controls=load('test_independent_controls',HERE/'test_independent_controls.py')
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(author),
                         unittest.defaultTestLoader.loadTestsFromModule(controls)])
result=unittest.TextTestRunner(verbosity=2).run(suite)
target=HERE/'PYTHON-COUNTS-01.json'
assert not target.exists()
target.write_bytes((json.dumps({'executed':result.testsRun,'failures':len(result.failures),
                               'errors':len(result.errors),'skipped':len(result.skipped),
                               'runtime_launched':False,'prior_outcome_used':False},indent=2)+'\n').encode('utf-8'))
sys.exit(0 if result.wasSuccessful() else 1)
