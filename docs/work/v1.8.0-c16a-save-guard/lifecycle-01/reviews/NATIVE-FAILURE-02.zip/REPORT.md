# Native02 guard lifecycle: independent actual-result audit

## Findings

1. **Native02 failed before unload/reacquisition/restoration; it is not PASS.** The actual Root command exited **1 after79.807475 s**. The first phase receipt reports `FAIL` at `wait_unload_begin`: no required unload-begin marker within the unchanged total60-second deadline. Independent scans find **zero literal occurrences and zero exact INFO markers** for `ARCE_GUARD_UNLOAD_BEGIN` in this cohort's stdout/latest/debug logs. This proves the captured marker is absent, not why the event or logger condition was not observed. No production-defect cause or policy conclusion is assigned.

2. **The successful early cuts do not establish the missing lifecycle observation.** The24 recorded console commands show initial force-load/LOADED, exact culprit tank and AIR marker, STONE mutation, first save, direct console culprit removal/AIR assertion, second save, then force-load removal and two false-loaded predicate probes/barriers. Native stdout reports `ARCE_GUARD_NOT_LOADED` at line627 and its barrier at628. There is no ticket reacquisition, restoration command/marker, `stop`, second cycle or summary. The initial and post-removal save windows have **3 and2 matched refusal pairs**; the full stdout has **6 EventBus +6 ChunkMap ERROR headers**. `Saved the game` is not counted as a successful terrain write. This is not a clean-log, clean-stop, actual-disposal, live restoration or restart test.

3. **Fresh stopped terrain retention is observed independently, but does not satisfy findings1-2.** Only native02's stopped fixed region was read. Region slot363/sector344/two sectors yields **5,898 compressed bytes**, SHA `d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8`, exactly equal to native02's own captured source. Independent typed decoding measures54,066 expanded bytes,531 nodes and depth7. The exact four tank BE cells retain Int schema/amount fields, 300,000 mB overflow water, tagged5,000 mB lava/batch metadata, future schema2 water with two4,096-element **TAG_Byte_Array** extensions, and corrupt amount-1. The saved culprit cell is tank and the marker cell is AIR. This is post-failure/abort terrain-record evidence, not proof of a clean stop, natural crash atomicity, live rollback, whole-region equality or cross-store conservation.

## Cohort and source/artifact pins

This audit does not depend on live HEAD or reuse native01's outcome. Its declared build snapshot is Source23, **2,995 named build/tool inputs**, manifest SHA `bab73c802f4ae710d5e854a7ccd26417c5c0925a9421172da7b0b3d6288554e4`. The boundary receipt names baseline commit `a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce`,2,992 preceding build inputs and these exact three new/changed postimages:

| Input | SHA-256 |
|---|---|
| `gametest/GuardedChunkUnloadObservation.java` | `a426612fd9986b871d7930fa413b8ad0ade1e994d911c901c3f87e3b313fdd87` |
| `scripts/run_v180_guard_lifecycle_smoke.py` | `544e25035fe5554994bc812727ed0bbe6e5d5e24a0165607f4d95b1dd0e67a30` |
| `tests/test_run_v180_guard_lifecycle_smoke.py` | `3fa8716ed3682b94b750e533d2b7462266a0912246079b74e8ae5985b2737ea9` |

All three were captured against the Source23 manifest before later commits. The frozen Python inputs, rather than live postimages, were used for the replay.

Fresh actual main JAR: **5,443,263 B**, SHA `5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9`. Sources: `4ab8254184549cef0ca0edbdb3d256ee8215ecf2470a7036b453baddfa8053a3`; API: `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da`. The three actual artifact files were independently hashed. Newly installed native02 host and fixture matched their input pins; fixture SHA `765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4`.

The fresh main archive contains exactly one observer class and the sources archive's observer Java member equals the Source23 source pin. Actual launch enables `advancedrocketrycommunity.releaseTestHooks=true`. These checks establish packaged input identity, **not event registration/callback execution**. No source/API admission or new runtime eligibility is inferred.

## Preservation attribution

Root's precheck records2,995 matching inputs and sufficient C/D space. Source23 postcheck records0 mismatches; native postcheck asserts source/library equality; harness postcheck asserts historical source-world/artifact equality. The source-world inventory contains139 safe-relative rows and the library inventory104 named entries. Their exact receipts/manifests are pinned, and Source23's2,995 paths/schema/hash fields were independently checked for safe relative identities.

This auditor **did not rewalk the historical source world, libraries or every production file**. Those full preservation assertions remain attributed to the actual Root/harness checks. Independent recomputation covers the exact three source postimages, all three named artifacts, installed host/fixture, this cohort's captured/stopped fixed compressed record and decoded roots/cells. No whole terrain region equality is claimed.

## Actual independent commands and controls

| Command | Result |
|---|---|
| `python -B intake_extract.py` | exit0; exact new source intake, one stopped-region allocation/record extraction |
| `python -B audit_native02.py` | exit0; fresh raw marker/window/command/phase/typed-root and artifact/source checks |
| `python -B run_controls.py` | exit0; **29 tests** = exact frozen author21 + reviewer8,0 failures/errors/skips |

Controls reject substituting the false-loaded predicate for the unload event, stale/wrong-logger/severity/coordinate markers, END barriers for restoration, a second or late deadline, changed compressed bytes, duplicate keys or erased native array types. The typed parser code was reused from the auditor's earlier immutable helper, **only its pure parsing/cell functions**; native01 data/result/main was not called. Every record and receipt assertion here uses fresh native02 inputs.

One locator failure is retained: the initially guessed `ARTIFACTS23.json` did not exist; the actual `ARTIFACTS23-01.json` was then read. No bound, timeout, assertion or source was changed. No Java/native/Gradle/server/client, cleanup, process termination, commit or push was performed.

## Remaining scope

The run does not prove unload-begin/provider/final disposal, reacquisition, restored live roots/marker, clean stop, restart retrigger, first-save managed-entry defense, private GuardTicket/family lifecycle, cross-store/drop/charged-mode conservation, natural-crash behavior, native replay or any Required Gate. Direct administrator `setblock` is not ordinary player-removal/drop evidence. Root's earlier failed native01 and Source22/23 builds remain separate immutable histories; no outcome was borrowed from them.

Any later observation change needs separately reviewed exact source/callback evidence and a fresh cohort. This audit supplies no production patch, Gate/policy decision or passing restoration interpretation.

## Evidence

[Fresh measured result and input hashes](AUDIT-RESULT-02.json), [intake/allocation](INTAKE-EXTRACTION-01.json), [intake log](intake.log), [audit log](audit.log), [actual markers](observed-markers.txt), [29-test raw log](python.log), [counts](PYTHON-COUNTS-01.json), [Python command](python-command.json).

`source_inputs/` contains only the exact three Source23 postimages; `raw_inputs/` contains small named first-phase/Root receipts and stdout. The loose manifest hashes this audit's internal files only. No whole-source, JAR, world or region export/archive was made, and no sealed original was changed.
