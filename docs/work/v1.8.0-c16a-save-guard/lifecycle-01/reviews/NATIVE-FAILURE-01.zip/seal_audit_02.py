"""Corrected seal: exact original committed test-tool objects, never live delta."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
COMMIT = 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce'
result = json.loads((HERE / 'AUDIT-RESULT-01.json').read_bytes())
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
directory = HERE / 'inputs-02'
assert not directory.exists()
directory.mkdir()
commands = []
for target, name in [('script.py', 'scripts/run_v180_guard_lifecycle_smoke.py'),
                     ('test_script.py', 'tests/test_run_v180_guard_lifecycle_smoke.py')]:
    command = ['git', '-C', str(ROOT), 'show', COMMIT + ':' + name]
    run = subprocess.run(command, capture_output=True)
    commands.append({'command': command, 'exit': run.returncode, 'stdout': pin(run.stdout),
                     'stderr': run.stderr.decode('utf-8')})
    assert run.returncode == 0
    assert pin(run.stdout) == result['inputs'][str(ROOT / name)]
    (directory / target).write_bytes(run.stdout)
targets = {
    'native-result.json': BASE / 'NATIVE-RESULT-01.json',
    'native-traceback.log': BASE / 'native-01.log',
    'phase-receipt.json': BASE / 'native-01/removal-availability-reload/receipt.json',
    'phase-commands.json': BASE / 'native-01/removal-availability-reload/commands.json',
    'stdout.txt': BASE / 'native-01/removal-availability-reload/stdout.txt',
    'captured-original-chunk.nbt.zlib': BASE / 'native-01/source-chunk-11-11.nbt.zlib',
}
for name, source in targets.items():
    body = source.read_bytes()
    assert pin(body) == result['inputs'][str(source)], str(source)
    (directory / name).write_bytes(body)
receipt = HERE / 'SOURCE-COMMIT-INTAKE-02.json'
assert not receipt.exists()
receipt.write_bytes((json.dumps({'fixed_test_tool_commit': COMMIT, 'commands': commands,
                                'exact_original_pins_match': True,
                                'later_live_source_used': False}, indent=2) + '\n').encode('utf-8'))
links = re.findall(r'\]\(([^)]+)\)', (HERE / 'REPORT.md').read_text(encoding='utf-8'))
assert all((HERE / name).is_file() for name in links)
files = {}
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        files[path.relative_to(HERE).as_posix()] = pin(path.read_bytes())
out = {'format': 'loose-evidence-manifest-v1', 'files': files, 'payload_count': len(files),
       'payload_bytes': sum(row['bytes'] for row in files.values()),
       'native_precheck_commit': '355c4681a6cbddd380545a50e0f6e524bad6d295',
       'exact_original_test_tool_commit': COMMIT,
       'native_result': 'FAIL; exit1; no completed restart cohort',
       'links_checked': len(links), 'links_missing': 0, 'source_runtime_writes': False,
       'archive_created': False, 'first_seal_failure_preserved': True}
manifest = HERE / 'MANIFEST.json'
assert not manifest.exists()
manifest.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
files['MANIFEST.json'] = pin(manifest.read_bytes())
checksums = HERE / 'SHA256SUMS.txt'
assert not checksums.exists()
checksums.write_bytes(''.join(f"{row['sha256']}  {name}\n" for name, row in sorted(files.items())).encode('ascii'))
print(json.dumps({'report': files['REPORT.md'], 'manifest': files['MANIFEST.json'],
                  'checksums': pin(checksums.read_bytes()), 'payload_count': out['payload_count'],
                  'payload_bytes': out['payload_bytes'], 'links': len(links)}, indent=2))
