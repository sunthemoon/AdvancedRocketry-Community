# First native guard lifecycle run: independent evidence audit

## Findings first

1. **Failed native observation; restoration and restart coverage remain open.** Root's actual command exited **1 after 20.909501 s**. The first phase receipt is `FAIL`, with `Native fixed-cell block check failed: ARCE_GUARD_REMOVAL_ROLLED_BACK`. At `stdout.txt:839-840`, the loaded-predicate marker and barrier are present; at line893 only `ARCE_GUARD_REMOVAL_ROLLED_BACK_END` exists, not the required exact restoration marker. The recorded 31 console commands contain no `stop`; the second `restart-retrigger` directory and final summary were not created. This is not a passing restoration, clean-stop or restart run. The failure is a measured coverage/result boundary, not an independently diagnosed production-defect severity.

2. **The successful earlier observations are narrower than actual unload/reload proof.** Exact console INFO markers show the initial tank carrier and AIR marker, then the STONE mutation, then culprit AIR after direct administrator `setblock` removal. Initial `save-all flush` produced **3 paired EventBus/ChunkMap refusal headers**; the next save after removal produced **2 pairs**, with matched save/barrier markers. `stdout.txt:575` reports `ARCE_GUARD_NOT_LOADED`; lines839-840 report loaded again. The harness itself defines this as the `execute loaded` predicate, not observed unload callbacks/provider disposal (`scripts/run_v180_guard_lifecycle_smoke.py:47-73`). It is not evidence that a new holder, live BE or Level denial state was created or that disk was reread. No cause for the failed restoration is selected by this audit.

3. **Stopped fixed-record retention is independently observed, but does not repair finding1.** Independent extraction of only the stopped runtime's region slot363 (chunk11,11) found **5,898 compressed bytes**, SHA `d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8`, exactly equal to the captured original chunk. Independent typed decoding measured **54,066 expanded bytes, 531 nodes, depth7** under unchanged bounds. Four exact tank BE carriers remain at x182/184/186/188, y180,z180, with the original Int schema/amount fields, tagged lava batch metadata, future schema2 with two4,096-element native arrays, and corrupt amount-1. The exact saved culprit cell is tank and the saved marker cell is AIR. This is terrain-record evidence after the harness failure/abort, not a successful live rollback assertion or clean restart. It does not assert whole-region equality, independent-storage conservation or crash atomicity.

## Input and preservation boundaries

- Recorded native precheck HEAD is `355c4681a6cbddd380545a50e0f6e524bad6d295`; this run originally used the two development test-tool inputs. Root subsequently committed their exact original bytes at `a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce`. Final snapshots are read from those explicit Git objects, not from later live amendment postimages. A test-tool commit does not turn the failed native run into a source/runtime acceptance.
- Actual script SHA `f9c6418758b35f327ef6c00e2a1d372a863478e0dfa72be581999a83d23645d7`; test SHA `9e657e2c13a13e8d26b43936d50174db062f1ba0176850c51a762da90431088d`. Narrow snapshots are retained before future observation changes.
- Recorded host SHA `26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a`; fixture SHA `765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4`. Both newly installed runtime mod files were independently hashed against those receipt pins, without exporting JARs.
- Root precheck names2,992 unchanged build inputs and sufficient C/D free space. Root postcheck asserts candidate/build-input/library preservation; harness postcheck asserts source-world/artifact preservation. These exact receipts and the139-row safe-relative source-world inventory were inspected and pinned. **This auditor did not rewalk/recompute the historical source world, libraries or all2,992 production inputs**, so those full preservation claims remain attributed to the executing Root/harness assertions. The independently measured comparisons are the two candidate source pins, installed artifacts and captured/stopped fixed chunk.
- Full captured stdout contains **11 EventBus +11 ChunkMap refusal headers**. This is not a clean log. The narrower3/2 save windows agree with the phase receipt. Neither `Saved the game` nor `All dimensions are saved` was promoted to a disk-write success; the fixed compressed-byte oracle was checked separately.

## Actual independent commands

| Check | Actual result |
|---|---|
| `python -B extract_fixed_record.py` | exit0; one bounded stopped-region allocation, compressed equality |
| `python -B audit_native01.py` | exit0; typed fixed cells/roots, strict raw marker counts, actual failure/phase boundaries and named pins |
| `python -B -m unittest -v tests.test_run_v180_guard_lifecycle_smoke test_independent_controls` | exit0; **24 tests** = original16 + reviewer8,0 failures/errors |
| First `python -B seal_audit.py` | exit1 before source copy: live script no longer matched the audited original pin; failed attempt retained, not overwritten |

The independent controls preserve the failure distinction: an END barrier cannot satisfy its block marker; nested/wrong-severity/logger text is refused; trailing compressed bytes, duplicate compound keys, wrong coordinates and excessive expansion are refused; native IntArray/LongArray types stay distinct; palette presence alone cannot establish a fixed-cell state; identical saved bytes do not supply the missing live marker.

Named source locator mistakes (Windows `rg` wildcard arguments and two absent guessed task filenames) are retained as tooling observations in the audit result. No source test, timeout or bound was relaxed; Root's original native failure and earlier tooling/test failures remain immutable.

Root confirmed the live mismatch belongs to a later separately reviewed observation amendment. The corrected sealing attempt uses only the two exact original `a382e36e` Git objects and the unchanged first-run receipts. The later script/test bytes are out of this audit scope; the original seal failure is retained separately.

## Completed and uncompleted scope

Completed: read-only audit of the first actual failed run, its early save/removal/predicate cuts, exact named input receipts, newly installed artifact identities, independently decoded stopped terrain record and Python controls. Only this new small external evidence directory was written; no Root/source/old packet edits or full tree/region/JAR exports.

Uncompleted: a corrected native observation plan/run; actual unload/provider/final-disposal instrumentation; live restoration; clean stop and restart retrigger; first-save managed-entry defense; private GuardTicket/family consumers; charged ordinary/creative/drop conservation; independent-store consistency; natural crash recovery; player/client/native replay and all version Required Gates. Direct console `setblock` is not ordinary player-removal/drop-policy evidence. Existing save-risk R-021 remains open; its current risk-register entry explicitly distinguishes dirty marking from unload prevention and cross-store durability.

Next evidence must preserve this failed run and use a separately reviewed, source-backed observation amendment before executing a fresh native cohort. No production change or passing conclusion is recommended from these results.

## Evidence companions

- [Independent measured result and all named input hashes](AUDIT-RESULT-01.json)
- [Stopped allocation/record receipt](STOPPED-RECORD-01.json)
- [Raw independent extraction command/result](extract-command.json), [output](extract.log)
- [Raw independent audit command/result](audit-command.json), [output](audit.log)
- [Python command](python-command.json), [raw24-test output](python.log), [result](python-result.json)
- [Exact authoritative native marker excerpts](observed-markers.txt)
- The `inputs-02/` directory retains only the exact original script/test, first failed receipt/commands/log/Root result and original compressed fixed chunk needed to review this failure after runtime cleanup. Its entries are identified in the final loose manifest; no sealed prior artifact is changed. The first attempt's empty `inputs/` directory is left untouched.
