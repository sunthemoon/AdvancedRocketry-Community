"""Reviewer controls: reject substitutes for actual records/native block markers."""
import copy
import struct
import unittest
import zlib
from pathlib import Path

import audit_native01 as audit
from scripts import run_v180_guard_lifecycle_smoke as guard

HERE = Path(__file__).parent

class IndependentEvidenceControls(unittest.TestCase):
    def test_barrier_does_not_prove_restored_block(self):
        barrier = '[16:49:55] [Server thread/INFO] [minecraft/MinecraftServer]: [Not Secure] [Server] ARCE_GUARD_REMOVAL_ROLLED_BACK_END'
        observed = audit.markers([barrier])
        self.assertEqual(observed[0]['marker'], 'ARCE_GUARD_REMOVAL_ROLLED_BACK_END')
        self.assertFalse(any(m['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK' for m in observed))
        self.assertIsNone(guard.marker('ARCE_GUARD_REMOVAL_ROLLED_BACK').search(barrier))

    def test_nested_or_wrong_logger_is_not_an_observation(self):
        genuine = '[16:49:55] [Server thread/INFO] [minecraft/MinecraftServer]: [Server] ARCE_GUARD_LOADED'
        self.assertEqual(len(audit.markers([genuine])), 1)
        for line in ['echo ' + genuine, genuine.replace('/INFO]', '/ERROR]'),
                     genuine.replace('minecraft/MinecraftServer', 'example/Other')]:
            self.assertEqual(audit.markers([line]), [])

    def test_compressed_trailing_bytes_refused(self):
        compressed = (HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes()
        with self.assertRaises(AssertionError):
            audit.unpack(compressed + b'trailing')

    def test_duplicate_compound_key_refused(self):
        name = struct.pack('>H', 1) + b'a'
        raw = b'\x0a\x00\x00' + b'\x03' + name + struct.pack('>i', 1)
        raw += b'\x03' + name + struct.pack('>i', 2) + b'\x00'
        with self.assertRaises(AssertionError):
            audit.Reader(raw).root()

    def test_native_array_types_are_not_collapsed(self):
        def root(kind, width):
            body = b'\x0a\x00\x00' + bytes([kind]) + b'\x00\x01a' + struct.pack('>i', 1)
            return audit.Reader(body + (b'\x00' * width) + b'\x00').root()
        ints, longs = root(11, 4), root(12, 8)
        self.assertEqual(audit.plain(ints), audit.plain(longs))
        self.assertNotEqual(ints, longs)

    def test_palette_presence_is_not_exact_position(self):
        _, chunk, _ = audit.unpack((HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes())
        self.assertEqual(audit.cell(chunk, (186, 180, 180)), {'Name': 'advancedrocketrycommunity:pressurized_tank'})
        changed = copy.deepcopy(chunk)
        section = next(s for s in changed['sections'] if s['Y'] == 180 >> 4)
        states = section['block_states']
        air = next(i for i, state in enumerate(states['palette']) if state == {'Name': 'minecraft:air'})
        bits = max(4, (len(states['palette']) - 1).bit_length())
        cells = 64 // bits
        word = sum(air << (slot * bits) for slot in range(cells))
        if word >= 1 << 63:
            word -= 1 << 64
        states['data'] = [word] * len(states['data'])
        self.assertIn({'Name': 'advancedrocketrycommunity:pressurized_tank'}, states['palette'])
        self.assertEqual(audit.cell(changed, (186, 180, 180)), {'Name': 'minecraft:air'})

    def test_wrong_identity_and_expansion_limit_refused(self):
        _, chunk, _ = audit.unpack((HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes())
        with self.assertRaises(AssertionError):
            audit.cell(chunk, (0, 180, 0))
        with self.assertRaises(AssertionError):
            audit.unpack(zlib.compress(b'x' * (1024 * 1024 + 1)))

    def test_same_saved_bytes_do_not_supply_missing_live_marker(self):
        compressed = (HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes()
        self.assertEqual(guard.check_record(compressed, compressed)['sha256'],
                         'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8')
        lines = (audit.PHASE / 'stdout.txt').read_text(encoding='utf-8').splitlines()
        self.assertTrue(any(m['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK_END' for m in audit.markers(lines)))
        self.assertFalse(any(m['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK' for m in audit.markers(lines)))

if __name__ == '__main__':
    unittest.main()
