# Native guard lifecycle first-run evidence audit

Delegated independent read-only evidence auditor. Root native first run and
source reviewed by another agent are inputs, not a requested passing verdict.

write_scope: only this fresh external D directory for small report, scripts,
controls, captured compressed fixed chunk and receipts/hashes. Root, source,
old packets and historical source worlds remain read-only. No Java, Gradle,
server/native replay, cleanup, process operations, commits, push, OpenPet,
protected bundle access, source tree or region/world export.

The only world read permitted is the stopped owned native01 runtime's fixed
terrain region r.0.0.mca; extraction is limited to chunk 11,11. Historical input
preservation is audited from existing receipts/manifests, not new world walks.
