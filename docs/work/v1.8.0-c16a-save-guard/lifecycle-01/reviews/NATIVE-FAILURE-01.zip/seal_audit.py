"""Pin/check narrow named input snapshots and seal only this small audit bundle."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
result = json.loads((HERE / 'AUDIT-RESULT-01.json').read_bytes())
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
targets = {
    'script.py': ROOT / 'scripts/run_v180_guard_lifecycle_smoke.py',
    'test_script.py': ROOT / 'tests/test_run_v180_guard_lifecycle_smoke.py',
    'native-result.json': BASE / 'NATIVE-RESULT-01.json',
    'native-traceback.log': BASE / 'native-01.log',
    'phase-receipt.json': BASE / 'native-01/removal-availability-reload/receipt.json',
    'phase-commands.json': BASE / 'native-01/removal-availability-reload/commands.json',
    'stdout.txt': BASE / 'native-01/removal-availability-reload/stdout.txt',
    'captured-original-chunk.nbt.zlib': BASE / 'native-01/source-chunk-11-11.nbt.zlib',
}
directory = HERE / 'inputs'
assert not directory.exists()
directory.mkdir()
for name, source in targets.items():
    body = source.read_bytes()
    assert pin(body) == result['inputs'][str(source)], str(source)
    (directory / name).write_bytes(body)
links = re.findall(r'\]\(([^)]+)\)', (HERE / 'REPORT.md').read_text(encoding='utf-8'))
assert all((HERE / name).is_file() for name in links)
files = {}
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        files[path.relative_to(HERE).as_posix()] = pin(path.read_bytes())
out = {'format': 'loose-evidence-manifest-v1', 'files': files, 'payload_count': len(files),
       'payload_bytes': sum(row['bytes'] for row in files.values()),
       'source_snapshot': '355c4681a6cbddd380545a50e0f6e524bad6d295 plus two exact development test-tool inputs',
       'native_result': 'FAIL; exit1; no completed restart cohort',
       'links_checked': len(links), 'links_missing': 0, 'source_runtime_writes': False,
       'archive_created': False}
manifest = HERE / 'MANIFEST.json'
assert not manifest.exists()
manifest.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
files['MANIFEST.json'] = pin(manifest.read_bytes())
checksums = HERE / 'SHA256SUMS.txt'
assert not checksums.exists()
checksums.write_bytes(''.join(f"{row['sha256']}  {name}\n" for name, row in sorted(files.items())).encode('ascii'))
print(json.dumps({'report': files['REPORT.md'], 'manifest': files['MANIFEST.json'],
                  'checksums': pin(checksums.read_bytes()), 'payload_count': out['payload_count'],
                  'payload_bytes': out['payload_bytes'], 'links': len(links)}, indent=2))
