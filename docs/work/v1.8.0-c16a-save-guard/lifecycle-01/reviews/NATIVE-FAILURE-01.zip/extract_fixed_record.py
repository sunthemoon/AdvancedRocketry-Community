"""Read exactly one stopped region; independent bounded allocation extraction."""
import hashlib
import json
import struct
from pathlib import Path

HERE = Path(__file__).parent
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-01')
region = BASE / 'server/world/region/r.0.0.mca'
assert region.is_file() and not region.is_symlink() and region.stat().st_size <= 16 * 1024 * 1024
raw = region.read_bytes()
slot = 11 + 32 * 11
offset = 4 * slot
sector = int.from_bytes(raw[offset:offset + 3], 'big')
allocation = raw[offset + 3]
assert sector >= 2 and allocation >= 1 and (sector + allocation) * 4096 <= len(raw)
start = sector * 4096
length = struct.unpack_from('>I', raw, start)[0]
assert 2 <= length <= 128 * 1024 + 1 and length + 4 <= allocation * 4096
assert raw[start + 4] == 2
record = raw[start + 5:start + 4 + length]
source = (BASE / 'source-chunk-11-11.nbt.zlib').read_bytes()
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
out = {'region_path': str(region), 'region': pin(raw), 'slot': slot, 'sector': sector,
       'allocation_sectors': allocation, 'record_length_with_codec': length,
       'record': pin(record), 'captured_source': pin(source),
       'compressed_record_equal': record == source,
       'termination_boundary': 'after harness failure/abort; not a successful stop/restart phase'}
target = HERE / 'STOPPED-RECORD-01.json'
assert not target.exists() and not (HERE / 'stopped-chunk-11-11.nbt.zlib').exists()
target.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
(HERE / 'stopped-chunk-11-11.nbt.zlib').write_bytes(record)
print(json.dumps(out, indent=2))
