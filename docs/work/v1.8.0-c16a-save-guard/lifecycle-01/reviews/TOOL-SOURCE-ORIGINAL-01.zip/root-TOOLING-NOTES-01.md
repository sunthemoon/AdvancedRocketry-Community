# Root tooling observations

Initial focused command: 30 tests, one error, exit 1. The mocked clock ran out;
the separately corrected clock fixture passes the same 30 tests. The original
tool result is transcribed in INITIAL-UNIT-FAILURE-01.txt, not represented as an
original raw file capture. Production deadlines and assertions were unchanged.

An optional level.dat spawn inspection used the SavedData reader's unchanged
4,096-tag budget and failed with NbtError before returning the spawn fields.
No reader limit was enlarged and no world was modified. That command first
validated the 5,898-byte fixture chunk but printed an unnecessarily long root;
it is not a passing spawn observation. The separate fixture-intake-02 command
prints only chunk identity and historical logger accounting and exits 0.

Initial read-only path discovery encountered absent lower-case version/plan
and test directory guesses and a Windows rg wildcard argument error. The real
version, status plan and tests were then read by exact paths. These are tooling
failures, not production failures or passing validation commands.
