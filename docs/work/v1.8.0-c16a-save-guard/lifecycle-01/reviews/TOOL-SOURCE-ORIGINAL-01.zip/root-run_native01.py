"""Root command receipt and unchanged build-input precheck for one native task."""
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41')
JAR = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/artifacts/advancedrocketry-community-1.20.1-1.8.0-dev.jar')
SERVER = OLD / 'tank-native-06/server'
PINS = {
    'scripts/run_v180_guard_lifecycle_smoke.py': 'be65d985495146c67b0969fa9472e373fc3f89997b15c9fa93bf9febc38e28f3',
    'tests/test_run_v180_guard_lifecycle_smoke.py': 'd431a668d5b3b1617023ce471f465006590c4978d08f9d6546d6d34703d06c11',
}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

inputs = json.loads(Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/SOURCE22-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, record in inputs.items():
    path = ROOT / name
    assert path.stat().st_size == record['bytes'] and digest(path) == record['sha256'], name
for name, pin in PINS.items():
    assert digest(ROOT / name) == pin, name
assert digest(JAR) == '26356660ef03e9e938067e8bb53ac085290300cdf947a27d0d85dd6c1355682a'
fixture = SERVER / 'mods/arce-adapter-compat-test-1.0.0.jar'
assert digest(fixture) == '765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == '355c4681a6cbddd380545a50e0f6e524bad6d295'
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
write('NATIVE-PRECHECK-01.json', {'head': head, 'source22_inputs_unchanged': len(inputs),
                               'candidate_pins': PINS, 'free_bytes': free, 'threshold_bytes': 10000000000})
assert all(value >= 10000000000 for value in free.values())
libraries = {}
library_total = 0
for path in sorted((SERVER / 'libraries').rglob('*')):
    assert not path.is_symlink()
    if path.is_file():
        size = path.stat().st_size
        library_total += size
        assert size <= 64 * 1024 ** 2 and len(libraries) < 512 and library_total <= 512 * 1024 ** 2
        libraries[path.relative_to(SERVER / 'libraries').as_posix()] = {'bytes': size, 'sha256': digest(path)}
write('LIBRARIES-INPUTS-01.json', libraries)
command = [sys.executable, '-B', 'scripts/run_v180_guard_lifecycle_smoke.py',
           '--runtime-template', str(SERVER), '--source-world', str(SERVER / 'world'),
           '--host-jar', str(JAR), '--fixture-jar', str(fixture),
           '--work-root', str(OUT / 'native-01'), '--java', 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
write('NATIVE-COMMAND-01.json', {'command': command, 'cwd': str(ROOT), 'started_utc': started})
start = time.monotonic()
with (OUT / 'native-01.log').open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
write('NATIVE-RESULT-01.json', {'command': command, 'exit_code': result.returncode,
                             'elapsed_seconds': time.monotonic() - start, 'started_utc': started,
                             'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
post = {
    'source22_inputs_unchanged': all((ROOT / name).stat().st_size == row['bytes']
                                   and digest(ROOT / name) == row['sha256'] for name, row in inputs.items()),
    'candidate_unchanged': all(digest(ROOT / name) == pin for name, pin in PINS.items()),
    'source_libraries_unchanged': all((SERVER / 'libraries' / name).stat().st_size == row['bytes']
                                    and digest(SERVER / 'libraries' / name) == row['sha256']
                                    for name, row in libraries.items()),
}
write('NATIVE-POSTCHECK-01.json', post)
assert all(post.values()), post
print((OUT / 'native-01.log').read_text(encoding='utf-8'))
sys.exit(result.returncode)
