# Guard lifecycle harness: independent source review 01

## Findings

### Medium M1 — broad refusal-text matching can waive unexpected log findings

In the reviewed [script](candidate-02/scripts/run_v180_guard_lifecycle_smoke.py),
lines 100–108 delegate log admission to `tanks.audit_save_refusal` and count
headers using any ERROR logger plus the message substring. The unchanged
parent (`scripts/run_v180_tank_smoke.py`, lines 212–222) similarly permits any
finding containing the expected phrase or the chunk-save suffix, without
requiring its expected severity and logger.

Consequently:

- Expected EventBus/ChunkMap ERRORs plus an unrelated FATAL containing the
  refusal text are accepted, including the FATAL in the returned findings.
- Two ERRORs from `example/Other` with the known messages are accepted and
  counted as one native EventBus/ChunkMap pair.

The [unchanged reviewer controls](independent_controls02.py), lines 148–157,
reproduce both cases: [10 tests, two failures, exit 1](independent-02.log).
This is one log-classification issue, not two independent findings. It is
inherited by the new wrapper but affects this wrapper's paired-native-header
claim. Require the actual expected ERROR severities/loggers and reject all
other findings, including every FATAL. Preserve the actual expected refusal
messages, chunk identity and count requirement. This recommendation changes
only test-oracle admission, not production save or risk policy.

No native failure or actual unexpected FATAL is alleged by these synthetic
controls. Native execution has not been performed by this reviewer.

## Prior observed claim correction

The first read saw script `9700d3f01a03d848af2dde1de3061d3b4f38769b1f70ddb3d2cb4f48a0695d0c`
and test `46ec6c98a4bce0d9fa524b7676ce1ea60c7c8a71f6143f84b0cbdb65e72e8cdd`.
Their loaded-command observation was described as a FULL-availability cut.
These reads were tool-output observations; this reviewer did not obtain a
complete original three-file snapshot before Root's correction. Do not treat
the later snapshots as the original bytes.

The independently checked [primary facts](PRIMARY-01.json) establish that
`ExecuteCommand.isChunkLoaded` requires a nonnull chunk, status exactly
`ENTITY_TICKING`, and `areEntitiesLoaded`. A false result alone does not prove
loss of FULL, disposal, or unload callback execution. Root separately changed
the wording/marker/summary. The snapshotted proposal now says loaded-predicate
cut and explicitly leaves callbacks uninstrumented. That observed claim issue
is addressed in these postimages; it does not grant unload proof.

## Sequencing boundary

Lines 151–156 reacquire the ticket after the first false loaded predicate.
The modeled control in [independent_controls02.py](independent_controls02.py),
lines 85–93, exercises a source-supported distinction: the loaded predicate
becomes false while the mutable chunk has not yet been disposed. Immediate
reacquisition retains the edited cells and the restoration oracle correctly
fails. This is **not** a rollback false-positive and is not a production
diagnosis. It remains a dependency for obtaining the intended native disposal/
restoration observation. An unrelated fixed delay or forced ticket is not
proof. No reliable disposal instrument was implemented or independently
admitted by this review. Root's separately investigated native debug-report
observation requires its own source/command assessment if added.

## Scope and pinned inputs

Baseline HEAD: `355c4681a6cbddd380545a50e0f6e524bad6d295`.
The repository reported only unrelated user-maintained `AGENTS.md` changes in
tracked status; these three candidate files are new/untracked. Root alone
writes/integrates them. No Root file, Java source, policy or sealed evidence
was edited by this reviewer.

[INPUTS-01](INPUTS-01.json) binds 25 individually named governance, proposal and
dependency inputs. The exact three proposal snapshots are under
`candidate-02/`; no whole-source export, JAR, runtime library or world copy is
included. Current script/test hashes are respectively
`be65d985495146c67b0969fa9472e373fc3f89997b15c9fa93bf9febc38e28f3` and
`d431a668d5b3b1617023ce471f465006590c4978d08f9d6546d6d34703d06c11`.
The task hash is recorded in that manifest rather than inferred from mutable
progress. [POSTCHECK-01](POSTCHECK-01.json) records all named inputs unchanged
through the scoped replay.

The primary mapped Forge 47.4.10 JAR was independently SHA-checked at
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Only its named ExecuteCommand entry was parsed. The retained JSON contains
selected declaration/branch facts and hashes, not official class bodies.

Root's [first failure transcription](root-INITIAL-UNIT-FAILURE-01.txt) and
[separate corrected run](root-unit-02.log) are preserved byte-for-byte and
indexed by [HISTORICAL-INPUTS-01](HISTORICAL-INPUTS-01.json). The first is
explicitly a transcribed tool result, not an original wrapper log.
The copied `root-run_native01.py` is inspected only; it was not executed.

## Actual checks

- [audit.py](audit.py): SHA intake, independent primary class parser and
  `python -B -m unittest tests.test_run_v180_guard_lifecycle_smoke
  tests.test_run_v180_tank_smoke`: [exit 0, 30 tests](scoped-01.log),
  0.050 seconds as reported by unittest. Exact command/time/log pins are in
  [scoped-01.json](scoped-01.json).
- First reviewer controls: [exit 1, 10 tests/three failures](independent-01.log).
  Two are M1. The third was this reviewer's incorrect expected exception-message
  regex (`overlap` versus the actual `World copy must be new and disjoint`).
  The original script/log were not overwritten.
- Separately corrected reviewer regex only: [exit 1, 10 tests/two failures](independent-02.log),
  with [exact command receipt](independent-02.json). The two M1 controls are
  unchanged. Eight controls pass, covering modeled stage ordering, missing
  restoration rejection, byte-mismatch rejection, nonzero process exit,
  restart refusal, overlap rejection before launch, bounded real tiny-world
  copy isolation, and fixture nonmutation.

The first reviewer invocation used a Python orchestration wrapper which exited
0 while recording inner test exit 1; that outer tool exit is not a test pass.
The corrected invocation explicitly propagates test exit 1.

No Java, Gradle, native server/client, dependency download, live-world read,
Git write, OpenPet event or cleanup of another task was performed. Temporary
toy-copy test directories were created only inside this reviewer's own directory
and removed by `TemporaryDirectory`.

## Safety and unverified boundaries

The code requires a fresh disjoint output, copies/verifies a bounded input
world before process launch, checks library links, installs hash-checked copied
artifacts, and postchecks original world/artifacts after the two cycles.
Expected cell positions and chunk identity are fixed. Console markers require
the exact INFO MinecraftServer `[Server]` origin and fresh command-barrier
position. Load polling keeps the total 60-second/240-probe bound;
startup/save/stop remain 300 seconds. Disk comparison runs only after a clean
process exit and checks exact compressed chunk payload before semantic decode.
It is not a comparison of the entire region file, timestamps or padding.

Runtime-library content pinning and the intended input fixture/JAR identity
must be bound by the actual runner/result evidence. The script records paths
and JAR hashes but does not independently hard-code all runtime-library hashes.
Fixture semantic decoding is a plain-value check; compressed-byte equality
preserves the supplied original record, not a universal typed-NBT migration
claim. The Root launch wrapper pins source/JAR/fixture before launch; this
review did not read or rerun its live/native inputs.

Actual callbacks, record restoration, native refusal, durable resource behavior,
256/257 saturation, first-save writer, cross-store/arbitrary-crash conservation,
offline repair, performance/log quota, visual/multiplayer and version Gates
remain unverified here. Existing build/DataGen/GameTest evidence is inherited,
not a new execution or source admission by this task. New Guard/carrier runtime
or R-021/ADR/risk acceptance is not granted.

Recommendation for the reviewed source: resolve M1 before using this oracle to
admit a native result. Assess any subsequently added lifecycle instrument as a
separate postimage; do not borrow this report as its source verdict.
