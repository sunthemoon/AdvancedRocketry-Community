# Read-only locator/tooling observations

The first PowerShell intake guessed `docs/versions/v1.8.0.md`; Get-FileHash
reported that absent file, while the compound shell command continued and
exited 0. A later bounded lookup found the actual named
`V1.8.0-CLASSIC-CONTENT-COMPLETION.md`, used by the successful intake. Similarly,
one bounded `rg` call guessed an absent ADR-064 filename and the compound
command exited 1; the actual `ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md`
was read and pinned afterwards. These are locator failures, not passing checks.
The original terminal outputs are not falsely represented as raw file logs.

Three guessed server-copy dependency filenames in preliminary exploration were
absent. The actual Tank imports supplied the named dependency paths pinned in
INPUTS-01; no arbitrary tree search or protected bundle access was performed.

The first reviewer test run had a message-regex fixture failure. The exact
original source/result remain unchanged, and the separately named controls02
correct only `overlap` to the actual `new and disjoint` phrase. The actual
copy refusal and isolation assertions are retained. Two unrelated log-admission
failures remain red and are reported, not relabeled as tool errors.

Evidence location: `D:/ARCE-Task-Evidence/v1.8.0/aglr-f0f51f0d31`.
No redundant archive or whole-source copy is produced under current AGENTS
storage rules. No native runner was invoked.
