"""Reviewer-only specification controls; modeled processes never launch Java."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard
from tests.test_run_v180_guard_lifecycle_smoke import errors, info, oversized_fixture

class TraceProcess:
    """Finite console trace model, not a Minecraft lifecycle implementation."""
    def __init__(self, restore=True, exit_code=0):
        self.lines = ['[Server thread/INFO] [minecraft/DedicatedServer]: Done (1.0s)! For help, type "help"']
        self.blocks = {guard.CULPRIT: guard.tanks.NS + ':pressurized_tank',
                       guard.tanks.SAVE_MARKER_POSITION: 'minecraft:air'}
        self.restore, self.loaded, self.exit_code = restore, False, exit_code
        self.aborted = False
        self.requested = []

    def command(self, command):
        self.requested.append(command)
        parts = command.split()
        if command.startswith('forceload add'):
            if self.restore and any(line == 'NOT_LOADED_CUT' for line in self.lines):
                self.blocks[guard.CULPRIT] = guard.tanks.NS + ':pressurized_tank'
                self.blocks[guard.tanks.SAVE_MARKER_POSITION] = 'minecraft:air'
            self.loaded = True
        elif command.startswith('forceload remove'):
            self.loaded = False
            self.lines.append('NOT_LOADED_CUT')
        elif command.startswith('setblock '):
            self.blocks[tuple(map(int, parts[1:4]))] = parts[4]
        elif command.startswith('execute '):
            if parts[2] == 'loaded':
                matches = self.loaded if parts[1] == 'if' else not self.loaded
            else:
                matches = self.blocks[tuple(map(int, parts[3:6]))] == parts[6]
            if matches: self.lines.append(info(parts[-1]))
        elif command.startswith('say '): self.lines.append(info(command[4:]))
        elif command == 'save-all flush':
            self.lines += errors() + ['[Server thread/INFO] [minecraft/MinecraftServer]: Saved the game']

    def wait_for(self, expression, timeout, start_at=0):
        assert timeout <= 300
        if not any(expression.search(line) for line in self.lines[start_at:]):
            raise guard.server.SmokeError('Modeled marker unavailable')

    def finish(self, timeout):
        assert timeout == 300
        return self.exit_code

    def abort(self): self.aborted = True

class IndependentGuardControls(unittest.TestCase):
    def run_cycle(self, process, actual=b'fixed', removal=True):
        with tempfile.TemporaryDirectory(prefix='cycle-', dir=OUT) as folder:
            folder = Path(folder)
            with patch.object(guard.server, 'CapturedProcess', return_value=process), \
                    patch.object(guard, 'saved_record', return_value=actual), \
                    patch.object(guard.regions, '_decode_chunk', return_value=oversized_fixture()), \
                    patch.object(guard.time, 'monotonic', return_value=0), \
                    patch.object(guard.time, 'sleep'):
                try:
                    result = guard.native_cycle(folder, folder / 'evidence', ['MODELED_NO_JAVA'], b'fixed', removal)
                except Exception:
                    self.last_receipt = json.loads((folder / 'evidence/receipt.json').read_text(encoding='utf-8'))
                    raise
                self.last_receipt = json.loads((folder / 'evidence/receipt.json').read_text(encoding='utf-8'))
                return result

    def test_modeled_cycle_requires_each_exact_stage_and_preserves_budget(self):
        process = TraceProcess()
        result = self.run_cycle(process)
        self.assertEqual(result['result'], 'PASS')
        self.assertEqual(result['after_removal_refusal']['event_bus_error_headers'], 1)
        self.assertIn('setblock 186 180 180 minecraft:air', process.requested)
        self.assertIn('execute unless loaded 180 180 180 run say ARCE_GUARD_NOT_LOADED', process.requested)
        self.assertIn('execute if block 186 180 180 advancedrocketrycommunity:pressurized_tank run say ARCE_GUARD_REMOVAL_ROLLED_BACK', process.requested)
        self.assertEqual(process.requested[-1], 'stop')
        self.assertFalse(process.aborted)

    def test_false_loaded_predicate_without_disposal_does_not_fake_rollback(self):
        process = TraceProcess(restore=False)
        with self.assertRaisesRegex(RuntimeError, 'REMOVAL_ROLLED_BACK'):
            self.run_cycle(process)
        self.assertEqual(self.last_receipt['result'], 'FAIL')
        self.assertTrue(process.aborted)
        self.assertNotIn('stop', process.requested)

    def test_bad_stopped_record_is_not_accepted_after_console_success(self):
        process = TraceProcess()
        with self.assertRaisesRegex(RuntimeError, 'terrain record changed'):
            self.run_cycle(process, actual=b'changed')
        self.assertEqual(self.last_receipt['result'], 'FAIL')
        self.assertTrue(process.aborted)

    def test_nonzero_exit_is_not_accepted_before_disk_oracle(self):
        process = TraceProcess(exit_code=1)
        with self.assertRaisesRegex(RuntimeError, 'stop cleanly'):
            self.run_cycle(process)
        self.assertEqual(self.last_receipt['result'], 'FAIL')

    def test_restart_cycle_retriggers_refusal_without_removal(self):
        process = TraceProcess()
        result = self.run_cycle(process, removal=False)
        self.assertEqual(result['result'], 'PASS')
        self.assertNotIn('after_removal_refusal', result)
        self.assertNotIn('setblock 186 180 180 minecraft:air', process.requested)

    def test_input_output_overlap_rejected_before_any_launch_or_artifact_read(self):
        with tempfile.TemporaryDirectory(prefix='paths-', dir=OUT) as folder:
            folder = Path(folder)
            source = folder / 'source'; source.mkdir()
            work = source / 'new-evidence'
            args = ['guard', '--runtime-template', str(source), '--source-world', str(source),
                    '--host-jar', str(folder / 'host.jar'), '--fixture-jar', str(folder / 'fixture.jar'),
                    '--work-root', str(work)]
            with patch.object(sys, 'argv', args), patch.object(guard.server, 'CapturedProcess') as native, \
                    patch.object(guard.tanks.motors, 'artifact') as artifact:
                with self.assertRaisesRegex(RuntimeError, 'overlaps an input'):
                    guard.main()
                native.assert_not_called(); artifact.assert_not_called()
            self.assertFalse(work.exists())

    def test_real_bounded_world_copy_isolated_and_original_manifest_unchanged(self):
        with tempfile.TemporaryDirectory(prefix='world-copy-', dir=OUT) as folder:
            folder = Path(folder)
            source = folder / 'source'; source.mkdir()
            (source / 'probe.bin').write_bytes(b'original')
            before = guard.worlds.inventory(source)
            self.assertEqual(guard.worlds.copy_world(source, folder / 'copy'), before)
            (folder / 'copy/probe.bin').write_bytes(b'changed')
            self.assertEqual(guard.worlds.inventory(source), before)
            with self.assertRaisesRegex(RuntimeError, 'overlap'):
                guard.worlds.copy_world(source, source / 'child')

    def test_fixture_resource_and_marker_inputs_not_mutated(self):
        chunk = oversized_fixture(); before = copy.deepcopy(chunk)
        guard.check_fixture(chunk)
        self.assertEqual(chunk, before)

    def test_guard_message_in_unrelated_fatal_must_not_be_waived(self):
        fatal = '[Server thread/FATAL] [example/Other]: Exception caught during firing event: ' + guard.tanks.SAVE_REFUSAL
        with self.assertRaises(RuntimeError):
            guard.audit_refusal(errors() + [fatal])

    def test_known_text_from_other_error_logger_must_not_count_as_native_pair(self):
        impostor = [line.replace('net.minecraftforge.eventbus.EventBus/EVENTBUS', 'example/Other')
                    .replace('minecraft/ChunkMap', 'example/Other') for line in errors()]
        with self.assertRaises(RuntimeError):
            guard.audit_refusal(impostor)

if __name__ == '__main__': unittest.main(verbosity=2)
