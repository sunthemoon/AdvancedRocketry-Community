"""Bounded read-only intake and Python replay; never starts a native process."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
GOVERNANCE = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
              'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
              'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
              'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
              'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
              'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
              'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md',
              'docs/work/v1.8.0-c16a-save-guard/SAVE-REFUSAL-DISPOSITION-01.md']
CANDIDATE = ['scripts/run_v180_guard_lifecycle_smoke.py',
             'tests/test_run_v180_guard_lifecycle_smoke.py',
             'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md']
DEPENDENCIES = ['scripts/run_v180_tank_smoke.py', 'tests/test_run_v180_tank_smoke.py',
                'scripts/run_dedicated_server_smoke.py', 'scripts/run_v050_rocket_server_smoke.py',
                'scripts/run_v180_motor_smoke.py', 'scripts/v120_precision_world_fixture.py',
                'scripts/v140_migration_fixture.py', 'scripts/inspect_celestial_saved_data.py',
                'scripts/run_v130_adapter_recovery_smoke.py']

def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def command(name, args, cwd=ROOT):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    write(name + '.json', {'command': args, 'cwd': str(cwd), 'started_utc': start,
                          'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'elapsed_seconds': time.monotonic() - tick, 'exit_code': result.returncode,
                          'log': name + '.log', 'log_identity': pin(OUT / (name + '.log'))})
    print(name, result.returncode)
    print((OUT / (name + '.log')).read_text(encoding='utf-8'))
    return result.returncode

def intake():
    paths = GOVERNANCE + CANDIDATE + DEPENDENCIES
    baseline = {name: pin(ROOT / name) for name in paths}
    for name in CANDIDATE:
        target = OUT / 'candidate-02' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / name).read_bytes())
    write('INPUTS-01.json', {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                            'files': baseline, 'source_snapshots': CANDIDATE})
    assert baseline[CANDIDATE[0]]['sha256'] == 'be65d985495146c67b0969fa9472e373fc3f89997b15c9fa93bf9febc38e28f3'
    assert baseline[CANDIDATE[1]]['sha256'] == 'd431a668d5b3b1617023ce471f465006590c4978d08f9d6546d6d34703d06c11'
    evidence = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
    history = ['INITIAL-UNIT-FAILURE-01.txt', 'unit-02.log', 'unit-02.exit',
               'TOOLING-NOTES-01.md', 'run_native01.py']
    for name in history:
        (OUT / ('root-' + name)).write_bytes((evidence / name).read_bytes())
    write('HISTORICAL-INPUTS-01.json', {str(evidence / name): pin(evidence / name) for name in history})
    return baseline

def primary():
    # Independently parse just the named class method. No official body is emitted.
    path = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
    identity = pin(path)
    assert identity['sha256'] == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
    with zipfile.ZipFile(path) as archive:
        raw = archive.read('net/minecraft/server/commands/ExecuteCommand.class')
    assert hashlib.sha256(raw).hexdigest() == 'd98eec809b2477b3de63aa2e567c6c4cffda13683b2c24302841666f508a15a8'
    at = 8
    def take(n):
        nonlocal at
        value = raw[at:at+n]; at += n; return value
    def u2(): return int.from_bytes(take(2), 'big')
    def u4(): return int.from_bytes(take(4), 'big')
    cp = [None] * u2(); index = 1
    while index < len(cp):
        tag = take(1)[0]
        if tag == 1: cp[index] = take(u2()).decode('utf-8', errors='replace')
        elif tag in (7, 8, 16, 19, 20): cp[index] = (tag, u2())
        elif tag in (9, 10, 11, 12, 17, 18): cp[index] = (tag, u2(), u2())
        elif tag in (3, 4): take(4)
        elif tag in (5, 6): take(8); index += 1
        elif tag == 15: take(3)
        else: raise ValueError(tag)
        index += 1
    def ref(index):
        entry = cp[index]
        owner = cp[cp[entry[1]][1]]
        pair = cp[entry[2]]
        return owner + '.' + cp[pair[1]] + cp[pair[2]]
    take(6); take(u2()*2)
    def attrs():
        result = {}
        for _ in range(u2()):
            name = cp[u2()]; result[name] = take(u4())
        return result
    for _ in range(u2()): take(6); attrs()
    method = None
    for _ in range(u2()):
        access, name, descriptor = u2(), cp[u2()], cp[u2()]
        values = attrs()
        if name == 'isChunkLoaded': method = (descriptor, values['Code'])
    assert method is not None
    code = method[1][8:8+int.from_bytes(method[1][4:8], 'big')]
    targets = {21: 'getChunkNow', 30: 'getFullStatus', 33: 'ENTITY_TICKING', 44: 'areEntitiesLoaded'}
    facts = []
    for offset, expected in targets.items():
        reference = ref(int.from_bytes(code[offset+1:offset+3], 'big'))
        assert expected in reference
        facts.append({'offset': offset, 'opcode': code[offset], 'reference': reference})
    assert code[26] == 0xc6 and code[36] == 0xa6 and code[47] == 0x99
    assert code[50] == 0x04 and code[54] == 0x03 and code[56] == 0x03
    write('PRIMARY-01.json', {'jar_path': str(path), 'jar': identity,
                            'entry': 'net/minecraft/server/commands/ExecuteCommand.class',
                            'entry_bytes': len(raw), 'entry_sha256': hashlib.sha256(raw).hexdigest(),
                            'method': 'isChunkLoaded' + method[0], 'selected_references': facts,
                            'branch_fact': 'nonnull chunk AND exact ENTITY_TICKING AND areEntitiesLoaded',
                            'native_body_copied': False, 'Java_launches': 0})

if __name__ == '__main__':
    before = intake()
    primary()
    result = command('scoped-01', [sys.executable, '-B', '-m', 'unittest',
                                  'tests.test_run_v180_guard_lifecycle_smoke', 'tests.test_run_v180_tank_smoke'])
    after = {name: pin(ROOT / name) for name in before}
    write('POSTCHECK-01.json', {'files': after, 'changed': [name for name in before if before[name] != after[name]]})
    assert before == after
    sys.exit(result)
