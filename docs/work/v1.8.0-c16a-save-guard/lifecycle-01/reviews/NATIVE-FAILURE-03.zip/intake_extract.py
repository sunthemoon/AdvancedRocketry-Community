"""Capture only named native03 receipts and one stopped region record."""
import ast
import hashlib
import json
import re
import struct
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
inputs = {}

def read(path):
    body = path.read_bytes()
    inputs[str(path)] = pin(body)
    return body

old_body = read(BASE / 'SOURCE23-MANIFEST-01.json')
new_body = read(BASE / 'SETUP03-MANIFEST-01.json')
old, new = json.loads(old_body), json.loads(new_body)
assert len(old) == len(new) == 2995 and set(old) == set(new)
for name, row in new.items():
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in name
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in relative.parts
    assert set(row) == {'bytes', 'sha256'} and type(row['bytes']) is int and row['bytes'] >= 0
    assert re.fullmatch('[0-9a-f]{64}', row['sha256'])
changed = {name: {'before': old[name], 'after': new[name]} for name in old if old[name] != new[name]}
assert set(changed) == {'scripts/run_v180_guard_lifecycle_smoke.py', 'tests/test_run_v180_guard_lifecycle_smoke.py'}
assert changed['scripts/run_v180_guard_lifecycle_smoke.py']['after']['sha256'] == '4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad'
assert changed['tests/test_run_v180_guard_lifecycle_smoke.py']['after']['sha256'] == 'e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16'
source = HERE / 'source_inputs'
assert not source.exists()
source.mkdir()
source_names = [*changed, 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java']
for name in source_names:
    body = read(ROOT / name)
    assert pin(body) == new[name], name
    (source / Path(name).name).write_bytes(body)
required = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
            'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
            'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
            'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
            'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
            'docs/decisions/ADR-064-CLASSIC-MACHINES-FLUIDS-AND-COMPONENTS.md', 'docs/11-RISK-REGISTER.md']
for name in required:
    read(ROOT / name)
names = ['native-03-command.json', 'native-03-result.json', 'native-03.log',
         'NATIVE-PRECHECK-03.json', 'NATIVE-POSTCHECK-03.json', 'SETUP03-BOUNDARY-01.json',
         'ARTIFACTS23-01.json', 'LIBRARIES-INPUTS-01.json', 'run_native03.py',
         'python-regression-08-command.json', 'python-regression-08-result.json', 'python-regression-08.log',
         'native-03/inputs.json', 'native-03/input-postcheck.json', 'native-03/source-world-files.json',
         'native-03/removal-availability-reload/receipt.json',
         'native-03/removal-availability-reload/commands.json',
         'native-03/removal-availability-reload/launch.json',
         'native-03/removal-availability-reload/stdout.txt',
         'native-03/removal-availability-reload/latest.log',
         'native-03/removal-availability-reload/debug.log']
raw = HERE / 'raw_inputs'
assert not raw.exists()
raw.mkdir()
for name in names:
    body = read(BASE / name)
    assert len(body) <= 1_000_000
    target = raw / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
region = BASE / 'native-03/server/world/region/r.0.0.mca'
assert region.is_file() and not region.is_symlink() and region.stat().st_size <= 16 * 1024 * 1024
body = read(region)
slot = 11 + 32 * 11
index = slot * 4
sector = int.from_bytes(body[index:index + 3], 'big')
sectors = body[index + 3]
assert sector >= 2 and sectors >= 1 and (sector + sectors) * 4096 <= len(body)
start = sector * 4096
length = struct.unpack_from('>I', body, start)[0]
assert 2 <= length <= 128 * 1024 + 1 and length + 4 <= sectors * 4096
assert body[start + 4] == 2
actual = body[start + 5:start + 4 + length]
original = read(BASE / 'native-03/source-chunk-11-11.nbt.zlib')
assert len(original) == 5898 and pin(original)['sha256'] == 'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
(HERE / 'stopped-chunk-11-11.nbt.zlib').write_bytes(actual)
(HERE / 'captured-source-chunk-11-11.nbt.zlib').write_bytes(original)
# Reuse only the earlier independent parser declarations, not any old cohort input/main/outcome.
helper = Path('D:/ARCE-Task-Evidence/v1.8.0/agla2-f8a64164b5/reviewer_reader.py')
helper_body = read(helper)
old_manifest = json.loads((helper.parent / 'MANIFEST.json').read_bytes())
assert pin(helper_body) == old_manifest['files'][helper.name]
tree = ast.parse(helper_body)
allowed = {'pin', 'Reader', 'plain', 'unpack', 'cell'}
nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in allowed]
assert len(nodes) == len(allowed)
pure = '"""Pure bounded parser functions reused from own immutable prior audit; no prior data/main."""\nimport hashlib\nimport struct\nimport zlib\n\n'
pure += '\n\n'.join(ast.unparse(node) for node in nodes) + '\n'
(HERE / 'native_reader.py').write_bytes(pure.encode('utf-8'))
out = {'input_pins': inputs, 'source23_manifest': pin(old_body), 'setup03_manifest': pin(new_body),
       'manifest_rows': len(new), 'changed_inputs': changed, 'unchanged_other_inputs': len(new)-len(changed),
       'exact_captured_source_names': source_names,
       'record_allocation': {'slot': slot, 'sector': sector, 'sectors': sectors, 'length_with_codec': length},
       'record': pin(actual), 'captured_source': pin(original), 'compressed_equal': actual == original,
       'parser': {'original_own_code': pin(helper_body), 'pure_declarations': sorted(allowed), 'prior_results_used': False},
       'historical_world_or_other_stopped_cohort_read': False, 'Java_native_launched': False}
(HERE / 'INTAKE-EXTRACTION-01.json').write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps({key: out[key] for key in ['manifest_rows', 'unchanged_other_inputs', 'record_allocation', 'record', 'compressed_equal']}, indent=2))
