"""Seal this existing audit scope only; no external writes or duplicate archive."""
import datetime
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
assert HERE == Path('D:/ARCE-Task-Evidence/v1.8.0/agla3-8073c3e4c2').resolve()
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
for name in ('intake', 'audit', 'log-formats', 'python', 'completion'):
    assert (HERE / (name+'.exit')).read_text().strip() == '0'
audit = json.loads((HERE / 'AUDIT-RESULT-03.json').read_text(encoding='utf-8'))
assert audit['native_result']['exit_code'] == 1
assert audit['log_measurements']['stdout.txt']['unload_literal_occurrences'] == 0
assert audit['command_counts']['total'] == 26 and audit['command_counts']['stop'] == 0
assert audit['decoded_record']['compressed_equal']
assert re.search(r'Ran 10 tests in \d+\.\d+s\s+OK\s*$', (HERE / 'python.log').read_text(encoding='utf-8-sig'))
intake = json.loads((HERE / 'INTAKE-EXTRACTION-01.json').read_text(encoding='utf-8'))
assert intake['record'] == pin((HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes())
assert intake['captured_source'] == pin((HERE / 'captured-source-chunk-11-11.nbt.zlib').read_bytes())
assert (HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes() == (HERE / 'captured-source-chunk-11-11.nbt.zlib').read_bytes()
excluded = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt'}
result = {'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': 0,
          'actual_native_disposition': 'FAIL', 'own_python_controls': 10, 'own_controls_failed': 0,
          'Java_native_or_cleanup_performed': False, 'C_temporary_outputs_created': False,
          'manifest_excludes_only': sorted(excluded)}
(HERE / 'SEAL-01.json').write_bytes((json.dumps(result, indent=2)+'\n').encode('utf-8'))
files = {}
for path in sorted(HERE.rglob('*')):
    if not path.is_file() or path.name in excluded:
        continue
    assert path.resolve().is_relative_to(HERE) and not path.is_symlink()
    files[path.relative_to(HERE).as_posix()] = pin(path.read_bytes())
total = sum(entry['bytes'] for entry in files.values())
assert len(files) < 100 and total < 2_000_000
report = (HERE / 'REPORT.md').read_text(encoding='utf-8')
links = re.findall(r'\]\(([^)]+)\)', report)
for link in links:
    assert (HERE / link).resolve().is_relative_to(HERE) and (HERE / link).is_file(), link
manifest = {'scope': 'native03 independent actual-result audit only', 'files': files,
            'entries': len(files), 'payload_bytes': total, 'report_local_links': len(links),
            'native_disposition': 'FAIL', 'Required_Gate_admitted': False}
body = (json.dumps(manifest, indent=2)+'\n').encode('utf-8')
assert not (HERE / 'INTERNAL-MANIFEST.json').exists()
(HERE / 'INTERNAL-MANIFEST.json').write_bytes(body)
manifest_hash = hashlib.sha256(body).hexdigest()
report_hash = hashlib.sha256((HERE / 'REPORT.md').read_bytes()).hexdigest()
(HERE / 'SHA256SUMS.txt').write_bytes((manifest_hash+'  INTERNAL-MANIFEST.json\n'+report_hash+'  REPORT.md\n').encode('ascii'))
for name, expected in files.items():
    assert pin((HERE / name).read_bytes()) == expected
print(json.dumps({'report_sha256': report_hash, 'manifest_sha256': manifest_hash,
                  'entries': len(files), 'payload_bytes': total, 'local_links': len(links),
                  'all_local_payloads_verified': True, 'native_disposition': 'FAIL', 'exit': 0}, indent=2))
