"""Bounded independent native03 parser/oracle controls; never starts a process."""
import json
import struct
import unittest
from pathlib import Path

import audit_native03 as audit
import native_reader as reader

HERE = Path(__file__).resolve().parent

class IndependentNative03Controls(unittest.TestCase):
    def test_false_loaded_console_say_is_not_real_unload_event(self):
        line = '[17:52:39] [Server thread/INFO] [minecraft/MinecraftServer]: [Not Secure] [Server] ARCE_GUARD_NOT_LOADED'
        self.assertIsNone(audit.UNLOAD.fullmatch(line))
        self.assertEqual(audit.markers([line])[0]['marker'], 'ARCE_GUARD_NOT_LOADED')

    def test_unload_event_rejects_fake_logger_severity_coordinate_or_embedded_line(self):
        line = '[17:52:39] [Server thread/INFO] [advancedrocketrycommunity/]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11'
        self.assertIsNotNone(audit.UNLOAD.fullmatch(line))
        for fake in (line.replace('/INFO]', '/ERROR]'), line.replace('11,11', '11,12'),
                     line.replace('advancedrocketrycommunity/', 'example/'), 'echo ' + line, line + ' suffix'):
            self.assertIsNone(audit.UNLOAD.fullmatch(fake))

    def test_spawn_success_not_console_echo_wrong_coordinates_or_logger(self):
        line = '[17:52:29] [Server thread/INFO] [minecraft/MinecraftServer]: Set the world spawn point to 256, 74, -256 [0.0]'
        self.assertIsNotNone(audit.SPAWN.fullmatch(line))
        for fake in (line.replace('-256', '-32'), line.replace('MinecraftServer', 'Other'),
                     line.replace('[0.0]', '[0]'), 'prefix ' + line):
            self.assertIsNone(audit.SPAWN.fullmatch(fake))

    def test_restoration_end_marker_is_not_restoration_observation(self):
        line = '[17:52:39] [Server thread/INFO] [minecraft/MinecraftServer]: [Server] ARCE_GUARD_REMOVAL_ROLLED_BACK_END'
        observed = audit.markers([line])
        self.assertEqual(observed[0]['marker'], 'ARCE_GUARD_REMOVAL_ROLLED_BACK_END')
        self.assertFalse(any(row['marker'] == 'ARCE_GUARD_REMOVAL_ROLLED_BACK' for row in observed))

    def test_changed_compressed_bytes_do_not_pass_retention(self):
        original = (HERE / 'captured-source-chunk-11-11.nbt.zlib').read_bytes()
        changed = bytearray(original)
        changed[-1] ^= 1
        with self.assertRaisesRegex(AssertionError, 'Compressed terrain record differs'):
            audit.roots(bytes(changed), original)

    def test_actual_four_typed_roots_and_AIR_are_post_abort_observations(self):
        original = (HERE / 'captured-source-chunk-11-11.nbt.zlib').read_bytes()
        measured = audit.roots((HERE / 'stopped-chunk-11-11.nbt.zlib').read_bytes(), original)
        self.assertEqual(measured['decoded_bounds'], {'expanded_bytes': 54066, 'nodes': 531, 'depth': 7})
        self.assertEqual(len(measured['roots']), 4)
        self.assertEqual(measured['saved_marker'], {'Name': 'minecraft:air'})
        self.assertTrue(measured['post_abort_observation_only'])
        self.assertEqual(measured['roots'][2]['extension_arrays']['part0']['native_type'], 7)

    def test_duplicate_native_compound_key_is_rejected(self):
        field = b'\x03\x00\x01a' + struct.pack('>i', 1)
        source = b'\x0a\x00\x00' + field + field + b'\x00'
        with self.assertRaises(AssertionError):
            reader.Reader(source).root()

    def test_ByteArray_and_IntArray_native_type_are_distinct(self):
        byte_array = reader.Reader(struct.pack('>i', 2) + b'\x00\x01').tag(7, 0)
        int_array = reader.Reader(struct.pack('>i', 2) + struct.pack('>ii', 0, 1)).tag(11, 0)
        self.assertEqual(byte_array[1], int_array[1])
        self.assertNotEqual(byte_array[0], int_array[0])

    def test_original_depth_and_node_ceilings_reject_overflow(self):
        nested = b'\x0a\x00\x00' + b'\x0a\x00\x01a' * 17 + b'\x00' * 18
        with self.assertRaises(AssertionError):
            reader.Reader(nested).root()
        members = b'\x01' + struct.pack('>i', 4096) + bytes(4096)
        with self.assertRaises(AssertionError):
            reader.Reader(members).tag(9, 0)

    def test_setup_success_and_saved_record_do_not_promote_actual_FAIL(self):
        result = json.loads((HERE / 'AUDIT-RESULT-03.json').read_text(encoding='utf-8'))
        self.assertEqual(result['native_result']['exit_code'], 1)
        self.assertEqual(result['log_measurements']['stdout.txt']['exact_spawn_success'], 1)
        self.assertTrue(result['decoded_record']['compressed_equal'])
        self.assertEqual(result['log_measurements']['stdout.txt']['unload_literal_occurrences'], 0)
        self.assertFalse(result['second_cycle_summary_or_clean_stop_executed'])
        self.assertTrue(result['disposition'].startswith('FAIL'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
