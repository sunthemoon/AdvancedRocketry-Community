"""Pure bounded parser functions reused from own immutable prior audit; no prior data/main."""
import hashlib
import struct
import zlib

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

class Reader:
    """Exact native tag types and bounded arrays; ASCII fixture string scope only."""

    def __init__(self, data):
        assert len(data) <= 1024 * 1024
        self.data = data
        self.offset = self.nodes = self.depth = 0

    def take(self, count):
        assert 0 <= count <= len(self.data) - self.offset
        body = self.data[self.offset:self.offset + count]
        self.offset += count
        return body

    def number(self, format):
        return struct.unpack(format, self.take(struct.calcsize(format)))[0]

    def string(self):
        size = self.number('>H')
        assert size <= 4096
        return self.take(size).decode('utf-8', errors='strict')

    def length(self):
        size = self.number('>i')
        assert 0 <= size <= 4096
        return size

    def tag(self, kind, depth):
        self.nodes += 1
        self.depth = max(self.depth, depth)
        assert self.nodes <= 4096 and depth <= 16
        formats = {1: '>b', 2: '>h', 3: '>i', 4: '>q', 5: '>f', 6: '>d'}
        if kind in formats:
            value = self.number(formats[kind])
        elif kind == 7:
            value = list(self.take(self.length()))
        elif kind == 8:
            value = self.string()
        elif kind == 9:
            child, count = (self.number('>B'), self.length())
            assert child != 0 or count == 0
            value = [self.tag(child, depth + 1) for _ in range(count)]
        elif kind == 10:
            value = {}
            while True:
                child = self.number('>B')
                if child == 0:
                    break
                name = self.string()
                assert name not in value
                value[name] = self.tag(child, depth + 1)
        elif kind in (11, 12):
            value = [self.number('>i' if kind == 11 else '>q') for _ in range(self.length())]
        else:
            raise AssertionError('Unsupported native tag kind')
        return (kind, value)

    def root(self):
        assert self.number('>B') == 10
        self.string()
        root = self.tag(10, 0)
        assert self.offset == len(self.data)
        return root

def plain(node):
    kind, value = node
    if kind == 10:
        return {name: plain(child) for name, child in value.items()}
    if kind == 9:
        return [plain(child) for child in value]
    return value

def unpack(compressed):
    assert len(compressed) <= 128 * 1024
    stream = zlib.decompressobj()
    body = stream.decompress(compressed, 1024 * 1024 + 1)
    assert len(body) <= 1024 * 1024 and stream.eof and (not stream.unused_data) and (not stream.unconsumed_tail)
    reader = Reader(body)
    typed = reader.root()
    value = plain(typed)
    assert (value['xPos'], value['zPos']) == (11, 11)
    return (typed, value, {'expanded_bytes': len(body), 'nodes': reader.nodes, 'depth': reader.depth})

def cell(chunk, position):
    x, y, z = position
    assert (x >> 4, z >> 4) == (11, 11)
    sections = [section for section in chunk['sections'] if section['Y'] == y >> 4]
    assert len(sections) == 1
    states = sections[0]['block_states']
    palette = states['palette']
    assert 1 <= len(palette) <= 4096
    if len(palette) == 1:
        assert not states.get('data')
        return palette[0]
    bits = max(4, (len(palette) - 1).bit_length())
    per_word = 64 // bits
    words = states['data']
    assert len(words) == (4096 + per_word - 1) // per_word
    local = y % 16 * 256 + z % 16 * 16 + x % 16
    word = words[local // per_word] & (1 << 64) - 1
    index = word >> local % per_word * bits & (1 << bits) - 1
    assert index < len(palette)
    return palette[index]
