"""Derive exact planned phase identities from the captured source, not guessed labels."""
import ast
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/native-03')
tree = ast.parse((HERE / 'source_inputs/run_v180_guard_lifecycle_smoke.py').read_bytes())
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
calls = [node for node in ast.walk(main) if isinstance(node, ast.Call)
         and isinstance(node.func, ast.Name) and node.func.id == 'native_cycle']
calls.sort(key=lambda node: node.lineno)
names = []
for call in calls:
    argument = call.args[1]
    assert isinstance(argument, ast.BinOp) and isinstance(argument.op, ast.Div)
    assert isinstance(argument.left, ast.Name) and argument.left.id == 'work'
    assert isinstance(argument.right, ast.Constant) and isinstance(argument.right.value, str)
    names.append(argument.right.value)
assert names == ['removal-availability-reload', 'restart-retrigger']
assert (BASE / names[0] / 'receipt.json').exists()
assert not (BASE / names[1]).exists()
assert not (BASE / 'summary.json').exists()
source = (HERE / 'raw_inputs/native-03.log').read_text(encoding='utf-8')
assert 'line 261, in main' in source and 'line 192, in native_cycle' in source
result = {'planned_phase_names_from_captured_source': names,
          'first_phase_receipt_present': True, 'actual_second_phase_directory_present': False,
          'summary_present': False, 'failure_trace_before_second_phase_call': True,
          'original_audit_absence_probe_qualification': 'The initial audit tested the unused guessed label retained-record-restart. That absence is not evidence for the intended second phase. This check uses the exact source-derived restart-retrigger label and the preserved traceback.'}
(HERE / 'COMPLETION-BOUNDARY-01.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
print(json.dumps(result, indent=2))
