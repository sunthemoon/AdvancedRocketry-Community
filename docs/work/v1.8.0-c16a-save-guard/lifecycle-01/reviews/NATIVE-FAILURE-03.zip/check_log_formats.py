"""Separate native file-log framing measurements; do not relabel stdout patterns."""
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PHASE = HERE / 'raw_inputs/native-03/removal-availability-reload'
PREFIX = r'^\[\d{2}[A-Za-z]{3}\d{4} \d{2}:\d{2}:\d{2}\.\d{3}\] \[Server thread/'
SPAWN = re.compile(PREFIX + r'INFO\] \[net\.minecraft\.server\.MinecraftServer/\]: '
                   r'Set the world spawn point to 256, 74, -256 \[0\.0\]$')
EVENT = re.compile(PREFIX + r'ERROR\] \[net\.minecraftforge\.eventbus\.EventBus/EVENTBUS\]: '
                   r'Exception caught during firing event: Refusing oversized tank chunk save; back up and repair first$')
CHUNK = re.compile(PREFIX + r'ERROR\] \[net\.minecraft\.server\.level\.ChunkMap/\]: Failed to save chunk 11,11$')
out = {}
for name in ('latest.log', 'debug.log'):
    lines = (PHASE / name).read_text(encoding='utf-8').splitlines()
    out[name] = {'exact_file_logger_spawn_success': sum(bool(SPAWN.fullmatch(line)) for line in lines),
                 'exact_file_logger_EventBus_headers': sum(bool(EVENT.fullmatch(line)) for line in lines),
                 'exact_file_logger_ChunkMap_headers': sum(bool(CHUNK.fullmatch(line)) for line in lines),
                 'unload_marker_literal_occurrences': sum('ARCE_GUARD_UNLOAD_BEGIN' in line for line in lines)}
    assert out[name]['exact_file_logger_spawn_success'] == 1
    assert out[name]['exact_file_logger_EventBus_headers'] == out[name]['exact_file_logger_ChunkMap_headers']
    assert out[name]['unload_marker_literal_occurrences'] == 0
out['qualification'] = 'The first audit applies stdout logger framing to all streams; its file-log exact counts of zero do not mean no errors or spawn response. This separate measurement uses actual file-log framing.'
target = HERE / 'NATIVE-LOG-FORMATS-01.json'
assert not target.exists()
target.write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps(out, indent=2))
