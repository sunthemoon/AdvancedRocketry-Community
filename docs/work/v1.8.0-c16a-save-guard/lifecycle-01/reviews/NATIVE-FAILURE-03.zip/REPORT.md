# Native03 guard lifecycle: independent actual-result audit

## Findings

1. **The fresh native03 cohort failed; setup success is not lifecycle success.**
   The actual Root command exited **1 after 88.4728555 seconds**. Its first
   phase receipt is `FAIL` at `wait_unload_begin`, and the traceback ends at
   the unchanged real unload-marker wait. Independent scans of this cohort's
   stdout, latest and debug logs find **zero literal unload-marker occurrences**.
   The actual strict copied-spawn success is present: stdout line 152, before
   its barrier at 153. This establishes a successful setup observation, not
   why the later real unload event/marker was absent.

2. **The early cuts succeeded, but restoration, stop and restart were not reached.**
   The 26 recorded commands include initial force-load, two loaded probes,
   one fixed spawn command, initial tank/AIR checks, stone mutation, two
   `save-all flush` operations, direct culprit removal/AIR check, force-load
   removal and two false-loaded probes. Stdout line 659 reports
   `ARCE_GUARD_NOT_LOADED`. There is no ticket reacquisition, live restoration
   marker, `stop` command, intended `restart-retrigger` phase or final summary.
   The two early save windows each contain **3 EventBus + 3 ChunkMap refusal
   headers**; the full logs each contain **7 + 7** under their actual logger
   framing. `Saved the game` does not prove this terrain chunk was written.

3. **Stopped terrain retention is observed independently, not a passing recovery test.**
   Fresh native03 region slot 363, sector 344, two allocated sectors yielded
   **5,898 compressed bytes**, SHA-256
   `d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8`.
   These bytes equal native03's own captured source record. Independent typed
   decoding measures **54,066 expanded bytes, 531 nodes and depth 7**. Four
   exact tank BE cells retain their native types and resources; the saved
   culprit is a tank and the saved marker is AIR. This is a post-failure/abort
   record observation, not live rollback, a clean stop, restart, whole-region
   equality, cross-store conservation or arbitrary-crash atomicity.

No unique ticket, observer registration, event-thread, logger or production
failure cause is assigned. The diagnostic remains failed and R-021 remains
open. No Gate or production lifecycle policy is admitted by this audit.

## Exact cohort and boundary

This audit is separate from native01/native02 and from the setup source review.
It uses the actual [native03 command/result](raw_inputs/native-03-result.json),
[first-phase receipt](raw_inputs/native-03/removal-availability-reload/receipt.json),
[commands](raw_inputs/native-03/removal-availability-reload/commands.json) and
[raw traceback](raw_inputs/native-03.log); no old successful result was borrowed.

[Manifest comparison](INTAKE-EXTRACTION-01.json) checks 2,995 safe-relative rows
in both snapshots. Source23 manifest SHA is
`bab73c802f4ae710d5e854a7ccd26417c5c0925a9421172da7b0b3d6288554e4`;
the separately bound Setup03 manifest SHA is
`9b98557a7c2e6d3bb9b6f7d7d667e74804d11cd09babb5614a2d0141cd80886d`.
Only two tool rows change; **2,993 others are byte-identical between manifests**.
The boundary names fixed commit `23bec1eb1452e8c8ef37c004606aaed3a2394063` and
explicitly reuses the existing Java build rather than claiming a new Gradle run.

| Captured input | SHA-256 |
| --- | --- |
| Script | `4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad` |
| Tests | `e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16` |
| Unchanged unload observer | `a426612fd9986b871d7930fa413b8ad0ade1e994d911c901c3f87e3b313fdd87` |

All three named postimages were independently captured and hashed against
Setup03. The previously frozen source review remains unchanged and is not
relabeled as a native pass. This audit does not depend on later live HEAD.

The actual main artifact and newly installed native03 host were independently
hashed as **5,443,263 bytes**, SHA
`5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9`.
The installed fixture is 96,772 bytes, SHA
`765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4`.
The actual sources and API artifacts also match their pins:
`4ab8254184549cef0ca0edbdb3d256ee8215ecf2470a7036b453baddfa8053a3`
and `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da`.

The main archive has exactly one unload-observer class; its Java member in
the sources archive equals the captured source. Launch enables the real
release-test property. This demonstrates installed/packaged identity, **not
observer callback registration or execution**.

## Fresh stopped-record measurements

Only the new stopped owned runtime's fixed region/chunk was read. No historical
world or other cohort world was walked. The [allocation and record pins](INTAKE-EXTRACTION-01.json)
and [typed resource measurements](AUDIT-RESULT-03.json) preserve:

| Position | Native root/resource observations |
| --- | --- |
| `(182,180,180)` | Int schema 1; Int amount 300,000 mB water (overflow root). |
| `(184,180,180)` | Int schema 1; Int amount 5,000 mB lava; native compound/String batch `native-retained`. |
| `(186,180,180)` | Int schema 2; Int amount 5,000 mB water; two **TAG_Byte_Array** extensions, each 4,096 zero elements. |
| `(188,180,180)` | Int schema 1; Int amount -1 mB water (corrupt root preserved, not normalized). |

The exact BE IDs and palette cells are `advancedrocketrycommunity:pressurized_tank`.
The marker `(190,180,180)` and reference cell `(180,180,180)` are saved AIR.
The independently authored reader preserves native tag distinctions, rejects
duplicate keys, and retains the 4,096-node/depth-16 bounds. Its string scope is
this ASCII fixture, not a general modified-UTF/native-emission protocol claim.
Only its pure parser/cell declarations were reused; no prior cohort data,
main function or result was executed.

## Preservation attribution and actual commands

Root's precheck records 2,995 checked inputs, unchanged Java/build identity,
and C/D free space above the 10,000,000,000-byte threshold. Root/harness postchecks
assert Setup03 source/library equality, original world equality and artifact
equality. The captured inventories contain 139 safe-relative world rows and
104 library rows. Those full input-preservation assertions are **attributed to
the actual Root/harness checks**, not an independent rewalk by this auditor.
Independent recomputation covers the named three source files, three artifact
files, installed host/fixture and this cohort's source/stopped compressed record.

| Independent command | Actual result |
| --- | --- |
| `python -B intake_extract.py` | Exit 0; named input captures, two-tool manifest delta and one fixed record extraction. |
| `python -B audit_native03.py` | Exit 0; fresh command/log/resource/JAR observations. Native outcome remains FAIL. |
| `python -B check_log_formats.py` | Exit 0; actual file-log framing confirms one spawn response and 7 + 7 error headers in each file log. |
| `python -B test_independent_controls.py` | Exit 0; **10 tests, 0 failures/errors/skips**. |
| `python -B verify_completion_boundary.py` | Exit 0; exact source-derived second-phase name and pre-second-call failure verified. |

Root's distinct preceding Python regression is actually 114 tests/exit 0;
this is read from its fresh raw log/receipt, not this auditor's own 10-test count.
No Java/native/Gradle/server/client/process cleanup was launched by the auditor.

Two audit qualifications are preserved rather than hidden. The first measurement
applies stdout logger framing to all streams; its exact file-log counts of zero
are not absence of errors/spawn response. [The separate file-log measurement](NATIVE-LOG-FORMATS-01.json)
uses actual long timestamp/logger names. The first absence probe tested an
unused guessed second-phase label; [the source-derived completion check](COMPLETION-BOUNDARY-01.json)
verifies the actual `restart-retrigger` label and preserved traceback. Neither
qualification changes the underlying failed native result or its source.

## Remaining scope and evidence

Unload/provider transition, actual disposal, ticket reacquisition, restored
live roots/AIR, clean stop, restart retrigger, earliest-load/first-save defense,
GuardTicket/lifecycle eligibility, charged drops/placement, cross-store
durability, natural-crash behavior, real-client and Required Gates are unproven.
Direct console `setblock` is not ordinary player-removal or charged conservation
evidence. Further causal work requires new source-backed checks and separately
bound observations, not replacement of this failed cohort.

[Audit result](AUDIT-RESULT-03.json), [intake](INTAKE-EXTRACTION-01.json),
[raw marker ordering](observed-markers.txt), [audit command/log](audit-command.json),
[audit raw output](audit.log), [independent test command](python-command.json),
[test raw output](python.log) and all named raw receipts/logs are included.
This is a small loose bundle; no whole tree, JAR, world, region or ZIP is exported.
No Root/source/old sealed evidence was modified or deleted. This task created
no C-drive temporary scripts/directories; future fresh outputs follow the
new `D:/GitHub/ARCE-Task-Evidence` direction. The existing audit location is
retained solely to preserve its already-started intake and seal consistently.
