"""Independent archived native03 observations; no process/world/source mutation."""
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

import native_reader as reader

HERE = Path(__file__).resolve().parent
RAW = HERE / 'raw_inputs'
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
PHASE = RAW / 'native-03/removal-availability-reload'
PREFIX = r'^(?:\[\d{2}:\d{2}:\d{2}\] )?\[Server thread/INFO\] '
SAY = re.compile(PREFIX + r'\[minecraft/MinecraftServer\]: (?:\[Not Secure\] )?\[Server\] (\S+)\s*$')
SPAWN = re.compile(PREFIX + r'\[minecraft/MinecraftServer\]: Set the world spawn point to 256, 74, -256 \[0\.0\]\s*$')
UNLOAD = re.compile(PREFIX + r'\[advancedrocketrycommunity/\]: ARCE_GUARD_UNLOAD_BEGIN chunk=11,11\s*$')
EVENT = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[ne\.mi\.ev\.EventBus/EVENTBUS\]: Exception caught during firing event: '
                   r'Refusing oversized tank chunk save; back up and repair first$')
CHUNK = re.compile(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/ERROR\] '
                   r'\[minecraft/ChunkMap\]: Failed to save chunk 11,11$')
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def markers(lines):
    return [{'line': index + 1, 'marker': match.group(1), 'text': line}
            for index, line in enumerate(lines) if (match := SAY.fullmatch(line))]

def roots(record, expected):
    assert record == expected, 'Compressed terrain record differs'
    typed, chunk, limits = reader.unpack(record)
    assert reader.cell(chunk, (180, 180, 180)) == {'Name': 'minecraft:air'}
    assert reader.cell(chunk, (190, 180, 180)) == {'Name': 'minecraft:air'}
    entities = typed[1]['block_entities']
    assert entities[0] == 9 and len(entities[1]) == 4
    out = []
    for index, entity in enumerate(sorted(entities[1], key=lambda node: reader.plain(node)['x']), 1):
        plain = reader.plain(entity)
        pos = (180 + index * 2, 180, 180)
        assert tuple(plain[key] for key in ('x', 'y', 'z')) == pos
        assert plain['id'] == 'advancedrocketrycommunity:pressurized_tank'
        assert reader.cell(chunk, pos) == {'Name': 'advancedrocketrycommunity:pressurized_tank'}
        root = entity[1]['arce_pressurized_tank']
        assert root[0] == 10 and root[1]['schema'] == (3, 2 if index == 3 else 1)
        fluid = root[1]['fluid']
        assert fluid[0] == 10
        assert fluid[1]['Amount'] == (3, {1: 300000, 2: 5000, 3: 5000, 4: -1}[index])
        assert fluid[1]['FluidName'] == (8, 'minecraft:lava' if index == 2 else 'minecraft:water')
        if index == 2:
            assert fluid[1]['Tag'] == (10, {'batch': (8, 'native-retained')})
        arrays = {}
        if index == 3:
            extension = root[1]['extension']
            assert extension[0] == 10
            for name in ('part0', 'part1'):
                kind, values = extension[1][name]
                assert kind == 7 and len(values) == 4096 and set(values) == {0}
                arrays[name] = {'native_type': kind, 'elements': len(values), 'all_zero': True}
        out.append({'position': pos, 'schema_native_type': 3,
                    'schema': root[1]['schema'][1], 'fluid': reader.plain(fluid), 'extension_arrays': arrays})
    return {'decoded_bounds': limits, 'roots': out, 'saved_culprit': reader.cell(chunk, (186, 180, 180)),
            'saved_marker': reader.cell(chunk, (190, 180, 180)), 'compressed_equal': True,
            'post_abort_observation_only': True}

def main():
    inputs = {}
    def read(path):
        body = path.read_bytes()
        inputs[str(path)] = pin(body)
        return body
    def document(path):
        return json.loads(read(path))
    receipts = {name: document(RAW / name) for name in (
        'native-03-command.json', 'native-03-result.json', 'NATIVE-PRECHECK-03.json',
        'NATIVE-POSTCHECK-03.json', 'SETUP03-BOUNDARY-01.json', 'ARTIFACTS23-01.json',
        'LIBRARIES-INPUTS-01.json', 'native-03/inputs.json', 'native-03/input-postcheck.json',
        'native-03/source-world-files.json', 'native-03/removal-availability-reload/receipt.json',
        'native-03/removal-availability-reload/commands.json', 'native-03/removal-availability-reload/launch.json',
        'python-regression-08-command.json', 'python-regression-08-result.json')}
    read(RAW / 'native-03.log')
    root_result = receipts['native-03-result.json']
    phase_result = receipts['native-03/removal-availability-reload/receipt.json']
    assert root_result['exit_code'] == 1 and phase_result['result'] == 'FAIL'
    assert 'Timed out waiting for server marker' in phase_result['error']
    assert 'ARCE_GUARD_UNLOAD_BEGIN' in phase_result['error']
    assert 'unload_begin_line' not in phase_result and 'record' not in phase_result
    assert root_result['command'] == receipts['native-03-command.json']['command']
    assert receipts['python-regression-08-result.json']['exit_code'] == 0
    regression = read(RAW / 'python-regression-08.log').decode('utf-8')
    assert re.search(r'Ran 114 tests in \d+\.\d+s\s+OK\s*$', regression)
    logs = {name: read(PHASE / name).decode('utf-8').splitlines() for name in ('stdout.txt', 'latest.log', 'debug.log')}
    log_measures = {}
    for name, lines in logs.items():
        log_measures[name] = {
            'lines': len(lines), 'exact_spawn_success': sum(bool(SPAWN.fullmatch(line)) for line in lines),
            'unload_literal_occurrences': sum('ARCE_GUARD_UNLOAD_BEGIN' in line for line in lines),
            'unload_exact_INFO_markers': sum(bool(UNLOAD.fullmatch(line)) for line in lines),
            'event_bus_refusal_headers': sum(bool(EVENT.fullmatch(line)) for line in lines),
            'chunk_map_refusal_headers': sum(bool(CHUNK.fullmatch(line)) for line in lines),
            'stopping_server_literal_occurrences': sum('Stopping server' in line for line in lines)}
        assert log_measures[name]['unload_literal_occurrences'] == 0
        assert log_measures[name]['unload_exact_INFO_markers'] == 0
    lines = logs['stdout.txt']
    observed = markers(lines)
    def single(marker):
        hits = [row for row in observed if row['marker'] == marker]
        assert len(hits) == 1, marker
        return hits[0]
    loaded = single('ARCE_GUARD_LOADED')
    setup = [dict(line=index+1, text=line) for index, line in enumerate(lines) if SPAWN.fullmatch(line)]
    assert len(setup) == 1 and phase_result['copy_spawn_setup'] == setup[0]['text']
    sequence = [loaded, setup[0], single('ARCE_GUARD_COPY_SPAWN_END'),
                single('ARCE_GUARD_ROOT_RELOADED'), single('ARCE_GUARD_MARKER_ABSENT'),
                single('ARCE_GUARD_MARKER_MUTATED'), single('initial_refusal_END'),
                single('ARCE_GUARD_ROOT_REMOVED'), single('after_removal_refusal_END'),
                single('ARCE_GUARD_NOT_LOADED')]
    assert [row['line'] for row in sequence] == sorted(row['line'] for row in sequence)
    for forbidden in ('ARCE_GUARD_REMOVAL_ROLLED_BACK', 'ARCE_GUARD_MUTATION_ROLLED_BACK'):
        assert not any(row['marker'] == forbidden or row['marker'] == forbidden+'_END' for row in observed)
    cuts = {}
    for label, start_marker in (('initial_refusal', 'ARCE_GUARD_MARKER_MUTATED_END'),
                                ('after_removal_refusal', 'ARCE_GUARD_ROOT_REMOVED_END')):
        first, last = single(start_marker)['line'], single(label+'_END')['line']
        window = lines[first:last-1]
        cut = {'start_line_exclusive': first, 'end_line_exclusive': last,
               'event_bus_error_headers': sum(bool(EVENT.fullmatch(line)) for line in window),
               'chunk_map_error_headers': sum(bool(CHUNK.fullmatch(line)) for line in window)}
        assert cut['event_bus_error_headers'] == phase_result[label]['event_bus_error_headers']
        assert cut['chunk_map_error_headers'] == phase_result[label]['chunk_map_error_headers']
        cuts[label] = cut
    commands = receipts['native-03/removal-availability-reload/commands.json']
    assert commands[0] == 'forceload add 176 176'
    assert commands.count('forceload add 176 176') == 1
    assert commands.count('forceload remove 176 176') == 1
    assert commands.count('setworldspawn 256 74 -256 0') == 1
    assert commands.count('save-all flush') == 2 and 'stop' not in commands
    assert commands[-2:] == ['execute unless loaded 180 180 180 run say ARCE_GUARD_NOT_LOADED',
                              'say ARCE_GUARD_PROBE_END_1']
    command_counts = {'total': len(commands), 'forced_add': 1, 'forced_remove': 1, 'spawn_setup': 1,
                      'save_all_flush': 2, 'stop': 0,
                      'loaded_true_probes': sum(command.startswith('execute if loaded') for command in commands),
                      'loaded_false_probes': sum(command.startswith('execute unless loaded') for command in commands)}
    assert not (BASE / 'native-03/retained-record-restart').exists()
    assert not (BASE / 'native-03/summary.json').exists()
    record = read(HERE / 'stopped-chunk-11-11.nbt.zlib')
    original = read(HERE / 'captured-source-chunk-11-11.nbt.zlib')
    decoded = roots(record, original)
    artifacts = {}
    for entry in receipts['ARTIFACTS23-01.json']:
        actual = pin(read(Path(entry['path'])))
        assert actual == {key: entry[key] for key in ('bytes', 'sha256')}
        artifacts[Path(entry['path']).name] = actual
    native_inputs = receipts['native-03/inputs.json']
    installed = {}
    for key in ('host', 'fixture'):
        entry = native_inputs[key]
        expected = {field: entry[field] for field in ('bytes', 'sha256')}
        assert pin(read(Path(entry['path']))) == expected
        path = BASE / 'native-03/server/mods' / entry['name']
        actual = pin(read(path))
        assert actual == expected
        installed[key] = {'installed_path': str(path), **actual}
    assert installed['host']['sha256'] == '5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9'
    observer_name = 'io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation'
    main = Path(native_inputs['host']['path'])
    with zipfile.ZipFile(main) as jar:
        names = [entry.filename for entry in jar.infolist() if entry.filename == observer_name+'.class']
        assert len(names) == 1
        observer_class = pin(jar.read(names[0]))
    source_entry = next(entry for entry in receipts['ARTIFACTS23-01.json'] if entry['path'].endswith('-sources.jar'))
    own_observer = read(HERE / 'source_inputs/GuardedChunkUnloadObservation.java')
    with zipfile.ZipFile(source_entry['path']) as jar:
        names = [entry.filename for entry in jar.infolist() if entry.filename == observer_name+'.java']
        assert len(names) == 1 and jar.read(names[0]) == own_observer
    launch = receipts['native-03/removal-availability-reload/launch.json']
    assert '-Dadvancedrocketrycommunity.releaseTestHooks=true' in launch['command']
    worlds = receipts['native-03/source-world-files.json']
    libraries = receipts['LIBRARIES-INPUTS-01.json']
    for name in [entry['path'] for entry in worlds] + list(libraries):
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
    assert receipts['native-03/input-postcheck.json'] == {'artifacts_unchanged': True, 'world_unchanged': True}
    assert receipts['NATIVE-POSTCHECK-03.json'] == {'setup03_inputs_unchanged': True, 'source_libraries_unchanged': True}
    result = {'input_pins': inputs, 'native_result': root_result,
              'disposition': 'FAIL; fresh setup success does not establish unload/restoration',
              'command_counts': command_counts, 'ordered_observations': sequence, 'save_windows': cuts,
              'log_measurements': log_measures, 'decoded_record': decoded,
              'installed_artifacts': installed, 'three_artifacts': artifacts,
              'observer': {'class_pin': observer_class, 'source_pin': pin(own_observer),
                           'release_property_enabled': True, 'callback_execution_proved': False},
              'postcheck_attribution': {'historical_world_inventory_rows': len(worlds),
                                      'library_inventory_rows': len(libraries),
                                      'full_historical_world_or_libraries_rewalked': False,
                                      'Root_harness_postchecks_asserted': True},
              'second_cycle_summary_or_clean_stop_executed': False,
              'independent_native_replay_or_Gate_admission': False}
    (HERE / 'AUDIT-RESULT-03.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    texts = [f"{row['line']}: {row.get('marker', 'spawn_success')}: {row['text']}" for row in sequence]
    (HERE / 'observed-markers.txt').write_bytes(('\n'.join(texts)+'\n').encode('utf-8'))
    print(json.dumps({key: result[key] for key in ('disposition', 'command_counts', 'save_windows', 'log_measurements')}, indent=2))
    print(json.dumps({'typed_bounds': decoded['decoded_bounds'], 'roots': len(decoded['roots']),
                      'source_equal': True, 'full_world_inventory_rows': len(worlds),
                      'library_rows': len(libraries), 'independent_runtime': False}, indent=2))

if __name__ == '__main__':
    main()
