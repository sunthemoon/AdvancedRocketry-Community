"""Separately bound copy-only spawn setup; reuse exact unchanged Java artifact."""
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
SERVER = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41/tank-native-06/server')
JAR = OUT / 'artifacts23-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'
fixture = SERVER / 'mods/arce-adapter-compat-test-1.0.0.jar'
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def write(name,value):
    path=OUT/name; assert not path.exists(),name
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')

old=json.loads((OUT/'SOURCE23-MANIFEST-01.json').read_text(encoding='utf-8'))
replacements={
    'scripts/run_v180_guard_lifecycle_smoke.py': '4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad',
    'tests/test_run_v180_guard_lifecycle_smoke.py': 'e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16',
}
inputs=dict(old)
changed=[]
for name,row in old.items():
    path=ROOT/name
    new={'bytes':path.stat().st_size,'sha256':digest(path)}
    if new!=row:
        changed.append(name)
        assert name in replacements and new['sha256']==replacements[name],name
        inputs[name]=new
assert set(changed)==set(replacements),changed
write('SETUP03-MANIFEST-01.json',inputs)
write('SETUP03-BOUNDARY-01.json',{'source_commit':'23bec1eb1452e8c8ef37c004606aaed3a2394063',
    'previous_snapshot':'SOURCE23-MANIFEST-01.json','tool_only_changes':changed,
    'unchanged_other_inputs':len(old)-len(changed),'Java_build':'Exact Source23 artifact; not a new Gradle execution'})
assert digest(JAR)=='5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9'
assert digest(fixture)=='765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'
libraries=json.loads((OUT/'LIBRARIES-INPUTS-01.json').read_text(encoding='utf-8'))
for name,row in libraries.items():
    path=SERVER/'libraries'/name
    assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],name
sys.path.insert(0,str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard
record=guard.saved_record(SERVER/'world')
assert len(record)==5898 and hashlib.sha256(record).hexdigest()=='d9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
guard.check_fixture(guard.regions._decode_chunk(record,*guard.CHUNK))
free={drive:shutil.disk_usage(drive+':/').free for drive in ('C','D')}
write('NATIVE-PRECHECK-03.json',{'inputs_checked':len(inputs),'free_bytes':free,
    'threshold_bytes':10000000000,'main_jar_sha256':digest(JAR),'source23_unchanged_inputs':len(old)-len(changed)})
assert all(value>=10000000000 for value in free.values())
jobs=[('python-regression-08',[sys.executable,'-B','-m','unittest',
    'tests.test_run_v180_guard_lifecycle_smoke','tests.test_run_v180_pump_smoke',
    'tests.test_run_v180_tank_smoke','tests.test_run_v180_signature_smoke','-v']),
    ('native-03',[sys.executable,'-B','scripts/run_v180_guard_lifecycle_smoke.py',
    '--runtime-template',str(SERVER),'--source-world',str(SERVER/'world'),
    '--host-jar',str(JAR),'--fixture-jar',str(fixture),'--work-root',str(OUT/'native-03'),
    '--java','C:/Program Files/Java/jdk-17.0.7/bin/java.exe'])]
rows=[]
for name,command in jobs:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(name+'-command.json',{'command':command,'cwd':str(ROOT),'started_utc':started})
    start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    row={'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,
         'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(name+'-result.json',row); rows.append(row)
    print(json.dumps(row),flush=True)
    if result.returncode:
        break
post={'setup03_inputs_unchanged':all((ROOT/name).stat().st_size==row['bytes'] and digest(ROOT/name)==row['sha256'] for name,row in inputs.items()),
      'source_libraries_unchanged':all((SERVER/'libraries'/name).stat().st_size==row['bytes'] and digest(SERVER/'libraries'/name)==row['sha256'] for name,row in libraries.items())}
write('NATIVE-POSTCHECK-03.json',post)
assert all(post.values()),post
print((OUT/(jobs[len(rows)-1][0]+'.log')).read_text(encoding='utf-8'),flush=True)
sys.exit(rows[-1]['exit_code'])
