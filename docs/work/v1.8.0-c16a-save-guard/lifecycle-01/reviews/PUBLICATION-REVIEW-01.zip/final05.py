import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import posixpath
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = ROOT / 'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

result = {'input_pins': {}, 'index_mismatches': [], 'checksum_mismatches': [], 'internal_links': [], 'doc_drift': []}
for name in ('INDEX.md', 'SOURCE-NATIVE-PACKETS-01.json', 'SHA256SUMS.txt'):
    result['input_pins'][name] = pin(BASE / name)
manifest = json.loads((BASE / 'SOURCE-NATIVE-PACKETS-01.json').read_text(encoding='utf-8'))
for name, declared in manifest['files'].items():
    observed = pin(BASE / name)
    if observed != declared:
        result['index_mismatches'].append({'path': name, 'declared': declared, 'actual': observed})
result['indexed_packets'] = len(manifest['files'])
result['total_bytes_actual'] = sum((BASE / n).stat().st_size for n in manifest['files'])
result['declared_total'] = manifest['total_bytes']
result['size_ceiling_files'] = all((BASE / n).stat().st_size < 50_000_000 for n in manifest['files'])
result['size_ceiling_slice'] = result['total_bytes_actual'] < 100_000_000
for line in (BASE / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    expected, name = line.split('  ', 1)
    actual = sha((BASE / name).read_bytes())
    if actual != expected:
        result['checksum_mismatches'].append({'path': name, 'expected': expected, 'actual': actual})

for path in sorted(BASE.rglob('*.zip')):
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        for member in sorted(n for n in names if n.endswith('.md')):
            text = archive.read(member).decode('utf-8-sig')
            for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', text):
                target = match.group(1).split('#')[0]
                if not target or re.match(r'^(https?:|mailto:|[A-Za-z]:)', target):
                    continue
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(member), target))
                result['internal_links'].append({'packet': path.relative_to(BASE).as_posix(), 'member': member,
                    'line': text[:match.start()].count('\n') + 1, 'target': target,
                    'resolved_member': resolved, 'contained': resolved in names})

asset = ROOT / 'docs/work/v1.8.0-asset-plan.csv'
data = asset.read_bytes()
result['input_pins'][str(asset)] = pin(asset)
rows = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
result['asset_handling_counts'] = dict(collections.Counter(r['handling'] for r in rows))
first = json.loads((HERE / 'INPUTS-01.json').read_text(encoding='utf-8'))
latest = json.loads((HERE / 'INPUTS-04.json').read_text(encoding='utf-8'))
for name in first.keys() & latest.keys():
    if first[name]['sha256'] != latest[name]['sha256']:
        result['doc_drift'].append({'path': name, 'first': first[name]['sha256'], 'final_intake': latest[name]['sha256']})
result['reviewed_docs_after_intake_unchanged'] = {}
for name in latest:
    if name.startswith('docs/'):
        result['reviewed_docs_after_intake_unchanged'][name] = pin(ROOT / name)['sha256'] == latest[name]['sha256']

result['native_record_bytes'] = []
for number in ('01', '02', '03'):
    path = BASE / 'reviews' / f'NATIVE-FAILURE-{number}.zip'
    with zipfile.ZipFile(path) as archive:
        entries = [n for n in archive.namelist() if n.endswith('chunk-11-11.nbt.zlib')]
        identities = [{'name': n, 'bytes': len(archive.read(n)), 'sha256': sha(archive.read(n))} for n in entries]
        result['native_record_bytes'].append({'packet': path.name, 'entries': identities})

with zipfile.ZipFile(BASE / 'C-CLEANUP-DISPOSITION-01.zip') as archive:
    rows = json.loads(archive.read('C-SCRIPT-PRECHECK-01.json'))
    result['cleanup_precheck'] = {'file_count': len(rows), 'bytes': sum(r['bytes'] for r in rows),
                                'parents': sorted({str(Path(r['source']).parent) for r in rows}),
                                'only_recorded_precheck_not_deletion': True}

(HERE / 'FINAL-CONTROLS-05.json').write_text(json.dumps(result, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'packets': result['indexed_packets'], 'total': result['total_bytes_actual'],
    'index_mismatches': len(result['index_mismatches']), 'checksum_mismatches': len(result['checksum_mismatches']),
    'missing_internal_links': [x for x in result['internal_links'] if not x['contained']],
    'asset_REVIEW': result['asset_handling_counts'].get('REVIEW'),
    'reviewed_docs_unchanged': all(result['reviewed_docs_after_intake_unchanged'].values())}, indent=2))
raise SystemExit(1 if result['index_mismatches'] or result['checksum_mismatches'] else 0)
