# Withdrawn exploratory rendering observation

During a bounded `python -B -c` ZIP/member read, PowerShell-mediated stdout
displayed the Chinese owner quotation as replacement glyphs. This reviewer
sent a tentative Low receipt observation before verifying the bytes.

A separate UTF-8 byte/codepoint read then reported zero `ef bf bd` sequences
and zero U+FFFD characters. ASCII-escaped output independently identified the
actual readable Chinese code units in line 7. The issue was output rendering,
not corruption in the original ZIP/member. The tentative finding was expressly
withdrawn in a follow-up message to Root. No Root packet or report was modified.

Both commands completed with exit 0; the first visual observation was not a
failing packet-integrity result. No corrected owner receipt is required on this
basis. The exact escaped bytes are recorded separately in
[cleanup-quote-control-01.json](cleanup-quote-control-01.json).
