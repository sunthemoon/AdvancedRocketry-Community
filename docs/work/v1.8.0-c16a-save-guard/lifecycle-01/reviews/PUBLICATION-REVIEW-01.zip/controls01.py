import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
EXTERNAL = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')

def sha(value):
    return hashlib.sha256(value).hexdigest()

checks = {}
input_pins = {}
failures = []
packet = ROOT / 'docs/work/v1.8.0-c16a-save-guard/lifecycle-01/ROOT-SOURCE23-COMPACT-01.zip'
with zipfile.ZipFile(packet) as archive:
    xml_names = [n for n in archive.namelist() if n.startswith('junit23-01/TEST-') and n.endswith('.xml')]
    totals = collections.Counter()
    actual_cases = 0
    for name in xml_names:
        root = ET.fromstring(archive.read(name))
        totals.update({key: int(root.attrib.get(key, 0)) for key in ('tests', 'failures', 'errors', 'skipped')})
        actual_cases += len(root.findall('testcase'))
    checks['compact_XML'] = {'files': len(xml_names), 'declared': dict(totals), 'actual_cases': actual_cases}
    gt = {}
    for name in ('gametest23-01.log', 'gametest23-native-02.log'):
        text = archive.read(name).decode('utf-8')
        gt[name] = {'completion_464': '464 GAME TESTS COMPLETE' in text,
                    'all_required_pass': 'All 464 required tests passed' in text,
                    'ERROR_headers': sum('/ERROR]' in line for line in text.splitlines()),
                    'FATAL_headers': sum('/FATAL]' in line for line in text.splitlines())}
    checks['compact_GT_logs'] = gt
checks['compact_sha256'] = sha(packet.read_bytes())

ledger = ROOT / 'docs/work/v1.8.0-content-ledger.csv'
data = ledger.read_bytes()
input_pins[str(ledger)] = {'bytes': len(data), 'sha256': sha(data)}
rows = list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
checks['actual_ledger_dispositions'] = dict(collections.Counter(row['disposition'] for row in rows))

for number in ('02', '03'):
    receipt_path = EXTERNAL / f'SOURCE-COMMIT-PUSH-{number}.json'
    data = receipt_path.read_bytes()
    input_pins[str(receipt_path)] = {'bytes': len(data), 'sha256': sha(data)}
    receipt = json.loads(data)
    details = []
    for name, expected in receipt['scope'].items():
        proc = subprocess.run(['git', '-C', str(ROOT), 'show', receipt['commit'] + ':' + name], capture_output=True)
        observed = sha(proc.stdout)
        details.append({'path': name, 'expected': expected, 'actual': observed, 'exit': proc.returncode})
        if proc.returncode or observed != expected:
            failures.append('committed postimage ' + name)
    logs = []
    for command in receipt['commands']:
        log_path = EXTERNAL / command['log']
        observed = sha(log_path.read_bytes())
        logs.append({'path': str(log_path), 'expected': command['log_sha256'], 'actual': observed,
                     'recorded_exit': command['exit']})
        if observed != command['log_sha256']:
            failures.append('commit/push raw log ' + str(log_path))
    checks['source_commit_push_' + number] = {'commit': receipt['commit'], 'postimages': details, 'logs': logs,
                                            'tracking_receipt': receipt['origin_tracking']}

checks['environment_scope'] = 'only bounded Python / Git read subprocesses; no Java/native, deletion, network or repository writes'
(HERE / 'CONTROLS-01.json').write_text(json.dumps({'checks': checks, 'inputs': input_pins, 'failures': failures}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'XML': checks['compact_XML'], 'GT': checks['compact_GT_logs'],
                  'ledger': checks['actual_ledger_dispositions'], 'failures': failures}, indent=2))
raise SystemExit(1 if failures else 0)
