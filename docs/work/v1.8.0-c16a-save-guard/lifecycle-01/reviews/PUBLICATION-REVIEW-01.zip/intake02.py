from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'intake01.py').read_text(encoding='utf-8')
for before, after in (
    ('doc-snapshots-01', 'doc-snapshots-02'),
    ('INPUTS-01.json', 'INPUTS-02.json'),
    ('LINKS-01.json', 'LINKS-02.json'),
    ('PACKETS-01.json', 'PACKETS-02.json'),
    ('OBSERVATIONS-01.json', 'OBSERVATIONS-02.json'),
):
    source = source.replace(before, after)
exec(compile(source, str(here / 'intake01.py'), 'exec'))
