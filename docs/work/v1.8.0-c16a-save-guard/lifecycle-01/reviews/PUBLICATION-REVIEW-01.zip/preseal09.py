import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
identities = json.loads((HERE / 'CORRECTION-07.json').read_text(encoding='utf-8'))['docs']
links = []
doc_errors = []
for name, declared in identities.items():
    path = ROOT / name
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != declared['sha256']:
        doc_errors.append(name)
    text = data.decode('utf-8-sig')
    if name.endswith('implementation-log.md'):
        text = text.split('### Source22 K3')[0]
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', text):
        target = match.group(1).split('#')[0]
        if not target or re.match(r'^(https?:|mailto:)', target):
            continue
        links.append({'document': name, 'line': text[:match.start()].count('\n') + 1,
                      'target': target, 'exists': (path.parent / target).exists()})
proc = subprocess.run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], capture_output=True, text=True)
result = {'docs': identities, 'postimage_mismatches': doc_errors, 'scoped_links': links,
          'missing_links': [x for x in links if not x['exists']],
          'HEAD': proc.stdout.strip(), 'HEAD_read_exit': proc.returncode,
          'no_Root_source_or_evidence_changes_by_reviewer': True,
          'new_C_paths_this_review': [], 'no_deletion': True}
(HERE / 'FINAL-INPUT-INTEGRITY-09.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'docs': len(identities), 'links': len(links), 'missing': len(result['missing_links']),
                 'doc_mismatches': doc_errors, 'HEAD': result['HEAD']}))
raise SystemExit(1 if doc_errors or result['missing_links'] or proc.returncode else 0)
