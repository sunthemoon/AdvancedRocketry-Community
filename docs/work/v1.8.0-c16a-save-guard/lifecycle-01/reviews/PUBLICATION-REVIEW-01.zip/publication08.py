from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'publication06.py').read_text(encoding='utf-8')
for name in ('PUBLICATION-CHECKS', 'MARKDOWN-LINKS', 'SETUP03-FINAL-POSTCHECK'):
    source = source.replace(name + '-01.json', name + '-02.json')
source = source.replace("scoped_inputs = json.loads((HERE / 'INPUTS-04.json').read_text(encoding='utf-8'))",
                        "scoped_inputs = json.loads((HERE / 'CORRECTION-07.json').read_text(encoding='utf-8'))['docs']")
source = source.replace("    if 'snapshot' not in identity:\n        continue\n", '')
source = source.replace('PUBLICATION-RECEIPTS-06.json', 'PUBLICATION-RECEIPTS-08.json')
exec(compile(source, str(here / 'publication06.py'), 'exec'))
