import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
EXTERNAL = Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
DOCS = [
    'docs/status/CURRENT_VERSION.md',
    'docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',
    'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-VERIFICATION-01.md',
    'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md',
]
GOVERNANCE = [
    'AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md',
    'docs/01-PORTING-PRINCIPLES.md', 'docs/04-VERSION-ROADMAP.md',
    'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

def write(name, data):
    target = HERE / name
    if target.exists():
        raise FileExistsError(target)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

snapshot = HERE / 'doc-snapshots-01'
snapshot.mkdir()
inputs = {}
links = []
for name in DOCS + GOVERNANCE:
    path = ROOT / name
    data = path.read_bytes()
    inputs[name] = {'absolute_path': str(path), **pin(path)}
    if name not in DOCS:
        continue
    text = data.decode('utf-8-sig')
    if name.endswith('implementation-log.md'):
        # Preserve only the current checkpoint, not the very large history.
        lines = text.splitlines(keepends=True)
        end = next(i for i, line in enumerate(lines) if line.startswith('### Source22 K3'))
        saved = ''.join(lines[:end]).encode('utf-8')
        scope = f'lines 1-{end}'
    else:
        saved = data
        scope = 'entire individually scoped text'
    out = snapshot / Path(name).name
    out.write_bytes(saved)
    inputs[name]['snapshot'] = str(out.relative_to(HERE))
    inputs[name]['snapshot_scope'] = scope
    saved_text = saved.decode('utf-8-sig')
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', saved_text):
        target = match.group(1).split('#')[0]
        if not target or re.match(r'^(https?:|mailto:)', target):
            continue
        resolved = path.parent / target
        links.append({'document': name, 'line': saved_text[:match.start()].count('\n') + 1,
                      'target': target, 'exists': resolved.exists()})

evidence_names = [
    'SOURCE23-PACKETS-01.json', 'SOURCE-COMMIT-PUSH-02.json',
    'SOURCE-COMMIT-PUSH-03.json', 'SETUP03-BOUNDARY-01.json',
    'python-regression-08-command.json', 'python-regression-08-result.json',
    'python-regression-08.log', 'NATIVE-RESULT-01.json',
    'NATIVE-RESULT-02.json', 'native-03-result.json',
    'CLEANUP-TOOL-FAILURE-01.md', 'SOURCE23-POSTCHECK-02.json',
]
for name in evidence_names:
    path = EXTERNAL / name
    inputs['external/' + name] = {'absolute_path': str(path), **pin(path)}

packets = []
packet_root = ROOT / 'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'
for path in sorted(packet_root.rglob('*.zip')):
    # This traversal is limited to the specifically assigned packet directory.
    result = {'path': path.relative_to(ROOT).as_posix(), **pin(path)}
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        result['entries'] = len(names)
        result['duplicate_names'] = sorted(n for n in set(names) if names.count(n) > 1)
        result['crc_bad_member'] = archive.testzip()
        result['manifests'] = {}
        mismatches = []
        for name in names:
            if '/' in name or not name.lower().endswith('.json') or 'manifest' not in name.lower():
                continue
            data = archive.read(name)
            manifest = json.loads(data)
            result['manifests'][name] = {'sha256': sha(data), 'bytes': len(data)}
            if name == 'SOURCE23-MANIFEST-01.json':
                result['manifests'][name]['scope'] = 'external declared source inputs; not ZIP members'
                continue
            files = manifest.get('files')
            if not isinstance(files, dict):
                # Source manifests bind external committed inputs, not ZIP members.
                continue
            checked = 0
            for member, identity in files.items():
                if not isinstance(identity, dict) or 'sha256' not in identity:
                    continue
                if member not in names:
                    mismatches.append({'manifest': name, 'member': member, 'error': 'missing'})
                    continue
                value = archive.read(member)
                if sha(value) != identity['sha256'] or (identity.get('bytes') is not None and len(value) != identity['bytes']):
                    mismatches.append({'manifest': name, 'member': member, 'error': 'identity'})
                checked += 1
            result['manifests'][name]['checked_members'] = checked
        result['manifest_mismatches'] = mismatches
    packets.append(result)

recorded = json.loads((EXTERNAL / 'SOURCE23-PACKETS-01.json').read_text(encoding='utf-8'))
receipt_mismatches = []
by_path = {item['path']: item for item in packets}
for item in recorded['packets']:
    actual = by_path.get(item['path'])
    if actual is None or any(actual[k] != item[k] for k in ('sha256', 'bytes')):
        receipt_mismatches.append(item['path'])

git = {}
for label, args in [
    ('HEAD', ['rev-parse', 'HEAD']),
    ('origin_tracking', ['rev-parse', 'refs/remotes/origin/codex/v1.8.0-classic-content']),
    ('source_commits', ['log', '-3', '--format=%H %s']),
]:
    proc = subprocess.run(['git', '-C', str(ROOT)] + args, capture_output=True, text=True)
    git[label] = {'command': args, 'exit': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}

native = {}
for name in ('NATIVE-RESULT-01.json', 'NATIVE-RESULT-02.json', 'native-03-result.json'):
    result = json.loads((EXTERNAL / name).read_text(encoding='utf-8'))
    native[name] = {key: result.get(key) for key in ('exit_code', 'elapsed_seconds', 'started_utc', 'ended_utc')}
python_receipt = json.loads((EXTERNAL / 'python-regression-08-result.json').read_text(encoding='utf-8'))
python_log = (EXTERNAL / 'python-regression-08.log').read_text(encoding='utf-8')
count_match = re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+\nOK', python_log)

write('INPUTS-01.json', inputs)
write('LINKS-01.json', {'links': links, 'missing': [x for x in links if not x['exists']]})
write('PACKETS-01.json', {'packets': packets, 'receipt_mismatches': receipt_mismatches})
write('OBSERVATIONS-01.json', {
    'git': git, 'native_results': native, 'python_receipt': python_receipt,
    'python_log_Ran_OK': count_match.groups() if count_match else None,
    'new_C_paths': [], 'no_deletion': True,
    'subprocess_environment': {key: os.environ.get(key) for key in ('TEMP', 'TMP', 'TMPDIR')},
    'scope': 'current publication documentation and named packets; no native execution or source admission',
})
errors = sum(bool(x['crc_bad_member'] or x['duplicate_names'] or x['manifest_mismatches']) for x in packets)
errors += len(receipt_mismatches) + sum(not x['exists'] for x in links)
print(json.dumps({'packets': len(packets), 'links': len(links), 'errors': errors,
                  'python_log_Ran_OK': count_match.groups() if count_match else None}, ensure_ascii=False))
raise SystemExit(1 if errors else 0)
