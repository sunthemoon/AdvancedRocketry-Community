import hashlib
import json
from pathlib import Path
import posixpath
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = ROOT / 'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'
prior = json.loads((HERE / 'INPUTS-04.json').read_text(encoding='utf-8'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

result = {'docs': {}, 'drift': [], 'locator_controls': [], 'source_native_identity_changes': [], 'link_errors': []}
snapshot = HERE / 'doc-correction-07'
snapshot.mkdir()
for name, identity in prior.items():
    if 'snapshot' not in identity:
        continue
    actual = pin(ROOT / name)
    result['docs'][name] = actual
    if actual['sha256'] != identity['sha256']:
        result['drift'].append({'path': name, 'before': identity['sha256'], 'after': actual['sha256']})
        (snapshot / Path(name).name).write_bytes((ROOT / name).read_bytes())
locator = BASE / 'COMPANION-LOCATORS-01.md'
text = locator.read_text(encoding='utf-8')
result['docs'][locator.relative_to(ROOT).as_posix()] = pin(locator)
(snapshot / locator.name).write_bytes(locator.read_bytes())
for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', text):
    if not (locator.parent / match.group(1)).exists():
        result['link_errors'].append(match.group(1))

for source_packet, source_member, relative, target_packet, target_member in (
    ('LIFECYCLE-PRIMARY-02.zip', 'REVIEW-NATIVE02.md', '../aglf-94222005ae/FEASIBILITY-01.md', 'LIFECYCLE-PRIMARY-01.zip', 'FEASIBILITY-01.md'),
    ('LIFECYCLE-PRIMARY-03.zip', 'REVIEW-NATIVE03.md', '../agnf-1b7aa2336c/REVIEW-NATIVE02.md', 'LIFECYCLE-PRIMARY-02.zip', 'REVIEW-NATIVE02.md'),
):
    with zipfile.ZipFile(BASE / 'reviews' / source_packet) as archive:
        source = archive.read(source_member).decode('utf-8')
    with zipfile.ZipFile(BASE / 'reviews' / target_packet) as archive:
        target = archive.read(target_member)
    expected_folder = relative.split('/')[1]
    control = {'source_packet': source_packet, 'source_member': source_member, 'relative': relative,
               'source_contains_reference': relative in source,
               'target_packet': target_packet, 'target_member': target_member,
               'actual_target_sha256': sha(target),
               'locator_contains_actual_hash': sha(target) in text,
               'locator_contains_target_member': target_member in text,
               'locator_contains_sibling_directory': ('`' + expected_folder + '/`') in text}
    result['locator_controls'].append(control)

packets = json.loads((HERE / 'PACKETS-04.json').read_text(encoding='utf-8'))['packets']
for packet in packets:
    observed = pin(ROOT / packet['path'])
    if any(observed[k] != packet[k] for k in ('bytes', 'sha256')):
        result['source_native_identity_changes'].append(packet['path'])

(HERE / 'CORRECTION-07.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
errors = len(result['link_errors']) + len(result['source_native_identity_changes'])
errors += sum(not all(c[key] for key in ('source_contains_reference', 'locator_contains_actual_hash', 'locator_contains_target_member', 'locator_contains_sibling_directory')) for c in result['locator_controls'])
print(json.dumps({'drift': result['drift'], 'locator_controls': len(result['locator_controls']), 'errors': errors}))
raise SystemExit(1 if errors else 0)
