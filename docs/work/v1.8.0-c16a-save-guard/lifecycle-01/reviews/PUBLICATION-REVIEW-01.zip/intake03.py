from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'intake01.py').read_text(encoding='utf-8')
source = source.replace("snapshot = HERE / 'doc-snapshots-01'", "snapshot = HERE / 'doc-snapshots-03'")
for name in ('INPUTS', 'LINKS', 'PACKETS', 'OBSERVATIONS'):
    source = source.replace(f"write('{name}-01.json',", f"write('{name}-03.json',")
exec(compile(source, str(here / 'intake01.py'), 'exec'))
