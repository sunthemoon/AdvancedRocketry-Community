from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'intake01.py').read_text(encoding='utf-8')
source = source.replace("snapshot = HERE / 'doc-snapshots-01'", "DOCS.append('docs/work/v1.8.0-c16a-save-guard/lifecycle-01/INDEX.md')\nsnapshot = HERE / 'doc-snapshots-04'")
for name in ('INPUTS', 'LINKS', 'PACKETS', 'OBSERVATIONS'):
    source = source.replace(f"write('{name}-01.json',", f"write('{name}-04.json',")
exec(compile(source, str(here / 'intake01.py'), 'exec'))
