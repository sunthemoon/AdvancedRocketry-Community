import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
EXCLUDED = {'EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt', 'FREEZE-RESULT-01.json', 'freeze-10.log', 'freeze-10.exit'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

for name in ('EVIDENCE-MANIFEST.json', 'SHA256SUMS.txt', 'FREEZE-RESULT-01.json'):
    if (HERE / name).exists():
        raise FileExistsError(name)
links = []
for name in ('REVIEW-01.md', 'RENDERING-OBSERVATION-01.md'):
    text = (HERE / name).read_text(encoding='utf-8')
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', text):
        target = match.group(1).split('#')[0]
        if not target or re.match(r'^(https?:|mailto:)', target):
            continue
        links.append({'document': name, 'target': target, 'exists': (HERE / target).is_file()})
if any(not x['exists'] for x in links):
    raise ValueError([x for x in links if not x['exists']])

files = {}
for path in sorted(HERE.rglob('*')):
    if not path.is_file() or path.name in EXCLUDED:
        continue
    data = path.read_bytes()
    files[path.relative_to(HERE).as_posix()] = {'bytes': len(data), 'sha256': sha(data)}
manifest = {'scope': 'independent final publication review at fixed f945, no source/native/Gate admission',
            'payload_files': len(files), 'payload_bytes': sum(x['bytes'] for x in files.values()),
            'new_C_paths': [], 'Java_native_server_executions': 0, 'deletions': 0,
            'excluded_sealing_metadata': sorted(EXCLUDED), 'files': files,
            'own_report_links': links, 'snapshots': 'Individual scoped Root-doc postimages/context; their original repository links were independently checked against Root, not relocated as a whole repository.'}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
(HERE / 'EVIDENCE-MANIFEST.json').write_bytes(manifest_bytes)
sums = [f"{identity['sha256']}  {name}" for name, identity in files.items()]
sums.append(sha(manifest_bytes) + '  EVIDENCE-MANIFEST.json')
(HERE / 'SHA256SUMS.txt').write_text('\n'.join(sums) + '\n', encoding='ascii')
verified = []
for name, identity in files.items():
    data = (HERE / name).read_bytes()
    if len(data) != identity['bytes'] or sha(data) != identity['sha256']:
        verified.append(name)
if verified:
    raise ValueError(verified)
result = {'report_sha256': sha((HERE / 'REVIEW-01.md').read_bytes()),
          'report_bytes': (HERE / 'REVIEW-01.md').stat().st_size,
          'manifest_sha256': sha(manifest_bytes),
          'checksum_sha256': sha((HERE / 'SHA256SUMS.txt').read_bytes()),
          'payload_files': len(files), 'payload_bytes': manifest['payload_bytes'],
          'own_report_links': len(links), 'missing_links': 0, 'manifest_mismatches': 0,
          'ZIP_created': False, 'new_C_paths': []}
(HERE / 'FREEZE-RESULT-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
