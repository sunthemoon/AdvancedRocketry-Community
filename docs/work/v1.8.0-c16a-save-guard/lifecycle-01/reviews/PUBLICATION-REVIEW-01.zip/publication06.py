import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-publication-01')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

inputs = {}
for name in ('PUBLICATION-CHECKS-01.json', 'MARKDOWN-LINKS-01.json', 'SETUP03-FINAL-POSTCHECK-01.json'):
    inputs[name] = pin(BASE / name)
summary = json.loads((BASE / 'PUBLICATION-CHECKS-01.json').read_text(encoding='utf-8'))
links = json.loads((BASE / 'MARKDOWN-LINKS-01.json').read_text(encoding='utf-8'))
postcheck = json.loads((BASE / 'SETUP03-FINAL-POSTCHECK-01.json').read_text(encoding='utf-8'))
raw_jobs = []
mismatches = []
for job in summary['jobs']:
    name = job['name']
    raw = BASE / (name + '.log')
    command = BASE / (name + '.command.json')
    inputs[raw.name] = pin(raw)
    inputs[command.name] = pin(command)
    if inputs[raw.name]['sha256'] != job['log_sha256']:
        mismatches.append(raw.name)
    raw_jobs.append({'name': name, 'recorded_exit': job['exit'], 'raw_log_sha_matches': inputs[raw.name]['sha256'] == job['log_sha256'],
                     'command': json.loads(command.read_text(encoding='utf-8'))})

scoped_inputs = json.loads((HERE / 'INPUTS-04.json').read_text(encoding='utf-8'))
doc_controls = []
for name, identity in scoped_inputs.items():
    if 'snapshot' not in identity:
        continue
    actual = pin(ROOT / name)
    doc_controls.append({'name': name, 'reviewed_sha256': identity['sha256'], 'live_sha256': actual['sha256'],
                         'Root_link_check_sha256': links['doc_sha256'].get(name)})
    if actual['sha256'] != identity['sha256']:
        mismatches.append('live doc ' + name)
    if links['doc_sha256'].get(name) != identity['sha256']:
        mismatches.append('Root link-check doc ' + name)

result = {'input_pins': inputs, 'jobs': raw_jobs, 'doc_controls': doc_controls,
    'Root_link_check': {key: links[key] for key in ('files', 'links', 'errors')},
    'Root_final_source_check': postcheck,
    'mismatches': mismatches,
    'attribution': 'Root checks are parsed and raw pins verified; this reviewer did not rerun whole-repository/link/2995-source checks',
    'independent_full_Gate_or_native_claim': False}
(HERE / 'PUBLICATION-RECEIPTS-06.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'raw_jobs': len(raw_jobs), 'recorded_exit_codes': [x['recorded_exit'] for x in raw_jobs],
                 'Root_links': result['Root_link_check'], 'scoped_docs': len(doc_controls), 'mismatches': mismatches}))
raise SystemExit(1 if mismatches else 0)
