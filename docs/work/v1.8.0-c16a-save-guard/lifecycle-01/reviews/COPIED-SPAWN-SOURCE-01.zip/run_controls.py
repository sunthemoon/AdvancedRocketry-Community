"""Run exact candidate Python source tests and independent controls only."""
import importlib.util
import json
import sys
import unittest
from pathlib import Path

HERE=Path(__file__).parent
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(HERE))
import scripts
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module; spec.loader.exec_module(module)
    return module
guard=load('scripts.run_v180_guard_lifecycle_smoke',HERE/'postimages/run_v180_guard_lifecycle_smoke.py')
scripts.run_v180_guard_lifecycle_smoke=guard; sys.modules['frozen_guard']=guard
author=load('frozen_author_tests',HERE/'postimages/test_run_v180_guard_lifecycle_smoke.py')
controls=load('test_independent_controls',HERE/'test_independent_controls.py')
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(author),unittest.defaultTestLoader.loadTestsFromModule(controls)])
result=unittest.TextTestRunner(verbosity=2).run(suite)
target=HERE/'PYTHON-COUNTS-01.json'; assert not target.exists()
target.write_bytes((json.dumps({'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
                               'skipped':len(result.skipped),'native_run':False},indent=2)+'\n').encode('utf-8'))
sys.exit(0 if result.wasSuccessful() else 1)
