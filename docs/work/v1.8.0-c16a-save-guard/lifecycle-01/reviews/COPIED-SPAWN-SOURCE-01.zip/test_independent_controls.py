"""Independent controls for copied setup only; no native cause/outcome assumption."""
import ast
import unittest
from pathlib import Path
from unittest.mock import patch

import frozen_guard as guard

HERE=Path(__file__).parent
SUCCESS='[17:17:02] [Server thread/INFO] [minecraft/MinecraftServer]: Set the world spawn point to 256, 74, -256 [0.0]'
END='[17:17:02] [Server thread/INFO] [minecraft/MinecraftServer]: [Server] ARCE_GUARD_COPY_SPAWN_END'

class CopiedSetupIndependentControls(unittest.TestCase):
    def test_fixed_literal_command_and_spawn_distance_arithmetic(self):
        self.assertEqual(guard.COPY_SPAWN_COMMAND,'setworldspawn 256 74 -256 0')
        target=(11,11)
        old=(256//16,-32//16)
        new=(256//16,-256//16)
        distance=lambda pos:max(abs(target[0]-pos[0]),abs(target[1]-pos[1]))
        self.assertEqual((old,new,distance(old),distance(new)),((16,-2),(16,-16),13,27))
        # Arithmetic control only; runtime START/propagation facts are separately pinned.
        self.assertEqual((22+distance(old),22+distance(new)),(35,49))
        self.assertLessEqual(35,45)
        self.assertGreater(49,45)

    def test_setup_call_is_between_initial_loaded_and_first_block_check(self):
        source=(HERE/'postimages/run_v180_guard_lifecycle_smoke.py').read_text(encoding='utf-8')
        tree=ast.parse(source)
        cycle=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='native_cycle')
        outer=next(n for n in cycle.body if isinstance(n,ast.Try))
        statements=outer.body
        setup=next(i for i,n in enumerate(statements) if isinstance(n,ast.Assign) and
                   isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='relocate_copy_spawn')
        self.assertEqual(ast.unparse(statements[setup-1]),'wait_chunk(process, commands, True)')
        self.assertIn('ARCE_GUARD_ROOT_RELOADED',ast.unparse(statements[setup+1]))
        self.assertEqual(sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and
                             n.func.id=='relocate_copy_spawn' for n in ast.walk(tree)),1)

    def test_complete_fresh_success_and_barrier_process_order(self):
        class Process:
            def __init__(self):
                self.lines=[]; self.sent=[]
            def command(self,text):
                self.sent.append(text)
                self.lines.append(SUCCESS if text==guard.COPY_SPAWN_COMMAND else END)
            def wait_for(self,pattern,timeout,start_at):
                assert timeout==60 and start_at==1
                assert any(pattern.search(l) for l in self.lines[start_at:])
        process=Process(); commands=[]
        self.assertEqual(guard.relocate_copy_spawn(process,commands),SUCCESS)
        self.assertEqual(process.sent,[guard.COPY_SPAWN_COMMAND,'say ARCE_GUARD_COPY_SPAWN_END'])
        self.assertEqual(commands,process.sent)

    def test_old_success_and_fresh_barrier_alone_cannot_pass(self):
        class Process:
            lines=[SUCCESS]
            def command(self,text):
                if text.startswith('say '):
                    self.lines.append(END)
            def wait_for(self,pattern,timeout,start_at):
                assert any(pattern.search(l) for l in self.lines[start_at:])
        with self.assertRaisesRegex(RuntimeError,'exactly once'):
            guard.relocate_copy_spawn(Process(),[])

    def test_duplicate_fresh_success_cannot_pass(self):
        class Process:
            def __init__(self):
                self.lines=[]
            def command(self,text):
                self.lines.extend([SUCCESS,SUCCESS] if text==guard.COPY_SPAWN_COMMAND else [END])
            def wait_for(self,pattern,timeout,start_at):
                assert any(pattern.search(l) for l in self.lines[start_at:])
        with self.assertRaisesRegex(RuntimeError,'exactly once'):
            guard.relocate_copy_spawn(Process(),[])

    def test_console_say_or_error_or_embedded_text_cannot_supply_command_success(self):
        for line in [SUCCESS.replace('/INFO]','/ERROR]'),SUCCESS.replace(']: Set',']: [Server] Set'),
                     SUCCESS.replace('minecraft/MinecraftServer','advancedrocketrycommunity/'),
                     'echo '+SUCCESS,SUCCESS+' extra',SUCCESS.replace('74','75'),SUCCESS.replace('[0.0]','[0]')]:
            self.assertIsNone(guard.COPY_SPAWN_SUCCESS.search(line))
        self.assertIsNotNone(guard.COPY_SPAWN_SUCCESS.search(SUCCESS))

    def test_barrier_failure_is_not_ignored(self):
        class Process:
            lines=[]
            def command(self,text):
                pass
        with (patch.object(guard,'say_barrier',side_effect=guard.server.SmokeError('barrier failed')),
              self.assertRaisesRegex(guard.server.SmokeError,'barrier failed')):
            guard.relocate_copy_spawn(Process(),[])

    def test_original_unload_deadline_and_byte_oracle_are_unchanged(self):
        before=ast.parse((HERE/'preimages/run_v180_guard_lifecycle_smoke.py').read_text(encoding='utf-8'))
        after=ast.parse((HERE/'postimages/run_v180_guard_lifecycle_smoke.py').read_text(encoding='utf-8'))
        for name in ['wait_unload_begin','wait_chunk','check_record','check_fixture','main']:
            get=lambda tree:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(ast.dump(get(before),include_attributes=False),ast.dump(get(after),include_attributes=False))

if __name__=='__main__':
    unittest.main()
