"""Capture four named, bounded primary records; never copy a source tree/JAR/world."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = Path('D:/ARCE-Task-Evidence/v1.8.0/agnf-1b7aa2336c')
PINS = {
    'TICKET-LIFECYCLE-04.json': '214e614a3018a670fc6db91ddf32198c221b5bf4afd921905b99e7318548c126',
    'TICKET-PRIMARY-03.json': 'c82698992f4b55d61a0c3233674582dcbeb03ec205121c980f2b5e46699d706d',
    'ANNOTATION-MESSAGE-05.json': '667b05dbb13301a592bb7ef1105a6e174e327ba4544347c64bda4d3f5532b33b',
    'LEVEL-FACTS-02.json': '6f6b3737a6db7787ae846333ebf8a986e3fad289b075cca77c01b7aca414aa9f',
}
records = {}
total = 0
target = HERE / 'primary_inputs'
assert not target.exists()
target.mkdir()
for name, expected in PINS.items():
    body = (SOURCE / name).read_bytes()
    assert len(body) <= 250_000
    assert hashlib.sha256(body).hexdigest() == expected
    total += len(body)
    assert total <= 400_000
    (target / name).write_bytes(body)
    records[name] = {'bytes': len(body), 'sha256': expected}
sealed = {}
for name, expected in {
    'REVIEW-NATIVE02.md': '76f1053e12fab5497592dd527697e556a4a70b52cc80a861e2514ba40e84f387',
    'INTERNAL-MANIFEST.json': '72083029929d4f9a61180b0f5076c7746e4b6fa480ff0c349fc590083694c090',
}.items():
    body = (SOURCE / name).read_bytes()
    assert hashlib.sha256(body).hexdigest() == expected
    sealed[name] = {'bytes': len(body), 'sha256': expected, 'copied': False}
out = {'source_directory': str(SOURCE), 'copied_records': records,
       'copied_bytes': total, 'later_primary_bundle_seal_pins': sealed,
       'JARs_source_trees_or_worlds_copied': False}
(HERE / 'PRIMARY-CAPTURE-01.json').write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'records': len(records), 'bytes': total, 'seal_pins_verified': len(sealed)}))
