"""Read pinned records and reparse named cached classfiles without Java/exports."""
import ast
import hashlib
import json
import struct
import zipfile
from pathlib import Path

HERE=Path(__file__).parent
PRIMARY=Path('D:/ARCE-Task-Evidence/v1.8.0/agnf-1b7aa2336c')
PINS={'TICKET-LIFECYCLE-04.json':'214e614a3018a670fc6db91ddf32198c221b5bf4afd921905b99e7318548c126',
      'TICKET-PRIMARY-03.json':'c82698992f4b55d61a0c3233674582dcbeb03ec205121c980f2b5e46699d706d',
      'ANNOTATION-MESSAGE-05.json':'667b05dbb13301a592bb7ef1105a6e174e327ba4544347c64bda4d3f5532b33b',
      'LEVEL-FACTS-02.json':'6f6b3737a6db7787ae846333ebf8a986e3fad289b075cca77c01b7aca414aa9f'}
pin=lambda body:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
records={}; inputs={}
for name,expected in PINS.items():
    body=(PRIMARY/name).read_bytes()
    assert pin(body)['sha256']==expected,name
    inputs[str(PRIMARY/name)]=pin(body)
    records[name]=json.loads(body)
jar=records['TICKET-PRIMARY-03.json']['primary_jar']
path=Path(jar['path'])
with path.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==jar['sha256']
assert jar['sha256']=='95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
helper=Path(records['TICKET-PRIMARY-03.json']['helper']['path'])
body=helper.read_bytes()
assert pin(body)['sha256']=='001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167'
inputs[str(helper)]=pin(body)
tree=ast.parse(body)
# Execute only the two pure class-reader declarations, excluding module report I/O.
nodes=[node for node in tree.body if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ('R','parse')]
assert len(nodes)==2
namespace={'hashlib':hashlib,'struct':struct}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper)+'#pure_declarations','exec'),namespace)
selected={}
with zipfile.ZipFile(path) as source:
    for record_name in ['TICKET-PRIMARY-03.json','TICKET-LIFECYCLE-04.json']:
        for name,expected in records[record_name].get('classes',{}).items():
            if not any(s in name for s in ['ServerLevel.class','SetWorldSpawnCommand.class','TicketType.class','Ticket.class','ChunkLevel.class','ChunkTracker.class']):
                continue
            body=source.read(name)
            assert len(body)<=1024*1024 and pin(body)['sha256']==expected['sha256']
            methods=expected.get('selected_methods',{})
            names={signature.split('(')[0] for signature in methods}
            actual=namespace['parse'](body,names)
            for signature,method in methods.items():
                assert actual['selected_methods'][signature]['code_hex']==method['code_hex']
                assert actual['selected_methods'][signature]['instructions']==method['instructions']
            chosen={signature:{'code_bytes':len(bytes.fromhex(method['code_hex'])),
                               'references':[i['reference'] for i in method['instructions'] if i['reference'] is not None]}
                    for signature,method in actual['selected_methods'].items()
                    if any(s in signature for s in ['setDefaultSpawnPos','setSpawn(','lambda$setSpawn','getComputedLevel','isTimedOut','create(','<clinit>'])}
            selected[name]={'class':pin(body),'methods':chosen}
server=selected['net/minecraft/server/level/ServerLevel.class']['methods']
spawn=next(method for name,method in server.items() if name.startswith('setDefaultSpawnPos('))
references=spawn['references']
remove=next(i for i,reference in enumerate(references) if '.removeRegionTicket(' in reference)
add=next(i for i,reference in enumerate(references) if '.addRegionTicket(' in reference)
assert remove<add
command=selected['net/minecraft/server/commands/SetWorldSpawnCommand.class']['methods']
set_spawn=next(method for name,method in command.items() if name.startswith('setSpawn('))['references']
assert next(i for i,r in enumerate(set_spawn) if '.setDefaultSpawnPos(' in r)<next(i for i,r in enumerate(set_spawn) if '.sendSuccess(' in r)
def find_language(value):
    if isinstance(value,dict):
        if value.get('key')=='commands.setworldspawn.success':
            yield value
        for child in value.values():
            yield from find_language(child)
    elif isinstance(value,list):
        for child in value:
            yield from find_language(child)
language=list(find_language(records['ANNOTATION-MESSAGE-05.json']))
assert len(language)==1
language=language[0]
assert language['template']=='Set the world spawn point to %s, %s, %s [%s]'
with Path(language['jar_path']).open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==language['jar_sha256']
with zipfile.ZipFile(language['jar_path']) as jar_file:
    body=jar_file.read(language['member'])
    assert pin(body)['sha256']==language['member_sha256']
    assert json.loads(body)['commands.setworldspawn.success']==language['template']
level=records['LEVEL-FACTS-02.json']
for value in level['named_level_files'].values():
    assert [value['fields'][axis] for axis in ['SpawnX','SpawnY','SpawnZ']]==[256,74,-32]
    assert value['spawn_chunk']==[16,-2] and value['Chebyshev_distance_from_spawn']==13
out={'pinned_record_inputs':inputs,'primary_jar':records['TICKET-PRIMARY-03.json']['primary_jar'],
     'class_method_reparse':selected,'old_start_removed_before_new_start_added':True,
     'spawn_update_precedes_command_success':True,'language_resource':language,
     'old_spawn_fields':{'SpawnX':256,'SpawnY':74,'SpawnZ':-32,'old_chunk':[16,-2],'target':[11,11]},
     'record_attribution':'Four exact raw records pinned; whole primary report bundle not claimed sealed',
     'spawn_world_read_by_this_worker':False,'Java_or_native_launched':False,
     'official_source_or_assets_exported':False,'helper_module_main_executed':False}
target=HERE/'PRIMARY-CHECKS-01.json'; assert not target.exists()
target.write_bytes((json.dumps(out,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'exact_records':len(PINS),'reparsed_classes':len(selected),'old_before_new':True,
                  'update_before_success':True,'language_template':language['template'],'no_runtime':True},indent=2))
