"""Seal only this declared small evidence directory, preserving failed controls."""
import datetime
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED = Path('D:/ARCE-Task-Evidence/v1.8.0/agsr3-6746c51d09').resolve()
assert HERE == EXPECTED
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
pin = lambda body: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
intake = json.loads((HERE / 'INTAKE-01.json').read_text(encoding='utf-8-sig'))
checks = {}
for relative, entry in intake['files'].items():
    own = HERE / 'postimages' / Path(relative).name
    expected = entry['after']
    assert pin(own.read_bytes()) == expected
    assert pin((ROOT / relative).read_bytes()) == expected
    checks[relative] = {'captured_postimage': expected, 'named_live_input_equal': True}
capture = json.loads((HERE / 'PRIMARY-CAPTURE-01.json').read_text(encoding='utf-8'))
for name, expected in capture['copied_records'].items():
    assert pin((HERE / 'primary_inputs' / name).read_bytes()) == expected
counts = json.loads((HERE / 'PYTHON-COUNTS-01.json').read_text(encoding='utf-8'))
assert counts == {'executed': 32, 'failures': 0, 'errors': 0, 'skipped': 0, 'native_run': False}
assert (HERE / 'python-01.exit').read_text().strip() == '1'
assert 'SyntaxError' in (HERE / 'python-01.log').read_text()
assert (HERE / 'python-02.exit').read_text().strip() == '0'
assert pin((HERE / 'test_independent_controls_failed_01.txt').read_bytes())['sha256'] == 'e0cac4e5a2774ba512e14eaf2824870c589ce6653ab1bb9b131d578ed205de26'
assert (HERE / 'capture-primary-01.exit').read_text().strip() == '0'
result = {'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'command': [sys.executable, '-B', str(HERE / 'seal.py')],
          'exit': 0, 'input_rechecks': checks,
          'retained_first_test_failure': True, 'passing_test_count': 32,
          'Java_native_launched': False, 'external_or_source_files_written': False,
          'manifest_excludes_only': ['INTERNAL-MANIFEST.json', 'SHA256SUMS.txt']}
(HERE / 'SEAL-01.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
files = {}
for path in sorted(HERE.rglob('*')):
    if not path.is_file() or path.name in result['manifest_excludes_only']:
        continue
    assert path.resolve().is_relative_to(HERE)
    assert not path.is_symlink()
    files[path.relative_to(HERE).as_posix()] = pin(path.read_bytes())
assert len(files) < 100 and sum(v['bytes'] for v in files.values()) < 1_000_000
manifest = {'scope': 'copied-world spawn setup independent source review only',
            'fixed_baseline': intake['fixed_baseline'], 'files': files,
            'entry_count': len(files), 'payload_bytes': sum(v['bytes'] for v in files.values()),
            'native_result_admission': False}
body = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
assert not (HERE / 'INTERNAL-MANIFEST.json').exists()
(HERE / 'INTERNAL-MANIFEST.json').write_bytes(body)
manifest_hash = hashlib.sha256(body).hexdigest()
report_hash = hashlib.sha256((HERE / 'REPORT.md').read_bytes()).hexdigest()
(HERE / 'SHA256SUMS.txt').write_bytes((manifest_hash + '  INTERNAL-MANIFEST.json\n'
                                      + report_hash + '  REPORT.md\n').encode('ascii'))
for relative, expected in files.items():
    assert pin((HERE / relative).read_bytes()) == expected
print(json.dumps({'report_sha256': report_hash, 'manifest_sha256': manifest_hash,
                  'entries': len(files), 'payload_bytes': manifest['payload_bytes'],
                  'checked_all_local_payloads': True, 'exit': 0}, indent=2))
