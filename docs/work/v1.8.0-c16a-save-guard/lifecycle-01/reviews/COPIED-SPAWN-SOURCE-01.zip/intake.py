"""Named fixed-baseline source intake and bounded AST preservation comparison."""
import ast
import hashlib
import json
import subprocess
from pathlib import Path

HERE=Path(__file__).parent
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
COMMIT='23bec1eb1452e8c8ef37c004606aaed3a2394063'
PINS={
    'scripts/run_v180_guard_lifecycle_smoke.py':'4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad',
    'tests/test_run_v180_guard_lifecycle_smoke.py':'e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16',
    'docs/work/v1.8.0-c16a-save-guard/COPIED-SPAWN-SETUP-AMENDMENT-01.md':'0a923ac5f7a372e851058fda9d41bc4c8dd290c575f2affa75f4ce8f950ce386'}
pin=lambda body:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
commands=[]
def git(args):
    command=['git','-C',str(ROOT),*args]
    result=subprocess.run(command,capture_output=True)
    commands.append({'command':command,'exit':result.returncode,'stdout':pin(result.stdout),
                     'stderr':result.stderr.decode('utf-8')})
    return result
assert git(['rev-parse','HEAD']).stdout.decode().strip()==COMMIT
post=HERE/'postimages'; before=HERE/'preimages'
assert not post.exists() and not before.exists()
post.mkdir(); before.mkdir()
records={}; texts={}
for name,expected in PINS.items():
    body=(ROOT/name).read_bytes()
    assert pin(body)['sha256']==expected,name
    (post/Path(name).name).write_bytes(body)
    records[name]={'after':pin(body)}
    texts[name]=body.decode('utf-8')
    if name.endswith('.py'):
        result=git(['show',COMMIT+':'+name])
        assert result.returncode==0
        (before/Path(name).name).write_bytes(result.stdout)
        records[name]['before']=pin(result.stdout)
    else:
        result=git(['cat-file','-e',COMMIT+':'+name])
        assert result.returncode!=0
        records[name]['before']='absent expected new task record'
script='scripts/run_v180_guard_lifecycle_smoke.py'
test='tests/test_run_v180_guard_lifecycle_smoke.py'
def methods(tree):
    return {node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,ast.FunctionDef)}
old=ast.parse((before/Path(script).name).read_text(encoding='utf-8'))
new=ast.parse(texts[script])
old_functions,new_functions=methods(old),methods(new)
preserved=[name for name,tree in old_functions.items() if tree==new_functions[name]]
assert set(old_functions)-set(preserved)=={'native_cycle'}
old_cycle=next(node for node in old.body if isinstance(node,ast.FunctionDef) and node.name=='native_cycle')
new_cycle=next(node for node in new.body if isinstance(node,ast.FunctionDef) and node.name=='native_cycle')
added=[node for node in ast.walk(new_cycle) if isinstance(node,ast.Assign) and
       any(isinstance(t,ast.Subscript) and isinstance(t.slice,ast.Constant) and t.slice.value=='copy_spawn_setup' for t in node.targets)]
assert len(added)==1
setup=added[0]
new_cycle.body=[node for node in new_cycle.body if node is not setup]
# The setup assignment is nested within the try body, not top-level function body.
for node in ast.walk(new_cycle):
    if hasattr(node,'body') and isinstance(node.body,list):
        node.body=[child for child in node.body if child is not setup]
assert ast.dump(new_cycle,include_attributes=False)==ast.dump(old_cycle,include_attributes=False)
def test_methods(tree):
    return {node.name+'.'+child.name:ast.dump(child,include_attributes=False)
            for node in tree.body if isinstance(node,ast.ClassDef)
            for child in node.body if isinstance(child,ast.FunctionDef) and child.name.startswith('test_')}
old_tests=test_methods(ast.parse((before/Path(test).name).read_text(encoding='utf-8')))
new_tests=test_methods(ast.parse(texts[test]))
assert all(new_tests[name]==body for name,body in old_tests.items())
assert len(set(new_tests)-set(old_tests))==3
diff=git(['diff',COMMIT,'--',script,test])
assert diff.returncode==0
(HERE/'ACTUAL-SOURCE-DIFF.patch').write_bytes(diff.stdout)
required=['AGENTS.md','PROJECT-CONFIG.md','PRODUCT.md','docs/01-PORTING-PRINCIPLES.md',
          'docs/04-VERSION-ROADMAP.md','docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
          'docs/05-MASTER-TEST-PLAN.md','docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
          'docs/16-POST-1.0-VERSION-ROADMAP.md','docs/17-V1PLUS-QUALITY-BUDGETS.md',
          'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
out={'fixed_baseline':COMMIT,'files':records,'commands':commands,
     'required_input_pins':{name:pin((ROOT/name).read_bytes()) for name in required},
     'original_functions':len(old_functions),'unchanged_functions':preserved,
     'native_cycle_change':'exact one added setup receipt/call; removing that assignment preserves entire old AST',
     'original_test_methods':len(old_tests),'new_test_methods':len(new_tests),'original_methods_ast_equal':True,
     'source_or_runtime_writes':False}
target=HERE/'INTAKE-01.json'; assert not target.exists()
target.write_bytes((json.dumps(out,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'original_functions':len(old_functions),'unchanged_functions':len(preserved),
                  'original_methods':len(old_tests),'new_methods':len(new_tests),'original_ast_equal':True},indent=2))
