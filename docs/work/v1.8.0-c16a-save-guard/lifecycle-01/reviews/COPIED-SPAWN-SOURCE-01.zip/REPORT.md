# Copied-world spawn setup: independent source review

## Findings and scoped disposition

No introduced Critical, High, Medium or Low finding was identified in the
exact three-file setup amendment. It is eligible **as copied test-world setup
for a separately pinned native cohort only**. This is not a native pass, proof
of the unique cause of native02, production lifecycle admission, or a version
Gate disposition. Native01 and native02 remain failed observations.

The reviewed baseline is `23bec1eb1452e8c8ef37c004606aaed3a2394063`.
The captured candidate postimages are immutable inputs to this report:

| File | SHA-256 |
| --- | --- |
| [Script](postimages/run_v180_guard_lifecycle_smoke.py) | `4bd80229065402ce85e74a7332c5a6d9812f0f2cb03c1bafeb6ecde3001398ad` |
| [Tests](postimages/test_run_v180_guard_lifecycle_smoke.py) | `e8c117bab441cd88680d6a3aed5775fa30e66ccc27d09bbf10eb11c52fecaa16` |
| [Task record](postimages/COPIED-SPAWN-SETUP-AMENDMENT-01.md) | `0a923ac5f7a372e851058fda9d41bc4c8dd290c575f2affa75f4ce8f950ce386` |

## Actual delta and preservation

The [actual two-file diff](ACTUAL-SOURCE-DIFF.patch) adds a fixed console command
and whole-line success predicate at script lines 23-26, a bounded fresh-output
check at lines 90-98, and one setup call at line 180. The call follows the
initial forced-load confirmation and precedes the original block assertions,
stone mutation, saves and forceload removal. It runs in the existing copied
runtime, not the historical input world.

The predicate accepts exactly one fresh native INFO/MinecraftServer response
with coordinates `(256, 74, -256)` and angle `[0.0]`, after the existing command
barrier. Stale, missing, duplicate, prefixed, wrong-logger, wrong-level,
wrong-coordinate and wrong-angle lines are rejected. Barrier failure remains
a failure. Test lines 252-293 add three focused methods.

[AST comparisons](INTAKE-01.json) confirm all 21 original test methods are
unchanged. Nine of ten original script functions are unchanged; removing the
single new setup assignment makes `native_cycle` identical to its original
AST. Original total 60-second unload deadline, real fresh-event requirement,
live tank/AIR restoration, exact compressed-record/resource checks, copy-only
preconditions and original-input postchecks are unchanged. No Java,
production Guard, schema, ticket implementation or lifecycle API changed.

## Independently checked primary facts

[Primary checks](PRIMARY-CHECKS-01.json) bind and reparse the four exact supplied
raw records; their [captured copies](PRIMARY-CAPTURE-01.json) are included. The
later separate primary report/manifest seal pins were also verified, but that
report is not substituted for this source review.

The cached mapped Forge 47.4.10 JAR was hashed directly as
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Six named classfiles were parsed independently using only the two pure
class-reader declarations from the pinned helper, without running its module
report-writing code. Selected method code and instruction records match the
supplied primary records. The references establish old START removal before
new START addition in `ServerLevel.setDefaultSpawnPos`, and spawn mutation
before `SetWorldSpawnCommand` sends success.

The pinned native facts establish START level 22, no timed expiry, and maximum
holder level 45. The supplied stopped-level facts report original spawn
`(256, 74, -32)`, chunk `(16, -2)`: distance 13 from target `(11, 11)` yields
35. The new literal spawn is chunk `(16, -16)`: distance 27 yields 49, outside
that standard START retention range. These are source-derived calculations,
not observed live ticket state or proof that no other ticket retains the
target. This worker did not decode or modify level.dat or inspect live worlds.

The server-extra JAR and its named English language member were hashed
directly. The actual template is `Set the world spawn point to %s, %s, %s [%s]`.
The exact authoritative response still requires observation in the new
native cohort. No official JAR, classfile, source tree or artwork was exported.

## Executed commands and retained failures

| Command | Actual result |
| --- | --- |
| `python -B intake.py` | Exit 0; three postimage pins, fixed Git preimages and AST preservation verified. |
| `python -B run_controls.py`, first attempt | Exit 1; reviewer declaration SyntaxError, zero tests executed. Original probe/traceback retained. |
| Same command, corrected declaration | Exit 0; **32 tests: candidate 24 + independent 8; 0 failures/errors/skips**. No script main or native process executed. |
| `python -B inspect_primary.py` | Exit 0; exact raw-record/JAR/member pins and six classfile comparisons verified. |
| `python -B capture_primary_inputs.py` | Exit 0; four records / 360,062 bytes captured and two later primary seal pins verified. |

Raw command/result/exit/log companions are kept in this directory. The
[additional inline summary failure](TOOLING-FAILURE-01.md) is explicitly a
transcribed tooling observation, not a raw test log or candidate failure.
No assertions, deadlines or resource budgets were weakened. All Root,
author, historical, sealed and protected inputs were read-only.

## Required unrun checks and limits

1. A fresh Root native cohort must bind these two amended tool postimages
   separately from the unchanged Source23 Java/build inputs and installed JAR
   `5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9`.
   The old Source23 full manifest contains the previous Python hashes; it
   cannot be relabelled as a full unchanged amended-tool manifest.
2. Actually observe strict spawn success, then fresh unload-begin, restoration,
   stopped bytes and both intended cycles within the unchanged deadlines.
   Command success/barrier is not disk durability or callback completion.
3. Other tickets, event registration/execution, disposal, rollback, sticky
   denial, earliest-load/first-save behavior and shutdown outcomes remain
   unproven by this static setup review. Direct block removal is diagnostic,
   not a public gameplay/charged-resource conservation contract.
4. There was no Java, GameTest, native server, client or independent native
   replay. Clean stops cannot prove arbitrary-crash recovery. R-021 and all
   version Required Gates remain outside this source-only disposition.

This small loose bundle contains report/checks/preimages/postimages only; no
full-tree, JAR, world or redundant ZIP export is made.

Root subsequently reported that native03 observed the exact spawn success
line but failed the unchanged unload-marker deadline. That new cohort is not
independently audited in this source report; its failure is not relabelled as
passed by this source-only eligibility finding. A distinct result audit is
required and must preserve setup success versus lifecycle failure.
