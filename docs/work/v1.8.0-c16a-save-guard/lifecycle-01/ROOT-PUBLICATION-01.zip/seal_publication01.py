"""Copy frozen publication evidence; do not change the source/native index."""
import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
HERE = Path(__file__).parent
REVIEW = HERE.parent / 'aglp-50fa177c0c'
TARGET = ROOT / 'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'
HEAD = 'f945dc1c33f09199da9d47663e891acf1cf4a475'
TEMP = HERE / 'tmp'
TEMP.mkdir(exist_ok=True)
for name in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[name] = str(TEMP)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()


def safe_member(name):
    part = PurePosixPath(name)
    assert not part.is_absolute() and '..' not in part.parts and '\\' not in name
    return part


def archive(name, source, names):
    target = TARGET / name
    assert not target.exists(), str(target)
    entries = {}
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as bundle:
        for rel in sorted(set(names)):
            safe_member(rel)
            file = source / rel
            assert file.is_file() and not file.is_symlink(), str(file)
            raw = file.read_bytes()
            assert len(raw) <= 50_000_000, rel
            entries[rel] = {'bytes': len(raw), 'sha256': sha(raw)}
            bundle.writestr(rel, raw)
        assert sum(row['bytes'] for row in entries.values()) <= 100_000_000
        bundle.writestr('ROOT-COPY-MANIFEST-01.json', json.dumps({
            'scope': 'Separate publication receipt; no native or Gate admission',
            'files': entries,
        }, indent=2, sort_keys=True) + '\n')
    with zipfile.ZipFile(target) as bundle:
        assert bundle.testzip() is None
        assert len(bundle.namelist()) == len(set(bundle.namelist()))
        for rel, expected in entries.items():
            raw = bundle.read(rel)
            assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
    row = {'path': target.relative_to(ROOT).as_posix(), **pin(target),
           'payload_files': len(entries),
           'payload_bytes': sum(item['bytes'] for item in entries.values())}
    assert row['bytes'] <= 50_000_000
    sidecar = target.with_suffix('.sha256')
    assert not sidecar.exists(), str(sidecar)
    sidecar.write_text(f"{row['sha256']}  {target.name}\n", encoding='ascii')
    return row


assert git('rev-parse', 'HEAD') == HEAD
assert not git('diff', '--cached', '--name-only')
gov = pin(ROOT / 'AGENTS.md')
assert gov == {'bytes': 12047, 'sha256':
               '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'}
index = TARGET / 'SOURCE-NATIVE-PACKETS-01.json'
assert pin(index)['sha256'] == 'f82843504a72d349a5f0dadcf533665168d4d0a025e12b7550aa356bdcb25524'
indexed = json.loads(index.read_text(encoding='utf-8'))['files']
immutable_names = list(indexed) + ['INDEX.md', 'SOURCE-NATIVE-PACKETS-01.json',
                                 'SHA256SUMS.txt']
immutable = {name: pin(TARGET / name) for name in immutable_names}
for name, row in indexed.items():
    assert immutable[name] == row, name
assert len(indexed) == 15

manifest_file = REVIEW / 'EVIDENCE-MANIFEST.json'
assert pin(manifest_file)['sha256'] == 'c5cd52615aa4943107bd94508621930d23efcbcc41c569c0003194e3889be224'
assert pin(REVIEW / 'REVIEW-01.md')['sha256'] == 'b36dac2b9f10802758ea8356b80d6fb0fe6a04287f611c0696c18cb61eca58fc'
assert pin(REVIEW / 'SHA256SUMS.txt')['sha256'] == '48a413e7ded8946f5bac65e46746283ad5fdc1df232cd4f6f41c7aaacd7e189a'
manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
for name, expected in manifest['files'].items():
    safe_member(name)
    assert pin(REVIEW / name) == expected, name
assert len(manifest['files']) == 77
review_names = list(manifest['files']) + manifest['excluded_sealing_metadata']
review_packet = archive('reviews/PUBLICATION-REVIEW-01.zip', REVIEW, review_names)

checks = json.loads((HERE / 'PUBLICATION-CHECKS-02.json').read_text(encoding='utf-8'))
assert checks['source_inputs'] == 2995 and not checks['source_mismatches']
assert checks['links_errors'] == 0
links = json.loads((HERE / 'MARKDOWN-LINKS-02.json').read_text(encoding='utf-8'))
assert links['files'] == 695 and links['links'] == 3171 and not links['errors']
for name in (
    'docs/status/CURRENT_VERSION.md', 'docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md',
    'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-TASK-01.md',
    'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-VERIFICATION-01.md',
    'docs/work/v1.8.0-c16a-save-guard/lifecycle-01/INDEX.md',
    'docs/work/v1.8.0-c16a-save-guard/lifecycle-01/COMPANION-LOCATORS-01.md',
):
    assert pin(ROOT / name)['sha256'] == links['doc_sha256'][name], name

checkpoint = HERE / 'PUBLICATION-PRESEAL-01.json'
assert not checkpoint.exists()
checkpoint.write_text(json.dumps({
    'head': HEAD, 'AGENTS_unchanged': gov,
    'immutable_source_native_files': immutable,
    'new_review_packet': review_packet,
    'C_cleanup_completed': False, 'required_gates_passed': False,
    'private_directory_read': False,
}, indent=2, sort_keys=True) + '\n', encoding='utf-8')

# Only this task's direct bounded receipts, never process inventory or runtime.
names = [
    'C-CLEANUP-TOOL-FAILURE-01.md', 'C-SCRIPT-PRECHECK-01.json',
    'C-TEMP-ROOT-CANDIDATES-01.json', 'MARKDOWN-LINKS-01.json',
    'MARKDOWN-LINKS-02.json', 'NATIVE03-PACKETS-01.json',
    'PUBLICATION-CHECKS-01.json', 'PUBLICATION-CHECKS-02.json',
    'PUBLICATION-RUNNER-02.json', 'PUBLICATION-TOOLING-NOTES-01.md',
    'SETUP03-FINAL-POSTCHECK-01.json', 'SETUP03-FINAL-POSTCHECK-02.json',
    'run_publication_checks01.py', 'run_publication_checks02.py',
    'seal_native03_packets01.py', 'seal-native03-01.exit',
    'seal-native03-01.log', 'write_packet_index01.py',
    'seal_publication01.py', 'PUBLICATION-PRESEAL-01.json',
]
for stage in ('01', '02'):
    for job in ('planning', 'ledger-strict', 'ledger-closure',
                'generated-diff', 'diff-check', 'global-dirty-diff'):
        names += [f'{job}-publication{stage}.command.json',
                  f'{job}-publication{stage}.log']
root_packet = archive('ROOT-PUBLICATION-01.zip', HERE, names)
assert {name: pin(TARGET / name) for name in immutable_names} == immutable
assert pin(ROOT / 'AGENTS.md') == gov
total = sum(file.stat().st_size for file in TARGET.rglob('*') if file.is_file())
assert total <= 100_000_000
assert git('rev-parse', 'HEAD') == HEAD and not git('diff', '--cached', '--name-only')
result = HERE / 'PUBLICATION-PACKETS-01.json'
assert not result.exists()
result.write_text(json.dumps({
    'packets': [review_packet, root_packet], 'leaf_bytes': total,
    'immutable_source_native_files_unchanged': True,
    'private_directory_read': False, 'C_cleanup_completed': False,
    'required_gates_passed': False,
}, indent=2) + '\n', encoding='utf-8')
print(result.read_text(encoding='utf-8'), flush=True)
