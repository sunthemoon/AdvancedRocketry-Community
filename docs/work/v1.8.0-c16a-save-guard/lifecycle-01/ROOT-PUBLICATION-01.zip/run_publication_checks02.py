"""Run a separately numbered final postimage; retain the original checks untouched."""
import hashlib
import json
from pathlib import Path
here=Path(__file__).parent
original=here/'run_publication_checks01.py'
body=original.read_text(encoding='utf-8')
replacements={
    'SETUP03-FINAL-POSTCHECK-01.json':'SETUP03-FINAL-POSTCHECK-02.json',
    'MARKDOWN-LINKS-01.json':'MARKDOWN-LINKS-02.json',
    'PUBLICATION-CHECKS-01.json':'PUBLICATION-CHECKS-02.json',
    'planning-publication01':'planning-publication02',
    'ledger-strict-publication01':'ledger-strict-publication02',
    'ledger-closure-publication01':'ledger-closure-publication02',
    'generated-diff-publication01':'generated-diff-publication02',
    'diff-check-publication01':'diff-check-publication02',
    'global-dirty-diff-publication01':'global-dirty-diff-publication02',
}
for old,new in replacements.items():
    assert body.count(old)==1,old
    body=body.replace(old,new)
anchor='broken,count=markdown_link_errors(ROOT,list(paths))'
assert body.count(anchor)==1
body=body.replace(anchor,"paths.add(ROOT/'docs/work/v1.8.0-c16a-save-guard/lifecycle-01/COMPANION-LOCATORS-01.md')\n"+anchor)
(here/'PUBLICATION-RUNNER-02.json').write_text(json.dumps({'original_script_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'output_name_replacements':replacements,'one_added_document':'COMPANION-LOCATORS-01.md','virtual_postimage_sha256':hashlib.sha256(body.encode()).hexdigest()},indent=2)+'\n',encoding='utf-8')
exec(compile(body,str(here/'run_publication_checks02.virtual.py'),'exec'),{'__file__':str(original),'__name__':'__main__'})
