"""Final document/source checks; keep open global/closure results nonzero."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
HERE=Path(__file__).parent
temp=HERE/'tmp'; temp.mkdir(exist_ok=True)
for name in ('TEMP','TMP','TMPDIR'): os.environ[name]=str(temp)
sys.path.insert(0,str(ROOT))
from scripts.validate_repository import markdown_link_errors
manifest=json.loads(Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/SETUP03-MANIFEST-01.json').read_text(encoding='utf-8'))
changed=[name for name,row in manifest.items() if (ROOT/name).stat().st_size!=row['bytes'] or hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=row['sha256']]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
(HERE/'SETUP03-FINAL-POSTCHECK-01.json').write_text(json.dumps({'named_inputs':len(manifest),'mismatches':changed,'current_head':head,'source_code_unchanged':not changed,'private_directory_read':False},indent=2)+'\n',encoding='utf-8')
paths={ROOT/name for name in subprocess.check_output(['git','ls-files','*.md'],cwd=ROOT,text=True).splitlines()}
paths.add(ROOT/'docs/work/v1.8.0-c16a-save-guard/NATIVE-LIFECYCLE-VERIFICATION-01.md')
paths.add(ROOT/'docs/work/v1.8.0-c16a-save-guard/lifecycle-01/INDEX.md')
broken,count=markdown_link_errors(ROOT,list(paths))
links={'files':len(paths),'links':count,'errors':broken,'doc_sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},'private_directory_read':False}
(HERE/'MARKDOWN-LINKS-01.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:links[k] for k in ('files','links','errors')}),flush=True)
rows=[]
jobs=[
 ('planning-publication01',[sys.executable,'-B','scripts/validate_v1plus_planning.py']),
 ('ledger-strict-publication01',[sys.executable,'-B','scripts/validate_v180_content_ledger.py','--require-accepted']),
 ('ledger-closure-publication01',[sys.executable,'-B','scripts/validate_v180_content_ledger.py','--closure']),
 ('generated-diff-publication01',['git','diff','--exit-code','--','src/generated']),
 ('diff-check-publication01',['git','diff','--check']),
 ('global-dirty-diff-publication01',['git','diff','--exit-code']),
]
for name,command in jobs:
    started=datetime.datetime.now(datetime.timezone.utc)
    log=HERE/(name+'.log'); assert not log.exists()
    (HERE/(name+'.command.json')).write_text(json.dumps({'command':command,'cwd':str(ROOT),'started_utc':started.isoformat(),'TEMP':str(temp)},indent=2)+'\n',encoding='utf-8')
    with log.open('xb') as output:
        result=subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
    row={'name':name,'exit':result.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'elapsed_seconds':(datetime.datetime.now(datetime.timezone.utc)-started).total_seconds()}
    rows.append(row);print(json.dumps(row),flush=True)
unexpected=[r for r in rows if r['exit']!=(1 if r['name'].startswith(('ledger-closure','global-dirty')) else 0)]
(HERE/'PUBLICATION-CHECKS-01.json').write_text(json.dumps({'jobs':rows,'source_inputs':len(manifest),'source_mismatches':changed,'links_errors':len(broken),'required_gates_passed':False,'C_cleanup_completed':False},indent=2)+'\n',encoding='utf-8')
sys.exit(bool(changed or broken or unexpected))
