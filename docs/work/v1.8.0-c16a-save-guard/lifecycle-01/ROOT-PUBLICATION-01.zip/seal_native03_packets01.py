"""Add new bounded packets, leaving every earlier sealed packet unchanged."""
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
HERE=Path(__file__).parent
OLD=Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01')
BASE=OLD.parent
TARGET=ROOT/'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'
def sha(data): return hashlib.sha256(data).hexdigest()
def archive(name,source,paths):
    out=TARGET/name; out.parent.mkdir(parents=True,exist_ok=True)
    assert not out.exists(),name
    entries={}
    with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(set(paths)):
            rel=path.relative_to(source).as_posix(); p=PurePosixPath(rel)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in rel,rel
            assert path.is_file() and not path.is_symlink(),rel
            data=path.read_bytes(); assert len(data)<=50_000_000,rel
            entries[rel]={'bytes':len(data),'sha256':sha(data)}; z.writestr(rel,data)
        assert sum(x['bytes'] for x in entries.values())<=100_000_000
        z.writestr('ROOT-COPY-MANIFEST-01.json',json.dumps({'scope':'Packet-local copies; no Gate or native PASS','files':entries},indent=2,sort_keys=True)+'\n')
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        for rel,row in entries.items():
            data=z.read(rel); assert len(data)==row['bytes'] and sha(data)==row['sha256'],rel
    assert out.stat().st_size<=50_000_000
    return {'path':out.relative_to(ROOT).as_posix(),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'payloads':len(entries),'payload_bytes':sum(x['bytes'] for x in entries.values())}

paths=[]
for p in OLD.iterdir():
    if p.is_file() and (p.name.startswith(('SETUP03','native-03','NATIVE-PRECHECK-03','NATIVE-POSTCHECK-03','python-regression-07','python-regression-08','SOURCE-COMMIT-03','SOURCE-COMMIT-PUSH-03','source-add-03','source-index-check-03','source-commit-03','source-push-03')) or p.name in ('run_native03.py','commit_source03.py')):
        paths.append(p)
for p in (OLD/'native-03').iterdir():
    if p.is_file(): paths.append(p)
folder=OLD/'native-03/removal-availability-reload'
paths.extend(p for p in folder.iterdir() if p.is_file())
rows=[archive('ROOT-NATIVE03-COMPACT-01.zip',OLD,paths)]
for directory,manifest,name in [
 ('agnf-1b7aa2336c','INTERNAL-MANIFEST.json','LIFECYCLE-PRIMARY-02.zip'),
 ('agsr3-6746c51d09','INTERNAL-MANIFEST.json','COPIED-SPAWN-SOURCE-01.zip'),
 ('agla3-8073c3e4c2','INTERNAL-MANIFEST.json','NATIVE-FAILURE-03.zip'),
 ('agn3-bcad519a7e','INTERNAL-MANIFEST.json','LIFECYCLE-PRIMARY-03.zip'),
]:
    source=BASE/directory; m=json.loads((source/manifest).read_text(encoding='utf-8'))
    paths=[]
    for rel,row in m['files'].items():
        p=PurePosixPath(rel); assert not p.is_absolute() and '..' not in p.parts,rel
        file=source/rel; raw=file.read_bytes()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],rel
        paths.append(file)
    paths.append(source/manifest)
    for companion in ('SHA256SUMS','SHA256SUMS.txt','checksums.txt','FREEZE-RESULT-01.json','FREEZE-01.json'):
        file=source/companion
        if file.is_file(): paths.append(file)
    row=archive('reviews/'+name,source,paths)
    row.update(original_directory=str(source),original_manifest_sha256=sha((source/manifest).read_bytes()))
    rows.append(row)
paths=[HERE/name for name in ('C-TEMP-ROOT-CANDIDATES-01.json','C-SCRIPT-PRECHECK-01.json','C-CLEANUP-TOOL-FAILURE-01.md')]
rows.append(archive('C-CLEANUP-DISPOSITION-01.zip',HERE,paths))
assert sum(x.stat().st_size for x in TARGET.rglob('*') if x.is_file())<=100_000_000
result=HERE/'NATIVE03-PACKETS-01.json'; assert not result.exists()
result.write_text(json.dumps({'packets':rows,'prior_packets_and_originals_modified':False,'cleanup_completed':False,'gate_claimed':False},indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2),flush=True)
