# Explicitly requested C-drive script cleanup: tool rejection

On 2026-10-04 the owner requests cleanup of temporary test scripts from C and
directs future temporary scripts/output to the project's parent directory.
The new approved working location is `D:/GitHub/ARCE-Task-Evidence`.
Source: the owner's message in this conversation on that date, verbatim:
"c盘塞的临时的测试脚本别忘了清理了后面放到当前项目父母录下，及时清理".
Scope: owned temporary test scripts/output, not unrelated tasks, sealed evidence,
source worlds, global environment/registry or user-maintained AGENTS.md.

Root's read-only precheck identifies eleven direct script/probe files totalling
24,930 bytes in exactly two older Root task directories. The precheck records
resolved C paths, exact SHA-256 and proposed parent-directory backup paths.
Their direct parent directories have no reparse flag or evidence checksum/seal
file. Current tasks report no C output; unrelated earlier Java processes and
OpenPet processes are not terminated or modified.

The requested PowerShell command would verify each exact path/hash, copy and
verify the eleven backup files, check named active processes, and remove only
those individual files with literal paths. The execution tool rejects the
**entire command before OS execution**, with `blocked by policy`.

Therefore no backup, removal, active-task check or cleanup result from that
command is claimed. The C scripts remain. No alternate deletion mechanism is
attempted. The successful read-only precheck and unrelated process inventory
remain separate from this transcribed tool rejection. Old logs, worlds,
sealed originals and unallocated other-agent temporary directories are intact.

Future helpers and publication records already use the requested D project-
parent location. C cleanup and older stopped D runtime-copy cleanup remain
open storage work, not completed milestones or Required Gate evidence.
