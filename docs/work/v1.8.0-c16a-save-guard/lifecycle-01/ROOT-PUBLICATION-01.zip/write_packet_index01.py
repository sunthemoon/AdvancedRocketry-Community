"""Create an index for the immutable source/native packets, not self-review metadata."""
import hashlib
import json
from pathlib import Path
ROOT=Path('D:/GitHub/AdvancedRocketry-Community')
HERE=Path(__file__).parent
TARGET=ROOT/'docs/work/v1.8.0-c16a-save-guard/lifecycle-01'
rows=json.loads(Path('D:/ARCE-Task-Evidence/v1.8.0/guard-lifecycle-01/SOURCE23-PACKETS-01.json').read_text(encoding='utf-8'))['packets']
rows+=json.loads((HERE/'NATIVE03-PACKETS-01.json').read_text(encoding='utf-8'))['packets']
entries={}
lines=['# Bounded guard lifecycle source/native evidence index','',
       'Source/tool phases are pushed at `a382e36e`, `23bec1eb` and `f945dc1c`.',
       'The Source23 build passes; **all three native lifecycle attempts fail**.',
       'Stopped-record retention is not live restoration, clean stop or restart.',
       'No new save writer, risk acceptance, Required Gate, tag or release is admitted.','',
       'Each ZIP adds a packet-local copy manifest and preserves original audit',
       'manifests/checksums. No complete source tree, JAR, runtime/world or region',
       'export is included. Originals and earlier sealed packets are unchanged.',
       'The source/native index excludes later standalone documentation-review',
       'and publication-receipt files to avoid self-referential manifests.','',
       '| Packet | Bytes | SHA-256 |','|---|---:|---|']
for row in rows:
    path=ROOT/row['path']; raw=path.read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    rel=path.relative_to(TARGET).as_posix(); assert rel not in entries
    entries[rel]={'bytes':len(raw),'sha256':row['sha256']}
    lines.append(f"| [{rel}]({rel}) | {len(raw)} | `{row['sha256']}` |")
total=sum(row['bytes'] for row in entries.values())
assert len(entries)==15 and total<=100_000_000
lines+=['',f'15 indexed source/native packets total {total:,} bytes.',
        'Each file is below 50 MB; this task packet slice is below 100 MB.',
        'These limits do not resolve the previously documented oversized legacy',
        'evidence debt in other slices.','',
        'The C cleanup disposition records the exact owner directive and checked',
        'script targets. The removal tool rejected the whole command before OS',
        'execution: **no C script deletion or backup is claimed**. Future temporary',
        'helpers/output use `D:/GitHub/ARCE-Task-Evidence`, with process-local',
        'TEMP/TMP settings. No global environment or unrelated task is modified.','',
        'Current qualification: [verification](../NATIVE-LIFECYCLE-VERIFICATION-01.md).','']
index=TARGET/'INDEX.md'; assert not index.exists()
index.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
manifest=TARGET/'SOURCE-NATIVE-PACKETS-01.json'; assert not manifest.exists()
manifest.write_text(json.dumps({'scope':'15 source/native packets; later publication artifacts excluded','files':entries,'total_bytes':total,'required_gates_passed':False,'cleanup_completed':False},indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
checks=TARGET/'SHA256SUMS.txt'; assert not checks.exists()
check_files=[TARGET/rel for rel in entries]+[index,manifest]
checks.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(TARGET).as_posix()+'\n' for p in sorted(check_files)),encoding='utf-8',newline='\n')
print(json.dumps({'packets':len(entries),'bytes':total,'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}),flush=True)
