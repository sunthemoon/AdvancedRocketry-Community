# Original collector failure

Actual `python -B .../run_build23.py` execution exits 1 after both Gradle jobs
exit 0. Its output is captured by the Root exec/write_stdin tool, not a separate
raw outer-output file. The build and GameTest commands have their own unchanged
raw logs and result receipts: 202.70069019997027 and 230.57891550008208 seconds.

The collector then used the wrong `run/gameTestServer/logs/latest.log` location
and raised FileNotFoundError at line 80. Actual build.gradle:84 uses
`build/gametest`. The original collector is preserved unchanged; no Gradle
failure is converted to PASS, and no original native log capture is claimed.

The separate collect_build23_02.py copies the real log from the configured
directory and independently checks source/old JAR members. Its command result
is separate evidence, not a rewrite of this failed collector attempt.
