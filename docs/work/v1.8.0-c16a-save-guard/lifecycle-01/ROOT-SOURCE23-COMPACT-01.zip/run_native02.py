"""Root fresh native command for the separately built unload observer."""
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/integration-072fbcf821ce4ceb9fbcb3d98ec27d41')
SERVER = OLD / 'tank-native-06/server'
JAR = OUT / 'artifacts23-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'
fixture = SERVER / 'mods/arce-adapter-compat-test-1.0.0.jar'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

inputs = json.loads((OUT / 'SOURCE23-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, row in inputs.items():
    path = ROOT / name
    assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], name
assert digest(JAR) == '5fd2a23dd02c8c4977efe9c03628edfe4c517bc1d3d02ba0e846aa89649aeee9'
assert digest(fixture) == '765735d1254ed6f66049f45cc740208882195bff7a00bfd29e2245e264976fa4'
libraries = json.loads((OUT / 'LIBRARIES-INPUTS-01.json').read_text(encoding='utf-8'))
for name, row in libraries.items():
    path = SERVER / 'libraries' / name
    assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], name
sys.path.insert(0, str(ROOT))
from scripts import run_v180_guard_lifecycle_smoke as guard
record = guard.saved_record(SERVER / 'world')
assert len(record) == 5898 and hashlib.sha256(record).hexdigest() == 'd9b170538589303c92cef7a2430407ed20f790c23df4e80da30388434ea54ea8'
guard.check_fixture(guard.regions._decode_chunk(record, *guard.CHUNK))
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
write('NATIVE-PRECHECK-02.json', {'inputs_unchanged': len(inputs), 'free_bytes': free,
                               'threshold_bytes': 10000000000, 'main_jar_sha256': digest(JAR)})
assert all(value >= 10000000000 for value in free.values())
command = [sys.executable, '-B', 'scripts/run_v180_guard_lifecycle_smoke.py',
           '--runtime-template', str(SERVER), '--source-world', str(SERVER / 'world'),
           '--host-jar', str(JAR), '--fixture-jar', str(fixture),
           '--work-root', str(OUT / 'native-02'), '--java', 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
write('NATIVE-COMMAND-02.json', {'command': command, 'cwd': str(ROOT), 'started_utc': started})
start = time.monotonic()
with (OUT / 'native-02.log').open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
write('NATIVE-RESULT-02.json', {'command': command, 'exit_code': result.returncode,
                             'elapsed_seconds': time.monotonic() - start, 'started_utc': started,
                             'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
post = {
    'source23_inputs_unchanged': all((ROOT / name).stat().st_size == row['bytes']
                                   and digest(ROOT / name) == row['sha256'] for name, row in inputs.items()),
    'source_libraries_unchanged': all((SERVER / 'libraries' / name).stat().st_size == row['bytes']
                                    and digest(SERVER / 'libraries' / name) == row['sha256']
                                    for name, row in libraries.items()),
}
write('NATIVE-POSTCHECK-02.json', post)
assert all(post.values()), post
print((OUT / 'native-02.log').read_text(encoding='utf-8'))
sys.exit(result.returncode)
