"""Publish only the reviewed observation/tooling source, not native delivery."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
scope = {
    'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java': 'a426612fd9986b871d7930fa413b8ad0ade1e994d911c901c3f87e3b313fdd87',
    'scripts/run_v180_guard_lifecycle_smoke.py': '544e25035fe5554994bc812727ed0bbe6e5d5e24a0165607f4d95b1dd0e67a30',
    'tests/test_run_v180_guard_lifecycle_smoke.py': '3fa8716ed3682b94b750e533d2b7462266a0912246079b74e8ae5985b2737ea9',
    'docs/work/v1.8.0-c16a-save-guard/UNLOAD-OBSERVATION-AMENDMENT-01.md': '9410a63e79f06f5dcfae485d4a364ff41eb4835bd7e4585bc476f626a36e9ef7',
}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root).strip()
for name, digest in scope.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
assert hashlib.sha256((root/'AGENTS.md').read_bytes()).hexdigest() == '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
rows=[]
def run(label, command):
    log=here/(label+'.log'); assert not log.exists()
    result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log.write_bytes(result.stdout)
    rows.append({'command':command,'exit':result.returncode,'log':log.name,'log_sha256':hashlib.sha256(result.stdout).hexdigest()})
    (here/'SOURCE-COMMIT-02.json').write_text(json.dumps({'scope':scope,'commands':rows,'native_result':'FAIL; not runtime delivery'},indent=2)+'\n',encoding='utf-8')
    print(result.stdout.decode('utf-8',errors='replace'),flush=True)
    assert result.returncode==0, label
run('source-add-02',['git','add','--',*scope])
staged=set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())
assert staged==set(scope),staged
for name,digest in scope.items():
    assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=root)).hexdigest()==digest,name
run('source-index-check-02',['git','diff','--cached','--check'])
run('source-commit-02',['git','commit','-m','test(persistence): observe actual guarded chunk unload'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
run('source-push-02',['git','push','origin','HEAD:codex/v1.8.0-classic-content'])
remote=subprocess.check_output(['git','rev-parse','origin/codex/v1.8.0-classic-content'],cwd=root,text=True).strip()
assert head==remote
(here/'SOURCE-COMMIT-PUSH-02.json').write_text(json.dumps({'commit':head,'origin_tracking':remote,'scope':scope,'commands':rows,'source_review_sha256':'78f7e97826d3e3d9d87419b55b18e530604c2c2eaf7d671ef736a1452aca4b2e','native_result':'FAIL; not runtime delivery','gate_claimed':False},indent=2)+'\n',encoding='utf-8')
print(head,flush=True)
