"""Separate correct-path capture; never changes the original command collector."""
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
OLD = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01/artifacts')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

assert json.loads((OUT / 'gametest23-01-result.json').read_text())['exit_code'] == 0
native = ROOT / 'build/gametest/logs/latest.log'
shutil.copyfile(native, OUT / 'gametest23-native-02.log')
comparisons = {}
for current in sorted((OUT / 'artifacts23-01').glob('*.jar')):
    old = OLD / current.name
    with zipfile.ZipFile(old) as before, zipfile.ZipFile(current) as after:
        a, b = set(before.namelist()), set(after.namelist())
        removed = sorted(a - b)
        changed = sorted(name for name in a & b if before.read(name) != after.read(name))
        comparisons[current.name] = {'added': sorted(b - a), 'removed': removed, 'changed': changed,
                                     'members': len(b), 'sha256': digest(current),
                                     'whole_bytes_unchanged': digest(old) == digest(current)}
        assert not removed and not changed, comparisons[current.name]
write('ARTIFACTS23-COMPARISON-01.json', comparisons)
inputs = json.loads((OUT / 'SOURCE23-MANIFEST-01.json').read_text(encoding='utf-8'))
different = []
for name, row in inputs.items():
    path = ROOT / name
    if path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
        different.append(name)
write('SOURCE23-POSTCHECK-02.json', {'inputs': len(inputs), 'mismatches': different, 'unchanged': not different})
assert not different
gradle_lines = (OUT / 'gametest23-01.log').read_text(encoding='utf-8').splitlines()
native_lines = native.read_text(encoding='utf-8').splitlines()
summary = {'gradle_markers': [line for line in gradle_lines if 'tests done' in line or 'required tests passed' in line],
           'native_markers': [line for line in native_lines if 'tests done' in line or 'required tests passed' in line],
           'gradle_error_headers': sum(bool(re.search(r'\[[^\]]+/ERROR\]', line)) for line in gradle_lines),
           'native_error_headers': sum(bool(re.search(r'\[[^\]]+/ERROR\]', line)) for line in native_lines),
           'interpretation': 'Marker excerpts are qualified by independent audit; no blanket log waiver'}
write('GAMETEST23-CAPTURE-02.json', summary)
print(json.dumps(summary, indent=2))
