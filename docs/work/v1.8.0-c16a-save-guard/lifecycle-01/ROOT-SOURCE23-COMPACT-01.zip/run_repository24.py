import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('D:/GitHub/AdvancedRocketry-Community')
here = Path(__file__).parent
command = [sys.executable, '-B', str(here / 'validate_repository_boundary24.py')]
start = datetime.datetime.now(datetime.timezone.utc)
pins = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
        for name in ('AGENTS.md', 'docs/11-RISK-REGISTER.md', 'scripts/validate_repository.py')}
for name in ('repository-boundary-24.log', 'repository-boundary-24.command.json', 'repository-boundary-24.result.json'):
    assert not (here / name).exists(), name
(here / 'repository-boundary-24.command.json').write_text(json.dumps({
    'command': command, 'cwd': str(root), 'started_utc': start.isoformat(),
    'governance_and_validator_pins': pins, 'private_directory_read_or_walked': False}, indent=2) + '\n', encoding='utf-8')
with (here / 'repository-boundary-24.log').open('xb') as output:
    result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
post = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in pins}
receipt = {'exit': result.returncode, 'elapsed_seconds': (datetime.datetime.now(datetime.timezone.utc)-start).total_seconds(),
           'log_sha256': hashlib.sha256((here / 'repository-boundary-24.log').read_bytes()).hexdigest(),
           'governance_and_validator_postpins': post, 'pinned_inputs_unchanged': post == pins, 'gate_claim': False}
(here / 'repository-boundary-24.result.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt), flush=True)
sys.exit(result.returncode if result.returncode else int(post != pins))
