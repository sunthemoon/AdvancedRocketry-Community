"""Root source-pinned build and GameTest command receipts."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = Path('D:/ARCE-Task-Evidence/v1.8.0/k3-integration-01')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

inputs = json.loads((BASE / 'SOURCE22-MANIFEST-01.json').read_text(encoding='utf-8'))
for name, row in inputs.items():
    assert (ROOT / name).stat().st_size == row['bytes'] and digest(ROOT / name) == row['sha256'], name
new = ['src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/GuardedChunkUnloadObservation.java',
       'scripts/run_v180_guard_lifecycle_smoke.py', 'tests/test_run_v180_guard_lifecycle_smoke.py']
for name in new:
    assert name not in inputs
    path = ROOT / name
    inputs[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
write('SOURCE23-MANIFEST-01.json', inputs)
write('SOURCE23-BOUNDARY-01.json', {'baseline_commit': 'a382e36e4e1ce5949bb9cc9c9ab3517ebfd9d0ce',
                                 'previous_build_inputs': len(inputs) - len(new), 'new_inputs': new,
                                 'boundary': 'Declared build/tool inputs, not entire tracked repository'})
env = os.environ.copy()
env['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
env['PATH'] = env['JAVA_HOME'] + '/bin;' + env['PATH']
flags = ['--offline', '--no-daemon', '--max-workers=2', '-Dorg.gradle.jvmargs=-Xmx2G']

def run(name, args):
    free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
    write(name + '-disk-precheck.json', {'free_bytes': free, 'threshold_bytes': 10000000000})
    assert all(value >= 10000000000 for value in free.values())
    command = [str(ROOT / 'gradlew.bat')] + flags + args
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(name + '-command.json', {'command': command, 'cwd': str(ROOT), 'started_utc': started,
                                'java_home': env['JAVA_HOME']})
    start = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    write(name + '-result.json', {'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
                               'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(name, 'exit', result.returncode, flush=True)
    if result.returncode:
        print((OUT / (name + '.log')).read_text(encoding='utf-8', errors='replace')[-6000:], flush=True)
        sys.exit(result.returncode)

run('build23-01', ['clean', 'build', 'test', 'runData'])
results = OUT / 'junit23-01'
results.mkdir()
totals = dict(tests=0, failures=0, errors=0, skipped=0, suites=0)
for path in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
    row = ET.parse(path).getroot()
    totals['suites'] += 1
    for key in ('tests', 'failures', 'errors', 'skipped'):
        totals[key] += int(row.get(key, '0'))
    shutil.copyfile(path, results / path.name)
write('JUNIT23-RESULT-01.json', totals)
artifacts = OUT / 'artifacts23-01'
artifacts.mkdir()
rows = []
for path in sorted((ROOT / 'build/libs').glob('*.jar')):
    target = artifacts / path.name
    shutil.copyfile(path, target)
    rows.append({'path': str(target), 'bytes': target.stat().st_size, 'sha256': digest(target)})
write('ARTIFACTS23-01.json', rows)
run('gametest23-01', ['runGameTestServer'])
shutil.copyfile(ROOT / 'run/gameTestServer/logs/latest.log', OUT / 'gametest23-native-01.log')
post = {name: {'bytes': (ROOT / name).stat().st_size, 'sha256': digest(ROOT / name)} for name in inputs}
write('SOURCE23-POSTCHECK-01.json', {'inputs': len(inputs), 'unchanged': post == inputs})
assert post == inputs
print(totals, flush=True)
