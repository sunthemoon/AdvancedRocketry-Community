# Owned runtime cleanup unavailable

Root requested PowerShell-only cleanup of its finished native-01/server copy
after the independent failed-run audit froze. The command checked the resolved
absolute target inside this task's exact named directory and the absence of
its active Java command before a literal-path Remove-Item.

The exec tool rejected the whole command before OS execution with "blocked by
policy". No path check, process read, cleanup receipt or delete from that command
ran. No alternate deletion mechanism was attempted. The stopped disposable
copy remains local and is excluded from all Git evidence packets. Source worlds
and sealed prior evidence are untouched. This is remaining cleanup debt, not a
successful deletion or evidence-storage Gate.
