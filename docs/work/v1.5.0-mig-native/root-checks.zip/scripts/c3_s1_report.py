"""ADR-046 S1 subset report from the native C3 run. Usage: c3_s1_report.py <attempt dir> <out.md>."""
import json
import sys
from pathlib import Path

attempt = Path(sys.argv[1])
out = Path(sys.argv[2])
native = attempt / 'native'
summary = json.loads((native / 'summary.json').read_text(encoding='utf-8'))
inputs = json.loads((native / 'inputs.json').read_text(encoding='utf-8'))
upgrade = next(c for c in summary['cycles'] if c['phase'] == 'upgrade')
rows = upgrade['observations']['s1']
host = next(a for a in inputs['artifacts'] if a['version'] == '1.20.1-1.5.0-dev')
consumer = [a for a in inputs['artifacts'] if a['name'].startswith('arce-adapter')][-1]
EXPECTED = {
    'invite': 'owner allowed; member refused',
    'accept': 'the invited player only',
    'expand': 'owner allowed (confirmation issued); everyone else UNAUTHORIZED',
    'warp': 'owner reaches the quote (balance 0: energy does not cover the cost); everyone else UNAUTHORIZED',
    'status': 'owner and member; invitee and outsider refused',
    'remove': 'owner allowed',
    'remove_uuid': 'owner allowed; member refused',
    'admin': 'no player reaches the admin command; the console does',
}
w = []
w.append('# v1.5 multiplayer permission report: S1 subset (native, development copy)')
w.append('')
w.append('ADR-046 UI-03, level S1: a named subset of the matrix on the packaged JAR and a native')
w.append('dedicated server, with the fixture probe\'s connected players. It complements the A1')
w.append('report ([PERMISSION-MATRIX.md](../v1.5.0-elevator-ui/PERMISSION-MATRIX.md)). V2 (two')
w.append('real clients) stays open for ACC-02. This is evidence for the maintainer, **not a Gate')
w.append('approval**.')
w.append('')
w.append('## Identity')
w.append('')
w.append(f"- Host `{host['name']}`, SHA-256 `{host['sha256']}` (the JAR of full run 02).")
w.append(f"- Fixture `{consumer['name']}`, SHA-256 `{consumer['sha256']}`, built from `src/adapterTest`.")
w.append('- Minecraft 1.20.1, Forge 47.4.10, Java 17.0.7, native dedicated server; phase `upgrade` of')
w.append('  `native_mig_c3_check.py` (attempt 10), exit 0.')
w.append(f"- Station: MIG-A `{summary['stations']['A']}`, created by the v1.4 host and upgraded to root 4.")
w.append('')
w.append('## Actors')
w.append('')
w.append('| Actor | Construction |')
w.append('|---|---|')
w.append('| owner | probe player 0, the station\'s owner (v1.4-created), on the platform |')
w.append('| member | probe player 1, invited natively by the owner and accepted |')
w.append('| invitee | probe player 2, invited natively by the owner |')
w.append('| outsider | probe player 3, no relation |')
w.append('| console | the server console (operator) |')
w.append('')
w.append('All four players are connected over embedded channels, stand on the platform and issue')
w.append('the commands from their own sources. Every player command left the loaded chunk count')
w.append('unchanged (checked by the harness for each run).')
w.append('')
w.append('## Cells (in execution order)')
w.append('')
w.append('| # | Action | Actor | Command | Result | Last reply | Expected | Pass |')
w.append('|---|---|---|---|---|---|---|---|')
for index, row in enumerate(rows, 1):
    reply = (row['replies'][-1] if row['replies'] else (row.get('error') or '')).replace('|', '/')
    if len(reply) > 110:
        reply = reply[:107] + '...'
    w.append(f"| {index} | {row['action']} | {row['actor']} | `{row['command']}` | {row['result']} | {reply} | "
             f"{EXPECTED.get(row['action'], '')} | {'PASS' if row['pass'] else 'FAIL'} |")
w.append('| - | admin | console | `arce station admin inspect <A>` | 1 | region=... pad=... | operator allowed | PASS |')
w.append('')
w.append(f"Totals: {len(rows) + 1} cells, {sum(1 for r in rows if r['pass']) + 1} PASS, "
         f"{sum(1 for r in rows if not r['pass'])} FAIL.")
w.append('')
w.append('A non-operator\'s admin command fails at parse ("Incorrect argument for command ... station"),')
w.append('so the `admin` node is not reachable for them. The warp `status` for a member and the')
w.append('refusals name their reason in the reply.')
w.append('')
w.append('This report is not a Gate approval.')
out.write_text('\n'.join(w) + '\n', encoding='utf-8', newline='\n')
print('rows', len(rows))
