"""V150-MIG-01b, V150-MIG-02 and the ADR-046 S1 subset, natively, on a COPY of the retained v1.4 world.

Finite dedicated-server processes; the source world is never modified.

1. legacy (v1.4 host, release-test hooks): the v1.4 host creates two Earth-orbit stations, A and C,
   assembles two rockets on Earth and flies them to the stations. R1 stays docked at A. R2 departs
   from C to Earth and is frozen at DESTINATION_SPAWNED; after a durable save the process is killed.
   The world now holds a docked rocket and an in-flight transfer that both touch stations.
2. upgrade (v1.5 host and fixture probe): the pre-start migration upgrades the stations to root 4.
   Recovery completes R2's transfer once both ends are loaded, with no duplicate and the same
   logical identity; R1 is unchanged. S1: owner, member, invitee and outsider (connected probe
   players) on expand, warp request and status, invite and remove, and an admin command. The owner
   then warps A (with R1 docked) to the Moon through the real countdown.
3. concurrent: restart; R1 and A persisted. A (to Earth) and C (to the Moon) are confirmed together
   and both commit, each charged once. A third countdown is started and the process is killed.
4. interrupted: the killed countdown neither warped nor charged. A warp of C commits, and the process
   is killed right after the commit line.
5. final: the killed commit is complete (orbit and debit); R1's identity, fuel and position are
   unchanged through every step; no unclassified transfer record remains.

No real clients (V2), crash cuts inside a checked write, or load test.
"""
import copy
import hashlib
import json
import re
import shutil
import sys
import time
import uuid
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402
import run_v060_flight_server_smoke as flight  # noqa: E402
import run_v070_station_server_smoke as stations  # noqa: E402

schema, support, server = fixture.schema, fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json
ROOT = Path(__file__).resolve().parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8')
SOURCE = HISTORY / 'server-final/world'
LEGACY_JAR = HISTORY / 'artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar'
LEGACY_SHA = '576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475'
# The fixture JAR the retained world last ran with; without it the world has unidentified mappings.
LEGACY_CONSUMER = HISTORY / 'server-final/mods/arce-adapter-compat-test-1.0.0.jar'
SERVER = ROOT / 'station-server'
OUT = ROOT / 'native'
HOST = 'advancedrocketrycommunity'
STATION = HOST + '_stations.dat'
TRANSFERS = HOST + '_rocket_transfers.dat'
MANAGED = [HOST + '_' + name + '.dat' for name in
           ('celestial', 'rocket_transactions', 'rocket_transfers', 'stations', 'satellite_missions')]
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
HOST_JAR = REPO / 'build/libs/advancedrocketry-community-1.20.1-1.5.0-dev.jar'
CONSUMER = REPO / 'compat-test-mod/build/libs/arce-adapter-compat-test-1.0.0.jar'
SPACE = HOST + ':space'
OVERWORLD = 'minecraft:overworld'
EARTH, MOON = HOST + ':earth', HOST + ':moon'
PROBE = re.compile(r'ARCE_STATION_PROBE (\{.*\})\s*$')
CREATED = stations.STATION_TRANSACTION_LOG
PER_TICK = 200_000
COST = 2_000_000
OWNER_A = '00000000-0000-0000-0000-0000000c3a01'
MEMBER_A = '00000000-0000-0000-0000-0000000c3a02'
INVITEE_A = '00000000-0000-0000-0000-0000000c3a03'
OUTSIDER = '00000000-0000-0000-0000-0000000c3a04'
OWNER_C = '00000000-0000-0000-0000-0000000c3c01'
EXECUTE_REJECTED = re.compile(r'run this command yourself as a connected player')
UNAUTHORIZED = 'only the owner or an operator standing in the station can manage it'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    require(isinstance(value, list) and len(value) == 4, 'UUID must be an int array')
    return str(uuid.UUID(bytes=b''.join((part & 0xffffffff).to_bytes(4, 'big') for part in value)))


def observe_data(world, directory):
    directory.mkdir(parents=True)
    payloads = {}
    for name in MANAGED:
        source = world / 'data' / name
        if source.exists():
            shutil.copyfile(source, directory / name)
            payloads[name] = schema.read_nbt(directory / name)['data']
    write_json(directory / 'decoded.json', payloads)
    return payloads


def station_record(payload, station_id):
    matches = [s for s in payload['stations'] if nbt_uuid(s['station_id']) == station_id]
    require(len(matches) == 1, 'Station record missing: ' + station_id)
    return matches[0]


def balances(payload):
    return {nbt_uuid(entry['station_id']): entry['energy'] for entry in payload.get('warp_energy', [])}


class Phase:
    def __init__(self, name, artifacts, probe):
        self.name, self.artifacts, self.probe = name, artifacts, probe
        self.directory = OUT / name
        self.commands, self.probes, self.observations = [], [], {}

    def query(self, process, text, pattern, timeout=30):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern, timeout, start_at=start)]

    def probe_report(self, process, text, label):
        line = self.query(process, text, re.compile(r'ARCE_STATION_PROBE \{"label":"' + label + '"'))
        report = json.loads(PROBE.search(line).group(1))
        self.probes.append(report)
        return report

    def join(self, process, label, actor, position):
        report = self.probe_report(process, f'arce_station_probe join {label} {actor} ' + ' '.join(map(str, position)),
                                   label)
        require(report['connected'] is True, 'Probe player is not the connected player-list entity')

    def leave(self, process, label, actor):
        self.probe_report(process, f'arce_station_probe leave {label} {actor}', label)

    def look(self, process, label, actor, position):
        self.probe_report(process, f'arce_station_probe look {label} {actor} ' + ' '.join(map(str, position)), label)

    def energy(self, process, label, position, amount):
        return self.probe_report(process, f'arce_station_probe energy {label} ' + ' '.join(map(str, position))
                                 + f' {amount}', label)

    def run(self, process, label, actor, command):
        report = self.probe_report(process, f'arce_station_probe run {label} {actor} {command}', label)
        require(report['command'] == command, 'Probe run differs')
        require(report['loaded_chunks_before_command'] == report['loaded_chunks_after_command'],
                'A player command changed the loaded chunk count: ' + label)
        return report


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions, finish='stop'):
    """Runs one server process. finish: 'stop' (orderly), 'kill' (durable save, then killed) or
    'kill-now' (killed right after the actions, with no save)."""
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    if phase.probe:
        command.insert(1, '-Darce_adapter_test.stationSmoke=true')
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts,
                                                 'finish': finish})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS', 'finish': finish}
    process = None
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 300)
        status = server.wait_for_status(port)
        support.validate_status(status, len(phase.artifacts) > 1, phase.artifacts[0]['version'])
        write_json(phase.directory / 'status.json', status)
        actions(phase, process)
        if finish != 'kill-now':
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 60)
        findings = [line.rstrip() for line in server.scan_log(process.lines)
                    if not any(pattern.search(line) for pattern in ALLOWED_WARNINGS)]
        require(not findings, 'Blocking log findings: ' + json.dumps(findings[:5]))
        if finish in ('kill', 'kill-now'):
            kill_after(phase, process)
        else:
            phase.commands.append('stop')
            process.command('stop')
            require(process.finish() == 0, 'Server did not stop cleanly')
        receipt.update(result='PASS', log_counts=server.log_audit_counts(process.lines),
                       allowed_findings=[l.rstrip() for l in server.scan_log(process.lines)],
                       migration_lines=[l.rstrip() for l in process.lines if '[ARCE-BETA-' in l],
                       warp_lines=[l.rstrip() for l in process.lines if 'ARCE_STATION_WARP' in l],
                       recovery_lines=[l.rstrip() for l in process.lines if 'ARCE_TRANSFER_RECOVERY' in l],
                       observations=phase.observations)
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        write_json(phase.directory / 'probes.json', phase.probes)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


# Deliberate states whose warnings are expected in these logs.
ALLOWED_WARNINGS = [re.compile(p) for p in (r'ARCE_TRANSFER_RECOVERY ', r'ARCE_RELEASE_TEST_')]


def kill_after(phase, process):
    phase.commands.append('<kill>')
    process.abort()
    phase.observations['killed'] = True


def in_dim(dimension, command):
    return f'execute in {dimension} run {command}'


def report_rocket(phase, process, dimension, selector, attempts=15):
    """The release-test report of one rocket, by entity UUID or a selector (dimension-scoped). Entities
    of a chunk that was just force-loaded appear a moment later, so a missing entity is retried."""
    match = None
    for attempt in range(attempts):
        start = len(process.lines)
        text = in_dim(dimension, f'arce rocket release-test report {selector}')
        phase.commands.append(text)
        process.command(text)
        index = process.wait_for(flight.REPORT_OR_MISSING_LOG, 30, start_at=start)
        match = flight.REPORT_LOG.search(process.lines[index])
        if match is not None:
            break
        time.sleep(1.0)
    require(match is not None, f'No rocket found for {selector} in {dimension}')
    (entity, logical, snapshot, dim, state, fuel, capacity, passengers, transfer, x, y, z, blocks) = match.groups()
    return {'entity': entity, 'logical': logical, 'snapshot': snapshot, 'dimension': dim, 'state': state,
            'fuel': int(fuel), 'capacity': int(capacity), 'passengers': int(passengers), 'transfer': transfer,
            'origin': [int(x), int(y), int(z)], 'blocks': int(blocks)}


def assemble_rocket(phase, process):
    """FlightHarness.assemble without its `kill @e[type=rocket]`: an unrestricted @e selects rockets in
    every loaded dimension, which would destroy a rocket already docked at a station."""
    commands = [
        f'forceload add {flight.X} {flight.Z}',
        f'fill {flight.X - 2} {flight.Y} {flight.Z - 1} {flight.X + 2} {flight.Y + 4} {flight.Z + 1} minecraft:air',
        f'setblock {flight._position(flight.ASSEMBLER)} {HOST}:rocket_assembler',
        f'setblock {flight._position(flight.FUEL_TANK)} {HOST}:rocket_fuel_tank',
        f'setblock {flight._position(flight.MOTOR)} {HOST}:rocket_motor',
        f'setblock {flight._position(flight.SEAT)} {HOST}:rocket_seat',
        f'setblock {flight._position(flight.GUIDANCE)} {HOST}:guidance_computer',
        f'setblock {flight._position(flight.CHEST)} minecraft:chest',
        f'data merge block {flight._position(flight.CHEST)} {{Items:[{{Slot:0b,id:"minecraft:diamond",Count:17b}},'
        '{Slot:26b,id:"minecraft:iron_ingot",Count:64b}]}',
    ]
    for text in commands:
        phase.commands.append(text)
        process.command(text)
    start = len(process.lines)
    text = f'arce rocket assemble {flight._position(flight.ASSEMBLER)}'
    phase.commands.append(text)
    process.command(text)
    index = process.wait_for(flight.ASSEMBLY_LOG, 45, start_at=start)
    blocks, snapshot, entity = flight.ASSEMBLY_LOG.search(process.lines[index]).groups()
    require(int(blocks) == flight.EXPECTED_BLOCKS, 'Unexpected rocket block count')
    process.wait_for(re.compile(r'ARCE_ROCKET_ENTITY_ACTIVE entity=' + entity + r' operational=true '), 30,
                     start_at=index)
    report = report_rocket(phase, process, OVERWORLD, entity)
    require(report['state'] == 'ASSEMBLED' and report['snapshot'] == snapshot, 'Fresh rocket report differs')
    return report


def column(center, radius):
    """A full-height column around a landing origin: a descending rocket is still above it."""
    return (f'@e[type={HOST}:rocket,x={center[0] - radius},y=-64,z={center[2] - radius},'
            f'dx={2 * radius},dy=512,dz={2 * radius}]')


def count_rockets(phase, process, dimension, center, radius):
    text = f'execute in {dimension} if entity {column(center, radius)}'
    line = phase.query(process, text, re.compile(r'Test (passed|failed)'))
    match = re.search(r'Test passed, count: (\d+)', line)
    return int(match.group(1)) if match else 0


def forceload(phase, process, dimension, x, z):
    phase.query(process, in_dim(dimension, f'forceload add {x} {z}'),
                re.compile(r'Marked chunk|already marked|No chunks were marked'))


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    history = json.loads((HISTORY / 'native/summary.json').read_text(encoding='utf-8'))
    require(digest(LEGACY_JAR) == LEGACY_SHA, 'The retained v1.4 host JAR changed')
    require(LEGACY_SHA in json.dumps(history), 'The v1.4 host is not the one the retained world run recorded')
    legacy = support.artifact(LEGACY_JAR, HOST, '1.20.1-1.4.0-dev')
    legacy_consumer = support.artifact(LEGACY_CONSUMER, support.FIXTURE, '1.0.0')
    host = support.artifact(HOST_JAR, HOST, '1.20.1-1.5.0-dev')
    consumer = support.artifact(CONSUMER, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    write_json(OUT / 'inputs.json', {'source_world': str(SOURCE), 'history_summary': str(HISTORY / 'native/summary.json'),
                                     'artifacts': [legacy, legacy_consumer, host, consumer]})
    before = observe_data(SERVER / 'world', OUT / 'before')
    require(before[STATION]['schema_version'] == 2 and TRANSFERS not in before,
            'The source is not the v1.4 world without transfers')
    shutil.copytree(HISTORY / 'server-final/libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    harness = flight.FlightHarness(java=JAVA, server=SERVER, port=port, expected_version='1.20.1-1.4.0-dev',
                                   startup_timeout=300)
    receipts = []
    state = {}

    # ---- Phase 1: v1.4 host writes a docked rocket and an in-flight transfer that touch stations.
    def create(phase, process, owner, name):
        line = phase.query(process, f'arce station admin create {owner} {EARTH} {name}', CREATED, 45)
        station = stations._station_from_match(CREATED.search(line))
        require(station['owner_id'] == owner, 'Station creation changed the owner')
        return station

    def legacy_actions(phase, process):
        a = create(phase, process, OWNER_A, 'MIG-A')
        c = create(phase, process, OWNER_C, 'MIG-C')
        for station in (a, c):
            region = station['region']
            forceload(phase, process, SPACE, (region[0] + region[2] + 1) // 2, (region[1] + region[3] + 1) // 2)
        r1 = assemble_rocket(phase, process)
        leg1, dock1 = stations._launch_station(harness, process, source_dimension=flight.EARTH, entity=r1['entity'],
                                               logical=r1['logical'], station=a)
        r2 = assemble_rocket(phase, process)
        leg2, dock2 = stations._launch_station(harness, process, source_dimension=flight.EARTH, entity=r2['entity'],
                                               logical=r2['logical'], station=c)
        refuel = flight.FlightHarness.refuel(process, SPACE, dock2['entity'])
        require(refuel['logical'] == r2['logical'], 'R2 identity changed before its departure')
        start = len(process.lines)
        text = in_dim(SPACE, f'arce rocket release-test launch {dock2["entity"]} earth destination_spawned')
        phase.commands.append(text)
        process.command(text)
        launch = flight.LAUNCH_LOG.search(process.lines[process.wait_for(flight.LAUNCH_LOG, 30, start_at=start)])
        require(launch.group(7) == 'SUCCESS' and launch.group(3) == r2['logical'], 'R2 departure from C failed')
        transfer = launch.group(1)
        pause = flight.PAUSE_LOG.search(process.lines[process.wait_for(re.compile(
            r'ARCE_RELEASE_TEST_FLIGHT_PAUSED checkpoint=DESTINATION_SPAWNED transfer=' + transfer), 60,
            start_at=start)])
        require(pause.group(3) == 'DESTINATION_SPAWNED', 'R2 did not freeze at DESTINATION_SPAWNED')
        dock1_again = report_rocket(phase, process, SPACE, dock1['entity'])
        require(dock1_again['logical'] == r1['logical'] and dock1_again['state'] == 'LANDED', 'R1 is not docked')
        state.update(a=a, c=c, r1=dict(r1, dock=dock1_again, leg=leg1), r2=dict(r2, leg=leg2, dock=dock2),
                     r2_transfer=transfer, r2_paused_entity=pause.group(5),
                     r2_required=int(launch.group(8)), r2_fuel_before=int(launch.group(9)))
        phase.observations.update(stations={'A': a, 'C': c}, r1=state['r1'], r2=state['r2'],
                                  r2_transfer=transfer, r2_paused_entity=pause.group(5))

    legacy_phase = Phase('legacy', [legacy, legacy_consumer], False)
    receipts.append(run_phase(legacy_phase, port, legacy_actions, finish='kill'))
    if UNTIL == 'legacy':
        write_json(OUT / 'legacy-state.json', state)
        print('STOPPED after legacy (debug)')
        return
    after_legacy = observe_data(SERVER / 'world', legacy_phase.directory / 'state')
    require(after_legacy[STATION]['schema_version'] == 2, 'The v1.4 host changed the registry schema')
    records = after_legacy[TRANSFERS]['transfers']
    ids = [nbt_uuid(r['transfer_id']) for r in records]
    require(state['r2_transfer'] in ids, 'The in-flight transfer is not in the v1.4 journal')
    write_json(OUT / 'legacy-journal-ids.json', ids)

    # Both ends of every v1.4 record, as the journal itself states them.
    ends = []
    for record in records:
        for key in ('source_snapshot', 'destination_snapshot'):
            snapshot = record[key]
            ends.append((snapshot['source_dimension'], snapshot['source_origin']))
    r2_record = next(r for r in records if nbt_uuid(r['transfer_id']) == state['r2_transfer'])
    require(r2_record['phase'] == 'DESTINATION_SPAWNED', 'R2 is not frozen at DESTINATION_SPAWNED on disk')
    r2_destination = r2_record['destination_snapshot']['source_origin']
    r2_source = r2_record['source_snapshot']['source_origin']
    write_json(OUT / 'legacy-record-ends.json', ends)
    a_id, c_id = state['a']['station_id'], state['c']['station_id']
    r1_entity, r1_logical = state['r1']['dock']['entity'], state['r1']['logical']
    r1_origin = state['r1']['dock']['origin']
    pad_a = station_record(after_legacy[STATION], a_id)['landing_pad']
    pad_c = station_record(after_legacy[STATION], c_id)['landing_pad']

    # ---- Phase 2: upgrade, recovery of R2, S1 subset, and a warp of A with R1 docked.
    def upgrade_actions(phase, process):
        migrated = [l.strip() for l in process.lines if re.search(r'\[ARCE-BETA-100\d\].*migrated=[1-9]\d*, backup=\S', l)]
        require(migrated, 'The v1.4 world was not migrated with a backup')
        phase.observations['migration'] = migrated
        # Load both ends of every legacy record and the docked rocket (operator action for the test).
        for dimension, origin in ends:
            forceload(phase, process, dimension, origin[0], origin[2])
        recovered = process.wait_for(re.compile(r'ARCE_TRANSFER_RECOVERY transfer=' + state['r2_transfer']
                                                + r' .*status=RECOVERED'), 120)
        phase.observations['r2_recovery'] = process.lines[recovered].strip()
        # R2 exists exactly once, at one end, with its logical identity and exact fuel.
        at_destination = count_rockets(phase, process, OVERWORLD, r2_destination, 8)
        at_source = count_rockets(phase, process, SPACE, r2_source, 8)
        require(at_destination + at_source == 1, f'R2 duplicated or lost: {at_destination} + {at_source}')
        where = (OVERWORLD, r2_destination) if at_destination else (SPACE, r2_source)
        for attempt in range(40):
            r2 = report_rocket(phase, process, where[0], column(where[1], 8)[:-1] + ',limit=1]')
            if r2['state'] == 'LANDED':
                break
            time.sleep(1.0)
        require(r2['state'] == 'LANDED', 'R2 did not land after recovery: ' + json.dumps(r2))
        expected_fuel = state['r2_fuel_before'] - state['r2_required'] if at_destination else state['r2_fuel_before']
        require(r2['logical'] == state['r2']['logical'] and r2['fuel'] == expected_fuel,
                'R2 identity or fuel changed through recovery: ' + json.dumps(r2))
        phase.observations['r2_after_recovery'] = dict(r2, end='destination' if at_destination else 'source')
        r1 = report_rocket(phase, process, SPACE, r1_entity)
        require(r1['logical'] == r1_logical and r1['origin'] == r1_origin and r1['state'] == 'LANDED'
                and r1['fuel'] == state['r1']['dock']['fuel'], 'R1 changed through the upgrade: ' + json.dumps(r1))
        phase.observations['r1_after_upgrade'] = r1
        # S1 subset (ADR-046) on A: owner, member, invitee and outsider as connected probe players.
        stand = [pad_a[0] + 2, pad_a[1], pad_a[2] + 2]
        core = [pad_a[0], pad_a[1], pad_a[2] + 3]
        phase.join(process, 's1_owner_join', OWNER_A, stand)
        phase.join(process, 's1_member_join', MEMBER_A, stand)
        phase.join(process, 's1_invitee_join', INVITEE_A, stand)
        phase.join(process, 's1_outsider_join', OUTSIDER, stand)
        s1 = []

        def cell(action, actor_name, actor, command, expect):
            report = phase.run(process, f's1_{action}_{actor_name}', actor, command)
            text = ' | '.join(report['messages'][-3:]) + (' | ' + report['error'] if 'error' in report else '')
            ok = expect(report)
            s1.append({'action': action, 'actor': actor_name, 'command': command, 'result': report['result'],
                       'replies': report['messages'], 'error': report.get('error'), 'pass': ok})
            require(ok, f'S1 {action}/{actor_name} differs: {text}')

        said = lambda fragment: (lambda r: any(fragment in m for m in r['messages']))
        unknown = lambda r: r['result'] == -1 and 'Unknown or incomplete command' in (r.get('error') or '') or \
            r['result'] == -1 and 'Incorrect argument' in (r.get('error') or '')
        # Team: the owner invites the member and invitee (probe1, probe2); the member accepts.
        cell('invite', 'owner', OWNER_A, f'arce station invite {a_id} probe1', said('Invitation recorded'))
        cell('accept', 'member', MEMBER_A, f'arce station accept {a_id}', said('Station invitation accepted'))
        cell('invite', 'member', MEMBER_A, f'arce station invite {a_id} probe3', said('Station action rejected'))
        cell('invite', 'owner2', OWNER_A, f'arce station invite {a_id} probe2', said('Invitation recorded'))
        cell('expand', 'owner', OWNER_A, 'arce station expand', said('To confirm within'))
        for name, actor in (('member', MEMBER_A), ('invitee', INVITEE_A), ('outsider', OUTSIDER)):
            cell('expand', name, actor, 'arce station expand', said(UNAUTHORIZED))
        line = phase.query(process, in_dim(SPACE, f'setblock {core[0]} {core[1]} {core[2]} {HOST}:warp_core'),
                           re.compile(r'Changed the block at|Could not set the block'))
        require('Changed the block at' in line, 'Warp core was not placed')
        for label, actor in (('owner', OWNER_A), ('member', MEMBER_A), ('invitee', INVITEE_A), ('outsider', OUTSIDER)):
            phase.look(process, f's1_look_{label}', actor, core)
        cell('warp', 'owner', OWNER_A, f'arce station warp {MOON}', said('does not cover the cost'))
        for name, actor in (('member', MEMBER_A), ('invitee', INVITEE_A), ('outsider', OUTSIDER)):
            cell('warp', name, actor, f'arce station warp {MOON}', said(UNAUTHORIZED))
        for name, actor in (('owner', OWNER_A), ('member', MEMBER_A)):
            cell('status', name, actor, 'arce station warp status', said('Warp status; station=' + a_id))
        for name, actor in (('invitee', INVITEE_A), ('outsider', OUTSIDER)):
            cell('status', name, actor, 'arce station warp status', said('Station warp rejected'))
        cell('remove_uuid', 'member', MEMBER_A, f'arce station remove {a_id} uuid {MEMBER_A}',
             said('Station action rejected'))
        cell('remove', 'owner', OWNER_A, f'arce station remove {a_id} probe1', said('Member removed immediately'))
        cell('accept', 'invitee', INVITEE_A, f'arce station accept {a_id}', said('Station invitation accepted'))
        cell('remove_uuid', 'owner', OWNER_A, f'arce station remove {a_id} uuid {INVITEE_A}',
             said('removed immediately'))
        for name, actor in (('owner', OWNER_A), ('member', MEMBER_A), ('outsider', OUTSIDER)):
            cell('admin', name, actor, f'arce station admin inspect {a_id}', unknown)
        phase.query(process, f'arce station admin inspect {a_id}', re.compile(r'region=\S+ pad='))
        phase.observations['s1'] = s1
        for label, actor in (('member', MEMBER_A), ('invitee', INVITEE_A), ('outsider', OUTSIDER)):
            phase.leave(process, f's1_{label}_leave', actor)
        # Warp A to the Moon with R1 docked (production rocket rule, real countdown).
        for index in range(10):
            report = phase.energy(process, f'charge_a_{index}', core, PER_TICK)
            require(report['accepted'] == PER_TICK, 'Charge differs: ' + json.dumps(report))
        phase.run(process, 'warp_a_request', OWNER_A, f'arce station warp {MOON}')
        confirmed_at = len(process.lines)
        confirm = phase.run(process, 'warp_a_confirm', OWNER_A, f'arce station warp confirm {a_id}')
        require(any('Warp countdown started' in m for m in confirm['messages']), 'A countdown did not start')
        process.wait_for(re.compile(r'ARCE_STATION_WARP action=commit code=WARP_COMMITTED station=' + a_id), 40,
                         start_at=confirmed_at)
        r1 = report_rocket(phase, process, SPACE, r1_entity)
        require(r1['logical'] == r1_logical and r1['origin'] == r1_origin and r1['state'] == 'LANDED',
                'R1 changed through the warp: ' + json.dumps(r1))
        phase.observations['r1_after_warp'] = r1
        phase.leave(process, 'owner_leave', OWNER_A)
        state['core_a'] = core

    upgrade = Phase('upgrade', [host, consumer], True)
    receipts.append(run_phase(upgrade, port, upgrade_actions))
    after_upgrade = observe_data(SERVER / 'world', upgrade.directory / 'state')
    require(after_upgrade[STATION]['schema_version'] == 4, 'The registry is not root 4 after the upgrade')
    require(station_record(after_upgrade[STATION], a_id)['orbit_body'] == MOON, 'A did not warp to the Moon')
    require(balances(after_upgrade[STATION]).get(a_id) is None, 'A was not charged exactly its balance')
    # Landed reservations stay in the journal as COMMITTED records; recovery moved R2's forward.
    phases = {nbt_uuid(r['transfer_id']): r['phase'] for r in after_upgrade[TRANSFERS]['transfers']}
    require(phases.get(state['r2_transfer']) == 'COMMITTED' and set(phases.values()) == {'COMMITTED'},
            'Journal phases after recovery differ: ' + json.dumps(phases))
    core_c = [pad_c[0], pad_c[1], pad_c[2] + 3]

    def charge(phase, process, label, core, calls):
        for index in range(calls):
            report = phase.energy(process, f'{label}_{index}', core, PER_TICK)
            require(report['accepted'] == PER_TICK, 'Charge differs: ' + json.dumps(report))

    def check_r1(phase, process, label):
        forceload(phase, process, SPACE, pad_a[0], pad_a[2])
        forceload(phase, process, OVERWORLD, flight.X, flight.Z)
        r1 = report_rocket(phase, process, SPACE, r1_entity)
        require(r1['logical'] == r1_logical and r1['origin'] == r1_origin and r1['state'] == 'LANDED'
                and r1['fuel'] == state['r1']['dock']['fuel'], label + ': R1 changed: ' + json.dumps(r1))
        phase.observations[label] = r1

    # ---- Phase 3: two stations warp at once; a countdown is then interrupted by a kill.
    def concurrent_actions(phase, process):
        check_r1(phase, process, 'r1_restart')
        forceload(phase, process, SPACE, pad_c[0], pad_c[2])
        line = phase.query(process, in_dim(SPACE, f'setblock {core_c[0]} {core_c[1]} {core_c[2]} {HOST}:warp_core'),
                           re.compile(r'Changed the block at|Could not set the block'))
        require('Changed the block at' in line, 'Warp core C was not placed')
        stand_a = [pad_a[0] + 2, pad_a[1], pad_a[2] + 2]
        stand_c = [pad_c[0] + 2, pad_c[1], pad_c[2] + 2]
        phase.join(process, 'owner_a_join', OWNER_A, stand_a)
        phase.join(process, 'owner_c_join', OWNER_C, stand_c)
        phase.look(process, 'owner_a_look', OWNER_A, state['core_a'])
        phase.look(process, 'owner_c_look', OWNER_C, core_c)
        charge(phase, process, 'charge_a', state['core_a'], 10)
        charge(phase, process, 'charge_c', core_c, 10)
        phase.run(process, 'a_request', OWNER_A, f'arce station warp {EARTH}')
        phase.run(process, 'c_request', OWNER_C, f'arce station warp {MOON}')
        start = len(process.lines)
        a = phase.run(process, 'a_confirm', OWNER_A, f'arce station warp confirm {a_id}')
        c = phase.run(process, 'c_confirm', OWNER_C, f'arce station warp confirm {c_id}')
        require(any('Warp countdown started' in m for m in a['messages'])
                and any('Warp countdown started' in m for m in c['messages']), 'Both countdowns must start')
        for station_id in (a_id, c_id):
            process.wait_for(re.compile(r'ARCE_STATION_WARP action=commit code=WARP_COMMITTED station=' + station_id),
                             40, start_at=start)
        phase.observations['concurrent_commits'] = [l.strip() for l in process.lines[start:]
                                                    if 'action=commit' in l]
        # Interrupted countdown: A requests Moon again, confirms, and the process is killed mid-countdown.
        charge(phase, process, 'charge_a2', state['core_a'], 10)
        # ADR-044 cooldown: 100 ticks after a commit a new request is refused; then it is accepted.
        early = phase.run(process, 'a_request_cooldown', OWNER_A, f'arce station warp {MOON}')
        require(any('changed moments ago' in m for m in early['messages']), 'The post-commit cooldown did not refuse')
        time.sleep(6.0)
        phase.run(process, 'a_request_2', OWNER_A, f'arce station warp {MOON}')
        confirm = phase.run(process, 'a_confirm_2', OWNER_A, f'arce station warp confirm {a_id}')
        require(any('Warp countdown started' in m for m in confirm['messages']), 'Interrupted countdown did not start')
        phase.observations['interrupted'] = 'killed after a durable save, during the countdown'

    concurrent = Phase('concurrent', [host, consumer], True)
    receipts.append(run_phase(concurrent, port, concurrent_actions, finish='kill'))
    require(not any('station=' + a_id in l and 'action=commit' in l and 'MOON' in l.upper()
                    for l in receipts[-1]['warp_lines'][-3:]), 'Unexpected late commit')
    after_concurrent = observe_data(SERVER / 'world', concurrent.directory / 'state')
    reg = after_concurrent[STATION]
    require(station_record(reg, a_id)['orbit_body'] == EARTH and station_record(reg, c_id)['orbit_body'] == MOON,
            'Concurrent warps did not both commit to their own targets')
    require(balances(reg).get(a_id) == COST and balances(reg).get(c_id) is None,
            'Balances differ after the concurrent warps and the interrupted countdown: ' + json.dumps(balances(reg)))

    # ---- Phase 4: the killed countdown left nothing; a commit is killed right after its line.
    def interrupted_actions(phase, process):
        check_r1(phase, process, 'r1_after_kill')
        forceload(phase, process, SPACE, pad_c[0], pad_c[2])
        start = len(process.lines)
        phase.commands.append('arce station admin warp')
        process.command('arce station admin warp')
        line = process.lines[process.wait_for(re.compile(r'warp enabled='), 30, start_at=start)]
        require('countdowns=0' in line and 'pending_energy=0' in line, 'A countdown survived the kill: ' + line)
        phase.observations['admin_warp'] = line.strip()
        phase.join(process, 'owner_c_join', OWNER_C, [pad_c[0] + 2, pad_c[1], pad_c[2] + 2])
        phase.look(process, 'owner_c_look', OWNER_C, core_c)
        charge(phase, process, 'charge_c', core_c, 10)
        phase.run(process, 'c_request', OWNER_C, f'arce station warp {EARTH}')
        confirmed_at = len(process.lines)
        phase.run(process, 'c_confirm', OWNER_C, f'arce station warp confirm {c_id}')
        process.wait_for(re.compile(r'ARCE_STATION_WARP action=commit code=WARP_COMMITTED station=' + c_id), 40,
                         start_at=confirmed_at)
        phase.observations['kill_after_commit'] = 'killed right after the commit line, with no save'

    interrupted = Phase('interrupted', [host, consumer], True)
    receipts.append(run_phase(interrupted, port, interrupted_actions, finish='kill-now'))
    after_kill = observe_data(SERVER / 'world', interrupted.directory / 'state')
    reg = after_kill[STATION]
    require(station_record(reg, c_id)['orbit_body'] == EARTH and balances(reg).get(c_id) is None,
            'The commit killed after its line is not complete on disk: ' + json.dumps(balances(reg)))

    # ---- Phase 5: everything persisted; no unclassified record; R1 unchanged.
    def final_actions(phase, process):
        check_r1(phase, process, 'r1_final')
        journal = []
        for attempt in range(20):
            start = len(process.lines)
            phase.commands.append('arce station admin warp')
            process.command('arce station admin warp')
            index = process.wait_for(re.compile(r'transfer_journal='), 30, start_at=start)
            journal.append(process.lines[index].strip())
            if 'unclassified=0' in journal[-1]:
                break
            phase.query(process, 'forceload query', re.compile(r'chunks|forceloaded|No chunks'))
        require('unclassified=0' in journal[-1], 'An unclassified record remains: ' + json.dumps(journal))
        phase.observations['journal'] = journal

    final = Phase('final', [host, consumer], True)
    receipts.append(run_phase(final, port, final_actions))
    last = observe_data(SERVER / 'world', final.directory / 'state')
    require(last[STATION] == after_kill[STATION], 'The final restart changed the registry')
    require(fixture.inventory(SOURCE) == source_inventory, 'Original source world was changed')
    write_json(OUT / 'summary.json', {
        'result': 'PASS', 'source_world_unchanged': True, 'source_world': str(SOURCE),
        'legacy_host_sha256': LEGACY_SHA, 'stations': {'A': a_id, 'C': c_id},
        'r1': {'entity': r1_entity, 'logical': r1_logical, 'origin': r1_origin},
        'r2': {'logical': state['r2']['logical'], 'transfer': state['r2_transfer']},
        'cycles': receipts,
        'scope': ('v1.4-written docked rocket and in-flight transfer touching stations -> v1.5 upgrade and '
                  'recovery -> S1 subset -> warp with a docked rocket -> concurrent warps of two stations -> '
                  'killed countdown -> commit killed after its line -> final restart; no real clients, no '
                  'crash cut inside a checked write, no load test')})
    print('PASS: MIG-01b, MIG-02 and the S1 subset')



UNTIL = sys.argv[1] if len(sys.argv) > 1 else None

if __name__ == '__main__':
    main()
