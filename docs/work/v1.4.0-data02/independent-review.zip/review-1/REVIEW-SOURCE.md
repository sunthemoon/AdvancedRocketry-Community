# V140-DATA-02 independent source-review checkpoint

## Findings

No unresolved concrete source defect found in the revised files captured in `source-identities.json` at 2026-09-27 16:21:55 +08:00. This is a changing-worktree source checkpoint, not final executable verification, task completion, or Gate approval.

**P2, resolved in the reviewed revision: non-lenient Gson did not provide the promised strict JSON boundary.** Initial `celestial/data/BoundedDefinitionJson.java:39-41` delegated strictness to `JsonReader.setLenient(false)`. The pinned Gson 2.10 bytecode independently confirms that `peekKeyword` accepts mixed-case true/false/null, `nextQuotedValue` accepts raw string controls, and `readEscapeCharacter` accepts escaped apostrophes and backslash-newline. An otherwise-valid legacy definition could place these forms in ignored data; malformed input would then reach a publishable candidate rather than reject it. The finding was sent to root; root separately reported an actual failing reader regression and retained that execution. I did not run that regression.

The revised `BoundedDefinitionJson.java:39,50-81` preflights bounded text for raw string controls, non-JSON escapes and keyword spelling before the Gson structural reader. The reader still validates structural syntax and Unicode escapes, preserves duplicate detection on decoded keys, and bounds nesting before allocating children. `BoundedDefinitionJsonTest.java:53-67` now includes malformed values/keys, keyword casing and escape failures plus valid escaped keys/values. Source inspection supports the correction; independent execution remains pending.

## Scope and source observations

All Java references below are relative to `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/` unless marked as tests.

- `celestial/data/BoundedDefinitionJson.java:27-47,84-121`: reads at most limit + 1 bytes before UTF-8 decoding/tree allocation; body limit 32768 and route limit 4096; malformed UTF-8 reports rather than replaces; 16-container nesting and decoded-key duplicate checks. This bounds project parsing, not the platform's initial resource enumeration or blocking I/O duration.
- `celestial/data/PlanetaryDefinitionReloadListener.java:31-41,44-83`: reads the two winning resource sets and rejects any collected raw failure before decoding either catalog. Resource count checked before per-resource decode. File streams use try-with-resources. Both sets share eight-detail/2048-character diagnostics. Endpoint validation uses the same decoded celestial candidate.
- `celestial/data/PlanetaryCatalog.java:20-37`: body existence checked for both endpoint kinds; surface additionally requires a mapped non-gas body. Admission flags deliberately do not delete evacuation/reverse edges, matching ADR-031.
- `celestial/data/PlanetaryCatalogManager.java:10-44`: one atomic state owns the immutable definition/route pair and generation. A rejection retains the exact pair object, including its bounded route cache; acceptance publishes once. Its celestial projection captures one State before producing catalog/status. `celestial/service/CelestialCatalogManager.java:28-37,72-78` prevents mutation through that projection while preserving isolated mutable test owners.
- `PlanetaryDefinitionReloadListener.java:87-99`: initial rejected data throws with no ready pair; later rejection retains the previous pair. This does not roll back all other Forge reload listeners, as explicitly excluded by ADR-031.
- `AdvancedRocketryCommunity.java:87-88,204-208,236-240,308`: runtime wiring has one owner/listener and clears it on stop; old celestial/route listeners and route owner are removed. Satellite validation still runs in its apply stage against the runtime celestial projection, after the registered planetary listener.
- `rocket/server/RocketManager.java:78-85` rejects mismatched runtime context/planning owners. `RocketFlightService.java:111-164,304-312,379-406,429-431` captures one pair per quote batch/launch and passes both catalog objects to planning. Configured-but-unready catalogs remain fail-closed; isolated no-catalog fixture behavior is retained.
- `celestial/network/CelestialSnapshotSynchronizer.java:21-31,52-60` captures catalog and generation from one projection snapshot for each encoded display packet. No public API/save/channel edit is present in this slice's inspected diff.
- New `celestial/command/PlanetaryRouteCommands.java:22-46` is a permission-2 diagnostic; it captures one generation, reports one bounded route and does not resolve or load a Level. Root explicitly confirmed this new file's scope for native pair readback.
- `datagen/CelestialDefinitionProvider.java` only changes the directory constant owner; generated baseline resources are unchanged. `gametest/PlanetaryAdmissionGameTests.java` changes private fixture publication to paired owners without weakening existing admission assertions or timings.

## Test-source inspection, not test results

The checkpoint contains 8 `BoundedDefinitionJsonTest` methods and 15 `PlanetaryReloadTest` methods. Reviewed cases cover raw byte boundaries, malformed UTF-8, duplicate/escaped/null keys, nesting, lexer/number spelling, undrained oversize input; real PathPack resource reload, priority, startup rejection, graph/endpoints, body/route removal, exact old object/cache retention, 100-body/100-route input, count/diagnostic caps, reload barrier and injected stream-read failure/close. The added barrier test uses a controlled future and real listener lifecycle, not a sleep. The I/O test overrides a real pack's resource supplier and checks one close. Existing route test now checks retained route identity through the pair.

These source assertions are appropriate to the implementation. They do not prove full executor races, whole-Forge rollback, native restart, snapshot/client behavior, a reference-load performance budget, or authentic saved-world migration.

## Checks actually performed

Working tree: `D:/GitHub/AdvancedRocketry-Community`; branch `codex/v1.4.0-planetary-expansion`; HEAD/base `4db8b1bc573b6f9f20a20bd2a5a13a0836e055f2`.

Read AGENTS, project/product/governance/version/quality documents, accepted ADR-030/031, active log and status pointers. Read actual tracked diff plus explicitly new production/test files, related decoders, route cache/planner, command and satellite listener callers. Did not read the excluded user documentation bundle or mutable build artifacts.

Commands (read-only, apart from this Temp evidence):

1. `git rev-parse HEAD`, `git branch --show-current`, scoped `git status --short --untracked-files=all`, `git diff --stat/--numstat/--name-only <base>`, `git diff <base> -- src docs/work/v1.4.0-implementation-log.md`; normal completion. Saved the tracked patch and a 20-entry identity/deletion inventory.
2. PowerShell `Get-Content`, `Get-ChildItem`, `Select-String`, `Get-FileHash` and `rg` source searches. One attempted PowerShell command incorrectly used Bash brace syntax and failed parsing before execution; rerun used the explicit package root successfully. This did not mutate files.
3. `C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -classpath <cached gson-2.10.jar> -c -p com.google.gson.stream.JsonReader`; exit 0; full bytecode retained in `pinned-gson-2.10-JsonReader.javap.txt`. Gson JAR SHA-256 `0cdd163ce3598a20fc04eee71b140b24f6f2a3b35f0a499dbbdd9852e83fbfaf`.
4. `git diff --check`; exit 0.
5. `git diff --exit-code <base> -- src/main/java/io/github/sunthemoon/advancedrocketrycommunity/api build.gradle gradle.properties src/generated/resources`; exit 0, no output.

No Gradle, unit/Python tests, Minecraft server/client, remote or browser command was run by this reviewer. No tracked files, build outputs, Git index or world files were changed. No child agent was launched. Root owns all source changes and executable work until explicit slot handoff.

## Remaining verification / next scoped step

Await final frozen source and root's exclusive execution slot; independently run the agreed reader/reload/planning/snapshot checks, retaining actual results and identities. Review any new native runner separately and read its actual bounded reload/restart evidence when terminal. Artifact/classifier byte identity, final generated-resource identity and the new tests' outcomes are not established by this checkpoint. All v1.4 Required Gates and inherited acceptance remain outside this source-review conclusion.
