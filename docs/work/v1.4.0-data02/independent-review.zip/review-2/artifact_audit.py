import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).parent
FROZEN = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-data02-1790496634817/artifacts')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
artifacts = []
for path in sorted(FROZEN.glob('*.jar')):
    built = ROOT / 'build/libs' / path.name
    assert digest(path) == digest(built), path.name
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), path.name
        assert archive.testzip() is None, path.name
        assert not any('arceadaptertest/' in n or 'arce_adapter_test/' in n for n in names), path.name
        artifacts.append(dict(name=path.name, size=path.stat().st_size, sha256=digest(path),
                              entries=len(names), duplicates=0, fixture_entries=0))
api = next(FROZEN.glob('*-api.jar'))
main = next(p for p in FROZEN.glob('*.jar') if not p.name.endswith(('-api.jar', '-sources.jar')))
baseline = json.loads((ROOT / 'docs/releases/v1.3.0/development-artifacts.json').read_text(encoding='utf-8'))
old_api = next(a for a in baseline['artifacts'] if a['name'].endswith('-api.jar'))
assert digest(api) == old_api['sha256']
with zipfile.ZipFile(api) as a, zipfile.ZipFile(main) as m:
    classes = {n for n in a.namelist() if n.endswith('.class')}
    main_api = {n for n in m.namelist() if '/api/' in n and n.endswith('.class')}
    assert len(classes) == 27 and classes == main_api
    assert all(a.read(n) == m.read(n) for n in classes)
    body_base = 'data/advancedrocketrycommunity/celestial_bodies/'
    routes = sorted(n for n in m.namelist() if n.startswith('data/advancedrocketrycommunity/travel_routes/') and n.endswith('.json'))
    assert len(routes) == 4
    route_values = [json.loads(m.read(n)) for n in routes]
report = dict(artifacts=artifacts, api_class_count=len(classes), api_classes=sorted(classes),
              api_equals_v130_entire_jar=True, api_main_byte_identity=True,
              packaged_routes=route_values)
(OUT / 'artifact-audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
