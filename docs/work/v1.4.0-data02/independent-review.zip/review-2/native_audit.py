import gzip
import hashlib
import io
import json
import re
import struct
import uuid
from pathlib import Path

BASE = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-data02-1790496634817')
E = BASE / 'native-evidence-2'
OUT = Path(__file__).parent
HOST = 'advancedrocketrycommunity'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))

class Nbt:
    def __init__(self, payload):
        assert len(payload) <= 4 * 1024**2
        self.data = io.BytesIO(payload)
        self.nodes = 0
    def take(self, n):
        assert 0 <= n <= 4 * 1024**2
        b = self.data.read(n)
        assert len(b) == n
        return b
    def num(self, fmt):
        return struct.unpack('>' + fmt, self.take(struct.calcsize(fmt)))[0]
    def text(self):
        return self.take(self.num('H')).decode('utf-8')
    def value(self, kind, depth=0):
        self.nodes += 1
        assert self.nodes <= 4096 and depth <= 32
        if kind in range(1, 7):
            return self.num({1:'b', 2:'h', 3:'i', 4:'q', 5:'f', 6:'d'}[kind])
        if kind == 8:
            return self.text()
        if kind in (7, 11, 12):
            n = self.num('i')
            assert 0 <= n <= 4096
            return [self.num({7:'b', 11:'i', 12:'q'}[kind]) for _ in range(n)]
        if kind == 9:
            t, n = self.num('B'), self.num('i')
            assert 0 <= n <= 4096
            return [self.value(t, depth + 1) for _ in range(n)]
        if kind == 10:
            result = {}
            while True:
                t = self.num('B')
                if t == 0:
                    return result
                key = self.text()
                assert key not in result
                result[key] = self.value(t, depth + 1)
        raise AssertionError(('unknown tag', kind))
    def root(self):
        assert self.num('B') == 10
        name, value = self.text(), self.value(10)
        assert not self.data.read(1)
        return name, value

manifest = {}
for line in (E / 'SHA256SUMS').read_text(encoding='ascii').splitlines():
    expected, name = line.split('  ', 1)
    assert name not in manifest
    p = E / name
    assert p.resolve().is_relative_to(E.resolve())
    assert sha(p.read_bytes()) == expected, name
    manifest[name] = expected
assert set(manifest) == {p.relative_to(E).as_posix() for p in E.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}

raw_paths = [E/'create-reload/before-reload-stations.dat', E/'create-reload/stations.dat', E/'restart/stations.dat']
compressed = [p.read_bytes() for p in raw_paths]
assert compressed[0] == compressed[1] == compressed[2]
with gzip.GzipFile(fileobj=io.BytesIO(compressed[0])) as f:
    raw = f.read(4 * 1024**2 + 1)
name, whole = Nbt(raw).root()
data = whole['data']
assert data['schema_version'] == 2 and not data['reservations'] and len(data['stations']) == 1
station = data['stations'][0]
uid = lambda values: str(uuid.UUID(bytes=b''.join(struct.pack('>I', x & 0xffffffff) for x in values)))
station_id, owner_id = uid(station['station_id']), uid(station['owner_id'])
assert station['schema_version'] == 1 and station['orbit_body'] == HOST + ':moon'
assert station['landing_pad'] == [0, 128, 0] and station['region'] == [-256, -256, 255, 255]
assert not station['members'] and not station['invitations']
assert station['environment'] == dict(gravity_milli=0, solar_angle_milli_degrees=270000, vacuum=1)

diagnostics = ['celestial_bodies/raw_probe.json: End of input', 'travel_routes/raw_probe.json: End of input',
               'duplicate JSON key: id', 'JSON nesting exceeds 16', 'definition exceeds 4096 UTF-8 bytes',
               'Route ' + HOST + ':raw_probe references missing body ' + HOST + ':missing']
labels = ['body-syntax', 'route-syntax', 'duplicate-key', 'depth', 'route-bytes', 'missing-body']
for label in labels:
    d = E/'create-reload/rejected-inputs'/label
    assert load(d/'moon.json')['solar_intensity'] == 0.75
    assert load(d/'earth_moon.json')['distance_units'] == 222
    p = (d/'raw_probe.json').read_bytes()
    if label in ('body-syntax', 'route-syntax'): assert p == b'{'
    elif label == 'duplicate-key': assert p == b'{"id":null,"id":null}'
    elif label == 'depth': assert p == b'[' * 17 + b'0' + b']' * 17
    elif label == 'route-bytes': assert p == b' ' * 4097
    else: assert json.loads(p)['to']['body_id'] == HOST + ':missing'

summary = load(E/'summary.json')
assert summary['station_id'] == station_id and summary['joint_reload'] is True
logs = {}
for phase in ('create-reload', 'restart'):
    d = E/phase
    commands = load(d/'commands.json')
    assert commands[-1] == 'stop'
    assert commands.count('reload') == (8 if phase == 'create-reload' else 0)
    if phase == 'create-reload':
        assert f'arce station admin create {owner_id} {HOST}:moon Schema probe' in commands
    assert f'arce station admin inspect {station_id}' in commands
    expected_accepted = [('1','3','4'), ('2','4','4'), ('3','4','4')] if phase == 'create-reload' else [('1','4','4')]
    expected_routes = [(1,50), (2,123)] + [(2,123)] * 6 + [(3,222)] * 2 if phase == 'create-reload' else [(1,222)]
    for filename in ('stdout.txt', 'latest.log', 'debug.log'):
        lines = (d/filename).read_text(encoding='utf-8').splitlines()
        text = '\n'.join(lines)
        actual_accepted = re.findall(r'Accepted planetary catalog generation (\d+) with (\d+) bodies, (\d+) routes', text)
        assert actual_accepted == expected_accepted, (phase, filename, actual_accepted)
        routes = [(int(a),int(b)) for a,b in re.findall(r'Planetary route generation=(\d+) id='+HOST+r':earth_moon .* distance=(\d+) bidirectional=true', text)]
        assert routes == expected_routes, (phase, filename, routes)
        errors = [s for s in lines if re.search(r'/ERROR\]', s)]
        assert len(errors) == (6 if phase == 'create-reload' else 0), (phase, filename, errors)
        for error, diagnostic in zip(errors, diagnostics):
            assert 'AdvancedRocketryCommunity' in error and 'Rejected planetary catalog; last valid generation remains active:' in error and diagnostic in error
        assert not re.search(r'/FATAL\]', text)
        assert not any(marker in text for marker in ('NoClassDefFoundError', 'NoSuchMethodError', 'NoSuchFieldError', 'ExceptionInInitializerError', 'Attempted to load class net/minecraft/client'))
        assert len(re.findall('generation 2 retained after rejected reload', text)) == (6 if phase == 'create-reload' else 0)
        moons = re.findall(HOST+r':moon -> '+HOST+r':moon .* landable=false orbitable=false gas_giant=false solar=([0-9.]+) radiation=0.25', text)
        assert moons == (['0.5'] * 6 + ['0.75'] if phase == 'create-reload' else ['0.75']), (phase, filename, moons)
        assert HOST + ':schema_probe_gas -> unmapped gravity=2.5' in text
        assert "Unknown dimension '" + HOST + ":schema_probe_gas'" in text
        assert len(re.findall(r'The time is \d+', text)) == 3
        assert 'Station creation failed: UNKNOWN_ORBIT_BODY' in text
        assert f'Created Schema probe id={station_id} cell=0,0' in text if phase == 'create-reload' else True
        assert 'region=-256,-256..255,255 pad=0,128,0 orbit='+HOST+':moon gravity_milli=0 vacuum=true' in text
        assert 'Stopping server' in text and 'All dimensions are saved' in text
        project_warnings = [s for s in lines if '/WARN]' in s and ('AdvancedRocketryCommunity' in s or '/advancedrocketrycommunity' in s)]
        assert not project_warnings
        logs[phase+'/'+filename] = dict(errors=len(errors), fatal=0, standard_warnings=sum('/WARN]' in s for s in lines),
            lag_warnings=[s for s in lines if "Can't keep up!" in s], accepted=actual_accepted, routes=routes)
    assert load(d/'observations.json')['exit_code'] == 0
    assert load(d/'native-stations.json') == data
    launch = load(d/'launch.json')
    assert launch['artifact']['sha256'] == sha(Path(launch['artifact']['path']).read_bytes())
    assert not any('releaseTestHooks' in arg for arg in launch['command'])
    status = load(d/'status.json')
    assert status['version']['protocol'] == 763 and status['players']['online'] == 0

server = Path(summary['server'])
world = summary['world']
marker = server/world['identity_marker']
mark = load(marker)
assert sha(marker.read_bytes()) == world['identity_marker_sha256']
before = sha((E/'create-reload/level.dat').read_bytes())
after = sha((E/'restart/level.dat').read_bytes())
assert before == world['level_dat_before_restart_sha256'] and after == world['level_dat_after_restart_sha256']
assert sha((server/'world/level.dat').read_bytes()) == after
identity_input = f"{mark['session_id']}\0{mark['artifact_sha256']}\0{before}\0{mark['server_properties_sha256']}".encode()
assert sha(identity_input) == mark['world_identity'] == world['identity']
assert sha((server/'server.properties.v002-startup').read_bytes()) == mark['server_properties_sha256']
jar = Path(summary['artifact']['path'])
assert sha(jar.read_bytes()) == summary['artifact']['sha256'] == sha((server/'mods'/jar.name).read_bytes())
assert len(list((server/'mods').glob('*.jar'))) == 1
assert sha((server/'libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt').read_bytes()) == summary['forge_args_sha256']
installed = server/'world/datapacks/schema_probe/data'/HOST
assert load(installed/'celestial_bodies/moon.json')['solar_intensity'] == 0.75
assert load(installed/'travel_routes/earth_moon.json')['distance_units'] == 222
assert not list(installed.rglob('raw_probe.json'))

report = dict(manifest_files=len(manifest), station_id=station_id, owner_id=owner_id,
              station_compressed_sha256=sha(compressed[0]), station_root_sha256=sha(raw),
              native_root=whole, log_checks=logs, artifact_sha256=sha(jar.read_bytes()),
              whole_level_dat_decoded=False, live_dimensions_only=True, world_marker_recomputed=True,
              startup_properties_hash_verified=True,
              bounds='raw station NBT only; no world/process mutation or server launch')
(OUT/'native-audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
