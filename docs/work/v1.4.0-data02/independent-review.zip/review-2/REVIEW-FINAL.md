# V140-DATA-02 independent targeted execution and native audit

## Findings

No unresolved concrete defect found in the final reviewed production, corrected test fixture or `--check-joint-reload` runner within this slice. This conclusion is not v1.4 completion, a release decision or Gate approval.

1. **Resolved P2 source finding: Gson non-lenient mode accepted malformed JSON.** The separate source checkpoint records the initial finding and pinned bytecode evidence. Final `celestial/data/BoundedDefinitionJson.java:39,50-81` adds bounded raw lexical validation for controls, escapes and keyword spelling; the final independent reader tests pass. Root's original failing reader regression is retained separately; it was not an independent test execution by this reviewer.
2. **Resolved verification defect: packaged baseline has four routes, not three.** The first native attempt timed out against an incorrect three-route marker despite raw logs showing a valid generation 2 with four bodies/four routes. It is retained as FAIL with process exit 1, not a clean successful run. The runner now expects four at `scripts/run_v140_celestial_schema_smoke.py:128,183`. Final `PlanetaryReloadTest.java:54,66,185,221,235,254,314` includes `moon_surface_orbit`, checks four baseline routes, five with the gas route, 100 bodies/101 routes, and a 513-resource overflow. Independent re-execution after the correction passed. Production Java did not change for this correction.

No new production fix or broader framework was requested by this review.

## Identities and scope

- Checkout: `D:/GitHub/AdvancedRocketry-Community`, branch `codex/v1.4.0-planetary-expansion`.
- HEAD/base at both executions and final audit: `4db8b1bc573b6f9f20a20bd2a5a13a0836e055f2`; reviewed DATA-02 files were uncommitted. Full file hashes are in `before.json`, `after-gradle.json`, `final-before.json`, `final-after.json`.
- Source review: new bounded reader, paired catalog/manager/listener, diagnostics; celestial projection, central lifecycle, snapshot and flight capture; adapted GameTest/unit fixtures; operator route diagnostic and final native runner/tests against accepted ADR-030/031. No persistent/public API/channel contract change was found.
- Final reader SHA-256: `c25c70d11c7734ad4c56ef71302f279c59de186d33f89a50d240bbd37e1b0cf0`.
- Final reload test: `65a896e440d2fa855713c1111bc4970c60d50c87ca9c48dfd1caf0136f5e8115`.
- Final runner: `a28cbd37fff623e0f2525725b8139c6f475f5dbfc63880278b3ea6fc7509e2b9`.
- Final Python tests: `ac145e3d678e135c94ecca6d77ecfe9ec6bade0b5846d7ba34158147d0a3e739`.

Prior source-only report remains unchanged at `C:/Users/Administrator/AppData/Local/Temp/arce-v140-data02-review-a00661e20c014ba58ce08ea1f225623b/REVIEW-SOURCE.md`, SHA-256 `742d6672ea958a30930c56425f28256d22586ecd32bc6599611d99d8068e6ac2`.

## Independently executed tests

Working directory for both Gradle commands: the checkout above. Environment: `JAVA_HOME=C:/Program Files/Java/jdk-17.0.7`, with its `bin` first on PATH. Exact argument arrays/start/end times are retained in command/result JSONs.

First command, before the four-route fixture correction:

```text
.\gradlew.bat test --tests '*celestial.*' --tests '*travel.*' --tests '*RocketTargetFlightPlannerTest' --tests '*RocketFlightQuotesTest' --tests '*ServerEnvironmentQueriesTest' --tests '*EnvironmentSnapshotTest' --tests '*ApiArtifactTest' --tests '*ApiVersionsTest' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

- Exit 0; 50.508 seconds; 16 tasks executed, including actual `:test` (not cached XML).
- **167 tests, 25 suites; zero failures/errors/skips.** Raw XML in `junit/`; counts/names in `junit-suites.json`.
- Includes reader/reload, definitions/schema, catalog, snapshots, saved data, legacy import/migration, BodyContext, route graph/fuel formula, target flight planner/quotes, environment queries and API artifact/version checks.
- All 1096 non-runner source/build/test files and all three artifacts unchanged. Root's announced Python-only marker correction changed the runner while Java ran; that file was not Java input. `initial-source-deltas.json` records the one actual file change. The original `check-summary.json` value `source_changed=2` is the two sides of a whole-list Compare-Object difference, not two changed files; original receipt preserved.
- Log `gradle.txt` SHA-256 `41e68af899a296b43cce0783ceb8582e893e927393350c39c233cc0e45a98883`.

Final command, after the four-route fixture correction:

```text
.\gradlew.bat test --tests '*celestial.data.*' --rerun-tasks --offline --no-daemon --no-build-cache --console=plain
```

- Exit 0; 39.324 seconds; 16 tasks executed, including actual `:test`.
- **23 tests, 2 suites (8 reader + 15 reload); zero failures/errors/skips.** Raw XML in `final-junit/`.
- All **1097** hashed source/build/runner/test files and all three artifacts unchanged across this final execution. No generated-resource diff against the base; `git diff --check` also exits 0.
- Log `final-gradle.txt` SHA-256 `630dcea8b9ef6141bab42a4d97b5992c34c2b2e979ec1d664dd3d65a7214df1f`.

Python command, `PYTHONUTF8=1`:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B -m unittest tests.test_v140_celestial_schema_smoke -v
```

- Exit 0; **9 tests pass**, unittest reports 0.212 seconds. Temp fixtures only; bytecode cache suppressed.
- Exact fault-log whitelist rejects absent, extra, duplicate or changed errors rather than suppressing general ERROR/FATAL output. Native station comparison rejects field changes; fixture transforms preserve legacy values; process failure receipts and finite rejection inputs are exercised.
- Log `final-python.txt` SHA-256 `aea080c6dce817fff6df891a42c8687e04a6487cac888943a2794e5fb0443f30`.

No independent full GameTest or Minecraft process was launched. Root's reported 213 GameTests/full build remain root execution evidence, not a rerun by this reviewer. Gradle slots were explicitly released after both terminal results.

## Artifact audit

`artifact_audit.py` independently opened the frozen root artifacts and compared build outputs, ZIP CRCs, unique entry names, exclusion of external fixture code/resources, exported class set and class bytes. Exit 0; output retained in `artifact-audit.json/txt`.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| main | 2396291 | `9e90d868bd53fca8188c25cdb054cb2d2b578da6d46f1d00156fe22367db02e5` |
| API | 48469 | `50cc9ba02bc979c31e1579a840431247ffe8401114aff013ddf478f0765010bf` |
| sources | 1090318 | `4f98f37796a3e9fbc11afd421ea88ec7422ba0a989818aa973234609632f5542` |

All three equal root frozen copies and remain unchanged after both independent Gradle runs. API contains exactly **27** classes, all byte-identical to main; the **entire API JAR** equals the recorded v1.3 handoff API. Four actual packaged route JSON entries were enumerated, independently confirming the corrected count. No consumer mod was rebuilt or loaded by this review.

## Native evidence audit

Read-only source: `C:/Users/Administrator/AppData/Local/Temp/arce-v140-data02-1790496634817/native-evidence-2`, plus stopped `server-2` identities and frozen `artifacts/`. `native_audit.py` uses its own bounded binary NBT reader for actual compressed station files, not the runner's decoded JSON as authority. Helper exit 0; helper and derived JSON/text retained here. No world or capture was changed.

Observed facts:

- **40/40 manifest files** match recomputed hashes; manifest is complete, unique and contains no escaping path. Raw malicious fixture bytes are exactly the six declared cases: body/route syntax, duplicate key, depth 17, 4097 route bytes, missing endpoint body. Each retained candidate also contains Moon solar **0.75** and route distance **222**.
- In each of `stdout.txt`, `latest.log`, `debug.log`, create phase accepts `(generation,bodies,routes)` **(1,3,4)**, then **(2,4,4)**. All six rejected candidates leave generation **2**, route **123** and Moon solar **0.5** visible. Removing the bad resource accepts **(3,4,4)** with route **222** and solar **0.75**. Restart accepts **(1,4,4)** with the same repaired 222/0.75 values. Generation reset on new process is expected lifecycle behavior, not persisted generation continuity.
- Command receipts show **eight reloads** in the first process, none in restart. Corrected phase records both process exits **0**; raw logs contain stop, world-save and all-dimensions-saved completion. These are audited recorded exits, not processes independently started or monitored by this reviewer.
- Before reload, after rejection/repair and after restart, compressed station SavedData is **byte-identical**, and independently decoded full roots match. Station UUID `c08e7b79-a36d-4468-a544-327120c7243d`, owner `a48e8296-4464-4f77-8aed-5efaef6a11bd`, orbit Moon, pad `[0,128,0]`, region `[-256,-256,255,255]`, registry schema 2/station schema 1, empty reservations/members/invitations. Native values bind to actual creation/inspection commands and log receipts, not only the summary.
- Compressed station SHA-256 `249cc3c87018e3998554463dd0b8675977b06ceac1b01e6cf0c5dcfcfde66644`; uncompressed whole-root SHA-256 `12ea625b58cd51e55318854935f2a1d96b3c0ce90bbf6a42cac4a81f57bb246a`.
- Both processes retain the Moon station while refusing new Moon creation with `UNKNOWN_ORBIT_BODY`. Three live fixed-Level time queries succeed and the gas dimension query is rejected. This is **live dimension resolution**, not decoding the complete level.dat registry.
- Main artifact, installed sole mods JAR, launch receipts and Forge args hashes agree. Recomputed same-world identity binds the before-restart level.dat hash, startup-properties bytes, session marker and artifact. Raw after-restart level.dat matches stopped disk. Whole level.dat was deliberately **not decoded**.
- All three log variants have exactly **six intentional project ERROR rejection lines** in create phase and zero in restart; no additional ERROR, FATAL, project WARN or checked client-linkage failures. Ordinary standard WARN counts are **26/10**. First phase retains **2003 ms / 40 ticks** `Can't keep up`; no performance acceptance is inferred.
- Original `native-evidence/` remains a separate failed attempt: actual accepted four-route logs, wrong three-route wait marker, FAIL and process exit **1**. It is not relabeled by the correction.

## Boundaries and remaining work

The reader/reload tests prove the finite authored 100-body/101-route case, graph rejection and exact object/cache retention. Native checks prove this local four-body/four-route successful/rejected reload, station authority retention and clean restart. They do not prove reference-load throughput, arbitrary pack/provider behavior, full Forge/assets rollback, forced storage crash cuts, old-world upgrade, cross-restart custom body/Level binding, new explorable worlds, real-client snapshots/visuals, multiplayer or remote operation. Platform resource enumeration occurs before the project count check; bounded project parsing is not a claim of bounded native enumeration or I/O duration.

Tracked files and the Git index remained reviewer-read-only. Only authorized Gradle build/cache output, Python temporary fixtures and this review directory were written. The excluded user documentation bundle was neither read nor changed. No remote/network credentials, OpenPet, subagents or process termination were used. Root owns implementation, final documentation/checksum packaging and commits. Continue only the current v1.4 remaining DATA/MAP/MIG work and deferred acceptance obligations; this review does not mark all Required Gates satisfied.
