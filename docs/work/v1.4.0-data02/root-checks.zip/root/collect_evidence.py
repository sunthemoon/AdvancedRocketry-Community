"""Collect DATA-02 scoped evidence without reading the user documentation bundle."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).parent
OUT = ROOT / 'docs/work/v1.4.0-data02'
BASE = '4db8b1bc573b6f9f20a20bd2a5a13a0836e055f2'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()


def archive(name, groups):
    identities = []
    with zipfile.ZipFile(OUT / name, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for prefix, parent, paths in groups:
            for path in sorted(paths):
                if path.is_file():
                    member = prefix + path.relative_to(parent).as_posix()
                    zipped.write(path, member)
                    identities.append({'member': member, 'bytes': path.stat().st_size, 'sha256': digest(path)})
    with zipfile.ZipFile(OUT / name) as zipped:
        assert zipped.testzip() is None
        assert len(zipped.namelist()) == len(set(zipped.namelist()))
    return identities


def capture():
    OUT.mkdir(parents=True, exist_ok=True)
    suites = [ET.parse(path).getroot() for path in (TEMP / 'root-junit').glob('TEST-*.xml')]
    counts = {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
                                    for key in ('tests', 'failures', 'errors', 'skipped')}}
    log = (TEMP / 'clean-build-data-gametest-1.log').read_text(encoding='utf-8')
    assert counts == {'suites': 148, 'tests': 815, 'failures': 0, 'errors': 0, 'skipped': 0}
    assert 'All 213 required tests passed' in log and 'BUILD SUCCESSFUL in 2m 30s' in log
    assert '> Task :test\n' in log and 'written: 0' in log
    write(OUT / 'root-checks.json', {'base': BASE, 'junit': counts, 'required_gametests_passed': 213,
          'command': 'gradlew.bat clean build runData runGameTestServer --offline --no-daemon --console=plain',
          'exit_code': 0, 'seconds': 150, 'datagen_written': 0,
          'qualification': 'Production Java is final; final fixture inventory correction is checked separately.',
          'failures_retained': ['raw-json-2.log: 7 tests / 1 control-character rejection failure',
                                'native-1.log: harness expected 3 routes instead of the actual packaged 4'],
          'scope': 'Development checks, no full acceptance or Gate PASS'})
    groups = [('root/', TEMP, [p for p in TEMP.iterdir() if p.suffix in ('.log', '.py')])]
    for name in ('root-junit', 'gametest-logs', 'failed-raw-json-2'):
        parent = TEMP / name
        groups.append((name + '/', parent, parent.rglob('*')))
    archive('root-checks.zip', groups)
    artifacts = [{'name': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)}
                 for path in sorted((TEMP / 'artifacts').glob('*.jar'))]
    prior = json.loads((ROOT / 'docs/work/v1.4.0-data01/development-artifacts.json').read_text())
    api = next(a for a in artifacts if a['name'].endswith('-api.jar'))
    assert api in prior['artifacts']
    write(OUT / 'development-artifacts.json', {'build': '1.20.1-1.4.0-dev', 'artifacts': artifacts,
          'api_version': '1.7', 'api_byte_identical_to_data01_and_v130': True, 'candidate_commit': None})
    print(counts)


def sources():
    scopes = ['src', 'scripts/run_v140_celestial_schema_smoke.py', 'tests/test_v140_celestial_schema_smoke.py']
    paths = set(git('diff', '--name-only', BASE, '--', *scopes).splitlines())
    paths.update(git('ls-files', '--others', '--exclude-standard', '--', *scopes).splitlines())
    records = []
    for name in sorted(paths):
        if not name:
            continue
        path = ROOT / name
        if path.exists():
            records.append({'path': name, 'bytes': path.stat().st_size, 'sha256': digest(path),
                            'git_blob': git('hash-object', '--', name)})
        else:
            records.append({'path': name, 'deleted': True, 'base_blob': git('rev-parse', BASE + ':' + name)})
    write(OUT / 'source-identity.json', {'base_commit': BASE, 'files': records})


def native():
    parent = TEMP / 'native-evidence-2'
    summary = json.loads((parent / 'summary.json').read_text())
    assert summary['result'] == 'PASS' and summary['joint_reload']
    write(OUT / 'native-summary.json', summary)
    server = TEMP / 'server-2'
    world_inputs = [server / 'world/.v002-smoke-world-identity.json', server / 'server.properties',
                    server / 'server.properties.v002-startup']
    world_inputs.extend((server / 'world/datapacks/schema_probe').rglob('*'))
    archive('native-restart.zip', [('native/', parent, parent.rglob('*')), ('world-inputs/', server, world_inputs)])
    failed = TEMP / 'native-evidence'
    archive('native-attempt-1.zip', [('native-failed/', failed, failed.rglob('*'))])


def reviews():
    groups = []
    for index, name in enumerate(sys.argv[2:]):
        parent = Path(name)
        groups.append((f'review-{index + 1}/', parent, parent.rglob('*')))
    entries = archive('independent-review.zip', groups)
    write(OUT / 'independent-review.json', {'reviewer': '/root/prec04b_readback_review',
          'archive_sha256': digest(OUT / 'independent-review.zip'), 'entries': entries})


def links():
    paths = {ROOT / name for name in git('ls-files', '--', '*.md').splitlines()}
    paths.update(OUT.glob('*.md'))
    missing, count = [], 0
    for path in sorted(paths):
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith(('#', 'mailto:')) or re.match(r'^[A-Za-z]:[/\\]', target):
                continue
            relative = urllib.parse.unquote(target.split('#', 1)[0])
            if relative:
                count += 1
                if not (path.parent / relative).exists():
                    missing.append([path.relative_to(ROOT).as_posix(), target])
    write(OUT / 'links.json', {'markdown_files': len(paths), 'local_targets': count, 'missing': missing,
          'scope': 'File existence only; not external URLs or anchors'})
    assert not missing, missing
    print('Local links:', len(paths), count)


def checksums():
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{digest(path)}  {path.name}\n' for path in sorted(OUT.iterdir())
             if path.is_file() and path.name != 'SHA256SUMS.txt'), encoding='ascii', newline='\n')


def verify():
    for line in (OUT / 'SHA256SUMS.txt').read_text().splitlines():
        sha, name = line.split('  ', 1)
        assert digest(OUT / name) == sha, name
        blob = subprocess.check_output(['git', 'show', ':' + (OUT / name).relative_to(ROOT).as_posix()], cwd=ROOT)
        assert hashlib.sha256(blob).hexdigest() == sha, 'staged ' + name
        if name.endswith('.zip'):
            with zipfile.ZipFile(OUT / name) as zipped:
                assert zipped.testzip() is None
                assert len(zipped.namelist()) == len(set(zipped.namelist()))
    for item in json.loads((OUT / 'source-identity.json').read_text())['files']:
        if item.get('deleted'):
            assert not (ROOT / item['path']).exists()
            assert not git('ls-files', '--stage', '--', item['path'])
        else:
            assert digest(ROOT / item['path']) == item['sha256'], item['path']
            assert git('rev-parse', ':' + item['path']) == item['git_blob'], item['path']
    print('Working/staged checksums, ZIP CRC/member uniqueness and source/deletion identities match.')


if __name__ == '__main__':
    {'capture': capture, 'sources': sources, 'native': native, 'reviews': reviews,
     'links': links, 'checksums': checksums, 'verify': verify}[sys.argv[1]]()
