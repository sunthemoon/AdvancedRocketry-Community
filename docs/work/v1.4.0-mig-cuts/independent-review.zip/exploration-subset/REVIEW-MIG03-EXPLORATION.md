# V140-MIG-03 packaged interruption exploration

2026-09-28; delegated independent read-only reviewer.
Repository `D:/GitHub/AdvancedRocketry-Community`, HEAD
`b56e40e1c42c4e5b28cfdc4fcdbd64ead8530f1a`.
No repository/index edits, Gradle, game JVM, server, remote, or subdelegation.
This is feasibility/source review, not executed interruption evidence.

## Findings / requirements, ordered by significance

### P1 instrumentation risk: detaching before killing invalidates the cut

A matched breakpoint must suspend all target threads and remain held until the
owned target has actually terminated. Emitting a marker and exiting/disposal of
the debugger before the parent kills the server can allow the claim to complete.
Pinned JDK 17.0.7 `VirtualMachine.java:449-466` states that disposal cancels requests
and resumes suspended threads. `EventRequest.java:156-180` defines SUSPEND_ALL.
The exact local source excerpts are retained here. This is a proposed harness
requirement, not a finding in an existing implemented MIG-03 harness.

Use the parent's exact owned Process/Popen handle for force termination while
the debugger waits with the event held. Record the breakpoint identity and
authority bytes before kill, target termination receipt, and byte-identical
two-store authority observations after kill. Only then close the debugger.
Do not send `stop`, detach, resume, invoke `System.exit`, or allow a general
cleanup helper to perform graceful shutdown before the requested cut. JDI
`VirtualMachine.exit` is an alternative with documented abrupt-thread semantics
(`VirtualMachine.java:474-489`), but OS termination of the already-owned process
has the simpler existing harness ownership boundary.

### P2 oracle requirement: an unpaid durable READY mission must not auto-award

Claim first mutates the mission/account in memory; the first atomic replacement
is the first durable paid receipt. Before it, disk still has READY, zero payment,
no discovery. Startup deliberately queues only paid pending/claimed receipts:
[SatelliteManager:419-431](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L419),
[DiscoveryClaimRecovery:19-21](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryClaimRecovery.java#L19).
Therefore that pre-first-commit case must first demonstrate unchanged/unpaid
state after restart, then submit one explicit claim retry. Requiring automatic
completion there would manufacture authority from an uncommitted operation or
scratch file. Paid interior cuts should recover before any new manual claim.

### P2 isolation requirement: do not count every AtomicSavedData write

Both stores also save from ordinary autosave, launch, scheduler completion, and
startup replay. A global nth-write breakpoint can hit a different transaction.
Filter the actual event by class, exact overloaded method descriptor, location,
server thread, enclosing `DiscoveryClaimRecovery.recover` frame, selected
mission UUID, and concrete store type. Count only those matching events, with
the expected sequence MISSIONS / CELESTIAL / MISSIONS. Record nonmatching-event
counts and a finite maximum; mismatched context is a failed setup, not a pass.
Relevant paths:
[SatelliteManager:67-91](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L67),
[SatelliteManager:448-492](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/SatelliteManager.java#L448).

### No production/contract change identified as necessary for these observations

The existing final artifact retains line/local-variable metadata sufficient for
nonmutating observation. ADR-038 already scopes process interruption and excludes
portable hardware-power-loss guarantees. A finite helper may be external; no
new game event hook, Java agent, production callback, save schema, method
invocation, field mutation, NBT rewrite or disk-file obstacle is needed.
Debugger suspension changes execution timing, so this remains instrumented
packaged-process S2 evidence, not timing or undebugged hardware-failure proof.

## Actual artifact / viable breakpoint sites

Read-only `javap -p -c -l` inspected the frozen packaged host:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-worlds-608e947bd8c34249bc523f49858267b8/artifacts/advancedrocketry-community-1.20.1-1.4.0-dev.jar`

SHA-256: `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475`.
Output: `atomic-saved-data-javap.txt`.

Class:
`io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.AtomicSavedData`

Method remains named `flush`, exact descriptor:
`(Ljava/nio/file/Path;Lio/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData$Committer;)V`.

| Location | Packaged BCI | Meaning |
|---|---:|---|
| source line 90 | 326 | Staging file written, forced, closed, bounded-readback verified; before `Committer.commit` |
| source line 100 | 394 | Successful atomic replacement returned; before dirty-state acknowledgment |

Source:
[AtomicSavedData:57-102](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData.java#L57).
Both locations have `this`, `file`, `pending` and method arguments available.
Line 90 also has `outer` and `encoded`; they are no longer in local scope at
line 100. Use the line/method/BCI only after exact JAR/class identity checks;
do not assume these numbers survive rebuilding changed source. Fail if the
expected class/method/location is absent or ambiguous. Reobfuscated inherited
Minecraft methods have SRG names, but the selected host method is unchanged.

The `type` field identifies the two stores. Read enum/string/UUID fields and
argument values through JDI getters; do not invoke `Path.toString`, enum getters,
NBT serialization, or any method in the target VM. `StackFrame.getArgumentValues`
is available in the pinned local JDI API. The UUID argument of the enclosing
`recover` frame can bind the selected mission without executing target code.

## Minimum useful finite cases and tradeoffs

Two interior forced cuts (paid receipt without discovery, then discovery without
finalized mission) are the strict minimum new native evidence for ordered
two-store recovery. A compact **three-case** version at line 90 additionally
checks that a completely written but uncommitted scratch receipt is not treated
as authority. It uses the same prepared closed baseline copied to three disjoint
world directories; no disk state is fabricated or edited between stop/restart.

| Case | Matching pre-replacement hit | Durable mission/account | Durable discovery | Restart criterion |
|---|---|---|---|---|
| A | first MISSIONS | READY, uncredited/unspent | absent | No auto-credit; explicit retry then exact one payment/discovery |
| B | CELESTIAL | CLAIM_PENDING_DISCOVERY, paid once | absent | Automatic claim completion before another claim command |
| C | second MISSIONS | CLAIM_PENDING_DISCOVERY, paid once | present | Automatic finalization; preserve existing discovery timestamp |

The pending scratch differs intentionally: A contains a paid receipt, B a new
discovery, C a completed mission. Capture it separately, but never promote,
delete, rename, copy over an authority or feed it to the restart. The unchanged
runtime handles its own scratch on retry:
[AtomicSavedData:59,73-85](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData.java#L59).

Using post-replacement line 100 for the first two barriers observes the same
important durable authority pairs without a pending next-stage scratch. This
is a valid smaller alternative; report which exact points were exercised. A
fourth post-final-mission cut is optional if the desired native claim includes
all three acknowledgments; existing A0 tests already cover before/after each
barrier and MIG-02 covers final clean restart. Do not silently label two or
three native cuts as exhaustive arbitrary-cut testing.

Prepare via existing normal operator commands on a disposable world copy:
one fresh owner's mission to a still-undiscovered available target, wait for
READY, `save-all flush`, clean stop and bounded raw readback. The existing
MIG-02 final world has gas giant undiscovered; its currently allowed research
target avoids new content authoring. A fresh owner yields an uncomplicated
expected account delta **0/0/0 -> 20/120/100** using the existing captured
120 yield / 100 fee. The prepared mission/satellite IDs and captured duration,
target, definition, owner and snapshots must be identical in all scenario copies.

Existing source semantics justify this matrix:
[SatelliteMissionRegistry:283-339](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/mission/SatelliteMissionRegistry.java#L283)
charges once and pending/claimed retries do not credit again;
[DiscoveryClaimRecovery:24-46](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryClaimRecovery.java#L24)
writes receipt, discovery, completion in order;
[CelestialSavedData:160-179](D:/GitHub/AdvancedRocketry-Community/src/main/java/io/github/sunthemoon/advancedrocketrycommunity/celestial/persistence/CelestialSavedData.java#L160)
publishes a discovery only after its supplied writer returns.

## Native observations and bounds to require

- Loopback-only JDWP address, newly allocated owned port, disposable copy only;
  bind exact Java executable / Forge args / host / consumer hashes. No public
  debugger listener or remote credentials. Install one location request only
  after class identity/preparation; signal ARMED before issuing claim.
- Set SUSPEND_ALL explicitly. At the target event keep the debugger alive,
  retain stack/thread/store/mission/location receipt, and let the parent read
  only the two authorities and existing scratch files under strict quotas.
  Files must be regular and inside the owned world's `data` directory.
- Finite attach/arm/hit/kill/restart deadlines and event/log budgets; no retry
  loop that silently hunts a passing cut. Missing target, unexpected VM exit,
  timeout, incomplete copy or hash disagreement is a retained failure.
- The exact kill process is the owned handle, not a process-name search or
  blanket Java termination. Do not stop unrelated processes. On failures retain
  the world, diagnostics and exact exit/status distinction; intentional kill is
  not a clean exit or a startup PASS. Hold the event until target exit even if
  audit capture itself fails. Confirm both owned ports close afterward.
- Capture authoritative compressed bytes while suspended, immediately after
  kill, before restart, and after recovered clean stop. Require the first two
  authority pairs equal; retain scratch separately. **No active/killed-region
  decoding assumption:** MIG-02 already showed files may be unpadded until clean
  region close. Full region/NBT checks belong after the recovered clean stop.
- Bind mission, satellite, owner, target/definition, captured reward/cost/duration,
  status, current-mission linkage, root/record schema, accounts and discovery
  timestamps. Allow only documented scheduler clock advancement and required
  phase/discovery changes. Keep other historical records exact. No fabricated
  visit. Require target absent before first credit and exact once-only account
  delta. After automatic recovery, repeated claims must be ALREADY_CLAIMED with
  no payment or timestamp change.
- A ready/unpaid scratch must remain ignored on startup (case A); complete it
  only through the explicit claim afterward. For B/C, observe restored state
  before manually claiming, so manual retry cannot mask broken startup replay.
- Do not broaden this evidence to terminal inventory/chunk atomicity, whole
  world bytes, disk loss, hardware power failure, player/network/GPU behavior or
  performance. The two authority file replacements remain the exact scope.

## Existing tests and observations, not newly executed

[DiscoveryClaimRecoveryTest:38-67](D:/GitHub/AdvancedRocketry-Community/src/test/java/io/github/sunthemoon/advancedrocketrycommunity/satellite/service/DiscoveryClaimRecoveryTest.java#L38)
contains six real-file before/after barrier cuts and repeated reload/recovery;
its test explicitly calls `claim` after reload, so it does not itself establish
native startup auto-replay. Other cases test same-process failures, paid claimed
repair, full/future/absent targets and newer active mission preservation. Runtime
startup queue uses at most eight receipts/tick and clears on stop; absent or
failed work rotates/backs off. These explain expected criteria, not new test
results in this review.

No tracked JDI helper was found by `git ls-files '*jdi*' '*Jdi*' '*jdwp*'
'*interruption*'` or the scoped source/document searches. This is not a claim
that every old Temp archive was exhaustively searched. The pinned JDK's own
JDI sources and the actual packaged host metadata are sufficient for the
limited feasibility recommendation.

## Actual commands / evidence / limits

Executed read-only Git status/HEAD/source searches and file reads; one mistaken
search named nonexistent `MissionRegistry.java` before the actual
`SatelliteMissionRegistry.java` was read. Short `javap` command:

```text
C:/Program Files/Java/jdk-17.0.7/bin/javap.exe -classpath <frozen-host.jar> -p -c -l io.github.sunthemoon.advancedrocketrycommunity.persistence.migration.AtomicSavedData
```

It completed successfully, output retained in this directory. Short Python
`-B` read the local `jdk-17.0.7/lib/src.zip`; four relevant original JDI source
files are retained for audit only. No helper or JDI attach has been implemented
or executed here; actual handshake, Forge class loading, Windows termination,
leftover scratch and restart outcomes are **unverified** until separately run.
No source/API/schema modification is recommended solely to make these cuts
observable. Root owns the finite case selection and any implementation;
independent actual-diff/command review remains subsequent work. No Gate approval.
