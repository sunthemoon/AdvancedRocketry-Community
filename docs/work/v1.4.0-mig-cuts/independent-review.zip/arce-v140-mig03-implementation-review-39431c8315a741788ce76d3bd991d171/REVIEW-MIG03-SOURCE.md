# V140-MIG-03 independent source and targeted-check review

2026-09-28. Delegated independent reviewer; tracked/index read-only.
Base: `b56e40e1c42c4e5b28cfdc4fcdbd64ead8530f1a`,
`D:/GitHub/AdvancedRocketry-Community`.
Scope: external Java observer, two Python harness/oracle files, their tests and
active MIG-03 worklog diff. No production change or version Gate approval.

## Findings

### Resolved P2: scratch deletion was incorrectly required before an unpaid retry

The initial `run_v140_discovery_cut_smoke.py:193` required an empty scratch set
after restart, even for cut 1. ADR-038 permits an uncommitted regular scratch
file to remain until a later write. AtomicSavedData only overwrites it during a
store flush; a clean READY store need not become dirty merely to remove it.
Thus the essential pre-retry invariant is READY/unpaid/no discovery, not scratch
deletion. An intervening dirty scheduler save could mask this overly strict
oracle, but was not guaranteed.

The actual first native attempt failed at precisely that assertion, not in
production claim recovery. Independently decoded raw `paused`, `killed`,
`before-restart` and `before-manual-claim` captures show:

- durable mission READY, account **0/0/0**, target absent;
- scratch mission paid-pending, account **20/120/100**;
- scratch bytes unchanged across restart;
- paused/killed/pre-restart authority and scratch bytes identical.

Raw original attempt remains under
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-cuts-2cee140e075a4234b93df8bb6df2d28e/native`.
The helper's actual marker records line 90, BCI 326, first mission-store write,
the selected mission UUID, and disconnection after the owned kill. Kill receipt
exit 1 / probe exit 0 is distinct from the later failed recovery phase.
Reviewer helper and observations: `inspect_failed_cut1.py`,
`failed-cut1-readback.log`, `failed-cut1-readback.json`.

Final correction:
[fixture:159-170](D:/GitHub/AdvancedRocketry-Community/scripts/v140_discovery_cut_fixture.py#L159)
allows boundary-1 scratch to be absent **or exactly the killed scratch**, including
its captured bytes/hash metadata. Authority still must remain READY/unpaid and
undiscovered. Paid recovery cases still require no scratch. The explicit claim
and repeated claim still must clear it:
[runner:187-203](D:/GitHub/AdvancedRocketry-Community/scripts/run_v140_discovery_cut_smoke.py#L187).
[test:96-115](D:/GitHub/AdvancedRocketry-Community/tests/test_v140_discovery_cut_smoke.py#L96)
covers retained/cleared scratch and rejects changed bytes, changed scratch,
premature payment and paid recovery with scratch. This corrects the test oracle
without changing runtime behavior or treating scratch as authority.

### P3 non-passing-path limitation: observer disposal can resume after its timeout

[DiscoveryCutProbe:63-113](D:/GitHub/AdvancedRocketry-Community/scripts/java/DiscoveryCutProbe.java#L63)
holds the reached event on the normal path, but its 45-second deadline/error
finally calls `vm.dispose()`. If the parent stalls while reading the suspended
files until that deadline, disposal can resume the VM before parent cleanup.
This does **not** presently create an accepted false cut: the parent requires a
live observer, successful observer exit with the disconnect marker, and identical
paused/killed captures. The Java timeout exits unsuccessfully; the failed world
can nevertheless advance before the parent's force kill. Retain it as a failed
attempt, not an immutable held-boundary observation. Optional future hardening
could make a reached-observer failure terminate the attached owned target before
disposal; do not imply that path was exercised by passing native evidence.

No other concrete correctness finding in this inspected revision. The four-case
native result remains **unverified by this report** until final raw audit.

## Source assessment

- Java uses loopback SocketAttach, bounded 10-second attach / 45-second event
  window / 32 event-set / 96-frame limits, exact class/method signature and
  pinned line/BCI, SUSPEND_ALL, recovery/claim stack and selected UUID filters.
  It checks store order MISSIONS / CELESTIAL / MISSIONS and records method
  bytecode digest. It only reads target fields/arguments; no target method
  invocation, field mutation, class redefinition or injected game branch.
- The parent arms the observer before issuing the one claim, reads bounded
  two-store files while suspended, kills only its owned Popen handle, requires
  abnormal target exit plus successful held-cut disconnection, and compares
  exact captures before/after kill. The whole owned world inventory is checked
  unchanged from after kill until restart; no file repair/promotion occurs.
- Cases 1/2/3 use line 90 / BCI 326 before replacement; case 4 uses line 100 /
  BCI 394 after the third replacement. Disk states are respectively READY/no
  discovery, paid pending/no discovery, paid pending/discovered, claimed/discovered.
  Scratch is separately validated for the next prospective transition.
- Restart for cases 2-4 must show CLAIMED before manual claims. Case 1 first
  shows READY/unpaid; only its explicit retry may pay. Raw account comparisons
  require exactly **20/120/100**, maintain mission snapshots/linkages and timestamps,
  preserve unrelated history, and reject fabricated visit fields. Only the two
  validated scheduler clock fields are ignored.
- Preparation uses the authentic original-world copy inside MIG-02 evidence,
  **not MIG-02's upgraded final world**. It boots that copy on the current host
  and creates a new captured Mars mission for fresh owner 000...005. Full
  original and prepared copies remain immutable; every cut starts independently.
  This is coherent with a two-store interruption slice, not a new claim of
  rocket/station migration coverage.
- Capture is limited to the two atomic `.dat` authorities and existing scratch;
  it makes no active or force-killed Anvil padding assumption. Exact mod set,
  loopback server status, checksums, process receipts and original failure logs
  are retained. Native phase PASS for a cut means the intentional abnormal
  termination was observed, not that its JVM exited cleanly.
- Worklog remains in progress with finite four-cut scope and no public API,
  save-schema, production branch, real-player, GPU, load or power-loss claim.

## Independently executed commands and results

Python environment: `PYTHONUTF8=1`; executable
`D:/python/pyenv/pyenv-win/shims/python.bat`, no bytecode cache (`-B`).

```text
python.bat -B -m unittest tests.test_v140_discovery_cut_smoke tests.test_v140_migration_smoke tests.test_v140_celestial_schema_smoke tests.test_v140_planetary_worlds_smoke -v
```

- Initial inputs: **56 methods PASS**, exit 0, unittest **1.745 s**, outer
  **2.501083 s**. This is 13 new cut methods plus 43 adjacent methods.
- Corrected inputs: **57 methods PASS**, exit 0, unittest **1.411 s**. This is
  14 new cut methods plus 43 adjacent methods. Exact outer timing/command in
  `python-corrected-result.json`; full raw output retained separately.
- Both executions have before/after identities; no within-run input drift.
  The initial revision/snapshots/logs were not replaced by the corrected ones.

```text
C:/Program Files/Java/jdk-17.0.7/bin/javac.exe --add-modules jdk.jdi -d <review-Temp>/classes <review-Temp>/DiscoveryCutProbe.java
```

Independent helper compilation **exit 0**; output and command receipt in
`javac.log` / `javac-result.json`; class file retained. Java helper is unchanged
by the Python correction, so this compiled source is the final inspected helper.
No helper attachment or game JVM was launched by this reviewer.

Short `python -B inspect_failed_cut1.py` **exit 0** reread original raw compressed
NBT using the existing bounded byte decoder (not runner verdicts), establishing
the scratch/authority distinction above. No captured world or evidence was edited.
Other commands were read-only Git/rg/Get-Content/hash checks. One rg invocation
used unexpanded PowerShell wildcard filenames and failed; no assertion or
review conclusion relies on that search.

## Corrected inspected identities

| Input | SHA-256 |
|---|---|
| DiscoveryCutProbe.java | `536ebc2ba5443624d6ff339b4383edb76e14347c8fee3c8050026c013aca9d72` |
| v140_discovery_cut_fixture.py | `10a915f9f12c344e62d04de677c236634710a7d3df6d55126ae27131312b546e` |
| run_v140_discovery_cut_smoke.py | `96d8ecde2d50f41708b0c94b316e9e1a56904aba003ec747950392ddb79e5059` |
| test_v140_discovery_cut_smoke.py | `2cb2a6b0961a9bf5b5b0ec4b48200f09796bdab2d88508bb69b1b5889a12d688` |

## Remaining verification and scope

Final native attempt is running under root ownership; this report certifies
neither its summary nor all four actual breakpoints/restarts. A separate raw
manifest/authority/receipt/log audit is required after it terminates. No server,
Gradle, remote, client, V1/V2, general load or power-loss test was run here.
Java compilation alone proves syntax/dependency correctness, not actual JDI
attachment or every failure path. The root-controlled final build and full
GameTests remain separately attributed. No full Gate approval.

Only this fresh Temp directory was written. It contains project snapshots,
compiled project helper and review logs; **no copied JDK source text**. The
earlier exploration's original local evidence remains separate and unchanged;
root will archive its explicitly chosen non-JDK subset.
