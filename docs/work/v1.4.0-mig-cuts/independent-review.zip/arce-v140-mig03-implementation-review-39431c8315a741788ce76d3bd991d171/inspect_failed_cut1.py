"""Read the retained first attempt; no runtime or captured-world writes."""
import hashlib,json,sys,uuid
from pathlib import Path
sys.path.insert(0,'D:/GitHub/AdvancedRocketry-Community')
from scripts.run_v140_celestial_schema_smoke import read_nbt
root=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-cuts-2cee140e075a4234b93df8bb6df2d28e/native')
out=Path(__file__).parent
mission=json.loads((root/'mission.json').read_text())
def uid(a): return str(uuid.UUID(int=int.from_bytes(b''.join((v&0xffffffff).to_bytes(4,'big') for v in a),'big')))
def read(folder):
    result={}
    for path in sorted(folder.glob('*.dat*')):
        result[path.name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'data':read_nbt(path)['data']}
    return result
captures={name:read(root/rel) for name,rel in [('paused','cut-1/kill/paused'),('killed','cut-1/kill/killed'),('before_restart','cut-1/before-restart'),('before_manual','cut-1/recovery/before-manual-claim')]}
assert captures['paused']==captures['killed']==captures['before_restart']
authority='advancedrocketrycommunity_satellite_missions.dat'
scratch=authority+'.arce-pending'
observations={}
for name,files in captures.items():
    actual=files[authority]['data']; pending=files[scratch]['data']
    m=next(m for m in actual['missions'] if uid(m['mission_id'])==mission['mission'])
    pm=next(m for m in pending['missions'] if uid(m['mission_id'])==mission['mission'])
    a=next(a for a in actual['research_accounts'] if uid(a['owner_id'])==mission['owner'])
    pa=next(a for a in pending['research_accounts'] if uid(a['owner_id'])==mission['owner'])
    progress=files['advancedrocketrycommunity_celestial.dat']['data']
    assert m['status']=='ready' and pm['status']=='claim_pending_discovery'
    assert [a[k] for k in ['balance','lifetime_earned','lifetime_spent']]==[0,0,0]
    assert [pa[k] for k in ['balance','lifetime_earned','lifetime_spent']]==[20,120,100]
    assert mission['body'] not in [b['id'] for b in progress['bodies']]
    assert files[scratch]==captures['killed'][scratch]
    observations[name]={'authority_state':m['status'],'scratch_state':pm['status'],'account':[0,0,0],'scratch_account':[20,120,100],'file_hashes':{n:v['sha256'] for n,v in files.items()}}
result={'mission':mission,'observations':observations,'finding':'Retained scratch is not promoted: READY/unpaid authority and absent discovery survive restart before explicit retry.'}
(out/'failed-cut1-readback.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
