# V140-MIG-03 independent raw native supplement

## Findings

- No new blocking correctness or evidence-consistency finding in the four recorded final interruption cases. This conclusion is limited to the inspected captures and instrumentation, not release/Gate approval.
- Retained P3 non-passing-path limitation: `D:/GitHub/AdvancedRocketry-Community/scripts/java/DiscoveryCutProbe.java:62-63,103-111` leaves its observation loop at the 45-second deadline and calls `vm.dispose()` in `finally`. A stalled paused capture could therefore resume the target before owner cleanup. The final evidence did not take this path: each probe remained alive until the owned kill and recorded `MIG03_DISCONNECTED_AFTER_CUT`, with identical paused/killed/pre-restart authority bytes. Failed attempts must not be described as indefinitely suspended. The prior source report retains this finding; this audit does not test the timeout branch or recommend claiming it fixed.
- Resolved original oracle error, not a production recovery defect: the first attempt failed on `Recovery left scratch data` before any manual retry. An unpaid authoritative READY mission need not cause automatic replay or scratch deletion. Final boundary-1 evidence retains the exact killed scratch but still requires READY, zero fresh-account amounts and no Mars discovery; the successful explicit claim then clears scratch. Paid cases still require automatic recovery and no scratch.

## Scope and identities

Review time: 2026-09-28. Repository baseline recorded by the preceding source review: `b56e40e1c42c4e5b28cfdc4fcdbd64ead8530f1a`; the root-owned MIG-03 working files are bound by hashes below. No repository/index modifications, server, Gradle or JVM launches were performed for this supplement. The excluded user documentation bundle was not accessed.

Raw evidence root:
`C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-cuts-2cee140e075a4234b93df8bb6df2d28e`

- Final `native-final/SHA256SUMS`: **237 members**, every named byte hash checked, full file-set equality checked, digest `945cb4874713671909858a27c7146d35f0e1f3d2c5d78e4c620e6137acd41617`.
- Original `native/SHA256SUMS`: **103 members**, also independently checked; digest `c6393c36977a81c492a06ecf569c432016e99f81db4f34872e73c627b2bd2c02`.
- Current host: `advancedrocketry-community-1.20.1-1.4.0-dev.jar`, 2,624,223 bytes, SHA-256 `576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475`.
- Historical API consumer: `arce-adapter-compat-test-1.0.0.jar`, 72,583 bytes, SHA-256 `e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47`.
- Actual JAR bytes, duplicate-free ZIP entry sets, mod/version metadata and both installed mod files in each recorded process directory were checked. Actual Forge 47.4.10 argument-file copies match the recorded digest. This is not a new API-classifier or full library re-audit.
- Source provenance: the referenced 269-member MIG-02 manifest and source-summary digest verify. The **34-file original-world** is the historical pre-upgrade world, not the final upgraded MIG-02 world. Preparation under the current host yields a **39-file ready-world**, copied independently for each cut. Original and ready file-set/hashes were independently checked.

### Frozen inputs

Both `inputs-corrected` snapshots and current repository inputs matched these exact hashes; the original `inputs` snapshots also matched the preserved preceding source-review copies.

| Input | SHA-256 |
|---|---|
| `scripts/java/DiscoveryCutProbe.java` | `536ebc2ba5443624d6ff339b4383edb76e14347c8fee3c8050026c013aca9d72` |
| `scripts/v140_discovery_cut_fixture.py` | `10a915f9f12c344e62d04de677c236634710a7d3df6d55126ae27131312b546e` |
| `scripts/run_v140_discovery_cut_smoke.py` | `96d8ecde2d50f41708b0c94b316e9e1a56904aba003ec747950392ddb79e5059` |
| `tests/test_v140_discovery_cut_smoke.py` | `2cb2a6b0961a9bf5b5b0ec4b48200f09796bdab2d88508bb69b1b5889a12d688` |

The native observer class is byte-identical to the preceding independent Temp compilation: `4da92e38456e3a2acd43a9b34a0659e2cdd5f34b459e8f732315bff9fea541fa`. An independent classfile reader extracted the packaged `AtomicSavedData.flush(Path, Committer)` Code bytes, SHA-256 `08e46faf9c8a5da8fbe65abedffabe39f593fc6b530f7279451e4b8a840dfc50`, matching every JDI receipt. The actual LineNumberTable maps line 90 uniquely to BCI 326 and line 100 uniquely to BCI 394. This checks the executed artifact rather than assuming source line numbers prove a breakpoint.

## Independent observations

The helper imports only the existing low-level bounded NBT reader, not MIG-03 success predicates. It decodes the raw two-store and scratch files, constructs expected transitions from the raw prepared baseline, and compares them against both raw subsequent states and emitted projections. It normalizes only table ordering and the two validated nonnegative logical-clock fields; it does not normalize mission/account/history/discovery values.

Mission `e895c8a5-0543-3fb0-89e3-0c162691e733`, satellite `6f79aa6b-007f-4dba-b3c5-d1817a1f6edb`, owner `00000000-0000-0000-0000-000000000005`, target `advancedrocketrycommunity:mars` are bound across raw stores, commands and JDI receipts. Captured start/deadline/ready values are **526/726/740**, duration **200**, yield **120**, discovery cost **100**, discovery-required **1**. Store schemas are 2; mission/satellite/account records are schema 1.

| Cut | Durable authority immediately after kill | Captured scratch | Restart observed before manual claim | Explicit claim/replay |
|---|---|---|---|---|
| 1: before first mission replacement, line 90 / BCI 326 | READY, unpaid, no Mars discovery | paid pending mission | READY; account 0/0/0; no discovery; exactly unchanged scratch retained | SUCCESS, then ALREADY_CLAIMED |
| 2: before celestial replacement, line 90 / BCI 326 | paid pending mission, no Mars discovery | new celestial discovery | automatically CLAIMED, scratch absent | ALREADY_CLAIMED twice |
| 3: before final mission replacement, line 90 / BCI 326 | paid pending mission plus discovery | final CLAIMED mission | automatically CLAIMED, scratch absent | ALREADY_CLAIMED twice |
| 4: after final mission replacement, line 100 / BCI 394 | CLAIMED plus discovery | none | CLAIMED unchanged, scratch absent | ALREADY_CLAIMED twice |

For all four cuts, paused, killed and pre-restart **raw authority/scratch bytes are equal**. Store-selection receipt prefixes are respectively missions; missions/celestial; missions/celestial/missions; missions/celestial/missions. Receipts bind the selected UUID, one server thread, exact breakpoint method bytecode and full suspension.

Every final fresh account is exactly **balance 20 / lifetime earned 120 / lifetime spent 100**. Existing two claimed missions, existing satellite/account and original Earth discovery are preserved. The historical account remains **337/348/11** and Earth discovery time remains **461**. The fresh satellite's current-mission binding is cleared only on CLAIMED; all captured mission identity/definition/target/reward/deadline fields remain exact. No synthetic visit is introduced.

Timestamp checks preserve existing durable values rather than assuming cross-store clocks are a single transaction clock:
- Cut 1 first durable receipt and discovery: 752 / 752.
- Cut 2 durable paid receipt 768 retained; startup discovery 748 remains unchanged by subsequent manual replay.
- Cut 3 receipt/discovery 768 / 768 remain unchanged.
- Cut 4 receipt/discovery 770 / 770 remain unchanged.
Final replays preserve the complete normalized authorities and leave no scratch in any case.

### Process, command and log evidence

Nine distinct recorded server PIDs: one preparation, four cut processes, four recoveries. Preparation and all four recoveries exit **0** after `stop`; all four deliberately killed target processes exit **1**, with no clean-stop command/log. Each cut records `owned Popen.kill`, probe exit 0 and disconnection-after-cut. These abnormal terminations are not relabeled clean runs. Recorded Java executable is JDK 17.0.7; each JDWP endpoint is loopback-only, distinct from its game port. Recoveries contain no JDWP option. All status receipts report zero online players.

Cut commands are exactly catalog validation, selected mission READY inspection, `save-all flush`, then one selected claim. There is no successful claim-response marker before the kill. Recovery mission-status output precedes either explicit claim and proves the automatic/manual distinction above; each recovery includes two explicit claim calls and final clean save/stop.

All three log variants (stdout/latest/debug) were inspected independently. No audited ERROR/FATAL, `NoClassDefFoundError`, `Exception in thread`, or `Can't keep up` timing warning occurred. Bracketed warning counts agree with the runner: preparation **16**, each killed process **15**, each recovery **10**. Each stdout additionally contains one unbracketed `main WARN Advanced terminal features are not available in this environment`; therefore inclusive stdout WARN counts are **17/16/11**, not the runner's bracketed counts. No zero-warning claim is supported.

The initial native attempt remains failed: cut exit 1 and failed recovery exit 1, error `Recovery left scratch data`. Its manifest and input snapshots are retained and independently bound. The prior review independently decoded its unpaid durable state and unchanged scratch; the original evidence was not reinterpreted as a passing run.

## Commands and evidence produced by this reviewer

Primary audit command, from the repository with `PYTHONUTF8=1`:

```text
D:/python/pyenv/pyenv-win/shims/python.bat -B C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig03-native-review-ce6d862db90c4f1485f7cdf0cb71d76c/audit_native.py
```

Actual result: **exit 0**, outer duration **1.3556235 seconds**, `OBSERVATIONS_VERIFIED`. Exact command receipt, assertions, raw console output and derived observations are retained as `audit-command.json`, `audit_native.py`, `audit.log`, `observations.json`. This helper passed on its first execution. Read-only PowerShell `Get-Content` was then used to inspect those outputs and probe lines 60-125; both reads exited 0. No further runtime command was executed.

The preceding, separate immutable source review records the independently executed **57 Python tests** and Temp-only `javac --add-modules jdk.jdi` compilation; they were not rerun or relabeled as native execution in this supplement:
- `.../arce-v140-mig03-implementation-review-39431c8315a741788ce76d3bd991d171/REVIEW-MIG03-SOURCE.md`, SHA-256 `ac25a267c7beef18e091f39b31e534553658cad71a957d9006a1b29363900f98`.
- Its 24-entry manifest SHA-256 `4eaff4a6d9e50ccc10094878cddfec9999294481b8167f73fd6d5bbce05066ac`.

Root separately reported its required build terminal with 922 cached JUnit results and 236 executed GameTests. Those are root receipts, not commands performed for this raw supplement.

## Limits and disposition

- These are four selected packaged process-termination boundaries on the tested local filesystem, not arbitrary power loss, torn sector, fsync/directory durability, every possible instruction cut, long-load or hardware evidence.
- Full pair/scratch bytes are independently verified. The runner's full-world pre-restart inventory assertion and recorded post-kill inventory were inspected, including raw authority-file rows; there is no separate complete pre-restart world copy in the evidence from which this reviewer could reconstruct equality for every vanilla file. Do not expand pair conservation into independent whole-world immutability.
- No active/killed Anvil parsing, full `level.dat` decode, renderer/client/player-session test, or live process ownership query was performed. Process ownership conclusions use the retained launch/command/termination receipts and installed files, not a retroactive OS process observation.
- This scenario preserves raw prior research history, but does not repeat MIG-02 flight, cargo, station, binding-removal/restoration or all saved-world contracts. Such claims remain with their original evidence.
- Discovery receipt timestamps are preserved when already authoritative. The two scheduler clocks can differ after interruption; no common-clock ordering guarantee is inferred.
- The P3 timeout/dispose caveat remains open and explicitly bounded to failed instrumentation paths. Successful evidence here does not exercise it.
- The final native evidence supports the scoped MIG-03 four-boundary development verification. It does not establish full v1.4 Required Gate, release acceptance, multiplayer, visual or long-duration stability completion.

This report and its own manifest are new supplemental files. Prior reports/failures remain unchanged. No copied external JDK source text is included in this directory.
