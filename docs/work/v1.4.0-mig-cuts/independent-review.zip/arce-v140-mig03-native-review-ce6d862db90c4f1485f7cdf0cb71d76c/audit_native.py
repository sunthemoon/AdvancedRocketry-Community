"""Independent raw MIG-03 audit. Read original bytes; write only this review directory."""
import copy,hashlib,json,re,struct,sys,uuid,zipfile
from pathlib import Path
REPO=Path('D:/GitHub/AdvancedRocketry-Community'); sys.path.insert(0,str(REPO))
from scripts.run_v140_celestial_schema_smoke import read_nbt
BASE=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig-cuts-2cee140e075a4234b93df8bb6df2d28e')
N=BASE/'native-final'; OUT=Path(__file__).parent; H='advancedrocketrycommunity'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def uid(a): return str(uuid.UUID(int=int.from_bytes(b''.join((v&0xffffffff).to_bytes(4,'big') for v in a),'big')))
def manifest(root):
    rows={}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,rel=line.split('  ',1)
        assert re.fullmatch('[0-9a-f]{64}',digest) and rel not in rows
        p=(root/rel).resolve(); assert p.is_relative_to(root.resolve()) and sha(p)==digest,rel
        rows[rel]=digest
    assert set(rows)=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
    return {'members':len(rows),'sha256':sha(root/'SHA256SUMS')}
def capture(folder):
    result={'authority':{},'pending':{},'files':{}}
    for p in sorted(folder.glob('*.dat*')):
        assert p.stat().st_size<=4*1024**2
        m=re.fullmatch(H+r'_(satellite_missions|celestial)\.dat(\.arce-pending)?',p.name); assert m
        data=read_nbt(p)['data']
        result['pending' if m[2] else 'authority'][m[1]]=data
        result['files'][p.name]={'bytes':p.stat().st_size,'sha256':sha(p)}
    assert set(result['authority'])=={'satellite_missions','celestial'}
    emitted=js(folder/'decoded.json')
    assert result['authority']==emitted['authority'] and result['pending']==emitted['pending']
    assert result['files']=={f['path']:{'bytes':f['bytes'],'sha256':f['sha256']} for f in emitted['files']}
    return result
def normalized(authority):
    a=copy.deepcopy(authority)
    for v in a.values(): assert v['schema_version']==2
    c=a['satellite_missions'].pop('clock')
    assert set(c)=={'logical_game_time','last_observed_game_time'} and all(type(v) is int and v>=0 for v in c.values())
    for table,k in [('missions','mission_id'),('satellites','satellite_id'),('research_accounts','owner_id')]:
        rows=a['satellite_missions'][table]; mapped={uid(v[k]):v for v in rows}; assert len(rows)==len(mapped)
        a['satellite_missions'][table]=mapped
    rows=a['celestial']['bodies']; a['celestial']['bodies']={b['id']:b for b in rows}; assert len(rows)==len(a['celestial']['bodies'])
    return a
class Reader:
    def __init__(self,b): self.b,self.i=b,0
    def take(self,n): v=self.b[self.i:self.i+n]; assert len(v)==n; self.i+=n; return v
    def u(self,n): return int.from_bytes(self.take(n),'big')
def method_code(raw):
    r=Reader(raw); assert r.u(4)==0xcafebabe; r.take(4); cp=[None]*r.u(2); i=1
    while i<len(cp):
        t=r.u(1)
        if t==1: cp[i]=r.take(r.u(2)).decode('utf-8')
        elif t in (3,4,9,10,11,12,17,18): r.take(4)
        elif t in (5,6): r.take(8); i+=1
        elif t in (7,8,16,19,20): r.take(2)
        elif t==15: r.take(3)
        else: raise AssertionError(t)
        i+=1
    r.take(6); r.take(r.u(2)*2)
    def attrs(reader):
        return [(cp[reader.u(2)],reader.take(reader.u(4))) for _ in range(reader.u(2))]
    for _ in range(r.u(2)): r.take(6); attrs(r)
    found=[]
    for _ in range(r.u(2)):
        r.take(2); name,desc=cp[r.u(2)],cp[r.u(2)]; aa=attrs(r)
        if name=='flush' and desc=='(Ljava/nio/file/Path;Lio/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData$Committer;)V':
            c=Reader(dict(aa)['Code']); c.take(4); code=c.take(c.u(4)); c.take(c.u(2)*8)
            l=Reader(dict(attrs(c))['LineNumberTable']); lines=[(l.u(2),l.u(2)) for _ in range(l.u(2))]
            found.append({'code_sha256':hashlib.sha256(code).hexdigest(),'line90':[bci for bci,line in lines if line==90],'line100':[bci for bci,line in lines if line==100],'descriptor':desc})
    assert len(found)==1; return found[0]
result={'manifest':manifest(N),'initial_attempt_manifest':manifest(BASE/'native'),'processes':{},'cases':{}}
summary=js(N/'summary.json'); mission=js(N/'mission.json'); assert mission==summary['mission']
M,S,O,B=mission['mission'],mission['satellite'],mission['owner'],mission['body']
assert O=='00000000-0000-0000-0000-000000000005' and B==H+':mars'
expected_host='576eaaf8a5e23df1b049fd5fa5029f1cd6d6ffcfd0cf50bd5980fc280c31d475'
expected_consumer='e58de48ff038ff42fa1173bfd210d9e8321cfcfa66849ba1c13a0e31c1c02a47'
for a,digest in zip(summary['artifacts'],[expected_host,expected_consumer],strict=True):
    p=Path(a['path']); assert sha(p)==digest==a['sha256'] and p.stat().st_size==a['bytes']
    with zipfile.ZipFile(p) as z: assert len(z.namelist())==len(set(z.namelist())) and a['version'] in z.read('META-INF/mods.toml').decode()
with zipfile.ZipFile(summary['artifacts'][0]['path']) as z:
    class_path='io/github/sunthemoon/advancedrocketrycommunity/persistence/migration/AtomicSavedData.class'
    bytecode=method_code(z.read(class_path)); bytecode['class_sha256']=hashlib.sha256(z.read(class_path)).hexdigest()
assert bytecode['line90']==[326] and bytecode['line100']==[394]
assert bytecode['code_sha256']=='08e46faf9c8a5da8fbe65abedffabe39f593fc6b530f7279451e4b8a840dfc50'
result['artifact_bytecode']=bytecode; result['artifacts']=summary['artifacts']
expected_sources={'DiscoveryCutProbe.java':'536ebc2ba5443624d6ff339b4383edb76e14347c8fee3c8050026c013aca9d72',
 'v140_discovery_cut_fixture.py':'10a915f9f12c344e62d04de677c236634710a7d3df6d55126ae27131312b546e',
 'run_v140_discovery_cut_smoke.py':'96d8ecde2d50f41708b0c94b316e9e1a56904aba003ec747950392ddb79e5059',
 'test_v140_discovery_cut_smoke.py':'2cb2a6b0961a9bf5b5b0ec4b48200f09796bdab2d88508bb69b1b5889a12d688'}
for name,digest in expected_sources.items():
    actual=REPO/('scripts/java' if name.endswith('.java') else 'tests' if name.startswith('test_') else 'scripts')/name
    assert sha(BASE/'inputs-corrected'/name)==digest==sha(actual)
assert sha(N/'DiscoveryCutProbe.java')==expected_sources['DiscoveryCutProbe.java']
prior=Path('C:/Users/Administrator/AppData/Local/Temp/arce-v140-mig03-implementation-review-39431c8315a741788ce76d3bd991d171')
assert sha(N/'probe-classes/DiscoveryCutProbe.class')==sha(prior/'classes/DiscoveryCutProbe.class')
result['compiled_helper_sha256']=sha(N/'probe-classes/DiscoveryCutProbe.class'); result['corrected_inputs']=expected_sources
result['initial_inputs']={p.name:sha(p) for p in (BASE/'inputs').iterdir() if p.is_file()}
for name in expected_sources: assert sha(BASE/'inputs'/name)==sha(prior/name)
provenance=js(N/'source-provenance.json'); source_evidence=Path(provenance['evidence'])
assert manifest(source_evidence)['members']==provenance['manifest_entries']==269
assert sha(source_evidence/'summary.json')==provenance['summary_sha256']
for label,world,rows in [('original',source_evidence/'original-world',provenance['source_files']),('ready',N/'ready-world',js(N/'ready-world-files.json'))]:
    assert {p.relative_to(world).as_posix() for p in world.rglob('*') if p.is_file()}=={r['path'] for r in rows}
    for row in rows: assert sha(world/row['path'])==row['sha256'] and (world/row['path']).stat().st_size==row['bytes']
    result[label+'_world_files']=len(rows)
old=capture(N/'original-state')['authority']; ready_capture=capture(N/'prepare/state'); ready=ready_capture['authority']; assert not ready_capture['pending']
oldn,rn=normalized(old),normalized(ready); rr=rn['satellite_missions']; mr=rr['missions'][M]
assert mr['started_at']==526 and mr['completes_at']==726 and mr['ready_at']==740 and mr['status']=='ready'
assert mr['schema_version']==1 and mr['target_body_id']==B and mr['definition_id']==H+':data_satellite'
assert uid(mr['mission_id'])==M and uid(mr['owner_id'])==O and uid(mr['satellite_id'])==S
assert (mr['research_yield'],mr['discovery_cost'],mr['discovery_required'])==(120,100,1)
assert len(oldn['satellite_missions']['missions'])==2 and len(oldn['satellite_missions']['satellites'])==1
assert rn['celestial']['bodies']=={H+':earth':{'id':H+':earth','discovered_at':461}}
expected=copy.deepcopy(oldn)
for table,k in [('missions',M),('satellites',S),('research_accounts',O)]:
    assert k not in expected['satellite_missions'][table]; expected['satellite_missions'][table][k]=rr[table][k]
assert expected==rn
assert rr['research_accounts'][O]=={'schema_version':1,'owner_id':mr['owner_id'],'balance':0,'lifetime_earned':0,'lifetime_spent':0}
assert rr['satellites'][S]=={'schema_version':1,'satellite_id':mr['satellite_id'],'owner_id':mr['owner_id'],'definition_id':H+':data_satellite','launched_at':526,'status':'operational','current_mission_id':mr['mission_id']}
def check(authority,status,discovered,receipt=None,discovery=None):
    a=normalized(authority); e=copy.deepcopy(rn); reg=e['satellite_missions']; times={}
    actual_m=a['satellite_missions']['missions'][M]
    if status!='ready':
        t=actual_m['resolved_at']; assert type(t) is int and t>=740 and (receipt is None or t==receipt)
        reg['missions'][M].update(status=status,resolved_at=t); reg['research_accounts'][O].update(balance=20,lifetime_earned=120,lifetime_spent=100)
        times['receipt']=t
        if status=='claimed': reg['satellites'][S].pop('current_mission_id')
    if discovered:
        d=a['celestial']['bodies'][B]; assert set(d)=={'id','discovered_at'} and type(d['discovered_at']) is int and d['discovered_at']>=0
        assert discovery is None or d['discovered_at']==discovery
        e['celestial']['bodies'][B]=d; times['discovery']=d['discovered_at']
    assert e==a
    return times
def process(folder,expected_exit):
    launch,obs,commands=js(folder/'launch.json'),js(folder/'observations.json'),js(folder/'commands.json')
    assert obs['exit_code']==expected_exit and obs['pid']>0
    assert obs['command']==launch['command'] and obs['cwd']==launch['cwd']
    assert obs['command'][0]=='C:\\Program Files\\Java\\jdk-17.0.7\\bin\\java.exe'
    cwd=Path(obs['cwd']); assert cwd.is_relative_to(Path(summary['work_dir']))
    assert {p.name for p in (cwd/'mods').iterdir()}=={a['name'] for a in summary['artifacts']}
    for a in summary['artifacts']: assert sha(cwd/'mods'/a['name'])==a['sha256']
    args=cwd/'libraries/net/minecraftforge/forge/1.20.1-47.4.10/win_args.txt'; assert sha(args)==summary['forge_args_sha256']
    status=js(folder/'status.json'); assert status['players']['online']==0
    logs={}
    for name in ['stdout.txt','latest.log','debug.log']:
        text=(folder/name).read_text(encoding='utf8'); lines=text.splitlines()
        errors=[l for l in lines if re.search(r'/(ERROR|FATAL)\]',l)]; assert not errors,(str(folder),name,errors)
        assert 'NoClassDefFoundError' not in text and 'Exception in thread' not in text
        logs[name]={'bracketed_warnings':sum(bool(re.search(r'/WARN\]',l)) for l in lines),'unbracketed_warnings':[l for l in lines if ' WARN ' in l and '/WARN]' not in l],'timing_warnings':[l for l in lines if "Can't keep up" in l]}
    stdout=(folder/'stdout.txt').read_text(); assert 'Done (' in stdout and 'Saved the game' in stdout
    if expected_exit==0: assert commands[-1]=='stop' and 'Stopping server' in stdout
    else: assert 'stop' not in commands and 'Stopping server' not in stdout
    result['processes'][folder.relative_to(N).as_posix()]={'pid':obs['pid'],'exit_code':obs['exit_code'],'cwd':obs['cwd'],'port':obs['port'],'command_count':len(commands),'logs':logs,'runner_log_counts':obs['log_counts']}
    return obs,commands,stdout
process(N/'prepare',0)
for boundary in range(1,5):
    case=N/f'cut-{boundary}'; kill,commands,kill_text=process(case/'kill',1)
    recovery,rc,rt=process(case/'recovery',0)
    assert kill['cwd']==recovery['cwd'] and kill['pid']!=recovery['pid'] and kill['port']==recovery['port']
    agent=[a for a in kill['command'] if a.startswith('-agentlib:')]; assert len(agent)==1
    debug_port=int(agent[0].rsplit(':',1)[1]); assert agent[0].startswith('-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:') and debug_port!=kill['port']
    assert not any(a.startswith('-agentlib:') for a in recovery['command'])
    assert kill['termination']=={'pid':kill['pid'],'operation':'owned Popen.kill','exit_code':1,'probe_exit_code':0}
    probe=js(case/'kill/probe-launch.json')['command']; assert probe[-3:]==[str(debug_port),str(boundary),M]
    assert Path(probe[probe.index('-cp')+1])==N/'probe-classes'
    lines=(case/'kill/probe.txt').read_text().splitlines(); line,bci=(100,394) if boundary==4 else (90,326)
    expected_lines=[f'MIG03_ARMED boundary={boundary} line={line} bci={bci} bytecode_sha256={bytecode["code_sha256"]}']
    stores=['SATELLITE_MISSIONS','CELESTIAL','SATELLITE_MISSIONS'][:min(boundary,3)]
    assert lines[0]==expected_lines[0]
    tids=[]
    for ordinal,store in enumerate(stores,1):
        match=re.fullmatch(rf'MIG03_WRITE ordinal={ordinal} store={store} line={line} bci={bci} thread=(\d+) mission={M}',lines[ordinal]); assert match
        tids.append(match[1])
    assert len(set(tids))==1 and lines[-2:]==[f'MIG03_CUT_REACHED boundary={boundary} store={stores[-1]}','MIG03_DISCONNECTED_AFTER_CUT'] and len(lines)==len(stores)+3
    before=capture(case/'kill/before'); paused=capture(case/'kill/paused'); killed=capture(case/'kill/killed'); prerestart=capture(case/'before-restart')
    assert paused==killed==prerestart
    assert normalized(before['authority'])==rn and not before['pending']
    phase=['ready','claim_pending_discovery','claim_pending_discovery','claimed'][boundary-1]
    times=check(killed['authority'],phase,boundary>=3)
    scratch='celestial' if boundary==2 else 'satellite_missions'
    assert set(killed['pending'])==({scratch} if boundary<4 else set())
    if boundary<4:
        candidate={**killed['authority'],**killed['pending']}
        check(candidate,'claimed' if boundary==3 else 'claim_pending_discovery',boundary>=2,**times)
    world_rows={row['path']:row for row in kill['world_after_kill']}; assert len(world_rows)==len(kill['world_after_kill'])
    for name,row in killed['files'].items(): assert world_rows['data/'+name]['sha256']==row['sha256'] and world_rows['data/'+name]['bytes']==row['bytes']
    automatic=capture(case/'recovery/before-manual-claim'); first=capture(case/'recovery/first-claim'); final=capture(case/'recovery/final')
    auto_times=check(automatic['authority'],'ready' if boundary==1 else 'claimed',boundary!=1,**times)
    if boundary==1:
        assert automatic['pending'] in [{},killed['pending']]
        if automatic['pending']:
            for name,row in automatic['files'].items():
                if name.endswith('.arce-pending'): assert row==killed['files'][name]
    else: assert not automatic['pending']
    first_times=check(first['authority'],'claimed',True,**times); assert not first['pending'] and not final['pending']
    assert normalized(first['authority'])==normalized(final['authority'])
    if boundary!=1: assert normalized(automatic['authority'])==normalized(first['authority'])
    claim='arce satellite release-test claim '+M; status='arce satellite admin mission '+M
    assert commands==['arce celestial validate',status,'save-all flush',claim]
    assert rc.index(status)<rc.index(claim) and rc.count(claim)==2 and rc[-1]=='stop'
    s=re.search(r'mission='+M+r' .* status=(\S+) deadline=',rt); assert s and s.group(1)==('READY' if boundary==1 else 'CLAIMED')
    marker=f'ARCE_RELEASE_TEST_SATELLITE_CLAIM mission={M} owner={O} target={B} code='
    assert rt.index(s.group(0))<rt.index(marker)
    assert rt.count(marker+'ALREADY_CLAIMED status=CLAIMED research=20 discovered=true')==(1 if boundary==1 else 2)
    assert rt.count(marker+'SUCCESS status=CLAIMED research=20 discovered=true')==(1 if boundary==1 else 0)
    assert marker not in kill_text
    result['cases'][str(boundary)]={'site':{'line':line,'bci':bci},'stores':stores,'disk_phase':phase,'discovery_present':boundary>=3,'scratch':list(killed['pending']),'cut_times':times,'automatic_times':auto_times,'final_times':first_times,'automatic_scratch':list(automatic['pending']),'world_after_kill_inventory_members':len(world_rows),'pair_equality':True,'account_final':[20,120,100]}
assert len({p['pid'] for p in result['processes'].values()})==9
initial=BASE/'native'; assert js(initial/'failure.json')['error']=='Recovery left scratch data'
assert js(initial/'cut-1/kill/observations.json')['termination']['probe_exit_code']==0
assert js(initial/'cut-1/recovery/observations.json')['result']=='FAIL'
result['initial_failure']={'error':js(initial/'failure.json'),'cut_exit':js(initial/'cut-1/kill/observations.json')['exit_code'],'recovery_exit':js(initial/'cut-1/recovery/observations.json')['exit_code']}
result['mission']=mission; result['historical_account']=list(oldn['satellite_missions']['research_accounts'].values())[0]; result['result']='OBSERVATIONS_VERIFIED'
(OUT/'observations.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps(result,indent=2,sort_keys=True))
