"""Archive bounded MIG-03 observations; verify retained bytes and staged identities."""
import argparse
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
TEMP = Path(__file__).resolve().parent
OUT = ROOT / 'docs/work/v1.4.0-mig-cuts'
BASE = 'b56e40e1c42c4e5b28cfdc4fcdbd64ead8530f1a'
PRODUCTION = 'a9143c2b62d5daab412cefedcee198f1fd032588'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def manifest(source):
    rows = (source / 'SHA256SUMS').read_text(encoding='ascii').splitlines()
    names = set()
    for line in rows:
        digest, relative = line.split('  ', 1)
        path = (source / relative).resolve()
        assert path.is_relative_to(source.resolve()) and sha(path.read_bytes()) == digest, relative
        assert relative not in names
        names.add(relative)
    return len(rows)


def bundle(name, groups):
    members = []
    for prefix, source in groups:
        assert source.exists(), source
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            assert not path.is_symlink(), path
            if path.is_file():
                key = path.relative_to(source).as_posix() if source.is_dir() else path.name
                members.append((prefix + '/' + key if prefix else key, path))
    assert len(members) == len({name for name, _ in members})
    rows = []
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, path in sorted(members):
            data = path.read_bytes()
            archive.writestr(key, data)
            rows.append({'path': key, 'bytes': len(data), 'sha256': sha(data)})
    write(name + '-files.json', rows)


def archive(reviews, exploration):
    OUT.mkdir(exist_ok=True)
    counts = {name: manifest(TEMP / name) for name in ('native', 'native-final')}
    review_counts = {path.name: manifest(path) for path in reviews}
    bundle('native-cuts', [(name, TEMP / name) for name in counts]
           + [('inputs-initial', TEMP / 'inputs'), ('inputs-final', TEMP / 'inputs-corrected')])
    # Exploration copied JDK sources for local inspection only. Do not import them.
    exploration_files = [path for path in exploration.iterdir()
                         if path.is_file() and path.suffix in ('.md', '.log', '.json', '.txt')]
    bundle('independent-review', [(path.name, path) for path in reviews]
           + [('exploration-subset', path) for path in exploration_files])
    bundle('root-checks', [('', path) for path in sorted(TEMP.glob('*.log')) if not path.name.startswith('archive')]
           + [('junit', TEMP / 'root-junit'), ('', TEMP / 'archive_evidence.py')])
    summary = json.loads((TEMP / 'native-final/summary.json').read_text())
    assert summary['result'] == 'PASS' and summary['source_unchanged'] and summary['backup_unchanged']
    assert summary['boundaries'] == [1, 2, 3, 4]
    write('native-summary.json', summary)
    suites = [ET.parse(path).getroot() for path in (TEMP / 'root-junit').glob('TEST-*.xml')]
    junit = {'suites': len(suites), **{key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}}
    assert junit['tests'] == 922 and junit['failures'] == junit['errors'] == junit['skipped'] == 0
    log = (TEMP / 'root-gradle.log').read_text(encoding='utf-8')
    assert 'All 236 required tests passed' in log and 'BUILD SUCCESSFUL' in log and 'EXIT_CODE=0' in log
    cached = '> Task :test FROM-CACHE' in log
    write('root-checks.json', {'base_commit': BASE, 'junit': junit, 'junit_execution': 'FROM-CACHE' if cached else 'EXECUTED',
          'gametests_executed': 236, 'python_executed': 57, 'native_manifest_counts': counts,
          'review_manifest_counts': review_counts, 'exploration_archive': 'Subset excludes copied JDK source and original full manifest',
          'scope': 'Finite development checks; all Required Gates remain open'})
    artifacts = []
    for path in sorted((ROOT / 'build/libs').glob('*1.4.0-dev*.jar')):
        data = path.read_bytes()
        artifacts.append({'name': path.name, 'bytes': len(data), 'sha256': sha(data)})
    prior = json.loads((ROOT / 'docs/work/v1.4.0-mig-worlds/development-artifacts.json').read_text())
    assert len(artifacts) == 3 and artifacts == prior['artifacts']
    write('development-artifacts.json', {'artifacts': artifacts, 'runtime_unchanged': True,
          'production_commit': PRODUCTION, 'base_commit': BASE, 'native_artifacts': summary['artifacts']})
    print('PASS: archived root/native/independent observations; unchanged production artifacts')


def finalize():
    for name in ('source-identity.json', 'links.json', 'SHA256SUMS.txt'):
        if not (OUT / name).exists():
            (OUT / name).write_text('', encoding='ascii')
    rows, links = [], []
    for relative in git('diff', '--cached', '--name-only', BASE).decode().splitlines():
        assert not relative.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/')
        if not relative.startswith('docs/work/v1.4.0-mig-cuts/'):
            data, working = git('show', ':' + relative), (ROOT / relative).read_bytes()
            assert data == working.replace(b'\r\n', b'\n'), relative
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data), 'working_sha256': sha(working)})
        if relative.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (ROOT / relative).read_text(encoding='utf-8')):
                parsed = urlsplit(target)
                if parsed.scheme or parsed.netloc or not parsed.path:
                    continue
                path = ((ROOT / relative).parent / unquote(parsed.path)).resolve()
                assert path.is_relative_to(ROOT) and path.exists(), (relative, target)
                links.append({'document': relative, 'target': target})
    write('source-identity.json', {'base_commit': BASE, 'production_commit': PRODUCTION, 'files': rows})
    write('links.json', {'result': 'PASS', 'scope': 'Changed Markdown local file targets only; no anchor/URL check', 'links': links})
    for path in OUT.glob('*-files.json'):
        with zipfile.ZipFile(path.with_name(path.name.replace('-files.json', '.zip'))) as archive:
            listing = json.loads(path.read_text())
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(row['path'] for row in listing)
            for row in listing:
                raw = archive.read(row['path'])
                assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    paths = sorted(path for path in OUT.iterdir() if path.name != 'SHA256SUMS.txt')
    (OUT / 'SHA256SUMS.txt').write_text(''.join(f'{sha(path.read_bytes())}  {path.name}\n' for path in paths), encoding='ascii', newline='\n')
    print('PASS: staged source identities, local file links, complete ZIP byte readback and checksums')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, action='append', default=[])
    parser.add_argument('--exploration', type=Path)
    parser.add_argument('--finalize', action='store_true')
    args = parser.parse_args()
    if args.finalize:
        finalize()
    else:
        archive(args.review, args.exploration)
