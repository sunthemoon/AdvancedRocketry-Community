"""Independent raw capture audit; reads native NBT and logs, writes only this review directory."""
import hashlib,json,pathlib,re,sys,zipfile,zlib
REPO=pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
OUT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path("C:/Users/Administrator/AppData/Local/Temp/arce-v130-atm02-1790447854009")
EVIDENCE=BASE/"runtime-evidence"
sys.path.insert(0,str(REPO))
from scripts.inspect_celestial_saved_data import NbtReader
from scripts import inspect_celestial_saved_data as nbt_parser
from scripts.v120_precision_world_fixture import _region_chunk,_decode_chunk
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
js=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
manifest={}
for line in (EVIDENCE/"SHA256SUMS").read_text().splitlines():
    digest,name=line.split("  ",1)
    assert name not in manifest and not pathlib.PurePosixPath(name).is_absolute() and ".." not in pathlib.PurePosixPath(name).parts
    assert sha(EVIDENCE/name)==digest,(name,"manifest mismatch")
    manifest[name]=digest
assert set(manifest)=={p.relative_to(EVIDENCE).as_posix() for p in EVIDENCE.rglob("*") if p.is_file() and p.name!="SHA256SUMS"}
before=js(OUT/"before-rerun.json")
assert all(sha(REPO/p)==digest for p,digest in before["source_hashes"].items())
consumer=js(BASE/"consumer-reports/consumer/classpath.json")
for source in consumer["fixture_sources"]:
    assert sha(pathlib.Path(source["file"]))==source["sha256"],source["file"]
assert consumer["published_sha256"]==before["immutable_hashes"]["advancedrocketry-community-1.20.1-1.3.0-dev-api.jar"]
consumer_artifact=js(BASE/"consumer-reports/consumer/fixture-artifact.json")
assert consumer_artifact["sha256"]==before["immutable_hashes"]["arce-adapter-compat-test-1.0.0.jar"]
for name,digest in before["immutable_hashes"].items():
    assert sha(BASE/"artifacts"/name)==digest
    if name.startswith("advancedrocket"):
        with zipfile.ZipFile(BASE/"artifacts"/name) as z:
            assert not any("arceadaptertest/" in n or "arce_adapter_test/" in n for n in z.namelist())
with zipfile.ZipFile(BASE/"artifacts/advancedrocketry-community-1.20.1-1.3.0-dev-sources.jar") as z:
    for p,digest in before["source_hashes"].items():
        if p.startswith("src/main/java/") and ("/Suit" in p or p.endswith("/PlayerLifeSupportService.java") or p.endswith("/OxygenCanisterItem.java")):
            assert hashlib.sha256(z.read(p[len("src/main/java/"):])).hexdigest()==digest,p
host="advancedrocketrycommunity"
provider="arce_adapter_test:suit_oxygen"
position=(264,220,264)
region=pathlib.Path("world/dimensions")/host/"moon/region/r.0.0.mca"
def block_at(chunk,pos):
    section=next(s for s in chunk["sections"] if s["Y"]==pos[1]//16)
    state=section["block_states"];palette=state["palette"]
    if len(palette)==1:return palette[0]
    bits=max(4,(len(palette)-1).bit_length()); perlong=64//bits
    index=((pos[1]&15)<<8)|((pos[2]&15)<<4)|(pos[0]&15)
    return palette[(state["data"][index//perlong]>>(bits*(index%perlong)))&((1<<bits)-1)]
def level_data(path):
    raw=path.read_bytes(); assert len(raw)<1024**2
    d=zlib.decompressobj(31); expanded=d.decompress(raw,4*1024**2)
    assert d.eof and not d.unused_data and not d.unconsumed_tail and len(expanded)<4*1024**2
    # The celestial SavedData parser's 4,096-node budget is not a full level.dat budget.
    # Keep the 4 MiB/depth/string/collection caps and bound this native metadata read
    # to 65,536 nodes only; no production/test/source file is changed.
    old_limit=nbt_parser.MAX_TAGS
    nbt_parser.MAX_TAGS=65536
    try:
        return NbtReader(expanded).read_root()["Data"]
    finally:
        nbt_parser.MAX_TAGS=old_limit
observations=[];worldgen=None;previous_items=None;config=None;last_time=-1
for phase,units,full,empty in [("setup",999,1,1),("restart",998,1,1),("skipped",998,1,1),("restored",1997,0,2)]:
    d=EVIDENCE/phase
    chunk=_decode_chunk(_region_chunk((d/region).read_bytes(),16,16),16,16)
    bes=[be for be in chunk["block_entities"] if (be.get("x"),be.get("y"),be.get("z"))==position]
    assert len(bes)==1 and bes[0]["id"]=="minecraft:chest"
    assert block_at(chunk,position)=={"Name":"minecraft:chest","Properties":{"facing":"north","type":"single","waterlogged":"false"}}
    expected=[{"Slot":0,"id":"minecraft:leather_chestplate","Count":1,"tag":{"Damage":0,"fixture_marker":"persist-exactly",
                "arce_suit_provider":{"schema_version":1,"provider":provider,"payload_version":1,"data":{"oxygen":units}}}}]
    if full:expected.append({"Slot":1,"id":host+":oxygen_canister","Count":full})
    expected.append({"Slot":2,"id":host+":empty_canister","Count":empty})
    items=bes[0]["Items"];assert sorted(items,key=lambda s:s["Slot"])==expected,(phase,items)
    if phase=="skipped":assert items==previous_items
    previous_items=items
    consumed={"setup":1,"restart":2,"skipped":2,"restored":3}[phase]
    assert units+1000*full+consumed==2000 and full+empty==2
    native=level_data(d/"world/level.dat")
    if worldgen is None:worldgen=native["WorldGenSettings"]
    assert native["WorldGenSettings"]==worldgen
    assert native["LevelName"]=="world" and native["Time"]>last_time
    last_time=native["Time"]
    launch=js(d/"launch.json");result=js(d/"result.json");commands=js(d/"commands.json")
    assert result["exit_code"]==0 and result["phase"]==phase
    assert all(launch["mods"][name]==before["immutable_hashes"][name] for name in launch["mods"])
    assert set(launch["mods"])=={"advancedrocketry-community-1.20.1-1.3.0-dev.jar","arce-adapter-compat-test-1.0.0.jar"}
    assert ("-Darce_adapter_test.skipSuitEquipment=true" in launch["command"])==(phase=="skipped")
    assert "-Darce_adapter_test.suitSmoke=true" in launch["command"]
    assert not any("releaseTestHooks" in arg for arg in launch["command"])
    assert commands.count("arce_fixture_suit "+phase)==1 and commands[-2:]==["save-all flush","stop"]
    assert sum("run setblock " in c for c in commands)==(1 if phase=="setup" else 0)
    logs={}
    for name in ("stdout.txt","latest.log","debug.log"):
        text=(d/name).read_text(encoding="utf-8")
        errors=[line for line in text.splitlines() if re.search(r"/(?:ERROR|FATAL)[\] ]",line)]
        assert not errors,(phase,name,errors)
        assert not re.search(r"NoClassDefFoundError|ClassNotFoundException|NoSuchMethodError|NoSuchFieldError|LinkageError",text)
        assert "disabled for this server session" not in text
        token=(f"Skipped suit equipment {provider} (event 1)" if phase=="skipped" else
               f"Registered suit equipment {provider} (API 1.3, event 1)")
        selections=[line for line in text.splitlines() if "Registered suit equipment " in line or "Skipped suit equipment " in line]
        assert len(selections)==1 and selections[0].endswith(token),(phase,name,selections)
        assert len([line for line in text.splitlines() if line.endswith("V130_SUIT_PHASE_PASS "+phase)])==1
        assert "Stopping server" in text and "ThreadedAnvilChunkStorage: All dimensions are saved" in text
        warnings=[line for line in text.splitlines() if re.search(r"/WARN[\] ]",line)]
        project_warnings=[line for line in warnings if "io.github.sunthemoon" in line or "[io.gi.su." in line]
        assert not project_warnings
        logs[name]={"errors":len(errors),"structured_warnings":len(warnings),"sha256":sha(d/name)}
    stdout=(d/"stdout.txt").read_text()
    times=[int(s) for s in re.findall(r"The time is (\d+)",stdout)]
    assert len(times)>=2 and times[-1]-times[0]==result["observation_ticks"] and 20<=result["observation_ticks"]<=40
    configs={n:sha(d/n) for n in ("config/fml.toml","config/advancedrocketrycommunity-common.toml")}
    if config is None:config=configs
    assert config==configs
    props={}
    for line in (d/"server.properties").read_text().splitlines():
        if line and not line.startswith("#") and "=" in line:
            k,v=line.split("=",1);props[k]=v
    assert props["server-ip"]=="127.0.0.1" and props["server-port"]=="60520" and props["online-mode"]=="false"
    observations.append({"phase":phase,"oxygen":units,"full":full,"empty":empty,"cumulative_consumed":consumed,
        "native_items":items,"level_time":native["Time"],"seed":native["WorldGenSettings"]["seed"],
        "observation_ticks":times[-1]-times[0],"recorded_exit":result["exit_code"],"logs":logs})
result={"result":"PASS","manifest_files":len(manifest),"manifest_sha256":sha(EVIDENCE/"SHA256SUMS"),
        "consumer_fixture_sources_checked":len(consumer["fixture_sources"]),
        "reused_parser":"Low-level NbtReader and bounded Anvil decode only; expectations/log checks independently coded.",
        "artifact_hashes":before["immutable_hashes"],"source_files_unchanged":len(before["source_hashes"]),"phases":observations,
        "boundaries":"Native chest stack + full/empty quantities; three auxiliary armor pieces recreated; 20 manually dispatched FakePlayer events/phase, not real-time player or player save/login."}
(OUT/"native-audit.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k!="phases"},indent=2))
print(json.dumps([{k:v for k,v in p.items() if k not in ("logs","native_items")} for p in observations],indent=2))
