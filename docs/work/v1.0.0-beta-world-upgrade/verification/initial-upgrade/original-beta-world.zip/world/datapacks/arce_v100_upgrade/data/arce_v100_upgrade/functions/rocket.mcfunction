data modify storage arce_v100_upgrade:snapshot scratch set from entity @s
execute if entity @s[type=advancedrocketrycommunity:rocket] run data modify storage arce_v100_upgrade:snapshot scratch.observed_type set value "advancedrocketrycommunity:rocket"
execute if dimension minecraft:overworld run data modify storage arce_v100_upgrade:snapshot scratch.observed_dimension set value "minecraft:overworld"
execute if dimension advancedrocketrycommunity:moon run data modify storage arce_v100_upgrade:snapshot scratch.observed_dimension set value "advancedrocketrycommunity:moon"
data modify storage arce_v100_upgrade:snapshot state.rockets append from storage arce_v100_upgrade:snapshot scratch
