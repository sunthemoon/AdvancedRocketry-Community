data modify storage arce_v100_upgrade:snapshot state set value {schema:1,rockets:[]}
data modify storage arce_v100_upgrade:snapshot state.paused set from block 0 100 0 arce_machine
execute store success storage arce_v100_upgrade:snapshot state.paused_lit byte 1 run execute if block 0 100 0 advancedrocketrycommunity:electrolyzer[lit=true]
data modify storage arce_v100_upgrade:snapshot state.running set from block 4 100 0 arce_machine
execute store success storage arce_v100_upgrade:snapshot state.running_lit byte 1 run execute if block 4 100 0 advancedrocketrycommunity:electrolyzer[lit=true]
execute in advancedrocketrycommunity:moon run data modify storage arce_v100_upgrade:snapshot state.vent set from block 64 100 64 arce_oxygen_vent
execute in advancedrocketrycommunity:moon run execute store success storage arce_v100_upgrade:snapshot state.vent_lit byte 1 run execute if block 64 100 64 advancedrocketrycommunity:oxygen_vent[lit=true]
execute store result storage arce_v100_upgrade:snapshot state.game_time long 1 run time query gametime
execute as @e[type=advancedrocketrycommunity:rocket] at @s run function arce_v100_upgrade:rocket
data remove storage arce_v100_upgrade:snapshot scratch
say ARCE_V100_WORLD_CAPTURED
execute store success storage arce_v100_upgrade:snapshot state.flush_success byte 1 run save-all flush
execute if data storage arce_v100_upgrade:snapshot {state:{flush_success:1b}} run say ARCE_V100_WORLD_FLUSHED
stop
