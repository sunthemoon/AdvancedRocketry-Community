# C18a next leaf: handheld atmosphere analyzer

Status: **PROPOSED feasibility / exact leaf inputs still require Root review**.
Date: 2026-10-04. Author: delegated read-only worker `/root/c17_contract`.
Fixed inspected Git object: `bd0148e98d065df6ac77789eca0a5dae9b6a409a`.
This is neither a runtime implementation nor contract/API/ledger/Gate admission.

## Findings and dependency gaps first

No existing-runtime Critical/High/Medium/Low defect was reproduced by this task.
Only named read/static controls ran. Three **implementation-admission prerequisites**
remain, not newly classified defects in deliberately PLANNED content:

1. **Freeze the narrow host query and lifecycle integration.** The effective-cell
   authority exists in `atmosphere/server/AtmosphereManager.java:78–91` and
   `AtmosphereLevelService.java:223–251`, but `AtmosphereRuntime.java:12–40`
   exposes only vent observation/removal and metrics. The current public
   environment API deliberately reads configured metadata even at unloaded
   coordinates, not effective air (`api/environment/EnvironmentQueries.java:12–20`).
   Its station snapshot deliberately has no atmosphere
   (`compat/environment/ServerEnvironmentQueries.java:78–82`). A leaf must combine
   those authorities without silently changing either public API or inferring
   planetary air in orbit. Manager fallback for unmapped Levels
   (`AtmosphereManager.java:135–141`) is existing conservative gameplay, **not a
   verified instrument profile**. The proposed guards below are essential.
2. **Freeze NEW recipe/art/presentation inputs, not legacy parity.** ADR-066
   lines 935–937 explicitly reserves recipe/NEW art details to exact leaf review.
   The analyzer ID is specified but currently absent from both named item
   registries. The acquisition candidate below uses existing, actually generated
   crafting inputs; no new machine, final C16d circuit behavior, player gas writer
   or pad receipt is required. Review the candidate multiset and provenance before
   authoring/generation. The C16d complete progression graph remains open.
3. **Additive Root config/registration and actual execution remain necessary.**
   Accepted `lifeSupport.classicDevicesEnabled=true` (ADR-066:110–114) is not yet
   in the inspected `CommonConfig`. Root owns that switch and integration. All
   new query tests, packaged item use/restart, asset checks and V1/V2 remain
   unexecuted. Existing tests below are source evidence, not borrowed new results.

## 1. One independently useful scope

Proposed task ID **C18a-01-atmosphere-analyzer** (Root must check/assign the ID).
Exact primary ledger coverage: **one row**, `item:atmAnalyser`, currently
`PLANNED / C18a`, ledger line 464. Accepted target:
`advancedrocketrycommunity:atmosphere_analyzer` (ADR-066:184–187; companion
revision-3 unit coverage agrees). No other ledger unit changes as a consequence.

Player outcome: use the held analyzer to read the **server user's eye cell**;
receive localized actual cell breathability/control plus configured ambient
temperature, pressure and logical body/locus. This is useful on Earth, Moon,
other mapped surfaces and committed station regions, without consuming gas,
energy, durability or inventory, and without asking the client for a coordinate.

Explicitly not included: seal detector, redstone detector, scrubber, vent
migration, auxiliary tank/workstation/enchantment/jetpack, gas charge pad,
research, first-world advancements/outboxes, new HUD/menu/channel, room scans,
environmental damage changes, gravity, torch conversion, final circuit recipe
formalization, C17 propulsion or any new resource/transaction writer.

## 2. Why this leaf instead of the two alternatives

| Candidate | Existing useful foundation | Additional boundary before an honest vertical slice |
|---|---|---|
| **Analyzer (selected)** | `AtmosphereManager` cell read/control; catalog/BodyContext; ordinary item use/localized Component; original additive DataGen patterns | one read-only server-lifetime composition, NEW acquisition/art and Root registration/config |
| Seal detector | `ServerLevelVolumeWorldView` already implements ADR-024 loaded/state/tag/compiled-rule priority; `controlledAt` exists | loaded-only server-derived six-block hit trace, adjacent-cell definition, compiled catalog routing; current right-click-on-door/registered-boundary invalidation calls `markDirty` before ordinary interaction (`AtmosphereServerEvents.java:49–59`, ADR-024 runtime policy). A read-only detector must account for that interaction without weakening invalidation. This is a dependency to examine, not a reproduced detector bug. |
| Finite built-in oxygen reserve | Original key/schema `arce_space_suit_oxygen` and 0..2,000 buffer; existing authoritative suit commits | new bounded module/tank root/install owner, tier/config balances still **proposal**, saved maximum migration, active+reserve detached one-item commit and debit-order tests; pad/player source durability remains separately unproven. D1 does not approve every number or supply a writer. |

The analyzer adds no resource owner and does not depend on ADR-066 D4's
unproven chunk/player write protocol. Broad batch dependencies at ADR-066:939–944
(fans, carbon brick, chemical recipes, surveys and C17 summary) still apply to
their actual devices; they need not be invented as analyzer dependencies when
the existing baseline crafting ingredient route is used.

## 3. Exact behavior to freeze before source work

### Already established and preserved

- Stable ID above; namespace and lower-case path from ADR-061 §1.
- Native server item use reads exactly `BlockPos.containing(player.getX(),
  player.getEyeY(), player.getZ())`, the same eye coordinate used by life support
  (`PlayerLifeSupportService.java:68`). No hit target or player-provided position.
- Body identity is BodyContext, not selected UI destination or held NBT. One
  caller-captured catalog must drive context and ambient projection
  (`BodyContextResolver.java:37–60` supports the captured-catalog overload).
- SURFACE uses the actual unambiguous mapped surface body's atmosphere.
- In actual Space, including a station orbiting Earth/Venus/etc., ambient comes
  from the **actual Space Level definition**, not `orbitBody`'s surface. ORBIT
  remains a body/locus label. Do not populate public orbit-atmosphere Optional.
- Effective cell breathability/control comes from the current manager. Known
  supplied sealed volume gives breathable/control, but does not rewrite ambient
  temperature/pressure or infer a room temperature. Ambient values and actual
  supplied air are displayed separately (ADR-066:149–162; ADR-034 climate rule).
- Profile pressure finite **0..10**; temperature finite **0..2,000 K**
  (`AtmosphereDefinition.java:9–35`). There is **no oxygen concentration** field.
  Do not invent percent-O2 or physical pressure units. Pressure is the configured
  scale; K is already the model's temperature unit.
- Built-in default authoring facts, not frozen overrides of installed packs:
  Earth **1 / 288 K / breathable**, Moon **0 / 220 K / nonbreathable**, Space
  **0 / 3 K / nonbreathable** (`CelestialDefaults.java:23,32,41`). Use current
  installed definitions; accepted reload must be visible, rejected reload keeps
  existing last-good catalog behavior (`CelestialCatalogManager.java:44–67`).
- Existing detector predicates 240/330 K and pressure 2 are not retuned or
  separately implemented by the handheld analyzer. Detector ten-tick/six-neighbor
  scheduling belongs to `atmosphere_detector`, not this item.

### Proposed technical/UI details (not old balance claims)

1. Item is **unstackable, no durability, no capability, no owned NBT**.
   Accept ordinary server `ServerPlayer` currently in the owning PlayerList,
   alive, nonspectating, same actual Level/server, holding this exact item/count
   in the actual hand. Creative read returns the same air measurement, never
   an EXEMPT protection status. No oxygen/equipment provider is called. Client
   branch predicts ordinary item success only; it does not query the world or
   publish measurement. Return/consume the interaction without shrinking item.
2. One ordinary vanilla item cooldown **2 server ticks** caps accepted read
   feedback to 10/s; use the existing per-player cooldown owner, not a static UUID
   map. Reject/direct repeated calls before querying, then add cooldown after one
   valid report; test both hands. This new UX bound needs Root technical review;
   ADR-066's ten-menu-intents default alone is not an existing item cooldown.
3. Require installed live query owner and owner server thread **before** world
   reads. Check alive/connection/held item, build-height and `hasChunkAt(eye)`.
   Outside-height, unloaded or expired owner reports bounded UNAVAILABLE and
   never calls a loading query/clip/BlockEntity capability. Do not turn an
   unavailable eye into a fallback vacuum/Overworld-safe report.
4. Capture one current catalog, resolve BodyContext using existing committed
   station/Level resolver, then project ambient using the same catalog. Empty
   catalog, ambiguous mapping, unknown body, blocked station registry, reserved
   region or outside committed Space region yields UNAVAILABLE. A supplied
   volume does not validate an unknown context. No station reservation/create,
   SavedData writes or additional query-triggered SavedData acquisition.
5. Only after those guards, call `controlledAt` and `breathabilityAt` on the
   same manager/eye. AVAILABLE carries cell BREATHABLE or NON_BREATHABLE and
   explicit controlled flag. Manager's internal enum `VACUUM` is **not** a claim
   that a known positive-pressure nonbreathable atmosphere has zero pressure.
   PENDING carries a localized pending cell code and no positive controlled
   claim. Known ambient/context may remain displayed as explicitly **ambient**
   during PENDING; it must not imply actual supplied breathable air. UNAVAILABLE
   has no invented numeric/body fallback. No scans, dirty marks, vent ticks,
   resource debit, capability callback or persistent save is requested by the item.
6. Use one bounded localized **chat** Component rather than replacing the existing
   action-bar hazard warning or adding a custom screen. Show logical surface/orbit
   label; in ORBIT additionally identify ambient as Space. Show ambient pressure
   and temperature separately from cell breathability and supplied control.
   Numeric source remains double; use finite `Double.toString` arguments (no
   integer cast/rounding in domain data). Known body label uses existing
   `body.<namespace>.<path with / replaced by .>` convention, with the bounded
   stable ID as missing-translation fallback. Use a common-side translatable
   fallback, never `RocketStarMap`/client `I18n` from server code. Add only missing
   builtin Space label and analyzer keys to v180 bilingual output; do not replace
   already owned Earth/Moon/Mars/Venus/Tau labels. Expected complete message is
   bounded fixed fields, not untrusted NBT/reload error text.
7. Root adds accepted COMMON `lifeSupport.classicDevicesEnabled` default **true**.
   False returns localized DISABLED without new query/work. ID/model/recipe stay
   registered; there is no resource to withdraw/reconcile in this leaf. No
   `equipment.classicEnabled`/survey switch is needed just to implement analyzer.

### Minimal internal Java boundary, not a public API amendment

Root should freeze a small **host-only** service and immutable reading, e.g.
`AtmosphereAnalyzerService.read(ServerPlayer)` and `close()`, plus
`AnalyzerReading` with fixed availability/cell/locus enums, optional logical
body ID, optional ambient-body ID, the paired finite pressure/K values and
controlled flag. No ItemStack NBT/VolumeId/cell list/player/world reference escapes
in a reading. The item owns hand/type/cooldown admission; the service owns server,
loaded/context/profile admission and authoritative composition. No client-facing
arbitrary-position method is added. Method names/constructor wiring are proposed
implementation details, not admitted API signatures.

Use `BodyContextResolver(catalogs, List.of(new StationRegionBodyContextResolver(
existingStations::findAt)))` **only with Root's already acquired service owner**,
or another Root-controlled equivalent that preserves the same captured-catalog
rules. Do not broaden `EnvironmentQueries` or save a parallel station registry.
The read path may initialize an existing bounded AtmosphereLevelService and
invalidate its stale catalog-derived cache through normal manager reads; it must
not schedule/tick/force a scan. Metrics/vent/inventory tests distinguish those
existing maintenance effects from added work.

Any Item registry supplier/runtime bridge must bind to one actual server, close
and release server/Level references at stopping, refuse retained old handles and
never rebind an old handle to the next integrated server. At most one active host
query service, no per-player read cache. Existing manager cleanup remains Root
owned (`AdvancedRocketryCommunity.java:383–389`); do not silently redesign it.

## 4. Acquisition, stable storage and migration

**NEW recipe candidate for Root independent reachability review**:
vanilla shapeless **1 basic_circuit + 1 minecraft:glass_pane +
1 minecraft:iron_ingot → 1 atmosphere_analyzer**.
Recipe ID `advancedrocketrycommunity:atmosphere_analyzer`, normal crafting unlock
for possessing `basic_circuit`; no JEI-only recipe or research prerequisite.

Actual current inputs: `ModItems.java:136–137` registers wafer/basic circuit;
generated `basic_circuit.json` is shapeless wafer-tag + copper-ingot-tag +
redstone → 2 basic circuits. `silicon_wafer.json` is quartz-gem-tag + redstone
→ 2 wafers, and its item tag contains the built-in wafer. This is a concrete
ordinary route without powered machine recursion, **not** a full recipe-graph
proof or a claim all ingredients are available in the fresh Overworld. Quartz
requires its ordinary obtainable source/Nether access unless an installed pack
offers another route. The registered circuit still has its existing development
tooltip (`DevelopmentComponentItem`); C16d must later formalize it under the same
ID. This leaf neither removes that tooltip nor freezes the final circuit recipe.
Alternative analyzer ingredients require separate exact task review, not a silent
author choice. No upstream recipe/assets were read/copied for this candidate.

Add an original generated item model and **NEW 16×16 analyzer texture** under
normal `advancedrocketrycommunity` assets, with provenance recorded **before**
generation. Asset source status is NEW, not an approved legacy import. The final
design and generated hashes still need source/visual review. Original no-sound,
no-animation handheld art is enough for this leaf; it does not close C18d's legacy
asset rows merely by existing.

No analyzer-owned persisted fields/root/schema, world SavedData, saved selection,
transaction receipt or migration is needed. Ordinary ItemStack ID/count/custom
unrelated vanilla NBT remains vanilla-owned and must not be rewritten on use.
The new registry ID becomes permanent on first implementation commit. No
`advancedrocketry:atmAnalyser` alias or direct 1.12.2 conversion is introduced.
Existing v1.7/v1.8 suit/vent/station/API IDs, roots, balances and protocols are
unchanged. Rolling back to a host that lacks the new ID requires the matching
world backup/mod restoration; ordinary missing-registry behavior is not a
lossless downgrade guarantee.

## 5. Ownership for an isolated implementation

| Delegated new-file scope | Root exclusive integration |
|---|---|
| New `atmosphere/instrument/` reading, pure projection/presentation and item/service classes as frozen above; no edits to existing atmosphere/suit/BodyContext source | `ModItems`, `ModCreativeTabs`, `AdvancedRocketryCommunity` lifecycle/service wiring and any existing runtime bridge change |
| New `V180AnalyzerData.java`, `V180AnalyzerArt.java`, `V180AnalyzerLanguage.java`; own deterministic DataGen content maps | `BootstrapDataGenerators`, central `V180LanguageProvider` delegation; COMMON config/default/range tests |
| New instrument unit tests, new `AtmosphereAnalyzerGameTests.java`, own leaf TASK/PROGRESS/HANDOFF and proposed integration patch | Shared registered resources/provenance ledger, language/generated outputs, content ledger/status/implementation log/acceptance; scheduling full checks/native/client |

Root first freezes exact constructor/query boundary, recipe multiset, localization
keys/config/NEW art provenance and declaration of disjoint write scope. Worker
delivers only owned source/tests/providers and a central integration proposal.
No changes to exported `api.environment`/`api.atmosphere`, original suit root,
vent schema or station writer. Independent reviewer checks actual diff and key
tests; source and evidence bind a committed implementation before delivery marks.

## 6. Smallest sufficient tests and commands (all future work)

### A0 / codec-independent projection and data tests

- Ambient pressure 0/positive/10 and temperature 0/240/330/2,000: finite exact
  metadata survives reading; no percent-O2/room-288/planetary-pressure invention.
- SUPPLIED + known context ⇒ cell breathable/control, unchanged ambient values;
  PENDING/UNAVAILABLE cannot become a positive controlled-air answer. Known
  positive-pressure nonbreathable profile is not labelled vacuum from enum alone.
- Surface mapping and captured-catalog projection; Earth-orbit/Venus-orbit station
  has Space ambient even if station `vacuum=false`; Space gap/reserved/unknown
  body/ambiguous mapping/current catalog missing fail appropriately. Old immutable
  readings remain unchanged after accepted reload; rejected reload keeps last good.
- Localized en_us/zh_cn exact keys/arguments/body fallback with no client dependency;
  all fixed reason branches are represented and bounded. Recipe target/ingredient
  multiset/unlock and NEW model/texture references; deterministic resources.
- Disabled/off-thread/closed/cross-server/reentrant operation admission precedes
  provider/world access. No read invokes suit provider, consumes gas or writes NBT.

### Registered A1 adapter tests

- Actual registered item `use` by a connected non-FakePlayer, both hands,
  exact held type/count/lifecycle; recipient/report and cooldown. Client branch
  supplies no data. `ConnectedTestPlayers.java:24–65` can exercise an embedded
  server listener, but is **not** a real client or native restart proof.
- Actual Earth/Moon plus a committed Space station with actual manager/loaded eye;
  eye-versus-feet fixture crossing a supplied-volume boundary. Suit/no suit/empty
  suit/creative must not change reported air or trigger an oxygen read/debit.
- Real supplied room, opening/invalidation/energy exhaustion and pending scan;
  compare vent oxygen/FE/held count and existing data before/after the item call.
  Freeze game time during the comparison or explicitly account for ordinary vent
  tick debit; do not mistake scheduled debit for analyzer consumption.
- Unloaded/height guard, no chunk ticket or call to loading access; foreign
  context/expired service refuses before read. Query does not call markDirty,
  rescan, force-load, capabilities or resource commits. Metrics do not acquire
  new scan tasks because of analyzer use; repeated use cannot overflow queues.
- Registered craft via actual RecipeManager/container, not JSON string existence;
  verify exact one-item result and unaffected original recipes/translations.

Existing source tests to preserve/replay include `ServerEnvironmentQueriesTest`
(unloaded metadata, read-only station state, unresolved/blocked context, reload,
closed/off-thread handles), `BodyContextResolverTest`, `AtmosphereBoundaryGameTests`,
`AtmosphereGameTests` (supplied/invalidation/bounded/unloaded) and suit oxygen tests.
Their existence was checked; none were executed here.

### S1 / persistence and real clients

After independently reviewed Root integration and a current packaged JAR, run
the actual native item-use path using an owned real player on a disposable copied
world. Hold analyzer with unrelated custom NBT and representative old suit/vent
inventory; use it outside/inside a supplied room, in mapped surface/committed
Space, then clean stop/restart at least once and repeat the query after normal
scan reconstruction. Check exact ItemStack ID/count/unrelated metadata and old
balances/roots, correct recipient/ambient/current cell reading, old handle refusal
and no query-induced chunk tickets or new project ERROR. No stopped NBT value
proves the transient supplied-cell cache must persist; it must rebuild normally.

A synthetic opt-in connected-player/native hook is **not** part of this initial
scope. If later proposed, it needs the separately required offline UUID/file
ownership/receipt/pre-existing record refusal review; the unresolved tutorial
native-player draft must not be borrowed as a safe lifecycle solution. Real
player/manual S1 avoids inventing a new cross-store or synthetic player writer.
No S2/crash atomicity claim is needed for a read-only analyzer operation; whole
version persistence/repair/crash Gates remain separate.

V1 must show item model, actual localized report/fallback, GUI scale/readability,
resource reload and supplied versus ambient clarity. Two actual clients exercise
independent recipients/hands/positions, no cross-player report or authority, and
reconnect; embedded mocks do not satisfy V2. These remain real outstanding Gates.

### Commands to schedule, not executed here

In the isolated owned worktree using Java 17, offline/no-daemon/worker/heap limits
granted by Root: scoped `gradlew.bat ... test --tests <new instrument tests>` and
existing named suites; after Root integration `clean build`, `test`, `runData`
twice with exact generated-byte comparison, `git diff --exit-code`, and actual
`runGameTestServer` (existing discovered required suite plus new cases).
Strict repository/provenance/resource/content validators and DataGen singletons
must pass on the actual committed source/JAR. Root's currently failed full ledger
closure and unfinished C16d graph are reported as such, not converted to PASS.
Actual native/client commands must be frozen separately with owned inputs before
execution; no fabricated hook/flags or assumed installed-JAR result is provided.
Check ≥10 GB free before heavy jobs under live AGENTS §9 and preserve every failure.

## 7. Investigation actually completed and evidence

Only this own D leaf was written. Named repository reads/read-only Git object
queries, `rg`, Python 3.13.15 `-B` static controls and own-file byte inspections
ran. Initial collector failed **exit 1** before any tests because a historical
coverage CSV expands LF→CRLF in the live checkout; it is preserved alongside
all mistaken exploratory path/glob observations in [tool history](TOOL-OBSERVATIONS-01.md).
Corrected control run: **14 tests /0 failures/errors/skips, exit 0**. It checks
the facts in named existing sources, **not** actual Java query/item execution.

- [Input manifest](INPUT-MANIFEST-01.json): **81** individual named inputs bound
  to fixed Git object above. **79 literal Git-equal**, live user AGENTS separately
  pinned, one historical CSV separately measured as exact LF→CRLF expansion.
  Expanded live bytes are not represented as literal Git identity. No full source
  export/ZIP/JAR/library/official class copy or private directory read occurred.
- [Derived source facts](FACTS-01.json) and [line references](SOURCE-REFS-01.json).
- [Actual static log](static-controls-01.log) / [receipt](static-controls-01.json).
- [Historical coverage newline observation](coverage-newline-01.json), and original
  [failed collector helper](inspect_leaf-00.raw.txt).
- [Postcheck](POSTCHECK-01.json) and [small own evidence manifest](INTERNAL-MANIFEST.json)
  are added only after final input equality/references checks. No prior sealed
  report, Root evidence or source-world fixture was altered.

## 8. Qualified disposition / next action

**Prepare one isolated analyzer implementation task after Root freezes/reviews
the explicit leaf inputs above.** This is the smallest proposed C18 instrument
slice with an existing server authority and no new resource/cross-store writer.
No material owner gameplay decision is needed merely to read known eye-cell
air with accepted surface/orbit semantics. The proposed acquisition, cooldown,
localized layout and private constructor are still exact technical/UX review
inputs, not silent authorization. If a requested variant changes ordinary
acquisition, pressure measurement semantics, supplied-room truth or public API,
return that actual choice to its contract owner before implementation.

Completion here: feasibility, one-unit scope, source pins, proposed boundaries,
tests and execution plan. Uncompleted: source implementation/registration,
independent actual-diff/runtime checks, native/restart/client/visual/progression
proof, ledger delivery and all version Required Gates. **v1.8 G0–G9 remain open**;
no whole-version completeness, acceptance, risk closure or Gate is claimed.
