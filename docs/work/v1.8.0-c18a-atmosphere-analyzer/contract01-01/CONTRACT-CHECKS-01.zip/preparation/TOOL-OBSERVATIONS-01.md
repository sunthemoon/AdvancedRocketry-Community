# Retained exploration/tool observations

This is analysis-only evidence. No source or assertion was changed in the repository.

1. PowerShell multi-file exploratory read named nonexistent
   `celestial/service/CelestialRuntime.java`; `Get-Content` reported the missing
   file while continuing other named reads. No capability was inferred from it.
2. Two exploratory `rg` operands named nonexistent `datagen/CelestialDataProvider.java`
   and `celestial/client`; another named nonexistent `flight` package. Read-only
   `git ls-files` identified actual `celestial/CelestialDefaults.java` and client
   paths. No files were created at those mistaken locations.
3. `rg docs/decisions/ADR-024* docs/decisions/ADR-061*` used unsupported Windows
   operand globs and reported error 123. The following read used the two exact
   tracked ADR names. No source facts came from the failed search.
4. One exploratory read named nonexistent `celestial/service/CelestialReloadListener.java`.
   It was not needed for the selected catalog-manager query boundary.
5. Initial `python -B inspect_leaf.py` exited **1** before running tests because
   the first collector required literal live/fixed equality of the historical
   coverage CSV. Actual output ended with:

   ```text
   AssertionError: named input drift from fixed baseline: docs/work/v1.8.0-c18-contract/proposals/revision-03/unit-coverage.csv
   ```

   [Original helper bytes](inspect_leaf-00.raw.txt) are preserved. The subsequent
   [bounded byte inspection](coverage-newline-01.json) independently measured
   live 33,359 bytes/105 CRLF pairs versus fixed 33,254 bytes/0 CRLF pairs; the
   live file is exactly the LF-to-CRLF expansion of this one fixed object.
   The revised collector records literal equality and this explicit per-file
   observation separately. It does not label expanded bytes as literal Git
   equality or waive any build/release input rule. It also uses the actual CSV
   headers `disposition` and `plan` (there are no `status`/`batch` columns).

No command started Java, a game/server/client, Gradle, a network connection or a
process cleanup. The directory created for this task is on D only.
