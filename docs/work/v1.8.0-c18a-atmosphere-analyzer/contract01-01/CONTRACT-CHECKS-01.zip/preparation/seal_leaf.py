"""Final named-input and small own loose-evidence seal, without source exports."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
for key in ("TEMP", "TMP", "TMPDIR"):
    os.environ[key] = str(OWN)

def digest(data):
    return hashlib.sha256(data).hexdigest()

inputs = json.loads((OWN / "INPUT-MANIFEST-01.json").read_text(encoding="utf-8"))
checks = []
for path, before in inputs["files"].items():
    actual = (ROOT / path).read_bytes()
    checks.append({"path": path, "bytes": len(actual), "sha256": digest(actual),
                   "unchanged": len(actual) == before["bytes"] and digest(actual) == before["sha256"]})
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
links = []
for name in ("ACTIONABLE-01.md", "LEAF-PROPOSAL-01.md", "TOOL-OBSERVATIONS-01.md"):
    for target in re.findall(r"\]\(([^)]+)\)", (OWN / name).read_text(encoding="utf-8")):
        if target.startswith(("http:", "https:", "#")):
            continue
        if target == "INTERNAL-MANIFEST.json":
            # This entry is created below only after its payload inventory is complete.
            exists = True
        else:
            exists = (OWN / target.split("#", 1)[0]).is_file() or target == "POSTCHECK-01.json"
        links.append({"report": name, "target": target, "exists": exists})
result = {"fixed_input_commit": inputs["fixed_commit"], "head_at_postcheck": head,
          "moving_head_not_authority": head != inputs["fixed_commit"],
          "named_checks": checks, "drift": sum(not c["unchanged"] for c in checks),
          "links": links, "missing_links": sum(not c["exists"] for c in links),
          "no_java_native_source_edits_or_exports": True,
          "literal_git_equal_count": sum(spec["literal_git_equal"] for spec in inputs["files"].values()),
          "separate_exact_crlf_expansions": [path for path, spec in inputs["files"].items()
                                              if not spec["literal_git_equal"] and spec["exact_lf_to_crlf_expansion"]]}
(OWN / "POSTCHECK-01.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
if result["drift"] or result["missing_links"]:
    raise SystemExit("Refuse seal: input or presentation drift")
payloads = {}
for path in sorted(OWN.iterdir()):
    if path.is_file() and path.name != "INTERNAL-MANIFEST.json":
        data = path.read_bytes()
        payloads[path.name] = {"bytes": len(data), "sha256": digest(data)}
manifest = {"status": "FROZEN PREPARATION ONLY", "fixed_commit": inputs["fixed_commit"],
            "payload_count": len(payloads), "payload_bytes": sum(x["bytes"] for x in payloads.values()),
            "files": payloads, "no_archive": True}
(OWN / "INTERNAL-MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"named_checks": len(checks), "drift": result["drift"], "links": len(links),
                  "missing_links": result["missing_links"], "payload_count": len(payloads),
                  "payload_bytes": manifest["payload_bytes"],
                  "actionable_sha256": payloads["ACTIONABLE-01.md"]["sha256"],
                  "proposal_sha256": payloads["LEAF-PROPOSAL-01.md"]["sha256"],
                  "manifest_sha256": digest((OWN / "INTERNAL-MANIFEST.json").read_bytes())}))
