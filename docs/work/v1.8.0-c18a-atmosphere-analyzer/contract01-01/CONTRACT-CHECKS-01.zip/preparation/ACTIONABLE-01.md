# Proposed next C18 leaf: atmosphere analyzer

**Preparation only; no implementation, numeric/acquisition acceptance or ledger
change.** Fixed source object `bd0148e98d065df6ac77789eca0a5dae9b6a409a`.

## Findings / assignability

No existing runtime defect was reproduced. The **smallest independently useful
candidate is one C18a unit: `item:atmAnalyser`**, currently PLANNED, target
**`advancedrocketrycommunity:atmosphere_analyzer`**. Its accepted behavior is
read-only server eye-cell feedback (ADR-066:184–187). No auxiliary gas, pad,
transaction, new SavedData/schema or public API mutation is needed.

An isolated source task is assignable **after Root freezes three exact technical
inputs**: private query/lifetime wiring; NEW recipe/art/feedback choices; the
accepted additive device switch. These are actual preparation dependencies, not
implemented source or a contract-defect finding. No major new owner gameplay
choice is required for the accepted measurement semantics.

## Existing observer shape and exact read composition

| Existing source | Reuse / constraint |
|---|---|
| `PlayerLifeSupportService.java:68`; `AtmosphereManager.java:78–91` | Derive exactly the user's server eye cell; read effective `breathabilityAt` and `controlledAt`. No equipment/HUD/EXEMPT status determines air. |
| `AtmosphereLevelService.java:223–251` | Known supplied scanned volume is breathable/control; pending has its own state. Add loaded/build-height guard **before** querying: base breathable alone is not an unloaded-cell certificate. |
| `BodyContextResolver.java:37–60`, `CelestialCatalog.forLevel:116–119`, `StationRegionBodyContextResolver.java:22–36` | Capture one existing catalog; same catalog resolves logical body and ambient metadata. Committed station lookup only; unknown/blocked/reserved/Space gap fails context, never creates a station. |
| `ServerEnvironmentQueries.java:78–82`; `EnvironmentQueries.java:12–20` | Public API intentionally has **no station atmosphere**, can return configured metadata at unloaded coordinates and is not effective air. Keep API unchanged. In orbit use actual Space ambient, **not** orbitBody surface atmosphere. |
| `AtmosphereManager.java:135–141` | Unknown-Level conservative gameplay fallback is not a known instrument profile; resolve valid ambient/context first. |
| `CelestialCatalogManager.java:44–67` | Accepted reload is fresh; rejected reload retains last good. Old detached readings remain unchanged. |
| `AtmosphereRuntime.java:12–40`; `AdvancedRocketryCommunity.java:172–175,353–389` | Current bridge exposes metrics/vents, not item query. Root must wire a small host-only read service, close/drop server references on stopping, refuse old/cross-server/off-thread handles. No parallel atmosphere/registry store. |

Proposed private shape: immutable `AnalyzerReading` (fixed availability/cell/locus
enums, optional logical-body/ambient-body IDs, paired finite pressure/K metadata,
controlled flag); one host-only `read(ServerPlayer)` plus `close()`. Item admission
owns exact held item/hand/count and cooldown; service owns server/loaded/context
checks. It has no exported arbitrary-position method, persistent fields or
retained player/reading cache. Root reviews/freezes constructor/wiring before
delegation; this memo does not admit signatures.

## Established behavior vs unfrozen choices

**Established:** read own eye only; localized breathability/temperature/pressure/
body with PENDING/UNAVAILABLE. Supplied known cell gives effective breathable,
while ambient remains the actual profile. Unknown context cannot become valid
because of a vent. Positive-pressure nonbreathable air is not labelled vacuum
merely because the manager enum is named VACUUM. No oxygen fraction exists.
Pressure is finite **0..10**, temperature **0..2,000 K**. Current built-in authoring
facts: Earth **1/288 K**, Moon **0/220 K**, Space **0/3 K**; installed definitions
and reload remain authoritative. Detector 10-tick/six-neighbor or 240/330/2
predicates are **not** analyzer scheduling/new balance requirements.

**Proposed, not selected silently:** unstackable/no-durability item; vanilla
2-server-tick cooldown (10 reports/s); one fixed localized chat Component so
the existing hazard action bar is not overwritten; bounded ID fallback for a
missing body translation, ambient versus cell/control labels. Root must freeze
these exact UX details. Server admission checks real connected alive
nonspectating player, owning thread/Level, actual held item/count and eye loading;
creative reads the same air. Client branch only predicts use; no custom C2S,
target coordinates, NBT/capability callbacks, gas/FE debit or item mutation.

**NEW acquisition candidate, not legacy parity or agreed recipe:** shapeless
**1 basic_circuit + 1 glass_pane + 1 iron_ingot → 1 analyzer**, normal unlock on
basic circuit. Actual generated circuit and wafer shapeless recipes exist under
the same stable IDs (wafer + copper + redstone → circuit; quartz + redstone →
wafer). They need no powered machine, but quartz has ordinary source/Nether
access; this is not a fresh-Overworld/full-progression proof. Do not formalize
the circuit tooltip/final C16d recipe in this leaf. If Root rejects this
candidate, freeze another exact acquisition input before assignment.

**NEW art:** original generated 16×16 item texture/model; pre-authoring provenance
before DataGen, source/hash review and later V1. No upstream asset/recipe was read
or imported here; unrelated legacy C18d asset rows do not close automatically.

Root adds accepted COMMON `lifeSupport.classicDevicesEnabled=true`; absent in
current named config. Disabled returns fixed localized reason without work,
keeps ID/data registered. No equipment/survey switch or new item schema required.
Use only additive v180 language output with existing body labels left intact.

## Disjoint write boundary

- **Worker new files only:** `atmosphere/instrument/` reading/projection/service/item,
  analyzer-only NEW art/data/language providers, scoped unit tests, new
  `AtmosphereAnalyzerGameTests.java`, own task records and integration proposal.
- **Root only:** `ModItems`, `ModCreativeTabs`, common config/tests, main lifecycle/
  runtime bridge, bootstrap/provider language wiring, generated resources,
  provenance, ledger/status/acceptance and full-test/native/client scheduling.
- Original atmosphere/suit/BodyContext/API/station source read-only to worker;
  no resource writer, capacity migration, new block/menu/channel or large framework.

## Checks that determine source eligibility and later delivery

1. **A0:** strict reading invariants/finite metadata, body/locus/Space projection,
   PENDING/unknown guards, supplied versus ambient, locale/fallback fixed fields,
   disabled/closed/off-thread refusal, deterministic NEW resources and exact
   recipe/unlock. No oxygen-provider invocation or NBT mutation on any read.
2. **A1:** actual registered item/actual native `use` with connected non-FakePlayer,
   both hands/rate/recipient; actual manager Earth/Moon/committed station;
   eye-vs-feet volume edge, supply/invalidation/pending, suit independent reading,
   unloaded no-ticket/world-load refusal; unchanged held/custom data and vent
   balances with ordinary ticking explicitly accounted for; actual registered
   crafting result. Preserve/replay existing atmosphere, suit, context and
   `ServerEnvironmentQueriesTest` cases. Test source existence is not a pass.
3. **S1/restart:** current packaged committed JAR, disposable world and an owned
   real player use item before/after clean restart; unchanged item ID/count/
   unrelated NBT and old roots/balances; current rebuilt room authority, stale
   handle refusal, no added ERROR or query-induced tickets. A synthetic hook is
   not part of this leaf; it would require the separate offline UUID/file
   ownership protocol review, not reuse the unresolved inventory-native draft.
4. **V1/V2:** actual handheld model, readable en_us/zh_cn report/ambient-control
   distinction/scale/reload; two real clients receive their own positions/results
   and reconnect. Embedded `ConnectedTestPlayers` is A1, not V1/V2/native proof.
5. Root-scheduled Java17 commands: scoped/new+existing tests, `clean build`,
   `test`, `runData` twice/exact bytes, `git diff --exit-code`, actual required
   `runGameTestServer`, strict source/provenance/resource/content validation and
   current recipe reachability review. No build/GameTest/native/client ran here;
   C16d graph/full ledger and all v1.8 G0–G9 stay open. Check ≥10 GB before heavy jobs.

## Actual preparation evidence

**14 named-input static Python controls /0 FES, exit 0; no Java/native.** Initial
collector exit 1 and mistaken exploratory paths/globs are preserved in
[tool history](TOOL-OBSERVATIONS-01.md). [Input manifest](INPUT-MANIFEST-01.json)
pins 81 files: 79 literal fixed-Git equal, live user AGENTS separate, exactly one
historical CSV LF→CRLF expansion (not literal identity or a normalization waiver).
[Source refs](SOURCE-REFS-01.json), [static log](static-controls-01.log),
[receipt](static-controls-01.json), [final postcheck](POSTCHECK-01.json) and
[internal manifest](INTERNAL-MANIFEST.json) accompany this compact handoff.
[Detailed proposed boundary](LEAF-PROPOSAL-01.md) is supporting preparation only.

**Next action:** Root reviews/freezes the narrow query, recipe/UX/NEW art inputs
and isolated ownership, then assigns source implementation. No ADR adoption,
ledger delivery, source completion or version Gate is claimed by this report.
