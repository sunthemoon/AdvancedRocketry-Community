"""Named read-only C18 feasibility controls; no runtime or project writes."""
from __future__ import annotations
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import unittest

OWN = Path(__file__).resolve().parent
ROOT = Path("D:/GitHub/AdvancedRocketry-Community")
BASE = "bd0148e98d065df6ac77789eca0a5dae9b6a409a"
for key in ("TEMP", "TMP", "TMPDIR"):
    os.environ[key] = str(OWN)
PKG = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/"
TEST = "src/test/java/io/github/sunthemoon/advancedrocketrycommunity/"
ADR = "docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md"
PATHS = [
    "AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md",
    "docs/01-PORTING-PRINCIPLES.md", "docs/04-VERSION-ROADMAP.md",
    "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md",
    "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
    "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
    "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
    "docs/decisions/ADR-060-V180-DEVELOPMENT-BASELINE-EXCEPTION.md",
    "docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md",
    "docs/decisions/ADR-024-STATE-BASED-ATMOSPHERE-BOUNDARIES.md",
    "docs/decisions/ADR-025-SUIT-OXYGEN-PROVIDERS.md",
    "docs/decisions/ADR-034-PLANETARY-EXPOSURE-AND-PROTECTION.md", ADR,
    "docs/work/v1.8.0-c18-contract/ACCEPTANCE.md",
    "docs/work/v1.8.0-c18-contract/OWNER-DECISIONS.md",
    "docs/work/v1.8.0-c18-contract/TASK.md",
    "docs/work/v1.8.0-c18-contract/proposals/revision-03/unit-coverage.csv",
    "docs/work/v1.8.0-content-ledger.csv", "docs/status/CURRENT_VERSION.md",
    "docs/status/GATE_STATUS.md",
] + [PKG + path for path in [
    "AdvancedRocketryCommunity.java", "registry/ModItems.java",
    "registry/ModRegistries.java", "registry/ModCreativeTabs.java", "config/CommonConfig.java",
    "atmosphere/AtmosphereLimits.java", "atmosphere/life/BreathabilityState.java",
    "atmosphere/server/AtmosphereManager.java", "atmosphere/server/AtmosphereLevelService.java",
    "atmosphere/server/AtmosphereRuntime.java", "atmosphere/server/AtmosphereServerEvents.java",
    "atmosphere/server/ServerLevelVolumeWorldView.java", "atmosphere/server/PlayerLifeSupportService.java",
    "atmosphere/content/SpaceSuitOxygen.java", "atmosphere/content/SpaceSuitArmorItem.java",
    "atmosphere/content/OxygenCanisterItem.java", "atmosphere/command/AtmosphereCommands.java",
    "compat/atmosphere/AtmosphereBoundaryCatalog.java", "compat/atmosphere/SuitEquipmentService.java",
    "compat/atmosphere/SuitOxygenAccess.java", "api/atmosphere/AtmosphereBoundary.java",
    "api/environment/EnvironmentQueries.java", "api/environment/EnvironmentSnapshot.java",
    "compat/environment/ServerEnvironmentQueries.java", "compat/environment/EnvironmentQueryLifecycle.java",
    "celestial/CelestialDefaults.java", "celestial/CelestialIds.java",
    "celestial/service/CelestialEnvironmentService.java", "celestial/service/CelestialCatalog.java",
    "celestial/service/CelestialCatalogManager.java", "celestial/context/BodyContextResolver.java",
    "celestial/context/BodyContext.java", "celestial/context/BodyContextResolution.java",
    "celestial/context/WorldLocation.java", "celestial/model/CelestialBodyDefinition.java",
    "celestial/model/AtmosphereDefinition.java", "celestial/environment/PlayerEnvironmentalService.java",
    "station/orbit/StationRegionBodyContextResolver.java", "content/DevelopmentComponentItem.java",
    "datagen/BootstrapDataGenerators.java", "datagen/V180LanguageProvider.java",
    "datagen/V180PumpData.java", "datagen/FlightLanguageProvider.java",
    "datagen/StationLanguageProvider.java", "datagen/V140PlanetaryLanguageProvider.java",
    "client/starmap/RocketStarMap.java", "gametest/ConnectedTestPlayers.java",
    "gametest/AtmosphereGameTests.java", "gametest/AtmosphereBoundaryGameTests.java",
    "gametest/SuitEquipmentGameTests.java",
]] + [TEST + path for path in [
    "compat/environment/ServerEnvironmentQueriesTest.java",
    "api/environment/EnvironmentSnapshotTest.java", "celestial/context/BodyContextResolverTest.java",
    "atmosphere/content/SpaceSuitOxygenTest.java",
]] + [
    "src/generated/resources/data/advancedrocketrycommunity/recipes/basic_circuit.json",
    "src/generated/resources/data/advancedrocketrycommunity/recipes/silicon_wafer.json",
    "src/generated/resources/data/advancedrocketrycommunity/tags/items/silicon_wafers.json",
]

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git(*args: str) -> subprocess.CompletedProcess:
    result = subprocess.run(["git", *args], cwd=ROOT, capture_output=True)
    return result

def collect() -> dict:
    files = {}
    commands = []
    for relative in PATHS:
        path = ROOT / relative
        data = path.read_bytes()
        before = git("show", f"{BASE}:{relative}")
        commands.append({"argv": ["git", "show", f"{BASE}:{relative}"], "exit": before.returncode})
        files[relative] = {
            "bytes": len(data), "sha256": sha(data), "lines": len(data.decode("utf-8").splitlines()),
            "git_bytes": len(before.stdout) if before.returncode == 0 else None,
            "git_sha256": sha(before.stdout) if before.returncode == 0 else None,
            "literal_git_equal": before.returncode == 0 and before.stdout == data,
            "exact_lf_to_crlf_expansion": before.returncode == 0 and b"\r" not in before.stdout
                and data == before.stdout.replace(b"\n", b"\r\n"),
        }
        if (relative != "AGENTS.md" and not files[relative]["literal_git_equal"]
                and not files[relative]["exact_lf_to_crlf_expansion"]):
            raise AssertionError(f"named input drift from fixed baseline: {relative}")
    result = {"fixed_commit": BASE, "root": str(ROOT), "files": files, "commands": commands,
              "permissions": "read-only named inputs; static Python; no Java/native/Gradle/source writes"}
    (OWN / "INPUT-MANIFEST-01.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result

def text_at(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")

def numbered(relative: str, needles: list[str]) -> list[dict]:
    return [{"line": n, "text": line} for n, line in enumerate(text_at(relative).splitlines(), 1)
            if any(needle in line for needle in needles)]

class ExistingInputControls(unittest.TestCase):
    def test_accepted_contract_and_explicit_conditional_admission(self):
        adr = text_at(ADR)
        self.assertIn("status: ACCEPTED\nrevision: 3", adr)
        self.assertIn("Numeric choices labelled **proposal**", adr)
        self.assertIn("D4 pad/player durability remains unproven", text_at("docs/work/v1.8.0-c18-contract/ACCEPTANCE.md"))

    def test_exact_requested_ledger_units(self):
        rows = list(csv.DictReader(io.StringIO(text_at("docs/work/v1.8.0-content-ledger.csv"))))
        self.assertEqual(len([r for r in rows if r["unit_id"] == "item:atmAnalyser"]), 1)
        selected = next(r for r in rows if r["unit_id"] == "item:atmAnalyser")
        self.assertEqual(selected["disposition"], "PLANNED")
        self.assertEqual(selected["plan"], "C18a")
        self.assertEqual(next(r for r in rows if r["unit_id"] == "item:sealDetector")["disposition"], "PLANNED")

    def test_stable_target_name_is_accepted_but_not_registered(self):
        self.assertIn("`atmosphere_analyzer`: item-use reads the user's eye cell", text_at(ADR))
        registries = text_at(PKG + "registry/ModItems.java") + text_at(PKG + "registry/ModRegistries.java")
        self.assertNotIn('"atmosphere_analyzer"', registries)
        self.assertNotIn('"seal_detector"', registries)

    def test_no_existing_classic_device_switch_in_named_config(self):
        self.assertIn("lifeSupport.classicDevicesEnabled", text_at(ADR))
        self.assertNotIn("classicDevicesEnabled", text_at(PKG + "config/CommonConfig.java"))

    def test_profile_model_has_finite_values_and_no_oxygen_fraction(self):
        model = text_at(PKG + "celestial/model/AtmosphereDefinition.java")
        self.assertIn("MAX_PRESSURE = 10.0D", model)
        self.assertIn("MAX_TEMPERATURE_KELVIN = 2_000.0D", model)
        self.assertNotIn("oxygenFraction", model)

    def test_eye_and_effective_room_queries_exist_separately(self):
        life = text_at(PKG + "atmosphere/server/PlayerLifeSupportService.java")
        self.assertIn("BlockPos.containing(player.getX(), player.getEyeY(), player.getZ())", life)
        service = text_at(PKG + "atmosphere/server/AtmosphereLevelService.java")
        self.assertIn("baseAtmosphereBreathable || controlledAt(position)", service)
        self.assertIn("? BreathabilityState.PENDING : BreathabilityState.VACUUM", service)
        self.assertIn("if (!level.hasChunkAt(position))", service)

    def test_public_environment_snapshot_is_not_effective_atmosphere(self):
        api = text_at(PKG + "api/environment/EnvironmentQueries.java")
        self.assertIn("including at unloaded positions", api)
        self.assertIn("does not test room oxygen", api)
        query = text_at(PKG + "compat/environment/ServerEnvironmentQueries.java")
        self.assertIn("station.environment().vacuum(), Optional.empty()", query)

    def test_space_actual_ambient_exists_and_differs_from_earth(self):
        defaults = text_at(PKG + "celestial/CelestialDefaults.java")
        self.assertIn("new AtmosphereDefinition(1.0D, true, 288.0D", defaults)
        self.assertIn("new AtmosphereDefinition(0.0D, false, 3.0D", defaults)
        resolver = text_at(PKG + "station/orbit/StationRegionBodyContextResolver.java")
        self.assertIn("BodyContextResolution.unresolved()", resolver)
        self.assertIn("state.orbitBody()", resolver)

    def test_existing_read_only_lookups_and_lifecycle_do_not_grant_writer(self):
        query = text_at(PKG + "compat/environment/ServerEnvironmentQueries.java")
        self.assertIn("binding = null", query)
        self.assertIn("active.owningThread().getAsBoolean()", query)
        self.assertNotIn(".setDirty", query)
        self.assertNotIn("getBlockEntity", query)
        self.assertNotIn("getChunk(", query)

    def test_seal_detector_interaction_needs_existing_invalidation_accounting(self):
        events = text_at(PKG + "atmosphere/server/AtmosphereServerEvents.java")
        self.assertIn("onRightClickBlock(PlayerInteractEvent.RightClickBlock event)", events)
        self.assertIn("isDoorLike(state) || atmosphere.isRegisteredBoundary(state)", events)
        self.assertIn("atmosphere.markDirty(level, event.getPos())", events)
        self.assertIn("It triggers no scan/force-load or dynamic capability", text_at(ADR))

    def test_finite_reserves_have_new_schema_and_proposed_balance(self):
        adr = text_at(ADR)
        self.assertIn("**proposal** tiers 1,000/2,000/4,000/8,000", adr)
        self.assertIn("Numeric tier/config choices require scoped contract review", adr)
        oxygen = text_at(PKG + "atmosphere/content/SpaceSuitOxygen.java")
        self.assertIn('DATA_KEY = "arce_space_suit_oxygen"', oxygen)
        self.assertNotIn("auxiliary", oxygen)
        self.assertIn("SUIT_OXYGEN_CAPACITY = 2_000", text_at(PKG + "atmosphere/AtmosphereLimits.java"))

    def test_proposed_acquisition_dependency_is_current_craft_not_future_machine(self):
        basic = json.loads(text_at("src/generated/resources/data/advancedrocketrycommunity/recipes/basic_circuit.json"))
        wafer = json.loads(text_at("src/generated/resources/data/advancedrocketrycommunity/recipes/silicon_wafer.json"))
        self.assertEqual(basic["type"], "minecraft:crafting_shapeless")
        self.assertEqual(basic["result"]["item"], "advancedrocketrycommunity:basic_circuit")
        self.assertEqual(wafer["type"], "minecraft:crafting_shapeless")
        self.assertEqual(wafer["result"]["item"], "advancedrocketrycommunity:silicon_wafer")
        self.assertIn({"tag": "forge:gems/quartz"}, wafer["ingredients"])
        self.assertIn("BASIC_CIRCUIT = component(\"basic_circuit\")", text_at(PKG + "registry/ModItems.java"))

    def test_existing_tests_name_the_relevant_boundaries_without_running_them(self):
        query = text_at(TEST + "compat/environment/ServerEnvironmentQueriesTest.java")
        for name in ("blockedRegistryAndUnknownOrbitBodyNeverFallBackToSpace", "queriesLeaveNativeSavedStateAndDirtyFlagUnchanged",
                     "acceptedCelestialReloadIsFreshAndRejectedCandidateKeepsDetachedValues",
                     "offThreadAndExpiredHandlesFailBeforeWorldAccessAndNeverRebind"):
            self.assertIn(name, query)
        game = text_at(PKG + "gametest/AtmosphereGameTests.java")
        for name in ("sealedRoomBecomesBreathable", "doorChangeInvalidatesAndRecovers", "unloadedObservationCreatesNoChunkTicket"):
            self.assertIn(name, game)

    def test_new_item_leaf_has_no_need_to_add_pad_protocol_or_first_event_writer(self):
        adr = text_at(ADR)
        analyzer = adr.split("- `atmosphere_analyzer`:", 1)[1].split("- `seal_detector`:", 1)[0]
        self.assertIn("No target coordinates", analyzer)
        self.assertNotIn("outbox", analyzer)
        self.assertNotIn("schema", analyzer)
        self.assertIn("**Feasibility gate**", adr.split("## 4. Gas charging", 1)[1])

def main() -> int:
    manifest = collect()
    facts = {
        "fixed_commit": BASE,
        "scope": "static existing input controls, NOT runtime or actual query execution",
        "selected_unit": "item:atmAnalyser",
        "refs": {
            ADR: numbered(ADR, ["atmosphere_analyzer", "seal_detector", "actual Space Level", "Numeric tier/config", "Owner-confirmed decision D1", "lifeSupport.classicDevicesEnabled", "240/330", "Every ten ticks", "Exact pattern cells", "Per implemented slice", "C18a needs"]),
            PKG + "atmosphere/server/AtmosphereLevelService.java": numbered(PKG + "atmosphere/server/AtmosphereLevelService.java", ["breathabilityAt(", "controlledAt(", "level.hasChunkAt", "BreathabilityState.PENDING", "index.find(cell)", "provider.canSupplyAtmosphere", "public void clear"]),
            PKG + "compat/environment/ServerEnvironmentQueries.java": numbered(PKG + "compat/environment/ServerEnvironmentQueries.java", ["owningThread", "Locus.SURFACE", "Station", "Optional.empty()", "binding = null", "contexts().resolve"]),
            PKG + "celestial/CelestialDefaults.java": numbered(PKG + "celestial/CelestialDefaults.java", ["AtmosphereDefinition(", "CelestialIds.EARTH_ID", "CelestialIds.MOON_ID", "CelestialIds.SPACE_ID"]),
            PKG + "atmosphere/server/AtmosphereServerEvents.java": numbered(PKG + "atmosphere/server/AtmosphereServerEvents.java", ["onRightClickBlock", "isDoorLike(state) ||", "atmosphere.markDirty(level, event.getPos())"]),
            PKG + "atmosphere/server/AtmosphereRuntime.java": numbered(PKG + "atmosphere/server/AtmosphereRuntime.java", ["static volatile", "install(", "observe(", "metrics("]),
        },
        "named_live_vs_git_differences": [path for path, spec in manifest["files"].items() if not spec["literal_git_equal"]],
    }
    (OWN / "FACTS-01.json").write_text(json.dumps(facts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ExistingInputControls)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    raw = stream.getvalue()
    (OWN / "static-controls-01.log").write_text(raw, encoding="utf-8")
    receipt = {"command": [sys.executable, "-B", str(Path(__file__).resolve())], "exit": 0 if result.wasSuccessful() else 1,
               "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
               "runtime_claim": False, "source_pins": len(manifest["files"]),
               "input_manifest_sha256": sha((OWN / "INPUT-MANIFEST-01.json").read_bytes()),
               "facts_sha256": sha((OWN / "FACTS-01.json").read_bytes())}
    (OWN / "static-controls-01.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(raw)
    print(json.dumps(receipt))
    return receipt["exit"]

if __name__ == "__main__":
    raise SystemExit(main())
