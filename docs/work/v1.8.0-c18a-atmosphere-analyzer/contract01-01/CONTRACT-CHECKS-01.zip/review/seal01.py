from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve() for k in ('TEMP', 'TMP', 'TMPDIR'))
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
inputs = json.loads((OUT / 'INPUTS-02.json').read_bytes())
root = Path(inputs['root'])
for relative, row in inputs['files'].items():
    assert pin((root / relative).read_bytes()) == row['live'], relative
    run = subprocess.run(['git', '-C', str(root), 'show', inputs['fixed_commit'] + ':' + relative], capture_output=True)
    assert run.returncode == 0 and pin(run.stdout) == row['git'], relative
assert pin(Path(inputs['task']['path']).read_bytes()) == {k: inputs['task'][k] for k in ('bytes', 'sha256')}
feasibility = Path(inputs['feasibility']['directory'])
assert pin((feasibility / 'INTERNAL-MANIFEST.json').read_bytes()) == inputs['feasibility']['manifest']
for relative, expected in inputs['feasibility']['files'].items():
    assert pin((feasibility / relative).read_bytes()) == expected
report = OUT / 'REVIEW-01.md'
links = re.findall(r'\]\(([^)]+)\)', report.read_text(encoding='utf-8'))
for target in links:
    assert ':' not in target and '..' not in Path(target).parts
    assert (OUT / target.split('#', 1)[0]).is_file(), target
exclude = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-CHECK-01.json'}
files = []
for path in sorted(OUT.iterdir(), key=lambda p: p.name):
    if path.is_dir():
        assert path.name == 'tmp'
        continue
    assert not path.is_symlink() and path.is_file()
    assert path.name not in exclude, 'Pre-existing seal output: ' + path.name
    files.append({'path': path.name, **pin(path.read_bytes())})
manifest = {'schema': 1, 'scope': 'Independent proposed C18a atmosphere analyzer contract review only',
            'fixed_source': inputs['fixed_commit'], 'files': files,
            'payload_bytes': sum(row['bytes'] for row in files),
            'report': {'path': report.name, **pin(report.read_bytes())},
            'report_relative_links': len(links), 'missing_links': 0, 'excluded': sorted(exclude),
            'java_native_git_writes': 0}
manifestpath = OUT / 'INTERNAL-MANIFEST.json'
manifestpath.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
checksums = ''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in files)
checksums += pin(manifestpath.read_bytes())['sha256'] + '  INTERNAL-MANIFEST.json\n'
checksumspath = OUT / 'SHA256SUMS.txt'
checksumspath.write_bytes(checksums.encode('ascii'))
for row in files:
    assert pin((OUT / row['path']).read_bytes()) == {k: row[k] for k in ('bytes', 'sha256')}
receipt = {'exit': 0, 'payloads': len(files), 'payload_bytes': manifest['payload_bytes'],
           'report': manifest['report'], 'manifest': pin(manifestpath.read_bytes()),
           'checksums': pin(checksumspath.read_bytes()), 'report_relative_links': len(links),
           'missing_links': 0, 'named_project_inputs_postchecked': len(inputs['files']),
           'feasibility_payloads_postchecked': len(inputs['feasibility']['files']),
           'task_sha256': inputs['task']['sha256'], 'java_native_git_writes': 0, 'archive_created': False}
(OUT / 'SEAL-CHECK-01.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2))
