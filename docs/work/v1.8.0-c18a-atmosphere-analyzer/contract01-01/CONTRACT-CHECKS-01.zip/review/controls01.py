"""Contract/source facts and finite models only; no implemented analyzer runtime."""
from pathlib import Path
import ast
import csv
from dataclasses import dataclass
import io
import json
import math
import os
import re
import subprocess
import unittest

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
FEASIBILITY = OUT.parent / 'c18-next-leaf-b9a73f16d2'
BASE = 'bd0148e98d065df6ac77789eca0a5dae9b6a409a'
PKG = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
TEST = 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/'
ADR = 'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md'
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve() for k in ('TEMP', 'TMP', 'TMPDIR'))
INPUTS = json.loads((OUT / 'INPUTS-02.json').read_bytes())
CACHE = {}
def text_at(relative):
    assert relative in INPUTS['files']
    if relative not in CACHE:
        run = subprocess.run(['git', '-C', str(ROOT), 'show', BASE + ':' + relative], capture_output=True)
        assert run.returncode == 0
        CACHE[relative] = run.stdout.decode('utf-8')
    return CACHE[relative]

author_ns = {'unittest': unittest, 'csv': csv, 'io': io, 'json': json, 'text_at': text_at,
             'ADR': ADR, 'PKG': PKG, 'TEST': TEST}
tree = ast.parse((FEASIBILITY / 'inspect_leaf.py').read_bytes())
node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'ExistingInputControls')
exec(compile(ast.Module(body=[node], type_ignores=[]), 'unchanged ExistingInputControls', 'exec'), author_ns)

def project_context(locus, logical_profile, space_profile, context_known, supplied, cell, current=True):
    """Finite explanatory table, not source admitted for gameplay."""
    if not context_known or not current:
        return ('UNAVAILABLE', None, False)
    ambient = space_profile if locus == 'ORBIT' else logical_profile
    if ambient is None:
        return ('UNAVAILABLE', None, False)
    if cell == 'PENDING':
        return ('PENDING', ambient, False)
    return ('BREATHABLE' if supplied or cell == 'BREATHABLE' else 'NON_BREATHABLE', ambient, supplied)

def admissible(player, enabled=True, cooldown=False):
    """Side-effect counts illustrate proposed admission ordering, not Java behavior."""
    keys = ('connected', 'alive', 'nonspectating', 'owning_thread', 'owning_server', 'actual_level', 'hand_item', 'count_one')
    if not all(player.get(k) is True for k in keys) or cooldown:
        return (0, 0, 0)
    return (1 if enabled else 0, 1, 1)

class IndependentControls(unittest.TestCase):
    def test_instrument_ids_obey_current_existing_id_and_width_policy(self):
        self.assertIn('lower-case `snake_case`', text_at('docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md'))
        model = text_at(PKG + 'celestial/model/BoundedCelestialCodecs.java')
        self.assertIn('MAX_RESOURCE_LOCATION_CHARS = 128', model)
        self.assertIn('value.toString().length() > MAX_RESOURCE_LOCATION_CHARS', model)

    def test_ambient_numeric_limits_and_nonbreathable_positive_pressure(self):
        valid = lambda p, t: math.isfinite(p) and math.isfinite(t) and 0 <= p <= 10 and 0 <= t <= 2000
        for p, t in ((0, 0), (10, 2000), (1.7, 260)):
            self.assertTrue(valid(p, t))
        for p, t in ((-0.1, 200), (10.01, 200), (1, -1), (1, 2001), (float('nan'), 200), (1, float('inf'))):
            self.assertFalse(valid(p, t))
        self.assertEqual(project_context('SURFACE', (1.7, 260), (0, 3), True, False, 'VACUUM'),
                         ('NON_BREATHABLE', (1.7, 260), False))

    def test_orbit_uses_space_ambient_not_logical_planet_profile(self):
        earth, space = (1, 288), (0, 3)
        self.assertEqual(project_context('ORBIT', earth, space, True, False, 'VACUUM'),
                         ('NON_BREATHABLE', space, False))
        self.assertNotEqual(project_context('ORBIT', earth, space, True, False, 'VACUUM')[1], earth)

    def test_supplied_never_creates_context_and_pending_is_not_positive_control(self):
        for ambient in ((1, 288), (0, 3)):
            self.assertEqual(project_context('SURFACE', ambient, (0, 3), False, True, 'BREATHABLE'),
                             ('UNAVAILABLE', None, False))
            self.assertEqual(project_context('SURFACE', ambient, (0, 3), True, True, 'PENDING'),
                             ('PENDING', ambient, False))
        self.assertEqual(project_context('ORBIT', (1, 288), (0, 3), True, True, 'BREATHABLE'),
                         ('BREATHABLE', (0, 3), True))

    def test_changed_catalog_discards_composition_and_same_context_overload_exists(self):
        self.assertEqual(project_context('SURFACE', (1, 288), (0, 3), True, True, 'BREATHABLE', current=False),
                         ('UNAVAILABLE', None, False))
        resolver = text_at(PKG + 'celestial/context/BodyContextResolver.java')
        self.assertIn('resolve(WorldLocation location, CelestialCatalog catalog)', resolver)
        self.assertIn('catalog.get(context.bodyId())', resolver)

    def test_each_invalid_hand_host_or_player_refuses_before_query_and_cooldown(self):
        valid = dict.fromkeys(('connected', 'alive', 'nonspectating', 'owning_thread', 'owning_server', 'actual_level', 'hand_item', 'count_one'), True)
        for key in valid:
            malformed = dict(valid); malformed[key] = False
            self.assertEqual(admissible(malformed), (0, 0, 0))
        self.assertEqual(admissible(valid, cooldown=True), (0, 0, 0))
        self.assertEqual(admissible(valid, enabled=False), (0, 1, 1))

    def test_real_manager_control_reads_loaded_fixed_vent_state_not_equipment(self):
        level = text_at(PKG + 'atmosphere/server/AtmosphereLevelService.java')
        control = level.split('public boolean controlledAt(', 1)[1].split('public boolean baseAtmosphereBreathable', 1)[0]
        self.assertIn('if (!level.hasChunkAt(position))', control)
        self.assertIn('provider.canSupplyAtmosphere()', control)
        self.assertNotIn('SpaceSuit', control)
        vent = text_at(PKG + 'atmosphere/vent/OxygenVentBlockEntity.java')
        supply_read = vent.split('public boolean canSupplyAtmosphere()', 1)[1].split('public IItemHandler', 1)[0]
        self.assertIn('oxygenUnits > 0', supply_read)
        self.assertIn('energy.getEnergyStored()', supply_read)
        self.assertNotIn('extractEnergy', supply_read)
        self.assertNotIn('getCapability', supply_read)
        self.assertNotIn('setChanged', supply_read)

    def test_startup_saveddata_is_existing_boundary_not_per_read_mutation(self):
        lifecycle = text_at(PKG + 'compat/environment/EnvironmentQueryLifecycle.java')
        self.assertEqual(lifecycle.count('StationRegistrySavedData.get(server)'), 1)
        station = text_at(PKG + 'station/persistence/StationRegistrySavedData.java')
        find = station.split('public Optional<StationState> findAt(int x, int z)', 1)[1].split('public List<StationState>', 1)[0]
        self.assertIn('operational() ? registry.findAt(x, z) : Optional.empty()', find)
        self.assertNotIn('setDirty', find)
        self.assertNotIn('computeIfAbsent', find)

    def test_query_local_cache_maintenance_is_not_resource_debit_claim(self):
        manager = text_at(PKG + 'atmosphere/server/AtmosphereManager.java')
        self.assertIn('levels.computeIfAbsent(', manager)
        self.assertIn('service.updateEnvironment(', manager)
        service = text_at(PKG + 'atmosphere/server/AtmosphereLevelService.java')
        update = service.split('public void updateEnvironment(boolean breathable, boolean skyIsOpen, boolean climateRequired)', 1)[1].split('public boolean observeVent', 1)[0]
        self.assertIn('resetAllForRescan()', update)
        self.assertNotIn('applySupply(', update)

    def test_unambiguous_surface_and_no_station_public_atmosphere_payload(self):
        catalog = text_at(PKG + 'celestial/service/CelestialCatalog.java')
        self.assertIn('candidates.size() == 1 ? Optional.of(candidates.get(0)) : Optional.empty()', catalog)
        api = text_at(PKG + 'compat/environment/ServerEnvironmentQueries.java')
        self.assertIn('station.environment().vacuum(), Optional.empty()', api)

suite = unittest.TestSuite()
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(author_ns['ExistingInputControls']))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(IndependentControls))
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {'tests': result.testsRun, 'feasibility_unchanged_declaration_tests': 14, 'independent_tests': 10,
          'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
          'java_native_runs': 0, 'scope': 'Existing-source static facts and abstract contract examples only'}
(OUT / 'CONTROLS-01.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() else 1)
