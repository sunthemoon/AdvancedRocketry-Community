from pathlib import Path

# Preserve the original failed literal check; qualify only the inspected status doc.
source = Path(__file__).with_name('intake01.py').read_text(encoding='utf-8')
old = "assert actual == {k: before[relative][k] for k in ('bytes', 'sha256')}, relative"
new = """if relative == 'docs/status/CURRENT_VERSION.md':
            assert actual['sha256'] == '0064cbf41824c9cd9de230bf5b6ddeddcc88175ba097bcbf8cc2e554d26c5a64'
            (OUT / 'CURRENT_VERSION.input.md').write_bytes(raw)
        else:
            assert actual == {k: before[relative][k] for k in ('bytes', 'sha256')}, relative"""
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace("assert relative == 'AGENTS.md' or equal or (",
                        "assert relative in ('AGENTS.md', 'docs/status/CURRENT_VERSION.md') or equal or (")
source = source.replace("'exact_lf_to_crlf_expansion': expansion}",
                        "'exact_lf_to_crlf_expansion': expansion,\n"
                        "                       'matches_frozen_feasibility_input': relative not in before or actual == {k: before[relative][k] for k in ('bytes', 'sha256')}}")
source = source.replace('INPUTS-01.json', 'INPUTS-02.json')
exec(compile(source, 'intake01.py (exact separate live status qualification)', 'exec'))
