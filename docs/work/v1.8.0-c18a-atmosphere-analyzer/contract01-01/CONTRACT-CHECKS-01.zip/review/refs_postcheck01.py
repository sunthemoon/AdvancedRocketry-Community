from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve() for k in ('TEMP', 'TMP', 'TMPDIR'))
record = json.loads((OUT / 'INPUTS-02.json').read_bytes())
ROOT = Path(record['root'])
BASE = record['fixed_commit']
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
checks = []
for relative, row in record['files'].items():
    live = pin((ROOT / relative).read_bytes())
    run = subprocess.run(['git', '-C', str(ROOT), 'show', BASE + ':' + relative], capture_output=True)
    checks.append({'path': relative, 'exit': run.returncode, 'live_equal': live == row['live'],
                   'git_equal': run.returncode == 0 and pin(run.stdout) == row['git']})
assert all(row['live_equal'] and row['git_equal'] for row in checks)
task = Path(record['task']['path'])
assert pin(task.read_bytes()) == {k: record['task'][k] for k in ('bytes', 'sha256')}
feasibility = Path(record['feasibility']['directory'])
assert pin((feasibility / 'INTERNAL-MANIFEST.json').read_bytes()) == record['feasibility']['manifest']
for relative, expected in record['feasibility']['files'].items():
    assert pin((feasibility / relative).read_bytes()) == expected
pkg = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
selections = {
    pkg + 'atmosphere/server/AtmosphereManager.java': ['breathabilityAt(', 'controlledAt(', 'private AtmosphereLevelService service(', 'updateEnvironment(', 'computeIfAbsent('],
    pkg + 'atmosphere/server/AtmosphereLevelService.java': ['public void updateEnvironment(', 'public BreathabilityState breathabilityAt(', 'public boolean controlledAt(', 'provider.canSupplyAtmosphere()', 'private OxygenVentBlockEntity loadedVent(', 'resetAllForRescan()'],
    pkg + 'atmosphere/vent/OxygenVentBlockEntity.java': ['public boolean canSupplyAtmosphere()', 'oxygenUnits > 0', 'energy.getEnergyStored() >='],
    pkg + 'celestial/context/BodyContextResolver.java': ['public Optional<BodyContext> resolve(', 'catalog.get(context.bodyId())', 'candidates.size() == 1'],
    pkg + 'celestial/service/CelestialCatalogManager.java': ['public Optional<CelestialCatalog> current(', 'previous.catalog()', 'state.set(new Snapshot('],
    pkg + 'celestial/service/CelestialCatalog.java': ['public Optional<CelestialBodyDefinition> forLevel('],
    pkg + 'celestial/model/AtmosphereDefinition.java': ['MAX_PRESSURE', 'MAX_TEMPERATURE_KELVIN'],
    pkg + 'celestial/model/BoundedCelestialCodecs.java': ['MAX_RESOURCE_LOCATION_CHARS'],
    pkg + 'compat/environment/EnvironmentQueryLifecycle.java': ['onServerStarted(', 'StationRegistrySavedData.get(server)', 'onServerStopping(', 'onServerStopped('],
    pkg + 'station/persistence/StationRegistrySavedData.java': ['public Optional<StationState> findAt(', 'operational() ? registry.findAt'],
    pkg + 'compat/environment/ServerEnvironmentQueries.java': ['station.environment().vacuum(), Optional.empty()'],
    pkg + 'AdvancedRocketryCommunity.java': ['environmentQueries::onServer', 'initializeAtmosphereBoundaries()', 'atmosphereManager = new AtmosphereManager', 'atmosphereManager.clear()'],
    pkg + 'datagen/FlightLanguageProvider.java': ['body.advancedrocketrycommunity.'],
    'docs/work/v1.8.0-content-ledger.csv': ['item:atmAnalyser'],
    'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md': ['`atmosphere_analyzer`', 'actual Space Level', 'lifeSupport.classicDevicesEnabled'],
}
facts = {}
for relative, needles in selections.items():
    run = subprocess.run(['git', '-C', str(ROOT), 'show', BASE + ':' + relative], capture_output=True)
    assert run.returncode == 0
    facts[relative] = [{'line': i, 'text': line} for i, line in enumerate(run.stdout.decode('utf-8').splitlines(), 1)
                       if any(needle in line for needle in needles)]
links = []
for name in ('ACTIONABLE-01.md', 'LEAF-PROPOSAL-01.md'):
    for target in re.findall(r'\]\(([^)]+)\)', (feasibility / name).read_text(encoding='utf-8')):
        if ':' in target or target.startswith('#'):
            continue
        links.append({'file': name, 'target': target, 'exists': (feasibility / target.split('#', 1)[0]).is_file()})
assert all(row['exists'] for row in links)
(OUT / 'SOURCE-REFS-01.json').write_bytes((json.dumps({'fixed_commit': BASE, 'refs': facts}, indent=2) + '\n').encode())
result = {'checks': checks, 'named_project_files': len(checks), 'feasibility_payloads': 14,
          'task_and_feasibility_manifest_unchanged': True, 'all_named_pins_unchanged': True,
          'feasibility_links': links, 'missing_links': 0, 'java_native_git_writes': 0}
(OUT / 'POSTCHECK-01.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'named_project_files': len(checks), 'all_named_pins_unchanged': True,
                  'task_and_feasibility_manifest_unchanged': True, 'feasibility_links': len(links),
                  'missing_links': 0, 'java_native_git_writes': 0}))
