from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
FEASIBILITY = OUT.parent / 'c18-next-leaf-b9a73f16d2'
BASE = 'bd0148e98d065df6ac77789eca0a5dae9b6a409a'
assert all(Path(os.environ[k]).resolve() == (OUT / 'tmp').resolve() for k in ('TEMP', 'TMP', 'TMPDIR'))
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
manifestraw = (FEASIBILITY / 'INTERNAL-MANIFEST.json').read_bytes()
assert pin(manifestraw)['sha256'] == 'a9aeec17a742199ead21d240bc447208ec94df2302d117e4779350ac243ce3ed'
feasibility_files = {}
manifest = json.loads(manifestraw)
for name, row in manifest['files'].items():
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts and ':' not in name
    actual = pin((FEASIBILITY / name).read_bytes())
    assert actual == row, name
    feasibility_files[name] = actual
assert feasibility_files['ACTIONABLE-01.md']['sha256'] == '5fe719a90fb6d7c4ed048404b4d5250de8948b5746b1ac9e404053b835079c4a'
files = {}
before = json.loads((FEASIBILITY / 'INPUT-MANIFEST-01.json').read_bytes())['files']
commands = []
pkg = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
extra = [pkg + p for p in ['station/persistence/StationRegistrySavedData.java',
         'station/model/StationRegistryModel.java', 'celestial/model/BoundedCelestialCodecs.java',
         'atmosphere/vent/OxygenVentBlockEntity.java', 'celestial/environment/EnvironmentalConditions.java']]
for relative in list(before) + extra:
    raw = (ROOT / relative).read_bytes()
    actual = pin(raw)
    if relative in before:
        assert actual == {k: before[relative][k] for k in ('bytes', 'sha256')}, relative
    command = ['git', '-C', str(ROOT), 'show', BASE + ':' + relative]
    run = subprocess.run(command, capture_output=True, check=False)
    assert run.returncode == 0, (relative, run.stderr)
    gitpin = pin(run.stdout)
    equal = raw == run.stdout
    expansion = b'\r' not in run.stdout and raw == run.stdout.replace(b'\n', b'\r\n')
    assert relative == 'AGENTS.md' or equal or (
        relative == 'docs/work/v1.8.0-c18-contract/proposals/revision-03/unit-coverage.csv' and expansion)
    files[relative] = {'live': actual, 'git': gitpin, 'literal_git_equal': equal,
                       'exact_lf_to_crlf_expansion': expansion}
    commands.append({'argv': command, 'exit': run.returncode, **gitpin})
taskpath = ROOT / 'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md'
taskraw = taskpath.read_bytes()
assert pin(taskraw) == {'bytes': 11393, 'sha256': '234943b59e8423bfcce48916f7317453043356fc4f86e0f8edc5ded0749eeabc'}
(OUT / 'TASK.input.md').write_bytes(taskraw)
record = {'fixed_commit': BASE, 'feasibility': {'directory': str(FEASIBILITY),
          'manifest': pin(manifestraw), 'files': feasibility_files},
          'root': str(ROOT), 'files': files, 'git_commands': commands,
          'task': {'path': str(taskpath), **pin(taskraw)}, 'java_native_git_writes': 0}
(OUT / 'INPUTS-01.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({'feasibility_payloads': len(feasibility_files), 'named_project_inputs': len(files),
                  'git_objects': len(commands), 'live_vs_git_qualified': [r for r, f in files.items() if not f['literal_git_equal']],
                  'task_sha256': pin(taskraw)['sha256'], 'java_native_git_writes': 0}))
