# C18a-01 atmosphere analyzer contract review 01

Completed 2026-10-05 (Asia/Taipei). Independent delegated read-only review of
Root's exact proposed leaf; no implementation, recipe/art adoption, ledger or
version acceptance is claimed.

## Findings / scoped disposition

**No Critical/High/Medium/Low contract finding identified** in exact
`TASK.md` (11,393 bytes,
`234943b59e8423bfcce48916f7317453043356fc4f86e0f8edc5ded0749eeabc`)
against the named committed source and accepted ADR-066/061.

The task is eligible for **Root's narrow technical leaf adoption**: own-eye,
server-authoritative, loaded-only private measurement, explicit host lifetime,
NEW recipe/art/UX, and bounded isolated new-file ownership. Adoption would
authorize only separately assigned implementation/review, not an item delivery,
public API, native/visual result or v1.8 Gate. The analyzer remains PLANNED in the
actual ledger; there is no registered analyzer or implemented reader to review.

The twelve-row/eleven-row C18 inventory native proposal and its constructor/join
Medium are separate. This leaf explicitly does not reuse that unresolved fixture
or admit a synthetic native hook.

## Evidence-based comparison

All source line references below are to fixed
`bd0148e98d065df6ac77789eca0a5dae9b6a409a`; selected exact references are in
[SOURCE-REFS-01.json](SOURCE-REFS-01.json). Proposed task line references are to
[TASK.input.md](TASK.input.md), not a future mutable revision.

### Measurement composition and authority

- Accepted ADR-066:184–187 requires authoritative eye-cell air/profile feedback,
  unavailable/pending, no client target coordinates and no held-state air truth.
  Task:12–20,23–29,89–112 preserves this and excludes detector scheduling, seal
  probes, refill/reserves and shared writers. Equipment/HUD protection is not
  inferred to be breathable air.
- `AtmosphereManager.java:78–91` supplies current effective/control queries.
  `AtmosphereLevelService.java:223–251` can return base breathability before
  validating loading; therefore Task:89–93 correctly requires finite/bounds/
  height and loaded-only checks before manager access. This is an implementation
  obligation, not a claim the old manager itself certifies an unloaded eye.
- `BodyContextResolver.java:38–60` has the caller-captured-catalog overload and
  rejects unresolved or absent body identities; `CelestialCatalog.java:116–119`
  requires an unambiguous Level mapping. Task:95–108 composes with one snapshot
  and rejects a changed catalog rather than mixing generations. Manager calls
  internally consult the current catalog, so the final identity recheck must be
  implemented and tested, not omitted because the first capture was immutable.
- ADR-066:157–167 and Task:97–101 distinguish logical orbit body from actual
  Space ambient air. Existing `ServerEnvironmentQueries.java:78–82` intentionally
  has no orbital atmosphere payload; the proposed reader must not populate or
  change that public API. Known supplied air cannot make unknown station/context
  metadata valid. PENDING does not grant positive control/breathability.
- Task:45–55 separates effective state from ambient pressure/Kelvin and control.
  Positive-pressure nonbreathable air must not be displayed as vacuum merely
  because the existing internal state is named VACUUM. `AtmosphereDefinition`
  bounds remain pressure 0..10 and temperature 0..2,000 K; `BoundedCelestialCodecs`
  bounds IDs at 128 characters. No oxygen fraction or real-world pressure unit
  is introduced. Double.toString preserves the configured finite values.

### Existing query side effects and lifecycle

- Manager `service()` at 118–133 may create an existing Level service and update
  its environment. `AtmosphereLevelService.updateEnvironment` at 96–104 may reset
  existing scan/cache authority through `resetAllForRescan`. Thus a read is **not
  guaranteed to make the manager's internal memory bit-identical**. Task:109–112
  explicitly allows this existing local maintenance while prohibiting new scans,
  ticks, resource debit, explicit dirty marks and persistent stores. Ordinary
  world ticking must be accounted for separately in resource assertions.
- `controlledAt` reads a loaded registered vent, ACTIVE status and the concrete
  `OxygenVentBlockEntity.canSupplyAtmosphere` predicate (298–302: blocked flags,
  stored oxygen and stored FE). That predicate performs no debit, NBT copy or
  foreign capability lookup. The task's no-provider/NBT obligation must be
  applied to held/equipment/foreign oxygen callbacks; it does not justify
  bypassing or replacing the explicitly required manager's fixed native-vent
  eligibility predicate. Future tests should instrument those boundaries
  separately, not assert that no internal method called “provider” executes.
- Existing `EnvironmentQueryLifecycle.java:21–36` acquires StationRegistrySavedData
  only at startup; `StationRegistrySavedData.java:208–210` reads only operational
  committed state. Task:72–87 preserves that startup acquisition and prohibits
  per-query SavedData get/load/creation. The analyzer gets no writer authority.
- Main code initializes the manager at 345–353 and clears it on stop at 388.
  Existing environment observers close at HIGHEST stopping/stopped priority
  (173–175). Task:79–87 correctly requires a separate owned analyzer lifecycle,
  permanent close/release and owner-matching removal. Do not blindly copy the
  existing observer's unconditional close behavior: stale/foreign server events
  and old handles must be tested against the new explicit ownership contract.

### Acquisition, resources, configuration and isolated scope

- The stable `atmosphere_analyzer` identity follows ADR-061 snake_case/new-ID
  policy. Actual `item:atmAnalyser` ledger row 464 is PLANNED; no old registry ID
  is repurposed, renamed or removed, and no item-held schema is needed.
- The exact shapeless circuit/pane/iron recipe and two-tick item cooldown are
  **new proposed leaf choices**, not alleged legacy parity or existing balance.
  Current generated basic circuit/wafer recipes provide the declared path and
  wafer requires ordinary quartz; Task:31–36 explicitly avoids fresh-Overworld,
  final C16d or complete progression claims. Actual recipe/unlock/crafting and
  rate/shared-hand behavior remain unexecuted requirements.
- The original 16x16 instrument texture/model is explicitly NEW; Root must record
  source/provenance before authoring and later verify hashes/V1. This review
  authored/imported no bitmap and closes no unrelated asset row.
- Existing Earth/Moon translation keys are present (FlightLanguageProvider:37–38).
  Additive analyzer/Space labels, bounded translatable ID fallback and no server
  client-I18n dependency preserve the existing language boundary. Locale/readability
  and real-client receipt are not proven by static source strings.
- ADR-066:110–114 already defines additive default-true
  `lifeSupport.classicDevicesEnabled`; Task:56–59 proposes only its needed Root
  config implementation. Disabled feedback before querying, exact actual hand/
  count and cooldown-before-query maintain the proposed authority/rate boundary.
- Task:114–138 assigns nine NEW Java paths plus scoped tests/own records to a
  fresh worktree. Central registration/config/provider/generated/provenance/
  ledger/status files stay Root-owned; original atmosphere/context/station/API/
  equipment source is worker-read-only. No dependency/build/API expansion or
  transaction framework is admitted by this task.

## Actual independent checks

All commands used Python `-B` with process-local TEMP/TMP/TMPDIR in this owned D
directory's `tmp`. No Java/Gradle/GameTest/native/client/network/Git mutation,
source/world/deletion or protected-directory access occurred.

| Check | Actual result | Evidence |
|---|---|---|
| `python -B intake01.py` | exit 1 at literal frozen-feasibility comparison of newer live CURRENT_VERSION.md; original inspector/log retained | [script](intake01.py), [log](intake-01.log), [exit](intake-01.exit) |
| `python -B intake02.py` | exit 0; exact separate status qualification; 14 feasibility payloads, 86 named project files and 86 fixed Git object reads; Task hash exact | [script](intake02.py), [log](intake-02.log), [exit](intake-02.exit), [pins](INPUTS-02.json) |
| `python -B controls01.py` | **24 tests / 0 failures, errors, skips**, exit 0: 14 unchanged feasibility declarations and 10 independent static/model controls | [script](controls01.py), [log](controls-01.log), [exit](controls-01.exit), [counts](CONTROLS-01.json) |
| `python -B refs_postcheck01.py` | exit 0; all 86 live/Git pins, exact task and 14 feasibility payloads unchanged; 18 bounded feasibility companion links, 0 missing | [script](refs_postcheck01.py), [log](postcheck-01.log), [exit](postcheck-01.exit), [result](POSTCHECK-01.json) |

The feasibility tests were rerun as unchanged class declarations with reads of
fixed committed objects, not by executing its writing collector/main. The ten
independent controls check exact source paths and finite illustrative projection/
admission examples; they are **not an implemented AnalyzerReading, item/service,
cooldown, lifecycle or runtime test**. No future result is counted as passed.

Earlier bounded exploratory reads guessed absent `source_checks01.py`,
`docs/versions/v1.8.0.md`, `celestial/BodyContextResolver.java` and
`station/model/StationRegistry.java`; their Get-Content missing-path errors are
transcribed observations, not separately stored raw stderr or source failures.
Correct manifest/import-derived names were read. One bounded station-source rg
found no direct atmosphere references (rg no-match exit 1); its combined read
ended 0, and this is not a complete dependency-graph certification. No proposal
assertion, budget or source was changed because of those locator errors.

## Exact boundary and residual verification

- Fixed source: `bd0148e98d065df6ac77789eca0a5dae9b6a409a`.
- Exact Task: `234943b59e8423bfcce48916f7317453043356fc4f86e0f8edc5ded0749eeabc`.
- Feasibility ACTIONABLE: `5fe719a90fb6d7c4ed048404b4d5250de8948b5746b1ac9e404053b835079c4a`;
  internal manifest: `a9aeec17a742199ead21d240bc447208ec94df2302d117e4779350ac243ce3ed`.
- Of 86 named project inputs, 83 are literally fixed-Git equal. Separate
  user-maintained AGENTS has SHA
  `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`.
  One historical coverage CSV has only the previously pinned LF-to-CRLF expansion.
  Current live CURRENT_VERSION has SHA
  `0064cbf41824c9cd9de230bf5b6ddeddcc88175ba097bcbf8cc2e554d26c5a64`,
  reflecting Root's newer native-review/analyzer checkpoint; its separately
  captured [input](CURRENT_VERSION.input.md) is not relabelled as the old
  feasibility or fixed-Git bytes. Root confirmed that doc-only change and held
  the exact task/HEAD/named files through postcheck. No whole-repository identity
  or normalization waiver follows from this scoped input qualification.

Remaining: actual implementation/diff review; Java unit/registered native use;
foreign/off-thread/stale/closed lifecycle checks; exact snapshot reload races;
unloaded/ticket/eye-cell/room-supply assertions; held metadata/provider and resource
conservation; deterministic generated resources twice and real recipe unlock/
crafting; sidedness, suitable owned packaged player/restart cohort, V1/V2 and
language/model/readability/recipient/reconnect observation. Existing required
tests and budgets must remain intact. No synthetic offline-player fixture is
authorized here. Native, visual, performance, R-021 and all G0–G9 remain separate.

Completed scope is this read-only contract review and small loose evidence seal.
Only own external helper/test/log/pin/report files were created; no repository
postimages or source assets were authored. Root decides adoption and later
implementation; this review neither delivers the ledger unit nor completes v1.8.
