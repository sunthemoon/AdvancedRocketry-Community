"""Retain facts01 failure; include the actually referenced native guard method."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
old = (OUT / 'facts01.py').read_bytes()
text = old.decode('utf-8')
before = "'net/minecraft/core/MappedRegistry.class': {'createIntrusiveHolder'},"
after = "'net/minecraft/core/MappedRegistry.class': {'createIntrusiveHolder', 'validateWrite'},"
assert text.count(before) == 1
text = text.replace(before, after).replace("'FACTS-01.json'", "'FACTS-02.json'")
(OUT / 'FACTS-CORRECTION-02.json').write_text(json.dumps(dict(
    original_source_sha256=hashlib.sha256(old).hexdigest(),
    derived_source_sha256=hashlib.sha256(text.encode()).hexdigest(),
    correction=dict(before=before, after=after),
    qualification='Reviewer selection error: createIntrusiveHolder invokes validateWrite; the exception string is in that named dependency. No source/native/candidate alteration.'
), indent=2) + '\n', encoding='utf-8')
exec(compile(text, str(OUT / 'facts01.py') + '[guard-dependency-selected]', 'exec'))
