"""Exact proposal intake and neutral test-only registration controls."""
import hashlib
import itertools
import json
import pathlib
import unittest

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
proposal = AUTHOR / 'REGISTRY-FIX-PROPOSAL-01.md'
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))

before = pin(proposal)
assert before['sha256'] == '50c0649d16b473abb85de24e0f892ada35203ac8841e483d5d9f592007cd7834'
text = proposal.read_text(encoding='utf-8')
facts = json.loads((OUT / 'FACTS-02.json').read_text(encoding='utf-8'))
for name, expected in facts['read_inputs'].items(): assert pin(ROOT / name) == expected, name
for path, expected in facts['primary_inputs'].items(): assert pin(pathlib.Path(path)) == expected, path
log = facts['failed_Source26_log']; assert pin(pathlib.Path(log['path'])) == {k: log[k] for k in ('bytes', 'sha256')}
ids = ['advancedrocketrycommunity:gametest_analyzer_disabled', 'advancedrocketrycommunity:gametest_analyzer_unavailable']

class Controls(unittest.TestCase):
    def test_profile_and_registry_key_matrix(self):
        # Pure specification controls, not a launched FML event or normal-server observation.
        rows = []
        for production, dedicated, server_flag, generic_flag, item_key in itertools.product([False, True], repeat=5):
            server_hook = not production and server_flag
            admitted = dedicated and server_hook and item_key
            general_enabled = not production and (server_flag or generic_flag)
            rows.append(dict(production=production, dedicated=dedicated, gameTestServer=server_flag,
                enableGameTest=generic_flag, item_key=item_key, admitted=admitted, general_enabled=general_enabled))
            if admitted:
                self.assertFalse(production); self.assertTrue(dedicated and server_flag and item_key)
            if production or not dedicated or not server_flag or not item_key: self.assertFalse(admitted)
        self.assertEqual(32, len(rows))
        self.assertEqual(2, sum(r['admitted'] for r in rows))
        self.assertTrue(any(r['general_enabled'] and not r['admitted'] for r in rows))
        self.rows = rows
    def test_normal_generic_and_wrong_registry_make_no_supplier_value(self):
        def model(production, dedicated, server_flag, item_key):
            calls = []
            if dedicated and not production and server_flag and item_key:
                for stable_id in ids: calls.append(stable_id)
            return calls
        for inputs in [(True, True, True, True), (False, False, True, True),
                       (False, True, False, True), (False, True, True, False)]:
            self.assertEqual([], model(*inputs))
        self.assertEqual(ids, model(False, True, True, True))
    def test_exact_document_scope_and_disposal_are_explicit(self):
        for token in ['Dist.DEDICATED_SERVER', 'ForgeGameTestHooks.isGametestServer()',
                      'event.getRegistryKey().equals(ForgeRegistries.Keys.ITEMS)',
                      'inside\n  the registration supplier', 'before any fixture',
                      'reset\nbefore the disabled case and in its `finally` block',
                      'including any failed lookup/assertion', 'not creative entries',
                      'does **not** claim no save impact', 'other three failures']:
            self.assertIn(token, text)
        self.assertEqual(1, text.count(ids[0])); self.assertEqual(1, text.count(ids[1]))
    def test_existing_native_assertions_are_not_replaced_by_feedback_only(self):
        old = (ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
        for token in ['queries.get() == 0', 'queries.get() == 1', 'new ItemStack(unavailable, 2)',
                      '!detached.getCooldowns().isOnCooldown(unavailable)',
                      'replies.size() == 1 && player.getCooldowns().isOnCooldown(disabled)']:
            self.assertIn(token, old)
        self.assertIn('queries\n0 then 1', text)
        self.assertIn('Other actual registered-item tests continue using `atmosphere_analyzer`', text)
    def test_fixture_ids_absent_from_current_central_gameplay_registration(self):
        for name in ['ModItems.java', 'ModCreativeTabs.java']:
            old = (ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry' / name).read_text(encoding='utf-8')
            for stable_id in ids: self.assertNotIn(stable_id.split(':')[1], old)

suite = unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert pin(proposal) == before
assert not (OUT / 'REGISTRY-FIX-PROPOSAL-01.md').exists()
(OUT / 'REGISTRY-FIX-PROPOSAL-01.md').write_bytes(proposal.read_bytes())
(OUT / 'PROPOSAL-CONTROLS-03.json').write_text(json.dumps(dict(
    input_proposal=dict(path=str(proposal), **before), tests=result.testsRun,
    failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
    pure_profile_registry_cases=32, author_or_repository_writes=0, java_native_launches=0,
    baseline_source_inputs_unchanged=True, primary_inputs_unchanged=True,
    qualification='Technical proposal/specification controls only. No implemented handler, supplier, MOD event or profile/native execution.'
), indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
