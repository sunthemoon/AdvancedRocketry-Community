"""Preserve unloaded04; compare parser opcodes numerically, not hex padding."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
old = (OUT / 'unloaded04.py').read_bytes(); text = old.decode('utf-8')
before = "assert [i['opcode_hex'] for i in ins] == ['0x2a', constant, '0xb5', '0xb1']"
after = "assert [int(i['opcode_hex'], 16) for i in ins] == [0x2a, int(constant, 16), 0xb5, 0xb1]"
assert text.count(before) == 1
text = text.replace(before, after).replace("'UNLOADED-04.json'", "'UNLOADED-05.json'")
(OUT / 'UNLOADED-CORRECTION-05.json').write_text(json.dumps(dict(
    original_source_sha256=hashlib.sha256(old).hexdigest(),
    derived_source_sha256=hashlib.sha256(text.encode()).hexdigest(),
    correction=dict(before=before, after=after),
    cause='Parser formats native iconst_0/1 as 0x3/0x4, not zero-padded 0x03/0x04. Numeric instruction/control semantics are unchanged.',
    qualification='Reviewer helper formatting correction only; original source/log/zero-test failure and all candidate inputs retained.'
), indent=2) + '\n', encoding='utf-8')
exec(compile(text, str(OUT / 'unloaded04.py') + '[numeric-opcodes]', 'exec'))
