"""Pinned public-hook/native callback facts and controlled-fixture models only."""
import ast
import hashlib
import json
import pathlib
import struct
import unittest
import zipfile

OUT = pathlib.Path(__file__).resolve().parent
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))
inputs = {}
for name, expected in [('UNLOADED-FIX-PROPOSAL-01.md', '32246d396dc4d519883945eb3e866b3641cc30d531de359ac59593ef716792a0'),
                       ('UNLOADED-FIX-PROPOSAL-02.md', 'e1b8398ab6037751e423b4ea4423d30f7c71e60558d46213fa4983b61c6ae2c3')]:
    p = AUTHOR / name; value = pin(p); assert value['sha256'] == expected
    inputs[str(p)] = value
original = (AUTHOR / 'UNLOADED-FIX-PROPOSAL-01.md').read_text(encoding='utf-8')
supplement = (AUTHOR / 'UNLOADED-FIX-PROPOSAL-02.md').read_text(encoding='utf-8')
facts = json.loads((OUT / 'FACTS-02.json').read_text(encoding='utf-8'))
parser = pathlib.Path(next(p for p in facts['primary_inputs'] if p.endswith('debug_primary02.py')))
jar = pathlib.Path(next(p for p in facts['primary_inputs'] if p.endswith('_1.20.1.jar')))
for p in (parser, jar):
    assert pin(p) == facts['primary_inputs'][str(p)]
tree = ast.parse(parser.read_text(encoding='utf-8')); ns = {'struct': struct}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in {'R', 'parse'}], type_ignores=[]), str(parser), 'exec'), ns)
names = {'net/minecraft/world/entity/Entity.class': {'onAddedToWorld', 'onRemovedFromWorld', 'isAddedToWorld', 'setPos', 'setPosRaw'},
         'net/minecraft/world/entity/LivingEntity.class': {'onAddedToWorld', 'onRemovedFromWorld', 'isAddedToWorld'},
         'net/minecraft/world/entity/player/Player.class': {'onAddedToWorld', 'onRemovedFromWorld', 'isAddedToWorld'},
         'net/minecraft/server/level/ServerPlayer.class': {'onAddedToWorld', 'onRemovedFromWorld', 'isAddedToWorld'},
         'net/minecraft/server/players/PlayerList.class': {'remove'},
         'net/minecraft/server/level/ServerLevel.class': {'removePlayerImmediately', 'getForcedChunks'}}
classes = {}
with zipfile.ZipFile(jar) as z:
    parsed_by_name = {}
    for name, selected in names.items():
        raw = z.read(name); parsed = ns['parse'](raw, selected); parsed_by_name[name] = parsed
        methods = {key: dict(access=m['access'], references=[dict(offset=i['offset'], reference=i['reference']) for i in m['instructions'] if i.get('reference')])
                   for key, m in parsed['selected_methods'].items()}
        classes[name] = dict(bytes=len(raw), sha256=sha(raw), methods=methods)
    entity = parsed_by_name['net/minecraft/world/entity/Entity.class']['selected_methods']
    flips = {}
    for method, constant in [('onAddedToWorld()V', '0x04'), ('onRemovedFromWorld()V', '0x03')]:
        m = entity[method]; ins = m['instructions']
        assert [i['opcode_hex'] for i in ins] == ['0x2a', constant, '0xb5', '0xb1']
        assert 'isAddedToWorldZ' in ins[2]['reference']
        flips[method] = dict(public=bool(m['access'] & 1), only_receiver_boolean_assignment=True,
                            assigned_value=method.startswith('onAdded'), native_calls=0)
    for name in names:
        if name.endswith(('LivingEntity.class', 'Player.class', 'ServerPlayer.class')):
            assert not parsed_by_name[name]['selected_methods'], name
    raw = entity['setPosRaw(DDD)V']
    refs = [i['reference'] for i in raw['instructions'] if i.get('reference')]
    assert any('EntityInLevelCallback.onMove' in r for r in refs)
    assert any('Level.getChunk(II)' in r for r in refs)
    assert any('isAddedToWorld' in r for r in refs)
    getters = classes['net/minecraft/server/level/ServerLevel.class']['methods']
    assert 'LongSets.unmodifiable' in json.dumps(getters)

connected = ROOT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/ConnectedTestPlayers.java'
connected_before = pin(connected)
assert 'onRemovedFromWorld' not in connected.read_text(encoding='utf-8')
assert 'onAddedToWorld' not in connected.read_text(encoding='utf-8')
diag = AUTHOR / 'diagnostic-01-latest.log'; diag_before = pin(diag)
row = [(i+1, line) for i, line in enumerate(diag.read_text(encoding='utf-8').splitlines()) if 'unloadedeyerefuses' in line and 'failed!' in line]
assert len(row) == 1 and 'farLoaded=true' in row[0][1]

class Controls(unittest.TestCase):
    def test_immutable_snapshot_is_not_live_view(self):
        live = {1, 2}; historical = frozenset(live); alias = live
        live.add(3)
        self.assertEqual(alias, live); self.assertNotEqual(historical, live)
    def test_snapshot_budget_refuses_overflow_without_truncation(self):
        def capture(values):
            if len(values) > 4096: raise ValueError('fixture overflow')
            return frozenset(values)
        self.assertEqual(4096, len(capture(set(range(4096)))))
        with self.assertRaises(ValueError): capture(set(range(4097)))
    def test_setup_callback_change_prevents_query(self):
        for loaded, count_changed, tickets_changed in [(True, False, False), (False, True, False), (False, False, True)]:
            admitted = not (loaded or count_changed or tickets_changed)
            self.assertFalse(admitted)
    def test_nested_restoration_attempt_order_preserves_failure(self):
        for fail_body, fail_restore in [(False, False), (True, False), (False, True), (True, True)]:
            steps = []; failed = False
            try:
                try:
                    steps.append('detached-coordinate-query')
                    if fail_body: raise ValueError('body')
                finally:
                    try:
                        steps.append('restore-original-position')
                        if fail_restore: raise ValueError('restore')
                    finally: steps.append('restore-added-bit')
            except ValueError: failed = True
            finally: steps.append('normal-owned-remove')
            self.assertEqual(['restore-original-position', 'restore-added-bit', 'normal-owned-remove'], steps[-3:])
            self.assertEqual(fail_body or fail_restore, failed)
    def test_proposal_retains_callback_identity_assertions_and_evidence_limit(self):
        for token in ['levelCallback.onMove()', 'unchanged identity/admission checks',
                      'before** invoking the analyzer', 'Outer `finally`',
                      'controlled detached-coordinate', 'does not prove ordinary client movement']:
            self.assertIn(token, original)
        for token in ['size() <= 4096', 'Set.copyOf', 'before value',
                      'Before the query and after the query', 'not truncation']:
            self.assertIn(token, supplement)

result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
for path, expected in inputs.items(): assert pin(pathlib.Path(path)) == expected
assert pin(parser) == facts['primary_inputs'][str(parser)] and pin(jar) == facts['primary_inputs'][str(jar)]
assert pin(connected) == connected_before and pin(diag) == diag_before
for name in ['UNLOADED-FIX-PROPOSAL-01.md', 'UNLOADED-FIX-PROPOSAL-02.md']:
    assert not (OUT / name).exists(); (OUT / name).write_bytes((AUTHOR / name).read_bytes())
(OUT / 'UNLOADED-04.json').write_text(json.dumps(dict(inputs=inputs, native_primary=dict(path=str(jar), **pin(jar)),
    selected_classes=classes, actual_public_hook_semantics=flips,
    inheritance_has_no_hook_override_in_three_named_native_subclasses=True,
    connected_fixture_source=dict(path=str(connected), **connected_before, no_hook_override=True),
    diagnostic=dict(path=str(diag), **diag_before, selected_actual_failure=dict(line=row[0][0], text=row[0][1])),
    tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
    source_native_launches=0, inputs_unchanged=True,
    qualification='Public-hook compact primary facts plus pure controlled-fixture models; onMove still runs and no global callback/no-load or client/transfer/restart proof.'
), indent=2) + '\n', encoding='utf-8')
raise SystemExit(not result.wasSuccessful())
