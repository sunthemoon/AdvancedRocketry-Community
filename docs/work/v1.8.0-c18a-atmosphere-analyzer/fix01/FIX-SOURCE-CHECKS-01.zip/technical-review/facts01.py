"""Selected read-only registry/GameTest facts; no Java or official body export."""
import ast
import hashlib
import json
import pathlib
import struct
import subprocess
import zipfile

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
FIXED = '9fce551ea9389ce37a94f804aa0e817399586a7e'
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))
SOURCES = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar')
MAPPED = pathlib.Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
PARSER = pathlib.Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
before = {str(p): pin(p) for p in (SOURCES, MAPPED, PARSER)}
assert before[str(SOURCES)]['sha256'] == '918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0'
assert before[str(MAPPED)]['sha256'] == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'

entries = {}
with zipfile.ZipFile(SOURCES) as z:
    names = ['net/minecraftforge/gametest/ForgeGameTestHooks.java', 'net/minecraftforge/gametest/GameTestMain.java',
             'net/minecraftforge/registries/RegisterEvent.java', 'net/minecraftforge/registries/GameData.java',
             'net/minecraftforge/registries/ForgeRegistry.java', 'net/minecraftforge/gametest/GameTestHolder.java',
             'net/minecraftforge/event/RegisterGameTestsEvent.java']
    for name in names:
        raw = z.read(name); text = raw.decode('utf-8'); lines = text.splitlines()
        wanted = ['isGametestEnabled()', 'isGametestServer()', 'FMLLoader.isProduction()', 'System.setProperty(',
                  'Main.main(args)', 'postRegisterEvents()', 'new RegisterEvent(', 'forgeRegistry.unfreeze()',
                  'postEventWrapContainerInModOrder(', 'forgeRegistry.freeze()', 'valueSupplier.get()',
                  'registeredGametests', 'GameTestRegistry.register(', 'Class.forName(', 'getEnabledNamespaces()',
                  'the registry if the provided registry key matches', 'It is only run once']
        facts = [{'line': i+1, 'matched_tokens': [t for t in wanted if t in line]} for i, line in enumerate(lines) if any(t in line for t in wanted)]
        entries[name] = dict(bytes=len(raw), sha256=sha(raw), selected_locations=facts)
        if name.endswith('ForgeGameTestHooks.java'):
            assert 'return !FMLLoader.isProduction() && Boolean.getBoolean("forge.gameTestServer");' in text
            assert 'return !FMLLoader.isProduction() && (SharedConstants.f_136183_ || isGametestServer() || Boolean.getBoolean("forge.enableGameTest"));' in text
        if name.endswith('GameTestMain.java'):
            assert text.index('System.setProperty("forge.gameTestServer", "true")') < text.index('Main.main(args)')
        if name.endswith('RegisterEvent.java'):
            assert text.index('if (this.registryKey.equals(registryKey))') < text.index('valueSupplier.get()')
        if name.endswith('GameData.java'):
            start = text.index('public static void postRegisterEvents()')
            section = text[start:text.index('private static', start)]
            assert section.index('forgeRegistry.unfreeze()') < section.index('postEventWrapContainerInModOrder(registerEvent)') < section.index('forgeRegistry.freeze()')

ns = {'struct': struct}
tree = ast.parse(PARSER.read_text(encoding='utf-8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in {'R', 'parse'}], type_ignores=[]), str(PARSER), 'exec'), ns)
class_facts = {}
selections = {'net/minecraft/world/item/Item.class': {'<init>'},
    'net/minecraft/core/MappedRegistry.class': {'createIntrusiveHolder'},
    'net/minecraft/server/Main.class': {'main'},
    'net/minecraftforge/gametest/GameTestMain.class': {'main'}}
with zipfile.ZipFile(MAPPED) as z:
    for name, methods in selections.items():
        raw = z.read(name); parsed = ns['parse'](raw, methods)
        assert parsed['selected_methods'], name
        selected = {}
        for key, m in parsed['selected_methods'].items():
            selected[key] = dict(access=m['access'], references=[{'offset': i['offset'], 'reference': i['reference']} for i in m['instructions'] if i.get('reference')])
        class_facts[name] = dict(bytes=len(raw), sha256=sha(raw), methods=selected)
    item_refs = json.dumps(class_facts['net/minecraft/world/item/Item.class']['methods'])
    assert 'createIntrusiveHolder' in item_refs
    assert 'Registry is already frozen' in json.dumps(class_facts['net/minecraft/core/MappedRegistry.class']['methods'])
    assert 'ServerModLoader.load' in json.dumps(class_facts['net/minecraft/server/Main.class']['methods'])

names = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
         'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
         'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
         'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
         'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/SwitchOverrides.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfig.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry/ModItems.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/registry/ModCreativeTabs.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/instrument/AtmosphereAnalyzerItem.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/instrument/AtmosphereAnalyzerRuntime.java',
         'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java',
         'build.gradle']
read_inputs = {name: pin(ROOT / name) for name in names}
objects = {}
for name in [n for n in names if n.startswith('src/') or n == 'build.gradle']:
    cmd = ['git', 'show', FIXED + ':' + name]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    assert r.returncode == 0, (name, r.stderr)
    objects[name] = dict(bytes=len(r.stdout), sha256=sha(r.stdout), command=cmd, exit=r.returncode,
                         current_equal=sha(r.stdout) == read_inputs[name]['sha256'])

log_path = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01/gametest-01-latest.log')
log_before = pin(log_path)
failures = [{'line': i+1, 'text': line} for i, line in enumerate(log_path.read_text(encoding='utf-8').splitlines())
            if ' failed! ' in line and any(token in line for token in ('unloadedeyerefuses', 'disabledunavailable', 'incompletebudgetedroom', 'suppliedeyecell'))]
assert len(failures) == 4
assert sum('Registry is already frozen' in f['text'] for f in failures) == 1
assert pin(log_path) == log_before

guards = []
for production in [False, True]:
    for game_server in [False, True]:
        for generic_enabled in [False, True]:
            guards.append(dict(production=production, forge_gameTestServer=game_server,
                forge_enableGameTest=generic_enabled, server_guard=not production and game_server,
                general_guard_without_SharedConstants=not production and (game_server or generic_enabled)))
assert all(not e['server_guard'] for e in guards if e['production'] or not e['forge_gameTestServer'])
for path, expected in before.items(): assert pin(pathlib.Path(path)) == expected

result = dict(schema=1, status='PREPARATORY_PRIMARY_FACTS_NOT_CANDIDATE_VERDICT',
    source_basis=FIXED, primary_inputs=before, selected_source_entries=entries,
    selected_native_declarations=class_facts, read_inputs=read_inputs, fixed_objects=objects,
    failed_Source26_log=dict(path=str(log_path), **log_before, selected_failures=failures),
    guard_model=guards, java_native_launches=0, official_bodies_or_artifacts_copied=False,
    qualification='Pinned primary source/declarations and Boolean models only. Exact correction proposal/runtime registration/channel/world observations not yet available.')
(OUT / 'FACTS-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Primary seven Forge entries/four native declarations and exact Source26 four failures verified; server-only guard model has eight cases. No Java/native/config/source mutation.')
