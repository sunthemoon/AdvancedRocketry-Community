# Analyzer GameTest registry isolation — preparatory primary facts

Date: 2026-10-05. Status: FACTS_ONLY /AWAITING_EXACT_CORRECTION_PROPOSAL.
Independent delegated reviewer; no source, native or configuration execution.

## Observations requiring qualification

1. The immutable Source26 GameTest log has four distinct required analyzer
   failures. Only `disabledUnavailableAndInvalidUsesDoNotQueryOrMutate` reports
   `Registry is already frozen`. The unloaded-eye, pending-room and supplied-eye
   failures report their respective assertions. A registry-fixture change does
   not itself resolve the other three failures. Exact selected log lines and
   raw log SHA are in [facts](FACTS-02.json).
2. `@GameTestHolder` discovers tests; it does not constrain a class's MOD-bus
   registry listener or automatically guard construction of an Item.
3. `ForgeGameTestHooks.isGametestEnabled()` is broader than the dedicated
   GameTest-server predicate: nonproduction AND shared GameTest flag, dedicated
   flag or generic enable property. Ordinary development clients/servers with
   generic opt-in may therefore qualify. The exact dedicated predicate is
   nonproduction AND `forge.gameTestServer=true`; production returns false even
   with that property. These are pinned source/Boolean facts, not observed
   normal-server launches or network registry comparisons.
4. Conditionally registering stable fixture IDs has registry/save consequences
   within that admitted development process, even without recipes, models or a
   creative-tab entry. A test player holding a fixture may save its ID during
   ordinary removal. A GameTest-world registry snapshot may also include it.
   Therefore such data must remain disposable test data, not a normal gameplay
   acquisition/migration claim. Actual emitted records/snapshots remain unrun.

## Pinned registration and launch facts

Configured Forge47.4.10 source JAR SHA
`918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
Named primary path:
`C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar`.

| Primary member | SHA-256 |
|---|---|
| `net/minecraftforge/gametest/ForgeGameTestHooks.java` | `9f4166737f8380d66a65b16975c6bfcd44e8433d0cae3a5c4544dcc4fa278e9e` |
| `net/minecraftforge/gametest/GameTestMain.java` | `12d1ffb67cdcafe48e327fb3ad1b2dd274ead594c5d437daa58ecfe9318ae24d` |
| `net/minecraftforge/registries/RegisterEvent.java` | `6a7ce275489bb69691746160fecf20b6fd84d5bed1bc39eeb0735a9ed2204ddc` |
| `net/minecraftforge/registries/GameData.java` | `2de4043f6cda32f5417eef5d2f8890e417bfeab82d2c52fe3f8fe55b55b78a9c` |

The source GameTestMain sets both GameTest properties before Main.main. The
pinned mapped Main references ServerModLoader.load. RegisterEvent invokes a
value supplier only after matching the registry key. GameData's registration
dispatch unfreezes, posts the MOD event, then freezes the Forge registry.
These support an early positive GameTest-server gate in the appropriate Item
registration event; they do not validate an unprovided subscriber/class-loading
arrangement, exact fixture postimage or packaged runtime route.

Mapped primary JAR SHA
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.
Actual Item construction references `createIntrusiveHolder`; that method calls
MappedRegistry.validateWrite, which refuses when frozen. No manual unfreeze,
reflection/Unsafe or registry restoration is needed or authorized by this
research. The facts contain compact references/locations, not official bodies.

## Existing reusable capabilities and limits

Fixed source basis is `9fce551ea9389ce37a94f804aa0e817399586a7e`.
The named current source/API files and fixed Git objects are pinned in
[FACTS-02.json](FACTS-02.json); all compared current source files match that
object at intake. Root and author's later inputs must be checked separately.

- Existing `config/SwitchOverrides` can set/clear the accepted classic-devices
  switch without writing config. Existing CommonConfig.classicDevicesEnabled
  uses it, and the registered analyzer reads that switch. This can exercise
  real registered disabled feedback/cooldown, provided finally restores the
  specific override; it does not instrument its final reading callback.
- The injected Item constructor takes a BooleanSupplier and reading Function;
  the existing failing GameTest's local AtomicInteger proves zero/one query
  counts plus native use/chat/cooldown/invalid-count/disconnected guards. Merely
  substituting registered chat assertions would not preserve that evidence.
- Existing ConnectedTestPlayers still provides the connected non-FakePlayer
  adapter. It is not V1/V2 or native ownership/restart evidence.
- The bounded source search found no existing GameTest registry-event fixture
  in this project's GameTest package. No new source set or central registration
  is automatically needed or authorized from that absence.

## Exact-source questions before disposition

The author must provide its actual stable ID pair, guarded construction and
subscriber arrangement, registration-time suppliers, local instrumentation
lifetime/reset/finally behavior, immutable delta and actual test receipts.
Review must distinguish early class initialization from guarded supplier
execution; namespace discovery is not registration isolation. Neither fixture
may enter normal production IDs/creative tabs/recipes/assets or preserve live
world/player references in global instrumentation. Any test-only IDs/records
need an explicit disposable-world scope and no normal missing-ID migration.

The dedicated-launch guard can be assessed against pinned primary facts, but
its actual early property observation, MOD event ordering, native registry
membership, repeat/reset isolation and normal launch exclusion still require
source controls and runtime evidence. Native evidence must retain the original
four failures and cannot borrow other GameTest outcomes as proof of this fix.

## Actual commands, failures and boundaries

`python -B facts01.py`: exit 1. Reviewer selected only createIntrusiveHolder,
then incorrectly expected the exception string to live there; the native
method actually calls validateWrite. [Original raw](facts-01.log) and helper
remain unchanged.

`python -B facts02.py`: exit 0. Adds the actually referenced validateWrite
dependency to the selected read; seven source members/four primary classes,
eight Boolean guard models and all four Source26 failures verified.
[Correction](FACTS-CORRECTION-02.json), [raw](facts-02.log),
[command](facts-02.command.json) preserve the distinction.

An exploratory wrong SwitchOverrides package path was reported by PowerShell
before the correct config path was read; that combined command completed 0
after later reads. It is not a candidate or native failure and no missing
file was created. No other-agent files were modified.

Process-only TEMP/TMP/TMPDIR use this owned D project-parent leaf. No Java,
Gradle, server/client/native launch, dependency install, configuration/source
write, deletion, Git mutation, upstream asset/body import, whole-tree/archive
export or private-bundle access occurred. This is not final candidate review,
technical adoption, API/runtime admission, ledger delivery or any Required Gate.
