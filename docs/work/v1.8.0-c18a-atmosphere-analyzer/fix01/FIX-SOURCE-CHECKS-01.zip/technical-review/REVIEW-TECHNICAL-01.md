# Independent analyzer GameTest fixture-boundary review

Date: 2026-10-05. Delegated independent reviewer. Technical proposals only;
not an actual corrected-source or GameTest/native outcome review.

## Findings

No unresolved Critical, High, Medium or Low finding was identified in the
three exact technical proposal inputs inspected (**0 C /0 H /0 M /0 L**).
They can support Root's separately bounded, one-GameTest-file implementation
assignment, subject to the actual-source and runtime checks below. This report
does not adopt them or authorize source/configuration/runtime execution.

The original Source26 four required analyzer failures remain open historical
runtime observations. Only one is the frozen-registry error. The proposed
registration and controlled-coordinate corrections do not resolve the pending
or supplied-room failures, nor prove any corrected native/GameTest result.

## Exact proposal/source scope

| Input | SHA-256 |
|---|---|
| [Registry proposal01](REGISTRY-FIX-PROPOSAL-01.md), 5,320 B | `50c0649d16b473abb85de24e0f892ada35203ac8841e483d5d9f592007cd7834` |
| [Unloaded proposal01](UNLOADED-FIX-PROPOSAL-01.md), 3,489 B | `32246d396dc4d519883945eb3e866b3641cc30d531de359ac59593ef716792a0` |
| [Independent-snapshot supplement02](UNLOADED-FIX-PROPOSAL-02.md) | `e1b8398ab6037751e423b4ea4423d30f7c71e60558d46213fa4983b61c6ae2c3` |

Author provenance:
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b`.
Proposed Java scope is only
`src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java`
at fixed base `9fce551ea9389ce37a94f804aa0e817399586a7e`.
No corrected registration/movement Java postimage was provided or reviewed.
Existing Item/service/runtime/config/registry/build sources were read and pinned,
not changed. Their exact fixed Git object/live-input equivalence is recorded in
[primary/intake facts](FACTS-02.json).

## Registration boundary assessment

Registry proposal lines 10–40 correctly distinguish MOD registry dispatch from
GameTest discovery. It requires dedicated Dist AND the nonproduction dedicated
GameTest predicate AND ITEM registry-key equality before constructing either
Item or invoking its supplier. The two explicit stable fixture IDs are
`advancedrocketrycommunity:gametest_analyzer_disabled` and
`advancedrocketrycommunity:gametest_analyzer_unavailable`. Construction is inside
registration suppliers, not static Item initialization or a running test.
Exact registry lookup/type assertions have no fallback; queries remain observable
through the same test-only counter. Start/finally reset and owned player cleanup
cover failed lookup/assertion as well as the successful case.

Independent primary evidence:

- ForgeGameTestHooks source lines and predicate are pinned in
  [FACTS-02](FACTS-02.json). `isGametestServer()` requires nonproduction and
  the dedicated property; generic `isGametestEnabled()` also admits other
  opt-in development profiles. GameTestHolder/namespace filtering are not a
  registry isolation mechanism.
- GameTestMain sets both GameTest properties before Main.main. The selected
  mapped Main route references ServerModLoader.load. GameData registration
  unfreezes, posts RegisterEvent, then freezes; RegisterEvent calls suppliers
  only for its matching registry key. These are static launch/phase facts,
  not independently observed normal-server startup or an implemented subscriber.
- Item construction calls createIntrusiveHolder; its native validateWrite
  dependency rejects a frozen registry. Therefore moving construction to a
  positively guarded registration event is supported by the available APIs;
  manual unfreeze/reflection/Unsafe/global registry reset is not required.

The five independent [proposal controls](PROPOSAL-CONTROLS-03.json) include
all 32 production/dist/dedicated-property/generic-property/registry-key
combinations. Only the two dedicated nonproduction ITEM cases differing solely
in generic enable qualify. Production, flagged client, generic-only development,
and wrong-registry cases invoke no modeled supplier. This is a Boolean/specification
model, not real FML dispatch or normal-profile registry membership evidence.

The proposal explicitly allows a deliberately flagged development dedicated
profile to opt in; this is not a security boundary. Fixture entries may appear
in that disposable registry snapshot or synthetic playerdata. Their absence
from normal profiles does not make test-world reuse/missing-ID migration safe.
No creative/model/recipe/DataGen/public gameplay item is added by this proposed
scope. Real client handshake/multiplayer compatibility is unproved; a dedicated
fixture registry is not V1/V2 evidence.

Existing SwitchOverrides can exercise a registered item's disabled branch
without a config-file write but cannot replace the final reading callback's
zero/one query-count instrumentation. The exact existing count/cooldown/feedback/
invalid-count/disconnected assertions are checked unchanged in the source
intake; feedback-only substitution would not preserve their evidence.

## Controlled unloaded-eye boundary assessment

The actual diagnostic failure reports an Earth/BREATHABLE reading and
`farLoaded=true` after setPos. Its log is independently input-pinned in
[UNLOADED-05](UNLOADED-05.json); this is a test-setup observation, not evidence
that the analyzer query loaded the far chunk.

The selected pinned Entity declarations independently show:

- `onRemovedFromWorld()` is public and assigns only the receiver's Forge
  added-to-world Boolean false; `onAddedToWorld()` assigns it true. Neither
  invokes another native method. The named LivingEntity/Player/ServerPlayer
  subclasses and existing ConnectedTestPlayers do not override these hooks.
- setPosRaw still invokes EntityInLevelCallback.onMove and contains the native
  Level.getChunk path. Detaching the Boolean is not equivalent to replacing
  that callback, removing a player, or guaranteeing all native callback paths
  never load. Compact selected references are in [UNLOADED-05](UNLOADED-05.json).
- Existing analyzer admission does not require isAddedToWorld; it still checks
  actual connected/non-FakePlayer/alive/not-removed/nonspectating PlayerList,
  server and Level identity. No production guard or synthetic query coordinate
  is changed by this fixture proposal.

Proposal01 lines 21–42 preserves those actual admission checks, initial attached
state, loaded-count/null-target/not-forced assertions and the original
UNAVAILABLE/no-created-service result. It adds pre-query actual-state admission,
so any callback-induced load or lost identity is a fixture failure before the
analyzer is queried. It does not hide the callback or reclassify this as an
out-of-height/border rejection.

The snapshot supplement makes the forced-set observation independently owned:
native getForcedChunks returns an unmodifiable backing view, so storing that
view would not prove historical equality. The proposal instead checks size
at most 4,096 before Set.copyOf and before/after exact comparisons; overflow
refuses, never truncates. This is a test-only capture bound, not a production
save/NBT/scan-budget change. Actual source must preserve that distinction.

Inner finally restores original position while detached; nested finally
attempts to restore the bit even if body/position restoration fails; outer
finally retains normal owned PlayerList removal/service cleanup. The independent
five [controlled-fixture tests](UNLOADED-05.json) cover alias-vs-copy evidence,
4,096/4,097 bounds, callback-change pre-query refusal and restoration/removal
ordering for body/restore errors. They do not execute native callbacks or
establish complete exception-safe cleanup of a future Java implementation.

This is explicitly a controlled detached-coordinate query on an otherwise
admitted connected player. It is not ordinary client movement, natural unload,
transfer, reconnect, native restart or general gameplay-state proof. Actual
pre-query no-load/admission checks determine eligibility; the primary hook
facts do not substitute for those runtime observations.

## Commands and immutable failure lineage

| Actual command | Result |
|---|---|
| `python -B facts01.py` | exit 1, zero tests: reviewer omitted validateWrite while checking createIntrusiveHolder's error string; [original raw](facts-01.log) |
| `python -B facts02.py` | exit 0: seven Forge source entries, four native classes, eight guard cases and four original failures pinned; [raw](facts-02.log), [correction](FACTS-CORRECTION-02.json) |
| `python -B proposal03.py` | exit 0: five tests, 0 failure/error/skip, 32 profile/key cases; [raw](proposal-03.log), [command](proposal-03.command.json) |
| `python -B unloaded04.py` | exit 1, zero tests: reviewer compared parser `0x3/0x4` with zero-padded text; [original raw](unloaded-04.log) |
| `python -B unloaded05.py` | exit 0: numeric opcode comparison, six selected native classes and five models, 0 failure/error/skip; [raw](unloaded-05.log), [command](unloaded-05.command.json), [correction](UNLOADED-CORRECTION-05.json) |

The two helper failures are reviewer selection/formatting errors, not candidate
test failures. Original helpers/logs remain. A wrong exploratory SwitchOverrides
package read is qualified in [interim facts](FACTS-INTERIM-01.md); no missing file
was created. Diagnostic primary author inspection was not yet sealed; its
mutable expanded output was not substituted for this review's own pinned
primary reads. Source26/diagnostic raw failures are referenced and not rewritten.

Configured primary JARs:

- Forge source: `918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
- Mapped primary: `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`.

Only selected compact semantic facts/pins were retained. No official bodies,
JAR, source tree, mapping, world, archive or asset were exported.

## Required next-source scope and limits

Root may separately assign the exact one-file test-only correction. Actual
source review must verify nested subscriber/early guards/ID supplier construction,
counter reset+no world references, exact lookup/failure cleanup, no test removal
or weaker query/cooldown/resource assertions, and unchanged ten cases /40 ticks.
For the unloaded case it must verify copied/overflow-bounded ticket observations,
actual full admission before/after setPos, retained onMove, exact restoration
and attempt-all outer cleanup. An unexpected callback still fails; no time,
production service, registry framework or global resource policy is expanded.

Compile and full unfiltered GameTests must actually observe early item
registration/native use, no fixture leakage to other gameplay sources, repeated
run instrumentation isolation, and actual controlled-coordinate admission.
Original four failures and diagnostic inputs must remain available. Normal
packaged server/client exclusion remains source-derived until separately observed.
No native/client run is authorized or performed by these notes; pending/supplied
room fixes require their own evidence and exact source review.

No Java/Gradle/native/client/network/Git/configuration/source mutation/deletion
occurred in this review. Helpers and process-only TEMP/TMP/TMPDIR are under this
owned D project-parent leaf; no C output or private-bundle access occurred.
No source adoption, API/runtime admission, ledger delivery, V1/V2/GPU or any
v1.8 Required Gate follows from this technical eligibility recommendation.
