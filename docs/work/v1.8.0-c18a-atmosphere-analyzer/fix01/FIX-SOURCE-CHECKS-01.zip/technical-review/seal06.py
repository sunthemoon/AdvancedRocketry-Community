"""Small technical-review postcheck/loose seal, no archive or source export."""
import hashlib
import json
import pathlib
import re
from urllib.parse import unquote

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
sha = lambda b: hashlib.sha256(b).hexdigest()
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=sha(b))
facts = json.loads((OUT / 'FACTS-02.json').read_text(encoding='utf-8'))
for name, expected in facts['read_inputs'].items(): assert pin(ROOT / name) == expected, name
for p, expected in facts['primary_inputs'].items(): assert pin(pathlib.Path(p)) == expected, p
for file in ['PROPOSAL-CONTROLS-03.json', 'UNLOADED-05.json']:
    result = json.loads((OUT / file).read_text(encoding='utf-8'))
    assert result['tests'] == 5 and result['failures'] == result['errors'] == result['skipped'] == 0
    inputs = result.get('inputs', {})
    if file.startswith('PROPOSAL'):
        expected = result['input_proposal']
        assert pin(pathlib.Path(expected['path'])) == {k: expected[k] for k in ('bytes', 'sha256')}
    else:
        for p, expected in inputs.items(): assert pin(pathlib.Path(p)) == expected, p
        expected = result['diagnostic']
        assert pin(pathlib.Path(expected['path'])) == {k: expected[k] for k in ('bytes', 'sha256')}
report = OUT / 'REVIEW-TECHNICAL-01.md'
links = []
for raw in re.findall(r'\[[^\]]+\]\(([^)]+)\)', report.read_text(encoding='utf-8')):
    name = unquote(raw.split('#')[0]); rel = pathlib.PurePosixPath(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    assert (OUT / name).is_file(), name
    links.append(name)
post = dict(root_source_and_primary_inputs_unchanged=True, three_author_proposals_unchanged=True,
    actual_Source26_and_diagnostic_raw_logs_unchanged=True, report_links=len(links), missing_links=0,
    no_corrected_Java_postimage_reviewed=True, java_native_launches=0,
    source_basis='9fce551ea9389ce37a94f804aa0e817399586a7e',
    qualification='Technical proposals/source-derived models only, no implementation/native/profile/Gate disposition.')
(OUT / 'POSTCHECK-06.json').write_text(json.dumps(post, indent=2) + '\n', encoding='utf-8')
excluded = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-06.json', 'seal-06.log', 'seal-06.exit', 'seal-06.command.json'}
assert not (OUT / 'INTERNAL-MANIFEST.json').exists()
files = [dict(path=p.name, **pin(p)) for p in sorted(OUT.iterdir(), key=lambda p: p.name) if p.is_file() and p.name not in excluded]
manifest = dict(schema=1, scope='Independent analyzer registry and controlled-unloaded GameTest technical proposals only; no actual corrected-source/native admission.',
    files=files, payload_count=len(files), payload_bytes=sum(e['bytes'] for e in files),
    excluded=sorted(excluded | {'process-temp/'}), original_failures_preserved=True)
raw = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
(OUT / 'INTERNAL-MANIFEST.json').write_bytes(raw)
(OUT / 'SHA256SUMS.txt').write_text(''.join(f"{e['sha256']}  {e['path']}\n" for e in files) + f"{sha(raw)}  INTERNAL-MANIFEST.json\n", encoding='utf-8')
for e in files: assert pin(OUT / e['path']) == {k: e[k] for k in ('bytes', 'sha256')}
result = dict(report=pin(report), manifest=pin(OUT / 'INTERNAL-MANIFEST.json'), checksums=pin(OUT / 'SHA256SUMS.txt'),
    payload_count=manifest['payload_count'], payload_bytes=manifest['payload_bytes'], report_links=len(links), missing_links=0,
    all_entry_SHA_exact=True, archive_created=False, no_Java_native_source_mutation=True)
(OUT / 'SEAL-06.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
