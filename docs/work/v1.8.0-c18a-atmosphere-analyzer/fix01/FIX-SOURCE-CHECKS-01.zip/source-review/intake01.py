from pathlib import Path
import hashlib, json, subprocess, datetime, re

OUT = Path(__file__).resolve().parent
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
EVIDENCE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
PREFIX = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
GT = PREFIX + 'gametest/AtmosphereAnalyzerGameTests.java'
paths = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md']
paths += [PREFIX + x for x in ['atmosphere/server/AtmosphereRuntime.java',
    'atmosphere/server/AtmosphereManager.java', 'atmosphere/server/AtmosphereLevelService.java',
    'atmosphere/server/AtmosphereServerEvents.java', 'atmosphere/vent/OxygenVentBlockEntity.java',
    'atmosphere/instrument/AtmosphereAnalyzerService.java',
    'atmosphere/instrument/AtmosphereAnalyzerLifecycle.java',
    'gametest/ConnectedTestPlayers.java', 'gametest/AtmosphereGameTests.java']]

def pin(p, role):
    b=p.read_bytes()
    return {'path': str(p), 'role': role, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

records=[]
for x in paths:
    p=ROOT/x
    if p.is_file(): records.append(pin(p, 'live read-only context'))
    else: records.append({'path': str(p), 'role': 'locator not found'})

baseline=subprocess.run(['git','-C',str(ROOT),'show',BASE+':'+GT],capture_output=True,check=True).stdout
(OUT/'BASE-9fce-AtmosphereAnalyzerGameTests.java').write_bytes(baseline)
records.append(pin(OUT/'BASE-9fce-AtmosphereAnalyzerGameTests.java', 'fixed Git object'))
author=(AUTHOR/GT).read_bytes()
(OUT/'INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java').write_bytes(author)
records.append(pin(AUTHOR/GT, 'intermediate only; not final candidate'))
for round_id in ('01','02','03'):
    for suffix in ('COMMAND.json','RESULT.json','PRECHECK.json','POSTCHECK.json','SOURCE-MANIFEST.json'):
        p=EVIDENCE/f'diagnostic-{round_id}-{suffix}'
        records.append(pin(p, 'author distinct failed diagnostic observation'))
    p=EVIDENCE/f'diagnostic-{round_id}-latest.log'
    records.append(pin(p, 'author distinct failed diagnostic log'))
    lines=p.read_text(encoding='utf-8', errors='strict').splitlines()
    selected=[{'line':i+1,'text':line} for i,line in enumerate(lines)
              if ('AtmosphereAnalyzerGameTests' in line and ('failed' in line.lower() or 'Failure' in line))
              or 'required tests failed' in line or 'Root and fixture differ' in line
              or 'ARCE_ANALYZER' in line]
    (OUT/f'DIAGNOSTIC-{round_id}-EXCERPTS.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2),encoding='utf-8')
original=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01/gametest-01-latest.log')
records.append(pin(original,'Root Source26 original failed GT log'))
for x in ('REGISTRY-FIX-PROPOSAL-01.md','UNLOADED-FIX-PROPOSAL-01.md','UNLOADED-FIX-PROPOSAL-02.md'):
    records.append(pin(EVIDENCE/x,'adopted technical eligibility, not actual source acceptance'))
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixed_base':BASE,
    'root_live_head_context_only':subprocess.run(['git','-C',str(ROOT),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),
    'author_head':subprocess.run(['git','-C',str(AUTHOR),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),
    'inputs':records, 'phase':'preparatory intermediate intake; Java not authorized',
    'baseline_cases':re.findall(r'@GameTest\([^)]*\)\s*public static void (\w+)',baseline.decode()),
    'intermediate_cases':re.findall(r'@GameTest\([^)]*\)\s*public static void (\w+)',author.decode())}
(OUT/'INTAKE-01.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'inputs':len(records),'cases':len(result['baseline_cases']),
                  'intermediate_cases':len(result['intermediate_cases']),'utc':result['utc']}))
