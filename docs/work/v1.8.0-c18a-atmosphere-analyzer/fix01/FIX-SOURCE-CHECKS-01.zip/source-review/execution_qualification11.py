from pathlib import Path
import json, hashlib, re, datetime, xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
records=[]
for stage in ('04','10'):
    p=HERE/('INDEPENDENT-'+stage+'.log');raw=p.read_bytes();lines=raw.decode('utf-8').splitlines()
    tasks=[line for line in lines if re.match(r'^> Task :(?:cleanTest|compileJava|compileTestJava|test)(?: |$)',line)]
    test_lines=[line for line in lines if re.match(r'^> Task :test(?: |$)',line)]
    xml=[]
    for p in sorted((HERE/('independent'+stage+'-xml')).glob('TEST-*.xml')):
        root=ET.fromstring(p.read_bytes());cases=root.findall('testcase')
        xml.append({'path':p.relative_to(HERE).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                    'suite_timestamp':root.get('timestamp'),'tests':int(root.get('tests')),'actual_cases':len(cases)})
    record={'stage':stage,'raw_sha256':hashlib.sha256(raw).hexdigest(),'actual_task_lines':tasks,
            'exact_test_task_lines':test_lines,'junit_origin':'cache-restored, not independently executed' if stage=='04' else 'uncached test execution',
            'xml':xml}
    if stage=='04':assert test_lines==['> Task :test FROM-CACHE']
    else:assert test_lines==['> Task :test'] and '--no-build-cache' in json.loads((HERE/'INDEPENDENT-10-COMMAND.json').read_text(encoding='utf-8'))['command']
    records.append(record)
cache_hashes={x['sha256'] for x in records[0]['xml']};actual_hashes={x['sha256'] for x in records[1]['xml']}
assert not cache_hashes & actual_hashes
result={'records':records,'qualification':'Independent04 cleanTest restored test outputs from build cache. Independent10 separately executed the real unchanged five JUnit classes with --no-build-cache. Compiler tasks remain explicitly UP-TO-DATE, not freshly recompiled.',
 'collector_correction':'Original independent10 RESULT regex used whitespace that crossed a newline and captured JAVA_TOOL_OPTIONS. That original result/helper are retained. This separate splitlines-based observation establishes actual task status from immutable raw bytes without rewriting original evidence.',
 'XML_content_changes_between_cache_and_execution':True}
(HERE/'EXECUTION-QUALIFICATION-11.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cached_test_task':records[0]['exact_test_task_lines'],'uncached_test_task':records[1]['exact_test_task_lines'],'uncached_xml_suites':len(records[1]['xml']),'actual_cases':sum(x['actual_cases'] for x in records[1]['xml'])}))
