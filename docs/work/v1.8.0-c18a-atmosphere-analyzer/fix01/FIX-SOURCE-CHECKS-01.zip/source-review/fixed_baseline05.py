from pathlib import Path
import subprocess, json, hashlib

HERE=Path(__file__).resolve().parent
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
E=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
BASE='9fce551ea9389ce37a94f804aa0e817399586a7e'
manifest=E/'full-06-SOURCE-MANIFEST.json'
named=json.loads(manifest.read_text(encoding='utf-8'))['inputs']
done=subprocess.run(['git','-C',str(WT),'ls-tree','-r','-z',BASE,'--','src','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','gradle'],capture_output=True,check=True)
records=[]
for row in done.stdout.split(b'\0'):
    if not row: continue
    metadata,name=row.split(b'\t',1)
    mode,kind,oid=metadata.decode().split()
    assert kind=='blob'
    name=name.decode('utf-8')
    assert 'AdvancedRocketry-Community-v1plus-Development-Docs' not in name
    records.append((name,oid))
assert set(name for name,_ in records)==set(named)
proc=subprocess.Popen(['git','-C',str(WT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
changed=[]; observed_drift=[]
for name,oid in records:
    proc.stdin.write((oid+'\n').encode()); proc.stdin.flush()
    header=proc.stdout.readline().decode().split()
    assert header[0]==oid and header[1]=='blob'
    raw=proc.stdout.read(int(header[2])); assert proc.stdout.read(1)==b'\n'
    baseline={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    if baseline!=named[name]:changed.append({'path':name,'git_blob':oid,'baseline':baseline,'candidate':named[name]})
    actual=(WT/name).read_bytes()
    if {'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest()}!=named[name]:observed_drift.append(name)
proc.stdin.close(); exit_code=proc.wait(); assert exit_code==0
result={'fixed_base':BASE,'named_manifest':str(manifest),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
        'git_blob_count':len(records),'different_from_fixed_objects':changed,'wt_different_from_named_manifest':observed_drift,
        'excluded':'No private directory inventory or content read; explicit committed src/build paths only.',
        'phase':'full06 input confirmation; external final handoff still required'}
(HERE/'FIXED-BASELINE-CONTROL-05.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'git_blob_count':len(records),'changed_from_base':len(changed),'changed_paths':[x['path'] for x in changed],'manifest_drift':observed_drift}))
assert len(changed)==1 and changed[0]['path'].endswith('/AtmosphereAnalyzerGameTests.java') and not observed_drift
