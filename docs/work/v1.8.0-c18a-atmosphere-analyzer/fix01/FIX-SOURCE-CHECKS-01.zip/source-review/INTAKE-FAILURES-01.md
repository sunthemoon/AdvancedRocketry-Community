# Preparatory read failures

This reviewer has not run Java, Gradle or a GameTest/native host.

- The first task-record locator incorrectly used `v1.8.0-c18a-analyzer/PROGRESS.md`; the actual existing directory is `v1.8.0-c18a-atmosphere-analyzer`. The read failed. The latter progress text is inherited from original development and is not a current corrective handoff.
- The first adjacent-module locators omitted `server/` and `vent/`. `AtmosphereManager.java`, `AtmosphereEvents.java` and `OxygenVentBlockEntity.java` were not found at those guessed paths. The combined command exited 1. Subsequent bounded filename discovery found `server/AtmosphereManager.java`, `server/AtmosphereServerEvents.java`, `vent/OxygenVentBlockEntity.java`; no inputs were changed.
- A subsequent `rg` Windows argument ending in `Atmosphere*GameTests.java` produced invalid path error 123, and the combined command exited 1. The source reads preceding that failed search completed. Later searches use a named directory plus `-g`.

These are reviewer tooling failures, not candidate compile/test failures. Raw tool outputs remain in the session; this compact transcription preserves their scope without copying unnecessary full source output.

- A later abbreviated `FIX-HANDOFF.md` read failed; the actual named manifest entry is `FIX-HANDOFF-01.md`. The combined command exited 0 after other reads. The exact manifest-resolved path was then read successfully.
- `fixed_baseline05.py` exited 1 after observing two raw Git-blob differences rather than its expected one. It reported 2,835 actual named inputs, not 3,036. The extra difference was the unchanged Windows `gradlew.bat` checkout. Separate `fixed_baseline06.py` exited 0 after checking fixed `.gitattributes` requires CRLF and all 92 LF-to-CRLF pairs exactly account for the wrapper identity. The first result and failure remain unchanged; this is a reviewer qualification correction, not candidate source repair.

- Independent04 `cleanTest` did not defeat Gradle's build cache: `:test FROM-CACHE` restored five XML suites with 19 cases. Those XML/results/logs remain intact and are not a new independent JUnit execution. Root separately authorized serial independent10 with `--no-build-cache`; the real unchanged five test classes then executed. No candidate/test changes were made.
- The independent10 collector's status regex used `\s+` across a newline and captured the following `JAVA_TOOL_OPTIONS` line as a task suffix. Original helper/result remain intact. Separate `execution_qualification11.py` parses immutable raw log lines exactly and confirms `> Task :test`, uncached execution and five new XML content identities. The command itself exited 0; this collector field error is not a test failure.
