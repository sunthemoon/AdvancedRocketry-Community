from pathlib import Path
import os, json, hashlib, shutil, subprocess, time, datetime, re
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
BASE='9fce551ea9389ce37a94f804aa0e817399586a7e'
manifest=AUTHOR/'full-06-SOURCE-MANIFEST.json'
expected=json.loads(manifest.read_text(encoding='utf-8'))['inputs']

def write(name,result): (HERE/name).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def snapshot():
    return {p:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p in expected for b in [(WT/p).read_bytes()]}

before=snapshot();disk={d:shutil.disk_usage(d+':/').free for d in ('C','D')}
head=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
write('INDEPENDENT-10-PRECHECK.json',{'head':head,'source_count':len(before),'mismatches':[p for p in expected if expected[p]!=before[p]],
      'free_bytes':disk,'threshold_bytes':10_000_000_000,'author_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()})
assert head==BASE and before==expected and all(n>=10_000_000_000 for n in disk.values())
temp=HERE/'process-temp-10';temp.mkdir(exist_ok=True)
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Java/jdk-17.0.7';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
for k in ('TEMP','TMP','TMPDIR'):env[k]=str(temp)
env['JAVA_TOOL_OPTIONS']='-Djava.io.tmpdir='+temp.as_posix()
cmd=[str(WT/'gradlew.bat'),'--offline','--no-daemon','--no-build-cache','--max-workers=2',
     '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir='+temp.as_posix(),'cleanTest','compileJava','compileTestJava','test']
for selector in (
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AnalyzerReadingTest',
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerFeedbackTest',
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerServiceTest',
 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerLanguageTest',
 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerDataTest'):
    cmd+=['--tests',selector]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();wall=time.time();start=time.monotonic()
write('INDEPENDENT-10-COMMAND.json',{'command':cmd,'cwd':str(WT),'started_utc':started,
      'JAVA_HOME':env['JAVA_HOME'],'JAVA_TOOL_OPTIONS':env['JAVA_TOOL_OPTIONS'],'TEMP_TMP_TMPDIR':str(temp),
      'authority':'Root separately granted serial uncached scoped replay after independent04 terminal'})
print('START '+started,flush=True)
with (HERE/'INDEPENDENT-10.log').open('wb') as log: done=subprocess.run(cmd,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();changed=[p for p in expected if after[p]!=before[p]]
write('INDEPENDENT-10-POSTCHECK.json',{'source_count':len(after),'changed':changed,'head':head,
     'free_bytes':{d:shutil.disk_usage(d+':/').free for d in ('C','D')}})
target=HERE/'independent10-xml';target.mkdir(exist_ok=True);suites=[]
for p in sorted((WT/'build/test-results/test').glob('TEST-*.xml')):
    raw=p.read_bytes();(target/p.name).write_bytes(raw);r=ET.fromstring(raw);cases=r.findall('testcase')
    suites.append({'name':r.get('name'),**{k:int(r.get(k)) for k in ('tests','failures','errors','skipped')},
       'actual_cases':len(cases),'actual_failures':sum(c.find('failure') is not None for c in cases),
       'actual_errors':sum(c.find('error') is not None for c in cases),'fresh_after_launch':p.stat().st_mtime>=wall,
       'sha256':hashlib.sha256(raw).hexdigest()})
logtext=(HERE/'INDEPENDENT-10.log').read_text(encoding='utf-8')
tasks=re.findall(r'^> Task :test(?:\s+(.*))?$',logtext,re.M)
result={'exit':done.returncode,'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds':time.monotonic()-start,'source_changed':changed,'actual_test_task_statuses':tasks,
        'junit':{'suites':len(suites),**{k:sum(s[k] for s in suites) for k in ('tests','failures','errors','skipped','actual_cases','actual_failures','actual_errors')},'rows':suites}}
write('INDEPENDENT-10-RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
if any(x.strip() in ('FROM-CACHE','UP-TO-DATE') for x in tasks):raise SystemExit(3)
raise SystemExit(done.returncode if not changed else 2)
