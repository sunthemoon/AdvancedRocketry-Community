# C18a analyzer corrected GameTest source review

## Findings, highest severity first

No introduced Critical, High, Medium or Low finding was observed in the exact
one-GameTest-source correction and two task-record postimages reviewed here.
The cached-JUnit evidence gap encountered by the reviewer was resolved by a
separately authorized actual uncached run; original cached evidence remains
intact. This recommendation is limited to Root integration of the exact reviewed
correction. It is not normal native/client proof, ledger delivery or v1.8 Gate
approval.

## Exact scope and identity

The reviewer did not author these corrective postimages. All source/repository,
author evidence, central wiring and Git state remained read-only. Root remains
sole integrator and acceptance authority.

- Fixed execution Git base: `9fce551ea9389ce37a94f804aa0e817399586a7e`.
- Execution worktree: `D:/GitHub/arce-v180-c18a-analyzer-fix-20261005`.
- [Pinned GT preimage](BASE-9fce-AtmosphereAnalyzerGameTests.java): 29,847 B,
  SHA-256 `54e6ff5aae95f760260229fcbe2b8c830336726cea1ed75528fd23e87909ce21`.
- [Reviewed GT postimage](INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java):
  39,660 B, 541 lines, SHA-256
  `275947498de7b42a18f142616258c75400bedd7ed8d0a8f1d5b608d106b229c3`.
  Its filename preserves the first intermediate-intake chronology; final author
  handoff and both independent jobs subsequently confirmed these exact bytes.
- [Exact source patch](SOURCE-FIX-01.patch): 25,184 B, SHA-256
  `87a711965b8d77a3722859584f1678b269cbaf6b0c945d64b4580afdfa6f8d3e`.
  [Pure Python replay](PATCH-MODEL-07.json) verifies all 15 hunk contexts,
  deletions/counts and the exact final postimage. This is not a claim of a reviewer
  Git application in Root.
- [Three owned paths](OWNED-FILES-01.json), SHA-256
  `84e31d5d80ad52a309102317e8ac488bd2769d1fc41fd478cbb840db5a73c497`,
  comprise only the GT file, [FIX-HANDOFF-01](FIX-HANDOFF-01.md)
  (`596fc290fc8576a1085655f7c773473bdafee88cbbb5a8bb855e3b0268bf0ba8`)
  and [FIX-PROGRESS-01](FIX-PROGRESS-01.md)
  (`590c1899b56bddbc5a9272d71c2d64234af0e8e059ba7964fc7f29f90d9816d8`).

Author sealed evidence is
`D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b`.
Its `INTERNAL-MANIFEST-01.json` SHA-256 is
`eb49744fa37f02caa7c03ba4bea1f3a755e9d6b5697bc5f500ae4c2708579b74`.
[Final intake](FINAL-INTAKE-08.json) independently verifies every one of its
102 payloads / 24,249,421 B, all three WT postimages and author XML case counts;
no mismatch was observed. It does not copy the whole author packet or official
class bodies into this review.

### Execution cohort and governance qualification

Actual WT `git ls-files src` plus the named Gradle/build paths contain **2,835**
inputs, not Root's broader 3,036-input Source26 observation. Both independent
commands checked these actual WT inputs against author manifest
`full-06-SOURCE-MANIFEST.json`, SHA-256
`58424c10a6793b1f2e8b1364d61b9a362b48a183967027ea7aad3ee830db6f65`.
[Fixed-object control](FIXED-BASELINE-CONTROL-06.json) qualifies the only raw-Git
byte difference besides the GT: fixed `.gitattributes` requires `gradlew.bat`
CRLF, exactly explaining all 92 LF-to-CRLF pairs (Git 2,776 B / `18774a0a...`,
WT 2,868 B / `8e327fcb...`). The other 2,833 files equal fixed Git objects;
this is not a general normalization waiver or an author wrapper edit.

[Governance qualification](GOVERNANCE-QUALIFICATION-01.json) records the
effective live Root AGENTS separately: 12,047 B /
`1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`.
The WT's old Git checkout is 8,379 B /
`725dd46344046bcdb802872e08fbc3cd9dabf876e680eeba4c82dda801a9503`;
it does not override newer Root/user rules. Mandatory project/version/test/
quality/parallel documents and adjacent production query/lifecycle/vent/index
sources are individually pinned in [intake](INTAKE-01.json).

## Actual source assessment

All line references below identify the exact reviewed GT postimage.

1. **Registry and disabled/unavailable evidence, lines 72–95 and 129–154.**
   The MOD listener returns before either supplier construction unless dedicated
   distribution, actual non-production dedicated GameTest-server gate and ITEMS
   key all agree. Both items are supplier-created only under two exact stable
   `gametest_analyzer_*` IDs. Lookup has no fallback. The counter contains no
   world/player/resource reference and is reset before/finally. Original 0/1
   callback counts, chat/cooldown, malformed stack and detached-player assertions
   are unchanged. A 32-combination control derives two admitting rows differing
   only in the irrelevant generic GameTest-enable flag; generic enable alone
   cannot admit fixture registration. Relevant Forge primary facts are pinned by
   the preceding independent technical review (`b55893b98cab63ab5502f57c6763da687a617e827f792748f8a506c10f2efe70`),
   not replaced by this author proposal.

2. **Controlled unloaded-eye evidence, lines 339–382 and 431–438.**
   The copied forced-mark set is independent, bounded at 4,096, and compared before
   and after the query. Detachment precedes far coordinate placement; actual
   connected identity, exact eye, loaded count and null target are established
   before query. Native `onMove` is retained, so an indirect setup load fails
   admission rather than being ignored. Nested finally restores coordinates while
   detached and restores attachment before ordinary PlayerList removal. The
   source and passing actual case establish this controlled-coordinate scenario,
   not naturally occurring client movement. Equality covers the vanilla forced
   mark set, not every internal ticket type.

3. **Room producer/publication and ownership, lines 197–287 and 465–525.**
   FULL chunks are obtained before fixture writes; the geometry spans at most four
   chunks for either radius. Only newly added force marks are later removed, so
   pre-existing marks are preserved. Shell writes are bounded at 27/729 blocks;
   the large room retains 343 traversable cells versus the immutable 256-task
   inspection budget. Each readiness attempt explicitly runs the existing vent
   producer, then captures balances/inspection count and performs the read-only
   runtime query. It does not call a Root-manager tick, replace the installed
   runtime, or post synthetic lifecycle/tick events. Adjacent production
   `OxygenVentBlockEntity.serverTick` observes through AtmosphereRuntime and the
   existing `AtmosphereServerEvents` publishes on ordinary ServerTick END.
   Only after Root's actual required state/supplied flag appears does the isolated
   manager receive its original one explicit setup/supply tick. Every original
   reading, ambient, feet/eye, query/resource, native-use and dirty-wall assertion
   remains. Readiness fails/cleans at tick 39 within unchanged 40-tick tests;
   success follows cleanup. Cleanup closes only the local service/manager, removes
   the owned player, clears the bounded room (production block removal removes
   the Root vent) and releases only newly added marks, with nested finally.

4. **Assertion and scope retention.**
   [Condition extraction](SOURCE-CONTROLS-02.json) identifies all 44 original
   `assertTrue` first arguments: 41 exact, two equivalent captured read variables,
   one original loaded/null/notforced conjunction strengthened by whole-set
   equality. Final source has 52 assertions. All ten case identities, templates,
   batch names and 40-tick deadlines are retained; no old test or control is
   removed. [Source-bound controls](scope_controls03.log) exercise these exact
   source requirements. The 541-line class is ten test fixtures plus focused
   test-only registration/setup/readiness/assertion/cleanup helpers, not a new
   production framework. Production services/config, recipes, assets, registries,
   API, schemas, budgets and central wiring are untouched by this correction.

## Actual independent commands and results

All new helpers/output/process TEMP/TMP/TMPDIR and Java temp are under this own
D-parent evidence leaf. No C-drive helper was created in this task; no global
environment change, deletion, source/world export, Git mutation, normal native
server or client launch occurred.

- `python -B intake01.py`: exit 0; selected contextual input pins plus distinct
  diagnostic identities. Early wrong path/wildcard reads remain described in
  [tooling chronology](INTAKE-FAILURES-01.md).
- `python -B source_controls02.py`: exit 0, five parser/guard/bounds/snapshot/
  deadline controls. `python -B scope_controls03.py`: exit 0, seven exact-source
  controls, including 512 room chunk geometry combinations. These are bounded
  source/model observations, not independently executed Java behaviors.
- `python -B fixed_baseline05.py`: exit 1, initial raw-Git-versus-checkout
  expectation. Original result retained; separate `fixed_baseline06.py`: exit 0,
  exact specific CRLF and actual 2,835-input qualification.
- `python -B patch_model07.py`: exit 0, exact 15-hunk postimage replay.
- `python -B final_intake08.py`: exit 0, all 102 sealed author payloads and three
  actual owned WT postimages verified.
- **Independent04**, [command](INDEPENDENT-04-COMMAND.json),
  [raw log](INDEPENDENT-04.log), [result](INDEPENDENT-04-RESULT.json):
  `--offline --no-daemon --max-workers=2` / Java 17 / 2-GiB heap,
  `cleanTest compileJava compileTestJava test` with five exact class filters,
  followed by unfiltered `runGameTestServer` in the same command.
  Start `2026-10-04T19:35:59.989292Z`, end `19:39:56.520299Z`, **exit 0 /
  236.009056 s**. Precheck C 10,079,768,576 B / D 337,755,578,368 B.
  Compiler tasks are UP-TO-DATE. `:test FROM-CACHE` restored 19-case XML and
  **is not independent new JUnit execution**. The new actual unfiltered GT host
  completed **all 477 required tests**, including ten analyzer cases. The
  [native GameTest log](INDEPENDENT-04-latest.log), lines 2176–2177, records actual
  Root PENDING and supplied/BREATHABLE readiness at tick 1; line 5509 states
  all 477 required tests passed. The log retains **61 ERROR headers**; this is
  not a blanket clean-log or global waiver claim. No input drift was observed.
- **Independent10**, [command](INDEPENDENT-10-COMMAND.json),
  [raw log](INDEPENDENT-10.log), [result](INDEPENDENT-10-RESULT.json): separately
  authorized serial `--no-build-cache cleanTest compileJava compileTestJava test`
  with the same five real classes, all other controls unchanged. Start
  `2026-10-04T19:41:52.329043Z`, end `19:42:13.729448Z`, **exit 0 /
  21.400400 s**. Precheck C 10,075,865,088 B / D 337,747,836,928 B.
  **Real JUnit execution: 19 tests / five suites / zero failures, errors or skips**.
  All 19 XML cases are parsed; compiler tasks remain explicitly UP-TO-DATE.
  [Separate raw-line qualification](EXECUTION-QUALIFICATION-11.json) corrects the
  collector's newline-crossing task-status field without rewriting the original
  result/helper. It verifies exact `> Task :test`, uncached execution and five
  different freshly executed XML identities versus cached Independent04.
- `python -B final_postcheck12.py`: exit 0; all 102 author payloads, all three
  WT owned postimages and all selected contextual pins remained unchanged.
  Both independent jobs separately verified every one of the 2,835 actual WT
  inputs before/after and the unchanged fixed execution HEAD.

Both Java jobs are terminal and their slot was released; no additional Java job
is started by report sealing. Mutable WT build/GameTest outputs are excluded from
this evidence manifest and were only used through Root-authorized Gradle tasks;
no previously refused cleanup target was deleted or retried.

## Preserved negative history and remaining boundaries

Root Source26's original 477/four-required-failure observation and author
Diagnostic01/02/03 (each 477/the same four failures) remain distinct pinned
inputs. None was rewritten or attributed universally to a single cause. Author
Scoped04's guessed selectors actually ran only seven tests/two suites;
Scoped05 actually ran nineteen/five. Full06's 477 pass is an author result,
separate from the new independent477 pass here. Initial metadata guessed-version
locator failure and all reviewer path/EOL/cache/collector mistakes remain raw or
explicitly qualified. This review does not erase or reinterpret earlier native
failures from other leaves.

Normal production/unflagged profile exclusion is primary/source-backed only;
those profiles were not newly launched. Fixture IDs may enter disposable
GameTest registry snapshots/playerdata; this is **not** a no-save-impact claim,
and those worlds must not become normal gameplay/native worlds. The connected
non-FakePlayer mock drives actual native Item.use but is not a real client or
V1/V2 proof. No native gameplay analyzer/restart/cohort, Root full clean build /
DataGen / packaged-artifact regression, or whole-version Required Gate is proved
by this correction review. Root must integrate/commit exact bytes and perform
its separately assigned current-cohort verification; remaining current-version
native/client and delivery obligations stay open.
