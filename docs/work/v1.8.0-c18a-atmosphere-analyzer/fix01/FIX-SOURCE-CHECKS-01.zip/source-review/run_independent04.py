from pathlib import Path
import os, sys, json, hashlib, shutil, subprocess, time, datetime
import xml.etree.ElementTree as ET
import re

HERE=Path(__file__).resolve().parent
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
BASE='9fce551ea9389ce37a94f804aa0e817399586a7e'
GT='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
EXPECTED='275947498de7b42a18f142616258c75400bedd7ed8d0a8f1d5b608d106b229c3'

def sha(b): return hashlib.sha256(b).hexdigest()
def write(n,x): (HERE/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def snapshot(names):
    result={}
    for name in names:
        if 'AdvancedRocketry-Community-v1plus-Development-Docs' in name or Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('forbidden manifest input')
        data=(WT/name).read_bytes()
        result[name]={'bytes':len(data),'sha256':sha(data)}
    return result

manifest=Path(sys.argv[1])
original=json.loads(manifest.read_text(encoding='utf-8'))
assert original['base']==BASE
expected=original['inputs']
before=snapshot(expected)
head=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
disk={d:shutil.disk_usage(d+':/').free for d in ('C','D')}
pre={'head':head,'fixed_base':BASE,'author_manifest':str(manifest),'author_manifest_sha256':sha(manifest.read_bytes()),
     'source_count':len(before),'source_mismatches':[p for p in expected if expected[p]!=before[p]],
     'gt_sha256':before[GT]['sha256'],'free_bytes':disk,'threshold_bytes':10_000_000_000}
write('INDEPENDENT-04-PRECHECK.json',pre)
write('INDEPENDENT-04-SOURCE-MANIFEST.json',{'base':BASE,'inputs':before})
assert head==BASE and pre['gt_sha256']==EXPECTED and not pre['source_mismatches']
assert all(n>=10_000_000_000 for n in disk.values()),'disk launch threshold failed; no Java launched'

temp=HERE/'process-temp';temp.mkdir(exist_ok=True)
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Java/jdk-17.0.7'
env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
for key in ('TEMP','TMP','TMPDIR'):env[key]=str(temp)
env['JAVA_TOOL_OPTIONS']='-Djava.io.tmpdir='+temp.as_posix()
selectors=[
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AnalyzerReadingTest',
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerFeedbackTest',
 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerServiceTest',
 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerLanguageTest',
 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerDataTest']
cmd=[str(WT/'gradlew.bat'),'--offline','--no-daemon','--max-workers=2',
     '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir='+temp.as_posix(),
     'cleanTest','compileJava','compileTestJava','test']
for selector in selectors:cmd+=['--tests',selector]
cmd+=['runGameTestServer']
start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(); wall=time.time()
write('INDEPENDENT-04-COMMAND.json',{'command':cmd,'cwd':str(WT),'started_utc':start_utc,
 'JAVA_HOME':env['JAVA_HOME'],'JAVA_TOOL_OPTIONS':env['JAVA_TOOL_OPTIONS'],'TEMP_TMP_TMPDIR':str(temp),
 'scope':'Root-authorized independent scoped JUnit + unfiltered registered GameTest; no normal native/client',
 'cleanTest':'Root separately authorized for fresh ordinary test output, not deletion bypass'})
print('START '+start_utc+' source='+EXPECTED,flush=True)
start=time.monotonic()
with (HERE/'INDEPENDENT-04.log').open('wb') as log:
    done=subprocess.run(cmd,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-start
after=snapshot(expected)
changed=[p for p in before if before[p]!=after[p]]
write('INDEPENDENT-04-POSTCHECK.json',{'source_count':len(after),'changed':changed,
    'head':subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip(),
    'free_bytes':{d:shutil.disk_usage(d+':/').free for d in ('C','D')}})
result={'exit':done.returncode,'started_utc':start_utc,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds':elapsed,'source_changed':changed,'junit':{},'gametest':{}}
target=HERE/'independent04-xml';target.mkdir(exist_ok=True)
suites=[]
for path in sorted((WT/'build/test-results/test').glob('TEST-*.xml')):
    raw=path.read_bytes(); (target/path.name).write_bytes(raw)
    root=ET.fromstring(raw);cases=root.findall('testcase')
    suites.append({'name':root.get('name'),'tests':int(root.get('tests')),
         'failures':int(root.get('failures')),'errors':int(root.get('errors')),'skipped':int(root.get('skipped')),
         'actual_cases':len(cases),'actual_failures':sum(c.find('failure') is not None for c in cases),
         'actual_errors':sum(c.find('error') is not None for c in cases),
         'fresh_after_launch':path.stat().st_mtime>=wall,'sha256':sha(raw)})
result['junit']={'suites':len(suites),**{k:sum(s[k] for s in suites) for k in ('tests','failures','errors','skipped','actual_cases','actual_failures','actual_errors')},'rows':suites}
for name in ('latest.log','debug.log'):
    p=WT/'build/gametest/logs'/name
    if p.is_file():shutil.copyfile(p,HERE/('INDEPENDENT-04-'+name))
latest=HERE/'INDEPENDENT-04-latest.log'
if latest.is_file():
    lines=latest.read_text(encoding='utf-8').splitlines()
    passage=[{'line':i+1,'text':line} for i,line in enumerate(lines) if 'All ' in line and 'required tests passed' in line
             or 'required tests failed' in line or 'tests are now completed' in line or 'ARCE_ANALYZER_FIX_READY' in line]
    counts=[int(m.group(1)) for line in lines if (m:=re.search(r'All (\d+) required tests passed',line))]
    result['gametest']={'observed_required_pass_counts':counts,'error_lines':sum('/ERROR]' in l for l in lines),'selected':passage}
write('INDEPENDENT-04-RESULT.json',result)
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(done.returncode if not changed else 2)
