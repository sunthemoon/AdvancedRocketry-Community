from pathlib import Path
import json, hashlib, subprocess

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
before=json.loads((HERE/'INTAKE-01.json').read_text(encoding='utf-8'))
records=[]
for row in before['inputs']:
    if 'sha256' not in row:continue
    p=Path(row['path']);b=p.read_bytes()
    records.append({'path':str(p),'role':row['role'],'before_sha256':row['sha256'],
                    'now_sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'changed':hashlib.sha256(b).hexdigest()!=row['sha256']})
mp=AUTHOR/'INTERNAL-MANIFEST-01.json';manifest=json.loads(mp.read_text(encoding='utf-8'))
author_changed=[]
for row in manifest['files']:
    b=(AUTHOR/row['path']).read_bytes()
    if (len(b),hashlib.sha256(b).hexdigest())!=(row['bytes'],row['sha256']):author_changed.append(row['path'])
owned=json.loads((AUTHOR/'OWNED-FILES-01.json').read_text(encoding='utf-8'))
owned_changed=[]
for row in owned['files']:
    b=(WT/row['repository_path']).read_bytes()
    if (len(b),hashlib.sha256(b).hexdigest())!=(row['bytes'],row['sha256']):owned_changed.append(row['repository_path'])
result={'selected_context_records':records,'changed_selected_context':[r['path'] for r in records if r['changed']],
        'author_payloads':len(manifest['files']),'author_payload_changed':author_changed,'all_three_owned_changed':owned_changed,
        'fixed_execution_head':subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip(),
        'root_live_head_context_only':subprocess.check_output(['git','-C','D:/GitHub/AdvancedRocketry-Community','rev-parse','HEAD'],text=True).strip(),
        'execution_cohort':'Independent04 and independent10 separately checked all actual 2835 named WT inputs; Root broader 3036 not substituted'}
(HERE/'FINAL-POSTCHECK-12.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'selected_context_changes':result['changed_selected_context'],'author_payload_changes':author_changed,'owned_changes':owned_changed,'execution_head':result['fixed_execution_head']}))
assert not author_changed and not owned_changed
