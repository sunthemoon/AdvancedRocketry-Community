from pathlib import Path
import hashlib, re, json

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
patch=(AUTHOR/'SOURCE-FIX-01.patch').read_bytes()
pre=(HERE/'BASE-9fce-AtmosphereAnalyzerGameTests.java').read_bytes()
expected=(AUTHOR/'FINAL-AtmosphereAnalyzerGameTests.java').read_bytes()
old=pre.decode('utf-8').splitlines(keepends=True)
lines=patch.decode('utf-8').splitlines(keepends=True)
out=[]; cursor=0; i=0; hunks=[]
assert sum(line.startswith('diff --git ') for line in lines)==1
while i<len(lines):
    match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i])
    if not match: i+=1; continue
    start=int(match[1])-1; old_count=int(match[2] or 1); new_count=int(match[4] or 1)
    assert start>=cursor
    out.extend(old[cursor:start]); cursor=start; consumed=0; emitted=0; i+=1
    while i<len(lines) and not lines[i].startswith('@@ '):
        line=lines[i]
        if line.startswith(' '):
            assert old[cursor]==line[1:]
            out.append(line[1:]);cursor+=1;consumed+=1;emitted+=1
        elif line.startswith('-'):
            assert old[cursor]==line[1:]
            cursor+=1;consumed+=1
        elif line.startswith('+'):
            out.append(line[1:]);emitted+=1
        else: raise ValueError('unexpected hunk content '+repr(line[:80]))
        i+=1
    assert (consumed,emitted)==(old_count,new_count)
    hunks.append({'pre_start_line':start+1,'pre_lines':consumed,'post_lines':emitted})
out.extend(old[cursor:]); actual=''.join(out).encode('utf-8')
assert actual==expected==(HERE/'INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java').read_bytes()
result={'method':'Pure Python unified-text replay with exact context/deletion/count checks; no git apply or source writes',
 'patch_sha256':hashlib.sha256(patch).hexdigest(),'patch_bytes':len(patch),
 'preimage_sha256':hashlib.sha256(pre).hexdigest(),'postimage_sha256':hashlib.sha256(actual).hexdigest(),
 'postimage_bytes':len(actual),'hunks':hunks,'exact_postimage':True}
(HERE/'PATCH-MODEL-07.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'hunks':len(hunks),'exact_postimage':True,'postimage_sha256':result['postimage_sha256']}))
