from pathlib import Path
import hashlib, json, xml.etree.ElementTree as ET, shutil

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-author-ea8349712b')
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
mp=AUTHOR/'INTERNAL-MANIFEST-01.json'
assert hashlib.sha256(mp.read_bytes()).hexdigest()=='eb49744fa37f02caa7c03ba4bea1f3a755e9d6b5697bc5f500ae4c2708579b74'
manifest=json.loads(mp.read_text(encoding='utf-8'))
mismatches=[];total=0
for row in manifest['files']:
    name=row['path']; assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert 'process-temp' not in name and 'Development-Docs' not in name
    raw=(AUTHOR/name).read_bytes();total+=len(raw)
    if (len(raw),hashlib.sha256(raw).hexdigest())!=(row['bytes'],row['sha256']):mismatches.append(name)
assert not mismatches
owned=json.loads((AUTHOR/'OWNED-FILES-01.json').read_text(encoding='utf-8'))
post=[]
for row in owned['files']:
    payload=(AUTHOR/row['evidence_path']).read_bytes();actual=(WT/row['repository_path']).read_bytes()
    assert payload==actual and len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
    post.append(row)
assert len(post)==3
author_xml=[]
for p in sorted((AUTHOR/'scoped-05-xml').glob('TEST-*.xml')):
    root=ET.fromstring(p.read_bytes());cases=root.findall('testcase')
    author_xml.append({'name':root.get('name'),'tests':int(root.get('tests')),'failures':int(root.get('failures')),
                       'errors':int(root.get('errors')),'skipped':int(root.get('skipped')),'actual_cases':len(cases),
                       'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(author_xml)==5 and sum(x['tests'] for x in author_xml)==19 and sum(x['actual_cases'] for x in author_xml)==19
for name in ('SOURCE-FIX-01.patch','OWNED-FILES-01.json','FIX-HANDOFF-01.md','FIX-PROGRESS-01.md'):
    target=HERE/name; assert not target.exists();shutil.copyfile(AUTHOR/name,target)
result={'author_manifest':str(mp),'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),
        'verified_payloads':len(manifest['files']),'payload_bytes':total,'mismatches':mismatches,
        'actual_owned_postimages':post,'author_scoped05_xml':author_xml,
        'handoff':'Author explicitly released all Java and transferred ordinary mutable build/GameTest outputs; external evidence/source/docs frozen',
        'no_official_body_export':'All packet entries verified read-only; selected official primary fact files were not copied into reviewer evidence',
        'independent_execution':'not yet launched by this intake script'}
(HERE/'FINAL-INTAKE-08.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'payloads':len(manifest['files']),'bytes':total,'mismatch':mismatches,'owned':len(post),'author_tests':19}))
