from pathlib import Path
import json, re, collections, hashlib, itertools, unittest

HERE=Path(__file__).resolve().parent

def code_mask(text):
    out=list(text); i=0
    while i<len(text):
        if text.startswith('//',i):
            j=text.find('\n',i); j=len(text) if j<0 else j
            for k in range(i,j): out[k]=' '
            i=j
        elif text.startswith('/*',i):
            j=text.find('*/',i+2); j=len(text)-2 if j<0 else j
            for k in range(i,j+2): out[k]='\n' if text[k]=='\n' else ' '
            i=j+2
        elif text[i] in ('"',"'"):
            quote=text[i]; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==quote: i+=1; break
                i+=1
        else: i+=1
    return ''.join(out)

def matching(text, start, opened='(', closed=')'):
    depth=0; i=start
    while i<len(text):
        c=text[i]
        if c in ('"',"'"):
            q=c; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==q: break
                i+=1
        elif c==opened: depth+=1
        elif c==closed:
            depth-=1
            if depth==0: return i
        i+=1
    raise ValueError('unbalanced at '+str(start))

def args(text, start):
    end=matching(text,start); part=text[start+1:end]
    i=0; depth=0
    while i<len(part):
        c=part[i]
        if c in ('"',"'"):
            q=c; i+=1
            while i<len(part):
                if part[i]=='\\': i+=2; continue
                if part[i]==q: break
                i+=1
        elif c in '([{': depth+=1
        elif c in ')]}': depth-=1
        elif c==',' and depth==0: return part[:i],part[i+1:]
        i+=1
    return part,''

def assertions(text):
    cleaned=code_mask(text); out=[]
    for m in re.finditer(r'helper\.assertTrue\s*\(',cleaned):
        first,_=args(cleaned,cleaned.index('(',m.start()))
        out.append({'line':cleaned[:m.start()].count('\n')+1,
                    'condition':re.sub(r'\s+','',first)})
    return out

def analyze(old,new):
    a,b=assertions(old),assertions(new)
    left=collections.Counter(x['condition'] for x in a)
    right=collections.Counter(x['condition'] for x in b)
    missing=list((left-right).elements())
    added=list((right-left).elements())
    return {'original_assertions':len(a),'candidate_assertions':len(b),
            'exact_original_conditions_retained':len(a)-len(missing),
            'unmatched_original_conditions':missing,'new_conditions':added,
            'cases':re.findall(r'@GameTest\([^)]*\)\s*public static void (\w+)',new),
            'timeouts':re.findall(r'@GameTest\([^)]*timeoutTicks\s*=\s*(\d+)',new),
            'candidate_assertions_with_lines':b}

class BoundedControls(unittest.TestCase):
    def test_parser_keeps_nested_commas_strings_and_comments(self):
        t='// helper.assertTrue(false,"x");\nhelper.assertTrue(f(a,b)&&s.equals("a,b"), "diagnostic");'
        self.assertEqual([x['condition'] for x in assertions(t)],['f(a,b)&&s.equals("a,b")'])
    def test_registry_combinations(self):
        admitted=[]
        for production,dedicated,serverflag,genericflag,itemkey in itertools.product((False,True),repeat=5):
            gate=dedicated and not production and serverflag and itemkey
            if gate: admitted.append((production,dedicated,serverflag,genericflag,itemkey))
        self.assertEqual(len(admitted),2)
        self.assertTrue(all(x[0:3]==(False,True,True) and x[4] for x in admitted))
    def test_room_chunk_bounds_and_owned_release(self):
        for center in range(-32,33):
            for radius in (1,4):
                chunks=set(itertools.product(range((center-radius)>>4,((center+radius)>>4)+1),repeat=2))
                self.assertLessEqual(len(chunks),4)
                for existing in (set(),set(chunks),set(list(chunks)[:1])):
                    added=chunks-existing
                    after=(existing|chunks)-added
                    self.assertEqual(after,existing)
    def test_forced_snapshot_independent_and_bounded(self):
        native={1,2}; snapshot=frozenset(native); native.add(3)
        self.assertNotEqual(native,snapshot)
        self.assertTrue(len(set(range(4096)))<=4096)
        self.assertFalse(len(set(range(4097)))<=4096)
    def test_readiness_deadline_has_no_extension(self):
        checks=[]
        for tick in range(40):
            if tick>=39: checks.append(('refusal',tick)); break
            checks.append(('wait',tick))
        self.assertEqual(checks[-1],('refusal',39))

if __name__=='__main__':
    old=(HERE/'BASE-9fce-AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
    new=(HERE/'INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
    result=analyze(old,new)
    result['phase']='intermediate-only source analysis; no final admission'
    (HERE/'SOURCE-CONTROLS-02.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('original_assertions','candidate_assertions','exact_original_conditions_retained','unmatched_original_conditions','timeouts')}))
    unittest.main()
