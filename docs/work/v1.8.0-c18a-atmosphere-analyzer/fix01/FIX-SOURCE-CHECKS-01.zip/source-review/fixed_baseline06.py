from pathlib import Path
import hashlib, json, subprocess

HERE=Path(__file__).resolve().parent
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
BASE='9fce551ea9389ce37a94f804aa0e817399586a7e'
first=json.loads((HERE/'FIXED-BASELINE-CONTROL-05.json').read_text(encoding='utf-8'))
raw=subprocess.check_output(['git','-C',str(WT),'show',BASE+':gradlew.bat'])
actual=(WT/'gradlew.bat').read_bytes()
attrs=subprocess.check_output(['git','-C',str(WT),'show',BASE+':.gitattributes'])
attr_observation=subprocess.check_output(['git','-C',str(WT),'check-attr','text','eol','--','gradlew.bat'],text=True)
assert b'gradlew.bat text eol=crlf' in attrs
assert actual==raw.replace(b'\n',b'\r\n') and b'\r' not in raw
diffs=first['different_from_fixed_objects']
assert len(diffs)==2 and diffs[0]['path']=='gradlew.bat' and diffs[1]['path'].endswith('/AtmosphereAnalyzerGameTests.java')
assert not first['wt_different_from_named_manifest']
result={'fixed_base':BASE,'actual_named_src_build_inputs':first['git_blob_count'],
 'first_attempt':'fixed_baseline05.py exit 1 retained; raw Git LF blob comparison initially expected one difference',
 'wrapper_native_checkout':{'raw_git_sha256':hashlib.sha256(raw).hexdigest(),'raw_git_bytes':len(raw),
      'wt_sha256':hashlib.sha256(actual).hexdigest(),'wt_bytes':len(actual),'CRLF_pairs':actual.count(b'\r\n'),
      'fixed_gitattributes_sha256':hashlib.sha256(attrs).hexdigest(),'actual_git_check_attr':attr_observation},
 'qualification':'2835 is the actual author src/build cohort, not Root broader source26 3036. Raw Git blob LF and mandatory CRLF checkout are distinct pinned bytes; no author wrapper edit inferred.',
 'only_logical_source_delta':diffs[1],'remaining_inputs':'2833 other src/build files byte-equal fixed Git objects; wrapper follows fixed .gitattributes; all 2835 actual WT files match author full06 manifest',
 'private_directory_read':False}
(HERE/'FIXED-BASELINE-CONTROL-06.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'actual_src_build_inputs':first['git_blob_count'],'wrapper_required_CRLF_verified':True,'GT_only_logical_delta':True}))
