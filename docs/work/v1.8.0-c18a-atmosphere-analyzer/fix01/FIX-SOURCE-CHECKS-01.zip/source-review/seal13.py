from pathlib import Path
import hashlib, json, re, datetime

HERE=Path(__file__).resolve().parent
report=HERE/'REVIEW-01.md'
links=[]
for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',report.read_text(encoding='utf-8')):
    if '://' in link or link.startswith('#'): continue
    target=HERE/link.split('#',1)[0]
    links.append({'link':link,'exists':target.is_file()})
assert all(x['exists'] for x in links)
check={'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'report_links':links,
       'missing_links':[],'actual_source':hashlib.sha256((HERE/'INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java').read_bytes()).hexdigest(),
       'Java_jobs':'both terminal/released; sealing is Python-only',
       'authority':'reviewer source recommendation only; Root integration/Gates remain separate'}
(HERE/'SEAL-CHECK-13.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf-8')
exclude={'INTERNAL-MANIFEST-01.json','SHA256SUMS.txt','seal13.log','seal13.exit'}
files=[]
for p in sorted(HERE.rglob('*')):
    if not p.is_file() or p.name in exclude or any(part.startswith('process-temp') or part=='__pycache__' for part in p.relative_to(HERE).parts):continue
    b=p.read_bytes();files.append({'path':p.relative_to(HERE).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'format':1,'scope':'Independent exact one-GT-source correction review; selected source/model controls, raw actual independent jobs, original failures and qualification corrections',
          'excluded':'Mutable transferred WT build/runtime and own process-temp; no whole source/JAR/world export or official class body',
          'files':files,'payload_count':len(files),'payload_bytes':sum(x['bytes'] for x in files)}
mp=HERE/'INTERNAL-MANIFEST-01.json';assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
lines=[x['sha256']+'  '+x['path'] for x in files]+[hashlib.sha256(mp.read_bytes()).hexdigest()+'  INTERNAL-MANIFEST-01.json']
(HERE/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='ascii')
for row in files:
    b=(HERE/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'payload_count':len(files),'payload_bytes':manifest['payload_bytes'],
 'report_sha256':check['report_sha256'],'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),
 'SHA256SUMS_sha256':hashlib.sha256((HERE/'SHA256SUMS.txt').read_bytes()).hexdigest(),
 'report_links':len(links),'missing':0,'all_payload_mismatches':0}))
