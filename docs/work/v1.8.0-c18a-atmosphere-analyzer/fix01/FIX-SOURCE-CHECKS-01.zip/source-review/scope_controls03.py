from pathlib import Path
import json, re, unittest, itertools, hashlib
from source_controls02 import code_mask, matching, analyze

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'INTERMEDIATE-01-AtmosphereAnalyzerGameTests.java'
TEXT=SOURCE.read_text(encoding='utf-8')
CLEAN=code_mask(TEXT)

def method(name):
    m=re.search(r'\b'+re.escape(name)+r'\s*\([^;{}]*\)\s*\{', CLEAN)
    if not m: raise ValueError('method absent: '+name)
    start=CLEAN.index('{',m.start())
    return CLEAN[start+1:matching(CLEAN,start,'{','}')]

class SourceBoundControls(unittest.TestCase):
    def test_exact_case_identity_and_unchanged_limits(self):
        old=(HERE/'BASE-9fce-AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
        names=lambda t:re.findall(r'@GameTest\([^)]*\)\s*public static void (\w+)',t)
        self.assertEqual(names(old),names(TEXT))
        self.assertEqual(len(names(TEXT)),10)
        self.assertEqual(re.findall(r'timeoutTicks\s*=\s*(\d+)',TEXT),['40']*10)
        self.assertNotIn('MAX_TASK_INSPECTIONS_PER_TICK =',TEXT)
    def test_registry_guard_precedes_two_supplier_only_constructions(self):
        b=method('onRegisterItems')
        guard=b.index('return;')
        constructions=[m.start() for m in re.finditer(r'new AtmosphereAnalyzerItem\(',b)]
        self.assertEqual(len(constructions),2)
        self.assertTrue(all(i>guard for i in constructions))
        self.assertEqual(CLEAN.count('new AtmosphereAnalyzerItem('),2)
        self.assertIn('FMLEnvironment.dist != Dist.DEDICATED_SERVER',b[:guard])
        self.assertIn('!ForgeGameTestHooks.isGametestServer()',b[:guard])
        self.assertIn('!event.getRegistryKey().equals(ForgeRegistries.Keys.ITEMS)',b[:guard])
        self.assertEqual(b.count('() -> new AtmosphereAnalyzerItem'),2)
        self.assertNotIn('forge.enableGameTest',b)
    def test_injected_query_assertions_and_finally_are_retained(self):
        b=method('disabledUnavailableAndInvalidUsesDoNotQueryOrMutate')
        self.assertIn('AtomicInteger queries = FIXTURE_QUERIES;',b)
        self.assertIn('queries.set(0);',b[:b.index('try {')])
        self.assertIn('finally { queries.set(0); remove(helper, player); }',b)
        self.assertEqual(b.count('queries.get() == 0'),1)
        self.assertEqual(b.count('queries.get() == 1'),3)
        self.assertIn('new ItemStack(unavailable, 2)',b)
        self.assertIn('new ServerPlayer(',b)
    def test_controlled_coordinates_admission_and_whole_set_guards(self):
        b=method('unloadedEyeRefusesWithoutCreatingTicketsOrAtmosphereService')
        self.assertIn('Set<Long> forcedBefore = Set.copyOf(level.getForcedChunks())',b)
        self.assertEqual(b.count('level.getForcedChunks().size() <= 4096'),3)
        self.assertEqual(b.count('forcedBefore.equals(level.getForcedChunks())'),2)
        self.assertLess(b.index('player.onRemovedFromWorld()'),b.index('player.setPos(far'))
        self.assertLess(b.index('Movement setup loaded'),b.index('var reading = service.read(player)'))
        self.assertIn('try { player.setPos(original); } finally { player.onAddedToWorld(); }',b)
        self.assertIn('finally { service.close(); manager.clear(); remove(helper, player); }',b)
        admission=method('assertConnected')
        for field in ('player.connection != null','!player.isRemoved()', '!player.hasDisconnected()',
                      'player.isAlive()', '!player.isSpectator()', 'server.getPlayerList().getPlayer(player.getUUID()) == player',
                      'player.serverLevel() == level', 'server.getLevel(level.dimension()) == level'):
            self.assertIn(field,admission)
    def test_readiness_is_nonmutating_query_inside_original_deadline(self):
        b=method('awaitRuntimeFixture')
        self.assertIn('helper.onEachTick',b)
        self.assertIn('helper.getTick() < 39',b)
        self.assertEqual(b.count('AtmosphereAnalyzerRuntime.read(player)'),1)
        before=b.index('int energy = vent.energyStored()')
        after=b.index('if (actual.state()')
        query=b[before:after]
        self.assertNotRegex(query,r'\.tick\(|serverTick\(')
        self.assertIn('totalInspections() == inspections',query)
        self.assertIn('vent.energyStored() == energy && vent.oxygenUnits() == oxygen',query)
        self.assertIn('OxygenVentBlockEntity.serverTick(',b[:before])
        self.assertNotIn('post(',b)
        self.assertNotIn('install(',CLEAN)
    def test_cleanup_and_room_geometry_bounds(self):
        cleanup=method('cleanRoomFixture')
        self.assertIn('service.close(); manager.clear();',cleanup)
        self.assertIn('try { remove(helper, player); }',cleanup)
        self.assertIn('finally { try { clearRoom(',cleanup)
        self.assertIn('finally { releaseRoomChunks(level, forced); }',cleanup)
        prepare=method('prepareRoomChunks')
        self.assertIn('if (!level.getForcedChunks().contains(chunk.toLong()))',prepare)
        self.assertIn('added.add(chunk)',prepare)
        self.assertNotIn('setChunkForced',method('unloadedEyeRefusesWithoutCreatingTicketsOrAtmosphereService'))
        for cx,cz,radius in itertools.product(range(16),range(16),(1,4)):
            chunks=set(itertools.product(range((cx-radius)>>4,((cx+radius)>>4)+1),range((cz-radius)>>4,((cz+radius)>>4)+1)))
            self.assertLessEqual(len(chunks),4)
        self.assertEqual(3*3*3,27)
        self.assertEqual(9*9*9,729)
        self.assertEqual(7**3,343)
    def test_original_assertions_equivalent_or_strengthened(self):
        old=(HERE/'BASE-9fce-AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
        result=analyze(old,TEXT)
        self.assertEqual(result['exact_original_conditions_retained'],41)
        missing=result['unmatched_original_conditions']
        self.assertEqual(len(missing),3)
        new=result['new_conditions']
        self.assertIn('reading.state()==AnalyzerReading.State.UNAVAILABLE&&manager.metrics(level.dimension()).isEmpty()',new)
        self.assertIn('actual.equals(expected)',new)
        self.assertTrue(any(c.startswith(missing[1]+'&&') for c in new))
        unloaded=method('unloadedEyeRefusesWithoutCreatingTicketsOrAtmosphereService')
        native=method('nativeUse')
        self.assertIn('var reading = service.read(player);',unloaded)
        self.assertIn('var actual = AtmosphereAnalyzerRuntime.read(player);',native)

if __name__=='__main__':
    print(json.dumps({'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                      'phase':'fixed intermediate 275947 source; frozen handoff still required',
                      'model_limits':'models/source controls only, no native execution'}))
    unittest.main()
