# Unloaded fixture snapshot precision supplement

Status: PROPOSED technical supplement to unchanged proposal-01 SHA
`32246d396dc4d519883945eb3e866b3641cc30d531de359ac59593ef716792a0`.
It changes no production limits, service guards, tick/deadline or registry.

The supplied `getForcedChunks()` collection is an unmodifiable **backing view**,
not a historical snapshot. The implementation must not save that view as the
before value. On the server thread, before detaching/moving the admitted player:

1. Require `level.getForcedChunks().size() <= 4096`; overflow is a fixture
   admission failure, not truncation or a passing no-load test. This is a
   test-only snapshot budget (at most 4096 Long values), not a world/save budget.
2. Capture `Set<Long> forcedBefore = Set.copyOf(level.getForcedChunks())`, an
   independently owned immutable value snapshot. It contains no world reference.
3. Before the query and after the query, require both `size <= 4096` and exact
   `forcedBefore.equals(level.getForcedChunks())`, as well as the existing
   loaded-count/null-target/not-forced assertions. No iteration/loading/tickets
   are performed by the query setup helper beyond this bounded set copy.

All read comparisons occur synchronously within one GameTest callback, with no
server tick or external callback wait between snapshot and query. A callbacks'
load or altered ticket state still fails admission before analyzer execution.
The original original-position/attachment nested-finally restoration and actual
PlayerList/alive/Level identity checks remain required.

The bound is proposed solely for fixture evidence capture. It does not authorize
a change to a production resource/NBT/network/world-scan budget, and does not
claim natural client movement or native unload/restart proof.
