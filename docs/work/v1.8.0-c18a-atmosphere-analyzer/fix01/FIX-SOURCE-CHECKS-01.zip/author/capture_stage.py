import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ.update(TEMP=str(HERE), TMP=str(HERE), TMPDIR=str(HERE))
WT = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
REL = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
stage = sys.argv[1]
manifest = json.loads((HERE/(stage+'-SOURCE-MANIFEST.json')).read_text(encoding='utf8'))
data = (WT/REL).read_bytes()
assert hashlib.sha256(data).hexdigest() == manifest['inputs'][REL]['sha256']
target = HERE/(stage+'-AtmosphereAnalyzerGameTests.java')
assert not target.exists(), 'No overwrite of a stage source image'
target.write_bytes(data)
before = HERE/'BASE-AtmosphereAnalyzerGameTests.java'
if not before.exists():
    before.write_bytes(subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+REL]))
print(json.dumps({'stage':stage,'source_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                  'base_sha256':hashlib.sha256(before.read_bytes()).hexdigest()}))
