import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
REL = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
os.environ.update(TEMP=str(HERE), TMP=str(HERE), TMPDIR=str(HERE))
base = subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+REL])
current = (WT/REL).read_bytes()
assert hashlib.sha256(current).hexdigest()=='275947498de7b42a18f142616258c75400bedd7ed8d0a8f1d5b608d106b229c3'
assert (Path('D:/GitHub/AdvancedRocketry-Community')/REL).read_bytes()==base
target=HERE/'FINAL-AtmosphereAnalyzerGameTests.java'
assert not target.exists()
target.write_bytes(current)
patch=subprocess.check_output(['git','-C',str(WT),'diff','--binary','--no-ext-diff','--',REL])
(HERE/'SOURCE-FIX-01.patch').write_bytes(patch)
result={'base':BASE,'path':REL,'base_bytes':len(base),'base_sha256':hashlib.sha256(base).hexdigest(),
        'post_bytes':len(current),'post_sha256':hashlib.sha256(current).hexdigest(),
        'lines':current.count(b'\n'),'patch_bytes':len(patch),'patch_sha256':hashlib.sha256(patch).hexdigest(),
        'CRLF':{'base':base.count(b'\r\n'),'post':current.count(b'\r\n')},
        'Root_live_named_GT_is_exact_fixed_base':True}
(HERE/'SOURCE-POSTIMAGE-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
