# Controlled unloaded-eye fixture proposal

Status: PROPOSED; no movement amendment implemented or approved by this note.
Same assigned GT-file scope/base as the registration proposal.

## Actual failure and source basis

In diagnostic-01, a connected live player at `(25,000,000,80,25,000,000)` has a
FULL far chunk after `player.setPos` and before the query's observation. The
test's setup comment claiming this does not load is false. The original and
diagnostic failures remain immutable, including the post-query no-load check.

Mapped primary JAR SHA `95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`:
Entity.setPos calls setPosRaw; its Forge-added source line 3266 calls
`Level.getChunk(II)` under added-to-world/server/not-removed guards.
`onRemovedFromWorld()` only clears the Forge `isAddedToWorld` bit;
`onAddedToWorld()` sets it. `setPosRaw` still invokes `levelCallback.onMove()`.
The callback must not be replaced, bypassed or hidden, and if it loads a chunk
the fixture admission assertion fails.

## Exact proposed fixture sequence

1. Join through unchanged `ConnectedTestPlayers.join` and require the existing
   admitted identity conditions: actual PlayerList same object, actual server
   and Level, connected, alive, not removed/spectator/FakePlayer. Also require
   `player.isAddedToWorld()` initially true.
2. Record immutable original position and forced-chunk set, loaded count and
   require target chunk's `getChunkNow` null.
3. Temporarily call public `player.onRemovedFromWorld()` before synchronous
   `setPos(far)`; assert `!isAddedToWorld`, unchanged identity/admission checks,
   exact eye coordinates, target still null, same loaded count and same forced
   set **before** invoking the analyzer. No tick, teleport, forced ticket or
   callback replacement is added.
4. Execute the original reading UNAVAILABLE/no atmosphere service assertion
   and original unchanged loaded-count/null target/not-forced assertions; add
   exact forced-set equality. The service/query itself is not changed.
5. Inner `finally`: while still detached, restore the original position, then
   call `onAddedToWorld()` in a nested `finally` so all query/setup failures
   restore the bit. Assert attached state after a successful inner body.
   Outer `finally` closes service/manager and removes the connected fixture
   player through the unchanged PlayerList path.

This proves only an admitted connected player's **controlled detached-coordinate
query** at an actually unloaded eye chunk cannot create query-side loading or
atmosphere state. It does not prove ordinary client movement, player transfer,
disconnect/reconnect, naturally reached unload timing, native restart or V1/V2.
It does not change production admission; that service currently does not
require `isAddedToWorld`. No synthetic query coordinate getter or world loader
is substituted. Original unknown-eye assertions are retained, not reclassified
as an out-of-height/world-border rejection.

## Review / execution boundary

Root and an independent reviewer must evaluate the public-hook lifecycle use
and cleanup before any implementation. Full unfiltered GT after implementation
must fail on any setup-induced load or lost identity, and retain ten cases /
40 ticks. No native/client test is authorized by this proposal. Primary class
facts are observations, not proof that callback movement is non-loading in all
environments; the pre-query assertions determine that actual test condition.
