import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
WT=Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
os.environ.update(TEMP=str(HERE),TMP=str(HERE),TMPDIR=str(HERE))
stages=[]
for stage in ('diagnostic-01','diagnostic-02','diagnostic-03','full-06'):
    raw=(HERE/(stage+'-latest.log')).read_bytes()
    text=raw.decode('utf8',errors='replace')
    complete=re.findall(r'(\d+) GAME TESTS COMPLETE',text)
    passed=re.findall(r'All (\d+) required tests passed',text)
    failed=re.findall(r'(\d+) required tests failed',text)
    failing_names=re.findall(r'^\[.+?\] \[Server thread/ERROR\] \[net\.minecraft\.gametest\.framework\.LogTestReporter/\]: (\w+) failed!',text,re.MULTILINE)
    results=json.loads((HERE/(stage+'-RESULT.json')).read_text(encoding='utf8'))
    manifest=json.loads((HERE/(stage+'-SOURCE-MANIFEST.json')).read_text(encoding='utf8'))
    relative='src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
    ready=[line for line in text.splitlines() if 'ARCE_ANALYZER_FIX_READY ' in line]
    row={'stage':stage,'exit':results['exit'],'elapsed_seconds':results['elapsed_seconds'],
         'complete':complete,'all_required_passed':passed,'failed_required':failed,
         'failed_names':failing_names,'source_sha256':manifest['inputs'][relative]['sha256'],
         'input_drift':results['input_drift'],'ready':ready,
         'error_header_count':sum(bool(re.match(r'^\[.+?\] \[.+?/ERROR\]',line)) for line in text.splitlines()),
         'latest_log':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}}
    assert complete==['477']
    if stage=='full-06': assert results['exit']==0 and passed==['477'] and not failed and not failing_names and len(ready)==2
    else: assert results['exit']==1 and failed==['4'] and len(failing_names)==4
    stages.append(row)
patch=HERE/'SOURCE-FIX-01.patch'
done=subprocess.run(['git','-C','D:/GitHub/AdvancedRocketry-Community','apply','--check',str(patch)],capture_output=True)
(HERE/'patch-check-01.log').write_bytes(done.stdout+done.stderr)
(HERE/'PATCH-CHECK-01.json').write_text(json.dumps({'command':['git','-C','D:/GitHub/AdvancedRocketry-Community','apply','--check',str(patch)],'exit':done.returncode,
 'qualification':'Read-only forward check on individually verified fixed-base Root GT bytes. No apply or index operation.'},indent=2)+'\n',encoding='utf8')
assert done.returncode==0
(HERE/'RUN-SUMMARY-01.json').write_text(json.dumps({'stages':stages,'qualification':'Author scoped/GT observations only; no whole-version Gate, clean Root build/data, native or real client acceptance. ERROR header count is not a blanket waiver.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'stages':[{k:x[k] for k in ('stage','exit','complete','all_required_passed','failed_required','error_header_count')} for x in stages],'patch_check_exit':done.returncode}))
