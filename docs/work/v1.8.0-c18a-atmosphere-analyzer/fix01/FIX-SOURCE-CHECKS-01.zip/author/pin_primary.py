import hashlib
import json
import os
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ.update(TEMP=str(HERE), TMP=str(HERE), TMPDIR=str(HERE))
source = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/maven_downloader/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-sources.jar')
names = ['net/minecraftforge/gametest/ForgeGameTestHooks.java',
         'net/minecraftforge/gametest/GameTestMain.java',
         'net/minecraftforge/registries/RegisterEvent.java',
         'net/minecraftforge/registries/GameData.java']
rows = []
with zipfile.ZipFile(source) as jar:
    for name in names:
        data = jar.read(name)
        rows.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
result = {'jar':str(source),'jar_bytes':source.stat().st_size,
          'jar_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'members':rows}
(HERE/'FORGE-PRIMARY-PINS-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
