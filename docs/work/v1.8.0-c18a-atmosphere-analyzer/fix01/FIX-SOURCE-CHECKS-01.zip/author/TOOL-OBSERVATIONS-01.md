# Author tooling observations retained

These are helper/locator failures, not new source-runtime results.

* Guessed Moon generated JSON directories and guessed
  `atmosphere/scan/VolumeScanner.java` / `atmosphere/AtmosphereLevelService.java`
  did not exist. Exact `rg --files src` located the service under
  `atmosphere/server`; named actual Moon resources were subsequently read.
  No missing file is represented as an executed source check.
* Three manual apply_patch checks rejected stale expected context (clearRoom
  parameter name, registered return type, and progress-record wrapping).
  Verification failed before edits; exact successful patches were then applied.
* The primary method inspection was expanded from five members /16 methods to
  six /25 methods. Its first unsealed JSON path was reused during expansion;
  original invocation counts/logs remain. FINAL primary facts-01 and facts-02
  contain the expanded selection, not the initial five-member result. No sealed
  evidence was changed and no raw class bodies are exported.
* Scoped-04 supplied three nonexistent guessed class names. Gradle compiled
  successfully and ran only the two real matching classes (7 tests), not the
  intended five-class 19-test scope. Scoped-05 corrected the actual class
  selectors, preserving the first command/XML/result and executing 19 tests.
* Run-summary helper attempt 01 raised AssertionError at its four-failure
  reporter-count assertion because the selected native `latest.log` format has
  logger suffix `LogTestReporter/]:`, not the console `LogTestReporter]:` form.
  The error was emitted in the actual tool stderr; the Tee stdout file does not
  contain a fabricated stderr capture. Original helper bytes are preserved as
  `summarize_runs.failed-01.py`. `run-summary-diagnostic-02.log` preserves the
  measured empty matches and exact four required-failure terminal fields.
  The corrected helper recognizes the precise timestamp/server-thread/error/
  native logger prefix, without changing the expected failure count or source.

All source26/diagnostic GT failures, command receipts/raw latest/debug logs and
scoped XML remain separate. No failure above is treated as native/server/Gate
proof. No C-drive helper/output, process termination, native host, dependency
install, source/Git mutation outside the declared scope or cleanup is performed.
