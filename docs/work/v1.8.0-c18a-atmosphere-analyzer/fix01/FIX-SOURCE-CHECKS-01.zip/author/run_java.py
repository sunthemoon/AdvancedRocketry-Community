import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WT = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
ROOT_EVIDENCE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
TEMP = HERE/'process-temp'
TEMP.mkdir(exist_ok=True)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def write(name, data):
    (HERE/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def snapshot():
    done = subprocess.run(['git', '-C', str(WT), 'ls-files', 'src', 'build.gradle', 'settings.gradle',
                           'gradle.properties', 'gradlew', 'gradlew.bat', 'gradle'], capture_output=True, check=True)
    return {p: {'bytes': len(data), 'sha256': sha(data)}
            for p in done.stdout.decode('utf-8').splitlines() if (WT/p).is_file()
            for data in [(WT/p).read_bytes()]}
stage = sys.argv[1]
tasks = sys.argv[2:]
if not tasks or any(t not in ('runGameTestServer', 'compileJava', 'compileTestJava', 'test')
                    and not t.startswith('--tests') and not t.startswith('io.github.') for t in tasks):
    raise SystemExit('Only assigned scoped/test/GT commands are permitted')
free = {disk: shutil.disk_usage(disk+':/').free for disk in ('C', 'D')}
before = snapshot()
write(stage+'-SOURCE-MANIFEST.json', {'base': BASE, 'inputs': before})
write(stage+'-PRECHECK.json', {'free_bytes': free, 'threshold_bytes': 10_000_000_000,
                             'head': subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip()})
if any(n < 10_000_000_000 for n in free.values()):
    raise SystemExit('C/D free space below assigned launch threshold; no Java launched')
env = os.environ.copy()
env['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
env['PATH'] = env['JAVA_HOME']+'/bin;'+env['PATH']
for key in ('TEMP', 'TMP', 'TMPDIR'):
    env[key] = str(TEMP)
env['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir='+TEMP.as_posix()
cmd = [str(WT/'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
       '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir='+TEMP.as_posix(), *tasks]
write(stage+'-COMMAND.json', {'command': cmd, 'cwd': str(WT), 'JAVA_HOME': env['JAVA_HOME'],
                            'JAVA_TOOL_OPTIONS': env['JAVA_TOOL_OPTIONS'], 'TEMP_TMP_TMPDIR': str(TEMP),
                            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
start = time.monotonic()
with (HERE/(stage+'.log')).open('wb') as out:
    done = subprocess.run(cmd, cwd=WT, env=env, stdout=out, stderr=subprocess.STDOUT)
after = snapshot()
changed = [p for p in set(before)|set(after) if before.get(p) != after.get(p)]
write(stage+'-POSTCHECK.json', {'source_inputs': len(before), 'changed_during_command': sorted(changed),
                              'free_bytes': {d: shutil.disk_usage(d+':/').free for d in ('C', 'D')}})
result = {'exit': done.returncode, 'elapsed_seconds': time.monotonic()-start,
          'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'input_drift': changed}
for name in ('latest.log', 'debug.log'):
    source = WT/'build/gametest/logs'/name
    if 'runGameTestServer' in tasks and source.exists():
        shutil.copyfile(source, HERE/(stage+'-'+name))
if 'test' in tasks:
    import xml.etree.ElementTree as ET
    target = HERE/(stage+'-xml'); target.mkdir(exist_ok=True)
    suites = []
    for source in sorted((WT/'build/test-results/test').glob('TEST-*.xml')):
        shutil.copyfile(source, target/source.name)
        suite = ET.parse(source).getroot()
        suites.append({k: suite.get(k) for k in ('name', 'tests', 'failures', 'errors', 'skipped')})
    result['junit'] = {'suites': len(suites), **{k: sum(int(s[k]) for s in suites)
                     for k in ('tests', 'failures', 'errors', 'skipped')}, 'rows': suites}
write(stage+'-RESULT.json', result)
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(done.returncode if not changed else 2)
