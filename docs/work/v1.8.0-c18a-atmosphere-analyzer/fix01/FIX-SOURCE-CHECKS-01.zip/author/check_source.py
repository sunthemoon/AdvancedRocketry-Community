"""Bounded first-argument preservation and source-boundary controls, not runtime proof."""
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
REL = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
os.environ.update(TEMP=str(HERE), TMP=str(HERE), TMPDIR=str(HERE))
before = subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+REL]).decode('utf8')
after_data = (WT/REL).read_bytes()
after = after_data.decode('utf8')

def args(source):
    methods = list(re.finditer(r'(?:public|private) static [\w<>]+ (\w+)\(',source))
    rows = []
    for match in re.finditer(r'helper\.assertTrue\(',source):
        method = max((m for m in methods if m.start()<match.start()), key=lambda m:m.start()).group(1)
        pos = match.end(); start = pos; depth = 0; quote = None; escape = False
        while pos<len(source):
            c = source[pos]
            if quote:
                if escape: escape=False
                elif c=='\\': escape=True
                elif c==quote: quote=None
            elif c in ('"',"'"): quote=c
            elif c in '([{': depth+=1
            elif c in ')]}': depth-=1
            elif c==',' and depth==0: break
            pos+=1
        expression = re.sub(r'\s+','',source[start:pos])
        if method=='unloadedEyeRefusesWithoutCreatingTicketsOrAtmosphereService':
            expression=expression.replace('reading.state()','service.read(player).state()')
        if method=='nativeUse':
            expression=expression.replace('actual.equals(expected)','AtmosphereAnalyzerRuntime.read(player).equals(expected)')
        rows.append({'method':method,'line':source[:match.start()].count('\n')+1,'expression':expression})
    return rows

old, new = args(before), args(after)
retained = []
for row in old:
    matches = [x for x in new if x['method']==row['method'] and
               (x['expression']==row['expression'] or x['expression'].startswith(row['expression']+'&&'))]
    retained.append({'before':row,'matches':[{'line':m['line'],'expression':m['expression']} for m in matches]})
annotations = r'@GameTest\(template = "([^"]+)", batch = "([^"]+)", timeoutTicks = (\d+)\)\s+public static void (\w+)'
controls = {
    'ten_annotations_names_templates_batches_timeouts_exact': re.findall(annotations,before)==re.findall(annotations,after) and len(re.findall(annotations,after))==10,
    'original_first_arguments_retained_or_strengthened': all(row['matches'] for row in retained),
    'registration_guard_dist': 'FMLEnvironment.dist != Dist.DEDICATED_SERVER' in after,
    'registration_guard_dedicated_hook': '!ForgeGameTestHooks.isGametestServer()' in after,
    'registration_guard_key': '!event.getRegistryKey().equals(ForgeRegistries.Keys.ITEMS)' in after,
    'only_two_fixture_constructions_inside_suppliers': after.count('() -> new AtmosphereAnalyzerItem(')==2 and after.count('new AtmosphereAnalyzerItem(')==2,
    'no_query_runtime_install_or_production_scanner_edit_calls': 'AtmosphereRuntime.install' not in after and 'AtmosphereAnalyzerRuntime.install' not in after,
    'forced_set_is_independent': 'Set.copyOf(level.getForcedChunks())' in after,
    'counter_reset_start_finally': 'queries.set(0);' in after and '} finally { queries.set(0); remove(helper, player); }' in after,
    'movement_restores_coordinate_and_attachment_nested_finally': 'try { player.setPos(original); } finally { player.onAddedToWorld(); }' in after,
    'warmup_queries_check_inspection_and_resources': 'Readiness query scanned or spent vent resources' in after,
    'readiness_below_original_deadline': 'helper.getTick() < 39' in after,
    'room_marks_only_missing_and_cleanup_owned': 'if (!level.getForcedChunks().contains(chunk.toLong()))' in after and 'for (ChunkPos chunk : added)' in after,
}
initial = json.loads((HERE/'diagnostic-01-SOURCE-MANIFEST.json').read_text(encoding='utf8'))['inputs']
outside=[]
for name,row in initial.items():
    if name==REL: continue
    data=(WT/name).read_bytes()
    if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']: outside.append(name)
controls['all_2834_other_build_source_inputs_unchanged']=not outside
result={'postimage':{'path':REL,'bytes':len(after_data),'sha256':hashlib.sha256(after_data).hexdigest()},
        'before_assertions':len(old),'after_assertions':len(new),'original_first_arguments':retained,
        'controls':controls,'false_controls':[k for k,v in controls.items() if not v], 'outside_changes':outside,
        'qualification':'Static comparisons do not establish runtime scheduling, normal-profile launches, native persistence, clients or Gates.'}
(HERE/'SOURCE-CONTROLS-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({'original_assertions':len(old),'candidate_assertions':len(new),'false_controls':result['false_controls'],
                 'unmatched_originals':[x['before'] for x in retained if not x['matches']]}))
raise SystemExit(bool(result['false_controls']))
