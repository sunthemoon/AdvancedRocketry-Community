import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WT = Path('D:/GitHub/arce-v180-c18a-analyzer-fix-20261005')
ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
BASE = '9fce551ea9389ce37a94f804aa0e817399586a7e'
GT = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
DOC = 'docs/work/v1.8.0-c18a-atmosphere-analyzer/'
EXPECTED = '275947498de7b42a18f142616258c75400bedd7ed8d0a8f1d5b608d106b229c3'

def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    path = HERE / name
    content = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path.exists():
        assert path.read_text(encoding='utf-8') == content, name
        return
    with path.open('x', encoding='utf-8', newline='\n') as target:
        target.write(content)

def git(*args):
    done = subprocess.run(['git', '-C', str(WT), *args], capture_output=True, check=True)
    return done.stdout

assert git('rev-parse', 'HEAD').decode().strip() == BASE
stages = ['diagnostic-01', 'diagnostic-02', 'diagnostic-03', 'scoped-04', 'scoped-05', 'full-06']
snapshots = {stage: json.loads((HERE / (stage + '-SOURCE-MANIFEST.json')).read_text())['inputs']
             for stage in stages}
first, last = snapshots[stages[0]], snapshots[stages[-1]]
assert len(first) == len(last) == 2835
other_drift = [name for name in sorted(first) if name != GT and first[name] != last[name]]
live_drift = [name for name, pin in last.items() if digest((WT / name).read_bytes()) != pin]
assert not other_drift and not live_drift
for stage in stages:
    assert not json.loads((HERE / (stage + '-RESULT.json')).read_text())['input_drift']
post = (WT / GT).read_bytes()
assert digest(post)['sha256'] == EXPECTED
assert post == (HERE / 'FINAL-AtmosphereAnalyzerGameTests.java').read_bytes()
assert (HERE / 'BASE-AtmosphereAnalyzerGameTests.java').read_bytes() == git('show', BASE + ':' + GT)
assert digest((HERE / 'SOURCE-FIX-01.patch').read_bytes())['sha256'] == '87a711965b8d77a3722859584f1678b269cbaf6b0c945d64b4580afdfa6f8d3e'
wrapper_blob = git('show', BASE + ':gradlew.bat')
wrapper_worktree = (WT / 'gradlew.bat').read_bytes()
assert digest(wrapper_worktree) == first['gradlew.bat'] == last['gradlew.bat']
write('WRAPPER-CHECKOUT-01.json', {
    'base': BASE, 'path': 'gradlew.bat', 'raw_git_blob': digest(wrapper_blob),
    'observed_checkout': digest(wrapper_worktree),
    'first_last_live_exact': True,
    'raw_git_equals_checkout': wrapper_blob == wrapper_worktree,
    'only_crlf_checkout_difference': wrapper_worktree.replace(b'\r\n', b'\n') == wrapper_blob,
    'raw_git_crlf': wrapper_blob.count(b'\r\n'), 'raw_git_lf': wrapper_blob.count(b'\n'),
    'checkout_crlf': wrapper_worktree.count(b'\r\n'), 'checkout_lf': wrapper_worktree.count(b'\n'),
    'scope': 'This is one exact wrapper observation, not a general normalization allowance.'
})
owned = []
for path, evidence in [(GT, 'FINAL-AtmosphereAnalyzerGameTests.java'),
                       (DOC + 'FIX-PROGRESS-01.md', 'FIX-PROGRESS-01.md'),
                       (DOC + 'FIX-HANDOFF-01.md', 'FIX-HANDOFF-01.md')]:
    data = (WT / path).read_bytes()
    target = HERE / evidence
    if target.exists():
        assert target.read_bytes() == data
    else:
        with target.open('xb') as out:
            out.write(data)
    owned.append({'repository_path': path, 'evidence_path': evidence, **digest(data)})
write('OWNED-FILES-01.json', {'base': BASE, 'files': owned, 'scope': 'Exactly one GT source and two task records.'})
fixed_paths = ['AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
               'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
               'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
               'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
               'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
               DOC + 'TASK.md', DOC + 'REVIEW-DISPOSITION-01.md']
fixed = [{'commit': BASE, 'repository_path': name, **digest(git('show', BASE + ':' + name))}
         for name in fixed_paths]
old_names = ['gametest-01.command.json', 'gametest-01.result.json', 'GAMETEST-01.json',
             'gametest-01.log', 'gametest-01-latest.log', 'gametest-01-debug.log',
             'SOURCE26-MANIFEST-01.json', 'SOURCE26-POSTCHECK-01.json', 'JUNIT-01.json']
old_pins = [{'path': str(OLD / name), **digest((OLD / name).read_bytes())} for name in old_names]
effective = digest((ROOT / 'AGENTS.md').read_bytes())
assert effective == {'bytes': 12047, 'sha256': '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'}
write('INPUT-PINS-01.json', {
    'fixed_committed_documents': fixed, 'effective_root_governance_observation':
    {'path': str(ROOT / 'AGENTS.md'), **effective}, 'original_root_failure_named_inputs': old_pins,
    'selected_source_manifest': 'full-06-SOURCE-MANIFEST.json',
    'source_scope': '2835 actual WT src/build inputs, not 3036 Root inputs or all raw Git blobs.',
    'external_locations': 'Historical sealed input references/observations; not package checksum entries.'
})
status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
allowed = {GT, DOC + 'FIX-PROGRESS-01.md', DOC + 'FIX-HANDOFF-01.md'}
status_paths = [line[3:] for line in status.splitlines()]
assert set(status_paths) == allowed, status
write('FREEZE-RESULT-01.json', {
    'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': 0,
    'actual_command': ['python', '-B', str(HERE / 'seal_final.py')], 'base': BASE,
    'selected_inputs': len(last), 'non_gt_first_to_final_drift': other_drift,
    'final_live_input_drift': live_drift, 'git_status_readonly': status,
    'source_sha256': EXPECTED, 'raw_results_external': True,
    'author_java': 'All six launched Java/Gradle jobs terminal; author slot released.',
    'transfer': 'Source/docs frozen. Root may transfer this WT ordinary disposable build/GameTest outputs to the independent reviewer now.',
    'exclusions': ['process-temp/**', 'worktree build/**', 'worktree runtime/**', 'classes/JARs/whole copied source tree'],
    'qualification': 'Review-ready uncommitted correction only; no delivery, Root integrated cohort, native/client or Gate admission.'
})
files = []
for directory, dirs, names in os.walk(HERE):
    dirs[:] = sorted(name for name in dirs if name != 'process-temp')
    for name in sorted(names):
        path = Path(directory) / name
        assert not path.is_symlink()
        files.append({'path': path.relative_to(HERE).as_posix(), **digest(path.read_bytes())})
write('INTERNAL-MANIFEST-01.json', {
    'format': 1, 'scope': 'Immutable thin author evidence, excluding process temp and mutable WT build/runtime.',
    'files': files, 'entries': len(files), 'payload_bytes': sum(row['bytes'] for row in files)
})
print(json.dumps({'owned': owned, 'internal_manifest': digest((HERE / 'INTERNAL-MANIFEST-01.json').read_bytes()),
                  'entries': len(files), 'payload_bytes': sum(row['bytes'] for row in files),
                  'freeze_result': digest((HERE / 'FREEZE-RESULT-01.json').read_bytes())}, indent=2))
