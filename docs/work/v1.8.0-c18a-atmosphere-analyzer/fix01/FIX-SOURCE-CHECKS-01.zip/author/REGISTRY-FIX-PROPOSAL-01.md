# Analyzer GameTest-only item registration proposal

Status: PROPOSED, not permission to change registry behavior. The author waits for
Root and independent technical review before implementing this proposal.

## Scope and exact candidate

The only proposed Java write remains the assigned
`gametest/AtmosphereAnalyzerGameTests.java`, at base
`9fce551ea9389ce37a94f804aa0e817399586a7e`. Add a public static nested subscriber,
annotated `@Mod.EventBusSubscriber(modid = AdvancedRocketryCommunity.MOD_ID,
bus = Mod.EventBusSubscriber.Bus.MOD)`, with a static `@SubscribeEvent`
`onRegisterItems(RegisterEvent event)` method. No central subscription, registry,
build/source-set, configuration or production item change is proposed.

The handler returns unless **all** these conditions hold, before any fixture
item construction or supplier invocation:

1. `FMLEnvironment.dist == Dist.DEDICATED_SERVER`;
2. `ForgeGameTestHooks.isGametestServer()`;
3. `event.getRegistryKey().equals(ForgeRegistries.Keys.ITEMS)`.

Register exactly two IDs through `event.register(ForgeRegistries.Keys.ITEMS, id,
supplier)`:

* `advancedrocketrycommunity:gametest_analyzer_disabled`: construct
  `AtmosphereAnalyzerItem(new Item.Properties(), () -> false, query)` **inside
  the registration supplier**.
* `advancedrocketrycommunity:gametest_analyzer_unavailable`: the same with
  `() -> true`.

Each query increments the same test-owned `AtomicInteger` and returns
`AnalyzerReading.unavailable()`. Do not construct an Item in a static field or
in the running GameTest. The test resolves the exact registry IDs and requires
the type to be `AtmosphereAnalyzerItem`; no fallback or replacement is allowed.
Two IDs are needed because the production item has fixed config/query callbacks
and the existing test's disabled/unavailable query-count evidence must remain.

## Lifetime, publication and cleanup

The counter is test-only, contains no player/world/resource references, is reset
before the disabled case and in its `finally` block. The ten cases remain in the
same existing batch with their original 40-tick deadlines; no concurrent use of
these two fixture items is added. Every connected fixture player is removed in
`finally`, including any failed lookup/assertion. The test still checks queries
0 then 1, feedback count, cooldown, malformed stack refusal, and detached-player
refusal. Other actual registered-item tests continue using `atmosphere_analyzer`.

The two fixture entries exist for the lifetime of a dedicated, non-production
GameTest server registry. The same IDs are used on repeat test launches; no
duplicate per-test registration is attempted. These are not creative entries,
recipe inputs/outputs, DataGen or public gameplay IDs. They may appear in the
disposable GameTest registry snapshot and synthetic playerdata/item stacks; this
proposal does **not** claim no save impact inside that test world. They must not
be used in retained gameplay/native worlds, and normal-server inventories are
not migrated or written by this proposal.

## Profile boundary

The dedicated GameTest launcher sets `forge.enableGameTest=true` and
`forge.gameTestServer=true` before calling vanilla Main, which reaches Forge mod
loading and RegisterEvent while the registry is unfrozen. The Forge source
guard is `!FMLLoader.isProduction() && Boolean.getBoolean("forge.gameTestServer")`.
Thus packaged production server/client, ordinary dev server/client, `runData`,
and a dev profile with only `forge.enableGameTest=true` do not construct or
register these items. An explicitly flagged non-production dedicated profile
can opt in; this is a test-profile boundary, not a security mechanism.

`@GameTestHolder` and enabled test namespace filtering do not isolate MOD-bus
registration, so neither is relied on. The additional dedicated-dist condition
excludes flagged client profiles. No ASM, access transformer, reflection,
registry unfreeze, global production registry reset or coremod is proposed.

## Evidence and planned checks

Actual original Source26 and diagnostic-01 runs each execute 477 tests with
four analyzer required failures. In both, runtime Item construction fails with
`Registry is already frozen`; diagnostic-01 exits 1 and has zero input drift.
This proposal resolves only the registration construction boundary, not the
other three failures or native/client/Gates.

Primary source JAR: Forge 47.4.10, SHA-256
`918a11bdfceace2752d4c29bddbdf327981e1f6a1e1f0675f23e5fbf01e226c0`.
Named members: `ForgeGameTestHooks.java` (`9f416673...278e9e`),
`GameTestMain.java` (`12d1ffb6...ae24d`), `RegisterEvent.java`
(`6a7ce275...04ddc`), `GameData.java` (`2de4043f...b78a9c`).
Independent reviewer supplies separate primary facts; those are not approval.

Before implementation: independently inspect these exact handler/ID/lifetime
requirements and normal-profile truth table. After permission: static checks
bind construction to supplier/guard and preserve all original assertions; full
unfiltered GameTest run checks actual early registration, two exact lookups and
the injected callback counts. Compiled supplier/class inspection and absence of
creative/recipe/generated edits are separate evidence. No normal packaged
server/client or new native execution is authorized in this scope; their
non-execution must remain explicit.
