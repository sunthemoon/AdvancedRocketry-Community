# Final metadata locator failure

The first `python -B seal_final.py` metadata-only command returned exit 1.
Its attempted fixed-object read
`git show 9fce551ea9389ce37a94f804aa0e817399586a7e:docs/versions/v1.8.0.md`
returned exit 128 because that guessed name does not exist. The tool's actual
stderr was a `subprocess.CalledProcessError` at the fixed-documents collection;
this note is a transcription of the tool observation, not a new raw stderr file.

The exact first helper bytes are preserved as `seal_final.failed-01.py`.
Already created wrapper/owned-file receipts and postimage copies are unchanged.
No final evidence manifest was created, no Java launched, and no source or task
record changed during the failure. The bounded fixed `git ls-tree` read identifies
`docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md` as the actual version file.
The subsequent metadata-only helper uses that name and only verifies exact
already existing partial receipts before continuing. This fixes the locator, not
source assertions, test budgets, failed history or a behavior verdict.
