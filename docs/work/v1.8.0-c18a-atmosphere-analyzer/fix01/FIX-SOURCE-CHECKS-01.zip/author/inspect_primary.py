"""Selected mapped class facts only; no official source/class export."""
import hashlib
import json
import os
import struct
import zipfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
os.environ.update(TEMP=str(OUT), TMP=str(OUT), TMPDIR=str(OUT))
JAR = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')

class Reader:
    def __init__(self, data): self.data, self.p = data, 0
    def u(self, n):
        v = int.from_bytes(self.data[self.p:self.p+n], 'big'); self.p += n; return v
    def take(self, n):
        v = self.data[self.p:self.p+n]; self.p += n; return v

def inspect(data, wanted):
    r = Reader(data)
    assert r.u(4) == 0xcafebabe
    r.u(2); r.u(2); count = r.u(2); cp = [None] * count; i = 1
    while i < count:
        tag = r.u(1)
        if tag == 1: cp[i] = r.take(r.u(2)).decode('utf8', 'replace')
        elif tag in (3, 4): cp[i] = r.take(4)
        elif tag in (5, 6): cp[i] = r.take(8); i += 1
        elif tag in (7, 8, 16, 19, 20): cp[i] = (tag, r.u(2))
        elif tag in (9, 10, 11, 12, 17, 18): cp[i] = (tag, r.u(2), r.u(2))
        elif tag == 15: cp[i] = (tag, r.u(1), r.u(2))
        else: raise ValueError(tag)
        i += 1
    def desc(index):
        x = cp[index]
        if isinstance(x, str): return x
        if x[0] in (7, 8): return desc(x[1])
        if x[0] == 12: return desc(x[1]) + desc(x[2])
        if x[0] in (9, 10, 11): return desc(x[1]) + '.' + desc(x[2])
        return str(x)
    r.take(6); r.take(r.u(2)*2)
    for _ in range(r.u(2)):
        r.take(6)
        for _ in range(r.u(2)): r.u(2); r.take(r.u(4))
    found = []
    for _ in range(r.u(2)):
        flags, name, sig = r.u(2), desc(r.u(2)), desc(r.u(2)); code = None; lines = []
        for _ in range(r.u(2)):
            attr, body = desc(r.u(2)), r.take(r.u(4))
            if attr != 'Code': continue
            cr = Reader(body); cr.take(4); code = cr.take(cr.u(4)); cr.take(cr.u(2)*8)
            for _ in range(cr.u(2)):
                subname, subbody = desc(cr.u(2)), cr.take(cr.u(4))
                if subname == 'LineNumberTable':
                    lr = Reader(subbody)
                    lines = [(lr.u(2), lr.u(2)) for _ in range(lr.u(2))]
        if name not in wanted or code is None: continue
        calls = []; p = 0
        fixed = {16:1,17:2,18:1,19:2,20:2,132:2,169:1,188:1,197:3,185:4,186:4,200:4,201:4}
        for op in range(21,26): fixed[op]=1
        for op in range(54,59): fixed[op]=1
        for op in range(153,169): fixed[op]=2
        for op in range(178,185): fixed[op]=2
        for op in (187,189,192,193,198,199): fixed[op]=2
        while p < len(code):
            start, op = p, code[p]; p += 1
            if op in range(178,186):
                idx = int.from_bytes(code[p:p+2], 'big')
                line = max((ln for pc,ln in lines if pc <= start), default=None)
                calls.append({'offset':start,'line':line,'op':op,'target':desc(idx)})
            if op in (170,171):
                while p%4: p += 1
                p += 4
                if op == 170:
                    low, high = struct.unpack('>ii', code[p:p+8]); p += 8 + 4*(high-low+1)
                else:
                    pairs = int.from_bytes(code[p:p+4], 'big'); p += 4 + 8*pairs
            elif op == 196:
                wideop = code[p]; p += 5 if wideop == 132 else 3
            else: p += fixed.get(op, 0)
        found.append({'method':name,'descriptor':sig,'flags':flags,'calls':calls})
    return found

selected = {
    'net/minecraft/world/entity/Entity.class': ['setPos','setPosRaw','getEyeY','moveTo','setLevelCallback','onRemovedFromWorld','onAddedToWorld','isAddedToWorld','remove','setRemoved','unsetRemoved'],
    'net/minecraft/server/level/ServerPlayer.class': ['setPos','teleportTo'],
    'net/minecraft/server/level/ServerLevel.class': ['hasChunkAt','getBlockEntity','removePlayerImmediately'],
    'net/minecraft/world/level/entity/PersistentEntitySectionManager$Callback.class': ['onMove','onRemove'],
    'net/minecraft/world/level/Level.class': ['getBlockEntity','hasChunkAt'],
    'net/minecraft/world/level/chunk/LevelChunk.class': ['getBlockEntity','setBlockEntity'],
}
result = {'jar': str(JAR), 'sha256': hashlib.sha256(JAR.read_bytes()).hexdigest(), 'members': []}
with zipfile.ZipFile(JAR) as z:
    for member,wanted in selected.items():
        data = z.read(member)
        result['members'].append({'path':member,'sha256':hashlib.sha256(data).hexdigest(), 'facts':inspect(data,wanted)})
(OUT/'PRIMARY-METHOD-FACTS-02.json').write_text(json.dumps(result,indent=2)+'\n', encoding='utf8')
print(json.dumps({'members':len(result['members']),'methods':sum(len(x['facts']) for x in result['members']),'jar_sha256':result['sha256']}))
