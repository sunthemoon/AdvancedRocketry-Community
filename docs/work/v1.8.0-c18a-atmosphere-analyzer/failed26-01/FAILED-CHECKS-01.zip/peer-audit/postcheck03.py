"""Versioned reviewer-only CRC/mandatory-document locator corrections."""
import hashlib
from pathlib import Path

base = Path(__file__).resolve().parent
raw = (base / 'postcheck01.py').read_bytes()
source = raw.decode('utf-8')
corrections = {
    'with self.assertRaises(zipfile.BadZipFile): zip_control(broken)':
        'with self.assertRaises(AssertionError): zip_control(broken)',
    "'docs/versions/v1.8.0.md'": "'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md'",
    "(B / 'POSTCHECK-01.json')": "(B / 'POSTCHECK-03.json')",
}
for before, after in corrections.items():
    assert source.count(before) == 1
    source = source.replace(before, after)
print('Historical helper SHA256:', hashlib.sha256(raw).hexdigest())
print('Corrections: actual testzip refusal wrapper and actual roadmap version-document name; old failures retained.')
exec(compile(source, str(base / 'postcheck01.py') + '[crc-and-version-locator-corrections]', 'exec'))
