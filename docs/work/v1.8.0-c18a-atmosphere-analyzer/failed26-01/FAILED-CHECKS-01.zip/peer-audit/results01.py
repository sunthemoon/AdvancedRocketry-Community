"""Independently count terminal GT/JUnit observations, preserving nonzero exits."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

B = Path(__file__).resolve().parent
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
O = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
stamp = r'(?:\d{2}:\d{2}:\d{2}|\d{2}[A-Za-z]{3}\d{4} \d{2}:\d{2}:\d{2}\.\d{3})'
header = re.compile(r'^\[' + stamp + r'\] \[(?P<thread>[^\]\r\n]+)/(?P<level>INFO|ERROR|WARN|DEBUG)\] \[(?P<logger>[^\]\r\n]+)\]: (?P<message>[^\r\n]*)$')
server_loggers = {'minecraft/GameTestServer', 'net.minecraft.gametest.framework.GameTestServer/'}
reporter_loggers = {'minecraft/LogTestReporter', 'net.minecraft.gametest.framework.LogTestReporter/'}

def terminal(text):
    lines = text.splitlines()
    entries = []
    errors = []
    reporters = []
    boards = []
    complete = []
    required = []
    for number, line in enumerate(lines, 1):
        match = header.fullmatch(line)
        if match is None:
            continue
        row = {'line': number, **match.groupdict()}
        entries.append(row)
        if row['level'] == 'ERROR':
            errors.append(row)
        if row['thread'] != 'Server thread':
            continue
        if row['logger'] in reporter_loggers and row['level'] == 'ERROR':
            failure = re.fullmatch(r'([^ ]+) failed! (.*)', row['message'])
            if failure:
                reporters.append({'line': number, 'name': failure[1], 'message': failure[2]})
        if row['logger'] in server_loggers and row['level'] == 'INFO':
            total = re.fullmatch(r'=+ (\d+) GAME TESTS COMPLETE =+', row['message'])
            fail = re.fullmatch(r'(\d+) required tests failed :\(', row['message'])
            board = re.fullmatch(r'\[([+X_ x]+)\]', row['message'])
            if total:
                complete.append({'line': number, 'total': int(total[1])})
            if fail:
                required.append({'line': number, 'failures': int(fail[1])})
            if board:
                boards.append({'line': number, 'symbols': board[1]})
    assert len(complete) == len(required) == 1, 'Missing/ambiguous failed-run completion'
    c, f = complete[0], required[0]
    assert c['line'] < f['line']
    names = []
    for number in range(f['line'] + 1, len(lines) + 1):
        match = header.fullmatch(lines[number - 1])
        if match is None or match['thread'] != 'Server thread' or match['level'] != 'INFO' or match['logger'] not in server_loggers:
            break
        item = re.fullmatch(r'   - (\S+)', match['message'])
        if not item:
            break
        names.append({'line': number, 'name': item[1]})
    assert len(names) == f['failures'] and len({row['name'] for row in names}) == len(names)
    assert len(reporters) == f['failures'] and {row['name'] for row in reporters} == {row['name'] for row in names}
    final = [row for row in boards if row['line'] < c['line']][-1]
    assert len(final['symbols']) == c['total'] and Counter(final['symbols']) == {'+': c['total'] - f['failures'], 'X': f['failures']}
    counts = Counter((row['logger'], row['message']) for row in errors)
    return {'completion': c, 'required_failure_summary': f, 'failure_names': names, 'first_failure_reports': reporters,
            'last_complete_board': {'line': final['line'], 'symbols': dict(Counter(final['symbols']))},
            'error_header_count': len(errors), 'all_error_headers': errors,
            'exact_error_groups': [{'logger': a, 'message': b, 'count': n} for (a, b), n in sorted(counts.items())]}

def sample(total=2, failures=1):
    prefix = '[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: '
    return '\n'.join([
        '[00:00:00] [Server thread/ERROR] [minecraft/LogTestReporter]: alpha failed! a reason',
        prefix + '[+X]', prefix + f'========= {total} GAME TESTS COMPLETE =========',
        prefix + f'{failures} required tests failed :(', prefix + '   - alpha'])

class ParserControls(unittest.TestCase):
    def test_failed_terminal_retains_failure(self):
        self.assertEqual(terminal(sample())['required_failure_summary']['failures'], 1)
    def test_empty_is_not_a_pass(self):
        with self.assertRaises(AssertionError): terminal('')
    def test_nested_fake_logger_is_not_completion(self):
        with self.assertRaises(AssertionError): terminal(sample().replace('[minecraft/GameTestServer]:', '[other]: [minecraft/GameTestServer]:'))
    def test_duplicate_completion_refuses(self):
        with self.assertRaises(AssertionError): terminal(sample() + '\n[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: ========= 2 GAME TESTS COMPLETE =========')
    def test_inconsistent_board_refuses(self):
        with self.assertRaises(AssertionError): terminal(sample(total=3))
    def test_inconsistent_failure_count_refuses(self):
        with self.assertRaises(AssertionError): terminal(sample(failures=2))
    def test_listed_failure_must_have_report(self):
        with self.assertRaises(AssertionError): terminal(sample().replace('alpha failed!', 'beta failed!'))
    def test_other_thread_does_not_qualify(self):
        with self.assertRaises(AssertionError): terminal(sample().replace('[Server thread/INFO]', '[Client thread/INFO]'))

suite = unittest.defaultTestLoader.loadTestsFromTestCase(ParserControls)
controls = unittest.TextTestRunner(verbosity=2).run(suite)
assert controls.wasSuccessful()
observations = {}
for filename in ('gametest-01.log', 'gametest-01-latest.log', 'gametest-01-debug.log'):
    observed = terminal((F / filename).read_bytes().decode('utf-8'))
    assert observed['completion']['total'] == 477 and observed['required_failure_summary']['failures'] == 4
    assert observed['error_header_count'] == 65
    observations[filename] = observed
names = [{row['name'] for row in obs['failure_names']} for obs in observations.values()]
assert all(value == names[0] for value in names)
gt = json.loads((F / 'gametest-01.result.json').read_bytes())
assert gt['exit'] == 1 and 'non-zero exit value 4' in (F / 'gametest-01.log').read_text(encoding='utf-8')
assert 'BUILD FAILED' in (F / 'gametest-01.log').read_text(encoding='utf-8')
repeat = json.loads((F / 'REPEAT-DATAGEN-01.json').read_bytes())
repeat_log = (F / 'repeat-data-01.log').read_bytes()
assert repeat['log'] == {'bytes': len(repeat_log), 'sha256': hashlib.sha256(repeat_log).hexdigest()}
assert repeat['exit'] == 0 and repeat['files'] == 781 and repeat['changed'] == []
cache_lines = {}
for name in ('full-build-01.log', 'repeat-data-01.log'):
    cache_lines[name] = [{'line': n, 'text': line} for n, line in enumerate((F / name).read_text(encoding='utf-8').splitlines(), 1) if 'Caching: total files:' in line]
    assert len(cache_lines[name]) == 1 and 'total files: 781,' in cache_lines[name][0]['text'] and 'written: 0' in cache_lines[name][0]['text']
static = json.loads((F / 'STATIC-RESULTS-01.json').read_bytes())
assert len(static['jobs']) == 10
assert {(row['name'], row['exit']) for row in static['jobs'] if row['exit']} == {('ledger-closure', 1), ('dirty-diff', 1)}
assert '186 ledger rows are still PLANNED' in (F / 'ledger-closure-01.log').read_text(encoding='utf-8')
assert '154 assets are still handled as REVIEW' in (F / 'ledger-closure-01.log').read_text(encoding='utf-8')
diff_headers = [line for line in (F / 'dirty-diff-01.log').read_text(encoding='utf-8').splitlines() if line.startswith('diff --git ')]
assert diff_headers == ['diff --git a/AGENTS.md b/AGENTS.md']

def junit(path):
    records, files = {}, {}
    for xml in sorted(path.iterdir()):
        assert xml.suffix == '.xml'
        raw = xml.read_bytes()
        parent = ET.fromstring(raw)
        cases = parent.findall('testcase')
        assert len(cases) == int(parent.attrib['tests'])
        assert not any(case.find(key) is not None for case in cases for key in ('failure', 'error', 'skipped'))
        records[parent.attrib['name']] = sorted((case.attrib['classname'], case.attrib['name']) for case in cases)
        files[str(xml)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    return records, files
old, old_files = junit(O / 'junit-01')
new, _ = junit(F / 'junit-01')
assert set(old) <= set(new)
lost_cases = {name: sorted(set(old[name]) - set(new[name])) for name in old if set(old[name]) - set(new[name])}
assert not lost_cases
new_suites = sorted(set(new) - set(old))
assert len(old) == 333 and sum(len(value) for value in old.values()) == 1785
assert len(new) == 339 and sum(len(value) for value in new.values()) == 1807
added_cases = {name: sorted(set(new[name]) - set(old.get(name, []))) for name in new if set(new[name]) - set(old.get(name, []))}
assert sum(map(len, added_cases.values())) == 22
output = {'log_observations': observations, 'reviewer_parser_controls': {'tests': controls.testsRun, 'failures': len(controls.failures), 'errors': len(controls.errors)},
          'gametest_outer_exit': gt['exit'], 'native_java_child_exit_observed': 4,
          'old_junit_counts': {'tests': 1785, 'suites': 333}, 'new_junit_counts': {'tests': 1807, 'suites': 339},
          'no_old_testcase_names_removed': True, 'new_suites': new_suites, 'added_case_names': added_cases,
          'old_junit_input_pins': old_files, 'cache_lines': cache_lines, 'repeat_receipt': repeat,
          'static_exits': {row['name']: row['exit'] for row in static['jobs']}, 'dirty_diff_headers': diff_headers,
          'required_gates_passed': False,
          'limits': 'Recorded observations only. 65 ERROR headers are not globally waived. No Java/native replay or source diagnosis.'}
(B / 'RESULT-AUDIT-01.json').write_bytes((json.dumps(output, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'logs': {name: {'complete': row['completion']['total'], 'required_failures': row['required_failure_summary']['failures'], 'error_headers': row['error_header_count']} for name, row in observations.items()},
                  'controls': controls.testsRun, 'old_junit': [1785, 333], 'new_junit': [1807, 339], 'added_testcases': 22,
                  'static_exits': output['static_exits'], 'repeat_exit': repeat['exit'], 'repeat_generated': repeat['files'], 'repeat_changes': len(repeat['changed'])}))
