"""Seal only this auditor's small loose reports/probes, never sources or JARs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

B = Path(__file__).resolve().parent
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
R = Path('D:/GitHub/AdvancedRocketry-Community')
H = '9fce551ea9389ce37a94f804aa0e817399586a7e'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
pin = lambda raw: {'bytes': len(raw), 'sha256': sha(raw)}
def write(name, obj):
    p = B / name
    assert not p.exists(), name
    p.write_bytes((json.dumps(obj, indent=2) + '\n').encode('utf-8'))

intake = json.loads((B / 'INPUT-PINS-02.json').read_bytes())
results = json.loads((B / 'RESULT-AUDIT-01.json').read_bytes())
artifact = json.loads((B / 'SOURCE-ARTIFACT-AUDIT-01.json').read_bytes())
post = json.loads((B / 'POSTCHECK-03.json').read_bytes())
assert all(row['major'] == 61 for row in artifact['class_source_metadata'])
unchanged = {**intake['files'], **results['old_junit_input_pins']}
assert len(unchanged) == 729
assert all(pin(Path(name).read_bytes()) == wanted for name, wanted in unchanged.items())
cleanup = F / 'RUNTIME-CLEANUP-TOOL-FAILURE-01.md'
write('SUPPLEMENT-01.json', {'path': str(cleanup), 'pin': pin(cleanup.read_bytes()),
    'attribution': 'Separately authored Root note, not auditor-observed OS inventory/deletion; no cleanup replay or post-abort runtime filesystem inspection.',
    'effect_on_command_results': 'none'})
commands = [
    ('intake01.py', 'intake-01', 1, 'Reviewer receipt-field mismatch; no output manifest produced.'),
    ('intake02.py', 'intake-02', 0, 'Exact name/exit/seconds/log receipt match; pins and XML recounted.'),
    ('source_artifacts01.py', 'source-artifacts-01', 0, 'Named fixed-Git and actual JAR member/source mapping.'),
    ('results01.py', 'results-01', 0, 'Three failed GT logs, actual XML names/counts and eight parser controls.'),
    ('postcheck01.py', 'postcheck-01', 1, 'Five controls/one failed expected exception class; later postcheck not reached.'),
    ('postcheck02.py', 'postcheck-02', 1, 'Five controls pass; later mandatory-doc guessed locator missing.'),
    ('postcheck03.py', 'postcheck-03', 0, 'Five controls pass plus 729 immutable and 3036 current raw named postcheck.'),
]
rows = []
for helper, label, expected, scope in commands:
    rc = int((B / (label + '.exit')).read_text().strip())
    assert rc == expected
    rows.append({'argv': ['python', '-B', str(B / helper)], 'cwd': str(R),
                 'environment': {key: str(B / 'process-temp') for key in ('TEMP', 'TMP', 'TMPDIR')},
                 'helper': pin((B / helper).read_bytes()), 'log': pin((B / (label + '.log')).read_bytes()),
                 'exit_file': pin((B / (label + '.exit')).read_bytes()), 'actual_exit': rc, 'scope': scope})
write('COMMANDS-01.json', {'record': 'Actual completed reviewer helper invocations; no elapsed duration invented.',
                         'commands': rows, 'java_gradle_native_launches': 0, 'git_mutations': 0})
gt_path = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
raw = subprocess.check_output(['git', 'show', H + ':' + gt_path], cwd=R)
needles = ('disabledUnavailableAndInvalidUsesDoNotQueryOrMutate', 'suppliedEyeCellKeepsAmbientAndQueriesDoNotSpendVentResources',
           'incompleteBudgetedRoomReportsPendingWithoutPositiveSupplyOrQueryTick', 'unloadedEyeRefusesWithoutCreatingTicketsOrAtmosphereService',
           'Unknown eye queried', 'Eye-cell supply', 'Incomplete scan')
write('FIXED-TEST-LOCATIONS-01.json', {'fixed_commit': H, 'path': gt_path, 'source_pin': pin(raw),
    'source_observation_lines': [{'line': n, 'text': text} for n, text in enumerate(raw.decode('utf-8').splitlines(), 1) if any(needle in text for needle in needles)],
    'qualification': 'Method/assertion location only, not diagnosis or source acceptance.'})
write('FREEZE-RESULT-01.json', {'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'fixed_source_commit': H, 'report': pin((B / 'REPORT-01.md').read_bytes()),
    'immutable_inputs_rechecked_at_freeze': len(unchanged), 'immutable_input_drift': 0,
    'supplemental_root_note': pin(cleanup.read_bytes()),
    'final_independent_controls': {'terminal_log': 8, 'boundary_crc_hash': 5, 'failures': 0, 'errors': 0},
    'original_reviewer_failure_exits_preserved': ['intake-01.exit', 'postcheck-01.exit', 'postcheck-02.exit'],
    'required_gates_passed': False, 'no_source_jar_world_exports': True})
excluded = {'INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'finalize-01.log', 'finalize-01.exit'}
files = {}
for p in sorted(B.iterdir()):
    if p.is_dir():
        assert p.name == 'process-temp' and not p.is_symlink()
        continue
    if p.name in excluded:
        continue
    attrs = p.lstat()
    assert stat.S_ISREG(attrs.st_mode) and not p.is_symlink() and not getattr(attrs, 'st_file_attributes', 0) & 0x400
    files[p.name] = pin(p.read_bytes())
total = sum(row['bytes'] for row in files.values())
assert total < 1_000_000 and all(row['bytes'] < 50_000_000 for row in files.values())
write('INTERNAL-MANIFEST.json', {'layout': 'Small loose evidence only. files binds every payload. Manifest and SHA256SUMS metadata excluded from files; no ZIP/source/JAR/runtime export.',
    'files': files, 'payload_files': len(files), 'payload_bytes': total,
    'excluded_seal_console_files': ['finalize-01.log', 'finalize-01.exit']})
manifest_pin = pin((B / 'INTERNAL-MANIFEST.json').read_bytes())
sums = ''.join(row['sha256'] + '  ' + name + '\n' for name, row in sorted({**files, 'INTERNAL-MANIFEST.json': manifest_pin}.items()))
assert not (B / 'SHA256SUMS.txt').exists()
(B / 'SHA256SUMS.txt').write_bytes(sums.encode('utf-8'))
assert all(pin((B / name).read_bytes()) == row for name, row in files.items())
print(json.dumps({'directory': str(B), 'report': pin((B / 'REPORT-01.md').read_bytes()),
    'manifest': manifest_pin, 'sha256sums': pin((B / 'SHA256SUMS.txt').read_bytes()),
    'payload_files': len(files), 'payload_bytes': total,
    'immutable_named_evidence_inputs': 730,
    'status': 'Recorded failed GT preserved; evidence-only audit, no source/runtime/Gate approval.'}))
