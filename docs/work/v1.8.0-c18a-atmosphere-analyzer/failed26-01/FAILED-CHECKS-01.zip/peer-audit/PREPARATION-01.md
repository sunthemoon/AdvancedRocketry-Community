# Analyzer full-result audit preparation

Role: independent result auditor, not analyzer source implementer. Fixed tested
commit: `9fce551ea9389ce37a94f804aa0e817399586a7e`.

Own write scope: this small fresh external D directory only, with process-local
TEMP/TMP/TMPDIR in its process-temp and Python `-B`. Repository/source/Git/config,
old evidence and source worlds are read-only. No Java/Gradle/GameTest/native/client
execution, process termination, deletion, external classpath export or full tree
archive is permitted. Root owns integration, status and publication.

The actual full/post terminal notifications are not yet received. No result,
source count, artifact hash, failure disposition or Gate result is inferred.
Runtime files/logs in progress will not be treated as final evidence.

After notification, independently check only named immutable inputs:

- Declared Source26 raw manifest, old named boundaries, exact added leaf, fixed
  commit object equality and explicitly recorded AGENTS/wrapper qualifications.
- Fresh build and GameTest command/exits/raw logs, JUnit XML counts, input
  postchecks and any original orchestration/collector/test failures.
- Named main/sources/API artifacts, resource/source mappings and all actual ZIP
  member additions/removals/changes, with compiler/reobfuscation qualifications
  where relevant; no copied JARs or source export.
- Repeat DataGen and ten static receipts, preserving failed/exception results
  rather than borrowing the previous cohort's successful checks.

Report evidence findings/limits separately from source acceptance, actual native
or player/client/GPU proof, ledger delivery and all version Required Gates.
