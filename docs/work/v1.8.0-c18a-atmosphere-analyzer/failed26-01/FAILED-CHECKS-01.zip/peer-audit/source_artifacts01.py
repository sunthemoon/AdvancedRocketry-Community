"""Independently bind named Git inputs and compare actual JAR bytes in memory."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import struct
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
O = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01')
H = '9fce551ea9389ce37a94f804aa0e817399586a7e'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
pin = lambda data: {'bytes': len(data), 'sha256': sha(data)}
old = json.loads((O / 'SOURCE25-MANIFEST-01.json').read_bytes())
new = json.loads((F / 'SOURCE26-MANIFEST-01.json').read_bytes())
boundary = json.loads((F / 'SOURCE26-BOUNDARY-01.json').read_bytes())

def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '\\' not in name and ':' not in name and '..' not in p.parts and '\x00' not in name

assert len(old) == 3009 and len(new) == 3036
assert all(safe(name) for name in new)
added = sorted(set(new) - set(old))
removed = sorted(set(old) - set(new))
changed = {name: {'previous': old[name], 'current': new[name]} for name in sorted(set(new) & set(old)) if new[name] != old[name]}
assert removed == [] and added == boundary['new_named_inputs']
assert changed == boundary['changed_from_prior_cohort']
assert boundary['tested_commit'] == H
batch = ''.join(H + ':' + name + '\n' for name in sorted(new)).encode('utf-8')
argv = ['git', 'cat-file', '--batch']
proc = subprocess.run(argv, input=batch, cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
data, offset, git = proc.stdout, 0, {}
for name in sorted(new):
    end = data.index(b'\n', offset)
    object_id, kind, size = data[offset:end].split()
    assert kind == b'blob'
    size = int(size)
    raw = data[end + 1:end + 1 + size]
    assert len(raw) == size and data[end + 1 + size:end + 2 + size] == b'\n'
    git[name] = raw
    offset = end + 2 + size
assert offset == len(data)
qualifications = {}
exact = 0
for name, raw in git.items():
    if pin(raw) == new[name]:
        exact += 1
    else:
        q = boundary['git_qualifications'][name]
        assert pin(raw) == {'bytes': q['git_bytes'], 'sha256': q['git_sha256']}
        assert new[name] == q['live']
        if name == 'gradlew.bat':
            assert b'\r' not in raw and pin(raw.replace(b'\n', b'\r\n')) == new[name]
        else:
            assert name == 'AGENTS.md'
        qualifications[name] = q
assert exact == 3034 and set(qualifications) == {'AGENTS.md', 'gradlew.bat'}

def class_source(raw):
    """Read class-level SourceFile; never compare reobfuscated bytes to javac output."""
    pos = 0
    def take(n):
        nonlocal pos
        assert n >= 0 and pos + n <= len(raw)
        part = raw[pos:pos + n]
        pos += n
        return part
    def u(n):
        return int.from_bytes(take(n), 'big')
    assert u(4) == 0xCAFEBABE
    minor, major, count = u(2), u(2), u(2)
    cp, i = {}, 1
    while i < count:
        tag = u(1)
        if tag == 1:
            cp[i] = take(u(2))
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8)
            i += 1
        elif tag in (7, 8, 16, 19, 20):
            cp[i] = u(2)
        elif tag in (9, 10, 11, 12, 17, 18):
            take(4)
        elif tag == 15:
            take(3)
        else:
            raise AssertionError(('constant-pool tag', tag))
        i += 1
    access, self_index, parent = u(2), u(2), u(2)
    take(u(2) * 2)
    for _group in range(2):
        for _ in range(u(2)):
            take(6)
            for _attribute in range(u(2)):
                take(2)
                take(u(4))
    source_file, attrs = None, []
    for _ in range(u(2)):
        label = cp[u(2)].decode('ascii')
        content = take(u(4))
        attrs.append(label)
        if label == 'SourceFile':
            assert len(content) == 2 and source_file is None
            source_file = cp[int.from_bytes(content, 'big')].decode('ascii')
    assert pos == len(raw) and source_file is not None
    return {'class_name': cp[cp[self_index]].decode('ascii'), 'source_file': source_file,
            'major': major, 'minor': minor, 'class_attributes': attrs}

artifacts = json.loads((F / 'ARTIFACTS-01.json').read_bytes())
rows = []
metadata = []
source_count = generated_count = 0
for name in sorted(artifacts):
    with zipfile.ZipFile(O / 'artifacts-01' / name) as zold, zipfile.ZipFile(F / 'artifacts-01' / name) as znew:
        maps = []
        for archive in (zold, znew):
            info = archive.infolist()
            assert len(info) == len({entry.filename for entry in info})
            assert all(safe(entry.filename.rstrip('/')) for entry in info)
            assert archive.testzip() is None
            maps.append({entry.filename: archive.read(entry) for entry in info if not entry.is_dir()})
        a, b = maps
        plus = sorted(set(b) - set(a))
        minus = sorted(set(a) - set(b))
        delta = sorted(member for member in set(a) & set(b) if a[member] != b[member])
        observed = {'artifact': name, 'old_raw_entries': len(zold.infolist()), 'new_raw_entries': len(znew.infolist()),
                    'old_members': len(a), 'new_members': len(b), 'added': plus, 'removed': minus, 'changed': delta,
                    'unchanged_regular_members': len(set(a) & set(b)) - len(delta),
                    'crc_ok_both': True, 'duplicate_names_both': 0,
                    'delta_payload_pins': {member: {'old': pin(a[member]) if member in a else None,
                                                   'new': pin(b[member]) if member in b else None} for member in sorted(set(plus + minus + delta))}}
        root = json.loads((F / ('ARTIFACT-OBSERVATION-' + ('api' if '-api.' in name else 'sources' if '-sources.' in name else 'main') + '-01.json')).read_bytes())
        assert {key: observed[key] for key in root} == root
        assert not minus
        if '-api.' in name:
            assert not plus and not delta
            assert (O / 'artifacts-01' / name).read_bytes() == (F / 'artifacts-01' / name).read_bytes()
        else:
            matched_generated = 0
            for path in sorted(new):
                if path.startswith('src/generated/v1.8/resources/'):
                    member = path[len('src/generated/v1.8/resources/'):]
                    assert member in b and pin(b[member]) == new[path] and b[member] == git[path], path
                    matched_generated += 1
            assert matched_generated == 781
            observed['generated_v18_matched'] = matched_generated
            if '-sources.' in name:
                count = 0
                for path in sorted(new):
                    if path.startswith('src/main/java/'):
                        member = path[len('src/main/java/'):]
                        assert member in b and b[member] == git[path] and pin(b[member]) == new[path], path
                        count += 1
                source_count = count
                observed['all_named_main_java_matched'] = count
            else:
                for member in plus + delta:
                    if member.endswith('.class'):
                        record = class_source(b[member])
                        assert record['class_name'] + '.class' == member
                        source_path = 'src/main/java/' + str(PurePosixPath(member).parent / record['source_file'])
                        assert source_path in git and source_path in set(added) | set(changed)
                        metadata.append({'member': member, 'derived_source': source_path,
                                         'source_sha256': new[source_path]['sha256'], **record})
                observed['new_or_changed_classes_sourcefile_mapped'] = len(metadata)
        rows.append(observed)

out = {'fixed_commit': H, 'old_named_inputs': len(old), 'new_named_inputs': len(new),
       'old_named_removed': removed, 'new_named_added': added, 'old_named_changed': changed,
       'fixed_git_exact_inputs': exact, 'git_raw_qualifications': qualifications,
       'git_command': {'argv': argv, 'stdin': pin(batch), 'stdout': pin(proc.stdout), 'stderr': pin(proc.stderr), 'exit': proc.returncode},
       'artifacts': rows, 'class_source_metadata': metadata,
       'main_java_frozen_sources_jar_byte_matches': source_count,
       'claim_limit': 'Class SourceFile mapping is not equivalence to javac pre-reobfuscation output, runtime/native/client proof or whole-repository equality.'}
(B / 'SOURCE-ARTIFACT-AUDIT-01.json').write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'fixed_git_exact': exact, 'qualified': sorted(qualifications), 'named_added': len(added), 'named_changed': len(changed),
    'source_jar_java_matches': source_count, 'class_sourcefile_mappings': len(metadata),
    'artifact_counts': [{key: row[key] for key in ('artifact', 'old_raw_entries', 'new_raw_entries', 'old_members', 'new_members', 'unchanged_regular_members')} for row in rows]}))
