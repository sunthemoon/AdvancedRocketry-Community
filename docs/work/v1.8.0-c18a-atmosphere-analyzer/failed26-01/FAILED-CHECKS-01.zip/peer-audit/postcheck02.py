"""Preserve failed postcheck01; align its CRC control with testzip's result API."""
import hashlib
from pathlib import Path

base = Path(__file__).resolve().parent
raw = (base / 'postcheck01.py').read_bytes()
source = raw.decode('utf-8')
old = 'with self.assertRaises(zipfile.BadZipFile): zip_control(broken)'
new = 'with self.assertRaises(AssertionError): zip_control(broken)'
assert source.count(old) == 1
source = source.replace(old, new).replace('POSTCHECK-01.json', 'POSTCHECK-02.json')
# Only the reviewer output name changes; Root receipt locator stays literal.
source = source.replace("'SOURCE26-POSTCHECK-02.json'", "'SOURCE26-POSTCHECK-01.json'")
print('Historical helper SHA256:', hashlib.sha256(raw).hexdigest())
print('CRC remains refused: ZipFile.testzip returns the corrupt member name; the wrapper asserts None.')
exec(compile(source, str(base / 'postcheck01.py') + '[crc-exception-correction]', 'exec'))
