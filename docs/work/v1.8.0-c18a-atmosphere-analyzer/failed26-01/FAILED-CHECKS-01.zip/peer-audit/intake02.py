"""Correct the reviewer receipt-shape check without modifying failed intake01."""
import hashlib
from pathlib import Path

base = Path(__file__).resolve().parent
original = (base / 'intake01.py').read_bytes()
source = original.decode('utf-8')
old = "    assert receipt == {key: item[key] for key in ('exit', 'log', 'seconds')}"
new = "    assert set(receipt) == {'exit', 'log', 'name', 'seconds'}\n    assert receipt == {key: item[key] for key in ('exit', 'log', 'name', 'seconds')}"
assert source.count(old) == 1
source = source.replace(old, new).replace("INPUT-PINS-01.json", "INPUT-PINS-02.json")
print('Historical helper SHA256:', hashlib.sha256(original).hexdigest())
print('Correction: compare the actual exact receipt including name; no result field omitted.')
exec(compile(source, str(base / 'intake01.py') + '[receipt-shape-correction]', 'exec'))
