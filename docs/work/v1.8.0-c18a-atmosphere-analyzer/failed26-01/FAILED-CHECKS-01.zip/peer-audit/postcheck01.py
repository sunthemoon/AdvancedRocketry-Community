"""Post-pin immutable named inputs; observe current raw docs without changing them."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import unittest
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
H = '9fce551ea9389ce37a94f804aa0e817399586a7e'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
pin = lambda raw: {'bytes': len(raw), 'sha256': sha(raw)}

def canonical_name(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and name == p.as_posix() and name != '.' and not any(char in name for char in ('\\', ':', '\x00', '\n', '\r')) and '..' not in p.parts

def zip_control(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names = [entry.filename for entry in z.infolist()]
        assert len(names) == len(set(names)) and all(canonical_name(name) for name in names)
        assert z.testzip() is None

def archive(names):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', compression=zipfile.ZIP_STORED) as z:
        for name in names:
            z.writestr(name, b'content')
    return b.getvalue()

class BoundaryControls(unittest.TestCase):
    def test_valid_relative_archive(self): zip_control(archive(['a/b.txt']))
    def test_traversal_and_absolute_refused(self):
        for name in ('../b', '/b', 'D:/b', 'a\\b', '.', 'a//b', 'a/./b', 'a\nb'):
            with self.subTest(name=name): self.assertFalse(canonical_name(name))
    def test_duplicate_zip_names_refused(self):
        with self.assertRaises(AssertionError): zip_control(archive(['a', 'a']))
    def test_corrupted_stored_member_refused(self):
        raw = archive(['a'])
        broken = raw.replace(b'content', b'Content', 1)
        with self.assertRaises(zipfile.BadZipFile): zip_control(broken)
    def test_same_length_mutation_pin_differs(self): self.assertNotEqual(pin(b'content'), pin(b'Content'))

controls = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BoundaryControls))
assert controls.wasSuccessful()
intake = json.loads((B / 'INPUT-PINS-02.json').read_bytes())
observations = json.loads((B / 'RESULT-AUDIT-01.json').read_bytes())
all_inputs = {**intake['files'], **observations['old_junit_input_pins']}
immutable_drift = {}
for path, expected in all_inputs.items():
    p = Path(path)
    attr = p.lstat()
    assert not p.is_symlink() and stat.S_ISREG(attr.st_mode) and not getattr(attr, 'st_file_attributes', 0) & 0x400
    observed = pin(p.read_bytes())
    if observed != expected:
        immutable_drift[path] = {'expected': expected, 'observed': observed}
assert not immutable_drift
source = json.loads((F / 'SOURCE26-MANIFEST-01.json').read_bytes())
assert all(canonical_name(path) for path in source)
live_observations = {}
live_drift = {}
for path, expected in source.items():
    p = R / path
    attr = p.lstat()
    assert not p.is_symlink() and stat.S_ISREG(attr.st_mode) and not getattr(attr, 'st_file_attributes', 0) & 0x400
    observed = pin(p.read_bytes())
    if observed != expected:
        live_drift[path] = {'expected': expected, 'observed': observed}
for name in ('SOURCE26-POSTCHECK-01.json', 'POST-CHECKS-01.json'):
    claimed = json.loads((F / name).read_bytes())
    assert claimed['named_inputs'] == 3036 and claimed['mismatches'] == [] and claimed['required_gates_passed'] is False
scope = json.loads((F / 'POST-CHECK-SCOPE-01.json').read_bytes())
assert scope['tested_commit'] == H and scope['full_command_exits'] == [0, 1]
assert scope['these_checks_do_not_reclassify_gametest_failure'] is True
mandatory = ('AGENTS.md', 'PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
             'docs/04-VERSION-ROADMAP.md', 'docs/versions/v1.8.0.md', 'docs/05-MASTER-TEST-PLAN.md',
             'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md', 'docs/16-POST-1.0-VERSION-ROADMAP.md',
             'docs/17-V1PLUS-QUALITY-BUDGETS.md', 'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md')
for path in mandatory:
    raw = (R / path).read_bytes()
    live_observations[path] = pin(raw)
commit = subprocess.run(['git', 'cat-file', 'commit', H], cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
paths = subprocess.run(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', H], cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
named_commit_changes = paths.stdout.decode('utf-8').splitlines()
assert len(named_commit_changes) == 37
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip()
output = {'immutable_inputs_postchecked': len(all_inputs), 'immutable_input_drift': immutable_drift,
          'current_named_raw_inputs_observed': len(source), 'current_named_raw_drift': live_drift,
          'current_doc_input_pins': live_observations,
          'fixed_commit': H, 'observed_current_head': head,
          'git_object_observation': {'argv': ['git', 'cat-file', 'commit', H], 'stdout': pin(commit.stdout), 'stderr': pin(commit.stderr), 'exit': commit.returncode},
          'fixed_commit_changed_paths': named_commit_changes,
          'changed_commit_paths_outside_named_manifest': sorted(set(named_commit_changes) - set(source)),
          'fixed_commit_changes': 37,
          'reviewer_boundary_controls': {'tests': controls.testsRun, 'failures': len(controls.failures), 'errors': len(controls.errors)},
          'qualification': 'Current raw doc movement is not retroactive command evidence; fixed 9fce object equality and immutable receipts are authoritative for the observed cohort.'}
(B / 'POSTCHECK-01.json').write_bytes((json.dumps(output, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'immutable_inputs': len(all_inputs), 'immutable_drift': len(immutable_drift), 'named_raw_inputs': len(source),
                  'live_drift': sorted(live_drift), 'reviewer_boundary_controls': controls.testsRun, 'head_at_postcheck': head,
                  'fixed_commit_changed_paths_outside_named': output['changed_commit_paths_outside_named_manifest']}))
