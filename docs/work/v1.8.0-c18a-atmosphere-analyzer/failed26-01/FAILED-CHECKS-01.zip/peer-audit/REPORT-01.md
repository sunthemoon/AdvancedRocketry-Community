# Source26 analyzer full-result audit

## Findings and disposition

1. **Blocking recorded verification failure:** the required GameTest command
   failed on the exact committed Source26 cohort. The console completion at
   `gametest-01.log:5628-5633` is **477 complete, four required failures**, not a
   passing analyzer run. Its outer Gradle result is 1; its console reports child
   Java exit 4 at line 5668. The latest and debug logs independently agree. All
   three final progress boards contain 473 `+` and four `X`; this does not make
   the failed command pass. First reports in the console are:

   | Line | Required test | Actual reported failure |
   | --- | --- | --- |
   | 2271 | `unloadedeyerefuseswithoutcreatingticketsoratmosphereservice` | `Unknown eye queried an atmosphere service` |
   | 2281 | `disabledunavailableandinvalidusesdonotqueryormutate` | `Registry is already frozen` |
   | 2297 | `incompletebudgetedroomreportspendingwithoutpositivesupplyorquerytick` | `Incomplete scan made a positive or unknown ambient claim` |
   | 2299 | `suppliedeyecellkeepsambientandqueriesdonotspendventresources` | `Eye-cell supply was confused with feet or ambient profile` |

   Their fixed-commit test methods start at lines 306, 96, 215 and 163,
   respectively, of `src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java`.
   This audit establishes the observed failures, not whether their eventual
   correction belongs in a fixture, service or adapter. Source acceptance and
   a corrective implementation require a separate review/new cohort. The
   successful build, repeat DataGen and later post-driver cannot overwrite this
   failed result.

2. **Existing delivery failure remains:** `ledger-closure-01.log:1-2` explicitly
   reports 186 PLANNED rows and 154 REVIEW assets; the closure command exits 1.
   `dirty-diff-01.log:1` is a separate exit-1 diff of owner-maintained AGENTS.md.
   Their declared expected exit values preserve those failures; they are not
   passing checks or permission to close v1.8. The other eight scoped static
   commands exit zero. No new full-repository 45-check run is present in this
   cohort and none is borrowed from Source24/25.

3. **Log qualification, not an additional inferred source defect:** each fresh
   GT log contains 65 ERROR headers. Exact messages and line numbers are retained
   in `RESULT-AUDIT-01.json`; no blanket clean-log waiver is applied. Console
   groups are four actual LogTestReporter failures; 16 NetworkRegistry version
   rejection headers; 30 EventBus headers (24 oversized-recipe refusal, one
   oversized-combustion refusal, three explicitly named Energy-only save failures
   and two explicitly named one-shot Precision failures); five ChunkMap save
   failures; three recipe-tag unbound messages; three Precision saved-root
   mismatch messages; and four satellite operation failures. Message labels
   such as `Intentional` identify reported text only; this audit does not newly
   approve their production severity or a global exception policy.

No additional discrepancy was identified in the independently measured named
source boundary, fresh XML counts, terminal receipts or actual packaged member
diffs. This is **evidence consistency**, not analyzer source approval, runtime
success, release approval or a Required Gate pass.

## Exact scope and input identities

- Fixed tested source commit: `9fce551ea9389ce37a94f804aa0e817399586a7e`.
  Current HEAD was still this commit at this auditor's final named-input check;
  fixed Git object reads, not a movable HEAD, determine the source comparisons.
- Root cohort: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01`.
- Prior comparison only: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01`,
  Source25 at `a5abc34809891d6b10724ee60ab9b5e97f036bae`.
- Own write scope: this external D directory only. All process-local
  TEMP/TMP/TMPDIR settings point to its `process-temp`; Python uses `-B`.
  Repository, old packets, JARs, configs and source worlds remain read-only.
  No Java, Gradle, Minecraft, native/client replay, Git mutation, deletion,
  network, private-directory traversal or whole-source/JAR export was performed.
- `INPUT-PINS-02.json` pins 396 named current/prior receipts, logs, artifacts and
  fresh XML. `RESULT-AUDIT-01.json` additionally pins 333 prior XML files.
  `POSTCHECK-03.json` rechecks all **729 immutable inputs**, with zero drift.
  It also observes all **3,036** named current raw inputs with zero drift at
  that check. These are named-input observations, not a whole-repository claim.

## Source and Git/raw boundary

Independent flat-manifest comparison gives prior 3,009, current 3,036, **27
added, 11 changed, zero removed**. The changed set includes two earlier SETUP05
Python paths; they must not be mislabelled as analyzer Java author changes.
The source publication commit itself changes 37 paths; three publication docs
(`CURRENT_VERSION`, `COMPLETION-PLAN`, implementation log) are outside this
named source manifest. A 37-path commit and a 38-path cross-cohort union are
different comparisons, not a contradictory file count.

Bounded `git cat-file --batch` on exactly the 3,036 named paths at fixed 9fce
confirms **3,034 literal Git/raw matches**, plus two explicit qualifications:

| Input | Fixed Git bytes / SHA256 | Observed raw bytes / SHA256 |
| --- | --- | --- |
| `AGENTS.md` | 8,379 / `725dd46344046bcdb802872e08fbc3cd9da0bf876e680eeba4c82dda801a9503` | 12,047 / `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0` |
| `gradlew.bat` | 2,776 / `18774a0ac0203f6893bf1db3291a0d77f06cd1b4dca2a43b51e7009da3e28cfa` | 2,868 / `8e327fcb99d29ce0fe3ee2fec6e6a25de815a2df83a6a44a553dea89ffc92955` |

AGENTS is separately owner-maintained and excluded from staging. The wrapper's
raw hash is exactly reproduced by expanding every LF of its LF-only fixed Git
blob to CRLF; the manifest is not normalized or rewritten. Exact paths pass
canonical relative-name checks; each queried object is an actual Git blob.
Mandatory project/version/quality/parallel doc pins are recorded separately in
`POSTCHECK-03.json`, with the actual version document named
`docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md`.

## Independently measured command results

| Recorded Root command/result | Actual result |
| --- | --- |
| `clean build test runData` | exit 0; 172.10858170001302 s; raw `BUILD SUCCESSFUL` |
| Fresh JUnit XML | 1,807 testcase elements / 339 suites / 0 failures, errors or skips |
| `runGameTestServer` | exit 1; 235.94495620008092 s; 477 complete / four required failed |
| Repeat `runData` | exit 0; 22.326915799989365 s; 781 observed generated files / zero reported before-after changes |
| Ten scoped static commands | eight exit 0, closure exit 1, dirty-diff exit 1 |

Both full-build and GT command receipts bind Java 17, offline/no-daemon,
max-workers 2, 2-GiB heap, task-local D temporary paths and recorded C/D free
space above the 10,000,000,000-byte threshold. This auditor did not replay those
commands. Their result receipts include the exact `name`, `exit`, `seconds`
and raw log pin, all checked against FULL-CHECKS.

The 339 current XML files are individually parsed; suite attributes agree with
actual testcase/failure/error/skipped elements. Prior XML independently contains
1,785 tests / 333 suites. No old testcase name is removed; the new cohort adds
22 testcase names in six suites. This is name/count retention, not a fresh
review of all assertion bodies. Both original build and repeat DataGen logs
contain their own `HashCache` line reporting total files 781 and written 0;
the repeat manifest says `changed=[]`. Frozen generated bytes also match both
JARs and fixed Git, as below. This auditor did not repeat generation itself.

`POST-CHECK-SCOPE-01.json` explicitly binds full exits `[0,1]` and says post
checks do not reclassify GT failure. `run_post01.py` allows terminal GT exit 1
for evidence collection; its successful tail is not a successful full run.
All Root source postcheck receipts explicitly retain `required_gates_passed=false`.

## Actual artifact comparison, without a prefilled allowlist

All six named old/new JARs pass CRC and duplicate-name checks. Member additions,
removals and byte differences were recomputed before comparing Root's collector.

| Artifact | Old -> new regular members | Added / changed / removed | Old -> new raw ZIP entries |
| --- | --- | --- | --- |
| main | 3,040 -> 3,060 | 20 / 10 / 0 | 3,323 -> 3,344 |
| sources | 2,392 -> 2,405 | 13 / 8 / 0 | 2,676 -> 2,690 |
| API | 35 -> 35 | 0 / 0 / 0 | 48 -> 48 |

Main additions are four analyzer resources and 16 class files. Main changes
are two language resources and eight class files. Sources additions are those
four resources and nine Java sources; changes are the two languages and six
central Java sources. All other old regular member payloads are byte-identical:
3,030 main members and 2,384 sources members. Directory entries are separately
counted and are not silently included in regular-member counts.

All **781** named v1.8 generated resources match fixed Git and the main/sources
JARs literally. All **1,226** named main Java files match fixed Git and sources
JAR payloads. The 24 new/changed main classes have actual class-level SourceFile
metadata mapping to the corresponding new/changed frozen Java inputs, including
compiler-generated `$1`, enum/nested classes and the GameTest `$NoMenu` class.
They are Java 17 class files. This is source/member attribution, not proof that
packaged classes equal pre-reobfuscation `build/classes` bytes or a bytecode
semantic equivalence proof; Forge packaging/reobfuscation must not be ignored.

| Frozen new artifact | Bytes | SHA256 |
| --- | --- | --- |
| main | 5,509,422 | `ba33be072bc9da427975d52ff351dce0ded9f36d88af7904980885f0280176a8` |
| sources | 2,652,897 | `6e6b289fc6185cc0a7e90eef1e4f5e90c91a89df7fa77bef3f8592eef05587eb` |
| API | 51,045 | `7484de1d50ffca610328200a838ff47cc8480ea72b37e964e772178325c749da` |

The entire API JAR is byte-identical to the named Source25 comparison, not just
its selected public members. All artifact/source/member metadata is in
`SOURCE-ARTIFACT-AUDIT-01.json`; no JAR/source export was made.

## Auditor commands and preserved failures

Every command below is `python -B <own helper>` with process-local D temp.
Actual raw logs and numeric exit files remain in this bundle:

| Helper | Exit / result | Preservation and correction |
| --- | --- | --- |
| `intake01.py` | 1 | Reviewer incorrectly required a three-field result receipt; actual receipt also has `name`. No Root result defect inferred. |
| `intake02.py` | 0 | Exact four-field receipt checked; old helper/log/exit retained. |
| `source_artifacts01.py` | 0 | Independent fixed-Git/raw/JAR/SourceFile mapping; no allowlist first supplied to measurement. |
| `results01.py` | 0 | Actual logs/XML/repeat/static audited; eight parser controls pass. |
| `postcheck01.py` | 1 | Reviewer CRC negative control expected BadZipFile, but testzip returns the bad member and the wrapper raises AssertionError; four of five methods passed. |
| `postcheck02.py` | 1 | All five controls passed; later mandatory-doc lookup failed because the guessed `docs/versions/v1.8.0.md` does not exist. |
| `postcheck03.py` | 0 | Correct actual version-doc locator and exact CRC-wrapper refusal, old two failures preserved; five controls and complete post-pin check pass. |

The final **13 distinct independent controls** are eight terminal-log controls
and five boundary/CRC/hash controls. They refuse missing/duplicate/inconsistent
completion, nested fake logger, other-thread claims, mismatched failure list,
traversal/noncanonical paths, duplicate ZIP names, corrupt member bytes and
same-size content mutation. Repeated executions are not added to that distinct
count. A duplicate-name warning is deliberately produced by a reviewer-only
in-memory negative fixture, not an actual JAR warning. No original Root assertion,
timeout, test or budget was changed.

Bounded PowerShell/Git/Python read-only inspections additionally read the named
receipts, four first failure messages, fixed test-method locations, mandatory
version path and original result shapes. Their observations are supported by
the pinned original logs/Git-derived metadata, not by invented execution receipts.

## Supplemental cleanup observation and remaining limits

Root later added only `RUNTIME-CLEANUP-TOOL-FAILURE-01.md`. Its reported literal
PowerShell cleanup was rejected by policy before OS/preflight/deletion execution;
the note says deleted bytes/files zero and size unmeasured. This is separately
pinned in `SUPPLEMENT-01.json`, not evidence of cleaned runtime state and not
a test failure reclassification. This auditor did not inspect/delete runtime
files, kill processes or bypass the rejected operation.

Completion scope: independent evidence audit of recorded Source26 source/Git
qualifications, build/XML, failed GT, repeat DataGen, ten static commands,
actual JAR/member/resource preservation and named input postchecks.
No repository/source/config/status change was made.

Unverified/not completed here: analyzer source correction or source self-review;
Java/GT/native replay; actual two-host/player behavior, real client/GPU visuals;
new native/restart/crash proof; tutorial ownership fixture runtime; GuardTicket
or save/lifecycle admission; ledger closure, R-021 closure and whole-version
Required Gates. Successful automatic checks do not imply those outcomes.

Recommended minimal follow-up: retain this failed fixed-commit cohort, separately
diagnose all four required failures, review any fixture/production correction
without weakening its assertions or budgets, then run a newly committed cohort.
Root alone integrates/publishes status and determines acceptance; this audit does
not change any version state.
