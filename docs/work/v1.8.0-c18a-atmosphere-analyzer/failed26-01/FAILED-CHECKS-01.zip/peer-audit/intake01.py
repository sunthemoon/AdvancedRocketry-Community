"""Pin named terminal Source26 evidence; no source/runtime/artifact export."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import xml.etree.ElementTree as ET

B = Path(__file__).resolve().parent
TEMP = B / 'process-temp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
R = Path('D:/GitHub/AdvancedRocketry-Community')
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
O = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01')
H = '9fce551ea9389ce37a94f804aa0e817399586a7e'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}

def pin(path):
    assert not path.is_symlink()
    attributes = path.lstat()
    assert stat.S_ISREG(attributes.st_mode) and not getattr(attributes, 'st_file_attributes', 0) & 0x400
    raw = path.read_bytes()
    result = {'bytes': len(raw), 'sha256': sha(raw)}
    files[str(path)] = result
    return raw

names = (
    'SOURCE26-MANIFEST-01.json', 'SOURCE26-BOUNDARY-01.json', 'SOURCE26-POSTCHECK-01.json',
    'FULL-CHECKS-01.json', 'full-build-01.command.json', 'full-build-01.result.json', 'full-build-01.log',
    'full-driver-01.log', 'JUNIT-01.json', 'gametest-01.command.json', 'gametest-01.result.json',
    'gametest-01.log', 'gametest-01-latest.log', 'gametest-01-debug.log', 'GAMETEST-01.json',
    'run_full01.py', 'run_post01.py', 'post-driver-01.log', 'POST-CHECK-SCOPE-01.json',
    'POST-CHECKS-01.json', 'repeat-data-01.command.json', 'repeat-data-01.log', 'REPEAT-DATAGEN-01.json',
    'STATIC-RESULTS-01.json', 'ARTIFACTS-01.json', 'ARTIFACT-MEMBER-AUDIT-01.json',
    'ARTIFACT-OBSERVATION-main-01.json', 'ARTIFACT-OBSERVATION-sources-01.json', 'ARTIFACT-OBSERVATION-api-01.json',
)
for name in names:
    pin(F / name)
static = json.loads((F / 'STATIC-RESULTS-01.json').read_bytes())
assert len(static['jobs']) == 10
for job in static['jobs']:
    command_raw = pin(F / (job['name'] + '-01.command.json'))
    log_raw = pin(F / (job['name'] + '-01.log'))
    assert job['log'] == {'bytes': len(log_raw), 'sha256': sha(log_raw)}
source_old = json.loads(pin(O / 'SOURCE25-MANIFEST-01.json'))
pin(O / 'ARTIFACTS-01.json')
pin(O / 'ARTIFACT-MEMBER-AUDIT-01.json') if (O / 'ARTIFACT-MEMBER-AUDIT-01.json').exists() else None
artifacts = json.loads((F / 'ARTIFACTS-01.json').read_bytes())
old_artifacts = json.loads((O / 'ARTIFACTS-01.json').read_bytes())
for name, wanted in artifacts.items():
    data = pin(F / 'artifacts-01' / name)
    assert files[str(F / 'artifacts-01' / name)] == wanted
    prior = pin(O / 'artifacts-01' / name)
    assert files[str(O / 'artifacts-01' / name)] == old_artifacts[name]
totals = {'tests': 0, 'suites': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
suite_records = []
for path in sorted((F / 'junit-01').iterdir()):
    assert path.suffix == '.xml'
    raw = pin(path)
    suite = ET.fromstring(raw)
    assert suite.tag == 'testsuite'
    testcases = suite.findall('testcase')
    assert len(testcases) == int(suite.attrib['tests'])
    observed = {'tests': len(testcases)}
    for key, tag in (('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')):
        observed[key] = sum(len(case.findall(tag)) for case in testcases)
        assert observed[key] == int(suite.attrib.get(key, '0')), (path, key)
    totals['suites'] += 1
    for key in observed:
        totals[key] += observed[key]
    suite_records.append({'file': path.name, 'name': suite.attrib['name'], **observed,
                          'bytes': len(raw), 'sha256': sha(raw)})
assert totals == json.loads((F / 'JUNIT-01.json').read_bytes())
full = json.loads((F / 'FULL-CHECKS-01.json').read_bytes())
assert full['tested_commit'] == H
assert [item['exit'] for item in full['commands']] == [0, 1]
for item in full['commands']:
    log = (F / (item['name'] + '.log')).read_bytes()
    assert item['log'] == {'bytes': len(log), 'sha256': sha(log)}
    receipt = json.loads((F / (item['name'] + '.result.json')).read_bytes())
    assert receipt == {key: item[key] for key in ('exit', 'log', 'seconds')}
    command = json.loads((F / (item['name'] + '.command.json')).read_bytes())
    assert command['tested_commit'] == H
    assert all(value >= command['threshold_bytes'] for value in command['free_bytes'].values())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip()
commit_paths = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', H], cwd=R).decode().splitlines()
out = {'scope': 'Terminal Source26 named inputs and independently counted XML only, not whole repository/native/source acceptance.',
    'fixed_source_commit': H, 'observed_current_head': head, 'files': files,
    'commit_paths': commit_paths, 'commit_path_count': len(commit_paths), 'old_named_manifest_inputs': len(source_old),
    'new_named_manifest_inputs': len(json.loads((F / 'SOURCE26-MANIFEST-01.json').read_bytes())),
    'actual_junit_counts': totals, 'suites': suite_records, 'full_command_exits': [0, 1],
    'java_native_commands_executed_by_reviewer': 0}
(B / 'INPUT-PINS-01.json').write_bytes((json.dumps(out, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'named_result_artifact_xml_files_pinned': len(files), 'actual_junit_counts': totals,
    'commit_path_count': len(commit_paths), 'observed_head': head, 'old_named_inputs': len(source_old),
    'new_named_inputs': out['new_named_manifest_inputs'], 'full_command_exits': [0, 1]}))
