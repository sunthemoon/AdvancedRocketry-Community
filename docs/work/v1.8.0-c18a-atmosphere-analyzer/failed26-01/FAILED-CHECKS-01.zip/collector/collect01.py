"""Capture only the named failed Source26 evidence groups; no result admission."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import unittest
import xml.etree.ElementTree as ET
import zipfile
import zlib

B = Path(__file__).resolve().parent
T = B / 'process-temp'
T.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(T)
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
A = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-result-audit-b8154b0a71')
C = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-cleanup-770814f9da')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')
H = '9fce551ea9389ce37a94f804aa0e817399586a7e'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
pin = lambda raw: {'bytes': len(raw), 'sha256': sha(raw)}
inputs, payload, groups = {}, {}, {}

def safe(name):
    p = PurePosixPath(name)
    return bool(name) and name != '.' and not p.is_absolute() and name == p.as_posix() and '..' not in p.parts and not any(char in name for char in ('\\', ':', '\x00', '\r', '\n'))

def read_regular(path):
    a = path.lstat()
    assert path.is_file() and not path.is_symlink() and stat.S_ISREG(a.st_mode) and not getattr(a, 'st_file_attributes', 0) & 0x400
    assert a.st_size <= 50_000_000
    raw = path.read_bytes()
    assert len(raw) == a.st_size
    return raw

def add(group, path, relative):
    name = group + '/' + relative
    assert safe(relative) and safe(name) and name not in payload and str(path) not in inputs
    raw = read_regular(path)
    inputs[str(path)] = {'member': name, **pin(raw)}
    payload[name] = raw
    groups.setdefault(group, []).append(name)

def verify_pin(raw, wanted):
    if pin(raw) != wanted:
        raise ValueError('Payload digest/length does not match frozen pin')

def verify_zip(raw, wanted):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = [info.filename for info in archive.infolist()]
        if len(names) != len(set(names)) or set(names) != set(wanted) or not all(safe(name) for name in names):
            raise ValueError('Archive name set/uniqueness/canonical scope mismatch')
        if archive.testzip() is not None:
            raise ValueError('Archive CRC mismatch')
        for info in archive.infolist():
            raw_member = archive.read(info)
            verify_pin(raw_member, {key: wanted[info.filename][key] for key in ('bytes', 'sha256')})
            if info.CRC != wanted[info.filename]['crc32']:
                raise ValueError('Recorded CRC mismatch')

def fixture(names):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', compression=zipfile.ZIP_STORED) as z:
        for name in names:
            z.writestr(name, b'fixed content')
    return b.getvalue()

class Controls(unittest.TestCase):
    def test_exact_pin_accepts(self): verify_pin(b'a', pin(b'a'))
    def test_same_size_mutation_refuses(self):
        with self.assertRaises(ValueError): verify_pin(b'b', pin(b'a'))
    def test_wrong_length_refuses(self):
        with self.assertRaises(ValueError): verify_pin(b'aa', pin(b'a'))
    def test_traversal_and_noncanonical_refuse(self):
        for name in ('../a', '/a', 'D:/a', 'a\\b', 'a//b', '.', 'a\nb'):
            self.assertFalse(safe(name))
    def test_missing_and_extra_archive_member_refuse(self):
        with self.assertRaises(ValueError): verify_zip(fixture(['a']), {})
    def test_duplicate_archive_member_refuses(self):
        with self.assertRaises(ValueError): verify_zip(fixture(['a', 'a']), {})
    def test_corrupt_member_refuses(self):
        raw = fixture(['a']).replace(b'fixed content', b'Fixed content', 1)
        wanted = {'a': {**pin(b'fixed content'), 'crc32': zlib.crc32(b'fixed content') & 0xFFFFFFFF}}
        with self.assertRaises(ValueError): verify_zip(raw, wanted)

control = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
assert control.wasSuccessful()

# Capture the exact current regular-file inventory, no recursive top-level walk.
full_top = [p for p in sorted(F.iterdir()) if p.is_file()]
full_dirs = [p.name for p in sorted(F.iterdir()) if p.is_dir()]
assert set(full_dirs) == {'artifacts-01', 'junit-01', 'process-temp'}
assert all(p.suffix != '.jar' for p in full_top)
for path in full_top:
    add('full', path, path.name)
xmls = list(sorted((F / 'junit-01').iterdir()))
assert all(path.is_file() and path.suffix == '.xml' for path in xmls)
for path in xmls:
    add('full', path, 'junit-01/' + path.name)

# The original audit manifest and sidecar are frozen and must agree exactly.
audit_manifest_raw = read_regular(A / 'INTERNAL-MANIFEST.json')
assert sha(audit_manifest_raw) == 'e075c9c57ed8fff56f41bdc34840273ed4c1c8b8ade46b82f73959477d63533c'
audit = json.loads(audit_manifest_raw)
assert len(audit['files']) == audit['payload_files'] == 32
for relative, wanted in sorted(audit['files'].items()):
    assert safe(relative)
    add('peer-audit', A / relative, relative)
    verify_pin(payload['peer-audit/' + relative], wanted)
assert sum(row['bytes'] for row in audit['files'].values()) == audit['payload_bytes'] == 570657
add('peer-audit', A / 'INTERNAL-MANIFEST.json', 'INTERNAL-MANIFEST.json')
add('peer-audit', A / 'SHA256SUMS.txt', 'SHA256SUMS.txt')
sums = payload['peer-audit/SHA256SUMS.txt'].decode('utf-8').splitlines()
checksum_rows = {}
for line in sums:
    digest, relative = line.split('  ', 1)
    assert re.fullmatch(r'[0-9a-f]{64}', digest) and safe(relative) and relative not in checksum_rows
    checksum_rows[relative] = digest
assert set(checksum_rows) == set(audit['files']) | {'INTERNAL-MANIFEST.json'}
assert all(sha(payload['peer-audit/' + name]) == digest for name, digest in checksum_rows.items())
assert sha(payload['peer-audit/SHA256SUMS.txt']) == 'ed519886ea8d72b2f653601dc3a600997f4c4c8cb3219e674e00e04d415495c8'

# Cleanup metadata is actually ten payloads + one manifest, not an invented sidecar.
cleanup_raw = read_regular(C / 'INTERNAL-MANIFEST.json')
assert sha(cleanup_raw) == '992a2e389b90ae3eef8e9b3be8290a14fc0d7783289ae93f458c7a5d207ebafe'
cleanup = json.loads(cleanup_raw)
assert len(cleanup['files']) == 10
assert len({row['name'] for row in cleanup['files']}) == 10
for row in cleanup['files']:
    assert safe(row['name'])
    add('author-cleanup', C / row['name'], row['name'])
    verify_pin(payload['author-cleanup/' + row['name']], {key: row[key] for key in ('bytes', 'sha256')})
add('author-cleanup', C / 'INTERNAL-MANIFEST.json', 'INTERNAL-MANIFEST.json')
assert sum(row['bytes'] for row in cleanup['files']) == 29020
assert {p.name for p in C.iterdir()} == {row['name'] for row in cleanup['files']} | {'INTERNAL-MANIFEST.json'}
assert sha(payload['author-cleanup/REPORT-01.md']) == '9bb741c30ffc1e218570fac2ba54e242060f384c971125ee89f4d1e14cda9dda'

# Select only the explicitly authorized publication prefix and helper/note.
extra = {'SOURCE-PUBLICATION-01.json', 'SOURCE-PUBLICATION-COMMANDS-01.json', 'publish-source01.py', 'source-publisher-01.log', 'SCRATCH-CLEANUP-01.md'}
publication_files = [p for p in sorted(P.iterdir()) if p.is_file() and (p.name in extra or re.fullmatch(r'source-publish-command-\d{2}\.(?:stdout|stderr)', p.name))]
assert extra <= {p.name for p in publication_files}
for path in publication_files:
    add('root-publication', path, path.name)
publication = json.loads(payload['root-publication/SOURCE-PUBLICATION-01.json'])
commands = json.loads(payload['root-publication/SOURCE-PUBLICATION-COMMANDS-01.json'])
assert len(publication['paths']) == len(set(publication['paths'])) == 37
assert publication['commit'] == publication['remote_commit'] == H
assert publication['required_gates_passed'] is False
command_raw_names = set()
for row in commands:
    for key in ('stdout', 'stderr'):
        relative = row[key]
        assert re.fullmatch(r'source-publish-command-\d{2}\.' + key, relative)
        assert 'root-publication/' + relative in payload
        command_raw_names.add(relative)
assert command_raw_names == {p.name for p in publication_files} - extra

# Actual current terminal results stay FAILED after packaging.
full = json.loads(payload['full/FULL-CHECKS-01.json'])
assert full['tested_commit'] == H and [row['exit'] for row in full['commands']] == [0, 1]
for row in full['commands']:
    verify_pin(payload['full/' + row['name'] + '.log'], row['log'])
    result = json.loads(payload['full/' + row['name'] + '.result.json'])
    assert result == {key: row[key] for key in ('name', 'exit', 'log', 'seconds')}
counts = {'tests': 0, 'suites': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
for path in xmls:
    parent = ET.fromstring(payload['full/junit-01/' + path.name])
    assert parent.tag == 'testsuite'
    cases = parent.findall('testcase')
    assert len(cases) == int(parent.attrib['tests'])
    counts['tests'] += len(cases)
    counts['suites'] += 1
    for key, element in (('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')):
        actual = sum(len(case.findall(element)) for case in cases)
        assert actual == int(parent.attrib.get(key, '0'))
        counts[key] += actual
assert counts == json.loads(payload['full/JUNIT-01.json'])
console = payload['full/gametest-01.log'].decode('utf-8')
complete = re.findall(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/INFO\] \[minecraft/GameTestServer\]: =+ (\d+) GAME TESTS COMPLETE =+$', console, re.M)
required = re.findall(r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/INFO\] \[minecraft/GameTestServer\]: (\d+) required tests failed :\($', console, re.M)
assert complete == ['477'] and required == ['4']
static = json.loads(payload['full/STATIC-RESULTS-01.json'])
assert {(row['name'], row['exit']) for row in static['jobs'] if row['exit']} == {('ledger-closure', 1), ('dirty-diff', 1)}
for row in static['jobs']:
    verify_pin(payload['full/' + row['name'] + '-01.log'], row['log'])

# An exact snapshot of every selected input is checked a second time.
assert all(pin(read_regular(Path(name))) == {key: row[key] for key in ('bytes', 'sha256')} for name, row in inputs.items())
source_lists = {group: sorted(names) for group, names in groups.items()}
collection = {'scope': 'Copy-only failed Source26 publication evidence collection; not execution, source acceptance, native proof or Gate admission.',
    'fixed_source_commit': H, 'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_groups': {group: {'files': len(names), 'bytes': sum(len(payload[name]) for name in names)} for group, names in sorted(groups.items())},
    'source_lists': source_lists, 'full_top_regular_files': len(full_top), 'full_xml_files': len(xmls),
    'sealed_peer_audit': {'payload_files': 32, 'payload_bytes': 570657, 'metadata_files': 2, 'all_hashes_verified': True},
    'sealed_author_cleanup': {'payload_files': 10, 'payload_bytes': 29020, 'metadata_files': 1, 'all_hashes_verified': True,
        'qualification': 'Root requested two metadata files on a count assumption, then confirmed the actual one-manifest layout. No missing author sidecar was generated or sought.'},
    'root_publication': {'paths': len(publication['paths']), 'commands': len(commands), 'nonzero_recorded_command_exits': [row for row in commands if row['exit']]},
    'actual_terminal_results': {'full_command_exits': [0, 1], 'junit': counts, 'gametest_complete': 477, 'required_failed': 4,
        'static_exits': {row['name']: row['exit'] for row in static['jobs']}, 'required_gates_passed': False},
    'collector_controls': {'tests': control.testsRun, 'failures': len(control.failures), 'errors': len(control.errors)},
    'input_postcheck': {'files': len(inputs), 'drift': []},
    'excluded': ['full/artifacts-01 JARs', 'full/process-temp', 'all runtime/world files', 'whole Root source/tree',
                 'author61/review74/old Root-intermediate20 already in SOURCE-CHECKS packet',
                 'peer-audit finalize-01.log/exit declared outside the sealed 32-payload manifest',
                 'publication __pycache__/process-temp/intermediate-01-xml and all nonauthorized prefix files'],
    'cleanup_claim_limit': 'Root/author-reported tool rejection retained; collection itself does not prove OS execution, target removal or host emptiness.',
    'no_java_gradle_native_network_git_mutation_deletion': True}
report_raw = (json.dumps(collection, indent=2) + '\n').encode('utf-8')
assert not (B / 'COLLECTION-REPORT-01.json').exists()
(B / 'COLLECTION-REPORT-01.json').write_bytes(report_raw)
payload['collector/COLLECTION-REPORT-01.json'] = report_raw
payload['collector/collect01.py'] = read_regular(Path(__file__))
records = {name: {**pin(raw), 'crc32': zlib.crc32(raw) & 0xFFFFFFFF} for name, raw in sorted(payload.items())}
manifest = {'scope': collection['scope'], 'fixed_source_commit': H, 'files': records,
    'payload_files': len(records), 'payload_bytes': sum(len(raw) for raw in payload.values()), 'source_groups': collection['source_groups'],
    'inputs': inputs, 'input_postcheck': {'files': len(inputs), 'drift': []},
    'manifest_self_excluded': True, 'required_gates_passed': False, 'no_artifacts_runtime_whole_source_export': True}
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
assert manifest['payload_bytes'] < 100_000_000
assert not (B / 'INTERNAL-MANIFEST.json').exists()
(B / 'INTERNAL-MANIFEST.json').write_bytes(manifest_raw)
payload['INTERNAL-MANIFEST.json'] = manifest_raw
records['INTERNAL-MANIFEST.json'] = {**pin(manifest_raw), 'crc32': zlib.crc32(manifest_raw) & 0xFFFFFFFF}
target = B / 'FAILED-CHECKS-01.zip'
assert not target.exists()
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, raw in sorted(payload.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 5, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o100644 << 16)
        archive.writestr(info, raw)
verify_zip(read_regular(target), records)
assert all(pin(read_regular(Path(name))) == {key: row[key] for key in ('bytes', 'sha256')} for name, row in inputs.items())
zip_pin = pin(read_regular(target))
sidecar = B / 'FAILED-CHECKS-01.sha256'
assert not sidecar.exists()
sidecar.write_bytes((zip_pin['sha256'] + '  ' + target.name + '\n').encode('ascii'))
result = {'archive': str(target), **zip_pin, 'entries': len(records), 'expanded_bytes': sum(row['bytes'] for row in records.values()),
    'internal_manifest': pin(manifest_raw), 'collection_report': pin(report_raw), 'sidecar': pin(sidecar.read_bytes()),
    'crc_all_members_verified': True, 'unique_member_names': True, 'all_member_sha256_bytes_verified': True,
    'input_postcheck_files': len(inputs), 'input_drift': 0, 'source_groups': collection['source_groups'],
    'actual_results_stay_failed': True, 'required_gates_passed': False}
assert not (B / 'COLLECTION-RESULT-01.json').exists()
(B / 'COLLECTION-RESULT-01.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
print(json.dumps(result))
