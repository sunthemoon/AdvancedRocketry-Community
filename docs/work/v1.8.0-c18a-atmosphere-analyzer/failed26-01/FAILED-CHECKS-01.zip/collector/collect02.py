"""Versioned collector correction: observe LF/CRLF lines; package raw bytes intact."""
import hashlib
from pathlib import Path

B = Path(__file__).resolve().parent
raw = (B / 'collect01.py').read_bytes()
source = raw.decode('utf-8')
function = r'''
def observed_terminal_counts(text):
    prefix = r'^\[\d{2}:\d{2}:\d{2}\] \[Server thread/INFO\] \[minecraft/GameTestServer\]: '
    lines = text.splitlines()
    completed = [m[1] for line in lines if (m := re.fullmatch(prefix + r'=+ (\d+) GAME TESTS COMPLETE =+', line))]
    failed = [m[1] for line in lines if (m := re.fullmatch(prefix + r'(\d+) required tests failed :\(', line))]
    return completed, failed

'''
assert source.count('class Controls(unittest.TestCase):') == 1
source = source.replace('class Controls(unittest.TestCase):', function + 'class Controls(unittest.TestCase):')
methods = '''    def test_lf_terminal_observation(self):
        prefix = '[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: '
        fixture = prefix + '========= 2 GAME TESTS COMPLETE =========\\n' + prefix + '1 required tests failed :(\\n'
        self.assertEqual(observed_terminal_counts(fixture), (['2'], ['1']))
    def test_crlf_terminal_observation_same_without_byte_rewrite(self):
        prefix = '[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: '
        fixture = prefix + '========= 2 GAME TESTS COMPLETE =========\\r\\n' + prefix + '1 required tests failed :(\\r\\n'
        before = fixture.encode('utf-8')
        self.assertEqual(observed_terminal_counts(fixture), (['2'], ['1']))
        self.assertEqual(fixture.encode('utf-8'), before)
'''
assert source.count('    def test_exact_pin_accepts(self):') == 1
source = source.replace('    def test_exact_pin_accepts(self):', methods + '    def test_exact_pin_accepts(self):')
start = source.index('complete = re.findall(')
end = source.index("\nassert complete == ['477'] and required == ['4']", start)
assert len(source[start:end].splitlines()) == 2
source = source[:start] + 'complete, required = observed_terminal_counts(console)' + source[end:]
old = "payload['collector/collect01.py'] = read_regular(Path(__file__))"
new = """for relative in ('collect01.py', 'collect02.py', 'collect-01.log', 'collect-01.exit'):
    payload['collector/' + relative] = read_regular(B / relative)
assert int(payload['collector/collect-01.exit'].decode('utf-8').strip()) == 1"""
assert source.count(old) == 1
source = source.replace(old, new)
old = "    'collector_controls': {'tests': control.testsRun, 'failures': len(control.failures), 'errors': len(control.errors)},"
new = old + "\n    'collector_prior_failure': {'helper': 'collect01.py', 'exit': 1, 'cause': 'Reviewer multiline-dollar regex did not match console CRLF; failed before any output ZIP or manifest. New splitlines/fullmatch observation leaves archived raw bytes unchanged.', 'helper_sha256': sha(read_regular(B / 'collect01.py'))},"
assert source.count(old) == 1
source = source.replace(old, new)
print('Historical helper SHA256:', hashlib.sha256(raw).hexdigest())
print('Correction changes terminal observation only; no normalization of archived bytes or result reclassification.')
exec(compile(source, str(B / 'collect01.py') + '[line-ending-observation-correction]', 'exec'))
