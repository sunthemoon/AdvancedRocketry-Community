# First preflight helper failure

The first PowerShell preflight stopped at line 33 before any deletion command:

```text
Where-Object: preflight.ps1:33
Method invocation failed because [System.Object[]] does not contain a method named 'op_BitwiseAnd'.
```

The helper accidentally nested its entry array while checking reparse attributes.
Its original bytes are retained in `preflight-failed-01.ps1.txt`. The corrected
helper concatenates two flat arrays and explicitly compares UTC timestamps.
No target deletion was attempted in this failed preflight; the original tool
exception is not a deletion refusal or native exit code. No sealed/source file
was changed.
