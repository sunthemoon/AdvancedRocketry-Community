$ErrorActionPreference = 'Stop'
$Output = $PSScriptRoot
$env:TEMP=$Output; $env:TMP=$Output; $env:TMPDIR=$Output
$Worktree='D:/GitHub/arce-v180-c18a-analyzer-20261005'
$Root='D:/GitHub/AdvancedRocketry-Community'
$Evidence='D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8'
$Build=(Get-Item -LiteralPath "$Worktree/build" -Force).FullName
$Perf=(Get-Item -LiteralPath "$Evidence/hsperfdata_Administrator" -Force).FullName
if ($Build -ne 'D:\GitHub\arce-v180-c18a-analyzer-20261005\build') { throw 'Unexpected resolved build path' }
if ($Perf -ne 'D:\GitHub\ARCE-Task-Evidence\v1.8.0\c18-analyzer-author-4a2d730bc8\hsperfdata_Administrator') { throw 'Unexpected resolved perf path' }
if ((Get-FileHash -LiteralPath "$Evidence/INTERNAL-MANIFEST.json").Hash.ToLower() -ne 'd9b53421547e16b24da6491cb73da0f8f73ed50992d2c71b4c8331711df8057c') { throw 'Sealed manifest identity differs' }
$Verified=@()
foreach ($Line in Get-Content -LiteralPath "$Evidence/SHA256SUMS.txt") {
    $Match=[regex]::Match($Line,'^([0-9a-f]{64})  (.+)$')
    if(-not $Match.Success){throw 'Invalid checksum line'}
    $Name=$Match.Groups[2].Value
    if($Name.Contains('..') -or [IO.Path]::IsPathRooted($Name)){throw 'Invalid payload path'}
    $Path=Join-Path $Evidence $Name
    if ((Get-FileHash -LiteralPath $Path).Hash.ToLower() -ne $Match.Groups[1].Value) { throw "Payload drift $Name" }
    $Verified += $Name
}
if(@($Verified | Where-Object {$_ -like 'hsperfdata_Administrator*'}).Count -ne 0){throw 'Perf target contains sealed evidence'}
$Own=Get-Content -LiteralPath "$Evidence/OWNED-FILES-01.json" -Raw | ConvertFrom-Json
$Source=@()
foreach($Property in $Own.files.PSObject.Properties){
    $Name=$Property.Name; $Expected=$Property.Value.sha256
    $Author=(Get-FileHash -LiteralPath (Join-Path $Worktree $Name)).Hash.ToLower()
    $Imported=(Get-FileHash -LiteralPath (Join-Path $Root $Name)).Hash.ToLower()
    if($Author -ne $Expected -or $Imported -ne $Expected){throw "Author/imported postimage differs $Name"}
    $Source += @{path=$Name;author=$Author;imported=$Imported}
}
$Entries=@(Get-ChildItem -LiteralPath $Build -Recurse -Force)
$AllEntries=@(Get-Item -LiteralPath $Build -Force) + $Entries
$Reparse=@($AllEntries | Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0})
if($Reparse.Count -ne 0){throw 'Build contains reparse entries'}
if(@(Get-ChildItem -LiteralPath $Perf -Force).Count -ne 0){throw 'Perf target is not empty'}
if(((Get-Item -LiteralPath $Perf -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Perf is a reparse point'}
$Processes=@(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='javaw.exe' OR Name='gradle.exe'")
$Active=@($Processes | Where-Object {$_.CommandLine -like '*arce-v180-c18a-analyzer-20261005*' -or $_.CommandLine -like '*c18-analyzer-author-4a2d730bc8*'})
if($Active.Count -ne 0){throw 'Analyzer process remains active'}
$Round=Get-Content -LiteralPath "$Evidence/scoped-01-result.json" -Raw | ConvertFrom-Json
$Creation=(Get-Item -LiteralPath $Build).CreationTimeUtc
$Started=if($Round.started -is [DateTime]){$Round.started.ToUniversalTime()}else{[DateTimeOffset]::Parse($Round.started).UtcDateTime}
$Ended=if($Round.ended -is [DateTime]){$Round.ended.ToUniversalTime()}else{[DateTimeOffset]::Parse($Round.ended).UtcDateTime}
if($Creation -lt $Started -or $Creation -gt $Ended){throw 'Build creation not within author round01'}
$XML=@()
foreach($File in Get-ChildItem -LiteralPath "$Worktree/build/test-results/test" -Filter '*.xml'){
    $Copy=Join-Path "$Evidence/scoped-03-xml" $File.Name
    if((Get-FileHash -LiteralPath $File.FullName).Hash -ne (Get-FileHash -LiteralPath $Copy).Hash){throw 'Latest XML is not preserved'}
    $XML += $File.Name
}
$Receipt=@{targets=@(@{absolute=$Build;regularFiles=@($Entries|Where-Object{-not $_.PSIsContainer}).Count;bytes=($Entries|Where-Object{-not $_.PSIsContainer}|Measure-Object Length -Sum).Sum;reparseCount=0;createdWithinAuthorRound01=$true},
    @{absolute=$Perf;regularFiles=0;bytes=0;empty=$true;notManifested=$true}); sealedChecksumFiles=$Verified.Count;sourcePostimages=$Source;
    latestXMLPreserved=$XML;knownAnalyzerProcesses=0;unrelatedJava=@($Processes|Select-Object ProcessId,CreationDate,CommandLine);
    disks=@(Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:' OR DeviceID='D:'"|Select-Object DeviceID,FreeSpace)}
$Receipt|ConvertTo-Json -Depth 7|Set-Content -LiteralPath "$Output/PREFLIGHT-03.json" -Encoding utf8
Write-Output "Verified $($Verified.Count) sealed checksum files and $($Source.Count) author/Root postimages; disposable build $($Receipt.targets[0].bytes) bytes"
