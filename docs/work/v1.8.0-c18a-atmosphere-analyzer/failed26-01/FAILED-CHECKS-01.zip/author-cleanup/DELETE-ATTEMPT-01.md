# Native deletion attempt

The single submitted PowerShell command contained these exact destructive calls,
after checking the absolute targets and active analyzer processes:

```powershell
Remove-Item -LiteralPath 'D:/GitHub/arce-v180-c18a-analyzer-20261005/build' -Recurse -Force
Remove-Item -LiteralPath 'D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8/hsperfdata_Administrator' -Force
```

Actual tool result at CreateProcess, before OS execution:

```text
Script error:
exec_command failed: CreateProcess
Rejected(... rejected: blocked by policy)
```

The tool's echoed full command was truncated in its diagnostic. There is no native
exit code, no executed Remove-Item result and no DELETE-RESULT-01.json. Both
submitted targets were stopped after this one refusal; no alternative tool,
shell, helper invocation or filesystem API was tried. Actual deleted files and
discarded file bytes are zero. Read-only postchecks verify the targets and all
sealed/source files remain.
