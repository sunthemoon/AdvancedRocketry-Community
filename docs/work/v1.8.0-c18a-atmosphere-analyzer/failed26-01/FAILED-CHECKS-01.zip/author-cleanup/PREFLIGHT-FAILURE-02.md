# Second preflight helper failure

Actual command exit 1, before any deletion:

```text
Exception: preflight.ps1:43
Build creation not within author round01
```

PowerShell ConvertFrom-Json had already converted the timestamp fields to
DateTime. Passing those objects through a string parser dropped the timezone.
The unchanged raw round is 16:51:03.0888729Z to 16:51:58.3126634Z and the actual
directory creation is 16:51:15.3665629Z. The corrected helper normalizes DateTime
objects directly with ToUniversalTime; it still requires that exact ownership
window. Original helper bytes are preserved in `preflight-failed-02.ps1.txt`.
No deletion was attempted, no ownership check was waived and no policy rejection
was bypassed.
