$ErrorActionPreference='Stop'
$Output=$PSScriptRoot
$env:TEMP=$Output;$env:TMP=$Output;$env:TMPDIR=$Output
$Evidence='D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8'
$Worktree='D:/GitHub/arce-v180-c18a-analyzer-20261005'
$Root='D:/GitHub/AdvancedRocketry-Community'
$Checks=0
foreach($Line in Get-Content -LiteralPath "$Evidence/SHA256SUMS.txt"){
    $Match=[regex]::Match($Line,'^([0-9a-f]{64})  (.+)$')
    if(-not $Match.Success){throw 'Invalid sealed checksum'}
    if((Get-FileHash -LiteralPath (Join-Path $Evidence $Match.Groups[2].Value)).Hash.ToLower() -ne $Match.Groups[1].Value){throw 'Sealed payload changed'}
    $Checks++
}
$Own=Get-Content -LiteralPath "$Evidence/OWNED-FILES-01.json" -Raw|ConvertFrom-Json
$Sources=0
foreach($File in $Own.files.PSObject.Properties){
    if((Get-FileHash -LiteralPath (Join-Path $Worktree $File.Name)).Hash.ToLower() -ne $File.Value.sha256){throw 'Author source changed'}
    if((Get-FileHash -LiteralPath (Join-Path $Root $File.Name)).Hash.ToLower() -ne $File.Value.sha256){throw 'Root imported postimage changed'}
    $Sources++
}
$Build=Get-Item -LiteralPath "$Worktree/build"
$Files=@(Get-ChildItem -LiteralPath $Build.FullName -Recurse -Force|Where-Object{-not $_.PSIsContainer})
@{deletedFiles=0;discardedFileBytes=0;deletionOutcome='TOOL_POLICY_REJECTED_BEFORE_OS';sealedChecksumEntriesUnchanged=$Checks;
    authorAndRootPostimagesUnchanged=$Sources;buildRemains=@{path=$Build.FullName;regularFiles=$Files.Count;bytes=($Files|Measure-Object Length -Sum).Sum};
    emptyPerfRemains=(Test-Path -LiteralPath "$Evidence/hsperfdata_Administrator");
    disks=@(Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:' OR DeviceID='D:'"|Select-Object DeviceID,FreeSpace)}|
    ConvertTo-Json -Depth 5|Set-Content -LiteralPath "$Output/POSTCHECK-01.json" -Encoding utf8
Get-Content -LiteralPath "$Output/POSTCHECK-01.json"
