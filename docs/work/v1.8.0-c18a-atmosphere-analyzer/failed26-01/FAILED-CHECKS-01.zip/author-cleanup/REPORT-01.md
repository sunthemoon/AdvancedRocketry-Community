# Analyzer author-output cleanup result

Outcome: TOOL_POLICY_BLOCKED, before OS deletion. Actual removed files: **0**.
Actual discarded file bytes: **0**. No alternate deletion method was attempted.

## Targets checked

- `D:/GitHub/arce-v180-c18a-analyzer-20261005/build`: 3,608 regular files,
  54,471,846 bytes; exact resolved path inside the assigned isolated worktree,
  no reparse entries. Its creation at 16:51:15.3665629Z falls within the author's
  recorded first compile window, 16:51:03.0888729Z–16:51:58.3126634Z. Latest test
  XML is byte-identical to the sealed scoped03 copies. The independent reviewer
  has finished and Root has imported all 17 postimages.
- `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8/hsperfdata_Administrator`:
  empty unmanifested process-temp directory, no reparse point. No sealed payload
  is inside this target. No other directory was authorized for deletion.

The author evidence manifest remains exactly
`d9b53421547e16b24da6491cb73da0f8f73ed50992d2c71b4c8331711df8057c`.
All 62 sealed checksum entries and all 17 author/Root imported source/task
postimages were independently checked before and after the attempt; unchanged.
No analyzer-related Java process was active. Two September-30 historical Java
processes were observed and left untouched; the host is not claimed empty.

## Executed actions and failures

- First preflight stopped on a nested PowerShell array attribute error. Second
  preflight exited 1 on timestamp coercion. Both helper versions/diagnostics are
  retained; neither contained or reached a deletion operation.
- Corrected preflight exited 0 and preserved the same path, reparse, ownership,
  source/evidence and process criteria; [receipt](PREFLIGHT-03.json).
- One native PowerShell LiteralPath deletion call was submitted for the two
  targets. The tool rejected CreateProcess as blocked by policy. There is no OS
  exit code and neither Remove-Item executed; [attempt record](DELETE-ATTEMPT-01.md).
- Read-only postcheck exited 0. Both targets remain, with the same build byte/file
  counts; [receipt](POSTCHECK-01.json). C free: 10,288,979,968 bytes. D free:
  339,184,156,672 bytes. Those free-space observations are not deletion gains.

The worktree's uncommitted source/task files, `.gradle` cache, all AA sealed
evidence, source worlds, Root files and other-agent output remain untouched.
No Git, Java/Gradle/native, process termination, network or cleanup workaround
ran. Root must coordinate the unfinished two-target cleanup through an allowed
mechanism; this report neither changes source acceptance nor any version Gate.
