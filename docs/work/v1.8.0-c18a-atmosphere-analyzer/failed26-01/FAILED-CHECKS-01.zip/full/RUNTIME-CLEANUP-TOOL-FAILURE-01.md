# Source26 stopped GameTest runtime cleanup rejection

Date: 2026-10-05. Root's completed command cohort is 9fce551e, with raw
latest/debug/console logs copied to this evidence directory. After termination,
Root submits a single native PowerShell command for its own exact
`D:/GitHub/AdvancedRocketry-Community/build/gametest` disposable runtime.
The command includes absolute workspace containment, non-reparse/entry checks,
inventory receipt and Remove-Item -LiteralPath -Recurse, followed by absence check.

exec_command returns CreateProcess Rejected: blocked by policy, before OS
execution. No preflight inventory/receipt or deletion actually executes. The
target remains, deleted files/bytes are zero; its size has not been measured by
that rejected command. No alternate shell/tool/helper retry is made. This is
separate from the successfully deleted new D helper bytecode file and from all
previous C/native/build cleanup rejections. Source worlds and sealed evidence
are not targeted or changed. No process is killed.
