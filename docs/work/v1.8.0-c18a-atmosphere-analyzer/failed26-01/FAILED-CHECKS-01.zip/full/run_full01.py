"""Fresh committed Source26 regression; actual results retained before assertions."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
HEAD = '9fce551ea9389ce37a94f804aa0e817399586a7e'
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01')
AI = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
TEMP = OUT / 'process-temp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(name, value):
    target = OUT / name
    assert not target.exists(), name
    target.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

def current_head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()

assert current_head() == HEAD
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
old_source = json.loads((OLD / 'SOURCE25-MANIFEST-01.json').read_bytes())
assert len(old_source) == 3009
source = {name: pin(ROOT / name) for name in old_source}
changed_prior = {name: {'previous': row, 'current': source[name]} for name, row in old_source.items() if source[name] != row}
owned = json.loads((AUTHOR / 'OWNED-FILES-01.json').read_bytes())['files']
central = json.loads((AI / 'ROOT-CENTRAL-01.json').read_bytes())['files']
named_additions = set(owned) | {row['path'] for row in central}
named_additions |= {name for name in json.loads((AI / 'GENERATED-POSTIMAGES-01.json').read_bytes()) if 'atmosphere_analyzer' in name}
named_additions |= {
    'docs/provenance/v1.8.0-c18a-analyzer-new-resources.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/REVIEW-DISPOSITION-01.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/SOURCE-REVIEW-DISPOSITION-01.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/SOURCE-INTEGRATION-01.md'}
new_named = sorted(named_additions - set(source))
source.update({name: pin(ROOT / name) for name in named_additions})
git_qualifications = {}
for name, row in source.items():
    committed = subprocess.check_output(['git', 'show', HEAD + ':' + name], cwd=ROOT)
    data = (ROOT / name).read_bytes()
    if committed != data:
        qualification = 'owner-maintained AGENTS live observation, excluded from staging' if name == 'AGENTS.md' else 'exact LF/CRLF expansion only'
        assert name == 'AGENTS.md' or committed.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), name
        git_qualifications[name] = {'qualification': qualification,
            'git_bytes': len(committed), 'git_sha256': hashlib.sha256(committed).hexdigest(), 'live': row}
save('SOURCE26-MANIFEST-01.json', source)
save('SOURCE26-BOUNDARY-01.json', {'tested_commit': HEAD, 'named_inputs': len(source),
    'not_whole_repository': True, 'new_named_inputs': new_named, 'changed_from_prior_cohort': changed_prior,
    'git_qualifications': git_qualifications, 'previous_full_cohort_commit': 'a5abc34809891d6b10724ee60ab9b5e97f036bae',
    'TEMP_TMP_TMPDIR': str(TEMP), 'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS'],
    'required_gates_passed': False})
flags = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
    '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix()]
jobs = [('full-build-01', flags + ['clean', 'build', 'test', 'runData']),
    ('gametest-01', flags + ['runGameTestServer'])]
rows = []
try:
    for label, command in jobs:
        assert current_head() == HEAD
        free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
        assert all(value >= 10_000_000_000 for value in free.values()), free
        save(label + '.command.json', {'command': command, 'cwd': str(ROOT),
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tested_commit': HEAD,
            'free_bytes': free, 'threshold_bytes': 10_000_000_000,
            'TEMP_TMP_TMPDIR': str(TEMP), 'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
        start = time.monotonic()
        with (OUT / (label + '.log')).open('xb') as log:
            process = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        row = {'name': label, 'exit': process.returncode, 'seconds': time.monotonic() - start,
            'log': pin(OUT / (label + '.log'))}
        rows.append(row)
        save(label + '.result.json', row)
        print(json.dumps(row), flush=True)
        if label == 'full-build-01':
            junit = OUT / 'junit-01'
            junit.mkdir()
            totals = dict(suites=0, tests=0, failures=0, errors=0, skipped=0)
            for path in sorted((ROOT / 'build/test-results/test').glob('TEST-*.xml')):
                shutil.copyfile(path, junit / path.name)
                suite = ET.parse(path).getroot()
                totals['suites'] += 1
                for key in ('tests', 'failures', 'errors', 'skipped'):
                    totals[key] += int(suite.attrib[key])
            save('JUNIT-01.json', totals)
            if process.returncode == 0:
                artifacts = OUT / 'artifacts-01'
                artifacts.mkdir()
                captured = {}
                for suffix in ('', '-sources', '-api'):
                    name = 'advancedrocketry-community-1.20.1-1.8.0-dev' + suffix + '.jar'
                    original = ROOT / 'build/libs' / name
                    shutil.copyfile(original, artifacts / name)
                    assert pin(original) == pin(artifacts / name)
                    captured[name] = pin(artifacts / name)
                save('ARTIFACTS-01.json', captured)
                assert totals == dict(suites=339, tests=1807, failures=0, errors=0, skipped=0), totals
        if label == 'gametest-01':
            for name in ('latest.log', 'debug.log'):
                original = ROOT / 'build/gametest/logs' / name
                if original.is_file():
                    shutil.copyfile(original, OUT / ('gametest-01-' + name))
            raw = (OUT / 'gametest-01.log').read_text(encoding='utf-8', errors='replace')
            passed = re.findall(r'All (\d+) required tests passed', raw)
            save('GAMETEST-01.json', {'command_exit': process.returncode, 'required_pass_reports': passed,
                'error_headers': len(re.findall(r'^.*\[[^\r\n]*ERROR\]', raw, re.MULTILINE)),
                'no_blanket_log_waiver': True})
            if process.returncode == 0:
                assert passed and all(value == '477' for value in passed), passed
        if process.returncode:
            break
finally:
    mismatches = [name for name, row in source.items() if not (ROOT / name).is_file() or pin(ROOT / name) != row]
    stable_head = current_head() == HEAD
    save('SOURCE26-POSTCHECK-01.json', {'named_inputs': len(source), 'mismatches': mismatches,
        'tested_head_unchanged': stable_head, 'required_gates_passed': False})
    save('FULL-CHECKS-01.json', {'commands': rows, 'tested_commit': HEAD,
        'source_unchanged': not mismatches and stable_head, 'required_gates_passed': False})
assert not mismatches and stable_head
assert len(rows) == 2
sys.exit(rows[-1]['exit'])
