"""Actual committed repeat/static/package checks, with open closure preserved."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
HEAD = '9fce551ea9389ce37a94f804aa0e817399586a7e'
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-integration-01/artifacts-01')
AI = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
TEMP = OUT / 'process-temp'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(name, value):
    target = OUT / name
    assert not target.exists(), name
    target.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == HEAD
source = json.loads((OUT / 'SOURCE26-MANIFEST-01.json').read_bytes())
assert all(pin(ROOT / name) == row for name, row in source.items())
full = json.loads((OUT / 'FULL-CHECKS-01.json').read_bytes())
assert len(full['commands']) == 2 and full['commands'][0]['exit'] == 0
assert full['commands'][1]['exit'] in (0, 1)
save('POST-CHECK-SCOPE-01.json', {'tested_commit': HEAD,
    'full_command_exits': [row['exit'] for row in full['commands']],
    'these_checks_do_not_reclassify_gametest_failure': True, 'required_gates_passed': False})
before = {path.relative_to(ROOT).as_posix(): pin(path) for path in (ROOT / 'src/generated/v1.8/resources').rglob('*')
          if path.is_file() and '.cache' not in path.parts}
command = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
    '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix(), 'runData']
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
save('repeat-data-01.command.json', {'command': command, 'cwd': str(ROOT), 'tested_commit': HEAD,
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'free_bytes': free,
    'TEMP_TMP_TMPDIR': str(TEMP), 'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
start = time.monotonic()
with (OUT / 'repeat-data-01.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
after = {path.relative_to(ROOT).as_posix(): pin(path) for path in (ROOT / 'src/generated/v1.8/resources').rglob('*')
         if path.is_file() and '.cache' not in path.parts}
changes = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
save('REPEAT-DATAGEN-01.json', {'exit': result.returncode, 'seconds': time.monotonic() - start,
    'files': len(after), 'changed': changes, 'log': pin(OUT / 'repeat-data-01.log')})
assert result.returncode == 0 and not changes and len(after) == 781
py = [sys.executable, '-B']
jobs = [
    ('common-client', py + ['scripts/check_client_imports.py'], 0),
    ('ledger-strict', py + ['scripts/validate_v180_content_ledger.py', '--require-accepted'], 0),
    ('ledger-closure', py + ['scripts/validate_v180_content_ledger.py', '--closure'], 1),
    ('planning', py + ['scripts/validate_v1plus_planning.py'], 0),
    ('provenance', py + ['scripts/validate_bootstrap_provenance.py', '--require-approved-review'], 0),
    ('machine-resources', py + ['scripts/validate_v120_machine_resources.py'], 0),
    ('artifact', py + ['scripts/validate_build_artifact.py', str(OUT / 'artifacts-01/advancedrocketry-community-1.20.1-1.8.0-dev.jar'),
        '--expected-version', '1.20.1-1.8.0-dev'], 0),
    ('generated-diff', ['git', 'diff', '--exit-code', '--', 'src/generated'], 0),
    ('diff-check', ['git', 'diff', '--check'], 0),
    ('dirty-diff', ['git', 'diff', '--exit-code'], 1)]
rows = []
for label, args, expected in jobs:
    save(label + '-01.command.json', {'command': args, 'cwd': str(ROOT), 'tested_commit': HEAD,
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    start = time.monotonic()
    with (OUT / (label + '-01.log')).open('xb') as log:
        actual = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    row = {'name': label, 'command': args, 'exit': actual.returncode, 'expected_exit': expected,
        'seconds': time.monotonic() - start, 'log': pin(OUT / (label + '-01.log'))}
    rows.append(row)
    print(json.dumps(row), flush=True)
save('STATIC-RESULTS-01.json', {'jobs': rows, 'required_gates_passed': False,
    'closure_is_real_failure_not_waived': True, 'dirty_diff_is_real_failure_not_waived': True})
assert all(row['exit'] == row['expected_exit'] for row in rows), rows
base = 'advancedrocketry-community-1.20.1-1.8.0-dev'
owned = json.loads((AUTHOR / 'OWNED-FILES-01.json').read_bytes())['files']
new_sources = {name[len('src/main/java/'):] for name in owned if name.startswith('src/main/java/')}
central = json.loads((AI / 'ROOT-CENTRAL-01.json').read_bytes())['files']
changed_sources = {row['path'][len('src/main/java/'):] for row in central if row['path'].startswith('src/main/java/')}
resources = {name[len('src/generated/v1.8/resources/'):] for name in after if 'atmosphere_analyzer' in name}
languages = {name[len('src/generated/v1.8/resources/'):] for name in after if '/lang/' in name}
assert len(new_sources) == 9 and len(changed_sources) == 6 and len(resources) == 4 and len(languages) == 2
def outer_member(member, sources):
    return any(member == name[:-5] + '.class' or member.startswith(name[:-5] + '$') and member.endswith('.class') for name in sources)
audits = []
for suffix in ('', '-sources', '-api'):
    name = base + suffix + '.jar'
    with zipfile.ZipFile(OLD / name) as old, zipfile.ZipFile(OUT / 'artifacts-01' / name) as new:
        old_names = {info.filename for info in old.infolist() if not info.is_dir()}
        new_list = [info.filename for info in new.infolist() if not info.is_dir()]
        new_names = set(new_list)
        assert len(new_list) == len(new_names) and old.testzip() is None and new.testzip() is None
        added = new_names - old_names
        removed = old_names - new_names
        changed = {member for member in old_names & new_names if old.read(member) != new.read(member)}
        row = {'artifact': name, 'old_members': len(old_names), 'new_members': len(new_names),
            'added': sorted(added), 'removed': sorted(removed), 'changed': sorted(changed)}
        audits.append(row)
        save('ARTIFACT-OBSERVATION-' + (suffix[1:] or 'main') + '-01.json', row)
        assert not removed, row
        if suffix == '-api':
            assert not added and not changed and (OLD / name).read_bytes() == (OUT / 'artifacts-01' / name).read_bytes()
        elif suffix == '-sources':
            assert added == new_sources | resources and changed == changed_sources | languages, row
        else:
            assert resources <= added and languages <= changed, row
            assert all(member in resources or outer_member(member, new_sources) for member in added), row
            assert all(member in languages or outer_member(member, changed_sources) for member in changed), row
            assert all(name[:-5] + '.class' in added for name in new_sources), row
        if suffix != '-api':
            for member in resources | languages:
                assert new.read(member) == (ROOT / 'src/generated/v1.8/resources' / member).read_bytes(), member
save('ARTIFACT-MEMBER-AUDIT-01.json', {'artifacts': audits, 'API_byte_exact': True,
    'unchanged_unrelated_members': True, 'main_synthetic_classes_scoped_to_owned_outer_classes': True,
    'required_gates_passed': False})
mismatches = [name for name, row in source.items() if pin(ROOT / name) != row]
save('POST-CHECKS-01.json', {'named_inputs': len(source), 'mismatches': mismatches, 'required_gates_passed': False})
assert not mismatches
print(json.dumps({'repeat_files': len(after), 'repeat_changes': len(changes), 'static_expected_exits_observed': True,
    'artifact_scoped_member_audit': True, 'API_byte_exact': True}), flush=True)
