"""Publish exactly the reviewed analyzer development checkpoint, not a Gate."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
BASE = '16e555111ad957e80570317cb103fb9dadc9895a'
BRANCH = 'codex/v1.8.0-classic-content'
AGENTS_SHA = '1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
PROTECTED = 'docs/work/v1.8.0-c18c-tutorial-inventory/NATIVE-TASK-04.md'
PROTECTED_SHA = '3bc4660923f9a17681ff754d4a9a3912541583eec1d9512d1868c00614ad4e43'
commands = []

def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())

def run(args, allowed=(0,)):
    started = time.monotonic()
    process = subprocess.run(args, cwd=ROOT, capture_output=True, env=os.environ.copy())
    stem = 'source-publish-command-%02d' % (len(commands) + 1)
    (OUT / (stem + '.stdout')).write_bytes(process.stdout)
    (OUT / (stem + '.stderr')).write_bytes(process.stderr)
    commands.append({'command': args, 'exit': process.returncode,
        'seconds': time.monotonic() - started, 'stdout': stem + '.stdout', 'stderr': stem + '.stderr'})
    (OUT / 'SOURCE-PUBLICATION-COMMANDS-01.json').write_bytes((json.dumps(commands, indent=2) + '\n').encode())
    assert process.returncode in allowed, (stem, process.returncode)
    return process.stdout

def links(path):
    text = (ROOT / path).read_text(encoding='utf-8')
    text = re.sub(r'(?ms)^(```|~~~)[^\n]*\n.*?^\1[^\n]*(?:\n|$)', '', text)
    count = 0
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        target = target.split('#', 1)[0]
        if target:
            assert (ROOT / path).parent.joinpath(target).is_file(), (path, target)
            count += 1
    return count

author = json.loads((AUTHOR / 'OWNED-FILES-01.json').read_bytes())['files']
central = json.loads((OUT / 'ROOT-CENTRAL-01.json').read_bytes())['files']
expected = dict(author)
expected.update({row['path']: {'bytes': row['post_bytes'], 'sha256': row['post_sha256']} for row in central})
generated = json.loads((OUT / 'GENERATED-POSTIMAGES-01.json').read_bytes())
new_outputs = [name for name in generated if 'atmosphere_analyzer' in name]
languages = [name for name in generated if '/lang/' in name]
assert len(expected) == 25 and len(new_outputs) == 4 and len(languages) == 2
expected.update({name: generated[name] for name in new_outputs + languages})
docs = ['docs/provenance/v1.8.0-c18a-analyzer-new-resources.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/SOURCE-REVIEW-DISPOSITION-01.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/SOURCE-INTEGRATION-01.md',
    'docs/status/COMPLETION-PLAN.md', 'docs/status/CURRENT_VERSION.md', 'docs/work/v1.8.0-implementation-log.md']
for name in docs:
    expected[name] = pin((ROOT / name).read_bytes())
paths = sorted(expected)
assert len(paths) == 37 and PROTECTED not in paths and 'AGENTS.md' not in paths
result = {'scope': '37-path reviewed analyzer development source checkpoint only',
    'paths': paths, 'base_commit': BASE, 'committed_full_regression_ran': False,
    'native_client_ledger_delivery': False, 'required_gates_passed': False}
started = time.monotonic()
try:
    assert run(['git', 'rev-parse', 'HEAD']).decode().strip() == BASE
    assert run(['git', 'branch', '--show-current']).decode().strip() == BRANCH
    assert not run(['git', 'diff', '--cached', '--name-only'])
    assert pin((ROOT / 'AGENTS.md').read_bytes())['sha256'] == AGENTS_SHA
    assert pin((ROOT / PROTECTED).read_bytes())['sha256'] == PROTECTED_SHA
    assert all(pin((ROOT / name).read_bytes()) == row for name, row in expected.items())
    result['real_local_links'] = sum(links(path) for path in paths if path.endswith('.md'))
    run(['python', '-B', 'scripts/validate_v1plus_planning.py'])
    run(['git', 'diff', '--check'])
    run(['git', 'diff', '--exit-code'], allowed=(1,))
    run(['git', 'add', '--'] + paths)
    assert sorted(run(['git', 'diff', '--cached', '--name-only']).decode().splitlines()) == paths
    identities = {}
    for name in paths:
        data = (ROOT / name).read_bytes()
        staged = run(['git', 'show', ':' + name])
        assert staged == data or staged == data.replace(b'\r\n', b'\n'), name
        identities[name] = {'physical': pin(data), 'staged': pin(staged),
            'qualification': 'literal' if staged == data else 'exact CRLF to LF only'}
    result['identities'] = identities
    run(['git', 'diff', '--cached', '--stat'])
    run(['git', 'diff', '--cached', '--check'])
    run(['git', 'commit', '-m', 'feat(atmosphere): add server-owned handheld analyzer'])
    commit = run(['git', 'rev-parse', 'HEAD']).decode().strip()
    run(['git', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH])
    remote = run(['git', 'ls-remote', 'origin', 'refs/heads/' + BRANCH]).decode().split()[0]
    assert remote == commit
    assert not run(['git', 'diff', '--cached', '--name-only'])
    assert pin((ROOT / 'AGENTS.md').read_bytes())['sha256'] == AGENTS_SHA
    assert pin((ROOT / PROTECTED).read_bytes())['sha256'] == PROTECTED_SHA
    assert all(pin((ROOT / name).read_bytes()) == row for name, row in expected.items())
    result.update({'status': 'PASS', 'commit': commit, 'remote_commit': remote})
except BaseException as error:
    result.update({'status': 'FAIL', 'exception_type': type(error).__name__, 'exception': str(error)})
    raise
finally:
    result['seconds'] = time.monotonic() - started
    save('SOURCE-PUBLICATION-01.json', result)
    print(json.dumps({key: value for key, value in result.items() if key != 'identities'}, indent=2))
