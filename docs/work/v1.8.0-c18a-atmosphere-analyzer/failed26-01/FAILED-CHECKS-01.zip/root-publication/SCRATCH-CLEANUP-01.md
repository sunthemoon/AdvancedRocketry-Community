# Root owned bytecode scratch cleanup

Date: 2026-10-05. Scope: one newly created Root helper bytecode file only.
Native PowerShell preflight verifies the regular non-reparse exact file stays
beneath this Root task directory. Remove-Item -LiteralPath completes with exit
0 and Test-Path confirms it is absent:

`__pycache__/run_intermediate01.cpython-313.pyc`

The console formatting does not preserve the pre-deletion size/hash in a
machine-readable receipt; no freed-byte amount is claimed. No sealed payload
contains this scratch file. No C target, prior rejected server/build target,
source world, source code or another agent's output is touched. This successful
new D-file cleanup does not resolve the separately recorded old cleanup debt.
