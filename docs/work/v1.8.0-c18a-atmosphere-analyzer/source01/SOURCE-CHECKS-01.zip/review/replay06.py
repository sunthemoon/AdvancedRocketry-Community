import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

OUT = pathlib.Path(__file__).resolve().parent
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
JDK = pathlib.Path('C:/Program Files/Java/jdk-17.0.7/bin')
JOBS = OUT / 'scoped-06'
JOBS.mkdir(exist_ok=False)
CLASSES = JOBS / 'classes'
CLASSES.mkdir()
XML = JOBS / 'xml'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
intake = load(OUT / 'FINAL-INTAKE-05.json')
metadata = load(AUTHOR / 'CLASSPATH-OBSERVATION-01.json')
def check_inputs():
    result = {}
    for name, expected in intake['external_files'].items():
        actual = pin(pathlib.Path(name)); assert actual == expected, name
        result[name] = actual
    for name, expected in intake['compiled_class_observations'].items():
        actual = pin(WT / 'build/classes/java/main' / name); assert actual == expected, name
    for directory, files in intake['resources_observed'].items():
        for name, expected in files.items(): assert pin(pathlib.Path(directory) / name) == expected, name
    for name, expected in intake['author_source'].items(): assert pin(WT / name) == expected, name
    for name, expected in intake['central_source'].items(): assert pin(ROOT / name) == expected, name
    return {'external_files': len(result), 'main_classes': len(intake['compiled_class_observations']),
            'resources': sum(map(len, intake['resources_observed'].values())), 'author_source': len(intake['author_source']), 'central_source': len(intake['central_source']), 'mismatches': 0}
pre = check_inputs()
disks = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(v >= 10000000000 for v in disks.values()), disks
(JOBS / 'DISKS-PRE-01.json').write_text(json.dumps(disks, indent=2) + '\n', encoding='utf-8')
print('DISKS', disks, flush=True)
environment = os.environ.copy()
for key in ('TEMP', 'TMP', 'TMPDIR'): environment[key] = str(OUT / 'process-temp')
environment['JAVA_HOME'] = str(JDK.parent)
environment['PATH'] = str(JDK) + os.pathsep + environment['PATH']
main_cp = metadata['classpath']['compile']
runtime_cp = [str(CLASSES)] + [p for p in metadata['classpath']['runtime'] if not p.replace('\\', '/').endswith('build/classes/java/test')]
sources = [str(WT / name) for name in intake['author_source'] if name.endswith('.java')]
sources.append(str(WT / metadata['test_support_source']['path']))
sources.append(str(OUT / 'EngineRunner.java'))
args = ['-encoding', 'UTF-8', '--release', '17', '-proc:none', '-implicit:none', '-sourcepath', '', '-classpath', ';'.join(main_cp), '-d', str(CLASSES)] + sources
def quote(s): return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'
(JOBS / 'javac.args').write_text('\n'.join(map(quote, args)) + '\n', encoding='utf-8')
commands = [([str(JDK / 'javac.exe'), '-J-Xmx1G', '-J-XX:ActiveProcessorCount=2', '-J-Djava.io.tmpdir=' + str(OUT / 'process-temp'), '@' + str(JOBS / 'javac.args')], 'compile'),
            ([str(JDK / 'java.exe'), '-Xmx1G', '-XX:ActiveProcessorCount=2', '-Djava.io.tmpdir=' + str(OUT / 'process-temp'), '-Xlog:class+load=info:file=' + str(JOBS / 'class-load.log').replace('\\', '/').replace(':', '\\:'), '-cp', ';'.join(runtime_cp), 'EngineRunner', str(XML)], 'junit')]
receipt = {'qualification': 'Fresh standalone javac + real JupiterTestEngine execution; not Gradle, central compilation or Forge runtime.',
           'precheck': pre, 'disks_pre': disks, 'sources': {p: pin(pathlib.Path(p)) for p in sources}, 'commands': []}
(JOBS / 'COMMAND-PLAN-01.json').write_text(json.dumps({'commands': commands, 'environment': {k: environment[k] for k in ('TEMP', 'TMP', 'TMPDIR', 'JAVA_HOME')}, 'classpath_first': runtime_cp[0]}, indent=2) + '\n', encoding='utf-8')
for command, name in commands:
    start = datetime.datetime.now(datetime.timezone.utc).isoformat(); clock = time.monotonic()
    with (JOBS / (name + '.log')).open('wb') as log:
        r = subprocess.run(command, cwd=JOBS, env=environment, stdout=log, stderr=subprocess.STDOUT)
    item = {'argv': command, 'start_utc': start, 'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - clock, 'exit': r.returncode, 'log': pin(JOBS / (name + '.log'))}
    receipt['commands'].append(item)
    (JOBS / 'RECEIPT-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(name, r.returncode, item['elapsed_seconds'], flush=True)
    if r.returncode: break
receipt['postcheck'] = check_inputs()
receipt['disks_post'] = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
receipt['output_classes'] = {str(p.relative_to(CLASSES)).replace('\\', '/'): pin(p) for p in sorted(CLASSES.rglob('*.class'))}
if XML.exists():
    sums = dict(tests=0, failures=0, errors=0, skipped=0)
    suites = {}
    for p in sorted(XML.glob('*.xml')):
        root = ET.parse(p).getroot()
        for k in sums: sums[k] += int(root.attrib[k])
        assert len(root.findall('testcase')) == int(root.attrib['tests'])
        suites[p.name] = {'pin': pin(p), 'counts': root.attrib}
    receipt['xml'] = dict(suites=len(suites), counts=sums, files=suites)
(JOBS / 'RECEIPT-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print('POSTCHECK', receipt['postcheck'], 'XML', receipt.get('xml', {}).get('counts'), flush=True)
raise SystemExit(receipt['commands'][-1]['exit'])
