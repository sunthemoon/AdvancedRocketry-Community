"""Final bounded static controls, tool/classpath attribution and immutable selected deltas."""
import difflib
import hashlib
import json
import pathlib
import re
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
CENTRAL = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
intake = load(OUT / 'FINAL-INTAKE-05.json')
for name, expected in intake['author_source'].items(): assert pin(WT / name) == expected
for name, expected in intake['central_source'].items(): assert pin(ROOT / name) == expected
for origin, target in ((AUTHOR / 'SOURCE-01.patch', OUT / 'SOURCE-AUTHOR-01.patch'),
                       (CENTRAL / 'ROOT-CENTRAL-01.patch', OUT / 'SOURCE-CENTRAL-01.patch')):
    assert not target.exists()
    target.write_bytes(origin.read_bytes())
    assert pin(target) == pin(origin)
old = (AUTHOR / 'scoped-01-ServiceTest.java.txt').read_text(encoding='utf-8-sig')
now = (WT / 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/atmosphere/instrument/AtmosphereAnalyzerServiceTest.java').read_text(encoding='utf-8')
# Exact original text, with only the existing bootstrap import/annotation/setup appended.
stripped = now.replace('import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;\n', '')
stripped = stripped.replace('import org.junit.jupiter.api.BeforeAll;\n', '')
stripped = stripped.replace('    @BeforeAll static void bootstrap() { MinecraftBootstrap.initialize(); }\n', '')
assert stripped == old
(OUT / 'BOOTSTRAP-TEST-DELTA-01.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True), now.splitlines(True), fromfile='scoped01-ServiceTest', tofile='final-ServiceTest')), encoding='utf-8')
scope7 = load(OUT / 'scoped-07/RECEIPT-01.json')
scope8 = load(OUT / 'scoped-08/RECEIPT-01.json')
assert scope7['commands'][0]['exit'] == 0 and scope8['exit'] == 0
assert scope8['xml']['suites'] == 5 and scope8['xml']['counts'] == dict(tests=19, failures=0, errors=0, skipped=0)
log = (OUT / 'scoped-08/class-load.log').read_text(encoding='utf-8', errors='replace')
loaded_owned = [line for line in log.splitlines() if 'advancedrocketrycommunity.atmosphere.instrument.' in line or 'advancedrocketrycommunity.datagen.V180AtmosphereAnalyzer' in line]
assert loaded_owned and all('/scoped-07/classes/' in line for line in loaded_owned)
native = [line for line in log.splitlines() if 'net.minecraft.server.Bootstrap source:' in line or 'net.minecraft.resources.ResourceKey source:' in line or 'net.minecraft.network.chat.Component source:' in line]
assert native and all('47.4.10_mapped_official_1.20.1' in line for line in native)
baseline = [line for line in log.splitlines() if 'advancedrocketrycommunity.celestial.CelestialDefaults source:' in line or 'advancedrocketrycommunity.datagen.V180MaterialArt source:' in line]
assert len(baseline) == 2 and all('arce-v180-c18a-analyzer-20261005/build/classes/java/main/' in line for line in baseline)
(OUT / 'CLASS-SOURCE-ATTRIBUTION-01.json').write_text(json.dumps({'qualification': 'Actual standalone JUnit class loading, not ModLauncher/native server proof.',
    'owned_loaded_lines': loaded_owned, 'selected_native_loaded_lines': native, 'selected_baseline_loaded_lines': baseline,
    'bootstrap_delta_exactly_setup_only': True, 'bootstrap_delta_pin': pin(OUT / 'BOOTSTRAP-TEST-DELTA-01.diff'),
    'junit_log': pin(OUT / 'scoped-08/junit.log'), 'class_load_log': pin(OUT / 'scoped-08/class-load.log')}, indent=2) + '\n', encoding='utf-8')
source = (OUT / 'static04.py').read_text(encoding='utf-8')
assert source.count("B / 'STATIC-04.json'") == 1
source = source.replace("B / 'STATIC-04.json'", "B / 'STATIC-FINAL-09.json'")
source = source.replace("'source_state': 'INTERMEDIATE_UNCOMMITTED'", "'source_state': 'FINAL_FROZEN_AUTHOR_SOURCE'")
print('Final source and central pins exact; isolated bootstrap delta has no changed original assertion. Attribution uses own classes + observed baseline/native jars.', flush=True)
exec(compile(source, str(OUT / 'final09.py'), 'exec'))
