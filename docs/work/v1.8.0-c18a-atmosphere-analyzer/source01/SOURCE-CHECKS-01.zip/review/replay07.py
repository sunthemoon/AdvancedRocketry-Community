"""One corrected job: immutable replay06 mechanics with recorded classpath-only correction."""
import hashlib
import json
import pathlib

out = pathlib.Path(__file__).resolve().parent
old = (out / 'replay06.py').read_text(encoding='utf-8')
corrections = {
    "JOBS = OUT / 'scoped-06'": "JOBS = OUT / 'scoped-07'",
    "main_cp = metadata['classpath']['compile']":
        "main_cp = list(dict.fromkeys(metadata['classpath']['compile'] + [p for p in metadata['classpath']['runtime'] if not p.replace('\\\\', '/').endswith('build/classes/java/test')]))",
}
new = old
for before, after in corrections.items():
    assert new.count(before) == 1
    new = new.replace(before, after)
(out / 'REPLAY-CORRECTION-07.json').write_text(json.dumps({
    'qualification': 'Reviewer harness/classpath correction only; author/Root sources and assertions unchanged.',
    'original_replay_sha256': hashlib.sha256(old.encode()).hexdigest(),
    'corrections': corrections,
    'derived_replay_sha256': hashlib.sha256(new.encode()).hexdigest(),
}, indent=2) + '\n', encoding='utf-8')
exec(compile(new, str(out / 'replay07.py'), 'exec'))
