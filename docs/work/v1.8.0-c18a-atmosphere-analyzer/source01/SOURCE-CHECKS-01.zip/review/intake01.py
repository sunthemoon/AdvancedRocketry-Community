"""Named read-only intermediate source intake; no source export or execution."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
W = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
R = Path('D:/GitHub/AdvancedRocketry-Community')
BASE = '9135c20c34a402b7cf0715148aeb6683a35c1f50'
P = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
T = 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/'
sha = lambda d: hashlib.sha256(d).hexdigest()
commands = []


def git(where, *args):
    cmd = ['git', '-C', str(where), *args]
    done = subprocess.run(cmd, capture_output=True, check=False)
    commands.append({'command': cmd, 'exit': done.returncode,
                     'stdout_bytes': len(done.stdout), 'stdout_sha256': sha(done.stdout),
                     'stderr': done.stderr.decode('utf-8', errors='replace')})
    assert done.returncode == 0
    return done.stdout


assert git(W, 'rev-parse', 'HEAD').decode().strip() == BASE
root_head = git(R, 'rev-parse', 'HEAD').decode().strip()
main = [P + 'atmosphere/instrument/' + x + '.java' for x in
        ('AnalyzerReading', 'AtmosphereAnalyzerService', 'AtmosphereAnalyzerRuntime',
         'AtmosphereAnalyzerLifecycle', 'AtmosphereAnalyzerItem', 'AtmosphereAnalyzerFeedback')]
main += [P + 'datagen/V180AtmosphereAnalyzerData.java', P + 'datagen/V180AtmosphereAnalyzerLanguage.java',
         P + 'gametest/AtmosphereAnalyzerGameTests.java']
tests = [T + 'atmosphere/instrument/' + x + '.java' for x in
         ('AnalyzerReadingTest', 'AtmosphereAnalyzerServiceTest', 'AtmosphereAnalyzerFeedbackTest')]
tests += [T + 'datagen/V180AtmosphereAnalyzerDataTest.java', T + 'datagen/V180AtmosphereAnalyzerLanguageTest.java']
docs = ['PROJECT-CONFIG.md', 'PRODUCT.md', 'docs/01-PORTING-PRINCIPLES.md',
    'docs/04-VERSION-ROADMAP.md', 'docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md',
    'docs/05-MASTER-TEST-PLAN.md', 'docs/06-RELEASE-AND-ACCEPTANCE-GATES.md',
    'docs/16-POST-1.0-VERSION-ROADMAP.md', 'docs/17-V1PLUS-QUALITY-BUDGETS.md',
    'docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md',
    'UPSTREAM.md', 'NOTICE.md', 'docs/02-UPSTREAM-TREE-AND-ASSET-AUDIT.md',
    'docs/08-ASSET-LICENSE-AND-PROVENANCE.md',
    'docs/decisions/ADR-066-CLASSIC-LIFE-SUPPORT-EQUIPMENT-RESEARCH-AND-PRESENTATION.md',
    'docs/decisions/ADR-061-CLASSIC-CONTENT-IDENTITY-IMPORT-AND-VALIDATION.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md',
    'docs/work/v1.8.0-c18a-atmosphere-analyzer/REVIEW-DISPOSITION-01.md',
    'docs/provenance/v1.8.0-c18a-analyzer-new-resources.md']
dependencies = [P + path for path in (
    'atmosphere/server/AtmosphereManager.java', 'atmosphere/server/AtmosphereLevelService.java',
    'atmosphere/life/BreathabilityState.java', 'celestial/context/BodyContextResolver.java',
    'celestial/context/BodyContext.java', 'celestial/context/WorldLocation.java',
    'celestial/service/CelestialCatalog.java', 'celestial/service/CelestialCatalogManager.java',
    'celestial/service/CelestialEnvironmentService.java', 'celestial/model/CelestialBodyDefinition.java',
    'station/orbit/StationRegionBodyContextResolver.java', 'compat/environment/EnvironmentQueryLifecycle.java',
    'gametest/ConnectedTestPlayers.java', 'datagen/V180MaterialArt.java')]
central = [P + path for path in ('AdvancedRocketryCommunity.java', 'config/CommonConfig.java',
    'registry/ModItems.java', 'registry/ModCreativeTabs.java',
    'datagen/BootstrapDataGenerators.java', 'datagen/V180LanguageProvider.java')]
inputs = []
for category, where, paths in (('intermediate_author_source', W, main + tests),
    ('fixed_authority_docs', W, docs), ('fixed_dependencies', W, dependencies),
    ('provisional_root_central', R, central),
    ('provisional_root_test', R, [T + 'config/ClassicDevicesConfigTest.java']),
    ('provisional_root_pin_test', R, [T + 'config/CommonConfigTest.java']),
    ('live_governance', R, ['AGENTS.md'])):
    for path in paths:
        data = (where / path).read_bytes()
        entry = {'category': category, 'path': str(where / path), 'relative_path': path,
                 'bytes': len(data), 'lines': len(data.splitlines()), 'sha256': sha(data)}
        if category in ('fixed_authority_docs', 'fixed_dependencies', 'provisional_root_central', 'provisional_root_pin_test'):
            baseline = git(W, 'show', BASE + ':' + path)
            entry.update({'baseline_commit': BASE, 'baseline_sha256': sha(baseline),
                          'baseline_bytes': len(baseline), 'literal_git_equal': data == baseline,
                          'text_git_equal': data.replace(b'\r\n', b'\n') == baseline.replace(b'\r\n', b'\n')})
        inputs.append(entry)
diff = git(R, 'diff', '--', *central)
(B / 'CENTRAL-OBSERVATION-01.diff').write_bytes(diff)
out = {'schema': 1, 'fixed_base': BASE, 'observed_root_head': root_head,
       'scope': 'intermediate intake only; author and Root have not frozen final source verdict inputs',
       'inputs': inputs, 'commands': commands, 'central_diff_sha256': sha(diff),
       'java_launches': 0, 'new_C_outputs': 0}
(B / 'INPUTS-01.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'inputs': len(inputs), 'author_source_files': len(main) + len(tests),
    'root_central_files': len(central), 'source_state': 'INTERMEDIATE', 'java_launches': 0,
    'fixed_context_text_mismatches': [e['relative_path'] for e in inputs
       if e['category'] in ('fixed_authority_docs', 'fixed_dependencies')
       and not e['text_git_equal']]}))
