import difflib
import hashlib
import json
import pathlib
import re
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
baseline = load(AUTHOR / 'BASELINE-01.json')
observations = {}
for name, expected in baseline['tracked_baseline'].items():
    assert name.startswith('src/') or name in ('build.gradle', 'gradle.properties'), name
    assert '..' not in pathlib.PurePosixPath(name).parts
    actual = pin(WT / name); assert actual == expected, name
    observations[name] = actual
assert len(observations) == 2811
intake = load(OUT / 'FINAL-INTAKE-05.json')
lines = {}
for owner, table, worktree in (('author', intake['author_source'], WT), ('central', intake['central_source'], ROOT)):
    for name, expected in table.items():
        assert pin(worktree / name) == expected
        text = (worktree / name).read_text(encoding='utf-8')
        lines[owner + ':' + name] = {'pin': expected, 'lines': len(text.splitlines())}
selected = {
    'AtmosphereAnalyzerService.java': ('atmosphere/instrument', ['public AnalyzerReading read(', 'static boolean admitted(', 'static Optional<AmbientIdentity> project(', 'static AnalyzerReading compose(', '@Override public void close()']),
    'AtmosphereAnalyzerItem.java': ('atmosphere/instrument', ['public static final int COOLDOWN_TICKS', 'public InteractionResultHolder<ItemStack> use(', 'player.sendSystemMessage(', 'player.getCooldowns().addCooldown(']),
    'AtmosphereAnalyzerLifecycle.java': ('atmosphere/instrument', ['public void onServerStarted(', 'StationRegistrySavedData.get(server)', 'private void close(']),
    'AtmosphereAnalyzerRuntime.java': ('atmosphere/instrument', ['static synchronized void install(', 'static synchronized void remove(', 'public static AnalyzerReading read(']),
    'V180AtmosphereAnalyzerData.java': ('datagen', ['public static Map<String, JsonObject> clientFiles(', 'public static Map<String, JsonObject> serverFiles(', 'public static byte[] texture(', 'public CompletableFuture<?> run(']),
    'AtmosphereAnalyzerGameTests.java': ('gametest', ['public static void ', 'private static void nativeUse(', 'helper.runAfterDelay(2'])}
references = {}
for name, (directory, fragments) in selected.items():
    relative = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/' + directory + '/' + name
    textlines = (WT / relative).read_text(encoding='utf-8').splitlines()
    references[relative] = [{'line': i + 1, 'text': line.strip()} for i, line in enumerate(textlines) if any(fragment in line for fragment in fragments)]
gt = (WT / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java').read_text(encoding='utf-8')
assert len(re.findall(r'@GameTest\(', gt)) == 10
assert set(re.findall(r'timeoutTicks = (\d+)', gt)) == {'40'}
doc_pins = {}
for name in ('AGENTS.md', 'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md', 'docs/work/v1.8.0-c18a-atmosphere-analyzer/REVIEW-DISPOSITION-01.md', 'docs/provenance/v1.8.0-c18a-analyzer-new-resources.md'):
    doc_pins[name] = pin(ROOT / name)
r = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, text=True)
assert r.returncode == 0
result = {'qualification': 'Named source/build baseline scope checks only; no full-source export or whole repository/Gate validation.',
          'baseline_manifest': pin(AUTHOR / 'BASELINE-01.json'), 'base_commit': baseline['base'],
          'tracked_baseline_count': len(observations), 'tracked_baseline_mismatches': 0,
          'lines': lines, 'selected_source_references': references, 'GameTests': {'declared': 10, 'timeoutTicks': 40, 'run_here': False},
          'current_root_doc_pins': doc_pins, 'root_head_observed': r.stdout.strip(),
          'source_base_head_separate': True, 'java_slot_released': True}
(OUT / 'FINAL-SCOPE-11.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('2811 literal author source/build baseline pins exact; 17 author and 8 central pins exact; ten40-tick GameTests declared/not run; Root docs HEAD recorded separately.')
