# Initial central pin-test observation and separately authorized correction

The first actual source read observed CommonConfigTest line 42 asserting exactly
69 configured leaves. Root's initial six-file central diff added one BooleanValue
at lifeSupport.classicDevicesEnabled without changing this test. This would make
the inherited all-config count assertion stale; no live JUnit count was measured
by this reviewer. The issue was sent to Root before final source freeze.

Root subsequently identified the unchanged preimage SHA as
`93b3c4f633bb255790471177432c97eeb0e93b6b22c94fd8e6f7f3de96cd9954`
and changed the assertion/comment to exactly 70, authorizing that eighth central
source/test path separately. Root reports postimage
`7245da202440c2d337e2f0aa2236d9dc26b3f5417919cf5d1ab943a9d94c30d7`.
This receipt is historical context, not a passing test or final disposition;
the actual correction will be read/pinned and its diff assessed independently.
