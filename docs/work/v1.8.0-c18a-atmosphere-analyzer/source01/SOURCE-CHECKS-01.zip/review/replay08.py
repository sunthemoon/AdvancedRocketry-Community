"""Authorized JVM-only retry of immutable scoped07 classes, relative own-D log path."""
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

OUT = pathlib.Path(__file__).resolve().parent
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
OLD = OUT / 'scoped-07'
JOB = OUT / 'scoped-08'
JOB.mkdir(exist_ok=False)
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
intake = load(OUT / 'FINAL-INTAKE-05.json')
old = load(OLD / 'RECEIPT-01.json')
assert old['commands'][0]['exit'] == 0 and old['commands'][1]['exit'] == 1 and 'xml' not in old
def check():
    for name, expected in intake['external_files'].items(): assert pin(pathlib.Path(name)) == expected, name
    for name, expected in intake['compiled_class_observations'].items(): assert pin(WT / 'build/classes/java/main' / name) == expected, name
    for directory, files in intake['resources_observed'].items():
        for name, expected in files.items(): assert pin(pathlib.Path(directory) / name) == expected, name
    for name, expected in intake['author_source'].items(): assert pin(WT / name) == expected, name
    for name, expected in intake['central_source'].items(): assert pin(ROOT / name) == expected, name
    for name, expected in old['sources'].items(): assert pin(pathlib.Path(name)) == expected, name
    for name, expected in old['output_classes'].items(): assert pin(OLD / 'classes' / name) == expected, name
    return {'author17': 17, 'central8': 8, 'external_files': 124, 'baseline_classes': 1881, 'resource_files': 1198,
            'own_classes': len(old['output_classes']), 'mismatches': 0}
pre = check()
disks = {d: shutil.disk_usage(d + ':/').free for d in ('C', 'D')}
assert all(v >= 10000000000 for v in disks.values()), disks
command = old['commands'][1]['argv'].copy()
xlog = [i for i, arg in enumerate(command) if arg.startswith('-Xlog:')]
assert len(xlog) == 1
command[xlog[0]] = '-Xlog:class+load=info:file=class-load.log'
command[-1] = str(JOB / 'xml')
env = os.environ.copy()
for key in ('TEMP', 'TMP', 'TMPDIR'): env[key] = str(OUT / 'process-temp')
plan = {'argv': command, 'cwd': str(JOB), 'environment': {key: env[key] for key in ('TEMP', 'TMP', 'TMPDIR')},
        'precheck': pre, 'disks_pre': disks, 'previous_receipt': pin(OLD / 'RECEIPT-01.json'),
        'qualification': 'JVM-only retry; same exact scoped07 compiled classes and five Jupiter selectors; no candidate/compiler edits.',
        'jdk_java': pin(pathlib.Path(command[0])), 'jdk_release': pin(pathlib.Path(command[0]).parent.parent / 'release')}
(JOB / 'COMMAND-01.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('DISKS', disks, flush=True)
start = datetime.datetime.now(datetime.timezone.utc).isoformat(); clock = time.monotonic()
with (JOB / 'junit.log').open('wb') as log:
    result = subprocess.run(command, cwd=JOB, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt = {**plan, 'start_utc': start, 'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'elapsed_seconds': time.monotonic() - clock, 'exit': result.returncode, 'postcheck': check(),
           'disks_post': {d: shutil.disk_usage(d + ':/').free for d in ('C', 'D')}, 'junit_log': pin(JOB / 'junit.log')}
if (JOB / 'xml').exists():
    sums = dict(tests=0, failures=0, errors=0, skipped=0); suites = {}
    for p in sorted((JOB / 'xml').glob('*.xml')):
        root = ET.parse(p).getroot()
        for k in sums: sums[k] += int(root.attrib[k])
        assert len(root.findall('testcase')) == int(root.attrib['tests'])
        suites[p.name] = {'pin': pin(p), 'counts': root.attrib}
    receipt['xml'] = dict(suites=len(suites), counts=sums, files=suites)
(JOB / 'RECEIPT-01.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print('JVM', result.returncode, receipt['elapsed_seconds'], 'XML', receipt.get('xml', {}).get('counts'), 'POST', receipt['postcheck'], flush=True)
raise SystemExit(result.returncode)
