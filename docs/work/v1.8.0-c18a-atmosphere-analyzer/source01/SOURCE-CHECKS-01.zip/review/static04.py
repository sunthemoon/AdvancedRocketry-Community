"""Independent bounded source/resource controls; not a Java/Forge execution."""
from collections import deque
import hashlib
import json
import os
from pathlib import Path
import re
import unittest

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
W = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
R = Path('D:/GitHub/AdvancedRocketry-Community')
P = W / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity'
sha = lambda data: hashlib.sha256(data).hexdigest()
selected = [P / 'atmosphere/instrument' / (n + '.java') for n in
    ('AnalyzerReading', 'AtmosphereAnalyzerService', 'AtmosphereAnalyzerRuntime',
     'AtmosphereAnalyzerLifecycle', 'AtmosphereAnalyzerItem', 'AtmosphereAnalyzerFeedback')]
selected += [P / 'datagen/V180AtmosphereAnalyzerData.java', P / 'datagen/V180AtmosphereAnalyzerLanguage.java',
    P / 'gametest/AtmosphereAnalyzerGameTests.java', P / 'atmosphere/scan/VolumeScanTask.java',
    P / 'atmosphere/scan/VolumeScanCoordinator.java', P / 'atmosphere/AtmosphereLimits.java']
before = [{'path': str(p), 'bytes': len(p.read_bytes()), 'sha256': sha(p.read_bytes())} for p in selected]
texts = {p.stem: p.read_text(encoding='utf-8') for p in selected}
instrument = {k: v for k, v in texts.items() if k.startswith(('Analyzer', 'AtmosphereAnalyzer')) and not k.endswith('GameTests')}
data = texts['V180AtmosphereAnalyzerData']
jsons = [json.loads(m) for m in re.findall(r'json\("""(.*?)"""\)', data, flags=re.S)]
recipe, advancement = [v for v in jsons if 'ingredients' in v][0], [v for v in jsons if 'criteria' in v][0]
model = [v for v in jsons if 'textures' in v][0]


def scanned_room(radius, height):
    # Domain-sized model of observed VolumeScanTask BFS ordering. This does not
    # execute candidate/native code or prove global manager scheduling.
    queue, enqueued = deque([(0, 1, 0)]), {(0, 1, 0)}
    inspected, air = 0, set()
    by_step = []
    neighbors = ((0, -1, 0), (0, 1, 0), (0, 0, -1), (0, 0, 1), (-1, 0, 0), (1, 0, 0))
    while queue:
        for _ in range(256):
            if not queue: break
            x, y, z = queue.popleft(); inspected += 1
            if abs(x) >= radius or abs(z) >= radius or y <= 0 or y >= height:
                continue
            air.add((x, y, z))
            for a, b, c in neighbors:
                next_pos = x + a, y + b, z + c
                if next_pos not in enqueued:
                    enqueued.add(next_pos); queue.append(next_pos)
        by_step.append({'inspected': inspected, 'queue_remaining': len(queue), 'air': len(air)})
    return by_step


class Controls(unittest.TestCase):
    def test_recipe_literal_json_has_exact_frozen_multiset(self):
        self.assertEqual('minecraft:crafting_shapeless', recipe['type'])
        self.assertCountEqual([{'item': 'advancedrocketrycommunity:basic_circuit'},
            {'item': 'minecraft:glass_pane'}, {'item': 'minecraft:iron_ingot'}], recipe['ingredients'])
        self.assertEqual({'item': 'advancedrocketrycommunity:atmosphere_analyzer', 'count': 1}, recipe['result'])

    def test_unlock_literal_json_is_normal_vanilla_or_and_exact_reward(self):
        self.assertEqual('minecraft:recipes/root', advancement['parent'])
        self.assertEqual([['has_input', 'has_the_recipe']], advancement['requirements'])
        self.assertEqual({'recipes': ['advancedrocketrycommunity:atmosphere_analyzer']}, advancement['rewards'])
        self.assertEqual({'items': [{'items': ['advancedrocketrycommunity:basic_circuit']}]},
                         advancement['criteria']['has_input']['conditions'])

    def test_model_and_original_grid_have_no_bitmap_import(self):
        self.assertEqual({'parent': 'minecraft:item/generated',
            'textures': {'layer0': 'advancedrocketrycommunity:item/atmosphere_analyzer'}}, model)
        grid_text = re.search(r'return new String\[\]\s*\{(.*?)\};', data, re.S).group(1)
        grid = re.findall(r'"([.0-9]+)"', grid_text)
        self.assertEqual(16, len(grid)); self.assertTrue(all(len(row) == 16 for row in grid))
        self.assertEqual('V180MaterialArt.png(grid(), 0x8AD2C2)', re.search(r'public static byte\[\] texture\(\) \{ return (.*?);', data).group(1))
        self.assertNotIn('getResourceAsStream', data)

    def test_read_guard_order_is_loaded_eye_before_manager_and_final_identity(self):
        text = texts['AtmosphereAnalyzerService']
        self.assertLess(text.index('!active.server().isSameThread()'), text.index('player.serverLevel()'))
        self.assertIn('BlockPos.containing(x, y, z)', text)
        order = ['getChunkNow(', 'CelestialCatalog catalog =', '.resolve(new WorldLocation',
                 'project(catalog, context', '.breathabilityAt(', 'AnalyzerReading reading =', 'binding != active']
        points = [text.index(s) for s in order]
        self.assertEqual(sorted(points), points)
        self.assertIn('active.catalogs().current().orElse(null) != catalog', text)

    def test_item_uses_same_identity_count_and_cooldown_without_owned_nbt(self):
        text = texts['AtmosphereAnalyzerItem']
        self.assertIn('properties.stacksTo(1)', text)
        self.assertIn('held.getItem() != this || held.getCount() != 1', text)
        self.assertIn('COOLDOWN_TICKS = 2', text)
        self.assertLess(text.index('isOnCooldown(this)'), text.index('readings.apply('))
        self.assertLess(text.index('sendSystemMessage('), text.index('addCooldown('))
        self.assertNotRegex(text, r'\.(getTag|getOrCreateTag|save|copy|getCapability|setTag|shrink|hurtAndBreak)\(')

    def test_space_projection_and_nonbreathable_mapping_are_explicit(self):
        text = texts['AtmosphereAnalyzerService']
        self.assertIn('level.equals(CelestialIds.SPACE_LEVEL)', text)
        self.assertIn('!body.id().equals(CelestialIds.SPACE_ID)', text)
        self.assertIn('context.locus() != BodyContext.Locus.ORBIT', text)
        self.assertIn('case VACUUM -> AnalyzerReading.State.NON_BREATHABLE', text)
        self.assertNotIn('baseAtmosphereBreathable', text)

    def test_lifecycle_reference_release_and_owner_matching_are_source_visible(self):
        text = texts['AtmosphereAnalyzerLifecycle']
        self.assertEqual(1, text.count('StationRegistrySavedData.get(server)'))
        self.assertIn('service != null && service.owns(server)', text)
        self.assertLess(text.index('AtmosphereAnalyzerRuntime.remove(service)'), text.index('service.close()'))
        self.assertIn('service = null', text)
        self.assertIn('@Override public void close() { binding = null; }', texts['AtmosphereAnalyzerService'])
        self.assertIn('if (active == service) { active = null; }', texts['AtmosphereAnalyzerRuntime'])

    def test_fixed_feedback_has_finite_unrounded_values_and_no_client_linkage(self):
        self.assertIn('Double.toString(ambient.pressure())', texts['AtmosphereAnalyzerFeedback'])
        self.assertIn('Double.toString(ambient.temperatureKelvin())', texts['AtmosphereAnalyzerFeedback'])
        for name, text in instrument.items():
            self.assertNotIn('net.minecraft.client.', text, name)
            self.assertNotRegex(text, r'static\s+(?:final\s+)?(?:Map|List|Set|Collection)\s*[< ]')
            self.assertLess(len(text.splitlines()), 500)

    def test_scan_model_quantifies_two_tick_pending_fixture_not_native_timing(self):
        small, large = scanned_room(1, 2), scanned_room(4, 8)
        self.assertEqual({'inspected': 7, 'queue_remaining': 0, 'air': 1}, small[-1])
        self.assertEqual({'inspected': 637, 'queue_remaining': 0, 'air': 343}, large[-1])
        self.assertGreater(large[1]['queue_remaining'], 0)
        self.assertEqual(256, large[0]['inspected'])
        self.assertIn('MAX_TASK_INSPECTIONS_PER_TICK = 256', texts['AtmosphereLimits'])
        self.assertIn('index < ids.size()', texts['VolumeScanCoordinator'])


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    unchanged = all(sha(Path(e['path']).read_bytes()) == e['sha256'] for e in before)
    assert unchanged
    out = {'source_state': 'INTERMEDIATE_UNCOMMITTED', 'inputs': before,
        'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'skips': len(result.skipped), 'inputs_unchanged': unchanged,
        'small_room_model': scanned_room(1, 2), 'large_room_model': scanned_room(4, 8),
        'java_launches': 0,
        'limits': 'literal JSON/declaration/order and specification scan-model checks; no Java/native callback/item-use/manager scheduling/client proof'}
    (B / 'STATIC-04.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
    raise SystemExit(not result.wasSuccessful())
