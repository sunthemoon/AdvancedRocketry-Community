# C18a-01 analyzer: independent actual-source review

## Findings and recommendation

No unresolved Critical, High, Medium or Low finding was identified in the exact
14 new author Java postimages and eight Root central postimages reviewed here.
The source is eligible for **bounded Root integration and full regression**;
this is not runtime, native/player restart, client, ledger or version Gate
admission. The 19 unit results below do not replace the ten unrun GameTests.

One intermediate central test-coherence observation is resolved:
`config/CommonConfigTest.java:38-43` still asserted 69 after Root added one
BooleanValue. Root subsequently changed only the explanatory comment and count
to 70. The original observed bytes and the separate corrected pre/postimages are
retained. Existing ranges/other assertions were not relaxed. The new three-case
`ClassicDevicesConfigTest` and changed central files were inspected statically,
**not independently compiled or executed** in this review.

## Exact candidate and review scope

- Source base: `9135c20c34a402b7cf0715148aeb6683a35c1f50`; author worktree
  `D:/GitHub/arce-v180-c18a-analyzer-20261005`.
- Author evidence: `D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8`.
  Manifest `d9b53421547e16b24da6491cb73da0f8f73ed50992d2c71b4c8331711df8057c`:
  all 61 payloads / 1,448,902 bytes independently verified. OWNED-FILES
  `2e556a1bef567bb3faf8c6c745573e8b2f7a21499e6266793398cd27f121b13f`
  binds 17 postimages: nine main classes, five unit classes and three task records.
  All 2,811 explicitly named original source/build pins remain exact.
- Author new-file patch
  `5721de9ce0bc93f87d7a04a7613605427d41e9ba047b0633c530820f3b426863`;
  independent reverse applicability check exited 0 on the actual postimages.
- Root central receipt
  `059c7b4164e25c2d6cb47dace2fea77b4f091c6fa85a6fa042391af3098bb5d6`;
  eight actual postimages/preimages exact. Central patch
  `8606b45ce17510f1ee963717d3a53267d97e38329a61cbdd2e3ec06a1e16c302`
  independently checks forward on the author's fixed base and reverse on Root,
  both exit 0. These read-only checks did not apply or stage anything.
- Root HEAD was observed separately at
  `16e555111ad957e80570317cb103fb9dadc9895a`, a documentation-only movement.
  It is not substituted for the source base. Live AGENTS SHA
  `1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0`
  and committed TASK `234943b59e8423bfcce48916f7317453043356fc4f86e0f8edc5ded0749eeabc`
  were read; historical PROPOSED header is qualified by its adopted disposition.
  Pre-authoring NEW-origin record SHA
  `91935234d35e72eb6ef1405d7600b90050a855ea1887192c0410525b16c98d9d`
  predates source authoring. No upstream/official art was imported.

Exact individual pins and original/final input qualification are in
[final intake](D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-source-review-5ddc460a12/FINAL-INTAKE-05.json)
and [final scope](D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-source-review-5ddc460a12/FINAL-SCOPE-11.json).
Only the individually necessary author/central patches are copied here; there
is no source-tree, official JAR or world export.

## Source observations

- `AtmosphereAnalyzerService.java:31-61,64-86`: owning thread/player/current-Level
  admission precedes environment reads; finite eye coordinates, build/world
  bounds and `getChunkNow` precede context/manager access. One captured catalog
  is supplied to the resolver; the binding/catalog identity is rechecked before
  return. A station's logical orbit body is distinct from actual Space ambient.
  Existing VACUUM breathability maps to NON_BREATHABLE, not invented pressure.
- `AtmosphereAnalyzerItem.java:17,32-46`: actual hand/item/count, server identity,
  shared two-tick native Item cooldown, fixed chat feedback; disabled bypasses
  the read callback. No held-NBT decode/copy, equipment/provider access, damage,
  capability, arbitrary position or persistence writer was added.
- `AtmosphereAnalyzerLifecycle.java:27-52` and
  `AtmosphereAnalyzerRuntime.java:10-26`: startup-only committed station lookup,
  one private host handle, owner-matched removal and permanent close/reference
  release. Root registers startup and HIGHEST stopping/stopped listeners. The
  foreign lifecycle test uses an unregistered instance and does not dispatch a
  global shutdown event.
- `V180AtmosphereAnalyzerData.java:30-59`: exact NEW three-ingredient singleton
  shapeless recipe, normal OR recipe unlock, one generated model and original
  16x16 grid through the existing PNG encoder. Fifteen bilingual keys include
  only the missing Space label and analyzer text; numerical pressure is not
  relabelled as oxygen concentration or a real pressure unit.
- Root actual integration matches the author's required registrations/providers,
  except its deliberate config callback uses `CommonConfig::classicDevicesEnabled`
  rather than raw BooleanValue.get. This follows the existing server-switch
  default-before-load/test-override helper and preserves the accepted Boolean
  behavior; it is not asserted to be an exact copy of proposed example lines.
- `AtmosphereAnalyzerGameTests.java:65-350,372-387` declares ten 40-tick tests.
  Later source corrections add real registered-item/runtime comparisons for
  Earth/Moon/supplied/PENDING/committed and reserved stations, captured-catalog
  replacement and lifecycle ownership. The two ordinary-tick delays at184/234
  are compiled **but their world publication/timing remains unrun**. The finite
  637-observation room model explains the fixture budget, not global scheduling
  or proof that a registered manager has published the expected result.

## Actual independent commands and results

All scripts used Python `-B`, process-local D TEMP/TMP/TMPDIR; Java also used own
D `java.io.tmpdir`. C dependencies/JDK were read-only. No helper/output was
created on C. No Gradle, DataGen, GameTest, native server, client, network,
dependency install, source edit, Git mutation or cleanup was run here.

| Own entrypoint / command | Actual observation |
| --- | --- |
| `intake01.py`, `primary02.py`, `central03.py`, `static04.py` | Initial intake/selected primary facts/central checks exit0; nine Python static/model controls passed. Two mistaken read locators were preserved as transcriptions, not fabricated raw logs. |
| `final_intake05.py` | Exit0; 61 payloads,17 author and8 central postimages exact; three patch checks0; author XML independently parsed:19/6 red, then19/0 twice in5 suites. |
| `replay06.py` | Reviewer javac exit1/2.314s, zero tests.34 EngineRunner errors because compile-only classpath omitted the pinned runtime engine jars. Candidate source was not changed. |
| `replay07.py` | Fresh javac exit0/2.413s for all9 main/5 test classes, literal existing MinecraftBootstrap and the reviewer engine adapter. Three ResourceLocation deprecation warnings retained. JVM option initialization then exit1/0.045s, zero tests: reviewer Windows absolute `-Xlog` path escaping was invalid. |
| `replay08.py` | Authorized JVM-only retry, unchanged compiled output and five real Jupiter selectors; relative own-D class-load log. Exit0/3.801s; discovered/executed19 tests,5 fresh XML suites,0 failure/error/skip/failed-container. |
| `final09.py` then `final10.py` | First static attribution assertion exit1 mistakenly treated synthetic lambda enclosing-class source labels as file URLs. Corrected file-backed versus synthetic attribution exit0; original failure preserved. Exact original ServiceTest differs only by existing bootstrap setup, no assertion change. Nine final Python static/model controls pass. |
| `scope11.py` | Exit0;2,811 named baseline pins and17+8 final postimages exact; ten40-tick GT declarations counted, not executed. |

The JVM-only retry started `2026-10-04T17:35:59.018763+00:00`. Fresh precheck:
C10,172,825,600 and D339,195,985,920 bytes free. Each JVM/compiler heap was<=1GiB,
ActiveProcessorCount2; no shared cache writes. There is no known reviewer Java
left running; the slot was released immediately after its terminal result.

The independent engine adapter executes `JupiterTestEngine.discover/execute`,
not a reflection loop or weakened assertion substitute. All five test classes
load from own `scoped-07/classes`, including their existing BeforeAll. Actual
class-loading records identify the pinned mapped47.4.10 JAR
`95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e`
for selected native classes. Existing celestial/PNG dependencies come from
observed author baseline compiled classes; they were not independently rebuilt.
The 124 file dependencies,1,881 baseline class files,1,198 resources,17+8 source
postimages and27 own compiled classes are unchanged across the replay. This
observed standalone classpath is not a Forge/ModLauncher server identity claim.

Raw attempts/commands/results/XML are retained in `scoped-06`, `scoped-07` and
`scoped-08`; the explicit final execution receipt is
[scoped08 receipt](D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-source-review-5ddc460a12/scoped-08/RECEIPT-01.json).
No entire log is described as warning-free: the terminal-capability warning and
compiler deprecations remain visible.

## Remaining acceptance obligations / non-goals

Root must integrate exact source/central pins, compile and run central config
tests, full build/regression and generated resources twice, then execute all ten
registered GameTests with their assertions/deadlines intact. Any scheduling or
bootstrap failure must be preserved and diagnosed, not guessed away from these
unit/model results. Old atmosphere/suit/context/API data and resources must stay
unchanged except the adopted additive resources/localization.

Actual native registered-item use, receiving-player/chat, reconnect/restart,
distinct-host old-handle behavior and source-backed owned player/record fixtures
remain separate. The unresolved synthetic native-player contract cannot be
admitted by this source review. Real V1/V2 are still required; connected GameTest
mocks are not real clients. No C18 ledger unit, C18 batch or v1.8 Required Gate is
closed here; prior unrelated native FAILs are not erased or borrowed.
