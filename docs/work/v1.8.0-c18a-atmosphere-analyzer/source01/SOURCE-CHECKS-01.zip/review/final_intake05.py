import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

OUT = pathlib.Path(__file__).resolve().parent
AUTHOR = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
CENTRAL = pathlib.Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')

def digest(b):
    return hashlib.sha256(b).hexdigest()

def pin(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': digest(b)}

def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def run(args, cwd):
    r = subprocess.run(args, cwd=cwd, capture_output=True)
    return {'argv': args, 'cwd': str(cwd), 'exit': r.returncode,
            'stdout': r.stdout.decode('utf-8', errors='replace'), 'stderr': r.stderr.decode('utf-8', errors='replace')}

manifest = load(AUTHOR / 'INTERNAL-MANIFEST.json')
assert pin(AUTHOR / 'INTERNAL-MANIFEST.json')['sha256'] == 'd9b53421547e16b24da6491cb73da0f8f73ed50992d2c71b4c8331711df8057c'
payload = {name: pin(AUTHOR / name) for name in manifest['files']}
assert payload == manifest['files']
assert len(payload) == 61 and sum(v['bytes'] for v in payload.values()) == 1448902
owned = load(AUTHOR / 'OWNED-FILES-01.json')
assert pin(AUTHOR / 'OWNED-FILES-01.json')['sha256'] == '2e556a1bef567bb3faf8c6c745573e8b2f7a21499e6266793398cd27f121b13f'
owned_now = {name: pin(WT / name) for name in owned['files']}
assert owned_now == owned['files']
assert len(owned_now) == 17 and len([p for p in owned_now if p.endswith('.java')]) == 14
central = load(CENTRAL / 'ROOT-CENTRAL-01.json')
assert pin(CENTRAL / 'ROOT-CENTRAL-01.json')['sha256'] == '059c7b4164e25c2d6cb47dace2fea77b4f091c6fa85a6fa042391af3098bb5d6'
central_now = {}
preimages = {}
for entry in central['files']:
    name = entry['path']
    central_now[name] = pin(ROOT / name)
    assert central_now[name] == {'bytes': entry['post_bytes'], 'sha256': entry['post_sha256']}
    r = subprocess.run(['git', 'show', central['base_commit'] + ':' + name], cwd=ROOT, capture_output=True)
    if entry['base_exists']:
        assert r.returncode == 0 and digest(r.stdout) == entry['base_sha256']
        preimages[name] = {'bytes': len(r.stdout), 'sha256': digest(r.stdout)}
    else:
        assert r.returncode != 0
        preimages[name] = {'absent_at_base': True, 'git_show_exit': r.returncode}
checks = [run(['git', 'apply', '--check', '--reverse', str(AUTHOR / 'SOURCE-01.patch')], WT),
          run(['git', 'apply', '--check', '--reverse', str(CENTRAL / 'ROOT-CENTRAL-01.patch')], ROOT),
          run(['git', 'apply', '--check', str(CENTRAL / 'ROOT-CENTRAL-01.patch')], WT)]
assert all(r['exit'] == 0 for r in checks)
xml = {}
for round_no in (1, 2, 3):
    sums = dict(tests=0, failures=0, errors=0, skipped=0)
    entries = {}
    for p in sorted((AUTHOR / ('scoped-%02d-xml' % round_no)).glob('*.xml')):
        tree = ET.parse(p).getroot()
        for k in sums:
            sums[k] += int(tree.attrib[k])
        entries[p.name] = {'pin': pin(p), 'counts': tree.attrib, 'actual_testcases': len(tree.findall('testcase'))}
        assert len(tree.findall('testcase')) == int(tree.attrib['tests'])
    xml[str(round_no)] = {'suites': len(entries), 'counts': sums, 'entries': entries}
assert xml['1']['counts'] == dict(tests=19, failures=6, errors=0, skipped=0)
assert xml['2']['counts'] == xml['3']['counts'] == dict(tests=19, failures=0, errors=0, skipped=0)
cp = load(AUTHOR / 'CLASSPATH-OBSERVATION-01.json')
external_files = {}
for name, observed in cp['entry_observations'].items():
    if observed['kind'] == 'file':
        actual = pin(pathlib.Path(name))
        assert actual == {k: observed[k] for k in ('bytes', 'sha256')}
        external_files[name] = actual
main = WT / 'build/classes/java/main'
compiled = {name: pin(main / name) for name in cp['main_compiled_classes_observed']}
assert compiled == cp['main_compiled_classes_observed']
support = cp['test_support_source']
assert pin(WT / support['path']) == {k: support[k] for k in ('bytes', 'sha256')}
r = subprocess.run(['git', 'show', support['base_commit'] + ':' + support['path']], cwd=WT, capture_output=True)
assert r.returncode == 0 and digest(r.stdout) == support['sha256']
resources = {}
for name in cp['classpath']['runtime']:
    path = pathlib.Path(name)
    if 'build' in path.parts and 'resources' in path.parts and path.exists():
        resources[str(path)] = {str(p.relative_to(path)).replace('\\', '/'): pin(p) for p in sorted(path.rglob('*')) if p.is_file()}
result = {'qualification': 'Exact final frozen author/Root central intake; observed external dependencies are not portable payloads or native proof.',
          'author_manifest': pin(AUTHOR / 'INTERNAL-MANIFEST.json'), 'payload_files': payload,
          'author_source': owned_now, 'central_source': central_now, 'central_preimages': preimages,
          'patch_checks': checks, 'xml': xml, 'classpath_observation': pin(AUTHOR / 'CLASSPATH-OBSERVATION-01.json'),
          'external_files': external_files, 'compiled_class_observations': compiled,
          'resources_observed': resources, 'support_source': support,
          'source_base': owned['base_commit'], 'root_head_observed': run(['git', 'rev-parse', 'HEAD'], ROOT),
          'author_head_observed': run(['git', 'rev-parse', 'HEAD'], WT),
          'root_governance': pin(ROOT / 'AGENTS.md')}
(OUT / 'FINAL-INTAKE-05.json').write_text(json.dumps(result, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print('Verified 61 author payloads / 17 postimages / 8 central postimages; patch checks 0; author XML 19/6 then 19/0 twice.')
print('Observed dependencies: %d external files, %d main class files, %d resource files; no exports.' % (len(external_files), len(compiled), sum(len(v) for v in resources.values())))
