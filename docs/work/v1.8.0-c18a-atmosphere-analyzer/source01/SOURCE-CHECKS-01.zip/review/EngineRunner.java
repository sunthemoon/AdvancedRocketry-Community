import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import org.junit.jupiter.engine.JupiterTestEngine;
import org.junit.platform.engine.*;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.engine.support.descriptor.MethodSource;

/** Reviewer-owned engine adapter: retains Jupiter discovery, assertions and lifecycle. */
public final class EngineRunner {
    private static final List<String> CLASSES = List.of(
        "io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AnalyzerReadingTest",
        "io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerServiceTest",
        "io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerFeedbackTest",
        "io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerDataTest",
        "io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerLanguageTest");
    private static final ConfigurationParameters PARAMETERS = new ConfigurationParameters() {
        public Optional<String> get(String key) { return Optional.empty(); }
        public Optional<Boolean> getBoolean(String key) { return Optional.empty(); }
        public int size() { return 0; }
        public Set<String> keySet() { return Set.of(); }
    };
    private record Row(TestDescriptor descriptor, TestExecutionResult result, String skipped, long nanos) { }
    private static String xml(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\"", "&quot;").replace("'", "&apos;");
    }
    public static void main(String[] args) throws Exception {
        Path output = Path.of(args[0]);
        Files.createDirectories(output);
        List<DiscoverySelector> selectors = new ArrayList<>();
        for (String name : CLASSES) {
            Class<?> type = Class.forName(name, false, EngineRunner.class.getClassLoader());
            System.out.println("SELECT " + name + " source=" + type.getProtectionDomain().getCodeSource().getLocation());
            selectors.add(DiscoverySelectors.selectClass(type));
        }
        EngineDiscoveryRequest request = new EngineDiscoveryRequest() {
            public <T extends DiscoverySelector> List<T> getSelectorsByType(Class<T> type) {
                return selectors.stream().filter(type::isInstance).map(type::cast).toList();
            }
            public <T extends DiscoveryFilter<?>> List<T> getFiltersByType(Class<T> type) { return List.of(); }
            public ConfigurationParameters getConfigurationParameters() { return PARAMETERS; }
        };
        JupiterTestEngine engine = new JupiterTestEngine();
        System.out.println("ENGINE " + engine.getId() + " source=" + engine.getClass().getProtectionDomain().getCodeSource().getLocation());
        TestDescriptor root = engine.discover(request, UniqueId.forEngine(engine.getId()));
        long discovered = root.getDescendants().stream().filter(TestDescriptor::isTest).count();
        System.out.println("DISCOVERED " + discovered);
        List<Row> rows = new ArrayList<>();
        List<String> failedContainers = new ArrayList<>();
        Map<String, Long> started = new HashMap<>();
        engine.execute(new ExecutionRequest(root, new EngineExecutionListener() {
            public void executionStarted(TestDescriptor descriptor) { started.put(descriptor.getUniqueId().toString(), System.nanoTime()); }
            public void executionSkipped(TestDescriptor descriptor, String reason) {
                if (descriptor.isTest()) { rows.add(new Row(descriptor, null, reason, 0)); }
                System.out.println("SKIPPED " + descriptor.getUniqueId() + " " + reason);
            }
            public void executionFinished(TestDescriptor descriptor, TestExecutionResult result) {
                long nanos = System.nanoTime() - started.getOrDefault(descriptor.getUniqueId().toString(), System.nanoTime());
                if (descriptor.isTest()) { rows.add(new Row(descriptor, result, null, nanos)); }
                else if (result.getStatus() != TestExecutionResult.Status.SUCCESSFUL) { failedContainers.add(descriptor.getUniqueId().toString()); }
                System.out.println("RESULT " + descriptor.getUniqueId() + " " + result.getStatus());
                result.getThrowable().ifPresent(Throwable::printStackTrace);
            }
        }, PARAMETERS));
        int failures = 0, errors = 0, skipped = 0;
        for (String className : CLASSES) {
            List<Row> suite = rows.stream().filter(r -> r.descriptor().getSource().orElse(null) instanceof MethodSource source
                && source.getClassName().equals(className)).toList();
            int sf = 0, se = 0, ss = 0;
            for (Row row : suite) {
                if (row.skipped() != null || row.result().getStatus() == TestExecutionResult.Status.ABORTED) { ss++; }
                else if (row.result().getStatus() == TestExecutionResult.Status.FAILED) {
                    if (row.result().getThrowable().orElse(null) instanceof AssertionError) { sf++; } else { se++; }
                }
            }
            failures += sf; errors += se; skipped += ss;
            try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(output.resolve("TEST-" + className + ".xml"), StandardCharsets.UTF_8))) {
                writer.printf("<testsuite name=\"%s\" tests=\"%d\" failures=\"%d\" errors=\"%d\" skipped=\"%d\">%n", className, suite.size(), sf, se, ss);
                for (Row row : suite) {
                    MethodSource source = (MethodSource) row.descriptor().getSource().orElseThrow();
                    writer.printf("<testcase classname=\"%s\" name=\"%s\" time=\"%.9f\">", className, xml(source.getMethodName()), row.nanos() / 1e9);
                    if (row.skipped() != null) { writer.printf("<skipped message=\"%s\"/>", xml(row.skipped())); }
                    else if (row.result().getStatus() != TestExecutionResult.Status.SUCCESSFUL) {
                        Throwable thrown = row.result().getThrowable().orElse(null);
                        String kind = row.result().getStatus() == TestExecutionResult.Status.ABORTED ? "skipped" : thrown instanceof AssertionError ? "failure" : "error";
                        writer.printf("<%s message=\"%s\">%s</%s>", kind, xml(String.valueOf(thrown)), xml(String.valueOf(thrown)), kind);
                    }
                    writer.println("</testcase>");
                }
                writer.println("</testsuite>");
            }
        }
        System.out.printf("SUMMARY discovered=%d executed=%d suites=%d failures=%d errors=%d skipped=%d failedContainers=%d%n",
            discovered, rows.size(), CLASSES.size(), failures, errors, skipped, failedContainers.size());
        if (failures + errors + skipped != 0 || !failedContainers.isEmpty() || discovered != rows.size() || rows.isEmpty()) { System.exit(1); }
    }
}
