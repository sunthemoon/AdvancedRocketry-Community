"""Narrow class-log parser correction: synthetic lambdas name their enclosing class, not a file URL."""
import hashlib
import json
import pathlib

out = pathlib.Path(__file__).resolve().parent
old = (out / 'final09.py').read_text(encoding='utf-8')
corrections = {
    "    assert not target.exists()\n    target.write_bytes(origin.read_bytes())":
        "    if not target.exists(): target.write_bytes(origin.read_bytes())",
    "assert loaded_owned and all('/scoped-07/classes/' in line for line in loaded_owned)":
        "file_loaded_owned = [line for line in loaded_owned if ' source: file:' in line]\nassert file_loaded_owned and all('/scoped-07/classes/' in line for line in file_loaded_owned)\nassert all('$$Lambda$' in line for line in loaded_owned if line not in file_loaded_owned)",
    "'owned_loaded_lines': loaded_owned": "'owned_file_loaded_lines': file_loaded_owned, 'synthetic_owned_lines': [line for line in loaded_owned if line not in file_loaded_owned]",
}
new = old
for before, after in corrections.items():
    assert new.count(before) == 1
    new = new.replace(before, after)
(out / 'CLASS-LOG-CORRECTION-10.json').write_text(json.dumps({'old_script_sha256': hashlib.sha256(old.encode()).hexdigest(),
    'new_derived_script_sha256': hashlib.sha256(new.encode()).hexdigest(), 'corrections': corrections,
    'qualification': 'Static tool parser correction only; preserves original assertion failure; no Java/input changes.'}, indent=2) + '\n', encoding='utf-8')
exec(compile(new, str(out / 'final10.py'), 'exec'))
