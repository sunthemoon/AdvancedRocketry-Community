"""Read only named primary declarations/references; do not export native bodies."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

B = Path(__file__).resolve().parent
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
sha = lambda data: hashlib.sha256(data).hexdigest()
parser = Path('D:/ARCE-Task-Evidence/v1.8.0/aglf-94222005ae/debug_primary02.py')
parser_data = parser.read_bytes()
assert sha(parser_data) == '001f5479d2278b80a3a1ca965445d9c756629f43b6a83aa34e6b6471a2631167'
nodes = [n for n in ast.parse(parser_data).body
         if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in ('R', 'parse')]
namespace = {'struct': struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser), 'exec'), namespace)
jar = Path('C:/Users/Administrator/.gradle/caches/forge_gradle/minecraft_user_repo/'
    'net/minecraftforge/forge/1.20.1-47.4.10_mapped_official_1.20.1/'
    'forge-1.20.1-47.4.10_mapped_official_1.20.1.jar')
before = sha(jar.read_bytes())
assert before == '95eecc5985233d83a6571299f89f02de034267646da171f7b36a5be2d394d71e'
requests = {
    'net/minecraft/server/level/ServerPlayer.class': {'hasDisconnected', 'sendSystemMessage', 'isSpectator', 'isCreative'},
    'net/minecraft/world/item/ItemCooldowns.class': {'tick', 'isOnCooldown', 'getCooldownPercent', 'addCooldown'},
    'net/minecraft/world/entity/LivingEntity.class': {'getItemInHand'},
    'net/minecraft/world/level/Level.class': {'isInSpawnableBounds'},
    'net/minecraft/server/level/ServerChunkCache.class': {'getChunkNow'},
}
out = {'jar_path': str(jar), 'jar_sha256': before, 'parser_sha256': sha(parser_data),
       'classes': {}, 'java_launches': 0,
       'qualification': 'configured mapped primary class identities; not a measured author runtime classpath'}
with zipfile.ZipFile(jar) as archive:
    for name, wanted in requests.items():
        data = archive.read(name)
        parsed = namespace['parse'](data, wanted)
        assert wanted.issubset({m.split('(')[0] for m in parsed['selected_methods']})
        methods = {}
        for name_desc, info in parsed['selected_methods'].items():
            methods[name_desc] = {'access': info['access'],
                'references': [{'offset': i['offset'], 'reference': i['reference']}
                    for i in info['instructions'] if i['reference'] is not None],
                'branch_targets': [{'offset': i['offset'], 'opcode': i['opcode_hex'], 'target': i['branch_target']}
                    for i in info['instructions'] if i['branch_target'] is not None],
                'literal_constants': [{'offset': i['offset'], 'opcode': i['opcode_hex'], 'operand': i['operand_hex']}
                    for i in info['instructions'] if i['opcode_hex'] in ('0x3', '0x4', '0x5', '0x6', '0x7', '0x8', '0x10', '0x11')]}
        out['classes'][name] = {'bytes': len(data), 'sha256': sha(data), 'methods': methods}
assert sha(jar.read_bytes()) == before
out['jar_unchanged'] = True
(B / 'PRIMARY-02.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'classes': len(out['classes']), 'selected_methods': sum(len(v['methods']) for v in out['classes'].values()),
                  'jar_unchanged': True, 'java_launches': 0}))
