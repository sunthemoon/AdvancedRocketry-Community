"""Read-only exact central patch checks and declaration accounting."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

B = Path(__file__).resolve().parent
for k in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[k] = str(B / 'process-temp')
W = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
R = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-integration-20261005-01')
sha = lambda d: hashlib.sha256(d).hexdigest()
record = E / 'ROOT-CENTRAL-01.json'
patch = E / 'ROOT-CENTRAL-01.patch'
assert sha(record.read_bytes()) == '059c7b4164e25c2d6cb47dace2fea77b4f091c6fa85a6fa042391af3098bb5d6'
assert sha(patch.read_bytes()) == '8606b45ce17510f1ee963717d3a53267d97e38329a61cbdd2e3ec06a1e16c302'
receipt = json.loads(record.read_text(encoding='utf-8'))
assert len(receipt['files']) == 8
inputs = []
commands = []
for entry in receipt['files']:
    data = (R / entry['path']).read_bytes()
    assert len(data) == entry['post_bytes'] and sha(data) == entry['post_sha256']
    cmd = ['git', '-C', str(W), 'show', receipt['base_commit'] + ':' + entry['path']]
    done = subprocess.run(cmd, capture_output=True, check=False)
    if entry['base_exists']:
        assert done.returncode == 0 and sha(done.stdout) == entry['base_sha256']
    else:
        assert done.returncode != 0
        # The absent committed new-test path is the expected base observation,
        # not a failed patch or skipped assertion.
    commands.append({'command': cmd, 'exit': done.returncode, 'expected_absent': not entry['base_exists'],
                     'stderr': done.stderr.decode('utf-8', errors='replace')})
    inputs.append(entry)
for where, args in ((W, ['apply', '--check', str(patch)]),
                    (R, ['apply', '--check', '--reverse', str(patch)])):
    cmd = ['git', '-C', str(where), *args]
    done = subprocess.run(cmd, capture_output=True, check=False)
    commands.append({'command': cmd, 'exit': done.returncode,
                     'stdout': done.stdout.decode('utf-8', errors='replace'),
                     'stderr': done.stderr.decode('utf-8', errors='replace')})
    assert done.returncode == 0
p = R / 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfig.java'
post = p.read_text(encoding='utf-8')
cmd = ['git', '-C', str(W), 'show', receipt['base_commit'] + ':' + p.relative_to(R).as_posix()]
done = subprocess.run(cmd, capture_output=True, check=False)
assert done.returncode == 0
pre = done.stdout.decode('utf-8')
import re
definitions = lambda text: len(re.findall(r'\.define(?:InRange|ListAllowEmpty|List|Enum|InList)?\s*\(', text))
before_count, after_count = definitions(pre), definitions(post)
assert after_count == before_count + 1
assert '.define("lifeSupport.classicDevicesEnabled", true)' in post
pin_test = (R / 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/config/CommonConfigTest.java').read_text(encoding='utf-8')
assert 'assertEquals(70, countValues(CommonConfig.SPEC.getValues()))' in pin_test
out = {'schema': 1, 'inputs': inputs, 'record_sha256': sha(record.read_bytes()),
    'patch_sha256': sha(patch.read_bytes()), 'commands': commands,
    'source_define_call_counts': {'before': before_count, 'after': after_count,
        'scope': 'textual declaration count, not live ForgeConfigSpec/JUnit execution'},
    'pin_test_postimage_matches': True, 'patch_checks': 2, 'java_launches': 0,
    'qualification': 'source correspondence only; no automatic runtime/config/item/resource admission'}
(B / 'CENTRAL-03.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'postimages': len(inputs), 'checks': 2, 'define_call_delta': after_count - before_count,
                  'pin_test_exact70': True, 'java_launches': 0}))
