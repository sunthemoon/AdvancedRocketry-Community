"""Seal only selected own small reports/logs/results/XML/deltas; no whole source/JAR export."""
import hashlib
import json
import pathlib
import re

OUT = pathlib.Path(__file__).resolve().parent
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
scope = load(OUT / 'FINAL-SCOPE-11.json')
intake = load(OUT / 'FINAL-INTAKE-05.json')
WT = pathlib.Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
ROOT = pathlib.Path('D:/GitHub/AdvancedRocketry-Community')
for owner, table, directory in (('author', intake['author_source'], WT), ('central', intake['central_source'], ROOT)):
    for name, expected in table.items(): assert pin(directory / name) == expected, owner + ':' + name
report = OUT / 'REVIEW-01.md'
links = re.findall(r'\]\(([^)]+)\)', report.read_text(encoding='utf-8'))
checks = []
for link in links:
    p = pathlib.Path(link)
    assert p.is_file(), link
    assert OUT in p.parents, link
    checks.append({'link': link, 'pin': pin(p)})
payload = {}
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name not in ('INTERNAL-MANIFEST.json', 'SHA256SUMS.txt', 'SEAL-RESULT-12.json', 'seal-12.log', 'seal-12.exit'):
        payload[p.name] = pin(p)
for directory in ('scoped-06', 'scoped-07', 'scoped-08'):
    root = OUT / directory
    for p in sorted(root.rglob('*')):
        if p.is_file() and 'classes' not in p.relative_to(root).parts:
            payload[str(p.relative_to(OUT)).replace('\\', '/')] = pin(p)
manifest = {'qualification': 'Independent actual-source review; small selected own evidence only; compiled scratch/process-temp excluded; external read inputs are observational, not payloads. No source/runtime/Gate admission.',
            'source_base': scope['base_commit'], 'root_head_observed': scope['root_head_observed'],
            'author_manifest_sha256': intake['author_manifest']['sha256'],
            'unresolved_source_findings': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
            'report': pin(report), 'files': payload}
target = OUT / 'INTERNAL-MANIFEST.json'
assert not target.exists()
target.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
checksums = payload | {'INTERNAL-MANIFEST.json': pin(target)}
(OUT / 'SHA256SUMS.txt').write_text(''.join(v['sha256'] + '  ' + n + '\n' for n, v in sorted(checksums.items())), encoding='ascii')
for name, expected in payload.items(): assert pin(OUT / name) == expected
result = {'payload_files': len(payload), 'payload_bytes': sum(v['bytes'] for v in payload.values()),
          'report': pin(report), 'manifest': pin(target), 'checksum': pin(OUT / 'SHA256SUMS.txt'),
          'all_payload_checks': '0 mismatches', 'active_own_companion_links': checks,
          'java_remaining': False, 'zip_created': False, 'external_input_postchecks': 'author17+central8 exact'}
(OUT / 'SEAL-RESULT-12.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
