import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
OUT = Path(__file__).parent

def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

own = json.loads((OUT / 'OWNED-FILES-01.json').read_text())
assert all(digest(ROOT / name) == expected for name, expected in own['files'].items())
commands = [['git', '-C', str(ROOT), 'rev-parse', 'HEAD'],
            ['git', '-C', str(ROOT), 'diff', '--check'],
            ['git', '-C', str(ROOT), 'diff', '--exit-code'],
            ['git', '-C', str(ROOT), 'status', '--short']]
receipts = []
for command in commands:
    result = subprocess.run(command, capture_output=True, text=True)
    receipts.append({'command': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0
(OUT / 'FINAL-GIT-READONLY-01.json').write_text(json.dumps(receipts, indent=2) + '\n', encoding='utf-8')
assert not (OUT / 'INTERNAL-MANIFEST.json').exists()
payload = {str(path.relative_to(OUT)).replace('\\', '/'): digest(path)
           for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in ('INTERNAL-MANIFEST.json', 'SHA256SUMS.txt')}
manifest = {'qualification': 'Compact immutable review-ready source/evidence, no full source/runtime or JAR exports; external classpath is observational only.',
            'base_commit': own['base_commit'], 'files': payload}
(OUT / 'INTERNAL-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
entries = {**payload, 'INTERNAL-MANIFEST.json': digest(OUT / 'INTERNAL-MANIFEST.json')}
(OUT / 'SHA256SUMS.txt').write_text(''.join(info['sha256'] + '  ' + name + '\n' for name, info in sorted(entries.items())), encoding='utf-8')
print(json.dumps({'files': len(payload), 'payload_bytes': sum(info['bytes'] for info in payload.values()),
                  'manifest': digest(OUT / 'INTERNAL-MANIFEST.json'), 'report': digest(OUT / 'REPORT-01.md'),
                  'own_files': digest(OUT / 'OWNED-FILES-01.json'), 'patch': digest(OUT / 'SOURCE-01.patch'),
                  'handoff': digest(ROOT / 'docs/work/v1.8.0-c18a-atmosphere-analyzer/HANDOFF.md'),
                  'central_proposal': digest(ROOT / 'docs/work/v1.8.0-c18a-atmosphere-analyzer/PROPOSED-CENTRAL-INTEGRATION-01.md')}, indent=2))
