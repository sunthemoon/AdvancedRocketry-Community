# Tool observations

- Early source reads used three incorrect existing test filenames:
  `TutorialInventoryGameTests.java`, `BodyContextGameTests.java` and
  `celestial/service/CelestialCatalogTest.java`. PowerShell/rg reported missing
  paths. The correct existing helpers were then located with bounded Git/rg
  queries. These read failures did not change source or execute tests.
- Scoped round 01 is an actual failed Java run: 19 JUnit tests, six ServiceTest
  failures from missing MinecraftBootstrap test initialization. All five raw XML
  suites, command/log/result and the pre-fix test source are retained. The
  correction adds only the existing bootstrap setup; original assertions remain.
- The first unsealed source-check JSON was reused by the second check helper
  invocation before freeze. Both actual stdout logs remain, and the final named
  source-check receipt will bind the current final postimages. No failed Java
  log/XML, sealed record or prior source verdict was overwritten. The helper now
  refuses an existing output name. The original source-check file is retained as
  an intermediate observation, not the earlier source identity.
- ResourceLocation constructor deprecation warnings and the existing Gradle
  deprecation notice are preserved in raw compilation logs. No budget, timeout,
  dependency, original test or generated output was changed to suppress them.

All task-created files and per-process TEMP/TMP/TMPDIR/Java temp are under this
D evidence leaf or the assigned isolated worktree. No C helper/output was created.
No DataGen, GameTest, native server, client, Git commit/stage/push or cleanup ran.
