import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
OUT = Path(__file__).parent

def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''): sha.update(block)
    return {'bytes': path.stat().st_size, 'sha256': sha.hexdigest()}

source_check = json.loads((OUT / 'SOURCE-CHECK-FINAL-01.json').read_text())
assert source_check['failed'] == 0
names = sorted(source_check['owned_source'])
docs = ['docs/work/v1.8.0-c18a-atmosphere-analyzer/' + n for n in (
    'PROGRESS.md', 'HANDOFF.md', 'PROPOSED-CENTRAL-INTEGRATION-01.md')]
own = {'base_commit': '9135c20c34a402b7cf0715148aeb6683a35c1f50',
       'qualification': 'Uncommitted review-ready postimages, reproducible by the included new-file patch; not delivery.',
       'files': {name: digest(ROOT / name) for name in names + docs}}
for name in names:
    assert own['files'][name] == source_check['owned_source'][name]
(OUT / 'OWNED-FILES-01.json').write_text(json.dumps(own, indent=2) + '\n', encoding='utf-8')
patch = []
for name in names + docs:
    data = (ROOT / name).read_bytes()
    assert data.endswith(b'\n') and b'\r' not in data
    lines = data.decode('utf-8').splitlines(keepends=True)
    patch.extend([f'diff --git a/{name} b/{name}\n', 'new file mode 100644\n', '--- /dev/null\n',
                  f'+++ b/{name}\n', f'@@ -0,0 +1,{len(lines)} @@\n'] + ['+' + line for line in lines])
(OUT / 'SOURCE-01.patch').write_text(''.join(patch), encoding='utf-8', newline='\n')
command = ['git', '-C', str(ROOT), 'apply', '--reverse', '--check', str(OUT / 'SOURCE-01.patch')]
checked = subprocess.run(command, capture_output=True, text=True)
(OUT / 'patch-reverse-check-01.log').write_text(checked.stdout + checked.stderr, encoding='utf-8')
(OUT / 'patch-reverse-check-01.json').write_text(json.dumps({'command': command, 'exit': checked.returncode}, indent=2) + '\n', encoding='utf-8')
assert checked.returncode == 0

# Paths and hashes here observe the mutable read-input classpath, never inventory payloads outside this leaf.
log = (OUT / 'classpath-01.log').read_text(encoding='utf-8-sig')
classpath = {}
for label in ('RUNTIME', 'COMPILE'):
    prefix = 'ARCE_TEST_' + label + '_CLASSPATH='
    values = [line[len(prefix):] for line in log.splitlines() if line.startswith(prefix)]
    assert len(values) == 1
    classpath[label.lower()] = values[0].split(';')
external = {}
for name in sorted(set(classpath['runtime'] + classpath['compile'])):
    path = Path(name)
    if path.is_file(): external[name] = {'kind': 'file', **digest(path)}
    elif path.is_dir(): external[name] = {'kind': 'directory', 'qualification': 'Mutable read input; not a frozen payload or portable checksum target.'}
    else: external[name] = {'kind': 'absent_directory', 'qualification': 'Declared optional resource output; no producer was run.'}
main = ROOT / 'build/classes/java/main'
classes = {str(p.relative_to(main)).replace('\\', '/'): digest(p) for p in sorted(main.rglob('*.class'))}
observed = {'qualification': 'Observed scoped03 compiler/test read inputs. All entries outside this evidence leaf remain mutable, not packet checksums.',
            'classpath': classpath, 'entry_observations': external,
            'main_compiled_classes_observed': classes,
            'test_support_source': {'path': 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/testsupport/MinecraftBootstrap.java',
                                    'base_commit': own['base_commit'], **digest(ROOT / 'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/testsupport/MinecraftBootstrap.java')}}
(OUT / 'CLASSPATH-OBSERVATION-01.json').write_text(json.dumps(observed, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'owned_files': len(own['files']), 'own_source_files': len(names), 'patch_reverse_check': checked.returncode,
                  'runtime_classpath_entries': len(classpath['runtime']), 'compile_classpath_entries': len(classpath['compile']),
                  'observed_main_classfiles': len(classes)}, indent=2))
