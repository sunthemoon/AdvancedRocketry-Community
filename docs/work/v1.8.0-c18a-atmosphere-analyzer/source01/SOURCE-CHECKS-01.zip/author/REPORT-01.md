# C18a-01 isolated author result

This is an implementation handoff, not an independent review verdict, delivery,
contract acceptance or version Gate. The source base is the clean committed
`9135c20c34a402b7cf0715148aeb6683a35c1f50`; 17 new uncommitted postimages are bound
by [OWNED-FILES-01.json](OWNED-FILES-01.json) and [SOURCE-01.patch](SOURCE-01.patch).
No whole source/runtime or JAR export is included. Root owns actual central
changes, integration and every commit/push.

## Actual result

- Nine assigned main Java files and five corresponding scoped JUnit classes are
  implemented, together with three own task records. The tests contain 19 unique
  methods; ten registered GameTest declarations compiled but never ran.
- Scoped round 01 failed: 19 tests/five suites/six failures, from omitted existing
  MinecraftBootstrap setup. The raw XML/log/result and pre-fix test are retained.
  The setup correction did not remove/change an assertion or a budget.
- Scoped round 02 passed: 19 tests/five suites/zero failures, errors or skips.
- Final round 03 compiled the later GT coverage and passed the same 19 tests in
  five suites, zero failures, errors or skips; command exit 0 in 26 seconds.
- Final structural/source check passed 25 controls and found all 2,811 tracked
  source/build inputs byte-identical, including old generated and API source.
- The separate metadata-only Gradle task exited 0 in 10.524 seconds. It records
  127 runtime/121 compile classpath entries. The [classpath observation](CLASSPATH-OBSERVATION-01.json)
  includes the exact existing MinecraftBootstrap source and observed compiled
  baseline dependencies. These external paths are mutable read-input observations,
  **not packet checksum targets, portable payloads or native proof**. An independent
  javac replay must compile all nine owned main/five test postimages into its own
  output and put that output first, rather than execute the author's owned class
  implementations from `build/`.
- The generated new-file patch passed a read-only reverse `git apply --check`
  against the 17 actual postimages; its [receipt](patch-reverse-check-01.json)
  and raw output are retained. No Git index/commit or source file was changed by
  that check.

All task Java commands use the exact Java17.0.7 location, offline/no-daemon,
two workers, 2 GiB Gradle heap and per-process D temp recorded in command JSON.
Fresh C/D checks preceded each launch. Final metadata postcheck recorded
C 10,178,457,600 bytes and D 339,199,524,864 bytes free. The Java slot is released.

## Behavior/source boundaries

Only stable item `advancedrocketrycommunity:atmosphere_analyzer` / ledger unit
`item:atmAnalyser` is covered. The data/feedback/acquisition are NEW project work,
with exact committed pre-authoring provenance, not upstream asset or recipe
parity. The grid is independently authored in code and only the existing
deterministic material PNG encoder is reused. No external bitmap was opened as
an art reference or copied.

The service owns only a captured host binding; it queries the existing manager
and one catalog, uses committed station lookup acquired only at startup, checks
the loaded eye cell and refuses mixed catalog generations. Supplied/effective
breathing is distinct from ambient pressure/K; actual Space stays distinct from
the logical orbit body. The item uses server-authoritative actual hand/count,
shared two-tick vanilla cooldown, fixed localized chat, injected config/runtime
callbacks and no held-NBT inspection or suit/provider access. No schema, public
API export, packet, capability, arbitrary-position query, scan, progression event,
resource writer, native hook or new atmosphere truth store is added.

The central proposal is included in the new-file patch at the named own task
path; it is not an edit of central Java. Root's actual item/config/listener/
creative/provider/language integration and central tests require separate review.

## Limits and remaining work

GT source prepares actual registered use and runtime equality for Earth/Moon,
supplied/PENDING cells and committed/reserved stations; hand/cooldown/recipient,
held/suit data preservation, dirty/unloaded refusal, captured-catalog changes,
closed/off-thread handle and foreign lifecycle ownership checks, and crafting.
The registered manager's actual publication/timing is **unrun**. The two-room
delay/637-observation scanner model is a source prerequisite, not a world result.
Likewise a foreign lifecycle's same-host refusal is not proof of distinct real
server restart/old-handle behavior. Real native/C2S/client recipient, reconnect,
before/after restart, exact generated resources and V1/V2 remain unverified.

No DataGen, GameTest, native server, full build, client, dependency install,
source-world mutation, Git mutation or cleanup ran. The existing own build output
is retained temporarily for the separately authorized reviewer classpath read;
it is not packaged or treated as sealed evidence. Root will coordinate cleanup
after independent replay, without deleting original worlds or other-agent files.
The [tool observations](TOOL-OBSERVATIONS.md) preserve locator failures, the failed
JUnit round and the intermediate unsealed collector reuse. No original sealed
or failing Java evidence was rewritten.

The next current-version action is independent exact-source/central review,
committed Root integration and its required full regression/DataGen/GameTest,
legitimately owned native/player restart and real-client checks. All v1.8
Required Gates remain open; this source handoff cannot deliver the item ledger.
