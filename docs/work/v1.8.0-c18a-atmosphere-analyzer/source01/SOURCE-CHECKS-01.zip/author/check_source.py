import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
OUT = Path(__file__).parent
BASE = json.loads((OUT / 'BASELINE-01.json').read_text(encoding='utf-8'))
PKG = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/'
INSTRUMENT = PKG + 'atmosphere/instrument/'
PRODUCTION = [INSTRUMENT + name + '.java' for name in (
    'AnalyzerReading', 'AtmosphereAnalyzerService', 'AtmosphereAnalyzerRuntime',
    'AtmosphereAnalyzerLifecycle', 'AtmosphereAnalyzerItem', 'AtmosphereAnalyzerFeedback')]
PRODUCTION += [PKG + 'datagen/V180AtmosphereAnalyzerData.java', PKG + 'datagen/V180AtmosphereAnalyzerLanguage.java',
               PKG + 'gametest/AtmosphereAnalyzerGameTests.java']
TESTS = ['src/test/java/io/github/sunthemoon/advancedrocketrycommunity/' + name for name in (
    'atmosphere/instrument/AnalyzerReadingTest.java', 'atmosphere/instrument/AtmosphereAnalyzerServiceTest.java',
    'atmosphere/instrument/AtmosphereAnalyzerFeedbackTest.java', 'datagen/V180AtmosphereAnalyzerDataTest.java',
    'datagen/V180AtmosphereAnalyzerLanguageTest.java')]
DOCS = ['docs/work/v1.8.0-c18a-atmosphere-analyzer/' + name for name in (
    'PROGRESS.md', 'PROPOSED-CENTRAL-INTEGRATION-01.md')]

def pin(data): return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

checks = []
def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

drift = [name for name, expected in BASE['tracked_baseline'].items() if pin((ROOT / name).read_bytes()) != expected]
check('all 2811 tracked source/build inputs unchanged', not drift, drift)
check('isolated Git base unchanged', subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip() == BASE['base'])
check('live Root governance exact', pin(Path('D:/GitHub/AdvancedRocketry-Community/AGENTS.md').read_bytes()) == BASE['live_agents'])
for field, name in [('task', 'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md'),
                    ('disposition', 'docs/work/v1.8.0-c18a-atmosphere-analyzer/REVIEW-DISPOSITION-01.md'),
                    ('provenance', 'docs/provenance/v1.8.0-c18a-analyzer-new-resources.md')]:
    check(field + ' unchanged', pin((ROOT / name).read_bytes()) == BASE[field])
other = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '--others', '--exclude-standard', '-z', '--', 'src', 'docs/work/v1.8.0-c18a-atmosphere-analyzer']).decode().split('\0')
other = sorted(n for n in other if n)
allowed = set(PRODUCTION + TESTS + DOCS + ['docs/work/v1.8.0-c18a-atmosphere-analyzer/HANDOFF.md'])
check('writes limited to declared nine Java, corresponding tests and task records', set(other) <= allowed, other)
check('exact nine owned main Java classes', all((ROOT / name).is_file() for name in PRODUCTION))
source = {name: (ROOT / name).read_text(encoding='utf-8') for name in PRODUCTION + TESTS}
check('no common client imports', all('net.minecraft.client.' not in source[n] for n in PRODUCTION))
check('focused classes below 500 lines', all(len(source[n].splitlines()) <= 500 for n in PRODUCTION), {n: len(source[n].splitlines()) for n in PRODUCTION})
check('no owned Java trailing whitespace', all(not re.search(r'[ \t]+$', line) for data in source.values() for line in data.splitlines()))
service = source[INSTRUMENT + 'AtmosphereAnalyzerService.java']
item = source[INSTRUMENT + 'AtmosphereAnalyzerItem.java']
lifecycle = source[INSTRUMENT + 'AtmosphereAnalyzerLifecycle.java']
runtime = source[INSTRUMENT + 'AtmosphereAnalyzerRuntime.java']
reading = source[INSTRUMENT + 'AnalyzerReading.java']
feedback = source[INSTRUMENT + 'AtmosphereAnalyzerFeedback.java']
check('eye expression and loaded-only chunk lookup', 'BlockPos.containing(x, y, z)' in service and 'player.getEyeY()' in service and '.getChunkNow(' in service)
check('query path excludes loaders, scans, saves and equipment providers', not re.search(r'getChunkAt\(|StationRegistrySavedData\.get|\.tick\(|markDirty\(|setChanged\(|\.save\(|getCapability\(|SpaceSuit|SuitEquipment', service + item))
check('only startup acquires station SavedData once', lifecycle.count('StationRegistrySavedData.get(server)') == 1 and 'stations::findAt' in lifecycle)
check('captured catalog resolver and post-composition identity check', 'new WorldLocation(level.dimension(), eye), catalog' in service and service.index('AnalyzerReading reading = compose') < service.index('active.catalogs().current().orElse(null) != catalog'))
check('permanent close clears binding', 'public void close() { binding = null; }' in service)
check('runtime removes only matching handle', 'if (active == service)' in runtime and 'active != null && active != service' in runtime)
check('lifecycle stopping and stopped match owning server', 'service.owns(server)' in lifecycle and 'onServerStopping' in lifecycle and 'onServerStopped' in lifecycle)
check('invalid current player and foreign actual Level identity guarded', 'getPlayer(player.getUUID()) == player' in service and 'server.getLevel(player.serverLevel().dimension()) == player.serverLevel()' in service)
check('cooldown precedes config and reading callbacks', item.index('isOnCooldown') < item.index('enabled.getAsBoolean()') < item.index('addCooldown'))
check('held item NBT never inspected/copied/serialized by item', not re.search(r'getTag|save\(|copy\(|deserialize|serialize|setTag', item))
check('one fixed chat publication not hazard actionbar', item.count('sendSystemMessage(') == 1 and 'displayClientMessage' not in item)
check('reading has no world/player/item/volume identity references', not re.search(r'MinecraftServer|ServerPlayer|ServerLevel|ItemStack|VolumeId|net\.minecraft', reading))
check('finite Double.toString output and stable body fallback', feedback.count('Double.toString(') == 2 and 'translatableWithFallback' in feedback)
check('no nonexistent central config/item field references', 'CommonConfig.' not in item and 'ModItems.ATMOSPHERE_ANALYZER' not in source[PKG + 'gametest/AtmosphereAnalyzerGameTests.java'])
rounds = {}
for folder in sorted(OUT.glob('scoped-*-xml')):
    total = {'tests': 0, 'suites': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
    for file in folder.glob('*.xml'):
        suite = ET.parse(file).getroot(); total['suites'] += 1
        for field in ('tests', 'failures', 'errors', 'skipped'): total[field] += int(suite.attrib[field])
    rounds[folder.name] = total
result = {'checks': checks, 'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks),
          'tracked_baseline_count': len(BASE['tracked_baseline']), 'junit_rounds': rounds,
          'owned_source': {n: pin((ROOT / n).read_bytes()) for n in PRODUCTION + TESTS}}
target = OUT / (sys.argv[1] if len(sys.argv) > 1 else 'SOURCE-CHECK-FINAL-01.json')
if target.exists():
    raise RuntimeError('Refusing to overwrite a source-check receipt')
target.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'checks': len(checks), 'failed': result['failed'], 'junit_rounds': rounds}, indent=2))
raise SystemExit(bool(result['failed']))
