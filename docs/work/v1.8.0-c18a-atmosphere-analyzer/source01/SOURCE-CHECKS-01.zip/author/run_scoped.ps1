param([string]$Round = 'scoped-01')
$ErrorActionPreference = 'Stop'
$Evidence = $PSScriptRoot
$Root = 'D:/GitHub/arce-v180-c18a-analyzer-20261005'
$env:TEMP = $Evidence
$env:TMP = $Evidence
$env:TMPDIR = $Evidence
$env:JAVA_HOME = 'C:/Program Files/Java/jdk-17.0.7'
$env:PATH = "$env:JAVA_HOME/bin;$env:PATH"
$Disks = @(Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:' OR DeviceID='D:'" | Select-Object DeviceID, FreeSpace)
$Disks | ConvertTo-Json | Set-Content -LiteralPath "$Evidence/$Round-disks.json" -Encoding utf8
if ($Disks.Count -ne 2 -or @($Disks | Where-Object FreeSpace -LT 10000000000).Count -ne 0) {
    throw 'Both C and D need 10,000,000,000 bytes free before Java'
}
$Args = @('--offline', '--no-daemon', '--max-workers=2', "-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=$Evidence",
    "-Djava.io.tmpdir=$Evidence", 'compileJava', 'compileTestJava', 'test',
    '--tests', 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AnalyzerReadingTest',
    '--tests', 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerServiceTest',
    '--tests', 'io.github.sunthemoon.advancedrocketrycommunity.atmosphere.instrument.AtmosphereAnalyzerFeedbackTest',
    '--tests', 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerDataTest',
    '--tests', 'io.github.sunthemoon.advancedrocketrycommunity.datagen.V180AtmosphereAnalyzerLanguageTest')
$Started = [DateTime]::UtcNow
Set-Location -LiteralPath $Root
@{ cwd=$Root; executable="$Root/gradlew.bat"; arguments=$Args; started=$Started.ToString('o'); javaHome=$env:JAVA_HOME; temp=$Evidence } |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$Evidence/$Round-command.json" -Encoding utf8
& "$Root/gradlew.bat" @Args *> "$Evidence/$Round.log"
$Code = $LASTEXITCODE
$Ended = [DateTime]::UtcNow
@{ exit=$Code; started=$Started.ToString('o'); ended=$Ended.ToString('o'); elapsedSeconds=($Ended-$Started).TotalSeconds } |
    ConvertTo-Json | Set-Content -LiteralPath "$Evidence/$Round-result.json" -Encoding utf8
Write-Output "Scoped round $Round exit $Code"
Get-Content -LiteralPath "$Evidence/$Round.log" -Tail 45
exit $Code
