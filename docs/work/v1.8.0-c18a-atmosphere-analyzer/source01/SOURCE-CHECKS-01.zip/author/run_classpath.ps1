$ErrorActionPreference = 'Stop'
$Evidence = $PSScriptRoot
$Root = 'D:/GitHub/arce-v180-c18a-analyzer-20261005'
$env:TEMP=$Evidence; $env:TMP=$Evidence; $env:TMPDIR=$Evidence
$env:JAVA_HOME='C:/Program Files/Java/jdk-17.0.7'
$env:PATH="$env:JAVA_HOME/bin;$env:PATH"
$Disks = @(Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:' OR DeviceID='D:'" | Select-Object DeviceID,FreeSpace)
$Disks | ConvertTo-Json | Set-Content -LiteralPath "$Evidence/classpath-01-disks.json" -Encoding utf8
if ($Disks.Count -ne 2 -or @($Disks | Where-Object FreeSpace -LT 10000000000).Count -ne 0) { throw 'Insufficient C/D free bytes' }
$Arguments=@('--offline','--no-daemon','--max-workers=2',"-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=$Evidence",
    "-Djava.io.tmpdir=$Evidence",'--init-script',"$Evidence/classpath.init.gradle",'c18AnalyzerTestClasspath')
$Started=[DateTime]::UtcNow
@{cwd=$Root;executable="$Root/gradlew.bat";arguments=$Arguments;started=$Started.ToString('o');javaHome=$env:JAVA_HOME;temp=$Evidence} |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$Evidence/classpath-01-command.json" -Encoding utf8
Set-Location -LiteralPath $Root
& "$Root/gradlew.bat" @Arguments *> "$Evidence/classpath-01.log"
$Code=$LASTEXITCODE; $Ended=[DateTime]::UtcNow
@{exit=$Code;started=$Started.ToString('o');ended=$Ended.ToString('o');elapsedSeconds=($Ended-$Started).TotalSeconds} |
    ConvertTo-Json | Set-Content -LiteralPath "$Evidence/classpath-01-result.json" -Encoding utf8
Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:' OR DeviceID='D:'" | Select-Object DeviceID,FreeSpace |
    ConvertTo-Json | Set-Content -LiteralPath "$Evidence/classpath-01-postdisks.json" -Encoding utf8
Write-Output "Classpath metadata exit $Code"
Get-Content -LiteralPath "$Evidence/classpath-01.log" -Tail 8
exit $Code
