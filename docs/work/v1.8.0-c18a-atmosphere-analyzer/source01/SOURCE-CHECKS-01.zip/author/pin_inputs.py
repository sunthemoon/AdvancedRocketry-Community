import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
OUT = Path(__file__).parent

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

names = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '-z']).decode().split('\0')
scope = [n for n in names if n.startswith('src/') or n in ('build.gradle', 'gradle.properties')]
result = {
    'base': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip(),
    'branch': subprocess.check_output(['git', '-C', str(ROOT), 'branch', '--show-current']).decode().strip(),
    'live_agents': pin(Path('D:/GitHub/AdvancedRocketry-Community/AGENTS.md')),
    'task': pin(ROOT / 'docs/work/v1.8.0-c18a-atmosphere-analyzer/TASK.md'),
    'disposition': pin(ROOT / 'docs/work/v1.8.0-c18a-atmosphere-analyzer/REVIEW-DISPOSITION-01.md'),
    'provenance': pin(ROOT / 'docs/provenance/v1.8.0-c18a-analyzer-new-resources.md'),
    'tracked_baseline': {n: pin(ROOT / n) for n in scope},
}
(OUT / 'BASELINE-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Pinned base', result['base'], 'and', len(scope), 'tracked source/build inputs')
