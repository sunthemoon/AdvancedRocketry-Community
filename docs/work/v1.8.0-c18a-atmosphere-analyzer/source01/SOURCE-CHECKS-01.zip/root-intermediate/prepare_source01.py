"""Prepare only the exact frozen seventeen new author postimages for apply_patch."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
AUTHOR = Path('D:/GitHub/arce-v180-c18a-analyzer-20261005')
EVIDENCE = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
OUT = Path(__file__).resolve().parent
raw = (EVIDENCE / 'OWNED-FILES-01.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '2e556a1bef567bb3faf8c6c745573e8b2f7a21499e6266793398cd27f121b13f'
owned = json.loads(raw)
assert owned['base_commit'] == '9135c20c34a402b7cf0715148aeb6683a35c1f50'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=AUTHOR).decode().strip() == owned['base_commit']
assert len(owned['files']) == 17
patch = ['*** Begin Patch\n']
for name, row in owned['files'].items():
    rel = Path(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    assert name.startswith(('src/main/java/io/github/sunthemoon/advancedrocketrycommunity/',
                            'src/test/java/io/github/sunthemoon/advancedrocketrycommunity/',
                            'docs/work/v1.8.0-c18a-atmosphere-analyzer/'))
    data = (AUTHOR / rel).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert not (ROOT / rel).exists(), name
    text = data.decode('utf-8')
    assert '\r' not in text and text.endswith('\n'), name
    patch.append('*** Add File: ' + (ROOT / rel).as_posix() + '\n')
    patch.extend('+' + line + '\n' for line in text.splitlines())
patch.append('*** End Patch\n')
value = ''.join(patch)
(OUT / 'AUTHORED-APPLY-01.patch').write_bytes(value.encode('utf-8'))
print(json.dumps({'patch': value, 'paths': 17,
                  'sha256': hashlib.sha256(value.encode('utf-8')).hexdigest()}))
