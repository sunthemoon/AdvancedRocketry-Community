"""Repeat actual DataGen, preserving the first round and every observed result."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
TEMP = OUT / 'process-temp'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()

def pin(file):
    data = file.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    path = OUT / name
    assert not path.exists()
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode('utf-8'))

generated = json.loads((OUT / 'GENERATED-POSTIMAGES-01.json').read_bytes())
assert len(generated) == 781
assert all(pin(ROOT / path) == row for path, row in generated.items())
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
command = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
           '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix(), 'runData']
write('repeat-data-01.command.json', {'command': command, 'cwd': str(ROOT), 'free_bytes': free,
      'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'state': 'uncommitted intermediate, not delivery', 'TEMP_TMP_TMPDIR': str(TEMP),
      'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
start = time.monotonic()
with (OUT / 'repeat-data-01.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
changed = [path for path, row in generated.items() if pin(ROOT / path) != row]
write('REPEAT-DATAGEN-01.json', {'exit': result.returncode, 'seconds': time.monotonic() - start,
      'generated': len(generated), 'changed': changed, 'log': pin(OUT / 'repeat-data-01.log'),
      'post_free_bytes': {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')},
      'gates_passed': False})
assert result.returncode == 0 and not changed, (result.returncode, changed)
print(json.dumps({'exit': result.returncode, 'generated': len(generated), 'changed': len(changed)}), flush=True)
