"""Pin the provisional Root-owned central delta; no source delivery assertion."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
PACKAGE = 'io/github/sunthemoon/advancedrocketrycommunity/'
BASE = '9135c20c34a402b7cf0715148aeb6683a35c1f50'
FILES = ['src/main/java/' + PACKAGE + suffix for suffix in (
    'AdvancedRocketryCommunity.java', 'config/CommonConfig.java',
    'registry/ModItems.java', 'registry/ModCreativeTabs.java',
    'datagen/BootstrapDataGenerators.java', 'datagen/V180LanguageProvider.java')]
FILES += ['src/test/java/' + PACKAGE + 'config/CommonConfigTest.java',
          'src/test/java/' + PACKAGE + 'config/ClassicDevicesConfigTest.java']

def sha(data):
    return hashlib.sha256(data).hexdigest()

entries = []
patch = []
for path in FILES:
    new = (ROOT / path).read_bytes()
    p = subprocess.run(['git', 'show', BASE + ':' + path], cwd=ROOT, capture_output=True)
    absent = path.endswith('/ClassicDevicesConfigTest.java')
    assert (p.returncode != 0) == absent
    old = b'' if absent else p.stdout
    before = '/dev/null' if absent else 'a/' + path
    patch.append('diff --git a/' + path + ' b/' + path + '\n')
    if absent:
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.decode('utf-8').splitlines(True),
                 new.decode('utf-8').splitlines(True), fromfile=before, tofile='b/' + path))
    entries.append({'path': path, 'base_exists': not absent,
                    'base_sha256': None if absent else sha(old),
                    'post_bytes': len(new), 'post_sha256': sha(new)})
data = ''.join(patch).encode('utf-8')
(OUT / 'ROOT-CENTRAL-01.patch').write_bytes(data)
result = {'schema': 1, 'status': 'INTERMEDIATE_UNCOMMITTED', 'base_commit': BASE,
          'scope': 'eight Root-owned central source/test paths',
          'java_ran': False, 'integration_admitted': False, 'files': entries,
          'patch_bytes': len(data), 'patch_sha256': sha(data)}
(OUT / 'ROOT-CENTRAL-01.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'paths': len(entries), 'patch_bytes': len(data), 'patch_sha256': sha(data)}))
