"""Actual scoped Root checks/DataGen; this uncommitted round is not delivery."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
AUTHOR = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-author-4a2d730bc8')
BASE = '16e555111ad957e80570317cb103fb9dadc9895a'
TEMP = OUT / 'process-temp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(file):
    data = file.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

def write(name, value):
    path = OUT / name
    assert not path.exists(), name
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode('utf-8'))

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == BASE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT)
owned = json.loads((AUTHOR / 'OWNED-FILES-01.json').read_bytes())['files']
central = json.loads((OUT / 'ROOT-CENTRAL-01.json').read_bytes())['files']
source = {path: {'bytes': row['bytes'], 'sha256': row['sha256']} for path, row in owned.items()}
source.update({row['path']: {'bytes': row['post_bytes'], 'sha256': row['post_sha256']} for row in central})
assert len(source) == 25
for path, row in source.items():
    assert pin(ROOT / path) == row, path
tracked = subprocess.check_output(['git', 'ls-files', '--', 'src/generated/v1.8/resources'], cwd=ROOT).decode().splitlines()
assert len(tracked) == 777
old_generated = {path: pin(ROOT / path) for path in tracked}
old_languages = {path: json.loads((ROOT / path).read_bytes()) for path in tracked if '/lang/' in path}
assert len(old_languages) == 2
classes = [path[len('src/test/java/'): -len('.java')].replace('/', '.')
           for path in owned if path.startswith('src/test/java/')]
assert len(classes) == 5
classes += ['io.github.sunthemoon.advancedrocketrycommunity.config.ClassicDevicesConfigTest',
            'io.github.sunthemoon.advancedrocketrycommunity.config.CommonConfigTest']
command = [str(ROOT / 'gradlew.bat'), '--offline', '--no-daemon', '--max-workers=2',
           '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir=' + TEMP.as_posix(), 'test']
for name in classes:
    command += ['--tests', name]
command += ['runData']
free = {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')}
assert all(value >= 10_000_000_000 for value in free.values()), free
write('intermediate-01.command.json', {'command': command, 'cwd': str(ROOT),
      'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'free_bytes': free,
      'base_commit': BASE, 'source_state': 'Reviewed uncommitted intermediate, not delivery',
      'selected_test_classes': classes, 'TEMP_TMP_TMPDIR': str(TEMP),
      'JAVA_TOOL_OPTIONS': os.environ['JAVA_TOOL_OPTIONS']})
start = time.monotonic()
with (OUT / 'intermediate-01.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
write('intermediate-01.result.json', {'exit': result.returncode, 'seconds': time.monotonic() - start,
      'log': pin(OUT / 'intermediate-01.log')})
summary = {'suites': 0, 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
xml_dir = OUT / 'intermediate-01-xml'
xml_dir.mkdir()
observed = []
for name in classes:
    file = ROOT / 'build/test-results/test' / ('TEST-' + name + '.xml')
    if file.is_file():
        shutil.copyfile(file, xml_dir / file.name)
        suite = ET.parse(file).getroot()
        observed.append(name)
        summary['suites'] += 1
        for key in ('tests', 'failures', 'errors', 'skipped'):
            summary[key] += int(suite.attrib[key])
write('INTERMEDIATE-JUNIT-01.json', {'totals': summary, 'observed_classes': observed,
      'qualified_only_after_successful_command': result.returncode == 0})
mismatches = [path for path, row in source.items() if pin(ROOT / path) != row]
write('INTERMEDIATE-SOURCE-POSTCHECK-01.json', {'paths': len(source),
      'mismatches': mismatches,
      'post_free_bytes': {drive: shutil.disk_usage(drive + ':/').free for drive in ('C', 'D')},
      'gates_passed': False})
assert result.returncode == 0, result.returncode
assert not mismatches, mismatches
assert len(observed) == 7 and not any(summary[key] for key in ('failures', 'errors', 'skipped')), summary
generated_dir = ROOT / 'src/generated/v1.8/resources'
actual = {path.relative_to(ROOT).as_posix(): pin(path)
          for path in generated_dir.rglob('*') if path.is_file() and '.cache' not in path.parts}
new_paths = sorted(set(actual) - set(old_generated))
expected = sorted('src/generated/v1.8/resources/' + suffix for suffix in (
    'assets/advancedrocketrycommunity/models/item/atmosphere_analyzer.json',
    'assets/advancedrocketrycommunity/textures/item/atmosphere_analyzer.png',
    'data/advancedrocketrycommunity/recipes/atmosphere_analyzer.json',
    'data/advancedrocketrycommunity/advancements/recipes/misc/atmosphere_analyzer.json'))
assert new_paths == expected, new_paths
assert set(old_generated) <= set(actual)
changed = [path for path, row in old_generated.items() if actual[path] != row]
assert set(changed) == set(old_languages), changed
for path, old in old_languages.items():
    new = json.loads((ROOT / path).read_bytes())
    assert all(new[key] == value for key, value in old.items()), path
    assert len(set(new) - set(old)) == 15, path
write('INTERMEDIATE-DATAGEN-01.json', {'generated_files': len(actual), 'added': expected,
      'changed': changed, 'old_language_keys_unchanged': True, 'added_keys_per_locale': 15,
      'source_paths_unchanged': all(pin(ROOT / path) == row for path, row in source.items()),
      'gates_passed': False})
write('GENERATED-POSTIMAGES-01.json', actual)
print(json.dumps({'exit': result.returncode, 'junit': summary, 'generated': len(actual),
                  'added': len(new_paths), 'changed': len(changed)}), flush=True)
