"""Verify named immutable predecessors without rewriting or reclassifying them."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
from audit_primitives import junit_document, terminal_gt, task_observations

B = Path(__file__).resolve().parent
E = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def write(name, value):
    (B / name).write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8'))
def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '\\' not in name and ':' not in name and '..' not in p.parts
def verify(directory, manifest_name, expected_sha=None):
    raw = (directory / manifest_name).read_bytes()
    if expected_sha:
        assert pin(raw)['sha256'] == expected_sha
    manifest = json.loads(raw)
    records = manifest['files']
    if isinstance(records, dict):
        records = [{'path': name, **value} for name, value in records.items()]
    assert len(records) == len({r['path'] for r in records})
    for r in records:
        assert safe(r['path'])
        assert pin((directory / r['path']).read_bytes()) == {'bytes': r['bytes'], 'sha256': r['sha256']}
    return {'directory': str(directory), 'manifest': manifest_name, 'manifest_pin': pin(raw), 'payloads': len(records),
            'payload_bytes': sum(r['bytes'] for r in records), 'postcheck': 'all unchanged', 'records': records}

author = E / 'c18-analyzer-fix-author-ea8349712b'
review = E / 'c18-analyzer-corrected-review-0da9d89cec'
old = E / 'c18-analyzer-full-20261005-01'
old_own = E / 'c18-analyzer-result-audit-b8154b0a71'
manifests = [verify(author, 'INTERNAL-MANIFEST-01.json'),
             verify(review, 'INTERNAL-MANIFEST-01.json', '01d920335adeb8d34e75ccd0ea5df4862c13181962c2631738066d7d5afd582a'),
             verify(old_own, 'INTERNAL-MANIFEST.json', 'e075c9c57ed8fff56f41bdc34840273ed4c1c8b8ade46b82f73959477d63533c')]
assert pin((review / 'REVIEW-01.md').read_bytes())['sha256'] == '7b81c11ac68aee4cfe8d12ae8ceb1e25eb24474b6c31eba6636d96b90cc9e187'
historical = []
for directory, name in ((old, 'gametest-01.log'), (author, 'diagnostic-01.log'), (author, 'diagnostic-02.log'), (author, 'diagnostic-03.log')):
    raw = (directory / name).read_bytes()
    observed = terminal_gt(raw.decode('utf-8'))
    historical.append({'path': str(directory / name), 'pin': pin(raw), 'completion': observed['completion'],
                       'outcome': observed['outcome'], 'failure_names': observed['failure_names'],
                       'error_headers': len(observed['error_fatal_headers'])})
assert all(row['outcome']['status'] == 'failed' for row in historical)
assert all(set(row['failure_names']) == set(historical[0]['failure_names']) for row in historical)
cache = []
case_sets = []
for name, xml_dir in (('INDEPENDENT-04.log', 'independent04-xml'), ('INDEPENDENT-10.log', 'independent10-xml')):
    raw = (review / name).read_bytes()
    rows = [r for r in task_observations(raw.decode('utf-8')) if r['task'] in {':cleanTest', ':compileJava', ':compileTestJava', ':test'}]
    status = [r['status'] for r in rows if r['task'] == ':test']
    totals, cases = Counter(tests=0, failures=0, errors=0, skipped=0), Counter()
    xml = []
    for path in sorted((review / xml_dir).glob('TEST-*.xml')):
        doc = junit_document(path.read_bytes())
        totals.update(doc['totals']); cases.update(doc['cases'])
        xml.append({'file': path.name, 'timestamp': doc['timestamp'], 'pin': pin(path.read_bytes())})
    case_sets.append(cases)
    cache.append({'path': str(review / name), 'pin': pin(raw), 'task_rows': rows, 'test_status': status,
                  'xml': xml, 'totals': dict(totals), 'suites': len(xml)})
assert cache[0]['test_status'] == ['FROM-CACHE'] and cache[1]['test_status'] == ['EXECUTED']
assert case_sets[0] == case_sets[1]
for row in manifests:
    verify(Path(row['directory']), row['manifest'], row['manifest_pin']['sha256'])
write('LINEAGE-AUDIT-01.json', {'manifests': manifests, 'historical_failed_GameTests': historical,
       'reviewer_cached_and_uncached_jobs': cache,
       'limits': 'Verifies immutable record identities and actual recorded task statuses; this auditor did not run their Java jobs or accept their source.'})
print(json.dumps({'predecessor_manifests': [{k:r[k] for k in ('directory','manifest_pin','payloads','payload_bytes')} for r in manifests],
                  'historical_failures': [(r['completion']['total'],r['outcome']['count']) for r in historical],
                  'reviewer_test_statuses': [r['test_status'] for r in cache], 'reviewer_case_counts': [r['totals'] for r in cache]}))
