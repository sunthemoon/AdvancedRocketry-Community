# Corrected analyzer committed-result audit preparation

Date: 2026-10-05. Role: independent delegated result auditor.
Write scope: this small external D directory only. Root/worktrees/old bundles
remain read-only. No Java/Gradle/GameTest/native/client/network/deletion or
Git mutation is permitted. Python uses `-B` and process-only D temp.

The named Root result directory currently contains only three prepared files:
PREPARATION-01.md, run_full01.py and run_post01.py. No fixed corrected code
commit, COHORT input, Source27 manifest, result, XML or artifact has been
provided as terminal evidence. Their future names are not read or invented.
Preparation is not a result disposition, expected test count or source review.

## Independent bounded method

1. Pin the eventual exact committed cohort configuration, drivers, source
   manifest/boundary, command/result/raw logs and captured artifact/XML files
   before any analysis. Recheck the same named bytes afterward. Preserve all
   helper/intake failures as independent attempts rather than overwrite them.
2. Derive source additions/removals/changes against exact Source26 manifest.
   Compare each named new input to the fixed Git object, not moving HEAD;
   identify raw LF/CRLF-only wrapper qualifications and separately pinned
   owner-maintained AGENTS. Record actual exceptions, not whole-repository
   identity. The proposed one-GT-compilation-unit scope is a check to compare,
   not an allowlist that hides unrelated artifact deltas.
3. Independently read every new captured JUnit XML and count actual testcase
   elements, failure/error/skipped children, duplicate names and per-suite
   attribute agreement. Compare old/new testcase multisets without deleting
   failures. Inspect clean/task/log order, `--no-build-cache` arguments and
   exact task statuses; cached/UP-TO-DATE/no-source tasks are not new executions.
   A receipt's existence or XML count does not establish freshness alone.
4. Parse anchored Server-thread/GameTestServer completion and pass/fail lines
   in raw Gradle, latest and debug logs. Reconcile boards, required summaries,
   failed names and native reporter lines with command/child exits. Preserve
   every ERROR/FATAL group separately, including expected-fixture errors;
   unfiltered GT success never means a globally clean log or client/native Gate.
5. Inspect both old/new named JARs in memory: exact whole pins, ZIP CRC/unique
   regular member inventory and every added/removed/changed payload. Parse
   SourceFile/internal class identity for each changed/added class, including
   compiler-generated classes. Compare its actual fixed committed owner source
   and sources-JAR bytes; never require reobfuscated bytes to equal pre-reobf
   build/classes. Compare all named generated resources in both artifacts and
   the fixed source manifest/Git, and actual API whole bytes separately.
6. Audit repeat DataGen pre/post identity and exact raw written/total counters.
   Bind all ten actual static command exits/log hashes, including any closure/
   dirty diff failures as failures, not expected-exit passes. Follow postcheck
   scope without letting later static/repeat output reclassify GT or build.
7. Keep Source26 four required GT failures, the three author diagnostic
   failures, and corrected-reviewer's cached-JUnit observation separate from
   new Root no-cache execution. Read source-review records only as dependency
   evidence; do not inherit reviewer verdicts as runtime results.

If disk/authority checks prevent a new command from executing, record actual
missing execution rather than assume intended flags make a run occur. A new
read-only audit is not independent native/Java replay, source acceptance,
runtime/client crash proof or completion of v1.8 Required Gates.

Only small helpers, controls, logs/results, input pins and report/manifest will
be retained here. No source tree/JAR/world export or old archive duplication.
Final findings wait for Root's fixed code SHA and terminal full/post notification.
