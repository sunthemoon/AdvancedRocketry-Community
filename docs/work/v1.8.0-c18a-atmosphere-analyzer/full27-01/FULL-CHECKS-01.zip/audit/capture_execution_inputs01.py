"""Bind now-created fixed cohort configuration; do not read running results."""
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).parent
ROOT = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
F = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01")
HEAD = "a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c"


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


inputs = {}
for name in ("COHORT-INPUT-01.json", "run_full01.py", "run_post01.py"):
    inputs[name] = pin((F / name).read_bytes())
cohort = json.loads((F / "COHORT-INPUT-01.json").read_text(encoding="utf-8"))
assert cohort["code_commit"] == HEAD
relative = "src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java"
command = ["git", "show", HEAD + ":" + relative]
read = subprocess.run(command, cwd=ROOT, capture_output=True, check=True)
assert pin(read.stdout)["sha256"] == cohort["reviewed_gt_sha256"]
old = json.loads((OUT / "PREPARATION-INPUTS-01.json").read_text(encoding="utf-8"))["input_pins"]
driver_drift = {name: {"prepared": old[str(F / name)], "execution": inputs[name]}
                for name in ("run_full01.py", "run_post01.py") if old[str(F / name)] != inputs[name]}
result = {
    "schema": 1, "fixed_code_commit": HEAD, "available_execution_input_pins": inputs,
    "cohort": cohort, "driver_delta_since_preparation": driver_drift,
    "fixed_gt_git_blob": {"relative": relative, **pin(read.stdout)},
    "git_read": {"args": command, "exit": read.returncode, "stdout": pin(read.stdout), "stderr": pin(read.stderr)},
    "terminal_results_audited": False, "result_paths_read": [],
    "limits": "Root running cohort notification only; no command completion, artifact, XML or Gate inferred",
}
for name, expected in inputs.items():
    assert pin((F / name).read_bytes()) == expected
target = OUT / "EXECUTION-INPUTS-01.json"
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
