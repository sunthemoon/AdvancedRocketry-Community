"""Bounded fixed-Git and archive-member audit; no javac/reobf byte assumption."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

B = Path(__file__).resolve().parent
R = Path('D:/GitHub/AdvancedRocketry-Community')
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01')
O = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
H = 'a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def write(name, value):
    (B / name).write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8'))

def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '\\' not in name and ':' not in name and '..' not in p.parts and '\x00' not in name

old = json.loads((O / 'SOURCE26-MANIFEST-01.json').read_bytes())
new = json.loads((F / 'SOURCE27-MANIFEST-01.json').read_bytes())
boundary = json.loads((F / 'SOURCE27-BOUNDARY-01.json').read_bytes())
assert all(safe(name) and 'AdvancedRocketry-Community-v1plus-Development-Docs' not in name for name in new)
added = sorted(set(new) - set(old))
removed = sorted(set(old) - set(new))
changed = {name: {'previous': old[name], 'current': new[name]} for name in sorted(set(new) & set(old)) if new[name] != old[name]}
assert removed == [] and set(added) == set(boundary['added_named_inputs'])
assert changed == boundary['changed_from_prior_cohort'] and boundary['tested_commit'] == H
batch = ''.join(H + ':' + name + '\n' for name in sorted(new)).encode('utf-8')
argv = ['git', 'cat-file', '--batch']
proc = subprocess.run(argv, input=batch, cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
data, offset, git = proc.stdout, 0, {}
for name in sorted(new):
    end = data.index(b'\n', offset)
    object_id, kind, size = data[offset:end].split()
    assert kind == b'blob'
    size = int(size)
    raw = data[end + 1:end + 1 + size]
    assert len(raw) == size and data[end + 1 + size:end + 2 + size] == b'\n'
    git[name] = raw
    offset = end + 2 + size
assert offset == len(data)
qualifications = {}
exact = 0
for name, raw in git.items():
    current = (R / name).read_bytes()
    assert pin(current) == new[name], name
    if pin(raw) == new[name]:
        exact += 1
    else:
        q = boundary['git_qualifications'][name]
        assert pin(raw) == {'bytes': q['git_bytes'], 'sha256': q['git_sha256']} and new[name] == q['live']
        if name == 'gradlew.bat':
            assert b'\r' not in raw and raw.replace(b'\n', b'\r\n') == current
        else:
            assert name == 'AGENTS.md'
        qualifications[name] = q
assert set(qualifications) == set(boundary['git_qualifications'])

def class_source(raw):
    """Read only the class-file identity/version/SourceFile attributes."""
    pos = 0
    def take(n):
        nonlocal pos
        assert n >= 0 and pos + n <= len(raw)
        part = raw[pos:pos + n]
        pos += n
        return part
    def u(n):
        return int.from_bytes(take(n), 'big')
    assert u(4) == 0xCAFEBABE
    minor, major, count = u(2), u(2), u(2)
    cp, i = {}, 1
    while i < count:
        tag = u(1)
        if tag == 1:
            cp[i] = take(u(2))
        elif tag in (3, 4):
            take(4)
        elif tag in (5, 6):
            take(8)
            i += 1
        elif tag in (7, 8, 16, 19, 20):
            cp[i] = u(2)
        elif tag in (9, 10, 11, 12, 17, 18):
            take(4)
        elif tag == 15:
            take(3)
        else:
            raise AssertionError(('constant-pool tag', tag))
        i += 1
    access, self_index, parent = u(2), u(2), u(2)
    take(u(2) * 2)
    for _group in range(2):
        for _ in range(u(2)):
            take(6)
            for _attribute in range(u(2)):
                take(2)
                take(u(4))
    source_file, attrs = None, []
    for _ in range(u(2)):
        label = cp[u(2)].decode('ascii')
        content = take(u(4))
        attrs.append(label)
        if label == 'SourceFile':
            assert len(content) == 2 and source_file is None
            source_file = cp[int.from_bytes(content, 'big')].decode('ascii')
    assert pos == len(raw) and source_file is not None
    return {'class_name': cp[cp[self_index]].decode('ascii'), 'source_file': source_file,
            'major': major, 'minor': minor, 'class_attributes': attrs}

artifacts = json.loads((F / 'ARTIFACTS-01.json').read_bytes())
old_artifacts = json.loads((O / 'ARTIFACTS-01.json').read_bytes())
rows, classes = [], []
for name, expected in sorted(artifacts.items()):
    current_file, old_file = F / 'artifacts-01' / name, O / 'artifacts-01' / name
    assert pin(current_file.read_bytes()) == expected and pin(old_file.read_bytes()) == old_artifacts[name]
    with zipfile.ZipFile(old_file) as zold, zipfile.ZipFile(current_file) as znew:
        maps = []
        for archive in (zold, znew):
            infos = archive.infolist()
            assert len(infos) == len({i.filename for i in infos})
            assert all(safe(i.filename.rstrip('/')) for i in infos)
            assert archive.testzip() is None
            maps.append({i.filename: archive.read(i) for i in infos if not i.is_dir()})
        a, b = maps
        plus, minus = sorted(set(b) - set(a)), sorted(set(a) - set(b))
        delta = sorted(member for member in set(a) & set(b) if a[member] != b[member])
        row = {'artifact': name, 'old_pin': old_artifacts[name], 'new_pin': expected,
               'old_raw_entries': len(zold.infolist()), 'new_raw_entries': len(znew.infolist()),
               'old_members': len(a), 'new_members': len(b), 'added': plus, 'removed': minus, 'changed': delta,
               'unchanged_regular_members': len(set(a) & set(b)) - len(delta),
               'crc_ok_both': True, 'duplicate_names_both': 0,
               'delta_payload_pins': {member: {'old': pin(a[member]) if member in a else None,
                                             'new': pin(b[member]) if member in b else None} for member in sorted(set(plus + minus + delta))}}
        if '-api.' in name:
            row['entire_raw_equal'] = current_file.read_bytes() == old_file.read_bytes()
            assert row['entire_raw_equal'] and not plus and not minus and not delta
        else:
            generated_matches = 0
            for path in sorted(new):
                if path.startswith('src/generated/v1.8/resources/'):
                    member = path[len('src/generated/v1.8/resources/'):]
                    assert member in b and pin(b[member]) == new[path] and b[member] == git[path]
                    generated_matches += 1
            row['generated_v18_matched'] = generated_matches
            if '-sources.' in name:
                matches = 0
                for path in sorted(new):
                    if path.startswith('src/main/java/'):
                        member = path[len('src/main/java/'):]
                        assert member in b and b[member] == git[path] and pin(b[member]) == new[path]
                        matches += 1
                row['all_named_main_java_matched'] = matches
                assert set('src/main/java/' + member for member in delta) == set(changed)
                assert not plus and not minus
            else:
                for member in plus + delta + minus:
                    assert member.endswith('.class')
                    fact = {'member': member}
                    for label, raw in (('old', a.get(member)), ('new', b.get(member))):
                        if raw is not None:
                            record = class_source(raw)
                            assert record['class_name'] + '.class' == member
                            source = 'src/main/java/' + str(PurePosixPath(member).parent / record['source_file'])
                            assert source in changed
                            fact[label] = {'derived_source': source, **record}
                    classes.append(fact)
                assert not minus
        rows.append(row)

root_member = json.loads((F / 'ARTIFACT-MEMBER-AUDIT-01.json').read_bytes())
for row in root_member['artifacts']:
    observed = next(v for v in rows if v['artifact'] == row['artifact'])
    assert all(row[key] == observed[key] for key in row)
assert all(pin((R / name).read_bytes()) == expected for name, expected in new.items())
write('SOURCE-ARTIFACT-AUDIT-01.json', {'fixed_commit': H, 'old_named_inputs': len(old), 'new_named_inputs': len(new),
      'old_named_removed': removed, 'new_named_added': added, 'old_named_changed': changed,
      'fixed_git_exact_inputs': exact, 'git_raw_qualifications': qualifications, 'live_named_postcheck_mismatches': [],
      'git_read': {'argv': argv, 'stdin': pin(batch), 'stdout': pin(proc.stdout), 'stderr': pin(proc.stderr), 'exit': proc.returncode},
      'artifacts': rows, 'delta_classes_sourcefile_metadata': classes,
      'limits': 'Named inputs, not whole Git snapshot. Class SourceFile ownership, not reobf/javac equality, packaged normal-profile exclusion, native/client or Gate proof.'})
print(json.dumps({'named': len(new), 'raw_git_equal': exact, 'qualifications': sorted(qualifications), 'old_changed': list(changed), 'added': added,
                  'artifacts': [{k:r[k] for k in ('artifact','old_raw_entries','new_raw_entries','old_members','new_members','added','removed','changed')} for r in rows],
                  'delta_class_source_mappings': len(classes)}))
