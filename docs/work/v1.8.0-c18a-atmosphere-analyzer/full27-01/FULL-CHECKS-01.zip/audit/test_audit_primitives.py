"""Independent fake-input controls only; no observed cohort outcomes are encoded."""
import unittest
from audit_primitives import junit_document, task_observations, terminal_gt

PREFIX = "[00:00:00] [Server thread/INFO] [minecraft/GameTestServer]: "


def passing():
    return "\n".join(PREFIX + value for value in (
        "[++]", "========= 2 GAME TESTS COMPLETE =========", "All 2 required tests passed :)"))


def failing():
    return "[00:00:00] [Server thread/ERROR] [minecraft/LogTestReporter]: alpha failed! reason\n" + "\n".join(
        PREFIX + value for value in ("[+X]", "========= 2 GAME TESTS COMPLETE =========", "1 required tests failed :(", "   - alpha"))


def xml(case="<testcase classname='A' name='one'/>", tests=1, failures=0, errors=0, skipped=0):
    return (f"<testsuite name='A' tests='{tests}' failures='{failures}' errors='{errors}' skipped='{skipped}'>"
            + case + "</testsuite>").encode()


class AuditControls(unittest.TestCase):
    def test_executed_task_is_distinct_from_cache(self):
        rows = task_observations("> Task :test\n> Task :other FROM-CACHE\n> Task :third UP-TO-DATE\n")
        self.assertEqual(["EXECUTED", "FROM-CACHE", "UP-TO-DATE"], [row["status"] for row in rows])

    def test_embedded_task_text_is_not_execution(self):
        self.assertEqual([], task_observations("fake > Task :test\nassertion: test FROM-CACHE\n"))

    def test_failed_and_no_source_task_keep_status(self):
        self.assertEqual(["FAILED", "NO-SOURCE", "SKIPPED"], [row["status"] for row in task_observations(
            "> Task :test FAILED\n> Task :x NO-SOURCE\n> Task :y SKIPPED")])

    def test_junit_counts_actual_case_and_duplicate_multiplicity(self):
        row = junit_document(xml("<testcase classname='A' name='one'/><testcase classname='A' name='one'/>", tests=2))
        self.assertEqual(2, row["totals"]["tests"])
        self.assertEqual(2, row["cases"][("A", "one")])

    def test_junit_failure_error_skip_children_are_not_a_pass(self):
        for kind, field in (("failure", "failures"), ("error", "errors"), ("skipped", "skipped")):
            kwargs = {field: 1}
            with self.subTest(kind=kind):
                row = junit_document(xml(f"<testcase classname='A' name='one'><{kind}/></testcase>", **kwargs))
                self.assertEqual(1, row["totals"][field])

    def test_junit_false_attribute_count_refuses(self):
        with self.assertRaises(AssertionError):
            junit_document(xml(tests=2))

    def test_junit_entity_declaration_refuses(self):
        with self.assertRaises(AssertionError):
            junit_document(b"<!DOCTYPE x [<!ENTITY z 'value'>]>" + xml())

    def test_gt_pass_is_measured_without_count_defaults(self):
        row = terminal_gt(passing())
        self.assertEqual({"status": "passed", "count": 2, "line": 3}, row["outcome"])

    def test_gt_failure_stays_failure(self):
        row = terminal_gt(failing())
        self.assertEqual("failed", row["outcome"]["status"])
        self.assertEqual(["alpha"], row["failure_names"])

    def test_empty_is_not_terminal(self):
        with self.assertRaises(AssertionError):
            terminal_gt("")

    def test_nested_logger_is_not_authoritative(self):
        with self.assertRaises(AssertionError):
            terminal_gt(passing().replace("[minecraft/GameTestServer]:", "[other]: [minecraft/GameTestServer]:"))

    def test_other_thread_and_level_do_not_count(self):
        for source in (passing().replace("Server thread", "Client thread"), passing().replace("/INFO]", "/WARN]")):
            with self.subTest(source=source), self.assertRaises(AssertionError):
                terminal_gt(source)

    def test_duplicate_completion_is_not_terminal_success(self):
        with self.assertRaises(AssertionError):
            terminal_gt(passing() + "\n" + PREFIX + "========= 2 GAME TESTS COMPLETE =========")

    def test_board_and_summary_contradiction_refuses(self):
        with self.assertRaises(AssertionError):
            terminal_gt(passing().replace("[++]", "[+X]"))

    def test_failed_name_must_match_native_reporter(self):
        with self.assertRaises(AssertionError):
            terminal_gt(failing().replace("alpha failed!", "beta failed!"))

    def test_expected_error_text_is_preserved_not_waived(self):
        text = "[00:00:00] [Server thread/ERROR] [custom/Fixture]: expected refusal\n" + passing()
        self.assertEqual("expected refusal", terminal_gt(text)["error_fatal_headers"][0]["message"])


if __name__ == "__main__":
    unittest.main()
