"""Pin only actually available preparation and fixed previous audit inputs."""
import hashlib
import json
import pathlib

OUT = pathlib.Path(__file__).parent
ROOT = pathlib.Path("D:/GitHub/AdvancedRocketry-Community")
OLD = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-result-audit-b8154b0a71")
FUTURE = pathlib.Path("D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01")


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


manifest = OLD / "INTERNAL-MANIFEST.json"
assert pin(manifest)["sha256"] == "e075c9c57ed8fff56f41bdc34840273ed4c1c8b8ade46b82f73959477d63533c"
prior = json.loads(manifest.read_text(encoding="utf-8"))
for name, expected in prior["files"].items():
    assert pathlib.PurePosixPath(name).as_posix() == name and ".." not in pathlib.PurePosixPath(name).parts
    assert pin(OLD / name) == expected
mandatory = (
    "AGENTS.md", "PROJECT-CONFIG.md", "PRODUCT.md", "docs/01-PORTING-PRINCIPLES.md",
    "docs/04-VERSION-ROADMAP.md", "docs/versions/V1.8.0-CLASSIC-CONTENT-COMPLETION.md",
    "docs/05-MASTER-TEST-PLAN.md", "docs/06-RELEASE-AND-ACCEPTANCE-GATES.md",
    "docs/16-POST-1.0-VERSION-ROADMAP.md", "docs/17-V1PLUS-QUALITY-BUDGETS.md",
    "docs/14-PARALLEL-DEVELOPMENT-AND-WORKTREE-COORDINATION.md",
)
paths = [ROOT / name for name in mandatory]
paths += [FUTURE / name for name in ("PREPARATION-01.md", "run_full01.py", "run_post01.py")]
paths += [OLD / name for name in ("INTERNAL-MANIFEST.json", "REPORT-01.md", "results01.py", "source_artifacts01.py")]
pins = {str(path): pin(path) for path in paths}
for path, expected in pins.items():
    assert pin(pathlib.Path(path)) == expected
result = {
    "schema": 1, "phase": "preparation_only_not_result_audit",
    "input_pins": pins, "prior_audit_payloads_verified": len(prior["files"]),
    "fixed_corrected_code_commit": None, "terminal_results_provided": False,
    "future_result_paths_read": [], "Java_Gradle_native_launched": False,
    "current_governance_qualification": "Live mandatory docs are separate preparation pins; no whole-Git/source/runtime identity claimed",
    "method_controls": {"tests": 16, "failures": 0, "errors": 0, "skips": 0},
}
target = OUT / "PREPARATION-INPUTS-01.json"
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({key: value for key, value in result.items() if key != "input_pins"}, indent=2))
