"""Read-only audit of the terminal named Source27 result cohort."""
from collections import Counter
from datetime import datetime, timedelta
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
from audit_primitives import junit_document, terminal_gt, task_observations

B = Path(__file__).resolve().parent
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01')
O = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
H = 'a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c'
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
pin = lambda data: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    (B / name).write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8'))

files = {p.relative_to(F).as_posix(): pin(p.read_bytes()) for p in sorted(F.iterdir()) if p.is_file()}
for p in sorted((F / 'junit-01').glob('TEST-*.xml')):
    assert p.is_file()
    files[p.relative_to(F).as_posix()] = pin(p.read_bytes())
artifacts = json.loads((F / 'ARTIFACTS-01.json').read_bytes())
for name, expected in artifacts.items():
    path = F / 'artifacts-01' / name
    assert path.is_file() and pin(path.read_bytes()) == expected
    files[path.relative_to(F).as_posix()] = expected
write('ROOT-INPUT-PINS-01.json', {'scope': 'terminal top-level regular files, TEST XML and explicitly named artifacts; no runtime/source export', 'base': str(F), 'files': files})

def j(name):
    return json.loads((F / name).read_bytes())

cohort = j('COHORT-INPUT-01.json')
assert cohort['code_commit'] == H
checks = j('FULL-CHECKS-01.json')
assert checks['tested_commit'] == H and checks['required_gates_passed'] is False
commands = []
full_start = full_end = None
for name, result_name, task in (('full-build-01', 'full-build-01.result.json', ':test'),
                                ('gametest-01', 'gametest-01.result.json', ':runGameTestServer'),
                                ('repeat-data-01', 'REPEAT-DATAGEN-01.json', ':runData')):
    command, result = j(name + '.command.json'), j(result_name)
    raw = (F / (name + '.log')).read_bytes()
    assert pin(raw) == result['log']
    assert command['tested_commit'] == H
    assert '--no-build-cache' in command['command'] and '--offline' in command['command'] and '--no-daemon' in command['command']
    assert '--max-workers=2' in command['command']
    assert all(amount >= 10_000_000_000 for amount in command['free_bytes'].values())
    rows = task_observations(raw.decode('utf-8'))
    observed = [r for r in rows if r['task'] == task]
    assert len(observed) == 1 and observed[0]['status'] == 'EXECUTED', (name, observed)
    assert result['exit'] == 0 and raw.count(b'BUILD SUCCESSFUL') == 1 and b'BUILD FAILED' not in raw
    start = datetime.fromisoformat(command['started_utc'])
    end = start + timedelta(seconds=result['seconds'])
    if name == 'full-build-01':
        full_start, full_end = start.replace(tzinfo=None), end.replace(tzinfo=None)
    commands.append({'name': name, 'argv': command['command'], 'exit': result['exit'], 'seconds': result['seconds'],
                     'started_utc': command['started_utc'], 'computed_end_utc': end.isoformat(),
                     'free_bytes': command['free_bytes'], 'log': pin(raw), 'tasks': rows})
assert datetime.fromisoformat(commands[1]['started_utc']) > datetime.fromisoformat(commands[0]['computed_end_utc'])
assert datetime.fromisoformat(commands[2]['started_utc']) > datetime.fromisoformat(commands[1]['computed_end_utc'])
assert checks['commands'] == [j('full-build-01.result.json'), j('gametest-01.result.json')]

def xml_group(directory):
    totals = Counter(tests=0, failures=0, errors=0, skipped=0)
    cases, rows = Counter(), []
    for p in sorted(directory.glob('TEST-*.xml')):
        doc = junit_document(p.read_bytes())
        totals.update(doc['totals'])
        cases.update(doc['cases'])
        rows.append({'file': p.name, 'suite': doc['suite'], 'timestamp': doc['timestamp'], 'totals': doc['totals'], 'pin': pin(p.read_bytes())})
    assert len(rows) == len({r['suite'] for r in rows})
    return totals, cases, rows

totals, cases, xml = xml_group(F / 'junit-01')
prior_totals, prior_cases, prior_xml = xml_group(O / 'junit-01')
assert cases == prior_cases
assert {**dict(totals), 'suites': len(xml)} == j('JUNIT-01.json')
assert all(full_start <= datetime.fromisoformat(r['timestamp']) <= full_end for r in xml)

gt = {}
for name in ('gametest-01.log', 'gametest-01-latest.log', 'gametest-01-debug.log'):
    gt[name] = terminal_gt((F / name).read_text(encoding='utf-8'))
outcomes = [(v['completion']['total'], v['outcome']['status'], v['outcome']['count'], v['failure_names']) for v in gt.values()]
assert all(value == outcomes[0] for value in outcomes)
root_gt = j('GAMETEST-01.json')
assert root_gt['completed_reports'] == [str(outcomes[0][0])] and root_gt['required_pass_reports'] == [str(outcomes[0][2])]
assert root_gt['required_failure_reports'] == [] and root_gt['command_exit'] == 0
assert root_gt['error_headers'] == len(gt['gametest-01-latest.log']['error_fatal_headers'])
groups = {}
for name, observation in gt.items():
    groups[name] = [{'logger': key[0], 'message': key[1], 'count': count} for key, count in sorted(Counter((row['logger'], row['message']) for row in observation['error_fatal_headers']).items())]

cache_lines = {}
pattern = re.compile(r'Caching: total files: (\d+), old count: (\d+), new count: (\d+), removed stale: (\d+), written: (\d+)')
for name in ('full-build-01.log', 'repeat-data-01.log'):
    rows = []
    for n, line in enumerate((F / name).read_text(encoding='utf-8').splitlines(), 1):
        if match := pattern.search(line):
            rows.append({'line': n, 'text': line, 'counts': list(map(int, match.groups()))})
    assert len(rows) == 1
    cache_lines[name] = rows
repeat = j('REPEAT-DATAGEN-01.json')
manifest = j('SOURCE27-MANIFEST-01.json')
generated = {key: value for key, value in manifest.items() if key.startswith('src/generated/v1.8/resources/')}
assert repeat['files'] == len(generated) == cache_lines['repeat-data-01.log'][0]['counts'][0]
assert repeat['changed'] == []
assert all(rows[0]['counts'][-1] == 0 for rows in cache_lines.values())

static = j('STATIC-RESULTS-01.json')
jobs = []
for row in static['jobs']:
    command = j(row['name'] + '-01.command.json')
    raw = (F / (row['name'] + '-01.log')).read_bytes()
    assert pin(raw) == row['log'] and command['command'] == row['command']
    jobs.append({'name': row['name'], 'exit': row['exit'], 'seconds': row['seconds'], 'log': row['log'], 'command': row['command']})
assert len(jobs) == len({r['name'] for r in jobs})
post = [j('SOURCE27-POSTCHECK-01.json'), j('POST-CHECKS-01.json')]
assert all(row['named_inputs'] == len(manifest) and row['mismatches'] == [] and row['tested_head_unchanged'] is True and row['required_gates_passed'] is False for row in post)
write('RESULT-AUDIT-01.json', {'fixed_commit': H, 'commands': commands, 'xml': {'totals': dict(totals), 'suites': len(xml), 'files': xml,
      'distinct_case_names': len(cases), 'same_case_multiset_as_source26': True, 'prior_totals': dict(prior_totals), 'timestamps_in_actual_build_interval': True},
      'gametest': gt, 'error_fatal_groups': groups, 'DataGen_raw_cache_lines': cache_lines, 'repeat_source_count': len(generated),
      'static_actual_jobs': jobs, 'static_exit_counts': dict(Counter(r['exit'] for r in jobs)), 'root_postcheck_receipts': post,
      'limits': 'Result evidence audit, not independent Java/native replay, clean-log waiver, repository-wide validation or Required Gates.'})
assert all(pin((F / path).read_bytes()) == expected for path, expected in files.items())
write('ROOT-INPUT-POSTCHECK-01.json', {'checked': len(files), 'mismatches': [], 'scope': 'same individually pinned terminal files, XML and artifacts'})
print(json.dumps({'tests': dict(totals), 'suites': len(xml), 'gt': outcomes, 'GT_error_headers': {name: len(v['error_fatal_headers']) for name,v in gt.items()},
                  'static_exits': dict(Counter(r['exit'] for r in jobs)), 'individual_inputs_unchanged': len(files)}))
