"""Finalize only this owned compact loose audit; never rewrite predecessors."""
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01')
R = Path('D:/GitHub/AdvancedRocketry-Community')
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def write(name, value):
    (B / name).write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8'))
assert not (B / 'INTERNAL-MANIFEST.json').exists() and not (B / 'SHA256SUMS.txt').exists()
inputs = json.loads((B / 'ROOT-INPUT-PINS-01.json').read_bytes())['files']
assert all(pin((F / name).read_bytes()) == expected for name, expected in inputs.items())
source = json.loads((F / 'SOURCE27-MANIFEST-01.json').read_bytes())
assert all(pin((R / name).read_bytes()) == expected for name, expected in source.items())
supplement = {}
for name in ('DOCS-PATCH-FAILURE-01.md', 'TEMP-CLEANUP-TOOL-FAILURE-01.md'):
    raw = (F / name).read_bytes()
    supplement[name] = pin(raw)
links = []
for path in sorted(B.glob('*.md')):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            resolved = (path.parent / target.split('#', 1)[0]).resolve()
            assert resolved.is_relative_to(B) and resolved.is_file(), (path.name, target)
            links.append({'file': path.name, 'target': target})
write('FINAL-CHECK-01.json', {'original_result_inputs_postchecked': len(inputs), 'original_result_mismatches': [],
      'named_source_postchecked': len(source), 'named_source_mismatches': [], 'supplemental_root_notes': supplement,
      'supplemental_limits': 'Root reported documentation/cleanup tool observations, not auditor OS deletion proof or new test results',
      'local_companion_links_checked': links, 'missing_local_companions': [], 'no_runtime_or_artifact_export': True})
files = {p.name: pin(p.read_bytes()) for p in sorted(B.iterdir()) if p.is_file()}
write('INTERNAL-MANIFEST.json', {'schema': 1, 'scope': 'Independent Source27 recorded-result/source/artifact audit, compact loose files only',
      'fixed_commit': 'a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c', 'files': files,
      'payload_count': len(files), 'payload_bytes': sum(v['bytes'] for v in files.values()),
      'excluded': ['process-temp', 'manifest/checksum self', 'original full source, JARs, worlds and Java build outputs'],
      'required_gates_passed': False})
manifest = pin((B / 'INTERNAL-MANIFEST.json').read_bytes())
(B / 'SHA256SUMS.txt').write_bytes((''.join(v['sha256'] + '  ' + k + '\n' for k,v in files.items())
      + manifest['sha256'] + '  INTERNAL-MANIFEST.json\n').encode('ascii'))
assert all(pin((B / name).read_bytes()) == expected for name, expected in files.items())
print(json.dumps({'report': pin((B / 'REPORT-01.md').read_bytes()), 'manifest': manifest,
       'checksum': pin((B / 'SHA256SUMS.txt').read_bytes()), 'payloads': len(files), 'payload_bytes': sum(v['bytes'] for v in files.values()),
       'result_inputs_postchecked': len(inputs), 'sources_postchecked': len(source), 'links': len(links), 'originals_changed': 0}))
