"""Negative framing controls for the independent in-memory class-file reader."""
import ast
from pathlib import Path
import unittest

tree = ast.parse((Path(__file__).parent / 'audit_source_artifacts01.py').read_text(encoding='utf-8'))
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'class_source')
ns = {}
exec(compile(ast.Module(body=[node], type_ignores=[]), '<isolated-class-reader>', 'exec'), ns)
read = ns['class_source']
u2 = lambda n: n.to_bytes(2, 'big')
u4 = lambda n: n.to_bytes(4, 'big')
utf = lambda s: b'\x01' + u2(len(s)) + s

def frame(source=True):
    cp = utf(b'example/Fixture') + b'\x07' + u2(1) + utf(b'SourceFile') + utf(b'Fixture.java')
    prefix = u4(0xCAFEBABE) + u2(0) + u2(61) + u2(5) + cp
    body = u2(1) + u2(2) + u2(0) + u2(0) + u2(0) + u2(0)
    attrs = u2(1) + u2(3) + u4(2) + u2(4) if source else u2(0)
    return prefix + body + attrs

class BinaryControls(unittest.TestCase):
    def test_exact_identity_and_java17(self):
        row = read(frame())
        self.assertEqual(('example/Fixture', 'Fixture.java', 61), (row['class_name'], row['source_file'], row['major']))
    def test_missing_source(self):
        with self.assertRaises(AssertionError): read(frame(False))
    def test_trailing_bytes(self):
        with self.assertRaises(AssertionError): read(frame() + b'\x00')
    def test_every_truncation(self):
        raw = frame()
        for n in range(len(raw)):
            with self.subTest(n=n), self.assertRaises((AssertionError, KeyError)): read(raw[:n])
    def test_bad_magic(self):
        with self.assertRaises(AssertionError): read(b'\x00\x00\x00\x00' + frame()[4:])
    def test_unknown_pool_tag(self):
        with self.assertRaises(AssertionError): read(frame()[:10] + b'\xff' + frame()[11:])
    def test_wrong_source_attribute_size(self):
        raw = frame()
        with self.assertRaises(AssertionError): read(raw[:-6] + u4(1) + raw[-2:-1])
    def test_duplicate_source_attribute(self):
        raw = frame()
        with self.assertRaises(AssertionError): read(raw[:-10] + u2(2) + raw[-8:] + raw[-8:])

if __name__ == '__main__': unittest.main(verbosity=2)
