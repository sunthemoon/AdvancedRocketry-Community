"""Pure result-audit controls, with no cohort defaults or result assumptions."""
from collections import Counter
import re
import xml.etree.ElementTree as ET

STAMP = r"(?:\d{2}:\d{2}:\d{2}|\d{2}[A-Za-z]{3}\d{4} \d{2}:\d{2}:\d{2}\.\d{3})"
HEADER = re.compile(r"^\[" + STAMP + r"\] \[(?P<thread>[^\]\r\n]+)/(?P<level>INFO|ERROR|FATAL|WARN|DEBUG)\] "
                    r"\[(?P<logger>[^\]\r\n]+)\]: (?P<message>[^\r\n]*)$")
GT = {"minecraft/GameTestServer", "net.minecraft.gametest.framework.GameTestServer/"}
REPORTER = {"minecraft/LogTestReporter", "net.minecraft.gametest.framework.LogTestReporter/"}
TASK = re.compile(r"^> Task (?P<task>:[^\s]+)(?: (?P<status>FROM-CACHE|UP-TO-DATE|NO-SOURCE|SKIPPED|FAILED))?$")


def task_observations(text):
    rows = []
    for number, line in enumerate(text.splitlines(), 1):
        match = TASK.fullmatch(line)
        if match:
            rows.append({"line": number, "task": match["task"], "status": match["status"] or "EXECUTED"})
    return rows


def junit_document(raw):
    assert b"<!DOCTYPE" not in raw and b"<!ENTITY" not in raw, "XML declaration not admitted"
    root = ET.fromstring(raw)
    assert root.tag == "testsuite"
    cases = root.findall("testcase")
    totals = {"tests": len(cases), "failures": 0, "errors": 0, "skipped": 0}
    names = Counter()
    for case in cases:
        names[(case.attrib["classname"], case.attrib["name"])] += 1
        for kind, field in (("failure", "failures"), ("error", "errors"), ("skipped", "skipped")):
            totals[field] += int(case.find(kind) is not None)
    for field, count in totals.items():
        assert root.attrib[field].isdigit() and int(root.attrib[field]) == count, (field, count, root.attrib[field])
    return {"suite": root.attrib["name"], "timestamp": root.attrib.get("timestamp"),
            "totals": totals, "cases": names}


def terminal_gt(text):
    headers = []
    for number, line in enumerate(text.splitlines(), 1):
        match = HEADER.fullmatch(line)
        if match:
            headers.append({"line": number, **match.groupdict()})
    eligible = [row for row in headers if row["thread"] == "Server thread" and row["level"] == "INFO" and row["logger"] in GT]
    completions, outcomes, boards = [], [], []
    for row in eligible:
        message = row["message"]
        if complete := re.fullmatch(r"=+ (\d+) GAME TESTS COMPLETE =+", message):
            completions.append({"line": row["line"], "total": int(complete[1])})
        if failed := re.fullmatch(r"(\d+) required tests failed :\(", message):
            outcomes.append({"line": row["line"], "status": "failed", "count": int(failed[1])})
        if passed := re.fullmatch(r"All (\d+) required tests passed :\)", message):
            outcomes.append({"line": row["line"], "status": "passed", "count": int(passed[1])})
        if board := re.fullmatch(r"\[([+X_ x]+)\]", message):
            boards.append({"line": row["line"], "symbols": board[1]})
    assert len(completions) == len(outcomes) == 1, "Missing/ambiguous terminal observations"
    completion, outcome = completions[0], outcomes[0]
    assert completion["line"] < outcome["line"]
    assert 0 < outcome["count"] <= completion["total"]
    final_boards = [row for row in boards if row["line"] < completion["line"]]
    assert final_boards, "No prior terminal board"
    final = final_boards[-1]
    symbols = Counter(final["symbols"])
    assert sum(symbols.values()) == completion["total"] and not symbols["_"] and not symbols[" "]
    assert symbols["X"] == (outcome["count"] if outcome["status"] == "failed" else 0)
    listed = []
    for row in eligible:
        if row["line"] <= outcome["line"]:
            continue
        if item := re.fullmatch(r"   - (\S+)", row["message"]):
            listed.append(item[1])
        else:
            break
    reporters = []
    for row in headers:
        if row["thread"] == "Server thread" and row["level"] == "ERROR" and row["logger"] in REPORTER:
            if failure := re.fullmatch(r"([^ ]+) failed! (.*)", row["message"]):
                reporters.append({"line": row["line"], "name": failure[1], "message": failure[2]})
    expected_failures = outcome["count"] if outcome["status"] == "failed" else 0
    assert len(listed) == len(set(listed)) == expected_failures
    assert len(reporters) == expected_failures and {row["name"] for row in reporters} == set(listed)
    errors = [row for row in headers if row["level"] in {"ERROR", "FATAL"}]
    return {"completion": completion, "outcome": outcome, "failure_names": listed,
            "native_reporters": reporters, "last_board": {"line": final["line"], "symbols": dict(symbols)},
            "error_fatal_headers": errors}
