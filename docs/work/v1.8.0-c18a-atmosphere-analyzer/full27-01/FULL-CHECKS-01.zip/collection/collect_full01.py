"""Copy only explicitly bounded frozen/result files into a unique new archive."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import sys
import zipfile
import zlib

B = Path(__file__).resolve().parent
F = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-full-20261005-01')
A = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fixed-result-audit-4f783db6c1')
P = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-fix-integration-20261005-01')
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(B / 'process-temp')
(B / 'process-temp').mkdir(exist_ok=True)
pin = lambda raw: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8')
def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '\\' not in name and ':' not in name and '..' not in p.parts and '\x00' not in name
assert not (B / 'FULL-CHECKS-01.zip').exists()
(B / 'COLLECTION-COMMAND-01.json').write_bytes(json_bytes({'command': [sys.executable, '-B', str(Path(__file__).resolve())],
      'started_utc': datetime.now(timezone.utc).isoformat(), 'process_temp': {key: os.environ[key] for key in ('TEMP', 'TMP', 'TMPDIR')},
      'scope': 'Python read/copy/hash/ZIP only; no Java/runtime/source writes'}))
audit_raw = (A / 'INTERNAL-MANIFEST.json').read_bytes()
assert pin(audit_raw)['sha256'] == 'fb368b59b7cec0ff66a8184f770bc9ace0d8a98bea55ea669bab7c09d04632e0'
audit = json.loads(audit_raw)
sources, expected = {}, {}
def add(group, path, relative=None, frozen_pin=None):
    assert path.is_file() and not path.is_symlink()
    name = group + '/' + (relative or path.name)
    assert safe(name) and name not in sources
    raw = path.read_bytes()
    if frozen_pin:
        assert pin(raw) == frozen_pin, str(path)
    sources[name] = path
    expected[name] = pin(raw)
for name, frozen_pin in audit['files'].items():
    assert safe(name)
    add('audit', A / name, frozen_pin=frozen_pin)
add('audit', A / 'INTERNAL-MANIFEST.json')
add('audit', A / 'SHA256SUMS.txt', frozen_pin={'bytes': 3313, 'sha256': 'a4de122e62b8a9a3d442387f24b64afbbe677c8b0f76e24fcdd6ce482c63627c'})

original_full = json.loads((A / 'ROOT-INPUT-PINS-01.json').read_bytes())['files']
supplement = json.loads((A / 'FINAL-CHECK-01.json').read_bytes())['supplemental_root_notes']
for path in sorted(F.iterdir()):
    if path.is_file():
        assert path.name in original_full or path.name in supplement, ('new unpinned top-level input', path.name)
        add('full', path, frozen_pin=original_full.get(path.name, supplement.get(path.name)))
for path in sorted((F / 'junit-01').glob('TEST-*.xml')):
    relative = path.relative_to(F).as_posix()
    add('full', path, relative, original_full[relative])
excluded = {}
for path in sorted(P.iterdir()):
    if not path.is_file():
        continue
    if path.name in {'FIX-SOURCE-CHECKS-01.zip', 'publication-command-14.stdout'}:
        excluded[path.name] = {'original': str(path), **pin(path.read_bytes()), 'reason': 'Exact duplicate prior source-review ZIP, preserved separately; no nested archive duplication'}
    else:
        assert not path.name.endswith('.zip')
        add('root-publication', path)
assert set(excluded) == {'FIX-SOURCE-CHECKS-01.zip', 'publication-command-14.stdout'}
assert {v['sha256'] for v in excluded.values()} == {'db736d3de4286b179ad38a463773310eadfc8eb9e6003f1c6ad10ebac0765cee'}
pub = json.loads((P / 'PUBLICATION-COMMANDS-01.json').read_bytes())
assert pub[13]['stdout'] == 'publication-command-14.stdout' and pub[13]['exit'] == 0
exclusion = {'files': excluded,
             'preserved_separate_locator': 'docs/work/v1.8.0-c18a-atmosphere-analyzer/fix01/FIX-SOURCE-CHECKS-01.zip',
             'claim_limits': 'Pins only; no re-export/reinterpretation of old ZIP contents and not full publication raw-output closure. Corresponding command/stderr/checksum and all other publication records are retained.'}
(B / 'EXCLUSIONS-01.json').write_bytes(json_bytes(exclusion))
groups = {group: {'files': sum(name.startswith(group + '/') for name in sources),
                   'bytes': sum(expected[name]['bytes'] for name in sources if name.startswith(group + '/'))}
          for group in ('full', 'audit', 'root-publication')}
intake = {'fixed_code_commit': 'a0873a30a2e1ad9fe0b42d11a0b89903fc478d5c', 'groups': groups,
          'inputs': {name: {'original': str(sources[name]), **expected[name]} for name in sorted(sources)},
          'excluded': exclusion, 'result_reclassification': False,
          'excluded_directories': ['artifacts-01', 'process-temp', '__pycache__', 'runtime/world', 'wholeRoot']}
(B / 'COLLECTION-INPUT-PINS-01.json').write_bytes(json_bytes(intake))
for name in ('README-01.md', 'collect_full01.py', 'EXCLUSIONS-01.json', 'COLLECTION-INPUT-PINS-01.json', 'COLLECTION-COMMAND-01.json'):
    add('collection', B / name)
manifest = {'schema': 1, 'fixed_code_commit': intake['fixed_code_commit'], 'groups': groups,
            'files': {name: {**expected[name], 'crc32': f'{zlib.crc32(sources[name].read_bytes()) & 0xffffffff:08x}'} for name in sorted(sources)},
            'payloads': len(sources), 'payload_bytes': sum(v['bytes'] for v in expected.values()),
            'self_excluded': 'PACKET-MANIFEST-01.json is bound by outer archive SHA and collection result; no recursive self-hash',
            'required_gates_passed': False}
manifest_raw = json_bytes(manifest)
(B / 'PACKET-MANIFEST-01.json').write_bytes(manifest_raw)
with zipfile.ZipFile(B / 'FULL-CHECKS-01.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(sources):
        archive.writestr(name, sources[name].read_bytes())
    archive.writestr('PACKET-MANIFEST-01.json', manifest_raw)
with zipfile.ZipFile(B / 'FULL-CHECKS-01.zip') as archive:
    info = archive.infolist()
    assert len(info) == len({v.filename for v in info}) == len(sources) + 1
    assert archive.testzip() is None
    assert archive.read('PACKET-MANIFEST-01.json') == manifest_raw
    for name, row in manifest['files'].items():
        raw = archive.read(name)
        assert pin(raw) == {k: row[k] for k in ('bytes', 'sha256')}
        assert f'{archive.getinfo(name).CRC:08x}' == row['crc32']
assert all(pin(path.read_bytes()) == expected[name] for name,path in sources.items())
for path in excluded.values():
    assert pin(Path(path['original']).read_bytes()) == {k:path[k] for k in ('bytes','sha256')}
archive_pin = pin((B / 'FULL-CHECKS-01.zip').read_bytes())
(B / 'FULL-CHECKS-01.zip.sha256').write_bytes((archive_pin['sha256'] + '  FULL-CHECKS-01.zip\n').encode('ascii'))
result = {'exit': 0, 'archive': archive_pin, 'sidecar': pin((B / 'FULL-CHECKS-01.zip.sha256').read_bytes()),
          'internal_manifest': pin(manifest_raw), 'archive_entries': len(sources) + 1, 'payloads': len(sources),
          'payload_bytes': manifest['payload_bytes'], 'groups': groups,
          'all_CRC_member_pin_checks': True, 'all_original_inputs_postchecked': len(sources), 'original_mismatches': [],
          'excluded_duplicate_input_postchecks': len(excluded), 'no_test_or_native_execution': True,
          'result_reclassification': False, 'audit_report': pin((A / 'REPORT-01.md').read_bytes())}
(B / 'COLLECTION-RESULT-01.json').write_bytes(json_bytes(result))
print(json.dumps(result))
