# Source27 full-check evidence packet

This is a byte-preserving compact collection, not a new execution or acceptance.
`full/` contains the actual committed full/repeated/static result receipts,
logs, all339 JUnit XML and bounded helpers. `audit/` contains the frozen
independent result audit plus its original metadata. `root-publication/`
contains the source-correction integration/publication records and raw command
outputs except the explicitly excluded binary stdout14. This is not the full
publication raw-output closure. The report's actual scoped results coexist with original failed
lineage and cache qualifications; collection does not turn any failure into a
pass or close native/client/version Gates.

No JAR, whole source tree, Java build output, runtime/world, process-temp,
__pycache__ or duplicate prior source-review ZIP is included. The duplicate
prior source ZIP and its exact binary Git stdout are explicitly pinned but
excluded; their other publication receipts remain. `collection/` binds this
selection, the exclusions and collection helper. `PACKET-MANIFEST-01.json`
records every other member's length, SHA-256 and CRC32. The archive's `.sha256`
sidecar and external collection result bind the archive itself.

The earlier source-review archive remains separately published at
`docs/work/v1.8.0-c18a-atmosphere-analyzer/fix01/FIX-SOURCE-CHECKS-01.zip`,
SHA-256 `db736d3de4286b179ad38a463773310eadfc8eb9e6003f1c6ad10ebac0765cee`.
