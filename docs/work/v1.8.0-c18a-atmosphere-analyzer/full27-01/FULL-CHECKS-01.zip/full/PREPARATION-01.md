# Committed regression preparation

Two new drivers are prepared but not executed. They require a subsequently
created `COHORT-INPUT-01.json` identifying the reviewed, committed correction.
Source27 will compare the preceding 3,036 named inputs and add only the two FIX
records plus Root's source disposition, not claim a whole-repository snapshot.
Only the reviewed GameTest file may change among preceding inputs. Independent
reviewer execution currently owns the one Java slot; Root does not start Java.

The mandatory clean/build/test/DataGen and unfiltered GameTest results, repeat
DataGen, static exits, one-compilation-unit package audit and fresh disk/temp
observations will be retained as actual observations. Prior Source26 and three
author diagnostic failures remain immutable. These prepared drivers are not
evidence of successful execution or version acceptance.

Before any execution the prepared flags add `--no-build-cache`, so a restored
JUnit cache is not mislabeled as Root's new test execution. The independent
reviewer's first combined replay actually runs all GameTests but restores its
scoped `:test` from cache; that distinct observation is retained and a separate
no-cache scoped replay is assigned. No driver/result already executed is edited.

A combined Root read returned exit 1 after an optional read of
`NATIVE-HANDOFF-04.md` in the integration checkout, where that not-yet-integrated
worker record was absent. The analyzer author records preceding that optional
read were read successfully. No missing file was created, native/Python/Java
test was invoked, or successful result inferred from this locator attempt.
