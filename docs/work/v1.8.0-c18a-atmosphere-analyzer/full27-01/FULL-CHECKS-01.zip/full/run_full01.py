"""Complete committed analyzer-fixture regression; preserve every actual exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
PREVIOUS = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
CONFIG = json.loads((OUT / 'COHORT-INPUT-01.json').read_bytes())
HEAD = CONFIG['code_commit']
TEMP = OUT / 'process-temp'
TEMP.mkdir(exist_ok=True)
for key in ('TEMP', 'TMP', 'TMPDIR'):
    os.environ[key] = str(TEMP)
os.environ['JAVA_HOME'] = 'C:/Program Files/Java/jdk-17.0.7'
os.environ['PATH'] = os.environ['JAVA_HOME'] + '/bin;' + os.environ['PATH']
assert not os.environ.get('JAVA_TOOL_OPTIONS')
os.environ['JAVA_TOOL_OPTIONS'] = '-Djava.io.tmpdir=' + TEMP.as_posix()

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(name, value):
    target = OUT / name
    assert not target.exists(), name
    target.write_bytes((json.dumps(value, indent=2, sort_keys=True)+'\n').encode())

def current_head():
    return subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT).decode().strip()

assert current_head() == HEAD
assert not subprocess.check_output(['git','diff','--cached','--name-only'], cwd=ROOT)
assert not subprocess.check_output(['git','diff','--name-only','--','src/main','src/test','src/generated','scripts'], cwd=ROOT)
old = json.loads((PREVIOUS/'SOURCE26-MANIFEST-01.json').read_bytes())
assert len(old) == 3036
source = {name:pin(ROOT/name) for name in old}
changed = {name:{'previous':row,'current':source[name]} for name,row in old.items() if row != source[name]}
gt_path = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
assert set(changed) == {gt_path}, changed
assert source[gt_path]['sha256'] == CONFIG['reviewed_gt_sha256']
additional = CONFIG['additional_named_inputs']
assert len(additional) == len(set(additional)) == 3
assert not set(additional) & set(source)
source.update({name:pin(ROOT/name) for name in additional})
qualifications = {}
for name,row in source.items():
    data = (ROOT/name).read_bytes()
    committed = subprocess.check_output(['git','show',HEAD+':'+name], cwd=ROOT)
    if committed != data:
        assert name == 'AGENTS.md' or committed.replace(b'\r\n',b'\n') == data.replace(b'\r\n',b'\n'), name
        qualifications[name] = {'git_bytes':len(committed),'git_sha256':hashlib.sha256(committed).hexdigest(),
            'live':row,'qualification':'owner-maintained live AGENTS, excluded from staging' if name=='AGENTS.md' else 'exact LF/CRLF expansion only'}
save('SOURCE27-MANIFEST-01.json',source)
save('SOURCE27-BOUNDARY-01.json',{'tested_commit':HEAD,'previous_full_commit':'9fce551ea9389ce37a94f804aa0e817399586a7e',
    'previous_full_result':'four required analyzer failures retained','named_inputs':len(source),
    'not_whole_repository':True,'added_named_inputs':additional,'changed_from_prior_cohort':changed,
    'git_qualifications':qualifications,'cohort_input':pin(OUT/'COHORT-INPUT-01.json'),
    'TEMP_TMP_TMPDIR':str(TEMP),'JAVA_TOOL_OPTIONS':os.environ['JAVA_TOOL_OPTIONS'],'required_gates_passed':False})
flags = [str(ROOT/'gradlew.bat'),'--offline','--no-daemon','--no-build-cache','--max-workers=2',
    '-Dorg.gradle.jvmargs=-Xmx2G -Djava.io.tmpdir='+TEMP.as_posix()]
rows = []
try:
    for label,command in [('full-build-01',flags+['clean','build','test','runData']),
                          ('gametest-01',flags+['runGameTestServer'])]:
        assert current_head() == HEAD
        free = {drive:shutil.disk_usage(drive+':/').free for drive in ('C','D')}
        assert all(value >= 10_000_000_000 for value in free.values()), free
        save(label+'.command.json',{'command':command,'cwd':str(ROOT),'tested_commit':HEAD,
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':free,
            'threshold_bytes':10_000_000_000,'TEMP_TMP_TMPDIR':str(TEMP),'JAVA_TOOL_OPTIONS':os.environ['JAVA_TOOL_OPTIONS']})
        begin = time.monotonic()
        with (OUT/(label+'.log')).open('xb') as log:
            actual = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        row = {'name':label,'exit':actual.returncode,'seconds':time.monotonic()-begin,'log':pin(OUT/(label+'.log'))}
        rows.append(row)
        save(label+'.result.json',row)
        print(json.dumps(row),flush=True)
        if label == 'full-build-01':
            junit = OUT/'junit-01'
            junit.mkdir()
            totals = dict(suites=0,tests=0,failures=0,errors=0,skipped=0)
            for path in sorted((ROOT/'build/test-results/test').glob('TEST-*.xml')):
                shutil.copyfile(path,junit/path.name)
                suite = ET.parse(path).getroot()
                totals['suites'] += 1
                for key in ('tests','failures','errors','skipped'):
                    totals[key] += int(suite.attrib[key])
            save('JUNIT-01.json',totals)
            if actual.returncode == 0:
                artifacts = OUT/'artifacts-01'
                artifacts.mkdir()
                captured = {}
                for suffix in ('','-sources','-api'):
                    name = 'advancedrocketry-community-1.20.1-1.8.0-dev'+suffix+'.jar'
                    original = ROOT/'build/libs'/name
                    shutil.copyfile(original,artifacts/name)
                    assert pin(original) == pin(artifacts/name)
                    captured[name] = pin(artifacts/name)
                save('ARTIFACTS-01.json',captured)
                assert totals == dict(suites=339,tests=1807,failures=0,errors=0,skipped=0), totals
        else:
            for name in ('latest.log','debug.log'):
                original = ROOT/'build/gametest/logs'/name
                if original.is_file():
                    shutil.copyfile(original,OUT/('gametest-01-'+name))
            raw = (OUT/'gametest-01.log').read_text(encoding='utf-8',errors='replace')
            passed = re.findall(r'All (\d+) required tests passed',raw)
            completed = re.findall(r'(\d+) GAME TESTS COMPLETE',raw)
            failures = re.findall(r'(\d+) required tests failed',raw)
            save('GAMETEST-01.json',{'command_exit':actual.returncode,'required_pass_reports':passed,
                'completed_reports':completed,'required_failure_reports':failures,
                'error_headers':len(re.findall(r'^.*\[[^\r\n]*ERROR\]',raw,re.MULTILINE)),'no_blanket_log_waiver':True})
            if actual.returncode == 0:
                assert passed and all(value=='477' for value in passed), passed
        if actual.returncode:
            break
finally:
    drift = [name for name,row in source.items() if not (ROOT/name).is_file() or pin(ROOT/name) != row]
    stable_head = current_head() == HEAD
    save('SOURCE27-POSTCHECK-01.json',{'named_inputs':len(source),'mismatches':drift,'tested_head_unchanged':stable_head,'required_gates_passed':False})
    save('FULL-CHECKS-01.json',{'commands':rows,'tested_commit':HEAD,'source_unchanged':not drift and stable_head,'required_gates_passed':False})
assert not drift and stable_head
assert len(rows) == 2
sys.exit(rows[-1]['exit'])
