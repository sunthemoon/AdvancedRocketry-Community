# Metadata locator selection error

Root's initial read-only inline metadata probe selects the first filename
containing MANIFEST and then expects a `files` field. It actually selects an
execution source-map manifest and raises KeyError before printing a result.
The combined PowerShell command continues to read the review and returns 0;
that wrapper exit does not turn the failed Python probe into a success.
The original tool output is retained. A later explicit-name metadata probe
reads the actual two evidence manifests successfully. No Root source/index,
old sealed file, Java process or artifact is changed by either probe.
