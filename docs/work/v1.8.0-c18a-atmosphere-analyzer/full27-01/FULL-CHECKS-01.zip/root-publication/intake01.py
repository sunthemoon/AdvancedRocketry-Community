"""Seal exact independent correction evidence and prepare an apply_patch input."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
PARENT = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0')
GROUPS = [
    ('author', PARENT/'c18-analyzer-fix-author-ea8349712b', 'INTERNAL-MANIFEST-01.json',
     'eb49744fa37f02caa7c03ba4bea1f3a755e9d6b5697bc5f500ae4c2708579b74', 102, None),
    ('source-review', PARENT/'c18-analyzer-corrected-review-0da9d89cec', 'INTERNAL-MANIFEST-01.json',
     '01d920335adeb8d34e75ccd0ea5df4862c13181962c2631738066d7d5afd582a', 79, 'SHA256SUMS.txt'),
    ('technical-review', PARENT/'c18-analyzer-gt-registry-review-c6ca391f42', 'INTERNAL-MANIFEST.json',
     'd5acd728ad474d4e21772f29cb888c27bbb4d6eb86fcce5a87b406000d21114e', 32, 'SHA256SUMS.txt'),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

payloads = {}
originals = {}
for prefix, directory, name, expected, count, checksum in GROUPS:
    raw = (directory/name).read_bytes()
    assert sha(raw)==expected, name
    manifest = json.loads(raw)
    rows = manifest['files']
    assert len(rows)==count
    for row in rows:
        path = row['path']
        data = (directory/path).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256'], (prefix,path)
        member = prefix+'/'+path
        assert member not in payloads
        payloads[member] = data
        originals[str(directory/path)] = {'bytes':len(data),'sha256':sha(data)}
    payloads[prefix+'/'+name] = raw
    if checksum:
        checksum_data = (directory/checksum).read_bytes()
        for line in checksum_data.decode().splitlines():
            digest, path = line.split('  ',1)
            assert re.fullmatch(r'[0-9a-f]{64}',digest) and sha((directory/path).read_bytes())==digest, path
        payloads[prefix+'/'+checksum] = checksum_data
author = GROUPS[0][1]
review = GROUPS[1][1]
assert sha((review/'REVIEW-01.md').read_bytes())=='7b81c11ac68aee4cfe8d12ae8ceb1e25eb24474b6c31eba6636d96b90cc9e187'
owned = json.loads((author/'OWNED-FILES-01.json').read_bytes())
assert len(owned['files'])==3 and owned['base']=='9fce551ea9389ce37a94f804aa0e817399586a7e'
for row in owned['files']:
    data = (author/row['evidence_path']).read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['bytes']
gt = owned['files'][0]
assert sha((ROOT/gt['repository_path']).read_bytes())=='54e6ff5aae95f760260229fcbe2b8c830336726cea1ed75528fd23e87909ce21'
patch = (author/'SOURCE-FIX-01.patch').read_bytes()
assert sha(patch)=='87a711965b8d77a3722859584f1678b269cbaf6b0c945d64b4580afdfa6f8d3e'
lines = patch.decode().splitlines()
start = next(i for i,line in enumerate(lines) if line.startswith('@@'))
chunks = ['@@' if line.startswith('@@') else line for line in lines[start:]]
prepared = ['*** Begin Patch','*** Update File: '+(ROOT/gt['repository_path']).as_posix()] + chunks
for row in owned['files'][1:]:
    prepared += ['*** Add File: '+(ROOT/row['repository_path']).as_posix()]
    prepared += ['+'+line for line in (author/row['evidence_path']).read_text(encoding='utf-8').splitlines()]
prepared.append('*** End Patch')
(OUT/'APPLY-01.patch').write_text('\n'.join(prepared)+'\n',encoding='utf-8')
assert len(payloads)==218
outer = {'scope':'thin author, independent corrected-source and technical-boundary evidence; no new Root execution',
    'fixed_base':owned['base'],'reviewed_gt_sha256':gt['sha256'],
    'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(payloads.items())}}
raw_outer = (json.dumps(outer,indent=2,sort_keys=True)+'\n').encode()
zip_path = OUT/'FIX-SOURCE-CHECKS-01.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payloads.items()):
        info = zipfile.ZipInfo(name,(2026,10,5,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
    archive.writestr('INTERNAL-MANIFEST.json',raw_outer)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))==219
    assert archive.read('INTERNAL-MANIFEST.json')==raw_outer
    assert all(archive.read(name)==data for name,data in payloads.items())
assert all(len(Path(path).read_bytes())==pin['bytes'] and sha(Path(path).read_bytes())==pin['sha256'] for path,pin in originals.items())
data = zip_path.read_bytes()
sidecar = (sha(data)+'  FIX-SOURCE-CHECKS-01.zip\n').encode()
(OUT/'FIX-SOURCE-CHECKS-01.zip.sha256').write_bytes(sidecar)
destination = ROOT/'docs/work/v1.8.0-c18a-atmosphere-analyzer/fix01'
assert not destination.exists()
destination.mkdir()
for name, content in [('FIX-SOURCE-CHECKS-01.zip',data),('FIX-SOURCE-CHECKS-01.zip.sha256',sidecar)]:
    with (destination/name).open('xb') as handle:
        handle.write(content)
    assert (destination/name).read_bytes()==content
result = {'original_payloads':len(originals),'archive_members':219,'bytes':len(data),'sha256':sha(data),
    'outer_manifest_sha256':sha(raw_outer),'apply_patch_sha256':sha((OUT/'APPLY-01.patch').read_bytes()),
    'crc_member_and_original_postcheck':True,'source_not_yet_applied':True}
(OUT/'INTAKE-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
