"""Publish the reviewed one-GameTest correction and eight owned records."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = Path(__file__).resolve().parent
BASE = '8af62cc489631a162089a7ecae08ab3525565adb'
BRANCH = 'codex/v1.8.0-classic-content'
GT = 'src/main/java/io/github/sunthemoon/advancedrocketrycommunity/gametest/AtmosphereAnalyzerGameTests.java'
PREFIX = 'docs/work/v1.8.0-c18a-atmosphere-analyzer/'
PATHS = sorted([GT,'docs/status/CURRENT_VERSION.md','docs/status/COMPLETION-PLAN.md',
    'docs/work/v1.8.0-implementation-log.md']+[PREFIX+name for name in (
    'FIX-PROGRESS-01.md','FIX-HANDOFF-01.md','FIX-REVIEW-DISPOSITION-01.md',
    'fix01/FIX-SOURCE-CHECKS-01.zip','fix01/FIX-SOURCE-CHECKS-01.zip.sha256')])
OLD = Path('D:/GitHub/ARCE-Task-Evidence/v1.8.0/c18-analyzer-full-20261005-01')
pins = json.loads((OLD/'SOURCE26-MANIFEST-01.json').read_bytes())
owner_before = (ROOT/'AGENTS.md').read_bytes()
commands = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(args, allowed=(0,)):
    begin = time.monotonic()
    actual = subprocess.run(args,cwd=ROOT,capture_output=True)
    stem = 'publication-command-%02d' % (len(commands)+1)
    (OUT/(stem+'.stdout')).write_bytes(actual.stdout)
    (OUT/(stem+'.stderr')).write_bytes(actual.stderr)
    commands.append({'command':args,'exit':actual.returncode,'seconds':time.monotonic()-begin,
        'stdout':stem+'.stdout','stderr':stem+'.stderr'})
    (OUT/'PUBLICATION-COMMANDS-01.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
    assert actual.returncode in allowed,(stem,actual.returncode)
    return actual.stdout

def source_check():
    changes = []
    for path,pin in pins.items():
        data = (ROOT/path).read_bytes()
        if len(data)!=pin['bytes'] or sha(data)!=pin['sha256']:
            changes.append(path)
    assert changes==[GT], changes
    assert sha((ROOT/GT).read_bytes())=='275947498de7b42a18f142616258c75400bedd7ed8d0a8f1d5b608d106b229c3'

begin = time.monotonic()
result = {'paths':PATHS,'scope':'one reviewed GT fixture correction; complete committed regression remains pending'}
try:
    assert run(['git','rev-parse','HEAD']).decode().strip()==BASE
    assert not run(['git','diff','--cached','--name-only'])
    assert run(['git','diff','--name-only','--','src/main','src/test','src/generated','scripts']).decode().splitlines()==[GT]
    assert sha(owner_before)=='1be0391c3f69f566ae3f627e37107adfbd0bbfa6f581b105ff6bd2a2c2630dc0'
    source_check()
    links = 0
    for path in PATHS:
        if path.endswith('.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(ROOT/path).read_text(encoding='utf-8')):
                if not target.startswith(('http:','https:','#')):
                    assert (ROOT/path).parent.joinpath(target.split('#')[0]).exists(),(path,target)
                    links += 1
    result['local_links'] = links
    run(['python','-B','scripts/validate_v1plus_planning.py'])
    run(['git','diff','--check'])
    run(['git','diff','--exit-code'],allowed=(1,))
    images = {path:(ROOT/path).read_bytes() for path in PATHS}
    assert sha(images[PREFIX+'fix01/FIX-SOURCE-CHECKS-01.zip'])=='db736d3de4286b179ad38a463773310eadfc8eb9e6003f1c6ad10ebac0765cee'
    run(['git','add','--']+PATHS)
    assert sorted(run(['git','diff','--cached','--name-only']).decode().splitlines())==PATHS
    result['staged_identities'] = {}
    for path,data in images.items():
        staged = run(['git','show',':'+path])
        assert staged==data or staged==data.replace(b'\r\n',b'\n'), path
        result['staged_identities'][path] = {'physical_sha256':sha(data),'staged_sha256':sha(staged),
            'qualification':'literal' if staged==data else 'exact CRLF-to-LF only'}
    run(['git','diff','--cached','--stat'])
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','test(atmosphere): repair analyzer registry and world fixtures'])
    head = run(['git','rev-parse','HEAD']).decode().strip()
    run(['git','push','origin','HEAD:refs/heads/'+BRANCH])
    remote = run(['git','ls-remote','origin','refs/heads/'+BRANCH]).decode().split()[0]
    assert remote==head and not run(['git','diff','--cached','--name-only'])
    source_check()
    assert (ROOT/'AGENTS.md').read_bytes()==owner_before
    assert all((ROOT/path).read_bytes()==data for path,data in images.items())
    result.update(status='PASS',commit=head,remote_commit=remote,named_inputs_checked=3036,only_existing_GT_source_changed=True)
finally:
    result['seconds'] = time.monotonic()-begin
    (OUT/'PUBLICATION-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:value for key,value in result.items() if key!='staged_identities'}))
