"""Print failing JUnit test cases with a bounded message excerpt."""
import pathlib
import sys
import xml.etree.ElementTree as ET

root = pathlib.Path(r"D:/GitHub/AdvancedRocketry-Community/build/test-results/test")
limit = int(sys.argv[1]) if len(sys.argv) > 1 else 600
for path in sorted(root.glob("*.xml")):
    tree = ET.parse(path).getroot()
    for case in tree.findall("testcase"):
        for failure in list(case.findall("failure")) + list(case.findall("error")):
            text = (failure.get("message") or "") + "\n" + (failure.text or "")
            lines = [line for line in text.splitlines() if line.strip()]
            keep = [line for line in lines if "at org.junit" not in line and "at java." not in line
                    and "at jdk." not in line and "at org.gradle" not in line][:14]
            print("==", tree.get("name").split(".")[-1], "::", case.get("name"))
            print("\n".join(keep)[:limit])
