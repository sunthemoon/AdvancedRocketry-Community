"""Preserve stopped fourth-process disk evidence without resuming the world."""
import json
import shutil
import socket
from pathlib import Path
import independent_postcheck as check

base = Path(__file__).resolve().parent
server = base / "server"
target = base / "failed-uninstall-disk"
target.mkdir()
paths = ["world/region/r.0.0.mca", "world/entities/r.0.0.mca",
         "world/data/advancedrocketrycommunity_rocket_transactions.dat", "world/level.dat",
         "server.properties", "config/advancedrocketrycommunity-common.toml", "config/fml.toml"]
files = []
for relative in paths:
    source, copied = server / relative, target / relative
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, copied)
    assert check.digest(source) == check.digest(copied)
    files.append({"path": relative, "bytes": copied.stat().st_size, "sha256": check.digest(copied)})
previous = base / "recovery-evidence/provider-skipped"
entities = check.read_entities(target / "world/entities/r.0.0.mca")
previous_entities = check.read_entities(previous / "world/entities/r.0.0.mca")
rocket = [entity for entity in entities if entity["id"] == check.ROCKET]
previous_rocket = [entity for entity in previous_entities if entity["id"] == check.ROCKET]
assert len(rocket) == len(previous_rocket) == 1
assert rocket[0]["RocketEntityData"] == previous_rocket[0]["RocketEntityData"]
assert rocket[0]["UUID"] == previous_rocket[0]["UUID"]
journal_path = "world/data/advancedrocketrycommunity_rocket_transactions.dat"
journal = check.read_journal(target / journal_path)
assert journal == check.read_journal(previous / journal_path)
assert len(journal["transactions"]) == 1
assert journal["transactions"][0]["snapshot"] == rocket[0]["RocketEntityData"]["snapshot"]
data = (target / "world/region/r.0.0.mca").read_bytes()
chunk = check.region._decode_chunk(check.region._region_chunk(data, 16, 16), 16, 16)
positions = [(256, 100, 256), (256, 101, 256), (256, 102, 256), (256, 103, 256), (257, 101, 256)]
blocks = {str(pos): check.block_name(chunk, *pos) for pos in positions}
assert list(blocks.values()) == [check.HOST + ":rocket_assembler"] + ["minecraft:air"] * 4
assert not any(be["id"] == check.CARGO for be in chunk["block_entities"])
assert not any(entity["id"] == "minecraft:item" for entity in entities)
summary = json.loads((base / "recovery-evidence/summary.json").read_text(encoding="utf-8"))
try:
    connection = socket.create_connection(("127.0.0.1", summary["port"]), timeout=1)
except OSError:
    pass
else:
    connection.close()
    raise AssertionError("Owned endpoint remains open")
result = {"scope": "Read-only post-failure observation; not a six-phase pass", "files": files,
          "entity_count": len(rocket), "journal_count": len(journal["transactions"]),
          "entity_uuid": check.nbt_uuid(rocket[0]["UUID"]), "journal": journal,
          "rocket_entity_data": rocket[0]["RocketEntityData"], "blocks": blocks,
          "observed_port_closed": summary["port"]}
(target / "postcheck.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print("PASS read-only failure postcheck: exact fourth-process opaque entity/journal retained, four source blocks air, no cargo BE/item drops, endpoint closed; no reinstall executed")
