"""Read captured disk bytes and full logs, independent of runner verdict fields."""
import hashlib
import json
import re
import socket
import sys
import uuid
import zlib
from pathlib import Path

sys.dont_write_bytecode = True
REPO = Path("D:/GitHub/AdvancedRocketry-Community")
sys.path.insert(0, str(REPO / "scripts"))
import run_dedicated_server_smoke as smoke
import v120_precision_world_fixture as region
from inspect_celestial_saved_data import NbtReader
from run_v100_transaction_forced_stop import read_journal

BASE = Path(__file__).resolve().parent
EVIDENCE = BASE / "recovery-evidence"
PHASES = ["assemble", "entity-restart", "provider-skipped", "mod-uninstalled",
          "provider-reinstalled", "container-restart"]
HOST = "advancedrocketrycommunity"
FIXTURE = "arce_adapter_test"
ROCKET = HOST + ":rocket"
CARGO = FIXTURE + ":cargo_container"
ITEMS = [{"Slot": 0, "id": "minecraft:diamond", "Count": 17,
          "tag": {"display": {"Name": '{"text":"Public adapter cargo"}'}}},
         {"Slot": 1, "id": "minecraft:iron_ingot", "Count": 64}]
ERROR = re.compile(r"\[[^\]]+/(?:ERROR|FATAL)\]")
LINKAGE = re.compile(r"NoSuchMethodError|AbstractMethodError|NoClassDefFoundError|ClassNotFoundException|IncompatibleClassChangeError|LinkageError")
MAPPING = "There are unidentified mappings in this world - we are going to attempt to process anyway"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nbt_uuid(value):
    assert isinstance(value, list) and len(value) == 4
    return str(uuid.UUID(bytes=b"".join((number & 0xffffffff).to_bytes(4, "big") for number in value)))


def read_entities(path):
    data = path.read_bytes()
    assert len(data) <= 16 * 1024**2
    offset = 4 * (16 + 32 * 16)
    if data[offset:offset + 4] == bytes(4):
        return []
    compressed = region._region_chunk(data, 16, 16)
    decoder = zlib.decompressobj()
    payload = decoder.decompress(compressed, 4 * 1024**2 + 1)
    assert len(payload) <= 4 * 1024**2 and decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    root = NbtReader(payload).read_root()
    assert root["Position"] == [16, 16]
    return root["Entities"]


def block_name(chunk, x, y, z):
    sections = [section for section in chunk["sections"] if section["Y"] == y // 16]
    assert len(sections) == 1
    states = sections[0]["block_states"]
    palette = states["palette"]
    if len(palette) == 1:
        return palette[0]["Name"]
    bits = max(4, (len(palette) - 1).bit_length())
    values_per_long = 64 // bits
    cell = (y % 16) * 256 + (z % 16) * 16 + x % 16
    word = states["data"][cell // values_per_long] & ((1 << 64) - 1)
    index = (word >> ((cell % values_per_long) * bits)) & ((1 << bits) - 1)
    return palette[index]["Name"]


def main():
    summary = json.loads((EVIDENCE / "summary.json").read_text(encoding="utf-8"))
    assert [cycle["phase"] for cycle in summary["cycles"]] == PHASES
    identities = json.loads((BASE / "artifact-identities.json").read_text(encoding="utf-8-sig"))
    for artifact in identities["artifacts"]:
        assert digest(Path(artifact["copy"])) == artifact["sha256"]
        assert digest(Path(summary["server"]) / "mods" / Path(artifact["copy"]).name) == artifact["sha256"]
    baseline = staged = None
    observations = []
    positions = {(256, 100, 256): HOST + ":rocket_assembler",
                 (256, 101, 256): HOST + ":rocket_motor", (256, 102, 256): HOST + ":rocket_seat",
                 (256, 103, 256): HOST + ":guidance_computer", (257, 101, 256): CARGO}
    for cycle in summary["cycles"]:
        phase = cycle["phase"]
        folder = EVIDENCE / phase
        assert cycle["exit_code"] == 0 and cycle["observation_ticks"] >= 20
        status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
        mods = smoke.forge_mod_versions(status)
        expected = {HOST, "forge", "minecraft"} | (set() if phase == "mod-uninstalled" else {FIXTURE})
        assert set(mods) == expected and mods[HOST] == "1.20.1-1.3.0-dev"
        stdout = (folder / "stdout.txt").read_text(encoding="utf-8")
        registered = [line for line in stdout.splitlines() if "Registered rocket adapter " in line]
        skipped = [line for line in stdout.splitlines() if "Skipped rocket adapter " in line]
        if phase == "mod-uninstalled":
            assert not registered and not skipped
        elif phase == "provider-skipped":
            assert not registered and len(skipped) == 1 and "(API 1.1, event 1)" in skipped[0]
        else:
            assert len(registered) == 1 and not skipped and "(payload 1, API 1.1, event 1)" in registered[0]
        log_reports = []
        for name in ("stdout.txt", "debug.log", "latest.log"):
            text = (folder / name).read_text(encoding="utf-8")
            assert not LINKAGE.search(text), (phase, name)
            findings = [line for line in text.splitlines() if ERROR.search(line)]
            for finding in findings:
                assert (phase == "mod-uninstalled" and finding.endswith(MAPPING)
                        and re.search(r"\[(?:ne\.mi\.re\.|net\.minecraftforge\.registries\.)GameData/REGISTRIES\]", finding)), finding
            log_reports.append({"file": name, "sha256": digest(folder / name), "errors": findings,
                                "warning_count": len([line for line in text.splitlines() if "/WARN]" in line])})
        debug = (folder / "debug.log").read_text(encoding="utf-8")
        loaded_sources = []
        for artifact in identities["artifacts"]:
            installed = str(Path(summary["server"]) / "mods" / Path(artifact["copy"]).name)
            source_line = "Loading mod file " + installed
            hits = [line for line in debug.splitlines() if source_line in line]
            assert bool(hits) == (artifact["mod_id"] != FIXTURE or phase != "mod-uninstalled")
            loaded_sources.extend(hits)
        entities = read_entities(folder / "world/entities/r.0.0.mca")
        rockets = [entity for entity in entities if entity["id"] == ROCKET]
        assert not any(entity["id"] == "minecraft:item" for entity in entities)
        chunk_bytes = (folder / "world/region/r.0.0.mca").read_bytes()
        chunk = region._decode_chunk(region._region_chunk(chunk_bytes, 16, 16), 16, 16)
        recovered = phase in PHASES[4:]
        assert len(rockets) == (0 if recovered else 1)
        observed_blocks = {str(pos): block_name(chunk, *pos) for pos in positions}
        assert observed_blocks == {str(pos): name if recovered or pos[1] == 100 else "minecraft:air" for pos, name in positions.items()}
        cargo = [entry for entry in chunk["block_entities"] if entry["id"] == CARGO]
        journal = read_journal(folder / "world/data/advancedrocketrycommunity_rocket_transactions.dat")
        if recovered:
            assert len(cargo) == 1 and (cargo[0]["x"], cargo[0]["y"], cargo[0]["z"]) == (257, 101, 256)
            assert cargo[0]["FixtureInventory"] == {"schema_version": 1, "Items": ITEMS}
            assert journal["transactions"] == []
        else:
            assert not cargo
            data = rockets[0]["RocketEntityData"]
            if baseline is None:
                baseline = data
            assert data == baseline
            assert nbt_uuid(rockets[0]["UUID"]) == summary["receipt"][1]
            snapshot = data["snapshot"]
            assert snapshot["content_hash"] == summary["receipt"][0]
            payloads = [block["block_entity"] for block in snapshot["relative_blocks"] if "block_entity" in block]
            assert payloads == [{"adapter": FIXTURE + ":cargo_inventory", "data": {"payload_version": 1, "data": {"Items": ITEMS}}}]
            if phase in ("provider-skipped", "mod-uninstalled"):
                assert len(journal["transactions"]) == 1
                entry = journal["transactions"][0]
                assert entry["snapshot"] == snapshot and entry["phase"] == "EXTRACTING" and entry["progress"] == 4
                assert entry["transaction_id"] == data["assembly_transaction_id"] and entry["owner_id"] == data["owner_id"]
                if staged is None:
                    staged = journal
                assert journal == staged
            else:
                assert journal["transactions"] == []
        observations.append({"phase": phase, "exit_code": cycle["exit_code"], "mods": mods,
                             "loaded_sources": loaded_sources, "logs": log_reports,
                             "rocket_count": len(rockets), "cargo_block_entity_count": len(cargo),
                             "journal_count": len(journal["transactions"]), "blocks": observed_blocks})
    try:
        connection = socket.create_connection(("127.0.0.1", summary["port"]), timeout=1)
    except OSError:
        pass
    else:
        connection.close()
        raise AssertionError("Owned server endpoint remains open")
    with (BASE / "independent-observations.json").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"phases": observations, "port_closed": summary["port"],
                                "scope": "Six short clean processes; synthetic staged journal, no forced crash"}, indent=2, sort_keys=True) + "\n")
    print("PASS: six raw-disk authority/inventory/journal checks, actual JAR sources, full log audit, artifact hashes and closed port")


if __name__ == "__main__":
    main()
