"""Collect a slice run: JUnit XML and summary, GameTest log, hashes of every implementation file changed since the
slice base (the slice spans several commits), artifact hashes, and a class-by-class API classifier comparison with
the baseline's classifier."""
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
E = Path(__file__).resolve().parent.parent
sha = lambda b: hashlib.sha256(b).hexdigest()

base = (E / 'base-commit.txt').read_text().strip()
junit = E / 'full-junit'
junit.mkdir()
tests = failures = errors = skipped = suites = 0
for f in sorted((ROOT / 'build/test-results/test').glob('*.xml')):
    shutil.copyfile(f, junit / f.name)
    r = ET.parse(f).getroot()
    suites += 1
    tests += int(r.get('tests')); failures += int(r.get('failures')); errors += int(r.get('errors'))
    skipped += int(r.get('skipped'))
summary = {'suites': suites, 'tests': tests, 'failures': failures, 'errors': errors, 'skipped': skipped}
(E / 'junit-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

changed = subprocess.check_output(['git', 'diff', '--name-only', base, 'HEAD'], cwd=ROOT).decode().splitlines()
files = {}
for path in changed:
    if path.startswith('docs/') or path.startswith('AdvancedRocketry-Community-v1plus-Development-Docs/'):
        continue
    if (ROOT / path).is_file():
        files[path] = sha((ROOT / path).read_bytes())
(E / 'implementation-files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
(E / 'post-run-changes.json').write_text('{"files": []}\n', encoding='utf-8')

artifacts = []
for jar in sorted((ROOT / 'build/libs').glob('*.jar')):
    artifacts.append({'name': jar.name, 'bytes': jar.stat().st_size, 'sha256': sha(jar.read_bytes())})
(E / 'artifacts.json').write_text(json.dumps({'artifacts': artifacts}, indent=2) + '\n', encoding='utf-8')

for name in ('latest.log', 'debug.log'):
    log = ROOT / 'build/gametest/logs' / name
    if log.exists():
        shutil.copyfile(log, E / ('gametest-' + name))


C11A_ARTIFACTS = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v170-c12-close-790f1077ef4b412891f327373dca6226/artifacts.json')
previous = {a['name']: a for a in json.loads(C11A_ARTIFACTS.read_text())['artifacts']}
api = next(a for a in artifacts if a['name'].endswith('-api.jar'))
result = {'comparison': 'API jar against the C12 review evidence run (10d9b12)', 'previous_sha256': previous[api['name']]['sha256'],
          'current_sha256': api['sha256'], 'identical': previous[api['name']]['sha256'] == api['sha256']}
(E / 'api-jar-comparison.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(summary, len(files), 'implementation files', [a['name'] for a in artifacts])
print('api jar identical to the C12 close:', result['identical'])
