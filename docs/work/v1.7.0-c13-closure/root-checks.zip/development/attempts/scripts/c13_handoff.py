"""C13: write docs/releases/v1.7.0 development-artifacts.json, evidence-index.json and checksums.txt.

Usage: c13_handoff.py <evidence dir> <parent commit> [--checksums]
Without --checksums: verifies every earlier v1.7 packet's SHA256SUMS and writes the two JSON indexes.
With --checksums: writes checksums.txt over the handoff directory (run last).
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('D:/GitHub/AdvancedRocketry-Community')
OUT = ROOT / 'docs/releases/v1.7.0'
E = Path(sys.argv[1])
PARENT = sys.argv[2]
CLOSURE = 'v1.7.0-c13-closure'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')


if '--checksums' in sys.argv:
    paths = sorted((p for p in OUT.iterdir() if p.is_file() and p.name != 'checksums.txt'), key=lambda p: p.name)
    (OUT / 'checksums.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in paths),
                                       encoding='ascii', newline='\n')
    print('checksums:', len(paths))
    sys.exit(0)

artifacts = json.loads((E / 'artifacts.json').read_text())['artifacts']
for row in artifacts:
    assert sha((ROOT / 'build/libs' / row['name']).read_bytes()) == row['sha256'], row['name']
native = []
for run in ('native', 'refload'):
    inputs = E / run / 'inputs.json'
    if inputs.exists():
        for row in json.loads(inputs.read_text(encoding='utf-8'))['artifacts']:
            native.append({'run': run, **{k: row[k] for k in ('name', 'sha256', 'version')}})
write('development-artifacts.json', {
    'schema_version': 1,
    'build': '1.20.1-1.7.0-dev',
    'development_parent_commit': PARENT,
    'candidate_commit': None,
    'artifacts': artifacts,
    'native_inputs': native,
    'scope': ('Bytes built and tested by the C13 closure full run and its native harnesses. Development '
              'artifacts, not a release candidate or a download.'),
})

records, failures = [], []
total_files = total_bytes = 0
for packet in sorted(p for p in (ROOT / 'docs/work').iterdir() if p.is_dir() and p.name.startswith('v1.7.0-')):
    if packet.name == CLOSURE:
        continue
    sums = packet / 'SHA256SUMS.txt'
    if not sums.exists():
        continue
    checked = checked_bytes = 0
    for line in sums.read_text(encoding='ascii').splitlines():
        digest, name = line.split('  ', 1)
        data = (packet / name).read_bytes()
        if sha(data) != digest:
            failures.append(f'{packet.name}/{name}')
        checked += 1
        checked_bytes += len(data)
    report = packet / 'VERIFICATION.md'
    raw = sums.read_bytes()
    records.append({
        'packet': packet.relative_to(ROOT).as_posix(),
        'manifest': {'path': sums.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)},
        'report': ({'path': report.relative_to(ROOT).as_posix(), 'bytes': len(report.read_bytes()),
                    'sha256': sha(report.read_bytes())} if report.exists() else None),
        'files_checked': checked,
        'bytes_checked': checked_bytes,
        'artifact_scope': 'historical artifact of that slice',
    })
    total_files += checked
    total_bytes += checked_bytes
assert not failures, failures
write('evidence-index.json', {
    'schema_version': 1,
    'development_parent_commit': PARENT,
    'candidate_commit': None,
    'records': records,
    'manifest_count': len(records),
    'manifest_files_checked': total_files,
    'manifest_bytes_checked': total_bytes,
    'manifest_failures': failures,
    'not_indexed': {'packet': 'docs/work/' + CLOSURE,
                    'reason': ('Committed with this handoff. Its source-identity.json and SHA256SUMS.txt bind '
                               'this directory, so indexing it here would be circular.')},
    'scope': ('Verifies each earlier v1.7 packet against its own SHA256SUMS. It does not relabel '
              'historical runs as tests of the current artifacts.'),
})
print('packets:', len(records), 'files:', total_files, 'bytes:', total_bytes)
