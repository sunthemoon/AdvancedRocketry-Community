"""C13 native performance evidence for v1.7: the ADR-054 section 7 endgame reference load on a COPY of the v1.6 world.

One dedicated-server process (no real clients; release-test players with embedded connections, ticked as
connected players):
  1. build the reference load (refload build), save, and let it stand for 11 minutes with nothing driven. The idle
     window is read twice: cold, from the first 1,200 ticks after the build, and warm, from the last 1,200 ticks
     (the once-per-tick code is compiled by then, as on a long-running server); the budget is judged on the warm one;
  2. drive it (refload drive on): drills and fields started through their owners' menus, elevator pairs bound,
     16 railgun launch requests every 20 ticks, 4 rides a minute; wait for the steady state;
  3. sample the 1,200-tick timing window three times, 70 s apart, with the status line and vanilla MSPT.
The flush budget is judged on every flush of the run, the ramp included (review C13-F2): the run's maximum and the
count over 60 ms. Each window also records the mean with the flush time included, the launches that escrowed per
second, the root's size and the drills' states (review C13-F3, F11). The budgets are evaluated and written to
summary.json; a budget miss is reported, not hidden.
"""
import json
import re
import time
from pathlib import Path

import native_v170_check as check

ROOT = Path(__file__).resolve().parent.parent
check.SERVER = ROOT / 'refload-server'
check.OUT = ROOT / 'refload'
PROFILE = ROOT / 'jfr' / 'refload.jfr'
_command = check.support.rocket_smoke._server_command


def _profiled(java):
    """The server command with a Java Flight Recorder profile, written outside the evidence directories."""
    command = list(_command(java))
    # After the heap options: run_phase raises the heap by replacing command[2], which must stay the -Xmx option.
    command.insert(3, f'-XX:StartFlightRecording=filename={PROFILE.as_posix()},settings=profile,dumponexit=true')
    return command


check.support.rocket_smoke._server_command = _profiled
BASE = (9000, 9000)
STEADY_TIMEOUT = 900
IDLE_WARMUP_SECONDS = 660
COLD_IDLE_SECONDS = 62
SAMPLES = 3
BUDGETS = {
    'idle_mean_ms': 0.1,
    'load_mean_ms': 2.0,
    'load_p99_quiet_ms': 8.0,
    'laser_drill': 0.8,
    'ledger': 0.5,
    'black_hole_generator': 0.2,
    'field_lookups': 0.3,
    'rides': 0.2,
    'flush_max_ms': 60.0,
}


def timing(phase, process):
    """The endgame timing window, parsed: totals in ms, each place's mean, P99 and maximum in ms, and the flushes of
    the whole run so far (count, maximum, count over 60 ms)."""
    line = phase.release(process, 'arce endgame release-test timing', 'timing')
    values = check.fields(line)
    places = {}
    key = next(name for name in values if name.startswith('places_'))
    for part in values[key].split(','):
        name, numbers = part.split('=')
        parts = [float(value) / 1000.0 for value in numbers.split('/')]
        places[name] = dict(zip(('mean_ms', 'p99_ms', 'max_ms'), parts))
    mean = float(values['total_mean_us']) / 1000.0
    return {'line': line, 'ticks': int(values['ticks']), 'mean_ms': mean,
            'mean_with_flush_ms': mean + places['flush']['mean_ms'],
            'p99_quiet_ms': float(values['total_p99_quiet_us']) / 1000.0, 'places': places,
            'run_flushes': int(values['flushes']), 'run_flush_max_ms': float(values['max_ms']),
            'run_flushes_over_60ms': int(values['over_60ms'])}


def status(phase, process):
    return check.fields(phase.release(process, 'arce endgame release-test refload status', 'refload status'))


def main():
    check.require(not check.OUT.exists() and not check.SERVER.exists(), 'Refusing to overwrite evidence or server')
    frozen = ROOT / 'host-jar' / check.HOST_JAR.name
    frozen.parent.mkdir(exist_ok=True)
    check.shutil.copyfile(check.HOST_JAR, frozen)
    host = check.support.artifact(frozen, check.HOST, '1.20.1-1.7.0-dev')
    consumer = check.support.artifact(check.FIXTURE_JAR, check.support.FIXTURE, '1.0.0')
    check.OUT.mkdir()
    check.SERVER.mkdir()
    PROFILE.parent.mkdir(exist_ok=True)
    inventory = check.fixture.copy_world(check.SOURCE, check.SERVER / 'world')
    check.shutil.copytree(check.HISTORY / 'libraries', check.SERVER / 'libraries')
    port = check.server.allocate_port()
    check.server.write_server_configuration(check.SERVER, port, True)
    check.write_json(check.OUT / 'inputs.json', {'source_world': str(check.SOURCE), 'artifacts': [host, consumer],
                                                 'base': BASE, 'budgets': BUDGETS})
    results = {}

    def actions(phase, process):
        built = check.fields(phase.release(process, f'arce endgame release-test refload build {BASE[0]} {BASE[1]}',
                                           'refload built', 600))
        results['built'] = built
        phase.query(process, 'save-all flush', check.server.SAVE_MARKER, 300)
        # Cold: the first 1,200 ticks after the build (review C13-F11).
        time.sleep(COLD_IDLE_SECONDS)
        results['idle_cold'] = {'timing': timing(phase, process), 'status': status(phase, process)}
        # A long-running server's code is compiled: the once-per-tick methods reach C2 after about 10,000 calls
        # (8 minutes), so the warm idle window is read after 11 minutes of the idle load, its last 1,200 ticks.
        time.sleep(IDLE_WARMUP_SECONDS - COLD_IDLE_SECONDS)
        results['idle_after_seconds'] = IDLE_WARMUP_SECONDS
        results['idle'] = {'timing': timing(phase, process), 'status': status(phase, process)}
        phase.release(process, 'arce endgame release-test refload drive on', 'refload drive')
        began = time.monotonic()
        steady = None
        while time.monotonic() - began < STEADY_TIMEOUT:
            state = status(phase, process)
            results.setdefault('ramp', []).append({'seconds': round(time.monotonic() - began), 'status': state})
            if (int(state['drills_running']) >= 20 and int(state['fields_active']) >= 64
                    and int(state['generators_burning']) >= 16 and int(state['elevators_bound']) >= 8):
                steady = state
                break
            time.sleep(10)
        results['steady'] = steady
        results['steady_after_seconds'] = round(time.monotonic() - began)
        samples = []
        previous = (time.monotonic(), int(status(phase, process)['launches_escrowed']))
        for _ in range(SAMPLES):
            time.sleep(70)
            sample = {'timing': timing(phase, process), 'status': status(phase, process)}
            now, escrowed = time.monotonic(), int(sample['status']['launches_escrowed'])
            sample['launches_escrowed_per_second'] = round((escrowed - previous[1]) / (now - previous[0]), 2)
            previous = (now, escrowed)
            samples.append(sample)
        results['samples'] = samples
        phase.release(process, 'arce endgame release-test refload drive off', 'refload drive')

    receipt = check.run_phase(check.Phase('refload', [host, consumer], allowed=(r'Can\'t keep up',)), port, actions)
    worst = {
        'load_mean_ms': max(s['timing']['mean_ms'] for s in results['samples']),
        'load_p99_quiet_ms': max(s['timing']['p99_quiet_ms'] for s in results['samples']),
    }
    for place in ('laser_drill', 'ledger', 'black_hole_generator', 'field_lookups', 'rides'):
        worst[place] = max(s['timing']['places'][place]['mean_ms'] for s in results['samples'])
    worst['idle_mean_ms'] = results['idle']['timing']['mean_ms']
    # Every flush of the run counts, the ramp included: the last sample's run-wide maximum (review C13-F2).
    last = results['samples'][-1]['timing']
    results['flush_max_in_load_windows_ms'] = max(s['timing']['places']['flush']['max_ms'] for s in results['samples'])
    results['flushes'] = {'count': last['run_flushes'], 'max_ms': last['run_flush_max_ms'],
                          'over_60ms': last['run_flushes_over_60ms']}
    worst['flush_max_ms'] = last['run_flush_max_ms']
    results['load_mean_with_flush_ms'] = max(s['timing']['mean_with_flush_ms'] for s in results['samples'])
    results['idle_cold_mean_ms'] = results['idle_cold']['timing']['mean_ms']
    results['launches_escrowed_per_second'] = [s['launches_escrowed_per_second'] for s in results['samples']]
    results['root_per_window'] = [{key: s['status'][key] for key in ('root_records', 'root_endpoints',
                                                                     'root_tombstones', 'accounted_bytes')}
                                  for s in results['samples']]
    results['drill_codes_per_window'] = [s['status']['drill_codes'] for s in results['samples']]
    verdicts = {name: {'measured_ms': round(worst[name], 4), 'budget_ms': limit, 'within': worst[name] <= limit}
                for name, limit in BUDGETS.items()}
    check.require(check.fixture.inventory(check.SOURCE) == inventory, 'The source world was changed')
    summary = {'result': 'PASS' if results['steady'] and all(v['within'] for v in verdicts.values()) else 'REVIEW',
               'steady_state_reached': results['steady'] is not None, 'verdicts': verdicts, 'results': results,
               'receipt': receipt, 'source_world_unchanged': True,
               'note': 'Windows development host; provisional numbers (ADR-054 section 7). Reference hardware is [H].'}
    check.write_json(check.OUT / 'summary.json', summary)
    print(summary['result'], json.dumps(verdicts))


if __name__ == '__main__':
    main()
