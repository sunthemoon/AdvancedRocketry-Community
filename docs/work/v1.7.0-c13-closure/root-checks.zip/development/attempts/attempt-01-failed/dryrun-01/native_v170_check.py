"""C13 native evidence for v1.7 (ADR-054 section 11 with a railgun pair) on a COPY of the retained v1.6 world.

Phases, each a finite dedicated-server process:
  upgrade   the v1.7 host opens the v1.6 world: no endgame file before the first endgame change, the satellite
            registry intact; flush timings of synthetic endgame roots (reference and accounted maximum).
  setup     a railgun pair (two chunks, forced) is built and registered through release-test hooks; a payload is
            put into the source; everything is saved.
  cut-N / verify-N   ADR-054 section 11 crash cuts. Each cut phase turns saves off, launches, waits for one ledger
            state, persists only what the cut names (nothing, the chunks, or the root), and halts the JVM (exit 75).
            What reached the disk is read back before the next start. The next phase lets the transfer finish
            (saves driven by save-all) and checks the cargo exists exactly once: in the source's input or in the
            destination's receive buffer, never both, never twice, and the ledger empty.
  final     restart: nothing forced beyond the fixture, totals unchanged, endgame timing sampled.

No real clients. The source world is verified unchanged at the end.
"""
import gzip
import hashlib
import json
import re
import shutil
import sys
import time
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402
import inspect_celestial_saved_data as nbt  # noqa: E402

nbt.MAX_TAGS = 2_000_000
nbt.MAX_COLLECTION_ENTRIES = 65_536
support, server = fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json

ROOT = Path(__file__).resolve().parent.parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v160-c9-1d4b262cc75c4042b9945eebde09cd04'
               '/attempt-04/native-server')
SOURCE = HISTORY / 'world'
FIXTURE_JAR = HISTORY / 'mods/arce-adapter-compat-test-1.0.0.jar'
HOST_JAR = REPO / 'build/libs/advancedrocketry-community-1.20.1-1.7.0-dev.jar'
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
HOST = 'advancedrocketrycommunity'
ENDGAME = HOST + '_endgame.dat'
SERVER = ROOT / 'native-server'
OUT = ROOT / 'native'
HALT = 75
OWNER = 'a7c0ffee-0000-4000-8000-000000000017'
SOURCE_POS = (8192, 120, 8192)
DEST_POS = (8192, 120, 8216)
PAYLOAD = 5
RELEASE = re.compile(r'ARCE_RELEASE_TEST (.*)$')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_endgame(world):
    path = world / 'data' / ENDGAME
    if not path.exists():
        return None
    with gzip.open(path, 'rb') as stream:
        payload = stream.read(8 * 1024 ** 2 + 1)
    root = nbt.NbtReader(payload).read_root()
    data = root['data']
    return {'save_epoch': data.get('save_epoch'), 'endpoints': len(data.get('endpoints', [])),
            'transits': [{'seq': record.get('seq'), 'state': record.get('state'), 'acknowledged':
                          record.get('acknowledged')} for record in data.get('transits', [])]}


class Phase:
    def __init__(self, name, artifacts, expect_halt=False, allowed=()):
        self.name, self.artifacts, self.expect_halt, self.allowed = name, artifacts, expect_halt, list(allowed)
        self.directory = OUT / name
        self.commands, self.observations = [], {}

    def query(self, process, text, pattern, timeout=60):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern if hasattr(pattern, 'search') else re.compile(pattern),
                                              timeout, start_at=start)].rstrip()

    def release(self, process, text, prefix, timeout=120):
        line = self.query(process, text, re.compile(r'ARCE_RELEASE_TEST ' + re.escape(prefix)), timeout)
        return RELEASE.search(line).group(1)


def fields(text):
    return dict(part.split('=', 1) for part in text.split() if '=' in part)


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    command[2] = '-Xmx2G'
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    started = time.monotonic()
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 300)
        receipt['startup_seconds'] = round(time.monotonic() - started, 1)
        write_json(phase.directory / 'status.json', server.wait_for_status(port))
        actions(phase, process)
        if phase.expect_halt:
            code = process.finish(120)
            require(code == HALT, f'Expected the crash-cut halt ({HALT}), got {code}')
        else:
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
            phase.commands.append('stop')
            process.command('stop')
            code = process.finish(180)
            require(code == 0, 'Server did not stop cleanly')
        findings = server.scan_log(process.lines)
        unexpected = [line for line in findings if not any(re.search(p, line) for p in phase.allowed)]
        require(not unexpected, 'Unexpected log findings: ' + json.dumps(unexpected[:10]))
        receipt.update(result='PASS', exit_code=code, log_counts=server.log_audit_counts(process.lines),
                       findings=findings, observations=phase.observations,
                       endgame_lines=[l.rstrip() for l in process.lines if 'ARCE_ENDGAME' in l][-400:],
                       release_lines=[l.rstrip() for l in process.lines if 'ARCE_RELEASE_TEST' in l])
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def pos(position):
    return ' '.join(str(value) for value in position)


def endpoint(phase, process, position):
    return fields(phase.release(process, f'arce endgame release-test endpoint {pos(position)}', 'endpoint'))


def ledger(phase, process):
    return phase.release(process, 'arce endgame release-test ledger', 'ledger')


def wait_until(phase, process, check, label, timeout=150, save=False, interval=0.5):
    began, last = time.monotonic(), None
    while time.monotonic() - began < timeout:
        if save:
            phase.query(process, 'save-all', server.SAVE_MARKER, 60)
        last = check()
        if last:
            return last
        time.sleep(interval)
    raise AssertionError(f'{phase.name}: timed out waiting for {label}')


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    host = support.artifact(HOST_JAR, HOST, '1.20.1-1.7.0-dev')
    consumer = support.artifact(FIXTURE_JAR, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    shutil.copytree(HISTORY / 'libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    write_json(OUT / 'inputs.json', {'source_world': str(SOURCE), 'artifacts': [host, consumer], 'owner': OWNER,
                                     'source': SOURCE_POS, 'destination': DEST_POS, 'payload': PAYLOAD})
    world = SERVER / 'world'
    receipts, results = [], {'cuts': {}}
    expected = {'delivered': 0}

    # 1. upgrade: the v1.6 world opens; nothing endgame is written before an endgame change.
    def upgrade_actions(phase, process):
        results['forced_baseline'] = phase.query(process, 'forceload query', r'(No chunks were|force loaded)',
                                                 30).split(']: ', 1)[-1]
        phase.observations['status'] = phase.query(process, 'arce endgame status', r'endgame ', 30)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        require(read_endgame(world) is None, 'An endgame file was written before any endgame change')
        phase.observations['satellite'] = phase.query(process, 'arce satellite admin diagnostics',
                                                      r'ARCE_SATELLITE_DIAGNOSTICS ', 30)
        phase.observations['flush_reference'] = phase.release(
            process, 'arce endgame release-test flushbench 1024 1024 256 8 10', 'flushbench', 300)
        phase.observations['flush_accounted_maximum'] = phase.release(
            process, 'arce endgame release-test flushbench 2048 8192 256 1024 10', 'flushbench', 600)

    receipts.append(run_phase(Phase('upgrade', [host, consumer]), port, upgrade_actions))
    results['upgrade'] = receipts[-1]['observations']

    # 2. setup: the pair, registered and durable, with a payload in the source.
    def setup_actions(phase, process):
        for position in (SOURCE_POS, DEST_POS):
            phase.query(process, f'forceload add {position[0]} {position[2]}', r'(Marked chunk|force loaded)', 30)
        built = fields(phase.release(process, f'arce endgame release-test railguns {pos(SOURCE_POS)} {OWNER}',
                                     'railguns', 60))
        results['pair'] = built
        wait_until(phase, process, lambda: endpoint(phase, process, SOURCE_POS)['status'] == 'OK'
                   and endpoint(phase, process, DEST_POS)['status'] == 'OK', 'registration', save=True)
        phase.release(process, 'arce endgame release-test persist root', 'persist root')
        phase.release(process, f'arce endgame release-test fill {pos(SOURCE_POS)} minecraft:diamond {PAYLOAD}', 'fill')
        phase.observations['source'] = endpoint(phase, process, SOURCE_POS)

    receipts.append(run_phase(Phase('setup', [host, consumer]), port, setup_actions))
    results['setup_root'] = read_endgame(world)

    def launch(phase, process):
        phase.query(process, 'save-off', r'(Automatic saving is now disabled|Saving is already turned off)', 30)
        phase.release(process, f'arce endgame release-test launch {pos(SOURCE_POS)}', 'launch requested')

    cuts = {
        # name: (wait condition, persist, delivered after verify)
        'escrow-unsaved': ('outbox', None, False),
        'escrow-saved': ('outbox', 'chunks', True),
        'registered-unflushed': ('record', None, True),
        'registered-flushed': ('record', 'root', True),
        'claimed-unsaved': ('incoming', None, True),
        'claimed-root-saved': ('incoming', 'root', True),
        'claimed-chunk-saved': ('incoming', 'chunks', True),
        'moved-unflushed': ('moved', None, True),
    }

    def cut_actions(name):
        condition, persist, _ = cuts[name]

        def actions(phase, process):
            before = endpoint(phase, process, DEST_POS)
            launch(phase, process)
            wait_until(phase, process, lambda: endpoint(phase, process, SOURCE_POS)['outbox'] != '[]', 'escrow')
            if condition in ('record', 'incoming', 'moved'):
                # The saved entry registers once the save's observation is 40 ticks old.
                phase.release(process, 'arce endgame release-test persist chunks', 'persist chunks')
                wait_until(phase, process, lambda: 'records=1' in ledger(phase, process), 'registration')
            if condition in ('incoming', 'moved'):
                # A durable record travels and is claimed into incoming.
                phase.release(process, 'arce endgame release-test persist root', 'persist root')
                wait_until(phase, process, lambda: endpoint(phase, process, DEST_POS)['incoming'] == '1', 'claim')
            if condition == 'moved':
                # A save shows the incoming payload; 40 ticks later it moves and the claim is acknowledged.
                phase.release(process, 'arce endgame release-test persist chunks', 'persist chunks')
                wait_until(phase, process, lambda: int(endpoint(phase, process, DEST_POS)['receive'])
                           > int(before['receive']), 'the move', timeout=60)
            if persist:
                phase.release(process, f'arce endgame release-test persist {persist}', f'persist {persist}')
            phase.observations['at_halt'] = {'source': endpoint(phase, process, SOURCE_POS),
                                             'destination': endpoint(phase, process, DEST_POS),
                                             'ledger': ledger(phase, process)}
            phase.commands.append('arce endgame release-test halt')
            process.command('arce endgame release-test halt')
        return actions

    def verify(name):
        def actions(phase, process):
            delivered = cuts[name][2]
            if delivered:
                expected['delivered'] += 1
            want = expected['delivered'] * PAYLOAD
            phase.observations['after_restart'] = {'source': endpoint(phase, process, SOURCE_POS),
                                                   'destination': endpoint(phase, process, DEST_POS),
                                                   'ledger': ledger(phase, process)}

            def settled():
                source = endpoint(phase, process, SOURCE_POS)
                destination = endpoint(phase, process, DEST_POS)
                quiet = 'records=0' in ledger(phase, process) and source['outbox'] == '[]'                     and destination['incoming'] == '0' and destination['receipts'] == '0'
                return (source, destination) if quiet and int(destination['receive']) >= want else None

            source, destination = wait_until(phase, process, settled, f'{name} settling', timeout=240, save=True,
                                             interval=2.0)
            require(int(destination['receive']) == want, f'{name}: the destination holds {destination["receive"]},'
                    f' expected {want}')
            require(int(source['input']) == (0 if delivered else PAYLOAD),
                    f'{name}: the source input holds {source["input"]}')
            results['cuts'][name] = {'delivered': delivered, 'destination_receive': int(destination['receive']),
                                     'source_input': int(source['input']), 'ledger': ledger(phase, process),
                                     'after_restart': phase.observations['after_restart']}
            if delivered:
                phase.release(process, f'arce endgame release-test fill {pos(SOURCE_POS)} minecraft:diamond '
                                       f'{PAYLOAD}', 'fill')
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        return actions

    names = list(cuts)
    for index, name in enumerate(names):
        receipts.append(run_phase(Phase('cut-' + name, [host, consumer], expect_halt=True), port, cut_actions(name)))
        results['cuts_on_disk'] = results.get('cuts_on_disk', {})
        results['cuts_on_disk'][name] = read_endgame(world)
        receipts.append(run_phase(Phase('verify-' + name, [host, consumer]), port, verify(name)))

    # 3. final: a clean restart; the fixture's forced chunks only; timing sampled.
    def final_actions(phase, process):
        phase.observations['forceload_query'] = phase.query(process, 'forceload query',
                                                            r'(No chunks were|force loaded)', 30).split(']: ', 1)[-1]
        phase.observations['destination'] = endpoint(phase, process, DEST_POS)
        require(int(phase.observations['destination']['receive']) == expected['delivered'] * PAYLOAD,
                'The final restart changed the delivered total')
        phase.observations['ledger'] = ledger(phase, process)
        time.sleep(65)
        phase.observations['timing'] = phase.release(process, 'arce endgame release-test timing', 'timing')
        phase.observations['status'] = phase.query(process, 'arce endgame status', r'endgame ', 30)

    receipts.append(run_phase(Phase('final', [host, consumer]), port, final_actions))
    results['final'] = receipts[-1]['observations']
    results['final_root'] = read_endgame(world)
    require(fixture.inventory(SOURCE) == source_inventory, 'The source world was changed')
    write_json(OUT / 'summary.json', {'result': 'PASS', 'source_world_unchanged': True, 'results': results,
                                      'cycles': receipts})
    print('PASS: v1.7 native upgrade, flush benchmark, eight ledger crash cuts with a railgun pair, final restart')


if __name__ == '__main__':
    main()
