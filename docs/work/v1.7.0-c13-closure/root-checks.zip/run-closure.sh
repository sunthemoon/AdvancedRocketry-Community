#!/usr/bin/env bash
# C13 closure run: Gradle full run, test rerun, collection, native check, reference load. Sequential, alone on the host.
C=/c/Users/Administrator/AppData/Local/Temp/arce-v170-c13-close2-d5991756c4e14bd0ace46b7af9dd39ee
cd /d/GitHub/AdvancedRocketry-Community || exit 1
export JAVA_HOME="C:/Program Files/Java/jdk-17.0.7"
git rev-parse HEAD > $C/run-commit.txt
git status --porcelain > $C/pre-run-status.txt
./gradlew --offline clean build test runData runGameTestServer > $C/root-gradle-01.log 2>&1
echo $? > $C/root-gradle-01.exit
git status --porcelain -- src/generated > $C/generated-status.txt
git diff --stat > $C/post-gradle-diff.txt
./gradlew --offline test --rerun > $C/root-gradle-02.log 2>&1
echo $? > $C/root-gradle-02.exit
if [ "$(cat $C/root-gradle-01.exit)" != "0" ] || [ "$(cat $C/root-gradle-02.exit)" != "0" ]; then echo GRADLE_FAILED > $C/closure.status; exit 1; fi
python $C/scripts/collect_run.py > $C/collect.log 2>&1 || { echo COLLECT_FAILED > $C/closure.status; exit 1; }
cd $C
python scripts/native_v170_check.py > native-harness.log 2>&1
echo $? > native-harness.exit
python scripts/native_v170_refload.py > refload-harness.log 2>&1
echo $? > refload-harness.exit
echo DONE > $C/closure.status
