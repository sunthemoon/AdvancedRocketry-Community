package io.github.sunthemoon.advancedrocketrycommunity.endgame.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSettings;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSystem;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.OutboxEntry;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitDestinationState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitEndpoint;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitKey;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitLimits;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitPayload;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitSourceState;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Review probe (C13, commit 8687d9d0): an idle loaded endpoint that a new record names is re-evaluated only in a
 * sweep tick, and a sweep tick stops where the reconciliation budget runs out. Two hubs that spend the whole budget
 * without changing the table (full receive buffers) make the round-robin cursor alternate between them; every sweep
 * then starts at the same cursor parity, so an idle endpoint between them in ID order never gets its claim, although
 * its record arrived. Before 8687d9d0 the endpoint was visited every second tick. This probe PASSES when the defect
 * is present.
 */
final class ReviewC13IdleSweepProbeTest {
    private static final String TYPE = "advancedrocketrycommunity:railgun";
    private static final ResourceLocation KIND = ResourceLocation.tryBuild("advancedrocketrycommunity", "railgun");
    private static final ResourceLocation LEVEL = ResourceLocation.tryBuild("minecraft", "overworld");
    private static final UUID OWNER = new UUID(1L, 1L);
    private static final UUID HUB_A = new UUID(0L, 0x10L);
    private static final UUID IDLE = new UUID(0L, 0x20L);
    private static final UUID HUB_B = new UUID(0L, 0x30L);
    private static final UUID SOURCE_A = new UUID(0L, 0x101L);
    private static final UUID SOURCE_B = new UUID(0L, 0x102L);
    private static final UUID SOURCE_X = new UUID(0L, 0x103L);

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    private static final class Endpoint implements TransitEndpoint {
        final UUID id;
        final boolean full;
        final TransitSourceState source = new TransitSourceState();
        final TransitDestinationState destination = new TransitDestinationState();

        Endpoint(UUID id, boolean full) {
            this.id = id;
            this.full = full;
        }

        @Override
        public UUID endpointId() {
            return id;
        }

        @Override
        public Optional<UUID> endpointOwner() {
            return Optional.of(OWNER);
        }

        @Override
        public boolean transitFrozen() {
            return false;
        }

        @Override
        public TransitSourceState source() {
            return source;
        }

        @Override
        public TransitDestinationState destination() {
            return destination;
        }

        @Override
        public TransitDestinationState.ReceiveBuffer receiveBuffer() {
            return new TransitDestinationState.ReceiveBuffer() {
                @Override
                public boolean fits(List<List<ItemStack>> payloads) {
                    return !full;
                }

                @Override
                public void insert(List<ItemStack> stacks) {
                }
            };
        }

        @Override
        public void transitChanged() {
        }

        @Override
        public boolean returnToInput(List<ItemStack> stacks) {
            return true;
        }
    }

    private static TransitPayload payload() {
        return TransitPayload.of(List.of(new ItemStack(Items.DIAMOND, 7))).orElseThrow();
    }

    private static void persist(EndgameService service) {
        service.root().orElseThrow().markPersisted();
    }

    /** Ticks from {@code registerAt}'s registration of a record for the idle endpoint until its claim, or -1. */
    private static long claimLatency(long registerAt, int travel) {
        EndgameService service = new EndgameService(() -> EndgameSettings.DEFAULTS, () -> Set.of(TYPE),
                () -> TransitLimits.DEFAULTS);
        service.startForTest(EndgameSavedData.create());
        int x = 0;
        for (UUID id : List.of(HUB_A, IDLE, HUB_B, SOURCE_A, SOURCE_B, SOURCE_X)) {
            long pos = new BlockPos(400 * x++, 64, 0).asLong();
            service.coalesced(root -> root.register(id, KIND, OWNER, LEVEL, pos, false, 2048, 64));
        }
        persist(service);
        for (long seq = 1; seq <= 64; seq++) {
            long s = seq;
            service.coalesced(root -> {
                root.registerTransit(TransitRecord.registered(SOURCE_A, new OutboxEntry(s, HUB_A, payload(), 1, 20,
                        EndgameSystem.RAILGUN), OWNER, root.saveEpoch(), 0L).arrived());
                root.registerTransit(TransitRecord.registered(SOURCE_B, new OutboxEntry(s, HUB_B, payload(), 1, 20,
                        EndgameSystem.RAILGUN), OWNER, root.saveEpoch(), 0L).arrived());
                return null;
            });
        }
        persist(service);
        persist(service);
        Endpoint hubA = new Endpoint(HUB_A, true);
        Endpoint idle = new Endpoint(IDLE, false);
        Endpoint hubB = new Endpoint(HUB_B, true);
        service.transits().attach(hubA);
        service.transits().attach(idle);
        service.transits().attach(hubB);
        TransitKey key = new TransitKey(SOURCE_X, 1L);
        long arriveAt = registerAt + travel;
        for (long now = 100L; now <= registerAt + 600L; now++) {
            if (now == registerAt) {
                // A registration in this tick's ledger pass, as a source's reconcile would make it.
                long at = now;
                service.coalesced(root -> {
                    root.registerTransit(TransitRecord.registered(SOURCE_X, new OutboxEntry(1L, IDLE, payload(), 1,
                            travel, EndgameSystem.RAILGUN), OWNER, root.saveEpoch(), at));
                    return null;
                });
                persist(service);
                persist(service);
            }
            service.tick(now);
            if (idle.destination.incoming().containsKey(key)) {
                return now - arriveAt;
            }
        }
        return -1L;
    }

    @Test
    void anIdleEndpointBetweenTwoBudgetSpendingHubsWaitsLongerThanTheSweepInterval() {
        List<String> results = new ArrayList<>();
        long worst = 0L;
        boolean never = false;
        for (long registerAt : new long[] {300L, 301L}) {
            for (int travel : new int[] {20, 21}) {
                long latency = claimLatency(registerAt, travel);
                results.add("registerAt=" + registerAt + " travel=" + travel + " latency=" + latency);
                never |= latency < 0;
                worst = Math.max(worst, latency);
            }
        }
        System.out.println("REVIEW_PROBE idle-sweep " + results);
        assertTrue(never || worst > 20L, "the idle endpoint always claimed within 20 ticks: " + results);
    }
}
