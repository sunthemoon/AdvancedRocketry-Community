package io.github.sunthemoon.advancedrocketrycommunity.persistence.migration;

import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameRoot;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameRootCodec;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Review probe (C13 flush budget): splits one checked endgame-root flush of the ADR-054 section 7 reference root
 * (the flush benchmark's own synthetic root: 1,024 endpoints, 1,024 tombstones, 256 records, 8 pairs) into its
 * CPU parts (encode, compress, read-back decode, deep compare) and the forced write, on this host. A measurement
 * probe: it prints the medians and asserts only that the run completed.
 */
final class ReviewC13FlushCostProbeTest {
    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    private static EndgameRoot reference(int endpoints, int tombstones, int records, int pairs) throws Exception {
        Class<?> commands = Class.forName(
                "io.github.sunthemoon.advancedrocketrycommunity.endgame.command.EndgameReleaseTestCommands");
        Method synthetic = commands.getDeclaredMethod("synthetic", int.class, int.class, int.class, int.class);
        synthetic.setAccessible(true);
        return (EndgameRoot) synthetic.invoke(null, endpoints, tombstones, records, pairs);
    }

    private static double median(long[] nanos) {
        long[] sorted = nanos.clone();
        Arrays.sort(sorted);
        return sorted[sorted.length / 2] / 1_000_000.0D;
    }

    private static void measure(String name, EndgameRoot root) throws Exception {
        int runs = 25;
        long[] encode = new long[runs];
        long[] compress = new long[runs];
        long[] write = new long[runs];
        long[] force = new long[runs];
        long[] readBack = new long[runs];
        long[] compare = new long[runs];
        long[] fullFlush = new long[runs];
        Path folder = Files.createTempDirectory("arce-c13-review-flush");
        Path scratch = folder.resolve("scratch.dat");
        Path target = folder.resolve(ManagedSavedDataType.ENDGAME.fileName());
        int bytes = 0;
        for (int warm = -10; warm < runs; warm++) {
            long t0 = System.nanoTime();
            CompoundTag outer = new CompoundTag();
            outer.put("data", EndgameRootCodec.encode(root, new CompoundTag()));
            NbtUtils.addCurrentDataVersion(outer);
            long t1 = System.nanoTime();
            byte[] encoded = BoundedSavedDataIo.write(outer, ManagedSavedDataType.ENDGAME);
            long t2 = System.nanoTime();
            long t3;
            long t4;
            try (FileChannel output = FileChannel.open(scratch, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                ByteBuffer buffer = ByteBuffer.wrap(encoded);
                while (buffer.hasRemaining()) {
                    output.write(buffer);
                }
                t3 = System.nanoTime();
                output.force(true);
                t4 = System.nanoTime();
            }
            CompoundTag read = BoundedSavedDataIo.read(scratch, ManagedSavedDataType.ENDGAME);
            long t5 = System.nanoTime();
            boolean same = outer.equals(read);
            long t6 = System.nanoTime();
            CheckedSavedDataFile.replace(target, ManagedSavedDataType.ENDGAME,
                    () -> EndgameRootCodec.encode(root, new CompoundTag()));
            long t7 = System.nanoTime();
            assertTrue(same, "read-back differs");
            bytes = encoded.length;
            if (warm >= 0) {
                encode[warm] = t1 - t0;
                compress[warm] = t2 - t1;
                write[warm] = t3 - t2;
                force[warm] = t4 - t3;
                readBack[warm] = t5 - t4;
                compare[warm] = t6 - t5;
                fullFlush[warm] = t7 - t6;
            }
        }
        System.out.printf(java.util.Locale.ROOT, "REVIEW_PROBE flush-cost %s accounted_bytes=%d file_bytes=%d "
                        + "median_ms encode=%.2f compress=%.2f write=%.2f force=%.2f readback_decode=%.2f compare=%.2f "
                        + "cpu_total=%.2f checked_replace_total=%.2f%n", name, root.accountedBytes(), bytes,
                median(encode), median(compress), median(write), median(force), median(readBack), median(compare),
                median(encode) + median(compress) + median(readBack) + median(compare), median(fullFlush));
        Files.deleteIfExists(scratch);
        Files.deleteIfExists(target);
        Files.deleteIfExists(folder);
    }

    @Test
    void splitTheCheckedFlushOfTheReferenceAndMaximumRoots() throws Exception {
        measure("reference", reference(1024, 1024, 256, 8));
        measure("accounted_maximum", reference(2048, 8192, 256, 1024));
    }
}
