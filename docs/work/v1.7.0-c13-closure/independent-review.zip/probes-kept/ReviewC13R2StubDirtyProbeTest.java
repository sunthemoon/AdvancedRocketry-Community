package io.github.sunthemoon.advancedrocketrycommunity.endgame.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.device.EndgameDeviceTags;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSettings;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSystem;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.OutboxEntry;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitCodec;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitDestinationState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitEndpoint;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitKey;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitLimits;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitPayload;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitSourceState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitTags;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Review probe, round 2 (commit 3b88c0ba): can {@code awaitPruningSave} keep a chunk dirty for good? The ack-flushed
 * crash state (durable acknowledgement at D, D's chunk restored with the payload still incoming and its receipt), but
 * the payload no longer decodes after the restart (an item of a removed mod). The incoming gate freezes it as
 * INCOMING_QUARANTINED; every save of D's chunk then shows the payload held, so the stub is never pruned and the ledger
 * marks D's chunk dirty on every visit until an operator resolves it. The probe also counts the INCOMING_QUARANTINED
 * audit lines, since the incoming loop re-freezes an existing conflict on every pass. PASSES when both happen.
 */
final class ReviewC13R2StubDirtyProbeTest {
    private static final String TYPE = "advancedrocketrycommunity:railgun";
    private static final ResourceLocation KIND = ResourceLocation.tryBuild("advancedrocketrycommunity", "railgun");
    private static final ResourceLocation LEVEL = ResourceLocation.tryBuild("minecraft", "overworld");
    private static final UUID OWNER = new UUID(1L, 1L);
    private static final UUID SOURCE = new UUID(0L, 10L);
    private static final UUID DEST = new UUID(0L, 20L);
    private static final BlockPos SOURCE_POS = new BlockPos(8, 64, 8);
    private static final BlockPos DEST_POS = new BlockPos(200, 64, 200);

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    private static final class Endpoint implements TransitEndpoint {
        final UUID id;
        final TransitSourceState source = new TransitSourceState();
        final TransitDestinationState destination = new TransitDestinationState();
        int changes;

        Endpoint(UUID id) {
            this.id = id;
        }

        @Override
        public UUID endpointId() {
            return id;
        }

        @Override
        public Optional<UUID> endpointOwner() {
            return Optional.of(OWNER);
        }

        @Override
        public boolean transitFrozen() {
            return false;
        }

        @Override
        public TransitSourceState source() {
            return source;
        }

        @Override
        public TransitDestinationState destination() {
            return destination;
        }

        @Override
        public TransitDestinationState.ReceiveBuffer receiveBuffer() {
            return new TransitDestinationState.ReceiveBuffer() {
                @Override
                public boolean fits(List<List<ItemStack>> payloads) {
                    return true;
                }

                @Override
                public void insert(List<ItemStack> stacks) {
                }
            };
        }

        @Override
        public void transitChanged() {
            changes++;
        }

        @Override
        public boolean returnToInput(List<ItemStack> stacks) {
            return true;
        }

        CompoundTag chunkTag(BlockPos pos) {
            CompoundTag section = new CompoundTag();
            source.write(section);
            destination.write(section);
            CompoundTag root = new CompoundTag();
            root.putUUID(EndgameDeviceTags.DEVICE_ID, id);
            root.put(TransitTags.SECTION, section);
            CompoundTag blockEntity = new CompoundTag();
            blockEntity.putString("id", TYPE);
            blockEntity.putInt("x", pos.getX());
            blockEntity.putInt("y", pos.getY());
            blockEntity.putInt("z", pos.getZ());
            blockEntity.put(EndgameDeviceTags.ROOT, root);
            ListTag list = new ListTag();
            list.add(blockEntity);
            CompoundTag chunk = new CompoundTag();
            chunk.put("block_entities", list);
            return chunk;
        }
    }

    private static void persist(EndgameService service) {
        service.root().orElseThrow().markPersisted();
    }

    private static int auditLines(EndgameService service, String action) {
        int count = 0;
        for (int page = 0; page < 64; page++) {
            List<String> lines = service.audit().page(null, page);
            if (lines.isEmpty()) {
                break;
            }
            for (String line : lines) {
                count += line.contains("action=" + action + " ") ? 1 : 0;
            }
        }
        return count;
    }

    @Test
    void anUndecodableAcknowledgedPayloadKeepsItsChunkDirtyAndItsStubForever() {
        EndgameService service = new EndgameService(() -> EndgameSettings.DEFAULTS, () -> Set.of(TYPE),
                () -> TransitLimits.DEFAULTS);
        service.startForTest(EndgameSavedData.create());
        service.coalesced(root -> root.register(SOURCE, KIND, OWNER, LEVEL, SOURCE_POS.asLong(), false, 2048, 64));
        service.coalesced(root -> root.register(DEST, KIND, OWNER, LEVEL, DEST_POS.asLong(), false, 2048, 64));
        persist(service);
        persist(service);
        TransitKey key = new TransitKey(SOURCE, 1L);
        TransitPayload good = TransitPayload.of(List.of(new ItemStack(Items.DIAMOND, 7))).orElseThrow();
        // The ledger as the ack-flushed cut leaves it: claimed at D and acknowledged, durably.
        service.coalesced(root -> {
            root.registerTransit(TransitRecord.registered(SOURCE, new OutboxEntry(1L, DEST, good, 1, 20,
                    EndgameSystem.RAILGUN), OWNER, root.saveEpoch(), 0L).arrived().claimed(DEST)
                    .acknowledged(root.saveEpoch()));
            return null;
        });
        persist(service);
        persist(service);
        // D's chunk as restored: the payload still incoming with its receipt, but its item no longer exists.
        ListTag raw = new ListTag();
        CompoundTag gizmo = new CompoundTag();
        gizmo.putString("id", "removedmod:gizmo");
        gizmo.putByte("Count", (byte) 1);
        raw.add(gizmo);
        TransitPayload undecodable = TransitPayload.raw(raw);
        CompoundTag section = new CompoundTag();
        ListTag incoming = new ListTag();
        incoming.add(TransitCodec.encodeIncoming(key, undecodable));
        ListTag receipts = new ListTag();
        receipts.add(TransitCodec.encodeKey(key));
        section.put("incoming", incoming);
        section.put("receipts", receipts);
        section.put("conflicts", new ListTag());
        Endpoint dest = new Endpoint(DEST);
        dest.destination.read(section);
        service.transits().attach(dest);
        long chunk = new ChunkPos(DEST_POS).toLong();
        int changesFrom300 = 0;
        for (long now = 100L; now <= 1100L; now++) {
            if (now % 100 == 0) {
                // A save of D's chunk (eager saves every 5 s): the observation the incoming gate and pruning use.
                service.observe(LEVEL, chunk, dest.chunkTag(DEST_POS), false);
            }
            if (now == 300L) {
                changesFrom300 = dest.changes;
            }
            service.tick(now);
        }
        boolean stubStays = service.root().orElseThrow().transits().record(key).isPresent();
        int dirtied = dest.changes - changesFrom300;
        int quarantined = auditLines(service, "INCOMING_QUARANTINED");
        System.out.println("REVIEW_PROBE stub-dirty stub_present=" + stubStays + " conflicts="
                + dest.destination.conflicts().size() + " incoming=" + dest.destination.incoming().size()
                + " transitChanged_calls_ticks_300_1100=" + dirtied + " incoming_quarantined_audit_lines_in_ring="
                + quarantined + " ring=" + service.audit().ringSize());
        assertTrue(stubStays && dirtied >= 800, "the stub was pruned or the chunk was left clean");
    }
}
