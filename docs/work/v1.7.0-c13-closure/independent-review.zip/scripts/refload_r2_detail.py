import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
print("result:", d.get('result'), "steady:", d.get('steady_state_reached'))
for k, v in d['verdicts'].items():
    print("  verdict", k, v)
r = d['results']
for k in ('idle_cold_mean_ms', 'flushes', 'flush_max_in_load_windows_ms', 'load_mean_with_flush_ms', 'launches_escrowed_per_second', 'root_per_window', 'drill_codes_per_window', 'steady_after_seconds', 'built'):
    print(k, ":", r.get(k))
print("idle timing:", r['idle']['timing']['line'][:400])
print("cold timing:", r['idle_cold']['timing']['line'][:400])
for i, s in enumerate(r['samples']):
    print("sample", i, s['timing']['line'][:600])
    print("   status:", s['status'])
