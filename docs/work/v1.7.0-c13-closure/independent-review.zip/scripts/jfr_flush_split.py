import sys, collections, subprocess
JFR = r"C:/Program Files/Java/jdk-17.0.7/bin/jfr.exe"
path = sys.argv[1]
proc = subprocess.Popen([JFR, "print", "--events", "jdk.ExecutionSample,jdk.NativeMethodSample", "--stack-depth", "64", path],
                        stdout=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
KEYS = [("force", "FileChannelImpl.force"), ("readback", "BoundedSavedDataIo.read"),
        ("compress", "NbtIo.writeCompressed"), ("compress", "BoundedSavedDataIo.write"),
        ("encode", "EndgameRootCodec.encode"), ("compare", "CompoundTag.equals"),
        ("move", "Files.move"), ("stat", "CheckedSavedDataFile.stat"), ("open", "FileChannel.open"), ("writebuf", "FileChannelImpl.write")]
counts = {"jdk.ExecutionSample": collections.Counter(), "jdk.NativeMethodSample": collections.Counter()}
kind = None
frames = []
in_stack = False
def flush_event():
    global frames, kind
    if kind and frames:
        text = "\n".join(frames)
        if "CheckedSavedDataFile.replace" in text:
            label = "other"
            # the deepest (top-of-stack) matching key wins: iterate frames from top
            for f in frames:
                hit = None
                for name, key in KEYS:
                    if key in f:
                        hit = name; break
                if hit:
                    label = hit; break
            counts[kind][label] += 1
            counts[kind]["_total"] += 1
    frames = []
for line in proc.stdout:
    s = line.strip()
    if s.startswith("jdk.ExecutionSample {") or s.startswith("jdk.NativeMethodSample {"):
        flush_event()
        kind = s.split()[0]
        in_stack = False
        continue
    if s.startswith("stackTrace = ["):
        in_stack = True
        continue
    if in_stack:
        if s == "]" or s.startswith("]"):
            in_stack = False
        elif s and s != "...":
            frames.append(s)
flush_event()
for k, c in counts.items():
    print(k, dict(c))
