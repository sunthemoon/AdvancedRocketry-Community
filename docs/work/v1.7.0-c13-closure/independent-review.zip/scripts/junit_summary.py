import glob, sys, xml.etree.ElementTree as ET
d = sys.argv[1]
t = f = e = s = 0
files = glob.glob(d + '/**/TEST-*.xml', recursive=True)
fails = []
for p in files:
    r = ET.parse(p).getroot()
    t += int(r.get('tests')); f += int(r.get('failures')); e += int(r.get('errors')); s += int(r.get('skipped'))
    for tc in r.findall('testcase'):
        if tc.find('failure') is not None or tc.find('error') is not None:
            fails.append(tc.get('classname') + '#' + tc.get('name'))
print(f"files={len(files)} tests={t} failures={f} errors={e} skipped={s}")
for x in fails: print("FAIL", x)
