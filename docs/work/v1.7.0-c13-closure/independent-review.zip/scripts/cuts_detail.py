import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
r = d['results']
for name, disk in r['cuts_on_disk'].items():
    print(name, "ON_DISK:", json.dumps(disk))
    cut = r['cuts'][name]
    print("   after_restart:", json.dumps(cut['after_restart'])[:600])
    print("   result: delivered=%s receive=%s input=%s ledger=%s" % (cut['delivered'], cut['destination_receive'], cut['source_input'], cut['ledger']))
for c in d['cycles']:
    if c['phase'].startswith('cut-'):
        print(c['phase'], "at_halt:", json.dumps(c['observations'].get('at_halt'))[:700])
