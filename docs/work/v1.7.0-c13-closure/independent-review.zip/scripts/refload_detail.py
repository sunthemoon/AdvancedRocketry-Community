import json, sys, re, collections
d = json.load(open(sys.argv[1], encoding='utf-8'))
r = d['results']
for k in ('idle_after_seconds','steady_after_seconds','flush_max_in_load_windows_ms'):
    print(k, r.get(k))
print("IDLE timing line:", r['idle']['timing']['line'])
for i, s in enumerate(r['samples']):
    print(f"--- sample {i}")
    print(" status:", s['status'])
    print(" timing:", s['timing']['line'])
for i, s in enumerate(r['ramp']):
    print(f"--- ramp {i}:", s)
print("release_lines:")
for l in d['receipt']['release_lines']:
    print("  ", l[:600])
c = collections.Counter()
for l in d['receipt']['endgame_lines']:
    m = re.search(r'system=(\S+) action=(\S+) result=(\S+)', l)
    if m: c[m.groups()] += 1
print("endgame line counts (first 400 only):", c.most_common())
