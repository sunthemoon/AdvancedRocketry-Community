import re, sys
from datetime import datetime
lines = open(sys.argv[1], encoding='utf-8', errors='replace').read().splitlines()
start, end = sys.argv[2], sys.argv[3]
prev = None
pat = re.compile(r'^\[\d+\w+\d+ (\d\d:\d\d:\d\d\.\d+)\]')
for i, l in enumerate(lines):
    m = pat.match(l)
    if not m: continue
    t = m.group(1)
    if t < start or t > end: continue
    ts = datetime.strptime(t, "%H:%M:%S.%f")
    if prev is not None:
        gap = (ts - prev[0]).total_seconds() * 1000
        if gap > float(sys.argv[4]):
            print(f"gap {gap:.0f} ms before line {i+1}: prev={prev[1][:160]}\n    next={l[:200]}")
    prev = (ts, l)
