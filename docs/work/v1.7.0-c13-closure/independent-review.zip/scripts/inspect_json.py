import json, sys
def walk(o, path="", depth=0, maxdepth=4):
    if depth > maxdepth: return
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, (dict, list)):
                print(f"{path}/{k}: {type(v).__name__}[{len(v)}]")
                walk(v, path + "/" + k, depth + 1, maxdepth)
            else:
                s = repr(v)
                print(f"{path}/{k} = {s[:200]}")
    elif isinstance(o, list):
        if o and isinstance(o[0], (dict, list)):
            walk(o[0], path + "[0]", depth + 1, maxdepth)
        else:
            print(f"{path} sample: {repr(o[:3])[:300]}")
data = json.load(open(sys.argv[1], encoding='utf-8'))
walk(data, maxdepth=int(sys.argv[2]) if len(sys.argv) > 2 else 4)
