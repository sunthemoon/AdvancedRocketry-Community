# v1.7 C13 independent review, round 1

Reviewer: independent read-only reviewer (Claude). Subject: branch `codex/v1.7.0-endgame-systems`, HEAD
`011e81d16b78687087544ba0279c5b03c8e2b88c`, C13 range: `ccc861c0`, `d8a916d4`, `23acc49f`, `aab2cb85`, `83f1b9c4`
and `5fbc4123..011e81d1` (C12 closed at `80fc15a9`). No Gate is passed or claimed by this review.

While this review ran, the author pushed `162a1d08` ("tick the release-test players like connected ones", 13:54),
which touches only `ReleaseTestPlayers`. It is outside this review's base and was not reviewed. From its message, it
addresses F3.1 (players never ticked, so field lookups measured 0). The closure evidence reviewed here predates it, so
F3.1 still applies to that evidence until the reference load is re-run.

The repository was not modified. All work was done on a `git archive 011e81d1` export in
`C:/Users/Administrator/AppData/Local/Temp/arce-v170-c13-review-r1/export/`. A control export of `7c13a933`, the
commit before `8687d9d0`, is in `.../control/`. The untracked development-docs folder and the other worktrees were not
opened.

## 1. What I read

- Every C13 diff, saved per commit in `diffs/`. Full current sources of the following:
  - `TransitLedger`, `TransitTable`, `TransitDestinationState`, `TransitSourceState`, `TransitRules`, `TransitRecord`,
    `TransitKey`, `EndgameIdOrder`;
  - `EndgameService`, `EndgameSavedData`, `AtomicSavedData`, `CheckedSavedDataFile`, `BoundedSavedDataIo`,
    `EndgameTimings`;
  - `EndgameStructure`, `EndgameDevices`, `PatternBlockCache`, `ServerLevelPatternWorldView`,
    `MultiblockPatternCatalogManager`;
  - `BlackHoleGeneratorBlockEntity`, `ElevatorTerminalBlockEntity`, `ElevatorEndpointBlockEntity`, `ElevatorPairs`
    (bind), `ElevatorCargo`, `CargoEndpointBlockEntity`, `RailgunLauncher`;
  - all four release-test hook classes, `ReleaseTestPlayers`, `ReferenceLoadFixture`, `EndgameModule`,
    `EndgameDestructionGameTests`, `EndgameCommands` (status, timing, retire), `TransitOperations` (mutation paths),
    `TransitLedgerTest`, `TransitTableIndexTest`, `PatternBlockCacheTest`, `EndgameModelTest`.
- Contracts: ADR-054 §7, §9.1, §10 (write path), §11 (crash-cut table), §12 and Verification; ADR-057 tick rules;
  ADR-059 §2, §3, §6, §8 and Verification (S2); docs/17 §4 and §7; the implementation log's C13 section; CHANGELOG;
  `docs/ENDGAME-OPERATOR-GUIDE.md`.
- Closure evidence `arce-v170-c13-close-bf619549…`:
  - `junit-summary.json`, `artifacts.json`, `api-jar-comparison.json`, `implementation-files.json`, the Gradle logs;
  - `scripts/native_v170_check.py` and `scripts/native_v170_refload.py`;
  - `native/summary.json` (every cut's on-disk root, at-halt and after-restart state) and `refload/summary.json`;
  - the refload server `latest.log` and `jfr/refload.jfr`.
- Development evidence `arce-v170-c13-7013b313…`: the timing lines of every `refload-attempt-*` and `jfr/refload.jfr`
  (attempt 08).

## 2. What I ran

| # | Command (in my export unless stated) | Exit | Result |
|---|---|---|---|
| 1 | `./gradlew --offline clean build test runData runGameTestServer` (JAVA_HOME jdk-17.0.7) | 0 | BUILD SUCCESSFUL in 4m44s; JUnit 253 suites, **1,367 tests, 0 failures, 0 errors, 0 skipped**; **All 335 required GameTests passed** (fresh GameTest world). `runData`: `src/generated` identical to the archive, apart from the git-ignored `.cache` folder. Log: `gradle-01.log` |
| 2 | `sha256sum build/libs/*.jar` | 0 | main jar `45b5737f…` and API jar `824813cf…` are byte-identical to the closure evidence (`artifacts.json`, `host-jar/`), so the native evidence ran this commit's code |
| 3 | `./gradlew --offline test --tests '*ReviewC13*'` (two probes added in my export, section 6) | 0 | Both probes pass. The idle-sweep probe confirms finding F1. The flush-cost probe is a measurement. Log: `gradle-probe-01.log`; XML in `probes/` |
| 4 | The same idle-sweep probe on the control export `7c13a933` | 1 (expected) | The probe **fails** on the control, as it should: every claim latency is 0–1 ticks, so the defect is absent before `8687d9d0`. Log: `gradle-control-01.log`; XML in `probes/control-7c13a933-…xml` |
| 5 | `jfr print --events jdk.FileForce` on the closure and attempt-08 recordings, and a streaming split of `jdk.ExecutionSample` and `jdk.NativeMethodSample` inside `CheckedSavedDataFile.replace` (`scripts/jfr_flush_split.py`) | 0 | See F2 and F5. Output: `fileforce.txt` |
| 6 | Analysis scripts over the evidence JSON and logs (`scripts/refload_detail.py`, `cuts_detail.py`, `log_gaps.py`, `inspect_json.py`) | 0 | See F3 and F4 |

Bytecode checks (`javap` on the mapped Forge 1.20.1-47.4.10 jar) showed the following:

- `ClientPacketListener.handleUpdateTags` posts `TagsUpdatedEvent` on the client thread, after
  `ensureRunningOnSameThread(…, Minecraft)`.
- `ServerPlayer.tick()` never calls `Player.tick()`. Only `ServerPlayer.doTick()` does, and only
  `ServerGamePacketListenerImpl.tick()` calls `doTick()`. That method in turn runs only from `Connection.tick()`, which
  `ServerConnectionListener` calls for its own `connections` list.
- `PlayerList.placeNewPlayer` never adds a connection to that list.

## 3. Verdict

**Accept with required changes.**

The performance changes are correct with one exception. The index rewrite, the ID order, the box, pattern and
pattern-block caches, the generator's idle re-check and the terminal's placement cadence keep every order and every
safety property, and no item can be lost or duplicated by them. The exception is the idle set of `8687d9d0`. It
weakens the C12R-M1 round-robin guarantee: an idle endpoint that a new record names can wait indefinitely (F1, proven
by probe and control). That needs a fix and a regression test.

The C13 evidence is less sound than the code, and its headline claims overstate it:

- **Flush (F2, F5).** The closure run itself contains a 350 ms flush (a 327 ms `FileChannel.force`). The harness
  dropped it because it reads only the loaded windows, and wrote `flush_max_ms within: true`. The log reports an
  outlier of 116 ms. A typical flush is mostly CPU work on the server thread, not fsync.
- **Reference load (F3).** It does not reach ADR-054 §7. Railgun launches run at about 10% of the specified rate,
  because one owner hits `TRANSIT_LIMIT`. The root has 924 endpoints and about 0.9 MiB, not 1,024 and 1.1 MiB. Field
  lookups never run, because the test players are never ticked.
- **Crash cuts (F4).** The `registered-unflushed` cut never reached its state. The coalesced flush ignores `save-off`,
  so the record was on disk at the halt.

None of this changes the conclusion that G7 stays open. All of it must be corrected before C13 closes.

## 4. Findings

| ID | Severity | Area | Title |
|---|---|---|---|
| F1 | Medium | `TransitLedger` idle set (`8687d9d0`) | A sweep that the reconciliation budget cuts short can starve an idle endpoint forever; the "20-tick sweep / wake on any table change" bound does not hold |
| F2 | High | Evidence: flush budget | The closure run had a 350 ms root flush (327 ms fsync). The harness's flush verdict ignores it (`within: true`, 51.4 ms), and the log reports a 116 ms outlier |
| F3 | Medium | Evidence: reference-load fidelity | Field lookups are never exercised (test players never tick). Railguns run at about 10% of "16 every 20 ticks". The root is short of 1,024 endpoints, 256 records and 1.1 MiB. Physical drills finish in the first window |
| F4 | Medium | Evidence: native crash cuts / S2 | `registered-unflushed` reached the flushed state (coalesced flush runs during `save-off`). Removal and stale-drop rows, an ack-flushed cut and elevator cargo cuts are absent. Ride assertions are partly vacuous |
| F5 | Medium | Evidence: flush attribution | A typical flush is about 60–80% CPU on the server thread, and the mandated read-back decode alone is about 45% of the unloaded reference flush. Only the outliers are fsync-bound |
| F6 | Low | `EndgameModule` / `PatternBlockCache` | The `TagsUpdatedEvent` listener clears the server-thread `HashMap` from the client thread (`CLIENT_PACKET_RECEIVED`) in single-player and LAN hosts |
| F7 | Low | Tests | No tests for the idle set (wake-ups, sweep), the per-catalog pattern cache, the structure box cache, the tag-reload clear or the generator idle re-check |
| F8 | Low | Release-test hooks | The static `CHANNELS` map and the `ReferenceLoadFixture.Load` instance outlive a server in the same JVM (old `ServerLevel`s retained). The keep-alive answering in `pump` is dead code |
| F9 | Low | Terminal placement cache (`a1437a3d`) | "Every action re-derives what it needs at use" is not true. Bind step 2 and `ElevatorCargo.ownState` read the cached `station()` and `placement()`, now up to 20 ticks old (no exploitable path found) |
| F10 | Info | Operator guide | `status` does not show "pending observations" (it shows `loaded_ledger_endpoints`). The guide does not say the root keeps flushing while saves are off |
| F11 | Info | Measurement method | The total excludes coalesced flush time (still within budget if included). The idle window is a warmed state (11 minutes), so a cold window should be reported too. The docs/17 §4 base load is only partly present |
| F12 | Info | Size note | `TransitLedger` grew from 554 to 589 lines. The C12 responsibility note still says 554 |
| F13 | Info | Idle set | A block-entity NBT reload (`/data merge block`, `load()`) while attached changes transit state without waking the endpoint. It waits for the next sweep, and is subsumed by F1's fix |

### F1 (Medium): the idle set can starve an endpoint that a new record names

**Location.** `TransitLedger.reconcileLoaded`, lines 228–277 (`8687d9d0`). The relevant lines are:

```java
boolean sweep = now >= nextIdleSweep || root.transits().version() != sweptVersion;
if (sweep) { nextIdleSweep = now + IDLE_SWEEP_TICKS; sweptVersion = root.transits().version(); }
...
if (!sweep && idle.contains(id)) { cursor = id; continue; }
...
if (reconciliationsLeft <= 0) { return; }
```

**Contract.**

- ADR-054 §7 and §11: reconciliation of the loaded ledger endpoints runs in ID order, round robin. The C12R-M1 fix
  promises that the next tick starts at the next endpoint, so every endpoint gets its turn.
- The commit message and the implementation log say an idle endpoint "is looked at again in a sweep every 20 ticks,
  in the tick after any change to the transit table".

**Failure scenario.** A sweep is only the one tick in which the flag is set, and the loop still returns as soon as the
budget runs out. `nextIdleSweep` and `sweptVersion` advance anyway, so idle endpoints after the cut are not
re-evaluated until a later sweep tick happens to reach them.

Take two destinations, hubs A and B, each with at least 64 arrived records and a full receive buffer (or 64
outstanding receipts). Each spends the whole budget per visit without changing the table, because `land` returns
false after `takeReconciliation`. The cursor then alternates A, B, A, … with period 2. Every 20-tick sweep starts at
the same parity, since 20 is even.

An idle endpoint X lying between them in ID order is visited only in ticks that start after the "right" hub. The
version-triggered sweeps happen at the registration tick + 1 (a source registers during tick T's pass) and at the
arrival tick T + travel. Both fall on the same parity when the travel time is odd. Local railgun travel is
`20 + distance / 64` ticks, clamped to 20..200, so odd travel times are common, for example 21 ticks at 64–127 blocks.
Every later 20-tick sweep then keeps that parity, and X's arrived record is never claimed while the table stays
unchanged. Before `8687d9d0`, X was visited every second tick.

**Probe.** `probes/ReviewC13IdleSweepProbeTest.java`, in package `endgame.service`, with hubs `(0,0x10)` and
`(0,0x30)` and the idle endpoint `(0,0x20)`. At `011e81d1` it prints
`registerAt=300 travel=20 latency=-1`: the claim never happens within 600 ticks of the registration. The other
configurations give 0 to 1 ticks. At `7c13a933` all four latencies are 0 or 1 ticks. The probe passes at HEAD
(defect present) and fails at the control (defect absent).

**Impact.** Liveness only: no loss or duplicate. On a quiet server with two or more stuck hubs, a delivery can wait
until some unrelated table change happens to land on the right parity.

**Suggested fix (any one of these).**

- (a) Wake precisely. Let `TransitTable` report the endpoint IDs each mutation names (destination, paid endpoint and
  source, before and after), and have the ledger drain them from `idle`. Names are the only predicate input the
  table changes, so the version-triggered sweep becomes unnecessary.
- (b) In a sweep tick, after the budget runs out, keep walking the remaining idle endpoints with the O(1) predicate
  only, removing those that now have work.
- (c) Keep the sweep pending across ticks until one full wrap has been evaluated.

In every case, add the probe as a regression test (F7).

### F2 (High): the closure evidence omits a 350 ms flush and marks the flush budget "within"

**Location.** `scripts/native_v170_refload.py`, line 126 (`flush_max = max(s['timing']['places']['flush']['max_ms']
for s in samples)`). The outputs are `refload/summary.json` (`verdicts.flush_max_ms: {budget 60, measured 51.3962,
within: true}`) and the implementation log's C13 section ("42–55 ms under the load, with an outlier of 116 ms").

**Contract.** ADR-054 §7: "One coalesced or barrier flush ≤ 60 ms at the reference root, ≤ 250 ms at the accounted
maximum". The budget is per flush, not per window. AGENTS.md §5 forbids passing a budget by narrowing the
measurement.

**Evidence.**

- The closure run's own timing lines print the cumulative `max_ms`: 33.18 ms at the idle read (13:33:32) and
  **350.12 ms** in every loaded sample. So the flush happened in the ramp between "drive on" and the first window,
  which the harness never reads.
- JFR (`jfr/refload.jfr`) shows `jdk.FileForce` on `advancedrocketrycommunity_endgame.dat.arce-pending` at
  13:33:45.126 lasting **327 ms**. Typical forces take 18–20 ms under load and about 11 ms idle.
- The development runs show the same tail in their cumulative maxima: attempt 01 562 ms, attempt 06 229 ms, attempt 07
  283 ms (in a loaded window), attempt 08 116 ms (91.7 ms fsync). Attempts 06 and 07 were the heap-limited runs.
- 350 ms exceeds even the 250 ms accounted-maximum budget, and the root at that moment was about 0.92 MB accounted.

**Suggested fix.**

- Report the run's cumulative maximum and every flush over budget, ramp included. Better, log each flush's duration
  with its tick.
- Set the verdict to failing.
- Correct the log and headline to "worst 350 ms (327 ms fsync)".
- Feed this into the writer-thread ADR decision.

### F3 (Medium): the reference load does not reach ADR-054 §7

**Locations.** `ReferenceLoadFixture`, `ReleaseTestPlayers`, `ReferenceLoadReleaseTestCommands`, and the log's C13
"Reference load" bullet.

1. **Field lookups are never measured.** The test players join through `placeNewPlayer` with an unregistered
   `Connection`, so nothing ever calls `Connection.tick()`. That means no `ServerGamePacketListenerImpl.tick()`, no
   `ServerPlayer.doTick()` and no `LivingTickEvent`, so `CelestialGravityController.onLivingTick` →
   `EndgameDevices.fieldGravity` never runs. Every window shows `field_lookups=0.0/0.0/0.0`, and the verdict
   `field_lookups 0.0 within` measures nothing.
   - The `ReleaseTestPlayers` Javadoc ("the server treats them as real (… field lookups)") and `e00fa22a`'s "keep-alives
     answered" are wrong. With no tick, no keep-alive is ever sent.
   - Fix: call `player.connection.tick()` (or `player.doTick()`) for each test player in `pump`, then re-measure.
2. **Railgun rate.** "16 railguns launch every 20 ticks" is what the driver *requests*. All 16 pairs belong to one
   owner, so the per-owner transit limit (32 live records plus outbox entries) refuses most launches. The server limit
   adds a second cap: 256 records in all, of which 192 are the synthetic ones, so at most 64 can be live.
   - The closure log has **3,006 `launch result=TRANSIT_LIMIT` against 354 escrows** over about 221 s, which is about
     1.6 launches per second against the 16 per second specified (about 10%).
   - The ledger (0.149 ms against 0.5) and railgun timings were therefore measured at about a tenth of the specified
     traffic.
   - Even with one owner per pair, the persistence gate caps each railgun at about four launches per eager chunk save
     (about 10 s). The specified rate may be unreachable by design. Record the achieved rate and the reason, and use
     one owner per pair to get as close as the gates allow.
3. **Root mass.**
   - `synthetic(152)` subtracts drills, generators and fields, which are not root endpoints. The root holds **924
     endpoints**, not 1,024.
   - Live records add only 7–30 to the 192 synthetic ones, giving **199–222 records**, not 256.
   - The accounted size is 0.92–1.0 MB (0.88–0.95 MiB), not about 1.1 MiB.
   - Fix: subtract only the 52 ledger endpoints and markers, and add synthetic records up to 256.
4. **Physical drills.** The 64-block stone columns are exhausted at about 13:34:40, so `drill_codes={COMPLETE=4,OK=16}`
   holds from sample 0 on. Windows 2 and 3 have no physical drilling. Use deeper columns or reset the markers.
5. The log's "every per-system and total budget at the reference load holds with room" should say which shares were
   measured at reduced load or not at all.

### F4 (Medium): the native crash cuts do not cover what the log claims

**Location.** `scripts/native_v170_check.py` (the `cuts` table and `ride_cut`/`ride_verify`), and the log's "the eight
ADR-054 §11 crash cuts, each … exactly once".

1. **`registered-unflushed` was never unflushed.** `EndgameService.tick` runs the coalesced flush whenever
   `flushPending` and 100 ticks have passed, regardless of `save-off`, so the new record is written about one tick
   after registration. The evidence agrees:
   - at the halt, `ledger … pending=false`;
   - `cuts_on_disk.registered-unflushed.transits = [{seq 2, IN_TRANSIT}]`;
   - after the restart the record exists and the source shows `outbox [2]`.

   That is ADR-054 §11 row "Ledger flushed, release not saved", the same state as `registered-flushed`. The row
   "Registered, ledger not flushed → registered again with the same (S, seq)" has no native coverage. Fix: a
   release-test hook that holds the coalesced flush (for example `persist hold on|off`) so the cut can halt with the
   record only in memory.
2. **Effective coverage is narrower than eight distinct states.** `moved-unflushed` leaves the same disk state as
   `claimed-chunk-saved` (root `IN_TRANSIT`, destination chunk with incoming payload and receipt). Not covered at all:
   - the two removal rows of §11 (endpoint removed, removal unsaved or saved);
   - the two `OUTBOX_STALE_DROPPED` rows;
   - "ack flushed, D's chunk not saved after the move".

   ADR-054 Verification S1/S2 names forced stops "around … release, claim and acknowledgement". The acknowledgement
   side has only the unflushed variant.
3. **ADR-059 S2 cargo.** S2 also asks for "cargo crash cuts as ADR-054 §11" for the elevator. Only a same-Level
   railgun pair was cut, so the elevator's escrow path (`ElevatorCargo`) and the cross-Level delivery (Overworld
   anchor ↔ space terminal) have no native cut.
4. **Ride assertions.**
   - With saves off only the "neither" branch of "either both or neither" can occur.
   - In `ride-countdown` the rider has no player file before or after (`rider_data` null both times), so the rider
     check is vacuous and only the energy check is meaningful.
   - `rides=0 tickets=0` after a JVM halt is trivially true, because both are runtime state.
5. **Cargo energy.** The verify phases do not assert the source's energy (paid FE), although the data agree, for
   example `escrow-unsaved` restores 1,000,000 and `escrow-saved` shows 974,760.
6. **Docstring claims that are not asserted.** The final phase only records "nothing forced beyond the fixture" (7
   forced chunks against a baseline of 4, the extra 3 being the harness's own), and `upgrade` only records "satellite
   registry intact". Neither is asserted.

**Suggested fix.** Add the flush-hold hook and the missing cuts (or record them as unit-only with a reason), add one
elevator cargo cut, assert energy, and correct the log's wording.

### F5 (Medium): flush time is not mainly fsync; the read-back decode is the largest server-thread cost

**Location.** `CheckedSavedDataFile.replace` (pre-C13 code, mandated by ADR-054 §10 as the "replace-and-read-back
path"), and the log's "A JFR native profile puts the time in `FileChannel.force`".

**Probe.** `probes/ReviewC13FlushCostProbeTest.java` runs the flush benchmark's own synthetic roots through the same
code on this host, median of 25 runs after 10 warm-ups (ms):

| Root | encode | compress | write | force | read-back decode | compare | CPU total | full checked replace |
|---|---|---|---|---|---|---|---|---|
| Reference (1,024 / 1,024 / 256 / 8; 1.13 MB accounted; 23.8 KB file) | 3.50 | 7.00 | 0.62 | 3.16 | **14.34** | 0.64 | 25.5 | **31.8** (native benchmark 31.9) |
| Accounted maximum (2,048 / 8,192 / 256 / 1,024 + 256 zones) | 6.97 | 22.28 | 0.67 | 2.70 | **44.76** | 1.57 | 75.6 | **81.3** (native 86.2) |

JFR in the closure run agrees. `FileForce` takes about 11 ms idle and 18–20 ms loaded, against loaded flushes of 42–55
ms. Inside `replace`, Java samples fall into encode 9, compress 6, compare 1 and other 3, and native samples into
force 12, compress 4, read-back 4 and move 2. Attempt 08 shows the same picture, and its 116 ms flush was a 91.7 ms
force.

**Assessment.** The outliers (116, 327 ms) are fsync stalls, so the conclusion that a writer thread is needed stands.
But a typical flush, including the 42–55 ms loaded ones that leave only 5–18 ms of headroom, is 60–80% CPU on the
server thread, and the read-back decode is about 45% (reference) to 55% (maximum).

**Suggested fix.**

- Correct the attribution in the log and evidence.
- In the writer-thread ADR, move encode, compress, read-back and force off the server thread. Alternatively, satisfy
  "read back" by comparing the re-read bytes with the encoded bytes and keep the full decode-and-equality check in
  tests and at load.
- Snapshotting stays on the server thread.

### F6 (Low): the pattern-block cache is cleared from the client thread

**Location.** `EndgameModule.install`:
`MinecraftForge.EVENT_BUS.addListener((TagsUpdatedEvent event) -> devices.patternBlocks().clear());`

**Contract.** The cache's own Javadoc and AGENTS.md: server-thread runtime state.

**Scenario.** In single-player and on a LAN host, the integrated client handles `ClientboundUpdateTagsPacket` on the
render thread (bytecode-verified) and posts `TagsUpdatedEvent` (`CLIENT_PACKET_RECEIVED`). That happens at every join
and after `/reload`. The listener then calls `HashMap.clear()` while the server thread may be in `get` or `put`
(validation every 200 ticks). It is a data race on a non-thread-safe map, with consequences limited to lost or corrupt
cache entries or a wrong `size()` count. The server-side event (`SERVER_DATA_LOAD`) already clears on the server
thread.

**Fix.** Check `event.getUpdateCause() == TagsUpdatedEvent.UpdateCause.SERVER_DATA_LOAD` (or
`!event.shouldUpdateStaticData()`), and add a test.

### F7 (Low): the C13 behaviour changes have no tests of their own

`8687d9d0` ("Unit tests and GameTests pass unchanged"), `21285b29`, `b8957785`, `a1437a3d` and the tag-reload path of
`f0aa6ff6` add behaviour without a test:

- the idle set's wake-ups (attach, observation, escrow admission, table change), its sweep and a budget-cut sweep;
- pattern cache invalidation on a catalog swap;
- the box cache on a facing or definition change;
- the clear on `TagsUpdatedEvent`;
- a generator that becomes ineligible while idle.

F1 shows the gap is real. At least add the F1 regression test and a ledger test that runs consecutive ticks, because
the existing tests jump 20 or more ticks, which forces a sweep every tick.

### F8 (Low): release-test hooks hold state across servers

**`ReleaseTestPlayers.CHANNELS`** is a static `HashMap` of `EmbeddedChannel`s. Through the `Connection` and its
packet listener it reaches the `ServerPlayer` and its `ServerLevel`. Nothing clears it at server stop, and entries go
only when a later server's `pump` finds the player missing.

**`ReferenceLoadReleaseTestCommands`** is created once per mod construction, so its `Load` (`built`, `driving`,
devices holding `ServerLevel` references and menus) survives into the next integrated server. `refload build`
answers "already", and a still-`driving` driver would touch the old Levels.

Both are gated by `-Dadvancedrocketrycommunity.releaseTestHooks=true` and permission 2, so normal play is unaffected.
Nothing else in C13 is reachable without the property: the constructors are trivial and the `register` methods
return at once. AGENTS.md forbids static world state without a lifecycle.

**Fix.** Clear both on `ServerStoppedEvent`. Remove or justify the keep-alive branch (see F3.1).

### F9 (Low): the terminal's 20-tick placement cache is read by actions

**Location.** `ElevatorTerminalBlockEntity.placementReady`, which recomputes `station` and `placement` only every 20
ticks. The commit says "every action re-derives what it needs at use".

**Reality.**

- `ElevatorPairs.bind` takes the station from `terminal.station()` and ADR-059 §3 step 2 from
  `terminal.placement()`.
- `ElevatorCargo.ownState` (launch and menu) returns `endpoint.placement()`.

Both are now up to 20 ticks stale instead of 1. I found no exploit:

- ADR-045 rule 1 is re-derived for the station ID, so a vanished station fails.
- Warp and deletion are refused while bound.
- Regions only grow.

The effect is a bind or launch refused or allowed up to one second late after a station appears or expands. Correct
the commit or log wording, or re-derive placement at bind time; it is one region lookup.

### F10 (Info): operator guide accuracy

These parts match the code:

- the command set, permission levels, limits (2,048 / 64 / 256 / 256 / 32), intervals (10, 2), zone span and allow
  list, the tombstone numbers and `retire`'s chunk-loaded refusal;
- the barrier spacing, the escrow stop at 256 while saves are off, the restore and downgrade warnings, and the
  physical-mode description.

Two differences:

- **`status` contents.** The guide's "the ledger's records, stubs and pending observations" is wrong: `status` prints
  `transits=… stubs=… loaded_ledger_endpoints=…` and `awaiting_registration`.
- **Root writes during backups.** The guide does not say that the endgame root keeps being written every 5 s during
  `save-off`. That is crash-safe (root newer than regions), but useful for backup tooling.

### F11 (Info): measurement method notes

- **Total excludes flush time.** `EndgameTimings.total` leaves out the `FLUSH` place, so "loaded mean 0.47 ms" excludes
  coalesced flushes. Including them, about 0.85 ms, is still within 2.0 ms.
- **Ledger share without index work.** `7c13a933` moves index work out of `LEDGER`. That is defensible, and adds about
  10 µs if counted back.
- **Warm idle window.** The idle window is read after 11 minutes, so that per-tick code is C2-compiled. It is
  disclosed, but the cold idle mean should also be reported.
- **Base load.** ADR-054 §7's "on top of the docs/17 §4 reference load" is only partly present: the base world has
  about 1,000 satellites, but no rockets, oxygen devices or assembly.

### F12 (Info): TransitLedger size note

`TransitLedger` is 589 lines (it was 554). It still has a single responsibility, since the idle set is reconciliation
scheduling, but the recorded size note should be updated.

### F13 (Info): NBT reload while attached

An attached endpoint whose `load()` runs again (`/data merge block`, schematic tools) changes `source` and
`destination` in place without `attach`. It is re-evaluated only at the next sweep. This matters only together with
F1; F1(a) or a `transits().attach(this)` from `readState` would cover it.

## 5. Checked and conforming

- **`EndgameIdOrder` (`b4cdbcaa`).** `UUID.toString()` is the zero-padded lowercase hex of the two halves with dashes
  at fixed places, so `String.compareTo` order is exactly the unsigned order of the most significant half, then of the
  least significant half.
  - Comparator equality agrees with `UUID.equals`.
  - The `TreeMap<UUID>` `loaded` map, the cursor `tailMap`/`headMap` and the `GravityField` tie-break keep the
    previous orders.
  - The 20,000-pair test is sound.
- **`TransitTable` indexes (`5fbc4123`).**
  - `add`, `restore` (index before the bound check, which throws on decode), `replace` (unindex previous then index,
    so destination and paid-endpoint changes, return and stub are correct) and `remove` all keep `byEndpoint`,
    `bySource`, `inTransit` and `acknowledgedWithPayload` consistent.
  - Empty sets are dropped, so `names` matches `record.names`.
  - `due` equals the old filter, sort and limit, because natural `TransitKey` order equals `TransitKey.ORDER`.
  - The root is mutated in place (`EndgameSavedData.update`), so the table instance and its `version` are stable for a
    server's life, and `clear()` resets `sweptVersion`.
  - The property test covers every transition but quarantine, which uses the same path.
- **Idle-set predicate.** For a non-frozen, owned, `ACTIVE` endpoint, "no outbox, no incoming, receipt or conflict, not
  named, no rollback" is exactly the condition under which `reconcile` does nothing.
  - `dispatched_through` changes only through `registerTransit` (a table change) or the eviction of a settled
    tombstone, which is not loaded.
  - Every production escrow (`RailgunLauncher`, `ElevatorCargo`) calls `admitEscrow` before `escrow`.
  - Operator purge, resolve, resettle and retire either change the table or reduce work.
  - Frozen, unowned and inactive endpoints are skipped before the predicate.
  - Detach paths remove from `idle`.
  - Only F1 and F13 escape the wake-ups.
- **Structure box cache (`21285b29`).** The box depends only on the definition (identity, and a new catalog yields new
  instances), the facing, the Level and the controller, all of which are in the condition. Revalidation on dirty and
  every 200 ticks is unchanged. The `consumeDirty` fast path is equivalent.
- **Per-catalog pattern cache (`b8957785`).** It is keyed on the catalog instance, which the manager swaps atomically
  per accepted reload, and keeps the old catalog on reject. It is bounded by the fixed pattern IDs, read only from
  `EndgameStructure.tick` on the server thread, and cleared at server stop.
- **`PatternBlockCache` (`f0aa6ff6`).** A `PatternBlock` is a pure function of the state's block ID, tags and `isAir`
  plus the role, and all of these are in the key. Tags change only through a reload, which posts a server-thread
  `TagsUpdatedEvent` (see F6 for the client-side post). Exceptions are not cached. The cache is bounded at 4,096
  entries and has no client imports.
- **Generator idle re-check (`a1437a3d`).** It is idle only with no burn, no energy and no plain fuel, and fuel or
  energy makes it process at once. ADR-057's per-tick steps apply only to a burning or pushing generator. The only
  effect is that status, release of the active slot and an `ACTIVE_LIMIT` retry are delayed by up to 20 ticks for an
  idle generator. That is test-visible only as status latency, and the GameTests pass.
- **Destruction-bound GameTests (`d8a916d4`) against ADR-054 §9.1.**
  - The endpoint blocks are derived from the observed block-entity types; four types give four blocks.
  - The tests check `wither_immune`, `dragon_immune`, `create:non_movable`, `carryon:block_blacklist`,
    `PushReaction.BLOCK` and resistance of at least 1,200, plus a power-6 blast one block away. That covers TNT (4),
    beds (5), charged creepers and end crystals (6); dangerous wither skulls are handled through `wither_immune`.
  - The generated tag files list the four blocks. `replace` is omitted, so it defaults to false.
  - The `onRemove` settlement is covered by the C12 tests.
- **Release-test hooks.** Every hook is gated by the system property, checked at `RegisterCommandsEvent`, and by
  permission 2. `halt` uses `Runtime.halt`, and `persist chunks` uses `ChunkSource.save(true)`, which waits for the
  IO worker. No `net.minecraft.client` imports appear in C13 code, and I found no bidirectional package dependency.
- **Measurement.**
  - The idle window shows no flush. P99 is taken over non-flush ticks as ADR-054 §7 says.
  - The per-system means use the worst of three windows.
  - The idle fix sequence (0.44 → 0.052 → 0.049 ms) is reproduced in the attempt logs.
  - The flush benchmark numbers (31.9 and 86 ms) are reproduced by my probe (31.8 and 81.3 ms).
- **Native harness exactly-once checks.** The verify phases require all of the following, which detects both loss
  and duplication for the covered states:
  - destination receive equal to the cumulative expected count;
  - source input of 0 or 5;
  - an empty outbox, incoming area and receipts;
  - `records=0`.

  The JVM halt is a real cut. The evidence jar is this commit's jar.
- **Build and suite.** 1,367 JUnit tests and 335 GameTests pass on a fresh export. `runData` is idempotent. The API jar
  is unchanged from the C12 evidence.
- **CHANGELOG.** The entries match the code. "An idle black-hole generator notices new fuel … within one second" is
  conservative, since it notices at once.

## 6. Probe files

- `probes/ReviewC13IdleSweepProbeTest.java`: F1. It passes at `011e81d1` with
  `[300/20: -1, 300/21: 0, 301/20: 0, 301/21: 1]` and fails at `7c13a933` with `[1, 0, 0, 1]`.
- `probes/ReviewC13FlushCostProbeTest.java`: F5 measurement.
- `probes/TEST-*.xml`: the JUnit results, including the control run's.
- `scripts/`: the evidence and JFR analysis scripts.
- `diffs/`: one diff per C13 commit.
- Logs: `gradle-01.log`, `gradle-probe-01.log`, `gradle-control-01.log`, and `fileforce.txt` (closure JFR
  `FileForce` events).
