# v1.7 C13 independent review, round 2

**Subject.** Branch `codex/v1.7.0-endgame-systems` at HEAD `13998d64fdc4b17777e4e41a996855d1594a9f10`. This round covers
the round-1 fixes in `011e81d1..13998d64` (15 commits) and the revised native harnesses outside the repository. No
Gate is passed or claimed.

**Method.**

- The repository was not modified, and no harness was run.
- All builds and probes ran in `C:/Users/Administrator/AppData/Local/Temp/arce-v170-c13-review-r1/`:
  - `export-r2/` holds a `git archive 13998d64` export;
  - `mutant/` holds a copy of that export used for mutation checks;
  - `diffs-r2/` holds one diff per commit;
  - `harness-r2/` holds copies of the revised harness scripts as read.
- I read, but did not run, the harness outputs that existed when I looked:
  - the native shakeout in `arce-v170-c13-7013b313…/native/`, which stopped at `verify-removed-unsaved`;
  - `native-r2-attempt-01-stub-never-pruned/`;
  - `refload-r2-attempt-01-synthetic192/`;
  - `arce-v170-c13-refload-shake2/`, which finished during the review.

## 1. What I ran

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `./gradlew --offline clean build test runData runGameTestServer` in `export-r2` | 0 | BUILD SUCCESSFUL in 6m47s. JUnit: 254 suites, **1,373 tests, 0 failures, 0 errors, 0 skipped**. **All 337 required GameTests passed** (fresh world). `runData` left `src/generated` unchanged apart from the ignored `.cache`. The API jar `824813cf…` is unchanged. Log: `gradle-r2-01.log` |
| 2 | `./gradlew --offline test --tests '*ReviewC13R2*'` in `export-r2` (probe in section 5) | 0 | The probe passes: an undecodable acknowledged payload keeps its stub and dirties its chunk on every tick. Log: `gradle-r2-probe-01.log` |
| 3 | Mutant M1: `evaluateIdle(...)` call removed (F1 fix undone); `test --tests '*TransitLedgerTest*'` | 1 (expected) | Only `anIdleEndpointBetweenTwoBudgetSpendingHubsClaimsItsArrival` fails, so the regression test catches F1. Log: `gradle-mutant-m1.log` |
| 4 | Mutant M2: `awaitPruningSave(...)` call removed; `test --tests '*TransitLedgerTest*' --tests '*ReviewC13R2*'` | 1 (expected) | Only `aStubWhoseOnlySaveCameTooEarlyKeepsItsChunkDirtyUntilPruned` fails, so the test catches the stub defect. My probe still passes, with 801 instead of 1,602 dirty marks (see N3). Log: `gradle-mutant-m2.log` |
| 5 | Mutant M3: `facing != trackedFacing` removed from the box-cache condition; `runGameTestServer` | 1 (expected) | 337 GameTests complete, **exactly 1 required test failed**: `anidlegeneratorrecheckswithintwentyticksandseesfuelandfacingatonce failed! A facing change waited 180 ticks`. Log: `gradle-mutant-m3.log` |

## 2. Verdict

**Accept with required changes.**

The code fixes are correct:

- **F1, F6, F8, F9:** fixed, each with a test.
- **F2:** the flush counter is honest. Both revised refload shakeouts now report the flush budget as failed: 207 ms with
  2 flushes over 60 ms, and 202 ms with 6.
- **`3b88c0ba`:** the new stub-pruning fix is right, bounded, and caught by its test.

The F4 harness is not yet right. Four cuts now reach the ADR-054 §11 rows they name, but the removal cuts encode
outcomes that contradict §9 and §9.1:

- `removed-unsaved` timed out in the shakeout, exactly as the code says it must.
- `removed-saved` and `source-removed-unsaved` will fail as written.

F3 has a new regression. With 64 synthetic transfers, the loaded windows hold 118 records and 0.77 MB, not the 256
records and about 1.1 MiB that `13998d64` claims.

## 3. Round-1 findings

| ID | Status | Notes |
|---|---|---|
| F1 idle-set starvation | **Resolved** | A budget-cut sweep now finishes with `evaluateIdle` over the remaining endpoints: no reconcile, no cursor move, and the same predicates as the loop. The cost is O(n) cheap predicates in sweep ticks only. An endpoint woken this way joins the round robin and is visited as before C13 (every second tick in the two-hub case). The regression test's latencies are 0–1 ticks; mutant M1 fails it. |
| F2 flush evidence | **Resolved** | `EndgameTimings` counts flushes over 60 ms for the whole run (`over_60ms`), with a unit test. The harness judges the run-wide maximum, ramp and build included. Shakeout 1: 207.4 ms, 2 flushes over 60 ms, verdict `within: false`. Shakeout 2: 202.2 ms, 6 over, verdict `false`, result `REVIEW`. |
| F3 reference-load fidelity | **Partly resolved; regressed by `13998d64` (N2)** | Resolved: test players tick, field lookups measure 0.036–0.041 ms; one owner per pair; escrows counted; 1,024 endpoints; drills at `{OK=20}` in all windows. The record and root targets are not met (N2). |
| F4 native crash cuts | **Partly resolved; harness still wrong for the removal rows (N1)** | The hold hook works: `registered-unflushed` halts with `pending=true` and no record on disk. `moved-unflushed` is now distinct (`CLAIMED` on disk). `ack-flushed` exists and found a real defect. Energy is asserted per pair. Ride cuts have a saved player file and a "both" branch. The final phase asserts forced chunks and satellites. The elevator cargo cut is added but not yet run. The removal cuts are wrong (N1). |
| F5 flush attribution | **Resolved** (log) | |
| F6 client-thread clear | **Resolved** | `onTagsUpdated` clears only on `SERVER_DATA_LOAD`, with a unit test for all three event shapes. |
| F7 missing tests | **Resolved** | Added: idle wake-up and sweep over consecutive ticks; per-catalog pattern cache; generator idle re-check, fuel and facing GameTest. M1 and M2 confirm the ledger tests catch their defects. M3: see the note below the table. |
| F8 hook state across servers | **Resolved** | A `ServerStoppedEvent` listener resets the load and closes and forgets the channels. Config changes are not reset (N5). |
| F9 terminal placement | **Resolved** | `refreshPlacement()` runs at bind and at cargo launch. The GameTest binds in the tick of the station's deletion and gets `TERMINAL_UNAVAILABLE`. |
| F10 operator guide | **Resolved** | Minor: "at once for binds, removals and operator commands" is broader than the code. Removals with nothing to settle and some operator commands (`endpoint forget`) are coalesced. |
| F11 measurement notes | **Handled in the harness** | The cold idle window is reported (0.158–0.161 ms; the warm one is judged), along with mean-with-flush and the rate, root and drill codes per window. |
| F12 size note | **Partly resolved** | The log says `TransitLedger` is 624 lines; at HEAD it is 647, after `3b88c0ba` and `4da28600`. |
| F13 NBT reload | **Resolved** | Covered by the sweep test (a raw escrow is seen within 20 ticks). |

M3 note (F7, facing GameTest mutation): with `facing` removed from the box-cache condition, the new generator GameTest
fails with "A facing change waited 180 ticks: the structure box was not recomputed", as the commit says.

## 4. New findings

| ID | Severity | Title |
|---|---|---|
| N1 | Medium | Revised native harness: the removal cuts expect outcomes that §9 and §9.1 rule out. `removed-unsaved` already failed in the shakeout; `removed-saved` and `source-removed-unsaved` will fail. The `source-removed-unsaved` removal is not deterministically flushed |
| N2 | Medium | `13998d64`: the loaded reference load holds 118 records and 0.77 MB, not 256 records and about 1.1 MiB. The commit message and the fixture's Javadoc say the live traffic fills to 256 |
| N3 | Low (pre-existing C12 code, surfaced by `3b88c0ba`) | A frozen incoming conflict is re-frozen and audited on every reconcile pass. That is one `INCOMING_QUARANTINED` or `REDIRECT_CONFLICT` INFO line per tick per conflict, the 512-line audit ring floods, and the chunk is dirtied every tick until a resolve |
| N4 | Low | The implementation log's C13 progress section still carries the round-1 claims |
| N5 | Info | `awaitPruningSave` assessment (conforming), plus small notes on the refload harness and the fixture |

### N1 (Medium): the harness's removal cuts contradict the freeze of a retired ID

**Location.** `arce-v170-c13-7013b313…/scripts/native_v170_check.py`: the `cuts` entries `removed-unsaved` and
`removed-saved`, and `source_cut`.

**Contract.**

- ADR-054 §9.1, last paragraph: "A crash after the barrier flush but before the endpoint's chunk saved the removal
  restores the endpoint with its incoming payload and receipt, while the record is ARRIVED and the ID is retired: the
  restored block entity is ENDPOINT_RETIRED and inert, its copy is frozen, and the record is delivered once through a
  redirect."
- §9 and R4-L3, as implemented in `CargoEndpointBlockEntity.checkEndpoint`: a retired ID is frozen for good. Its
  transit contents wait for a resolve or a break, and the ledger skips it (`reconcilable()` is false).

**Evidence and predictions.**

1. **`removed-unsaved` expects `dest`.** The comment says "D comes back and re-claims once". The shakeout's
   `verify-removed-unsaved` **timed out**. Its log shows the restored destination as
   `status=ENDPOINT_RETIRED … incoming=1 receipts=1 receive=40` and the ledger as
   `records=1 … [972660ac…/9:ARRIVED]`. That is §9.1's state, and nothing in the code re-claims it.

   The correct verify would:
   - expect D frozen with incoming 1 and receipts 1, and the record `ARRIVED` (`DESTINATION_MISSING`);
   - have an operator redirect the record (to the source) and assert one delivery there;
   - resolve or break the frozen D and assert `INCOMING_DESTROYED`, not a second delivery;
   - assert D's restored receive buffer (40) unchanged.

   ADR-054 §11 row 6 says "is re-claimed once". Read literally, that conflicts with §9.1. The maintainer should align
   the row's wording with §9.1 ("delivered once through a redirect").
2. **`removed-saved` follows `removed-unsaved` on the same pair.** Pair A's source still targets the now-retired D, so
   its launch is refused and the `escrow` wait times out. Each removal cut needs its own destination: a fresh pair, or
   a re-selected target.
3. **`source-removed-unsaved`** has the steps `register, persist root, remove source`. The source's removal has nothing
   to settle (its record is durable), so it is a coalesced mutation. The harness halts within a few hundred
   milliseconds, before the next coalesced flush (at least 100 ticks after the registration's flush). The disk check
   `present` does not look at S's tombstone. Either way the verify fails:
   - **Removal not flushed (likely):** S restores `ACTIVE`, and its entry is released silently, because the record is
     present and durable. No `OUTBOX_STALE_DROPPED` is logged, so the anomaly assertion fails.
   - **Removal flushed:** S restores `ENDPOINT_RETIRED` and frozen. The ledger never drops its entry, so `settled()`
     (source outbox `[]`) times out. Only a resolve or a break discards it, and that path logs `OUTBOX_DISCARDED`, not
     `OUTBOX_STALE_DROPPED`.

   ADR-054 §11 row 10 ("S restored … Dropped (OUTBOX_STALE_DROPPED)") also does not match the implemented freeze.
   Exactly-once still holds: the record delivers once, and the frozen entry is discarded at resolve because its seq is
   at or below the tombstone's `dispatched_through`.

   Fix:
   - add `persist root` after `remove source`, so the row's "ledger flushed" holds;
   - check S's tombstone on disk;
   - expect a frozen S, run `endpoint resolve <S>`, and assert `OUTBOX_DISCARDED` and one delivery at D;
   - have the maintainer correct the row's wording.

The other cuts reach their rows. The shakeout logs show:

- `registered-unflushed`: `pending=true` at the halt, no record on disk, no `SEQUENCE_GAP` after the restart.
- `registered-flushed`: `pending=false`.
- `claimed-*`: `pending=true` under hold; `REMATERIALIZED` and `CLAIM_RECOVERED` logged.
- `moved-unflushed`: `CLAIMED:ack`.
- `ack-flushed`: `CLAIMED:ack:stub`, acknowledged on disk.

`source-unloaded` (row 11) is correct by reading but was not reached.

### N2 (Medium): the revised reference load no longer reaches 256 records or the reference root

**Location.** `ReferenceLoadFixture.REFERENCE_TRANSFERS = 64` (`13998d64`) and its Javadoc ("64 transfers to which the
live ones add up to the global limit of 256"). The commit says "The root still reaches 256 records".

**Evidence (`arce-v170-c13-refload-shake2`, this commit's jar).**

- `root_records=118` in all three loaded windows, with `accounted_bytes=767488` (0.73 MiB). The idle root has 64
  records and 0.62 MB.
- Each 1,200-tick summary shows `transit_registered=192 … transit_pruned=192`: a steady state of about 54 live
  records.
- Launches escrowed at 2.97 to 3.20 per second. 2,634 launches were refused with `OUTBOX_FULL` and none with
  `TRANSIT_LIMIT`.

So the binding constraint is the persistence gate: four outbox entries per railgun, each waiting for an eager chunk
save plus 40 ticks. The record limit is not reached. The first revised shakeout, with 192 synthetic transfers, held
229–234 records and about 1.06 MB at 2.3 escrows per second.

ADR-054 §7's "256 transit records … a root of about 1.1 MiB" and "16 launching every 20 ticks" cannot both hold under
the gates. The flush (60 ms at the reference root) and ledger budgets are now measured on a root about a third
smaller than the reference.

**Fix.**

- Correct the Javadoc and the commit or log wording.
- Either measure two configurations (about 192 synthetic, for the reference root's flush and ledger cost; 64, for
  throughput) or record the deviation from §7 for the maintainer.
- In both cases, report the achieved records, accounted size and rate next to the verdicts. The harness already
  reports these.

### N3 (Low, pre-existing): a frozen incoming conflict re-freezes and logs every tick

**Location.** `TransitDestinationState.reconcile`, the incoming loop at lines 162–185. It is unchanged since C12
(`62ec8b68`). The records loop and the receipts loop skip `conflicts.contains(key)`; the incoming loop does not.

**Scenario.** An incoming payload whose item no longer decodes (`INCOMING_QUARANTINED`), or one whose record names
another endpoint after an operator file restore (`REDIRECT_CONFLICT`). The endpoint holds contents, so it is never
idle and is visited every tick. Each pass calls `freeze` again, which writes one audit line, and therefore one INFO
log line, and sets `changed`, which calls `transitChanged()`.

**Probe.** `ReviewC13R2StubDirtyProbeTest` builds the `ack-flushed` crash state with an undecodable payload, then runs
1,000 consecutive ticks with a save every 100 ticks. Result:

- the stub is never pruned, because every save shows the payload incoming;
- 1,602 `transitChanged` calls in 800 ticks, of which 801 come from the re-freeze and 801 from `awaitPruningSave`
  (mutant M2 shows 801);
- the audit ring holds **512 of 512 `INCOMING_QUARANTINED` lines**, so all other audit history is gone.

**Impact.** The log floods (20 lines per second per conflict, up to the per-tick audit cap of 64) and
`/arce endgame audit` loses its history until an operator resolves the conflict. No item is lost or duplicated.

**Fix.** Skip `conflicts.contains(key)` in the incoming loop, as the receipts loop does. Then
`awaitPruningSave`'s per-tick dirtying for such a stub is the only remaining cost (N5). This is outside the C13 range,
but it is a one-line fix with a clear test.

### N4 (Low): the log still carries the round-1 overclaims

The "C13 progress" section of the implementation log still says all of these:

- "the eight ADR-054 §11 crash cuts, each … exactly once";
- "synthetic root mass up to 1,024 endpoints, 1,024 tombstones and 256 transfers";
- "16 railguns launch every 20 ticks";
- "every per-system and total budget at the reference load holds with room";
- "an outlier of 116 ms".

The "C13 review fixes" part records only F12 and F5. Before C13 closes, record F1–F4 and F6–F13 with the new
evidence: the achieved rate, the root size, the run-wide flush maximum and `over_60ms`, and the list of cuts and rows
actually covered. Also fix the F12 line count (647).

### N5 (Info): `awaitPruningSave` (`3b88c0ba`) and other notes

**`awaitPruningSave` conforms.** It runs only for a reconcilable, non-idle endpoint, and a stub always names its paid
endpoint, so such an endpoint is never idle. Per visit it iterates `forEndpoint(id)`, which is at most 256 records and
is already built for `destination.reconcile`, and calls `transitChanged()` once. It stops when a save at least 40
ticks after the acknowledgement prunes the stub. That is normally the next eager save of the chunk (cooldown about
10 s); M2 shows the test fails without it.

| Question | Answer |
|---|---|
| Can it keep a chunk dirty forever? | Only while a save shows the payload still incoming. With an aged observation, a paid-here acknowledged payload is moved by the incoming gate, so the only lasting case is a frozen conflict, which N3 already dirties every tick. An unreadable section quarantines the block entity, which then is not reconcilable. |
| Frozen or unowned endpoints? | Skipped before the call. A restored, retired copy is not dirtied; its stub prunes after a resolve or a break. |
| Idle set? | Not touched. `evaluateIdle` does not call it, and the endpoint is visited by the round robin. |
| Saves off? | Dirty every tick until saves resume. That is expected and cheap. |
| After a restart? | `acknowledgedAt` is empty, so the default counts as old, matching the prune rule. |

**Other notes.**

- `ReferenceLoadFixture.build` sets `ENDGAME_LASER_PHYSICAL=true` and `LASER_DRILL_MAX_DEPTH=256` in the common
  config. The F8 stop listener does not restore them (release-test only).
- The refload harness allows "Can't keep up" for the whole run. In shakeout 1 it occurred only at the 24-s build. Scope
  the allowance to the build, or report the warning's time.
- The cold idle mean (0.16 ms) is reported, not judged. That is fine as documented.
- `registered-unflushed`'s verify does not assert that no `SEQUENCE_GAP` was logged. The shakeout log shows none; it
  could be asserted.

## 5. Probe and mutation files

- `export-r2/src/test/java/.../endgame/service/ReviewC13R2StubDirtyProbeTest.java`: N3 and the N5 forever-dirty
  question. Output in `export-r2/build/test-results/test/TEST-*ReviewC13R2*.xml`.
- `mutant/`: M1, M2 and M3 as in section 1. Each mutation was applied and then reverted with `sed`; the logs are
  `gradle-mutant-m1.log`, `gradle-mutant-m2.log` and `gradle-mutant-m3.log`.
- `scripts/refload_r2_detail.py`: the refload summary extraction.
- `harness-r2/`: the revised harness scripts as reviewed.
