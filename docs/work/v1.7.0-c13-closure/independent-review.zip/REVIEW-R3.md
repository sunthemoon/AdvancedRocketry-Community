# v1.7 C13 independent review, round 3

**Subject.** Branch `codex/v1.7.0-endgame-systems`. This round covers the round-2 fixes and two later code commits:

- `13998d64..c85e2f9a`: `17f02044` (N3), `36b8153a` (N2) and `c85e2f9a` (N5);
- `ba479160` and `1ca6fbe7`, added at the coordinator's request, so the final HEAD reviewed is
  `1ca6fbe712be25f488da16628c44507f7ce71ba1`;
- the revised native harness for N1, which lives outside the repository, and its development shakeouts (read-only).

No Gate is passed or claimed.

**Method.**

- The repository was not modified, and no harness was run.
- I kept one export at a time, piped from `git archive` with no tar file kept:
  - `export-r3/` at `c85e2f9a` (built, probed, mutated in place and reverted, then deleted);
  - then `export-r3b/` at `1ca6fbe7` (built, then deleted).

## 1. What I ran

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `./gradlew --offline clean build test runData runGameTestServer` at `c85e2f9a` | 0 | BUILD SUCCESSFUL in 6m23s. JUnit: 254 suites, **1,374 tests, 0 failures, 0 errors, 0 skipped**. **All 337 GameTests passed**. `runData` left `src/generated` unchanged apart from the ignored `.cache`. API jar `824813cf…` is unchanged. Log: `gradle-r3-01.log` |
| 2 | `test --tests '*ReviewC13R*'` at `c85e2f9a`: the round-2 stub probe and the new `ReviewC13R3ConflictProbeTest` | 0 | Stub probe: `incoming_quarantined_audit_lines_in_ring=1` (was 512), with 801 dirty marks in 800 ticks (only `awaitPruningSave` now). Conflict probe: `received=0 incoming=1 conflicts=1`. Logs: `gradle-r3-probe-01.log` and `-02.log` |
| 3 | Mutant at `c85e2f9a`: the N3 skip removed; `test --tests '*TransitLedgerTest*' --tests '*ReviewC13R3*'` | 1 (expected) | Two failures. `aFrozenIncomingPayloadIsAuditedOnce` fails. The conflict probe fails with `received=1 incoming=0 conflicts=1`, a second delivery. Restored and re-run green. Log: `gradle-r3-mutant-n3.log` |
| 4 | `./gradlew --offline clean build test runData runGameTestServer` at `1ca6fbe7` | 0 | BUILD SUCCESSFUL in 5m. JUnit: 254 suites, **1,376 tests, 0 failures, 0 errors, 0 skipped**. That includes `anEndpointWhoseChunkIsNotFullIsLeftAlone`, `aRedirectConflictStaysFrozenAfterItsRecordIsPruned` and `aFrozenIncomingPayloadIsAuditedOnce`. **All 337 GameTests passed** (fresh world). `src/generated` is unchanged apart from `.cache`. API jar `824813cf…` is unchanged. Log: `gradle-r3b-01.log` |

## 2. Verdict

**Accept.** The code in `011e81d1..1ca6fbe7` has no open finding. The only conditions left are about evidence, and
they belong to the closure step the coordinator has already planned.

**Code findings.**

- **Resolved:** N2, N3 (with its safety regression test) and N5.
- **New code is correct:** `1ca6fbe7` fixes a real but exactly-once-safe ledger defect that the shakeouts exposed.
- **Builds:** both exports are green, with 1,374 and 1,376 JUnit tests and all 337 GameTests.

**Native harness (N1).** The revised removal cuts match ADR-054 §9 and §9.1, and the development shakeout
`native-r2-attempt-06` passed:

- all fourteen ledger cuts with their anomaly lines;
- `source-unloaded`, `source-removed-unsaved` and `removed-saved`;
- the elevator cargo cut and the three ride cuts.

Its final phase failed only on a wrong harness assertion (asteroid instances), now fixed.

**Conditions for the C13 close (evidence, not code):**

1. Run the planned closure run on the `1ca6fbe7` jar (attempt 06 used `c85e2f9a`'s), including the patched final
   phase, and archive it.
2. Do N4: the log text with the closure numbers, the size note (`TransitLedger` 654 lines), and the ADR-054 §11 rows 6
   and 10 against §9.1 recorded for the maintainer.
3. Record the Info notes: the Javadoc figures (about 230 records and 1.0 MiB), and stubs at endpoints held below FULL.

## 3. Round-2 findings

### N3: an incoming conflict was re-frozen every pass (`17f02044`, test `ba479160`)

**Resolved.** The incoming loop now skips `conflicts.contains(key)`. A frozen payload is audited once and stays frozen
until a resolve.

The mutation showed the fix also closes a **latent duplicate delivery**, pre-existing since C12. Take a payload frozen
as `REDIRECT_CONFLICT`, for example after an operator restores an older endgame file:

1. Another endpoint delivers the cargo, and its record is pruned.
2. On the next pass the old loop finds no record, so `TransitRules.moves(aged, null)` is true.
3. The stale copy moves into this endpoint's receive buffer, and the key stays in `conflicts` for good.

`ba479160` adds this case as `TransitLedgerTest.aRedirectConflictStaysFrozenAfterItsRecordIsPruned`. It is my probe; the
commit says it fails without the fix, and the mutation in row 3 confirms that. The operator guide's "until you resolve
it" now holds.

### N2: reference root (`36b8153a`)

**Resolved.** `REFERENCE_TRANSFERS` is back to 192. The loaded windows measure the flush and ledger budgets near the
reference root: shakeout 1 measured 229–234 records and 1.01 MiB at 2.3 escrows a second.

The commit records that the outbox and persistence gates allow about 3 escrows a second whatever the synthetic share,
and that ADR-054 §7's 16 launches a second is a deviation for the maintainer.

Info: the Javadoc says "about the 256 records and 1.1 MiB" and "add up to about 256", but measured it is about 230
records and 1.0 MiB, as the commit itself says. Align it with the closure numbers.

### N5: configuration restored at stop (`c85e2f9a`)

**Resolved.**

- The build records the previous `ENDGAME_LASER_PHYSICAL` and `LASER_DRILL_MAX_DEPTH`.
- The stop listener restores them, then resets the load and channels.
- It is a no-op when nothing was built, and release-test only.
- A JVM halted mid-load leaves the values written in the config file. That only matters to the harness, which uses a
  fresh server folder.

### N4: implementation log

**Open, as the coordinator states.**

- The C13 progress text, the closure numbers and the size note are still to be updated. `TransitLedger` is 654 lines
  at `1ca6fbe7`.
- The conflict between ADR-054 §11 rows 6 and 10 and §9.1 goes to the maintainer in `KNOWN-ISSUES` and the log. The
  accepted ADR is not edited, which is the right handling.

### N1: native harness removal cuts

**Resolved by reading, and confirmed by the development shakeout `native-r2-attempt-06`** (`c85e2f9a` jar). That
shakeout passed every phase through `verify-ride-commit-saved`; the final phase failed only on a harness assertion,
fixed since.

I checked the script against the code (copies in `harness-r3/`):

- **`removed-unsaved` (`frozen-dest`).**
  - **Expects:** D restored as `ENDPOINT_RETIRED` with `incoming=1` and `receipts=1`, and the record `ARRIVED`.
  - **Then:** an operator redirect to the source, one delivery there, and `endpoint resolve <D>` giving `destroyed=1`.
    That is right, because once the record is pruned, `resolveIncoming(null)` is `DESTROY`.
  - **Also asserts:** `INCOMING_DESTROYED`, checked after the resolve, and D's receive unchanged.
  - **On disk:** `check_disk` requires D's index entry to be no longer `ACTIVE`. Young tombstones sit in `endpoints`
    with state `RETIRED`, and `uuid_of` matches `UUID.toString`.
- **`removed-saved`** runs on its own pair C.
- **`source-removed-unsaved` (`frozen-source`).**
  - `persist root` after the removal now makes "ledger flushed" deterministic.
  - S is restored retired with `outbox [seq]`, and the record delivers once.
  - The resolve gives `destroyed=1` and `OUTBOX_DISCARDED`: the tombstone keeps `dispatched_through`, so the entry is not
    returned to input.

**Attempt 06 evidence** (audit lines in each phase's log):

| Phase | Audit lines |
|---|---|
| `source-unloaded` | `OUTBOX_STALE_DROPPED` ×1 |
| `verify-source-removed-unsaved` | `OUTBOX_DISCARDED` ×1, `endpoint_resolve` ×1 |
| `verify-removed-unsaved` | `REDIRECT_OPERATOR`, `INCOMING_DESTROYED`, `endpoint_resolve` (×1 each) |
| `verify-removed-saved` | `REDIRECT_OPERATOR` ×1 |
| `verify-elevator-cargo` | `REMATERIALIZED` ×1 |
| ride cuts | `ride_commit` once in each re-ride after a restart |

**Final phase.** It failed on the asteroid `instances` count (6 to 3). ADR-051 §7 expires those with logical time; the
registry counts were unchanged (1,011 satellites, 1,012 missions, 1,000 unfinished, 12 finished). The coordinator now
compares only those four counts and reports instances separately, which is correct.

**Attempts 03–05** failed on harness timing and layout. Each has a `NOTE.txt`, and each led to a fix:

- **03:** the wait for the source to unload only checked the endpoint query, which reports the chunk gone as soon as it
  leaves FULL. The block entity stayed attached and released its entry, so no stale entry existed.
- **04:** a restored endpoint's first status is `AWAITING_WORLD_SAVE` until its 20-tick check; the verify now waits for
  it.
- **05:** pair B's source lay within 13 chunks of forced chunks, so it stayed in memory below FULL and never unloaded.
  Pair B now sits 16–20 chunks away.

My earlier reading of attempt 03 blamed a race with the chunk unload. Attempt 05 shows the chunk never unloaded at all;
that is the root cause, now addressed in code by `1ca6fbe7`.

**Still open:** the closure run with the final jar.

## 4. New code since round 2

### `1ca6fbe7`: leave ledger endpoints in chunks below FULL alone

**Correct.**

**The problem.**

- `Level.blockEntityChanged` marks a chunk unsaved only when `hasChunkAt(pos)`, that is, when the chunk is FULL.
- A chunk within 13 chunks of a forced chunk stays in memory below FULL with its block entities attached, and Forge
  never calls `onChunkUnloaded` for it.
- The ledger kept reconciling such endpoints. It released, claimed and acknowledged state that might never be saved.

That stays exactly-once, because the ledger advances only on observed saves, but progress could stall and the native
cut states were distorted.

**The fix.**

- `TransitEndpoint.transitAccessible()` defaults to true; cargo endpoints return `level.hasChunkAt(worldPosition)`,
  the same test `blockEntityChanged` uses.
- `reconcilable()` returns false first, before any `transitChanged`, so no reconcile runs, nothing is marked idle,
  and `awaitPruningSave` is skipped.
- `loaded(id)` filters out inaccessible endpoints for its only callers: `endpoint resolve`, and `transfer purge` of a
  quarantined entry, which now answers `CHUNK_UNLOADED` or `TRANSFER_NOT_FOUND`.

**What still sees a below-FULL endpoint.** These paths use the raw map, as they should:

- `observed()` still applies save and load tags to it; those are runtime facts about disk.
- `knownOutbox` still counts its outbox entries, so admission stays conservative.

**When the chunk is FULL again,** the endpoint rejoins the round robin. An endpoint already in the idle set is
re-evaluated at the next sweep: at most 20 ticks, or one tick after a table change.

**Cost.** One `hasChunkAt` lookup per visit and per `loaded` call.

**Test.** `anEndpointWhoseChunkIsNotFullIsLeftAlone` covers both the skip and the lookup.

**Side effect, Info.** A stub paid at an endpoint whose chunk stays below FULL indefinitely is not dirtied by
`awaitPruningSave`, so it waits for that chunk to become FULL again or be saved for another reason. It still counts
toward the 256-record limit meanwhile. The record is pinned in the same way as a stub of an unloaded endpoint, and it
is the price of not changing unsavable state. Note it in the closure log.

### `ba479160`

Test only: see N3.

### Other changes

Nothing else new. `TransitDestinationState` gained three lines, `TransitLedgerTest` gained three tests, and the
reference-load fixture and its commands changed. No client imports or package cycles were introduced in common code.

## 5. Files

- `REVIEW-R3.md` (this file).
- Logs: `gradle-r3-01.log`, `gradle-r3-probe-01.log`, `gradle-r3-probe-02.log`, `gradle-r3-mutant-n3.log` and
  `gradle-r3b-01.log`.
- `probes-r3/`: `ReviewC13R3ConflictProbeTest.java`, the JUnit XML at `c85e2f9a` (pass), and `mutant-n3-*.xml`.
- `probes-kept/`: the earlier probe sources.
- `harness-r3/`: the N1 script as first revised, and as patched after attempt 03.
- `diffs-r3/`: one diff per commit, five in all.
- `export-r3/` and `export-r3b/` were deleted after the runs. No tar files or mutant copies remain.
