package io.github.sunthemoon.advancedrocketrycommunity.endgame.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import io.github.sunthemoon.advancedrocketrycommunity.endgame.device.EndgameDeviceTags;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSettings;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.model.EndgameSystem;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.root.EndgameSavedData;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.OutboxEntry;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitCodec;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitDestinationState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitEndpoint;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitKey;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitLimits;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitPayload;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitRecord;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitSourceState;
import io.github.sunthemoon.advancedrocketrycommunity.endgame.transit.TransitTags;
import io.github.sunthemoon.advancedrocketrycommunity.testsupport.MinecraftBootstrap;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Review probe, round 3 (commit 17f02044): a REDIRECT_CONFLICT payload stays frozen after its record is gone. After an
 * operator restores an older endgame file, D's chunk holds an incoming payload whose record names another endpoint, so
 * D freezes it (REDIRECT_CONFLICT). The other endpoint delivers it and the record is pruned. Before 17f02044 the
 * incoming loop did not skip frozen keys: with the record gone, TransitRules.moves(aged, null) is true and D moved its
 * stale copy into its receive buffer (a second delivery), leaving the key in conflicts for good. This probe PASSES when
 * the payload stays frozen and D's buffer stays empty.
 */
final class ReviewC13R3ConflictProbeTest {
    private static final String TYPE = "advancedrocketrycommunity:railgun";
    private static final ResourceLocation KIND = ResourceLocation.tryBuild("advancedrocketrycommunity", "railgun");
    private static final ResourceLocation LEVEL = ResourceLocation.tryBuild("minecraft", "overworld");
    private static final UUID OWNER = new UUID(1L, 1L);
    private static final UUID SOURCE = new UUID(0L, 10L);
    private static final UUID STALE = new UUID(0L, 20L);
    private static final UUID OTHER = new UUID(0L, 30L);
    private static final BlockPos SOURCE_POS = new BlockPos(8, 64, 8);
    private static final BlockPos STALE_POS = new BlockPos(200, 64, 200);
    private static final BlockPos OTHER_POS = new BlockPos(400, 64, 400);

    @BeforeAll
    static void bootstrap() {
        MinecraftBootstrap.initialize();
    }

    private static final class Endpoint implements TransitEndpoint {
        final UUID id;
        final TransitSourceState source = new TransitSourceState();
        final TransitDestinationState destination = new TransitDestinationState();
        final List<ItemStack> received = new ArrayList<>();

        Endpoint(UUID id) {
            this.id = id;
        }

        @Override
        public UUID endpointId() {
            return id;
        }

        @Override
        public Optional<UUID> endpointOwner() {
            return Optional.of(OWNER);
        }

        @Override
        public boolean transitFrozen() {
            return false;
        }

        @Override
        public TransitSourceState source() {
            return source;
        }

        @Override
        public TransitDestinationState destination() {
            return destination;
        }

        @Override
        public TransitDestinationState.ReceiveBuffer receiveBuffer() {
            return new TransitDestinationState.ReceiveBuffer() {
                @Override
                public boolean fits(List<List<ItemStack>> payloads) {
                    return true;
                }

                @Override
                public void insert(List<ItemStack> stacks) {
                    stacks.forEach(stack -> received.add(stack.copy()));
                }
            };
        }

        @Override
        public void transitChanged() {
        }

        @Override
        public boolean returnToInput(List<ItemStack> stacks) {
            return true;
        }

        CompoundTag chunkTag(BlockPos pos) {
            CompoundTag section = new CompoundTag();
            source.write(section);
            destination.write(section);
            CompoundTag root = new CompoundTag();
            root.putUUID(EndgameDeviceTags.DEVICE_ID, id);
            root.put(TransitTags.SECTION, section);
            CompoundTag blockEntity = new CompoundTag();
            blockEntity.putString("id", TYPE);
            blockEntity.putInt("x", pos.getX());
            blockEntity.putInt("y", pos.getY());
            blockEntity.putInt("z", pos.getZ());
            blockEntity.put(EndgameDeviceTags.ROOT, root);
            ListTag list = new ListTag();
            list.add(blockEntity);
            CompoundTag chunk = new CompoundTag();
            chunk.put("block_entities", list);
            return chunk;
        }
    }

    private static void persist(EndgameService service) {
        service.root().orElseThrow().markPersisted();
    }

    @Test
    void aRedirectConflictStaysFrozenAfterItsRecordIsPruned() {
        EndgameService service = new EndgameService(() -> EndgameSettings.DEFAULTS, () -> Set.of(TYPE),
                () -> TransitLimits.DEFAULTS);
        service.startForTest(EndgameSavedData.create());
        service.coalesced(root -> root.register(SOURCE, KIND, OWNER, LEVEL, SOURCE_POS.asLong(), false, 2048, 64));
        service.coalesced(root -> root.register(STALE, KIND, OWNER, LEVEL, STALE_POS.asLong(), false, 2048, 64));
        service.coalesced(root -> root.register(OTHER, KIND, OWNER, LEVEL, OTHER_POS.asLong(), false, 2048, 64));
        persist(service);
        persist(service);
        TransitKey key = new TransitKey(SOURCE, 1L);
        TransitPayload payload = TransitPayload.of(List.of(new ItemStack(Items.DIAMOND, 7))).orElseThrow();
        // The ledger names OTHER (the cargo was redirected there); STALE's restored chunk still holds the payload.
        service.coalesced(root -> {
            root.registerTransit(TransitRecord.registered(SOURCE, new OutboxEntry(1L, OTHER, payload, 1, 20,
                    EndgameSystem.RAILGUN), OWNER, root.saveEpoch(), 0L).arrived().claimed(OTHER));
            return null;
        });
        persist(service);
        persist(service);
        CompoundTag section = new CompoundTag();
        ListTag incoming = new ListTag();
        incoming.add(TransitCodec.encodeIncoming(key, payload));
        ListTag receipts = new ListTag();
        receipts.add(TransitCodec.encodeKey(key));
        section.put("incoming", incoming);
        section.put("receipts", receipts);
        section.put("conflicts", new ListTag());
        Endpoint stale = new Endpoint(STALE);
        stale.destination.read(section);
        service.transits().attach(stale);
        long chunk = new ChunkPos(STALE_POS).toLong();
        service.observe(LEVEL, chunk, stale.chunkTag(STALE_POS), false);
        for (long now = 100L; now <= 150L; now++) {
            service.tick(now);
        }
        assertTrue(stale.destination.conflicts().contains(key), "the stale payload was not frozen");
        // OTHER delivered it; the record is pruned.
        service.coalesced(root -> root.transits().remove(key));
        for (long now = 151L; now <= 250L; now++) {
            service.tick(now);
        }
        System.out.println("REVIEW_PROBE conflict received=" + stale.received.size() + " incoming="
                + stale.destination.incoming().size() + " conflicts=" + stale.destination.conflicts().size());
        assertTrue(stale.received.isEmpty() && stale.destination.incoming().containsKey(key),
                "the frozen stale payload moved into the receive buffer once its record was gone (a second delivery)");
    }
}
