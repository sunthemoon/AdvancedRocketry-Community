"""C13 native evidence for v1.7 (ADR-054 section 11 with two railgun pairs and an elevator) on a COPY of the retained
v1.6 world. Revised after the C13 review (F4): every crash cut reaches the state its ADR-054 section 11 row names, and
each verify phase asserts the row's outcome.

Phases, each a finite dedicated-server process:
  upgrade   the v1.7 host opens the v1.6 world: no endgame file before the first endgame change; the satellite
            registry is read for the final comparison; flush timings of synthetic endgame roots (reference and
            accounted maximum).
  setup     railgun pair A (two chunks, forced) is built and registered through release-test hooks; a payload is put
            into the source; everything is saved.
  cut-N / verify-N   crash cuts. A cut phase turns saves off, launches, drives the transfer to one ledger state, holds
            the coalesced root flush where the row needs the ledger unflushed ("persist hold on"), persists only what
            the row names (the chunks, the root, or a removal), and halts the JVM (exit 75). The root on disk is read
            back and checked against the row before the next start. The verify phase lets the transfer finish (saves
            driven by save-all), and checks that the cargo exists exactly once where the row says, the source paid the
            launch energy exactly when its escrow was saved, the ledger is empty, and the row's audit anomaly
            (CLAIM_RECOVERED, REMATERIALIZED, OUTBOX_STALE_DROPPED) was logged.
            Pair A: escrow unsaved and saved; registered with the ledger unflushed and flushed; claimed with neither,
            only the ledger, or only D saved; moved with the acknowledgement unflushed and flushed (D's chunk not saved
            after the move); D removed by a non-player cause after its chunk saved the claim, the removal's barrier
            flush written but the chunk not saved again. ADR-054 section 9.1: the restored D is ENDPOINT_RETIRED and
            frozen with its incoming payload, the record is ARRIVED and waits as DESTINATION_MISSING; an operator
            redirects it to its source, which receives it once, and resolving the frozen copy destroys the stale
            payload (INCOMING_DESTROYED).
  setup-b, source-unloaded   pair B; a record is pruned while its source is unloaded with the entry still saved in
            its chunk; when the source loads again the entry is dropped (OUTBOX_STALE_DROPPED), delivered once.
  cut/verify source-removed-unsaved   pair B's source is removed after its record is durable, the removal is flushed
            and its chunk is not saved: the restored source is ENDPOINT_RETIRED and frozen with the entry (section 9),
            the record delivers once, and resolving the source discards the entry (OUTBOX_DISCARDED).
  setup-c, cut/verify removed-saved   pair C's D is removed after its chunk saved the claim, and the removal is saved:
            the record waits as DESTINATION_MISSING, an operator redirects it to its source, which receives it once.
  elevator  ADR-059 S2: a station, its terminal and an anchor are built, registered and bound; a test rider with an
            embedded connection rides up and down once, so its player file exists. Cargo from the anchor to the
            terminal is cut with the claim in the flushed ledger only (rematerialized once in space). ride-countdown
            halts during a countdown and ride-commit right after a commit, both with nothing saved after the request:
            the rider's saved Level and the departure's energy show neither the ride. ride-commit-saved saves after
            the commit and halts: both show the ride. Ride and ticket counts are runtime state and are only checked to
            be empty after a start.
  final     restart: the forced chunks are exactly the world's own plus the harness's; the delivered totals and the
            satellite registry are unchanged; endgame timing sampled.

No real clients. The source world is verified unchanged at the end.
"""
import gzip
import hashlib
import json
import re
import shutil
import sys
import time
from pathlib import Path

REPO = Path('D:/GitHub/AdvancedRocketry-Community')
sys.path.insert(0, str(REPO / 'scripts'))
import v140_migration_fixture as fixture  # noqa: E402
import inspect_celestial_saved_data as nbt  # noqa: E402

nbt.MAX_TAGS = 2_000_000
nbt.MAX_COLLECTION_ENTRIES = 65_536
support, server = fixture.support, fixture.server
require, write_json = fixture.require, fixture.write_json

ROOT = Path(__file__).resolve().parent.parent
HISTORY = Path('C:/Users/Administrator/AppData/Local/Temp/arce-v160-c9-1d4b262cc75c4042b9945eebde09cd04'
               '/attempt-04/native-server')
SOURCE = HISTORY / 'world'
FIXTURE_JAR = HISTORY / 'mods/arce-adapter-compat-test-1.0.0.jar'
HOST_JAR = REPO / 'build/libs/advancedrocketry-community-1.20.1-1.7.0-dev.jar'
JAVA = 'C:/Program Files/Java/jdk-17.0.7/bin/java.exe'
HOST = 'advancedrocketrycommunity'
ENDGAME = HOST + '_endgame.dat'
SERVER = ROOT / 'native-server'
OUT = ROOT / 'native'
HALT = 75
OWNER = 'a7c0ffee-0000-4000-8000-000000000017'
PAIR_A = {'name': 'A', 'source': (8192, 120, 8192), 'dest': (8192, 120, 8216)}
# Pair B's ends are six chunks apart: a forced chunk keeps its neighbours loaded up to two chunks away, and pair B's
# source must unload on its own.
PAIR_B = {'name': 'B', 'source': (8320, 120, 8192), 'dest': (8320, 120, 8288)}
# Pair C: a removal cut needs a destination of its own, since a retired ID stays frozen.
PAIR_C = {'name': 'C', 'source': (8448, 120, 8192), 'dest': (8448, 120, 8216)}
PAYLOAD = 5
ANCHOR_POS = (8256, 120, 8192)
RIDER = 'a7c0ffee-0000-4000-8000-0000000000e1'
RIDE_COST = 50_000
SPACE = 'advancedrocketrycommunity:space'
RELEASE = re.compile(r'ARCE_RELEASE_TEST (.*)$')
SAVE_OFF = r'(Automatic saving is now disabled|Saving is already turned off)'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_endgame(world):
    path = world / 'data' / ENDGAME
    if not path.exists():
        return None
    with gzip.open(path, 'rb') as stream:
        payload = stream.read(8 * 1024 ** 2 + 1)
    root = nbt.NbtReader(payload).read_root()
    data = root['data']
    return {'save_epoch': data.get('save_epoch'), 'endpoints': len(data.get('endpoints', [])),
            'endpoint_states': {uuid_of(entry.get('id')): entry.get('state') for entry in data.get('endpoints', [])},
            'transits': [{'seq': record.get('seq'), 'state': record.get('state'),
                          'acknowledged': bool(record.get('acknowledged')),
                          'redirected': bool(record.get('redirected'))} for record in data.get('transits', [])]}


def uuid_of(ints):
    """A UUID from NBT's four-int array, as java.util.UUID prints it."""
    if not ints or len(ints) != 4:
        return None
    value = 0
    for part in ints:
        value = (value << 32) | (part & 0xFFFFFFFF)
    text = f'{value:032x}'
    return f'{text[:8]}-{text[8:12]}-{text[12:16]}-{text[16:20]}-{text[20:]}'


class Phase:
    def __init__(self, name, artifacts, expect_halt=False, allowed=()):
        self.name, self.artifacts, self.expect_halt, self.allowed = name, artifacts, expect_halt, list(allowed)
        self.directory = OUT / name
        self.commands, self.observations = [], {}

    def query(self, process, text, pattern, timeout=60):
        start = len(process.lines)
        self.commands.append(text)
        process.command(text)
        return process.lines[process.wait_for(pattern if hasattr(pattern, 'search') else re.compile(pattern),
                                              timeout, start_at=start)].rstrip()

    def release(self, process, text, prefix, timeout=120):
        line = self.query(process, text, re.compile(r'ARCE_RELEASE_TEST ' + re.escape(prefix)), timeout)
        return RELEASE.search(line).group(1)


def fields(text):
    return dict(part.split('=', 1) for part in text.split() if '=' in part)


def install_mods(artifacts):
    mods = SERVER / 'mods'
    if mods.exists():
        shutil.rmtree(mods)
    mods.mkdir()
    for artifact in artifacts:
        shutil.copyfile(artifact['path'], mods / artifact['name'])
        require(digest(mods / artifact['name']) == artifact['sha256'], 'Installed artifact changed')


def run_phase(phase, port, actions):
    phase.directory.mkdir()
    install_mods(phase.artifacts)
    command = support.rocket_smoke._server_command(JAVA)
    command[2] = '-Xmx2G'
    write_json(phase.directory / 'launch.json', {'command': command, 'cwd': str(SERVER), 'artifacts': phase.artifacts})
    receipt = {'phase': phase.name, 'result': 'IN_PROGRESS'}
    process = None
    started = time.monotonic()
    try:
        process = server.CapturedProcess(command, SERVER, phase.directory / 'stdout.txt')
        process.wait_for(server.READY_MARKER, 300)
        receipt['startup_seconds'] = round(time.monotonic() - started, 1)
        write_json(phase.directory / 'status.json', server.wait_for_status(port))
        actions(phase, process)
        if phase.expect_halt:
            code = process.finish(120)
            require(code == HALT, f'Expected the crash-cut halt ({HALT}), got {code}')
        else:
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
            phase.commands.append('stop')
            process.command('stop')
            code = process.finish(180)
            require(code == 0, 'Server did not stop cleanly')
        findings = server.scan_log(process.lines)
        unexpected = [line for line in findings if not any(re.search(p, line) for p in phase.allowed)]
        require(not unexpected, 'Unexpected log findings: ' + json.dumps(unexpected[:10]))
        receipt.update(result='PASS', exit_code=code, log_counts=server.log_audit_counts(process.lines),
                       findings=findings, observations=phase.observations,
                       endgame_lines=[l.rstrip() for l in process.lines if 'ARCE_ENDGAME' in l][-400:],
                       release_lines=[l.rstrip() for l in process.lines if 'ARCE_RELEASE_TEST' in l])
    except BaseException as exc:
        receipt.update(result='FAIL', error=f'{type(exc).__name__}: {exc}')
        if process is not None:
            process.abort()
        raise
    finally:
        receipt['exit_code'] = process.process.poll() if process is not None else None
        write_json(phase.directory / 'receipt.json', receipt)
        write_json(phase.directory / 'commands.json', phase.commands)
        for name in ('latest.log', 'debug.log'):
            if (SERVER / 'logs' / name).exists():
                shutil.copyfile(SERVER / 'logs' / name, phase.directory / name)
    return receipt


def pos(position):
    return ' '.join(str(value) for value in position)


def in_space(command):
    return f'execute in {SPACE} run {command}'


def endpoint(phase, process, position, space=False, timeout=60, allow_missing=False):
    """One endpoint's state; right after a start its forced chunk may not be loaded yet, so this waits for it."""
    command = f'arce endgame release-test endpoint {pos(position)}'
    command = in_space(command) if space else command
    began = time.monotonic()
    while True:
        answer = fields(phase.release(process, command, 'endpoint'))
        if 'status' in answer:
            return answer
        if allow_missing:
            return None
        if time.monotonic() - began > timeout:
            raise AssertionError(f'{phase.name}: the endpoint at {position} stayed missing')
        time.sleep(0.5)


def ledger(phase, process):
    return phase.release(process, 'arce endgame release-test ledger', 'ledger')


def records(phase, process):
    return int(fields(ledger(phase, process))['records'])


def hold(phase, process, on):
    phase.release(process, f'arce endgame release-test persist hold {"on" if on else "off"}', 'persist hold')


def persist(phase, process, what):
    phase.release(process, f'arce endgame release-test persist {what}', f'persist {what}')


def audited(process, action, since):
    return any(f'action={action}' in line for line in process.lines[since:])


def rider_state(phase, process):
    return fields(phase.release(process, f'arce endgame release-test elevator state {RIDER}', 'elevator state'))


def rider_data(world):
    """The rider's saved Level and block position, from its player data file (None before its first save)."""
    path = world / 'playerdata' / f'{RIDER}.dat'
    if not path.exists():
        return None
    with gzip.open(path, 'rb') as stream:
        root = nbt.NbtReader(stream.read(4 * 1024 ** 2)).read_root()
    position = root.get('Pos', [])
    return {'dimension': root.get('Dimension'), 'pos': [int(value // 1) for value in position]}


def wait_until(phase, process, check, label, timeout=150, save=False, interval=0.5):
    began = time.monotonic()
    while time.monotonic() - began < timeout:
        if save:
            phase.query(process, 'save-all', server.SAVE_MARKER, 60)
        last = check()
        if last:
            return last
        time.sleep(interval)
    raise AssertionError(f'{phase.name}: timed out waiting for {label}')


def satellite_counts(line):
    values = fields(line.split('ARCE_SATELLITE_DIAGNOSTICS', 1)[1])
    return {key: values[key] for key in ('satellites', 'missions', 'unfinished', 'finished', 'instances')}


def main():
    require(not OUT.exists() and not SERVER.exists(), 'Refusing to overwrite evidence or server')
    # The repository's jar is rebuilt by any later Gradle test run; every phase installs this frozen copy.
    frozen = ROOT / 'host-jar' / HOST_JAR.name
    frozen.parent.mkdir(exist_ok=True)
    shutil.copyfile(HOST_JAR, frozen)
    host = support.artifact(frozen, HOST, '1.20.1-1.7.0-dev')
    consumer = support.artifact(FIXTURE_JAR, support.FIXTURE, '1.0.0')
    OUT.mkdir()
    SERVER.mkdir()
    source_inventory = fixture.copy_world(SOURCE, SERVER / 'world')
    write_json(OUT / 'source-world-files.json', source_inventory)
    shutil.copytree(HISTORY / 'libraries', SERVER / 'libraries')
    port = server.allocate_port()
    server.write_server_configuration(SERVER, port, True)
    write_json(OUT / 'inputs.json', {'source_world': str(SOURCE), 'artifacts': [host, consumer], 'owner': OWNER,
                                     'pairs': [PAIR_A, PAIR_B, PAIR_C], 'anchor': ANCHOR_POS, 'payload': PAYLOAD})
    world = SERVER / 'world'
    receipts, results = [], {'cuts': {}, 'cuts_on_disk': {}, 'cuts_at_halt': {}}
    delivered = {'A': 0, 'B': 0, 'C': 0, 'elevator': 0}
    harness_chunks = set()
    launch_cost = {}

    def forceload(phase, process, position):
        phase.query(process, f'forceload add {position[0]} {position[2]}', r'(Marked chunk|force loaded)', 30)
        harness_chunks.add((position[0] >> 4, position[2] >> 4))

    # 1. upgrade: the v1.6 world opens; nothing endgame is written before an endgame change.
    def upgrade_actions(phase, process):
        results['forced_baseline'] = phase.query(process, 'forceload query', r'(No chunks were|force loaded)',
                                                 30).split(']: ', 1)[-1]
        phase.observations['status'] = phase.query(process, 'arce endgame status', r'endgame ', 30)
        phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        require(read_endgame(world) is None, 'An endgame file was written before any endgame change')
        phase.observations['satellite'] = phase.query(process, 'arce satellite admin diagnostics',
                                                      r'ARCE_SATELLITE_DIAGNOSTICS ', 30)
        counts = satellite_counts(phase.observations['satellite'])
        require(int(counts['satellites']) > 0 and int(counts['missions']) > 0, f'No satellite registry: {counts}')
        results['satellites_at_upgrade'] = counts
        phase.observations['flush_reference'] = phase.release(
            process, 'arce endgame release-test flushbench 1024 1024 256 8 10', 'flushbench', 300)
        phase.observations['flush_accounted_maximum'] = phase.release(
            process, 'arce endgame release-test flushbench 2048 8192 256 1024 10', 'flushbench', 600)

    receipts.append(run_phase(Phase('upgrade', [host, consumer]), port, upgrade_actions))
    results['upgrade'] = receipts[-1]['observations']
    results['forced_baseline_chunks'] = sorted(re.findall(r'\[(-?\d+), (-?\d+)\]', results['forced_baseline']))

    # 2. setup: a pair, registered and durable, with a payload in the source.
    def setup_actions(pair):
        def actions(phase, process):
            for position in (pair['source'], pair['dest']):
                forceload(phase, process, position)
            distance = pair['dest'][2] - pair['source'][2]
            built = fields(phase.release(process, f'arce endgame release-test railguns {pos(pair["source"])} {OWNER} '
                                                  f'{distance}', 'railguns', 60))
            require(built['destination_pos'] == ','.join(str(v) for v in pair['dest']), f'Built elsewhere: {built}')
            results['pair_' + pair['name']] = built
            wait_until(phase, process, lambda: endpoint(phase, process, pair['source'])['status'] == 'OK'
                       and endpoint(phase, process, pair['dest'])['status'] == 'OK', 'registration', save=True)
            persist(phase, process, 'root')
            phase.release(process, f'arce endgame release-test fill {pos(pair["source"])} minecraft:diamond {PAYLOAD}',
                          'fill')
            phase.observations['source'] = endpoint(phase, process, pair['source'])
        return actions

    receipts.append(run_phase(Phase('setup', [host, consumer]), port, setup_actions(PAIR_A)))
    results['setup_root'] = read_endgame(world)

    # Each cut: its steps, what the root on disk shows for the cut's record, and where the payload ends.
    #   outcome 'dest': delivered once to the destination; 'source': back in the source's input (escrow lost);
    #   'redirect': the destination was removed, the record waits as DESTINATION_MISSING, an operator redirects it to
    #   its source, which receives it once; 'frozen-dest': as 'redirect', but the destination came back retired and
    #   frozen with the payload incoming, which a resolve then destroys; 'frozen-source': the source came back retired
    #   and frozen with the entry, the record delivers once, and a resolve discards the entry.
    cuts = {
        'escrow-unsaved': dict(pair=PAIR_A, steps=[], disk='absent', outcome='source'),
        'escrow-saved': dict(pair=PAIR_A, steps=['persist chunks'], disk='absent', outcome='dest'),
        'registered-unflushed': dict(pair=PAIR_A, steps=['hold', 'register'], disk='absent', outcome='dest'),
        # A record is claimed only once durable, so the flush that makes it durable never shows it CLAIMED.
        'registered-flushed': dict(pair=PAIR_A, steps=['register', 'persist root'], disk='not CLAIMED',
                                   outcome='dest'),
        'claimed-unsaved': dict(pair=PAIR_A, steps=['register', 'persist root', 'hold', 'claim'],
                                disk='not CLAIMED', outcome='dest'),
        'claimed-root-saved': dict(pair=PAIR_A, steps=['register', 'persist root', 'hold', 'claim', 'persist root'],
                                   disk='CLAIMED', outcome='dest', anomaly='REMATERIALIZED'),
        'claimed-chunk-saved': dict(pair=PAIR_A, steps=['register', 'persist root', 'hold', 'claim',
                                                        'persist chunks'],
                                    disk='not CLAIMED', outcome='dest', anomaly='CLAIM_RECOVERED'),
        'moved-unflushed': dict(pair=PAIR_A, steps=['register', 'persist root', 'claim', 'persist root', 'hold',
                                                    'move'],
                                disk='CLAIMED', outcome='dest'),
        'ack-flushed': dict(pair=PAIR_A, steps=['register', 'persist root', 'claim', 'persist root', 'hold', 'move',
                                                'persist root'],
                            disk='acknowledged', outcome='dest'),
        # D's chunk holds the claim (incoming payload and receipt) when D is removed; the removal's barrier flush
        # returns the claim to ARRIVED and retires D's ID. The last cut of pair A: D stays retired.
        'removed-unsaved': dict(pair=PAIR_A, steps=['register', 'persist root', 'claim', 'persist root',
                                                    'persist chunks', 'remove dest'],
                                disk='ARRIVED', removed_on_disk='dest', outcome='frozen-dest',
                                anomaly='INCOMING_DESTROYED'),
    }

    def drive(phase, process, pair, steps, space=False):
        """Launches from the pair's source with saves off and runs the steps; returns the launch's seq."""
        source, dest = pair['source'], pair['dest']
        phase.query(process, 'save-off', SAVE_OFF, 30)
        seq = int(endpoint(phase, process, source)['next_seq'])
        before = endpoint(phase, process, dest, space)
        phase.release(process, f'arce endgame release-test launch {pos(source)}', 'launch requested')
        wait_until(phase, process, lambda: endpoint(phase, process, source)['outbox'] != '[]', 'escrow')
        for step in steps:
            if step == 'hold':
                hold(phase, process, True)
            elif step == 'register':
                # The saved entry registers once the save's observation is 40 ticks old.
                persist(phase, process, 'chunks')
                wait_until(phase, process, lambda: records(phase, process) == 1, 'registration')
            elif step == 'claim':
                wait_until(phase, process, lambda: endpoint(phase, process, dest, space)['incoming'] == '1', 'claim')
            elif step == 'move':
                # A save shows the incoming payload; 40 ticks later it moves and the claim is acknowledged.
                persist(phase, process, 'chunks')
                wait_until(phase, process, lambda: int(endpoint(phase, process, dest, space)['receive'])
                           > int(before['receive']), 'the move', timeout=60)
            elif step.startswith('persist '):
                persist(phase, process, step.split()[1])
            elif step == 'remove dest':
                phase.query(process, f'setblock {pos(dest)} air', r'(Changed the block|Could not set)', 30)
                require(endpoint(phase, process, dest, space, allow_missing=True) is None, 'The destination stayed')
            elif step == 'remove source':
                phase.query(process, f'setblock {pos(source)} air', r'(Changed the block|Could not set)', 30)
                require(endpoint(phase, process, source, allow_missing=True) is None, 'The source stayed')
            else:
                raise AssertionError(f'Unknown step {step}')
        return seq

    def cut_actions(name, spec):
        def actions(phase, process):
            pair = spec['pair']
            source_before = endpoint(phase, process, pair['source'])
            dest_before = endpoint(phase, process, pair['dest'], spec.get('space', False))
            seq = drive(phase, process, pair, spec['steps'], spec.get('space', False))
            results['cuts_at_halt'][name] = {'seq': seq, 'source_before': source_before, 'dest_before': dest_before,
                                             'source': endpoint(phase, process, pair['source'], allow_missing=True),
                                             'destination': endpoint(phase, process, pair['dest'],
                                                                     spec.get('space', False), allow_missing=True),
                                             'ledger': ledger(phase, process)}
            phase.commands.append('arce endgame release-test halt')
            process.command('arce endgame release-test halt')
        return actions

    def check_disk(name, spec):
        """The root on disk at the halt matches the cut's row."""
        seq = results['cuts_at_halt'][name]['seq']
        root = read_endgame(world)
        results['cuts_on_disk'][name] = root
        found = [record for record in (root or {}).get('transits', []) if record['seq'] == seq]
        want = spec['disk']
        if want == 'absent':
            ok = not found
        elif want == 'not CLAIMED':
            ok = len(found) == 1 and found[0]['state'] != 'CLAIMED' and not found[0]['acknowledged']
        elif want == 'present':
            ok = len(found) == 1 and not found[0]['acknowledged']
        elif want == 'acknowledged':
            ok = len(found) == 1 and found[0]['acknowledged']
        else:
            ok = len(found) == 1 and found[0]['state'] == want and not found[0]['acknowledged']
        require(ok, f'{name}: the root on disk does not show the cut ({want}): {found}')
        removed = spec.get('removed_on_disk')
        if removed:
            at_halt = results['cuts_at_halt'][name]
            removed_id = at_halt['source_before']['id'] if removed == 'source' else at_halt['dest_before']['id']
            state = (root or {}).get('endpoint_states', {}).get(removed_id)
            require(state is not None and state != 'ACTIVE', f'{name}: the removal of {removed} is not on disk '
                    f'({removed_id}: {state})')

    def verify(name, spec):
        def actions(phase, process):
            pair, outcome = spec['pair'], spec['outcome']
            since = 0
            at_halt = results['cuts_at_halt'][name]
            source_id = at_halt['source_before']['id']
            seq = at_halt['seq']
            after = {'source': endpoint(phase, process, pair['source']),
                     'destination': endpoint(phase, process, pair['dest'], allow_missing=outcome == 'redirect'),
                     'ledger': ledger(phase, process)}
            if outcome == 'frozen-dest':
                destination = after['destination']
                require(destination['status'] == 'ENDPOINT_RETIRED' and destination['incoming'] == '1'
                        and destination['receipts'] == '1', f'{name}: D is not restored retired with its claim: '
                        f'{destination}')
                require(f'/{seq}:ARRIVED' in after['ledger'], f'{name}: the record is not ARRIVED: {after["ledger"]}')
            if outcome == 'frozen-source':
                require(after['source']['status'] == 'ENDPOINT_RETIRED' and after['source']['outbox'] == f'[{seq}]',
                        f'{name}: S is not restored retired with its entry: {after["source"]}')
            phase.observations['after_restart'] = after
            # The source paid the launch exactly when its escrow was saved.
            paid = int(at_halt['source_before']['energy']) - int(after['source']['energy'])
            if outcome == 'source':
                require(paid == 0, f'{name}: an unsaved escrow left the source {paid} FE short')
            else:
                cost = launch_cost.setdefault(pair['name'], paid)
                require(paid > 0 and paid == cost, f'{name}: the source paid {paid} FE, its launches cost {cost}')
            if outcome in ('redirect', 'frozen-dest'):
                if outcome == 'redirect':
                    require(after['destination'] is None, f'{name}: the removed destination came back')
                wait_until(phase, process, lambda: records(phase, process) == 1, 'the record')
                answer = phase.query(process, f'arce endgame transfer redirect {source_id} {seq} {source_id}',
                                     r'(transfer_redirect |\([A-Z_]+\)\s*$)', 30)
                require('transfer_redirect ' in answer, f'{name}: the redirect was refused: {answer}')
                phase.observations['redirect'] = answer
            want_dest = (delivered[pair['name']] + (1 if outcome in ('dest', 'frozen-source') else 0)) * PAYLOAD

            def settled():
                source = endpoint(phase, process, pair['source'])
                destination = endpoint(phase, process, pair['dest'], allow_missing=outcome == 'redirect')
                # A frozen endpoint keeps its transit contents until the resolve below.
                source_quiet = outcome == 'frozen-source' or source['outbox'] == '[]'
                dest_quiet = destination is None or outcome == 'frozen-dest' or (
                    destination['incoming'] == '0' and destination['receipts'] == '0')
                quiet = records(phase, process) == 0 and source_quiet and source['incoming'] == '0' \
                    and source['receipts'] == '0' and dest_quiet
                if outcome in ('redirect', 'frozen-dest'):
                    return (source, destination) if quiet and int(source['receive']) >= PAYLOAD else None
                return (source, destination) if quiet and int(destination['receive']) >= want_dest else None

            source, destination = wait_until(phase, process, settled, f'{name} settling', timeout=240, save=True,
                                             interval=2.0)
            if outcome in ('redirect', 'frozen-dest'):
                require(int(source['receive']) == PAYLOAD and int(source['input']) == 0,
                        f'{name}: the redirected payload is not in the source exactly once: {source}')
            else:
                require(int(destination['receive']) == want_dest, f'{name}: the destination holds '
                        f'{destination["receive"]}, expected {want_dest}')
                require(int(source['input']) == (PAYLOAD if outcome == 'source' else 0),
                        f'{name}: the source input holds {source["input"]}')
            if outcome in ('frozen-dest', 'frozen-source'):
                # The frozen copy's stale contents: one item set, destroyed or discarded by the resolve.
                frozen_side = 'dest' if outcome == 'frozen-dest' else 'source'
                frozen = endpoint(phase, process, pair[frozen_side])
                answer = phase.query(process, f'arce endgame endpoint resolve {frozen["id"]}',
                                     r'(endpoint_resolve |\([A-Z_]+\)\s*$)', 30)
                require('endpoint_resolve ' in answer and 'destroyed=1' in answer,
                        f'{name}: the resolve did not discard the stale contents once: {answer}')
                phase.observations['resolve'] = answer
                resolved = endpoint(phase, process, pair[frozen_side])
                require(resolved['incoming'] == '0' and resolved['receipts'] == '0' and resolved['outbox'] == '[]'
                        and resolved['receive'] == frozen['receive'] and resolved['input'] == frozen['input'],
                        f'{name}: the resolve moved something: {frozen} -> {resolved}')
                if outcome == 'frozen-source':
                    source = resolved
                else:
                    destination = resolved
            if outcome == 'frozen-dest':
                require(int(destination['receive']) == int(results['cuts_at_halt'][name]['dest_before']['receive']),
                        f'{name}: the frozen D\'s receive buffer changed: {destination}')
            if spec.get('anomaly'):
                require(audited(process, spec['anomaly'], since), f'{name}: no {spec["anomaly"]} audit line')
            if outcome in ('dest', 'frozen-source'):
                delivered[pair['name']] += 1
            results['cuts'][name] = {'outcome': outcome, 'source': source, 'destination': destination,
                                     'paid_fe': paid, 'ledger': ledger(phase, process), 'after_restart': after,
                                     'anomaly': spec.get('anomaly')}
            if outcome == 'dest':
                phase.release(process, f'arce endgame release-test fill {pos(pair["source"])} minecraft:diamond '
                                       f'{PAYLOAD}', 'fill')
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        return actions

    for name, spec in cuts.items():
        receipts.append(run_phase(Phase('cut-' + name, [host, consumer], expect_halt=True), port,
                                  cut_actions(name, spec)))
        check_disk(name, spec)
        receipts.append(run_phase(Phase('verify-' + name, [host, consumer]), port, verify(name, spec)))

    # 3. Pair B: a record pruned while its source is unloaded with the entry saved; then a source removal cut.
    receipts.append(run_phase(Phase('setup-b', [host, consumer]), port, setup_actions(PAIR_B)))

    def source_unloaded(phase, process):
        source, dest = PAIR_B['source'], PAIR_B['dest']
        hold(phase, process, True)
        seq = int(endpoint(phase, process, source)['next_seq'])
        phase.release(process, f'arce endgame release-test launch {pos(source)}', 'launch requested')
        wait_until(phase, process, lambda: endpoint(phase, process, source)['outbox'] != '[]', 'escrow')
        persist(phase, process, 'chunks')
        wait_until(phase, process, lambda: records(phase, process) == 1, 'registration')
        # The record is not durable (held), so the source keeps its entry; its chunk unloads and saves it.
        phase.query(process, f'forceload remove {source[0]} {source[2]}', r'(Unmarked chunk|not marked)', 30)
        harness_chunks.discard((source[0] >> 4, source[2] >> 4))
        wait_until(phase, process, lambda: endpoint(phase, process, source, allow_missing=True) is None,
                   'the source unloading', timeout=120, interval=1.0)
        hold(phase, process, False)
        persist(phase, process, 'root')
        since = len(process.lines)
        wait_until(phase, process, lambda: records(phase, process) == 0
                   and int(endpoint(phase, process, dest)['receive']) == PAYLOAD, 'delivery and pruning',
                   timeout=240, save=True, interval=2.0)
        forceload(phase, process, source)
        restored = wait_until(phase, process, lambda: (lambda state: state if state['outbox'] == '[]' else None)(
            endpoint(phase, process, source)), 'the stale entry dropped', timeout=120, save=True, interval=1.0)
        require(audited(process, 'OUTBOX_STALE_DROPPED', since), 'source-unloaded: no OUTBOX_STALE_DROPPED line')
        destination = endpoint(phase, process, dest)
        require(int(destination['receive']) == PAYLOAD and int(restored['input']) == 0,
                f'source-unloaded: not delivered exactly once: {destination} {restored}')
        delivered['B'] += 1
        results['source_unloaded'] = {'seq': seq, 'source': restored, 'destination': destination}
        phase.release(process, f'arce endgame release-test fill {pos(source)} minecraft:diamond {PAYLOAD}', 'fill')

    receipts.append(run_phase(Phase('source-unloaded', [host, consumer]), port, source_unloaded))
    source_cut = dict(pair=PAIR_B, steps=['register', 'persist root', 'remove source', 'persist root'],
                      disk='present', removed_on_disk='source', outcome='frozen-source', anomaly='OUTBOX_DISCARDED')
    receipts.append(run_phase(Phase('cut-source-removed-unsaved', [host, consumer], expect_halt=True), port,
                              cut_actions('source-removed-unsaved', source_cut)))
    check_disk('source-removed-unsaved', source_cut)
    receipts.append(run_phase(Phase('verify-source-removed-unsaved', [host, consumer]), port,
                              verify('source-removed-unsaved', source_cut)))

    receipts.append(run_phase(Phase('setup-c', [host, consumer]), port, setup_actions(PAIR_C)))
    removed_saved = dict(pair=PAIR_C, steps=['register', 'persist root', 'claim', 'persist root', 'persist chunks',
                                             'remove dest', 'persist chunks'],
                         disk='ARRIVED', removed_on_disk='dest', outcome='redirect')
    receipts.append(run_phase(Phase('cut-removed-saved', [host, consumer], expect_halt=True), port,
                              cut_actions('removed-saved', removed_saved)))
    check_disk('removed-saved', removed_saved)
    receipts.append(run_phase(Phase('verify-removed-saved', [host, consumer]), port,
                              verify('removed-saved', removed_saved)))

    # 4. ADR-059 S2: an elevator pair, a cargo cut and forced stops around rides.
    elevator = {}

    def request_ride(phase, process, up, retry=0):
        position, space = departure_of(up)
        command = f'arce endgame release-test elevator ride {pos(position)} {RIDER}'

        def asked():
            answer = fields(phase.release(process, in_space(command) if space else command, 'elevator ride'))
            return answer if answer['code'] == 'RIDE_COUNTDOWN' else None

        if retry:
            # A commit starts a 200-tick cooldown.
            return wait_until(phase, process, asked, 'a ride', timeout=retry, interval=2.0)
        answer = asked()
        require(answer is not None, 'The ride was refused')
        return answer

    def arrived(phase, process, up):
        state = rider_state(phase, process)
        want = SPACE if up else 'minecraft:overworld'
        return state if state.get('rider') == want and state['pending'] == 'false' else None

    def departure_of(up):
        return (ANCHOR_POS, False) if up else (elevator['terminal_xyz'], True)

    def elevator_setup(phase, process):
        forceload(phase, process, ANCHOR_POS)
        built = fields(phase.release(process, f'arce endgame release-test elevator build {pos(ANCHOR_POS)} {OWNER} '
                                              f'{RIDER}', 'elevator built', 60))
        elevator.update(built)
        elevator['terminal_xyz'] = tuple(int(value) for value in built['terminal_pos'].split(','))
        wait_until(phase, process, lambda: endpoint(phase, process, ANCHOR_POS)['status'] == 'OK'
                   and endpoint(phase, process, elevator['terminal_xyz'], True)['status'] == 'OK',
                   'elevator registration', save=True)
        persist(phase, process, 'root')
        bound = fields(phase.release(process, f'arce endgame release-test elevator bind {built["station"]}',
                                     'elevator bind'))
        require(bound['code'] == 'OK', f'The elevator bind failed: {bound}')
        phase.observations['bind'] = bound
        # One ride up and one down with saves on, so the rider's player file exists for the ride cuts.
        request_ride(phase, process, True)
        wait_until(phase, process, lambda: arrived(phase, process, True), 'the setup ride up', timeout=60)
        request_ride(phase, process, False, retry=60)
        wait_until(phase, process, lambda: arrived(phase, process, False), 'the setup ride down', timeout=60)
        phase.release(process, f'arce endgame release-test fill {pos(ANCHOR_POS)} minecraft:diamond {PAYLOAD}', 'fill')

    receipts.append(run_phase(Phase('elevator-setup', [host, consumer]), port, elevator_setup))
    results['elevator'] = dict(elevator, terminal_xyz=list(elevator['terminal_xyz']))
    elevator_pair = {'name': 'elevator', 'source': ANCHOR_POS, 'dest': elevator['terminal_xyz']}
    cargo_cut = dict(pair=elevator_pair, space=True, steps=['register', 'persist root', 'hold', 'claim',
                                                            'persist root'],
                     disk='CLAIMED', outcome='dest', anomaly='REMATERIALIZED')

    def elevator_verify(name, spec):
        """As verify, with the destination in space."""
        def actions(phase, process):
            at_halt = results['cuts_at_halt'][name]
            after = {'source': endpoint(phase, process, ANCHOR_POS),
                     'destination': endpoint(phase, process, elevator['terminal_xyz'], True)}
            paid = int(at_halt['source_before']['energy']) - int(after['source']['energy'])
            require(paid > 0, f'{name}: the anchor did not pay the saved escrow: {paid}')
            want = PAYLOAD

            def settled():
                source = endpoint(phase, process, ANCHOR_POS)
                destination = endpoint(phase, process, elevator['terminal_xyz'], True)
                quiet = records(phase, process) == 0 and source['outbox'] == '[]' \
                    and destination['incoming'] == '0' and destination['receipts'] == '0'
                return (source, destination) if quiet and int(destination['receive']) >= want else None

            source, destination = wait_until(phase, process, settled, f'{name} settling', timeout=240, save=True,
                                             interval=2.0)
            require(int(destination['receive']) == want and int(source['input']) == 0,
                    f'{name}: the cargo is not in the terminal exactly once: {source} {destination}')
            require(audited(process, spec['anomaly'], 0), f'{name}: no {spec["anomaly"]} audit line')
            delivered['elevator'] += 1
            results['cuts'][name] = {'outcome': 'dest', 'source': source, 'destination': destination,
                                     'paid_fe': paid, 'after_restart': after, 'anomaly': spec['anomaly']}
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        return actions

    receipts.append(run_phase(Phase('cut-elevator-cargo', [host, consumer], expect_halt=True), port,
                              cut_actions('elevator-cargo', cargo_cut)))
    check_disk('elevator-cargo', cargo_cut)
    receipts.append(run_phase(Phase('verify-elevator-cargo', [host, consumer]), port,
                              elevator_verify('elevator-cargo', cargo_cut)))

    def ride_cut(name, up, after_commit, saved):
        def actions(phase, process):
            position, space = departure_of(up)
            elevator[f'energy_{name}'] = int(endpoint(phase, process, position, space)['energy'])
            phase.query(process, 'save-off', SAVE_OFF, 30)
            phase.observations['request'] = request_ride(phase, process, up, retry=60)
            if after_commit:
                phase.observations['committed'] = wait_until(phase, process, lambda: arrived(phase, process, up),
                                                             'the commit', timeout=60, interval=0.2)
            else:
                time.sleep(1.0)
                state = rider_state(phase, process)
                require(state['pending'] == 'true' and state['tickets'] == '1', f'No countdown at the cut: {state}')
                phase.observations['countdown'] = state
            if saved:
                # save-all writes the players, the chunks and the root even with saves off.
                phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
            phase.observations['departure_at_halt'] = endpoint(phase, process, position, space)
            phase.commands.append('arce endgame release-test halt')
            process.command('arce endgame release-test halt')
        return actions

    def ride_verify(name, up, saved):
        def actions(phase, process):
            position, space = departure_of(up)
            state = rider_state(phase, process)
            # Runtime state: a fresh start has none; checked so nothing restores a ride.
            require(state['rider'] == 'offline' and state['rides'] == '0' and state['tickets'] == '0',
                    f'{name}: a ride or ticket after the start: {state}')
            departure = endpoint(phase, process, position, space)
            data = rider_data(world)
            before = elevator['rider_saved']
            require(before is not None, f'{name}: the rider had no saved player file before the cut')
            if saved:
                # Both: the debit and the rider's arrival Level were saved together.
                require(int(departure['energy']) == elevator[f'energy_{name}'] - RIDE_COST,
                        f'{name}: the saved ride was not debited: {departure}')
                require(data['dimension'] == (SPACE if up else 'minecraft:overworld'),
                        f'{name}: the saved ride did not move the rider: {data}')
            else:
                # Neither: nothing saved after the request.
                require(int(departure['energy']) == elevator[f'energy_{name}'], f'{name}: departure {departure}')
                require(data == before, f'{name}: the rider data changed: {data}')
            phase.observations['after_restart'] = {'state': state, 'departure': departure, 'rider_data': data}
            results['rides'][name] = {'after_restart': phase.observations['after_restart'], 'saved': saved,
                                      'rider_before': before}
            if not saved:
                # The same ride now commits and is saved.
                request_ride(phase, process, up, retry=60)
                wait_until(phase, process, lambda: arrived(phase, process, up), 'the ride after restart', timeout=60)
                debited = int(endpoint(phase, process, position, space)['energy'])
                require(debited == elevator[f'energy_{name}'] - RIDE_COST, f'{name}: the ride cost {debited}')
                results['rides'][name]['debited_to'] = debited
            phase.query(process, 'save-all flush', server.SAVE_MARKER, 120)
        return actions

    results['rides'] = {}
    for name, up, after_commit, saved in (('ride-countdown', True, False, False),
                                          ('ride-commit', False, True, False),
                                          ('ride-commit-saved', True, True, True)):
        elevator['rider_saved'] = rider_data(world)
        receipts.append(run_phase(Phase('cut-' + name, [host, consumer], expect_halt=True), port,
                                  ride_cut(name, up, after_commit, saved)))
        receipts.append(run_phase(Phase('verify-' + name, [host, consumer]), port, ride_verify(name, up, saved)))
    results['rides']['final_rider_data'] = rider_data(world)
    require(results['rides']['final_rider_data']['dimension'] == SPACE, 'The rider was not saved up')

    # 5. final: a clean restart; the world's and the harness's forced chunks only; totals unchanged.
    def final_actions(phase, process):
        query = phase.query(process, 'forceload query', r'(No chunks were|force loaded)', 30).split(']: ', 1)[-1]
        phase.observations['forceload_query'] = query
        forced = {tuple(int(v) for v in pair) for pair in re.findall(r'\[(-?\d+), (-?\d+)\]', query)}
        baseline = {tuple(int(v) for v in pair) for pair in results['forced_baseline_chunks']}
        require(forced == baseline | harness_chunks, f'Forced chunks {sorted(forced)} are not the world\'s '
                f'{sorted(baseline)} plus the harness\'s {sorted(harness_chunks)}')
        for pair in (PAIR_A, PAIR_B):
            state = endpoint(phase, process, pair['dest'], allow_missing=True)
            phase.observations['destination_' + pair['name']] = state
            if pair is PAIR_B:
                require(int(state['receive']) == delivered['B'] * PAYLOAD,
                        'The final restart changed pair B\'s delivered total')
        terminal = endpoint(phase, process, elevator['terminal_xyz'], True)
        require(int(terminal['receive']) == delivered['elevator'] * PAYLOAD, 'The terminal total changed')
        phase.observations['ledger'] = ledger(phase, process)
        require(records(phase, process) == 0, 'Records remain at the final restart')
        satellite = phase.query(process, 'arce satellite admin diagnostics', r'ARCE_SATELLITE_DIAGNOSTICS ', 30)
        phase.observations['satellite'] = satellite
        require(satellite_counts(satellite) == results['satellites_at_upgrade'],
                f'The satellite registry changed: {satellite_counts(satellite)}')
        time.sleep(65)
        phase.observations['timing'] = phase.release(process, 'arce endgame release-test timing', 'timing')
        phase.observations['status'] = phase.query(process, 'arce endgame status', r'endgame ', 30)

    receipts.append(run_phase(Phase('final', [host, consumer]), port, final_actions))
    results['final'] = receipts[-1]['observations']
    results['final_root'] = read_endgame(world)
    results['delivered'] = delivered
    results['launch_cost_fe'] = launch_cost
    require(fixture.inventory(SOURCE) == source_inventory, 'The source world was changed')
    write_json(OUT / 'summary.json', {'result': 'PASS', 'source_world_unchanged': True, 'results': results,
                                      'cycles': receipts})
    print('PASS: v1.7 native upgrade, flush benchmark, twelve ledger crash cuts and a pruned-while-unloaded source '
          'with three railgun pairs, an elevator cargo cut, three ride forced stops, final restart')


if __name__ == '__main__':
    main()
